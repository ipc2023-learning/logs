begin_version
3
end_version
begin_metric
0
end_metric
60
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera2, rover3)
NegatedAtom calibrated(camera2, rover3)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var128
-1
2
Atom have_image(rover3, objective9, low_res)
NegatedAtom have_image(rover3, objective9, low_res)
end_variable
begin_variable
var126
-1
2
Atom have_image(rover3, objective9, colour)
NegatedAtom have_image(rover3, objective9, colour)
end_variable
begin_variable
var118
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var117
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var116
-1
2
Atom have_image(rover3, objective5, low_res)
NegatedAtom have_image(rover3, objective5, low_res)
end_variable
begin_variable
var114
-1
2
Atom have_image(rover3, objective5, colour)
NegatedAtom have_image(rover3, objective5, colour)
end_variable
begin_variable
var112
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var109
-1
2
Atom have_image(rover3, objective3, high_res)
NegatedAtom have_image(rover3, objective3, high_res)
end_variable
begin_variable
var107
-1
2
Atom have_image(rover3, objective2, low_res)
NegatedAtom have_image(rover3, objective2, low_res)
end_variable
begin_variable
var105
-1
2
Atom have_image(rover3, objective2, colour)
NegatedAtom have_image(rover3, objective2, colour)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover3, objective1, colour)
NegatedAtom have_image(rover3, objective1, colour)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var6
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var7
-1
2
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var8
-1
2
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
end_variable
begin_variable
var9
-1
2
Atom at_rock_sample(waypoint9)
Atom have_rock_analysis(rover3, waypoint9)
end_variable
begin_variable
var55
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var48
-1
2
Atom communicated_rock_data(waypoint8)
NegatedAtom communicated_rock_data(waypoint8)
end_variable
begin_variable
var47
-1
2
Atom communicated_rock_data(waypoint7)
NegatedAtom communicated_rock_data(waypoint7)
end_variable
begin_variable
var46
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var45
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var44
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var101
-1
2
Atom have_image(rover2, objective9, low_res)
NegatedAtom have_image(rover2, objective9, low_res)
end_variable
begin_variable
var99
-1
2
Atom have_image(rover2, objective9, colour)
NegatedAtom have_image(rover2, objective9, colour)
end_variable
begin_variable
var91
-1
2
Atom have_image(rover2, objective6, high_res)
NegatedAtom have_image(rover2, objective6, high_res)
end_variable
begin_variable
var33
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var90
-1
2
Atom have_image(rover2, objective6, colour)
NegatedAtom have_image(rover2, objective6, colour)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var87
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var85
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var82
-1
2
Atom have_i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




331
2
26 0
27 0
0
337
2
26 1
27 0
0
349
2
26 2
27 0
0
370
2
26 3
27 0
0
391
2
26 4
27 0
0
403
2
26 5
27 0
0
424
2
26 6
27 0
0
436
2
26 7
27 0
0
454
2
26 8
27 0
end_DTG
begin_DTG
0
5
0
336
2
26 1
27 0
0
369
2
26 3
27 0
0
390
2
26 4
27 0
0
423
2
26 6
27 0
0
453
2
26 8
27 0
end_DTG
begin_DTG
0
5
0
334
2
26 1
27 0
0
367
2
26 3
27 0
0
388
2
26 4
27 0
0
421
2
26 6
27 0
0
451
2
26 8
27 0
end_DTG
begin_DTG
0
5
0
329
2
26 0
27 0
0
365
2
26 3
27 0
0
386
2
26 4
27 0
0
419
2
26 6
27 0
0
449
2
26 8
27 0
end_DTG
begin_DTG
0
8
0
74
2
26 0
35 0
0
75
2
26 1
35 0
0
76
2
26 2
35 0
0
77
2
26 4
35 0
0
118
2
0 0
9 0
0
119
2
0 1
9 0
0
120
2
0 2
9 0
0
121
2
0 4
9 0
end_DTG
begin_DTG
0
7
0
326
2
26 0
27 0
0
347
2
26 2
27 0
0
362
2
26 3
27 0
0
383
2
26 4
27 0
0
416
2
26 6
27 0
0
434
2
26 7
27 0
0
446
2
26 8
27 0
end_DTG
begin_DTG
0
8
0
70
2
26 0
37 0
0
71
2
26 1
37 0
0
72
2
26 2
37 0
0
73
2
26 4
37 0
0
114
2
0 0
10 0
0
115
2
0 1
10 0
0
116
2
0 2
10 0
0
117
2
0 4
10 0
end_DTG
begin_DTG
0
4
0
345
2
26 2
27 0
0
360
2
26 3
27 0
0
381
2
26 4
27 0
0
402
2
26 5
27 0
end_DTG
begin_DTG
0
4
0
343
2
26 2
27 0
0
358
2
26 3
27 0
0
379
2
26 4
27 0
0
400
2
26 5
27 0
end_DTG
begin_DTG
0
3
0
355
2
26 3
27 0
0
412
2
26 6
27 0
0
442
2
26 8
27 0
end_DTG
begin_DTG
3
1
167
0
5
168
0
8
169
0
3
0
170
0
6
171
0
8
172
0
3
3
173
0
7
174
0
8
175
0
1
2
176
0
2
6
177
0
8
178
0
2
0
179
0
7
180
0
3
1
181
0
4
182
0
7
183
0
3
2
184
0
5
185
0
6
186
0
4
0
187
0
1
188
0
2
189
0
4
190
0
end_DTG
begin_DTG
9
1
291
1
42 5
1
302
1
42 6
1
284
1
42 4
1
314
1
42 8
1
312
1
42 7
1
246
1
42 1
1
257
1
42 3
1
254
1
42 2
1
240
1
42 0
5
0
0
1
42 1
0
1
1
42 3
0
2
1
42 4
0
3
1
42 6
0
4
1
42 8
end_DTG
begin_DTG
0
1
0
306
2
42 6
43 0
end_DTG
begin_DTG
0
12
0
54
2
42 0
44 0
0
55
2
42 1
44 0
0
56
2
42 2
44 0
0
57
2
42 4
44 0
0
98
2
26 0
28 0
0
99
2
26 1
28 0
0
100
2
26 2
28 0
0
101
2
26 4
28 0
0
142
2
0 0
3 0
0
143
2
0 1
3 0
0
144
2
0 2
3 0
0
145
2
0 4
3 0
end_DTG
begin_DTG
0
1
0
305
2
42 6
43 0
end_DTG
begin_DTG
0
12
0
50
2
42 0
46 0
0
51
2
42 1
46 0
0
52
2
42 2
46 0
0
53
2
42 4
46 0
0
94
2
26 0
29 0
0
95
2
26 1
29 0
0
96
2
26 2
29 0
0
97
2
26 4
29 0
0
138
2
0 0
4 0
0
139
2
0 1
4 0
0
140
2
0 2
4 0
0
141
2
0 4
4 0
end_DTG
begin_DTG
0
9
0
239
2
42 0
43 0
0
243
2
42 1
43 0
0
251
2
42 2
43 0
0
265
2
42 3
43 0
0
279
2
42 4
43 0
0
287
2
42 5
43 0
0
301
2
42 6
43 0
0
309
2
42 7
43 0
0
321
2
42 8
43 0
end_DTG
begin_DTG
0
12
0
46
2
42 0
48 0
0
47
2
42 1
48 0
0
48
2
42 2
48 0
0
49
2
42 4
48 0
0
86
2
26 0
32 0
0
87
2
26 1
32 0
0
88
2
26 2
32 0
0
89
2
26 4
32 0
0
130
2
0 0
6 0
0
131
2
0 1
6 0
0
132
2
0 2
6 0
0
133
2
0 4
6 0
end_DTG
begin_DTG
0
5
0
242
2
42 1
43 0
0
264
2
42 3
43 0
0
278
2
42 4
43 0
0
300
2
42 6
43 0
0
320
2
42 8
43 0
end_DTG
begin_DTG
0
12
0
42
2
42 0
50 0
0
43
2
42 1
50 0
0
44
2
42 2
50 0
0
45
2
42 4
50 0
0
82
2
26 0
33 0
0
83
2
26 1
33 0
0
84
2
26 2
33 0
0
85
2
26 4
33 0
0
126
2
0 0
7 0
0
127
2
0 1
7 0
0
128
2
0 2
7 0
0
129
2
0 4
7 0
end_DTG
begin_DTG
0
5
0
241
2
42 1
43 0
0
263
2
42 3
43 0
0
277
2
42 4
43 0
0
299
2
42 6
43 0
0
319
2
42 8
43 0
end_DTG
begin_DTG
0
12
0
38
2
42 0
52 0
0
39
2
42 1
52 0
0
40
2
42 2
52 0
0
41
2
42 4
52 0
0
78
2
26 0
34 0
0
79
2
26 1
34 0
0
80
2
26 2
34 0
0
81
2
26 4
34 0
0
122
2
0 0
8 0
0
123
2
0 1
8 0
0
124
2
0 2
8 0
0
125
2
0 4
8 0
end_DTG
begin_DTG
0
4
0
248
2
42 2
43 0
0
258
2
42 3
43 0
0
272
2
42 4
43 0
0
286
2
42 5
43 0
end_DTG
begin_DTG
0
12
0
34
2
42 0
54 0
0
35
2
42 1
54 0
0
36
2
42 2
54 0
0
37
2
42 4
54 0
0
66
2
26 0
39 0
0
67
2
26 1
39 0
0
68
2
26 2
39 0
0
69
2
26 4
39 0
0
110
2
0 0
11 0
0
111
2
0 1
11 0
0
112
2
0 2
11 0
0
113
2
0 4
11 0
end_DTG
begin_DTG
0
4
0
247
2
42 2
43 0
0
257
2
42 3
43 0
0
271
2
42 4
43 0
0
285
2
42 5
43 0
end_DTG
begin_DTG
0
12
0
30
2
42 0
56 0
0
31
2
42 1
56 0
0
32
2
42 2
56 0
0
33
2
42 4
56 0
0
62
2
26 0
40 0
0
63
2
26 1
40 0
0
64
2
26 2
40 0
0
65
2
26 4
40 0
0
106
2
0 0
12 0
0
107
2
0 1
12 0
0
108
2
0 2
12 0
0
109
2
0 4
12 0
end_DTG
begin_DTG
0
3
0
255
2
42 3
43 0
0
293
2
42 6
43 0
0
313
2
42 8
43 0
end_DTG
begin_DTG
0
12
0
26
2
42 0
58 0
0
27
2
42 1
58 0
0
28
2
42 2
58 0
0
29
2
42 4
58 0
0
58
2
26 0
41 0
0
59
2
26 1
41 0
0
60
2
26 2
41 0
0
61
2
26 4
41 0
0
102
2
0 0
13 0
0
103
2
0 1
13 0
0
104
2
0 2
13 0
0
105
2
0 4
13 0
end_DTG
begin_CG
36
14 1
15 1
16 1
17 1
18 1
19 1
2 144
1 48
59 4
57 4
55 4
38 4
36 4
53 4
51 4
49 4
31 4
47 4
45 4
25 4
24 4
23 4
22 4
21 4
20 6
13 6
12 8
11 4
10 7
9 5
8 10
7 5
6 18
5 9
4 2
3 1
5
13 3
12 4
8 5
6 9
4 1
11
13 3
12 4
11 4
10 7
9 5
8 5
7 5
6 9
5 9
4 1
3 1
1
45 4
1
47 4
1
31 4
1
49 4
1
51 4
1
53 4
1
36 4
1
38 4
1
55 4
1
57 4
1
59 4
2
25 4
20 1
2
24 4
20 1
2
23 4
20 1
2
22 4
20 1
2
21 4
20 1
1
20 1
6
14 1
15 1
16 1
17 1
18 1
19 1
0
0
0
0
0
23
27 144
59 4
57 4
55 4
38 4
36 4
53 4
51 4
49 4
31 4
47 4
45 4
41 3
40 4
39 4
37 7
35 5
34 5
33 5
32 9
30 9
29 1
28 1
11
41 3
40 4
39 4
37 7
35 5
34 5
33 5
32 9
30 9
29 1
28 1
1
45 4
1
47 4
1
31 4
0
1
49 4
1
51 4
1
53 4
1
36 4
0
1
38 4
0
1
55 4
1
57 4
1
59 4
17
43 95
59 4
57 4
55 4
53 4
51 4
49 4
47 4
45 4
58 3
56 4
54 4
52 5
50 5
48 9
46 1
44 1
8
58 3
56 4
54 4
52 5
50 5
48 9
46 1
44 1
1
45 4
0
1
47 4
0
1
49 4
0
1
51 4
0
1
53 4
0
1
55 4
0
1
57 4
0
1
59 4
0
end_CG
