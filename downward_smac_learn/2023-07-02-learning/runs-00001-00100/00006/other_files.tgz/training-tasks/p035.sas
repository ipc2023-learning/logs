begin_version
3
end_version
begin_metric
0
end_metric
12
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var5
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var26
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var27
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
end_variable
begin_variable
var23
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var22
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var21
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
5
2
0
0
0
0
0
0
0
1
1
1
end_state
begin_goal
3
9 0
10 0
11 0
end_goal
40
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint3 waypoint1
2
1 2
2 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint3 waypoint1
2
1 2
3 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint6 waypoint3 waypoint1
2
1 2
4 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint3 waypoint1
2
0 2
2 2
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint4 waypoint3 waypoint1
2
0 2
3 2
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint6 waypoint3 waypoint1
2
0 2
4 2
1
0 9 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 6 1 0
0
end_operator
begin_operator
drop rover2 rover2store
0
1
0 7 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 1 0 2
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint6
0
1
0 1 1 5
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint1
0
1
0 1 2 0
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint6
0
1
0 1 2 5
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint5
0
1
0 1 3 4
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint6
0
1
0 1 3 5
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint4
0
1
0 1 4 3
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint6
0
1
0 1 4 5
0
end_operator
begin_operator
navigate rover1 waypoint6 waypoint2
0
1
0 1 5 1
0
end_operator
begin_operator
navigate rover1 waypoint6 waypoint3
0
1
0 1 5 2
0
end_operator
begin_operator
navigate rover1 waypoint6 waypoint4
0
1
0 1 5 3
0
end_operator
begin_operator
navigate rover1 waypoint6 waypoint5
0
1
0 1 5 4
0
end_operator
begin_operator
navigate rover2 waypoint1 waypoint3
0
1
0 0 0 2
0
end_operator
begin_operator
navigate rover2 waypoint2 waypoint6
0
1
0 0 1 5
0
end_operator
begin_operator
navigate rover2 waypoint3 waypoint1
0
1
0 0 2 0
0
end_operator
begin_operator
navigate rover2 waypoint3 waypoint6
0
1
0 0 2 5
0
end_operator
begin_operator
navigate rover2 waypoint4 waypoint5
0
1
0 0 3 4
0
end_operator
begin_operator
navigate rover2 waypoint5 waypoint4
0
1
0 0 4 3
0
end_operator
begin_operator
navigate rover2 waypoint5 waypoint6
0
1
0 0 4 5
0
end_operator
begin_operator
navigate rover2 waypoint6 waypoint2
0
1
0 0 5 1
0
end_operator
begin_operator
navigate rover2 waypoint6 waypoint3
0
1
0 0 5 2
0
end_operator
begin_operator
navigate rover2 waypoint6 waypoint5
0
1
0 0 5 4
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
1 0
2
0 2 0 1
0 6 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint4
1
1 3
2
0 3 0 1
0 6 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint6
1
1 5
2
0 4 0 1
0 6 0 1
0
end_operator
begin_operator
sample_rock rover2 rover2store waypoint1
1
0 0
2
0 2 0 2
0 7 0 1
0
end_operator
begin_operator
sample_rock rover2 rover2store waypoint4
1
0 3
2
0 3 0 2
0 7 0 1
0
end_operator
begin_operator
sample_rock rover2 rover2store waypoint6
1
0 5
2
0 4 0 2
0 7 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint5
1
1 4
2
0 5 0 1
0 6 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint6
1
1 5
2
0 8 0 1
0 6 0 1
0
end_operator
begin_operator
sample_soil rover2 rover2store waypoint5
1
0 4
2
0 5 0 2
0 7 0 1
0
end_operator
begin_operator
sample_soil rover2 rover2store waypoint6
1
0 5
2
0 8 0 2
0 7 0 1
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 6
check 0
check 1
30
check 0
check 0
check 0
check 0
check 0
check 1
9
switch 0
check 2
10
11
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
0
check 0
switch 3
check 0
check 0
check 1
1
check 0
switch 4
check 0
check 0
check 1
2
check 0
check 0
switch 0
check 2
12
13
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 6
check 0
check 1
31
check 0
check 0
check 0
check 0
check 0
switch 0
check 2
14
15
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 6
check 0
check 1
36
check 0
check 0
check 0
check 0
check 0
switch 0
check 4
16
17
18
19
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 6
check 0
check 1
32
check 0
check 0
check 0
check 0
switch 8
check 0
switch 6
check 0
check 1
37
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
switch 2
check 1
20
switch 7
check 0
check 1
33
check 0
check 0
check 0
check 0
check 0
check 1
21
switch 2
check 2
22
23
check 0
check 0
check 1
3
switch 3
check 0
check 0
check 0
check 1
4
switch 4
check 0
check 0
check 0
check 1
5
check 0
switch 2
check 1
24
check 0
check 0
check 0
switch 3
check 0
switch 7
check 0
check 1
34
check 0
check 0
check 0
check 0
check 0
switch 2
check 2
25
26
check 0
check 0
check 0
switch 5
check 0
switch 7
check 0
check 1
38
check 0
check 0
check 0
check 0
check 0
switch 2
check 3
27
28
29
check 0
check 0
check 0
switch 4
check 0
switch 7
check 0
check 1
35
check 0
check 0
check 0
check 0
switch 8
check 0
switch 7
check 0
check 1
39
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 0
check 1
6
switch 7
check 0
check 0
check 1
7
check 0
end_SG
begin_DTG
1
2
20
0
1
5
21
0
2
0
22
0
5
23
0
1
4
24
0
2
3
25
0
5
26
0
3
1
27
0
2
28
0
4
29
0
end_DTG
begin_DTG
1
2
8
0
1
5
9
0
2
0
10
0
5
11
0
2
4
12
0
5
13
0
2
3
14
0
5
15
0
4
1
16
0
2
17
0
3
18
0
4
19
0
end_DTG
begin_DTG
2
1
30
2
1 0
6 0
2
33
2
0 0
7 0
0
0
end_DTG
begin_DTG
2
1
31
2
1 3
6 0
2
34
2
0 3
7 0
0
0
end_DTG
begin_DTG
2
1
32
2
1 5
6 0
2
35
2
0 5
7 0
0
0
end_DTG
begin_DTG
2
1
36
2
1 4
6 0
2
38
2
0 4
7 0
0
0
end_DTG
begin_DTG
5
1
30
2
1 0
2 0
1
31
2
1 3
3 0
1
32
2
1 5
4 0
1
36
2
1 4
5 0
1
37
2
1 5
8 0
1
0
6
0
end_DTG
begin_DTG
5
1
33
2
0 0
2 0
1
34
2
0 3
3 0
1
35
2
0 5
4 0
1
38
2
0 4
5 0
1
39
2
0 5
8 0
1
0
7
0
end_DTG
begin_DTG
2
1
37
2
1 5
6 0
2
39
2
0 5
7 0
0
0
end_DTG
begin_DTG
0
2
0
2
2
1 2
4 1
0
5
2
0 2
4 2
end_DTG
begin_DTG
0
2
0
1
2
1 2
3 1
0
4
2
0 2
3 2
end_DTG
begin_DTG
0
2
0
0
2
1 2
2 1
0
3
2
0 2
2 2
end_DTG
begin_CG
9
2 1
3 1
4 1
5 1
8 1
11 1
10 1
9 1
7 5
9
2 1
3 1
4 1
5 1
8 1
11 1
10 1
9 1
6 5
3
11 2
6 1
7 1
3
10 2
6 1
7 1
3
9 2
6 1
7 1
2
6 1
7 1
5
2 1
3 1
4 1
5 1
8 1
5
2 1
3 1
4 1
5 1
8 1
2
6 1
7 1
0
0
0
end_CG
