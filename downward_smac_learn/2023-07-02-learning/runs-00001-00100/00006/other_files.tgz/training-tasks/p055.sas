begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var2
-1
7
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
end_variable
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var49
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var3
-1
4
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var4
-1
4
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var5
-1
4
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var6
-1
4
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var7
-1
4
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
Atom have_soil_analysis(rover3, waypoint4)
end_variable
begin_variable
var9
-1
4
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var42
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var43
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var10
-1
4
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
Atom have_soil_analysis(rover3, waypoint6)
end_variable
begin_variable
var11
-1
4
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var44
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var40
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var39
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var38
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var37
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var34
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
0
begin_state
3
0
5
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
end_state
begin_goal
8
5 0
8 0
11 0
24 0
25 0
26 0
27 0
28 0
end_goal
227
begin_operator
calibrate rover1 camera1 objective6 waypoint2
1
2 1
1
0 9 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint3
1
2 2
1
0 6 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint4
1
2 3
1
0 6 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint5
1
2 4
1
0 6 -1 0
0
end_operator
begin_operator
calib




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 0
check 0
check 0
check 0
check 0
check 0
switch 22
check 0
switch 20
check 0
check 1
88
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
56
switch 12
check 1
57
check 0
check 0
check 0
check 0
switch 15
check 0
switch 23
check 0
check 1
89
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 1
58
switch 23
check 0
check 1
74
check 0
check 0
check 0
check 0
check 0
switch 16
check 0
switch 23
check 0
check 1
90
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 5
59
60
61
62
63
check 0
check 0
check 0
check 0
switch 13
check 0
switch 23
check 0
check 1
75
check 0
check 0
check 0
check 0
check 1
14
switch 16
check 0
check 0
check 0
check 0
check 1
23
switch 17
check 0
switch 23
check 0
check 1
91
check 0
check 0
check 0
check 0
check 1
24
switch 18
check 0
check 0
check 0
check 0
check 1
25
switch 21
check 0
check 0
check 0
check 0
check 1
26
check 0
switch 12
check 1
64
check 0
check 0
check 0
check 0
switch 14
check 0
switch 23
check 0
check 1
76
check 0
check 0
check 0
check 0
check 0
switch 18
check 0
switch 23
check 0
check 1
92
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 2
65
66
check 0
check 0
check 0
check 0
switch 21
check 0
switch 23
check 0
check 1
93
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 1
67
check 0
check 0
check 0
check 0
switch 22
check 0
switch 23
check 0
check 1
94
check 0
check 0
check 0
check 0
check 0
check 0
switch 19
check 0
check 0
check 1
27
switch 20
check 0
check 0
check 1
28
switch 23
check 0
check 0
check 1
29
check 0
end_SG
begin_DTG
1
5
56
0
1
3
57
0
1
3
58
0
5
1
59
0
2
60
0
4
61
0
5
62
0
6
63
0
1
3
64
0
2
0
65
0
3
66
0
1
3
67
0
end_DTG
begin_DTG
2
5
42
0
6
43
0
1
3
44
0
1
3
45
0
5
1
46
0
2
47
0
4
48
0
5
49
0
6
50
0
1
3
51
0
2
0
52
0
3
53
0
2
0
54
0
3
55
0
end_DTG
begin_DTG
1
5
30
0
1
3
31
0
1
3
32
0
5
1
33
0
2
34
0
4
35
0
5
36
0
6
37
0
1
3
38
0
2
0
39
0
3
40
0
1
3
41
0
end_DTG
begin_DTG
7
1
178
1
2 4
1
195
1
2 5
1
172
1
2 3
1
200
1
2 6
1
112
1
2 0
1
129
1
2 1
1
140
1
2 2
4
0
5
1
2 0
0
6
1
2 1
0
7
1
2 2
0
8
1
2 6
end_DTG
begin_DTG
0
4
0
154
2
2 2
3 0
0
166
2
2 3
3 0
0
178
2
2 4
3 0
0
214
2
2 6
3 0
end_DTG
begin_DTG
0
1
0
11
2
2 3
4 0
end_DTG
begin_DTG
7
1
193
1
2 5
1
163
1
2 3
1
174
1
2 4
1
198
1
2 6
1
127
1
2 1
1
97
1
2 0
1
138
1
2 2
4
0
1
1
2 2
0
2
1
2 3
0
3
1
2 4
0
4
1
2 6
end_DTG
begin_DTG
0
8
0
103
2
2 0
6 0
0
105
2
2 0
3 0
0
121
2
2 1
6 0
0
123
2
2 1
3 0
0
145
2
2 2
6 0
0
147
2
2 2
3 0
0
205
2
2 6
6 0
0
207
2
2 6
3 0
end_DTG
begin_DTG
0
1
0
10
2
2 3
7 0
end_DTG
begin_DTG
7
1
161
1
2 3
1
221
1
2 6
1
191
1
2 5
1
185
1
2 4
1
95
1
2 0
1
149
1
2 2
1
131
1
2 1
1
0
0
1
2 1
end_DTG
begin_DTG
0
12
0
101
2
2 0
9 0
0
102
2
2 0
6 0
0
104
2
2 0
3 0
0
119
2
2 1
9 0
0
120
2
2 1
6 0
0
122
2
2 1
3 0
0
143
2
2 2
9 0
0
144
2
2 2
6 0
0
146
2
2 2
3 0
0
203
2
2 6
9 0
0
204
2
2 6
6 0
0
206
2
2 6
3 0
end_DTG
begin_DTG
0
1
0
9
2
2 3
10 0
end_DTG
begin_DTG
3
1
68
2
2 2
19 0
2
71
2
1 2
20 0
3
74
2
0 2
23 0
0
0
0
end_DTG
begin_DTG
3
1
69
2
2 3
19 0
2
72
2
1 3
20 0
3
75
2
0 3
23 0
0
0
0
end_DTG
begin_DTG
3
1
70
2
2 4
19 0
2
73
2
1 4
20 0
3
76
2
0 4
23 0
0
0
0
end_DTG
begin_DTG
3
1
77
2
2 1
19 0
2
83
2
1 1
20 0
3
89
2
0 1
23 0
0
0
0
end_DTG
begin_DTG
3
1
78
2
2 2
19 0
2
84
2
1 2
20 0
3
90
2
0 2
23 0
0
0
0
end_DTG
begin_DTG
3
1
79
2
2 3
19 0
2
85
2
1 3
20 0
3
91
2
0 3
23 0
0
0
0
end_DTG
begin_DTG
3
1
80
2
2 4
19 0
2
86
2
1 4
20 0
3
92
2
0 4
23 0
0
0
0
end_DTG
begin_DTG
9
1
68
2
2 2
12 0
1
69
2
2 3
13 0
1
70
2
2 4
14 0
1
77
2
2 1
15 0
1
78
2
2 2
16 0
1
79
2
2 3
17 0
1
80
2
2 4
18 0
1
81
2
2 5
21 0
1
82
2
2 6
22 0
1
0
27
0
end_DTG
begin_DTG
9
1
71
2
1 2
12 0
1
72
2
1 3
13 0
1
73
2
1 4
14 0
1
83
2
1 1
15 0
1
84
2
1 2
16 0
1
85
2
1 3
17 0
1
86
2
1 4
18 0
1
87
2
1 5
21 0
1
88
2
1 6
22 0
1
0
28
0
end_DTG
begin_DTG
3
1
81
2
2 5
19 0
2
87
2
1 5
20 0
3
93
2
0 5
23 0
0
0
0
end_DTG
begin_DTG
3
1
82
2
2 6
19 0
2
88
2
1 6
20 0
3
94
2
0 6
23 0
0
0
0
end_DTG
begin_DTG
9
1
74
2
0 2
12 0
1
75
2
0 3
13 0
1
76
2
0 4
14 0
1
89
2
0 1
15 0
1
90
2
0 2
16 0
1
91
2
0 3
17 0
1
92
2
0 4
18 0
1
93
2
0 5
21 0
1
94
2
0 6
22 0
1
0
29
0
end_DTG
begin_DTG
0
3
0
18
2
2 3
21 1
0
22
2
1 3
21 2
0
26
2
0 3
21 3
end_DTG
begin_DTG
0
3
0
17
2
2 3
18 1
0
21
2
1 3
18 2
0
25
2
0 3
18 3
end_DTG
begin_DTG
0
3
0
16
2
2 3
17 1
0
20
2
1 3
17 2
0
24
2
0 3
17 3
end_DTG
begin_DTG
0
3
0
15
2
2 3
16 1
0
19
2
1 3
16 2
0
23
2
0 3
16 3
end_DTG
begin_DTG
0
3
0
12
2
2 3
13 1
0
13
2
1 3
13 2
0
14
2
0 3
13 3
end_DTG
begin_CG
15
12 1
13 1
14 1
15 1
16 1
17 1
18 1
21 1
22 1
28 1
27 1
26 1
25 1
24 1
23 9
15
12 1
13 1
14 1
15 1
16 1
17 1
18 1
21 1
22 1
28 1
27 1
26 1
25 1
24 1
20 9
24
12 1
13 1
14 1
15 1
16 1
17 1
18 1
21 1
22 1
9 23
6 48
3 70
11 1
8 1
5 1
28 1
27 1
26 1
25 1
24 1
19 9
10 12
7 8
4 4
3
10 4
7 4
4 4
1
5 1
0
2
10 4
7 4
1
8 1
0
1
10 4
1
11 1
0
3
19 1
20 1
23 1
4
28 3
19 1
20 1
23 1
3
19 1
20 1
23 1
3
19 1
20 1
23 1
4
27 3
19 1
20 1
23 1
4
26 3
19 1
20 1
23 1
4
25 3
19 1
20 1
23 1
9
12 1
13 1
14 1
15 1
16 1
17 1
18 1
21 1
22 1
9
12 1
13 1
14 1
15 1
16 1
17 1
18 1
21 1
22 1
4
24 3
19 1
20 1
23 1
3
19 1
20 1
23 1
9
12 1
13 1
14 1
15 1
16 1
17 1
18 1
21 1
22 1
0
0
0
0
0
end_CG
