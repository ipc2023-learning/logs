begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var2
-1
7
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
end_variable
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var50
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover3, waypoint1)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover3, waypoint2)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var6
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var7
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
Atom have_soil_analysis(rover3, waypoint1)
end_variable
begin_variable
var9
-1
4
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var42
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var43
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var10
-1
4
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var11
-1
4
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var44
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var37
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var36
-1
2
Atom communicated_rock_data(




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
2
2 6
5 0
end_DTG
begin_DTG
0
10
0
225
2
2 1
4 0
0
228
2
2 1
3 0
0
257
2
2 2
4 0
0
260
2
2 2
3 0
0
289
2
2 4
4 0
0
292
2
2 4
3 0
0
321
2
2 5
4 0
0
324
2
2 5
3 0
0
361
2
2 6
4 0
0
364
2
2 6
3 0
end_DTG
begin_DTG
0
5
0
16
2
2 0
7 0
0
17
2
2 1
7 0
0
18
2
2 2
7 0
0
19
2
2 4
7 0
0
20
2
2 6
7 0
end_DTG
begin_DTG
7
1
343
1
2 5
1
295
1
2 4
1
358
1
2 6
1
239
1
2 1
1
191
1
2 0
1
254
1
2 2
1
270
1
2 3
4
0
0
1
2 0
0
1
1
2 3
0
2
1
2 5
0
3
1
2 6
end_DTG
begin_DTG
0
12
0
279
2
2 3
9 0
0
282
2
2 3
4 0
0
285
2
2 3
3 0
0
303
2
2 4
9 0
0
306
2
2 4
4 0
0
309
2
2 4
3 0
0
335
2
2 5
9 0
0
338
2
2 5
4 0
0
341
2
2 5
3 0
0
383
2
2 6
9 0
0
386
2
2 6
4 0
0
389
2
2 6
3 0
end_DTG
begin_DTG
0
5
0
41
2
2 0
10 0
0
42
2
2 1
10 0
0
43
2
2 2
10 0
0
44
2
2 4
10 0
0
45
2
2 6
10 0
end_DTG
begin_DTG
0
15
0
199
2
2 0
9 0
0
202
2
2 0
4 0
0
205
2
2 0
3 0
0
231
2
2 1
9 0
0
234
2
2 1
4 0
0
237
2
2 1
3 0
0
263
2
2 2
9 0
0
266
2
2 2
4 0
0
269
2
2 2
3 0
0
295
2
2 4
9 0
0
298
2
2 4
4 0
0
301
2
2 4
3 0
0
375
2
2 6
9 0
0
378
2
2 6
4 0
0
381
2
2 6
3 0
end_DTG
begin_DTG
0
5
0
36
2
2 0
12 0
0
37
2
2 1
12 0
0
38
2
2 2
12 0
0
39
2
2 4
12 0
0
40
2
2 6
12 0
end_DTG
begin_DTG
0
12
0
191
2
2 0
9 0
0
194
2
2 0
4 0
0
197
2
2 0
3 0
0
271
2
2 3
9 0
0
274
2
2 3
4 0
0
277
2
2 3
3 0
0
327
2
2 5
9 0
0
330
2
2 5
4 0
0
333
2
2 5
3 0
0
367
2
2 6
9 0
0
370
2
2 6
4 0
0
373
2
2 6
3 0
end_DTG
begin_DTG
0
5
0
31
2
2 0
14 0
0
32
2
2 1
14 0
0
33
2
2 2
14 0
0
34
2
2 4
14 0
0
35
2
2 6
14 0
end_DTG
begin_DTG
0
12
0
190
2
2 0
9 0
0
192
2
2 0
4 0
0
195
2
2 0
3 0
0
270
2
2 3
9 0
0
272
2
2 3
4 0
0
275
2
2 3
3 0
0
326
2
2 5
9 0
0
328
2
2 5
4 0
0
331
2
2 5
3 0
0
366
2
2 6
9 0
0
368
2
2 6
4 0
0
371
2
2 6
3 0
end_DTG
begin_DTG
0
5
0
26
2
2 0
16 0
0
27
2
2 1
16 0
0
28
2
2 2
16 0
0
29
2
2 4
16 0
0
30
2
2 6
16 0
end_DTG
begin_DTG
0
15
0
223
2
2 1
9 0
0
226
2
2 1
4 0
0
229
2
2 1
3 0
0
255
2
2 2
9 0
0
258
2
2 2
4 0
0
261
2
2 2
3 0
0
287
2
2 4
9 0
0
290
2
2 4
4 0
0
293
2
2 4
3 0
0
319
2
2 5
9 0
0
322
2
2 5
4 0
0
325
2
2 5
3 0
0
359
2
2 6
9 0
0
362
2
2 6
4 0
0
365
2
2 6
3 0
end_DTG
begin_DTG
0
5
0
21
2
2 0
18 0
0
22
2
2 1
18 0
0
23
2
2 2
18 0
0
24
2
2 4
18 0
0
25
2
2 6
18 0
end_DTG
begin_DTG
0
15
0
222
2
2 1
9 0
0
224
2
2 1
4 0
0
227
2
2 1
3 0
0
254
2
2 2
9 0
0
256
2
2 2
4 0
0
259
2
2 2
3 0
0
286
2
2 4
9 0
0
288
2
2 4
4 0
0
291
2
2 4
3 0
0
318
2
2 5
9 0
0
320
2
2 5
4 0
0
323
2
2 5
3 0
0
358
2
2 6
9 0
0
360
2
2 6
4 0
0
363
2
2 6
3 0
end_DTG
begin_DTG
0
5
0
11
2
2 0
20 0
0
12
2
2 1
20 0
0
13
2
2 2
20 0
0
14
2
2 4
20 0
0
15
2
2 6
20 0
end_DTG
begin_DTG
1
1
173
2
0 0
33 0
0
end_DTG
begin_DTG
1
1
174
2
0 1
33 0
0
end_DTG
begin_DTG
1
1
175
2
0 2
33 0
0
end_DTG
begin_DTG
1
1
176
2
0 3
33 0
0
end_DTG
begin_DTG
1
1
177
2
0 4
33 0
0
end_DTG
begin_DTG
3
1
178
2
2 0
29 0
2
182
2
1 0
30 0
3
186
2
0 0
33 0
0
0
0
end_DTG
begin_DTG
3
1
179
2
2 1
29 0
2
183
2
1 1
30 0
3
187
2
0 1
33 0
0
0
0
end_DTG
begin_DTG
4
1
178
2
2 0
27 0
1
179
2
2 1
28 0
1
180
2
2 2
31 0
1
181
2
2 4
32 0
1
0
106
0
end_DTG
begin_DTG
4
1
182
2
1 0
27 0
1
183
2
1 1
28 0
1
184
2
1 2
31 0
1
185
2
1 4
32 0
1
0
107
0
end_DTG
begin_DTG
3
1
180
2
2 2
29 0
2
184
2
1 2
30 0
3
188
2
0 2
33 0
0
0
0
end_DTG
begin_DTG
3
1
181
2
2 4
29 0
2
185
2
1 4
30 0
3
189
2
0 4
33 0
0
0
0
end_DTG
begin_DTG
9
1
173
2
0 0
22 0
1
174
2
0 1
23 0
1
175
2
0 2
24 0
1
176
2
0 3
25 0
1
177
2
0 4
26 0
1
186
2
0 0
27 0
1
187
2
0 1
28 0
1
188
2
0 2
31 0
1
189
2
0 4
32 0
1
0
108
0
end_DTG
begin_DTG
0
5
0
71
2
0 0
26 1
0
72
2
0 1
26 1
0
73
2
0 2
26 1
0
74
2
0 4
26 1
0
75
2
0 6
26 1
end_DTG
begin_DTG
0
5
0
66
2
0 0
25 1
0
67
2
0 1
25 1
0
68
2
0 2
25 1
0
69
2
0 4
25 1
0
70
2
0 6
25 1
end_DTG
begin_DTG
0
5
0
61
2
0 0
24 1
0
62
2
0 1
24 1
0
63
2
0 2
24 1
0
64
2
0 4
24 1
0
65
2
0 6
24 1
end_DTG
begin_DTG
0
5
0
56
2
0 0
23 1
0
57
2
0 1
23 1
0
58
2
0 2
23 1
0
59
2
0 4
23 1
0
60
2
0 6
23 1
end_DTG
begin_DTG
0
5
0
51
2
0 0
22 1
0
52
2
0 1
22 1
0
53
2
0 2
22 1
0
54
2
0 4
22 1
0
55
2
0 6
22 1
end_DTG
begin_DTG
0
15
0
81
2
2 0
31 1
0
82
2
2 1
31 1
0
83
2
2 2
31 1
0
84
2
2 4
31 1
0
85
2
2 6
31 1
0
91
2
1 0
31 2
0
92
2
1 1
31 2
0
93
2
1 2
31 2
0
94
2
1 4
31 2
0
95
2
1 6
31 2
0
101
2
0 0
31 3
0
102
2
0 1
31 3
0
103
2
0 2
31 3
0
104
2
0 4
31 3
0
105
2
0 6
31 3
end_DTG
begin_DTG
0
15
0
76
2
2 0
27 1
0
77
2
2 1
27 1
0
78
2
2 2
27 1
0
79
2
2 4
27 1
0
80
2
2 6
27 1
0
86
2
1 0
27 2
0
87
2
1 1
27 2
0
88
2
1 2
27 2
0
89
2
1 4
27 2
0
90
2
1 6
27 2
0
96
2
0 0
27 3
0
97
2
0 1
27 3
0
98
2
0 2
27 3
0
99
2
0 4
27 3
0
100
2
0 6
27 3
end_DTG
begin_CG
17
22 1
23 1
24 1
25 1
26 1
27 1
28 1
31 1
32 1
38 5
37 5
36 5
35 5
34 5
40 5
39 5
33 9
7
27 1
28 1
31 1
32 1
40 5
39 5
30 4
26
27 1
28 1
31 1
32 1
9 56
4 81
3 82
21 5
8 5
19 5
17 5
15 5
13 5
11 5
6 5
40 5
39 5
29 4
20 15
7 10
18 15
16 12
14 12
12 15
10 12
5 6
8
20 5
7 5
18 5
16 4
14 4
12 5
10 4
5 3
8
20 5
7 5
18 5
16 4
14 4
12 5
10 4
5 3
1
6 5
0
1
8 5
0
6
20 5
18 5
16 4
14 4
12 5
10 4
1
11 5
0
1
13 5
0
1
15 5
0
1
17 5
0
1
19 5
0
1
21 5
0
2
38 5
33 1
2
37 5
33 1
2
36 5
33 1
2
35 5
33 1
2
34 5
33 1
4
40 15
29 1
30 1
33 1
3
29 1
30 1
33 1
4
27 1
28 1
31 1
32 1
4
27 1
28 1
31 1
32 1
4
39 15
29 1
30 1
33 1
3
29 1
30 1
33 1
9
22 1
23 1
24 1
25 1
26 1
27 1
28 1
31 1
32 1
0
0
0
0
0
0
0
end_CG
