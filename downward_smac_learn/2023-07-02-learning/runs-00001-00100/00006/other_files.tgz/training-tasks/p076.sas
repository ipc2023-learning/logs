begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var3
-1
4
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var4
-1
4
Atom at_rock_sample(waypoint9)
Atom have_rock_analysis(rover1, waypoint9)
Atom have_rock_analysis(rover2, waypoint9)
Atom have_rock_analysis(rover3, waypoint9)
end_variable
begin_variable
var5
-1
4
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var6
-1
4
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var42
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var43
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var7
-1
4
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint9)
Atom have_soil_analysis(rover1, waypoint9)
Atom have_soil_analysis(rover2, waypoint9)
Atom have_soil_analysis(rover3, waypoint9)
end_variable
begin_variable
var44
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var41
-1
2
Atom communicated_soil_data(waypoint9)
NegatedAtom communicated_soil_data(waypoint9)
end_variable
begin_variable
var37
-1
2
Atom communicated_rock_data(waypoint9)
NegatedAtom communicated_rock_data(waypoint9)
end_variable
0
begin_state
3
7
5
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
end_state
begin_goal
4
6 0
9 0
19 0
20 0
end_goal
486
begin_operator
calibrate rover1 camera1 objective7 waypoint2
1
2 1
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective7 waypoint3
1
2 2
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective7 waypoint4
1
2 3
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective7 waypoint5
1
2 4
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective7 waypoint6
1
2 5
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective7 waypoint7
1
2 6
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective7 waypoint8
1
2 7
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective7 waypoint9
1
2 8
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint1
1
2 0
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint2
1
2 1
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint3
1
2 2
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint4
1
2 3
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint5
1
2 4
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint6
1
2 5
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint7
1
2 6
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint8
1
2 7
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 c




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
check 0
check 0
check 1
53
switch 17
check 0
check 0
check 0
check 0
check 1
74
check 0
switch 10
check 1
158
check 0
check 0
check 0
check 0
switch 11
check 0
check 0
check 0
check 0
check 1
54
switch 16
check 0
switch 18
check 0
check 1
179
check 0
check 0
check 0
check 0
check 0
switch 17
check 0
check 0
check 0
check 0
check 1
75
check 0
switch 10
check 2
159
160
check 0
check 0
check 0
check 0
switch 11
check 0
check 0
check 0
check 0
check 1
55
switch 17
check 0
check 0
check 0
check 0
check 1
76
check 0
switch 10
check 2
161
162
check 0
check 0
check 0
check 0
switch 11
check 0
switch 18
check 0
check 1
168
check 0
check 0
check 0
check 0
check 1
56
switch 17
check 0
switch 18
check 0
check 1
180
check 0
check 0
check 0
check 0
check 1
77
check 0
switch 14
check 0
check 0
check 1
78
switch 15
check 0
check 0
check 1
79
switch 18
check 0
check 0
check 1
80
check 0
end_SG
begin_DTG
4
1
141
0
2
142
0
6
143
0
8
144
0
4
0
145
0
3
146
0
5
147
0
7
148
0
1
0
149
0
4
1
150
0
4
151
0
5
152
0
8
153
0
2
3
154
0
7
155
0
2
1
156
0
3
157
0
1
0
158
0
2
1
159
0
4
160
0
2
0
161
0
3
162
0
end_DTG
begin_DTG
5
1
107
0
2
108
0
5
109
0
6
110
0
8
111
0
2
0
112
0
7
113
0
4
0
114
0
6
115
0
7
116
0
8
117
0
5
4
118
0
5
119
0
6
120
0
7
121
0
8
122
0
3
3
123
0
5
124
0
7
125
0
3
0
126
0
3
127
0
4
128
0
3
0
129
0
2
130
0
3
131
0
5
1
132
0
2
133
0
3
134
0
4
135
0
8
136
0
4
0
137
0
2
138
0
3
139
0
7
140
0
end_DTG
begin_DTG
4
1
81
0
2
82
0
6
83
0
8
84
0
3
0
85
0
7
86
0
8
87
0
1
0
88
0
4
4
89
0
5
90
0
7
91
0
8
92
0
3
3
93
0
5
94
0
7
95
0
2
3
96
0
4
97
0
1
0
98
0
4
1
99
0
3
100
0
4
101
0
8
102
0
4
0
103
0
1
104
0
3
105
0
7
106
0
end_DTG
begin_DTG
9
1
415
1
2 6
1
340
1
2 4
1
360
1
2 5
1
430
1
2 7
1
465
1
2 8
1
260
1
2 2
1
190
1
2 0
1
215
1
2 1
1
285
1
2 3
5
0
17
1
2 0
0
18
1
2 2
0
19
1
2 4
0
20
1
2 5
0
21
1
2 6
end_DTG
begin_DTG
9
1
392
1
2 6
1
373
1
2 5
1
353
1
2 4
1
468
1
2 8
1
449
1
2 7
1
239
1
2 1
1
242
1
2 2
1
202
1
2 0
1
314
1
2 3
9
0
8
1
2 0
0
9
1
2 1
0
10
1
2 2
0
11
1
2 3
0
12
1
2 4
0
13
1
2 5
0
14
1
2 6
0
15
1
2 7
0
16
1
2 8
end_DTG
begin_DTG
0
18
0
320
2
2 4
3 0
0
465
2
2 8
3 0
0
464
2
2 8
4 0
0
430
2
2 7
3 0
0
429
2
2 7
4 0
0
395
2
2 6
3 0
0
394
2
2 6
4 0
0
360
2
2 5
3 0
0
359
2
2 5
4 0
0
184
2
2 0
4 0
0
319
2
2 4
4 0
0
285
2
2 3
3 0
0
284
2
2 3
4 0
0
245
2
2 2
3 0
0
244
2
2 2
4 0
0
215
2
2 1
3 0
0
214
2
2 1
4 0
0
185
2
2 0
3 0
end_DTG
begin_DTG
0
7
0
22
2
2 1
5 0
0
23
2
2 2
5 0
0
24
2
2 4
5 0
0
25
2
2 5
5 0
0
26
2
2 6
5 0
0
27
2
2 7
5 0
0
28
2
2 8
5 0
end_DTG
begin_DTG
9
1
411
1
2 6
1
336
1
2 4
1
356
1
2 5
1
426
1
2 7
1
461
1
2 8
1
256
1
2 2
1
186
1
2 0
1
211
1
2 1
1
281
1
2 3
8
0
0
1
2 1
0
1
1
2 2
0
2
1
2 3
0
3
1
2 4
0
4
1
2 5
0
5
1
2 6
0
6
1
2 7
0
7
1
2 8
end_DTG
begin_DTG
0
16
0
206
2
2 0
7 0
0
207
2
2 0
4 0
0
226
2
2 1
7 0
0
227
2
2 1
4 0
0
266
2
2 2
7 0
0
267
2
2 2
4 0
0
301
2
2 3
7 0
0
302
2
2 3
4 0
0
341
2
2 4
7 0
0
342
2
2 4
4 0
0
376
2
2 5
7 0
0
377
2
2 5
4 0
0
446
2
2 7
7 0
0
447
2
2 7
4 0
0
471
2
2 8
7 0
0
472
2
2 8
4 0
end_DTG
begin_DTG
0
7
0
29
2
2 1
8 0
0
30
2
2 2
8 0
0
31
2
2 4
8 0
0
32
2
2 5
8 0
0
33
2
2 6
8 0
0
34
2
2 7
8 0
0
35
2
2 8
8 0
end_DTG
begin_DTG
3
1
163
2
2 5
14 0
2
165
2
1 5
15 0
3
167
2
0 5
18 0
0
0
0
end_DTG
begin_DTG
3
1
164
2
2 8
14 0
2
166
2
1 8
15 0
3
168
2
0 8
18 0
0
0
0
end_DTG
begin_DTG
3
1
169
2
2 1
14 0
2
173
2
1 1
15 0
3
177
2
0 1
18 0
0
0
0
end_DTG
begin_DTG
3
1
170
2
2 4
14 0
2
174
2
1 4
15 0
3
178
2
0 4
18 0
0
0
0
end_DTG
begin_DTG
6
1
163
2
2 5
10 0
1
164
2
2 8
11 0
1
169
2
2 1
12 0
1
170
2
2 4
13 0
1
171
2
2 6
16 0
1
172
2
2 8
17 0
1
0
78
0
end_DTG
begin_DTG
6
1
165
2
1 5
10 0
1
166
2
1 8
11 0
1
173
2
1 1
12 0
1
174
2
1 4
13 0
1
175
2
1 6
16 0
1
176
2
1 8
17 0
1
0
79
0
end_DTG
begin_DTG
3
1
171
2
2 6
14 0
2
175
2
1 6
15 0
3
179
2
0 6
18 0
0
0
0
end_DTG
begin_DTG
3
1
172
2
2 8
14 0
2
176
2
1 8
15 0
3
180
2
0 8
18 0
0
0
0
end_DTG
begin_DTG
6
1
167
2
0 5
10 0
1
168
2
0 8
11 0
1
177
2
0 1
12 0
1
178
2
0 4
13 0
1
179
2
0 6
16 0
1
180
2
0 8
17 0
1
0
80
0
end_DTG
begin_DTG
0
21
0
67
2
1 5
17 2
0
77
2
0 8
17 3
0
76
2
0 7
17 3
0
75
2
0 6
17 3
0
74
2
0 5
17 3
0
73
2
0 4
17 3
0
72
2
0 2
17 3
0
71
2
0 1
17 3
0
70
2
1 8
17 2
0
69
2
1 7
17 2
0
68
2
1 6
17 2
0
57
2
2 1
17 1
0
66
2
1 4
17 2
0
65
2
1 2
17 2
0
64
2
1 1
17 2
0
63
2
2 8
17 1
0
62
2
2 7
17 1
0
61
2
2 6
17 1
0
60
2
2 5
17 1
0
59
2
2 4
17 1
0
58
2
2 2
17 1
end_DTG
begin_DTG
0
21
0
46
2
1 5
11 2
0
56
2
0 8
11 3
0
55
2
0 7
11 3
0
54
2
0 6
11 3
0
53
2
0 5
11 3
0
52
2
0 4
11 3
0
51
2
0 2
11 3
0
50
2
0 1
11 3
0
49
2
1 8
11 2
0
48
2
1 7
11 2
0
47
2
1 6
11 2
0
36
2
2 1
11 1
0
45
2
1 4
11 2
0
44
2
1 2
11 2
0
43
2
1 1
11 2
0
42
2
2 8
11 1
0
41
2
2 7
11 1
0
40
2
2 6
11 1
0
39
2
2 5
11 1
0
38
2
2 4
11 1
0
37
2
2 2
11 1
end_DTG
begin_CG
9
10 1
11 1
12 1
13 1
16 1
17 1
20 7
19 7
18 6
9
10 1
11 1
12 1
13 1
16 1
17 1
20 7
19 7
15 6
16
10 1
11 1
12 1
13 1
16 1
17 1
7 69
4 192
3 66
6 7
9 7
20 7
19 7
14 6
5 18
8 16
1
5 9
2
5 9
8 8
1
6 7
0
1
8 8
1
9 7
0
3
14 1
15 1
18 1
4
20 21
14 1
15 1
18 1
3
14 1
15 1
18 1
3
14 1
15 1
18 1
6
10 1
11 1
12 1
13 1
16 1
17 1
6
10 1
11 1
12 1
13 1
16 1
17 1
3
14 1
15 1
18 1
4
19 21
14 1
15 1
18 1
6
10 1
11 1
12 1
13 1
16 1
17 1
0
0
end_CG
