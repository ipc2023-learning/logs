begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var3
-1
4
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
Atom have_rock_analysis(rover3, waypoint1)
end_variable
begin_variable
var4
-1
4
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var5
-1
4
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var6
-1
4
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover1, waypoint8)
Atom have_rock_analysis(rover2, waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
end_variable
begin_variable
var7
-1
4
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
Atom have_soil_analysis(rover3, waypoint4)
end_variable
begin_variable
var9
-1
4
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var10
-1
4
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
Atom have_soil_analysis(rover3, waypoint6)
end_variable
begin_variable
var44
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var45
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var11
-1
4
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var12
-1
4
Atom at_soil_sample(waypoint8)
Atom have_soil_analysis(rover1, waypoint8)
Atom have_soil_analysis(rover2, waypoint8)
Atom have_soil_analysis(rover3, waypoint8)
end_variable
begin_variable
var46
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var43
-1
2
Atom communicated_soil_data(waypoint8)
NegatedAtom communicated_soil_data(waypoint8)
end_variable
begin_variable
var42
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var41
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var39
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var38
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
0
begin_state
0
5
6
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
end_state
begin_goal
8
6 0
9 0
11 0
25 0
26 0
27 0
28 0
29 0
end_goal
294
begin_operator
calibrate rover1 camera1 objective4 waypoint2
1
2 1
1
0 7 -1 0
0
end_operator
begin_operato




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
check 0
switch 16
check 0
check 0
check 0
check 0
check 1
46
switch 17
check 0
check 0
check 0
check 0
check 1
48
switch 19
check 0
switch 24
check 0
check 1
135
check 0
check 0
check 0
check 0
check 1
50
switch 22
check 0
check 0
check 0
check 0
check 1
52
switch 23
check 0
check 0
check 0
check 0
check 1
54
check 0
switch 12
check 1
106
check 0
check 0
check 0
check 0
switch 22
check 0
switch 24
check 0
check 1
136
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 1
107
check 0
check 0
check 0
check 0
switch 15
check 0
switch 24
check 0
check 1
119
check 0
check 0
check 0
check 0
check 0
switch 23
check 0
switch 24
check 0
check 1
137
check 0
check 0
check 0
check 0
check 0
check 0
switch 20
check 0
check 0
check 1
55
switch 21
check 0
check 0
check 1
56
switch 24
check 0
check 0
check 1
57
check 0
end_SG
begin_DTG
1
1
94
0
3
0
95
0
5
96
0
7
97
0
1
4
98
0
1
5
99
0
2
2
100
0
5
101
0
4
1
102
0
3
103
0
4
104
0
6
105
0
1
5
106
0
1
1
107
0
end_DTG
begin_DTG
2
1
78
0
6
79
0
3
0
80
0
5
81
0
7
82
0
1
4
83
0
1
5
84
0
2
2
85
0
5
86
0
4
1
87
0
3
88
0
4
89
0
6
90
0
2
0
91
0
5
92
0
1
1
93
0
end_DTG
begin_DTG
4
1
58
0
3
59
0
5
60
0
6
61
0
3
0
62
0
5
63
0
7
64
0
1
4
65
0
2
0
66
0
5
67
0
2
2
68
0
5
69
0
5
0
70
0
1
71
0
3
72
0
4
73
0
6
74
0
2
0
75
0
5
76
0
1
1
77
0
end_DTG
begin_DTG
8
1
257
1
2 5
1
221
1
2 3
1
226
1
2 4
1
262
1
2 6
1
280
1
2 7
1
179
1
2 1
1
143
1
2 0
1
184
1
2 2
8
0
11
1
2 0
0
12
1
2 1
0
13
1
2 2
0
14
1
2 3
0
15
1
2 4
0
16
1
2 5
0
17
1
2 6
0
18
1
2 7
end_DTG
begin_DTG
8
1
255
1
2 5
1
219
1
2 3
1
224
1
2 4
1
260
1
2 6
1
278
1
2 7
1
177
1
2 1
1
141
1
2 0
1
182
1
2 2
8
0
3
1
2 0
0
4
1
2 1
0
5
1
2 2
0
6
1
2 3
0
7
1
2 4
0
8
1
2 5
0
9
1
2 6
0
10
1
2 7
end_DTG
begin_DTG
0
14
0
147
2
2 0
4 0
0
148
2
2 0
3 0
0
165
2
2 1
4 0
0
166
2
2 1
3 0
0
189
2
2 2
4 0
0
190
2
2 2
3 0
0
207
2
2 3
4 0
0
208
2
2 3
3 0
0
249
2
2 5
4 0
0
250
2
2 5
3 0
0
267
2
2 6
4 0
0
268
2
2 6
3 0
0
291
2
2 7
4 0
0
292
2
2 7
3 0
end_DTG
begin_DTG
0
2
0
21
2
2 0
5 0
0
22
2
2 5
5 0
end_DTG
begin_DTG
8
1
253
1
2 5
1
217
1
2 3
1
222
1
2 4
1
258
1
2 6
1
276
1
2 7
1
175
1
2 1
1
139
1
2 0
1
180
1
2 2
3
0
0
1
2 1
0
1
1
2 4
0
2
1
2 6
end_DTG
begin_DTG
0
6
0
151
2
2 0
7 0
0
155
2
2 0
3 0
0
211
2
2 3
7 0
0
215
2
2 3
3 0
0
235
2
2 4
7 0
0
239
2
2 4
3 0
end_DTG
begin_DTG
0
2
0
23
2
2 0
8 0
0
24
2
2 5
8 0
end_DTG
begin_DTG
0
2
0
283
2
2 7
7 0
0
287
2
2 7
3 0
end_DTG
begin_DTG
0
2
0
19
2
2 0
10 0
0
20
2
2 5
10 0
end_DTG
begin_DTG
3
1
108
2
2 0
20 0
2
112
2
1 0
21 0
3
116
2
0 0
24 0
0
0
0
end_DTG
begin_DTG
3
1
109
2
2 3
20 0
2
113
2
1 3
21 0
3
117
2
0 3
24 0
0
0
0
end_DTG
begin_DTG
3
1
110
2
2 5
20 0
2
114
2
1 5
21 0
3
118
2
0 5
24 0
0
0
0
end_DTG
begin_DTG
3
1
111
2
2 7
20 0
2
115
2
1 7
21 0
3
119
2
0 7
24 0
0
0
0
end_DTG
begin_DTG
3
1
120
2
2 2
20 0
2
126
2
1 2
21 0
3
132
2
0 2
24 0
0
0
0
end_DTG
begin_DTG
3
1
121
2
2 3
20 0
2
127
2
1 3
21 0
3
133
2
0 3
24 0
0
0
0
end_DTG
begin_DTG
3
1
122
2
2 4
20 0
2
128
2
1 4
21 0
3
134
2
0 4
24 0
0
0
0
end_DTG
begin_DTG
3
1
123
2
2 5
20 0
2
129
2
1 5
21 0
3
135
2
0 5
24 0
0
0
0
end_DTG
begin_DTG
10
1
108
2
2 0
12 0
1
109
2
2 3
13 0
1
110
2
2 5
14 0
1
111
2
2 7
15 0
1
120
2
2 2
16 0
1
121
2
2 3
17 0
1
122
2
2 4
18 0
1
123
2
2 5
19 0
1
124
2
2 6
22 0
1
125
2
2 7
23 0
1
0
55
0
end_DTG
begin_DTG
10
1
112
2
1 0
12 0
1
113
2
1 3
13 0
1
114
2
1 5
14 0
1
115
2
1 7
15 0
1
126
2
1 2
16 0
1
127
2
1 3
17 0
1
128
2
1 4
18 0
1
129
2
1 5
19 0
1
130
2
1 6
22 0
1
131
2
1 7
23 0
1
0
56
0
end_DTG
begin_DTG
3
1
124
2
2 6
20 0
2
130
2
1 6
21 0
3
136
2
0 6
24 0
0
0
0
end_DTG
begin_DTG
3
1
125
2
2 7
20 0
2
131
2
1 7
21 0
3
137
2
0 7
24 0
0
0
0
end_DTG
begin_DTG
10
1
116
2
0 0
12 0
1
117
2
0 3
13 0
1
118
2
0 5
14 0
1
119
2
0 7
15 0
1
132
2
0 2
16 0
1
133
2
0 3
17 0
1
134
2
0 4
18 0
1
135
2
0 5
19 0
1
136
2
0 6
22 0
1
137
2
0 7
23 0
1
0
57
0
end_DTG
begin_DTG
0
6
0
33
2
2 0
23 1
0
34
2
2 5
23 1
0
43
2
1 0
23 2
0
44
2
1 5
23 2
0
53
2
0 0
23 3
0
54
2
0 5
23 3
end_DTG
begin_DTG
0
6
0
31
2
2 0
22 1
0
32
2
2 5
22 1
0
41
2
1 0
22 2
0
42
2
1 5
22 2
0
51
2
0 0
22 3
0
52
2
0 5
22 3
end_DTG
begin_DTG
0
6
0
29
2
2 0
19 1
0
30
2
2 5
19 1
0
39
2
1 0
19 2
0
40
2
1 5
19 2
0
49
2
0 0
19 3
0
50
2
0 5
19 3
end_DTG
begin_DTG
0
6
0
27
2
2 0
17 1
0
28
2
2 5
17 1
0
37
2
1 0
17 2
0
38
2
1 5
17 2
0
47
2
0 0
17 3
0
48
2
0 5
17 3
end_DTG
begin_DTG
0
6
0
25
2
2 0
16 1
0
26
2
2 5
16 1
0
35
2
1 0
16 2
0
36
2
1 5
16 2
0
45
2
0 0
16 3
0
46
2
0 5
16 3
end_DTG
begin_CG
16
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
22 1
23 1
29 2
28 2
27 2
26 2
25 2
24 10
16
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
22 1
23 1
29 2
28 2
27 2
26 2
25 2
21 10
25
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
22 1
23 1
7 55
4 60
3 60
11 2
6 2
9 2
29 2
28 2
27 2
26 2
25 2
20 10
10 2
5 14
8 6
3
10 1
5 7
8 3
1
5 7
1
6 2
0
2
10 1
8 3
1
9 2
0
1
11 2
0
3
20 1
21 1
24 1
3
20 1
21 1
24 1
3
20 1
21 1
24 1
3
20 1
21 1
24 1
4
29 6
20 1
21 1
24 1
4
28 6
20 1
21 1
24 1
3
20 1
21 1
24 1
4
27 6
20 1
21 1
24 1
10
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
22 1
23 1
10
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
22 1
23 1
4
26 6
20 1
21 1
24 1
4
25 6
20 1
21 1
24 1
10
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
22 1
23 1
0
0
0
0
0
end_CG
