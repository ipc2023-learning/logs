begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover2, objective6, high_res)
NegatedAtom have_image(rover2, objective6, high_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var36
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var31
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
0
begin_state
6
1
1
1
1
1
1
1
1
1
1
1
0
0
0
1
end_state
begin_goal
5
5 0
7 0
9 0
11 0
15 0
end_goal
202
begin_operator
calibrate rover2 camera1 objective2 waypoint2
1
0 1
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint3
1
0 2
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint4
1
0 3
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint5
1
0 4
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint7
1
0 6
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint8
1
0 7
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint2
1
0 1
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint3
1
0 2
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint4
1
0 3
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint5
1
0 4
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint7
1
0 6
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint8
1
0 7
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective2 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective2 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective2 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective2 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective2 waypoint7
1
0 6
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective2 waypoint8
1
0 7
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint1 waypoint6
2
0 0
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint7 waypoint6
2
0 6
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective4 high_res waypoint1 waypoint6
2
0 0
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective4 high_res waypoint7 waypoint6
2
0 6
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective5 low_res waypoint1 waypoint6
2
0 0
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective5 low_res waypoint7 waypoint6
2
0 6
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective6 high_res waypoint1 waypoint6
2
0 0
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective6 high_res waypoint7 waypoint6
2
0 6
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint6 waypoint1 waypoint6
2
0 0
13 1
1
0 15 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




oint8 objective2 camera3 low_res
1
0 7
1
0 1 0 1
0
end_operator
begin_operator
take_image rover2 waypoint8 objective6 camera1 colour
1
0 7
1
0 3 0 1
0
end_operator
begin_operator
take_image rover2 waypoint8 objective6 camera1 high_res
1
0 7
2
0 3 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint8 objective6 camera1 low_res
1
0 7
1
0 3 0 1
0
end_operator
begin_operator
take_image rover2 waypoint8 objective6 camera2 high_res
1
0 7
2
0 2 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint8 objective6 camera3 colour
1
0 7
1
0 1 0 1
0
end_operator
begin_operator
take_image rover2 waypoint8 objective6 camera3 high_res
1
0 7
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint8 objective6 camera3 low_res
1
0 7
1
0 1 0 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 12
check 6
29
30
31
32
33
34
check 0
check 0
switch 13
check 0
check 0
check 1
26
switch 3
check 0
check 3
55
56
57
check 0
switch 2
check 0
check 1
58
check 0
switch 1
check 0
check 3
59
60
61
check 0
switch 10
check 0
check 1
18
check 0
switch 8
check 0
check 1
20
check 0
switch 6
check 0
check 1
22
check 0
switch 4
check 0
check 1
24
check 0
check 0
switch 12
check 7
0
6
12
35
36
37
38
check 0
check 0
switch 3
check 0
check 9
62
63
64
69
70
71
76
77
78
check 0
switch 2
check 0
check 3
65
72
79
check 0
switch 1
check 0
check 9
66
67
68
73
74
75
80
81
82
check 0
check 0
switch 12
check 4
1
7
13
39
check 0
check 0
switch 3
check 0
check 9
83
84
85
90
91
92
97
98
99
check 0
switch 2
check 0
check 3
86
93
100
check 0
switch 1
check 0
check 9
87
88
89
94
95
96
101
102
103
check 0
check 0
switch 12
check 5
2
8
14
40
41
check 0
check 0
switch 3
check 0
check 15
104
105
106
111
112
113
118
119
120
125
126
127
132
133
134
check 0
switch 2
check 0
check 5
107
114
121
128
135
check 0
switch 1
check 0
check 15
108
109
110
115
116
117
122
123
124
129
130
131
136
137
138
check 0
check 0
switch 12
check 7
3
9
15
42
43
44
45
switch 14
check 0
check 1
53
check 0
check 0
check 0
switch 3
check 0
check 6
139
140
141
146
147
148
check 0
switch 2
check 0
check 2
142
149
check 0
switch 1
check 0
check 6
143
144
145
150
151
152
check 0
check 0
switch 12
check 2
46
47
check 0
check 0
switch 13
check 0
switch 14
check 0
check 1
54
check 0
check 0
check 0
switch 3
check 0
check 3
153
154
155
check 0
switch 2
check 0
check 1
156
check 0
switch 1
check 0
check 3
157
158
159
check 0
check 0
switch 12
check 6
4
10
16
48
49
50
check 0
check 0
switch 13
check 0
check 0
check 1
27
switch 3
check 0
check 9
160
161
162
167
168
169
174
175
176
check 0
switch 2
check 0
check 3
163
170
177
check 0
switch 1
check 0
check 9
164
165
166
171
172
173
178
179
180
check 0
switch 10
check 0
check 1
19
check 0
switch 8
check 0
check 1
21
check 0
switch 6
check 0
check 1
23
check 0
switch 4
check 0
check 1
25
check 0
check 0
switch 12
check 5
5
11
17
51
52
check 0
check 0
switch 3
check 0
check 9
181
182
183
188
189
190
195
196
197
check 0
switch 2
check 0
check 3
184
191
198
check 0
switch 1
check 0
check 9
185
186
187
192
193
194
199
200
201
check 0
check 0
switch 14
check 0
check 0
check 1
28
check 0
end_SG
begin_DTG
6
1
29
0
2
30
0
4
31
0
5
32
0
6
33
0
7
34
0
4
0
35
0
3
36
0
4
37
0
7
38
0
1
0
39
0
2
1
40
0
4
41
0
4
0
42
0
1
43
0
3
44
0
6
45
0
2
0
46
0
6
47
0
3
0
48
0
4
49
0
5
50
0
2
0
51
0
1
52
0
end_DTG
begin_DTG
8
1
166
1
0 6
1
131
1
0 3
1
143
1
0 4
1
157
1
0 5
1
185
1
0 7
1
95
1
0 2
1
60
1
0 0
1
66
1
0 1
6
0
12
1
0 1
0
13
1
0 2
0
14
1
0 3
0
15
1
0 4
0
16
1
0 6
0
17
1
0 7
end_DTG
begin_DTG
8
1
128
1
0 3
1
198
1
0 7
1
177
1
0 6
1
156
1
0 5
1
149
1
0 4
1
58
1
0 0
1
100
1
0 2
1
79
1
0 1
6
0
6
1
0 1
0
7
1
0 2
0
8
1
0 3
0
9
1
0 4
0
10
1
0 6
0
11
1
0 7
end_DTG
begin_DTG
8
1
162
1
0 6
1
127
1
0 3
1
139
1
0 4
1
153
1
0 5
1
181
1
0 7
1
91
1
0 2
1
56
1
0 0
1
62
1
0 1
6
0
0
1
0 1
0
1
1
0 2
0
2
1
0 3
0
3
1
0 4
0
4
1
0 6
0
5
1
0 7
end_DTG
begin_DTG
0
21
0
135
2
0 3
2 0
0
200
2
0 7
1 0
0
198
2
0 7
2 0
0
196
2
0 7
3 0
0
179
2
0 6
1 0
0
177
2
0 6
2 0
0
175
2
0 6
3 0
0
158
2
0 5
1 0
0
156
2
0 5
2 0
0
154
2
0 5
3 0
0
137
2
0 3
1 0
0
56
2
0 0
3 0
0
133
2
0 3
3 0
0
102
2
0 2
1 0
0
100
2
0 2
2 0
0
98
2
0 2
3 0
0
81
2
0 1
1 0
0
79
2
0 1
2 0
0
77
2
0 1
3 0
0
60
2
0 0
1 0
0
58
2
0 0
2 0
end_DTG
begin_DTG
0
2
0
24
2
0 0
4 0
0
25
2
0 6
4 0
end_DTG
begin_DTG
0
2
0
92
2
0 2
3 0
0
96
2
0 2
1 0
end_DTG
begin_DTG
0
2
0
22
2
0 0
6 0
0
23
2
0 6
6 0
end_DTG
begin_DTG
0
6
0
126
2
0 3
3 0
0
128
2
0 3
2 0
0
130
2
0 3
1 0
0
147
2
0 4
3 0
0
149
2
0 4
2 0
0
151
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
20
2
0 0
8 0
0
21
2
0 6
8 0
end_DTG
begin_DTG
0
6
0
104
2
0 3
3 0
0
108
2
0 3
1 0
0
160
2
0 6
3 0
0
164
2
0 6
1 0
0
181
2
0 7
3 0
0
185
2
0 7
1 0
end_DTG
begin_DTG
0
2
0
18
2
0 0
10 0
0
19
2
0 6
10 0
end_DTG
begin_DTG
1
1
53
2
0 4
14 0
0
end_DTG
begin_DTG
1
1
54
2
0 5
14 0
0
end_DTG
begin_DTG
2
1
53
2
0 4
12 0
1
54
2
0 5
13 0
1
0
28
0
end_DTG
begin_DTG
0
2
0
26
2
0 0
13 1
0
27
2
0 6
13 1
end_DTG
begin_CG
15
12 1
13 1
3 69
2 27
1 69
11 2
9 2
7 2
5 2
15 2
14 2
10 6
8 6
6 2
4 21
4
10 3
8 2
6 1
4 7
2
8 2
4 7
4
10 3
8 2
6 1
4 7
1
5 2
0
1
7 2
0
1
9 2
0
1
11 2
0
1
14 1
2
15 2
14 1
2
12 1
13 1
0
end_CG
