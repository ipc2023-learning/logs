begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var7
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var26
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var25
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var23
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
0
begin_state
2
1
1
1
1
1
1
1
1
1
end_state
begin_goal
4
3 0
5 0
7 0
9 0
end_goal
60
begin_operator
calibrate rover1 camera1 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint1 waypoint3
2
0 0
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint2 waypoint3
2
0 1
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint4 waypoint3
2
0 3
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint5 waypoint3
2
0 4
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint1 waypoint3
2
0 0
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint2 waypoint3
2
0 1
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint4 waypoint3
2
0 3
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint5 waypoint3
2
0 4
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint1 waypoint3
2
0 0
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint2 waypoint3
2
0 1
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint4 waypoint3
2
0 3
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint5 waypoint3
2
0 4
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint1 waypoint3
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint2 waypoint3
2
0 1
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint4 waypoint3
2
0 3
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint5 waypoint3
2
0 4
2 0
1
0 3 -1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint5
0
1
0 0 0 4
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint3
0
1
0 0 1 2
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint5
0
1
0 0 1 4
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint2
0
1
0 0 2 1
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint4
0
1
0 0 2 3
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint5
0
1
0 0 2 4
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint3
0
1
0 0 3 2
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint1
0
1
0 0 4 0
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint2
0
1
0 0 4 1
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint3
0
1
0 0 4 2
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective2 camera1 colour
1
0 0
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective2 camera1 high_res
1
0 0
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective2 camera1 low_res
1
0 0
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 colour
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 high_res
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 low_res
1
0 1
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 colour
1
0 1
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 high_res
1
0 1
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 low_res
1
0 1
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 colour
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 high_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 colour
1
0 2
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 high_res
1
0 2
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 low_res
1
0 2
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 colour
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 high_res
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 low_res
1
0 4
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 colour
1
0 4
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 high_res
1
0 4
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 low_res
1
0 4
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 1
check 3
0
21
22
check 6
33
34
35
36
37
38
check 0
switch 8
check 0
check 1
5
check 0
switch 6
check 0
check 1
9
check 0
switch 4
check 0
check 1
13
check 0
switch 2
check 0
check 1
17
check 0
check 0
switch 1
check 3
1
23
24
check 6
39
40
41
42
43
44
check 0
switch 8
check 0
check 1
6
check 0
switch 6
check 0
check 1
10
check 0
switch 4
check 0
check 1
14
check 0
switch 2
check 0
check 1
18
check 0
check 0
switch 1
check 4
2
25
26
27
check 6
45
46
47
48
49
50
check 0
check 0
switch 1
check 3
3
28
29
check 3
51
52
53
check 0
switch 8
check 0
check 1
7
check 0
switch 6
check 0
check 1
11
check 0
switch 4
check 0
check 1
15
check 0
switch 2
check 0
check 1
19
check 0
check 0
switch 1
check 4
4
30
31
32
check 6
54
55
56
57
58
59
check 0
switch 8
check 0
check 1
8
check 0
switch 6
check 0
check 1
12
check 0
switch 4
check 0
check 1
16
check 0
switch 2
check 0
check 1
20
check 0
check 0
check 0
end_SG
begin_DTG
2
3
21
0
4
22
0
2
2
23
0
4
24
0
3
1
25
0
3
26
0
4
27
0
2
0
28
0
2
29
0
3
0
30
0
1
31
0
2
32
0
end_DTG
begin_DTG
5
1
46
1
0 2
1
59
1
0 4
1
53
1
0 3
1
33
1
0 0
1
44
1
0 1
5
0
0
1
0 0
0
1
1
0 1
0
2
1
0 2
0
3
1
0 3
0
4
1
0 4
end_DTG
begin_DTG
0
4
0
38
2
0 0
1 0
0
44
2
0 1
1 0
0
50
2
0 2
1 0
0
59
2
0 4
1 0
end_DTG
begin_DTG
0
4
0
17
2
0 0
2 0
0
18
2
0 1
2 0
0
19
2
0 3
2 0
0
20
2
0 4
2 0
end_DTG
begin_DTG
0
4
0
37
2
0 0
1 0
0
43
2
0 1
1 0
0
49
2
0 2
1 0
0
58
2
0 4
1 0
end_DTG
begin_DTG
0
4
0
13
2
0 0
4 0
0
14
2
0 1
4 0
0
15
2
0 3
4 0
0
16
2
0 4
4 0
end_DTG
begin_DTG
0
4
0
36
2
0 0
1 0
0
42
2
0 1
1 0
0
48
2
0 2
1 0
0
57
2
0 4
1 0
end_DTG
begin_DTG
0
4
0
9
2
0 0
6 0
0
10
2
0 1
6 0
0
11
2
0 3
6 0
0
12
2
0 4
6 0
end_DTG
begin_DTG
0
5
0
35
2
0 0
1 0
0
41
2
0 1
1 0
0
47
2
0 2
1 0
0
53
2
0 3
1 0
0
56
2
0 4
1 0
end_DTG
begin_DTG
0
4
0
5
2
0 0
8 0
0
6
2
0 1
8 0
0
7
2
0 3
8 0
0
8
2
0 4
8 0
end_DTG
begin_CG
9
1 32
9 4
7 4
5 4
3 4
8 5
6 4
4 4
2 4
4
8 5
6 4
4 4
2 4
1
3 4
0
1
5 4
0
1
7 4
0
1
9 4
0
end_CG
