begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var0
-1
2
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var10
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var5
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var9
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var4
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var8
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var3
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var7
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var6
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
1
begin_mutex_group
2
8 0
9 1
end_mutex_group
begin_state
1
1
1
1
1
1
1
1
0
0
1
end_state
begin_goal
4
3 0
5 0
7 0
10 0
end_goal
12
begin_operator
calibrate rover1 camera1 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint2 waypoint1
2
0 1
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint2 waypoint1
2
0 1
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint2 waypoint1
2
0 1
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint2 waypoint1
2
0 1
8 1
1
0 10 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 9 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 0 0 1
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint1
0
1
0 0 1 0
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
0 0
2
0 8 0 1
0 9 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 8
check 2
0
6
switch 9
check 0
check 1
8
check 0
check 0
check 0
switch 1
check 0
check 3
9
10
11
check 0
check 0
switch 8
check 1
7
check 0
check 1
4
switch 6
check 0
check 1
1
check 0
switch 4
check 0
check 1
2
check 0
switch 2
check 0
check 1
3
check 0
check 0
switch 9
check 0
check 0
check 1
5
check 0
end_SG
begin_DTG
1
1
6
0
1
0
7
0
end_DTG
begin_DTG
1
1
9
1
0 0
1
0
0
1
0 0
end_DTG
begin_DTG
0
1
0
11
2
0 0
1 0
end_DTG
begin_DTG
0
1
0
3
2
0 1
2 0
end_DTG
begin_DTG
0
1
0
10
2
0 0
1 0
end_DTG
begin_DTG
0
1
0
2
2
0 1
4 0
end_DTG
begin_DTG
0
1
0
9
2
0 0
1 0
end_DTG
begin_DTG
0
1
0
1
2
0 1
6 0
end_DTG
begin_DTG
1
1
8
2
0 0
9 0
0
end_DTG
begin_DTG
1
1
8
2
0 0
8 0
1
0
5
0
end_DTG
begin_DTG
0
1
0
4
2
0 1
8 1
end_DTG
begin_CG
10
8 1
1 4
7 1
5 1
3 1
10 1
9 1
6 1
4 1
2 1
3
6 1
4 1
2 1
1
3 1
0
1
5 1
0
1
7 1
0
2
10 1
9 1
1
8 1
0
end_CG
