begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var6
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var5
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var31
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var27
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var7
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var3
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
end_variable
begin_variable
var23
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var22
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var20
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var19
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
3
4
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
1
1
end_state
begin_goal
8
5 0
7 0
9 0
11 0
13 0
15 0
21 0
22 0
end_goal
99
begin_operator
calibrate rover1 camera1 objective3 waypoint1
1
1 0
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint3
1
1 2
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint5
1
1 4
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint1
1
1 0
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint3
1
1 2
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint5
1
1 4
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint6
1
1 5
1
0 2 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint3 waypoint4
2
1 2
14 0
1
0 15 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint6 waypoint4
2
1 5
14 0
1
0 15 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint3 waypoint4
2
1 2
12 0
1
0 13 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint6 waypoint4
2
1 5
12 0
1
0 13 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 high_res waypoint3 waypoint4
2
1 2
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 high_res waypoint6 waypoint4
2
1 5
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective4 colour waypoint3 waypoint4
2
1 2
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective4 colour waypoint6 waypoint4
2
1 5
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective4 high_res waypoint3 waypoint4
2
1 2
6 0
1
0 7 -1 0
0
end_operator
begin_opera




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ver1 waypoint5 objective4 camera1 high_res
1
1 4
2
0 3 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective4 camera1 low_res
1
1 4
2
0 3 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective4 camera2 low_res
1
1 4
2
0 2 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera1 colour
1
1 5
2
0 3 0 1
0 14 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera1 high_res
1
1 5
1
0 3 0 1
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera1 low_res
1
1 5
1
0 3 0 1
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera2 low_res
1
1 5
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint6 objective4 camera1 colour
1
1 5
2
0 3 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective4 camera1 high_res
1
1 5
2
0 3 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective4 camera1 low_res
1
1 5
2
0 3 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective4 camera2 low_res
1
1 5
2
0 2 0 1
0 4 -1 0
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 4
0
3
27
28
check 0
check 0
check 0
check 0
check 0
check 0
switch 20
check 0
switch 19
check 0
check 1
47
check 0
check 0
check 0
check 0
switch 3
check 0
check 9
51
52
53
55
56
57
59
60
61
check 0
switch 2
check 0
check 3
54
58
62
check 0
check 0
switch 0
check 1
29
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 3
63
64
65
check 0
switch 2
check 0
check 1
66
check 0
check 0
switch 0
check 4
1
4
30
31
check 0
check 0
check 0
check 0
check 0
check 0
switch 20
check 0
check 0
check 1
19
check 0
switch 16
check 0
switch 19
check 0
check 1
49
check 0
check 0
check 1
23
switch 3
check 0
check 9
67
68
69
71
72
73
75
76
77
check 0
switch 2
check 0
check 3
70
74
78
check 0
switch 14
check 0
check 1
7
check 0
switch 12
check 0
check 1
9
check 0
switch 10
check 0
check 1
11
check 0
switch 8
check 0
check 1
13
check 0
switch 6
check 0
check 1
15
check 0
switch 4
check 0
check 1
17
check 0
check 0
check 2
32
33
switch 0
check 3
2
5
34
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 9
79
80
81
83
84
85
87
88
89
check 0
switch 2
check 0
check 3
82
86
90
check 0
check 0
switch 0
check 3
6
35
36
check 0
check 0
check 0
check 0
check 0
check 0
switch 20
check 0
check 0
check 1
20
check 0
switch 16
check 0
check 0
check 1
24
switch 17
check 0
switch 19
check 0
check 1
50
check 0
check 0
check 0
switch 3
check 0
check 6
91
92
93
95
96
97
check 0
switch 2
check 0
check 2
94
98
check 0
switch 14
check 0
check 1
8
check 0
switch 12
check 0
check 1
10
check 0
switch 10
check 0
check 1
12
check 0
switch 8
check 0
check 1
14
check 0
switch 6
check 0
check 1
16
check 0
switch 4
check 0
check 1
18
check 0
check 0
switch 0
check 0
switch 20
check 2
37
38
switch 18
check 0
check 1
48
check 0
check 0
check 0
check 0
check 0
check 1
39
switch 20
check 2
40
41
check 0
check 0
check 1
21
check 0
check 2
42
43
check 1
44
switch 20
check 2
45
46
check 0
check 0
check 1
22
check 0
switch 19
check 0
check 0
check 1
25
switch 18
check 0
check 0
check 1
26
check 0
end_SG
begin_DTG
2
2
37
0
4
38
0
1
5
39
0
2
0
40
0
3
41
0
2
2
42
0
5
43
0
1
0
44
0
2
1
45
0
3
46
0
end_DTG
begin_DTG
2
2
27
0
4
28
0
1
5
29
0
2
0
30
0
3
31
0
2
2
32
0
5
33
0
1
0
34
0
2
1
35
0
3
36
0
end_DTG
begin_DTG
5
1
54
1
1 0
1
66
1
1 1
1
70
1
1 2
1
82
1
1 4
1
94
1
1 5
4
0
3
1
1 0
0
4
1
1 2
0
5
1
1 4
0
6
1
1 5
end_DTG
begin_DTG
5
1
87
1
1 4
1
76
1
1 2
1
91
1
1 5
1
63
1
1 1
1
52
1
1 0
3
0
0
1
1 0
0
1
1
1 2
0
2
1
1 4
end_DTG
begin_DTG
0
8
0
61
2
1 0
3 0
0
62
2
1 0
2 0
0
77
2
1 2
3 0
0
78
2
1 2
2 0
0
89
2
1 4
3 0
0
90
2
1 4
2 0
0
97
2
1 5
3 0
0
98
2
1 5
2 0
end_DTG
begin_DTG
0
2
0
17
2
1 2
4 0
0
18
2
1 5
4 0
end_DTG
begin_DTG
0
4
0
60
2
1 0
3 0
0
76
2
1 2
3 0
0
88
2
1 4
3 0
0
96
2
1 5
3 0
end_DTG
begin_DTG
0
2
0
15
2
1 2
6 0
0
16
2
1 5
6 0
end_DTG
begin_DTG
0
4
0
59
2
1 0
3 0
0
75
2
1 2
3 0
0
87
2
1 4
3 0
0
95
2
1 5
3 0
end_DTG
begin_DTG
0
2
0
13
2
1 2
8 0
0
14
2
1 5
8 0
end_DTG
begin_DTG
0
3
0
56
2
1 0
3 0
0
72
2
1 2
3 0
0
84
2
1 4
3 0
end_DTG
begin_DTG
0
2
0
11
2
1 2
10 0
0
12
2
1 5
10 0
end_DTG
begin_DTG
0
1
0
51
2
1 0
3 0
end_DTG
begin_DTG
0
2
0
9
2
1 2
12 0
0
10
2
1 5
12 0
end_DTG
begin_DTG
0
4
0
63
2
1 1
3 0
0
67
2
1 2
3 0
0
79
2
1 4
3 0
0
91
2
1 5
3 0
end_DTG
begin_DTG
0
2
0
7
2
1 2
14 0
0
8
2
1 5
14 0
end_DTG
begin_DTG
1
1
49
2
1 2
19 0
0
end_DTG
begin_DTG
1
1
50
2
1 5
19 0
0
end_DTG
begin_DTG
1
1
48
2
0 0
20 0
1
0
26
0
end_DTG
begin_DTG
3
1
47
2
1 0
20 0
1
49
2
1 2
16 0
1
50
2
1 5
17 0
1
0
25
0
end_DTG
begin_DTG
2
1
47
2
1 0
19 0
2
48
2
0 0
18 0
0
0
end_DTG
begin_DTG
0
2
0
23
2
1 2
16 1
0
24
2
1 5
16 1
end_DTG
begin_DTG
0
4
0
19
2
1 2
20 1
0
20
2
1 5
20 1
0
21
2
0 2
20 2
0
22
2
0 5
20 2
end_DTG
begin_CG
3
20 1
22 2
18 1
20
20 1
16 1
17 1
3 39
2 16
15 2
13 2
11 2
9 2
7 2
5 2
22 2
21 2
19 3
14 4
12 1
10 3
8 4
6 4
4 8
1
4 4
6
14 4
12 1
10 3
8 4
6 4
4 4
1
5 2
0
1
7 2
0
1
9 2
0
1
11 2
0
1
13 2
0
1
15 2
0
2
21 2
19 1
1
19 1
1
20 1
3
20 1
16 1
17 1
3
22 4
19 1
18 1
0
0
end_CG
