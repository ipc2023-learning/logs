begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
end_variable
begin_variable
var25
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var22
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var20
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var19
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var18
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
0
begin_state
1
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
4
9 0
10 0
11 0
12 0
end_goal
32
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint1 waypoint5
2
0 0
1 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint2 waypoint5
2
0 1
1 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint3 waypoint5
2
0 2
1 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint4 waypoint5
2
0 3
1 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint1 waypoint5
2
0 0
2 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint2 waypoint5
2
0 1
2 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint3 waypoint5
2
0 2
2 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint4 waypoint5
2
0 3
2 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint5 waypoint1 waypoint5
2
0 0
3 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint5 waypoint2 waypoint5
2
0 1
3 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint5 waypoint3 waypoint5
2
0 2
3 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint5 waypoint4 waypoint5
2
0 3
3 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint1 waypoint5
2
0 0
5 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint2 waypoint5
2
0 1
5 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint3 waypoint5
2
0 2
5 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint4 waypoint5
2
0 3
5 1
1
0 9 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 8 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 0 0 1
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint1
0
1
0 0 1 0
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint3
0
1
0 0 1 2
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint2
0
1
0 0 2 1
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint5
0
1
0 0 2 4
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint3
0
1
0 0 4 2
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint3
1
0 2
2
0 1 0 1
0 8 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint4
1
0 3
2
0 2 0 1
0 8 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint5
1
0 4
2
0 3 0 1
0 8 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint1
1
0 0
2
0 4 0 1
0 8 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
0 2
2
0 5 0 1
0 8 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint4
1
0 3
2
0 6 0 1
0 8 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint5
1
0 4
2
0 7 0 1
0 8 0 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 1
check 2
17
18
check 0
check 1
0
switch 2
check 0
check 0
check 1
4
switch 3
check 0
check 0
check 1
8
switch 4
check 0
switch 8
check 0
check 1
28
check 0
check 0
check 0
switch 5
check 0
check 0
check 1
12
check 0
switch 1
check 2
19
20
check 0
check 1
1
switch 2
check 0
check 0
check 1
5
switch 3
check 0
check 0
check 1
9
switch 5
check 0
check 0
check 1
13
check 0
switch 1
check 2
21
22
switch 8
check 0
check 1
25
check 0
check 0
check 1
2
switch 2
check 0
check 0
check 1
6
switch 3
check 0
check 0
check 1
10
switch 5
check 0
switch 8
check 0
check 1
29
check 0
check 0
check 1
14
check 0
switch 1
check 1
23
check 0
check 1
3
switch 2
check 0
switch 8
check 0
check 1
26
check 0
check 0
check 1
7
switch 3
check 0
check 0
check 1
11
switch 5
check 0
check 0
check 1
15
switch 6
check 0
switch 8
check 0
check 1
30
check 0
check 0
check 0
check 0
switch 1
check 1
24
check 0
check 0
switch 3
check 0
switch 8
check 0
check 1
27
check 0
check 0
check 0
switch 7
check 0
switch 8
check 0
check 1
31
check 0
check 0
check 0
check 0
switch 8
check 0
check 0
check 1
16
check 0
end_SG
begin_DTG
2
1
17
0
3
18
0
2
0
19
0
2
20
0
2
1
21
0
4
22
0
1
0
23
0
1
2
24
0
end_DTG
begin_DTG
1
1
25
2
0 2
8 0
0
end_DTG
begin_DTG
1
1
26
2
0 3
8 0
0
end_DTG
begin_DTG
1
1
27
2
0 4
8 0
0
end_DTG
begin_DTG
1
1
28
2
0 0
8 0
0
end_DTG
begin_DTG
1
1
29
2
0 2
8 0
0
end_DTG
begin_DTG
1
1
30
2
0 3
8 0
0
end_DTG
begin_DTG
1
1
31
2
0 4
8 0
0
end_DTG
begin_DTG
7
1
25
2
0 2
1 0
1
26
2
0 3
2 0
1
27
2
0 4
3 0
1
28
2
0 0
4 0
1
29
2
0 2
5 0
1
30
2
0 3
6 0
1
31
2
0 4
7 0
1
0
16
0
end_DTG
begin_DTG
0
4
0
12
2
0 0
5 1
0
13
2
0 1
5 1
0
14
2
0 2
5 1
0
15
2
0 3
5 1
end_DTG
begin_DTG
0
4
0
8
2
0 0
3 1
0
9
2
0 1
3 1
0
10
2
0 2
3 1
0
11
2
0 3
3 1
end_DTG
begin_DTG
0
4
0
4
2
0 0
2 1
0
5
2
0 1
2 1
0
6
2
0 2
2 1
0
7
2
0 3
2 1
end_DTG
begin_DTG
0
4
0
0
2
0 0
1 1
0
1
2
0 1
1 1
0
2
2
0 2
1 1
0
3
2
0 3
1 1
end_DTG
begin_CG
12
1 1
2 1
3 1
4 1
5 1
6 1
7 1
12 4
11 4
10 4
9 4
8 7
2
12 4
8 1
2
11 4
8 1
2
10 4
8 1
1
8 1
2
9 4
8 1
1
8 1
1
8 1
7
1 1
2 1
3 1
4 1
5 1
6 1
7 1
0
0
0
0
end_CG
