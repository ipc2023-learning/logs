begin_version
3
end_version
begin_metric
0
end_metric
57
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera4, rover4)
NegatedAtom calibrated(camera4, rover4)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera3, rover4)
NegatedAtom calibrated(camera3, rover4)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera2, rover4)
NegatedAtom calibrated(camera2, rover4)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera1, rover4)
NegatedAtom calibrated(camera1, rover4)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover4, objective9, high_res)
NegatedAtom have_image(rover4, objective9, high_res)
end_variable
begin_variable
var46
-1
2
Atom communicated_image_data(objective9, high_res)
NegatedAtom communicated_image_data(objective9, high_res)
end_variable
begin_variable
var87
-1
2
Atom have_image(rover4, objective8, low_res)
NegatedAtom have_image(rover4, objective8, low_res)
end_variable
begin_variable
var44
-1
2
Atom communicated_image_data(objective8, low_res)
NegatedAtom communicated_image_data(objective8, low_res)
end_variable
begin_variable
var85
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var42
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var83
-1
2
Atom have_image(rover4, objective7, high_res)
NegatedAtom have_image(rover4, objective7, high_res)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var82
-1
2
Atom have_image(rover4, objective7, colour)
NegatedAtom have_image(rover4, objective7, colour)
end_variable
begin_variable
var39
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover4, objective6, low_res)
NegatedAtom have_image(rover4, objective6, low_res)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var80
-1
2
Atom have_image(rover4, objective6, high_res)
NegatedAtom have_image(rover4, objective6, high_res)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var33
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover4, objective4, high_res)
NegatedAtom have_image(rover4, objective4, high_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var73
-1
2
Atom have_image(rover4, objective4, colour)
NegatedAtom have_image(rover4, objective4, colour)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var69
-1
2
Atom have_image(rover4, objective2, low_res)
NegatedAtom have_image(rover4, objective2, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover4, objective2, high_res)
NegatedAtom have_image(rover4, objective2, high_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var67
-1
2
Atom have_image(rover4, objective2, colour)
NegatedAtom have_image(rover4, objective2, colour)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var64
-1
2
Atom have_image(rover4, objective10, colour)
NegatedAtom have_image(rover4, objective10, colour)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective10, colour)
NegatedAtom communicated_image_data(objective10, colour)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, wa




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
8
263
0
3
0
264
0
3
265
0
9
266
0
3
3
267
0
5
268
0
6
269
0
4
1
270
0
2
271
0
4
272
0
7
273
0
4
0
274
0
3
275
0
6
276
0
9
277
0
2
2
278
0
8
279
0
4
0
280
0
2
281
0
4
282
0
9
283
0
2
0
284
0
3
285
0
2
0
286
0
5
287
0
3
1
288
0
4
289
0
6
290
0
end_DTG
begin_DTG
2
1
363
2
36 1
45 0
2
366
2
35 1
46 0
0
0
end_DTG
begin_DTG
2
1
364
2
36 2
45 0
2
367
2
35 2
46 0
0
0
end_DTG
begin_DTG
2
1
365
2
36 3
45 0
2
368
2
35 3
46 0
0
0
end_DTG
begin_DTG
3
1
369
2
36 0
45 0
2
376
2
35 0
46 0
3
383
2
0 0
49 0
0
0
0
end_DTG
begin_DTG
3
1
370
2
36 2
45 0
2
377
2
35 2
46 0
3
384
2
0 2
49 0
0
0
0
end_DTG
begin_DTG
3
1
371
2
36 3
45 0
2
378
2
35 3
46 0
3
385
2
0 3
49 0
0
0
0
end_DTG
begin_DTG
3
1
372
2
36 5
45 0
2
379
2
35 5
46 0
3
386
2
0 5
49 0
0
0
0
end_DTG
begin_DTG
3
1
373
2
36 6
45 0
2
380
2
35 6
46 0
3
387
2
0 6
49 0
0
0
0
end_DTG
begin_DTG
10
1
363
2
36 1
37 0
1
364
2
36 2
38 0
1
365
2
36 3
39 0
1
369
2
36 0
40 0
1
370
2
36 2
41 0
1
371
2
36 3
42 0
1
372
2
36 5
43 0
1
373
2
36 6
44 0
1
374
2
36 7
47 0
1
375
2
36 8
48 0
1
0
256
0
end_DTG
begin_DTG
10
1
366
2
35 1
37 0
1
367
2
35 2
38 0
1
368
2
35 3
39 0
1
376
2
35 0
40 0
1
377
2
35 2
41 0
1
378
2
35 3
42 0
1
379
2
35 5
43 0
1
380
2
35 6
44 0
1
381
2
35 7
47 0
1
382
2
35 8
48 0
1
0
257
0
end_DTG
begin_DTG
3
1
374
2
36 7
45 0
2
381
2
35 7
46 0
3
388
2
0 7
49 0
0
0
0
end_DTG
begin_DTG
3
1
375
2
36 8
45 0
2
382
2
35 8
46 0
3
389
2
0 8
49 0
0
0
0
end_DTG
begin_DTG
7
1
383
2
0 0
40 0
1
384
2
0 2
41 0
1
385
2
0 3
42 0
1
386
2
0 5
43 0
1
387
2
0 6
44 0
1
388
2
0 7
47 0
1
389
2
0 8
48 0
1
0
258
0
end_DTG
begin_DTG
0
21
0
224
2
35 5
47 2
0
255
2
0 8
47 3
0
254
2
0 7
47 3
0
253
2
0 6
47 3
0
252
2
0 5
47 3
0
251
2
0 4
47 3
0
250
2
0 2
47 3
0
249
2
0 1
47 3
0
227
2
35 8
47 2
0
226
2
35 7
47 2
0
225
2
35 6
47 2
0
193
2
36 1
47 1
0
223
2
35 4
47 2
0
222
2
35 2
47 2
0
221
2
35 1
47 2
0
199
2
36 8
47 1
0
198
2
36 7
47 1
0
197
2
36 6
47 1
0
196
2
36 5
47 1
0
195
2
36 4
47 1
0
194
2
36 2
47 1
end_DTG
begin_DTG
0
21
0
217
2
35 5
44 2
0
248
2
0 8
44 3
0
247
2
0 7
44 3
0
246
2
0 6
44 3
0
245
2
0 5
44 3
0
244
2
0 4
44 3
0
243
2
0 2
44 3
0
242
2
0 1
44 3
0
220
2
35 8
44 2
0
219
2
35 7
44 2
0
218
2
35 6
44 2
0
186
2
36 1
44 1
0
216
2
35 4
44 2
0
215
2
35 2
44 2
0
214
2
35 1
44 2
0
192
2
36 8
44 1
0
191
2
36 7
44 1
0
190
2
36 6
44 1
0
189
2
36 5
44 1
0
188
2
36 4
44 1
0
187
2
36 2
44 1
end_DTG
begin_DTG
0
21
0
210
2
35 5
43 2
0
241
2
0 8
43 3
0
240
2
0 7
43 3
0
239
2
0 6
43 3
0
238
2
0 5
43 3
0
237
2
0 4
43 3
0
236
2
0 2
43 3
0
235
2
0 1
43 3
0
213
2
35 8
43 2
0
212
2
35 7
43 2
0
211
2
35 6
43 2
0
179
2
36 1
43 1
0
209
2
35 4
43 2
0
208
2
35 2
43 2
0
207
2
35 1
43 2
0
185
2
36 8
43 1
0
184
2
36 7
43 1
0
183
2
36 6
43 1
0
182
2
36 5
43 1
0
181
2
36 4
43 1
0
180
2
36 2
43 1
end_DTG
begin_DTG
0
21
0
203
2
35 5
41 2
0
234
2
0 8
41 3
0
233
2
0 7
41 3
0
232
2
0 6
41 3
0
231
2
0 5
41 3
0
230
2
0 4
41 3
0
229
2
0 2
41 3
0
228
2
0 1
41 3
0
206
2
35 8
41 2
0
205
2
35 7
41 2
0
204
2
35 6
41 2
0
172
2
36 1
41 1
0
202
2
35 4
41 2
0
201
2
35 2
41 2
0
200
2
35 1
41 2
0
178
2
36 8
41 1
0
177
2
36 7
41 1
0
176
2
36 6
41 1
0
175
2
36 5
41 1
0
174
2
36 4
41 1
0
173
2
36 2
41 1
end_DTG
begin_DTG
0
14
0
144
2
36 1
39 1
0
145
2
36 2
39 1
0
146
2
36 4
39 1
0
147
2
36 5
39 1
0
148
2
36 6
39 1
0
149
2
36 7
39 1
0
150
2
36 8
39 1
0
165
2
35 1
39 2
0
166
2
35 2
39 2
0
167
2
35 4
39 2
0
168
2
35 5
39 2
0
169
2
35 6
39 2
0
170
2
35 7
39 2
0
171
2
35 8
39 2
end_DTG
begin_DTG
0
14
0
137
2
36 1
38 1
0
138
2
36 2
38 1
0
139
2
36 4
38 1
0
140
2
36 5
38 1
0
141
2
36 6
38 1
0
142
2
36 7
38 1
0
143
2
36 8
38 1
0
158
2
35 1
38 2
0
159
2
35 2
38 2
0
160
2
35 4
38 2
0
161
2
35 5
38 2
0
162
2
35 6
38 2
0
163
2
35 7
38 2
0
164
2
35 8
38 2
end_DTG
begin_DTG
0
14
0
130
2
36 1
37 1
0
131
2
36 2
37 1
0
132
2
36 4
37 1
0
133
2
36 5
37 1
0
134
2
36 6
37 1
0
135
2
36 7
37 1
0
136
2
36 8
37 1
0
151
2
35 1
37 2
0
152
2
35 2
37 2
0
153
2
35 4
37 2
0
154
2
35 5
37 2
0
155
2
35 6
37 2
0
156
2
35 7
37 2
0
157
2
35 8
37 2
end_DTG
begin_CG
46
40 1
41 1
42 1
43 1
44 1
47 1
48 1
4 166
3 114
2 53
1 108
34 7
32 7
30 7
28 7
26 7
24 7
22 7
20 7
18 7
16 7
14 7
12 7
10 7
8 7
6 7
53 7
52 7
51 7
50 7
49 7
33 3
31 36
29 32
27 24
25 8
23 28
21 21
19 8
17 3
15 1
13 36
11 27
9 16
7 4
5 30
12
33 1
31 9
29 8
27 8
23 7
21 7
19 2
17 1
13 9
11 9
9 4
5 10
6
31 9
29 8
23 7
19 2
13 9
9 4
12
33 1
31 9
29 8
27 8
23 7
21 7
19 2
17 1
13 9
11 9
9 4
5 10
15
33 1
31 9
29 8
27 8
25 8
23 7
21 7
19 2
17 1
15 1
13 9
11 9
9 4
7 4
5 10
1
6 7
0
1
8 7
0
1
10 7
0
1
12 7
0
1
14 7
0
1
16 7
0
1
18 7
0
1
20 7
0
1
22 7
0
1
24 7
0
1
26 7
0
1
28 7
0
1
30 7
0
1
32 7
0
1
34 7
0
18
37 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
47 1
48 1
56 7
55 7
54 7
53 7
52 7
51 7
50 7
46 10
18
37 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
47 1
48 1
56 7
55 7
54 7
53 7
52 7
51 7
50 7
45 10
3
56 14
45 1
46 1
3
55 14
45 1
46 1
3
54 14
45 1
46 1
3
45 1
46 1
49 1
4
53 21
45 1
46 1
49 1
3
45 1
46 1
49 1
4
52 21
45 1
46 1
49 1
4
51 21
45 1
46 1
49 1
10
37 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
47 1
48 1
10
37 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
47 1
48 1
4
50 21
45 1
46 1
49 1
3
45 1
46 1
49 1
7
40 1
41 1
42 1
43 1
44 1
47 1
48 1
0
0
0
0
0
0
0
end_CG
