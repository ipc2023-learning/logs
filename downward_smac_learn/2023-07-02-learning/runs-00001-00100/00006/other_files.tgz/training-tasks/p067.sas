begin_version
3
end_version
begin_metric
0
end_metric
43
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective6, high_res)
NegatedAtom have_image(rover1, objective6, high_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover1, objective5, colour)
NegatedAtom have_image(rover1, objective5, colour)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var59
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var55
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var3
-1
4
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var4
-1
4
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var5
-1
4
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var6
-1
4
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var7
-1
4
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
Atom have_soil_analysis(rover3, waypoint1)
end_variable
begin_variable
var9
-1
4
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var10
-1
4
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
Atom have_soil_analysis(rover3, waypoint6)
end_variable
begin_variable
var47
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var48
-1
2
Atom empty(rover




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
14
1
2 7
end_DTG
begin_DTG
8
1
308
1
2 5
1
337
1
2 6
1
290
1
2 4
1
367
1
2 7
1
194
1
2 1
1
223
1
2 2
1
182
1
2 0
1
253
1
2 3
4
0
4
1
2 2
0
5
1
2 3
0
6
1
2 5
0
7
1
2 7
end_DTG
begin_DTG
8
1
306
1
2 5
1
335
1
2 6
1
288
1
2 4
1
365
1
2 7
1
192
1
2 1
1
221
1
2 2
1
180
1
2 0
1
251
1
2 3
4
0
0
1
2 2
0
1
1
2 3
0
2
1
2 5
0
3
1
2 7
end_DTG
begin_DTG
0
3
0
383
2
2 7
5 0
0
385
2
2 7
4 0
0
387
2
2 7
3 0
end_DTG
begin_DTG
0
2
0
29
2
2 0
6 0
0
30
2
2 1
6 0
end_DTG
begin_DTG
0
8
0
172
2
2 0
5 0
0
196
2
2 1
5 0
0
226
2
2 2
5 0
0
262
2
2 3
5 0
0
280
2
2 4
5 0
0
310
2
2 5
5 0
0
340
2
2 6
5 0
0
376
2
2 7
5 0
end_DTG
begin_DTG
0
2
0
27
2
2 0
8 0
0
28
2
2 1
8 0
end_DTG
begin_DTG
0
6
0
258
2
2 3
5 0
0
260
2
2 3
4 0
0
336
2
2 6
5 0
0
338
2
2 6
4 0
0
372
2
2 7
5 0
0
374
2
2 7
4 0
end_DTG
begin_DTG
0
2
0
25
2
2 0
10 0
0
26
2
2 1
10 0
end_DTG
begin_DTG
0
9
0
257
2
2 3
5 0
0
259
2
2 3
4 0
0
261
2
2 3
3 0
0
335
2
2 6
5 0
0
337
2
2 6
4 0
0
339
2
2 6
3 0
0
371
2
2 7
5 0
0
373
2
2 7
4 0
0
375
2
2 7
3 0
end_DTG
begin_DTG
0
2
0
23
2
2 0
12 0
0
24
2
2 1
12 0
end_DTG
begin_DTG
0
3
0
256
2
2 3
5 0
0
334
2
2 6
5 0
0
370
2
2 7
5 0
end_DTG
begin_DTG
0
2
0
21
2
2 0
14 0
0
22
2
2 1
14 0
end_DTG
begin_DTG
0
7
0
166
2
2 0
5 0
0
190
2
2 1
5 0
0
220
2
2 2
5 0
0
250
2
2 3
5 0
0
304
2
2 5
5 0
0
328
2
2 6
5 0
0
364
2
2 7
5 0
end_DTG
begin_DTG
0
2
0
19
2
2 0
16 0
0
20
2
2 1
16 0
end_DTG
begin_DTG
0
8
0
216
2
2 2
5 0
0
218
2
2 2
4 0
0
246
2
2 3
5 0
0
248
2
2 3
4 0
0
300
2
2 5
5 0
0
302
2
2 5
4 0
0
360
2
2 7
5 0
0
362
2
2 7
4 0
end_DTG
begin_DTG
0
2
0
17
2
2 0
18 0
0
18
2
2 1
18 0
end_DTG
begin_DTG
0
14
0
186
2
2 1
5 0
0
188
2
2 1
4 0
0
210
2
2 2
5 0
0
212
2
2 2
4 0
0
240
2
2 3
5 0
0
242
2
2 3
4 0
0
276
2
2 4
5 0
0
278
2
2 4
4 0
0
294
2
2 5
5 0
0
296
2
2 5
4 0
0
324
2
2 6
5 0
0
326
2
2 6
4 0
0
354
2
2 7
5 0
0
356
2
2 7
4 0
end_DTG
begin_DTG
0
2
0
15
2
2 0
20 0
0
16
2
2 1
20 0
end_DTG
begin_DTG
3
1
136
2
2 2
30 0
2
141
2
1 2
31 0
3
146
2
0 2
34 0
0
0
0
end_DTG
begin_DTG
3
1
137
2
2 3
30 0
2
142
2
1 3
31 0
3
147
2
0 3
34 0
0
0
0
end_DTG
begin_DTG
3
1
138
2
2 4
30 0
2
143
2
1 4
31 0
3
148
2
0 4
34 0
0
0
0
end_DTG
begin_DTG
3
1
139
2
2 5
30 0
2
144
2
1 5
31 0
3
149
2
0 5
34 0
0
0
0
end_DTG
begin_DTG
3
1
140
2
2 6
30 0
2
145
2
1 6
31 0
3
150
2
0 6
34 0
0
0
0
end_DTG
begin_DTG
3
1
151
2
2 0
30 0
2
156
2
1 0
31 0
3
161
2
0 0
34 0
0
0
0
end_DTG
begin_DTG
3
1
152
2
2 1
30 0
2
157
2
1 1
31 0
3
162
2
0 1
34 0
0
0
0
end_DTG
begin_DTG
3
1
153
2
2 5
30 0
2
158
2
1 5
31 0
3
163
2
0 5
34 0
0
0
0
end_DTG
begin_DTG
10
1
136
2
2 2
22 0
1
137
2
2 3
23 0
1
138
2
2 4
24 0
1
139
2
2 5
25 0
1
140
2
2 6
26 0
1
151
2
2 0
27 0
1
152
2
2 1
28 0
1
153
2
2 5
29 0
1
154
2
2 6
32 0
1
155
2
2 7
33 0
1
0
79
0
end_DTG
begin_DTG
10
1
141
2
1 2
22 0
1
142
2
1 3
23 0
1
143
2
1 4
24 0
1
144
2
1 5
25 0
1
145
2
1 6
26 0
1
156
2
1 0
27 0
1
157
2
1 1
28 0
1
158
2
1 5
29 0
1
159
2
1 6
32 0
1
160
2
1 7
33 0
1
0
80
0
end_DTG
begin_DTG
3
1
154
2
2 6
30 0
2
159
2
1 6
31 0
3
164
2
0 6
34 0
0
0
0
end_DTG
begin_DTG
3
1
155
2
2 7
30 0
2
160
2
1 7
31 0
3
165
2
0 7
34 0
0
0
0
end_DTG
begin_DTG
10
1
146
2
0 2
22 0
1
147
2
0 3
23 0
1
148
2
0 4
24 0
1
149
2
0 5
25 0
1
150
2
0 6
26 0
1
161
2
0 0
27 0
1
162
2
0 1
28 0
1
163
2
0 5
29 0
1
164
2
0 6
32 0
1
165
2
0 7
33 0
1
0
81
0
end_DTG
begin_DTG
0
6
0
65
2
2 0
33 1
0
66
2
2 1
33 1
0
71
2
1 0
33 2
0
72
2
1 1
33 2
0
77
2
0 0
33 3
0
78
2
0 1
33 3
end_DTG
begin_DTG
0
6
0
63
2
2 0
29 1
0
64
2
2 1
29 1
0
69
2
1 0
29 2
0
70
2
1 1
29 2
0
75
2
0 0
29 3
0
76
2
0 1
29 3
end_DTG
begin_DTG
0
6
0
61
2
2 0
27 1
0
62
2
2 1
27 1
0
67
2
1 0
27 2
0
68
2
1 1
27 2
0
73
2
0 0
27 3
0
74
2
0 1
27 3
end_DTG
begin_DTG
0
6
0
39
2
2 0
26 1
0
40
2
2 1
26 1
0
49
2
1 0
26 2
0
50
2
1 1
26 2
0
59
2
0 0
26 3
0
60
2
0 1
26 3
end_DTG
begin_DTG
0
6
0
37
2
2 0
25 1
0
38
2
2 1
25 1
0
47
2
1 0
25 2
0
48
2
1 1
25 2
0
57
2
0 0
25 3
0
58
2
0 1
25 3
end_DTG
begin_DTG
0
6
0
35
2
2 0
24 1
0
36
2
2 1
24 1
0
45
2
1 0
24 2
0
46
2
1 1
24 2
0
55
2
0 0
24 3
0
56
2
0 1
24 3
end_DTG
begin_DTG
0
6
0
33
2
2 0
23 1
0
34
2
2 1
23 1
0
43
2
1 0
23 2
0
44
2
1 1
23 2
0
53
2
0 0
23 3
0
54
2
0 1
23 3
end_DTG
begin_DTG
0
6
0
31
2
2 0
22 1
0
32
2
2 1
22 1
0
41
2
1 0
22 2
0
42
2
1 1
22 2
0
51
2
0 0
22 3
0
52
2
0 1
22 3
end_DTG
begin_CG
19
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
32 1
33 1
42 2
41 2
40 2
39 2
38 2
37 2
36 2
35 2
34 10
19
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
32 1
33 1
42 2
41 2
40 2
39 2
38 2
37 2
36 2
35 2
31 10
38
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
32 1
33 1
5 118
4 80
3 45
21 2
19 2
17 2
15 2
13 2
11 2
9 2
7 2
42 2
41 2
40 2
39 2
38 2
37 2
36 2
35 2
30 10
20 14
18 8
16 7
14 3
12 9
10 6
8 8
6 3
2
12 3
6 1
5
20 7
18 4
12 3
10 3
6 1
8
20 7
18 4
16 7
14 3
12 3
10 3
8 8
6 1
1
7 2
0
1
9 2
0
1
11 2
0
1
13 2
0
1
15 2
0
1
17 2
0
1
19 2
0
1
21 2
0
4
42 6
30 1
31 1
34 1
4
41 6
30 1
31 1
34 1
4
40 6
30 1
31 1
34 1
4
39 6
30 1
31 1
34 1
4
38 6
30 1
31 1
34 1
4
37 6
30 1
31 1
34 1
3
30 1
31 1
34 1
4
36 6
30 1
31 1
34 1
10
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
32 1
33 1
10
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
32 1
33 1
3
30 1
31 1
34 1
4
35 6
30 1
31 1
34 1
10
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
32 1
33 1
0
0
0
0
0
0
0
0
end_CG
