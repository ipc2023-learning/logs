begin_version
3
end_version
begin_metric
0
end_metric
49
begin_variable
var2
-1
7
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var65
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover3, objective5, high_res)
NegatedAtom have_image(rover3, objective5, high_res)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var55
-1
2
Atom have_image(rover3, objective1, high_res)
NegatedAtom have_image(rover3, objective1, high_res)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera2, rover3)
NegatedAtom calibrated(camera2, rover3)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover3, objective3, low_res)
NegatedAtom have_image(rover3, objective3, low_res)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover3, objective2, low_res)
NegatedAtom have_image(rover3, objective2, low_res)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover2, objective6, high_res)
NegatedAtom have_image(rover2, objective6, high_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover2, objective6, colour)
NegatedAtom have_image(rover2, objective6, colour)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var50
-1
2
Atom have_image(rover2, objective5, high_res)
NegatedAtom have_image(rover2, objective5, high_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var49
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var42
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover2, objective1, high_res)
NegatedAtom have_image(rover2, objective1, high_res)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var37
-1
2
Atom have_image(rover2, objective1, colour)
Neg




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 2
0
14
1
0 3
0
15
1
0 5
end_DTG
begin_DTG
0
5
0
209
2
0 0
1 0
0
225
2
0 2
1 0
0
233
2
0 3
1 0
0
241
2
0 4
1 0
0
251
2
0 6
1 0
end_DTG
begin_DTG
0
3
0
207
2
0 0
1 0
0
217
2
0 1
1 0
0
249
2
0 6
1 0
end_DTG
begin_DTG
0
6
0
205
2
0 0
1 0
0
215
2
0 1
1 0
0
223
2
0 2
1 0
0
231
2
0 3
1 0
0
239
2
0 4
1 0
0
247
2
0 6
1 0
end_DTG
begin_DTG
0
6
0
199
2
0 0
1 0
0
211
2
0 1
1 0
0
219
2
0 2
1 0
0
227
2
0 3
1 0
0
235
2
0 4
1 0
0
243
2
0 5
1 0
end_DTG
begin_DTG
7
1
224
1
0 2
1
250
1
0 6
1
244
1
0 5
1
240
1
0 4
1
232
1
0 3
1
198
1
0 0
1
216
1
0 1
5
0
6
1
0 0
0
7
1
0 2
0
8
1
0 3
0
9
1
0 4
0
10
1
0 6
end_DTG
begin_DTG
0
6
0
204
2
0 0
6 0
0
214
2
0 1
6 0
0
222
2
0 2
6 0
0
230
2
0 3
6 0
0
238
2
0 4
6 0
0
246
2
0 6
6 0
end_DTG
begin_DTG
0
2
0
202
2
0 0
6 0
0
236
2
0 4
6 0
end_DTG
begin_DTG
0
5
0
200
2
0 0
6 0
0
212
2
0 1
6 0
0
220
2
0 2
6 0
0
228
2
0 3
6 0
0
244
2
0 5
6 0
end_DTG
begin_DTG
0
6
0
198
2
0 0
6 0
0
210
2
0 1
6 0
0
218
2
0 2
6 0
0
226
2
0 3
6 0
0
234
2
0 4
6 0
0
242
2
0 5
6 0
end_DTG
begin_DTG
1
5
83
0
1
2
84
0
2
1
85
0
4
86
0
1
6
87
0
2
2
88
0
6
89
0
2
0
90
0
6
91
0
3
3
92
0
4
93
0
5
94
0
end_DTG
begin_DTG
7
1
167
1
11 3
1
177
1
11 4
1
158
1
11 2
1
188
1
11 5
1
197
1
11 6
1
127
1
11 0
1
136
1
11 1
6
0
0
1
11 0
0
1
1
11 1
0
2
1
11 2
0
3
1
11 3
0
4
1
11 4
0
5
1
11 6
end_DTG
begin_DTG
0
5
0
133
2
11 0
12 0
0
157
2
11 2
12 0
0
169
2
11 3
12 0
0
181
2
11 4
12 0
0
196
2
11 6
12 0
end_DTG
begin_DTG
0
4
0
38
2
11 2
13 0
0
39
2
11 6
13 0
0
54
2
0 2
2 0
0
55
2
0 6
2 0
end_DTG
begin_DTG
0
5
0
132
2
11 0
12 0
0
156
2
11 2
12 0
0
168
2
11 3
12 0
0
180
2
11 4
12 0
0
195
2
11 6
12 0
end_DTG
begin_DTG
0
2
0
36
2
11 2
15 0
0
37
2
11 6
15 0
end_DTG
begin_DTG
0
3
0
130
2
11 0
12 0
0
145
2
11 1
12 0
0
193
2
11 6
12 0
end_DTG
begin_DTG
0
4
0
34
2
11 2
17 0
0
35
2
11 6
17 0
0
52
2
0 2
3 0
0
53
2
0 6
3 0
end_DTG
begin_DTG
0
3
0
129
2
11 0
12 0
0
144
2
11 1
12 0
0
192
2
11 6
12 0
end_DTG
begin_DTG
0
2
0
32
2
11 2
19 0
0
33
2
11 6
19 0
end_DTG
begin_DTG
0
6
0
128
2
11 0
12 0
0
143
2
11 1
12 0
0
155
2
11 2
12 0
0
167
2
11 3
12 0
0
179
2
11 4
12 0
0
191
2
11 6
12 0
end_DTG
begin_DTG
0
4
0
30
2
11 2
21 0
0
31
2
11 6
21 0
0
50
2
0 2
7 0
0
51
2
0 6
7 0
end_DTG
begin_DTG
0
6
0
127
2
11 0
12 0
0
142
2
11 1
12 0
0
154
2
11 2
12 0
0
166
2
11 3
12 0
0
178
2
11 4
12 0
0
190
2
11 6
12 0
end_DTG
begin_DTG
0
4
0
28
2
11 2
23 0
0
29
2
11 6
23 0
0
48
2
0 2
4 0
0
49
2
0 6
4 0
end_DTG
begin_DTG
0
2
0
125
2
11 0
12 0
0
176
2
11 4
12 0
end_DTG
begin_DTG
0
4
0
26
2
11 2
25 0
0
27
2
11 6
25 0
0
46
2
0 2
8 0
0
47
2
0 6
8 0
end_DTG
begin_DTG
0
2
0
123
2
11 0
12 0
0
174
2
11 4
12 0
end_DTG
begin_DTG
0
2
0
24
2
11 2
27 0
0
25
2
11 6
27 0
end_DTG
begin_DTG
0
5
0
122
2
11 0
12 0
0
140
2
11 1
12 0
0
152
2
11 2
12 0
0
164
2
11 3
12 0
0
188
2
11 5
12 0
end_DTG
begin_DTG
0
4
0
22
2
11 2
29 0
0
23
2
11 6
29 0
0
44
2
0 2
9 0
0
45
2
0 6
9 0
end_DTG
begin_DTG
0
6
0
119
2
11 0
12 0
0
137
2
11 1
12 0
0
149
2
11 2
12 0
0
161
2
11 3
12 0
0
173
2
11 4
12 0
0
185
2
11 5
12 0
end_DTG
begin_DTG
0
4
0
20
2
11 2
31 0
0
21
2
11 6
31 0
0
42
2
0 2
10 0
0
43
2
0 6
10 0
end_DTG
begin_DTG
0
6
0
118
2
11 0
12 0
0
136
2
11 1
12 0
0
148
2
11 2
12 0
0
160
2
11 3
12 0
0
172
2
11 4
12 0
0
184
2
11 5
12 0
end_DTG
begin_DTG
0
4
0
18
2
11 2
33 0
0
19
2
11 6
33 0
0
40
2
0 2
5 0
0
41
2
0 6
5 0
end_DTG
begin_DTG
0
6
0
117
2
11 0
12 0
0
135
2
11 1
12 0
0
147
2
11 2
12 0
0
159
2
11 3
12 0
0
171
2
11 4
12 0
0
183
2
11 5
12 0
end_DTG
begin_DTG
0
2
0
16
2
11 2
35 0
0
17
2
11 6
35 0
end_DTG
begin_DTG
1
5
71
0
1
2
72
0
2
1
73
0
4
74
0
1
6
75
0
2
2
76
0
6
77
0
2
0
78
0
6
79
0
3
3
80
0
4
81
0
5
82
0
end_DTG
begin_DTG
2
1
111
2
37 1
40 0
2
114
2
0 1
44 0
0
0
end_DTG
begin_DTG
2
1
112
2
37 2
40 0
2
115
2
0 2
44 0
0
0
end_DTG
begin_DTG
3
1
111
2
37 1
38 0
1
112
2
37 2
39 0
1
113
2
37 5
41 0
1
0
68
0
end_DTG
begin_DTG
2
1
113
2
37 5
40 0
2
116
2
0 5
44 0
0
0
end_DTG
begin_DTG
2
1
107
2
11 1
43 0
2
109
2
0 1
44 0
0
0
end_DTG
begin_DTG
2
1
107
2
11 1
42 0
1
108
2
11 3
45 0
1
0
69
0
end_DTG
begin_DTG
5
1
109
2
0 1
42 0
1
110
2
0 3
45 0
1
114
2
0 1
38 0
1
115
2
0 2
39 0
1
116
2
0 5
41 0
1
0
70
0
end_DTG
begin_DTG
2
1
108
2
11 3
43 0
2
110
2
0 3
44 0
0
0
end_DTG
begin_DTG
0
4
0
58
2
11 2
45 1
0
59
2
11 6
45 1
0
62
2
0 2
45 2
0
63
2
0 6
45 2
end_DTG
begin_DTG
0
4
0
56
2
11 2
42 1
0
57
2
11 6
42 1
0
60
2
0 2
42 2
0
61
2
0 6
42 2
end_DTG
begin_DTG
0
4
0
64
2
37 2
39 1
0
65
2
37 6
39 1
0
66
2
0 2
39 2
0
67
2
0 6
39 2
end_DTG
begin_CG
27
42 1
45 1
38 1
39 1
41 1
6 32
1 32
34 2
32 2
30 2
26 2
24 2
22 2
18 2
14 2
47 2
46 2
48 2
44 5
5 6
10 6
9 5
8 2
4 6
7 6
3 3
2 5
4
5 6
4 6
3 3
2 5
1
14 2
1
18 2
1
24 2
1
34 2
4
10 6
9 5
8 2
7 6
1
22 2
1
26 2
1
30 2
1
32 2
30
42 1
45 1
12 87
36 2
34 2
32 2
30 2
28 2
26 2
24 2
22 2
20 2
18 2
16 2
14 2
47 2
46 2
43 2
35 6
33 6
31 6
29 5
27 2
25 2
23 6
21 6
19 3
17 3
15 5
13 5
12
35 6
33 6
31 6
29 5
27 2
25 2
23 6
21 6
19 3
17 3
15 5
13 5
1
14 2
0
1
16 2
0
1
18 2
0
1
20 2
0
1
22 2
0
1
24 2
0
1
26 2
0
1
28 2
0
1
30 2
0
1
32 2
0
1
34 2
0
1
36 2
0
5
38 1
39 1
41 1
48 2
40 3
2
40 1
44 1
3
48 4
40 1
44 1
3
38 1
39 1
41 1
2
40 1
44 1
3
47 4
43 1
44 1
2
42 1
45 1
5
42 1
45 1
38 1
39 1
41 1
3
46 4
43 1
44 1
0
0
0
end_CG
