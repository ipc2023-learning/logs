begin_version
3
end_version
begin_metric
0
end_metric
22
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
end_variable
begin_variable
var33
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var34
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
end_variable
begin_variable
var30
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var28
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var27
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
0
begin_state
4
1
1
1
5
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
1
end_state
begin_goal
5
7 0
9 0
19 0
20 0
21 0
end_goal
269
begin_operator
calibrate rover1 camera1 objective2 waypoint1
1
4 0
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint2
1
4 1
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint3
1
4 2
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint5
1
4 4
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint6
1
4 5
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint7
1
4 6
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective3 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective3 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective3 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective3 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective3 waypoint6
1
0 5
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint3 waypoint2
2
4 2
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint4 waypoint2
2
4 3
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint5 waypoint2
2
4 4
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint6 waypoint2
2
4 5
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint7 waypoint2
2
4 6
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective4 high_res waypoint3 waypoint2
2
4 2
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective4 high_res waypoint4 waypoint2
2
4 3
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 gene




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
switch 6
check 0
check 1
19
check 0
check 0
switch 0
check 4
5
70
71
72
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
35
switch 12
check 0
check 0
check 1
40
switch 13
check 0
switch 16
check 0
check 1
94
check 0
check 0
check 0
switch 14
check 0
check 0
check 1
45
check 0
switch 18
check 0
switch 16
check 0
check 1
97
check 0
check 0
check 0
check 0
switch 5
check 0
check 12
173
174
175
176
177
178
179
180
181
182
183
184
check 0
switch 8
check 0
check 1
15
check 0
switch 6
check 0
check 1
20
check 0
check 0
switch 0
check 0
switch 10
check 2
6
73
check 0
check 0
switch 14
check 0
switch 17
check 0
check 1
98
check 0
check 0
check 0
check 0
switch 1
check 0
check 12
185
186
187
188
189
190
191
192
193
194
195
196
check 0
check 0
switch 10
check 3
74
75
76
check 0
check 0
switch 1
check 0
check 6
197
198
199
200
201
202
check 0
check 0
switch 10
check 4
7
77
78
79
check 0
check 0
switch 14
check 0
check 0
check 0
check 1
46
switch 1
check 0
check 12
203
204
205
206
207
208
209
210
211
212
213
214
check 0
switch 3
check 0
check 1
21
check 0
switch 2
check 0
check 1
26
check 0
check 0
switch 10
check 4
8
80
81
82
check 0
check 0
switch 14
check 0
check 0
check 0
check 1
47
switch 1
check 0
check 12
215
216
217
218
219
220
221
222
223
224
225
226
check 0
switch 3
check 0
check 1
22
check 0
switch 2
check 0
check 1
27
check 0
check 0
switch 10
check 3
9
83
84
check 0
check 0
switch 14
check 0
check 0
check 0
check 1
48
switch 1
check 0
check 15
227
228
229
230
231
232
233
234
235
236
237
238
239
240
241
check 0
switch 3
check 0
check 1
23
check 0
switch 2
check 0
check 1
28
check 0
check 0
switch 10
check 4
10
85
86
87
check 0
check 0
switch 14
check 0
check 0
check 0
check 1
49
switch 15
check 0
switch 17
check 0
check 1
99
check 0
check 0
check 0
check 0
switch 1
check 0
check 15
242
243
244
245
246
247
248
249
250
251
252
253
254
255
256
check 0
switch 3
check 0
check 1
24
check 0
switch 2
check 0
check 1
29
check 0
check 0
switch 10
check 3
88
89
90
check 0
check 0
switch 14
check 0
check 0
check 0
check 1
50
switch 18
check 0
switch 17
check 0
check 1
100
check 0
check 0
check 0
check 0
switch 1
check 0
check 12
257
258
259
260
261
262
263
264
265
266
267
268
check 0
switch 3
check 0
check 1
25
check 0
switch 2
check 0
check 1
30
check 0
check 0
switch 16
check 0
check 0
check 1
51
switch 17
check 0
check 0
check 1
52
check 0
end_SG
begin_DTG
1
5
73
0
3
2
74
0
3
75
0
5
76
0
3
1
77
0
3
78
0
4
79
0
3
1
80
0
2
81
0
6
82
0
2
2
83
0
6
84
0
3
0
85
0
1
86
0
6
87
0
3
3
88
0
4
89
0
5
90
0
end_DTG
begin_DTG
7
1
237
1
0 4
1
247
1
0 5
1
258
1
0 6
1
195
1
0 0
1
205
1
0 2
1
202
1
0 1
1
216
1
0 3
5
0
6
1
0 0
0
7
1
0 2
0
8
1
0 3
0
9
1
0 4
0
10
1
0 5
end_DTG
begin_DTG
0
6
0
192
2
0 0
1 0
0
210
2
0 2
1 0
0
222
2
0 3
1 0
0
237
2
0 4
1 0
0
252
2
0 5
1 0
0
264
2
0 6
1 0
end_DTG
begin_DTG
0
5
0
190
2
0 0
1 0
0
208
2
0 2
1 0
0
220
2
0 3
1 0
0
235
2
0 4
1 0
0
250
2
0 5
1 0
end_DTG
begin_DTG
3
2
53
0
4
54
0
5
55
0
2
2
56
0
4
57
0
4
0
58
0
1
59
0
3
60
0
4
61
0
2
2
62
0
6
63
0
4
0
64
0
1
65
0
2
66
0
6
67
0
2
0
68
0
6
69
0
3
3
70
0
4
71
0
5
72
0
end_DTG
begin_DTG
7
1
153
1
4 4
1
163
1
4 5
1
174
1
4 6
1
111
1
4 0
1
121
1
4 2
1
118
1
4 1
1
132
1
4 3
6
0
0
1
4 0
0
1
1
4 1
0
2
1
4 2
0
3
1
4 4
0
4
1
4 5
0
5
1
4 6
end_DTG
begin_DTG
0
6
0
108
2
4 0
5 0
0
126
2
4 2
5 0
0
138
2
4 3
5 0
0
153
2
4 4
5 0
0
168
2
4 5
5 0
0
180
2
4 6
5 0
end_DTG
begin_DTG
0
10
0
16
2
4 2
6 0
0
17
2
4 3
6 0
0
18
2
4 4
6 0
0
19
2
4 5
6 0
0
20
2
4 6
6 0
0
26
2
0 2
2 0
0
27
2
0 3
2 0
0
28
2
0 4
2 0
0
29
2
0 5
2 0
0
30
2
0 6
2 0
end_DTG
begin_DTG
0
5
0
106
2
4 0
5 0
0
124
2
4 2
5 0
0
136
2
4 3
5 0
0
151
2
4 4
5 0
0
166
2
4 5
5 0
end_DTG
begin_DTG
0
10
0
11
2
4 2
8 0
0
12
2
4 3
8 0
0
13
2
4 4
8 0
0
14
2
4 5
8 0
0
15
2
4 6
8 0
0
21
2
0 2
3 0
0
22
2
0 3
3 0
0
23
2
0 4
3 0
0
24
2
0 5
3 0
0
25
2
0 6
3 0
end_DTG
begin_DTG
1
1
91
2
4 0
16 0
0
end_DTG
begin_DTG
1
1
92
2
4 2
16 0
0
end_DTG
begin_DTG
1
1
93
2
4 5
16 0
0
end_DTG
begin_DTG
1
1
94
2
4 6
16 0
0
end_DTG
begin_DTG
2
1
95
2
4 0
16 0
2
98
2
0 0
17 0
0
0
end_DTG
begin_DTG
2
1
96
2
4 5
16 0
2
99
2
0 5
17 0
0
0
end_DTG
begin_DTG
7
1
91
2
4 0
10 0
1
92
2
4 2
11 0
1
93
2
4 5
12 0
1
94
2
4 6
13 0
1
95
2
4 0
14 0
1
96
2
4 5
15 0
1
97
2
4 6
18 0
1
0
51
0
end_DTG
begin_DTG
3
1
98
2
0 0
14 0
1
99
2
0 5
15 0
1
100
2
0 6
18 0
1
0
52
0
end_DTG
begin_DTG
2
1
97
2
4 6
16 0
2
100
2
0 6
17 0
0
0
end_DTG
begin_DTG
0
10
0
41
2
4 2
14 1
0
42
2
4 3
14 1
0
43
2
4 4
14 1
0
44
2
4 5
14 1
0
45
2
4 6
14 1
0
46
2
0 2
14 2
0
47
2
0 3
14 2
0
48
2
0 4
14 2
0
49
2
0 5
14 2
0
50
2
0 6
14 2
end_DTG
begin_DTG
0
5
0
36
2
4 2
12 1
0
37
2
4 3
12 1
0
38
2
4 4
12 1
0
39
2
4 5
12 1
0
40
2
4 6
12 1
end_DTG
begin_DTG
0
5
0
31
2
4 2
11 1
0
32
2
4 3
11 1
0
33
2
4 4
11 1
0
34
2
4 5
11 1
0
35
2
4 6
11 1
end_DTG
begin_CG
10
14 1
15 1
18 1
1 89
9 5
7 5
19 5
17 3
3 5
2 6
2
3 5
2 6
1
7 5
1
9 5
16
10 1
11 1
12 1
13 1
14 1
15 1
18 1
5 90
9 5
7 5
21 5
20 5
19 5
16 7
8 5
6 6
2
8 5
6 6
1
7 5
0
1
9 5
0
1
16 1
2
21 5
16 1
2
20 5
16 1
1
16 1
3
19 10
16 1
17 1
2
16 1
17 1
7
10 1
11 1
12 1
13 1
14 1
15 1
18 1
3
14 1
15 1
18 1
2
16 1
17 1
0
0
0
end_CG
