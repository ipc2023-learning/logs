begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var0
-1
4
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
end_variable
begin_variable
var6
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var18
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var17
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var8
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var16
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var7
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var15
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var12
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var11
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
0
begin_state
2
1
1
1
1
1
1
1
0
0
0
0
0
0
1
1
end_state
begin_goal
5
3 0
5 0
7 0
14 0
15 0
end_goal
39
begin_operator
calibrate rover1 camera1 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint2 waypoint1
2
0 1
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint3 waypoint1
2
0 2
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint4 waypoint1
2
0 3
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint2 waypoint1
2
0 1
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint3 waypoint1
2
0 2
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint4 waypoint1
2
0 3
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint2 waypoint1
2
0 1
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint3 waypoint1
2
0 2
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint4 waypoint1
2
0 3
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint2 waypoint1
2
0 1
9 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint3 waypoint1
2
0 2
9 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint4 waypoint1
2
0 3
9 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint2 waypoint1
2
0 1
10 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint3 waypoint1
2
0 2
10 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint4 waypoint1
2
0 3
10 1
1
0 14 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 13 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint4
0
1
0 0 1 3
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint4
0
1
0 0 2 3
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint2
0
1
0 0 3 1
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint3
0
1
0 0 3 2
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
0 0
2
0 8 0 1
0 13 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint2
1
0 1
2
0 9 0 1
0 13 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint4
1
0 3
2
0 10 0 1
0 13 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint2
1
0 1
2
0 11 0 1
0 13 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
0 2
2
0 12 0 1
0 13 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 colour
1
0 2
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 high_res
1
0 2
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 8
check 2
0
19
switch 13
check 0
check 1
25
check 0
check 0
check 0
switch 1
check 0
check 3
30
31
32
check 0
check 0
switch 8
check 1
20
check 0
check 0
switch 9
check 0
switch 13
check 0
check 1
26
check 0
check 0
check 1
12
switch 10
check 0
check 0
check 1
15
switch 11
check 0
switch 13
check 0
check 1
28
check 0
check 0
check 0
switch 6
check 0
check 1
3
check 0
switch 4
check 0
check 1
6
check 0
switch 2
check 0
check 1
9
check 0
check 0
switch 8
check 2
1
21
check 0
check 0
switch 9
check 0
check 0
check 1
13
switch 10
check 0
check 0
check 1
16
switch 12
check 0
switch 13
check 0
check 1
29
check 0
check 0
check 0
switch 1
check 0
check 3
33
34
35
check 0
switch 6
check 0
check 1
4
check 0
switch 4
check 0
check 1
7
check 0
switch 2
check 0
check 1
10
check 0
check 0
switch 8
check 4
2
22
23
24
check 0
check 0
switch 9
check 0
check 0
check 1
14
switch 10
check 0
switch 13
check 0
check 1
27
check 0
check 0
check 1
17
switch 1
check 0
check 3
36
37
38
check 0
switch 6
check 0
check 1
5
check 0
switch 4
check 0
check 1
8
check 0
switch 2
check 0
check 1
11
check 0
check 0
switch 13
check 0
check 0
check 1
18
check 0
end_SG
begin_DTG
1
3
19
0
1
3
20
0
1
3
21
0
3
0
22
0
1
23
0
2
24
0
end_DTG
begin_DTG
3
1
30
1
0 0
1
33
1
0 2
1
36
1
0 3
3
0
0
1
0 0
0
1
1
0 2
0
2
1
0 3
end_DTG
begin_DTG
0
3
0
32
2
0 0
1 0
0
35
2
0 2
1 0
0
38
2
0 3
1 0
end_DTG
begin_DTG
0
3
0
9
2
0 1
2 0
0
10
2
0 2
2 0
0
11
2
0 3
2 0
end_DTG
begin_DTG
0
3
0
31
2
0 0
1 0
0
34
2
0 2
1 0
0
37
2
0 3
1 0
end_DTG
begin_DTG
0
3
0
6
2
0 1
4 0
0
7
2
0 2
4 0
0
8
2
0 3
4 0
end_DTG
begin_DTG
0
3
0
30
2
0 0
1 0
0
33
2
0 2
1 0
0
36
2
0 3
1 0
end_DTG
begin_DTG
0
3
0
3
2
0 1
6 0
0
4
2
0 2
6 0
0
5
2
0 3
6 0
end_DTG
begin_DTG
1
1
25
2
0 0
13 0
0
end_DTG
begin_DTG
1
1
26
2
0 1
13 0
0
end_DTG
begin_DTG
1
1
27
2
0 3
13 0
0
end_DTG
begin_DTG
1
1
28
2
0 1
13 0
0
end_DTG
begin_DTG
1
1
29
2
0 2
13 0
0
end_DTG
begin_DTG
5
1
25
2
0 0
8 0
1
26
2
0 1
9 0
1
27
2
0 3
10 0
1
28
2
0 1
11 0
1
29
2
0 2
12 0
1
0
18
0
end_DTG
begin_DTG
0
3
0
15
2
0 1
10 1
0
16
2
0 2
10 1
0
17
2
0 3
10 1
end_DTG
begin_DTG
0
3
0
12
2
0 1
9 1
0
13
2
0 2
9 1
0
14
2
0 3
9 1
end_DTG
begin_CG
15
8 1
9 1
10 1
11 1
12 1
1 12
7 3
5 3
3 3
15 3
14 3
13 5
6 3
4 3
2 3
3
6 3
4 3
2 3
1
3 3
0
1
5 3
0
1
7 3
0
1
13 1
2
15 3
13 1
2
14 3
13 1
1
13 1
1
13 1
5
8 1
9 1
10 1
11 1
12 1
0
0
end_CG
