begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint8)
Atom have_soil_analysis(rover3, waypoint8)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
Atom have_rock_analysis(rover3, waypoint1)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var39
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var40
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var38
-1
2
Atom communicated_soil_data(waypoint8)
NegatedAtom communicated_soil_data(waypoint8)
end_variable
begin_variable
var35
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var34
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var33
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
0
7
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
4
10 0
11 0
12 0
13 0
end_goal
92
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint1 waypoint8
2
1 0
5 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint2 waypoint8
2
1 1
5 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint4 waypoint8
2
1 3
5 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint6 waypoint8
2
1 5
5 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint7 waypoint8
2
1 6
5 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint5 waypoint1 waypoint8
2
1 0
6 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint5 waypoint2 waypoint8
2
1 1
6 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint5 waypoint4 waypoint8
2
1 3
6 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint5 waypoint6 waypoint8
2
1 5
6 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint5 waypoint7 waypoint8
2
1 6
6 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint6 waypoint1 waypoint8
2
1 0
9 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint6 waypoint2 waypoint8
2
1 1
9 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint6 waypoint4 waypoint8
2
1 3
9 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint6 waypoint6 waypoint8
2
1 5
9 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint6 waypoint7 waypoint8
2
1 6
9 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint1 waypoint1 waypoint8
2
0 0
5 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint1 waypoint2 waypoint8
2
0 1
5 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint1 waypoint4 waypoint8
2
0 3
5 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint1 waypoint6 waypoint8
2
0 5
5 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint1 waypoint7 waypoint8
2
0 6
5 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint5 waypoint1 waypoint8
2
0 0
6 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint5 waypoint2 waypoint8
2
0 1
6 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint5 waypoint4 waypoint8
2
0 3
6 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint5 waypoint6 waypoint8
2
0 5
6 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint5 waypoint7 waypoint8
2
0 6
6 2
1
0 12 -1 0
0
end_operator
begin_operator




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




r3store waypoint5
1
0 4
2
0 6 0 2
0 8 0 1
0
end_operator
begin_operator
sample_rock rover3 rover3store waypoint6
1
0 5
2
0 9 0 2
0 8 0 1
0
end_operator
begin_operator
sample_soil rover3 rover3store waypoint3
1
0 2
2
0 2 0 1
0 8 0 1
0
end_operator
begin_operator
sample_soil rover3 rover3store waypoint7
1
0 6
2
0 3 0 1
0 8 0 1
0
end_operator
begin_operator
sample_soil rover3 rover3store waypoint8
1
0 7
2
0 4 0 1
0 8 0 1
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 1
37
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 7
check 0
check 1
83
check 0
check 0
check 1
0
check 0
switch 6
check 0
check 0
check 1
5
check 0
switch 9
check 0
check 0
check 1
10
check 0
check 0
switch 0
check 3
38
39
40
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 0
check 1
1
check 0
switch 6
check 0
check 0
check 1
6
check 0
switch 9
check 0
check 0
check 1
11
check 0
check 0
check 3
41
42
43
switch 0
check 3
44
45
46
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 0
check 1
2
check 0
switch 6
check 0
check 0
check 1
7
check 0
switch 9
check 0
check 0
check 1
12
check 0
check 0
switch 0
check 4
47
48
49
50
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 1
84
check 0
check 0
check 0
check 0
check 0
switch 0
check 2
51
52
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 0
check 1
3
check 0
switch 6
check 0
check 0
check 1
8
check 0
switch 9
check 0
switch 7
check 0
check 1
85
check 0
check 0
check 1
13
check 0
check 0
switch 0
check 3
53
54
55
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 0
check 1
4
check 0
switch 6
check 0
check 0
check 1
9
check 0
switch 9
check 0
check 0
check 1
14
check 0
check 0
check 3
56
57
58
switch 0
check 0
switch 5
check 3
59
60
61
switch 8
check 0
check 1
86
check 0
check 0
check 0
check 1
15
switch 6
check 0
check 0
check 0
check 1
20
switch 9
check 0
check 0
check 0
check 1
25
switch 4
check 0
check 0
check 1
30
check 0
switch 5
check 2
62
63
check 0
check 0
check 1
16
switch 6
check 0
check 0
check 0
check 1
21
switch 9
check 0
check 0
check 0
check 1
26
switch 4
check 0
check 0
check 1
31
check 0
switch 5
check 2
64
65
check 0
check 0
check 0
switch 2
check 0
switch 8
check 0
check 1
89
check 0
check 0
check 0
check 0
switch 5
check 4
66
67
68
69
check 0
check 0
check 1
17
switch 6
check 0
check 0
check 0
check 1
22
switch 9
check 0
check 0
check 0
check 1
27
switch 4
check 0
check 0
check 1
32
check 0
switch 5
check 4
70
71
72
73
check 0
check 0
check 0
switch 6
check 0
switch 8
check 0
check 1
87
check 0
check 0
check 0
check 0
check 0
switch 5
check 4
74
75
76
77
check 0
check 0
check 1
18
switch 6
check 0
check 0
check 0
check 1
23
switch 9
check 0
switch 8
check 0
check 1
88
check 0
check 0
check 0
check 1
28
switch 4
check 0
check 0
check 1
33
check 0
switch 5
check 2
78
79
check 0
check 0
check 1
19
switch 6
check 0
check 0
check 0
check 1
24
switch 9
check 0
check 0
check 0
check 1
29
switch 3
check 0
switch 8
check 0
check 1
90
check 0
check 0
check 0
switch 4
check 0
check 0
check 1
34
check 0
switch 5
check 3
80
81
82
check 0
check 0
check 0
switch 4
check 0
switch 8
check 0
check 1
91
check 0
check 0
check 0
check 0
switch 7
check 0
check 0
check 1
35
switch 8
check 0
check 0
check 1
36
check 0
end_SG
begin_DTG
3
1
59
0
4
60
0
7
61
0
2
0
62
0
3
63
0
2
4
64
0
6
65
0
4
1
66
0
4
67
0
5
68
0
7
69
0
4
0
70
0
2
71
0
3
72
0
5
73
0
4
3
74
0
4
75
0
6
76
0
7
77
0
2
2
78
0
5
79
0
3
0
80
0
3
81
0
5
82
0
end_DTG
begin_DTG
1
4
37
0
3
3
38
0
6
39
0
7
40
0
3
3
41
0
4
42
0
6
43
0
3
1
44
0
2
45
0
4
46
0
4
0
47
0
2
48
0
3
49
0
5
50
0
2
4
51
0
7
52
0
3
1
53
0
2
54
0
7
55
0
3
1
56
0
5
57
0
6
58
0
end_DTG
begin_DTG
1
1
89
2
0 2
8 0
0
end_DTG
begin_DTG
1
1
90
2
0 6
8 0
0
end_DTG
begin_DTG
1
1
91
2
0 7
8 0
0
end_DTG
begin_DTG
2
1
83
2
1 0
7 0
2
86
2
0 0
8 0
0
0
end_DTG
begin_DTG
2
1
84
2
1 4
7 0
2
87
2
0 4
8 0
0
0
end_DTG
begin_DTG
3
1
83
2
1 0
5 0
1
84
2
1 4
6 0
1
85
2
1 5
9 0
1
0
35
0
end_DTG
begin_DTG
6
1
86
2
0 0
5 0
1
87
2
0 4
6 0
1
88
2
0 5
9 0
1
89
2
0 2
2 0
1
90
2
0 6
3 0
1
91
2
0 7
4 0
1
0
36
0
end_DTG
begin_DTG
2
1
85
2
1 5
7 0
2
88
2
0 5
8 0
0
0
end_DTG
begin_DTG
0
5
0
30
2
0 0
4 1
0
31
2
0 1
4 1
0
32
2
0 3
4 1
0
33
2
0 5
4 1
0
34
2
0 6
4 1
end_DTG
begin_DTG
0
10
0
10
2
1 0
9 1
0
11
2
1 1
9 1
0
12
2
1 3
9 1
0
13
2
1 5
9 1
0
14
2
1 6
9 1
0
25
2
0 0
9 2
0
26
2
0 1
9 2
0
27
2
0 3
9 2
0
28
2
0 5
9 2
0
29
2
0 6
9 2
end_DTG
begin_DTG
0
10
0
5
2
1 0
6 1
0
6
2
1 1
6 1
0
7
2
1 3
6 1
0
8
2
1 5
6 1
0
9
2
1 6
6 1
0
20
2
0 0
6 2
0
21
2
0 1
6 2
0
22
2
0 3
6 2
0
23
2
0 5
6 2
0
24
2
0 6
6 2
end_DTG
begin_DTG
0
10
0
0
2
1 0
5 1
0
1
2
1 1
5 1
0
2
2
1 3
5 1
0
3
2
1 5
5 1
0
4
2
1 6
5 1
0
15
2
0 0
5 2
0
16
2
0 1
5 2
0
17
2
0 3
5 2
0
18
2
0 5
5 2
0
19
2
0 6
5 2
end_DTG
begin_CG
11
5 1
6 1
9 1
2 1
3 1
4 1
13 5
12 5
11 5
10 5
8 6
7
5 1
6 1
9 1
13 5
12 5
11 5
7 3
1
8 1
1
8 1
2
10 5
8 1
3
13 10
7 1
8 1
3
12 10
7 1
8 1
3
5 1
6 1
9 1
6
5 1
6 1
9 1
2 1
3 1
4 1
3
11 10
7 1
8 1
0
0
0
0
end_CG
