begin_version
3
end_version
begin_metric
0
end_metric
93
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera2, rover4)
NegatedAtom calibrated(camera2, rover4)
end_variable
begin_variable
var120
-1
2
Atom have_image(rover4, objective9, colour)
NegatedAtom have_image(rover4, objective9, colour)
end_variable
begin_variable
var119
-1
2
Atom have_image(rover4, objective8, low_res)
NegatedAtom have_image(rover4, objective8, low_res)
end_variable
begin_variable
var118
-1
2
Atom have_image(rover4, objective8, high_res)
NegatedAtom have_image(rover4, objective8, high_res)
end_variable
begin_variable
var117
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var116
-1
2
Atom have_image(rover4, objective7, low_res)
NegatedAtom have_image(rover4, objective7, low_res)
end_variable
begin_variable
var115
-1
2
Atom have_image(rover4, objective7, high_res)
NegatedAtom have_image(rover4, objective7, high_res)
end_variable
begin_variable
var113
-1
2
Atom have_image(rover4, objective6, low_res)
NegatedAtom have_image(rover4, objective6, low_res)
end_variable
begin_variable
var111
-1
2
Atom have_image(rover4, objective6, colour)
NegatedAtom have_image(rover4, objective6, colour)
end_variable
begin_variable
var110
-1
2
Atom have_image(rover4, objective5, low_res)
NegatedAtom have_image(rover4, objective5, low_res)
end_variable
begin_variable
var108
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var107
-1
2
Atom have_image(rover4, objective4, low_res)
NegatedAtom have_image(rover4, objective4, low_res)
end_variable
begin_variable
var105
-1
2
Atom have_image(rover4, objective4, colour)
NegatedAtom have_image(rover4, objective4, colour)
end_variable
begin_variable
var104
-1
2
Atom have_image(rover4, objective3, low_res)
NegatedAtom have_image(rover4, objective3, low_res)
end_variable
begin_variable
var103
-1
2
Atom have_image(rover4, objective3, high_res)
NegatedAtom have_image(rover4, objective3, high_res)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover4, objective3, colour)
NegatedAtom have_image(rover4, objective3, colour)
end_variable
begin_variable
var101
-1
2
Atom have_image(rover4, objective2, low_res)
NegatedAtom have_image(rover4, objective2, low_res)
end_variable
begin_variable
var100
-1
2
Atom have_image(rover4, objective2, high_res)
NegatedAtom have_image(rover4, objective2, high_res)
end_variable
begin_variable
var98
-1
2
Atom have_image(rover4, objective10, low_res)
NegatedAtom have_image(rover4, objective10, low_res)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover4, objective10, high_res)
NegatedAtom have_image(rover4, objective10, high_res)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover4, objective10, colour)
NegatedAtom have_image(rover4, objective10, colour)
end_variable
begin_variable
var95
-1
2
Atom have_image(rover4, objective1, low_res)
NegatedAtom have_image(rover4, objective1, low_res)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var18
-1
2
Atom calibrated(camera4, rover3)
NegatedAtom calibrated(camera4, rover3)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var90
-1
2
Atom have_image(rover3, objective9, colour)
NegatedAtom have_image(rover3, objective9, colour)
end_variable
begin_variable
var46
-1
2
Atom communicated_image_data(objective9, colour)
NegatedAtom communicated_image_data(objective9, colour)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover3, objective8, low_res)
NegatedAtom have_image(rover3, objective8, low_res)
end_variable
begin_variable
var45
-1
2
Atom communicated_image_data(objective8, low_res)
NegatedAtom communicated_image_data(objective8, low_res)
end_variable
begin_variable
var88
-1
2
Atom have_image(rover3, objective8, high_res)
NegatedAtom have_image(rover3, objective8, high_res)
end_variable
begin_variable
var44
-1
2
Atom communicated_image_data(objective8, high_res)
NegatedAtom communicated_image_data(objective8, high_res)
end_variable
begin_variable
var87
-1
2
Atom have_image(rover3, objective8, colour)
NegatedAtom have_image(rover3, objective8, colour)
end_variable
be




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
41
2
24 8
62 0
0
147
2
0 0
19 0
0
148
2
0 3
19 0
0
149
2
0 5
19 0
0
150
2
0 6
19 0
0
151
2
0 8
19 0
end_DTG
begin_DTG
0
4
0
497
2
24 6
27 0
0
507
2
24 7
27 0
0
542
2
24 8
27 0
0
567
2
24 9
27 0
end_DTG
begin_DTG
0
10
0
32
2
24 0
64 0
0
33
2
24 3
64 0
0
34
2
24 5
64 0
0
35
2
24 6
64 0
0
36
2
24 8
64 0
0
142
2
0 0
20 0
0
143
2
0 3
20 0
0
144
2
0 5
20 0
0
145
2
0 6
20 0
0
146
2
0 8
20 0
end_DTG
begin_DTG
0
8
0
496
2
24 6
27 0
0
500
2
24 6
25 0
0
506
2
24 7
27 0
0
510
2
24 7
25 0
0
541
2
24 8
27 0
0
545
2
24 8
25 0
0
566
2
24 9
27 0
0
570
2
24 9
25 0
end_DTG
begin_DTG
0
10
0
27
2
24 0
66 0
0
28
2
24 3
66 0
0
29
2
24 5
66 0
0
30
2
24 6
66 0
0
31
2
24 8
66 0
0
137
2
0 0
21 0
0
138
2
0 3
21 0
0
139
2
0 5
21 0
0
140
2
0 6
21 0
0
141
2
0 8
21 0
end_DTG
begin_DTG
0
2
0
453
2
24 4
27 0
0
454
2
24 4
26 0
end_DTG
begin_DTG
0
10
0
22
2
24 0
68 0
0
23
2
24 3
68 0
0
24
2
24 5
68 0
0
25
2
24 6
68 0
0
26
2
24 8
68 0
0
132
2
0 0
22 0
0
133
2
0 3
22 0
0
134
2
0 5
22 0
0
135
2
0 6
22 0
0
136
2
0 8
22 0
end_DTG
begin_DTG
0
1
0
452
2
24 4
27 0
end_DTG
begin_DTG
0
10
0
17
2
24 0
70 0
0
18
2
24 3
70 0
0
19
2
24 5
70 0
0
20
2
24 6
70 0
0
21
2
24 8
70 0
0
127
2
0 0
23 0
0
128
2
0 3
23 0
0
129
2
0 5
23 0
0
130
2
0 6
23 0
0
131
2
0 8
23 0
end_DTG
begin_DTG
1
1
377
2
24 0
76 0
0
end_DTG
begin_DTG
1
1
378
2
24 1
76 0
0
end_DTG
begin_DTG
1
1
379
2
24 3
76 0
0
end_DTG
begin_DTG
1
1
380
2
24 7
76 0
0
end_DTG
begin_DTG
4
1
377
2
24 0
72 0
1
378
2
24 1
73 0
1
379
2
24 3
74 0
1
380
2
24 7
75 0
1
0
293
0
end_DTG
begin_DTG
0
5
0
287
2
24 0
75 1
0
288
2
24 3
75 1
0
289
2
24 5
75 1
0
290
2
24 6
75 1
0
291
2
24 8
75 1
end_DTG
begin_DTG
5
2
295
0
3
296
0
6
297
0
7
298
0
8
299
0
1
6
300
0
2
0
301
0
3
302
0
3
0
303
0
2
304
0
7
305
0
1
6
306
0
2
8
307
0
9
308
0
3
0
309
0
1
310
0
4
311
0
3
0
312
0
3
313
0
9
314
0
2
0
315
0
5
316
0
2
5
317
0
7
318
0
end_DTG
begin_DTG
2
1
363
2
78 0
85 0
2
370
2
0 0
86 0
0
0
end_DTG
begin_DTG
2
1
364
2
78 1
85 0
2
371
2
0 1
86 0
0
0
end_DTG
begin_DTG
2
1
365
2
78 3
85 0
2
372
2
0 3
86 0
0
0
end_DTG
begin_DTG
2
1
366
2
78 5
85 0
2
373
2
0 5
86 0
0
0
end_DTG
begin_DTG
2
1
367
2
78 7
85 0
2
374
2
0 7
86 0
0
0
end_DTG
begin_DTG
2
1
368
2
78 8
85 0
2
375
2
0 8
86 0
0
0
end_DTG
begin_DTG
7
1
363
2
78 0
79 0
1
364
2
78 1
80 0
1
365
2
78 3
81 0
1
366
2
78 5
82 0
1
367
2
78 7
83 0
1
368
2
78 8
84 0
1
369
2
78 9
87 0
1
0
292
0
end_DTG
begin_DTG
7
1
370
2
0 0
79 0
1
371
2
0 1
80 0
1
372
2
0 3
81 0
1
373
2
0 5
82 0
1
374
2
0 7
83 0
1
375
2
0 8
84 0
1
376
2
0 9
87 0
1
0
294
0
end_DTG
begin_DTG
2
1
369
2
78 9
85 0
2
376
2
0 9
86 0
0
0
end_DTG
begin_DTG
0
10
0
257
2
78 0
87 1
0
258
2
78 3
87 1
0
259
2
78 5
87 1
0
260
2
78 6
87 1
0
261
2
78 8
87 1
0
282
2
0 0
87 2
0
283
2
0 3
87 2
0
284
2
0 5
87 2
0
285
2
0 6
87 2
0
286
2
0 8
87 2
end_DTG
begin_DTG
0
10
0
252
2
78 0
84 1
0
253
2
78 3
84 1
0
254
2
78 5
84 1
0
255
2
78 6
84 1
0
256
2
78 8
84 1
0
277
2
0 0
84 2
0
278
2
0 3
84 2
0
279
2
0 5
84 2
0
280
2
0 6
84 2
0
281
2
0 8
84 2
end_DTG
begin_DTG
0
10
0
247
2
78 0
82 1
0
248
2
78 3
82 1
0
249
2
78 5
82 1
0
250
2
78 6
82 1
0
251
2
78 8
82 1
0
272
2
0 0
82 2
0
273
2
0 3
82 2
0
274
2
0 5
82 2
0
275
2
0 6
82 2
0
276
2
0 8
82 2
end_DTG
begin_DTG
0
10
0
242
2
78 0
80 1
0
243
2
78 3
80 1
0
244
2
78 5
80 1
0
245
2
78 6
80 1
0
246
2
78 8
80 1
0
267
2
0 0
80 2
0
268
2
0 3
80 2
0
269
2
0 5
80 2
0
270
2
0 6
80 2
0
271
2
0 8
80 2
end_DTG
begin_DTG
0
10
0
237
2
78 0
79 1
0
238
2
78 3
79 1
0
239
2
78 5
79 1
0
240
2
78 6
79 1
0
241
2
78 8
79 1
0
262
2
0 0
79 2
0
263
2
0 3
79 2
0
264
2
0 5
79 2
0
265
2
0 6
79 2
0
266
2
0 8
79 2
end_DTG
begin_CG
58
79 1
80 1
81 1
82 1
83 1
84 1
87 1
1 130
71 5
69 5
67 5
65 5
63 5
61 5
59 5
57 5
55 5
53 5
51 5
49 5
47 5
45 5
43 5
41 5
39 5
37 5
35 5
33 5
31 5
29 5
92 5
91 5
90 5
89 5
88 5
86 7
23 1
22 1
21 4
20 4
19 4
18 4
17 4
16 6
15 6
14 6
13 10
12 10
11 5
10 5
9 5
8 5
7 2
6 2
5 2
4 2
3 2
2 1
22
23 1
22 1
21 4
20 4
19 4
18 4
17 4
16 6
15 6
14 6
13 10
12 10
11 5
10 5
9 5
8 5
7 2
6 2
5 2
4 2
3 2
2 1
1
29 5
1
31 5
1
33 5
1
35 5
1
37 5
1
39 5
1
41 5
1
43 5
1
45 5
1
47 5
1
49 5
1
51 5
1
53 5
1
55 5
1
57 5
1
59 5
1
61 5
1
63 5
1
65 5
1
67 5
1
69 5
1
71 5
53
72 1
73 1
74 1
75 1
27 121
26 44
25 42
71 5
69 5
67 5
65 5
63 5
61 5
59 5
57 5
55 5
53 5
51 5
49 5
47 5
45 5
43 5
41 5
39 5
37 5
35 5
33 5
31 5
29 5
77 5
76 4
70 1
68 2
66 8
64 4
62 8
60 4
58 8
56 12
54 6
52 12
50 20
48 20
46 10
44 10
42 10
40 10
38 2
36 4
34 4
32 2
30 4
28 2
7
66 4
56 6
50 10
46 5
42 5
34 2
28 1
9
68 1
62 4
58 4
52 6
48 10
44 5
40 5
36 2
30 2
22
70 1
68 1
66 4
64 4
62 4
60 4
58 4
56 6
54 6
52 6
50 10
48 10
46 5
44 5
42 5
40 5
38 2
36 2
34 2
32 2
30 2
28 1
1
29 5
0
1
31 5
0
1
33 5
0
1
35 5
0
1
37 5
0
1
39 5
0
1
41 5
0
1
43 5
0
1
45 5
0
1
47 5
0
1
49 5
0
1
51 5
0
1
53 5
0
1
55 5
0
1
57 5
0
1
59 5
0
1
61 5
0
1
63 5
0
1
65 5
0
1
67 5
0
1
69 5
0
1
71 5
0
1
76 1
1
76 1
1
76 1
2
77 5
76 1
4
72 1
73 1
74 1
75 1
0
13
79 1
80 1
81 1
82 1
83 1
84 1
87 1
92 5
91 5
90 5
89 5
88 5
85 7
3
92 10
85 1
86 1
3
91 10
85 1
86 1
2
85 1
86 1
3
90 10
85 1
86 1
2
85 1
86 1
3
89 10
85 1
86 1
7
79 1
80 1
81 1
82 1
83 1
84 1
87 1
7
79 1
80 1
81 1
82 1
83 1
84 1
87 1
3
88 10
85 1
86 1
0
0
0
0
0
end_CG
