begin_version
3
end_version
begin_metric
0
end_metric
77
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var80
-1
2
Atom have_image(rover3, objective7, low_res)
NegatedAtom have_image(rover3, objective7, low_res)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover3, objective5, low_res)
NegatedAtom have_image(rover3, objective5, low_res)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover3, objective5, high_res)
NegatedAtom have_image(rover3, objective5, high_res)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var73
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover3, objective3, low_res)
NegatedAtom have_image(rover3, objective3, low_res)
end_variable
begin_variable
var71
-1
2
Atom have_image(rover3, objective3, high_res)
NegatedAtom have_image(rover3, objective3, high_res)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover3, objective2, low_res)
NegatedAtom have_image(rover3, objective2, low_res)
end_variable
begin_variable
var69
-1
2
Atom have_image(rover3, objective2, high_res)
NegatedAtom have_image(rover3, objective2, high_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var67
-1
2
Atom have_image(rover3, objective1, high_res)
NegatedAtom have_image(rover3, objective1, high_res)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective7, low_res)
NegatedAtom have_image(rover1, objective7, low_res)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var57
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var51
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var64
-1
2
Atom have_image(rover1, objective7, colour)
NegatedAtom have_image(rover1, objective7, colour)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective7, colour)
Ne




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




51
2
0 2
14 0
0
152
2
0 4
14 0
0
153
2
0 5
14 0
0
154
2
0 6
14 0
0
155
2
0 7
14 0
end_DTG
begin_DTG
0
8
0
480
2
16 1
32 0
0
482
2
16 1
17 0
0
500
2
16 2
32 0
0
502
2
16 2
17 0
0
510
2
16 4
32 0
0
512
2
16 4
17 0
0
550
2
16 7
32 0
0
552
2
16 7
17 0
end_DTG
begin_DTG
0
7
0
9
2
16 0
57 0
0
10
2
16 1
57 0
0
11
2
16 2
57 0
0
12
2
16 4
57 0
0
13
2
16 5
57 0
0
14
2
16 6
57 0
0
15
2
16 7
57 0
end_DTG
begin_DTG
2
1
455
2
16 1
65 0
2
459
2
0 1
69 0
0
0
end_DTG
begin_DTG
2
1
456
2
16 3
65 0
2
460
2
0 3
69 0
0
0
end_DTG
begin_DTG
2
1
457
2
16 4
65 0
2
461
2
0 4
69 0
0
0
end_DTG
begin_DTG
2
1
458
2
16 5
65 0
2
462
2
0 5
69 0
0
0
end_DTG
begin_DTG
3
1
463
2
16 0
65 0
2
467
2
15 0
66 0
3
471
2
0 0
69 0
0
0
0
end_DTG
begin_DTG
3
1
464
2
16 3
65 0
2
468
2
15 3
66 0
3
472
2
0 3
69 0
0
0
0
end_DTG
begin_DTG
8
1
455
2
16 1
59 0
1
456
2
16 3
60 0
1
457
2
16 4
61 0
1
458
2
16 5
62 0
1
463
2
16 0
63 0
1
464
2
16 3
64 0
1
465
2
16 6
67 0
1
466
2
16 7
68 0
1
0
366
0
end_DTG
begin_DTG
4
1
467
2
15 0
63 0
1
468
2
15 3
64 0
1
469
2
15 6
67 0
1
470
2
15 7
68 0
1
0
367
0
end_DTG
begin_DTG
3
1
465
2
16 6
65 0
2
469
2
15 6
66 0
3
473
2
0 6
69 0
0
0
0
end_DTG
begin_DTG
3
1
466
2
16 7
65 0
2
470
2
15 7
66 0
3
474
2
0 7
69 0
0
0
0
end_DTG
begin_DTG
8
1
459
2
0 1
59 0
1
460
2
0 3
60 0
1
461
2
0 4
61 0
1
462
2
0 5
62 0
1
471
2
0 0
63 0
1
472
2
0 3
64 0
1
473
2
0 6
67 0
1
474
2
0 7
68 0
1
0
368
0
end_DTG
begin_DTG
0
21
0
334
2
15 4
68 2
0
365
2
0 7
68 3
0
364
2
0 6
68 3
0
363
2
0 5
68 3
0
362
2
0 4
68 3
0
361
2
0 2
68 3
0
360
2
0 1
68 3
0
359
2
0 0
68 3
0
337
2
15 7
68 2
0
336
2
15 6
68 2
0
335
2
15 5
68 2
0
303
2
16 0
68 1
0
333
2
15 2
68 2
0
332
2
15 1
68 2
0
331
2
15 0
68 2
0
309
2
16 7
68 1
0
308
2
16 6
68 1
0
307
2
16 5
68 1
0
306
2
16 4
68 1
0
305
2
16 2
68 1
0
304
2
16 1
68 1
end_DTG
begin_DTG
0
21
0
327
2
15 4
67 2
0
358
2
0 7
67 3
0
357
2
0 6
67 3
0
356
2
0 5
67 3
0
355
2
0 4
67 3
0
354
2
0 2
67 3
0
353
2
0 1
67 3
0
352
2
0 0
67 3
0
330
2
15 7
67 2
0
329
2
15 6
67 2
0
328
2
15 5
67 2
0
296
2
16 0
67 1
0
326
2
15 2
67 2
0
325
2
15 1
67 2
0
324
2
15 0
67 2
0
302
2
16 7
67 1
0
301
2
16 6
67 1
0
300
2
16 5
67 1
0
299
2
16 4
67 1
0
298
2
16 2
67 1
0
297
2
16 1
67 1
end_DTG
begin_DTG
0
21
0
320
2
15 4
64 2
0
351
2
0 7
64 3
0
350
2
0 6
64 3
0
349
2
0 5
64 3
0
348
2
0 4
64 3
0
347
2
0 2
64 3
0
346
2
0 1
64 3
0
345
2
0 0
64 3
0
323
2
15 7
64 2
0
322
2
15 6
64 2
0
321
2
15 5
64 2
0
289
2
16 0
64 1
0
319
2
15 2
64 2
0
318
2
15 1
64 2
0
317
2
15 0
64 2
0
295
2
16 7
64 1
0
294
2
16 6
64 1
0
293
2
16 5
64 1
0
292
2
16 4
64 1
0
291
2
16 2
64 1
0
290
2
16 1
64 1
end_DTG
begin_DTG
0
21
0
313
2
15 4
63 2
0
344
2
0 7
63 3
0
343
2
0 6
63 3
0
342
2
0 5
63 3
0
341
2
0 4
63 3
0
340
2
0 2
63 3
0
339
2
0 1
63 3
0
338
2
0 0
63 3
0
316
2
15 7
63 2
0
315
2
15 6
63 2
0
314
2
15 5
63 2
0
282
2
16 0
63 1
0
312
2
15 2
63 2
0
311
2
15 1
63 2
0
310
2
15 0
63 2
0
288
2
16 7
63 1
0
287
2
16 6
63 1
0
286
2
16 5
63 1
0
285
2
16 4
63 1
0
284
2
16 2
63 1
0
283
2
16 1
63 1
end_DTG
begin_DTG
0
14
0
254
2
16 0
62 1
0
255
2
16 1
62 1
0
256
2
16 2
62 1
0
257
2
16 4
62 1
0
258
2
16 5
62 1
0
259
2
16 6
62 1
0
260
2
16 7
62 1
0
275
2
0 0
62 2
0
276
2
0 1
62 2
0
277
2
0 2
62 2
0
278
2
0 4
62 2
0
279
2
0 5
62 2
0
280
2
0 6
62 2
0
281
2
0 7
62 2
end_DTG
begin_DTG
0
14
0
247
2
16 0
61 1
0
248
2
16 1
61 1
0
249
2
16 2
61 1
0
250
2
16 4
61 1
0
251
2
16 5
61 1
0
252
2
16 6
61 1
0
253
2
16 7
61 1
0
268
2
0 0
61 2
0
269
2
0 1
61 2
0
270
2
0 2
61 2
0
271
2
0 4
61 2
0
272
2
0 5
61 2
0
273
2
0 6
61 2
0
274
2
0 7
61 2
end_DTG
begin_DTG
0
14
0
240
2
16 0
60 1
0
241
2
16 1
60 1
0
242
2
16 2
60 1
0
243
2
16 4
60 1
0
244
2
16 5
60 1
0
245
2
16 6
60 1
0
246
2
16 7
60 1
0
261
2
0 0
60 2
0
262
2
0 1
60 2
0
263
2
0 2
60 2
0
264
2
0 4
60 2
0
265
2
0 5
60 2
0
266
2
0 6
60 2
0
267
2
0 7
60 2
end_DTG
begin_CG
43
59 1
60 1
61 1
62 1
63 1
64 1
67 1
68 1
1 40
56 7
31 7
52 7
29 7
48 7
27 7
44 7
25 7
40 7
23 7
36 7
21 7
19 7
76 7
75 7
74 7
73 7
72 7
71 7
70 7
69 8
14 4
13 4
12 1
11 1
10 3
9 3
8 5
7 5
6 1
5 1
4 1
3 1
2 3
13
14 4
13 4
12 1
11 1
10 3
9 3
8 5
7 5
6 1
5 1
4 1
3 1
2 3
1
19 7
1
21 7
1
36 7
1
23 7
1
40 7
1
25 7
1
44 7
1
27 7
1
48 7
1
29 7
1
52 7
1
31 7
1
56 7
9
63 1
64 1
67 1
68 1
73 7
72 7
71 7
70 7
66 4
58
59 1
60 1
61 1
62 1
63 1
64 1
67 1
68 1
32 37
17 58
58 7
56 7
31 7
54 7
52 7
29 7
50 7
48 7
27 7
46 7
44 7
25 7
42 7
40 7
23 7
38 7
36 7
21 7
34 7
19 7
76 7
75 7
74 7
73 7
72 7
71 7
70 7
65 8
57 8
55 8
30 4
53 2
51 2
28 1
49 6
47 6
26 3
45 10
43 10
24 5
41 2
39 2
22 1
37 2
35 2
20 1
33 6
18 3
20
57 4
55 4
30 4
53 1
51 1
28 1
49 3
47 3
26 3
45 5
43 5
24 5
41 1
39 1
22 1
37 1
35 1
20 1
33 3
18 3
1
19 7
0
1
21 7
0
1
23 7
0
1
25 7
0
1
27 7
0
1
29 7
0
1
31 7
0
13
57 4
55 4
53 1
51 1
49 3
47 3
45 5
43 5
41 1
39 1
37 1
35 1
33 3
1
34 7
0
1
36 7
0
1
38 7
0
1
40 7
0
1
42 7
0
1
44 7
0
1
46 7
0
1
48 7
0
1
50 7
0
1
52 7
0
1
54 7
0
1
56 7
0
1
58 7
0
2
65 1
69 1
3
76 14
65 1
69 1
3
75 14
65 1
69 1
3
74 14
65 1
69 1
4
73 21
65 1
66 1
69 1
4
72 21
65 1
66 1
69 1
8
59 1
60 1
61 1
62 1
63 1
64 1
67 1
68 1
4
63 1
64 1
67 1
68 1
4
71 21
65 1
66 1
69 1
4
70 21
65 1
66 1
69 1
8
59 1
60 1
61 1
62 1
63 1
64 1
67 1
68 1
0
0
0
0
0
0
0
end_CG
