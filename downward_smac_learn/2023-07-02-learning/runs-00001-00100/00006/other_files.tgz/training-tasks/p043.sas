begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var31
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var7
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover2, objective3, high_res)
NegatedAtom have_image(rover2, objective3, high_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var32
-1
2
Atom have_image(rover2, objective2, high_res)
NegatedAtom have_image(rover2, objective2, high_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var5
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var26
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var27
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var22
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var21
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
0
begin_state
2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
1
1
end_state
begin_goal
8
3 0
6 0
8 0
10 0
12 0
14 0
23 0
24 0
end_goal
151
begin_operator
calibrate rover2 camera1 objective1 waypoint1
1
0 0
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint3
1
0 2
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint5
1
0 4
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint6
1
0 5
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint6
1
0 5
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective2 colour waypoint1 waypoint2
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective2 colour waypoint3 waypoint2
2
0 2
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective2 colour waypoint4 waypoint2
2
0 3
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective2 colour waypoint5 waypoint2
2
0 4
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective2 colour waypoint6 waypoint2
2
0 5
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective2 high_res waypoint1 waypoint2
2
0 0
13 0
1
0 14 -1 0
0
end_operator
begin_operator
communicate_i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




h 11
check 0
check 1
18
check 0
switch 9
check 0
check 1
23
check 0
switch 7
check 0
check 1
28
check 0
switch 5
check 0
check 1
33
check 0
check 0
switch 16
check 1
70
check 0
check 0
switch 4
check 0
check 4
95
96
99
100
check 0
switch 1
check 0
check 4
97
98
101
102
check 0
check 0
switch 16
check 3
1
5
71
switch 21
check 0
check 1
80
check 0
check 0
check 1
39
switch 17
check 0
check 0
check 1
44
switch 4
check 0
check 8
103
104
107
108
111
112
115
116
check 0
switch 1
check 0
check 8
105
106
109
110
113
114
117
118
check 0
switch 2
check 0
check 1
9
check 0
switch 13
check 0
check 1
14
check 0
switch 11
check 0
check 1
19
check 0
switch 9
check 0
check 1
24
check 0
switch 7
check 0
check 1
29
check 0
switch 5
check 0
check 1
34
check 0
check 0
switch 16
check 2
72
73
check 0
check 1
40
switch 17
check 0
switch 21
check 0
check 1
81
check 0
check 0
check 1
45
switch 19
check 0
switch 21
check 0
check 1
85
check 0
check 0
check 0
check 0
switch 4
check 0
check 6
119
120
123
124
127
128
check 0
switch 1
check 0
check 6
121
122
125
126
129
130
check 0
switch 2
check 0
check 1
10
check 0
switch 13
check 0
check 1
15
check 0
switch 11
check 0
check 1
20
check 0
switch 9
check 0
check 1
25
check 0
switch 7
check 0
check 1
30
check 0
switch 5
check 0
check 1
35
check 0
check 0
switch 16
check 4
2
6
74
75
check 0
check 1
41
switch 17
check 0
check 0
check 1
46
switch 18
check 0
switch 21
check 0
check 1
82
check 0
check 0
check 0
switch 22
check 0
switch 21
check 0
check 1
86
check 0
check 0
check 0
check 0
switch 4
check 0
check 6
131
132
135
136
139
140
check 0
switch 1
check 0
check 6
133
134
137
138
141
142
check 0
switch 2
check 0
check 1
11
check 0
switch 13
check 0
check 1
16
check 0
switch 11
check 0
check 1
21
check 0
switch 9
check 0
check 1
26
check 0
switch 7
check 0
check 1
31
check 0
switch 5
check 0
check 1
36
check 0
check 0
switch 16
check 6
3
7
76
77
78
79
check 0
check 1
42
switch 17
check 0
check 0
check 1
47
switch 4
check 0
check 4
143
144
147
148
check 0
switch 1
check 0
check 4
145
146
149
150
check 0
switch 2
check 0
check 1
12
check 0
switch 13
check 0
check 1
17
check 0
switch 11
check 0
check 1
22
check 0
switch 9
check 0
check 1
27
check 0
switch 7
check 0
check 1
32
check 0
switch 5
check 0
check 1
37
check 0
check 0
switch 20
check 0
check 0
check 1
48
switch 21
check 0
check 0
check 1
49
check 0
end_SG
begin_DTG
4
2
66
0
3
67
0
4
68
0
5
69
0
1
5
70
0
1
0
71
0
2
0
72
0
5
73
0
2
0
74
0
5
75
0
4
0
76
0
1
77
0
3
78
0
4
79
0
end_DTG
begin_DTG
6
1
121
1
0 3
1
150
1
0 5
1
142
1
0 4
1
89
1
0 0
1
118
1
0 2
1
102
1
0 1
4
0
4
1
0 0
0
5
1
0 2
0
6
1
0 4
0
7
1
0 5
end_DTG
begin_DTG
0
4
0
97
2
0 1
1 0
0
109
2
0 2
1 0
0
121
2
0 3
1 0
0
137
2
0 4
1 0
end_DTG
begin_DTG
0
5
0
8
2
0 0
2 0
0
9
2
0 2
2 0
0
10
2
0 3
2 0
0
11
2
0 4
2 0
0
12
2
0 5
2 0
end_DTG
begin_DTG
6
1
119
1
0 3
1
148
1
0 5
1
140
1
0 4
1
87
1
0 0
1
116
1
0 2
1
100
1
0 1
4
0
0
1
0 0
0
1
1
0 2
0
2
1
0 4
0
3
1
0 5
end_DTG
begin_DTG
0
3
0
116
2
0 2
4 0
0
128
2
0 3
4 0
0
140
2
0 4
4 0
end_DTG
begin_DTG
0
5
0
33
2
0 0
5 0
0
34
2
0 2
5 0
0
35
2
0 3
5 0
0
36
2
0 4
5 0
0
37
2
0 5
5 0
end_DTG
begin_DTG
0
6
0
115
2
0 2
4 0
0
118
2
0 2
1 0
0
127
2
0 3
4 0
0
130
2
0 3
1 0
0
139
2
0 4
4 0
0
142
2
0 4
1 0
end_DTG
begin_DTG
0
5
0
28
2
0 0
7 0
0
29
2
0 2
7 0
0
30
2
0 3
7 0
0
31
2
0 4
7 0
0
32
2
0 5
7 0
end_DTG
begin_DTG
0
10
0
91
2
0 0
4 0
0
94
2
0 0
1 0
0
99
2
0 1
4 0
0
102
2
0 1
1 0
0
111
2
0 2
4 0
0
114
2
0 2
1 0
0
123
2
0 3
4 0
0
126
2
0 3
1 0
0
147
2
0 5
4 0
0
150
2
0 5
1 0
end_DTG
begin_DTG
0
5
0
23
2
0 0
9 0
0
24
2
0 2
9 0
0
25
2
0 3
9 0
0
26
2
0 4
9 0
0
27
2
0 5
9 0
end_DTG
begin_DTG
0
4
0
96
2
0 1
4 0
0
108
2
0 2
4 0
0
120
2
0 3
4 0
0
136
2
0 4
4 0
end_DTG
begin_DTG
0
5
0
18
2
0 0
11 0
0
19
2
0 2
11 0
0
20
2
0 3
11 0
0
21
2
0 4
11 0
0
22
2
0 5
11 0
end_DTG
begin_DTG
0
8
0
95
2
0 1
4 0
0
98
2
0 1
1 0
0
107
2
0 2
4 0
0
110
2
0 2
1 0
0
119
2
0 3
4 0
0
122
2
0 3
1 0
0
135
2
0 4
4 0
0
138
2
0 4
1 0
end_DTG
begin_DTG
0
5
0
13
2
0 0
13 0
0
14
2
0 2
13 0
0
15
2
0 3
13 0
0
16
2
0 4
13 0
0
17
2
0 5
13 0
end_DTG
begin_DTG
3
2
50
0
3
51
0
5
52
0
1
5
53
0
2
0
54
0
5
55
0
3
0
56
0
4
57
0
5
58
0
2
3
59
0
5
60
0
5
0
61
0
1
62
0
2
63
0
3
64
0
4
65
0
end_DTG
begin_DTG
1
1
80
2
0 2
21 0
0
end_DTG
begin_DTG
1
1
81
2
0 3
21 0
0
end_DTG
begin_DTG
1
1
82
2
0 4
21 0
0
end_DTG
begin_DTG
2
1
83
2
15 3
20 0
2
85
2
0 3
21 0
0
0
end_DTG
begin_DTG
2
1
83
2
15 3
19 0
1
84
2
15 4
22 0
1
0
48
0
end_DTG
begin_DTG
5
1
80
2
0 2
16 0
1
81
2
0 3
17 0
1
82
2
0 4
18 0
1
85
2
0 3
19 0
1
86
2
0 4
22 0
1
0
49
0
end_DTG
begin_DTG
2
1
84
2
15 4
20 0
2
86
2
0 4
21 0
0
0
end_DTG
begin_DTG
0
5
0
43
2
0 0
17 1
0
44
2
0 2
17 1
0
45
2
0 3
17 1
0
46
2
0 4
17 1
0
47
2
0 5
17 1
end_DTG
begin_DTG
0
5
0
38
2
0 0
16 1
0
39
2
0 2
16 1
0
40
2
0 3
16 1
0
41
2
0 4
16 1
0
42
2
0 5
16 1
end_DTG
begin_CG
22
16 1
17 1
18 1
19 1
22 1
4 36
1 36
3 5
14 5
12 5
10 5
8 5
6 5
24 5
23 5
21 5
2 4
13 8
11 4
9 10
7 6
5 3
4
2 4
13 4
9 5
7 3
1
3 5
0
5
13 4
11 4
9 5
7 3
5 3
1
6 5
0
1
8 5
0
1
10 5
0
1
12 5
0
1
14 5
0
3
19 1
22 1
20 2
2
24 5
21 1
2
23 5
21 1
1
21 1
2
20 1
21 1
2
19 1
22 1
5
16 1
17 1
18 1
19 1
22 1
2
20 1
21 1
0
0
end_CG
