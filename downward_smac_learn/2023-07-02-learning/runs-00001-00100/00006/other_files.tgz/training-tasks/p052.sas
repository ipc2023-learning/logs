begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover2, objective5, high_res)
NegatedAtom have_image(rover2, objective5, high_res)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var33
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var34
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var32
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var31
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var30
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var28
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
1
1
1
1
1
1
5
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
1
1
1
end_state
begin_goal
8
5 0
9 0
11 0
21 0
22 0
23 0
24 0
25 0
end_goal
191
begin_operator
calibrate rover1 camera1 objective3 waypoint1
1
6 0
1
0 7 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective3 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint1 waypoint2
2
6 0
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint5 waypoint2
2
6 4
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint6 waypoint2
2
6 5
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint7 waypoint2
2
6 6
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective5 high_res waypoint1 waypoint2
2
6 0
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective5 high_res waypoint5 waypoint2
2
6 4
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective5 high_res waypoint6 waypoint2
2
6 5
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective5 high_res waypoint7 waypoint2
2
6 6
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
switch 19
check 0
check 1
103
check 0
check 0
check 0
check 0
switch 1
check 0
check 9
149
150
151
152
153
154
155
156
157
check 0
check 0
switch 12
check 2
84
85
check 0
check 0
check 0
switch 17
check 0
switch 19
check 0
check 1
104
check 0
check 0
check 0
check 0
switch 1
check 0
check 9
158
159
160
161
162
163
164
165
166
check 0
check 0
switch 12
check 3
86
87
88
check 0
check 0
check 0
switch 13
check 0
switch 19
check 0
check 1
97
check 0
check 0
check 0
check 0
switch 1
check 0
check 3
167
168
169
check 0
check 0
switch 12
check 1
89
check 0
check 0
check 1
31
switch 14
check 0
check 0
check 0
check 1
35
switch 16
check 0
check 0
check 0
check 1
51
switch 17
check 0
check 0
check 0
check 1
55
switch 20
check 0
switch 19
check 0
check 1
105
check 0
check 0
check 0
check 1
59
switch 1
check 0
check 6
170
171
172
173
174
175
check 0
switch 4
check 0
check 1
11
check 0
switch 3
check 0
check 1
15
check 0
switch 2
check 0
check 1
19
check 0
check 0
switch 12
check 1
90
check 0
check 0
check 1
32
switch 14
check 0
switch 19
check 0
check 1
98
check 0
check 0
check 0
check 1
36
switch 16
check 0
check 0
check 0
check 1
52
switch 17
check 0
check 0
check 0
check 1
56
switch 20
check 0
check 0
check 0
check 1
60
switch 1
check 0
check 6
176
177
178
179
180
181
check 0
switch 4
check 0
check 1
12
check 0
switch 3
check 0
check 1
16
check 0
switch 2
check 0
check 1
20
check 0
check 0
switch 12
check 1
91
check 0
check 0
check 1
33
switch 14
check 0
check 0
check 0
check 1
37
switch 15
check 0
switch 19
check 0
check 1
99
check 0
check 0
check 0
check 0
switch 16
check 0
check 0
check 0
check 1
53
switch 17
check 0
check 0
check 0
check 1
57
switch 20
check 0
check 0
check 0
check 1
61
switch 1
check 0
check 9
182
183
184
185
186
187
188
189
190
check 0
switch 4
check 0
check 1
13
check 0
switch 3
check 0
check 1
17
check 0
switch 2
check 0
check 1
21
check 0
check 0
switch 18
check 0
check 0
check 1
62
switch 19
check 0
check 0
check 1
63
check 0
end_SG
begin_DTG
2
1
80
0
2
81
0
2
0
82
0
6
83
0
2
0
84
0
3
85
0
3
2
86
0
4
87
0
5
88
0
1
3
89
0
1
3
90
0
1
1
91
0
end_DTG
begin_DTG
7
1
178
1
0 5
1
166
1
0 2
1
167
1
0 3
1
170
1
0 4
1
182
1
0 6
1
153
1
0 1
1
141
1
0 0
1
0
1
1
0 0
end_DTG
begin_DTG
0
5
0
156
2
0 1
1 0
0
165
2
0 2
1 0
0
168
2
0 3
1 0
0
180
2
0 5
1 0
0
189
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
145
2
0 0
1 0
end_DTG
begin_DTG
0
5
0
140
2
0 0
1 0
0
149
2
0 1
1 0
0
170
2
0 4
1 0
0
176
2
0 5
1 0
0
182
2
0 6
1 0
end_DTG
begin_DTG
0
4
0
10
2
0 0
4 0
0
11
2
0 4
4 0
0
12
2
0 5
4 0
0
13
2
0 6
4 0
end_DTG
begin_DTG
2
1
64
0
2
65
0
2
0
66
0
6
67
0
3
0
68
0
3
69
0
5
70
0
4
2
71
0
4
72
0
5
73
0
6
74
0
1
3
75
0
2
2
76
0
3
77
0
2
1
78
0
3
79
0
end_DTG
begin_DTG
7
1
132
1
6 5
1
124
1
6 3
1
126
1
6 4
1
123
1
6 2
1
134
1
6 6
1
115
1
6 1
1
107
1
6 0
1
0
0
1
6 0
end_DTG
begin_DTG
0
5
0
116
2
6 1
7 0
0
122
2
6 2
7 0
0
124
2
6 3
7 0
0
132
2
6 5
7 0
0
138
2
6 6
7 0
end_DTG
begin_DTG
0
8
0
6
2
6 0
8 0
0
7
2
6 4
8 0
0
8
2
6 5
8 0
0
9
2
6 6
8 0
0
18
2
0 0
2 0
0
19
2
0 4
2 0
0
20
2
0 5
2 0
0
21
2
0 6
2 0
end_DTG
begin_DTG
0
1
0
109
2
6 0
7 0
end_DTG
begin_DTG
0
8
0
2
2
6 0
10 0
0
3
2
6 4
10 0
0
4
2
6 5
10 0
0
5
2
6 6
10 0
0
14
2
0 0
3 0
0
15
2
0 4
3 0
0
16
2
0 5
3 0
0
17
2
0 6
3 0
end_DTG
begin_DTG
2
1
92
2
6 0
18 0
2
96
2
0 0
19 0
0
0
end_DTG
begin_DTG
2
1
93
2
6 3
18 0
2
97
2
0 3
19 0
0
0
end_DTG
begin_DTG
2
1
94
2
6 5
18 0
2
98
2
0 5
19 0
0
0
end_DTG
begin_DTG
2
1
95
2
6 6
18 0
2
99
2
0 6
19 0
0
0
end_DTG
begin_DTG
2
1
100
2
6 1
18 0
2
103
2
0 1
19 0
0
0
end_DTG
begin_DTG
2
1
101
2
6 2
18 0
2
104
2
0 2
19 0
0
0
end_DTG
begin_DTG
7
1
92
2
6 0
12 0
1
93
2
6 3
13 0
1
94
2
6 5
14 0
1
95
2
6 6
15 0
1
100
2
6 1
16 0
1
101
2
6 2
17 0
1
102
2
6 4
20 0
1
0
62
0
end_DTG
begin_DTG
7
1
96
2
0 0
12 0
1
97
2
0 3
13 0
1
98
2
0 5
14 0
1
99
2
0 6
15 0
1
103
2
0 1
16 0
1
104
2
0 2
17 0
1
105
2
0 4
20 0
1
0
63
0
end_DTG
begin_DTG
2
1
102
2
6 4
18 0
2
105
2
0 4
19 0
0
0
end_DTG
begin_DTG
0
8
0
46
2
6 0
20 1
0
47
2
6 4
20 1
0
48
2
6 5
20 1
0
49
2
6 6
20 1
0
58
2
0 0
20 2
0
59
2
0 4
20 2
0
60
2
0 5
20 2
0
61
2
0 6
20 2
end_DTG
begin_DTG
0
8
0
42
2
6 0
17 1
0
43
2
6 4
17 1
0
44
2
6 5
17 1
0
45
2
6 6
17 1
0
54
2
0 0
17 2
0
55
2
0 4
17 2
0
56
2
0 5
17 2
0
57
2
0 6
17 2
end_DTG
begin_DTG
0
8
0
38
2
6 0
16 1
0
39
2
6 4
16 1
0
40
2
6 5
16 1
0
41
2
6 6
16 1
0
50
2
0 0
16 2
0
51
2
0 4
16 2
0
52
2
0 5
16 2
0
53
2
0 6
16 2
end_DTG
begin_DTG
0
8
0
26
2
6 0
14 1
0
27
2
6 4
14 1
0
28
2
6 5
14 1
0
29
2
6 6
14 1
0
34
2
0 0
14 2
0
35
2
0 4
14 2
0
36
2
0 5
14 2
0
37
2
0 6
14 2
end_DTG
begin_DTG
0
8
0
22
2
6 0
12 1
0
23
2
6 4
12 1
0
24
2
6 5
12 1
0
25
2
6 6
12 1
0
30
2
0 0
12 2
0
31
2
0 4
12 2
0
32
2
0 5
12 2
0
33
2
0 6
12 2
end_DTG
begin_CG
20
12 1
13 1
14 1
15 1
16 1
17 1
20 1
1 52
5 4
11 4
9 4
25 4
24 4
23 4
22 4
21 4
19 7
4 5
3 1
2 5
3
4 5
3 1
2 5
1
9 4
1
11 4
1
5 4
0
18
12 1
13 1
14 1
15 1
16 1
17 1
20 1
7 35
11 4
9 4
25 4
24 4
23 4
22 4
21 4
18 7
10 1
8 5
2
10 1
8 5
1
9 4
0
1
11 4
0
3
25 8
18 1
19 1
2
18 1
19 1
3
24 8
18 1
19 1
2
18 1
19 1
3
23 8
18 1
19 1
3
22 8
18 1
19 1
7
12 1
13 1
14 1
15 1
16 1
17 1
20 1
7
12 1
13 1
14 1
15 1
16 1
17 1
20 1
3
21 8
18 1
19 1
0
0
0
0
0
end_CG
