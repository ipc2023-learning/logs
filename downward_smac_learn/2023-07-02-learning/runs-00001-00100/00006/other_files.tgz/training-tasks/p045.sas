begin_version
3
end_version
begin_metric
0
end_metric
32
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var41
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var37
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var38
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var10
-1
3
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
end_variable
begin_variable
var36
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var34
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var33
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var31
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var30
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var29
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var28
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
0
begin_state
4
3
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
end_state
begin_goal
12
4 0
6 0
8 0
11 0
13 0
25 0
26 0
27 0
28 0
29 0
30 0
31 0
end_goal
198
begin_operator
calibrate rover1 camera1 objective1 waypoint3
1
1 2
1
0 9 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint4
1
1 3
1
0 9 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective5 waypoint1
1
1 0
1
0 2 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint1 waypoint3
2
1 0
7 0
1
0 8 -1 0
0
end_operator
begin_operator





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




heck 0
check 0
check 1
95
check 0
switch 14
check 2
123
124
check 0
check 0
check 1
51
switch 15
check 0
check 0
check 0
check 1
56
switch 16
check 0
switch 23
check 0
check 1
134
check 0
check 0
check 0
check 1
61
switch 17
check 0
check 0
check 0
check 1
66
switch 19
check 0
check 0
check 0
check 1
86
switch 20
check 0
check 0
check 0
check 1
91
switch 21
check 0
switch 23
check 0
check 1
144
check 0
check 0
check 0
check 0
switch 24
check 0
check 0
check 0
check 1
96
check 0
switch 14
check 3
125
126
127
check 0
check 0
check 1
52
switch 15
check 0
check 0
check 0
check 1
57
switch 16
check 0
check 0
check 0
check 1
62
switch 17
check 0
switch 23
check 0
check 1
135
check 0
check 0
check 0
check 1
67
switch 19
check 0
check 0
check 0
check 1
87
switch 20
check 0
check 0
check 0
check 1
92
switch 24
check 0
switch 23
check 0
check 1
145
check 0
check 0
check 0
check 1
97
check 0
switch 22
check 0
check 0
check 1
98
switch 23
check 0
check 0
check 1
99
check 0
end_SG
begin_DTG
3
3
114
0
4
115
0
5
116
0
1
3
117
0
2
3
118
0
5
119
0
3
0
120
0
1
121
0
2
122
0
2
0
123
0
5
124
0
3
0
125
0
2
126
0
4
127
0
end_DTG
begin_DTG
2
3
100
0
4
101
0
2
2
102
0
3
103
0
2
1
104
0
3
105
0
4
0
106
0
1
107
0
2
108
0
5
109
0
2
0
110
0
5
111
0
2
3
112
0
4
113
0
end_DTG
begin_DTG
6
1
185
1
1 4
1
173
1
1 3
1
195
1
1 5
1
160
1
1 1
1
148
1
1 0
1
163
1
1 2
1
0
2
1
1 0
end_DTG
begin_DTG
0
4
0
147
2
1 0
2 0
0
179
2
1 3
2 0
0
187
2
1 4
2 0
0
195
2
1 5
2 0
end_DTG
begin_DTG
0
5
0
13
2
1 0
3 0
0
14
2
1 1
3 0
0
15
2
1 3
3 0
0
16
2
1 4
3 0
0
17
2
1 5
3 0
end_DTG
begin_DTG
0
2
0
165
2
1 2
2 0
0
173
2
1 3
2 0
end_DTG
begin_DTG
0
5
0
8
2
1 0
5 0
0
9
2
1 1
5 0
0
10
2
1 3
5 0
0
11
2
1 4
5 0
0
12
2
1 5
5 0
end_DTG
begin_DTG
0
2
0
163
2
1 2
2 0
0
171
2
1 3
2 0
end_DTG
begin_DTG
0
5
0
3
2
1 0
7 0
0
4
2
1 1
7 0
0
5
2
1 3
7 0
0
6
2
1 4
7 0
0
7
2
1 5
7 0
end_DTG
begin_DTG
6
1
146
1
1 0
1
158
1
1 1
1
162
1
1 2
1
170
1
1 3
1
182
1
1 4
1
194
1
1 5
2
0
0
1
1 2
0
1
1
1 3
end_DTG
begin_DTG
0
2
0
154
2
1 0
9 0
0
156
2
1 0
2 0
end_DTG
begin_DTG
0
5
0
23
2
1 0
10 0
0
24
2
1 1
10 0
0
25
2
1 3
10 0
0
26
2
1 4
10 0
0
27
2
1 5
10 0
end_DTG
begin_DTG
0
8
0
146
2
1 0
9 0
0
148
2
1 0
2 0
0
178
2
1 3
9 0
0
180
2
1 3
2 0
0
186
2
1 4
9 0
0
188
2
1 4
2 0
0
194
2
1 5
9 0
0
196
2
1 5
2 0
end_DTG
begin_DTG
0
5
0
18
2
1 0
12 0
0
19
2
1 1
12 0
0
20
2
1 3
12 0
0
21
2
1 4
12 0
0
22
2
1 5
12 0
end_DTG
begin_DTG
2
1
128
2
1 1
22 0
2
132
2
0 1
23 0
0
0
end_DTG
begin_DTG
2
1
129
2
1 2
22 0
2
133
2
0 2
23 0
0
0
end_DTG
begin_DTG
2
1
130
2
1 4
22 0
2
134
2
0 4
23 0
0
0
end_DTG
begin_DTG
2
1
131
2
1 5
22 0
2
135
2
0 5
23 0
0
0
end_DTG
begin_DTG
2
1
136
2
1 0
22 0
2
141
2
0 0
23 0
0
0
end_DTG
begin_DTG
2
1
137
2
1 1
22 0
2
142
2
0 1
23 0
0
0
end_DTG
begin_DTG
2
1
138
2
1 3
22 0
2
143
2
0 3
23 0
0
0
end_DTG
begin_DTG
2
1
139
2
1 4
22 0
2
144
2
0 4
23 0
0
0
end_DTG
begin_DTG
9
1
128
2
1 1
14 0
1
129
2
1 2
15 0
1
130
2
1 4
16 0
1
131
2
1 5
17 0
1
136
2
1 0
18 0
1
137
2
1 1
19 0
1
138
2
1 3
20 0
1
139
2
1 4
21 0
1
140
2
1 5
24 0
1
0
98
0
end_DTG
begin_DTG
9
1
132
2
0 1
14 0
1
133
2
0 2
15 0
1
134
2
0 4
16 0
1
135
2
0 5
17 0
1
141
2
0 0
18 0
1
142
2
0 1
19 0
1
143
2
0 3
20 0
1
144
2
0 4
21 0
1
145
2
0 5
24 0
1
0
99
0
end_DTG
begin_DTG
2
1
140
2
1 5
22 0
2
145
2
0 5
23 0
0
0
end_DTG
begin_DTG
0
10
0
78
2
1 0
24 1
0
79
2
1 1
24 1
0
80
2
1 3
24 1
0
81
2
1 4
24 1
0
82
2
1 5
24 1
0
93
2
0 0
24 2
0
94
2
0 1
24 2
0
95
2
0 3
24 2
0
96
2
0 4
24 2
0
97
2
0 5
24 2
end_DTG
begin_DTG
0
10
0
73
2
1 0
20 1
0
74
2
1 1
20 1
0
75
2
1 3
20 1
0
76
2
1 4
20 1
0
77
2
1 5
20 1
0
88
2
0 0
20 2
0
89
2
0 1
20 2
0
90
2
0 3
20 2
0
91
2
0 4
20 2
0
92
2
0 5
20 2
end_DTG
begin_DTG
0
10
0
68
2
1 0
19 1
0
69
2
1 1
19 1
0
70
2
1 3
19 1
0
71
2
1 4
19 1
0
72
2
1 5
19 1
0
83
2
0 0
19 2
0
84
2
0 1
19 2
0
85
2
0 3
19 2
0
86
2
0 4
19 2
0
87
2
0 5
19 2
end_DTG
begin_DTG
0
10
0
43
2
1 0
17 1
0
44
2
1 1
17 1
0
45
2
1 3
17 1
0
46
2
1 4
17 1
0
47
2
1 5
17 1
0
63
2
0 0
17 2
0
64
2
0 1
17 2
0
65
2
0 3
17 2
0
66
2
0 4
17 2
0
67
2
0 5
17 2
end_DTG
begin_DTG
0
10
0
38
2
1 0
16 1
0
39
2
1 1
16 1
0
40
2
1 3
16 1
0
41
2
1 4
16 1
0
42
2
1 5
16 1
0
58
2
0 0
16 2
0
59
2
0 1
16 2
0
60
2
0 3
16 2
0
61
2
0 4
16 2
0
62
2
0 5
16 2
end_DTG
begin_DTG
0
10
0
33
2
1 0
15 1
0
34
2
1 1
15 1
0
35
2
1 3
15 1
0
36
2
1 4
15 1
0
37
2
1 5
15 1
0
53
2
0 0
15 2
0
54
2
0 1
15 2
0
55
2
0 3
15 2
0
56
2
0 4
15 2
0
57
2
0 5
15 2
end_DTG
begin_DTG
0
10
0
28
2
1 0
14 1
0
29
2
1 1
14 1
0
30
2
1 3
14 1
0
31
2
1 4
14 1
0
32
2
1 5
14 1
0
48
2
0 0
14 2
0
49
2
0 1
14 2
0
50
2
0 3
14 2
0
51
2
0 4
14 2
0
52
2
0 5
14 2
end_DTG
begin_CG
17
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
24 1
31 5
30 5
29 5
28 5
27 5
26 5
25 5
23 9
29
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
24 1
9 15
2 40
8 5
6 5
4 5
13 5
11 5
31 5
30 5
29 5
28 5
27 5
26 5
25 5
22 9
7 2
5 2
3 4
12 8
10 2
5
7 2
5 2
3 4
12 4
10 1
1
4 5
0
1
6 5
0
1
8 5
0
2
12 4
10 1
1
11 5
0
1
13 5
0
3
31 10
22 1
23 1
3
30 10
22 1
23 1
3
29 10
22 1
23 1
3
28 10
22 1
23 1
2
22 1
23 1
3
27 10
22 1
23 1
3
26 10
22 1
23 1
2
22 1
23 1
9
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
24 1
9
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
24 1
3
25 10
22 1
23 1
0
0
0
0
0
0
0
end_CG
