begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var0
-1
2
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var14
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var8
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var1
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var13
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var7
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var9
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var3
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
0
begin_state
1
1
1
1
1
1
1
1
1
end_state
begin_goal
3
3 0
6 0
8 0
end_goal
13
begin_operator
calibrate rover1 camera1 objective2 waypoint2
1
0 1
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint1 waypoint2
2
0 0
7 0
1
0 8 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint1 waypoint2
2
0 0
5 0
1
0 6 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint1 waypoint2
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 0 0 1
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint1
0
1
0 0 1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
2
0 4 0 1
0 7 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
1
0 4 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera2 low_res
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 colour
1
0 1
1
0 4 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 high_res
1
0 1
2
0 4 0 1
0 5 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera2 low_res
1
0 1
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 4
check 2
1
5
check 2
7
8
check 0
switch 1
check 0
check 1
9
check 0
switch 7
check 0
check 1
2
check 0
switch 5
check 0
check 1
3
check 0
switch 2
check 0
check 1
4
check 0
check 0
switch 4
check 2
0
6
check 2
10
11
check 0
switch 1
check 0
check 1
12
check 0
check 0
check 0
end_SG
begin_DTG
1
1
5
0
1
0
6
0
end_DTG
begin_DTG
2
1
9
1
0 0
1
12
1
0 1
1
0
1
1
0 0
end_DTG
begin_DTG
0
1
0
12
2
0 1
1 0
end_DTG
begin_DTG
0
1
0
4
2
0 0
2 0
end_DTG
begin_DTG
2
1
7
1
0 0
1
10
1
0 1
1
0
0
1
0 1
end_DTG
begin_DTG
0
1
0
11
2
0 1
4 0
end_DTG
begin_DTG
0
1
0
3
2
0 0
5 0
end_DTG
begin_DTG
0
1
0
7
2
0 0
4 0
end_DTG
begin_DTG
0
1
0
2
2
0 0
7 0
end_DTG
begin_CG
8
4 5
1 3
8 1
6 1
3 1
7 1
5 1
2 1
1
2 1
1
3 1
0
2
7 1
5 1
1
6 1
0
1
8 1
0
end_CG
