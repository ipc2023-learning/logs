begin_version
3
end_version
begin_metric
0
end_metric
35
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera4, rover3)
NegatedAtom calibrated(camera4, rover3)
end_variable
begin_variable
var95
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var83
-1
2
Atom have_image(rover3, objective2, colour)
NegatedAtom have_image(rover3, objective2, colour)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover3)
NegatedAtom calibrated(camera2, rover3)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var103
-1
2
Atom have_image(rover3, objective8, low_res)
NegatedAtom have_image(rover3, objective8, low_res)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var1
-1
10
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint10)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
Atom have_soil_analysis(rover4, waypoint1)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint10)
Atom have_soil_analysis(rover2, waypoint10)
Atom have_soil_analysis(rover4, waypoint10)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
Atom have_soil_analysis(rover4, waypoint5)
end_variable
begin_variable
var50
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var52
-1
2
Atom empty(rover4store)
Atom full(rover4store)
end_variable
begin_variable
var10
-1
3
Atom at_soil_sample(waypoint8)
Atom have_soil_analysis(rover2, waypoint8)
Atom have_soil_analysis(rover4, waypoint8)
end_variable
begin_variable
var46
-1
2
Atom communicated_soil_data(waypoint10)
NegatedAtom communicated_soil_data(waypoint10)
end_variable
begin_variable
var45
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var0
-1
10
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint10)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover1, objective8, low_res)
NegatedAtom have_image(rover1, objective8, low_res)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective8, low_res)
NegatedAtom communicated_image_data(objective8, low_res)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var49
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var51
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var44
-1
2
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
1 6
5 0
0
633
2
1 6
6 0
0
583
2
1 4
2 0
0
453
2
1 0
6 0
0
579
2
1 4
6 0
0
547
2
1 3
2 0
0
545
2
1 3
5 0
0
543
2
1 3
6 0
0
511
2
1 2
2 0
0
509
2
1 2
5 0
0
507
2
1 2
6 0
0
481
2
1 1
2 0
0
479
2
1 1
5 0
0
477
2
1 1
6 0
0
457
2
1 0
2 0
0
455
2
1 0
5 0
end_DTG
begin_DTG
4
2
175
0
5
176
0
7
177
0
8
178
0
2
6
179
0
9
180
0
2
0
181
0
7
182
0
4
5
183
0
6
184
0
7
185
0
9
186
0
1
6
187
0
4
0
188
0
3
189
0
6
190
0
8
191
0
5
1
192
0
3
193
0
4
194
0
5
195
0
8
196
0
4
0
197
0
2
198
0
3
199
0
8
200
0
5
0
201
0
5
202
0
6
203
0
7
204
0
9
205
0
3
1
206
0
3
207
0
8
208
0
end_DTG
begin_DTG
2
1
273
2
9 0
13 0
2
277
2
0 0
14 0
0
0
end_DTG
begin_DTG
2
1
274
2
9 1
13 0
2
278
2
0 1
14 0
0
0
end_DTG
begin_DTG
2
1
275
2
9 5
13 0
2
279
2
0 5
14 0
0
0
end_DTG
begin_DTG
4
1
273
2
9 0
10 0
1
274
2
9 1
11 0
1
275
2
9 5
12 0
1
276
2
9 8
15 0
1
0
132
0
end_DTG
begin_DTG
4
1
277
2
0 0
10 0
1
278
2
0 1
11 0
1
279
2
0 5
12 0
1
280
2
0 8
15 0
1
0
134
0
end_DTG
begin_DTG
2
1
276
2
9 8
13 0
2
280
2
0 8
14 0
0
0
end_DTG
begin_DTG
0
14
0
110
2
9 1
11 1
0
111
2
9 2
11 1
0
112
2
9 3
11 1
0
113
2
9 5
11 1
0
114
2
9 6
11 1
0
115
2
9 7
11 1
0
116
2
9 8
11 1
0
124
2
0 1
11 2
0
125
2
0 2
11 2
0
126
2
0 3
11 2
0
127
2
0 5
11 2
0
128
2
0 6
11 2
0
129
2
0 7
11 2
0
130
2
0 8
11 2
end_DTG
begin_DTG
0
14
0
103
2
9 1
10 1
0
104
2
9 2
10 1
0
105
2
9 3
10 1
0
106
2
9 5
10 1
0
107
2
9 6
10 1
0
108
2
9 7
10 1
0
109
2
9 8
10 1
0
117
2
0 1
10 2
0
118
2
0 2
10 2
0
119
2
0 3
10 2
0
120
2
0 5
10 2
0
121
2
0 6
10 2
0
122
2
0 7
10 2
0
123
2
0 8
10 2
end_DTG
begin_DTG
3
3
135
0
5
136
0
8
137
0
2
5
138
0
9
139
0
2
7
140
0
9
141
0
6
0
142
0
5
143
0
6
144
0
7
145
0
8
146
0
9
147
0
1
6
148
0
6
0
149
0
1
150
0
3
151
0
6
152
0
8
153
0
9
154
0
5
3
155
0
4
156
0
5
157
0
8
158
0
9
159
0
4
2
160
0
3
161
0
8
162
0
9
163
0
5
0
164
0
3
165
0
5
166
0
6
167
0
7
168
0
6
1
169
0
2
170
0
3
171
0
5
172
0
6
173
0
7
174
0
end_DTG
begin_DTG
10
1
390
1
18 7
1
381
1
18 6
1
370
1
18 5
1
430
1
18 9
1
421
1
18 8
1
311
1
18 2
1
302
1
18 1
1
291
1
18 0
1
350
1
18 4
1
331
1
18 3
9
0
0
1
18 0
0
1
1
18 1
0
2
1
18 2
0
3
1
18 3
0
4
1
18 4
0
5
1
18 6
0
6
1
18 7
0
7
1
18 8
0
8
1
18 9
end_DTG
begin_DTG
0
7
0
322
2
18 2
19 0
0
337
2
18 3
19 0
0
367
2
18 5
19 0
0
385
2
18 6
19 0
0
406
2
18 7
19 0
0
424
2
18 8
19 0
0
439
2
18 9
19 0
end_DTG
begin_DTG
0
14
0
40
2
18 1
20 0
0
41
2
18 2
20 0
0
42
2
18 3
20 0
0
43
2
18 5
20 0
0
44
2
18 6
20 0
0
45
2
18 7
20 0
0
46
2
18 8
20 0
0
68
2
1 1
7 0
0
69
2
1 2
7 0
0
70
2
1 3
7 0
0
71
2
1 5
7 0
0
72
2
1 6
7 0
0
73
2
1 7
7 0
0
74
2
1 8
7 0
end_DTG
begin_DTG
0
9
0
289
2
18 0
19 0
0
301
2
18 1
19 0
0
316
2
18 2
19 0
0
334
2
18 3
19 0
0
352
2
18 4
19 0
0
379
2
18 6
19 0
0
400
2
18 7
19 0
0
418
2
18 8
19 0
0
436
2
18 9
19 0
end_DTG
begin_DTG
0
14
0
33
2
18 1
22 0
0
34
2
18 2
22 0
0
35
2
18 3
22 0
0
36
2
18 5
22 0
0
37
2
18 6
22 0
0
38
2
18 7
22 0
0
39
2
18 8
22 0
0
61
2
1 1
8 0
0
62
2
1 2
8 0
0
63
2
1 3
8 0
0
64
2
1 5
8 0
0
65
2
1 6
8 0
0
66
2
1 7
8 0
0
67
2
1 8
8 0
end_DTG
begin_DTG
0
9
0
287
2
18 0
19 0
0
299
2
18 1
19 0
0
314
2
18 2
19 0
0
332
2
18 3
19 0
0
350
2
18 4
19 0
0
377
2
18 6
19 0
0
398
2
18 7
19 0
0
416
2
18 8
19 0
0
434
2
18 9
19 0
end_DTG
begin_DTG
0
14
0
26
2
18 1
24 0
0
27
2
18 2
24 0
0
28
2
18 3
24 0
0
29
2
18 5
24 0
0
30
2
18 6
24 0
0
31
2
18 7
24 0
0
32
2
18 8
24 0
0
54
2
1 1
3 0
0
55
2
1 2
3 0
0
56
2
1 3
3 0
0
57
2
1 5
3 0
0
58
2
1 6
3 0
0
59
2
1 7
3 0
0
60
2
1 8
3 0
end_DTG
begin_DTG
0
2
0
305
2
18 2
19 0
0
338
2
18 4
19 0
end_DTG
begin_DTG
0
14
0
19
2
18 1
26 0
0
20
2
18 2
26 0
0
21
2
18 3
26 0
0
22
2
18 5
26 0
0
23
2
18 6
26 0
0
24
2
18 7
26 0
0
25
2
18 8
26 0
0
47
2
1 1
4 0
0
48
2
1 2
4 0
0
49
2
1 3
4 0
0
50
2
1 5
4 0
0
51
2
1 6
4 0
0
52
2
1 7
4 0
0
53
2
1 8
4 0
end_DTG
begin_DTG
2
1
267
2
18 3
30 0
2
270
2
1 3
31 0
0
0
end_DTG
begin_DTG
2
1
268
2
18 5
30 0
2
271
2
1 5
31 0
0
0
end_DTG
begin_DTG
3
1
267
2
18 3
28 0
1
268
2
18 5
29 0
1
269
2
18 7
32 0
1
0
131
0
end_DTG
begin_DTG
3
1
270
2
1 3
28 0
1
271
2
1 5
29 0
1
272
2
1 7
32 0
1
0
133
0
end_DTG
begin_DTG
2
1
269
2
18 7
30 0
2
272
2
1 7
31 0
0
0
end_DTG
begin_DTG
0
14
0
82
2
18 1
32 1
0
83
2
18 2
32 1
0
84
2
18 3
32 1
0
85
2
18 5
32 1
0
86
2
18 6
32 1
0
87
2
18 7
32 1
0
88
2
18 8
32 1
0
96
2
1 1
32 2
0
97
2
1 2
32 2
0
98
2
1 3
32 2
0
99
2
1 5
32 2
0
100
2
1 6
32 2
0
101
2
1 7
32 2
0
102
2
1 8
32 2
end_DTG
begin_DTG
0
14
0
75
2
18 1
28 1
0
76
2
18 2
28 1
0
77
2
18 3
28 1
0
78
2
18 5
28 1
0
79
2
18 6
28 1
0
80
2
18 7
28 1
0
81
2
18 8
28 1
0
89
2
1 1
28 2
0
90
2
1 2
28 2
0
91
2
1 3
28 2
0
92
2
1 5
28 2
0
93
2
1 6
28 2
0
94
2
1 7
28 2
0
95
2
1 8
28 2
end_DTG
begin_CG
7
10 1
11 1
12 1
15 1
17 7
16 7
14 4
17
28 1
29 1
32 1
6 108
5 108
2 112
27 7
25 7
23 7
21 7
34 7
33 7
31 3
4 2
3 9
8 27
7 21
4
4 2
3 9
8 9
7 7
1
25 7
1
27 7
2
8 9
7 7
2
8 9
7 7
1
21 7
1
23 7
7
10 1
11 1
12 1
15 1
17 7
16 7
13 4
3
17 14
13 1
14 1
3
16 14
13 1
14 1
2
13 1
14 1
4
10 1
11 1
12 1
15 1
4
10 1
11 1
12 1
15 1
2
13 1
14 1
0
0
15
28 1
29 1
32 1
19 168
27 7
25 7
23 7
21 7
34 7
33 7
30 3
26 2
24 9
22 9
20 7
4
26 2
24 9
22 9
20 7
1
21 7
0
1
23 7
0
1
25 7
0
1
27 7
0
3
34 14
30 1
31 1
2
30 1
31 1
3
28 1
29 1
32 1
3
28 1
29 1
32 1
3
33 14
30 1
31 1
0
0
end_CG
