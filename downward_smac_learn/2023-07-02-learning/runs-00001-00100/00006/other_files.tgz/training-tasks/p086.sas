begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var3
-1
9
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var10
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover3, waypoint2)
Atom have_rock_analysis(rover4, waypoint2)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
Atom have_rock_analysis(rover4, waypoint3)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
Atom have_rock_analysis(rover4, waypoint5)
end_variable
begin_variable
var7
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
Atom have_rock_analysis(rover4, waypoint7)
end_variable
begin_variable
var55
-1
2
Atom empty(rover4store)
Atom full(rover4store)
end_variable
begin_variable
var8
-1
3
Atom at_rock_sample(waypoint9)
Atom have_rock_analysis(rover3, waypoint9)
Atom have_rock_analysis(rover4, waypoint9)
end_variable
begin_variable
var11
-1
3
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var53
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var54
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var12
-1
3
Atom at_soil_sample(waypoint8)
Atom have_soil_analysis(rover1, waypoint8)
Atom have_soil_analysis(rover3, waypoint8)
end_variable
begin_variable
var48
-1
2
Atom communicated_rock_data(waypoint9)
NegatedAtom communicated_rock_data(waypoint9)
end_variable
begin_variable
var47
-1
2
Atom communicated_rock_data(waypoint7)
NegatedAtom communicated_rock_data(waypoint7)
end_variable
begin_variable
var45
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var44
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
0
begin_state
8
2
3
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
4
15 0
16 0
17 0
18 0
end_goal
85
begin_operator
communicate_rock_data rover3 general waypoint2 waypoint4 waypoint2
2
1 3
5 1
1
0 18 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint2 waypoint5 waypoint2
2
1 4
5 1
1
0 18 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint3 waypoint4 waypoint2
2
1 3
6 1
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint3 waypoint5 waypoint2
2
1 4
6 1
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint7 waypoint4 waypoint2
2
1 3
8 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint7 waypoint5 waypoint2
2
1 4
8 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint9 waypoint4 waypoint2
2
1 3
10 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover3 general waypoint9 waypoint5 waypoint2
2
1 4
10 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint2 waypoint4 waypoint2
2
0 3
5 2
1
0 18 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint2 waypoint5 waypoint2
2
0 4
5 2
1
0 18 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint3 waypoint4 waypoint2
2
0 3
6 2
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint3 waypoint5 waypoint2
2
0 4
6 2
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint7 waypoint4 waypoint2
2
0 3
8 2
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint7 waypoint5 waypoint2
2
0 4
8 2
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint9 waypoint4 waypoint2
2
0 3
10 2
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover4 general waypoint9 waypoint5 waypoint2
2
0 4
10 2
1
0 15 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 12 1 0
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




tch 1
check 1
33
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 14
check 0
switch 12
check 0
check 1
80
check 0
check 0
check 0
check 0
check 0
check 1
34
switch 1
check 0
check 1
35
switch 0
check 2
36
37
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 13
check 0
check 1
67
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
38
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 13
check 0
check 1
68
check 0
check 0
check 0
check 0
switch 3
check 0
switch 13
check 0
check 1
81
check 0
check 0
check 0
check 0
check 0
switch 0
check 5
39
40
41
42
43
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 0
check 1
0
check 0
switch 6
check 0
check 0
check 1
2
check 0
switch 8
check 0
check 0
check 1
4
check 0
switch 10
check 0
check 0
check 1
6
check 0
check 0
switch 0
check 2
44
45
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 0
check 1
1
check 0
switch 6
check 0
check 0
check 1
3
check 0
switch 7
check 0
switch 13
check 0
check 1
69
check 0
check 0
check 0
check 0
switch 8
check 0
check 0
check 1
5
check 0
switch 10
check 0
check 0
check 1
7
check 0
switch 4
check 0
switch 13
check 0
check 1
82
check 0
check 0
check 0
check 0
check 0
check 1
46
switch 0
check 2
47
48
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
switch 13
check 0
check 1
70
check 0
check 0
check 0
check 0
switch 11
check 0
switch 13
check 0
check 1
83
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
49
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 14
check 0
switch 13
check 0
check 1
84
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
50
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
switch 13
check 0
check 1
71
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
51
switch 5
check 2
52
53
switch 9
check 0
check 1
72
check 0
check 0
check 0
check 0
check 0
switch 5
check 1
54
check 0
check 0
check 0
switch 6
check 0
switch 9
check 0
check 1
73
check 0
check 0
check 0
check 0
check 0
switch 5
check 5
55
56
57
58
59
check 0
check 0
check 1
8
switch 6
check 0
check 0
check 0
check 1
10
switch 8
check 0
check 0
check 0
check 1
12
switch 10
check 0
check 0
check 0
check 1
14
check 0
switch 5
check 2
60
61
check 0
check 0
check 1
9
switch 6
check 0
check 0
check 0
check 1
11
switch 7
check 0
switch 9
check 0
check 1
74
check 0
check 0
check 0
check 0
switch 8
check 0
check 0
check 0
check 1
13
switch 10
check 0
check 0
check 0
check 1
15
check 0
check 1
62
switch 5
check 2
63
64
check 0
check 0
check 0
switch 8
check 0
switch 9
check 0
check 1
75
check 0
check 0
check 0
check 0
check 0
check 1
65
switch 5
check 1
66
check 0
check 0
check 0
switch 10
check 0
switch 9
check 0
check 1
76
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
check 0
check 1
16
switch 13
check 0
check 0
check 1
17
switch 9
check 0
check 0
check 1
18
check 0
end_SG
begin_DTG
1
3
51
0
2
3
52
0
4
53
0
1
3
54
0
5
0
55
0
1
56
0
2
57
0
5
58
0
6
59
0
2
1
60
0
8
61
0
1
3
62
0
2
3
63
0
7
64
0
1
6
65
0
1
4
66
0
end_DTG
begin_DTG
1
3
35
0
2
3
36
0
4
37
0
1
3
38
0
5
0
39
0
1
40
0
2
41
0
5
42
0
6
43
0
2
1
44
0
8
45
0
1
3
46
0
2
3
47
0
7
48
0
1
6
49
0
1
4
50
0
end_DTG
begin_DTG
1
3
19
0
2
3
20
0
4
21
0
1
3
22
0
5
0
23
0
1
24
0
2
25
0
5
26
0
6
27
0
2
1
28
0
8
29
0
1
3
30
0
2
3
31
0
7
32
0
1
6
33
0
1
4
34
0
end_DTG
begin_DTG
2
1
77
2
2 2
12 0
2
81
2
1 2
13 0
0
0
end_DTG
begin_DTG
2
1
78
2
2 4
12 0
2
82
2
1 4
13 0
0
0
end_DTG
begin_DTG
2
1
67
2
1 1
13 0
2
72
2
0 1
9 0
0
0
end_DTG
begin_DTG
2
1
68
2
1 2
13 0
2
73
2
0 2
9 0
0
0
end_DTG
begin_DTG
2
1
69
2
1 4
13 0
2
74
2
0 4
9 0
0
0
end_DTG
begin_DTG
2
1
70
2
1 6
13 0
2
75
2
0 6
9 0
0
0
end_DTG
begin_DTG
5
1
72
2
0 1
5 0
1
73
2
0 2
6 0
1
74
2
0 4
7 0
1
75
2
0 6
8 0
1
76
2
0 8
10 0
1
0
18
0
end_DTG
begin_DTG
2
1
71
2
1 8
13 0
2
76
2
0 8
9 0
0
0
end_DTG
begin_DTG
2
1
79
2
2 6
12 0
2
83
2
1 6
13 0
0
0
end_DTG
begin_DTG
4
1
77
2
2 2
3 0
1
78
2
2 4
4 0
1
79
2
2 6
11 0
1
80
2
2 7
14 0
1
0
16
0
end_DTG
begin_DTG
9
1
67
2
1 1
5 0
1
68
2
1 2
6 0
1
69
2
1 4
7 0
1
70
2
1 6
8 0
1
71
2
1 8
10 0
1
81
2
1 2
3 0
1
82
2
1 4
4 0
1
83
2
1 6
11 0
1
84
2
1 7
14 0
1
0
17
0
end_DTG
begin_DTG
2
1
80
2
2 7
12 0
2
84
2
1 7
13 0
0
0
end_DTG
begin_DTG
0
4
0
6
2
1 3
10 1
0
7
2
1 4
10 1
0
14
2
0 3
10 2
0
15
2
0 4
10 2
end_DTG
begin_DTG
0
4
0
4
2
1 3
8 1
0
5
2
1 4
8 1
0
12
2
0 3
8 2
0
13
2
0 4
8 2
end_DTG
begin_DTG
0
4
0
2
2
1 3
6 1
0
3
2
1 4
6 1
0
10
2
0 3
6 2
0
11
2
0 4
6 2
end_DTG
begin_DTG
0
4
0
0
2
1 3
5 1
0
1
2
1 4
5 1
0
8
2
0 3
5 2
0
9
2
0 4
5 2
end_DTG
begin_CG
10
5 1
6 1
7 1
8 1
10 1
18 2
17 2
16 2
15 2
9 5
14
5 1
6 1
7 1
8 1
10 1
3 1
4 1
11 1
14 1
18 2
17 2
16 2
15 2
13 9
5
3 1
4 1
11 1
14 1
12 4
2
12 1
13 1
2
12 1
13 1
3
18 4
13 1
9 1
3
17 4
13 1
9 1
2
13 1
9 1
3
16 4
13 1
9 1
5
5 1
6 1
7 1
8 1
10 1
3
15 4
13 1
9 1
2
12 1
13 1
4
3 1
4 1
11 1
14 1
9
5 1
6 1
7 1
8 1
10 1
3 1
4 1
11 1
14 1
2
12 1
13 1
0
0
0
0
end_CG
