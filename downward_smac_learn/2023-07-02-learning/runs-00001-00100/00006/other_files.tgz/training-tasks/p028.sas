begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var30
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var29
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var28
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var26
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
end_variable
begin_variable
var25
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var23
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
0
begin_state
3
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
1
end_state
begin_goal
6
3 0
5 0
7 0
9 0
11 0
20 0
end_goal
68
begin_operator
calibrate rover1 camera1 objective3 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint1 waypoint4
2
0 0
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint5 waypoint4
2
0 4
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint1 waypoint4
2
0 0
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint5 waypoint4
2
0 4
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint1 waypoint4
2
0 0
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint5 waypoint4
2
0 4
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint1 waypoint4
2
0 0
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint5 waypoint4
2
0 4
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint1 waypoint4
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint5 waypoint4
2
0 4
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint4 waypoint1 waypoint4
2
0 0
17 1
1
0 20 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint4 waypoint5 waypoint4
2
0 4
17 1
1
0 20 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 19 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 0 0 2
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint5
0
1
0 0 1 4
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint1
0
1
0 0 2 0
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 colour
1
0 2
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 high_res
1
0 2
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 low_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
2
0 1 0 1
0 10 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 colour
1
0 3
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 high_res
1
0 3
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 colour
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 high_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 low_res
1
0 3
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 colour
1
0 4
2
0 1 0 1
0 10 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 high_res
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 low_res
1
0 4
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera1 colour
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera1 high_res
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera1 low_res
1
0 4
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 12
check 3
0
17
18
switch 19
check 0
check 1
25
check 0
check 0
check 0
switch 17
check 0
check 0
check 1
14
switch 1
check 0
check 9
32
33
34
35
36
37
38
39
40
check 0
switch 10
check 0
check 1
4
check 0
switch 8
check 0
check 1
6
check 0
switch 6
check 0
check 1
8
check 0
switch 4
check 0
check 1
10
check 0
switch 2
check 0
check 1
12
check 0
check 0
switch 12
check 2
1
19
check 0
check 0
switch 16
check 0
switch 19
check 0
check 1
29
check 0
check 0
check 0
switch 1
check 0
check 6
41
42
43
44
45
46
check 0
check 0
switch 12
check 1
20
check 0
check 0
switch 13
check 0
switch 19
check 0
check 1
26
check 0
check 0
check 0
switch 1
check 0
check 6
47
48
49
50
51
52
check 0
check 0
switch 12
check 3
2
21
22
check 0
check 0
switch 14
check 0
switch 19
check 0
check 1
27
check 0
check 0
check 0
switch 17
check 0
switch 19
check 0
check 1
30
check 0
check 0
check 0
switch 1
check 0
check 9
53
54
55
56
57
58
59
60
61
check 0
check 0
switch 12
check 3
3
23
24
check 0
check 0
switch 15
check 0
switch 19
check 0
check 1
28
check 0
check 0
check 0
switch 17
check 0
check 0
check 1
15
switch 18
check 0
switch 19
check 0
check 1
31
check 0
check 0
check 0
switch 1
check 0
check 6
62
63
64
65
66
67
check 0
switch 10
check 0
check 1
5
check 0
switch 8
check 0
check 1
7
check 0
switch 6
check 0
check 1
9
check 0
switch 4
check 0
check 1
11
check 0
switch 2
check 0
check 1
13
check 0
check 0
switch 19
check 0
check 0
check 1
16
check 0
end_SG
begin_DTG
2
2
17
0
3
18
0
1
4
19
0
1
0
20
0
2
0
21
0
4
22
0
2
1
23
0
3
24
0
end_DTG
begin_DTG
5
1
59
1
0 3
1
51
1
0 2
1
62
1
0 4
1
41
1
0 1
1
33
1
0 0
4
0
0
1
0 0
0
1
1
0 1
0
2
1
0 3
0
3
1
0 4
end_DTG
begin_DTG
0
4
0
40
2
0 0
1 0
0
46
2
0 1
1 0
0
61
2
0 3
1 0
0
67
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
12
2
0 0
2 0
0
13
2
0 4
2 0
end_DTG
begin_DTG
0
3
0
36
2
0 0
1 0
0
51
2
0 2
1 0
0
57
2
0 3
1 0
end_DTG
begin_DTG
0
2
0
10
2
0 0
4 0
0
11
2
0 4
4 0
end_DTG
begin_DTG
0
3
0
35
2
0 0
1 0
0
50
2
0 2
1 0
0
56
2
0 3
1 0
end_DTG
begin_DTG
0
2
0
8
2
0 0
6 0
0
9
2
0 4
6 0
end_DTG
begin_DTG
0
5
0
34
2
0 0
1 0
0
43
2
0 1
1 0
0
49
2
0 2
1 0
0
55
2
0 3
1 0
0
64
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
6
2
0 0
8 0
0
7
2
0 4
8 0
end_DTG
begin_DTG
0
5
0
32
2
0 0
1 0
0
41
2
0 1
1 0
0
47
2
0 2
1 0
0
53
2
0 3
1 0
0
62
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
4
2
0 0
10 0
0
5
2
0 4
10 0
end_DTG
begin_DTG
1
1
25
2
0 0
19 0
0
end_DTG
begin_DTG
1
1
26
2
0 2
19 0
0
end_DTG
begin_DTG
1
1
27
2
0 3
19 0
0
end_DTG
begin_DTG
1
1
28
2
0 4
19 0
0
end_DTG
begin_DTG
1
1
29
2
0 1
19 0
0
end_DTG
begin_DTG
1
1
30
2
0 3
19 0
0
end_DTG
begin_DTG
1
1
31
2
0 4
19 0
0
end_DTG
begin_DTG
7
1
25
2
0 0
12 0
1
26
2
0 2
13 0
1
27
2
0 3
14 0
1
28
2
0 4
15 0
1
29
2
0 1
16 0
1
30
2
0 3
17 0
1
31
2
0 4
18 0
1
0
16
0
end_DTG
begin_DTG
0
2
0
14
2
0 0
17 1
0
15
2
0 4
17 1
end_DTG
begin_CG
20
12 1
13 1
14 1
15 1
16 1
17 1
18 1
1 40
11 2
9 2
7 2
5 2
3 2
20 2
19 7
10 5
8 5
6 3
4 3
2 4
5
10 5
8 5
6 3
4 3
2 4
1
3 2
0
1
5 2
0
1
7 2
0
1
9 2
0
1
11 2
0
1
19 1
1
19 1
1
19 1
1
19 1
1
19 1
2
20 2
19 1
1
19 1
7
12 1
13 1
14 1
15 1
16 1
17 1
18 1
0
end_CG
