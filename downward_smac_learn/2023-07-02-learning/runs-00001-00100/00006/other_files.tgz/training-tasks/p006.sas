begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var1
-1
2
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var27
-1
2
Atom have_image(rover2, objective3, high_res)
NegatedAtom have_image(rover2, objective3, high_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var28
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var0
-1
3
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var26
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var25
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var22
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var23
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var19
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var21
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var20
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var18
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var17
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var16
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
1
1
1
1
1
1
end_state
begin_goal
11
3 0
6 0
10 0
12 0
14 0
23 0
24 0
25 0
26 0
27 0
28 0
end_goal
56
begin_operator
calibrate rover1 camera2 objective2 waypoint1
1
7 0
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective3 waypoint3
1
0 1
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective3 waypoint3
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint2 waypoint1
2
7 1
13 0
1
0 14 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint3 waypoint1
2
7 2
13 0
1
0 14 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint2 waypoint1
2
7 1
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint3 waypoint1
2
7 2
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint2 waypoint1
2
7 1
9 0
1
0 10 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint3 waypoint1
2
7 2
9 0
1
0 10 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective3 high_res waypoint2 waypoint1
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




int2
1
7 1
2
0 19 0 1
0 20 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
7 2
2
0 22 0 1
0 20 0 1
0
end_operator
begin_operator
sample_soil rover2 rover2store waypoint2
1
0 0
2
0 19 0 2
0 21 0 1
0
end_operator
begin_operator
sample_soil rover2 rover2store waypoint3
1
0 1
2
0 22 0 2
0 21 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera2 colour
1
7 0
2
0 8 0 1
0 13 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective2 camera2 colour
1
7 0
2
0 8 0 1
0 11 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective3 camera2 colour
1
7 2
2
0 8 0 1
0 9 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint3 objective3 camera1 low_res
1
0 1
2
0 4 0 1
0 5 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint3 objective3 camera3 high_res
1
0 1
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 7
check 0
switch 0
check 3
0
35
36
check 0
check 0
switch 15
check 0
switch 20
check 0
check 1
41
check 0
check 0
check 0
switch 16
check 0
switch 20
check 0
check 1
46
check 0
check 0
check 0
switch 8
check 0
check 2
51
52
check 0
check 0
switch 0
check 1
37
check 0
check 0
switch 15
check 0
check 0
check 1
13
switch 17
check 0
switch 20
check 0
check 1
42
check 0
check 0
check 1
15
check 0
switch 18
check 0
check 0
check 1
17
check 0
switch 16
check 0
check 0
check 1
23
switch 19
check 0
switch 20
check 0
check 1
47
check 0
check 0
check 1
25
check 0
switch 22
check 0
check 0
check 1
27
check 0
switch 13
check 0
check 1
3
check 0
switch 11
check 0
check 1
5
check 0
switch 9
check 0
check 1
7
check 0
check 0
switch 0
check 1
38
check 0
check 0
switch 15
check 0
check 0
check 1
14
switch 17
check 0
check 0
check 1
16
check 0
switch 18
check 0
switch 20
check 0
check 1
43
check 0
check 0
check 1
18
check 0
switch 16
check 0
check 0
check 1
24
switch 19
check 0
check 0
check 1
26
check 0
switch 22
check 0
switch 20
check 0
check 1
48
check 0
check 0
check 1
28
check 0
switch 8
check 0
check 1
53
check 0
switch 13
check 0
check 1
4
check 0
switch 11
check 0
check 1
6
check 0
switch 9
check 0
check 1
8
check 0
check 0
switch 0
check 0
switch 15
check 1
39
check 0
check 0
switch 17
check 0
switch 21
check 0
check 1
44
check 0
check 0
check 0
check 1
19
switch 18
check 0
check 0
check 0
check 1
21
switch 19
check 0
switch 21
check 0
check 1
49
check 0
check 0
check 0
check 1
29
switch 22
check 0
check 0
check 0
check 1
31
switch 2
check 0
check 1
9
check 0
switch 5
check 0
check 1
11
check 0
check 0
switch 15
check 3
1
2
40
check 0
check 0
switch 17
check 0
check 0
check 0
check 1
20
switch 18
check 0
switch 21
check 0
check 1
45
check 0
check 0
check 0
check 1
22
switch 19
check 0
check 0
check 0
check 1
30
switch 22
check 0
switch 21
check 0
check 1
50
check 0
check 0
check 0
check 1
32
switch 4
check 0
check 1
54
check 0
switch 1
check 0
check 1
55
check 0
switch 2
check 0
check 1
10
check 0
switch 5
check 0
check 1
12
check 0
check 0
switch 20
check 0
check 0
check 1
33
switch 21
check 0
check 0
check 1
34
check 0
end_SG
begin_DTG
1
1
39
0
1
0
40
0
end_DTG
begin_DTG
1
1
55
1
0 1
1
0
2
1
0 1
end_DTG
begin_DTG
0
1
0
55
2
0 1
1 0
end_DTG
begin_DTG
0
2
0
9
2
0 0
2 0
0
10
2
0 1
2 0
end_DTG
begin_DTG
1
1
54
1
0 1
1
0
1
1
0 1
end_DTG
begin_DTG
0
1
0
54
2
0 1
4 0
end_DTG
begin_DTG
0
2
0
11
2
0 0
5 0
0
12
2
0 1
5 0
end_DTG
begin_DTG
2
1
35
0
2
36
0
1
0
37
0
1
0
38
0
end_DTG
begin_DTG
2
1
51
1
7 0
1
53
1
7 2
1
0
0
1
7 0
end_DTG
begin_DTG
0
1
0
53
2
7 2
8 0
end_DTG
begin_DTG
0
2
0
7
2
7 1
9 0
0
8
2
7 2
9 0
end_DTG
begin_DTG
0
1
0
52
2
7 0
8 0
end_DTG
begin_DTG
0
2
0
5
2
7 1
11 0
0
6
2
7 2
11 0
end_DTG
begin_DTG
0
1
0
51
2
7 0
8 0
end_DTG
begin_DTG
0
2
0
3
2
7 1
13 0
0
4
2
7 2
13 0
end_DTG
begin_DTG
1
1
41
2
7 0
20 0
0
end_DTG
begin_DTG
1
1
46
2
7 0
20 0
0
end_DTG
begin_DTG
2
1
42
2
7 1
20 0
2
44
2
0 0
21 0
0
0
end_DTG
begin_DTG
2
1
43
2
7 2
20 0
2
45
2
0 1
21 0
0
0
end_DTG
begin_DTG
2
1
47
2
7 1
20 0
2
49
2
0 0
21 0
0
0
end_DTG
begin_DTG
6
1
41
2
7 0
15 0
1
42
2
7 1
17 0
1
43
2
7 2
18 0
1
46
2
7 0
16 0
1
47
2
7 1
19 0
1
48
2
7 2
22 0
1
0
33
0
end_DTG
begin_DTG
4
1
44
2
0 0
17 0
1
45
2
0 1
18 0
1
49
2
0 0
19 0
1
50
2
0 1
22 0
1
0
34
0
end_DTG
begin_DTG
2
1
48
2
7 2
20 0
2
50
2
0 1
21 0
0
0
end_DTG
begin_DTG
0
2
0
23
2
7 1
16 1
0
24
2
7 2
16 1
end_DTG
begin_DTG
0
4
0
27
2
7 1
22 1
0
28
2
7 2
22 1
0
31
2
0 0
22 2
0
32
2
0 1
22 2
end_DTG
begin_DTG
0
4
0
25
2
7 1
19 1
0
26
2
7 2
19 1
0
29
2
0 0
19 2
0
30
2
0 1
19 2
end_DTG
begin_DTG
0
4
0
17
2
7 1
18 1
0
18
2
7 2
18 1
0
21
2
0 0
18 2
0
22
2
0 1
18 2
end_DTG
begin_DTG
0
4
0
15
2
7 1
17 1
0
16
2
7 2
17 1
0
19
2
0 0
17 2
0
20
2
0 1
17 2
end_DTG
begin_DTG
0
2
0
13
2
7 1
15 1
0
14
2
7 2
15 1
end_DTG
begin_CG
15
17 1
18 1
19 1
22 1
4 2
1 2
3 2
6 2
27 2
26 2
25 2
24 2
21 4
2 1
5 1
1
2 1
1
3 2
0
1
5 1
1
6 2
0
20
15 1
17 1
18 1
16 1
19 1
22 1
8 4
14 2
12 2
10 2
28 2
27 2
26 2
23 2
25 2
24 2
20 6
13 1
11 1
9 1
3
13 1
11 1
9 1
1
10 2
0
1
12 2
0
1
14 2
0
2
28 2
20 1
2
23 2
20 1
3
27 4
20 1
21 1
3
26 4
20 1
21 1
3
25 4
20 1
21 1
6
15 1
17 1
18 1
16 1
19 1
22 1
4
17 1
18 1
19 1
22 1
3
24 4
20 1
21 1
0
0
0
0
0
0
end_CG
