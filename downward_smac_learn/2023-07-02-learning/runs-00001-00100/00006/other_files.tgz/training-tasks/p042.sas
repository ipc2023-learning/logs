begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var30
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var31
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var24
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var23
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
1
2
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
1
end_state
begin_goal
7
4 0
7 0
9 0
11 0
21 0
22 0
23 0
end_goal
105
begin_operator
calibrate rover1 camera1 objective4 waypoint6
1
1 5
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective2 waypoint2
1
1 1
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective2 waypoint3
1
1 2
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective2 waypoint6
1
1 5
1
0 2 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint2 waypoint3
2
1 1
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint6 waypoint3
2
1 5
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint2 waypoint3
2
1 1
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint6 waypoint3
2
1 5
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint2 waypoint3
2
1 1
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint6 waypoint3
2
1 5
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint2 waypoint3
2
1 1
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 low_res waypoint6 waypoint3
2
1 5
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint2 waypoint3
2
1 1
15 1
1
0 23 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint6 waypoint3
2
1 5
15 1
1
0 23 -1 0
0
end_operator
begin_operator
communicate_rock_data rover




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




es
1
1 5
1
0 2 0 1
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 1
26
check 0
check 0
check 0
check 0
check 0
check 0
switch 15
check 0
switch 18
check 0
check 1
50
check 0
check 0
check 0
check 0
switch 5
check 0
check 2
61
62
check 0
switch 2
check 0
check 2
63
64
check 0
check 0
switch 0
check 3
1
27
28
check 0
check 0
check 0
check 0
check 0
check 0
switch 15
check 0
check 0
check 1
12
check 0
switch 16
check 0
switch 18
check 0
check 1
51
check 0
check 0
check 1
14
check 0
switch 20
check 0
check 0
check 1
16
check 0
switch 5
check 0
check 4
65
66
69
70
check 0
switch 2
check 0
check 4
67
68
71
72
check 0
switch 10
check 0
check 1
4
check 0
switch 3
check 0
check 1
6
check 0
switch 8
check 0
check 1
8
check 0
switch 6
check 0
check 1
10
check 0
check 0
switch 0
check 2
2
29
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 4
73
74
77
78
check 0
switch 2
check 0
check 4
75
76
79
80
check 0
check 0
switch 0
check 1
30
check 0
check 0
check 0
check 0
check 0
check 0
switch 17
check 0
switch 18
check 0
check 1
52
check 0
check 0
check 0
check 0
switch 5
check 0
check 2
81
82
check 0
switch 2
check 0
check 2
83
84
check 0
check 0
switch 0
check 2
31
32
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 4
85
86
89
90
check 0
switch 2
check 0
check 4
87
88
91
92
check 0
check 0
switch 0
check 7
0
3
33
34
35
36
37
check 0
check 0
check 0
check 0
check 0
check 0
switch 15
check 0
check 0
check 1
13
check 0
switch 16
check 0
check 0
check 1
15
check 0
switch 20
check 0
switch 18
check 0
check 1
53
check 0
check 0
check 1
17
check 0
switch 5
check 0
check 6
93
94
97
98
101
102
check 0
switch 2
check 0
check 6
95
96
99
100
103
104
check 0
switch 10
check 0
check 1
5
check 0
switch 3
check 0
check 1
7
check 0
switch 8
check 0
check 1
9
check 0
switch 6
check 0
check 1
11
check 0
check 0
switch 0
check 0
switch 15
check 2
38
39
switch 19
check 0
check 1
54
check 0
check 0
check 0
check 0
switch 12
check 0
switch 19
check 0
check 1
58
check 0
check 0
check 0
check 0
switch 15
check 1
40
check 0
check 0
check 1
18
switch 16
check 0
switch 19
check 0
check 1
55
check 0
check 0
check 0
check 1
20
switch 20
check 0
check 0
check 0
check 1
22
check 0
switch 15
check 1
41
check 0
check 0
check 0
switch 13
check 0
switch 19
check 0
check 1
59
check 0
check 0
check 0
check 0
switch 15
check 1
42
check 0
check 0
check 0
switch 17
check 0
switch 19
check 0
check 1
56
check 0
check 0
check 0
check 0
check 0
check 2
43
44
switch 15
check 5
45
46
47
48
49
check 0
check 0
check 1
19
switch 16
check 0
check 0
check 0
check 1
21
switch 20
check 0
switch 19
check 0
check 1
57
check 0
check 0
check 0
check 1
23
switch 14
check 0
switch 19
check 0
check 1
60
check 0
check 0
check 0
check 0
switch 18
check 0
check 0
check 1
24
switch 19
check 0
check 0
check 1
25
check 0
end_SG
begin_DTG
2
4
38
0
5
39
0
1
5
40
0
1
5
41
0
1
5
42
0
2
0
43
0
5
44
0
5
0
45
0
1
46
0
2
47
0
3
48
0
4
49
0
end_DTG
begin_DTG
1
5
26
0
2
4
27
0
5
28
0
1
5
29
0
1
5
30
0
2
1
31
0
5
32
0
5
0
33
0
1
34
0
2
35
0
3
36
0
4
37
0
end_DTG
begin_DTG
6
1
84
1
1 3
1
104
1
1 5
1
92
1
1 4
1
63
1
1 0
1
80
1
1 2
1
72
1
1 1
3
0
1
1
1 1
0
2
1
1 2
0
3
1
1 5
end_DTG
begin_DTG
0
3
0
68
2
1 1
2 0
0
76
2
1 2
2 0
0
96
2
1 5
2 0
end_DTG
begin_DTG
0
2
0
6
2
1 1
3 0
0
7
2
1 5
3 0
end_DTG
begin_DTG
6
1
82
1
1 3
1
102
1
1 5
1
90
1
1 4
1
61
1
1 0
1
78
1
1 2
1
70
1
1 1
1
0
0
1
1 5
end_DTG
begin_DTG
0
6
0
62
2
1 0
5 0
0
70
2
1 1
5 0
0
78
2
1 2
5 0
0
82
2
1 3
5 0
0
90
2
1 4
5 0
0
98
2
1 5
5 0
end_DTG
begin_DTG
0
2
0
10
2
1 1
6 0
0
11
2
1 5
6 0
end_DTG
begin_DTG
0
12
0
61
2
1 0
5 0
0
63
2
1 0
2 0
0
69
2
1 1
5 0
0
71
2
1 1
2 0
0
77
2
1 2
5 0
0
79
2
1 2
2 0
0
81
2
1 3
5 0
0
83
2
1 3
2 0
0
89
2
1 4
5 0
0
91
2
1 4
2 0
0
97
2
1 5
5 0
0
99
2
1 5
2 0
end_DTG
begin_DTG
0
2
0
8
2
1 1
8 0
0
9
2
1 5
8 0
end_DTG
begin_DTG
0
1
0
86
2
1 4
5 0
end_DTG
begin_DTG
0
2
0
4
2
1 1
10 0
0
5
2
1 5
10 0
end_DTG
begin_DTG
1
1
58
2
0 0
19 0
0
end_DTG
begin_DTG
1
1
59
2
0 2
19 0
0
end_DTG
begin_DTG
1
1
60
2
0 5
19 0
0
end_DTG
begin_DTG
2
1
50
2
1 0
18 0
2
54
2
0 0
19 0
0
0
end_DTG
begin_DTG
2
1
51
2
1 1
18 0
2
55
2
0 1
19 0
0
0
end_DTG
begin_DTG
2
1
52
2
1 3
18 0
2
56
2
0 3
19 0
0
0
end_DTG
begin_DTG
4
1
50
2
1 0
15 0
1
51
2
1 1
16 0
1
52
2
1 3
17 0
1
53
2
1 5
20 0
1
0
24
0
end_DTG
begin_DTG
7
1
54
2
0 0
15 0
1
55
2
0 1
16 0
1
56
2
0 3
17 0
1
57
2
0 5
20 0
1
58
2
0 0
12 0
1
59
2
0 2
13 0
1
60
2
0 5
14 0
1
0
25
0
end_DTG
begin_DTG
2
1
53
2
1 5
18 0
2
57
2
0 5
19 0
0
0
end_DTG
begin_DTG
0
4
0
16
2
1 1
20 1
0
17
2
1 5
20 1
0
22
2
0 1
20 2
0
23
2
0 5
20 2
end_DTG
begin_DTG
0
4
0
14
2
1 1
16 1
0
15
2
1 5
16 1
0
20
2
0 1
16 2
0
21
2
0 5
16 2
end_DTG
begin_DTG
0
4
0
12
2
1 1
15 1
0
13
2
1 5
15 1
0
18
2
0 1
15 2
0
19
2
0 5
15 2
end_DTG
begin_CG
11
15 1
16 1
17 1
20 1
12 1
13 1
14 1
23 2
22 2
21 2
19 7
18
15 1
16 1
17 1
20 1
5 23
2 25
11 2
4 2
9 2
7 2
23 2
22 2
21 2
18 4
10 1
3 3
8 12
6 6
2
3 3
8 6
1
4 2
0
3
10 1
8 6
6 6
1
7 2
0
1
9 2
0
1
11 2
0
1
19 1
1
19 1
1
19 1
3
23 4
18 1
19 1
3
22 4
18 1
19 1
2
18 1
19 1
4
15 1
16 1
17 1
20 1
7
15 1
16 1
17 1
20 1
12 1
13 1
14 1
3
21 4
18 1
19 1
0
0
0
end_CG
