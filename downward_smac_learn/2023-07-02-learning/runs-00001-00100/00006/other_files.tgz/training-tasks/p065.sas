begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover3)
NegatedAtom calibrated(camera2, rover3)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var57
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover3, objective3, low_res)
NegatedAtom have_image(rover3, objective3, low_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var3
-1
4
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var4
-1
4
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var5
-1
4
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var6
-1
4
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover1, waypoint8)
Atom have_rock_analysis(rover2, waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
end_variable
begin_variable
var7
-1
4
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
Atom have_soil_analysis(rover3, waypoint1)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var43
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var44
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var9
-1
4
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var10
-1
4
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var45
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var38
-1
2
Atom communicated_rock_data(waypoint8)
NegatedAtom communicated_rock_data(waypoint8)
end_variable
0
begin_state
2
1
1
1
1
1
1
7
7
0
0
0
0
0
0
0
0
0
0
0
1
end_state
begin_goal
3
4 0
6 0
20 0
end_goal
252
begin_operator
calibrate rover3 camera1 objective1 waypoint6
1
0 5
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover3 camera2 objective1 waypoint6
1
0 5
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover3 general objective3 low_res waypoint1 waypoint3
2
0 0
5 0
1
0 6 -1 0
0
end_operator
begin_operator
communicate_image_data rover3 general objective3 low_res waypoint6 waypoint3
2
0 5
5 0
1
0 6 -1 0
0
end_operator
begin_operator
communicate_image_data rover3 general objective3 low_res waypoint7 waypoint3
2
0 6
5 0
1
0 6 -1 0
0
end_operator
begin_operator
communicate_image_data rover3 general objective4 low_res waypoint1 waypoint3
2
0 0
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_image_data rover3 general objective4 low_res waypoint6 waypoint3
2
0 5
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_image_data rover3 general objective4 low_res waypoint7 waypoint3
2
0 6
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint8 waypoint1 waypoint3
2
8 0
12 1
1
0 20 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint8 waypoint6 waypoint3
2
8 5
12 1
1
0 20 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint8 waypoint7 waypoint3
2
8 6
12 1
1
0 20 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint8 waypoint1 waypoint3
2
7 0
12 2
1
0 20 -1 0
0
end_operator
begin_o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
check 2
56
57
check 0
check 0
check 0
check 0
switch 14
check 0
switch 19
check 0
check 1
93
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 9
126
127
128
132
133
134
138
139
140
check 0
switch 1
check 0
check 9
129
130
131
135
136
137
141
142
143
check 0
check 0
switch 9
check 2
58
59
switch 19
check 0
check 1
80
check 0
check 0
check 0
check 0
check 0
switch 17
check 0
switch 19
check 0
check 1
94
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 9
144
145
146
150
151
152
156
157
158
check 0
switch 1
check 0
check 9
147
148
149
153
154
155
159
160
161
check 0
check 0
switch 9
check 3
60
61
62
check 0
check 0
check 0
check 0
switch 10
check 0
switch 19
check 0
check 1
81
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 6
162
163
164
168
169
170
check 0
switch 1
check 0
check 6
165
166
167
171
172
173
check 0
check 0
switch 9
check 2
63
64
check 0
check 0
check 0
check 0
switch 2
check 0
check 9
174
175
176
180
181
182
186
187
188
check 0
switch 1
check 0
check 9
177
178
179
183
184
185
189
190
191
check 0
check 0
switch 9
check 5
0
1
65
66
67
check 0
check 0
check 0
check 0
switch 11
check 0
switch 19
check 0
check 1
82
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
check 0
check 0
check 0
check 1
15
switch 2
check 0
check 12
192
193
194
198
199
200
204
205
206
210
211
212
check 0
switch 1
check 0
check 12
195
196
197
201
202
203
207
208
209
213
214
215
check 0
switch 5
check 0
check 1
3
check 0
switch 3
check 0
check 1
6
check 0
check 0
switch 9
check 2
68
69
check 0
check 0
check 0
check 0
switch 12
check 0
check 0
check 0
check 0
check 1
16
switch 18
check 0
switch 19
check 0
check 1
95
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 9
216
217
218
222
223
224
228
229
230
check 0
switch 1
check 0
check 9
219
220
221
225
226
227
231
232
233
check 0
switch 5
check 0
check 1
4
check 0
switch 3
check 0
check 1
7
check 0
check 0
switch 9
check 2
70
71
check 0
check 0
check 0
check 0
switch 12
check 0
switch 19
check 0
check 1
83
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 9
234
235
236
240
241
242
246
247
248
check 0
switch 1
check 0
check 9
237
238
239
243
244
245
249
250
251
check 0
check 0
switch 15
check 0
check 0
check 1
17
switch 16
check 0
check 0
check 1
18
switch 19
check 0
check 0
check 1
19
check 0
end_SG
begin_DTG
4
2
52
0
3
53
0
6
54
0
7
55
0
2
3
56
0
5
57
0
2
0
58
0
5
59
0
3
0
60
0
1
61
0
4
62
0
2
3
63
0
7
64
0
3
1
65
0
2
66
0
6
67
0
2
0
68
0
5
69
0
2
0
70
0
4
71
0
end_DTG
begin_DTG
8
1
196
1
0 5
1
191
1
0 4
1
233
1
0 6
1
251
1
0 7
1
118
1
0 0
1
136
1
0 1
1
155
1
0 2
1
173
1
0 3
1
0
1
1
0 5
end_DTG
begin_DTG
8
1
193
1
0 5
1
188
1
0 4
1
230
1
0 6
1
248
1
0 7
1
115
1
0 0
1
133
1
0 1
1
152
1
0 2
1
170
1
0 3
1
0
0
1
0 5
end_DTG
begin_DTG
0
4
0
104
2
0 0
2 0
0
107
2
0 0
1 0
0
218
2
0 6
2 0
0
221
2
0 6
1 0
end_DTG
begin_DTG
0
3
0
5
2
0 0
3 0
0
6
2
0 5
3 0
0
7
2
0 6
3 0
end_DTG
begin_DTG
0
6
0
98
2
0 0
2 0
0
101
2
0 0
1 0
0
146
2
0 2
2 0
0
149
2
0 2
1 0
0
236
2
0 7
2 0
0
239
2
0 7
1 0
end_DTG
begin_DTG
0
3
0
2
2
0 0
5 0
0
3
2
0 5
5 0
0
4
2
0 6
5 0
end_DTG
begin_DTG
3
2
38
0
6
39
0
7
40
0
2
3
41
0
5
42
0
1
0
43
0
2
1
44
0
4
45
0
1
3
46
0
2
1
47
0
6
48
0
2
0
49
0
5
50
0
1
0
51
0
end_DTG
begin_DTG
3
2
20
0
6
21
0
7
22
0
3
3
23
0
5
24
0
6
25
0
2
0
26
0
5
27
0
2
1
28
0
4
29
0
1
3
30
0
3
1
31
0
2
32
0
6
33
0
3
0
34
0
1
35
0
5
36
0
1
0
37
0
end_DTG
begin_DTG
3
1
72
2
8 2
15 0
2
76
2
7 2
16 0
3
80
2
0 2
19 0
0
0
0
end_DTG
begin_DTG
3
1
73
2
8 3
15 0
2
77
2
7 3
16 0
3
81
2
0 3
19 0
0
0
0
end_DTG
begin_DTG
3
1
74
2
8 5
15 0
2
78
2
7 5
16 0
3
82
2
0 5
19 0
0
0
0
end_DTG
begin_DTG
3
1
75
2
8 7
15 0
2
79
2
7 7
16 0
3
83
2
0 7
19 0
0
0
0
end_DTG
begin_DTG
3
1
84
2
8 0
15 0
2
88
2
7 0
16 0
3
92
2
0 0
19 0
0
0
0
end_DTG
begin_DTG
3
1
85
2
8 1
15 0
2
89
2
7 1
16 0
3
93
2
0 1
19 0
0
0
0
end_DTG
begin_DTG
8
1
72
2
8 2
9 0
1
73
2
8 3
10 0
1
74
2
8 5
11 0
1
75
2
8 7
12 0
1
84
2
8 0
13 0
1
85
2
8 1
14 0
1
86
2
8 2
17 0
1
87
2
8 6
18 0
1
0
17
0
end_DTG
begin_DTG
8
1
76
2
7 2
9 0
1
77
2
7 3
10 0
1
78
2
7 5
11 0
1
79
2
7 7
12 0
1
88
2
7 0
13 0
1
89
2
7 1
14 0
1
90
2
7 2
17 0
1
91
2
7 6
18 0
1
0
18
0
end_DTG
begin_DTG
3
1
86
2
8 2
15 0
2
90
2
7 2
16 0
3
94
2
0 2
19 0
0
0
0
end_DTG
begin_DTG
3
1
87
2
8 6
15 0
2
91
2
7 6
16 0
3
95
2
0 6
19 0
0
0
0
end_DTG
begin_DTG
8
1
80
2
0 2
9 0
1
81
2
0 3
10 0
1
82
2
0 5
11 0
1
83
2
0 7
12 0
1
92
2
0 0
13 0
1
93
2
0 1
14 0
1
94
2
0 2
17 0
1
95
2
0 6
18 0
1
0
19
0
end_DTG
begin_DTG
0
9
0
8
2
8 0
12 1
0
9
2
8 5
12 1
0
10
2
8 6
12 1
0
11
2
7 0
12 2
0
12
2
7 5
12 2
0
13
2
7 6
12 2
0
14
2
0 0
12 3
0
15
2
0 5
12 3
0
16
2
0 6
12 3
end_DTG
begin_CG
16
9 1
10 1
11 1
12 1
13 1
14 1
17 1
18 1
2 79
1 79
6 3
4 3
20 3
19 8
5 6
3 4
2
5 3
3 2
2
5 3
3 2
1
4 3
0
1
6 3
0
10
9 1
10 1
11 1
12 1
13 1
14 1
17 1
18 1
20 3
16 8
10
9 1
10 1
11 1
12 1
13 1
14 1
17 1
18 1
20 3
15 8
3
15 1
16 1
19 1
3
15 1
16 1
19 1
3
15 1
16 1
19 1
4
20 9
15 1
16 1
19 1
3
15 1
16 1
19 1
3
15 1
16 1
19 1
8
9 1
10 1
11 1
12 1
13 1
14 1
17 1
18 1
8
9 1
10 1
11 1
12 1
13 1
14 1
17 1
18 1
3
15 1
16 1
19 1
3
15 1
16 1
19 1
8
9 1
10 1
11 1
12 1
13 1
14 1
17 1
18 1
0
end_CG
