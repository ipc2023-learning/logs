begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var0
-1
4
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
end_variable
begin_variable
var5
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var16
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var8
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var15
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var7
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var14
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var6
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
0
begin_state
0
1
1
1
1
1
1
1
end_state
begin_goal
3
3 0
5 0
7 0
end_goal
20
begin_operator
calibrate rover1 camera1 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint1 waypoint3
2
0 0
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint4 waypoint3
2
0 3
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint1 waypoint3
2
0 0
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint4 waypoint3
2
0 3
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint1 waypoint3
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint4 waypoint3
2
0 3
2 0
1
0 3 -1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 0 0 1
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint1
0
1
0 0 1 0
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint4
0
1
0 0 2 3
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint3
0
1
0 0 3 2
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 colour
1
0 1
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 high_res
1
0 1
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 low_res
1
0 1
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 1
check 3
0
8
9
check 3
14
15
16
check 0
switch 6
check 0
check 1
2
check 0
switch 4
check 0
check 1
4
check 0
switch 2
check 0
check 1
6
check 0
check 0
switch 1
check 2
1
10
check 3
17
18
19
check 0
check 0
check 1
11
switch 1
check 2
12
13
check 0
check 0
switch 6
check 0
check 1
3
check 0
switch 4
check 0
check 1
5
check 0
switch 2
check 0
check 1
7
check 0
check 0
check 0
end_SG
begin_DTG
2
1
8
0
3
9
0
1
0
10
0
1
3
11
0
2
0
12
0
2
13
0
end_DTG
begin_DTG
2
1
14
1
0 0
1
17
1
0 1
2
0
0
1
0 0
0
1
1
0 1
end_DTG
begin_DTG
0
2
0
16
2
0 0
1 0
0
19
2
0 1
1 0
end_DTG
begin_DTG
0
2
0
6
2
0 0
2 0
0
7
2
0 3
2 0
end_DTG
begin_DTG
0
2
0
15
2
0 0
1 0
0
18
2
0 1
1 0
end_DTG
begin_DTG
0
2
0
4
2
0 0
4 0
0
5
2
0 3
4 0
end_DTG
begin_DTG
0
2
0
14
2
0 0
1 0
0
17
2
0 1
1 0
end_DTG
begin_DTG
0
2
0
2
2
0 0
6 0
0
3
2
0 3
6 0
end_DTG
begin_CG
7
1 8
7 2
5 2
3 2
6 2
4 2
2 2
3
6 2
4 2
2 2
1
3 2
0
1
5 2
0
1
7 2
0
end_CG
