begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var29
-1
2
Atom have_image(rover2, objective1, high_res)
NegatedAtom have_image(rover2, objective1, high_res)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var28
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var7
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var30
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var26
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var27
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var24
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var22
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
0
begin_state
2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
3
0
0
0
0
0
0
0
1
1
end_state
begin_goal
9
3 0
5 0
7 0
9 0
12 0
14 0
16 0
25 0
26 0
end_goal
151
begin_operator
calibrate rover2 camera1 objective1 waypoint1
1
0 0
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint2
1
0 1
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint3
1
0 2
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint1 waypoint2
2
0 0
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint3 waypoint2
2
0 2
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint4 waypoint2
2
0 3
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint5 waypoint2
2
0 4
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint6 waypoint2
2
0 5
8 0
1
0 9 -1 0
0
end_operator
begin_operator
com




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 0
check 0
switch 21
check 0
switch 23
check 0
check 1
96
check 0
check 0
check 0
check 1
47
switch 18
check 0
check 0
check 1
52
switch 10
check 0
check 3
124
127
130
check 0
switch 1
check 0
check 6
125
126
128
129
131
132
check 0
switch 8
check 0
check 1
7
check 0
switch 6
check 0
check 1
12
check 0
switch 15
check 0
check 1
17
check 0
switch 13
check 0
check 1
22
check 0
switch 4
check 0
check 1
27
check 0
switch 11
check 0
check 1
32
check 0
switch 2
check 0
check 1
37
check 0
check 0
switch 20
check 3
83
84
85
check 0
check 0
check 0
switch 21
check 0
check 0
check 0
check 1
48
switch 24
check 0
switch 23
check 0
check 1
97
check 0
check 0
check 0
check 0
switch 18
check 0
check 0
check 1
53
switch 10
check 0
check 1
133
check 0
switch 1
check 0
check 2
134
135
check 0
switch 8
check 0
check 1
8
check 0
switch 6
check 0
check 1
13
check 0
switch 15
check 0
check 1
18
check 0
switch 13
check 0
check 1
23
check 0
switch 4
check 0
check 1
28
check 0
switch 11
check 0
check 1
33
check 0
switch 2
check 0
check 1
38
check 0
check 0
switch 20
check 4
86
87
88
89
check 0
check 0
check 0
switch 21
check 0
check 0
check 0
check 1
49
switch 18
check 0
check 0
check 1
54
switch 19
check 0
switch 23
check 0
check 1
99
check 0
check 0
check 0
switch 10
check 0
check 2
136
139
check 0
switch 1
check 0
check 4
137
138
140
141
check 0
switch 8
check 0
check 1
9
check 0
switch 6
check 0
check 1
14
check 0
switch 15
check 0
check 1
19
check 0
switch 13
check 0
check 1
24
check 0
switch 4
check 0
check 1
29
check 0
switch 11
check 0
check 1
34
check 0
switch 2
check 0
check 1
39
check 0
check 0
switch 20
check 2
90
91
check 0
check 0
check 0
switch 21
check 0
check 0
check 0
check 1
50
switch 18
check 0
check 0
check 1
55
switch 10
check 0
check 3
142
145
148
check 0
switch 1
check 0
check 6
143
144
146
147
149
150
check 0
switch 8
check 0
check 1
10
check 0
switch 6
check 0
check 1
15
check 0
switch 15
check 0
check 1
20
check 0
switch 13
check 0
check 1
25
check 0
switch 4
check 0
check 1
30
check 0
switch 11
check 0
check 1
35
check 0
switch 2
check 0
check 1
40
check 0
check 0
switch 22
check 0
check 0
check 1
56
switch 23
check 0
check 0
check 1
57
check 0
end_SG
begin_DTG
1
4
78
0
2
3
79
0
4
80
0
2
3
81
0
5
82
0
3
1
83
0
2
84
0
4
85
0
4
0
86
0
1
87
0
3
88
0
5
89
0
2
2
90
0
4
91
0
end_DTG
begin_DTG
6
1
140
1
0 4
1
128
1
0 2
1
134
1
0 3
1
143
1
0 5
1
114
1
0 1
1
102
1
0 0
3
0
3
1
0 0
0
4
1
0 1
0
5
1
0 2
end_DTG
begin_DTG
0
6
0
111
2
0 0
1 0
0
123
2
0 1
1 0
0
132
2
0 2
1 0
0
135
2
0 3
1 0
0
141
2
0 4
1 0
0
150
2
0 5
1 0
end_DTG
begin_DTG
0
5
0
36
2
0 0
2 0
0
37
2
0 2
2 0
0
38
2
0 3
2 0
0
39
2
0 4
2 0
0
40
2
0 5
2 0
end_DTG
begin_DTG
0
4
0
107
2
0 0
1 0
0
119
2
0 1
1 0
0
128
2
0 2
1 0
0
146
2
0 5
1 0
end_DTG
begin_DTG
0
5
0
26
2
0 0
4 0
0
27
2
0 2
4 0
0
28
2
0 3
4 0
0
29
2
0 4
4 0
0
30
2
0 5
4 0
end_DTG
begin_DTG
0
3
0
102
2
0 0
1 0
0
114
2
0 1
1 0
0
126
2
0 2
1 0
end_DTG
begin_DTG
0
5
0
11
2
0 0
6 0
0
12
2
0 2
6 0
0
13
2
0 3
6 0
0
14
2
0 4
6 0
0
15
2
0 5
6 0
end_DTG
begin_DTG
0
3
0
101
2
0 0
1 0
0
113
2
0 1
1 0
0
125
2
0 2
1 0
end_DTG
begin_DTG
0
5
0
6
2
0 0
8 0
0
7
2
0 2
8 0
0
8
2
0 3
8 0
0
9
2
0 4
8 0
0
10
2
0 5
8 0
end_DTG
begin_DTG
6
1
124
1
0 2
1
148
1
0 5
1
139
1
0 4
1
133
1
0 3
1
100
1
0 0
1
121
1
0 1
3
0
0
1
0 0
0
1
1
0 1
0
2
1
0 2
end_DTG
begin_DTG
0
4
0
106
2
0 0
10 0
0
118
2
0 1
10 0
0
127
2
0 2
10 0
0
145
2
0 5
10 0
end_DTG
begin_DTG
0
5
0
31
2
0 0
11 0
0
32
2
0 2
11 0
0
33
2
0 3
11 0
0
34
2
0 4
11 0
0
35
2
0 5
11 0
end_DTG
begin_DTG
0
4
0
103
2
0 0
10 0
0
115
2
0 1
10 0
0
136
2
0 4
10 0
0
142
2
0 5
10 0
end_DTG
begin_DTG
0
5
0
21
2
0 0
13 0
0
22
2
0 2
13 0
0
23
2
0 3
13 0
0
24
2
0 4
13 0
0
25
2
0 5
13 0
end_DTG
begin_DTG
0
3
0
100
2
0 0
10 0
0
112
2
0 1
10 0
0
124
2
0 2
10 0
end_DTG
begin_DTG
0
5
0
16
2
0 0
15 0
0
17
2
0 2
15 0
0
18
2
0 3
15 0
0
19
2
0 4
15 0
0
20
2
0 5
15 0
end_DTG
begin_DTG
3
2
58
0
4
59
0
5
60
0
3
2
61
0
3
62
0
4
63
0
3
0
64
0
1
65
0
3
66
0
4
1
67
0
2
68
0
4
69
0
5
70
0
4
0
71
0
1
72
0
3
73
0
5
74
0
3
0
75
0
3
76
0
4
77
0
end_DTG
begin_DTG
1
1
98
2
0 0
23 0
0
end_DTG
begin_DTG
1
1
99
2
0 4
23 0
0
end_DTG
begin_DTG
2
1
92
2
17 1
22 0
2
95
2
0 1
23 0
0
0
end_DTG
begin_DTG
2
1
93
2
17 2
22 0
2
96
2
0 2
23 0
0
0
end_DTG
begin_DTG
3
1
92
2
17 1
20 0
1
93
2
17 2
21 0
1
94
2
17 3
24 0
1
0
56
0
end_DTG
begin_DTG
5
1
95
2
0 1
20 0
1
96
2
0 2
21 0
1
97
2
0 3
24 0
1
98
2
0 0
18 0
1
99
2
0 4
19 0
1
0
57
0
end_DTG
begin_DTG
2
1
94
2
17 3
22 0
2
97
2
0 3
23 0
0
0
end_DTG
begin_DTG
0
5
0
51
2
0 0
18 1
0
52
2
0 2
18 1
0
53
2
0 3
18 1
0
54
2
0 4
18 1
0
55
2
0 5
18 1
end_DTG
begin_DTG
0
10
0
41
2
17 0
21 1
0
42
2
17 2
21 1
0
43
2
17 3
21 1
0
44
2
17 4
21 1
0
45
2
17 5
21 1
0
46
2
0 0
21 2
0
47
2
0 2
21 2
0
48
2
0 3
21 2
0
49
2
0 4
21 2
0
50
2
0 5
21 2
end_DTG
begin_CG
24
20 1
21 1
24 1
18 1
19 1
10 20
1 37
9 5
7 5
16 5
14 5
5 5
12 5
3 5
26 5
25 5
23 5
8 3
6 3
15 3
13 4
4 4
11 4
2 6
4
8 3
6 3
4 4
2 6
1
3 5
0
1
5 5
0
1
7 5
0
1
9 5
0
3
15 3
13 4
11 4
1
12 5
0
1
14 5
0
1
16 5
0
5
20 1
21 1
24 1
26 5
22 3
2
25 5
23 1
1
23 1
2
22 1
23 1
3
26 10
22 1
23 1
3
20 1
21 1
24 1
5
20 1
21 1
24 1
18 1
19 1
2
22 1
23 1
0
0
end_CG
