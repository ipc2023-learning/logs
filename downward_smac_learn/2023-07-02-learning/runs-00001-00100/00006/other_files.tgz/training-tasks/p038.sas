begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var30
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var24
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var25
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var22
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var21
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var20
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
0
begin_state
4
0
1
1
1
0
0
0
0
0
0
1
1
1
end_state
begin_goal
4
4 0
11 0
12 0
13 0
end_goal
79
begin_operator
calibrate rover1 camera2 objective4 waypoint1
1
1 0
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint2
1
1 1
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint3
1
1 2
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint4
1
1 3
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint5
1
1 4
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint6
1
1 5
1
0 2 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint1 waypoint3
2
1 0
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint6 waypoint3
2
1 5
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint1 waypoint3
2
1 0
6 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint6 waypoint3
2
1 5
6 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint1 waypoint3
2
1 0
7 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint6 waypoint3
2
1 5
7 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint5 waypoint1 waypoint3
2
1 0
10 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint5 waypoint6 waypoint3
2
1 5
10 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint2 waypoint1 waypoint3
2
0 0
6 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint2 waypoint6 waypoint3
2
0 5
6 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint4 waypoint1 waypoint3
2
0 0
7 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint4 waypoint6 waypoint3
2
0 5
7 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint5 waypoint1 waypoint3
2
0 0
10 2
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint5 waypoint6 waypoint3
2
0 5
10 2
1
0 11 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 8 1 0
0
end_operator
begin_operator
drop rover2 rover2store
0
1
0 9 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 1 0 2
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 1 0 3
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint5
0
1
0 1 0 4
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint6
0
1
0 1 1 5
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint1
0
1
0 1 2 0
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint6
0
1
0 1 2 5
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 1 3 0
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint1
0
1
0 1 4 0
0
end_operator
begin_operator
navigate rover1 waypoint6 waypoint2
0
1
0 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera2 colour
1
1 3
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera2 high_res
1
1 3
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective4 camera2 colour
1
1 3
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective4 camera2 high_res
1
1 3
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera2 colour
1
1 4
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera2 high_res
1
1 4
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera2 colour
1
1 4
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera2 high_res
1
1 4
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera2 colour
1
1 4
2
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera2 high_res
1
1 4
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective4 camera2 colour
1
1 4
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective4 camera2 high_res
1
1 4
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera2 colour
1
1 5
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera2 high_res
1
1 5
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint6 objective4 camera2 colour
1
1 5
1
0 2 0 1
0
end_operator
begin_operator
take_image rover1 waypoint6 objective4 camera2 high_res
1
1 5
1
0 2 0 1
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 4
0
22
23
24
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 0
check 1
8
check 0
switch 7
check 0
check 0
check 1
10
check 0
switch 10
check 0
check 0
check 1
12
check 0
switch 2
check 0
check 4
53
54
55
56
check 0
switch 3
check 0
check 1
6
check 0
check 0
switch 0
check 2
1
25
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 8
check 0
check 1
46
check 0
check 0
check 0
check 0
switch 5
check 0
switch 8
check 0
check 1
52
check 0
check 0
check 0
switch 2
check 0
check 2
57
58
check 0
check 0
switch 0
check 3
2
26
27
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 4
59
60
61
62
check 0
check 0
switch 0
check 2
3
28
check 0
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
switch 8
check 0
check 1
47
check 0
check 0
check 0
check 0
switch 2
check 0
check 4
63
64
65
66
check 0
check 0
switch 0
check 2
4
29
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
switch 8
check 0
check 1
48
check 0
check 0
check 0
check 0
switch 2
check 0
check 8
67
68
69
70
71
72
73
74
check 0
check 0
switch 0
check 3
5
30
31
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 0
check 1
9
check 0
switch 7
check 0
check 0
check 1
11
check 0
switch 10
check 0
check 0
check 1
13
check 0
switch 2
check 0
check 4
75
76
77
78
check 0
switch 3
check 0
check 1
7
check 0
check 0
switch 0
check 0
switch 6
check 4
32
33
34
35
check 0
check 0
check 1
14
switch 7
check 0
check 0
check 0
check 1
16
switch 10
check 0
check 0
check 0
check 1
18
check 0
switch 6
check 2
36
37
switch 9
check 0
check 1
49
check 0
check 0
check 0
check 0
check 0
check 2
38
39
switch 6
check 1
40
check 0
check 0
check 0
switch 7
check 0
switch 9
check 0
check 1
50
check 0
check 0
check 0
check 0
check 0
switch 6
check 2
41
42
check 0
check 0
check 0
switch 10
check 0
switch 9
check 0
check 1
51
check 0
check 0
check 0
check 0
check 0
switch 6
check 3
43
44
45
check 0
check 0
check 1
15
switch 7
check 0
check 0
check 0
check 1
17
switch 10
check 0
check 0
check 0
check 1
19
check 0
switch 8
check 0
check 0
check 1
20
switch 9
check 0
check 0
check 1
21
check 0
end_SG
begin_DTG
4
2
32
0
3
33
0
4
34
0
5
35
0
2
4
36
0
5
37
0
2
0
38
0
5
39
0
1
0
40
0
2
0
41
0
1
42
0
3
0
43
0
1
44
0
2
45
0
end_DTG
begin_DTG
3
2
22
0
3
23
0
4
24
0
1
5
25
0
2
0
26
0
5
27
0
1
0
28
0
1
0
29
0
2
1
30
0
2
31
0
end_DTG
begin_DTG
6
1
66
1
1 3
1
78
1
1 5
1
74
1
1 4
1
53
1
1 0
1
62
1
1 2
1
58
1
1 1
6
0
0
1
1 0
0
1
1
1 1
0
2
1
1 2
0
3
1
1 3
0
4
1
1 4
0
5
1
1 5
end_DTG
begin_DTG
0
1
0
71
2
1 4
2 0
end_DTG
begin_DTG
0
2
0
6
2
1 0
3 0
0
7
2
1 5
3 0
end_DTG
begin_DTG
1
1
52
2
1 1
8 0
0
end_DTG
begin_DTG
2
1
46
2
1 1
8 0
2
49
2
0 1
9 0
0
0
end_DTG
begin_DTG
2
1
47
2
1 3
8 0
2
50
2
0 3
9 0
0
0
end_DTG
begin_DTG
4
1
46
2
1 1
6 0
1
47
2
1 3
7 0
1
48
2
1 4
10 0
1
52
2
1 1
5 0
1
0
20
0
end_DTG
begin_DTG
3
1
49
2
0 1
6 0
1
50
2
0 3
7 0
1
51
2
0 4
10 0
1
0
21
0
end_DTG
begin_DTG
2
1
48
2
1 4
8 0
2
51
2
0 4
9 0
0
0
end_DTG
begin_DTG
0
4
0
12
2
1 0
10 1
0
13
2
1 5
10 1
0
18
2
0 0
10 2
0
19
2
0 5
10 2
end_DTG
begin_DTG
0
4
0
10
2
1 0
7 1
0
11
2
1 5
7 1
0
16
2
0 0
7 2
0
17
2
0 5
7 2
end_DTG
begin_DTG
0
4
0
8
2
1 0
6 1
0
9
2
1 5
6 1
0
14
2
0 0
6 2
0
15
2
0 5
6 2
end_DTG
begin_CG
7
6 1
7 1
10 1
13 2
12 2
11 2
9 3
11
6 1
7 1
10 1
5 1
2 32
4 2
13 2
12 2
11 2
8 4
3 1
1
3 1
1
4 2
0
1
8 1
3
13 4
8 1
9 1
3
12 4
8 1
9 1
4
6 1
7 1
10 1
5 1
3
6 1
7 1
10 1
3
11 4
8 1
9 1
0
0
0
end_CG
