begin_version
3
end_version
begin_metric
0
end_metric
90
begin_variable
var3
-1
9
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera1, rover4)
NegatedAtom calibrated(camera1, rover4)
end_variable
begin_variable
var103
-1
2
Atom have_image(rover4, objective8, low_res)
NegatedAtom have_image(rover4, objective8, low_res)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var101
-1
2
Atom have_image(rover4, objective7, low_res)
NegatedAtom have_image(rover4, objective7, low_res)
end_variable
begin_variable
var99
-1
2
Atom have_image(rover4, objective6, low_res)
NegatedAtom have_image(rover4, objective6, low_res)
end_variable
begin_variable
var98
-1
2
Atom have_image(rover4, objective6, colour)
NegatedAtom have_image(rover4, objective6, colour)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover4, objective5, low_res)
NegatedAtom have_image(rover4, objective5, low_res)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var95
-1
2
Atom have_image(rover4, objective4, low_res)
NegatedAtom have_image(rover4, objective4, low_res)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover4, objective4, colour)
NegatedAtom have_image(rover4, objective4, colour)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover4, objective3, colour)
NegatedAtom have_image(rover4, objective3, colour)
end_variable
begin_variable
var91
-1
2
Atom have_image(rover4, objective2, low_res)
NegatedAtom have_image(rover4, objective2, low_res)
end_variable
begin_variable
var90
-1
2
Atom have_image(rover4, objective2, colour)
NegatedAtom have_image(rover4, objective2, colour)
end_variable
begin_variable
var88
-1
2
Atom have_image(rover4, objective1, colour)
NegatedAtom have_image(rover4, objective1, colour)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover4, waypoint1)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover4, waypoint5)
end_variable
begin_variable
var9
-1
2
Atom at_soil_sample(waypoint9)
Atom have_soil_analysis(rover4, waypoint9)
end_variable
begin_variable
var47
-1
2
Atom empty(rover4store)
Atom full(rover4store)
end_variable
begin_variable
var42
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera4, rover3)
NegatedAtom calibrated(camera4, rover3)
end_variable
begin_variable
var87
-1
2
Atom have_image(rover3, objective8, high_res)
NegatedAtom have_image(rover3, objective8, high_res)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover3, objective8, colour)
NegatedAtom have_image(rover3, objective8, colour)
end_variable
begin_variable
var85
-1
2
Atom have_image(rover3, objective7, high_res)
NegatedAtom have_image(rover3, objective7, high_res)
end_variable
begin_variable
var83
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var82
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover3, objective5, high_res)
NegatedAtom have_image(rover3, objective5, high_res)
end_variable
begin_variable
var80
-1
2
Atom have_image(rover3, objective5, colour)
NegatedAtom have_image(rover3, objective5, colour)
end_variable
begin_variable
var79
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover3, objective4, colour)
NegatedAtom have_image(rover3, objective4, colour)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover3, objective3, high_res)
NegatedAtom have_image(rover3, objective3, high_res)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover3, objective3, colour)
NegatedAtom have_image(rover3, objective3, colour)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover3, objective2, high_res)
NegatedAtom have_image(rover3, objective2, high_res)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover3, objective2, colour)
NegatedAtom have_image(rover3, objective2, colour)
end_variable
begin_variable
var73
-1
2
Atom have_image(rover3, objective1, high_res)
NegatedAtom have_image(rover3, objective1, high_res)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover3, objective1, colo




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




egin_DTG
0
8
0
58
2
38 1
63 0
0
59
2
38 2
63 0
0
60
2
38 4
63 0
0
61
2
38 7
63 0
0
186
2
0 1
9 0
0
187
2
0 2
9 0
0
188
2
0 4
9 0
0
189
2
0 7
9 0
end_DTG
begin_DTG
0
6
0
339
2
38 0
40 0
0
351
2
38 1
40 0
0
415
2
38 5
40 0
0
431
2
38 6
40 0
0
455
2
38 7
40 0
0
471
2
38 8
40 0
end_DTG
begin_DTG
0
8
0
54
2
38 1
65 0
0
55
2
38 2
65 0
0
56
2
38 4
65 0
0
57
2
38 7
65 0
0
134
2
20 1
29 0
0
135
2
20 2
29 0
0
136
2
20 4
29 0
0
137
2
20 7
29 0
end_DTG
begin_DTG
0
12
0
338
2
38 0
40 0
0
341
2
38 0
39 0
0
350
2
38 1
40 0
0
353
2
38 1
39 0
0
414
2
38 5
40 0
0
417
2
38 5
39 0
0
430
2
38 6
40 0
0
433
2
38 6
39 0
0
454
2
38 7
40 0
0
457
2
38 7
39 0
0
470
2
38 8
40 0
0
473
2
38 8
39 0
end_DTG
begin_DTG
0
12
0
50
2
38 1
67 0
0
51
2
38 2
67 0
0
52
2
38 4
67 0
0
53
2
38 7
67 0
0
130
2
20 1
30 0
0
131
2
20 2
30 0
0
132
2
20 4
30 0
0
133
2
20 7
30 0
0
182
2
0 1
10 0
0
183
2
0 2
10 0
0
184
2
0 4
10 0
0
185
2
0 7
10 0
end_DTG
begin_DTG
0
6
0
367
2
38 2
40 0
0
383
2
38 3
40 0
0
395
2
38 4
40 0
0
411
2
38 5
40 0
0
451
2
38 7
40 0
0
467
2
38 8
40 0
end_DTG
begin_DTG
0
8
0
46
2
38 1
69 0
0
47
2
38 2
69 0
0
48
2
38 4
69 0
0
49
2
38 7
69 0
0
126
2
20 1
31 0
0
127
2
20 2
31 0
0
128
2
20 4
31 0
0
129
2
20 7
31 0
end_DTG
begin_DTG
0
12
0
366
2
38 2
40 0
0
369
2
38 2
39 0
0
382
2
38 3
40 0
0
385
2
38 3
39 0
0
394
2
38 4
40 0
0
397
2
38 4
39 0
0
410
2
38 5
40 0
0
413
2
38 5
39 0
0
450
2
38 7
40 0
0
453
2
38 7
39 0
0
466
2
38 8
40 0
0
469
2
38 8
39 0
end_DTG
begin_DTG
0
12
0
42
2
38 1
71 0
0
43
2
38 2
71 0
0
44
2
38 4
71 0
0
45
2
38 7
71 0
0
122
2
20 1
32 0
0
123
2
20 2
32 0
0
124
2
20 4
32 0
0
125
2
20 7
32 0
0
178
2
0 1
11 0
0
179
2
0 2
11 0
0
180
2
0 4
11 0
0
181
2
0 7
11 0
end_DTG
begin_DTG
0
2
0
380
2
38 3
40 0
0
448
2
38 7
40 0
end_DTG
begin_DTG
0
8
0
38
2
38 1
73 0
0
39
2
38 2
73 0
0
40
2
38 4
73 0
0
41
2
38 7
73 0
0
174
2
0 1
12 0
0
175
2
0 2
12 0
0
176
2
0 4
12 0
0
177
2
0 7
12 0
end_DTG
begin_DTG
0
2
0
379
2
38 3
40 0
0
447
2
38 7
40 0
end_DTG
begin_DTG
0
8
0
34
2
38 1
75 0
0
35
2
38 2
75 0
0
36
2
38 4
75 0
0
37
2
38 7
75 0
0
118
2
20 1
33 0
0
119
2
20 2
33 0
0
120
2
20 4
33 0
0
121
2
20 7
33 0
end_DTG
begin_DTG
0
4
0
378
2
38 3
40 0
0
381
2
38 3
39 0
0
446
2
38 7
40 0
0
449
2
38 7
39 0
end_DTG
begin_DTG
0
12
0
30
2
38 1
77 0
0
31
2
38 2
77 0
0
32
2
38 4
77 0
0
33
2
38 7
77 0
0
114
2
20 1
34 0
0
115
2
20 2
34 0
0
116
2
20 4
34 0
0
117
2
20 7
34 0
0
170
2
0 1
13 0
0
171
2
0 2
13 0
0
172
2
0 4
13 0
0
173
2
0 7
13 0
end_DTG
begin_DTG
0
1
0
375
2
38 3
40 0
end_DTG
begin_DTG
0
8
0
26
2
38 1
79 0
0
27
2
38 2
79 0
0
28
2
38 4
79 0
0
29
2
38 7
79 0
0
110
2
20 1
35 0
0
111
2
20 2
35 0
0
112
2
20 4
35 0
0
113
2
20 7
35 0
end_DTG
begin_DTG
0
2
0
374
2
38 3
40 0
0
377
2
38 3
39 0
end_DTG
begin_DTG
0
12
0
22
2
38 1
81 0
0
23
2
38 2
81 0
0
24
2
38 4
81 0
0
25
2
38 7
81 0
0
106
2
20 1
36 0
0
107
2
20 2
36 0
0
108
2
20 4
36 0
0
109
2
20 7
36 0
0
166
2
0 1
14 0
0
167
2
0 2
14 0
0
168
2
0 4
14 0
0
169
2
0 7
14 0
end_DTG
begin_DTG
3
1
326
2
38 2
84 0
2
329
2
37 2
85 0
3
332
2
20 2
88 0
0
0
0
end_DTG
begin_DTG
3
1
326
2
38 2
83 0
1
327
2
38 6
86 0
1
328
2
38 8
87 0
1
0
234
0
end_DTG
begin_DTG
3
1
329
2
37 2
83 0
1
330
2
37 6
86 0
1
331
2
37 8
87 0
1
0
235
0
end_DTG
begin_DTG
3
1
327
2
38 6
84 0
2
330
2
37 6
85 0
3
333
2
20 6
88 0
0
0
0
end_DTG
begin_DTG
3
1
328
2
38 8
84 0
2
331
2
37 8
85 0
3
334
2
20 8
88 0
0
0
0
end_DTG
begin_DTG
3
1
332
2
20 2
83 0
1
333
2
20 6
86 0
1
334
2
20 8
87 0
1
0
236
0
end_DTG
begin_DTG
0
12
0
218
2
38 1
83 1
0
219
2
38 2
83 1
0
220
2
38 4
83 1
0
221
2
38 7
83 1
0
222
2
37 1
83 2
0
223
2
37 2
83 2
0
224
2
37 4
83 2
0
225
2
37 7
83 2
0
226
2
20 1
83 3
0
227
2
20 2
83 3
0
228
2
20 4
83 3
0
229
2
20 7
83 3
end_DTG
begin_CG
32
15 1
16 1
17 1
1 77
82 4
78 4
74 4
72 4
68 4
64 4
62 4
58 4
56 4
52 4
48 4
46 4
42 4
19 4
18 3
14 1
13 2
12 2
11 6
10 6
9 6
8 9
7 9
6 7
5 7
4 2
3 2
2 2
13
14 1
13 2
12 2
11 6
10 6
9 6
8 9
7 9
6 7
5 7
4 2
3 2
2 2
1
42 4
1
46 4
1
48 4
1
52 4
1
56 4
1
58 4
1
62 4
1
64 4
1
68 4
1
72 4
1
74 4
1
78 4
1
82 4
1
18 1
2
19 4
18 1
1
18 1
3
15 1
16 1
17 1
0
36
83 1
86 1
87 1
21 72
82 4
80 4
78 4
76 4
72 4
70 4
68 4
66 4
62 4
60 4
56 4
54 4
50 4
46 4
44 4
89 4
88 3
36 1
35 1
34 2
33 2
32 6
31 6
30 6
29 6
28 9
27 9
26 7
25 7
24 2
23 2
22 2
15
36 1
35 1
34 2
33 2
32 6
31 6
30 6
29 6
28 9
27 9
26 7
25 7
24 2
23 2
22 2
1
44 4
1
46 4
1
50 4
1
54 4
1
56 4
1
60 4
1
62 4
1
66 4
1
68 4
1
70 4
1
72 4
1
76 4
1
78 4
1
80 4
1
82 4
5
83 1
86 1
87 1
89 4
85 3
49
83 1
86 1
87 1
40 112
39 41
82 4
80 4
78 4
76 4
74 4
72 4
70 4
68 4
66 4
64 4
62 4
60 4
58 4
56 4
54 4
52 4
50 4
48 4
46 4
44 4
42 4
89 4
84 3
81 2
79 1
77 4
75 2
73 2
71 12
69 6
67 12
65 6
63 6
61 18
59 9
57 9
55 14
53 7
51 7
49 2
47 2
45 4
43 2
41 2
7
81 1
77 2
71 6
67 6
61 9
55 7
45 2
21
81 1
79 1
77 2
75 2
73 2
71 6
69 6
67 6
65 6
63 6
61 9
59 9
57 9
55 7
53 7
51 7
49 2
47 2
45 2
43 2
41 2
1
42 4
0
1
44 4
0
1
46 4
0
1
48 4
0
1
50 4
0
1
52 4
0
1
54 4
0
1
56 4
0
1
58 4
0
1
60 4
0
1
62 4
0
1
64 4
0
1
66 4
0
1
68 4
0
1
70 4
0
1
72 4
0
1
74 4
0
1
76 4
0
1
78 4
0
1
80 4
0
1
82 4
0
4
89 12
84 1
85 1
88 1
3
83 1
86 1
87 1
3
83 1
86 1
87 1
3
84 1
85 1
88 1
3
84 1
85 1
88 1
3
83 1
86 1
87 1
0
end_CG
