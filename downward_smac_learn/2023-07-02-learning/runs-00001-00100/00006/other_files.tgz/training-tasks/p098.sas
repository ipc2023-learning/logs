begin_version
3
end_version
begin_metric
0
end_metric
81
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var18
-1
2
Atom calibrated(camera4, rover4)
NegatedAtom calibrated(camera4, rover4)
end_variable
begin_variable
var147
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var144
-1
2
Atom have_image(rover4, objective7, colour)
NegatedAtom have_image(rover4, objective7, colour)
end_variable
begin_variable
var142
-1
2
Atom have_image(rover4, objective6, high_res)
NegatedAtom have_image(rover4, objective6, high_res)
end_variable
begin_variable
var141
-1
2
Atom have_image(rover4, objective6, colour)
NegatedAtom have_image(rover4, objective6, colour)
end_variable
begin_variable
var139
-1
2
Atom have_image(rover4, objective5, high_res)
NegatedAtom have_image(rover4, objective5, high_res)
end_variable
begin_variable
var138
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var137
-1
2
Atom have_image(rover4, objective4, low_res)
NegatedAtom have_image(rover4, objective4, low_res)
end_variable
begin_variable
var135
-1
2
Atom have_image(rover4, objective4, colour)
NegatedAtom have_image(rover4, objective4, colour)
end_variable
begin_variable
var133
-1
2
Atom have_image(rover4, objective3, high_res)
NegatedAtom have_image(rover4, objective3, high_res)
end_variable
begin_variable
var131
-1
2
Atom have_image(rover4, objective2, low_res)
NegatedAtom have_image(rover4, objective2, low_res)
end_variable
begin_variable
var130
-1
2
Atom have_image(rover4, objective2, high_res)
NegatedAtom have_image(rover4, objective2, high_res)
end_variable
begin_variable
var128
-1
2
Atom have_image(rover4, objective10, low_res)
NegatedAtom have_image(rover4, objective10, low_res)
end_variable
begin_variable
var124
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var119
-1
2
Atom have_image(rover3, objective8, colour)
NegatedAtom have_image(rover3, objective8, colour)
end_variable
begin_variable
var117
-1
2
Atom have_image(rover3, objective7, colour)
NegatedAtom have_image(rover3, objective7, colour)
end_variable
begin_variable
var115
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var113
-1
2
Atom have_image(rover3, objective5, colour)
NegatedAtom have_image(rover3, objective5, colour)
end_variable
begin_variable
var112
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var111
-1
2
Atom have_image(rover3, objective4, colour)
NegatedAtom have_image(rover3, objective4, colour)
end_variable
begin_variable
var108
-1
2
Atom have_image(rover3, objective2, low_res)
NegatedAtom have_image(rover3, objective2, low_res)
end_variable
begin_variable
var106
-1
2
Atom have_image(rover3, objective10, low_res)
NegatedAtom have_image(rover3, objective10, low_res)
end_variable
begin_variable
var1
-1
10
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint10)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover2, objective8, colour)
NegatedAtom have_image(rover2, objective8, colour)
end_variable
begin_variable
var43
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover2, objective7, colour)
NegatedAtom have_image(rover2, objective7, colour)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover2, objective6, high_res)
NegatedAtom have_image(rover2, objective6, high_res)
end_variable
begin_variable
var91
-1
2
Atom have_image(rover2, objective6, colour)
NegatedAtom have_image(rover2, objective6, colour)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicate




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 0
end_DTG
begin_DTG
0
6
0
443
2
48 0
49 0
0
454
2
48 3
49 0
0
464
2
48 6
49 0
0
470
2
48 7
49 0
0
474
2
48 8
49 0
0
479
2
48 9
49 0
end_DTG
begin_DTG
0
15
0
23
2
48 2
56 0
0
24
2
48 3
56 0
0
25
2
48 4
56 0
0
26
2
48 7
56 0
0
27
2
48 9
56 0
0
53
2
25 2
44 0
0
54
2
25 3
44 0
0
55
2
25 4
44 0
0
56
2
25 7
44 0
0
57
2
25 9
44 0
0
158
2
0 2
12 0
0
159
2
0 3
12 0
0
160
2
0 4
12 0
0
161
2
0 7
12 0
0
162
2
0 9
12 0
end_DTG
begin_DTG
0
3
0
442
2
48 0
49 0
0
450
2
48 2
49 0
0
473
2
48 8
49 0
end_DTG
begin_DTG
0
15
0
18
2
48 2
58 0
0
19
2
48 3
58 0
0
20
2
48 4
58 0
0
21
2
48 7
58 0
0
22
2
48 9
58 0
0
43
2
25 2
47 0
0
44
2
25 3
47 0
0
45
2
25 4
47 0
0
46
2
25 7
47 0
0
47
2
25 9
47 0
0
148
2
0 2
14 0
0
149
2
0 3
14 0
0
150
2
0 4
14 0
0
151
2
0 7
14 0
0
152
2
0 9
14 0
end_DTG
begin_DTG
1
1
437
2
25 0
70 0
0
end_DTG
begin_DTG
1
1
438
2
25 2
70 0
0
end_DTG
begin_DTG
1
1
439
2
25 4
70 0
0
end_DTG
begin_DTG
1
1
440
2
25 8
70 0
0
end_DTG
begin_DTG
1
1
441
2
25 9
70 0
0
end_DTG
begin_DTG
3
1
419
2
48 0
69 0
2
425
2
25 0
70 0
3
431
2
15 0
73 0
0
0
0
end_DTG
begin_DTG
3
1
420
2
48 1
69 0
2
426
2
25 1
70 0
3
432
2
15 1
73 0
0
0
0
end_DTG
begin_DTG
3
1
421
2
48 2
69 0
2
427
2
25 2
70 0
3
433
2
15 2
73 0
0
0
0
end_DTG
begin_DTG
3
1
422
2
48 4
69 0
2
428
2
25 4
70 0
3
434
2
15 4
73 0
0
0
0
end_DTG
begin_DTG
6
1
419
2
48 0
65 0
1
420
2
48 1
66 0
1
421
2
48 2
67 0
1
422
2
48 4
68 0
1
423
2
48 5
71 0
1
424
2
48 8
72 0
1
0
298
0
end_DTG
begin_DTG
11
1
425
2
25 0
65 0
1
426
2
25 1
66 0
1
427
2
25 2
67 0
1
428
2
25 4
68 0
1
429
2
25 5
71 0
1
430
2
25 8
72 0
1
437
2
25 0
60 0
1
438
2
25 2
61 0
1
439
2
25 4
62 0
1
440
2
25 8
63 0
1
441
2
25 9
64 0
1
0
299
0
end_DTG
begin_DTG
3
1
423
2
48 5
69 0
2
429
2
25 5
70 0
3
435
2
15 5
73 0
0
0
0
end_DTG
begin_DTG
3
1
424
2
48 8
69 0
2
430
2
25 8
70 0
3
436
2
15 8
73 0
0
0
0
end_DTG
begin_DTG
6
1
431
2
15 0
65 0
1
432
2
15 1
66 0
1
433
2
15 2
67 0
1
434
2
15 4
68 0
1
435
2
15 5
71 0
1
436
2
15 8
72 0
1
0
300
0
end_DTG
begin_DTG
0
5
0
293
2
25 2
64 1
0
294
2
25 3
64 1
0
295
2
25 4
64 1
0
296
2
25 7
64 1
0
297
2
25 9
64 1
end_DTG
begin_DTG
0
5
0
288
2
25 2
63 1
0
289
2
25 3
63 1
0
290
2
25 4
63 1
0
291
2
25 7
63 1
0
292
2
25 9
63 1
end_DTG
begin_DTG
0
15
0
233
2
48 2
72 1
0
234
2
48 3
72 1
0
235
2
48 4
72 1
0
236
2
48 7
72 1
0
237
2
48 9
72 1
0
258
2
25 2
72 2
0
259
2
25 3
72 2
0
260
2
25 4
72 2
0
261
2
25 7
72 2
0
262
2
25 9
72 2
0
283
2
15 2
72 3
0
284
2
15 3
72 3
0
285
2
15 4
72 3
0
286
2
15 7
72 3
0
287
2
15 9
72 3
end_DTG
begin_DTG
0
15
0
228
2
48 2
71 1
0
229
2
48 3
71 1
0
230
2
48 4
71 1
0
231
2
48 7
71 1
0
232
2
48 9
71 1
0
253
2
25 2
71 2
0
254
2
25 3
71 2
0
255
2
25 4
71 2
0
256
2
25 7
71 2
0
257
2
25 9
71 2
0
278
2
15 2
71 3
0
279
2
15 3
71 3
0
280
2
15 4
71 3
0
281
2
15 7
71 3
0
282
2
15 9
71 3
end_DTG
begin_DTG
0
15
0
223
2
48 2
68 1
0
224
2
48 3
68 1
0
225
2
48 4
68 1
0
226
2
48 7
68 1
0
227
2
48 9
68 1
0
248
2
25 2
68 2
0
249
2
25 3
68 2
0
250
2
25 4
68 2
0
251
2
25 7
68 2
0
252
2
25 9
68 2
0
273
2
15 2
68 3
0
274
2
15 3
68 3
0
275
2
15 4
68 3
0
276
2
15 7
68 3
0
277
2
15 9
68 3
end_DTG
begin_DTG
0
15
0
218
2
48 2
67 1
0
219
2
48 3
67 1
0
220
2
48 4
67 1
0
221
2
48 7
67 1
0
222
2
48 9
67 1
0
243
2
25 2
67 2
0
244
2
25 3
67 2
0
245
2
25 4
67 2
0
246
2
25 7
67 2
0
247
2
25 9
67 2
0
268
2
15 2
67 3
0
269
2
15 3
67 3
0
270
2
15 4
67 3
0
271
2
15 7
67 3
0
272
2
15 9
67 3
end_DTG
begin_DTG
0
15
0
213
2
48 2
65 1
0
214
2
48 3
65 1
0
215
2
48 4
65 1
0
216
2
48 7
65 1
0
217
2
48 9
65 1
0
238
2
25 2
65 2
0
239
2
25 3
65 2
0
240
2
25 4
65 2
0
241
2
25 7
65 2
0
242
2
25 9
65 2
0
263
2
15 2
65 3
0
264
2
15 3
65 3
0
265
2
15 4
65 3
0
266
2
15 7
65 3
0
267
2
15 9
65 3
end_DTG
begin_CG
27
1 118
59 5
46 5
57 5
43 5
55 5
40 5
38 5
36 5
53 5
33 5
51 5
30 5
28 5
14 3
13 3
12 6
11 6
10 4
9 1
8 1
7 5
6 5
5 10
4 10
3 1
2 5
13
14 3
13 3
12 6
11 6
10 4
9 1
8 1
7 5
6 5
5 10
4 10
3 1
2 5
1
28 5
1
30 5
1
51 5
1
33 5
1
53 5
1
36 5
1
38 5
1
40 5
1
55 5
1
43 5
1
57 5
1
46 5
1
59 5
29
65 1
66 1
67 1
68 1
71 1
72 1
16 88
46 5
43 5
40 5
38 5
36 5
33 5
30 5
28 5
80 5
79 5
78 5
77 5
76 5
73 6
24 3
23 6
22 1
21 1
20 5
19 10
18 1
17 5
8
24 3
23 6
22 1
21 1
20 5
19 10
18 1
17 5
1
28 5
1
30 5
1
33 5
1
36 5
1
38 5
1
40 5
1
43 5
1
46 5
46
65 1
66 1
67 1
68 1
71 1
72 1
60 1
61 1
62 1
63 1
64 1
26 120
59 5
46 5
57 5
43 5
55 5
40 5
38 5
36 5
53 5
33 5
51 5
30 5
28 5
80 5
79 5
78 5
77 5
76 5
75 5
74 5
70 11
47 3
45 3
44 6
42 6
41 4
39 1
37 1
35 5
34 5
32 10
31 10
29 1
27 5
13
47 3
45 3
44 6
42 6
41 4
39 1
37 1
35 5
34 5
32 10
31 10
29 1
27 5
1
28 5
0
1
30 5
0
1
51 5
1
33 5
0
1
53 5
1
36 5
0
1
38 5
0
1
40 5
0
1
55 5
1
43 5
0
1
57 5
1
46 5
0
1
59 5
23
65 1
66 1
67 1
68 1
71 1
72 1
49 43
59 5
57 5
55 5
53 5
51 5
80 5
79 5
78 5
77 5
76 5
69 6
58 3
56 6
54 4
52 5
50 10
5
58 3
56 6
54 4
52 5
50 10
1
51 5
0
1
53 5
0
1
55 5
0
1
57 5
0
1
59 5
0
1
70 1
1
70 1
1
70 1
2
75 5
70 1
2
74 5
70 1
4
80 15
69 1
70 1
73 1
3
69 1
70 1
73 1
4
79 15
69 1
70 1
73 1
4
78 15
69 1
70 1
73 1
6
65 1
66 1
67 1
68 1
71 1
72 1
11
65 1
66 1
67 1
68 1
71 1
72 1
60 1
61 1
62 1
63 1
64 1
4
77 15
69 1
70 1
73 1
4
76 15
69 1
70 1
73 1
6
65 1
66 1
67 1
68 1
71 1
72 1
0
0
0
0
0
0
0
end_CG
