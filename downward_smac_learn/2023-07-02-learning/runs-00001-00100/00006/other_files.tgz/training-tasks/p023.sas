begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var13
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var4
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var2
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
end_variable
begin_variable
var12
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var11
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var10
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
1
1
1
1
0
0
0
1
1
end_state
begin_goal
3
3 0
7 0
8 0
end_goal
40
begin_operator
calibrate rover1 camera1 objective1 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint2 waypoint5
2
0 1
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint3 waypoint5
2
0 2
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint4 waypoint5
2
0 3
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint2 waypoint5
2
0 1
4 1
1
0 8 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint3 waypoint5
2
0 2
4 1
1
0 8 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint4 waypoint5
2
0 3
4 1
1
0 8 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint5 waypoint2 waypoint5
2
0 1
5 1
1
0 7 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint5 waypoint3 waypoint5
2
0 2
5 1
1
0 7 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint5 waypoint4 waypoint5
2
0 3
5 1
1
0 7 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 6 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint3
0
1
0 0 1 2
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint4
0
1
0 0 1 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint5
0
1
0 0 1 4
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint2
0
1
0 0 2 1
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint5
0
1
0 0 2 4
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint2
0
1
0 0 3 1
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint5
0
1
0 0 3 4
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint2
0
1
0 0 4 1
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint3
0
1
0 0 4 2
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint4
0
1
0 0 4 3
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
0 0
2
0 4 0 1
0 6 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint5
1
0 4
2
0 5 0 1
0 6 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 colour
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 high_res
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 low_res
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 colour
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 high_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective2 camera1 low_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 colour
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 high_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 colour
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 high_res
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 low_res
1
0 4
1
0 1 0 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 4
check 1
11
switch 6
check 0
check 1
23
check 0
check 0
check 0
check 0
switch 4
check 3
12
13
14
check 0
check 1
4
switch 5
check 0
check 0
check 1
7
switch 1
check 0
check 3
25
26
27
check 0
switch 2
check 0
check 1
1
check 0
check 0
switch 4
check 2
15
16
check 0
check 1
5
switch 5
check 0
check 0
check 1
8
switch 1
check 0
check 3
28
29
30
check 0
switch 2
check 0
check 1
2
check 0
check 0
switch 4
check 4
0
17
18
19
check 0
check 1
6
switch 5
check 0
check 0
check 1
9
switch 1
check 0
check 6
31
32
33
34
35
36
check 0
switch 2
check 0
check 1
3
check 0
check 0
switch 4
check 3
20
21
22
check 0
check 0
switch 5
check 0
switch 6
check 0
check 1
24
check 0
check 0
check 0
switch 1
check 0
check 3
37
38
39
check 0
check 0
switch 6
check 0
check 0
check 1
10
check 0
end_SG
begin_DTG
1
3
11
0
3
2
12
0
3
13
0
4
14
0
2
1
15
0
4
16
0
3
0
17
0
1
18
0
4
19
0
3
1
20
0
2
21
0
3
22
0
end_DTG
begin_DTG
4
1
25
1
0 1
1
28
1
0 2
1
31
1
0 3
1
37
1
0 4
1
0
0
1
0 3
end_DTG
begin_DTG
0
1
0
31
2
0 3
1 0
end_DTG
begin_DTG
0
3
0
1
2
0 1
2 0
0
2
2
0 2
2 0
0
3
2
0 3
2 0
end_DTG
begin_DTG
1
1
23
2
0 0
6 0
0
end_DTG
begin_DTG
1
1
24
2
0 4
6 0
0
end_DTG
begin_DTG
2
1
23
2
0 0
4 0
1
24
2
0 4
5 0
1
0
10
0
end_DTG
begin_DTG
0
3
0
7
2
0 1
5 1
0
8
2
0 2
5 1
0
9
2
0 3
5 1
end_DTG
begin_DTG
0
3
0
4
2
0 1
4 1
0
5
2
0 2
4 1
0
6
2
0 3
4 1
end_DTG
begin_CG
8
4 1
5 1
1 16
3 3
8 3
7 3
6 2
2 1
1
2 1
1
3 3
0
2
8 3
6 1
2
7 3
6 1
2
4 1
5 1
0
0
end_CG
