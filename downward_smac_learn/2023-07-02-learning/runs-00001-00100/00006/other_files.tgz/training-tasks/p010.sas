begin_version
3
end_version
begin_metric
0
end_metric
12
begin_variable
var0
-1
4
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
end_variable
begin_variable
var5
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var16
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var8
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var14
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var6
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var3
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var13
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var10
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
0
begin_state
3
1
1
1
1
1
0
0
0
0
0
1
end_state
begin_goal
3
3 0
5 0
11 0
end_goal
23
begin_operator
calibrate rover1 camera1 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint2 waypoint3
2
0 1
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint4 waypoint3
2
0 3
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint2 waypoint3
2
0 1
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint4 waypoint3
2
0 3
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint2 waypoint3
2
0 1
7 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint4 waypoint3
2
0 3
7 1
1
0 11 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 10 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint3
0
1
0 0 1 2
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint4
0
1
0 0 1 3
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint2
0
1
0 0 2 1
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint4
0
1
0 0 2 3
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint2
0
1
0 0 3 1
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint3
0
1
0 0 3 2
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint3
1
0 2
2
0 6 0 1
0 10 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint4
1
0 3
2
0 7 0 1
0 10 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint2
1
0 1
2
0 8 0 1
0 10 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
0 2
2
0 9 0 1
0 10 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 6
check 2
0
8
check 0
check 0
switch 1
check 0
check 3
20
21
22
check 0
check 0
switch 6
check 2
9
10
check 0
check 0
switch 7
check 0
check 0
check 1
5
switch 8
check 0
switch 10
check 0
check 1
18
check 0
check 0
check 0
switch 4
check 0
check 1
1
check 0
switch 2
check 0
check 1
3
check 0
check 0
switch 6
check 2
11
12
switch 10
check 0
check 1
16
check 0
check 0
check 0
switch 9
check 0
switch 10
check 0
check 1
19
check 0
check 0
check 0
check 0
switch 6
check 3
13
14
15
check 0
check 0
switch 7
check 0
switch 10
check 0
check 1
17
check 0
check 0
check 1
6
switch 4
check 0
check 1
2
check 0
switch 2
check 0
check 1
4
check 0
check 0
switch 10
check 0
check 0
check 1
7
check 0
end_SG
begin_DTG
1
3
8
0
2
2
9
0
3
10
0
2
1
11
0
3
12
0
3
0
13
0
1
14
0
2
15
0
end_DTG
begin_DTG
1
1
20
1
0 0
1
0
0
1
0 0
end_DTG
begin_DTG
0
1
0
22
2
0 0
1 0
end_DTG
begin_DTG
0
2
0
3
2
0 1
2 0
0
4
2
0 3
2 0
end_DTG
begin_DTG
0
1
0
20
2
0 0
1 0
end_DTG
begin_DTG
0
2
0
1
2
0 1
4 0
0
2
2
0 3
4 0
end_DTG
begin_DTG
1
1
16
2
0 2
10 0
0
end_DTG
begin_DTG
1
1
17
2
0 3
10 0
0
end_DTG
begin_DTG
1
1
18
2
0 1
10 0
0
end_DTG
begin_DTG
1
1
19
2
0 2
10 0
0
end_DTG
begin_DTG
4
1
16
2
0 2
6 0
1
17
2
0 3
7 0
1
18
2
0 1
8 0
1
19
2
0 2
9 0
1
0
7
0
end_DTG
begin_DTG
0
2
0
5
2
0 1
7 1
0
6
2
0 3
7 1
end_DTG
begin_CG
11
6 1
7 1
8 1
9 1
1 4
5 2
3 2
11 2
10 4
4 1
2 1
2
4 1
2 1
1
3 2
0
1
5 2
0
1
10 1
2
11 2
10 1
1
10 1
1
10 1
4
6 1
7 1
8 1
9 1
0
end_CG
