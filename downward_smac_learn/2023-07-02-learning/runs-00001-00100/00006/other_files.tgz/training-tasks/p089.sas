begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var90
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var0
-1
10
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint10)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var18
-1
2
Atom calibrated(camera4, rover1)
NegatedAtom calibrated(camera4, rover1)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover1, objective9, low_res)
NegatedAtom have_image(rover1, objective9, low_res)
end_variable
begin_variable
var45
-1
2
Atom communicated_image_data(objective9, low_res)
NegatedAtom communicated_image_data(objective9, low_res)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover1, objective8, colour)
NegatedAtom have_image(rover1, objective8, colour)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover1, objective7, colour)
NegatedAtom have_image(rover1, objective7, colour)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
0
begin_state
3
1
1
9
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
6
7 0
10 0
12 0
14 0
16 0
18 0
end_goal
340
begin_operator
calibrate rover1 camera2 objective3 waypoint1
1
3 0
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint10
1
3 1
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint2
1
3 2
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint3
1
3 3
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint4
1
3 4
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint5
1
3 5
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint7
1
3 7
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint9
1
3 9
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective1 waypoint1
1
3 0
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective1 waypoint10
1
3 1
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective1 waypoint2
1
3 2
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective1 waypoint5
1
3 5
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective1 waypoint7
1
3 7
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective1 waypoint8
1
3 8
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective1 waypoint9
1
3 9
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera4 objective2 waypoint10
1
3 1
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera4 objective2 waypoint2
1
3 2
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera4 objective2 waypoint4
1
3 4
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera4 objective2 waypoint7
1
3 7
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera4 objective2 waypoint8
1
3 8
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover1 camera4 objective2 waypoint9
1
3 9
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover3 camera1 objective2 waypoint10
1
0 1
1
0 1 -1 0
0
end_operator
begin_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




tch 13
check 0
check 1
30
check 0
switch 11
check 0
check 1
31
check 0
switch 9
check 0
check 1
32
check 0
check 0
switch 0
check 3
5
11
44
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 12
182
183
188
189
194
195
200
201
206
207
212
213
check 0
switch 5
check 0
check 12
184
185
190
191
196
197
202
203
208
209
214
215
check 0
switch 4
check 0
check 12
186
187
192
193
198
199
204
205
210
211
216
217
check 0
check 0
switch 0
check 5
45
46
47
48
49
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 2
218
219
check 0
switch 5
check 0
check 2
220
221
check 0
switch 4
check 0
check 2
222
223
check 0
check 0
switch 0
check 6
6
12
18
50
51
52
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 10
224
225
230
231
236
237
242
243
248
249
check 0
switch 5
check 0
check 10
226
227
232
233
238
239
244
245
250
251
check 0
switch 4
check 0
check 10
228
229
234
235
240
241
246
247
252
253
check 0
check 0
switch 0
check 4
13
19
53
54
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 6
254
255
260
261
266
267
check 0
switch 5
check 0
check 6
256
257
262
263
268
269
check 0
switch 4
check 0
check 6
258
259
264
265
270
271
check 0
check 0
switch 0
check 4
7
14
20
55
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 10
272
273
278
279
284
285
290
291
296
297
check 0
switch 5
check 0
check 10
274
275
280
281
286
287
292
293
298
299
check 0
switch 4
check 0
check 10
276
277
282
283
288
289
294
295
300
301
check 0
check 0
switch 0
check 0
switch 1
check 2
56
57
check 3
302
303
304
check 0
check 0
switch 1
check 2
21
58
check 6
305
306
307
308
309
310
check 0
check 0
switch 1
check 3
22
59
60
check 5
311
312
313
314
315
check 0
check 0
switch 1
check 1
61
check 1
316
check 0
check 0
switch 1
check 4
23
62
63
64
check 3
317
318
319
check 0
switch 2
check 0
check 1
33
check 0
check 0
switch 1
check 1
65
check 6
320
321
322
323
324
325
check 0
check 0
switch 1
check 4
66
67
68
69
check 1
326
check 0
check 0
switch 1
check 3
24
70
71
check 5
327
328
329
330
331
check 0
check 0
switch 1
check 2
25
72
check 3
332
333
334
check 0
check 0
switch 1
check 2
26
73
check 5
335
336
337
338
339
check 0
check 0
check 0
end_SG
begin_DTG
2
4
56
0
7
57
0
1
2
58
0
2
1
59
0
6
60
0
1
7
61
0
3
0
62
0
5
63
0
6
64
0
1
4
65
0
4
2
66
0
4
67
0
8
68
0
9
69
0
2
0
70
0
3
71
0
1
6
72
0
1
6
73
0
end_DTG
begin_DTG
10
1
331
1
0 7
1
322
1
0 5
1
326
1
0 6
1
332
1
0 8
1
335
1
0 9
1
312
1
0 2
1
303
1
0 0
1
305
1
0 1
1
316
1
0 3
1
317
1
0 4
6
0
21
1
0 1
0
22
1
0 2
0
23
1
0 4
0
24
1
0 7
0
25
1
0 8
0
26
1
0 9
end_DTG
begin_DTG
0
2
0
322
2
0 5
1 0
0
326
2
0 6
1 0
end_DTG
begin_DTG
2
4
34
0
7
35
0
2
2
36
0
8
37
0
2
1
38
0
6
39
0
1
7
40
0
3
0
41
0
5
42
0
6
43
0
1
4
44
0
5
2
45
0
4
46
0
7
47
0
8
48
0
9
49
0
3
0
50
0
3
51
0
6
52
0
2
1
53
0
6
54
0
1
6
55
0
end_DTG
begin_DTG
10
1
217
1
3 5
1
246
1
3 7
1
223
1
3 6
1
276
1
3 9
1
271
1
3 8
1
103
1
3 1
1
132
1
3 2
1
91
1
3 0
1
162
1
3 3
1
181
1
3 4
6
0
15
1
3 1
0
16
1
3 2
0
17
1
3 4
0
18
1
3 7
0
19
1
3 8
0
20
1
3 9
end_DTG
begin_DTG
10
1
215
1
3 5
1
244
1
3 7
1
221
1
3 6
1
274
1
3 9
1
269
1
3 8
1
101
1
3 1
1
130
1
3 2
1
89
1
3 0
1
160
1
3 3
1
179
1
3 4
7
0
8
1
3 0
0
9
1
3 1
0
10
1
3 2
0
11
1
3 5
0
12
1
3 7
0
13
1
3 8
0
14
1
3 9
end_DTG
begin_DTG
0
4
0
196
2
3 5
5 0
0
199
2
3 5
4 0
0
220
2
3 6
5 0
0
223
2
3 6
4 0
end_DTG
begin_DTG
0
2
0
29
2
3 4
6 0
0
33
2
0 4
2 0
end_DTG
begin_DTG
10
1
213
1
3 5
1
242
1
3 7
1
219
1
3 6
1
272
1
3 9
1
267
1
3 8
1
99
1
3 1
1
128
1
3 2
1
87
1
3 0
1
158
1
3 3
1
177
1
3 4
8
0
0
1
3 0
0
1
1
3 1
0
2
1
3 2
0
3
1
3 3
0
4
1
3 4
0
5
1
3 5
0
6
1
3 7
0
7
1
3 9
end_DTG
begin_DTG
0
8
0
153
2
3 2
8 0
0
155
2
3 2
5 0
0
213
2
3 5
8 0
0
215
2
3 5
5 0
0
249
2
3 7
8 0
0
251
2
3 7
5 0
0
297
2
3 9
8 0
0
299
2
3 9
5 0
end_DTG
begin_DTG
0
1
0
32
2
3 4
9 0
end_DTG
begin_DTG
0
8
0
86
2
3 0
8 0
0
90
2
3 0
4 0
0
122
2
3 1
8 0
0
126
2
3 1
4 0
0
176
2
3 4
8 0
0
180
2
3 4
4 0
0
242
2
3 7
8 0
0
246
2
3 7
4 0
end_DTG
begin_DTG
0
1
0
31
2
3 4
11 0
end_DTG
begin_DTG
0
4
0
206
2
3 5
8 0
0
210
2
3 5
4 0
0
290
2
3 9
8 0
0
294
2
3 9
4 0
end_DTG
begin_DTG
0
1
0
30
2
3 4
13 0
end_DTG
begin_DTG
0
16
0
81
2
3 0
8 0
0
83
2
3 0
5 0
0
105
2
3 1
8 0
0
107
2
3 1
5 0
0
141
2
3 2
8 0
0
143
2
3 2
5 0
0
159
2
3 3
8 0
0
161
2
3 3
5 0
0
171
2
3 4
8 0
0
173
2
3 4
5 0
0
189
2
3 5
8 0
0
191
2
3 5
5 0
0
237
2
3 7
8 0
0
239
2
3 7
5 0
0
285
2
3 9
8 0
0
287
2
3 9
5 0
end_DTG
begin_DTG
0
1
0
28
2
3 4
15 0
end_DTG
begin_DTG
0
14
0
74
2
3 0
8 0
0
78
2
3 0
4 0
0
92
2
3 1
8 0
0
96
2
3 1
4 0
0
128
2
3 2
8 0
0
132
2
3 2
4 0
0
182
2
3 5
8 0
0
186
2
3 5
4 0
0
224
2
3 7
8 0
0
228
2
3 7
4 0
0
254
2
3 8
8 0
0
258
2
3 8
4 0
0
272
2
3 9
8 0
0
276
2
3 9
4 0
end_DTG
begin_DTG
0
1
0
27
2
3 4
17 0
end_DTG
begin_CG
3
1 44
7 1
2 2
1
2 2
1
7 1
15
8 84
5 83
4 82
18 1
16 1
7 1
14 1
12 1
10 1
17 14
15 16
6 4
13 4
11 8
9 8
4
17 7
6 2
13 2
11 4
3
15 8
6 2
9 4
1
7 1
0
5
17 7
15 8
13 2
11 4
9 4
1
10 1
0
1
12 1
0
1
14 1
0
1
16 1
0
1
18 1
0
end_CG
