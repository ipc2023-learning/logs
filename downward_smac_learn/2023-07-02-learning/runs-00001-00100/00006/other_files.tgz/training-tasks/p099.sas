begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera2, rover4)
NegatedAtom calibrated(camera2, rover4)
end_variable
begin_variable
var144
-1
2
Atom have_image(rover4, objective9, colour)
NegatedAtom have_image(rover4, objective9, colour)
end_variable
begin_variable
var132
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var119
-1
2
Atom have_image(rover4, objective1, low_res)
NegatedAtom have_image(rover4, objective1, low_res)
end_variable
begin_variable
var118
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint10)
Atom have_soil_analysis(rover4, waypoint10)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover4, waypoint4)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover4, waypoint5)
end_variable
begin_variable
var9
-1
2
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover4, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom at_soil_sample(waypoint8)
Atom have_soil_analysis(rover4, waypoint8)
end_variable
begin_variable
var11
-1
2
Atom at_soil_sample(waypoint9)
Atom have_soil_analysis(rover4, waypoint9)
end_variable
begin_variable
var56
-1
2
Atom empty(rover4store)
Atom full(rover4store)
end_variable
begin_variable
var53
-1
2
Atom communicated_soil_data(waypoint9)
NegatedAtom communicated_soil_data(waypoint9)
end_variable
begin_variable
var52
-1
2
Atom communicated_soil_data(waypoint8)
NegatedAtom communicated_soil_data(waypoint8)
end_variable
begin_variable
var51
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var48
-1
2
Atom communicated_soil_data(waypoint10)
NegatedAtom communicated_soil_data(waypoint10)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var114
-1
2
Atom have_image(rover3, objective9, colour)
NegatedAtom have_image(rover3, objective9, colour)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover3, objective5, colour)
NegatedAtom have_image(rover3, objective5, colour)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var88
-1
2
Atom have_image(rover3, objective1, high_res)
NegatedAtom have_image(rover3, objective1, high_res)
end_variable
begin_variable
var1
-1
10
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint10)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera4, rover2)
NegatedAtom calibrated(camera4, rover2)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover2, objective9, colour)
NegatedAtom have_image(rover2, objective9, colour)
end_variable
begin_variable
var43
-1
2
Atom communicated_image_data(objective9, colour)
NegatedAtom communicated_image_data(objective9, colour)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var59
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover2, objective1, high_res)
NegatedAtom have_image(rover2, objective1, high_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
0
begin_state
3
1
1
1
1
1
0
0
0
0
0
0
0
1
1
1
1
9
1
1
1
1
1
1
4
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
13 0
14 0
15 0
16 0
27 0
29 0
31 0
33 0
end_goal
772
begin_operator
calibrate rover2 camera4 objective3 wa




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7
2
0 1
9 1
0
138
2
0 2
9 1
0
139
2
0 3
9 1
0
140
2
0 4
9 1
0
141
2
0 5
9 1
0
142
2
0 6
9 1
0
143
2
0 7
9 1
0
144
2
0 9
9 1
end_DTG
begin_DTG
0
9
0
127
2
0 0
6 1
0
128
2
0 1
6 1
0
129
2
0 2
6 1
0
130
2
0 3
6 1
0
131
2
0 4
6 1
0
132
2
0 5
6 1
0
133
2
0 6
6 1
0
134
2
0 7
6 1
0
135
2
0 9
6 1
end_DTG
begin_DTG
5
3
202
0
4
203
0
6
204
0
8
205
0
9
206
0
2
4
207
0
9
208
0
3
4
209
0
6
210
0
8
211
0
2
0
212
0
5
213
0
7
0
214
0
1
215
0
2
216
0
5
217
0
7
218
0
8
219
0
9
220
0
4
3
221
0
4
222
0
7
223
0
8
224
0
2
0
225
0
2
226
0
3
4
227
0
5
228
0
8
229
0
6
0
230
0
2
231
0
4
232
0
5
233
0
7
234
0
9
235
0
4
0
236
0
1
237
0
4
238
0
8
239
0
end_DTG
begin_DTG
10
1
580
1
17 7
1
532
1
17 4
1
540
1
17 5
1
552
1
17 6
1
588
1
17 8
1
604
1
17 9
1
480
1
17 2
1
436
1
17 0
1
456
1
17 1
1
496
1
17 3
8
0
7
1
17 0
0
8
1
17 1
0
9
1
17 2
0
10
1
17 3
0
11
1
17 4
0
12
1
17 5
0
13
1
17 6
0
14
1
17 8
end_DTG
begin_DTG
10
1
563
1
17 6
1
573
1
17 7
1
538
1
17 5
1
527
1
17 4
1
613
1
17 9
1
599
1
17 8
1
466
1
17 1
1
477
1
17 2
1
441
1
17 0
1
503
1
17 3
4
0
3
1
17 0
0
4
1
17 1
0
5
1
17 2
0
6
1
17 7
end_DTG
begin_DTG
0
8
0
449
2
17 0
19 0
0
473
2
17 1
19 0
0
489
2
17 2
19 0
0
509
2
17 3
19 0
0
533
2
17 4
19 0
0
569
2
17 6
19 0
0
581
2
17 7
19 0
0
621
2
17 9
19 0
end_DTG
begin_DTG
0
4
0
437
2
17 0
19 0
0
541
2
17 5
19 0
0
593
2
17 8
19 0
0
609
2
17 9
19 0
end_DTG
begin_DTG
0
12
0
431
2
17 0
19 0
0
432
2
17 0
18 0
0
455
2
17 1
19 0
0
456
2
17 1
18 0
0
479
2
17 2
19 0
0
480
2
17 2
18 0
0
495
2
17 3
19 0
0
496
2
17 3
18 0
0
515
2
17 4
19 0
0
516
2
17 4
18 0
0
551
2
17 6
19 0
0
552
2
17 6
18 0
end_DTG
begin_DTG
0
6
0
430
2
17 0
19 0
0
454
2
17 1
19 0
0
478
2
17 2
19 0
0
494
2
17 3
19 0
0
514
2
17 4
19 0
0
550
2
17 6
19 0
end_DTG
begin_DTG
4
3
164
0
4
165
0
6
166
0
9
167
0
5
2
168
0
3
169
0
4
170
0
5
171
0
8
172
0
3
1
173
0
4
174
0
8
175
0
3
0
176
0
1
177
0
7
178
0
5
0
179
0
1
180
0
2
181
0
7
182
0
9
183
0
3
1
184
0
7
185
0
8
186
0
3
0
187
0
7
188
0
9
189
0
4
3
190
0
4
191
0
5
192
0
6
193
0
4
1
194
0
2
195
0
5
196
0
9
197
0
4
0
198
0
4
199
0
6
200
0
8
201
0
end_DTG
begin_DTG
10
1
383
1
24 6
1
390
1
24 7
1
364
1
24 5
1
356
1
24 4
1
420
1
24 9
1
410
1
24 8
1
310
1
24 1
1
318
1
24 2
1
291
1
24 0
1
338
1
24 3
3
0
0
1
24 6
0
1
1
24 8
0
2
1
24 9
end_DTG
begin_DTG
0
8
0
297
2
24 0
25 0
0
315
2
24 1
25 0
0
327
2
24 2
25 0
0
342
2
24 3
25 0
0
360
2
24 4
25 0
0
387
2
24 6
25 0
0
396
2
24 7
25 0
0
426
2
24 9
25 0
end_DTG
begin_DTG
0
27
0
86
2
17 4
20 0
0
126
2
0 9
2 0
0
125
2
0 7
2 0
0
124
2
0 6
2 0
0
123
2
0 5
2 0
0
122
2
0 4
2 0
0
121
2
0 3
2 0
0
120
2
0 2
2 0
0
119
2
0 1
2 0
0
118
2
0 0
2 0
0
90
2
17 9
20 0
0
89
2
17 7
20 0
0
88
2
17 6
20 0
0
87
2
17 5
20 0
0
46
2
24 0
26 0
0
85
2
17 3
20 0
0
84
2
17 2
20 0
0
83
2
17 1
20 0
0
82
2
17 0
20 0
0
54
2
24 9
26 0
0
53
2
24 7
26 0
0
52
2
24 6
26 0
0
51
2
24 5
26 0
0
50
2
24 4
26 0
0
49
2
24 3
26 0
0
48
2
24 2
26 0
0
47
2
24 1
26 0
end_DTG
begin_DTG
0
4
0
288
2
24 0
25 0
0
366
2
24 5
25 0
0
405
2
24 8
25 0
0
417
2
24 9
25 0
end_DTG
begin_DTG
0
27
0
77
2
17 4
21 0
0
117
2
0 9
3 0
0
116
2
0 7
3 0
0
115
2
0 6
3 0
0
114
2
0 5
3 0
0
113
2
0 4
3 0
0
112
2
0 3
3 0
0
111
2
0 2
3 0
0
110
2
0 1
3 0
0
109
2
0 0
3 0
0
81
2
17 9
21 0
0
80
2
17 7
21 0
0
79
2
17 6
21 0
0
78
2
17 5
21 0
0
37
2
24 0
28 0
0
76
2
17 3
21 0
0
75
2
17 2
21 0
0
74
2
17 1
21 0
0
73
2
17 0
21 0
0
45
2
24 9
28 0
0
44
2
24 7
28 0
0
43
2
24 6
28 0
0
42
2
24 5
28 0
0
41
2
24 4
28 0
0
40
2
24 3
28 0
0
39
2
24 2
28 0
0
38
2
24 1
28 0
end_DTG
begin_DTG
0
6
0
284
2
24 0
25 0
0
302
2
24 1
25 0
0
320
2
24 2
25 0
0
332
2
24 3
25 0
0
347
2
24 4
25 0
0
374
2
24 6
25 0
end_DTG
begin_DTG
0
27
0
68
2
17 4
22 0
0
108
2
0 9
4 0
0
107
2
0 7
4 0
0
106
2
0 6
4 0
0
105
2
0 5
4 0
0
104
2
0 4
4 0
0
103
2
0 3
4 0
0
102
2
0 2
4 0
0
101
2
0 1
4 0
0
100
2
0 0
4 0
0
72
2
17 9
22 0
0
71
2
17 7
22 0
0
70
2
17 6
22 0
0
69
2
17 5
22 0
0
28
2
24 0
30 0
0
67
2
17 3
22 0
0
66
2
17 2
22 0
0
65
2
17 1
22 0
0
64
2
17 0
22 0
0
36
2
24 9
30 0
0
35
2
24 7
30 0
0
34
2
24 6
30 0
0
33
2
24 5
30 0
0
32
2
24 4
30 0
0
31
2
24 3
30 0
0
30
2
24 2
30 0
0
29
2
24 1
30 0
end_DTG
begin_DTG
0
6
0
283
2
24 0
25 0
0
301
2
24 1
25 0
0
319
2
24 2
25 0
0
331
2
24 3
25 0
0
346
2
24 4
25 0
0
373
2
24 6
25 0
end_DTG
begin_DTG
0
27
0
59
2
17 4
23 0
0
99
2
0 9
5 0
0
98
2
0 7
5 0
0
97
2
0 6
5 0
0
96
2
0 5
5 0
0
95
2
0 4
5 0
0
94
2
0 3
5 0
0
93
2
0 2
5 0
0
92
2
0 1
5 0
0
91
2
0 0
5 0
0
63
2
17 9
23 0
0
62
2
17 7
23 0
0
61
2
17 6
23 0
0
60
2
17 5
23 0
0
19
2
24 0
32 0
0
58
2
17 3
23 0
0
57
2
17 2
23 0
0
56
2
17 1
23 0
0
55
2
17 0
23 0
0
27
2
24 9
32 0
0
26
2
24 7
32 0
0
25
2
24 6
32 0
0
24
2
24 5
32 0
0
23
2
24 4
32 0
0
22
2
24 3
32 0
0
21
2
24 2
32 0
0
20
2
24 1
32 0
end_DTG
begin_CG
20
6 1
7 1
8 1
9 1
10 1
11 1
1 151
33 9
31 9
29 9
27 9
16 9
15 9
14 9
13 9
12 6
5 6
4 6
3 4
2 8
4
5 6
4 6
3 4
2 8
1
27 9
1
29 9
1
31 9
1
33 9
2
16 9
12 1
1
12 1
1
12 1
2
15 9
12 1
2
14 9
12 1
2
13 9
12 1
6
6 1
7 1
8 1
9 1
10 1
11 1
0
0
0
0
10
19 151
18 57
33 9
31 9
29 9
27 9
23 6
22 12
21 4
20 8
1
22 6
4
23 6
22 6
21 4
20 8
1
27 9
1
29 9
1
31 9
1
33 9
9
25 150
33 9
31 9
29 9
27 9
32 6
30 6
28 4
26 8
4
32 6
30 6
28 4
26 8
1
27 9
0
1
29 9
0
1
31 9
0
1
33 9
0
end_CG
