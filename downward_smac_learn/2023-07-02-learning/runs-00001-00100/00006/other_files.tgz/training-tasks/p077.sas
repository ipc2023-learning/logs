begin_version
3
end_version
begin_metric
0
end_metric
68
begin_variable
var3
-1
9
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var79
-1
2
Atom have_image(rover2, objective8, colour)
NegatedAtom have_image(rover2, objective8, colour)
end_variable
begin_variable
var39
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover2, objective7, colour)
NegatedAtom have_image(rover2, objective7, colour)
end_variable
begin_variable
var36
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover2, objective6, colour)
NegatedAtom have_image(rover2, objective6, colour)
end_variable
begin_variable
var33
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover2, objective4, colour)
NegatedAtom have_image(rover2, objective4, colour)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var73
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera4, rover1)
NegatedAtom calibrated(camera4, rover1)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover1, objective7, high_res)
NegatedAtom have_image(rover1, objective7, high_res)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective6, high_res)
NegatedAtom have_image(rover1, objective6, high_res)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var64
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




19 0
0
343
2
18 5
20 0
0
345
2
18 5
19 0
0
358
2
18 6
20 0
0
360
2
18 6
19 0
end_DTG
begin_DTG
0
3
0
22
2
18 1
31 0
0
23
2
18 2
31 0
0
24
2
18 5
31 0
end_DTG
begin_DTG
0
2
0
263
2
18 1
20 0
0
265
2
18 1
19 0
end_DTG
begin_DTG
0
3
0
16
2
18 1
33 0
0
17
2
18 2
33 0
0
18
2
18 5
33 0
end_DTG
begin_DTG
9
1
312
1
18 3
1
372
1
18 8
1
362
1
18 7
1
357
1
18 6
1
352
1
18 5
1
337
1
18 4
1
247
1
18 0
1
297
1
18 2
1
282
1
18 1
2
0
0
1
18 1
0
1
1
18 3
end_DTG
begin_DTG
0
3
0
327
2
18 3
35 0
0
329
2
18 3
20 0
0
331
2
18 3
19 0
end_DTG
begin_DTG
0
3
0
49
2
18 1
36 0
0
50
2
18 2
36 0
0
51
2
18 5
36 0
end_DTG
begin_DTG
0
6
0
277
2
18 1
35 0
0
279
2
18 1
20 0
0
281
2
18 1
19 0
0
312
2
18 3
35 0
0
314
2
18 3
20 0
0
316
2
18 3
19 0
end_DTG
begin_DTG
0
3
0
40
2
18 1
38 0
0
41
2
18 2
38 0
0
42
2
18 5
38 0
end_DTG
begin_DTG
0
9
0
272
2
18 1
35 0
0
274
2
18 1
20 0
0
276
2
18 1
19 0
0
292
2
18 2
35 0
0
294
2
18 2
20 0
0
296
2
18 2
19 0
0
307
2
18 3
35 0
0
309
2
18 3
20 0
0
311
2
18 3
19 0
end_DTG
begin_DTG
0
3
0
31
2
18 1
40 0
0
32
2
18 2
40 0
0
33
2
18 5
40 0
end_DTG
begin_DTG
0
21
0
304
2
18 3
20 0
0
361
2
18 6
19 0
0
359
2
18 6
20 0
0
357
2
18 6
35 0
0
346
2
18 5
19 0
0
344
2
18 5
20 0
0
342
2
18 5
35 0
0
336
2
18 4
19 0
0
334
2
18 4
20 0
0
332
2
18 4
35 0
0
306
2
18 3
19 0
0
247
2
18 0
35 0
0
302
2
18 3
35 0
0
291
2
18 2
19 0
0
289
2
18 2
20 0
0
287
2
18 2
35 0
0
271
2
18 1
19 0
0
269
2
18 1
20 0
0
267
2
18 1
35 0
0
251
2
18 0
19 0
0
249
2
18 0
20 0
end_DTG
begin_DTG
0
3
0
25
2
18 1
42 0
0
26
2
18 2
42 0
0
27
2
18 5
42 0
end_DTG
begin_DTG
0
3
0
262
2
18 1
35 0
0
264
2
18 1
20 0
0
266
2
18 1
19 0
end_DTG
begin_DTG
0
3
0
19
2
18 1
44 0
0
20
2
18 2
44 0
0
21
2
18 5
44 0
end_DTG
begin_DTG
1
1
241
2
0 0
58 0
0
end_DTG
begin_DTG
1
1
242
2
0 1
58 0
0
end_DTG
begin_DTG
1
1
243
2
0 4
58 0
0
end_DTG
begin_DTG
1
1
244
2
0 5
58 0
0
end_DTG
begin_DTG
1
1
245
2
0 6
58 0
0
end_DTG
begin_DTG
1
1
246
2
0 7
58 0
0
end_DTG
begin_DTG
4
1
225
2
18 0
53 0
2
229
2
2 0
54 0
3
233
2
1 0
57 0
4
237
2
0 0
58 0
0
0
0
0
end_DTG
begin_DTG
4
1
225
2
18 0
52 0
1
226
2
18 1
55 0
1
227
2
18 7
56 0
1
228
2
18 8
59 0
1
0
133
0
end_DTG
begin_DTG
4
1
229
2
2 0
52 0
1
230
2
2 1
55 0
1
231
2
2 7
56 0
1
232
2
2 8
59 0
1
0
134
0
end_DTG
begin_DTG
4
1
226
2
18 1
53 0
2
230
2
2 1
54 0
3
234
2
1 1
57 0
4
238
2
0 1
58 0
0
0
0
0
end_DTG
begin_DTG
4
1
227
2
18 7
53 0
2
231
2
2 7
54 0
3
235
2
1 7
57 0
4
239
2
0 7
58 0
0
0
0
0
end_DTG
begin_DTG
4
1
233
2
1 0
52 0
1
234
2
1 1
55 0
1
235
2
1 7
56 0
1
236
2
1 8
59 0
1
0
135
0
end_DTG
begin_DTG
10
1
237
2
0 0
52 0
1
238
2
0 1
55 0
1
239
2
0 7
56 0
1
240
2
0 8
59 0
1
241
2
0 0
46 0
1
242
2
0 1
47 0
1
243
2
0 4
48 0
1
244
2
0 5
49 0
1
245
2
0 6
50 0
1
246
2
0 7
51 0
1
0
136
0
end_DTG
begin_DTG
4
1
228
2
18 8
53 0
2
232
2
2 8
54 0
3
236
2
1 8
57 0
4
240
2
0 8
58 0
0
0
0
0
end_DTG
begin_DTG
0
3
0
130
2
0 1
50 1
0
131
2
0 2
50 1
0
132
2
0 5
50 1
end_DTG
begin_DTG
0
3
0
127
2
0 1
49 1
0
128
2
0 2
49 1
0
129
2
0 5
49 1
end_DTG
begin_DTG
0
3
0
124
2
0 1
48 1
0
125
2
0 2
48 1
0
126
2
0 5
48 1
end_DTG
begin_DTG
0
3
0
121
2
0 1
47 1
0
122
2
0 2
47 1
0
123
2
0 5
47 1
end_DTG
begin_DTG
0
12
0
82
2
18 1
59 1
0
83
2
18 2
59 1
0
84
2
18 5
59 1
0
94
2
2 1
59 2
0
95
2
2 2
59 2
0
96
2
2 5
59 2
0
106
2
1 1
59 3
0
107
2
1 2
59 3
0
108
2
1 5
59 3
0
118
2
0 1
59 4
0
119
2
0 2
59 4
0
120
2
0 5
59 4
end_DTG
begin_DTG
0
12
0
79
2
18 1
56 1
0
80
2
18 2
56 1
0
81
2
18 5
56 1
0
91
2
2 1
56 2
0
92
2
2 2
56 2
0
93
2
2 5
56 2
0
103
2
1 1
56 3
0
104
2
1 2
56 3
0
105
2
1 5
56 3
0
115
2
0 1
56 4
0
116
2
0 2
56 4
0
117
2
0 5
56 4
end_DTG
begin_DTG
0
12
0
76
2
18 1
55 1
0
77
2
18 2
55 1
0
78
2
18 5
55 1
0
88
2
2 1
55 2
0
89
2
2 2
55 2
0
90
2
2 5
55 2
0
100
2
1 1
55 3
0
101
2
1 2
55 3
0
102
2
1 5
55 3
0
112
2
0 1
55 4
0
113
2
0 2
55 4
0
114
2
0 5
55 4
end_DTG
begin_DTG
0
12
0
73
2
18 1
52 1
0
74
2
18 2
52 1
0
75
2
18 5
52 1
0
85
2
2 1
52 2
0
86
2
2 2
52 2
0
87
2
2 5
52 2
0
97
2
1 1
52 3
0
98
2
1 2
52 3
0
99
2
1 5
52 3
0
109
2
0 1
52 4
0
110
2
0 2
52 4
0
111
2
0 5
52 4
end_DTG
begin_CG
19
52 1
55 1
56 1
59 1
46 1
47 1
48 1
49 1
50 1
51 1
67 3
66 3
65 3
64 3
63 3
62 3
61 3
60 3
58 10
9
52 1
55 1
56 1
59 1
67 3
66 3
65 3
64 3
57 4
24
52 1
55 1
56 1
59 1
3 30
17 3
15 3
13 3
11 3
9 3
7 3
5 3
67 3
66 3
65 3
64 3
54 4
16 1
14 7
12 3
10 2
8 6
6 4
4 1
7
16 1
14 7
12 3
10 2
8 6
6 4
4 1
1
5 3
0
1
7 3
0
1
9 3
0
1
11 3
0
1
13 3
0
1
15 3
0
1
17 3
0
36
52 1
55 1
56 1
59 1
35 28
20 55
19 59
34 3
45 3
32 3
43 3
30 3
41 3
28 3
26 3
39 3
24 3
22 3
37 3
67 3
66 3
65 3
64 3
53 4
33 2
44 3
31 14
42 21
29 6
40 9
27 4
25 4
38 6
23 12
21 8
36 3
12
33 1
44 1
31 7
42 7
29 3
40 3
27 2
25 2
38 2
23 6
21 4
36 1
12
33 1
44 1
31 7
42 7
29 3
40 3
27 2
25 2
38 2
23 6
21 4
36 1
1
22 3
0
1
24 3
0
1
26 3
0
1
28 3
0
1
30 3
0
1
32 3
0
1
34 3
0
5
44 1
42 7
40 3
38 2
36 1
1
37 3
0
1
39 3
0
1
41 3
0
1
43 3
0
1
45 3
0
1
58 1
2
63 3
58 1
2
62 3
58 1
2
61 3
58 1
2
60 3
58 1
1
58 1
5
67 12
53 1
54 1
57 1
58 1
4
52 1
55 1
56 1
59 1
4
52 1
55 1
56 1
59 1
5
66 12
53 1
54 1
57 1
58 1
5
65 12
53 1
54 1
57 1
58 1
4
52 1
55 1
56 1
59 1
10
52 1
55 1
56 1
59 1
46 1
47 1
48 1
49 1
50 1
51 1
5
64 12
53 1
54 1
57 1
58 1
0
0
0
0
0
0
0
0
end_CG
