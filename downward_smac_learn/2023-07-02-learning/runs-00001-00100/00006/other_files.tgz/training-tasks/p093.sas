begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera2, rover3)
NegatedAtom calibrated(camera2, rover3)
end_variable
begin_variable
var116
-1
2
Atom have_image(rover3, objective9, low_res)
NegatedAtom have_image(rover3, objective9, low_res)
end_variable
begin_variable
var111
-1
2
Atom have_image(rover3, objective8, colour)
NegatedAtom have_image(rover3, objective8, colour)
end_variable
begin_variable
var106
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var105
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover3, objective5, colour)
NegatedAtom have_image(rover3, objective5, colour)
end_variable
begin_variable
var100
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var98
-1
2
Atom have_image(rover3, objective3, low_res)
NegatedAtom have_image(rover3, objective3, low_res)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover3, objective3, colour)
NegatedAtom have_image(rover3, objective3, colour)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover3, objective2, high_res)
NegatedAtom have_image(rover3, objective2, high_res)
end_variable
begin_variable
var93
-1
2
Atom have_image(rover3, objective2, colour)
NegatedAtom have_image(rover3, objective2, colour)
end_variable
begin_variable
var91
-1
2
Atom have_image(rover3, objective10, high_res)
NegatedAtom have_image(rover3, objective10, high_res)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var0
-1
10
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint10)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera4, rover1)
NegatedAtom calibrated(camera4, rover1)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover1, objective9, low_res)
NegatedAtom have_image(rover1, objective9, low_res)
end_variable
begin_variable
var45
-1
2
Atom communicated_image_data(objective9, low_res)
NegatedAtom communicated_image_data(objective9, low_res)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover1, objective8, colour)
NegatedAtom have_image(rover1, objective8, colour)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover1, objective5, colour)
NegatedAtom have_image(rover1, objective5, colour)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var59
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover1, objective6, high_res)
NegatedAtom have_image(rover1, objective6, high_r




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8
21 0
0
105
2
15 7
21 0
0
104
2
15 6
21 0
0
103
2
15 5
21 0
0
102
2
15 3
21 0
0
101
2
15 2
21 0
0
100
2
15 1
21 0
end_DTG
begin_DTG
0
9
0
341
2
15 0
16 0
0
365
2
15 1
16 0
0
401
2
15 3
16 0
0
419
2
15 4
16 0
0
437
2
15 5
16 0
0
461
2
15 6
16 0
0
476
2
15 7
16 0
0
494
2
15 8
16 0
0
521
2
15 9
16 0
end_DTG
begin_DTG
0
18
0
198
2
0 0
7 0
0
206
2
0 9
7 0
0
205
2
0 8
7 0
0
204
2
0 7
7 0
0
203
2
0 6
7 0
0
202
2
0 5
7 0
0
201
2
0 3
7 0
0
200
2
0 2
7 0
0
199
2
0 1
7 0
0
90
2
15 0
23 0
0
98
2
15 9
23 0
0
97
2
15 8
23 0
0
96
2
15 7
23 0
0
95
2
15 6
23 0
0
94
2
15 5
23 0
0
93
2
15 3
23 0
0
92
2
15 2
23 0
0
91
2
15 1
23 0
end_DTG
begin_DTG
0
5
0
339
2
15 0
16 0
0
363
2
15 1
16 0
0
417
2
15 4
16 0
0
459
2
15 6
16 0
0
516
2
15 9
16 0
end_DTG
begin_DTG
0
18
0
180
2
0 0
9 0
0
188
2
0 9
9 0
0
187
2
0 8
9 0
0
186
2
0 7
9 0
0
185
2
0 6
9 0
0
184
2
0 5
9 0
0
183
2
0 3
9 0
0
182
2
0 2
9 0
0
181
2
0 1
9 0
0
72
2
15 0
25 0
0
80
2
15 9
25 0
0
79
2
15 8
25 0
0
78
2
15 7
25 0
0
77
2
15 6
25 0
0
76
2
15 5
25 0
0
75
2
15 3
25 0
0
74
2
15 2
25 0
0
73
2
15 1
25 0
end_DTG
begin_DTG
0
5
0
338
2
15 0
16 0
0
362
2
15 1
16 0
0
416
2
15 4
16 0
0
458
2
15 6
16 0
0
515
2
15 9
16 0
end_DTG
begin_DTG
0
18
0
171
2
0 0
10 0
0
179
2
0 9
10 0
0
178
2
0 8
10 0
0
177
2
0 7
10 0
0
176
2
0 6
10 0
0
175
2
0 5
10 0
0
174
2
0 3
10 0
0
173
2
0 2
10 0
0
172
2
0 1
10 0
0
63
2
15 0
27 0
0
71
2
15 9
27 0
0
70
2
15 8
27 0
0
69
2
15 7
27 0
0
68
2
15 6
27 0
0
67
2
15 5
27 0
0
66
2
15 3
27 0
0
65
2
15 2
27 0
0
64
2
15 1
27 0
end_DTG
begin_DTG
0
8
0
335
2
15 0
16 0
0
383
2
15 2
16 0
0
413
2
15 4
16 0
0
434
2
15 5
16 0
0
455
2
15 6
16 0
0
470
2
15 7
16 0
0
491
2
15 8
16 0
0
512
2
15 9
16 0
end_DTG
begin_DTG
0
18
0
153
2
0 0
12 0
0
161
2
0 9
12 0
0
160
2
0 8
12 0
0
159
2
0 7
12 0
0
158
2
0 6
12 0
0
157
2
0 5
12 0
0
156
2
0 3
12 0
0
155
2
0 2
12 0
0
154
2
0 1
12 0
0
45
2
15 0
29 0
0
53
2
15 9
29 0
0
52
2
15 8
29 0
0
51
2
15 7
29 0
0
50
2
15 6
29 0
0
49
2
15 5
29 0
0
48
2
15 3
29 0
0
47
2
15 2
29 0
0
46
2
15 1
29 0
end_DTG
begin_DTG
0
10
0
333
2
15 0
16 0
0
357
2
15 1
16 0
0
381
2
15 2
16 0
0
393
2
15 3
16 0
0
411
2
15 4
16 0
0
432
2
15 5
16 0
0
453
2
15 6
16 0
0
468
2
15 7
16 0
0
489
2
15 8
16 0
0
510
2
15 9
16 0
end_DTG
begin_DTG
0
18
0
135
2
0 0
14 0
0
143
2
0 9
14 0
0
142
2
0 8
14 0
0
141
2
0 7
14 0
0
140
2
0 6
14 0
0
139
2
0 5
14 0
0
138
2
0 3
14 0
0
137
2
0 2
14 0
0
136
2
0 1
14 0
0
27
2
15 0
31 0
0
35
2
15 9
31 0
0
34
2
15 8
31 0
0
33
2
15 7
31 0
0
32
2
15 6
31 0
0
31
2
15 5
31 0
0
30
2
15 3
31 0
0
29
2
15 2
31 0
0
28
2
15 1
31 0
end_DTG
begin_DTG
10
1
454
1
15 6
1
478
1
15 7
1
448
1
15 5
1
487
1
15 8
1
508
1
15 9
1
355
1
15 1
1
379
1
15 2
1
352
1
15 0
1
391
1
15 3
1
409
1
15 4
2
0
0
1
15 1
0
1
1
15 3
end_DTG
begin_DTG
0
8
0
343
2
15 0
33 0
0
367
2
15 1
33 0
0
403
2
15 3
33 0
0
421
2
15 4
33 0
0
439
2
15 5
33 0
0
463
2
15 6
33 0
0
478
2
15 7
33 0
0
496
2
15 8
33 0
end_DTG
begin_DTG
0
18
0
216
2
0 0
5 0
0
224
2
0 9
5 0
0
223
2
0 8
5 0
0
222
2
0 7
5 0
0
221
2
0 6
5 0
0
220
2
0 5
5 0
0
219
2
0 3
5 0
0
218
2
0 2
5 0
0
217
2
0 1
5 0
0
108
2
15 0
34 0
0
116
2
15 9
34 0
0
115
2
15 8
34 0
0
114
2
15 7
34 0
0
113
2
15 6
34 0
0
112
2
15 5
34 0
0
111
2
15 3
34 0
0
110
2
15 2
34 0
0
109
2
15 1
34 0
end_DTG
begin_DTG
0
3
0
397
2
15 3
33 0
0
472
2
15 7
33 0
0
517
2
15 9
33 0
end_DTG
begin_DTG
0
18
0
189
2
0 0
8 0
0
197
2
0 9
8 0
0
196
2
0 8
8 0
0
195
2
0 7
8 0
0
194
2
0 6
8 0
0
193
2
0 5
8 0
0
192
2
0 3
8 0
0
191
2
0 2
8 0
0
190
2
0 1
8 0
0
81
2
15 0
36 0
0
89
2
15 9
36 0
0
88
2
15 8
36 0
0
87
2
15 7
36 0
0
86
2
15 6
36 0
0
85
2
15 5
36 0
0
84
2
15 3
36 0
0
83
2
15 2
36 0
0
82
2
15 1
36 0
end_DTG
begin_DTG
0
8
0
334
2
15 0
33 0
0
382
2
15 2
33 0
0
412
2
15 4
33 0
0
433
2
15 5
33 0
0
454
2
15 6
33 0
0
469
2
15 7
33 0
0
490
2
15 8
33 0
0
511
2
15 9
33 0
end_DTG
begin_DTG
0
18
0
162
2
0 0
11 0
0
170
2
0 9
11 0
0
169
2
0 8
11 0
0
168
2
0 7
11 0
0
167
2
0 6
11 0
0
166
2
0 5
11 0
0
165
2
0 3
11 0
0
164
2
0 2
11 0
0
163
2
0 1
11 0
0
54
2
15 0
38 0
0
62
2
15 9
38 0
0
61
2
15 8
38 0
0
60
2
15 7
38 0
0
59
2
15 6
38 0
0
58
2
15 5
38 0
0
57
2
15 3
38 0
0
56
2
15 2
38 0
0
55
2
15 1
38 0
end_DTG
begin_DTG
0
2
0
358
2
15 1
33 0
0
394
2
15 3
33 0
end_DTG
begin_DTG
0
18
0
144
2
0 0
13 0
0
152
2
0 9
13 0
0
151
2
0 8
13 0
0
150
2
0 7
13 0
0
149
2
0 6
13 0
0
148
2
0 5
13 0
0
147
2
0 3
13 0
0
146
2
0 2
13 0
0
145
2
0 1
13 0
0
36
2
15 0
40 0
0
44
2
15 9
40 0
0
43
2
15 8
40 0
0
42
2
15 7
40 0
0
41
2
15 6
40 0
0
40
2
15 5
40 0
0
39
2
15 3
40 0
0
38
2
15 2
40 0
0
37
2
15 1
40 0
end_DTG
begin_CG
26
2 204
1 142
32 9
41 9
30 9
39 9
28 9
26 9
37 9
24 9
22 9
35 9
20 9
18 9
14 10
13 4
12 16
11 16
10 10
9 5
8 6
7 18
6 16
5 16
4 12
3 8
9
13 2
12 8
11 8
10 5
8 3
7 9
6 8
5 8
4 6
12
14 10
13 2
12 8
11 8
10 5
9 5
8 3
7 9
6 8
5 8
4 6
3 8
1
18 9
1
20 9
1
35 9
1
22 9
1
24 9
1
37 9
1
26 9
1
28 9
1
39 9
1
30 9
1
41 9
1
32 9
26
33 68
16 141
32 9
41 9
30 9
39 9
28 9
26 9
37 9
24 9
22 9
35 9
20 9
18 9
31 10
40 2
29 8
38 8
27 5
25 5
36 3
23 9
21 8
34 8
19 6
17 8
8
31 10
29 8
27 5
25 5
23 9
21 8
19 6
17 8
1
18 9
0
1
20 9
0
1
22 9
0
1
24 9
0
1
26 9
0
1
28 9
0
1
30 9
0
1
32 9
0
4
40 2
38 8
36 3
34 8
1
35 9
0
1
37 9
0
1
39 9
0
1
41 9
0
end_CG
