begin_version
3
end_version
begin_metric
0
end_metric
33
begin_variable
var3
-1
9
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera3, rover4)
NegatedAtom calibrated(camera3, rover4)
end_variable
begin_variable
var122
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var120
-1
2
Atom have_image(rover4, objective7, high_res)
NegatedAtom have_image(rover4, objective7, high_res)
end_variable
begin_variable
var115
-1
2
Atom have_image(rover4, objective5, low_res)
NegatedAtom have_image(rover4, objective5, low_res)
end_variable
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera2, rover3)
NegatedAtom calibrated(camera2, rover3)
end_variable
begin_variable
var95
-1
2
Atom have_image(rover3, objective7, high_res)
NegatedAtom have_image(rover3, objective7, high_res)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover3, objective5, low_res)
NegatedAtom have_image(rover3, objective5, low_res)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera4, rover2)
NegatedAtom calibrated(camera4, rover2)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover2, objective8, colour)
NegatedAtom have_image(rover2, objective8, colour)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover2, objective7, high_res)
NegatedAtom have_image(rover2, objective7, high_res)
end_variable
begin_variable
var36
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
Atom have_rock_analysis(rover4, waypoint3)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
Atom have_rock_analysis(rover4, waypoint5)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
Atom have_rock_analysis(rover4, waypoint6)
end_variable
begin_variable
var55
-1
2
Atom empty(rover4store)
Atom full(rover4store)
end_variable
begin_variable
var7
-1
3
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
Atom have_rock_analysis(rover4, waypoint8)
end_variable
begin_variable
var10
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
Atom have_soil_analysis(rover3, waypoint4)
end_variable
begin_variable
var11
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var53
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var54
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var12
-1
3
Atom at_soil_sample(waypoint9)
Atom have_soil_analysis(rover2, waypoint9)
Atom have_soil_analysis(rover3, waypoint9)
end_variable
begin_variable
var52
-1
2
Atom communicated_soil_data(waypoint9)
NegatedAtom communicated_soil_data(waypoint9)
end_variable
begin_variable
var51
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var44
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
0
begin_state
6
1
1
1
1
8
1
1
1
8
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
end_state
begin_goal
6
13 0
15 0
17 0
30 0
31 0
32 0
end_goal
699
begin_operator
calibrate rover2 camera1 objective1 waypoint1
1
9 0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
563
1
5 7
1
504
1
5 1
1
514
1
5 2
1
503
1
5 0
1
523
1
5 3
8
0
11
1
5 0
0
12
1
5 1
0
13
1
5 2
0
14
1
5 3
0
15
1
5 4
0
16
1
5 5
0
17
1
5 6
0
18
1
5 7
end_DTG
begin_DTG
0
8
0
498
2
5 0
6 0
0
506
2
5 1
6 0
0
518
2
5 2
6 0
0
522
2
5 3
6 0
0
534
2
5 4
6 0
0
546
2
5 5
6 0
0
552
2
5 6
6 0
0
558
2
5 7
6 0
end_DTG
begin_DTG
0
5
0
505
2
5 1
6 0
0
531
2
5 4
6 0
0
543
2
5 5
6 0
0
551
2
5 6
6 0
0
571
2
5 8
6 0
end_DTG
begin_DTG
2
4
136
0
7
137
0
1
6
138
0
3
4
139
0
6
140
0
8
141
0
3
4
142
0
5
143
0
7
144
0
5
0
145
0
2
146
0
3
147
0
6
148
0
7
149
0
3
3
150
0
7
151
0
8
152
0
4
1
153
0
2
154
0
4
155
0
7
156
0
6
0
157
0
3
158
0
4
159
0
5
160
0
6
161
0
8
162
0
3
2
163
0
5
164
0
7
165
0
end_DTG
begin_DTG
9
1
402
1
9 5
1
432
1
9 6
1
379
1
9 4
1
463
1
9 8
1
457
1
9 7
1
281
1
9 1
1
311
1
9 2
1
277
1
9 0
1
337
1
9 3
8
0
3
1
9 0
0
4
1
9 1
0
5
1
9 2
0
6
1
9 4
0
7
1
9 5
0
8
1
9 6
0
9
1
9 7
0
10
1
9 8
end_DTG
begin_DTG
9
1
399
1
9 5
1
429
1
9 6
1
376
1
9 4
1
460
1
9 8
1
454
1
9 7
1
278
1
9 1
1
308
1
9 2
1
274
1
9 0
1
334
1
9 3
3
0
0
1
9 0
0
1
1
9 2
0
2
1
9 4
end_DTG
begin_DTG
0
6
0
266
2
9 0
11 0
0
269
2
9 0
10 0
0
428
2
9 6
11 0
0
431
2
9 6
10 0
0
446
2
9 7
11 0
0
449
2
9 7
10 0
end_DTG
begin_DTG
0
16
0
37
2
9 0
12 0
0
38
2
9 1
12 0
0
39
2
9 2
12 0
0
40
2
9 3
12 0
0
41
2
9 5
12 0
0
42
2
9 6
12 0
0
43
2
9 7
12 0
0
44
2
9 8
12 0
0
77
2
0 0
2 0
0
78
2
0 1
2 0
0
79
2
0 2
2 0
0
80
2
0 3
2 0
0
81
2
0 5
2 0
0
82
2
0 6
2 0
0
83
2
0 7
2 0
0
84
2
0 8
2 0
end_DTG
begin_DTG
0
16
0
261
2
9 0
11 0
0
264
2
9 0
10 0
0
285
2
9 1
11 0
0
288
2
9 1
10 0
0
321
2
9 2
11 0
0
324
2
9 2
10 0
0
333
2
9 3
11 0
0
336
2
9 3
10 0
0
369
2
9 4
11 0
0
372
2
9 4
10 0
0
405
2
9 5
11 0
0
408
2
9 5
10 0
0
423
2
9 6
11 0
0
426
2
9 6
10 0
0
441
2
9 7
11 0
0
444
2
9 7
10 0
end_DTG
begin_DTG
0
24
0
57
2
5 5
7 0
0
76
2
0 8
3 0
0
75
2
0 7
3 0
0
74
2
0 6
3 0
0
73
2
0 5
3 0
0
72
2
0 3
3 0
0
71
2
0 2
3 0
0
70
2
0 1
3 0
0
69
2
0 0
3 0
0
60
2
5 8
7 0
0
59
2
5 7
7 0
0
58
2
5 6
7 0
0
29
2
9 0
14 0
0
56
2
5 3
7 0
0
55
2
5 2
7 0
0
54
2
5 1
7 0
0
53
2
5 0
7 0
0
36
2
9 8
14 0
0
35
2
9 7
14 0
0
34
2
9 6
14 0
0
33
2
9 5
14 0
0
32
2
9 3
14 0
0
31
2
9 2
14 0
0
30
2
9 1
14 0
end_DTG
begin_DTG
0
10
0
280
2
9 1
11 0
0
283
2
9 1
10 0
0
358
2
9 4
11 0
0
361
2
9 4
10 0
0
394
2
9 5
11 0
0
397
2
9 5
10 0
0
418
2
9 6
11 0
0
421
2
9 6
10 0
0
478
2
9 8
11 0
0
481
2
9 8
10 0
end_DTG
begin_DTG
0
24
0
49
2
5 5
8 0
0
68
2
0 8
4 0
0
67
2
0 7
4 0
0
66
2
0 6
4 0
0
65
2
0 5
4 0
0
64
2
0 3
4 0
0
63
2
0 2
4 0
0
62
2
0 1
4 0
0
61
2
0 0
4 0
0
52
2
5 8
8 0
0
51
2
5 7
8 0
0
50
2
5 6
8 0
0
21
2
9 0
16 0
0
48
2
5 3
8 0
0
47
2
5 2
8 0
0
46
2
5 1
8 0
0
45
2
5 0
8 0
0
28
2
9 8
16 0
0
27
2
9 7
16 0
0
26
2
9 6
16 0
0
25
2
9 5
16 0
0
24
2
9 3
16 0
0
23
2
9 2
16 0
0
22
2
9 1
16 0
end_DTG
begin_DTG
2
1
238
2
9 1
27 0
2
243
2
5 1
28 0
0
0
end_DTG
begin_DTG
2
1
239
2
9 2
27 0
2
244
2
5 2
28 0
0
0
end_DTG
begin_DTG
2
1
230
2
5 2
28 0
2
234
2
0 2
23 0
0
0
end_DTG
begin_DTG
2
1
231
2
5 4
28 0
2
235
2
0 4
23 0
0
0
end_DTG
begin_DTG
2
1
232
2
5 5
28 0
2
236
2
0 5
23 0
0
0
end_DTG
begin_DTG
4
1
234
2
0 2
20 0
1
235
2
0 4
21 0
1
236
2
0 5
22 0
1
237
2
0 7
24 0
1
0
135
0
end_DTG
begin_DTG
2
1
233
2
5 7
28 0
2
237
2
0 7
23 0
0
0
end_DTG
begin_DTG
2
1
240
2
9 3
27 0
2
245
2
5 3
28 0
0
0
end_DTG
begin_DTG
2
1
241
2
9 4
27 0
2
246
2
5 4
28 0
0
0
end_DTG
begin_DTG
5
1
238
2
9 1
18 0
1
239
2
9 2
19 0
1
240
2
9 3
25 0
1
241
2
9 4
26 0
1
242
2
9 8
29 0
1
0
133
0
end_DTG
begin_DTG
9
1
230
2
5 2
20 0
1
231
2
5 4
21 0
1
232
2
5 5
22 0
1
233
2
5 7
24 0
1
243
2
5 1
18 0
1
244
2
5 2
19 0
1
245
2
5 3
25 0
1
246
2
5 4
26 0
1
247
2
5 8
29 0
1
0
134
0
end_DTG
begin_DTG
2
1
242
2
9 8
27 0
2
247
2
5 8
28 0
0
0
end_DTG
begin_DTG
0
16
0
109
2
9 0
29 1
0
110
2
9 1
29 1
0
111
2
9 2
29 1
0
112
2
9 3
29 1
0
113
2
9 5
29 1
0
114
2
9 6
29 1
0
115
2
9 7
29 1
0
116
2
9 8
29 1
0
125
2
5 0
29 2
0
126
2
5 1
29 2
0
127
2
5 2
29 2
0
128
2
5 3
29 2
0
129
2
5 5
29 2
0
130
2
5 6
29 2
0
131
2
5 7
29 2
0
132
2
5 8
29 2
end_DTG
begin_DTG
0
16
0
101
2
9 0
26 1
0
102
2
9 1
26 1
0
103
2
9 2
26 1
0
104
2
9 3
26 1
0
105
2
9 5
26 1
0
106
2
9 6
26 1
0
107
2
9 7
26 1
0
108
2
9 8
26 1
0
117
2
5 0
26 2
0
118
2
5 1
26 2
0
119
2
5 2
26 2
0
120
2
5 3
26 2
0
121
2
5 5
26 2
0
122
2
5 6
26 2
0
123
2
5 7
26 2
0
124
2
5 8
26 2
end_DTG
begin_DTG
0
16
0
85
2
5 0
20 1
0
86
2
5 1
20 1
0
87
2
5 2
20 1
0
88
2
5 3
20 1
0
89
2
5 5
20 1
0
90
2
5 6
20 1
0
91
2
5 7
20 1
0
92
2
5 8
20 1
0
93
2
0 0
20 2
0
94
2
0 1
20 2
0
95
2
0 2
20 2
0
96
2
0 3
20 2
0
97
2
0 5
20 2
0
98
2
0 6
20 2
0
99
2
0 7
20 2
0
100
2
0 8
20 2
end_DTG
begin_CG
13
20 1
21 1
22 1
24 1
1 125
17 8
15 8
13 8
32 8
23 4
4 5
3 8
2 3
3
4 5
3 8
2 3
1
13 8
1
15 8
1
17 8
18
20 1
21 1
22 1
24 1
18 1
19 1
25 1
26 1
29 1
6 90
17 8
15 8
32 8
31 8
30 8
28 9
8 5
7 8
2
8 5
7 8
1
15 8
1
17 8
16
18 1
19 1
25 1
26 1
29 1
11 126
10 131
17 8
15 8
13 8
31 8
30 8
27 5
16 10
14 16
12 6
3
16 5
14 8
12 3
3
16 5
14 8
12 3
1
13 8
0
1
15 8
0
1
17 8
0
2
27 1
28 1
2
27 1
28 1
3
32 16
28 1
23 1
2
28 1
23 1
2
28 1
23 1
4
20 1
21 1
22 1
24 1
2
28 1
23 1
2
27 1
28 1
3
31 16
27 1
28 1
5
18 1
19 1
25 1
26 1
29 1
9
20 1
21 1
22 1
24 1
18 1
19 1
25 1
26 1
29 1
3
30 16
27 1
28 1
0
0
0
end_CG
