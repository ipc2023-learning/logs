begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var30
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var7
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var37
-1
2
Atom have_image(rover2, objective4, colour)
NegatedAtom have_image(rover2, objective4, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover2, objective3, high_res)
NegatedAtom have_image(rover2, objective3, high_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var32
-1
2
Atom have_image(rover2, objective2, high_res)
NegatedAtom have_image(rover2, objective2, high_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var31
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var29
-1
2
Atom have_image(rover2, objective1, high_res)
NegatedAtom have_image(rover2, objective1, high_res)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var28
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
0
begin_state
3
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
12
3 0
5 0
7 0
9 0
12 0
14 0
16 0
18 0
20 0
22 0
24 0
26 0
end_goal
114
begin_operator
calibrate rover2 camera1 objective4 waypoint1
1
0 0
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective4 waypoint2
1
0 1
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective4 waypoint4
1
0 3
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective4 waypoint5
1
0 4
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective4 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective4 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective4 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective4 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint1 waypoint3
2
0 0
25 0
1
0 26 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint6 waypoint3
2
0 5
25 0
1
0 26 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 high_res waypoint1 waypoint




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ver2 waypoint6 objective2 camera1 high_res
1
0 5
2
0 10 0 1
0 19 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint6 objective2 camera2 high_res
1
0 5
2
0 1 0 1
0 19 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint6 objective2 camera2 low_res
1
0 5
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint6 objective3 camera1 colour
1
0 5
2
0 10 0 1
0 17 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint6 objective3 camera1 high_res
1
0 5
2
0 10 0 1
0 15 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint6 objective3 camera2 high_res
1
0 5
2
0 1 0 1
0 15 -1 0
0
end_operator
begin_operator
take_image rover2 waypoint6 objective3 camera2 low_res
1
0 5
2
0 1 0 1
0 4 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 10
check 4
0
4
32
33
check 6
42
43
46
47
50
51
check 0
switch 1
check 0
check 6
44
45
48
49
52
53
check 0
switch 25
check 0
check 1
8
check 0
switch 23
check 0
check 1
10
check 0
switch 8
check 0
check 1
12
check 0
switch 21
check 0
check 1
14
check 0
switch 19
check 0
check 1
16
check 0
switch 6
check 0
check 1
18
check 0
switch 17
check 0
check 1
20
check 0
switch 15
check 0
check 1
22
check 0
switch 4
check 0
check 1
24
check 0
switch 13
check 0
check 1
26
check 0
switch 11
check 0
check 1
28
check 0
switch 2
check 0
check 1
30
check 0
check 0
switch 10
check 5
1
5
34
35
36
check 4
54
55
58
59
check 0
switch 1
check 0
check 4
56
57
60
61
check 0
check 0
switch 10
check 1
37
check 6
62
63
66
67
70
71
check 0
switch 1
check 0
check 6
64
65
68
69
72
73
check 0
check 0
switch 10
check 4
2
6
38
39
check 6
74
75
78
79
82
83
check 0
switch 1
check 0
check 6
76
77
80
81
84
85
check 0
check 0
switch 10
check 3
3
7
40
check 8
86
87
90
91
94
95
98
99
check 0
switch 1
check 0
check 8
88
89
92
93
96
97
100
101
check 0
check 0
switch 10
check 1
41
check 6
102
103
106
107
110
111
check 0
switch 1
check 0
check 6
104
105
108
109
112
113
check 0
switch 25
check 0
check 1
9
check 0
switch 23
check 0
check 1
11
check 0
switch 8
check 0
check 1
13
check 0
switch 21
check 0
check 1
15
check 0
switch 19
check 0
check 1
17
check 0
switch 6
check 0
check 1
19
check 0
switch 17
check 0
check 1
21
check 0
switch 15
check 0
check 1
23
check 0
switch 4
check 0
check 1
25
check 0
switch 13
check 0
check 1
27
check 0
switch 11
check 0
check 1
29
check 0
switch 2
check 0
check 1
31
check 0
check 0
check 0
end_SG
begin_DTG
2
1
32
0
2
33
0
3
0
34
0
3
35
0
5
36
0
1
0
37
0
2
1
38
0
4
39
0
1
3
40
0
1
1
41
0
end_DTG
begin_DTG
6
1
97
1
0 4
1
81
1
0 3
1
104
1
0 5
1
61
1
0 1
1
45
1
0 0
1
64
1
0 2
4
0
4
1
0 0
0
5
1
0 1
0
6
1
0 3
0
7
1
0 4
end_DTG
begin_DTG
0
4
0
53
2
0 0
1 0
0
61
2
0 1
1 0
0
85
2
0 3
1 0
0
101
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
30
2
0 0
2 0
0
31
2
0 5
2 0
end_DTG
begin_DTG
0
4
0
73
2
0 2
1 0
0
81
2
0 3
1 0
0
97
2
0 4
1 0
0
113
2
0 5
1 0
end_DTG
begin_DTG
0
2
0
24
2
0 0
4 0
0
25
2
0 5
4 0
end_DTG
begin_DTG
0
5
0
49
2
0 0
1 0
0
57
2
0 1
1 0
0
69
2
0 2
1 0
0
93
2
0 4
1 0
0
109
2
0 5
1 0
end_DTG
begin_DTG
0
2
0
18
2
0 0
6 0
0
19
2
0 5
6 0
end_DTG
begin_DTG
0
5
0
45
2
0 0
1 0
0
65
2
0 2
1 0
0
77
2
0 3
1 0
0
89
2
0 4
1 0
0
105
2
0 5
1 0
end_DTG
begin_DTG
0
2
0
12
2
0 0
8 0
0
13
2
0 5
8 0
end_DTG
begin_DTG
6
1
95
1
0 4
1
79
1
0 3
1
102
1
0 5
1
59
1
0 1
1
43
1
0 0
1
62
1
0 2
4
0
0
1
0 0
0
1
1
0 1
0
2
1
0 3
0
3
1
0 4
end_DTG
begin_DTG
0
8
0
51
2
0 0
10 0
0
52
2
0 0
1 0
0
59
2
0 1
10 0
0
60
2
0 1
1 0
0
83
2
0 3
10 0
0
84
2
0 3
1 0
0
99
2
0 4
10 0
0
100
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
28
2
0 0
11 0
0
29
2
0 5
11 0
end_DTG
begin_DTG
0
4
0
50
2
0 0
10 0
0
58
2
0 1
10 0
0
82
2
0 3
10 0
0
98
2
0 4
10 0
end_DTG
begin_DTG
0
2
0
26
2
0 0
13 0
0
27
2
0 5
13 0
end_DTG
begin_DTG
0
8
0
71
2
0 2
10 0
0
72
2
0 2
1 0
0
79
2
0 3
10 0
0
80
2
0 3
1 0
0
95
2
0 4
10 0
0
96
2
0 4
1 0
0
111
2
0 5
10 0
0
112
2
0 5
1 0
end_DTG
begin_DTG
0
2
0
22
2
0 0
15 0
0
23
2
0 5
15 0
end_DTG
begin_DTG
0
4
0
70
2
0 2
10 0
0
78
2
0 3
10 0
0
94
2
0 4
10 0
0
110
2
0 5
10 0
end_DTG
begin_DTG
0
2
0
20
2
0 0
17 0
0
21
2
0 5
17 0
end_DTG
begin_DTG
0
10
0
47
2
0 0
10 0
0
48
2
0 0
1 0
0
55
2
0 1
10 0
0
56
2
0 1
1 0
0
67
2
0 2
10 0
0
68
2
0 2
1 0
0
91
2
0 4
10 0
0
92
2
0 4
1 0
0
107
2
0 5
10 0
0
108
2
0 5
1 0
end_DTG
begin_DTG
0
2
0
16
2
0 0
19 0
0
17
2
0 5
19 0
end_DTG
begin_DTG
0
5
0
46
2
0 0
10 0
0
54
2
0 1
10 0
0
66
2
0 2
10 0
0
90
2
0 4
10 0
0
106
2
0 5
10 0
end_DTG
begin_DTG
0
2
0
14
2
0 0
21 0
0
15
2
0 5
21 0
end_DTG
begin_DTG
0
10
0
43
2
0 0
10 0
0
44
2
0 0
1 0
0
63
2
0 2
10 0
0
64
2
0 2
1 0
0
75
2
0 3
10 0
0
76
2
0 3
1 0
0
87
2
0 4
10 0
0
88
2
0 4
1 0
0
103
2
0 5
10 0
0
104
2
0 5
1 0
end_DTG
begin_DTG
0
2
0
10
2
0 0
23 0
0
11
2
0 5
23 0
end_DTG
begin_DTG
0
5
0
42
2
0 0
10 0
0
62
2
0 2
10 0
0
74
2
0 3
10 0
0
86
2
0 4
10 0
0
102
2
0 5
10 0
end_DTG
begin_DTG
0
2
0
8
2
0 0
25 0
0
9
2
0 5
25 0
end_DTG
begin_CG
26
10 40
1 40
26 2
24 2
9 2
22 2
20 2
7 2
18 2
16 2
5 2
14 2
12 2
3 2
25 5
23 10
8 5
21 5
19 10
6 5
17 4
15 8
4 4
13 4
11 8
2 4
8
23 5
8 5
19 5
6 5
15 4
4 4
11 4
2 4
1
3 2
0
1
5 2
0
1
7 2
0
1
9 2
0
8
25 5
23 5
21 5
19 5
17 4
15 4
13 4
11 4
1
12 2
0
1
14 2
0
1
16 2
0
1
18 2
0
1
20 2
0
1
22 2
0
1
24 2
0
1
26 2
0
end_CG
