begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var3
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var4
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var5
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
end_variable
begin_variable
var33
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var34
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
end_variable
begin_variable
var32
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var31
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var30
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var29
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var28
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var27
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
0
begin_state
6
2
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
end_state
begin_goal
9
4 0
7 0
17 0
18 0
19 0
20 0
21 0
22 0
23 0
end_goal
178
begin_operator
calibrate rover1 camera1 objective2 waypoint1
1
1 0
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint4
1
1 3
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint6
1
1 5
1
0 5 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint2
1
1 1
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint3
1
1 2
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint4
1
1 3
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint5
1
1 4
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective4 waypoint7
1
1 6
1
0 2 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint2 waypoint6
2
1 1
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint7 waypoint6
2
1 6
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective4 high_res waypoint2 waypoint6
2
1 1
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective4 high_res waypoint7 waypoint6
2
1 6
3 0
1
0 4 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint2 waypoint6
2
1 1
8 1
1
0 23 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint7 waypoint6
2
1 6
8 1
1
0 23 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general wayp




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




k 0
switch 14
check 0
check 1
73
check 0
check 0
check 0
check 0
switch 5
check 0
check 6
138
139
142
143
146
147
check 0
switch 2
check 0
check 6
140
141
144
145
148
149
check 0
check 0
switch 0
check 3
2
49
50
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
switch 14
check 0
check 1
74
check 0
check 0
check 0
check 0
switch 5
check 0
check 8
150
151
154
155
158
159
162
163
check 0
switch 2
check 0
check 8
152
153
156
157
160
161
164
165
check 0
check 0
switch 0
check 4
7
51
52
53
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 0
check 1
13
check 0
switch 9
check 0
check 0
check 1
17
check 0
switch 10
check 0
check 0
check 1
19
check 0
switch 11
check 0
check 0
check 1
21
check 0
switch 12
check 0
check 0
check 1
23
check 0
switch 13
check 0
check 0
check 1
25
check 0
switch 16
check 0
switch 14
check 0
check 1
75
check 0
check 0
check 1
27
check 0
switch 5
check 0
check 6
166
167
170
171
174
175
check 0
switch 2
check 0
check 6
168
169
172
173
176
177
check 0
switch 6
check 0
check 1
9
check 0
switch 3
check 0
check 1
11
check 0
check 0
switch 0
check 0
switch 8
check 2
54
55
check 0
check 0
check 0
switch 9
check 0
switch 15
check 0
check 1
76
check 0
check 0
check 0
check 0
check 0
switch 8
check 3
56
57
58
check 0
check 0
check 1
14
switch 9
check 0
check 0
check 0
check 1
28
switch 10
check 0
switch 15
check 0
check 1
77
check 0
check 0
check 0
check 1
30
switch 11
check 0
check 0
check 0
check 1
32
switch 12
check 0
check 0
check 0
check 1
34
switch 13
check 0
check 0
check 0
check 1
36
switch 16
check 0
check 0
check 0
check 1
38
check 0
switch 8
check 1
59
switch 15
check 0
check 1
69
check 0
check 0
check 0
check 0
check 0
switch 8
check 1
60
check 0
check 0
check 0
switch 11
check 0
switch 15
check 0
check 1
78
check 0
check 0
check 0
check 0
check 0
switch 8
check 1
61
check 0
check 0
check 0
switch 12
check 0
switch 15
check 0
check 1
79
check 0
check 0
check 0
check 0
check 0
switch 8
check 2
62
63
check 0
check 0
check 0
switch 13
check 0
switch 15
check 0
check 1
80
check 0
check 0
check 0
check 0
check 0
switch 8
check 4
64
65
66
67
check 0
check 0
check 1
15
switch 9
check 0
check 0
check 0
check 1
29
switch 10
check 0
check 0
check 0
check 1
31
switch 11
check 0
check 0
check 0
check 1
33
switch 12
check 0
check 0
check 0
check 1
35
switch 13
check 0
check 0
check 0
check 1
37
switch 16
check 0
switch 15
check 0
check 1
81
check 0
check 0
check 0
check 1
39
check 0
switch 14
check 0
check 0
check 1
40
switch 15
check 0
check 0
check 1
41
check 0
end_SG
begin_DTG
2
1
54
0
6
55
0
3
0
56
0
4
57
0
5
58
0
1
6
59
0
1
6
60
0
1
1
61
0
2
1
62
0
6
63
0
4
0
64
0
2
65
0
3
66
0
5
67
0
end_DTG
begin_DTG
1
1
42
0
3
0
43
0
4
44
0
5
45
0
1
6
46
0
1
6
47
0
1
1
48
0
2
1
49
0
6
50
0
3
2
51
0
3
52
0
5
53
0
end_DTG
begin_DTG
7
1
156
1
1 5
1
133
1
1 3
1
140
1
1 4
1
168
1
1 6
1
108
1
1 2
1
85
1
1 0
1
96
1
1 1
5
0
3
1
1 1
0
4
1
1 2
0
5
1
1 3
0
6
1
1 4
0
7
1
1 6
end_DTG
begin_DTG
0
5
0
100
2
1 1
2 0
0
116
2
1 2
2 0
0
136
2
1 3
2 0
0
144
2
1 4
2 0
0
172
2
1 6
2 0
end_DTG
begin_DTG
0
2
0
10
2
1 1
3 0
0
11
2
1 6
3 0
end_DTG
begin_DTG
7
1
154
1
1 5
1
131
1
1 3
1
138
1
1 4
1
166
1
1 6
1
106
1
1 2
1
83
1
1 0
1
94
1
1 1
3
0
0
1
1 0
0
1
1
1 3
0
2
1
1 5
end_DTG
begin_DTG
0
6
0
87
2
1 0
5 0
0
89
2
1 0
2 0
0
127
2
1 3
5 0
0
129
2
1 3
2 0
0
155
2
1 5
5 0
0
157
2
1 5
2 0
end_DTG
begin_DTG
0
2
0
8
2
1 1
6 0
0
9
2
1 6
6 0
end_DTG
begin_DTG
2
1
68
2
1 2
14 0
2
69
2
0 2
15 0
0
0
end_DTG
begin_DTG
2
1
70
2
1 0
14 0
2
76
2
0 0
15 0
0
0
end_DTG
begin_DTG
2
1
71
2
1 1
14 0
2
77
2
0 1
15 0
0
0
end_DTG
begin_DTG
2
1
72
2
1 3
14 0
2
78
2
0 3
15 0
0
0
end_DTG
begin_DTG
2
1
73
2
1 4
14 0
2
79
2
0 4
15 0
0
0
end_DTG
begin_DTG
2
1
74
2
1 5
14 0
2
80
2
0 5
15 0
0
0
end_DTG
begin_DTG
7
1
68
2
1 2
8 0
1
70
2
1 0
9 0
1
71
2
1 1
10 0
1
72
2
1 3
11 0
1
73
2
1 4
12 0
1
74
2
1 5
13 0
1
75
2
1 6
16 0
1
0
40
0
end_DTG
begin_DTG
7
1
69
2
0 2
8 0
1
76
2
0 0
9 0
1
77
2
0 1
10 0
1
78
2
0 3
11 0
1
79
2
0 4
12 0
1
80
2
0 5
13 0
1
81
2
0 6
16 0
1
0
41
0
end_DTG
begin_DTG
2
1
75
2
1 6
14 0
2
81
2
0 6
15 0
0
0
end_DTG
begin_DTG
0
4
0
26
2
1 1
16 1
0
27
2
1 6
16 1
0
38
2
0 1
16 2
0
39
2
0 6
16 2
end_DTG
begin_DTG
0
4
0
24
2
1 1
13 1
0
25
2
1 6
13 1
0
36
2
0 1
13 2
0
37
2
0 6
13 2
end_DTG
begin_DTG
0
4
0
22
2
1 1
12 1
0
23
2
1 6
12 1
0
34
2
0 1
12 2
0
35
2
0 6
12 2
end_DTG
begin_DTG
0
4
0
20
2
1 1
11 1
0
21
2
1 6
11 1
0
32
2
0 1
11 2
0
33
2
0 6
11 2
end_DTG
begin_DTG
0
4
0
18
2
1 1
10 1
0
19
2
1 6
10 1
0
30
2
0 1
10 2
0
31
2
0 6
10 2
end_DTG
begin_DTG
0
4
0
16
2
1 1
9 1
0
17
2
1 6
9 1
0
28
2
0 1
9 2
0
29
2
0 6
9 2
end_DTG
begin_DTG
0
4
0
12
2
1 1
8 1
0
13
2
1 6
8 1
0
14
2
0 1
8 2
0
15
2
0 6
8 2
end_DTG
begin_CG
15
8 1
9 1
10 1
11 1
12 1
13 1
16 1
23 2
22 2
21 2
20 2
19 2
18 2
17 2
15 7
21
8 1
9 1
10 1
11 1
12 1
13 1
16 1
5 51
2 53
7 2
4 2
23 2
22 2
21 2
20 2
19 2
18 2
17 2
14 7
6 6
3 5
2
6 3
3 5
1
4 2
0
1
6 3
1
7 2
0
3
23 4
14 1
15 1
3
22 4
14 1
15 1
3
21 4
14 1
15 1
3
20 4
14 1
15 1
3
19 4
14 1
15 1
3
18 4
14 1
15 1
7
8 1
9 1
10 1
11 1
12 1
13 1
16 1
7
8 1
9 1
10 1
11 1
12 1
13 1
16 1
3
17 4
14 1
15 1
0
0
0
0
0
0
0
end_CG
