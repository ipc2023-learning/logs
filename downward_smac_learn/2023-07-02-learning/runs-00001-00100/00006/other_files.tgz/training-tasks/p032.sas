begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var1
-1
5
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover2, objective3, high_res)
NegatedAtom have_image(rover2, objective3, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var37
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var31
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var29
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var30
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var28
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var26
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var24
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var23
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var22
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var21
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
3
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
end_state
begin_goal
13
4 0
6 0
8 0
10 0
12 0
14 0
16 0
28 0
29 0
30 0
31 0
32 0
33 0
end_goal
136
begin_operator
calibrate rover2 camera1 objective1 waypoint1
1
0 0
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint3
1
0 2
1
0 2 -1 0
0
end_operator
begi




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




k 0
check 1
12
check 0
switch 9
check 0
check 1
14
check 0
switch 7
check 0
check 1
16
check 0
switch 5
check 0
check 1
18
check 0
switch 3
check 0
check 1
20
check 0
check 0
switch 18
check 3
1
5
61
check 0
check 0
check 1
31
switch 19
check 0
check 0
check 0
check 1
33
switch 20
check 0
switch 26
check 0
check 1
70
check 0
check 0
check 0
check 1
35
switch 21
check 0
check 0
check 0
check 1
37
switch 23
check 0
switch 26
check 0
check 1
77
check 0
check 0
check 0
check 1
43
switch 27
check 0
check 0
check 0
check 1
45
switch 2
check 0
check 9
100
101
102
104
105
106
108
109
110
check 0
switch 1
check 0
check 3
103
107
111
check 0
switch 15
check 0
check 1
9
check 0
switch 13
check 0
check 1
11
check 0
switch 11
check 0
check 1
13
check 0
switch 9
check 0
check 1
15
check 0
switch 7
check 0
check 1
17
check 0
switch 5
check 0
check 1
19
check 0
switch 3
check 0
check 1
21
check 0
check 0
switch 18
check 3
2
6
62
check 0
check 0
check 0
switch 24
check 0
switch 26
check 0
check 1
78
check 0
check 0
check 0
check 0
switch 2
check 0
check 9
112
113
114
116
117
118
120
121
122
check 0
switch 1
check 0
check 3
115
119
123
check 0
check 0
switch 18
check 3
3
7
63
check 0
check 0
check 0
switch 21
check 0
switch 26
check 0
check 1
71
check 0
check 0
check 0
check 0
switch 27
check 0
switch 26
check 0
check 1
79
check 0
check 0
check 0
check 0
switch 2
check 0
check 9
124
125
126
128
129
130
132
133
134
check 0
switch 1
check 0
check 3
127
131
135
check 0
check 0
switch 25
check 0
check 0
check 1
46
switch 26
check 0
check 0
check 1
47
check 0
end_SG
begin_DTG
2
1
56
0
2
57
0
3
0
58
0
3
59
0
4
60
0
1
0
61
0
1
1
62
0
1
1
63
0
end_DTG
begin_DTG
5
1
83
1
0 0
1
95
1
0 1
1
103
1
0 2
1
115
1
0 3
1
127
1
0 4
4
0
4
1
0 0
0
5
1
0 2
0
6
1
0 3
0
7
1
0 4
end_DTG
begin_DTG
5
1
122
1
0 3
1
109
1
0 2
1
124
1
0 4
1
94
1
0 1
1
81
1
0 0
4
0
0
1
0 0
0
1
1
0 2
0
2
1
0 3
0
3
1
0 4
end_DTG
begin_DTG
0
10
0
90
2
0 0
2 0
0
91
2
0 0
1 0
0
98
2
0 1
2 0
0
99
2
0 1
1 0
0
110
2
0 2
2 0
0
111
2
0 2
1 0
0
122
2
0 3
2 0
0
123
2
0 3
1 0
0
134
2
0 4
2 0
0
135
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
20
2
0 1
3 0
0
21
2
0 2
3 0
end_DTG
begin_DTG
0
5
0
89
2
0 0
2 0
0
97
2
0 1
2 0
0
109
2
0 2
2 0
0
121
2
0 3
2 0
0
133
2
0 4
2 0
end_DTG
begin_DTG
0
2
0
18
2
0 1
5 0
0
19
2
0 2
5 0
end_DTG
begin_DTG
0
5
0
88
2
0 0
2 0
0
96
2
0 1
2 0
0
108
2
0 2
2 0
0
120
2
0 3
2 0
0
132
2
0 4
2 0
end_DTG
begin_DTG
0
2
0
16
2
0 1
7 0
0
17
2
0 2
7 0
end_DTG
begin_DTG
0
10
0
86
2
0 0
2 0
0
87
2
0 0
1 0
0
94
2
0 1
2 0
0
95
2
0 1
1 0
0
106
2
0 2
2 0
0
107
2
0 2
1 0
0
118
2
0 3
2 0
0
119
2
0 3
1 0
0
130
2
0 4
2 0
0
131
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
14
2
0 1
9 0
0
15
2
0 2
9 0
end_DTG
begin_DTG
0
5
0
84
2
0 0
2 0
0
92
2
0 1
2 0
0
104
2
0 2
2 0
0
116
2
0 3
2 0
0
128
2
0 4
2 0
end_DTG
begin_DTG
0
2
0
12
2
0 1
11 0
0
13
2
0 2
11 0
end_DTG
begin_DTG
0
8
0
82
2
0 0
2 0
0
83
2
0 0
1 0
0
102
2
0 2
2 0
0
103
2
0 2
1 0
0
114
2
0 3
2 0
0
115
2
0 3
1 0
0
126
2
0 4
2 0
0
127
2
0 4
1 0
end_DTG
begin_DTG
0
2
0
10
2
0 1
13 0
0
11
2
0 2
13 0
end_DTG
begin_DTG
0
4
0
80
2
0 0
2 0
0
100
2
0 2
2 0
0
112
2
0 3
2 0
0
124
2
0 4
2 0
end_DTG
begin_DTG
0
2
0
8
2
0 1
15 0
0
9
2
0 2
15 0
end_DTG
begin_DTG
2
1
48
0
2
49
0
3
0
50
0
3
51
0
4
52
0
1
0
53
0
1
1
54
0
1
1
55
0
end_DTG
begin_DTG
2
1
64
2
17 0
25 0
2
68
2
0 0
26 0
0
0
end_DTG
begin_DTG
2
1
65
2
17 1
25 0
2
69
2
0 1
26 0
0
0
end_DTG
begin_DTG
2
1
66
2
17 2
25 0
2
70
2
0 2
26 0
0
0
end_DTG
begin_DTG
2
1
67
2
17 4
25 0
2
71
2
0 4
26 0
0
0
end_DTG
begin_DTG
2
1
72
2
17 0
25 0
2
76
2
0 0
26 0
0
0
end_DTG
begin_DTG
2
1
73
2
17 2
25 0
2
77
2
0 2
26 0
0
0
end_DTG
begin_DTG
2
1
74
2
17 3
25 0
2
78
2
0 3
26 0
0
0
end_DTG
begin_DTG
8
1
64
2
17 0
18 0
1
65
2
17 1
19 0
1
66
2
17 2
20 0
1
67
2
17 4
21 0
1
72
2
17 0
22 0
1
73
2
17 2
23 0
1
74
2
17 3
24 0
1
75
2
17 4
27 0
1
0
46
0
end_DTG
begin_DTG
8
1
68
2
0 0
18 0
1
69
2
0 1
19 0
1
70
2
0 2
20 0
1
71
2
0 4
21 0
1
76
2
0 0
22 0
1
77
2
0 2
23 0
1
78
2
0 3
24 0
1
79
2
0 4
27 0
1
0
47
0
end_DTG
begin_DTG
2
1
75
2
17 4
25 0
2
79
2
0 4
26 0
0
0
end_DTG
begin_DTG
0
4
0
40
2
17 1
27 1
0
41
2
17 2
27 1
0
44
2
0 1
27 2
0
45
2
0 2
27 2
end_DTG
begin_DTG
0
4
0
38
2
17 1
23 1
0
39
2
17 2
23 1
0
42
2
0 1
23 2
0
43
2
0 2
23 2
end_DTG
begin_DTG
0
4
0
28
2
17 1
21 1
0
29
2
17 2
21 1
0
36
2
0 1
21 2
0
37
2
0 2
21 2
end_DTG
begin_DTG
0
4
0
26
2
17 1
20 1
0
27
2
17 2
20 1
0
34
2
0 1
20 2
0
35
2
0 2
20 2
end_DTG
begin_DTG
0
4
0
24
2
17 1
19 1
0
25
2
17 2
19 1
0
32
2
0 1
19 2
0
33
2
0 2
19 2
end_DTG
begin_DTG
0
4
0
22
2
17 1
18 1
0
23
2
17 2
18 1
0
30
2
0 1
18 2
0
31
2
0 2
18 2
end_DTG
begin_CG
31
18 1
19 1
20 1
21 1
22 1
23 1
24 1
27 1
2 46
1 18
16 2
14 2
12 2
10 2
8 2
6 2
4 2
33 2
32 2
31 2
30 2
29 2
28 2
26 8
15 4
13 8
11 5
9 10
7 5
5 5
3 10
3
13 4
9 5
3 5
7
15 4
13 4
11 5
9 5
7 5
5 5
3 5
1
4 2
0
1
6 2
0
1
8 2
0
1
10 2
0
1
12 2
0
1
14 2
0
1
16 2
0
15
18 1
19 1
20 1
21 1
22 1
23 1
24 1
27 1
33 2
32 2
31 2
30 2
29 2
28 2
25 8
3
33 4
25 1
26 1
3
32 4
25 1
26 1
3
31 4
25 1
26 1
3
30 4
25 1
26 1
2
25 1
26 1
3
29 4
25 1
26 1
2
25 1
26 1
8
18 1
19 1
20 1
21 1
22 1
23 1
24 1
27 1
8
18 1
19 1
20 1
21 1
22 1
23 1
24 1
27 1
3
28 4
25 1
26 1
0
0
0
0
0
0
end_CG
