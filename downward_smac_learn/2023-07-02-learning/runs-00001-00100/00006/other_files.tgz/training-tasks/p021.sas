begin_version
3
end_version
begin_metric
0
end_metric
22
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var28
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var27
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var23
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
end_variable
begin_variable
var22
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var21
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var20
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var19
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var18
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
0
begin_state
0
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
8
3 0
5 0
7 0
9 0
18 0
19 0
20 0
21 0
end_goal
37
begin_operator
calibrate rover1 camera1 objective2 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint1 waypoint5
2
0 0
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint1 waypoint5
2
0 0
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint1 waypoint5
2
0 0
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint1 waypoint5
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint2 waypoint1 waypoint5
2
0 0
13 1
1
0 21 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint1 waypoint5
2
0 0
14 1
1
0 20 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint4 waypoint1 waypoint5
2
0 0
15 1
1
0 19 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint5 waypoint1 waypoint5
2
0 0
16 1
1
0 18 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 17 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 0 0 2
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint5
0
1
0 0 0 4
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint3
0
1
0 0 1 2
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint1
0
1
0 0 2 0
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint2
0
1
0 0 2 1
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint1
0
1
0 0 4 0
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
0 0
2
0 10 0 1
0 17 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint2
1
0 1
2
0 11 0 1
0 17 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint4
1
0 3
2
0 12 0 1
0 17 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint2
1
0 1
2
0 13 0 1
0 17 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
0 2
2
0 14 0 1
0 17 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint4
1
0 3
2
0 15 0 1
0 17 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint5
1
0 4
2
0 16 0 1
0 17 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 colour
1
0 2
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 high_res
1
0 2
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 colour
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 high_res
1
0 4
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 low_res
1
0 4
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 10
check 3
10
11
12
switch 17
check 0
check 1
18
check 0
check 0
check 0
switch 13
check 0
check 0
check 1
5
switch 14
check 0
check 0
check 1
6
switch 15
check 0
check 0
check 1
7
switch 16
check 0
check 0
check 1
8
switch 1
check 0
check 3
25
26
27
check 0
switch 8
check 0
check 1
1
check 0
switch 6
check 0
check 1
2
check 0
switch 4
check 0
check 1
3
check 0
switch 2
check 0
check 1
4
check 0
check 0
switch 10
check 1
13
check 0
check 0
switch 11
check 0
switch 17
check 0
check 1
19
check 0
check 0
check 0
switch 13
check 0
switch 17
check 0
check 1
21
check 0
check 0
check 0
check 0
switch 10
check 2
14
15
check 0
check 0
switch 14
check 0
switch 17
check 0
check 1
22
check 0
check 0
check 0
switch 1
check 0
check 3
28
29
30
check 0
check 0
switch 10
check 1
16
check 0
check 0
switch 12
check 0
switch 17
check 0
check 1
20
check 0
check 0
check 0
switch 15
check 0
switch 17
check 0
check 1
23
check 0
check 0
check 0
switch 1
check 0
check 3
31
32
33
check 0
check 0
switch 10
check 2
0
17
check 0
check 0
switch 16
check 0
switch 17
check 0
check 1
24
check 0
check 0
check 0
switch 1
check 0
check 3
34
35
36
check 0
check 0
switch 17
check 0
check 0
check 1
9
check 0
end_SG
begin_DTG
3
2
10
0
3
11
0
4
12
0
1
2
13
0
2
0
14
0
1
15
0
1
0
16
0
1
0
17
0
end_DTG
begin_DTG
4
1
25
1
0 0
1
28
1
0 2
1
31
1
0 3
1
34
1
0 4
1
0
0
1
0 4
end_DTG
begin_DTG
0
1
0
36
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
4
2
0 0
2 0
end_DTG
begin_DTG
0
1
0
35
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
3
2
0 0
4 0
end_DTG
begin_DTG
0
3
0
26
2
0 0
1 0
0
29
2
0 2
1 0
0
32
2
0 3
1 0
end_DTG
begin_DTG
0
1
0
2
2
0 0
6 0
end_DTG
begin_DTG
0
3
0
25
2
0 0
1 0
0
28
2
0 2
1 0
0
31
2
0 3
1 0
end_DTG
begin_DTG
0
1
0
1
2
0 0
8 0
end_DTG
begin_DTG
1
1
18
2
0 0
17 0
0
end_DTG
begin_DTG
1
1
19
2
0 1
17 0
0
end_DTG
begin_DTG
1
1
20
2
0 3
17 0
0
end_DTG
begin_DTG
1
1
21
2
0 1
17 0
0
end_DTG
begin_DTG
1
1
22
2
0 2
17 0
0
end_DTG
begin_DTG
1
1
23
2
0 3
17 0
0
end_DTG
begin_DTG
1
1
24
2
0 4
17 0
0
end_DTG
begin_DTG
7
1
18
2
0 0
10 0
1
19
2
0 1
11 0
1
20
2
0 3
12 0
1
21
2
0 1
13 0
1
22
2
0 2
14 0
1
23
2
0 3
15 0
1
24
2
0 4
16 0
1
0
9
0
end_DTG
begin_DTG
0
1
0
8
2
0 0
16 1
end_DTG
begin_DTG
0
1
0
7
2
0 0
15 1
end_DTG
begin_DTG
0
1
0
6
2
0 0
14 1
end_DTG
begin_DTG
0
1
0
5
2
0 0
13 1
end_DTG
begin_CG
21
10 1
11 1
12 1
13 1
14 1
15 1
16 1
1 13
9 1
7 1
5 1
3 1
21 1
20 1
19 1
18 1
17 7
8 3
6 3
4 1
2 1
4
8 3
6 3
4 1
2 1
1
3 1
0
1
5 1
0
1
7 1
0
1
9 1
0
1
17 1
1
17 1
1
17 1
2
21 1
17 1
2
20 1
17 1
2
19 1
17 1
2
18 1
17 1
7
10 1
11 1
12 1
13 1
14 1
15 1
16 1
0
0
0
0
end_CG
