begin_version
3
end_version
begin_metric
0
end_metric
32
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var49
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var44
-1
2
Atom have_image(rover2, objective1, high_res)
NegatedAtom have_image(rover2, objective1, high_res)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var41
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var37
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var30
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var31
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var25
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var24
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var23
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
5
1
1
1
1
4
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
10
8 0
10 0
12 0
14 0
16 0
18 0
28 0
29 0
30 0
31 0
end_goal
170
begin_operator
calibrate rover1 camera1 objective2 waypoint1
1
5 0
1
0 6 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective2 waypoint4
1
5 3
1
0 6 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective4 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint2 waypoint1
2
5 1
17 0
1
0 18 -1 0
0
end_operator
begin_operator
comm




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
check 0
switch 4
check 0
check 1
34
check 0
switch 3
check 0
check 1
39
check 0
switch 2
check 0
check 1
44
check 0
check 0
switch 19
check 4
119
120
121
122
check 0
check 0
check 1
70
switch 20
check 0
check 0
check 0
check 1
75
switch 21
check 0
switch 26
check 0
check 1
132
check 0
check 0
check 0
check 1
80
switch 22
check 0
check 0
check 0
check 1
85
switch 1
check 0
check 6
162
163
164
165
166
167
check 0
switch 4
check 0
check 1
35
check 0
switch 3
check 0
check 1
40
check 0
switch 2
check 0
check 1
45
check 0
check 0
switch 19
check 2
123
124
check 0
check 0
check 1
71
switch 20
check 0
check 0
check 0
check 1
76
switch 21
check 0
check 0
check 0
check 1
81
switch 22
check 0
switch 26
check 0
check 1
133
check 0
check 0
check 0
check 1
86
switch 27
check 0
switch 26
check 0
check 1
139
check 0
check 0
check 0
check 0
switch 1
check 0
check 2
168
169
check 0
switch 4
check 0
check 1
36
check 0
switch 3
check 0
check 1
41
check 0
switch 2
check 0
check 1
46
check 0
check 0
switch 19
check 1
125
check 0
check 0
check 1
72
switch 20
check 0
check 0
check 0
check 1
77
switch 21
check 0
check 0
check 0
check 1
82
switch 22
check 0
check 0
check 0
check 1
87
switch 4
check 0
check 1
37
check 0
switch 3
check 0
check 1
42
check 0
switch 2
check 0
check 1
47
check 0
check 0
switch 25
check 0
check 0
check 1
88
switch 26
check 0
check 0
check 1
89
check 0
end_SG
begin_DTG
3
1
110
0
2
111
0
3
112
0
3
0
113
0
2
114
0
3
115
0
3
0
116
0
1
117
0
4
118
0
4
0
119
0
1
120
0
4
121
0
5
122
0
2
2
123
0
3
124
0
1
3
125
0
end_DTG
begin_DTG
4
1
158
1
0 0
1
160
1
0 1
1
162
1
0 3
1
168
1
0 4
1
0
2
1
0 1
end_DTG
begin_DTG
0
1
0
167
2
0 3
1 0
end_DTG
begin_DTG
0
2
0
159
2
0 0
1 0
0
165
2
0 3
1 0
end_DTG
begin_DTG
0
2
0
162
2
0 3
1 0
0
168
2
0 4
1 0
end_DTG
begin_DTG
4
1
90
0
2
91
0
4
92
0
5
93
0
2
0
94
0
2
95
0
4
0
96
0
1
97
0
3
98
0
4
99
0
3
2
100
0
4
101
0
5
102
0
4
0
103
0
2
104
0
3
105
0
5
106
0
3
0
107
0
3
108
0
4
109
0
end_DTG
begin_DTG
4
1
149
1
5 3
1
157
1
5 4
1
140
1
5 0
1
145
1
5 1
2
0
0
1
5 0
0
1
1
5 3
end_DTG
begin_DTG
0
1
0
143
2
5 1
6 0
end_DTG
begin_DTG
0
5
0
28
2
5 1
7 0
0
29
2
5 2
7 0
0
30
2
5 3
7 0
0
31
2
5 4
7 0
0
32
2
5 5
7 0
end_DTG
begin_DTG
0
1
0
154
2
5 3
6 0
end_DTG
begin_DTG
0
10
0
23
2
5 1
9 0
0
24
2
5 2
9 0
0
25
2
5 3
9 0
0
26
2
5 4
9 0
0
27
2
5 5
9 0
0
43
2
0 1
2 0
0
44
2
0 2
2 0
0
45
2
0 3
2 0
0
46
2
0 4
2 0
0
47
2
0 5
2 0
end_DTG
begin_DTG
0
1
0
152
2
5 3
6 0
end_DTG
begin_DTG
0
5
0
18
2
5 1
11 0
0
19
2
5 2
11 0
0
20
2
5 3
11 0
0
21
2
5 4
11 0
0
22
2
5 5
11 0
end_DTG
begin_DTG
0
2
0
142
2
5 0
6 0
0
151
2
5 3
6 0
end_DTG
begin_DTG
0
10
0
13
2
5 1
13 0
0
14
2
5 2
13 0
0
15
2
5 3
13 0
0
16
2
5 4
13 0
0
17
2
5 5
13 0
0
38
2
0 1
3 0
0
39
2
0 2
3 0
0
40
2
0 3
3 0
0
41
2
0 4
3 0
0
42
2
0 5
3 0
end_DTG
begin_DTG
0
2
0
140
2
5 0
6 0
0
149
2
5 3
6 0
end_DTG
begin_DTG
0
5
0
8
2
5 1
15 0
0
9
2
5 2
15 0
0
10
2
5 3
15 0
0
11
2
5 4
15 0
0
12
2
5 5
15 0
end_DTG
begin_DTG
0
2
0
147
2
5 3
6 0
0
156
2
5 4
6 0
end_DTG
begin_DTG
0
10
0
3
2
5 1
17 0
0
4
2
5 2
17 0
0
5
2
5 3
17 0
0
6
2
5 4
17 0
0
7
2
5 5
17 0
0
33
2
0 1
4 0
0
34
2
0 2
4 0
0
35
2
0 3
4 0
0
36
2
0 4
4 0
0
37
2
0 5
4 0
end_DTG
begin_DTG
2
1
126
2
5 0
25 0
2
130
2
0 0
26 0
0
0
end_DTG
begin_DTG
2
1
127
2
5 2
25 0
2
131
2
0 2
26 0
0
0
end_DTG
begin_DTG
2
1
128
2
5 3
25 0
2
132
2
0 3
26 0
0
0
end_DTG
begin_DTG
2
1
129
2
5 4
25 0
2
133
2
0 4
26 0
0
0
end_DTG
begin_DTG
2
1
134
2
5 0
25 0
2
137
2
0 0
26 0
0
0
end_DTG
begin_DTG
2
1
135
2
5 2
25 0
2
138
2
0 2
26 0
0
0
end_DTG
begin_DTG
7
1
126
2
5 0
19 0
1
127
2
5 2
20 0
1
128
2
5 3
21 0
1
129
2
5 4
22 0
1
134
2
5 0
23 0
1
135
2
5 2
24 0
1
136
2
5 4
27 0
1
0
88
0
end_DTG
begin_DTG
7
1
130
2
0 0
19 0
1
131
2
0 2
20 0
1
132
2
0 3
21 0
1
133
2
0 4
22 0
1
137
2
0 0
23 0
1
138
2
0 2
24 0
1
139
2
0 4
27 0
1
0
89
0
end_DTG
begin_DTG
2
1
136
2
5 4
25 0
2
139
2
0 4
26 0
0
0
end_DTG
begin_DTG
0
10
0
63
2
5 1
22 1
0
64
2
5 2
22 1
0
65
2
5 3
22 1
0
66
2
5 4
22 1
0
67
2
5 5
22 1
0
83
2
0 1
22 2
0
84
2
0 2
22 2
0
85
2
0 3
22 2
0
86
2
0 4
22 2
0
87
2
0 5
22 2
end_DTG
begin_DTG
0
10
0
58
2
5 1
21 1
0
59
2
5 2
21 1
0
60
2
5 3
21 1
0
61
2
5 4
21 1
0
62
2
5 5
21 1
0
78
2
0 1
21 2
0
79
2
0 2
21 2
0
80
2
0 3
21 2
0
81
2
0 4
21 2
0
82
2
0 5
21 2
end_DTG
begin_DTG
0
10
0
53
2
5 1
20 1
0
54
2
5 2
20 1
0
55
2
5 3
20 1
0
56
2
5 4
20 1
0
57
2
5 5
20 1
0
73
2
0 1
20 2
0
74
2
0 2
20 2
0
75
2
0 3
20 2
0
76
2
0 4
20 2
0
77
2
0 5
20 2
end_DTG
begin_DTG
0
10
0
48
2
5 1
19 1
0
49
2
5 2
19 1
0
50
2
5 3
19 1
0
51
2
5 4
19 1
0
52
2
5 5
19 1
0
68
2
0 1
19 2
0
69
2
0 2
19 2
0
70
2
0 3
19 2
0
71
2
0 4
19 2
0
72
2
0 5
19 2
end_DTG
begin_CG
19
19 1
20 1
21 1
22 1
23 1
24 1
27 1
1 13
18 5
14 5
10 5
31 5
30 5
29 5
28 5
26 7
4 2
3 2
2 1
3
4 2
3 2
2 1
1
10 5
1
14 5
1
18 5
25
19 1
20 1
21 1
22 1
23 1
24 1
27 1
6 20
18 5
16 5
14 5
12 5
10 5
8 5
31 5
30 5
29 5
28 5
25 7
17 2
15 2
13 2
11 1
9 1
7 1
6
17 2
15 2
13 2
11 1
9 1
7 1
1
8 5
0
1
10 5
0
1
12 5
0
1
14 5
0
1
16 5
0
1
18 5
0
3
31 10
25 1
26 1
3
30 10
25 1
26 1
3
29 10
25 1
26 1
3
28 10
25 1
26 1
2
25 1
26 1
2
25 1
26 1
7
19 1
20 1
21 1
22 1
23 1
24 1
27 1
7
19 1
20 1
21 1
22 1
23 1
24 1
27 1
2
25 1
26 1
0
0
0
0
end_CG
