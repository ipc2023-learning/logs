begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover2, objective7, low_res)
NegatedAtom have_image(rover2, objective7, low_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var50
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var42
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover2, objective7, high_res)
NegatedAtom have_image(rover2, objective7, high_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var49
-1
2
Atom have_image(rover2, objective3, high_res)
NegatedAtom have_image(rover2, objective3, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
end_variable
begin_variable
var6
-1
4
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
Atom have_soil_analysis(rover3, waypoint1)
end_variable
begin_variable
var39
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var40
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var7
-1
4
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
Atom have_soil_analysis(rover3, waypoint4)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover1, waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var41
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var38
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var37
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var35
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var34
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
0
begin_state
6
3
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
3
0
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
10
5 0
7 0
9 0
11 0
14 0
16 0
27 0
28 0
29 0
30 0
end_goal
367
begin_operator
calibrate rover2 camera1 objective1 waypoint3
1
1 2
1
0 12 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint6
1
1 5
1
0 12 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective5 waypoint1
1
1 0
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective5 waypoint3
1
1 2
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective5 waypo




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
check 0
switch 24
check 0
check 0
check 0
check 0
check 1
97
switch 25
check 0
check 0
check 0
check 0
check 1
104
check 0
switch 22
check 0
check 0
check 1
105
switch 23
check 0
check 0
check 1
106
switch 26
check 0
check 0
check 1
107
check 0
end_SG
begin_DTG
4
2
166
0
3
167
0
5
168
0
6
169
0
3
4
170
0
6
171
0
7
172
0
3
0
173
0
3
174
0
5
175
0
5
0
176
0
2
177
0
4
178
0
5
179
0
7
180
0
3
1
181
0
3
182
0
6
183
0
3
0
184
0
2
185
0
3
186
0
4
0
187
0
1
188
0
4
189
0
7
190
0
3
1
191
0
3
192
0
6
193
0
end_DTG
begin_DTG
2
2
138
0
5
139
0
3
3
140
0
6
141
0
7
142
0
3
0
143
0
3
144
0
5
145
0
6
1
146
0
2
147
0
4
148
0
5
149
0
6
150
0
7
151
0
2
3
152
0
6
153
0
4
0
154
0
2
155
0
3
156
0
6
157
0
5
1
158
0
3
159
0
4
160
0
5
161
0
7
162
0
3
1
163
0
3
164
0
6
165
0
end_DTG
begin_DTG
8
1
309
1
1 4
1
329
1
1 5
1
296
1
1 3
1
366
1
1 7
1
359
1
1 6
1
226
1
1 0
1
246
1
1 1
1
267
1
1 2
2
0
5
1
1 2
0
6
1
1 5
end_DTG
begin_DTG
8
1
306
1
1 4
1
326
1
1 5
1
293
1
1 3
1
363
1
1 7
1
356
1
1 6
1
223
1
1 0
1
243
1
1 1
1
264
1
1 2
3
0
2
1
1 0
0
3
1
1 2
0
4
1
1 4
end_DTG
begin_DTG
0
4
0
293
2
1 3
3 0
0
296
2
1 3
2 0
0
349
2
1 5
3 0
0
352
2
1 5
2 0
end_DTG
begin_DTG
0
7
0
42
2
1 1
4 0
0
43
2
1 2
4 0
0
44
2
1 3
4 0
0
45
2
1 4
4 0
0
46
2
1 5
4 0
0
47
2
1 6
4 0
0
48
2
1 7
4 0
end_DTG
begin_DTG
0
6
0
228
2
1 0
3 0
0
231
2
1 0
2 0
0
270
2
1 2
3 0
0
273
2
1 2
2 0
0
319
2
1 4
3 0
0
322
2
1 4
2 0
end_DTG
begin_DTG
0
7
0
28
2
1 1
6 0
0
29
2
1 2
6 0
0
30
2
1 3
6 0
0
31
2
1 4
6 0
0
32
2
1 5
6 0
0
33
2
1 6
6 0
0
34
2
1 7
6 0
end_DTG
begin_DTG
0
6
0
216
2
1 0
3 0
0
219
2
1 0
2 0
0
286
2
1 3
3 0
0
289
2
1 3
2 0
0
307
2
1 4
3 0
0
310
2
1 4
2 0
end_DTG
begin_DTG
0
7
0
21
2
1 1
8 0
0
22
2
1 2
8 0
0
23
2
1 3
8 0
0
24
2
1 4
8 0
0
25
2
1 5
8 0
0
26
2
1 6
8 0
0
27
2
1 7
8 0
end_DTG
begin_DTG
0
4
0
256
2
1 2
3 0
0
259
2
1 2
2 0
0
326
2
1 5
3 0
0
329
2
1 5
2 0
end_DTG
begin_DTG
0
7
0
7
2
1 1
10 0
0
8
2
1 2
10 0
0
9
2
1 3
10 0
0
10
2
1 4
10 0
0
11
2
1 5
10 0
0
12
2
1 6
10 0
0
13
2
1 7
10 0
end_DTG
begin_DTG
8
1
283
1
1 3
1
360
1
1 7
1
353
1
1 6
1
346
1
1 5
1
318
1
1 4
1
206
1
1 0
1
269
1
1 2
1
248
1
1 1
2
0
0
1
1 2
0
1
1
1 5
end_DTG
begin_DTG
0
6
0
290
2
1 3
12 0
0
292
2
1 3
3 0
0
295
2
1 3
2 0
0
346
2
1 5
12 0
0
348
2
1 5
3 0
0
351
2
1 5
2 0
end_DTG
begin_DTG
0
7
0
35
2
1 1
13 0
0
36
2
1 2
13 0
0
37
2
1 3
13 0
0
38
2
1 4
13 0
0
39
2
1 5
13 0
0
40
2
1 6
13 0
0
41
2
1 7
13 0
end_DTG
begin_DTG
0
9
0
213
2
1 0
12 0
0
215
2
1 0
3 0
0
218
2
1 0
2 0
0
283
2
1 3
12 0
0
285
2
1 3
3 0
0
288
2
1 3
2 0
0
304
2
1 4
12 0
0
306
2
1 4
3 0
0
309
2
1 4
2 0
end_DTG
begin_DTG
0
7
0
14
2
1 1
15 0
0
15
2
1 2
15 0
0
16
2
1 3
15 0
0
17
2
1 4
15 0
0
18
2
1 5
15 0
0
19
2
1 6
15 0
0
20
2
1 7
15 0
end_DTG
begin_DTG
3
1
108
0
5
109
0
6
110
0
4
0
111
0
3
112
0
6
113
0
7
114
0
4
3
115
0
5
116
0
6
117
0
7
118
0
5
1
119
0
2
120
0
4
121
0
5
122
0
7
123
0
2
3
124
0
6
125
0
3
0
126
0
2
127
0
3
128
0
5
0
129
0
1
130
0
2
131
0
4
132
0
7
133
0
4
1
134
0
2
135
0
3
136
0
6
137
0
end_DTG
begin_DTG
1
1
194
2
17 0
22 0
0
end_DTG
begin_DTG
1
1
195
2
17 3
22 0
0
end_DTG
begin_DTG
1
1
196
2
17 4
22 0
0
end_DTG
begin_DTG
3
1
197
2
17 0
22 0
2
200
2
1 0
23 0
3
203
2
0 0
26 0
0
0
0
end_DTG
begin_DTG
6
1
194
2
17 0
18 0
1
195
2
17 3
19 0
1
196
2
17 4
20 0
1
197
2
17 0
21 0
1
198
2
17 3
24 0
1
199
2
17 6
25 0
1
0
105
0
end_DTG
begin_DTG
3
1
200
2
1 0
21 0
1
201
2
1 3
24 0
1
202
2
1 6
25 0
1
0
106
0
end_DTG
begin_DTG
3
1
198
2
17 3
22 0
2
201
2
1 3
23 0
3
204
2
0 3
26 0
0
0
0
end_DTG
begin_DTG
3
1
199
2
17 6
22 0
2
202
2
1 6
23 0
3
205
2
0 6
26 0
0
0
0
end_DTG
begin_DTG
3
1
203
2
0 0
21 0
1
204
2
0 3
24 0
1
205
2
0 6
25 0
1
0
107
0
end_DTG
begin_DTG
0
21
0
87
2
1 4
25 2
0
104
2
0 7
25 3
0
103
2
0 6
25 3
0
102
2
0 5
25 3
0
101
2
0 4
25 3
0
100
2
0 3
25 3
0
99
2
0 2
25 3
0
98
2
0 1
25 3
0
90
2
1 7
25 2
0
89
2
1 6
25 2
0
88
2
1 5
25 2
0
70
2
17 1
25 1
0
86
2
1 3
25 2
0
85
2
1 2
25 2
0
84
2
1 1
25 2
0
76
2
17 7
25 1
0
75
2
17 6
25 1
0
74
2
17 5
25 1
0
73
2
17 4
25 1
0
72
2
17 3
25 1
0
71
2
17 2
25 1
end_DTG
begin_DTG
0
21
0
80
2
1 4
24 2
0
97
2
0 7
24 3
0
96
2
0 6
24 3
0
95
2
0 5
24 3
0
94
2
0 4
24 3
0
93
2
0 3
24 3
0
92
2
0 2
24 3
0
91
2
0 1
24 3
0
83
2
1 7
24 2
0
82
2
1 6
24 2
0
81
2
1 5
24 2
0
63
2
17 1
24 1
0
79
2
1 3
24 2
0
78
2
1 2
24 2
0
77
2
1 1
24 2
0
69
2
17 7
24 1
0
68
2
17 6
24 1
0
67
2
17 5
24 1
0
66
2
17 4
24 1
0
65
2
17 3
24 1
0
64
2
17 2
24 1
end_DTG
begin_DTG
0
7
0
56
2
17 1
20 1
0
57
2
17 2
20 1
0
58
2
17 3
20 1
0
59
2
17 4
20 1
0
60
2
17 5
20 1
0
61
2
17 6
20 1
0
62
2
17 7
20 1
end_DTG
begin_DTG
0
7
0
49
2
17 1
19 1
0
50
2
17 2
19 1
0
51
2
17 3
19 1
0
52
2
17 4
19 1
0
53
2
17 5
19 1
0
54
2
17 6
19 1
0
55
2
17 7
19 1
end_DTG
begin_CG
6
21 1
24 1
25 1
28 7
27 7
26 3
21
21 1
24 1
25 1
12 25
3 72
2 71
11 7
16 7
9 7
7 7
14 7
5 7
28 7
27 7
23 3
10 4
15 9
8 6
6 6
13 6
4 4
6
10 2
15 3
8 3
6 3
13 2
4 2
6
10 2
15 3
8 3
6 3
13 2
4 2
1
5 7
0
1
7 7
0
1
9 7
0
1
11 7
0
2
15 3
13 2
1
14 7
0
1
16 7
0
11
18 1
19 1
20 1
21 1
24 1
25 1
30 7
29 7
28 7
27 7
22 6
1
22 1
2
30 7
22 1
2
29 7
22 1
3
22 1
23 1
26 1
6
18 1
19 1
20 1
21 1
24 1
25 1
3
21 1
24 1
25 1
4
28 21
22 1
23 1
26 1
4
27 21
22 1
23 1
26 1
3
21 1
24 1
25 1
0
0
0
0
end_CG
