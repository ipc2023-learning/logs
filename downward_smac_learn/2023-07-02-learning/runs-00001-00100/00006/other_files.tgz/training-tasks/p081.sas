begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var101
-1
2
Atom have_image(rover3, objective7, high_res)
NegatedAtom have_image(rover3, objective7, high_res)
end_variable
begin_variable
var100
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var98
-1
2
Atom have_image(rover3, objective5, low_res)
NegatedAtom have_image(rover3, objective5, low_res)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var95
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera4, rover2)
NegatedAtom calibrated(camera4, rover2)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover2, objective8, colour)
NegatedAtom have_image(rover2, objective8, colour)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover2, objective7, high_res)
NegatedAtom have_image(rover2, objective7, high_res)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var82
-1
2
Atom have_image(rover2, objective6, low_res)
NegatedAtom have_image(rover2, objective6, low_res)
end_variable
begin_variable
var79
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover1, objective8, colour)
NegatedAtom have_image(rover1, objective8, colour)
end_variable
begin_variable
var36
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover3, waypoint2)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var6
-1
2
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var7
-1
2
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
end_variable
begin_variable
var8
-1
4
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
Atom have_soil_analysis(rover3, waypoint1)
end_variable
begin_variable
var46
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var47
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var9
-1
4
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





8 0
0
391
2
7 2
8 0
0
427
2
7 5
8 0
0
442
2
7 7
8 0
0
457
2
7 8
8 0
end_DTG
begin_DTG
0
10
0
52
2
7 0
10 0
0
53
2
7 2
10 0
0
54
2
7 3
10 0
0
55
2
7 4
10 0
0
56
2
7 7
10 0
0
82
2
0 0
2 0
0
83
2
0 2
2 0
0
84
2
0 3
2 0
0
85
2
0 4
2 0
0
86
2
0 7
2 0
end_DTG
begin_DTG
0
2
0
362
2
7 0
8 0
0
404
2
7 3
8 0
end_DTG
begin_DTG
0
8
0
359
2
7 0
8 0
0
374
2
7 1
8 0
0
389
2
7 2
8 0
0
401
2
7 3
8 0
0
410
2
7 4
8 0
0
425
2
7 5
8 0
0
431
2
7 6
8 0
0
455
2
7 8
8 0
end_DTG
begin_DTG
0
4
0
356
2
7 0
8 0
0
386
2
7 2
8 0
0
422
2
7 5
8 0
0
440
2
7 7
8 0
end_DTG
begin_DTG
0
4
0
355
2
7 0
8 0
0
385
2
7 2
8 0
0
421
2
7 5
8 0
0
439
2
7 7
8 0
end_DTG
begin_DTG
0
10
0
32
2
7 0
15 0
0
33
2
7 2
15 0
0
34
2
7 3
15 0
0
35
2
7 4
15 0
0
36
2
7 7
15 0
0
62
2
0 0
6 0
0
63
2
0 2
6 0
0
64
2
0 3
6 0
0
65
2
0 4
6 0
0
66
2
0 7
6 0
end_DTG
begin_DTG
1
5
135
0
1
3
136
0
2
6
137
0
8
138
0
3
1
139
0
5
140
0
8
141
0
1
8
142
0
2
0
143
0
3
144
0
1
2
145
0
1
8
146
0
4
2
147
0
3
148
0
4
149
0
7
150
0
end_DTG
begin_DTG
9
1
294
1
17 5
1
311
1
17 6
1
314
1
17 7
1
283
1
17 4
1
347
1
17 8
1
275
1
17 3
1
219
1
17 0
1
238
1
17 1
1
258
1
17 2
1
0
1
1
17 5
end_DTG
begin_DTG
9
1
292
1
17 5
1
309
1
17 6
1
312
1
17 7
1
281
1
17 4
1
345
1
17 8
1
273
1
17 3
1
217
1
17 0
1
236
1
17 1
1
256
1
17 2
1
0
0
1
17 7
end_DTG
begin_DTG
0
2
0
328
2
17 7
19 0
0
330
2
17 7
18 0
end_DTG
begin_DTG
0
10
0
27
2
17 0
20 0
0
28
2
17 2
20 0
0
29
2
17 3
20 0
0
30
2
17 4
20 0
0
31
2
17 7
20 0
0
57
2
7 0
9 0
0
58
2
7 2
9 0
0
59
2
7 3
9 0
0
60
2
7 4
9 0
0
61
2
7 7
9 0
end_DTG
begin_DTG
0
4
0
217
2
17 0
19 0
0
219
2
17 0
18 0
0
273
2
17 3
19 0
0
275
2
17 3
18 0
end_DTG
begin_DTG
0
15
0
22
2
17 0
22 0
0
23
2
17 2
22 0
0
24
2
17 3
22 0
0
25
2
17 4
22 0
0
26
2
17 7
22 0
0
47
2
7 0
12 0
0
48
2
7 2
12 0
0
49
2
7 3
12 0
0
50
2
7 4
12 0
0
51
2
7 7
12 0
0
77
2
0 0
3 0
0
78
2
0 2
3 0
0
79
2
0 3
3 0
0
80
2
0 4
3 0
0
81
2
0 7
3 0
end_DTG
begin_DTG
0
16
0
213
2
17 0
19 0
0
215
2
17 0
18 0
0
233
2
17 1
19 0
0
235
2
17 1
18 0
0
253
2
17 2
19 0
0
255
2
17 2
18 0
0
269
2
17 3
19 0
0
271
2
17 3
18 0
0
281
2
17 4
19 0
0
283
2
17 4
18 0
0
301
2
17 5
19 0
0
303
2
17 5
18 0
0
309
2
17 6
19 0
0
311
2
17 6
18 0
0
341
2
17 8
19 0
0
343
2
17 8
18 0
end_DTG
begin_DTG
0
15
0
17
2
17 0
24 0
0
18
2
17 2
24 0
0
19
2
17 3
24 0
0
20
2
17 4
24 0
0
21
2
17 7
24 0
0
42
2
7 0
13 0
0
43
2
7 2
13 0
0
44
2
7 3
13 0
0
45
2
7 4
13 0
0
46
2
7 7
13 0
0
72
2
0 0
4 0
0
73
2
0 2
4 0
0
74
2
0 3
4 0
0
75
2
0 4
4 0
0
76
2
0 7
4 0
end_DTG
begin_DTG
0
8
0
209
2
17 0
19 0
0
211
2
17 0
18 0
0
249
2
17 2
19 0
0
251
2
17 2
18 0
0
297
2
17 5
19 0
0
299
2
17 5
18 0
0
321
2
17 7
19 0
0
323
2
17 7
18 0
end_DTG
begin_DTG
0
15
0
12
2
17 0
26 0
0
13
2
17 2
26 0
0
14
2
17 3
26 0
0
15
2
17 4
26 0
0
16
2
17 7
26 0
0
37
2
7 0
14 0
0
38
2
7 2
14 0
0
39
2
7 3
14 0
0
40
2
7 4
14 0
0
41
2
7 7
14 0
0
67
2
0 0
5 0
0
68
2
0 2
5 0
0
69
2
0 3
5 0
0
70
2
0 4
5 0
0
71
2
0 7
5 0
end_DTG
begin_DTG
1
1
187
2
0 1
37 0
0
end_DTG
begin_DTG
1
1
188
2
0 2
37 0
0
end_DTG
begin_DTG
1
1
189
2
0 5
37 0
0
end_DTG
begin_DTG
1
1
190
2
0 7
37 0
0
end_DTG
begin_DTG
3
1
191
2
17 0
33 0
2
194
2
7 0
34 0
3
197
2
0 0
37 0
0
0
0
end_DTG
begin_DTG
3
1
191
2
17 0
32 0
1
192
2
17 2
35 0
1
193
2
17 7
36 0
1
0
132
0
end_DTG
begin_DTG
3
1
194
2
7 0
32 0
1
195
2
7 2
35 0
1
196
2
7 7
36 0
1
0
133
0
end_DTG
begin_DTG
3
1
192
2
17 2
33 0
2
195
2
7 2
34 0
3
198
2
0 2
37 0
0
0
0
end_DTG
begin_DTG
3
1
193
2
17 7
33 0
2
196
2
7 7
34 0
3
199
2
0 7
37 0
0
0
0
end_DTG
begin_DTG
7
1
187
2
0 1
28 0
1
188
2
0 2
29 0
1
189
2
0 5
30 0
1
190
2
0 7
31 0
1
197
2
0 0
32 0
1
198
2
0 2
35 0
1
199
2
0 7
36 0
1
0
134
0
end_DTG
begin_DTG
0
15
0
97
2
17 0
36 1
0
98
2
17 2
36 1
0
99
2
17 3
36 1
0
100
2
17 4
36 1
0
101
2
17 7
36 1
0
112
2
7 0
36 2
0
113
2
7 2
36 2
0
114
2
7 3
36 2
0
115
2
7 4
36 2
0
116
2
7 7
36 2
0
127
2
0 0
36 3
0
128
2
0 2
36 3
0
129
2
0 3
36 3
0
130
2
0 4
36 3
0
131
2
0 7
36 3
end_DTG
begin_DTG
0
15
0
92
2
17 0
35 1
0
93
2
17 2
35 1
0
94
2
17 3
35 1
0
95
2
17 4
35 1
0
96
2
17 7
35 1
0
107
2
7 0
35 2
0
108
2
7 2
35 2
0
109
2
7 3
35 2
0
110
2
7 4
35 2
0
111
2
7 7
35 2
0
122
2
0 0
35 3
0
123
2
0 2
35 3
0
124
2
0 3
35 3
0
125
2
0 4
35 3
0
126
2
0 7
35 3
end_DTG
begin_DTG
0
15
0
87
2
17 0
32 1
0
88
2
17 2
32 1
0
89
2
17 3
32 1
0
90
2
17 4
32 1
0
91
2
17 7
32 1
0
102
2
7 0
32 2
0
103
2
7 2
32 2
0
104
2
7 3
32 2
0
105
2
7 4
32 2
0
106
2
7 7
32 2
0
117
2
0 0
32 3
0
118
2
0 2
32 3
0
119
2
0 3
32 3
0
120
2
0 4
32 3
0
121
2
0 7
32 3
end_DTG
begin_CG
22
28 1
29 1
30 1
31 1
32 1
35 1
36 1
1 82
16 5
27 5
25 5
23 5
11 5
40 5
39 5
38 5
37 7
6 4
5 4
4 8
3 2
2 6
5
6 4
5 4
4 8
3 2
2 6
1
11 5
1
23 5
1
25 5
1
27 5
1
16 5
20
32 1
35 1
36 1
8 113
16 5
27 5
25 5
23 5
11 5
21 5
40 5
39 5
38 5
34 3
15 4
14 4
13 8
12 2
10 6
9 1
6
15 4
14 4
13 8
12 2
10 6
9 1
1
21 5
1
11 5
0
1
23 5
1
25 5
1
27 5
1
16 5
0
17
32 1
35 1
36 1
19 75
18 75
27 5
25 5
23 5
21 5
40 5
39 5
38 5
33 3
26 8
24 16
22 4
20 2
4
26 4
24 8
22 2
20 1
4
26 4
24 8
22 2
20 1
1
21 5
0
1
23 5
0
1
25 5
0
1
27 5
0
1
37 1
1
37 1
1
37 1
1
37 1
4
40 15
33 1
34 1
37 1
3
32 1
35 1
36 1
3
32 1
35 1
36 1
4
39 15
33 1
34 1
37 1
4
38 15
33 1
34 1
37 1
7
28 1
29 1
30 1
31 1
32 1
35 1
36 1
0
0
0
end_CG
