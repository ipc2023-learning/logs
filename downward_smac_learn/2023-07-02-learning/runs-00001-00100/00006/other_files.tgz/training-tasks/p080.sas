begin_version
3
end_version
begin_metric
0
end_metric
47
begin_variable
var3
-1
9
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var18
-1
2
Atom calibrated(camera4, rover4)
NegatedAtom calibrated(camera4, rover4)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera2, rover4)
NegatedAtom calibrated(camera2, rover4)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera1, rover4)
NegatedAtom calibrated(camera1, rover4)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover4, objective7, colour)
NegatedAtom have_image(rover4, objective7, colour)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover4, objective4, high_res)
NegatedAtom have_image(rover4, objective4, high_res)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover4, objective2, colour)
NegatedAtom have_image(rover4, objective2, colour)
end_variable
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var79
-1
2
Atom have_image(rover2, objective8, colour)
NegatedAtom have_image(rover2, objective8, colour)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover2, objective7, low_res)
NegatedAtom have_image(rover2, objective7, low_res)
end_variable
begin_variable
var39
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover2, objective7, colour)
NegatedAtom have_image(rover2, objective7, colour)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var69
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover3, waypoint2)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var7
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var8
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var9
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var56
-1
2
Atom empty(rover3store)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7
2
9 3
10 0
0
412
2
9 4
10 0
0
424
2
9 5
10 0
0
445
2
9 6
10 0
0
484
2
9 8
10 0
end_DTG
begin_DTG
0
12
0
45
2
9 1
19 0
0
46
2
9 2
19 0
0
47
2
9 5
19 0
0
48
2
9 6
19 0
0
49
2
9 7
19 0
0
50
2
9 8
19 0
0
81
2
0 1
6 0
0
82
2
0 2
6 0
0
83
2
0 5
6 0
0
84
2
0 6
6 0
0
85
2
0 7
6 0
0
86
2
0 8
6 0
end_DTG
begin_DTG
0
8
0
336
2
9 0
10 0
0
357
2
9 1
10 0
0
390
2
9 3
10 0
0
405
2
9 4
10 0
0
420
2
9 5
10 0
0
438
2
9 6
10 0
0
456
2
9 7
10 0
0
477
2
9 8
10 0
end_DTG
begin_DTG
0
12
0
39
2
9 1
21 0
0
40
2
9 2
21 0
0
41
2
9 5
21 0
0
42
2
9 6
21 0
0
43
2
9 7
21 0
0
44
2
9 8
21 0
0
75
2
0 1
7 0
0
76
2
0 2
7 0
0
77
2
0 5
7 0
0
78
2
0 6
7 0
0
79
2
0 7
7 0
0
80
2
0 8
7 0
end_DTG
begin_DTG
0
6
0
335
2
9 0
10 0
0
356
2
9 1
10 0
0
374
2
9 2
10 0
0
389
2
9 3
10 0
0
437
2
9 6
10 0
0
476
2
9 8
10 0
end_DTG
begin_DTG
0
6
0
33
2
9 1
23 0
0
34
2
9 2
23 0
0
35
2
9 5
23 0
0
36
2
9 6
23 0
0
37
2
9 7
23 0
0
38
2
9 8
23 0
end_DTG
begin_DTG
2
2
199
0
6
200
0
1
2
201
0
3
0
202
0
1
203
0
3
204
0
1
2
205
0
3
5
206
0
7
207
0
8
208
0
2
4
209
0
8
210
0
3
0
211
0
7
212
0
8
213
0
3
4
214
0
6
215
0
8
216
0
4
4
217
0
5
218
0
6
219
0
7
220
0
end_DTG
begin_DTG
2
1
307
2
25 1
36 0
2
314
2
8 1
32 0
0
0
end_DTG
begin_DTG
2
1
308
2
25 2
36 0
2
315
2
8 2
32 0
0
0
end_DTG
begin_DTG
2
1
309
2
25 3
36 0
2
316
2
8 3
32 0
0
0
end_DTG
begin_DTG
2
1
310
2
25 4
36 0
2
317
2
8 4
32 0
0
0
end_DTG
begin_DTG
2
1
311
2
25 5
36 0
2
318
2
8 5
32 0
0
0
end_DTG
begin_DTG
2
1
312
2
25 6
36 0
2
319
2
8 6
32 0
0
0
end_DTG
begin_DTG
7
1
314
2
8 1
26 0
1
315
2
8 2
27 0
1
316
2
8 3
28 0
1
317
2
8 4
29 0
1
318
2
8 5
30 0
1
319
2
8 6
31 0
1
320
2
8 8
33 0
1
0
197
0
end_DTG
begin_DTG
2
1
313
2
25 8
36 0
2
320
2
8 8
32 0
0
0
end_DTG
begin_DTG
3
1
321
2
25 0
36 0
2
325
2
9 0
37 0
3
329
2
0 0
40 0
0
0
0
end_DTG
begin_DTG
3
1
322
2
25 2
36 0
2
326
2
9 2
37 0
3
330
2
0 2
40 0
0
0
0
end_DTG
begin_DTG
11
1
307
2
25 1
26 0
1
308
2
25 2
27 0
1
309
2
25 3
28 0
1
310
2
25 4
29 0
1
311
2
25 5
30 0
1
312
2
25 6
31 0
1
313
2
25 8
33 0
1
321
2
25 0
34 0
1
322
2
25 2
35 0
1
323
2
25 4
38 0
1
324
2
25 8
39 0
1
0
195
0
end_DTG
begin_DTG
4
1
325
2
9 0
34 0
1
326
2
9 2
35 0
1
327
2
9 4
38 0
1
328
2
9 8
39 0
1
0
196
0
end_DTG
begin_DTG
3
1
323
2
25 4
36 0
2
327
2
9 4
37 0
3
331
2
0 4
40 0
0
0
0
end_DTG
begin_DTG
3
1
324
2
25 8
36 0
2
328
2
9 8
37 0
3
332
2
0 8
40 0
0
0
0
end_DTG
begin_DTG
4
1
329
2
0 0
34 0
1
330
2
0 2
35 0
1
331
2
0 4
38 0
1
332
2
0 8
39 0
1
0
198
0
end_DTG
begin_DTG
0
18
0
168
2
9 6
39 2
0
194
2
0 8
39 3
0
193
2
0 7
39 3
0
192
2
0 6
39 3
0
191
2
0 5
39 3
0
190
2
0 2
39 3
0
189
2
0 1
39 3
0
170
2
9 8
39 2
0
169
2
9 7
39 2
0
141
2
25 1
39 1
0
167
2
9 5
39 2
0
166
2
9 2
39 2
0
165
2
9 1
39 2
0
146
2
25 8
39 1
0
145
2
25 7
39 1
0
144
2
25 6
39 1
0
143
2
25 5
39 1
0
142
2
25 2
39 1
end_DTG
begin_DTG
0
18
0
162
2
9 6
38 2
0
188
2
0 8
38 3
0
187
2
0 7
38 3
0
186
2
0 6
38 3
0
185
2
0 5
38 3
0
184
2
0 2
38 3
0
183
2
0 1
38 3
0
164
2
9 8
38 2
0
163
2
9 7
38 2
0
135
2
25 1
38 1
0
161
2
9 5
38 2
0
160
2
9 2
38 2
0
159
2
9 1
38 2
0
140
2
25 8
38 1
0
139
2
25 7
38 1
0
138
2
25 6
38 1
0
137
2
25 5
38 1
0
136
2
25 2
38 1
end_DTG
begin_DTG
0
18
0
156
2
9 6
35 2
0
182
2
0 8
35 3
0
181
2
0 7
35 3
0
180
2
0 6
35 3
0
179
2
0 5
35 3
0
178
2
0 2
35 3
0
177
2
0 1
35 3
0
158
2
9 8
35 2
0
157
2
9 7
35 2
0
129
2
25 1
35 1
0
155
2
9 5
35 2
0
154
2
9 2
35 2
0
153
2
9 1
35 2
0
134
2
25 8
35 1
0
133
2
25 7
35 1
0
132
2
25 6
35 1
0
131
2
25 5
35 1
0
130
2
25 2
35 1
end_DTG
begin_DTG
0
18
0
150
2
9 6
34 2
0
176
2
0 8
34 3
0
175
2
0 7
34 3
0
174
2
0 6
34 3
0
173
2
0 5
34 3
0
172
2
0 2
34 3
0
171
2
0 1
34 3
0
152
2
9 8
34 2
0
151
2
9 7
34 2
0
123
2
25 1
34 1
0
149
2
9 5
34 2
0
148
2
9 2
34 2
0
147
2
9 1
34 2
0
128
2
25 8
34 1
0
127
2
25 7
34 1
0
126
2
25 6
34 1
0
125
2
25 5
34 1
0
124
2
25 2
34 1
end_DTG
begin_DTG
0
12
0
105
2
25 1
27 1
0
106
2
25 2
27 1
0
107
2
25 5
27 1
0
108
2
25 6
27 1
0
109
2
25 7
27 1
0
110
2
25 8
27 1
0
117
2
8 1
27 2
0
118
2
8 2
27 2
0
119
2
8 5
27 2
0
120
2
8 6
27 2
0
121
2
8 7
27 2
0
122
2
8 8
27 2
end_DTG
begin_DTG
0
12
0
99
2
25 1
26 1
0
100
2
25 2
26 1
0
101
2
25 5
26 1
0
102
2
25 6
26 1
0
103
2
25 7
26 1
0
104
2
25 8
26 1
0
111
2
8 1
26 2
0
112
2
8 2
26 2
0
113
2
8 5
26 2
0
114
2
8 6
26 2
0
115
2
8 7
26 2
0
116
2
8 8
26 2
end_DTG
begin_CG
20
34 1
35 1
38 1
39 1
3 116
2 62
1 62
22 6
20 6
16 6
12 6
44 6
43 6
42 6
41 6
40 4
7 16
6 16
5 12
4 18
3
7 8
5 6
4 9
1
6 8
4
7 8
6 8
5 6
4 9
1
12 6
1
16 6
1
20 6
1
22 6
10
26 1
27 1
28 1
29 1
30 1
31 1
33 1
46 6
45 6
32 7
24
34 1
35 1
38 1
39 1
10 171
24 6
22 6
20 6
18 6
16 6
14 6
12 6
44 6
43 6
42 6
41 6
37 4
23 6
21 8
19 8
17 8
15 6
13 6
11 9
7
23 6
21 8
19 8
17 8
15 6
13 6
11 9
1
12 6
0
1
14 6
0
1
16 6
0
1
18 6
0
1
20 6
0
1
22 6
0
1
24 6
0
18
26 1
27 1
28 1
29 1
30 1
31 1
33 1
34 1
35 1
38 1
39 1
46 6
45 6
44 6
43 6
42 6
41 6
36 11
3
46 12
36 1
32 1
3
45 12
36 1
32 1
2
36 1
32 1
2
36 1
32 1
2
36 1
32 1
2
36 1
32 1
7
26 1
27 1
28 1
29 1
30 1
31 1
33 1
2
36 1
32 1
4
44 18
36 1
37 1
40 1
4
43 18
36 1
37 1
40 1
11
26 1
27 1
28 1
29 1
30 1
31 1
33 1
34 1
35 1
38 1
39 1
4
34 1
35 1
38 1
39 1
4
42 18
36 1
37 1
40 1
4
41 18
36 1
37 1
40 1
4
34 1
35 1
38 1
39 1
0
0
0
0
0
0
end_CG
