begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera4, rover4)
NegatedAtom calibrated(camera4, rover4)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera2, rover4)
NegatedAtom calibrated(camera2, rover4)
end_variable
begin_variable
var114
-1
2
Atom have_image(rover4, objective8, high_res)
NegatedAtom have_image(rover4, objective8, high_res)
end_variable
begin_variable
var105
-1
2
Atom have_image(rover4, objective5, high_res)
NegatedAtom have_image(rover4, objective5, high_res)
end_variable
begin_variable
var104
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var98
-1
2
Atom have_image(rover4, objective3, colour)
NegatedAtom have_image(rover4, objective3, colour)
end_variable
begin_variable
var93
-1
2
Atom have_image(rover4, objective10, high_res)
NegatedAtom have_image(rover4, objective10, high_res)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover4, objective10, colour)
NegatedAtom have_image(rover4, objective10, colour)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera1, rover4)
NegatedAtom calibrated(camera1, rover4)
end_variable
begin_variable
var100
-1
2
Atom have_image(rover4, objective3, low_res)
NegatedAtom have_image(rover4, objective3, low_res)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover4, objective2, low_res)
NegatedAtom have_image(rover4, objective2, low_res)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover4, objective10, low_res)
NegatedAtom have_image(rover4, objective10, low_res)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
10
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint10)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover2, objective8, high_res)
NegatedAtom have_image(rover2, objective8, high_res)
end_variable
begin_variable
var42
-1
2
Atom communicated_image_data(objective8, high_res)
NegatedAtom communicated_image_data(objective8, high_res)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover2, objective5, high_res)
NegatedAtom have_image(rover2, objective5, high_res)
end_variable
begin_variable
var33
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var67
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var64
-1
2
Atom have_image(rover2, objective10, low_res)
NegatedAtom have_image(rover2, objective10, low_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective10, low_res)
NegatedAtom communicated_image_data(objective10, low_res)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover2, objective10, high_res)
NegatedAtom have_image(rover2, objective10, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective10, high_res)
NegatedAtom communicated_image_data(objective10, high_res)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover2, objective10, colour)
NegatedAtom have_image(rover2, objective10, colour)
end_variable
begin_variable
var20
-1
2
Atom communicated_ima




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




443
2
14 2
15 0
0
479
2
14 4
15 0
0
494
2
14 5
15 0
0
515
2
14 6
15 0
0
530
2
14 7
15 0
0
557
2
14 8
15 0
0
575
2
14 9
15 0
end_DTG
begin_DTG
0
16
0
27
2
14 1
30 0
0
28
2
14 2
30 0
0
29
2
14 3
30 0
0
30
2
14 4
30 0
0
31
2
14 5
30 0
0
32
2
14 6
30 0
0
33
2
14 7
30 0
0
34
2
14 9
30 0
0
99
2
0 1
7 0
0
100
2
0 2
7 0
0
101
2
0 3
7 0
0
102
2
0 4
7 0
0
103
2
0 5
7 0
0
104
2
0 6
7 0
0
105
2
0 7
7 0
0
106
2
0 9
7 0
end_DTG
begin_DTG
0
7
0
442
2
14 2
15 0
0
478
2
14 4
15 0
0
493
2
14 5
15 0
0
514
2
14 6
15 0
0
529
2
14 7
15 0
0
556
2
14 8
15 0
0
574
2
14 9
15 0
end_DTG
begin_DTG
0
16
0
19
2
14 1
32 0
0
20
2
14 2
32 0
0
21
2
14 3
32 0
0
22
2
14 4
32 0
0
23
2
14 5
32 0
0
24
2
14 6
32 0
0
25
2
14 7
32 0
0
26
2
14 9
32 0
0
91
2
0 1
8 0
0
92
2
0 2
8 0
0
93
2
0 3
8 0
0
94
2
0 4
8 0
0
95
2
0 5
8 0
0
96
2
0 6
8 0
0
97
2
0 7
8 0
0
98
2
0 9
8 0
end_DTG
begin_DTG
2
1
389
2
14 3
41 0
2
393
2
13 3
42 0
0
0
end_DTG
begin_DTG
2
1
390
2
14 4
41 0
2
394
2
13 4
42 0
0
0
end_DTG
begin_DTG
2
1
391
2
14 6
41 0
2
395
2
13 6
42 0
0
0
end_DTG
begin_DTG
2
1
392
2
14 9
41 0
2
396
2
13 9
42 0
0
0
end_DTG
begin_DTG
3
1
374
2
14 0
41 0
2
379
2
13 0
42 0
3
384
2
0 0
45 0
0
0
0
end_DTG
begin_DTG
3
1
375
2
14 3
41 0
2
380
2
13 3
42 0
3
385
2
0 3
45 0
0
0
0
end_DTG
begin_DTG
3
1
376
2
14 4
41 0
2
381
2
13 4
42 0
3
386
2
0 4
45 0
0
0
0
end_DTG
begin_DTG
9
1
374
2
14 0
38 0
1
375
2
14 3
39 0
1
376
2
14 4
40 0
1
377
2
14 7
43 0
1
378
2
14 9
44 0
1
389
2
14 3
34 0
1
390
2
14 4
35 0
1
391
2
14 6
36 0
1
392
2
14 9
37 0
1
0
275
0
end_DTG
begin_DTG
9
1
379
2
13 0
38 0
1
380
2
13 3
39 0
1
381
2
13 4
40 0
1
382
2
13 7
43 0
1
383
2
13 9
44 0
1
393
2
13 3
34 0
1
394
2
13 4
35 0
1
395
2
13 6
36 0
1
396
2
13 9
37 0
1
0
276
0
end_DTG
begin_DTG
3
1
377
2
14 7
41 0
2
382
2
13 7
42 0
3
387
2
0 7
45 0
0
0
0
end_DTG
begin_DTG
3
1
378
2
14 9
41 0
2
383
2
13 9
42 0
3
388
2
0 9
45 0
0
0
0
end_DTG
begin_DTG
5
1
384
2
0 0
38 0
1
385
2
0 3
39 0
1
386
2
0 4
40 0
1
387
2
0 7
43 0
1
388
2
0 9
44 0
1
0
277
0
end_DTG
begin_DTG
0
16
0
235
2
14 1
37 1
0
236
2
14 2
37 1
0
237
2
14 3
37 1
0
238
2
14 4
37 1
0
239
2
14 5
37 1
0
240
2
14 6
37 1
0
241
2
14 7
37 1
0
242
2
14 9
37 1
0
267
2
13 1
37 2
0
268
2
13 2
37 2
0
269
2
13 3
37 2
0
270
2
13 4
37 2
0
271
2
13 5
37 2
0
272
2
13 6
37 2
0
273
2
13 7
37 2
0
274
2
13 9
37 2
end_DTG
begin_DTG
0
16
0
227
2
14 1
36 1
0
228
2
14 2
36 1
0
229
2
14 3
36 1
0
230
2
14 4
36 1
0
231
2
14 5
36 1
0
232
2
14 6
36 1
0
233
2
14 7
36 1
0
234
2
14 9
36 1
0
259
2
13 1
36 2
0
260
2
13 2
36 2
0
261
2
13 3
36 2
0
262
2
13 4
36 2
0
263
2
13 5
36 2
0
264
2
13 6
36 2
0
265
2
13 7
36 2
0
266
2
13 9
36 2
end_DTG
begin_DTG
0
16
0
219
2
14 1
35 1
0
220
2
14 2
35 1
0
221
2
14 3
35 1
0
222
2
14 4
35 1
0
223
2
14 5
35 1
0
224
2
14 6
35 1
0
225
2
14 7
35 1
0
226
2
14 9
35 1
0
251
2
13 1
35 2
0
252
2
13 2
35 2
0
253
2
13 3
35 2
0
254
2
13 4
35 2
0
255
2
13 5
35 2
0
256
2
13 6
35 2
0
257
2
13 7
35 2
0
258
2
13 9
35 2
end_DTG
begin_DTG
0
16
0
211
2
14 1
34 1
0
212
2
14 2
34 1
0
213
2
14 3
34 1
0
214
2
14 4
34 1
0
215
2
14 5
34 1
0
216
2
14 6
34 1
0
217
2
14 7
34 1
0
218
2
14 9
34 1
0
243
2
13 1
34 2
0
244
2
13 2
34 2
0
245
2
13 3
34 2
0
246
2
13 4
34 2
0
247
2
13 5
34 2
0
248
2
13 6
34 2
0
249
2
13 7
34 2
0
250
2
13 9
34 2
end_DTG
begin_DTG
0
24
0
191
2
13 5
40 2
0
210
2
0 9
40 3
0
209
2
0 7
40 3
0
208
2
0 6
40 3
0
207
2
0 5
40 3
0
206
2
0 4
40 3
0
205
2
0 3
40 3
0
204
2
0 2
40 3
0
203
2
0 1
40 3
0
194
2
13 9
40 2
0
193
2
13 7
40 2
0
192
2
13 6
40 2
0
171
2
14 1
40 1
0
190
2
13 4
40 2
0
189
2
13 3
40 2
0
188
2
13 2
40 2
0
187
2
13 1
40 2
0
178
2
14 9
40 1
0
177
2
14 7
40 1
0
176
2
14 6
40 1
0
175
2
14 5
40 1
0
174
2
14 4
40 1
0
173
2
14 3
40 1
0
172
2
14 2
40 1
end_DTG
begin_DTG
0
24
0
183
2
13 5
38 2
0
202
2
0 9
38 3
0
201
2
0 7
38 3
0
200
2
0 6
38 3
0
199
2
0 5
38 3
0
198
2
0 4
38 3
0
197
2
0 3
38 3
0
196
2
0 2
38 3
0
195
2
0 1
38 3
0
186
2
13 9
38 2
0
185
2
13 7
38 2
0
184
2
13 6
38 2
0
163
2
14 1
38 1
0
182
2
13 4
38 2
0
181
2
13 3
38 2
0
180
2
13 2
38 2
0
179
2
13 1
38 2
0
170
2
14 9
38 1
0
169
2
14 7
38 1
0
168
2
14 6
38 1
0
167
2
14 5
38 1
0
166
2
14 4
38 1
0
165
2
14 3
38 1
0
164
2
14 2
38 1
end_DTG
begin_CG
29
38 1
39 1
40 1
43 1
44 1
9 69
2 206
1 68
33 8
31 8
29 8
27 8
25 8
23 8
21 8
19 8
17 8
51 8
50 8
45 5
8 14
7 7
12 14
11 20
6 4
10 4
5 20
4 10
3 3
3
8 7
6 2
5 10
9
8 7
7 7
12 7
11 10
6 2
10 2
5 10
4 10
3 3
1
17 8
1
19 8
1
21 8
1
25 8
1
31 8
1
33 8
3
12 7
11 10
10 2
1
23 8
1
27 8
1
29 8
16
38 1
39 1
40 1
43 1
44 1
34 1
35 1
36 1
37 1
51 8
50 8
49 8
48 8
47 8
46 8
42 9
35
38 1
39 1
40 1
43 1
44 1
34 1
35 1
36 1
37 1
15 204
33 8
31 8
29 8
27 8
25 8
23 8
21 8
19 8
17 8
51 8
50 8
49 8
48 8
47 8
46 8
41 9
32 7
30 7
28 7
26 10
24 2
22 2
20 10
18 10
16 3
9
32 7
30 7
28 7
26 10
24 2
22 2
20 10
18 10
16 3
1
17 8
0
1
19 8
0
1
21 8
0
1
23 8
0
1
25 8
0
1
27 8
0
1
29 8
0
1
31 8
0
1
33 8
0
3
49 16
41 1
42 1
3
48 16
41 1
42 1
3
47 16
41 1
42 1
3
46 16
41 1
42 1
4
51 24
41 1
42 1
45 1
3
41 1
42 1
45 1
4
50 24
41 1
42 1
45 1
9
38 1
39 1
40 1
43 1
44 1
34 1
35 1
36 1
37 1
9
38 1
39 1
40 1
43 1
44 1
34 1
35 1
36 1
37 1
3
41 1
42 1
45 1
3
41 1
42 1
45 1
5
38 1
39 1
40 1
43 1
44 1
0
0
0
0
0
0
end_CG
