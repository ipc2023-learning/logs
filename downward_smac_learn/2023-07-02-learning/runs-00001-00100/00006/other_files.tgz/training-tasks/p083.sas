begin_version
3
end_version
begin_metric
0
end_metric
63
begin_variable
var3
-1
9
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera2, rover4)
NegatedAtom calibrated(camera2, rover4)
end_variable
begin_variable
var115
-1
2
Atom have_image(rover4, objective7, colour)
NegatedAtom have_image(rover4, objective7, colour)
end_variable
begin_variable
var114
-1
2
Atom have_image(rover4, objective6, colour)
NegatedAtom have_image(rover4, objective6, colour)
end_variable
begin_variable
var113
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var111
-1
2
Atom have_image(rover4, objective3, colour)
NegatedAtom have_image(rover4, objective3, colour)
end_variable
begin_variable
var109
-1
2
Atom have_image(rover4, objective1, colour)
NegatedAtom have_image(rover4, objective1, colour)
end_variable
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var108
-1
2
Atom have_image(rover3, objective9, low_res)
NegatedAtom have_image(rover3, objective9, low_res)
end_variable
begin_variable
var107
-1
2
Atom have_image(rover3, objective9, high_res)
NegatedAtom have_image(rover3, objective9, high_res)
end_variable
begin_variable
var105
-1
2
Atom have_image(rover3, objective8, low_res)
NegatedAtom have_image(rover3, objective8, low_res)
end_variable
begin_variable
var104
-1
2
Atom have_image(rover3, objective8, high_res)
NegatedAtom have_image(rover3, objective8, high_res)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover3, objective7, low_res)
NegatedAtom have_image(rover3, objective7, low_res)
end_variable
begin_variable
var100
-1
2
Atom have_image(rover3, objective7, colour)
NegatedAtom have_image(rover3, objective7, colour)
end_variable
begin_variable
var99
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var98
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover3, objective5, low_res)
NegatedAtom have_image(rover3, objective5, low_res)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover3, objective5, colour)
NegatedAtom have_image(rover3, objective5, colour)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover3, objective3, high_res)
NegatedAtom have_image(rover3, objective3, high_res)
end_variable
begin_variable
var88
-1
2
Atom have_image(rover3, objective3, colour)
NegatedAtom have_image(rover3, objective3, colour)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var83
-1
2
Atom have_image(rover3, objective1, high_res)
NegatedAtom have_image(rover3, objective1, high_res)
end_variable
begin_variable
var82
-1
2
Atom have_image(rover3, objective1, colour)
NegatedAtom have_image(rover3, objective1, colour)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera4, rover1)
NegatedAtom calibrated(camera4, rover1)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover1, objective9, low_res)
NegatedAtom have_image(rover1, objective9, low_res)
end_variable
begin_variable
var43
-1
2
Atom communicated_image_data(objective9, low_res)
NegatedAtom communicated_image_data(objective9, low_res)
end_variable
begin_variable
var80
-1
2
Atom have_image(rover1, objective9, high_res)
NegatedAtom have_image(rover1, objective9, high_res)
end_variable
begin_variable
var42
-1
2
Atom communicated_image_data(objective9, high_res)
NegatedAtom communicated_image_data(objective9, high_res)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover1, objective8, low_res)
NegatedAtom have_image(rover1, objective8, low_res)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective8, low_re




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 5
28 0
0
578
2
26 5
27 0
0
605
2
26 6
28 0
0
608
2
26 6
27 0
0
641
2
26 7
28 0
0
644
2
26 7
27 0
0
671
2
26 8
28 0
0
674
2
26 8
27 0
end_DTG
begin_DTG
0
16
0
75
2
26 0
47 0
0
76
2
26 1
47 0
0
77
2
26 3
47 0
0
78
2
26 4
47 0
0
79
2
26 5
47 0
0
80
2
26 6
47 0
0
81
2
26 7
47 0
0
82
2
26 8
47 0
0
211
2
7 0
18 0
0
212
2
7 1
18 0
0
213
2
7 3
18 0
0
214
2
7 4
18 0
0
215
2
7 5
18 0
0
216
2
7 6
18 0
0
217
2
7 7
18 0
0
218
2
7 8
18 0
end_DTG
begin_DTG
0
16
0
435
2
26 0
28 0
0
438
2
26 0
27 0
0
459
2
26 1
28 0
0
462
2
26 1
27 0
0
483
2
26 2
28 0
0
486
2
26 2
27 0
0
513
2
26 3
28 0
0
516
2
26 3
27 0
0
573
2
26 5
28 0
0
576
2
26 5
27 0
0
603
2
26 6
28 0
0
606
2
26 6
27 0
0
639
2
26 7
28 0
0
642
2
26 7
27 0
0
669
2
26 8
28 0
0
672
2
26 8
27 0
end_DTG
begin_DTG
0
24
0
207
2
7 5
19 0
0
314
2
0 8
4 0
0
313
2
0 7
4 0
0
312
2
0 6
4 0
0
311
2
0 5
4 0
0
310
2
0 4
4 0
0
309
2
0 3
4 0
0
308
2
0 1
4 0
0
307
2
0 0
4 0
0
210
2
7 8
19 0
0
209
2
7 7
19 0
0
208
2
7 6
19 0
0
67
2
26 0
49 0
0
206
2
7 4
19 0
0
205
2
7 3
19 0
0
204
2
7 1
19 0
0
203
2
7 0
19 0
0
74
2
26 8
49 0
0
73
2
26 7
49 0
0
72
2
26 6
49 0
0
71
2
26 5
49 0
0
70
2
26 4
49 0
0
69
2
26 3
49 0
0
68
2
26 1
49 0
end_DTG
begin_DTG
0
6
0
478
2
26 2
28 0
0
481
2
26 2
27 0
0
568
2
26 5
28 0
0
571
2
26 5
27 0
0
598
2
26 6
28 0
0
601
2
26 6
27 0
end_DTG
begin_DTG
0
16
0
59
2
26 0
51 0
0
60
2
26 1
51 0
0
61
2
26 3
51 0
0
62
2
26 4
51 0
0
63
2
26 5
51 0
0
64
2
26 6
51 0
0
65
2
26 7
51 0
0
66
2
26 8
51 0
0
195
2
7 0
20 0
0
196
2
7 1
20 0
0
197
2
7 3
20 0
0
198
2
7 4
20 0
0
199
2
7 5
20 0
0
200
2
7 6
20 0
0
201
2
7 7
20 0
0
202
2
7 8
20 0
end_DTG
begin_DTG
0
6
0
430
2
26 0
28 0
0
433
2
26 0
27 0
0
544
2
26 4
28 0
0
547
2
26 4
27 0
0
562
2
26 5
28 0
0
565
2
26 5
27 0
end_DTG
begin_DTG
0
16
0
51
2
26 0
53 0
0
52
2
26 1
53 0
0
53
2
26 3
53 0
0
54
2
26 4
53 0
0
55
2
26 5
53 0
0
56
2
26 6
53 0
0
57
2
26 7
53 0
0
58
2
26 8
53 0
0
187
2
7 0
21 0
0
188
2
7 1
21 0
0
189
2
7 3
21 0
0
190
2
7 4
21 0
0
191
2
7 5
21 0
0
192
2
7 6
21 0
0
193
2
7 7
21 0
0
194
2
7 8
21 0
end_DTG
begin_DTG
0
6
0
429
2
26 0
28 0
0
432
2
26 0
27 0
0
543
2
26 4
28 0
0
546
2
26 4
27 0
0
561
2
26 5
28 0
0
564
2
26 5
27 0
end_DTG
begin_DTG
0
24
0
183
2
7 5
22 0
0
306
2
0 8
5 0
0
305
2
0 7
5 0
0
304
2
0 6
5 0
0
303
2
0 5
5 0
0
302
2
0 4
5 0
0
301
2
0 3
5 0
0
300
2
0 1
5 0
0
299
2
0 0
5 0
0
186
2
7 8
22 0
0
185
2
7 7
22 0
0
184
2
7 6
22 0
0
43
2
26 0
55 0
0
182
2
7 4
22 0
0
181
2
7 3
22 0
0
180
2
7 1
22 0
0
179
2
7 0
22 0
0
50
2
26 8
55 0
0
49
2
26 7
55 0
0
48
2
26 6
55 0
0
47
2
26 5
55 0
0
46
2
26 4
55 0
0
45
2
26 3
55 0
0
44
2
26 1
55 0
end_DTG
begin_DTG
0
8
0
419
2
26 0
28 0
0
422
2
26 0
27 0
0
503
2
26 3
28 0
0
506
2
26 3
27 0
0
533
2
26 4
28 0
0
536
2
26 4
27 0
0
629
2
26 7
28 0
0
632
2
26 7
27 0
end_DTG
begin_DTG
0
16
0
35
2
26 0
57 0
0
36
2
26 1
57 0
0
37
2
26 3
57 0
0
38
2
26 4
57 0
0
39
2
26 5
57 0
0
40
2
26 6
57 0
0
41
2
26 7
57 0
0
42
2
26 8
57 0
0
171
2
7 0
23 0
0
172
2
7 1
23 0
0
173
2
7 3
23 0
0
174
2
7 4
23 0
0
175
2
7 5
23 0
0
176
2
7 6
23 0
0
177
2
7 7
23 0
0
178
2
7 8
23 0
end_DTG
begin_DTG
0
8
0
418
2
26 0
28 0
0
421
2
26 0
27 0
0
502
2
26 3
28 0
0
505
2
26 3
27 0
0
532
2
26 4
28 0
0
535
2
26 4
27 0
0
628
2
26 7
28 0
0
631
2
26 7
27 0
end_DTG
begin_DTG
0
16
0
27
2
26 0
59 0
0
28
2
26 1
59 0
0
29
2
26 3
59 0
0
30
2
26 4
59 0
0
31
2
26 5
59 0
0
32
2
26 6
59 0
0
33
2
26 7
59 0
0
34
2
26 8
59 0
0
163
2
7 0
24 0
0
164
2
7 1
24 0
0
165
2
7 3
24 0
0
166
2
7 4
24 0
0
167
2
7 5
24 0
0
168
2
7 6
24 0
0
169
2
7 7
24 0
0
170
2
7 8
24 0
end_DTG
begin_DTG
0
8
0
417
2
26 0
28 0
0
420
2
26 0
27 0
0
501
2
26 3
28 0
0
504
2
26 3
27 0
0
531
2
26 4
28 0
0
534
2
26 4
27 0
0
627
2
26 7
28 0
0
630
2
26 7
27 0
end_DTG
begin_DTG
0
24
0
159
2
7 5
25 0
0
298
2
0 8
6 0
0
297
2
0 7
6 0
0
296
2
0 6
6 0
0
295
2
0 5
6 0
0
294
2
0 4
6 0
0
293
2
0 3
6 0
0
292
2
0 1
6 0
0
291
2
0 0
6 0
0
162
2
7 8
25 0
0
161
2
7 7
25 0
0
160
2
7 6
25 0
0
19
2
26 0
61 0
0
158
2
7 4
25 0
0
157
2
7 3
25 0
0
156
2
7 1
25 0
0
155
2
7 0
25 0
0
26
2
26 8
61 0
0
25
2
26 7
61 0
0
24
2
26 6
61 0
0
23
2
26 5
61 0
0
22
2
26 4
61 0
0
21
2
26 3
61 0
0
20
2
26 1
61 0
end_DTG
begin_CG
11
1 53
62 8
56 8
50 8
46 8
40 8
6 4
5 3
4 8
3 6
2 1
5
6 4
5 3
4 8
3 6
2 1
1
40 8
1
46 8
1
50 8
1
56 8
1
62 8
35
8 141
62 8
60 8
58 8
56 8
54 8
52 8
50 8
48 8
46 8
44 8
42 8
40 8
38 8
36 8
34 8
32 8
30 8
25 4
24 4
23 4
22 3
21 3
20 3
19 8
18 8
17 6
16 6
15 6
14 1
13 1
12 5
11 5
10 7
9 7
17
25 4
24 4
23 4
22 3
21 3
20 3
19 8
18 8
17 6
16 6
15 6
14 1
13 1
12 5
11 5
10 7
9 7
1
30 8
1
32 8
1
34 8
1
36 8
1
38 8
1
40 8
1
42 8
1
44 8
1
46 8
1
48 8
1
50 8
1
52 8
1
54 8
1
56 8
1
58 8
1
60 8
1
62 8
36
28 143
27 142
62 8
60 8
58 8
56 8
54 8
52 8
50 8
48 8
46 8
44 8
42 8
40 8
38 8
36 8
34 8
32 8
30 8
61 8
59 8
57 8
55 6
53 6
51 6
49 16
47 16
45 12
43 12
41 12
39 2
37 2
35 10
33 10
31 14
29 14
17
61 4
59 4
57 4
55 3
53 3
51 3
49 8
47 8
45 6
43 6
41 6
39 1
37 1
35 5
33 5
31 7
29 7
17
61 4
59 4
57 4
55 3
53 3
51 3
49 8
47 8
45 6
43 6
41 6
39 1
37 1
35 5
33 5
31 7
29 7
1
30 8
0
1
32 8
0
1
34 8
0
1
36 8
0
1
38 8
0
1
40 8
0
1
42 8
0
1
44 8
0
1
46 8
0
1
48 8
0
1
50 8
0
1
52 8
0
1
54 8
0
1
56 8
0
1
58 8
0
1
60 8
0
1
62 8
0
end_CG
