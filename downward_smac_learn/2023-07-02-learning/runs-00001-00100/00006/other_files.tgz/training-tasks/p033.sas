begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var1
-1
5
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover2, objective2, high_res)
NegatedAtom have_image(rover2, objective2, high_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var31
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var29
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var5
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var27
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var28
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var26
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var24
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var23
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var22
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var21
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var20
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
0
begin_state
0
1
1
1
1
1
1
1
1
1
1
1
1
4
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
end_state
begin_goal
11
3 0
6 0
8 0
10 0
12 0
23 0
24 0
25 0
26 0
27 0
28 0
end_goal
140
begin_operator
calibrate rover2 camera1 objective1 waypoint1
1
0 0
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint3
1
0 2
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint4
1
0 3
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective1 waypoint5
1
0 4
1
0 4 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective2 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint1 waypoint4
2
0 0
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover2 general objective1 colour waypoint2 waypoint4
2
0 1
11 0
1
0 12 -1 0
0
end_operator
begin_operator
co




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




h 5
check 0
check 1
19
check 0
check 0
switch 14
check 1
75
switch 21
check 0
check 1
85
check 0
check 0
check 0
check 1
32
switch 15
check 0
check 0
check 0
check 1
35
switch 16
check 0
check 0
check 0
check 1
38
switch 17
check 0
check 0
check 0
check 1
50
switch 18
check 0
check 0
check 0
check 1
53
switch 22
check 0
check 0
check 0
check 1
56
switch 4
check 0
check 2
108
109
check 0
switch 1
check 0
check 2
110
111
check 0
switch 11
check 0
check 1
8
check 0
switch 9
check 0
check 1
11
check 0
switch 2
check 0
check 1
14
check 0
switch 7
check 0
check 1
17
check 0
switch 5
check 0
check 1
20
check 0
check 0
switch 14
check 4
1
5
76
77
check 0
check 0
check 1
33
switch 15
check 0
switch 21
check 0
check 1
86
check 0
check 0
check 0
check 1
36
switch 16
check 0
check 0
check 0
check 1
39
switch 17
check 0
check 0
check 0
check 1
51
switch 18
check 0
switch 21
check 0
check 1
93
check 0
check 0
check 0
check 1
54
switch 22
check 0
check 0
check 0
check 1
57
switch 4
check 0
check 4
112
113
116
117
check 0
switch 1
check 0
check 4
114
115
118
119
check 0
switch 11
check 0
check 1
9
check 0
switch 9
check 0
check 1
12
check 0
switch 2
check 0
check 1
15
check 0
switch 7
check 0
check 1
18
check 0
switch 5
check 0
check 1
21
check 0
check 0
switch 14
check 5
2
6
78
79
80
check 0
check 0
check 0
switch 16
check 0
switch 21
check 0
check 1
87
check 0
check 0
check 0
check 0
switch 19
check 0
switch 21
check 0
check 1
94
check 0
check 0
check 0
check 0
switch 4
check 0
check 6
120
121
124
125
128
129
check 0
switch 1
check 0
check 6
122
123
126
127
130
131
check 0
check 0
switch 14
check 2
3
81
check 0
check 0
check 0
switch 22
check 0
switch 21
check 0
check 1
95
check 0
check 0
check 0
check 0
switch 4
check 0
check 4
132
133
136
137
check 0
switch 1
check 0
check 4
134
135
138
139
check 0
check 0
switch 20
check 0
check 0
check 1
58
switch 21
check 0
check 0
check 1
59
check 0
end_SG
begin_DTG
3
2
72
0
3
73
0
4
74
0
1
3
75
0
2
0
76
0
3
77
0
3
0
78
0
1
79
0
2
80
0
1
0
81
0
end_DTG
begin_DTG
5
1
119
1
0 2
1
139
1
0 4
1
131
1
0 3
1
98
1
0 0
1
111
1
0 1
3
0
4
1
0 0
0
5
1
0 2
0
6
1
0 3
end_DTG
begin_DTG
0
3
0
103
2
0 0
1 0
0
119
2
0 2
1 0
0
127
2
0 3
1 0
end_DTG
begin_DTG
0
3
0
13
2
0 0
2 0
0
14
2
0 1
2 0
0
15
2
0 2
2 0
end_DTG
begin_DTG
5
1
117
1
0 2
1
137
1
0 4
1
129
1
0 3
1
96
1
0 0
1
109
1
0 1
4
0
0
1
0 0
0
1
1
0 2
0
2
1
0 3
0
3
1
0 4
end_DTG
begin_DTG
0
8
0
104
2
0 0
4 0
0
106
2
0 0
1 0
0
108
2
0 1
4 0
0
110
2
0 1
1 0
0
128
2
0 3
4 0
0
130
2
0 3
1 0
0
136
2
0 4
4 0
0
138
2
0 4
1 0
end_DTG
begin_DTG
0
3
0
19
2
0 0
5 0
0
20
2
0 1
5 0
0
21
2
0 2
5 0
end_DTG
begin_DTG
0
3
0
101
2
0 0
4 0
0
117
2
0 2
4 0
0
125
2
0 3
4 0
end_DTG
begin_DTG
0
3
0
16
2
0 0
7 0
0
17
2
0 1
7 0
0
18
2
0 2
7 0
end_DTG
begin_DTG
0
4
0
97
2
0 0
4 0
0
113
2
0 2
4 0
0
121
2
0 3
4 0
0
133
2
0 4
4 0
end_DTG
begin_DTG
0
3
0
10
2
0 0
9 0
0
11
2
0 1
9 0
0
12
2
0 2
9 0
end_DTG
begin_DTG
0
8
0
96
2
0 0
4 0
0
98
2
0 0
1 0
0
112
2
0 2
4 0
0
114
2
0 2
1 0
0
120
2
0 3
4 0
0
122
2
0 3
1 0
0
132
2
0 4
4 0
0
134
2
0 4
1 0
end_DTG
begin_DTG
0
3
0
7
2
0 0
11 0
0
8
2
0 1
11 0
0
9
2
0 2
11 0
end_DTG
begin_DTG
3
1
60
0
3
61
0
4
62
0
2
0
63
0
3
64
0
2
3
65
0
4
66
0
3
0
67
0
1
68
0
2
69
0
2
0
70
0
2
71
0
end_DTG
begin_DTG
2
1
82
2
13 1
20 0
2
85
2
0 1
21 0
0
0
end_DTG
begin_DTG
2
1
83
2
13 2
20 0
2
86
2
0 2
21 0
0
0
end_DTG
begin_DTG
2
1
84
2
13 3
20 0
2
87
2
0 3
21 0
0
0
end_DTG
begin_DTG
2
1
88
2
13 0
20 0
2
92
2
0 0
21 0
0
0
end_DTG
begin_DTG
2
1
89
2
13 2
20 0
2
93
2
0 2
21 0
0
0
end_DTG
begin_DTG
2
1
90
2
13 3
20 0
2
94
2
0 3
21 0
0
0
end_DTG
begin_DTG
7
1
82
2
13 1
14 0
1
83
2
13 2
15 0
1
84
2
13 3
16 0
1
88
2
13 0
17 0
1
89
2
13 2
18 0
1
90
2
13 3
19 0
1
91
2
13 4
22 0
1
0
58
0
end_DTG
begin_DTG
7
1
85
2
0 1
14 0
1
86
2
0 2
15 0
1
87
2
0 3
16 0
1
92
2
0 0
17 0
1
93
2
0 2
18 0
1
94
2
0 3
19 0
1
95
2
0 4
22 0
1
0
59
0
end_DTG
begin_DTG
2
1
91
2
13 4
20 0
2
95
2
0 4
21 0
0
0
end_DTG
begin_DTG
0
6
0
46
2
13 0
22 1
0
47
2
13 1
22 1
0
48
2
13 2
22 1
0
55
2
0 0
22 2
0
56
2
0 1
22 2
0
57
2
0 2
22 2
end_DTG
begin_DTG
0
6
0
43
2
13 0
18 1
0
44
2
13 1
18 1
0
45
2
13 2
18 1
0
52
2
0 0
18 2
0
53
2
0 1
18 2
0
54
2
0 2
18 2
end_DTG
begin_DTG
0
6
0
40
2
13 0
17 1
0
41
2
13 1
17 1
0
42
2
13 2
17 1
0
49
2
0 0
17 2
0
50
2
0 1
17 2
0
51
2
0 2
17 2
end_DTG
begin_DTG
0
6
0
28
2
13 0
16 1
0
29
2
13 1
16 1
0
30
2
13 2
16 1
0
37
2
0 0
16 2
0
38
2
0 1
16 2
0
39
2
0 2
16 2
end_DTG
begin_DTG
0
6
0
25
2
13 0
15 1
0
26
2
13 1
15 1
0
27
2
13 2
15 1
0
34
2
0 0
15 2
0
35
2
0 1
15 2
0
36
2
0 2
15 2
end_DTG
begin_DTG
0
6
0
22
2
13 0
14 1
0
23
2
13 1
14 1
0
24
2
13 2
14 1
0
31
2
0 0
14 2
0
32
2
0 1
14 2
0
33
2
0 2
14 2
end_DTG
begin_CG
26
14 1
15 1
16 1
17 1
18 1
19 1
22 1
4 26
1 25
12 3
10 3
3 3
8 3
6 3
28 3
27 3
26 3
25 3
24 3
23 3
21 7
11 8
9 4
2 3
7 3
5 8
3
11 4
2 3
5 4
1
3 3
0
4
11 4
9 4
7 3
5 4
1
6 3
0
1
8 3
0
1
10 3
0
1
12 3
0
14
14 1
15 1
16 1
17 1
18 1
19 1
22 1
28 3
27 3
26 3
25 3
24 3
23 3
20 7
3
28 6
20 1
21 1
3
27 6
20 1
21 1
3
26 6
20 1
21 1
3
25 6
20 1
21 1
3
24 6
20 1
21 1
2
20 1
21 1
7
14 1
15 1
16 1
17 1
18 1
19 1
22 1
7
14 1
15 1
16 1
17 1
18 1
19 1
22 1
3
23 6
20 1
21 1
0
0
0
0
0
0
end_CG
