begin_version
3
end_version
begin_metric
0
end_metric
35
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var41
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var37
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var31
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var32
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
end_variable
begin_variable
var30
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var29
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var28
-1
2
Atom communicated_rock_data(waypoint7)
NegatedAtom communicated_rock_data(waypoint7)
end_variable
begin_variable
var27
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var25
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
0
begin_state
3
6
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
1
1
1
1
1
end_state
begin_goal
14
5 0
7 0
9 0
11 0
13 0
15 0
17 0
19 0
21 0
30 0
31 0
32 0
33 0
34 0
end_goal
252
begin_operator
calibrate 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
switch 25
check 0
switch 28
check 0
check 1
103
check 0
check 0
check 0
check 0
check 0
check 3
90
91
92
switch 24
check 3
93
94
95
check 0
check 0
check 1
46
switch 26
check 0
switch 28
check 0
check 1
104
check 0
check 0
check 0
check 1
49
switch 29
check 0
check 0
check 0
check 1
52
check 0
switch 24
check 2
96
97
check 0
check 0
check 1
47
switch 26
check 0
check 0
check 0
check 1
50
switch 29
check 0
switch 28
check 0
check 1
105
check 0
check 0
check 0
check 1
53
check 0
switch 27
check 0
check 0
check 1
60
switch 28
check 0
check 0
check 1
61
check 0
end_SG
begin_DTG
1
2
80
0
2
2
81
0
5
82
0
4
0
83
0
1
84
0
3
85
0
6
86
0
3
2
87
0
4
88
0
5
89
0
3
3
90
0
5
91
0
6
92
0
3
1
93
0
3
94
0
4
95
0
2
2
96
0
4
97
0
end_DTG
begin_DTG
2
2
62
0
5
63
0
3
2
64
0
5
65
0
6
66
0
4
0
67
0
1
68
0
3
69
0
6
70
0
2
2
71
0
4
72
0
2
3
73
0
5
74
0
3
0
75
0
1
76
0
4
77
0
2
1
78
0
2
79
0
end_DTG
begin_DTG
7
1
201
1
1 4
1
215
1
1 5
1
191
1
1 3
1
237
1
1 6
1
129
1
1 0
1
143
1
1 1
1
165
1
1 2
3
0
6
1
1 2
0
7
1
1 3
0
8
1
1 6
end_DTG
begin_DTG
7
1
198
1
1 4
1
212
1
1 5
1
188
1
1 3
1
234
1
1 6
1
126
1
1 0
1
140
1
1 1
1
162
1
1 2
6
0
0
1
1 0
0
1
1
1 1
0
2
1
1 2
0
3
1
1 4
0
4
1
1 5
0
5
1
1 6
end_DTG
begin_DTG
0
14
0
128
2
1 0
3 0
0
131
2
1 0
2 0
0
146
2
1 1
3 0
0
149
2
1 1
2 0
0
170
2
1 2
3 0
0
173
2
1 2
2 0
0
188
2
1 3
3 0
0
191
2
1 3
2 0
0
206
2
1 4
3 0
0
209
2
1 4
2 0
0
224
2
1 5
3 0
0
227
2
1 5
2 0
0
248
2
1 6
3 0
0
251
2
1 6
2 0
end_DTG
begin_DTG
0
3
0
33
2
1 2
4 0
0
34
2
1 5
4 0
0
35
2
1 6
4 0
end_DTG
begin_DTG
0
14
0
127
2
1 0
3 0
0
130
2
1 0
2 0
0
145
2
1 1
3 0
0
148
2
1 1
2 0
0
169
2
1 2
3 0
0
172
2
1 2
2 0
0
187
2
1 3
3 0
0
190
2
1 3
2 0
0
205
2
1 4
3 0
0
208
2
1 4
2 0
0
223
2
1 5
3 0
0
226
2
1 5
2 0
0
247
2
1 6
3 0
0
250
2
1 6
2 0
end_DTG
begin_DTG
0
3
0
30
2
1 2
6 0
0
31
2
1 5
6 0
0
32
2
1 6
6 0
end_DTG
begin_DTG
0
4
0
122
2
1 0
3 0
0
125
2
1 0
2 0
0
236
2
1 6
3 0
0
239
2
1 6
2 0
end_DTG
begin_DTG
0
3
0
27
2
1 2
8 0
0
28
2
1 5
8 0
0
29
2
1 6
8 0
end_DTG
begin_DTG
0
4
0
120
2
1 0
3 0
0
123
2
1 0
2 0
0
234
2
1 6
3 0
0
237
2
1 6
2 0
end_DTG
begin_DTG
0
3
0
24
2
1 2
10 0
0
25
2
1 5
10 0
0
26
2
1 6
10 0
end_DTG
begin_DTG
0
12
0
115
2
1 0
3 0
0
118
2
1 0
2 0
0
139
2
1 1
3 0
0
142
2
1 1
2 0
0
157
2
1 2
3 0
0
160
2
1 2
2 0
0
175
2
1 3
3 0
0
178
2
1 3
2 0
0
199
2
1 4
3 0
0
202
2
1 4
2 0
0
217
2
1 5
3 0
0
220
2
1 5
2 0
end_DTG
begin_DTG
0
3
0
21
2
1 2
12 0
0
22
2
1 5
12 0
0
23
2
1 6
12 0
end_DTG
begin_DTG
0
12
0
114
2
1 0
3 0
0
117
2
1 0
2 0
0
138
2
1 1
3 0
0
141
2
1 1
2 0
0
156
2
1 2
3 0
0
159
2
1 2
2 0
0
174
2
1 3
3 0
0
177
2
1 3
2 0
0
198
2
1 4
3 0
0
201
2
1 4
2 0
0
216
2
1 5
3 0
0
219
2
1 5
2 0
end_DTG
begin_DTG
0
3
0
18
2
1 2
14 0
0
19
2
1 5
14 0
0
20
2
1 6
14 0
end_DTG
begin_DTG
0
12
0
110
2
1 0
3 0
0
113
2
1 0
2 0
0
134
2
1 1
3 0
0
137
2
1 1
2 0
0
152
2
1 2
3 0
0
155
2
1 2
2 0
0
194
2
1 4
3 0
0
197
2
1 4
2 0
0
212
2
1 5
3 0
0
215
2
1 5
2 0
0
230
2
1 6
3 0
0
233
2
1 6
2 0
end_DTG
begin_DTG
0
3
0
15
2
1 2
16 0
0
16
2
1 5
16 0
0
17
2
1 6
16 0
end_DTG
begin_DTG
0
12
0
109
2
1 0
3 0
0
112
2
1 0
2 0
0
133
2
1 1
3 0
0
136
2
1 1
2 0
0
151
2
1 2
3 0
0
154
2
1 2
2 0
0
193
2
1 4
3 0
0
196
2
1 4
2 0
0
211
2
1 5
3 0
0
214
2
1 5
2 0
0
229
2
1 6
3 0
0
232
2
1 6
2 0
end_DTG
begin_DTG
0
3
0
12
2
1 2
18 0
0
13
2
1 5
18 0
0
14
2
1 6
18 0
end_DTG
begin_DTG
0
12
0
108
2
1 0
3 0
0
111
2
1 0
2 0
0
132
2
1 1
3 0
0
135
2
1 1
2 0
0
150
2
1 2
3 0
0
153
2
1 2
2 0
0
192
2
1 4
3 0
0
195
2
1 4
2 0
0
210
2
1 5
3 0
0
213
2
1 5
2 0
0
228
2
1 6
3 0
0
231
2
1 6
2 0
end_DTG
begin_DTG
0
3
0
9
2
1 2
20 0
0
10
2
1 5
20 0
0
11
2
1 6
20 0
end_DTG
begin_DTG
1
1
106
2
1 1
27 0
0
end_DTG
begin_DTG
1
1
107
2
1 5
27 0
0
end_DTG
begin_DTG
2
1
98
2
1 2
27 0
2
102
2
0 2
28 0
0
0
end_DTG
begin_DTG
2
1
99
2
1 3
27 0
2
103
2
0 3
28 0
0
0
end_DTG
begin_DTG
2
1
100
2
1 5
27 0
2
104
2
0 5
28 0
0
0
end_DTG
begin_DTG
6
1
98
2
1 2
24 0
1
99
2
1 3
25 0
1
100
2
1 5
26 0
1
101
2
1 6
29 0
1
106
2
1 1
22 0
1
107
2
1 5
23 0
1
0
60
0
end_DTG
begin_DTG
4
1
102
2
0 2
24 0
1
103
2
0 3
25 0
1
104
2
0 5
26 0
1
105
2
0 6
29 0
1
0
61
0
end_DTG
begin_DTG
2
1
101
2
1 6
27 0
2
105
2
0 6
28 0
0
0
end_DTG
begin_DTG
0
3
0
57
2
1 2
23 1
0
58
2
1 5
23 1
0
59
2
1 6
23 1
end_DTG
begin_DTG
0
3
0
54
2
1 2
22 1
0
55
2
1 5
22 1
0
56
2
1 6
22 1
end_DTG
begin_DTG
0
6
0
42
2
1 2
29 1
0
43
2
1 5
29 1
0
44
2
1 6
29 1
0
51
2
0 2
29 2
0
52
2
0 5
29 2
0
53
2
0 6
29 2
end_DTG
begin_DTG
0
6
0
39
2
1 2
26 1
0
40
2
1 5
26 1
0
41
2
1 6
26 1
0
48
2
0 2
26 2
0
49
2
0 5
26 2
0
50
2
0 6
26 2
end_DTG
begin_DTG
0
6
0
36
2
1 2
24 1
0
37
2
1 5
24 1
0
38
2
1 6
24 1
0
45
2
0 2
24 2
0
46
2
0 5
24 2
0
47
2
0 6
24 2
end_DTG
begin_CG
8
24 1
25 1
26 1
29 1
34 3
33 3
32 3
28 4
32
24 1
25 1
26 1
29 1
22 1
23 1
3 78
2 75
21 3
19 3
17 3
15 3
13 3
11 3
9 3
7 3
5 3
34 3
33 3
32 3
31 3
30 3
27 6
20 12
18 12
16 12
14 12
12 12
10 4
8 4
6 14
4 14
9
20 6
18 6
16 6
14 6
12 6
10 2
8 2
6 7
4 7
9
20 6
18 6
16 6
14 6
12 6
10 2
8 2
6 7
4 7
1
5 3
0
1
7 3
0
1
9 3
0
1
11 3
0
1
13 3
0
1
15 3
0
1
17 3
0
1
19 3
0
1
21 3
0
2
31 3
27 1
2
30 3
27 1
3
34 6
27 1
28 1
2
27 1
28 1
3
33 6
27 1
28 1
6
24 1
25 1
26 1
29 1
22 1
23 1
4
24 1
25 1
26 1
29 1
3
32 6
27 1
28 1
0
0
0
0
0
end_CG
