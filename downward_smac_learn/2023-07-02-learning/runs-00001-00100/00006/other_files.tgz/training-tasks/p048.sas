begin_version
3
end_version
begin_metric
0
end_metric
36
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var51
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var50
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var44
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var42
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var41
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
end_variable
begin_variable
var9
-1
2
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var35
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var36
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var34
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var33
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var32
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var31
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var30
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var29
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var28
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var27
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
6
6
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
end_state
begin_goal
15
4 0
6 0
9 0
11 0
13 0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 0
check 0
check 0
check 1
64
switch 24
check 0
switch 26
check 0
check 1
135
check 0
check 0
check 0
check 1
68
switch 27
check 0
check 0
check 0
check 1
72
check 0
switch 21
check 1
122
check 0
check 0
check 1
57
switch 22
check 0
check 0
check 0
check 1
61
switch 23
check 0
check 0
check 0
check 1
65
switch 24
check 0
check 0
check 0
check 1
69
switch 27
check 0
switch 26
check 0
check 1
136
check 0
check 0
check 0
check 1
73
check 0
switch 21
check 4
123
124
125
126
check 0
check 0
check 1
58
switch 22
check 0
check 0
check 0
check 1
62
switch 23
check 0
check 0
check 0
check 1
66
switch 24
check 0
check 0
check 0
check 1
70
switch 27
check 0
check 0
check 0
check 1
74
check 0
switch 25
check 0
check 0
check 1
87
switch 26
check 0
check 0
check 1
88
check 0
end_SG
begin_DTG
4
1
107
0
2
108
0
4
109
0
6
110
0
3
0
111
0
2
112
0
4
113
0
3
0
114
0
1
115
0
3
116
0
2
2
117
0
6
118
0
3
0
119
0
1
120
0
6
121
0
1
6
122
0
4
0
123
0
3
124
0
4
125
0
5
126
0
end_DTG
begin_DTG
1
4
89
0
2
2
90
0
4
91
0
3
1
92
0
3
93
0
4
94
0
2
2
95
0
6
96
0
5
0
97
0
1
98
0
2
99
0
5
100
0
6
101
0
2
4
102
0
6
103
0
3
3
104
0
4
105
0
5
106
0
end_DTG
begin_DTG
7
1
211
1
1 5
1
190
1
1 3
1
198
1
1 4
1
226
1
1 6
1
166
1
1 2
1
143
1
1 0
1
158
1
1 1
2
0
5
1
1 3
0
6
1
1 5
end_DTG
begin_DTG
0
5
0
150
2
1 0
2 0
0
158
2
1 1
2 0
0
174
2
1 2
2 0
0
202
2
1 4
2 0
0
218
2
1 5
2 0
end_DTG
begin_DTG
0
4
0
23
2
1 2
3 0
0
24
2
1 4
3 0
0
25
2
1 5
3 0
0
26
2
1 6
3 0
end_DTG
begin_DTG
0
2
0
190
2
1 3
2 0
0
214
2
1 5
2 0
end_DTG
begin_DTG
0
4
0
15
2
1 2
5 0
0
16
2
1 4
5 0
0
17
2
1 5
5 0
0
18
2
1 6
5 0
end_DTG
begin_DTG
7
1
209
1
1 5
1
188
1
1 3
1
196
1
1 4
1
224
1
1 6
1
164
1
1 2
1
141
1
1 0
1
156
1
1 1
5
0
0
1
1 0
0
1
1
1 1
0
2
1
1 2
0
3
1
1 3
0
4
1
1 5
end_DTG
begin_DTG
0
5
0
153
2
1 0
7 0
0
161
2
1 1
7 0
0
177
2
1 2
7 0
0
193
2
1 3
7 0
0
221
2
1 5
7 0
end_DTG
begin_DTG
0
4
0
31
2
1 2
8 0
0
32
2
1 4
8 0
0
33
2
1 5
8 0
0
34
2
1 6
8 0
end_DTG
begin_DTG
0
10
0
152
2
1 0
7 0
0
155
2
1 0
2 0
0
160
2
1 1
7 0
0
163
2
1 1
2 0
0
176
2
1 2
7 0
0
179
2
1 2
2 0
0
192
2
1 3
7 0
0
195
2
1 3
2 0
0
220
2
1 5
7 0
0
223
2
1 5
2 0
end_DTG
begin_DTG
0
4
0
27
2
1 2
10 0
0
28
2
1 4
10 0
0
29
2
1 5
10 0
0
30
2
1 6
10 0
end_DTG
begin_DTG
0
4
0
188
2
1 3
7 0
0
191
2
1 3
2 0
0
212
2
1 5
7 0
0
215
2
1 5
2 0
end_DTG
begin_DTG
0
4
0
19
2
1 2
12 0
0
20
2
1 4
12 0
0
21
2
1 5
12 0
0
22
2
1 6
12 0
end_DTG
begin_DTG
0
6
0
145
2
1 0
7 0
0
169
2
1 2
7 0
0
185
2
1 3
7 0
0
197
2
1 4
7 0
0
209
2
1 5
7 0
0
229
2
1 6
7 0
end_DTG
begin_DTG
0
4
0
11
2
1 2
14 0
0
12
2
1 4
14 0
0
13
2
1 5
14 0
0
14
2
1 6
14 0
end_DTG
begin_DTG
0
12
0
144
2
1 0
7 0
0
147
2
1 0
2 0
0
168
2
1 2
7 0
0
171
2
1 2
2 0
0
184
2
1 3
7 0
0
187
2
1 3
2 0
0
196
2
1 4
7 0
0
199
2
1 4
2 0
0
208
2
1 5
7 0
0
211
2
1 5
2 0
0
228
2
1 6
7 0
0
231
2
1 6
2 0
end_DTG
begin_DTG
0
4
0
7
2
1 2
16 0
0
8
2
1 4
16 0
0
9
2
1 5
16 0
0
10
2
1 6
16 0
end_DTG
begin_DTG
1
1
137
2
1 0
25 0
0
end_DTG
begin_DTG
1
1
138
2
1 3
25 0
0
end_DTG
begin_DTG
1
1
139
2
1 5
25 0
0
end_DTG
begin_DTG
2
1
127
2
1 0
25 0
2
132
2
0 0
26 0
0
0
end_DTG
begin_DTG
2
1
128
2
1 1
25 0
2
133
2
0 1
26 0
0
0
end_DTG
begin_DTG
2
1
129
2
1 2
25 0
2
134
2
0 2
26 0
0
0
end_DTG
begin_DTG
2
1
130
2
1 4
25 0
2
135
2
0 4
26 0
0
0
end_DTG
begin_DTG
8
1
127
2
1 0
21 0
1
128
2
1 1
22 0
1
129
2
1 2
23 0
1
130
2
1 4
24 0
1
131
2
1 5
27 0
1
137
2
1 0
18 0
1
138
2
1 3
19 0
1
139
2
1 5
20 0
1
0
87
0
end_DTG
begin_DTG
5
1
132
2
0 0
21 0
1
133
2
0 1
22 0
1
134
2
0 2
23 0
1
135
2
0 4
24 0
1
136
2
0 5
27 0
1
0
88
0
end_DTG
begin_DTG
2
1
131
2
1 5
25 0
2
136
2
0 5
26 0
0
0
end_DTG
begin_DTG
0
4
0
83
2
1 2
20 1
0
84
2
1 4
20 1
0
85
2
1 5
20 1
0
86
2
1 6
20 1
end_DTG
begin_DTG
0
4
0
79
2
1 2
19 1
0
80
2
1 4
19 1
0
81
2
1 5
19 1
0
82
2
1 6
19 1
end_DTG
begin_DTG
0
4
0
75
2
1 2
18 1
0
76
2
1 4
18 1
0
77
2
1 5
18 1
0
78
2
1 6
18 1
end_DTG
begin_DTG
0
8
0
51
2
1 2
27 1
0
52
2
1 4
27 1
0
53
2
1 5
27 1
0
54
2
1 6
27 1
0
71
2
0 2
27 2
0
72
2
0 4
27 2
0
73
2
0 5
27 2
0
74
2
0 6
27 2
end_DTG
begin_DTG
0
8
0
47
2
1 2
24 1
0
48
2
1 4
24 1
0
49
2
1 5
24 1
0
50
2
1 6
24 1
0
67
2
0 2
24 2
0
68
2
0 4
24 2
0
69
2
0 5
24 2
0
70
2
0 6
24 2
end_DTG
begin_DTG
0
8
0
43
2
1 2
23 1
0
44
2
1 4
23 1
0
45
2
1 5
23 1
0
46
2
1 6
23 1
0
63
2
0 2
23 2
0
64
2
0 4
23 2
0
65
2
0 5
23 2
0
66
2
0 6
23 2
end_DTG
begin_DTG
0
8
0
39
2
1 2
22 1
0
40
2
1 4
22 1
0
41
2
1 5
22 1
0
42
2
1 6
22 1
0
59
2
0 2
22 2
0
60
2
0 4
22 2
0
61
2
0 5
22 2
0
62
2
0 6
22 2
end_DTG
begin_DTG
0
8
0
35
2
1 2
21 1
0
36
2
1 4
21 1
0
37
2
1 5
21 1
0
38
2
1 6
21 1
0
55
2
0 2
21 2
0
56
2
0 4
21 2
0
57
2
0 5
21 2
0
58
2
0 6
21 2
end_DTG
begin_CG
11
21 1
22 1
23 1
24 1
27 1
35 4
34 4
33 4
32 4
31 4
26 5
33
21 1
22 1
23 1
24 1
27 1
18 1
19 1
20 1
7 51
2 48
17 4
15 4
6 4
13 4
4 4
11 4
9 4
35 4
34 4
33 4
32 4
31 4
30 4
29 4
28 4
25 8
16 12
14 6
5 2
12 4
3 5
10 10
8 5
5
16 6
5 2
12 2
3 5
10 5
1
4 4
0
1
6 4
0
5
16 6
14 6
12 2
10 5
8 5
1
9 4
0
1
11 4
0
1
13 4
0
1
15 4
0
1
17 4
0
2
30 4
25 1
2
29 4
25 1
2
28 4
25 1
3
35 8
25 1
26 1
3
34 8
25 1
26 1
3
33 8
25 1
26 1
3
32 8
25 1
26 1
8
21 1
22 1
23 1
24 1
27 1
18 1
19 1
20 1
5
21 1
22 1
23 1
24 1
27 1
3
31 8
25 1
26 1
0
0
0
0
0
0
0
0
end_CG
