begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var0
-1
4
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var17
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var16
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var11
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
1
0
0
0
0
0
0
0
1
1
end_state
begin_goal
2
8 0
9 0
end_goal
23
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint1 waypoint3
2
0 0
1 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint2 waypoint3
2
0 1
1 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint4 waypoint3
2
0 3
1 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint1 waypoint3
2
0 0
6 1
1
0 8 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint2 waypoint3
2
0 1
6 1
1
0 8 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint4 waypoint3
2
0 3
6 1
1
0 8 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 7 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 0 0 1
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 0 0 2
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint4
0
1
0 0 0 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint1
0
1
0 0 1 0
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint4
0
1
0 0 1 3
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint1
0
1
0 0 2 0
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint4
0
1
0 0 2 3
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint1
0
1
0 0 3 0
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint2
0
1
0 0 3 1
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint3
0
1
0 0 3 2
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
0 0
2
0 1 0 1
0 7 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint2
1
0 1
2
0 2 0 1
0 7 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint3
1
0 2
2
0 3 0 1
0 7 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint1
1
0 0
2
0 4 0 1
0 7 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint2
1
0 1
2
0 5 0 1
0 7 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
0 2
2
0 6 0 1
0 7 0 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 1
check 3
7
8
9
switch 7
check 0
check 1
17
check 0
check 0
check 1
0
switch 4
check 0
switch 7
check 0
check 1
20
check 0
check 0
check 0
switch 6
check 0
check 0
check 1
3
check 0
switch 1
check 2
10
11
check 0
check 1
1
switch 2
check 0
switch 7
check 0
check 1
18
check 0
check 0
check 0
switch 5
check 0
switch 7
check 0
check 1
21
check 0
check 0
check 0
switch 6
check 0
check 0
check 1
4
check 0
switch 1
check 2
12
13
check 0
check 0
switch 3
check 0
switch 7
check 0
check 1
19
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 1
22
check 0
check 0
check 0
check 0
switch 1
check 3
14
15
16
check 0
check 1
2
switch 6
check 0
check 0
check 1
5
check 0
switch 7
check 0
check 0
check 1
6
check 0
end_SG
begin_DTG
3
1
7
0
2
8
0
3
9
0
2
0
10
0
3
11
0
2
0
12
0
3
13
0
3
0
14
0
1
15
0
2
16
0
end_DTG
begin_DTG
1
1
17
2
0 0
7 0
0
end_DTG
begin_DTG
1
1
18
2
0 1
7 0
0
end_DTG
begin_DTG
1
1
19
2
0 2
7 0
0
end_DTG
begin_DTG
1
1
20
2
0 0
7 0
0
end_DTG
begin_DTG
1
1
21
2
0 1
7 0
0
end_DTG
begin_DTG
1
1
22
2
0 2
7 0
0
end_DTG
begin_DTG
6
1
17
2
0 0
1 0
1
18
2
0 1
2 0
1
19
2
0 2
3 0
1
20
2
0 0
4 0
1
21
2
0 1
5 0
1
22
2
0 2
6 0
1
0
6
0
end_DTG
begin_DTG
0
3
0
3
2
0 0
6 1
0
4
2
0 1
6 1
0
5
2
0 3
6 1
end_DTG
begin_DTG
0
3
0
0
2
0 0
1 1
0
1
2
0 1
1 1
0
2
2
0 3
1 1
end_DTG
begin_CG
9
1 1
2 1
3 1
4 1
5 1
6 1
9 3
8 3
7 6
2
9 3
7 1
1
7 1
1
7 1
1
7 1
1
7 1
2
8 3
7 1
6
1 1
2 1
3 1
4 1
5 1
6 1
0
0
end_CG
