begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var0
-1
3
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
end_variable
begin_variable
var3
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var12
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var6
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var10
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var4
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var2
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var9
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var8
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var7
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
1
1
1
1
1
1
0
0
0
1
1
end_state
begin_goal
4
3 0
5 0
9 0
10 0
end_goal
19
begin_operator
calibrate rover1 camera1 objective1 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint1 waypoint3
2
0 0
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint2 waypoint3
2
0 1
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint1 waypoint3
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint2 waypoint3
2
0 1
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint1 waypoint3
2
0 0
6 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint2 waypoint3
2
0 1
6 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint1 waypoint3
2
0 0
7 1
1
0 9 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint2 waypoint3
2
0 1
7 1
1
0 9 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 8 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 0 0 2
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint3
0
1
0 0 1 2
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint1
0
1
0 0 2 0
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint2
0
1
0 0 2 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
0 0
2
0 6 0 1
0 8 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
0 2
2
0 7 0 1
0 8 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 colour
1
0 2
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 high_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
2
0 1 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 6
check 1
10
switch 8
check 0
check 1
14
check 0
check 0
check 1
5
switch 7
check 0
check 0
check 1
7
switch 4
check 0
check 1
1
check 0
switch 2
check 0
check 1
3
check 0
check 0
switch 6
check 1
11
check 0
check 1
6
switch 7
check 0
check 0
check 1
8
switch 4
check 0
check 1
2
check 0
switch 2
check 0
check 1
4
check 0
check 0
switch 6
check 3
0
12
13
check 0
check 0
switch 7
check 0
switch 8
check 0
check 1
15
check 0
check 0
check 0
switch 1
check 0
check 3
16
17
18
check 0
check 0
switch 8
check 0
check 0
check 1
9
check 0
end_SG
begin_DTG
1
2
10
0
1
2
11
0
2
0
12
0
1
13
0
end_DTG
begin_DTG
1
1
16
1
0 2
1
0
0
1
0 2
end_DTG
begin_DTG
0
1
0
18
2
0 2
1 0
end_DTG
begin_DTG
0
2
0
3
2
0 0
2 0
0
4
2
0 1
2 0
end_DTG
begin_DTG
0
1
0
16
2
0 2
1 0
end_DTG
begin_DTG
0
2
0
1
2
0 0
4 0
0
2
2
0 1
4 0
end_DTG
begin_DTG
1
1
14
2
0 0
8 0
0
end_DTG
begin_DTG
1
1
15
2
0 2
8 0
0
end_DTG
begin_DTG
2
1
14
2
0 0
6 0
1
15
2
0 2
7 0
1
0
9
0
end_DTG
begin_DTG
0
2
0
7
2
0 0
7 1
0
8
2
0 1
7 1
end_DTG
begin_DTG
0
2
0
5
2
0 0
6 1
0
6
2
0 1
6 1
end_DTG
begin_CG
10
6 1
7 1
1 4
5 2
3 2
10 2
9 2
8 2
4 1
2 1
2
4 1
2 1
1
3 2
0
1
5 2
0
2
10 2
8 1
2
9 2
8 1
2
6 1
7 1
0
0
end_CG
