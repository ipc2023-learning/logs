begin_version
3
end_version
begin_metric
0
end_metric
68
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var95
-1
2
Atom have_image(rover3, objective7, low_res)
NegatedAtom have_image(rover3, objective7, low_res)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var93
-1
2
Atom have_image(rover3, objective7, colour)
NegatedAtom have_image(rover3, objective7, colour)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var35
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var91
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var90
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover3, objective5, low_res)
NegatedAtom have_image(rover3, objective5, low_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var85
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover3, objective4, colour)
NegatedAtom have_image(rover3, objective4, colour)
end_variable
begin_variable
var83
-1
2
Atom have_image(rover3, objective3, low_res)
NegatedAtom have_image(rover3, objective3, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover3, objective3, colour)
NegatedAtom have_image(rover3, objective3, colour)
end_variable
begin_variable
var80
-1
2
Atom have_image(rover3, objective2, low_res)
NegatedAtom have_image(rover3, objective2, low_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var79
-1
2
Atom have_image(rover3, objective2, high_res)
NegatedAtom have_image(rover3, objective2, high_res)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover3, objective1, colour)
NegatedAtom have_image(rover3, objective1, colour)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var73
-1
2
Atom have_image(rover2, objective6, high_res)
NegatedAtom have_image(rover2, objective6, high_res)
end_variable
begin_variable
var71
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var69
-1
2
Atom have_image(rover2, objective2, high_res)
NegatedAtom have_image(rover2, objective2, high_res)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective7, colour)
NegatedAtom have_image(rover1, objective7, colour)
end_variable
begin_variable
var36
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var65
-1
2
Atom have_image(rover1, objective6, high_res)
NegatedAtom have_image(rover1, objective6, high_res)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective6, high_res)





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




egin_DTG
0
3
0
216
2
29 0
30 0
0
230
2
29 2
30 0
0
248
2
29 4
30 0
end_DTG
begin_DTG
0
9
0
31
2
29 0
33 0
0
32
2
29 2
33 0
0
33
2
29 5
33 0
0
43
2
24 0
26 0
0
44
2
24 2
26 0
0
45
2
24 5
26 0
0
79
2
0 0
7 0
0
80
2
0 2
7 0
0
81
2
0 5
7 0
end_DTG
begin_DTG
0
3
0
215
2
29 0
30 0
0
229
2
29 2
30 0
0
247
2
29 4
30 0
end_DTG
begin_DTG
0
6
0
28
2
29 0
35 0
0
29
2
29 2
35 0
0
30
2
29 5
35 0
0
76
2
0 0
8 0
0
77
2
0 2
8 0
0
78
2
0 5
8 0
end_DTG
begin_DTG
0
7
0
214
2
29 0
30 0
0
226
2
29 2
30 0
0
234
2
29 3
30 0
0
244
2
29 4
30 0
0
252
2
29 5
30 0
0
260
2
29 6
30 0
0
268
2
29 7
30 0
end_DTG
begin_DTG
0
9
0
25
2
29 0
37 0
0
26
2
29 2
37 0
0
27
2
29 5
37 0
0
40
2
24 0
27 0
0
41
2
24 2
27 0
0
42
2
24 5
27 0
0
67
2
0 0
13 0
0
68
2
0 2
13 0
0
69
2
0 5
13 0
end_DTG
begin_DTG
0
7
0
213
2
29 0
30 0
0
225
2
29 2
30 0
0
233
2
29 3
30 0
0
243
2
29 4
30 0
0
251
2
29 5
30 0
0
259
2
29 6
30 0
0
267
2
29 7
30 0
end_DTG
begin_DTG
0
6
0
22
2
29 0
39 0
0
23
2
29 2
39 0
0
24
2
29 5
39 0
0
64
2
0 0
14 0
0
65
2
0 2
14 0
0
66
2
0 5
14 0
end_DTG
begin_DTG
0
1
0
265
2
29 7
30 0
end_DTG
begin_DTG
0
6
0
19
2
29 0
41 0
0
20
2
29 2
41 0
0
21
2
29 5
41 0
0
58
2
0 0
17 0
0
59
2
0 2
17 0
0
60
2
0 5
17 0
end_DTG
begin_DTG
0
3
0
220
2
29 1
30 0
0
242
2
29 4
30 0
0
258
2
29 6
30 0
end_DTG
begin_DTG
0
9
0
16
2
29 0
43 0
0
17
2
29 2
43 0
0
18
2
29 5
43 0
0
37
2
24 0
28 0
0
38
2
24 2
28 0
0
39
2
24 5
28 0
0
52
2
0 0
20 0
0
53
2
0 2
20 0
0
54
2
0 5
20 0
end_DTG
begin_DTG
0
1
0
239
2
29 4
30 0
end_DTG
begin_DTG
0
6
0
13
2
29 0
45 0
0
14
2
29 2
45 0
0
15
2
29 5
45 0
0
46
2
0 0
23 0
0
47
2
0 2
23 0
0
48
2
0 5
23 0
end_DTG
begin_DTG
2
1
183
2
29 2
57 0
2
189
2
24 2
58 0
0
0
end_DTG
begin_DTG
2
1
184
2
29 3
57 0
2
190
2
24 3
58 0
0
0
end_DTG
begin_DTG
2
1
185
2
29 4
57 0
2
191
2
24 4
58 0
0
0
end_DTG
begin_DTG
2
1
186
2
29 5
57 0
2
192
2
24 5
58 0
0
0
end_DTG
begin_DTG
2
1
187
2
29 6
57 0
2
193
2
24 6
58 0
0
0
end_DTG
begin_DTG
2
1
188
2
29 7
57 0
2
194
2
24 7
58 0
0
0
end_DTG
begin_DTG
3
1
195
2
29 1
57 0
2
201
2
24 1
58 0
3
207
2
0 1
61 0
0
0
0
end_DTG
begin_DTG
3
1
196
2
29 2
57 0
2
202
2
24 2
58 0
3
208
2
0 2
61 0
0
0
0
end_DTG
begin_DTG
3
1
197
2
29 3
57 0
2
203
2
24 3
58 0
3
209
2
0 3
61 0
0
0
0
end_DTG
begin_DTG
3
1
198
2
29 4
57 0
2
204
2
24 4
58 0
3
210
2
0 4
61 0
0
0
0
end_DTG
begin_DTG
12
1
183
2
29 2
47 0
1
184
2
29 3
48 0
1
185
2
29 4
49 0
1
186
2
29 5
50 0
1
187
2
29 6
51 0
1
188
2
29 7
52 0
1
195
2
29 1
53 0
1
196
2
29 2
54 0
1
197
2
29 3
55 0
1
198
2
29 4
56 0
1
199
2
29 6
59 0
1
200
2
29 7
60 0
1
0
130
0
end_DTG
begin_DTG
12
1
189
2
24 2
47 0
1
190
2
24 3
48 0
1
191
2
24 4
49 0
1
192
2
24 5
50 0
1
193
2
24 6
51 0
1
194
2
24 7
52 0
1
201
2
24 1
53 0
1
202
2
24 2
54 0
1
203
2
24 3
55 0
1
204
2
24 4
56 0
1
205
2
24 6
59 0
1
206
2
24 7
60 0
1
0
131
0
end_DTG
begin_DTG
3
1
199
2
29 6
57 0
2
205
2
24 6
58 0
3
211
2
0 6
61 0
0
0
0
end_DTG
begin_DTG
3
1
200
2
29 7
57 0
2
206
2
24 7
58 0
3
212
2
0 7
61 0
0
0
0
end_DTG
begin_DTG
6
1
207
2
0 1
53 0
1
208
2
0 2
54 0
1
209
2
0 3
55 0
1
210
2
0 4
56 0
1
211
2
0 6
59 0
1
212
2
0 7
60 0
1
0
132
0
end_DTG
begin_DTG
0
9
0
121
2
29 0
53 1
0
122
2
29 2
53 1
0
123
2
29 5
53 1
0
124
2
24 0
53 2
0
125
2
24 2
53 2
0
126
2
24 5
53 2
0
127
2
0 0
53 3
0
128
2
0 2
53 3
0
129
2
0 5
53 3
end_DTG
begin_DTG
0
6
0
103
2
29 0
52 1
0
104
2
29 2
52 1
0
105
2
29 5
52 1
0
118
2
24 0
52 2
0
119
2
24 2
52 2
0
120
2
24 5
52 2
end_DTG
begin_DTG
0
6
0
100
2
29 0
51 1
0
101
2
29 2
51 1
0
102
2
29 5
51 1
0
115
2
24 0
51 2
0
116
2
24 2
51 2
0
117
2
24 5
51 2
end_DTG
begin_DTG
0
6
0
97
2
29 0
49 1
0
98
2
29 2
49 1
0
99
2
29 5
49 1
0
112
2
24 0
49 2
0
113
2
24 2
49 2
0
114
2
24 5
49 2
end_DTG
begin_DTG
0
6
0
94
2
29 0
48 1
0
95
2
29 2
48 1
0
96
2
29 5
48 1
0
109
2
24 0
48 2
0
110
2
24 2
48 2
0
111
2
24 5
48 2
end_DTG
begin_DTG
0
6
0
91
2
29 0
47 1
0
92
2
29 2
47 1
0
93
2
29 5
47 1
0
106
2
24 0
47 2
0
107
2
24 2
47 2
0
108
2
24 5
47 2
end_DTG
begin_CG
39
53 1
54 1
55 1
56 1
59 1
60 1
1 94
46 3
22 3
44 3
19 3
42 3
16 3
40 3
38 3
12 3
10 3
36 3
34 3
6 3
32 3
3 3
62 3
61 6
23 1
21 1
20 3
18 3
17 1
15 1
14 7
13 7
11 7
9 6
8 3
7 3
5 3
4 8
2 8
15
23 1
21 1
20 3
18 3
17 1
15 1
14 7
13 7
11 7
9 6
8 3
7 3
5 3
4 8
2 8
1
3 3
0
1
32 3
1
6 3
0
1
34 3
1
36 3
1
10 3
0
1
12 3
0
1
38 3
1
40 3
1
16 3
0
1
42 3
1
19 3
0
1
44 3
1
22 3
0
1
46 3
26
47 1
48 1
49 1
50 1
51 1
52 1
53 1
54 1
55 1
56 1
59 1
60 1
25 32
44 3
38 3
34 3
67 3
66 3
65 3
64 3
63 3
62 3
58 12
28 3
27 7
26 3
3
28 3
27 7
26 3
1
34 3
1
38 3
1
44 3
36
47 1
48 1
49 1
50 1
51 1
52 1
53 1
54 1
55 1
56 1
59 1
60 1
30 61
46 3
44 3
42 3
40 3
38 3
36 3
34 3
32 3
67 3
66 3
65 3
64 3
63 3
62 3
57 12
45 1
43 3
41 1
39 7
37 7
35 3
33 3
31 8
8
45 1
43 3
41 1
39 7
37 7
35 3
33 3
31 8
1
32 3
0
1
34 3
0
1
36 3
0
1
38 3
0
1
40 3
0
1
42 3
0
1
44 3
0
1
46 3
0
3
67 6
57 1
58 1
3
66 6
57 1
58 1
3
65 6
57 1
58 1
2
57 1
58 1
3
64 6
57 1
58 1
3
63 6
57 1
58 1
4
62 9
57 1
58 1
61 1
3
57 1
58 1
61 1
3
57 1
58 1
61 1
3
57 1
58 1
61 1
12
47 1
48 1
49 1
50 1
51 1
52 1
53 1
54 1
55 1
56 1
59 1
60 1
12
47 1
48 1
49 1
50 1
51 1
52 1
53 1
54 1
55 1
56 1
59 1
60 1
3
57 1
58 1
61 1
3
57 1
58 1
61 1
6
53 1
54 1
55 1
56 1
59 1
60 1
0
0
0
0
0
0
end_CG
