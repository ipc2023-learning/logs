begin_version
3
end_version
begin_metric
0
end_metric
36
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover2, objective4, colour)
NegatedAtom have_image(rover2, objective4, colour)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var44
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var38
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var37
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var34
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var30
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
end_variable
begin_variable
var28
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var26
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var25
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var23
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var22
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
0
1
1
1
1
1
1
4
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
12
10 0
12 0
14 0
16 0
18 0
20 0
22 0
24 0
32 0
33 0
34 0
35 0
end_goal
234
begin_operator
calibrate rover1 camera2 objective3 waypoint1
1
7 0
1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
switch 3
check 0
check 1
65
check 0
switch 2
check 0
check 1
70
check 0
check 0
switch 25
check 5
6
119
120
121
122
check 0
check 0
switch 1
check 0
check 6
216
217
218
219
220
221
check 0
switch 6
check 0
check 1
51
check 0
switch 5
check 0
check 1
56
check 0
switch 4
check 0
check 1
61
check 0
switch 3
check 0
check 1
66
check 0
switch 2
check 0
check 1
71
check 0
check 0
switch 25
check 4
123
124
125
126
check 0
check 0
switch 1
check 0
check 6
222
223
224
225
226
227
check 0
check 0
switch 25
check 2
7
127
check 0
check 0
switch 1
check 0
check 6
228
229
230
231
232
233
check 0
switch 6
check 0
check 1
52
check 0
switch 5
check 0
check 1
57
check 0
switch 4
check 0
check 1
62
check 0
switch 3
check 0
check 1
67
check 0
switch 2
check 0
check 1
72
check 0
check 0
switch 31
check 0
check 0
check 1
93
check 0
end_SG
begin_DTG
2
3
110
0
4
111
0
3
2
112
0
3
113
0
4
114
0
4
1
115
0
3
116
0
4
117
0
5
118
0
4
0
119
0
1
120
0
2
121
0
4
122
0
4
0
123
0
1
124
0
2
125
0
3
126
0
1
2
127
0
end_DTG
begin_DTG
6
1
224
1
0 4
1
215
1
0 2
1
216
1
0 3
1
228
1
0 5
1
204
1
0 1
1
195
1
0 0
5
0
3
1
0 0
0
4
1
0 1
0
5
1
0 2
0
6
1
0 3
0
7
1
0 5
end_DTG
begin_DTG
0
6
0
201
2
0 0
1 0
0
209
2
0 1
1 0
0
215
2
0 2
1 0
0
221
2
0 3
1 0
0
227
2
0 4
1 0
0
233
2
0 5
1 0
end_DTG
begin_DTG
0
6
0
200
2
0 0
1 0
0
208
2
0 1
1 0
0
214
2
0 2
1 0
0
220
2
0 3
1 0
0
226
2
0 4
1 0
0
232
2
0 5
1 0
end_DTG
begin_DTG
0
3
0
199
2
0 0
1 0
0
207
2
0 1
1 0
0
225
2
0 4
1 0
end_DTG
begin_DTG
0
3
0
198
2
0 0
1 0
0
206
2
0 1
1 0
0
224
2
0 4
1 0
end_DTG
begin_DTG
0
5
0
197
2
0 0
1 0
0
205
2
0 1
1 0
0
213
2
0 2
1 0
0
219
2
0 3
1 0
0
231
2
0 5
1 0
end_DTG
begin_DTG
3
2
94
0
3
95
0
4
96
0
1
4
97
0
4
0
98
0
3
99
0
4
100
0
5
101
0
3
0
102
0
2
103
0
4
104
0
4
0
105
0
1
106
0
2
107
0
3
108
0
1
2
109
0
end_DTG
begin_DTG
6
1
179
1
7 4
1
165
1
7 2
1
167
1
7 3
1
185
1
7 5
1
149
1
7 1
1
135
1
7 0
3
0
0
1
7 0
0
1
1
7 1
0
2
1
7 4
end_DTG
begin_DTG
0
6
0
145
2
7 0
8 0
0
157
2
7 1
8 0
0
166
2
7 2
8 0
0
175
2
7 3
8 0
0
184
2
7 4
8 0
0
193
2
7 5
8 0
end_DTG
begin_DTG
0
10
0
43
2
7 0
9 0
0
44
2
7 1
9 0
0
45
2
7 2
9 0
0
46
2
7 3
9 0
0
47
2
7 5
9 0
0
68
2
0 0
2 0
0
69
2
0 1
2 0
0
70
2
0 2
2 0
0
71
2
0 3
2 0
0
72
2
0 5
2 0
end_DTG
begin_DTG
0
6
0
143
2
7 0
8 0
0
155
2
7 1
8 0
0
164
2
7 2
8 0
0
173
2
7 3
8 0
0
182
2
7 4
8 0
0
191
2
7 5
8 0
end_DTG
begin_DTG
0
10
0
38
2
7 0
11 0
0
39
2
7 1
11 0
0
40
2
7 2
11 0
0
41
2
7 3
11 0
0
42
2
7 5
11 0
0
63
2
0 0
3 0
0
64
2
0 1
3 0
0
65
2
0 2
3 0
0
66
2
0 3
3 0
0
67
2
0 5
3 0
end_DTG
begin_DTG
0
3
0
142
2
7 0
8 0
0
154
2
7 1
8 0
0
181
2
7 4
8 0
end_DTG
begin_DTG
0
10
0
33
2
7 0
13 0
0
34
2
7 1
13 0
0
35
2
7 2
13 0
0
36
2
7 3
13 0
0
37
2
7 5
13 0
0
58
2
0 0
4 0
0
59
2
0 1
4 0
0
60
2
0 2
4 0
0
61
2
0 3
4 0
0
62
2
0 5
4 0
end_DTG
begin_DTG
0
3
0
141
2
7 0
8 0
0
153
2
7 1
8 0
0
180
2
7 4
8 0
end_DTG
begin_DTG
0
5
0
28
2
7 0
15 0
0
29
2
7 1
15 0
0
30
2
7 2
15 0
0
31
2
7 3
15 0
0
32
2
7 5
15 0
end_DTG
begin_DTG
0
3
0
140
2
7 0
8 0
0
152
2
7 1
8 0
0
179
2
7 4
8 0
end_DTG
begin_DTG
0
10
0
23
2
7 0
17 0
0
24
2
7 1
17 0
0
25
2
7 2
17 0
0
26
2
7 3
17 0
0
27
2
7 5
17 0
0
53
2
0 0
5 0
0
54
2
0 1
5 0
0
55
2
0 2
5 0
0
56
2
0 3
5 0
0
57
2
0 5
5 0
end_DTG
begin_DTG
0
5
0
139
2
7 0
8 0
0
151
2
7 1
8 0
0
163
2
7 2
8 0
0
172
2
7 3
8 0
0
190
2
7 5
8 0
end_DTG
begin_DTG
0
10
0
18
2
7 0
19 0
0
19
2
7 1
19 0
0
20
2
7 2
19 0
0
21
2
7 3
19 0
0
22
2
7 5
19 0
0
48
2
0 0
6 0
0
49
2
0 1
6 0
0
50
2
0 2
6 0
0
51
2
0 3
6 0
0
52
2
0 5
6 0
end_DTG
begin_DTG
0
5
0
138
2
7 0
8 0
0
150
2
7 1
8 0
0
162
2
7 2
8 0
0
171
2
7 3
8 0
0
189
2
7 5
8 0
end_DTG
begin_DTG
0
5
0
13
2
7 0
21 0
0
14
2
7 1
21 0
0
15
2
7 2
21 0
0
16
2
7 3
21 0
0
17
2
7 5
21 0
end_DTG
begin_DTG
0
6
0
135
2
7 0
8 0
0
147
2
7 1
8 0
0
159
2
7 2
8 0
0
168
2
7 3
8 0
0
177
2
7 4
8 0
0
186
2
7 5
8 0
end_DTG
begin_DTG
0
5
0
8
2
7 0
23 0
0
9
2
7 1
23 0
0
10
2
7 2
23 0
0
11
2
7 3
23 0
0
12
2
7 5
23 0
end_DTG
begin_DTG
1
1
128
2
7 0
31 0
0
end_DTG
begin_DTG
1
1
129
2
7 5
31 0
0
end_DTG
begin_DTG
1
1
130
2
7 2
31 0
0
end_DTG
begin_DTG
1
1
131
2
7 3
31 0
0
end_DTG
begin_DTG
1
1
132
2
7 4
31 0
0
end_DTG
begin_DTG
1
1
133
2
7 5
31 0
0
end_DTG
begin_DTG
6
1
128
2
7 0
25 0
1
129
2
7 5
26 0
1
130
2
7 2
27 0
1
131
2
7 3
28 0
1
132
2
7 4
29 0
1
133
2
7 5
30 0
1
0
93
0
end_DTG
begin_DTG
0
5
0
88
2
7 0
29 1
0
89
2
7 1
29 1
0
90
2
7 2
29 1
0
91
2
7 3
29 1
0
92
2
7 5
29 1
end_DTG
begin_DTG
0
5
0
83
2
7 0
28 1
0
84
2
7 1
28 1
0
85
2
7 2
28 1
0
86
2
7 3
28 1
0
87
2
7 5
28 1
end_DTG
begin_DTG
0
5
0
78
2
7 0
26 1
0
79
2
7 1
26 1
0
80
2
7 2
26 1
0
81
2
7 3
26 1
0
82
2
7 5
26 1
end_DTG
begin_DTG
0
5
0
73
2
7 0
25 1
0
74
2
7 1
25 1
0
75
2
7 2
25 1
0
76
2
7 3
25 1
0
77
2
7 5
25 1
end_DTG
begin_CG
11
1 45
20 5
18 5
14 5
12 5
10 5
6 5
5 3
4 3
3 6
2 6
5
6 5
5 3
4 3
3 6
2 6
1
10 5
1
12 5
1
14 5
1
18 5
1
20 5
28
25 1
26 1
27 1
28 1
29 1
30 1
8 63
24 5
22 5
20 5
18 5
16 5
14 5
12 5
10 5
35 5
34 5
33 5
32 5
31 6
23 6
21 5
19 5
17 3
15 3
13 3
11 6
9 6
8
23 6
21 5
19 5
17 3
15 3
13 3
11 6
9 6
1
10 5
0
1
12 5
0
1
14 5
0
1
16 5
0
1
18 5
0
1
20 5
0
1
22 5
0
1
24 5
0
2
35 5
31 1
2
34 5
31 1
1
31 1
2
33 5
31 1
2
32 5
31 1
1
31 1
6
25 1
26 1
27 1
28 1
29 1
30 1
0
0
0
0
end_CG
