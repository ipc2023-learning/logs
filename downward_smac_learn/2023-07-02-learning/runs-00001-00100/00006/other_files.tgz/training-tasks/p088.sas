begin_version
3
end_version
begin_metric
0
end_metric
77
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
10
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint10)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var0
-1
10
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint10)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var18
-1
2
Atom calibrated(camera4, rover1)
NegatedAtom calibrated(camera4, rover1)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var87
-1
2
Atom have_image(rover1, objective9, low_res)
NegatedAtom have_image(rover1, objective9, low_res)
end_variable
begin_variable
var45
-1
2
Atom communicated_image_data(objective9, low_res)
NegatedAtom communicated_image_data(objective9, low_res)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover1, objective9, high_res)
NegatedAtom have_image(rover1, objective9, high_res)
end_variable
begin_variable
var44
-1
2
Atom communicated_image_data(objective9, high_res)
NegatedAtom communicated_image_data(objective9, high_res)
end_variable
begin_variable
var85
-1
2
Atom have_image(rover1, objective9, colour)
NegatedAtom have_image(rover1, objective9, colour)
end_variable
begin_variable
var43
-1
2
Atom communicated_image_data(objective9, colour)
NegatedAtom communicated_image_data(objective9, colour)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover1, objective8, low_res)
NegatedAtom have_image(rover1, objective8, low_res)
end_variable
begin_variable
var42
-1
2
Atom communicated_image_data(objective8, low_res)
NegatedAtom communicated_image_data(objective8, low_res)
end_variable
begin_variable
var83
-1
2
Atom have_image(rover1, objective8, high_res)
NegatedAtom have_image(rover1, objective8, high_res)
end_variable
begin_variable
var41
-1
2
Atom communicated_image_data(objective8, high_res)
NegatedAtom communicated_image_data(objective8, high_res)
end_variable
begin_variable
var82
-1
2
Atom have_image(rover1, objective8, colour)
NegatedAtom have_image(rover1, objective8, colour)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var80
-1
2
Atom have_image(rover1, objective7, high_res)
NegatedAtom have_image(rover1, objective7, high_res)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var36
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover1, objective6, high_res)
NegatedAtom have_image(rover1, objective6, high_res)
end_variable
begin_variable
var35
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var33
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var73
-1
2
Atom have_image(rover1, objective5, colour)
NegatedAtom have_image(rover1, objective5, colour)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





65 0
3
599
2
0 5
68 0
0
0
0
end_DTG
begin_DTG
5
1
595
2
0 0
61 0
1
596
2
0 2
62 0
1
597
2
0 3
63 0
1
598
2
0 4
66 0
1
599
2
0 5
67 0
1
0
422
0
end_DTG
begin_DTG
0
27
0
369
2
1 5
67 2
0
418
2
0 9
67 3
0
417
2
0 8
67 3
0
416
2
0 7
67 3
0
415
2
0 6
67 3
0
414
2
0 5
67 3
0
413
2
0 4
67 3
0
412
2
0 3
67 3
0
411
2
0 2
67 3
0
410
2
0 1
67 3
0
373
2
1 9
67 2
0
372
2
1 8
67 2
0
371
2
1 7
67 2
0
370
2
1 6
67 2
0
320
2
2 1
67 1
0
368
2
1 4
67 2
0
367
2
1 3
67 2
0
366
2
1 2
67 2
0
365
2
1 1
67 2
0
328
2
2 9
67 1
0
327
2
2 8
67 1
0
326
2
2 7
67 1
0
325
2
2 6
67 1
0
324
2
2 5
67 1
0
323
2
2 4
67 1
0
322
2
2 3
67 1
0
321
2
2 2
67 1
end_DTG
begin_DTG
0
27
0
360
2
1 5
66 2
0
409
2
0 9
66 3
0
408
2
0 8
66 3
0
407
2
0 7
66 3
0
406
2
0 6
66 3
0
405
2
0 5
66 3
0
404
2
0 4
66 3
0
403
2
0 3
66 3
0
402
2
0 2
66 3
0
401
2
0 1
66 3
0
364
2
1 9
66 2
0
363
2
1 8
66 2
0
362
2
1 7
66 2
0
361
2
1 6
66 2
0
311
2
2 1
66 1
0
359
2
1 4
66 2
0
358
2
1 3
66 2
0
357
2
1 2
66 2
0
356
2
1 1
66 2
0
319
2
2 9
66 1
0
318
2
2 8
66 1
0
317
2
2 7
66 1
0
316
2
2 6
66 1
0
315
2
2 5
66 1
0
314
2
2 4
66 1
0
313
2
2 3
66 1
0
312
2
2 2
66 1
end_DTG
begin_DTG
0
27
0
351
2
1 5
63 2
0
400
2
0 9
63 3
0
399
2
0 8
63 3
0
398
2
0 7
63 3
0
397
2
0 6
63 3
0
396
2
0 5
63 3
0
395
2
0 4
63 3
0
394
2
0 3
63 3
0
393
2
0 2
63 3
0
392
2
0 1
63 3
0
355
2
1 9
63 2
0
354
2
1 8
63 2
0
353
2
1 7
63 2
0
352
2
1 6
63 2
0
302
2
2 1
63 1
0
350
2
1 4
63 2
0
349
2
1 3
63 2
0
348
2
1 2
63 2
0
347
2
1 1
63 2
0
310
2
2 9
63 1
0
309
2
2 8
63 1
0
308
2
2 7
63 1
0
307
2
2 6
63 1
0
306
2
2 5
63 1
0
305
2
2 4
63 1
0
304
2
2 3
63 1
0
303
2
2 2
63 1
end_DTG
begin_DTG
0
27
0
342
2
1 5
62 2
0
391
2
0 9
62 3
0
390
2
0 8
62 3
0
389
2
0 7
62 3
0
388
2
0 6
62 3
0
387
2
0 5
62 3
0
386
2
0 4
62 3
0
385
2
0 3
62 3
0
384
2
0 2
62 3
0
383
2
0 1
62 3
0
346
2
1 9
62 2
0
345
2
1 8
62 2
0
344
2
1 7
62 2
0
343
2
1 6
62 2
0
293
2
2 1
62 1
0
341
2
1 4
62 2
0
340
2
1 3
62 2
0
339
2
1 2
62 2
0
338
2
1 1
62 2
0
301
2
2 9
62 1
0
300
2
2 8
62 1
0
299
2
2 7
62 1
0
298
2
2 6
62 1
0
297
2
2 5
62 1
0
296
2
2 4
62 1
0
295
2
2 3
62 1
0
294
2
2 2
62 1
end_DTG
begin_DTG
0
27
0
333
2
1 5
61 2
0
382
2
0 9
61 3
0
381
2
0 8
61 3
0
380
2
0 7
61 3
0
379
2
0 6
61 3
0
378
2
0 5
61 3
0
377
2
0 4
61 3
0
376
2
0 3
61 3
0
375
2
0 2
61 3
0
374
2
0 1
61 3
0
337
2
1 9
61 2
0
336
2
1 8
61 2
0
335
2
1 7
61 2
0
334
2
1 6
61 2
0
284
2
2 1
61 1
0
332
2
1 4
61 2
0
331
2
1 3
61 2
0
330
2
1 2
61 2
0
329
2
1 1
61 2
0
292
2
2 9
61 1
0
291
2
2 8
61 1
0
290
2
2 7
61 1
0
289
2
2 6
61 1
0
288
2
2 5
61 1
0
287
2
2 4
61 1
0
286
2
2 3
61 1
0
285
2
2 2
61 1
end_DTG
begin_DTG
0
18
0
275
2
2 1
58 2
0
283
2
2 9
58 2
0
282
2
2 8
58 2
0
281
2
2 7
58 2
0
280
2
2 6
58 2
0
279
2
2 5
58 2
0
278
2
2 4
58 2
0
277
2
2 3
58 2
0
276
2
2 2
58 2
0
248
2
3 1
58 1
0
256
2
3 9
58 1
0
255
2
3 8
58 1
0
254
2
3 7
58 1
0
253
2
3 6
58 1
0
252
2
3 5
58 1
0
251
2
3 4
58 1
0
250
2
3 3
58 1
0
249
2
3 2
58 1
end_DTG
begin_DTG
0
18
0
266
2
2 1
56 2
0
274
2
2 9
56 2
0
273
2
2 8
56 2
0
272
2
2 7
56 2
0
271
2
2 6
56 2
0
270
2
2 5
56 2
0
269
2
2 4
56 2
0
268
2
2 3
56 2
0
267
2
2 2
56 2
0
239
2
3 1
56 1
0
247
2
3 9
56 1
0
246
2
3 8
56 1
0
245
2
3 7
56 1
0
244
2
3 6
56 1
0
243
2
3 5
56 1
0
242
2
3 4
56 1
0
241
2
3 3
56 1
0
240
2
3 2
56 1
end_DTG
begin_DTG
0
18
0
257
2
2 1
54 2
0
265
2
2 9
54 2
0
264
2
2 8
54 2
0
263
2
2 7
54 2
0
262
2
2 6
54 2
0
261
2
2 5
54 2
0
260
2
2 4
54 2
0
259
2
2 3
54 2
0
258
2
2 2
54 2
0
230
2
3 1
54 1
0
238
2
3 9
54 1
0
237
2
3 8
54 1
0
236
2
3 7
54 1
0
235
2
3 6
54 1
0
234
2
3 5
54 1
0
233
2
3 4
54 1
0
232
2
3 3
54 1
0
231
2
3 2
54 1
end_DTG
begin_CG
11
61 1
62 1
63 1
66 1
67 1
73 9
72 9
71 9
70 9
69 9
68 5
11
61 1
62 1
63 1
66 1
67 1
73 9
72 9
71 9
70 9
69 9
65 5
20
54 1
55 1
56 1
57 1
58 1
60 1
61 1
62 1
63 1
66 1
67 1
76 9
75 9
74 9
73 9
72 9
71 9
70 9
69 9
64 11
60
54 1
55 1
56 1
57 1
58 1
60 1
7 142
6 135
5 135
4 95
53 9
51 9
49 9
47 9
45 9
43 9
41 9
39 9
37 9
35 9
33 9
31 9
29 9
27 9
25 9
23 9
21 9
19 9
17 9
15 9
13 9
11 9
9 9
76 9
75 9
74 9
59 6
52 12
50 12
48 4
46 3
44 4
42 20
40 15
38 20
36 12
34 9
32 12
30 32
28 32
26 40
24 30
22 40
20 21
18 20
16 15
14 20
12 8
10 6
8 8
16
52 3
50 3
48 1
44 1
42 5
38 5
36 3
32 3
30 8
28 8
26 10
22 10
18 5
14 5
12 2
8 2
23
52 3
50 3
48 1
46 1
44 1
42 5
40 5
38 5
36 3
34 3
32 3
30 8
28 8
26 10
24 10
22 10
20 7
18 5
16 5
14 5
12 2
10 2
8 2
23
52 3
50 3
48 1
46 1
44 1
42 5
40 5
38 5
36 3
34 3
32 3
30 8
28 8
26 10
24 10
22 10
20 7
18 5
16 5
14 5
12 2
10 2
8 2
23
52 3
50 3
48 1
46 1
44 1
42 5
40 5
38 5
36 3
34 3
32 3
30 8
28 8
26 10
24 10
22 10
20 7
18 5
16 5
14 5
12 2
10 2
8 2
1
9 9
0
1
11 9
0
1
13 9
0
1
15 9
0
1
17 9
0
1
19 9
0
1
21 9
0
1
23 9
0
1
25 9
0
1
27 9
0
1
29 9
0
1
31 9
0
1
33 9
0
1
35 9
0
1
37 9
0
1
39 9
0
1
41 9
0
1
43 9
0
1
45 9
0
1
47 9
0
1
49 9
0
1
51 9
0
1
53 9
0
3
76 18
59 1
64 1
2
59 1
64 1
3
75 18
59 1
64 1
2
59 1
64 1
3
74 18
59 1
64 1
6
54 1
55 1
56 1
57 1
58 1
60 1
2
59 1
64 1
4
73 27
64 1
65 1
68 1
4
72 27
64 1
65 1
68 1
4
71 27
64 1
65 1
68 1
11
54 1
55 1
56 1
57 1
58 1
60 1
61 1
62 1
63 1
66 1
67 1
5
61 1
62 1
63 1
66 1
67 1
4
70 27
64 1
65 1
68 1
4
69 27
64 1
65 1
68 1
5
61 1
62 1
63 1
66 1
67 1
0
0
0
0
0
0
0
0
end_CG
