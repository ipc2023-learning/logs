begin_version
3
end_version
begin_metric
0
end_metric
17
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var6
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var31
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var30
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var29
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var28
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var25
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var23
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var8
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
0
begin_state
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
7
4 0
6 0
8 0
10 0
12 0
14 0
16 0
end_goal
116
begin_operator
calibrate rover1 camera1 objective3 waypoint1
1
0 0
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint2
1
0 1
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint4
1
0 3
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective3 waypoint6
1
0 5
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint1
1
0 0
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective1 waypoint6
1
0 5
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint1 waypoint6
2
0 0
15 0
1
0 16 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint3 waypoint6
2
0 2
15 0
1
0 16 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint4 waypoint6
2
0 3
15 0
1
0 16 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint5 waypoint6
2
0 4
15 0
1
0 16 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint1 waypoint6
2
0 0
13 0
1
0 14 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint3 waypoint6
2
0 2
13 0
1
0 14 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint4 waypoint6
2
0 3
13 0
1
0 14 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint5 waypoint6
2
0 4
13 0
1
0 14 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint1 waypoint6
2
0 0
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint3 waypoint6
2
0 2
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint4 waypoint6
2
0 3
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint5 waypoint6
2
0 4
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint1 waypoint6
2
0 0
9 0
1
0 10 -1 0
0
end_operator
begin_operator
communicate_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




oint5 objective1 camera2 low_res
1
0 4
2
0 1 0 1
0 11 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera1 colour
1
0 5
2
0 2 0 1
0 15 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera1 high_res
1
0 5
2
0 2 0 1
0 13 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera1 low_res
1
0 5
2
0 2 0 1
0 11 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera2 high_res
1
0 5
2
0 1 0 1
0 13 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective1 camera2 low_res
1
0 5
2
0 1 0 1
0 11 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective3 camera1 colour
1
0 5
2
0 2 0 1
0 7 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective3 camera1 high_res
1
0 5
2
0 2 0 1
0 5 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective3 camera1 low_res
1
0 5
2
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective3 camera2 high_res
1
0 5
2
0 1 0 1
0 5 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint6 objective3 camera2 low_res
1
0 5
2
0 1 0 1
0 3 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 2
check 5
0
4
37
38
39
check 9
51
52
53
56
57
58
61
62
63
check 0
switch 1
check 0
check 6
54
55
59
60
64
65
check 0
switch 15
check 0
check 1
9
check 0
switch 13
check 0
check 1
13
check 0
switch 11
check 0
check 1
17
check 0
switch 9
check 0
check 1
21
check 0
switch 7
check 0
check 1
25
check 0
switch 5
check 0
check 1
29
check 0
switch 3
check 0
check 1
33
check 0
check 0
switch 2
check 3
1
5
40
check 9
66
67
68
71
72
73
76
77
78
check 0
switch 1
check 0
check 6
69
70
74
75
79
80
check 0
check 0
switch 2
check 2
6
41
check 6
81
82
83
86
87
88
check 0
switch 1
check 0
check 4
84
85
89
90
check 0
switch 15
check 0
check 1
10
check 0
switch 13
check 0
check 1
14
check 0
switch 11
check 0
check 1
18
check 0
switch 9
check 0
check 1
22
check 0
switch 7
check 0
check 1
26
check 0
switch 5
check 0
check 1
30
check 0
switch 3
check 0
check 1
34
check 0
check 0
switch 2
check 4
2
42
43
44
check 6
91
92
93
96
97
98
check 0
switch 1
check 0
check 4
94
95
99
100
check 0
switch 15
check 0
check 1
11
check 0
switch 13
check 0
check 1
15
check 0
switch 11
check 0
check 1
19
check 0
switch 9
check 0
check 1
23
check 0
switch 7
check 0
check 1
27
check 0
switch 5
check 0
check 1
31
check 0
switch 3
check 0
check 1
35
check 0
check 0
switch 2
check 5
7
45
46
47
48
check 3
101
102
103
check 0
switch 1
check 0
check 2
104
105
check 0
switch 15
check 0
check 1
12
check 0
switch 13
check 0
check 1
16
check 0
switch 11
check 0
check 1
20
check 0
switch 9
check 0
check 1
24
check 0
switch 7
check 0
check 1
28
check 0
switch 5
check 0
check 1
32
check 0
switch 3
check 0
check 1
36
check 0
check 0
switch 2
check 4
3
8
49
50
check 6
106
107
108
111
112
113
check 0
switch 1
check 0
check 4
109
110
114
115
check 0
check 0
check 0
end_SG
begin_DTG
3
3
37
0
4
38
0
5
39
0
1
4
40
0
1
3
41
0
3
0
42
0
2
43
0
4
44
0
4
0
45
0
1
46
0
3
47
0
5
48
0
2
0
49
0
4
50
0
end_DTG
begin_DTG
6
1
85
1
0 2
1
115
1
0 5
1
105
1
0 4
1
100
1
0 3
1
54
1
0 0
1
80
1
0 1
5
0
4
1
0 0
0
5
1
0 1
0
6
1
0 2
0
7
1
0 4
0
8
1
0 5
end_DTG
begin_DTG
6
1
98
1
0 3
1
83
1
0 2
1
101
1
0 4
1
106
1
0 5
1
67
1
0 1
1
52
1
0 0
4
0
0
1
0 0
0
1
1
0 1
0
2
1
0 3
0
3
1
0 5
end_DTG
begin_DTG
0
8
0
63
2
0 0
2 0
0
65
2
0 0
1 0
0
78
2
0 1
2 0
0
80
2
0 1
1 0
0
98
2
0 3
2 0
0
100
2
0 3
1 0
0
113
2
0 5
2 0
0
115
2
0 5
1 0
end_DTG
begin_DTG
0
4
0
33
2
0 0
3 0
0
34
2
0 2
3 0
0
35
2
0 3
3 0
0
36
2
0 4
3 0
end_DTG
begin_DTG
0
8
0
62
2
0 0
2 0
0
64
2
0 0
1 0
0
77
2
0 1
2 0
0
79
2
0 1
1 0
0
97
2
0 3
2 0
0
99
2
0 3
1 0
0
112
2
0 5
2 0
0
114
2
0 5
1 0
end_DTG
begin_DTG
0
4
0
29
2
0 0
5 0
0
30
2
0 2
5 0
0
31
2
0 3
5 0
0
32
2
0 4
5 0
end_DTG
begin_DTG
0
4
0
61
2
0 0
2 0
0
76
2
0 1
2 0
0
96
2
0 3
2 0
0
111
2
0 5
2 0
end_DTG
begin_DTG
0
4
0
25
2
0 0
7 0
0
26
2
0 2
7 0
0
27
2
0 3
7 0
0
28
2
0 4
7 0
end_DTG
begin_DTG
0
8
0
58
2
0 0
2 0
0
60
2
0 0
1 0
0
73
2
0 1
2 0
0
75
2
0 1
1 0
0
88
2
0 2
2 0
0
90
2
0 2
1 0
0
93
2
0 3
2 0
0
95
2
0 3
1 0
end_DTG
begin_DTG
0
4
0
21
2
0 0
9 0
0
22
2
0 2
9 0
0
23
2
0 3
9 0
0
24
2
0 4
9 0
end_DTG
begin_DTG
0
10
0
53
2
0 0
2 0
0
55
2
0 0
1 0
0
68
2
0 1
2 0
0
70
2
0 1
1 0
0
83
2
0 2
2 0
0
85
2
0 2
1 0
0
103
2
0 4
2 0
0
105
2
0 4
1 0
0
108
2
0 5
2 0
0
110
2
0 5
1 0
end_DTG
begin_DTG
0
4
0
17
2
0 0
11 0
0
18
2
0 2
11 0
0
19
2
0 3
11 0
0
20
2
0 4
11 0
end_DTG
begin_DTG
0
10
0
52
2
0 0
2 0
0
54
2
0 0
1 0
0
67
2
0 1
2 0
0
69
2
0 1
1 0
0
82
2
0 2
2 0
0
84
2
0 2
1 0
0
102
2
0 4
2 0
0
104
2
0 4
1 0
0
107
2
0 5
2 0
0
109
2
0 5
1 0
end_DTG
begin_DTG
0
4
0
13
2
0 0
13 0
0
14
2
0 2
13 0
0
15
2
0 3
13 0
0
16
2
0 4
13 0
end_DTG
begin_DTG
0
5
0
51
2
0 0
2 0
0
66
2
0 1
2 0
0
81
2
0 2
2 0
0
101
2
0 4
2 0
0
106
2
0 5
2 0
end_DTG
begin_DTG
0
4
0
9
2
0 0
15 0
0
10
2
0 2
15 0
0
11
2
0 3
15 0
0
12
2
0 4
15 0
end_DTG
begin_CG
16
2 43
1 31
16 4
14 4
12 4
10 4
8 4
6 4
4 4
15 5
13 10
11 10
9 8
7 4
5 8
3 8
5
13 5
11 5
9 4
5 4
3 4
7
15 5
13 5
11 5
9 4
7 4
5 4
3 4
1
4 4
0
1
6 4
0
1
8 4
0
1
10 4
0
1
12 4
0
1
14 4
0
1
16 4
0
end_CG
