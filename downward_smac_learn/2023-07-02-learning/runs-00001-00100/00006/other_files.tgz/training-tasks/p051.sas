begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var44
-1
2
Atom have_image(rover2, objective4, colour)
NegatedAtom have_image(rover2, objective4, colour)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var42
-1
2
Atom have_image(rover2, objective3, high_res)
NegatedAtom have_image(rover2, objective3, high_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var33
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var34
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var32
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var31
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var30
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var29
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var28
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var27
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
6
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
end_state
begin_goal
14
3 0
5 0
7 0
9 0
11 0
14 0
16 0
27 0
28 0
29 0
30 0
31 0
32 0
33 0
end_goal
174
begin_operator
calibrate rover2 camera1 objective4 waypoint1
1
0 0
1
0 12 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective4 waypoint2
1
0 1
1
0 12 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 obj




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 0
check 0
switch 21
check 3
1
7
44
check 0
check 0
check 0
switch 12
check 0
check 4
82
86
90
94
check 0
switch 1
check 0
check 12
83
84
85
87
88
89
91
92
93
95
96
97
check 0
check 0
switch 21
check 4
2
8
45
46
check 0
check 0
check 0
switch 12
check 0
check 4
98
102
106
110
check 0
switch 1
check 0
check 12
99
100
101
103
104
105
107
108
109
111
112
113
check 0
check 0
switch 21
check 3
3
9
47
check 0
check 0
check 0
switch 22
check 0
switch 25
check 0
check 1
60
check 0
check 0
check 0
check 0
switch 12
check 0
check 4
114
118
122
126
check 0
switch 1
check 0
check 12
115
116
117
119
120
121
123
124
125
127
128
129
check 0
check 0
switch 21
check 3
4
10
48
check 0
check 0
check 0
switch 23
check 0
switch 25
check 0
check 1
61
check 0
check 0
check 0
check 0
switch 12
check 0
check 4
130
134
138
142
check 0
switch 1
check 0
check 12
131
132
133
135
136
137
139
140
141
143
144
145
check 0
check 0
switch 21
check 6
5
49
50
51
52
53
check 0
check 0
check 1
22
switch 22
check 0
check 0
check 0
check 1
23
switch 23
check 0
check 0
check 0
check 1
24
switch 26
check 0
switch 25
check 0
check 1
62
check 0
check 0
check 0
check 1
25
switch 12
check 0
check 4
146
150
154
158
check 0
switch 1
check 0
check 12
147
148
149
151
152
153
155
156
157
159
160
161
check 0
switch 10
check 0
check 1
11
check 0
switch 15
check 0
check 1
12
check 0
switch 8
check 0
check 1
13
check 0
switch 6
check 0
check 1
14
check 0
switch 13
check 0
check 1
15
check 0
switch 4
check 0
check 1
16
check 0
switch 2
check 0
check 1
17
check 0
check 0
switch 21
check 2
6
54
check 0
check 0
check 0
switch 12
check 0
check 3
162
166
170
check 0
switch 1
check 0
check 9
163
164
165
167
168
169
171
172
173
check 0
check 0
switch 24
check 0
check 0
check 1
29
switch 25
check 0
check 0
check 1
30
check 0
end_SG
begin_DTG
1
2
43
0
1
5
44
0
2
0
45
0
5
46
0
1
5
47
0
1
5
48
0
5
1
49
0
2
50
0
3
51
0
4
52
0
6
53
0
1
5
54
0
end_DTG
begin_DTG
7
1
133
1
0 4
1
147
1
0 5
1
129
1
0 3
1
173
1
0 6
1
80
1
0 0
1
92
1
0 1
1
107
1
0 2
4
0
7
1
0 1
0
8
1
0 2
0
9
1
0 3
0
10
1
0 4
end_DTG
begin_DTG
0
3
0
79
2
0 0
1 0
0
95
2
0 1
1 0
0
159
2
0 5
1 0
end_DTG
begin_DTG
0
1
0
17
2
0 5
2 0
end_DTG
begin_DTG
0
7
0
77
2
0 0
1 0
0
93
2
0 1
1 0
0
113
2
0 2
1 0
0
129
2
0 3
1 0
0
145
2
0 4
1 0
0
157
2
0 5
1 0
0
173
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
16
2
0 5
4 0
end_DTG
begin_DTG
0
7
0
75
2
0 0
1 0
0
91
2
0 1
1 0
0
111
2
0 2
1 0
0
127
2
0 3
1 0
0
143
2
0 4
1 0
0
155
2
0 5
1 0
0
171
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
14
2
0 5
6 0
end_DTG
begin_DTG
0
7
0
73
2
0 0
1 0
0
89
2
0 1
1 0
0
109
2
0 2
1 0
0
125
2
0 3
1 0
0
141
2
0 4
1 0
0
153
2
0 5
1 0
0
169
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
13
2
0 5
8 0
end_DTG
begin_DTG
0
6
0
69
2
0 0
1 0
0
105
2
0 2
1 0
0
121
2
0 3
1 0
0
137
2
0 4
1 0
0
149
2
0 5
1 0
0
165
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
11
2
0 5
10 0
end_DTG
begin_DTG
7
1
118
1
0 3
1
170
1
0 6
1
158
1
0 5
1
142
1
0 4
1
66
1
0 0
1
110
1
0 2
1
94
1
0 1
7
0
0
1
0 0
0
1
1
0 1
0
2
1
0 2
0
3
1
0 3
0
4
1
0 4
0
5
1
0 5
0
6
1
0 6
end_DTG
begin_DTG
0
14
0
74
2
0 0
12 0
0
76
2
0 0
1 0
0
90
2
0 1
12 0
0
92
2
0 1
1 0
0
110
2
0 2
12 0
0
112
2
0 2
1 0
0
126
2
0 3
12 0
0
128
2
0 3
1 0
0
142
2
0 4
12 0
0
144
2
0 4
1 0
0
154
2
0 5
12 0
0
156
2
0 5
1 0
0
170
2
0 6
12 0
0
172
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
15
2
0 5
13 0
end_DTG
begin_DTG
0
14
0
70
2
0 0
12 0
0
72
2
0 0
1 0
0
86
2
0 1
12 0
0
88
2
0 1
1 0
0
106
2
0 2
12 0
0
108
2
0 2
1 0
0
122
2
0 3
12 0
0
124
2
0 3
1 0
0
138
2
0 4
12 0
0
140
2
0 4
1 0
0
150
2
0 5
12 0
0
152
2
0 5
1 0
0
166
2
0 6
12 0
0
168
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
12
2
0 5
15 0
end_DTG
begin_DTG
1
2
31
0
1
5
32
0
2
0
33
0
5
34
0
1
5
35
0
1
5
36
0
5
1
37
0
2
38
0
3
39
0
4
40
0
6
41
0
1
5
42
0
end_DTG
begin_DTG
1
1
63
2
17 0
24 0
0
end_DTG
begin_DTG
1
1
64
2
17 1
24 0
0
end_DTG
begin_DTG
1
1
65
2
17 4
24 0
0
end_DTG
begin_DTG
2
1
55
2
17 0
24 0
2
59
2
0 0
25 0
0
0
end_DTG
begin_DTG
2
1
56
2
17 3
24 0
2
60
2
0 3
25 0
0
0
end_DTG
begin_DTG
2
1
57
2
17 4
24 0
2
61
2
0 4
25 0
0
0
end_DTG
begin_DTG
7
1
55
2
17 0
21 0
1
56
2
17 3
22 0
1
57
2
17 4
23 0
1
58
2
17 5
26 0
1
63
2
17 0
18 0
1
64
2
17 1
19 0
1
65
2
17 4
20 0
1
0
29
0
end_DTG
begin_DTG
4
1
59
2
0 0
21 0
1
60
2
0 3
22 0
1
61
2
0 4
23 0
1
62
2
0 5
26 0
1
0
30
0
end_DTG
begin_DTG
2
1
58
2
17 5
24 0
2
62
2
0 5
25 0
0
0
end_DTG
begin_DTG
0
1
0
28
2
17 5
20 1
end_DTG
begin_DTG
0
1
0
27
2
17 5
19 1
end_DTG
begin_DTG
0
1
0
26
2
17 5
18 1
end_DTG
begin_DTG
0
2
0
21
2
17 5
26 1
0
25
2
0 5
26 2
end_DTG
begin_DTG
0
2
0
20
2
17 5
23 1
0
24
2
0 5
23 2
end_DTG
begin_DTG
0
2
0
19
2
17 5
22 1
0
23
2
0 5
22 2
end_DTG
begin_DTG
0
2
0
18
2
17 5
21 1
0
22
2
0 5
21 2
end_DTG
begin_CG
25
21 1
22 1
23 1
26 1
12 34
1 85
11 1
16 1
9 1
7 1
14 1
5 1
3 1
33 1
32 1
31 1
30 1
25 4
10 6
15 14
8 7
6 7
13 14
4 7
2 3
7
10 6
15 7
8 7
6 7
13 7
4 7
2 3
1
3 1
0
1
5 1
0
1
7 1
0
1
9 1
0
1
11 1
0
2
15 7
13 7
1
14 1
0
1
16 1
0
15
21 1
22 1
23 1
26 1
18 1
19 1
20 1
33 1
32 1
31 1
30 1
29 1
28 1
27 1
24 7
2
29 1
24 1
2
28 1
24 1
2
27 1
24 1
3
33 2
24 1
25 1
3
32 2
24 1
25 1
3
31 2
24 1
25 1
7
21 1
22 1
23 1
26 1
18 1
19 1
20 1
4
21 1
22 1
23 1
26 1
3
30 2
24 1
25 1
0
0
0
0
0
0
0
end_CG
