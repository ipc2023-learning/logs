begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
10
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint10)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var87
-1
2
Atom have_image(rover2, objective2, high_res)
NegatedAtom have_image(rover2, objective2, high_res)
end_variable
begin_variable
var9
-1
2
Atom at_soil_sample(waypoint10)
Atom have_soil_analysis(rover3, waypoint10)
end_variable
begin_variable
var10
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var11
-1
2
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover3, waypoint6)
end_variable
begin_variable
var12
-1
2
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var13
-1
2
Atom at_soil_sample(waypoint9)
Atom have_soil_analysis(rover3, waypoint9)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint10)
Atom have_rock_analysis(rover2, waypoint10)
Atom have_rock_analysis(rover3, waypoint10)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var7
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var58
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var59
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var8
-1
3
Atom at_rock_sample(waypoint9)
Atom have_rock_analysis(rover2, waypoint9)
Atom have_rock_analysis(rover3, waypoint9)
end_variable
begin_variable
var56
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var55
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var0
-1
10
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint10)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var65
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
0
begin_state
0
7
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
1
1
3
1
1
1
end_state
begin_goal
3
17 0
18 0
22 0
end_goal
616
begin_operator
calibrate rover1 camera3 objective4 waypoint10
1
19 1
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective4 waypoint2
1
19 2
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective4 waypoint4
1
19 4
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective4 waypoint5
1
19 5
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective4 waypoint6
1
19 6
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective4 waypoint7
1
19 7
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective4 waypoint8
1
19 8
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective4 waypoint9
1
19 9
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint1
1
1 0
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint10
1
1 1
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint2
1
1 2
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint3
1
1 3
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint5
1
1 5
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint6
1
1 6
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint7
1
1 7
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective2 waypoint9
1
1 9
1
0 3 -1 0
0
end_o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 0
switch 16
check 0
switch 14
check 0
check 1
115
check 0
check 0
check 0
check 0
switch 3
check 0
check 24
576
577
578
581
582
583
586
587
588
591
592
593
596
597
598
601
602
603
606
607
608
611
612
613
check 0
switch 2
check 0
check 16
579
580
584
585
589
590
594
595
599
600
604
605
609
610
614
615
check 0
switch 4
check 0
check 1
28
check 0
check 0
switch 0
check 0
switch 10
check 4
85
86
87
88
check 0
check 0
check 0
switch 7
check 0
check 0
check 1
29
switch 8
check 0
check 0
check 1
33
check 0
switch 10
check 2
89
90
switch 15
check 0
check 1
116
check 0
check 0
check 0
check 0
switch 5
check 0
switch 15
check 0
check 1
121
check 0
check 0
check 0
check 0
switch 10
check 3
91
92
93
check 0
check 0
check 0
switch 6
check 0
switch 15
check 0
check 1
122
check 0
check 0
check 0
check 0
check 3
94
95
96
check 3
97
98
99
switch 10
check 1
100
check 0
check 0
check 0
switch 11
check 0
switch 15
check 0
check 1
117
check 0
check 0
check 0
check 0
switch 7
check 0
check 0
check 1
30
switch 8
check 0
check 0
check 1
34
check 0
switch 10
check 3
101
102
103
check 0
check 0
check 0
switch 12
check 0
switch 15
check 0
check 1
118
check 0
check 0
check 0
check 0
switch 7
check 0
switch 15
check 0
check 1
123
check 0
check 0
check 1
31
switch 8
check 0
check 0
check 1
35
check 0
switch 10
check 2
104
105
check 0
check 0
check 0
switch 13
check 0
switch 15
check 0
check 1
119
check 0
check 0
check 0
check 0
switch 8
check 0
switch 15
check 0
check 1
124
check 0
check 0
check 0
check 0
check 2
106
107
switch 10
check 3
108
109
110
check 0
check 0
check 0
switch 16
check 0
switch 15
check 0
check 1
120
check 0
check 0
check 0
check 0
switch 7
check 0
check 0
check 1
32
switch 8
check 0
check 0
check 1
36
switch 9
check 0
switch 15
check 0
check 1
125
check 0
check 0
check 0
check 0
switch 14
check 0
check 0
check 1
37
switch 15
check 0
check 0
check 1
38
check 0
end_SG
begin_DTG
4
2
85
0
3
86
0
7
87
0
9
88
0
2
3
89
0
6
90
0
3
0
91
0
6
92
0
9
93
0
3
0
94
0
1
95
0
8
96
0
3
6
97
0
8
98
0
9
99
0
1
7
100
0
3
1
101
0
2
102
0
4
103
0
2
0
104
0
5
105
0
2
3
106
0
4
107
0
3
0
108
0
2
109
0
4
110
0
end_DTG
begin_DTG
3
2
63
0
3
64
0
7
65
0
1
6
66
0
4
0
67
0
3
68
0
6
69
0
9
70
0
2
0
71
0
2
72
0
2
6
73
0
8
74
0
1
7
75
0
4
1
76
0
2
77
0
4
78
0
7
79
0
3
0
80
0
5
81
0
6
82
0
1
4
83
0
1
2
84
0
end_DTG
begin_DTG
10
1
509
1
1 7
1
489
1
1 6
1
465
1
1 5
1
595
1
1 9
1
575
1
1 8
1
334
1
1 1
1
339
1
1 2
1
290
1
1 0
1
420
1
1 4
1
400
1
1 3
5
0
16
1
1 0
0
17
1
1 1
0
18
1
1 3
0
19
1
1 7
0
20
1
1 9
end_DTG
begin_DTG
10
1
507
1
1 7
1
486
1
1 6
1
462
1
1 5
1
593
1
1 9
1
573
1
1 8
1
332
1
1 1
1
336
1
1 2
1
287
1
1 0
1
418
1
1 4
1
398
1
1 3
8
0
8
1
1 0
0
9
1
1 1
0
10
1
1 2
0
11
1
1 3
0
12
1
1 5
0
13
1
1 6
0
14
1
1 7
0
15
1
1 9
end_DTG
begin_DTG
0
16
0
277
2
1 0
3 0
0
279
2
1 0
2 0
0
307
2
1 1
3 0
0
309
2
1 1
2 0
0
342
2
1 2
3 0
0
344
2
1 2
2 0
0
382
2
1 3
3 0
0
384
2
1 3
2 0
0
452
2
1 5
3 0
0
454
2
1 5
2 0
0
487
2
1 6
3 0
0
489
2
1 6
2 0
0
517
2
1 7
3 0
0
519
2
1 7
2 0
0
582
2
1 9
3 0
0
584
2
1 9
2 0
end_DTG
begin_DTG
1
1
121
2
0 1
15 0
0
end_DTG
begin_DTG
1
1
122
2
0 2
15 0
0
end_DTG
begin_DTG
1
1
123
2
0 6
15 0
0
end_DTG
begin_DTG
1
1
124
2
0 7
15 0
0
end_DTG
begin_DTG
1
1
125
2
0 9
15 0
0
end_DTG
begin_DTG
2
1
111
2
1 1
14 0
2
116
2
0 1
15 0
0
0
end_DTG
begin_DTG
2
1
112
2
1 5
14 0
2
117
2
0 5
15 0
0
0
end_DTG
begin_DTG
2
1
113
2
1 6
14 0
2
118
2
0 6
15 0
0
0
end_DTG
begin_DTG
2
1
114
2
1 7
14 0
2
119
2
0 7
15 0
0
0
end_DTG
begin_DTG
5
1
111
2
1 1
10 0
1
112
2
1 5
11 0
1
113
2
1 6
12 0
1
114
2
1 7
13 0
1
115
2
1 9
16 0
1
0
37
0
end_DTG
begin_DTG
10
1
116
2
0 1
10 0
1
117
2
0 5
11 0
1
118
2
0 6
12 0
1
119
2
0 7
13 0
1
120
2
0 9
16 0
1
121
2
0 1
5 0
1
122
2
0 2
6 0
1
123
2
0 6
7 0
1
124
2
0 7
8 0
1
125
2
0 9
9 0
1
0
38
0
end_DTG
begin_DTG
2
1
115
2
1 9
14 0
2
120
2
0 9
15 0
0
0
end_DTG
begin_DTG
0
4
0
33
2
0 0
8 1
0
34
2
0 5
8 1
0
35
2
0 6
8 1
0
36
2
0 9
8 1
end_DTG
begin_DTG
0
4
0
29
2
0 0
7 1
0
30
2
0 5
7 1
0
31
2
0 6
7 1
0
32
2
0 9
7 1
end_DTG
begin_DTG
4
2
39
0
3
40
0
7
41
0
9
42
0
1
6
43
0
3
0
44
0
6
45
0
9
46
0
2
0
47
0
8
48
0
2
6
49
0
8
50
0
1
7
51
0
3
1
52
0
2
53
0
4
54
0
3
0
55
0
5
56
0
9
57
0
2
3
58
0
4
59
0
3
0
60
0
2
61
0
7
62
0
end_DTG
begin_DTG
10
1
222
1
19 7
1
214
1
19 6
1
205
1
19 5
1
257
1
19 9
1
249
1
19 8
1
152
1
19 1
1
154
1
19 2
1
135
1
19 0
1
187
1
19 4
1
179
1
19 3
8
0
0
1
19 1
0
1
1
19 2
0
2
1
19 4
0
3
1
19 5
0
4
1
19 6
0
5
1
19 7
0
6
1
19 8
0
7
1
19 9
end_DTG
begin_DTG
0
8
0
131
2
19 0
20 0
0
143
2
19 1
20 0
0
157
2
19 2
20 0
0
173
2
19 3
20 0
0
201
2
19 5
20 0
0
215
2
19 6
20 0
0
227
2
19 7
20 0
0
253
2
19 9
20 0
end_DTG
begin_DTG
0
8
0
21
2
19 0
21 0
0
22
2
19 5
21 0
0
23
2
19 6
21 0
0
24
2
19 9
21 0
0
25
2
1 0
4 0
0
26
2
1 5
4 0
0
27
2
1 6
4 0
0
28
2
1 9
4 0
end_DTG
begin_CG
13
10 1
11 1
12 1
13 1
16 1
5 1
6 1
7 1
8 1
9 1
18 4
17 4
15 10
10
10 1
11 1
12 1
13 1
16 1
3 218
2 145
22 4
14 5
4 16
1
4 8
1
4 8
1
22 4
1
15 1
1
15 1
2
18 4
15 1
2
17 4
15 1
1
15 1
2
14 1
15 1
2
14 1
15 1
2
14 1
15 1
2
14 1
15 1
5
10 1
11 1
12 1
13 1
16 1
10
10 1
11 1
12 1
13 1
16 1
5 1
6 1
7 1
8 1
9 1
2
14 1
15 1
0
0
3
20 148
22 4
21 8
1
21 8
1
22 4
0
end_CG
