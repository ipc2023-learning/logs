begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var32
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var33
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint6)
Atom have_soil_analysis(rover1, waypoint6)
Atom have_soil_analysis(rover2, waypoint6)
end_variable
begin_variable
var31
-1
2
Atom communicated_soil_data(waypoint6)
NegatedAtom communicated_soil_data(waypoint6)
end_variable
begin_variable
var29
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var28
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var25
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var24
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
4
4
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
end_state
begin_goal
6
12 0
13 0
14 0
15 0
16 0
17 0
end_goal
89
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint1 waypoint3
2
1 0
2 1
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint2 waypoint3
2
1 1
2 1
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint4 waypoint3
2
1 3
2 1
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint5 waypoint3
2
1 4
2 1
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint6 waypoint3
2
1 5
2 1
1
0 17 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint1 waypoint3
2
1 0
3 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint2 waypoint3
2
1 1
3 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint4 waypoint3
2
1 3
3 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint5 waypoint3
2
1 4
3 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint6 waypoint3
2
1 5
3 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint1 waypoint3
2
1 0
4 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint2 waypoint3
2
1 1
4 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint4 waypoint3
2
1 3
4 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint5 waypoint3
2
1 4
4 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint6 waypoint3
2
1 5
4 1
1
0 15 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint1 waypoint1 waypoint3
2
1 0
6 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint1 waypoint2 waypoint3
2
1 1
6 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint1 waypoint4 waypoint3
2
1 3
6 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint1 waypoint5 waypoint3
2
1 4
6 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint1 waypoint6 waypoint3
2
1 5
6 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 waypoint1 waypoint3
2
1 0
7 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint3 way




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
check 1
15
check 0
switch 7
check 0
check 0
check 1
20
check 0
switch 11
check 0
check 0
check 1
25
check 0
check 0
switch 0
check 4
48
49
50
51
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
1
switch 3
check 0
switch 9
check 0
check 1
78
check 0
check 0
check 1
6
switch 4
check 0
check 0
check 1
11
switch 6
check 0
check 0
check 1
16
check 0
switch 7
check 0
check 0
check 1
21
check 0
switch 11
check 0
check 0
check 1
26
check 0
check 0
switch 0
check 3
52
53
54
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 9
check 0
check 1
79
check 0
check 0
check 0
switch 7
check 0
switch 9
check 0
check 1
82
check 0
check 0
check 0
check 0
check 0
switch 0
check 2
55
56
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
2
switch 3
check 0
check 0
check 1
7
switch 4
check 0
check 0
check 1
12
switch 5
check 0
switch 9
check 0
check 1
80
check 0
check 0
check 0
switch 6
check 0
check 0
check 1
17
check 0
switch 7
check 0
check 0
check 1
22
check 0
switch 8
check 0
switch 9
check 0
check 1
83
check 0
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
27
check 0
check 0
switch 0
check 3
57
58
59
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
3
switch 3
check 0
check 0
check 1
8
switch 4
check 0
check 0
check 1
13
switch 6
check 0
check 0
check 1
18
check 0
switch 7
check 0
check 0
check 1
23
check 0
switch 11
check 0
check 0
check 1
28
check 0
check 0
switch 0
check 5
60
61
62
63
64
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
4
switch 3
check 0
check 0
check 1
9
switch 4
check 0
check 0
check 1
14
switch 6
check 0
check 0
check 1
19
check 0
switch 7
check 0
check 0
check 1
24
check 0
switch 11
check 0
switch 9
check 0
check 1
84
check 0
check 0
check 1
29
check 0
check 0
switch 0
check 0
switch 2
check 2
65
66
check 0
check 0
switch 6
check 0
switch 10
check 0
check 1
85
check 0
check 0
check 0
check 1
30
switch 7
check 0
check 0
check 0
check 1
35
switch 11
check 0
check 0
check 0
check 1
40
check 0
switch 2
check 2
67
68
check 0
check 0
switch 6
check 0
check 0
check 0
check 1
31
switch 7
check 0
check 0
check 0
check 1
36
switch 11
check 0
check 0
check 0
check 1
41
check 0
switch 2
check 3
69
70
71
check 0
check 0
switch 7
check 0
switch 10
check 0
check 1
86
check 0
check 0
check 0
check 0
check 0
switch 2
check 1
72
check 0
check 0
switch 6
check 0
check 0
check 0
check 1
32
switch 7
check 0
check 0
check 0
check 1
37
switch 8
check 0
switch 10
check 0
check 1
87
check 0
check 0
check 0
check 0
switch 11
check 0
check 0
check 0
check 1
42
check 0
switch 2
check 1
73
check 0
check 0
switch 6
check 0
check 0
check 0
check 1
33
switch 7
check 0
check 0
check 0
check 1
38
switch 11
check 0
check 0
check 0
check 1
43
check 0
switch 2
check 3
74
75
76
check 0
check 0
switch 6
check 0
check 0
check 0
check 1
34
switch 7
check 0
check 0
check 0
check 1
39
switch 11
check 0
switch 10
check 0
check 1
88
check 0
check 0
check 0
check 1
44
check 0
switch 9
check 0
check 0
check 1
45
switch 10
check 0
check 0
check 1
46
check 0
end_SG
begin_DTG
2
1
65
0
5
66
0
2
0
67
0
2
68
0
3
1
69
0
4
70
0
5
71
0
1
5
72
0
1
2
73
0
3
0
74
0
2
75
0
3
76
0
end_DTG
begin_DTG
1
5
47
0
4
2
48
0
3
49
0
4
50
0
5
51
0
3
1
52
0
4
53
0
5
54
0
2
1
55
0
5
56
0
3
1
57
0
2
58
0
5
59
0
5
0
60
0
1
61
0
2
62
0
3
63
0
4
64
0
end_DTG
begin_DTG
1
1
77
2
1 0
9 0
0
end_DTG
begin_DTG
1
1
78
2
1 1
9 0
0
end_DTG
begin_DTG
1
1
79
2
1 2
9 0
0
end_DTG
begin_DTG
1
1
80
2
1 3
9 0
0
end_DTG
begin_DTG
2
1
81
2
1 0
9 0
2
85
2
0 0
10 0
0
0
end_DTG
begin_DTG
2
1
82
2
1 2
9 0
2
86
2
0 2
10 0
0
0
end_DTG
begin_DTG
2
1
83
2
1 3
9 0
2
87
2
0 3
10 0
0
0
end_DTG
begin_DTG
8
1
77
2
1 0
2 0
1
78
2
1 1
3 0
1
79
2
1 2
4 0
1
80
2
1 3
5 0
1
81
2
1 0
6 0
1
82
2
1 2
7 0
1
83
2
1 3
8 0
1
84
2
1 5
11 0
1
0
45
0
end_DTG
begin_DTG
4
1
85
2
0 0
6 0
1
86
2
0 2
7 0
1
87
2
0 3
8 0
1
88
2
0 5
11 0
1
0
46
0
end_DTG
begin_DTG
2
1
84
2
1 5
9 0
2
88
2
0 5
10 0
0
0
end_DTG
begin_DTG
0
10
0
25
2
1 0
11 1
0
26
2
1 1
11 1
0
27
2
1 3
11 1
0
28
2
1 4
11 1
0
29
2
1 5
11 1
0
40
2
0 0
11 2
0
41
2
0 1
11 2
0
42
2
0 3
11 2
0
43
2
0 4
11 2
0
44
2
0 5
11 2
end_DTG
begin_DTG
0
10
0
20
2
1 0
7 1
0
21
2
1 1
7 1
0
22
2
1 3
7 1
0
23
2
1 4
7 1
0
24
2
1 5
7 1
0
35
2
0 0
7 2
0
36
2
0 1
7 2
0
37
2
0 3
7 2
0
38
2
0 4
7 2
0
39
2
0 5
7 2
end_DTG
begin_DTG
0
10
0
15
2
1 0
6 1
0
16
2
1 1
6 1
0
17
2
1 3
6 1
0
18
2
1 4
6 1
0
19
2
1 5
6 1
0
30
2
0 0
6 2
0
31
2
0 1
6 2
0
32
2
0 3
6 2
0
33
2
0 4
6 2
0
34
2
0 5
6 2
end_DTG
begin_DTG
0
5
0
10
2
1 0
4 1
0
11
2
1 1
4 1
0
12
2
1 3
4 1
0
13
2
1 4
4 1
0
14
2
1 5
4 1
end_DTG
begin_DTG
0
5
0
5
2
1 0
3 1
0
6
2
1 1
3 1
0
7
2
1 3
3 1
0
8
2
1 4
3 1
0
9
2
1 5
3 1
end_DTG
begin_DTG
0
5
0
0
2
1 0
2 1
0
1
2
1 1
2 1
0
2
2
1 3
2 1
0
3
2
1 4
2 1
0
4
2
1 5
2 1
end_DTG
begin_CG
8
6 1
7 1
8 1
11 1
14 5
13 5
12 5
10 4
15
2 1
3 1
4 1
5 1
6 1
7 1
8 1
11 1
17 5
16 5
15 5
14 5
13 5
12 5
9 8
2
17 5
9 1
2
16 5
9 1
2
15 5
9 1
1
9 1
3
14 10
9 1
10 1
3
13 10
9 1
10 1
2
9 1
10 1
8
2 1
3 1
4 1
5 1
6 1
7 1
8 1
11 1
4
6 1
7 1
8 1
11 1
3
12 10
9 1
10 1
0
0
0
0
0
0
end_CG
