begin_version
3
end_version
begin_metric
0
end_metric
55
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var9
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var10
-1
2
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
end_variable
begin_variable
var47
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var45
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var44
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var43
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var42
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover1, objective8, colour)
NegatedAtom have_image(rover1, objective8, colour)
end_variable
begin_variable
var35
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var69
-1
2
Atom have_image(rover1, objective7, low_res)
NegatedAtom have_image(rover1, objective7, low_res)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover1, objective7, high_res)
NegatedAtom have_image(rover1, objective7, high_res)
end_variable
begin_variable
var33
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var67
-1
2
Atom have_image(rover1, objective7, colour)
NegatedAtom have_image(rover1, objective7, colour)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var64
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var57
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var54
-1
2
Atom have_i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3 0
0
76
2
11 7
23 0
0
77
2
11 8
23 0
end_DTG
begin_DTG
0
2
0
441
2
11 6
14 0
0
446
2
11 6
12 0
end_DTG
begin_DTG
0
6
0
66
2
11 0
25 0
0
67
2
11 2
25 0
0
68
2
11 3
25 0
0
69
2
11 6
25 0
0
70
2
11 7
25 0
0
71
2
11 8
25 0
end_DTG
begin_DTG
0
24
0
419
2
11 4
14 0
0
480
2
11 8
12 0
0
477
2
11 8
13 0
0
475
2
11 8
14 0
0
472
2
11 7
12 0
0
469
2
11 7
13 0
0
467
2
11 7
14 0
0
440
2
11 6
12 0
0
437
2
11 6
13 0
0
435
2
11 6
14 0
0
424
2
11 4
12 0
0
421
2
11 4
13 0
0
315
2
11 0
14 0
0
392
2
11 3
12 0
0
389
2
11 3
13 0
0
387
2
11 3
14 0
0
368
2
11 2
12 0
0
365
2
11 2
13 0
0
363
2
11 2
14 0
0
344
2
11 1
12 0
0
341
2
11 1
13 0
0
339
2
11 1
14 0
0
320
2
11 0
12 0
0
317
2
11 0
13 0
end_DTG
begin_DTG
0
6
0
60
2
11 0
27 0
0
61
2
11 2
27 0
0
62
2
11 3
27 0
0
63
2
11 6
27 0
0
64
2
11 7
27 0
0
65
2
11 8
27 0
end_DTG
begin_DTG
0
9
0
331
2
11 1
14 0
0
333
2
11 1
13 0
0
336
2
11 1
12 0
0
379
2
11 3
14 0
0
381
2
11 3
13 0
0
384
2
11 3
12 0
0
411
2
11 4
14 0
0
413
2
11 4
13 0
0
416
2
11 4
12 0
end_DTG
begin_DTG
0
6
0
54
2
11 0
29 0
0
55
2
11 2
29 0
0
56
2
11 3
29 0
0
57
2
11 6
29 0
0
58
2
11 7
29 0
0
59
2
11 8
29 0
end_DTG
begin_DTG
0
3
0
307
2
11 0
14 0
0
309
2
11 0
13 0
0
312
2
11 0
12 0
end_DTG
begin_DTG
0
6
0
48
2
11 0
31 0
0
49
2
11 2
31 0
0
50
2
11 3
31 0
0
51
2
11 6
31 0
0
52
2
11 7
31 0
0
53
2
11 8
31 0
end_DTG
begin_DTG
0
3
0
306
2
11 0
14 0
0
308
2
11 0
13 0
0
311
2
11 0
12 0
end_DTG
begin_DTG
0
6
0
42
2
11 0
33 0
0
43
2
11 2
33 0
0
44
2
11 3
33 0
0
45
2
11 6
33 0
0
46
2
11 7
33 0
0
47
2
11 8
33 0
end_DTG
begin_DTG
0
6
0
299
2
11 0
14 0
0
301
2
11 0
13 0
0
304
2
11 0
12 0
0
459
2
11 7
14 0
0
461
2
11 7
13 0
0
464
2
11 7
12 0
end_DTG
begin_DTG
0
6
0
36
2
11 0
35 0
0
37
2
11 2
35 0
0
38
2
11 3
35 0
0
39
2
11 6
35 0
0
40
2
11 7
35 0
0
41
2
11 8
35 0
end_DTG
begin_DTG
0
6
0
298
2
11 0
14 0
0
300
2
11 0
13 0
0
303
2
11 0
12 0
0
458
2
11 7
14 0
0
460
2
11 7
13 0
0
463
2
11 7
12 0
end_DTG
begin_DTG
0
6
0
30
2
11 0
37 0
0
31
2
11 2
37 0
0
32
2
11 3
37 0
0
33
2
11 6
37 0
0
34
2
11 7
37 0
0
35
2
11 8
37 0
end_DTG
begin_DTG
0
4
0
297
2
11 0
14 0
0
302
2
11 0
12 0
0
457
2
11 7
14 0
0
462
2
11 7
12 0
end_DTG
begin_DTG
0
6
0
24
2
11 0
39 0
0
25
2
11 2
39 0
0
26
2
11 3
39 0
0
27
2
11 6
39 0
0
28
2
11 7
39 0
0
29
2
11 8
39 0
end_DTG
begin_DTG
0
12
0
323
2
11 1
14 0
0
325
2
11 1
13 0
0
328
2
11 1
12 0
0
355
2
11 2
14 0
0
357
2
11 2
13 0
0
360
2
11 2
12 0
0
403
2
11 4
14 0
0
405
2
11 4
13 0
0
408
2
11 4
12 0
0
427
2
11 5
14 0
0
429
2
11 5
13 0
0
432
2
11 5
12 0
end_DTG
begin_DTG
0
6
0
18
2
11 0
41 0
0
19
2
11 2
41 0
0
20
2
11 3
41 0
0
21
2
11 6
41 0
0
22
2
11 7
41 0
0
23
2
11 8
41 0
end_DTG
begin_DTG
0
8
0
321
2
11 1
14 0
0
326
2
11 1
12 0
0
353
2
11 2
14 0
0
358
2
11 2
12 0
0
401
2
11 4
14 0
0
406
2
11 4
12 0
0
425
2
11 5
14 0
0
430
2
11 5
12 0
end_DTG
begin_DTG
0
6
0
12
2
11 0
43 0
0
13
2
11 2
43 0
0
14
2
11 3
43 0
0
15
2
11 6
43 0
0
16
2
11 7
43 0
0
17
2
11 8
43 0
end_DTG
begin_DTG
2
1
285
2
11 3
48 0
2
289
2
0 3
49 0
0
0
end_DTG
begin_DTG
2
1
286
2
11 6
48 0
2
290
2
0 6
49 0
0
0
end_DTG
begin_DTG
2
1
287
2
11 7
48 0
2
291
2
0 7
49 0
0
0
end_DTG
begin_DTG
4
1
285
2
11 3
45 0
1
286
2
11 6
46 0
1
287
2
11 7
47 0
1
288
2
11 8
50 0
1
0
174
0
end_DTG
begin_DTG
4
1
289
2
0 3
45 0
1
290
2
0 6
46 0
1
291
2
0 7
47 0
1
292
2
0 8
50 0
1
0
176
0
end_DTG
begin_DTG
2
1
288
2
11 8
48 0
2
292
2
0 8
49 0
0
0
end_DTG
begin_DTG
0
12
0
120
2
11 0
50 1
0
121
2
11 2
50 1
0
122
2
11 3
50 1
0
123
2
11 6
50 1
0
124
2
11 7
50 1
0
125
2
11 8
50 1
0
144
2
0 0
50 2
0
145
2
0 2
50 2
0
146
2
0 3
50 2
0
147
2
0 6
50 2
0
148
2
0 7
50 2
0
149
2
0 8
50 2
end_DTG
begin_DTG
0
12
0
114
2
11 0
47 1
0
115
2
11 2
47 1
0
116
2
11 3
47 1
0
117
2
11 6
47 1
0
118
2
11 7
47 1
0
119
2
11 8
47 1
0
138
2
0 0
47 2
0
139
2
0 2
47 2
0
140
2
0 3
47 2
0
141
2
0 6
47 2
0
142
2
0 7
47 2
0
143
2
0 8
47 2
end_DTG
begin_DTG
0
12
0
108
2
11 0
46 1
0
109
2
11 2
46 1
0
110
2
11 3
46 1
0
111
2
11 6
46 1
0
112
2
11 7
46 1
0
113
2
11 8
46 1
0
132
2
0 0
46 2
0
133
2
0 2
46 2
0
134
2
0 3
46 2
0
135
2
0 6
46 2
0
136
2
0 7
46 2
0
137
2
0 8
46 2
end_DTG
begin_DTG
0
12
0
102
2
11 0
45 1
0
103
2
11 2
45 1
0
104
2
11 3
45 1
0
105
2
11 6
45 1
0
106
2
11 7
45 1
0
107
2
11 8
45 1
0
126
2
0 0
45 2
0
127
2
0 2
45 2
0
128
2
0 3
45 2
0
129
2
0 6
45 2
0
130
2
0 7
45 2
0
131
2
0 8
45 2
end_DTG
begin_CG
9
45 1
46 1
47 1
50 1
54 6
53 6
52 6
51 6
49 4
9
2 1
3 1
4 1
5 1
10 6
9 6
8 6
7 6
6 4
2
10 6
6 1
2
9 6
6 1
2
8 6
6 1
2
7 6
6 1
4
2 1
3 1
4 1
5 1
0
0
0
0
42
45 1
46 1
47 1
50 1
14 76
13 53
12 83
44 6
42 6
40 6
38 6
36 6
34 6
32 6
30 6
28 6
26 6
24 6
22 6
20 6
18 6
16 6
54 6
53 6
52 6
51 6
48 4
43 8
41 12
39 4
37 6
35 6
33 3
31 3
29 9
27 24
25 2
23 3
21 10
19 15
17 15
15 2
15
43 4
41 4
39 2
37 2
35 2
33 1
31 1
29 3
27 8
25 1
23 1
21 5
19 5
17 5
15 1
10
41 4
37 2
35 2
33 1
31 1
29 3
27 8
23 1
19 5
17 5
15
43 4
41 4
39 2
37 2
35 2
33 1
31 1
29 3
27 8
25 1
23 1
21 5
19 5
17 5
15 1
1
16 6
0
1
18 6
0
1
20 6
0
1
22 6
0
1
24 6
0
1
26 6
0
1
28 6
0
1
30 6
0
1
32 6
0
1
34 6
0
1
36 6
0
1
38 6
0
1
40 6
0
1
42 6
0
1
44 6
0
3
54 12
48 1
49 1
3
53 12
48 1
49 1
3
52 12
48 1
49 1
4
45 1
46 1
47 1
50 1
4
45 1
46 1
47 1
50 1
3
51 12
48 1
49 1
0
0
0
0
end_CG
