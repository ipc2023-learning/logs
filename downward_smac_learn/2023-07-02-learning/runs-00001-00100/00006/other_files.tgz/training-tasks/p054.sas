begin_version
3
end_version
begin_metric
0
end_metric
37
begin_variable
var2
-1
7
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var64
-1
2
Atom have_image(rover3, objective2, colour)
NegatedAtom have_image(rover3, objective2, colour)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover3, objective1, colour)
NegatedAtom have_image(rover3, objective1, colour)
end_variable
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var59
-1
2
Atom have_image(rover1, objective6, high_res)
NegatedAtom have_image(rover1, objective6, high_res)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var41
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var7
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover3, waypoint4)
end_variable
begin_variable
var40
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var42
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var10
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var39
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var38
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var37
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var34
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_r




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





59
check 0
check 0
switch 29
check 0
check 0
check 1
110
switch 25
check 0
check 0
check 1
111
switch 30
check 0
check 0
check 1
112
check 0
end_SG
begin_DTG
3
2
139
0
4
140
0
5
141
0
3
3
142
0
5
143
0
6
144
0
2
0
145
0
5
146
0
1
1
147
0
2
0
148
0
6
149
0
3
0
150
0
1
151
0
2
152
0
2
1
153
0
4
154
0
end_DTG
begin_DTG
7
1
287
1
0 4
1
272
1
0 3
1
289
1
0 5
1
298
1
0 6
1
254
1
0 2
1
239
1
0 0
1
244
1
0 1
3
0
7
1
0 1
0
8
1
0 3
0
9
1
0 4
end_DTG
begin_DTG
0
3
0
251
2
0 1
1 0
0
275
2
0 3
1 0
0
287
2
0 4
1 0
end_DTG
begin_DTG
0
3
0
250
2
0 1
1 0
0
274
2
0 3
1 0
0
286
2
0 4
1 0
end_DTG
begin_DTG
0
3
0
245
2
0 1
1 0
0
254
2
0 2
1 0
0
266
2
0 3
1 0
end_DTG
begin_DTG
7
1
270
1
0 3
1
300
1
0 6
1
294
1
0 5
1
285
1
0 4
1
237
1
0 0
1
261
1
0 2
1
249
1
0 1
5
0
2
1
0 0
0
3
1
0 2
0
4
1
0 3
0
5
1
0 4
0
6
1
0 5
end_DTG
begin_DTG
0
7
0
237
2
0 0
5 0
0
246
2
0 1
5 0
0
255
2
0 2
5 0
0
267
2
0 3
5 0
0
276
2
0 4
5 0
0
288
2
0 5
5 0
0
297
2
0 6
5 0
end_DTG
begin_DTG
0
3
0
243
2
0 1
5 0
0
252
2
0 2
5 0
0
264
2
0 3
5 0
end_DTG
begin_DTG
1
5
125
0
3
3
126
0
5
127
0
6
128
0
2
3
129
0
5
130
0
2
1
131
0
2
132
0
1
6
133
0
3
0
134
0
1
135
0
2
136
0
2
1
137
0
4
138
0
end_DTG
begin_DTG
1
5
113
0
3
3
114
0
5
115
0
6
116
0
1
5
117
0
1
1
118
0
1
6
119
0
3
0
120
0
1
121
0
2
122
0
2
1
123
0
4
124
0
end_DTG
begin_DTG
7
1
212
1
9 4
1
209
1
9 3
1
222
1
9 5
1
231
1
9 6
1
179
1
9 1
1
187
1
9 2
1
176
1
9 0
2
0
0
1
9 4
0
1
1
9 5
end_DTG
begin_DTG
0
3
0
185
2
9 1
10 0
0
209
2
9 3
10 0
0
221
2
9 4
10 0
end_DTG
begin_DTG
0
10
0
30
2
9 2
11 0
0
31
2
9 3
11 0
0
32
2
9 4
11 0
0
33
2
9 5
11 0
0
34
2
9 6
11 0
0
55
2
0 2
2 0
0
56
2
0 3
2 0
0
57
2
0 4
2 0
0
58
2
0 5
2 0
0
59
2
0 6
2 0
end_DTG
begin_DTG
0
3
0
184
2
9 1
10 0
0
208
2
9 3
10 0
0
220
2
9 4
10 0
end_DTG
begin_DTG
0
10
0
25
2
9 2
13 0
0
26
2
9 3
13 0
0
27
2
9 4
13 0
0
28
2
9 5
13 0
0
29
2
9 6
13 0
0
50
2
0 2
3 0
0
51
2
0 3
3 0
0
52
2
0 4
3 0
0
53
2
0 5
3 0
0
54
2
0 6
3 0
end_DTG
begin_DTG
0
7
0
171
2
9 0
10 0
0
180
2
9 1
10 0
0
189
2
9 2
10 0
0
201
2
9 3
10 0
0
210
2
9 4
10 0
0
222
2
9 5
10 0
0
231
2
9 6
10 0
end_DTG
begin_DTG
0
10
0
20
2
9 2
15 0
0
21
2
9 3
15 0
0
22
2
9 4
15 0
0
23
2
9 5
15 0
0
24
2
9 6
15 0
0
45
2
0 2
6 0
0
46
2
0 3
6 0
0
47
2
0 4
6 0
0
48
2
0 5
6 0
0
49
2
0 6
6 0
end_DTG
begin_DTG
0
3
0
179
2
9 1
10 0
0
188
2
9 2
10 0
0
200
2
9 3
10 0
end_DTG
begin_DTG
0
10
0
15
2
9 2
17 0
0
16
2
9 3
17 0
0
17
2
9 4
17 0
0
18
2
9 5
17 0
0
19
2
9 6
17 0
0
40
2
0 2
4 0
0
41
2
0 3
4 0
0
42
2
0 4
4 0
0
43
2
0 5
4 0
0
44
2
0 6
4 0
end_DTG
begin_DTG
0
3
0
177
2
9 1
10 0
0
186
2
9 2
10 0
0
198
2
9 3
10 0
end_DTG
begin_DTG
0
10
0
10
2
9 2
19 0
0
11
2
9 3
19 0
0
12
2
9 4
19 0
0
13
2
9 5
19 0
0
14
2
9 6
19 0
0
35
2
0 2
7 0
0
36
2
0 3
7 0
0
37
2
0 4
7 0
0
38
2
0 5
7 0
0
39
2
0 6
7 0
end_DTG
begin_DTG
2
1
155
2
9 1
29 0
2
160
2
8 1
25 0
0
0
end_DTG
begin_DTG
2
1
156
2
9 2
29 0
2
161
2
8 2
25 0
0
0
end_DTG
begin_DTG
2
1
157
2
9 4
29 0
2
162
2
8 4
25 0
0
0
end_DTG
begin_DTG
2
1
158
2
9 5
29 0
2
163
2
8 5
25 0
0
0
end_DTG
begin_DTG
5
1
160
2
8 1
21 0
1
161
2
8 2
22 0
1
162
2
8 4
23 0
1
163
2
8 5
24 0
1
164
2
8 6
26 0
1
0
111
0
end_DTG
begin_DTG
2
1
159
2
9 6
29 0
2
164
2
8 6
25 0
0
0
end_DTG
begin_DTG
2
1
165
2
9 1
29 0
2
168
2
0 1
30 0
0
0
end_DTG
begin_DTG
2
1
166
2
9 3
29 0
2
169
2
0 3
30 0
0
0
end_DTG
begin_DTG
8
1
155
2
9 1
21 0
1
156
2
9 2
22 0
1
157
2
9 4
23 0
1
158
2
9 5
24 0
1
159
2
9 6
26 0
1
165
2
9 1
27 0
1
166
2
9 3
28 0
1
167
2
9 4
31 0
1
0
110
0
end_DTG
begin_DTG
3
1
168
2
0 1
27 0
1
169
2
0 3
28 0
1
170
2
0 4
31 0
1
0
112
0
end_DTG
begin_DTG
2
1
167
2
9 4
29 0
2
170
2
0 4
30 0
0
0
end_DTG
begin_DTG
0
10
0
90
2
9 2
31 1
0
91
2
9 3
31 1
0
92
2
9 4
31 1
0
93
2
9 5
31 1
0
94
2
9 6
31 1
0
105
2
0 2
31 2
0
106
2
0 3
31 2
0
107
2
0 4
31 2
0
108
2
0 5
31 2
0
109
2
0 6
31 2
end_DTG
begin_DTG
0
10
0
85
2
9 2
28 1
0
86
2
9 3
28 1
0
87
2
9 4
28 1
0
88
2
9 5
28 1
0
89
2
9 6
28 1
0
100
2
0 2
28 2
0
101
2
0 3
28 2
0
102
2
0 4
28 2
0
103
2
0 5
28 2
0
104
2
0 6
28 2
end_DTG
begin_DTG
0
10
0
80
2
9 2
27 1
0
81
2
9 3
27 1
0
82
2
9 4
27 1
0
83
2
9 5
27 1
0
84
2
9 6
27 1
0
95
2
0 2
27 2
0
96
2
0 3
27 2
0
97
2
0 4
27 2
0
98
2
0 5
27 2
0
99
2
0 6
27 2
end_DTG
begin_DTG
0
10
0
65
2
9 2
23 1
0
66
2
9 3
23 1
0
67
2
9 4
23 1
0
68
2
9 5
23 1
0
69
2
9 6
23 1
0
75
2
8 2
23 2
0
76
2
8 3
23 2
0
77
2
8 4
23 2
0
78
2
8 5
23 2
0
79
2
8 6
23 2
end_DTG
begin_DTG
0
10
0
60
2
9 2
21 1
0
61
2
9 3
21 1
0
62
2
9 4
21 1
0
63
2
9 5
21 1
0
64
2
9 6
21 1
0
70
2
8 2
21 2
0
71
2
8 3
21 2
0
72
2
8 4
21 2
0
73
2
8 5
21 2
0
74
2
8 6
21 2
end_DTG
begin_CG
19
27 1
28 1
31 1
5 27
1 47
20 5
18 5
16 5
14 5
12 5
34 5
33 5
32 5
30 3
7 3
4 3
6 7
3 3
2 3
3
4 3
3 3
2 3
1
12 5
1
14 5
1
18 5
2
7 3
6 7
1
16 5
1
20 5
8
21 1
22 1
23 1
24 1
26 1
36 5
35 5
25 5
25
21 1
22 1
23 1
24 1
26 1
27 1
28 1
31 1
10 68
20 5
18 5
16 5
14 5
12 5
36 5
35 5
34 5
33 5
32 5
29 8
19 3
17 3
15 7
13 3
11 3
5
19 3
17 3
15 7
13 3
11 3
1
12 5
0
1
14 5
0
1
16 5
0
1
18 5
0
1
20 5
0
3
36 10
29 1
25 1
2
29 1
25 1
3
35 10
29 1
25 1
2
29 1
25 1
5
21 1
22 1
23 1
24 1
26 1
2
29 1
25 1
3
34 10
29 1
30 1
3
33 10
29 1
30 1
8
21 1
22 1
23 1
24 1
26 1
27 1
28 1
31 1
3
27 1
28 1
31 1
3
32 10
29 1
30 1
0
0
0
0
0
end_CG
