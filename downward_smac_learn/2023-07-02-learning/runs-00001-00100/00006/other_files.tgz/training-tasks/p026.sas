begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var4
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var22
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
end_variable
begin_variable
var2
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var3
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
end_variable
begin_variable
var17
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var14
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
0
begin_state
1
1
1
1
1
1
0
0
0
0
1
end_state
begin_goal
3
3 0
5 0
10 0
end_goal
57
begin_operator
calibrate rover1 camera1 objective3 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint1 waypoint4
2
0 0
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint2 waypoint4
2
0 1
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint3 waypoint4
2
0 2
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint5 waypoint4
2
0 4
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint1 waypoint4
2
0 0
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint2 waypoint4
2
0 1
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint3 waypoint4
2
0 2
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint5 waypoint4
2
0 4
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint1 waypoint4
2
0 0
6 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint2 waypoint4
2
0 1
6 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint3 waypoint4
2
0 2
6 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint2 waypoint5 waypoint4
2
0 4
6 1
1
0 10 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 9 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 0 0 1
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 0 0 2
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint5
0
1
0 0 0 4
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint1
0
1
0 0 1 0
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint4
0
1
0 0 1 3
0
end_operator
begin_operator
navigate rover1 waypoint3 waypoint1
0
1
0 0 2 0
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint2
0
1
0 0 3 1
0
end_operator
begin_operator
navigate rover1 waypoint4 waypoint5
0
1
0 0 3 4
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint1
0
1
0 0 4 0
0
end_operator
begin_operator
navigate rover1 waypoint5 waypoint4
0
1
0 0 4 3
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint2
1
0 1
2
0 6 0 1
0 9 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint1
1
0 0
2
0 7 0 1
0 9 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint5
1
0 4
2
0 8 0 1
0 9 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective2 camera1 colour
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective2 camera1 high_res
1
0 0
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective2 camera1 low_res
1
0 0
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 colour
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 high_res
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 low_res
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 colour
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 high_res
1
0 1
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 low_res
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 colour
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 high_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 colour
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 high_res
1
0 3
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective2 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 colour
1
0 3
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 high_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 colour
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 high_res
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 low_res
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 colour
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 high_res
1
0 4
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective2 camera1 low_res
1
0 4
1
0 1 0 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 6
check 3
14
15
16
check 0
check 1
9
switch 7
check 0
switch 9
check 0
check 1
25
check 0
check 0
check 0
switch 1
check 0
check 6
27
28
29
30
31
32
check 0
switch 4
check 0
check 1
1
check 0
switch 2
check 0
check 1
5
check 0
check 0
switch 6
check 2
17
18
switch 9
check 0
check 1
24
check 0
check 0
check 1
10
switch 1
check 0
check 6
33
34
35
36
37
38
check 0
switch 4
check 0
check 1
2
check 0
switch 2
check 0
check 1
6
check 0
check 0
switch 6
check 1
19
check 0
check 1
11
switch 1
check 0
check 3
39
40
41
check 0
switch 4
check 0
check 1
3
check 0
switch 2
check 0
check 1
7
check 0
check 0
switch 6
check 3
0
20
21
check 0
check 0
switch 1
check 0
check 9
42
43
44
45
46
47
48
49
50
check 0
check 0
switch 6
check 2
22
23
check 0
check 1
12
switch 8
check 0
switch 9
check 0
check 1
26
check 0
check 0
check 0
switch 1
check 0
check 6
51
52
53
54
55
56
check 0
switch 4
check 0
check 1
4
check 0
switch 2
check 0
check 1
8
check 0
check 0
switch 9
check 0
check 0
check 1
13
check 0
end_SG
begin_DTG
3
1
14
0
2
15
0
4
16
0
2
0
17
0
3
18
0
1
0
19
0
2
1
20
0
4
21
0
2
0
22
0
3
23
0
end_DTG
begin_DTG
5
1
42
1
0 3
1
56
1
0 4
1
27
1
0 0
1
41
1
0 2
1
38
1
0 1
1
0
0
1
0 3
end_DTG
begin_DTG
0
1
0
48
2
0 3
1 0
end_DTG
begin_DTG
0
4
0
5
2
0 0
2 0
0
6
2
0 1
2 0
0
7
2
0 2
2 0
0
8
2
0 4
2 0
end_DTG
begin_DTG
0
4
0
31
2
0 0
1 0
0
37
2
0 1
1 0
0
46
2
0 3
1 0
0
55
2
0 4
1 0
end_DTG
begin_DTG
0
4
0
1
2
0 0
4 0
0
2
2
0 1
4 0
0
3
2
0 2
4 0
0
4
2
0 4
4 0
end_DTG
begin_DTG
1
1
24
2
0 1
9 0
0
end_DTG
begin_DTG
1
1
25
2
0 0
9 0
0
end_DTG
begin_DTG
1
1
26
2
0 4
9 0
0
end_DTG
begin_DTG
3
1
24
2
0 1
6 0
1
25
2
0 0
7 0
1
26
2
0 4
8 0
1
0
13
0
end_DTG
begin_DTG
0
4
0
9
2
0 0
6 1
0
10
2
0 1
6 1
0
11
2
0 2
6 1
0
12
2
0 4
6 1
end_DTG
begin_CG
10
6 1
7 1
8 1
1 31
5 4
3 4
10 4
9 3
4 4
2 1
2
4 4
2 1
1
3 4
0
1
5 4
0
2
10 4
9 1
1
9 1
1
9 1
3
6 1
7 1
8 1
0
end_CG
