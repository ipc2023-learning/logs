begin_version
3
end_version
begin_metric
0
end_metric
62
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
end_variable
begin_variable
var41
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var34
-1
2
Atom communicated_rock_data(waypoint8)
NegatedAtom communicated_rock_data(waypoint8)
end_variable
begin_variable
var33
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover2, objective7, low_res)
NegatedAtom have_image(rover2, objective7, low_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover2, objective7, high_res)
NegatedAtom have_image(rover2, objective7, high_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover2, objective7, colour)
NegatedAtom have_image(rover2, objective7, colour)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var59
-1
2
Atom have_image(rover2, objective6, low_res)
NegatedAtom have_image(rover2, objective6, low_res)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover2, objective6, high_res)
NegatedAtom have_image(rover2, objective6, high_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var57
-1
2
Atom have_image(rover2, objective6, colour)
NegatedAtom have_image(rover2, objective6, colour)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var55
-1
2
Atom have_image(rover2, objective5, high_res)
NegatedAtom have_image(rover2, objective5, high_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var51
-1
2
Atom have_image(rover2, objective4, colour)
NegatedAtom have_image(rover2, objective4, colour)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var50
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_varia




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
0
297
2
6 3
8 0
0
294
2
6 3
9 0
0
275
2
6 2
7 0
0
273
2
6 2
8 0
0
270
2
6 2
9 0
0
251
2
6 1
7 0
0
249
2
6 1
8 0
0
246
2
6 1
9 0
0
227
2
6 0
7 0
0
225
2
6 0
8 0
end_DTG
begin_DTG
0
4
0
69
2
6 0
26 0
0
70
2
6 2
26 0
0
71
2
6 3
26 0
0
72
2
6 6
26 0
end_DTG
begin_DTG
0
2
0
242
2
6 1
9 0
0
266
2
6 2
9 0
end_DTG
begin_DTG
0
4
0
65
2
6 0
28 0
0
66
2
6 2
28 0
0
67
2
6 3
28 0
0
68
2
6 6
28 0
end_DTG
begin_DTG
0
4
0
241
2
6 1
9 0
0
244
2
6 1
8 0
0
265
2
6 2
9 0
0
268
2
6 2
8 0
end_DTG
begin_DTG
0
4
0
61
2
6 0
30 0
0
62
2
6 2
30 0
0
63
2
6 3
30 0
0
64
2
6 6
30 0
end_DTG
begin_DTG
0
6
0
240
2
6 1
9 0
0
243
2
6 1
8 0
0
245
2
6 1
7 0
0
264
2
6 2
9 0
0
267
2
6 2
8 0
0
269
2
6 2
7 0
end_DTG
begin_DTG
0
4
0
57
2
6 0
32 0
0
58
2
6 2
32 0
0
59
2
6 3
32 0
0
60
2
6 6
32 0
end_DTG
begin_DTG
0
2
0
218
2
6 0
9 0
0
368
2
6 6
9 0
end_DTG
begin_DTG
0
4
0
53
2
6 0
34 0
0
54
2
6 2
34 0
0
55
2
6 3
34 0
0
56
2
6 6
34 0
end_DTG
begin_DTG
0
4
0
217
2
6 0
9 0
0
220
2
6 0
8 0
0
367
2
6 6
9 0
0
370
2
6 6
8 0
end_DTG
begin_DTG
0
4
0
49
2
6 0
36 0
0
50
2
6 2
36 0
0
51
2
6 3
36 0
0
52
2
6 6
36 0
end_DTG
begin_DTG
0
6
0
216
2
6 0
9 0
0
219
2
6 0
8 0
0
221
2
6 0
7 0
0
366
2
6 6
9 0
0
369
2
6 6
8 0
0
371
2
6 6
7 0
end_DTG
begin_DTG
0
4
0
45
2
6 0
38 0
0
46
2
6 2
38 0
0
47
2
6 3
38 0
0
48
2
6 6
38 0
end_DTG
begin_DTG
0
6
0
260
2
6 2
9 0
0
290
2
6 3
9 0
0
314
2
6 4
9 0
0
332
2
6 5
9 0
0
362
2
6 6
9 0
0
392
2
6 7
9 0
end_DTG
begin_DTG
0
4
0
41
2
6 0
40 0
0
42
2
6 2
40 0
0
43
2
6 3
40 0
0
44
2
6 6
40 0
end_DTG
begin_DTG
0
12
0
259
2
6 2
9 0
0
262
2
6 2
8 0
0
289
2
6 3
9 0
0
292
2
6 3
8 0
0
313
2
6 4
9 0
0
316
2
6 4
8 0
0
331
2
6 5
9 0
0
334
2
6 5
8 0
0
361
2
6 6
9 0
0
364
2
6 6
8 0
0
391
2
6 7
9 0
0
394
2
6 7
8 0
end_DTG
begin_DTG
0
4
0
37
2
6 0
42 0
0
38
2
6 2
42 0
0
39
2
6 3
42 0
0
40
2
6 6
42 0
end_DTG
begin_DTG
0
18
0
330
2
6 5
9 0
0
395
2
6 7
7 0
0
393
2
6 7
8 0
0
390
2
6 7
9 0
0
365
2
6 6
7 0
0
363
2
6 6
8 0
0
360
2
6 6
9 0
0
335
2
6 5
7 0
0
333
2
6 5
8 0
0
258
2
6 2
9 0
0
317
2
6 4
7 0
0
315
2
6 4
8 0
0
312
2
6 4
9 0
0
293
2
6 3
7 0
0
291
2
6 3
8 0
0
288
2
6 3
9 0
0
263
2
6 2
7 0
0
261
2
6 2
8 0
end_DTG
begin_DTG
0
4
0
33
2
6 0
44 0
0
34
2
6 2
44 0
0
35
2
6 3
44 0
0
36
2
6 6
44 0
end_DTG
begin_DTG
0
6
0
212
2
6 0
9 0
0
236
2
6 1
9 0
0
284
2
6 3
9 0
0
308
2
6 4
9 0
0
356
2
6 6
9 0
0
386
2
6 7
9 0
end_DTG
begin_DTG
0
4
0
29
2
6 0
46 0
0
30
2
6 2
46 0
0
31
2
6 3
46 0
0
32
2
6 6
46 0
end_DTG
begin_DTG
0
12
0
211
2
6 0
9 0
0
214
2
6 0
8 0
0
235
2
6 1
9 0
0
238
2
6 1
8 0
0
283
2
6 3
9 0
0
286
2
6 3
8 0
0
307
2
6 4
9 0
0
310
2
6 4
8 0
0
355
2
6 6
9 0
0
358
2
6 6
8 0
0
385
2
6 7
9 0
0
388
2
6 7
8 0
end_DTG
begin_DTG
0
4
0
25
2
6 0
48 0
0
26
2
6 2
48 0
0
27
2
6 3
48 0
0
28
2
6 6
48 0
end_DTG
begin_DTG
0
18
0
306
2
6 4
9 0
0
389
2
6 7
7 0
0
387
2
6 7
8 0
0
384
2
6 7
9 0
0
359
2
6 6
7 0
0
357
2
6 6
8 0
0
354
2
6 6
9 0
0
311
2
6 4
7 0
0
309
2
6 4
8 0
0
210
2
6 0
9 0
0
287
2
6 3
7 0
0
285
2
6 3
8 0
0
282
2
6 3
9 0
0
239
2
6 1
7 0
0
237
2
6 1
8 0
0
234
2
6 1
9 0
0
215
2
6 0
7 0
0
213
2
6 0
8 0
end_DTG
begin_DTG
0
4
0
21
2
6 0
50 0
0
22
2
6 2
50 0
0
23
2
6 3
50 0
0
24
2
6 6
50 0
end_DTG
begin_DTG
2
1
140
0
2
141
0
3
0
142
0
3
143
0
4
144
0
4
0
145
0
3
146
0
4
147
0
7
148
0
4
1
149
0
2
150
0
5
151
0
6
152
0
2
1
153
0
2
154
0
1
3
155
0
2
3
156
0
7
157
0
2
2
158
0
6
159
0
end_DTG
begin_DTG
2
1
202
2
52 0
56 0
2
206
2
6 0
57 0
0
0
end_DTG
begin_DTG
2
1
203
2
52 3
56 0
2
207
2
6 3
57 0
0
0
end_DTG
begin_DTG
2
1
204
2
52 5
56 0
2
208
2
6 5
57 0
0
0
end_DTG
begin_DTG
4
1
202
2
52 0
53 0
1
203
2
52 3
54 0
1
204
2
52 5
55 0
1
205
2
52 7
58 0
1
0
137
0
end_DTG
begin_DTG
4
1
206
2
6 0
53 0
1
207
2
6 3
54 0
1
208
2
6 5
55 0
1
209
2
6 7
58 0
1
0
138
0
end_DTG
begin_DTG
2
1
205
2
52 7
56 0
2
209
2
6 7
57 0
0
0
end_DTG
begin_DTG
0
8
0
121
2
52 0
58 1
0
122
2
52 2
58 1
0
123
2
52 3
58 1
0
124
2
52 6
58 1
0
133
2
6 0
58 2
0
134
2
6 2
58 2
0
135
2
6 3
58 2
0
136
2
6 6
58 2
end_DTG
begin_DTG
0
8
0
117
2
52 0
55 1
0
118
2
52 2
55 1
0
119
2
52 3
55 1
0
120
2
52 6
55 1
0
129
2
6 0
55 2
0
130
2
6 2
55 2
0
131
2
6 3
55 2
0
132
2
6 6
55 2
end_DTG
begin_DTG
0
8
0
113
2
52 0
54 1
0
114
2
52 2
54 1
0
115
2
52 3
54 1
0
116
2
52 6
54 1
0
125
2
6 0
54 2
0
126
2
6 2
54 2
0
127
2
6 3
54 2
0
128
2
6 6
54 2
end_DTG
begin_CG
5
1 1
2 1
5 4
4 4
3 2
2
5 4
3 1
2
4 4
3 1
2
1 1
2 1
0
0
53
53 1
54 1
55 1
58 1
9 108
8 76
7 41
51 4
49 4
47 4
45 4
43 4
41 4
39 4
37 4
35 4
33 4
31 4
29 4
27 4
25 4
23 4
21 4
19 4
17 4
15 4
13 4
11 4
61 4
60 4
59 4
57 4
50 18
48 12
46 6
44 18
42 12
40 6
38 6
36 4
34 2
32 6
30 4
28 2
26 24
24 16
22 8
20 9
18 6
16 3
14 21
12 14
10 7
7
50 6
44 6
38 2
32 2
26 8
20 3
14 7
14
50 6
48 6
44 6
42 6
38 2
36 2
32 2
30 2
26 8
24 8
20 3
18 3
14 7
12 7
21
50 6
48 6
46 6
44 6
42 6
40 6
38 2
36 2
34 2
32 2
30 2
28 2
26 8
24 8
22 8
20 3
18 3
16 3
14 7
12 7
10 7
1
11 4
0
1
13 4
0
1
15 4
0
1
17 4
0
1
19 4
0
1
21 4
0
1
23 4
0
1
25 4
0
1
27 4
0
1
29 4
0
1
31 4
0
1
33 4
0
1
35 4
0
1
37 4
0
1
39 4
0
1
41 4
0
1
43 4
0
1
45 4
0
1
47 4
0
1
49 4
0
1
51 4
0
8
53 1
54 1
55 1
58 1
61 4
60 4
59 4
56 4
2
56 1
57 1
3
61 8
56 1
57 1
3
60 8
56 1
57 1
4
53 1
54 1
55 1
58 1
4
53 1
54 1
55 1
58 1
3
59 8
56 1
57 1
0
0
0
end_CG
