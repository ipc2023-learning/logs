begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var2
-1
7
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover3, waypoint1)
end_variable
begin_variable
var9
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover3, waypoint3)
end_variable
begin_variable
var10
-1
2
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var41
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var39
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var38
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var37
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var6
-1
2
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var7
-1
2
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
end_variable
begin_variable
var40
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var35
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var34
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var33
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover1, objective5, colour)
NegatedAtom have_image(rover1, objective5, colour)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
0
begin_state
5
0
0
0
0
1
1
1
4
0
0
0
0
0
0
1
1
1
3
1
1
1
1
1
1
1
end_state
begin_goal
8
5 0
6 0
7 0
15 0
16 0
17 0
23 0
25 0
end_goal
270
begin_operator
calibrate rover1 camera1 objective4 waypoint2
1
18 1
1
0 21 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective4 waypoint4
1
18 3
1
0 21 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective4 waypoint5
1
18 4
1
0 21 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective5 waypoint1
1
18 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective5 waypoint5
1
18 4
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective5 waypoint6
1
18 5
1
0 20 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint1
1
18 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint2
1
18 1
1
0 19 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint4
1
18 3
1
0 19 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint6
1
18 5
1
0 19 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint7
1
18 6
1
0 19 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint1 waypoint7
2
18 0
24 0
1
0 25 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint3 waypoint7
2
18 2
24 0
1
0 25 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint4 waypoint7
2
18 3
24 0
1
0 25 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective5 colour waypoint1 waypoint7
2
18 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




witch 20
check 0
check 4
224
231
238
245
check 0
switch 19
check 0
check 12
225
226
227
232
233
234
239
240
241
246
247
248
check 0
check 0
switch 8
check 3
10
51
52
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 21
check 0
check 9
249
250
251
256
257
258
263
264
265
check 0
switch 20
check 0
check 3
252
259
266
check 0
switch 19
check 0
check 9
253
254
255
260
261
262
267
268
269
check 0
check 0
switch 8
check 0
switch 0
check 1
53
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
switch 14
check 0
check 1
87
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
17
switch 11
check 0
check 0
check 1
20
switch 12
check 0
check 0
check 1
23
check 0
switch 0
check 4
54
55
56
57
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
switch 14
check 0
check 1
88
check 0
check 0
check 0
check 0
switch 0
check 2
58
59
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
18
switch 11
check 0
check 0
check 1
21
switch 12
check 0
check 0
check 1
24
check 0
switch 0
check 2
60
61
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
19
switch 11
check 0
check 0
check 1
22
switch 12
check 0
check 0
check 1
25
check 0
switch 0
check 2
62
63
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
switch 14
check 0
check 1
89
check 0
check 0
check 0
check 0
switch 0
check 3
64
65
66
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
switch 14
check 0
check 1
90
check 0
check 0
check 0
check 0
switch 0
check 2
67
68
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
switch 14
check 0
check 1
91
check 0
check 0
check 0
check 0
switch 0
check 0
switch 9
check 3
69
70
71
check 0
check 0
switch 1
check 0
switch 4
check 0
check 1
92
check 0
check 0
check 1
26
switch 2
check 0
check 0
check 1
29
switch 3
check 0
check 0
check 1
32
check 0
check 4
72
73
74
75
switch 9
check 3
76
77
78
check 0
check 0
switch 1
check 0
check 0
check 1
27
switch 2
check 0
switch 4
check 0
check 1
93
check 0
check 0
check 1
30
switch 3
check 0
check 0
check 1
33
check 0
switch 9
check 1
79
check 0
check 0
switch 1
check 0
check 0
check 1
28
switch 2
check 0
check 0
check 1
31
switch 3
check 0
check 0
check 1
34
check 0
check 2
80
81
check 3
82
83
84
switch 9
check 2
85
86
check 0
check 0
switch 3
check 0
switch 4
check 0
check 1
94
check 0
check 0
check 0
check 0
switch 14
check 0
check 0
check 1
35
switch 4
check 0
check 0
check 1
36
check 0
end_SG
begin_DTG
3
4
69
0
5
70
0
6
71
0
4
2
72
0
3
73
0
4
74
0
5
75
0
3
1
76
0
5
77
0
6
78
0
1
1
79
0
2
0
80
0
1
81
0
3
0
82
0
1
83
0
2
84
0
2
0
85
0
2
86
0
end_DTG
begin_DTG
1
1
92
2
0 0
4 0
0
end_DTG
begin_DTG
1
1
93
2
0 2
4 0
0
end_DTG
begin_DTG
1
1
94
2
0 6
4 0
0
end_DTG
begin_DTG
3
1
92
2
0 0
1 0
1
93
2
0 2
2 0
1
94
2
0 6
3 0
1
0
36
0
end_DTG
begin_DTG
0
3
0
32
2
0 0
3 1
0
33
2
0 2
3 1
0
34
2
0 3
3 1
end_DTG
begin_DTG
0
3
0
29
2
0 0
2 1
0
30
2
0 2
2 1
0
31
2
0 3
2 1
end_DTG
begin_DTG
0
3
0
26
2
0 0
1 1
0
27
2
0 2
1 1
0
28
2
0 3
1 1
end_DTG
begin_DTG
1
5
53
0
4
2
54
0
3
55
0
4
56
0
5
57
0
2
1
58
0
6
59
0
2
1
60
0
6
61
0
2
1
62
0
5
63
0
3
0
64
0
1
65
0
4
66
0
2
2
67
0
3
68
0
end_DTG
begin_DTG
1
1
87
2
8 0
14 0
0
end_DTG
begin_DTG
1
1
88
2
8 1
14 0
0
end_DTG
begin_DTG
1
1
89
2
8 4
14 0
0
end_DTG
begin_DTG
1
1
90
2
8 5
14 0
0
end_DTG
begin_DTG
1
1
91
2
8 6
14 0
0
end_DTG
begin_DTG
5
1
87
2
8 0
9 0
1
88
2
8 1
10 0
1
89
2
8 4
11 0
1
90
2
8 5
12 0
1
91
2
8 6
13 0
1
0
35
0
end_DTG
begin_DTG
0
3
0
23
2
8 0
12 1
0
24
2
8 2
12 1
0
25
2
8 3
12 1
end_DTG
begin_DTG
0
3
0
20
2
8 0
11 1
0
21
2
8 2
11 1
0
22
2
8 3
11 1
end_DTG
begin_DTG
0
3
0
17
2
8 0
10 1
0
18
2
8 2
10 1
0
19
2
8 3
10 1
end_DTG
begin_DTG
1
5
37
0
4
2
38
0
3
39
0
4
40
0
5
41
0
3
1
42
0
5
43
0
6
44
0
2
1
45
0
6
46
0
1
1
47
0
3
0
48
0
1
49
0
2
50
0
2
2
51
0
3
52
0
end_DTG
begin_DTG
7
1
205
1
18 4
1
226
1
18 5
1
192
1
18 3
1
269
1
18 6
1
120
1
18 0
1
141
1
18 1
1
157
1
18 2
5
0
6
1
18 0
0
7
1
18 1
0
8
1
18 3
0
9
1
18 5
0
10
1
18 6
end_DTG
begin_DTG
7
1
182
1
18 3
1
266
1
18 6
1
245
1
18 5
1
217
1
18 4
1
98
1
18 0
1
154
1
18 2
1
140
1
18 1
3
0
3
1
18 0
0
4
1
18 4
0
5
1
18 5
end_DTG
begin_DTG
7
1
201
1
18 4
1
222
1
18 5
1
188
1
18 3
1
265
1
18 6
1
116
1
18 0
1
137
1
18 1
1
153
1
18 2
3
0
0
1
18 1
0
1
1
18 3
0
2
1
18 4
end_DTG
begin_DTG
0
6
0
109
2
18 0
21 0
0
113
2
18 0
19 0
0
214
2
18 4
21 0
0
218
2
18 4
19 0
0
235
2
18 5
21 0
0
239
2
18 5
19 0
end_DTG
begin_DTG
0
3
0
14
2
18 0
22 0
0
15
2
18 2
22 0
0
16
2
18 3
22 0
end_DTG
begin_DTG
0
9
0
146
2
18 2
21 0
0
147
2
18 2
20 0
0
150
2
18 2
19 0
0
167
2
18 3
21 0
0
168
2
18 3
20 0
0
171
2
18 3
19 0
0
202
2
18 4
21 0
0
203
2
18 4
20 0
0
206
2
18 4
19 0
end_DTG
begin_DTG
0
3
0
11
2
18 0
24 0
0
12
2
18 2
24 0
0
13
2
18 3
24 0
end_DTG
begin_CG
7
1 1
2 1
3 1
7 3
6 3
5 3
4 3
2
7 3
4 1
2
6 3
4 1
2
5 3
4 1
3
1 1
2 1
3 1
0
0
0
9
9 1
10 1
11 1
12 1
13 1
17 3
16 3
15 3
14 5
1
14 1
2
17 3
14 1
2
16 3
14 1
2
15 3
14 1
1
14 1
5
9 1
10 1
11 1
12 1
13 1
0
0
0
7
21 78
20 28
19 80
25 3
23 3
24 9
22 6
2
24 3
22 3
1
24 3
2
24 3
22 3
1
23 3
0
1
25 3
0
end_CG
