begin_version
3
end_version
begin_metric
0
end_metric
35
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover1, objective5, colour)
NegatedAtom have_image(rover1, objective5, colour)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var42
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var33
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var34
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var29
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var28
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var27
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
13
5 0
7 0
9 0
11 0
13 0
15 0
17 0
19 0
21 0
31 0
32 0
33 0
34 0
end_goal
269
begin_operator
calibrate rove




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 1
99
switch 27
check 0
check 0
check 0
check 1
105
switch 30
check 0
check 0
check 0
check 1
111
check 0
switch 28
check 0
check 0
check 1
112
switch 29
check 0
check 0
check 1
113
check 0
end_SG
begin_DTG
2
2
136
0
4
137
0
1
5
138
0
2
0
139
0
4
140
0
2
4
141
0
5
142
0
4
0
143
0
2
144
0
3
145
0
6
146
0
2
1
147
0
3
148
0
1
4
149
0
end_DTG
begin_DTG
2
4
114
0
6
115
0
2
2
116
0
5
117
0
4
1
118
0
3
119
0
4
120
0
6
121
0
3
2
122
0
4
123
0
5
124
0
4
0
125
0
2
126
0
3
127
0
6
128
0
3
1
129
0
3
130
0
6
131
0
4
0
132
0
2
133
0
4
134
0
5
135
0
end_DTG
begin_DTG
7
1
216
1
1 3
1
268
1
1 6
1
248
1
1 5
1
232
1
1 4
1
164
1
1 0
1
208
1
1 2
1
188
1
1 1
7
0
3
1
1 0
0
4
1
1 1
0
5
1
1 2
0
6
1
1 3
0
7
1
1 4
0
8
1
1 5
0
9
1
1 6
end_DTG
begin_DTG
7
1
227
1
1 4
1
241
1
1 5
1
219
1
1 3
1
255
1
1 6
1
174
1
1 1
1
171
1
1 0
1
201
1
1 2
3
0
0
1
1 2
0
1
1
1 5
0
2
1
1 6
end_DTG
begin_DTG
0
5
0
186
2
1 1
3 0
0
206
2
1 2
3 0
0
230
2
1 4
3 0
0
246
2
1 5
3 0
0
266
2
1 6
3 0
end_DTG
begin_DTG
0
6
0
58
2
1 0
4 0
0
59
2
1 1
4 0
0
60
2
1 2
4 0
0
61
2
1 4
4 0
0
62
2
1 5
4 0
0
63
2
1 6
4 0
end_DTG
begin_DTG
0
5
0
185
2
1 1
3 0
0
205
2
1 2
3 0
0
229
2
1 4
3 0
0
245
2
1 5
3 0
0
265
2
1 6
3 0
end_DTG
begin_DTG
0
6
0
52
2
1 0
6 0
0
53
2
1 1
6 0
0
54
2
1 2
6 0
0
55
2
1 4
6 0
0
56
2
1 5
6 0
0
57
2
1 6
6 0
end_DTG
begin_DTG
0
3
0
202
2
1 2
3 0
0
242
2
1 5
3 0
0
262
2
1 6
3 0
end_DTG
begin_DTG
0
6
0
46
2
1 0
8 0
0
47
2
1 1
8 0
0
48
2
1 2
8 0
0
49
2
1 4
8 0
0
50
2
1 5
8 0
0
51
2
1 6
8 0
end_DTG
begin_DTG
0
12
0
171
2
1 0
3 0
0
172
2
1 0
2 0
0
183
2
1 1
3 0
0
184
2
1 1
2 0
0
199
2
1 2
3 0
0
200
2
1 2
2 0
0
219
2
1 3
3 0
0
220
2
1 3
2 0
0
227
2
1 4
3 0
0
228
2
1 4
2 0
0
259
2
1 6
3 0
0
260
2
1 6
2 0
end_DTG
begin_DTG
0
6
0
40
2
1 0
10 0
0
41
2
1 1
10 0
0
42
2
1 2
10 0
0
43
2
1 4
10 0
0
44
2
1 5
10 0
0
45
2
1 6
10 0
end_DTG
begin_DTG
0
6
0
170
2
1 0
3 0
0
182
2
1 1
3 0
0
198
2
1 2
3 0
0
218
2
1 3
3 0
0
226
2
1 4
3 0
0
258
2
1 6
3 0
end_DTG
begin_DTG
0
6
0
34
2
1 0
12 0
0
35
2
1 1
12 0
0
36
2
1 2
12 0
0
37
2
1 4
12 0
0
38
2
1 5
12 0
0
39
2
1 6
12 0
end_DTG
begin_DTG
0
14
0
167
2
1 0
3 0
0
168
2
1 0
2 0
0
179
2
1 1
3 0
0
180
2
1 1
2 0
0
195
2
1 2
3 0
0
196
2
1 2
2 0
0
215
2
1 3
3 0
0
216
2
1 3
2 0
0
223
2
1 4
3 0
0
224
2
1 4
2 0
0
239
2
1 5
3 0
0
240
2
1 5
2 0
0
255
2
1 6
3 0
0
256
2
1 6
2 0
end_DTG
begin_DTG
0
6
0
28
2
1 0
14 0
0
29
2
1 1
14 0
0
30
2
1 2
14 0
0
31
2
1 4
14 0
0
32
2
1 5
14 0
0
33
2
1 6
14 0
end_DTG
begin_DTG
0
7
0
166
2
1 0
3 0
0
178
2
1 1
3 0
0
194
2
1 2
3 0
0
214
2
1 3
3 0
0
222
2
1 4
3 0
0
238
2
1 5
3 0
0
254
2
1 6
3 0
end_DTG
begin_DTG
0
6
0
22
2
1 0
16 0
0
23
2
1 1
16 0
0
24
2
1 2
16 0
0
25
2
1 4
16 0
0
26
2
1 5
16 0
0
27
2
1 6
16 0
end_DTG
begin_DTG
0
6
0
162
2
1 0
3 0
0
174
2
1 1
3 0
0
190
2
1 2
3 0
0
210
2
1 3
3 0
0
234
2
1 5
3 0
0
250
2
1 6
3 0
end_DTG
begin_DTG
0
6
0
16
2
1 0
18 0
0
17
2
1 1
18 0
0
18
2
1 2
18 0
0
19
2
1 4
18 0
0
20
2
1 5
18 0
0
21
2
1 6
18 0
end_DTG
begin_DTG
0
6
0
161
2
1 0
3 0
0
173
2
1 1
3 0
0
189
2
1 2
3 0
0
209
2
1 3
3 0
0
233
2
1 5
3 0
0
249
2
1 6
3 0
end_DTG
begin_DTG
0
6
0
10
2
1 0
20 0
0
11
2
1 1
20 0
0
12
2
1 2
20 0
0
13
2
1 4
20 0
0
14
2
1 5
20 0
0
15
2
1 6
20 0
end_DTG
begin_DTG
1
1
158
2
0 1
29 0
0
end_DTG
begin_DTG
1
1
159
2
0 3
29 0
0
end_DTG
begin_DTG
1
1
160
2
0 4
29 0
0
end_DTG
begin_DTG
2
1
150
2
1 0
28 0
2
154
2
0 0
29 0
0
0
end_DTG
begin_DTG
2
1
151
2
1 1
28 0
2
155
2
0 1
29 0
0
0
end_DTG
begin_DTG
2
1
152
2
1 2
28 0
2
156
2
0 2
29 0
0
0
end_DTG
begin_DTG
4
1
150
2
1 0
25 0
1
151
2
1 1
26 0
1
152
2
1 2
27 0
1
153
2
1 3
30 0
1
0
112
0
end_DTG
begin_DTG
7
1
154
2
0 0
25 0
1
155
2
0 1
26 0
1
156
2
0 2
27 0
1
157
2
0 3
30 0
1
158
2
0 1
22 0
1
159
2
0 3
23 0
1
160
2
0 4
24 0
1
0
113
0
end_DTG
begin_DTG
2
1
153
2
1 3
28 0
2
157
2
0 3
29 0
0
0
end_DTG
begin_DTG
0
12
0
82
2
1 0
30 1
0
83
2
1 1
30 1
0
84
2
1 2
30 1
0
85
2
1 4
30 1
0
86
2
1 5
30 1
0
87
2
1 6
30 1
0
106
2
0 0
30 2
0
107
2
0 1
30 2
0
108
2
0 2
30 2
0
109
2
0 4
30 2
0
110
2
0 5
30 2
0
111
2
0 6
30 2
end_DTG
begin_DTG
0
12
0
76
2
1 0
27 1
0
77
2
1 1
27 1
0
78
2
1 2
27 1
0
79
2
1 4
27 1
0
80
2
1 5
27 1
0
81
2
1 6
27 1
0
100
2
0 0
27 2
0
101
2
0 1
27 2
0
102
2
0 2
27 2
0
103
2
0 4
27 2
0
104
2
0 5
27 2
0
105
2
0 6
27 2
end_DTG
begin_DTG
0
12
0
70
2
1 0
26 1
0
71
2
1 1
26 1
0
72
2
1 2
26 1
0
73
2
1 4
26 1
0
74
2
1 5
26 1
0
75
2
1 6
26 1
0
94
2
0 0
26 2
0
95
2
0 1
26 2
0
96
2
0 2
26 2
0
97
2
0 4
26 2
0
98
2
0 5
26 2
0
99
2
0 6
26 2
end_DTG
begin_DTG
0
12
0
64
2
1 0
25 1
0
65
2
1 1
25 1
0
66
2
1 2
25 1
0
67
2
1 4
25 1
0
68
2
1 5
25 1
0
69
2
1 6
25 1
0
88
2
0 0
25 2
0
89
2
0 1
25 2
0
90
2
0 2
25 2
0
91
2
0 4
25 2
0
92
2
0 5
25 2
0
93
2
0 6
25 2
end_DTG
begin_CG
12
25 1
26 1
27 1
30 1
22 1
23 1
24 1
34 6
33 6
32 6
31 6
29 7
29
25 1
26 1
27 1
30 1
3 84
2 34
21 6
19 6
17 6
15 6
13 6
11 6
9 6
7 6
5 6
34 6
33 6
32 6
31 6
28 4
20 6
18 6
16 7
14 14
12 6
10 12
8 3
6 5
4 5
2
14 7
10 6
9
20 6
18 6
16 7
14 7
12 6
10 6
8 3
6 5
4 5
1
5 6
0
1
7 6
0
1
9 6
0
1
11 6
0
1
13 6
0
1
15 6
0
1
17 6
0
1
19 6
0
1
21 6
0
1
29 1
1
29 1
1
29 1
3
34 12
28 1
29 1
3
33 12
28 1
29 1
3
32 12
28 1
29 1
4
25 1
26 1
27 1
30 1
7
25 1
26 1
27 1
30 1
22 1
23 1
24 1
3
31 12
28 1
29 1
0
0
0
0
end_CG
