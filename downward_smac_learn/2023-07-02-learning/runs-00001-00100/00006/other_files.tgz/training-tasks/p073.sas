begin_version
3
end_version
begin_metric
0
end_metric
20
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var6
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var7
-1
2
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover2, waypoint8)
end_variable
begin_variable
var48
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var41
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var65
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover1, objective8, high_res)
NegatedAtom have_image(rover1, objective8, high_res)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective8, high_res)
NegatedAtom communicated_image_data(objective8, high_res)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover1, objective7, low_res)
NegatedAtom have_image(rover1, objective7, low_res)
end_variable
begin_variable
var35
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var67
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
0
begin_state
6
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
5
7 0
12 0
15 0
17 0
19 0
end_goal
236
begin_operator
calibrate rover1 camera1 objective5 waypoint2
1
8 1
1
0 13 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective5 waypoint8
1
8 7
1
0 13 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint2
1
8 1
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective3 waypoint5
1
8 4
1
0 10 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint2
1
8 1
1
0 9 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint5
1
8 4
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 colour waypoint2 waypoint3
2
8 1
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 colour waypoint5 waypoint3
2
8 4
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 colour waypoint6 waypoint3
2
8 5
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 colour waypoint7 waypoint3
2
8 6
11 0
1
0 12 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 low_res waypoint2 waypoint3
2
8 1
18 0
1
0 19 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 low_res waypoint5 waypoint3
2
8 4
18 0
1
0 19 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 low_res waypoint6 waypoint3
2
8 5
18 0
1
0 19 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective6 low_res waypoint7 waypoint3
2
8 6
18 0
1
0 19 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective7 low_res waypoint2 waypoint3
2
8 1
16 0
1
0 17 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective7 low_res waypoint5 waypoint3
2
8 4
16 0
1
0 17 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective7 low_res waypoint6 waypoint3
2
8 5
16 0
1
0 17 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective7 low_res waypoint7 waypoint3
2
8 6
16 0
1
0 17 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective8 high_res waypoint2 waypoi




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





33
34
35
36
switch 0
check 1
37
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 4
117
118
124
125
check 0
switch 10
check 0
check 6
119
120
121
126
127
128
check 0
switch 9
check 0
check 4
122
123
129
130
check 0
check 0
switch 0
check 3
3
5
38
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 12
131
132
138
139
145
146
152
153
159
160
166
167
check 0
switch 10
check 0
check 18
133
134
135
140
141
142
147
148
149
154
155
156
161
162
163
168
169
170
check 0
switch 9
check 0
check 12
136
137
143
144
150
151
157
158
164
165
171
172
check 0
switch 11
check 0
check 1
7
check 0
switch 18
check 0
check 1
11
check 0
switch 16
check 0
check 1
15
check 0
switch 14
check 0
check 1
19
check 0
check 0
switch 0
check 3
39
40
41
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 2
173
174
check 0
switch 10
check 0
check 3
175
176
177
check 0
switch 9
check 0
check 2
178
179
check 0
switch 11
check 0
check 1
8
check 0
switch 18
check 0
check 1
12
check 0
switch 16
check 0
check 1
16
check 0
switch 14
check 0
check 1
20
check 0
check 0
switch 0
check 1
42
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 8
180
181
187
188
194
195
201
202
check 0
switch 10
check 0
check 12
182
183
184
189
190
191
196
197
198
203
204
205
check 0
switch 9
check 0
check 8
185
186
192
193
199
200
206
207
check 0
switch 11
check 0
check 1
9
check 0
switch 18
check 0
check 1
13
check 0
switch 16
check 0
check 1
17
check 0
switch 14
check 0
check 1
21
check 0
check 0
switch 0
check 3
1
43
44
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 8
208
209
215
216
222
223
229
230
check 0
switch 10
check 0
check 12
210
211
212
217
218
219
224
225
226
231
232
233
check 0
switch 9
check 0
check 8
213
214
220
221
227
228
234
235
check 0
check 0
switch 0
check 0
switch 1
check 2
45
46
switch 6
check 0
check 1
63
check 0
check 0
check 0
check 0
switch 1
check 3
47
48
49
check 0
check 0
switch 2
check 0
switch 6
check 0
check 1
64
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
22
check 0
switch 1
check 4
50
51
52
53
check 0
check 0
switch 3
check 0
switch 6
check 0
check 1
65
check 0
check 0
check 0
check 0
check 2
54
55
switch 1
check 1
56
check 0
check 0
switch 3
check 0
check 0
check 1
23
switch 4
check 0
switch 6
check 0
check 1
66
check 0
check 0
check 0
check 0
switch 1
check 4
57
58
59
60
check 0
check 0
switch 3
check 0
check 0
check 1
24
check 0
switch 1
check 1
61
check 0
check 0
switch 3
check 0
check 0
check 1
25
check 0
switch 1
check 1
62
check 0
check 0
switch 5
check 0
switch 6
check 0
check 1
67
check 0
check 0
check 0
check 0
switch 6
check 0
check 0
check 1
26
check 0
end_SG
begin_DTG
2
1
45
0
3
46
0
3
0
47
0
2
48
0
5
49
0
4
1
50
0
4
51
0
5
52
0
6
53
0
2
0
54
0
5
55
0
1
2
56
0
4
1
57
0
2
58
0
3
59
0
7
60
0
1
2
61
0
1
5
62
0
end_DTG
begin_DTG
1
1
63
2
0 0
6 0
0
end_DTG
begin_DTG
1
1
64
2
0 1
6 0
0
end_DTG
begin_DTG
1
1
65
2
0 2
6 0
0
end_DTG
begin_DTG
1
1
66
2
0 4
6 0
0
end_DTG
begin_DTG
1
1
67
2
0 7
6 0
0
end_DTG
begin_DTG
5
1
63
2
0 0
1 0
1
64
2
0 1
2 0
1
65
2
0 2
3 0
1
66
2
0 4
4 0
1
67
2
0 7
5 0
1
0
26
0
end_DTG
begin_DTG
0
4
0
22
2
0 1
3 1
0
23
2
0 4
3 1
0
24
2
0 5
3 1
0
25
2
0 6
3 1
end_DTG
begin_DTG
2
1
27
0
3
28
0
4
0
29
0
2
30
0
5
31
0
7
32
0
4
1
33
0
4
34
0
5
35
0
6
36
0
1
0
37
0
1
2
38
0
3
1
39
0
2
40
0
7
41
0
1
2
42
0
2
1
43
0
5
44
0
end_DTG
begin_DTG
7
1
199
1
8 6
1
158
1
8 4
1
178
1
8 5
1
213
1
8 7
1
115
1
8 1
1
74
1
8 0
1
122
1
8 3
2
0
4
1
8 1
0
5
1
8 4
end_DTG
begin_DTG
7
1
175
1
8 5
1
191
1
8 6
1
170
1
8 4
1
217
1
8 7
1
91
1
8 1
1
86
1
8 0
1
128
1
8 3
2
0
2
1
8 1
0
3
1
8 4
end_DTG
begin_DTG
0
2
0
161
2
8 4
10 0
0
189
2
8 6
10 0
end_DTG
begin_DTG
0
4
0
6
2
8 1
11 0
0
7
2
8 4
11 0
0
8
2
8 5
11 0
0
9
2
8 6
11 0
end_DTG
begin_DTG
7
1
194
1
8 6
1
153
1
8 4
1
173
1
8 5
1
208
1
8 7
1
110
1
8 1
1
69
1
8 0
1
117
1
8 3
2
0
0
1
8 1
0
1
1
8 7
end_DTG
begin_DTG
0
21
0
169
2
8 4
10 0
0
234
2
8 7
9 0
0
232
2
8 7
10 0
0
229
2
8 7
13 0
0
206
2
8 6
9 0
0
204
2
8 6
10 0
0
201
2
8 6
13 0
0
178
2
8 5
9 0
0
176
2
8 5
10 0
0
173
2
8 5
13 0
0
171
2
8 4
9 0
0
82
2
8 0
13 0
0
166
2
8 4
13 0
0
129
2
8 3
9 0
0
127
2
8 3
10 0
0
124
2
8 3
13 0
0
115
2
8 1
9 0
0
113
2
8 1
10 0
0
110
2
8 1
13 0
0
87
2
8 0
9 0
0
85
2
8 0
10 0
end_DTG
begin_DTG
0
4
0
18
2
8 1
14 0
0
19
2
8 4
14 0
0
20
2
8 5
14 0
0
21
2
8 6
14 0
end_DTG
begin_DTG
0
6
0
195
2
8 6
13 0
0
198
2
8 6
10 0
0
200
2
8 6
9 0
0
223
2
8 7
13 0
0
226
2
8 7
10 0
0
228
2
8 7
9 0
end_DTG
begin_DTG
0
4
0
14
2
8 1
16 0
0
15
2
8 4
16 0
0
16
2
8 5
16 0
0
17
2
8 6
16 0
end_DTG
begin_DTG
0
6
0
160
2
8 4
13 0
0
163
2
8 4
10 0
0
165
2
8 4
9 0
0
188
2
8 6
13 0
0
191
2
8 6
10 0
0
193
2
8 6
9 0
end_DTG
begin_DTG
0
4
0
10
2
8 1
18 0
0
11
2
8 4
18 0
0
12
2
8 5
18 0
0
13
2
8 6
18 0
end_DTG
begin_CG
7
1 1
2 1
3 1
4 1
5 1
7 4
6 5
1
6 1
1
6 1
2
7 4
6 1
1
6 1
1
6 1
5
1 1
2 1
3 1
4 1
5 1
0
11
13 50
10 74
9 50
12 4
19 4
17 4
15 4
11 2
18 6
16 6
14 21
3
18 2
16 2
14 7
4
11 2
18 2
16 2
14 7
1
12 4
0
3
18 2
16 2
14 7
1
15 4
0
1
17 4
0
1
19 4
0
end_CG
