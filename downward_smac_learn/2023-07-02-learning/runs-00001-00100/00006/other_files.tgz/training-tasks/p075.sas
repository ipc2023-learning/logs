begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var2
-1
9
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover2, objective8, high_res)
NegatedAtom have_image(rover2, objective8, high_res)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective8, high_res)
NegatedAtom communicated_image_data(objective8, high_res)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover2, objective2, high_res)
NegatedAtom have_image(rover2, objective2, high_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var65
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var3
-1
4
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
Atom have_rock_analysis(rover3, waypoint1)
end_variable
begin_variable
var4
-1
4
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
Atom have_rock_analysis(rover3, waypoint2)
end_variable
begin_variable
var5
-1
4
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var6
-1
4
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var7
-1
4
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover1, waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
Atom have_rock_analysis(rover3, waypoint6)
end_variable
begin_variable
var8
-1
4
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover1, waypoint8)
Atom have_rock_analysis(rover2, waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
end_variable
begin_variable
var9
-1
4
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
Atom have_soil_analysis(rover3, waypoint4)
end_variable
begin_variable
var48
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var49
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var10
-1
4
Atom at_soil_sample(waypoint8)
Atom have_soil_analysis(rover1, waypoint8)
Atom have_soil_analysis(rover2, waypoint8)
Atom have_soil_analysis(rover3, waypoint8)
end_variable
begin_variable
var11
-1
4
Atom at_soil_sample(waypoint9)
Atom have_soil_analysis(rover1, waypoint9)
Atom have_soil_analysis(rover2, waypoint9)
Atom have_soil_analysis(rover3, waypoint9)
end_variable
begin_variable
var50
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var47
-1
2
Atom communicated_soil_data(waypoint9)
NegatedAtom communicated_soil_data(waypoint9)
end_variable
begin_variable
var45
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var44
-1
2
Atom communicated_rock_data(waypoint8)
NegatedAtom communicated_rock_data(waypoint8)
end_variable
begin_variable
var43
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var42
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var41
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var40
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var39
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
7
6
1
1
1
1
1
1
1
1
3
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
end_state
begin_goal
11
4 0
6 0
9 0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




240
0
2
241
0
4
242
0
5
243
0
8
244
0
7
0
245
0
1
246
0
2
247
0
3
248
0
4
249
0
5
250
0
7
251
0
end_DTG
begin_DTG
3
1
322
2
10 0
18 0
2
328
2
1 0
19 0
3
334
2
0 0
22 0
0
0
0
end_DTG
begin_DTG
3
1
323
2
10 1
18 0
2
329
2
1 1
19 0
3
335
2
0 1
22 0
0
0
0
end_DTG
begin_DTG
3
1
324
2
10 2
18 0
2
330
2
1 2
19 0
3
336
2
0 2
22 0
0
0
0
end_DTG
begin_DTG
3
1
325
2
10 3
18 0
2
331
2
1 3
19 0
3
337
2
0 3
22 0
0
0
0
end_DTG
begin_DTG
3
1
326
2
10 5
18 0
2
332
2
1 5
19 0
3
338
2
0 5
22 0
0
0
0
end_DTG
begin_DTG
3
1
327
2
10 7
18 0
2
333
2
1 7
19 0
3
339
2
0 7
22 0
0
0
0
end_DTG
begin_DTG
3
1
340
2
10 3
18 0
2
343
2
1 3
19 0
3
346
2
0 3
22 0
0
0
0
end_DTG
begin_DTG
9
1
322
2
10 0
11 0
1
323
2
10 1
12 0
1
324
2
10 2
13 0
1
325
2
10 3
14 0
1
326
2
10 5
15 0
1
327
2
10 7
16 0
1
340
2
10 3
17 0
1
341
2
10 7
20 0
1
342
2
10 8
21 0
1
0
201
0
end_DTG
begin_DTG
9
1
328
2
1 0
11 0
1
329
2
1 1
12 0
1
330
2
1 2
13 0
1
331
2
1 3
14 0
1
332
2
1 5
15 0
1
333
2
1 7
16 0
1
343
2
1 3
17 0
1
344
2
1 7
20 0
1
345
2
1 8
21 0
1
0
202
0
end_DTG
begin_DTG
3
1
341
2
10 7
18 0
2
344
2
1 7
19 0
3
347
2
0 7
22 0
0
0
0
end_DTG
begin_DTG
3
1
342
2
10 8
18 0
2
345
2
1 8
19 0
3
348
2
0 8
22 0
0
0
0
end_DTG
begin_DTG
9
1
334
2
0 0
11 0
1
335
2
0 1
12 0
1
336
2
0 2
13 0
1
337
2
0 3
14 0
1
338
2
0 5
15 0
1
339
2
0 7
16 0
1
346
2
0 3
17 0
1
347
2
0 7
20 0
1
348
2
0 8
21 0
1
0
203
0
end_DTG
begin_DTG
0
21
0
183
2
1 3
21 2
0
200
2
0 8
21 3
0
199
2
0 5
21 3
0
198
2
0 4
21 3
0
197
2
0 3
21 3
0
196
2
0 2
21 3
0
195
2
0 1
21 3
0
194
2
0 0
21 3
0
186
2
1 8
21 2
0
185
2
1 5
21 2
0
184
2
1 4
21 2
0
166
2
10 0
21 1
0
182
2
1 2
21 2
0
181
2
1 1
21 2
0
180
2
1 0
21 2
0
172
2
10 8
21 1
0
171
2
10 5
21 1
0
170
2
10 4
21 1
0
169
2
10 3
21 1
0
168
2
10 2
21 1
0
167
2
10 1
21 1
end_DTG
begin_DTG
0
21
0
176
2
1 3
17 2
0
193
2
0 8
17 3
0
192
2
0 5
17 3
0
191
2
0 4
17 3
0
190
2
0 3
17 3
0
189
2
0 2
17 3
0
188
2
0 1
17 3
0
187
2
0 0
17 3
0
179
2
1 8
17 2
0
178
2
1 5
17 2
0
177
2
1 4
17 2
0
159
2
10 0
17 1
0
175
2
1 2
17 2
0
174
2
1 1
17 2
0
173
2
1 0
17 2
0
165
2
10 8
17 1
0
164
2
10 5
17 1
0
163
2
10 4
17 1
0
162
2
10 3
17 1
0
161
2
10 2
17 1
0
160
2
10 1
17 1
end_DTG
begin_DTG
0
21
0
113
2
1 3
16 2
0
158
2
0 8
16 3
0
157
2
0 5
16 3
0
156
2
0 4
16 3
0
155
2
0 3
16 3
0
154
2
0 2
16 3
0
153
2
0 1
16 3
0
152
2
0 0
16 3
0
116
2
1 8
16 2
0
115
2
1 5
16 2
0
114
2
1 4
16 2
0
68
2
10 0
16 1
0
112
2
1 2
16 2
0
111
2
1 1
16 2
0
110
2
1 0
16 2
0
74
2
10 8
16 1
0
73
2
10 5
16 1
0
72
2
10 4
16 1
0
71
2
10 3
16 1
0
70
2
10 2
16 1
0
69
2
10 1
16 1
end_DTG
begin_DTG
0
21
0
106
2
1 3
15 2
0
151
2
0 8
15 3
0
150
2
0 5
15 3
0
149
2
0 4
15 3
0
148
2
0 3
15 3
0
147
2
0 2
15 3
0
146
2
0 1
15 3
0
145
2
0 0
15 3
0
109
2
1 8
15 2
0
108
2
1 5
15 2
0
107
2
1 4
15 2
0
61
2
10 0
15 1
0
105
2
1 2
15 2
0
104
2
1 1
15 2
0
103
2
1 0
15 2
0
67
2
10 8
15 1
0
66
2
10 5
15 1
0
65
2
10 4
15 1
0
64
2
10 3
15 1
0
63
2
10 2
15 1
0
62
2
10 1
15 1
end_DTG
begin_DTG
0
21
0
99
2
1 3
14 2
0
144
2
0 8
14 3
0
143
2
0 5
14 3
0
142
2
0 4
14 3
0
141
2
0 3
14 3
0
140
2
0 2
14 3
0
139
2
0 1
14 3
0
138
2
0 0
14 3
0
102
2
1 8
14 2
0
101
2
1 5
14 2
0
100
2
1 4
14 2
0
54
2
10 0
14 1
0
98
2
1 2
14 2
0
97
2
1 1
14 2
0
96
2
1 0
14 2
0
60
2
10 8
14 1
0
59
2
10 5
14 1
0
58
2
10 4
14 1
0
57
2
10 3
14 1
0
56
2
10 2
14 1
0
55
2
10 1
14 1
end_DTG
begin_DTG
0
21
0
92
2
1 3
13 2
0
137
2
0 8
13 3
0
136
2
0 5
13 3
0
135
2
0 4
13 3
0
134
2
0 3
13 3
0
133
2
0 2
13 3
0
132
2
0 1
13 3
0
131
2
0 0
13 3
0
95
2
1 8
13 2
0
94
2
1 5
13 2
0
93
2
1 4
13 2
0
47
2
10 0
13 1
0
91
2
1 2
13 2
0
90
2
1 1
13 2
0
89
2
1 0
13 2
0
53
2
10 8
13 1
0
52
2
10 5
13 1
0
51
2
10 4
13 1
0
50
2
10 3
13 1
0
49
2
10 2
13 1
0
48
2
10 1
13 1
end_DTG
begin_DTG
0
21
0
85
2
1 3
12 2
0
130
2
0 8
12 3
0
129
2
0 5
12 3
0
128
2
0 4
12 3
0
127
2
0 3
12 3
0
126
2
0 2
12 3
0
125
2
0 1
12 3
0
124
2
0 0
12 3
0
88
2
1 8
12 2
0
87
2
1 5
12 2
0
86
2
1 4
12 2
0
40
2
10 0
12 1
0
84
2
1 2
12 2
0
83
2
1 1
12 2
0
82
2
1 0
12 2
0
46
2
10 8
12 1
0
45
2
10 5
12 1
0
44
2
10 4
12 1
0
43
2
10 3
12 1
0
42
2
10 2
12 1
0
41
2
10 1
12 1
end_DTG
begin_DTG
0
21
0
78
2
1 3
11 2
0
123
2
0 8
11 3
0
122
2
0 5
11 3
0
121
2
0 4
11 3
0
120
2
0 3
11 3
0
119
2
0 2
11 3
0
118
2
0 1
11 3
0
117
2
0 0
11 3
0
81
2
1 8
11 2
0
80
2
1 5
11 2
0
79
2
1 4
11 2
0
33
2
10 0
11 1
0
77
2
1 2
11 2
0
76
2
1 1
11 2
0
75
2
1 0
11 2
0
39
2
10 8
11 1
0
38
2
10 5
11 1
0
37
2
10 4
11 1
0
36
2
10 3
11 1
0
35
2
10 2
11 1
0
34
2
10 1
11 1
end_DTG
begin_CG
18
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
21 1
30 7
29 7
28 7
27 7
26 7
25 7
24 7
23 7
22 9
26
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
21 1
7 41
2 79
6 7
9 7
4 7
30 7
29 7
28 7
27 7
26 7
25 7
24 7
23 7
19 9
5 7
8 7
3 4
2
5 7
3 4
1
4 7
0
1
6 7
0
1
8 7
1
9 7
0
18
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
21 1
30 7
29 7
28 7
27 7
26 7
25 7
24 7
23 7
18 9
4
30 21
18 1
19 1
22 1
4
29 21
18 1
19 1
22 1
4
28 21
18 1
19 1
22 1
4
27 21
18 1
19 1
22 1
4
26 21
18 1
19 1
22 1
4
25 21
18 1
19 1
22 1
4
24 21
18 1
19 1
22 1
9
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
21 1
9
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
21 1
3
18 1
19 1
22 1
4
23 21
18 1
19 1
22 1
9
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
21 1
0
0
0
0
0
0
0
0
end_CG
