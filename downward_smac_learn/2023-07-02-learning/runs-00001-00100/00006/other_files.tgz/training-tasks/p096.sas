begin_version
3
end_version
begin_metric
0
end_metric
132
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var20
-1
2
Atom calibrated(camera4, rover4)
NegatedAtom calibrated(camera4, rover4)
end_variable
begin_variable
var162
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var161
-1
2
Atom have_image(rover4, objective7, high_res)
NegatedAtom have_image(rover4, objective7, high_res)
end_variable
begin_variable
var160
-1
2
Atom have_image(rover4, objective7, colour)
NegatedAtom have_image(rover4, objective7, colour)
end_variable
begin_variable
var159
-1
2
Atom have_image(rover4, objective6, high_res)
NegatedAtom have_image(rover4, objective6, high_res)
end_variable
begin_variable
var158
-1
2
Atom have_image(rover4, objective6, colour)
NegatedAtom have_image(rover4, objective6, colour)
end_variable
begin_variable
var155
-1
2
Atom have_image(rover4, objective4, high_res)
NegatedAtom have_image(rover4, objective4, high_res)
end_variable
begin_variable
var154
-1
2
Atom have_image(rover4, objective4, colour)
NegatedAtom have_image(rover4, objective4, colour)
end_variable
begin_variable
var153
-1
2
Atom have_image(rover4, objective3, high_res)
NegatedAtom have_image(rover4, objective3, high_res)
end_variable
begin_variable
var152
-1
2
Atom have_image(rover4, objective3, colour)
NegatedAtom have_image(rover4, objective3, colour)
end_variable
begin_variable
var151
-1
2
Atom have_image(rover4, objective2, high_res)
NegatedAtom have_image(rover4, objective2, high_res)
end_variable
begin_variable
var150
-1
2
Atom have_image(rover4, objective2, colour)
NegatedAtom have_image(rover4, objective2, colour)
end_variable
begin_variable
var149
-1
2
Atom have_image(rover4, objective10, high_res)
NegatedAtom have_image(rover4, objective10, high_res)
end_variable
begin_variable
var148
-1
2
Atom have_image(rover4, objective10, colour)
NegatedAtom have_image(rover4, objective10, colour)
end_variable
begin_variable
var147
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var146
-1
2
Atom have_image(rover4, objective1, colour)
NegatedAtom have_image(rover4, objective1, colour)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var19
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var145
-1
2
Atom have_image(rover3, objective9, low_res)
NegatedAtom have_image(rover3, objective9, low_res)
end_variable
begin_variable
var142
-1
2
Atom have_image(rover3, objective8, low_res)
NegatedAtom have_image(rover3, objective8, low_res)
end_variable
begin_variable
var140
-1
2
Atom have_image(rover3, objective8, colour)
NegatedAtom have_image(rover3, objective8, colour)
end_variable
begin_variable
var139
-1
2
Atom have_image(rover3, objective7, low_res)
NegatedAtom have_image(rover3, objective7, low_res)
end_variable
begin_variable
var138
-1
2
Atom have_image(rover3, objective7, high_res)
NegatedAtom have_image(rover3, objective7, high_res)
end_variable
begin_variable
var137
-1
2
Atom have_image(rover3, objective7, colour)
NegatedAtom have_image(rover3, objective7, colour)
end_variable
begin_variable
var136
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var135
-1
2
Atom have_image(rover3, objective6, high_res)
NegatedAtom have_image(rover3, objective6, high_res)
end_variable
begin_variable
var134
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var130
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var129
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var128
-1
2
Atom have_image(rover3, objective4, colour)
NegatedAtom have_image(rover3, objective4, colour)
end_variable
begin_variable
var127
-1
2
Atom have_image(rover3, objective3, low_res)
NegatedAtom have_image(rover3, objective3, low_res)
end_variable
begin_variable
var126
-1
2
Atom have_image(rover3, objective3, high_res)
NegatedAtom have_image(rover3, objective3, high_res)
end_variable
begin_variable
var125
-1
2
Atom have_image(rover3, objective3, colour)
NegatedAtom have_image(rover3, objective3, colour)
end_variable
begin_variable
var124
-1
2
Atom have_image(rover3, objective2, low_res)
NegatedAtom have_image(rover3, objec




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
539
2
98 7
99 0
0
559
2
98 9
99 0
end_DTG
begin_DTG
0
16
0
39
2
98 0
116 0
0
40
2
98 2
116 0
0
41
2
98 5
116 0
0
42
2
98 7
116 0
0
119
2
42 0
58 0
0
120
2
42 2
58 0
0
121
2
42 5
58 0
0
122
2
42 7
58 0
0
211
2
17 0
30 0
0
212
2
17 2
30 0
0
213
2
17 5
30 0
0
214
2
17 7
30 0
0
291
2
0 0
8 0
0
292
2
0 2
8 0
0
293
2
0 5
8 0
0
294
2
0 7
8 0
end_DTG
begin_DTG
0
3
0
508
2
98 3
99 0
0
524
2
98 5
99 0
0
558
2
98 9
99 0
end_DTG
begin_DTG
0
12
0
35
2
98 0
118 0
0
36
2
98 2
118 0
0
37
2
98 5
118 0
0
38
2
98 7
118 0
0
115
2
42 0
59 0
0
116
2
42 2
59 0
0
117
2
42 5
59 0
0
118
2
42 7
59 0
0
207
2
17 0
31 0
0
208
2
17 2
31 0
0
209
2
17 5
31 0
0
210
2
17 7
31 0
end_DTG
begin_DTG
0
3
0
507
2
98 3
99 0
0
523
2
98 5
99 0
0
557
2
98 9
99 0
end_DTG
begin_DTG
0
16
0
31
2
98 0
120 0
0
32
2
98 2
120 0
0
33
2
98 5
120 0
0
34
2
98 7
120 0
0
107
2
42 0
62 0
0
108
2
42 2
62 0
0
109
2
42 5
62 0
0
110
2
42 7
62 0
0
199
2
17 0
33 0
0
200
2
17 2
33 0
0
201
2
17 5
33 0
0
202
2
17 7
33 0
0
283
2
0 0
10 0
0
284
2
0 2
10 0
0
285
2
0 5
10 0
0
286
2
0 7
10 0
end_DTG
begin_DTG
0
2
0
500
2
98 2
99 0
0
532
2
98 6
99 0
end_DTG
begin_DTG
0
12
0
27
2
98 0
122 0
0
28
2
98 2
122 0
0
29
2
98 5
122 0
0
30
2
98 7
122 0
0
103
2
42 0
63 0
0
104
2
42 2
63 0
0
105
2
42 5
63 0
0
106
2
42 7
63 0
0
195
2
17 0
34 0
0
196
2
17 2
34 0
0
197
2
17 5
34 0
0
198
2
17 7
34 0
end_DTG
begin_DTG
0
2
0
499
2
98 2
99 0
0
531
2
98 6
99 0
end_DTG
begin_DTG
0
16
0
23
2
98 0
124 0
0
24
2
98 2
124 0
0
25
2
98 5
124 0
0
26
2
98 7
124 0
0
95
2
42 0
66 0
0
96
2
42 2
66 0
0
97
2
42 5
66 0
0
98
2
42 7
66 0
0
187
2
17 0
36 0
0
188
2
17 2
36 0
0
189
2
17 5
36 0
0
190
2
17 7
36 0
0
275
2
0 0
12 0
0
276
2
0 2
12 0
0
277
2
0 5
12 0
0
278
2
0 7
12 0
end_DTG
begin_DTG
0
2
0
537
2
98 7
99 0
0
547
2
98 8
99 0
end_DTG
begin_DTG
0
16
0
19
2
98 0
126 0
0
20
2
98 2
126 0
0
21
2
98 5
126 0
0
22
2
98 7
126 0
0
87
2
42 0
69 0
0
88
2
42 2
69 0
0
89
2
42 5
69 0
0
90
2
42 7
69 0
0
179
2
17 0
38 0
0
180
2
17 2
38 0
0
181
2
17 5
38 0
0
182
2
17 7
38 0
0
267
2
0 0
14 0
0
268
2
0 2
14 0
0
269
2
0 5
14 0
0
270
2
0 7
14 0
end_DTG
begin_DTG
0
1
0
506
2
98 3
99 0
end_DTG
begin_DTG
0
12
0
15
2
98 0
128 0
0
16
2
98 2
128 0
0
17
2
98 5
128 0
0
18
2
98 7
128 0
0
83
2
42 0
70 0
0
84
2
42 2
70 0
0
85
2
42 5
70 0
0
86
2
42 7
70 0
0
175
2
17 0
39 0
0
176
2
17 2
39 0
0
177
2
17 5
39 0
0
178
2
17 7
39 0
end_DTG
begin_DTG
0
1
0
505
2
98 3
99 0
end_DTG
begin_DTG
0
16
0
11
2
98 0
130 0
0
12
2
98 2
130 0
0
13
2
98 5
130 0
0
14
2
98 7
130 0
0
75
2
42 0
73 0
0
76
2
42 2
73 0
0
77
2
42 5
73 0
0
78
2
42 7
73 0
0
167
2
17 0
41 0
0
168
2
17 2
41 0
0
169
2
17 5
41 0
0
170
2
17 7
41 0
0
259
2
0 0
16 0
0
260
2
0 2
16 0
0
261
2
0 5
16 0
0
262
2
0 7
16 0
end_DTG
begin_CG
54
80 1
81 1
82 1
83 1
84 1
85 1
88 1
74 1
75 1
76 1
77 1
78 1
79 1
1 87
131 4
72 4
127 4
68 4
125 4
65 4
121 4
61 4
117 4
57 4
113 4
53 4
109 4
49 4
105 4
97 4
96 4
95 4
94 4
93 4
92 4
91 4
90 4
89 4
87 13
16 1
15 1
14 2
13 2
12 2
11 2
10 3
9 3
8 3
7 3
6 10
5 10
4 6
3 6
2 4
15
16 1
15 1
14 2
13 2
12 2
11 2
10 3
9 3
8 3
7 3
6 10
5 10
4 6
3 6
2 4
1
105 4
1
49 4
1
109 4
1
53 4
1
113 4
1
57 4
1
117 4
1
61 4
1
121 4
1
65 4
1
125 4
1
68 4
1
127 4
1
72 4
1
131 4
47
18 129
131 4
72 4
129 4
127 4
68 4
125 4
65 4
123 4
121 4
61 4
119 4
117 4
57 4
115 4
113 4
53 4
111 4
109 4
49 4
107 4
105 4
103 4
101 4
41 1
40 1
39 1
38 2
37 2
36 2
35 2
34 2
33 3
32 3
31 3
30 3
29 3
28 3
27 10
26 10
25 10
24 6
23 6
22 6
21 4
20 4
19 9
23
41 1
40 1
39 1
38 2
37 2
36 2
35 2
34 2
33 3
32 3
31 3
30 3
29 3
28 3
27 10
26 10
25 10
24 6
23 6
22 6
21 4
20 4
19 9
1
101 4
1
103 4
1
105 4
1
107 4
1
49 4
1
109 4
1
111 4
1
53 4
1
113 4
1
115 4
1
57 4
1
117 4
1
119 4
1
61 4
1
121 4
1
123 4
1
65 4
1
125 4
1
68 4
1
127 4
1
129 4
1
72 4
1
131 4
62
80 1
81 1
82 1
83 1
84 1
85 1
88 1
43 129
131 4
72 4
129 4
127 4
68 4
125 4
65 4
123 4
121 4
61 4
119 4
117 4
57 4
115 4
113 4
53 4
111 4
109 4
49 4
107 4
105 4
103 4
101 4
97 4
96 4
95 4
94 4
93 4
92 4
91 4
86 7
73 1
71 1
70 1
69 2
67 2
66 2
64 2
63 2
62 3
60 3
59 3
58 3
56 3
55 3
54 10
52 10
51 10
50 6
48 6
47 6
46 4
45 4
44 9
23
73 1
71 1
70 1
69 2
67 2
66 2
64 2
63 2
62 3
60 3
59 3
58 3
56 3
55 3
54 10
52 10
51 10
50 6
48 6
47 6
46 4
45 4
44 9
1
101 4
1
103 4
1
105 4
1
107 4
1
49 4
0
1
109 4
1
111 4
1
53 4
0
1
113 4
1
115 4
1
57 4
0
1
117 4
1
119 4
1
61 4
0
1
121 4
1
123 4
1
65 4
0
1
125 4
1
68 4
0
1
127 4
1
129 4
1
72 4
0
1
131 4
1
87 1
1
87 1
2
90 4
87 1
1
87 1
1
87 1
2
89 4
87 1
3
97 8
86 1
87 1
3
96 8
86 1
87 1
3
95 8
86 1
87 1
3
94 8
86 1
87 1
3
93 8
86 1
87 1
3
92 8
86 1
87 1
7
80 1
81 1
82 1
83 1
84 1
85 1
88 1
13
80 1
81 1
82 1
83 1
84 1
85 1
88 1
74 1
75 1
76 1
77 1
78 1
79 1
3
91 8
86 1
87 1
0
0
0
0
0
0
0
0
0
33
99 86
131 4
129 4
127 4
125 4
123 4
121 4
119 4
117 4
115 4
113 4
111 4
109 4
107 4
105 4
103 4
101 4
130 1
128 1
126 2
124 2
122 2
120 3
118 3
116 3
114 3
112 10
110 10
108 6
106 6
104 4
102 4
100 9
16
130 1
128 1
126 2
124 2
122 2
120 3
118 3
116 3
114 3
112 10
110 10
108 6
106 6
104 4
102 4
100 9
1
101 4
0
1
103 4
0
1
105 4
0
1
107 4
0
1
109 4
0
1
111 4
0
1
113 4
0
1
115 4
0
1
117 4
0
1
119 4
0
1
121 4
0
1
123 4
0
1
125 4
0
1
127 4
0
1
129 4
0
1
131 4
0
end_CG
