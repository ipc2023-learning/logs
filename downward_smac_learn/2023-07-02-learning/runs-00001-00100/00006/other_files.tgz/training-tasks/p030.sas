begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var4
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var25
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var23
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var22
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var21
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var8
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var20
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var7
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var19
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var6
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var18
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var5
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
end_variable
begin_variable
var2
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var3
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
end_variable
begin_variable
var17
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var16
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var14
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
0
begin_state
2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
1
1
end_state
begin_goal
10
3 0
5 0
7 0
9 0
11 0
13 0
15 0
17 0
22 0
23 0
end_goal
52
begin_operator
calibrate rover1 camera1 objective1 waypoint3
1
0 2
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint4
1
0 3
1
0 1 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective1 waypoint5
1
0 4
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint3 waypoint4
2
0 2
16 0
1
0 17 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint3 waypoint4
2
0 2
14 0
1
0 15 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint3 waypoint4
2
0 2
12 0
1
0 13 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint3 waypoint4
2
0 2
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint3 waypoint4
2
0 2
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint3 waypoint4
2
0 2
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 colour waypoint3 waypoint4
2
0 2
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective3 high_res waypoint3 waypoint4
2
0 2
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint5 waypoint3 waypoint4
2
0 2
18 1
1
0 23 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint4 waypoint3 waypoint4
2
0 2
20 1
1
0 22 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 21 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 0 0 1
0
end_operator
begin_operator
nav




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ator
begin_operator
take_image rover1 waypoint2 objective2 camera1 high_res
1
0 1
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 low_res
1
0 1
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective3 camera1 colour
1
0 1
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective3 camera1 high_res
1
0 1
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective3 camera1 low_res
1
0 1
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 colour
1
0 2
2
0 1 0 1
0 16 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 high_res
1
0 2
2
0 1 0 1
0 14 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
2
0 1 0 1
0 12 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective3 camera1 colour
1
0 2
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective3 camera1 high_res
1
0 2
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective3 camera1 low_res
1
0 2
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
2
0 1 0 1
0 16 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
2
0 1 0 1
0 14 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
2
0 1 0 1
0 12 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 colour
1
0 3
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 high_res
1
0 3
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective3 camera1 low_res
1
0 3
1
0 1 0 1
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 colour
1
0 4
2
0 1 0 1
0 16 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 high_res
1
0 4
2
0 1 0 1
0 14 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective1 camera1 low_res
1
0 4
2
0 1 0 1
0 12 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera1 colour
1
0 4
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera1 high_res
1
0 4
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint5 objective3 camera1 low_res
1
0 4
1
0 1 0 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 18
check 1
14
check 0
check 0
switch 19
check 0
switch 21
check 0
check 1
23
check 0
check 0
check 0
switch 1
check 0
check 3
25
26
27
check 0
check 0
switch 18
check 2
15
16
check 0
check 0
switch 1
check 0
check 6
28
29
30
31
32
33
check 0
check 0
switch 18
check 4
0
17
18
19
check 0
check 1
11
switch 20
check 0
check 0
check 1
12
switch 1
check 0
check 6
34
35
36
37
38
39
check 0
switch 16
check 0
check 1
3
check 0
switch 14
check 0
check 1
4
check 0
switch 12
check 0
check 1
5
check 0
switch 10
check 0
check 1
6
check 0
switch 8
check 0
check 1
7
check 0
switch 6
check 0
check 1
8
check 0
switch 4
check 0
check 1
9
check 0
switch 2
check 0
check 1
10
check 0
check 0
switch 18
check 2
1
20
check 0
check 0
switch 20
check 0
switch 21
check 0
check 1
24
check 0
check 0
check 0
switch 1
check 0
check 6
40
41
42
43
44
45
check 0
check 0
switch 18
check 2
2
21
switch 21
check 0
check 1
22
check 0
check 0
check 0
switch 1
check 0
check 6
46
47
48
49
50
51
check 0
check 0
switch 21
check 0
check 0
check 1
13
check 0
end_SG
begin_DTG
1
1
14
0
2
0
15
0
2
16
0
3
1
17
0
3
18
0
4
19
0
1
2
20
0
1
2
21
0
end_DTG
begin_DTG
5
1
38
1
0 2
1
51
1
0 4
1
45
1
0 3
1
25
1
0 0
1
33
1
0 1
3
0
0
1
0 2
0
1
1
0 3
0
2
1
0 4
end_DTG
begin_DTG
0
5
0
26
2
0 0
1 0
0
32
2
0 1
1 0
0
38
2
0 2
1 0
0
44
2
0 3
1 0
0
50
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
10
2
0 2
2 0
end_DTG
begin_DTG
0
5
0
25
2
0 0
1 0
0
31
2
0 1
1 0
0
37
2
0 2
1 0
0
43
2
0 3
1 0
0
49
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
9
2
0 2
4 0
end_DTG
begin_DTG
0
1
0
30
2
0 1
1 0
end_DTG
begin_DTG
0
1
0
8
2
0 2
6 0
end_DTG
begin_DTG
0
1
0
29
2
0 1
1 0
end_DTG
begin_DTG
0
1
0
7
2
0 2
8 0
end_DTG
begin_DTG
0
1
0
28
2
0 1
1 0
end_DTG
begin_DTG
0
1
0
6
2
0 2
10 0
end_DTG
begin_DTG
0
3
0
36
2
0 2
1 0
0
42
2
0 3
1 0
0
48
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
5
2
0 2
12 0
end_DTG
begin_DTG
0
3
0
35
2
0 2
1 0
0
41
2
0 3
1 0
0
47
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
4
2
0 2
14 0
end_DTG
begin_DTG
0
3
0
34
2
0 2
1 0
0
40
2
0 3
1 0
0
46
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
3
2
0 2
16 0
end_DTG
begin_DTG
1
1
22
2
0 4
21 0
0
end_DTG
begin_DTG
1
1
23
2
0 0
21 0
0
end_DTG
begin_DTG
1
1
24
2
0 3
21 0
0
end_DTG
begin_DTG
3
1
22
2
0 4
18 0
1
23
2
0 0
19 0
1
24
2
0 3
20 0
1
0
13
0
end_DTG
begin_DTG
0
1
0
12
2
0 2
20 1
end_DTG
begin_DTG
0
1
0
11
2
0 2
18 1
end_DTG
begin_CG
23
18 1
19 1
20 1
1 30
17 1
15 1
13 1
11 1
9 1
7 1
5 1
3 1
23 1
22 1
21 3
16 3
14 3
12 3
10 1
8 1
6 1
4 5
2 5
8
16 3
14 3
12 3
10 1
8 1
6 1
4 5
2 5
1
3 1
0
1
5 1
0
1
7 1
0
1
9 1
0
1
11 1
0
1
13 1
0
1
15 1
0
1
17 1
0
2
23 1
21 1
1
21 1
2
22 1
21 1
3
18 1
19 1
20 1
0
0
end_CG
