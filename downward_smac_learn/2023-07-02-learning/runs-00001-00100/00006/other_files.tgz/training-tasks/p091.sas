begin_version
3
end_version
begin_metric
0
end_metric
72
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera4, rover4)
NegatedAtom calibrated(camera4, rover4)
end_variable
begin_variable
var106
-1
2
Atom have_image(rover4, objective9, high_res)
NegatedAtom have_image(rover4, objective9, high_res)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover4, objective7, high_res)
NegatedAtom have_image(rover4, objective7, high_res)
end_variable
begin_variable
var98
-1
2
Atom have_image(rover4, objective5, high_res)
NegatedAtom have_image(rover4, objective5, high_res)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover4, objective4, high_res)
NegatedAtom have_image(rover4, objective4, high_res)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover4, objective3, high_res)
NegatedAtom have_image(rover4, objective3, high_res)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover4, objective2, high_res)
NegatedAtom have_image(rover4, objective2, high_res)
end_variable
begin_variable
var90
-1
2
Atom have_image(rover4, objective10, high_res)
NegatedAtom have_image(rover4, objective10, high_res)
end_variable
begin_variable
var88
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover4)
NegatedAtom calibrated(camera1, rover4)
end_variable
begin_variable
var105
-1
2
Atom have_image(rover4, objective8, low_res)
NegatedAtom have_image(rover4, objective8, low_res)
end_variable
begin_variable
var103
-1
2
Atom have_image(rover4, objective7, low_res)
NegatedAtom have_image(rover4, objective7, low_res)
end_variable
begin_variable
var101
-1
2
Atom have_image(rover4, objective6, low_res)
NegatedAtom have_image(rover4, objective6, low_res)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover4, objective4, low_res)
NegatedAtom have_image(rover4, objective4, low_res)
end_variable
begin_variable
var93
-1
2
Atom have_image(rover4, objective2, low_res)
NegatedAtom have_image(rover4, objective2, low_res)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover4, objective1, low_res)
NegatedAtom have_image(rover4, objective1, low_res)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover3)
NegatedAtom calibrated(camera3, rover3)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover3, objective9, high_res)
NegatedAtom have_image(rover3, objective9, high_res)
end_variable
begin_variable
var44
-1
2
Atom communicated_image_data(objective9, high_res)
NegatedAtom communicated_image_data(objective9, high_res)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover3, objective8, low_res)
NegatedAtom have_image(rover3, objective8, low_res)
end_variable
begin_variable
var42
-1
2
Atom communicated_image_data(objective8, low_res)
NegatedAtom communicated_image_data(objective8, low_res)
end_variable
begin_variable
var81
-1
2
Atom have_image(rover3, objective7, low_res)
NegatedAtom have_image(rover3, objective7, low_res)
end_variable
begin_variable
var39
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var80
-1
2
Atom have_image(rover3, objective7, high_res)
NegatedAtom have_image(rover3, objective7, high_res)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover3, objective6, low_res)
NegatedAtom have_image(rover3, objective6, low_res)
end_variable
begin_variable
var36
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover3, objective5, high_res)
NegatedAtom have_image(rover3, objective5, high_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var71
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
0
end_DTG
begin_DTG
2
1
550
2
55 2
61 0
2
552
2
17 2
65 0
0
0
end_DTG
begin_DTG
2
1
551
2
55 5
61 0
2
553
2
17 5
65 0
0
0
end_DTG
begin_DTG
4
1
554
2
55 0
61 0
2
560
2
54 0
62 0
3
566
2
17 0
65 0
4
572
2
0 0
66 0
0
0
0
0
end_DTG
begin_DTG
4
1
555
2
55 2
61 0
2
561
2
54 2
62 0
3
567
2
17 2
65 0
4
573
2
0 2
66 0
0
0
0
0
end_DTG
begin_DTG
4
1
556
2
55 4
61 0
2
562
2
54 4
62 0
3
568
2
17 4
65 0
4
574
2
0 4
66 0
0
0
0
0
end_DTG
begin_DTG
8
1
550
2
55 2
56 0
1
551
2
55 5
57 0
1
554
2
55 0
58 0
1
555
2
55 2
59 0
1
556
2
55 4
60 0
1
557
2
55 5
63 0
1
558
2
55 6
64 0
1
559
2
55 9
67 0
1
0
402
0
end_DTG
begin_DTG
6
1
560
2
54 0
58 0
1
561
2
54 2
59 0
1
562
2
54 4
60 0
1
563
2
54 5
63 0
1
564
2
54 6
64 0
1
565
2
54 9
67 0
1
0
403
0
end_DTG
begin_DTG
4
1
557
2
55 5
61 0
2
563
2
54 5
62 0
3
569
2
17 5
65 0
4
575
2
0 5
66 0
0
0
0
0
end_DTG
begin_DTG
4
1
558
2
55 6
61 0
2
564
2
54 6
62 0
3
570
2
17 6
65 0
4
576
2
0 6
66 0
0
0
0
0
end_DTG
begin_DTG
8
1
552
2
17 2
56 0
1
553
2
17 5
57 0
1
566
2
17 0
58 0
1
567
2
17 2
59 0
1
568
2
17 4
60 0
1
569
2
17 5
63 0
1
570
2
17 6
64 0
1
571
2
17 9
67 0
1
0
404
0
end_DTG
begin_DTG
6
1
572
2
0 0
58 0
1
573
2
0 2
59 0
1
574
2
0 4
60 0
1
575
2
0 5
63 0
1
576
2
0 6
64 0
1
577
2
0 9
67 0
1
0
405
0
end_DTG
begin_DTG
4
1
559
2
55 9
61 0
2
565
2
54 9
62 0
3
571
2
17 9
65 0
4
577
2
0 9
66 0
0
0
0
0
end_DTG
begin_DTG
0
32
0
362
2
17 0
67 3
0
401
2
0 9
67 4
0
400
2
0 8
67 4
0
399
2
0 6
67 4
0
398
2
0 5
67 4
0
397
2
0 4
67 4
0
396
2
0 3
67 4
0
395
2
0 2
67 4
0
394
2
0 0
67 4
0
369
2
17 9
67 3
0
368
2
17 8
67 3
0
367
2
17 6
67 3
0
366
2
17 5
67 3
0
365
2
17 4
67 3
0
364
2
17 3
67 3
0
363
2
17 2
67 3
0
298
2
55 0
67 1
0
337
2
54 9
67 2
0
336
2
54 8
67 2
0
335
2
54 6
67 2
0
334
2
54 5
67 2
0
333
2
54 4
67 2
0
332
2
54 3
67 2
0
331
2
54 2
67 2
0
330
2
54 0
67 2
0
305
2
55 9
67 1
0
304
2
55 8
67 1
0
303
2
55 6
67 1
0
302
2
55 5
67 1
0
301
2
55 4
67 1
0
300
2
55 3
67 1
0
299
2
55 2
67 1
end_DTG
begin_DTG
0
32
0
354
2
17 0
60 3
0
393
2
0 9
60 4
0
392
2
0 8
60 4
0
391
2
0 6
60 4
0
390
2
0 5
60 4
0
389
2
0 4
60 4
0
388
2
0 3
60 4
0
387
2
0 2
60 4
0
386
2
0 0
60 4
0
361
2
17 9
60 3
0
360
2
17 8
60 3
0
359
2
17 6
60 3
0
358
2
17 5
60 3
0
357
2
17 4
60 3
0
356
2
17 3
60 3
0
355
2
17 2
60 3
0
290
2
55 0
60 1
0
329
2
54 9
60 2
0
328
2
54 8
60 2
0
327
2
54 6
60 2
0
326
2
54 5
60 2
0
325
2
54 4
60 2
0
324
2
54 3
60 2
0
323
2
54 2
60 2
0
322
2
54 0
60 2
0
297
2
55 9
60 1
0
296
2
55 8
60 1
0
295
2
55 6
60 1
0
294
2
55 5
60 1
0
293
2
55 4
60 1
0
292
2
55 3
60 1
0
291
2
55 2
60 1
end_DTG
begin_DTG
0
32
0
346
2
17 0
59 3
0
385
2
0 9
59 4
0
384
2
0 8
59 4
0
383
2
0 6
59 4
0
382
2
0 5
59 4
0
381
2
0 4
59 4
0
380
2
0 3
59 4
0
379
2
0 2
59 4
0
378
2
0 0
59 4
0
353
2
17 9
59 3
0
352
2
17 8
59 3
0
351
2
17 6
59 3
0
350
2
17 5
59 3
0
349
2
17 4
59 3
0
348
2
17 3
59 3
0
347
2
17 2
59 3
0
282
2
55 0
59 1
0
321
2
54 9
59 2
0
320
2
54 8
59 2
0
319
2
54 6
59 2
0
318
2
54 5
59 2
0
317
2
54 4
59 2
0
316
2
54 3
59 2
0
315
2
54 2
59 2
0
314
2
54 0
59 2
0
289
2
55 9
59 1
0
288
2
55 8
59 1
0
287
2
55 6
59 1
0
286
2
55 5
59 1
0
285
2
55 4
59 1
0
284
2
55 3
59 1
0
283
2
55 2
59 1
end_DTG
begin_DTG
0
32
0
338
2
17 0
58 3
0
377
2
0 9
58 4
0
376
2
0 8
58 4
0
375
2
0 6
58 4
0
374
2
0 5
58 4
0
373
2
0 4
58 4
0
372
2
0 3
58 4
0
371
2
0 2
58 4
0
370
2
0 0
58 4
0
345
2
17 9
58 3
0
344
2
17 8
58 3
0
343
2
17 6
58 3
0
342
2
17 5
58 3
0
341
2
17 4
58 3
0
340
2
17 3
58 3
0
339
2
17 2
58 3
0
274
2
55 0
58 1
0
313
2
54 9
58 2
0
312
2
54 8
58 2
0
311
2
54 6
58 2
0
310
2
54 5
58 2
0
309
2
54 4
58 2
0
308
2
54 3
58 2
0
307
2
54 2
58 2
0
306
2
54 0
58 2
0
281
2
55 9
58 1
0
280
2
55 8
58 1
0
279
2
55 6
58 1
0
278
2
55 5
58 1
0
277
2
55 4
58 1
0
276
2
55 3
58 1
0
275
2
55 2
58 1
end_DTG
begin_CG
41
58 1
59 1
60 1
63 1
64 1
67 1
10 71
1 134
46 8
44 8
42 8
40 8
38 8
36 8
34 8
32 8
30 8
28 8
26 8
24 8
22 8
20 8
71 8
70 8
69 8
68 8
66 6
9 5
16 10
8 4
7 10
15 20
6 3
5 9
14 18
4 5
13 6
3 10
12 20
11 20
2 6
14
9 5
16 5
8 4
7 10
15 10
6 3
5 9
14 9
4 5
13 3
3 10
12 10
11 10
2 6
1
20 8
1
26 8
1
30 8
1
34 8
1
36 8
1
40 8
1
42 8
1
46 8
6
16 5
15 10
14 9
13 3
12 10
11 10
1
22 8
1
24 8
1
28 8
1
32 8
1
38 8
1
44 8
49
56 1
57 1
58 1
59 1
60 1
63 1
64 1
67 1
47 75
18 201
46 8
44 8
42 8
40 8
38 8
53 8
36 8
34 8
32 8
30 8
51 8
28 8
49 8
26 8
24 8
22 8
20 8
71 8
70 8
69 8
68 8
65 8
45 5
43 5
41 4
39 10
37 10
52 6
35 3
33 9
31 9
29 5
50 6
27 3
48 20
25 10
23 10
21 10
19 6
17
45 5
43 5
41 4
39 10
37 10
52 3
35 3
33 9
31 9
29 5
50 3
27 3
48 10
25 10
23 10
21 10
19 6
1
20 8
0
1
22 8
0
1
24 8
0
1
26 8
0
1
28 8
0
1
30 8
0
1
32 8
0
1
34 8
0
1
36 8
0
1
38 8
0
1
40 8
0
1
42 8
0
1
44 8
0
1
46 8
0
3
52 3
50 3
48 10
1
49 8
0
1
51 8
0
1
53 8
0
11
58 1
59 1
60 1
63 1
64 1
67 1
71 8
70 8
69 8
68 8
62 6
13
56 1
57 1
58 1
59 1
60 1
63 1
64 1
67 1
71 8
70 8
69 8
68 8
61 8
2
61 1
65 1
2
61 1
65 1
5
71 32
61 1
62 1
65 1
66 1
5
70 32
61 1
62 1
65 1
66 1
5
69 32
61 1
62 1
65 1
66 1
8
56 1
57 1
58 1
59 1
60 1
63 1
64 1
67 1
6
58 1
59 1
60 1
63 1
64 1
67 1
4
61 1
62 1
65 1
66 1
4
61 1
62 1
65 1
66 1
8
56 1
57 1
58 1
59 1
60 1
63 1
64 1
67 1
6
58 1
59 1
60 1
63 1
64 1
67 1
5
68 32
61 1
62 1
65 1
66 1
0
0
0
0
end_CG
