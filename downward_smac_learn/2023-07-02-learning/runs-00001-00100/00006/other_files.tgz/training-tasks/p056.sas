begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var2
-1
7
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
end_variable
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera2, rover2)
NegatedAtom calibrated(camera2, rover2)
end_variable
begin_variable
var51
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var39
-1
2
Atom have_image(rover2, objective1, low_res)
NegatedAtom have_image(rover2, objective1, low_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var49
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover2, objective4, high_res)
NegatedAtom have_image(rover2, objective4, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var40
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var34
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
Atom have_rock_analysis(rover3, waypoint1)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
Atom have_rock_analysis(rover3, waypoint5)
end_variable
begin_variable
var35
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var36
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var6
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var32
-1
2
Atom communicated_rock_data(waypoint7)
NegatedAtom communicated_rock_data(waypoint7)
end_variable
begin_variable
var31
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var30
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var29
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
5
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
4
0
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
10
5 0
7 0
10 0
12 0
14 0
16 0
26 0
27 0
28 0
29 0
end_goal
221
begin_operator
calibrate rover2 camera1 objective5 waypoint1
1
1 0
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover2 camera1 objective5 waypoint7
1
1 6
1
0 8 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint2
1
1 1
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera2 objective1 waypoint5
1
1 4
1
0 3 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective6 waypoint1
1
1 0
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective6 waypoint2
1
1 1
1
0 2 -1 0
0
end_operator
begin_operator
calibrate rover2 camera3 objective6 waypoint3
1
1 2
1
0 2 -1 0
0
end_operator
begin_operator
calibrate 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




heck 0
switch 13
check 0
check 1
24
check 0
switch 11
check 0
check 1
29
check 0
switch 9
check 0
check 1
34
check 0
switch 4
check 0
check 1
39
check 0
check 0
switch 0
check 0
switch 20
check 3
111
112
113
switch 24
check 0
check 1
127
check 0
check 0
check 0
check 0
check 0
switch 20
check 1
114
check 0
check 0
check 1
60
switch 21
check 0
check 0
check 0
check 1
65
switch 22
check 0
check 0
check 0
check 1
70
switch 25
check 0
check 0
check 0
check 1
75
check 0
check 1
115
switch 20
check 3
116
117
118
check 0
check 0
check 1
61
switch 21
check 0
switch 24
check 0
check 1
128
check 0
check 0
check 0
check 1
66
switch 22
check 0
check 0
check 0
check 1
71
switch 25
check 0
check 0
check 0
check 1
76
check 0
switch 20
check 2
119
120
check 0
check 0
check 1
62
switch 21
check 0
check 0
check 0
check 1
67
switch 22
check 0
switch 24
check 0
check 1
129
check 0
check 0
check 0
check 1
72
switch 25
check 0
check 0
check 0
check 1
77
check 0
switch 20
check 1
121
check 0
check 0
check 1
63
switch 21
check 0
check 0
check 0
check 1
68
switch 22
check 0
check 0
check 0
check 1
73
switch 25
check 0
check 0
check 0
check 1
78
check 0
switch 20
check 1
122
check 0
check 0
check 1
64
switch 21
check 0
check 0
check 0
check 1
69
switch 22
check 0
check 0
check 0
check 1
74
switch 25
check 0
switch 24
check 0
check 1
130
check 0
check 0
check 0
check 1
79
check 0
switch 18
check 0
check 0
check 1
80
switch 23
check 0
check 0
check 1
81
switch 24
check 0
check 0
check 1
82
check 0
end_SG
begin_DTG
3
3
111
0
4
112
0
6
113
0
1
3
114
0
1
3
115
0
3
0
116
0
1
117
0
2
118
0
2
0
119
0
5
120
0
1
4
121
0
1
0
122
0
end_DTG
begin_DTG
3
3
95
0
4
96
0
6
97
0
1
3
98
0
2
3
99
0
4
100
0
4
0
101
0
1
102
0
2
103
0
5
104
0
3
0
105
0
2
106
0
5
107
0
2
3
108
0
4
109
0
1
0
110
0
end_DTG
begin_DTG
7
1
180
1
1 3
1
220
1
1 6
1
212
1
1 5
1
200
1
1 4
1
136
1
1 0
1
172
1
1 2
1
164
1
1 1
6
0
4
1
1 0
0
5
1
1 1
0
6
1
1 2
0
7
1
1 3
0
8
1
1 4
0
9
1
1 5
end_DTG
begin_DTG
7
1
179
1
1 3
1
219
1
1 6
1
211
1
1 5
1
199
1
1 4
1
135
1
1 0
1
171
1
1 2
1
163
1
1 1
2
0
2
1
1 1
0
3
1
1 4
end_DTG
begin_DTG
0
4
0
143
2
1 0
3 0
0
144
2
1 0
2 0
0
219
2
1 6
3 0
0
220
2
1 6
2 0
end_DTG
begin_DTG
0
5
0
35
2
1 1
4 0
0
36
2
1 3
4 0
0
37
2
1 4
4 0
0
38
2
1 5
4 0
0
39
2
1 6
4 0
end_DTG
begin_DTG
0
4
0
151
2
1 1
3 0
0
152
2
1 1
2 0
0
183
2
1 4
3 0
0
184
2
1 4
2 0
end_DTG
begin_DTG
0
5
0
10
2
1 1
6 0
0
11
2
1 3
6 0
0
12
2
1 4
6 0
0
13
2
1 5
6 0
0
14
2
1 6
6 0
end_DTG
begin_DTG
7
1
198
1
1 4
1
178
1
1 3
1
201
1
1 5
1
213
1
1 6
1
154
1
1 1
1
134
1
1 0
1
165
1
1 2
2
0
0
1
1 0
0
1
1
1 6
end_DTG
begin_DTG
0
2
0
141
2
1 0
8 0
0
217
2
1 6
8 0
end_DTG
begin_DTG
0
5
0
30
2
1 1
9 0
0
31
2
1 3
9 0
0
32
2
1 4
9 0
0
33
2
1 5
9 0
0
34
2
1 6
9 0
end_DTG
begin_DTG
0
4
0
138
2
1 0
8 0
0
158
2
1 1
8 0
0
194
2
1 4
8 0
0
206
2
1 5
8 0
end_DTG
begin_DTG
0
5
0
25
2
1 1
11 0
0
26
2
1 3
11 0
0
27
2
1 4
11 0
0
28
2
1 5
11 0
0
29
2
1 6
11 0
end_DTG
begin_DTG
0
1
0
189
2
1 4
8 0
end_DTG
begin_DTG
0
5
0
20
2
1 1
13 0
0
21
2
1 3
13 0
0
22
2
1 4
13 0
0
23
2
1 5
13 0
0
24
2
1 6
13 0
end_DTG
begin_DTG
0
7
0
133
2
1 0
8 0
0
153
2
1 1
8 0
0
165
2
1 2
8 0
0
173
2
1 3
8 0
0
185
2
1 4
8 0
0
201
2
1 5
8 0
0
213
2
1 6
8 0
end_DTG
begin_DTG
0
5
0
15
2
1 1
15 0
0
16
2
1 3
15 0
0
17
2
1 4
15 0
0
18
2
1 5
15 0
0
19
2
1 6
15 0
end_DTG
begin_DTG
3
3
83
0
4
84
0
6
85
0
1
3
86
0
1
3
87
0
3
0
88
0
1
89
0
2
90
0
2
0
91
0
5
92
0
1
4
93
0
1
0
94
0
end_DTG
begin_DTG
1
1
131
2
17 0
19 0
1
0
80
0
end_DTG
begin_DTG
2
1
131
2
17 0
18 0
2
132
2
1 0
23 0
0
0
end_DTG
begin_DTG
2
1
123
2
1 0
23 0
2
127
2
0 0
24 0
0
0
end_DTG
begin_DTG
2
1
124
2
1 3
23 0
2
128
2
0 3
24 0
0
0
end_DTG
begin_DTG
2
1
125
2
1 4
23 0
2
129
2
0 4
24 0
0
0
end_DTG
begin_DTG
5
1
123
2
1 0
20 0
1
124
2
1 3
21 0
1
125
2
1 4
22 0
1
126
2
1 6
25 0
1
132
2
1 0
19 0
1
0
81
0
end_DTG
begin_DTG
4
1
127
2
0 0
20 0
1
128
2
0 3
21 0
1
129
2
0 4
22 0
1
130
2
0 6
25 0
1
0
82
0
end_DTG
begin_DTG
2
1
126
2
1 6
23 0
2
130
2
0 6
24 0
0
0
end_DTG
begin_DTG
0
10
0
55
2
1 1
25 1
0
56
2
1 3
25 1
0
57
2
1 4
25 1
0
58
2
1 5
25 1
0
59
2
1 6
25 1
0
75
2
0 1
25 2
0
76
2
0 3
25 2
0
77
2
0 4
25 2
0
78
2
0 5
25 2
0
79
2
0 6
25 2
end_DTG
begin_DTG
0
10
0
50
2
1 1
22 1
0
51
2
1 3
22 1
0
52
2
1 4
22 1
0
53
2
1 5
22 1
0
54
2
1 6
22 1
0
70
2
0 1
22 2
0
71
2
0 3
22 2
0
72
2
0 4
22 2
0
73
2
0 5
22 2
0
74
2
0 6
22 2
end_DTG
begin_DTG
0
10
0
45
2
1 1
21 1
0
46
2
1 3
21 1
0
47
2
1 4
21 1
0
48
2
1 5
21 1
0
49
2
1 6
21 1
0
65
2
0 1
21 2
0
66
2
0 3
21 2
0
67
2
0 4
21 2
0
68
2
0 5
21 2
0
69
2
0 6
21 2
end_DTG
begin_DTG
0
10
0
40
2
1 1
20 1
0
41
2
1 3
20 1
0
42
2
1 4
20 1
0
43
2
1 5
20 1
0
44
2
1 6
20 1
0
60
2
0 1
20 2
0
61
2
0 3
20 2
0
62
2
0 4
20 2
0
63
2
0 5
20 2
0
64
2
0 6
20 2
end_DTG
begin_CG
9
20 1
21 1
22 1
25 1
29 5
28 5
27 5
26 5
24 4
25
20 1
21 1
22 1
25 1
19 1
8 46
3 24
2 28
7 5
16 5
14 5
12 5
10 5
5 5
29 5
28 5
27 5
26 5
23 5
6 4
15 7
13 1
11 4
9 2
4 4
2
6 2
4 2
2
6 2
4 2
1
5 5
0
1
7 5
0
4
15 7
13 1
11 4
9 2
1
10 5
0
1
12 5
0
1
14 5
0
1
16 5
0
2
19 1
18 1
1
19 1
2
18 1
23 1
3
29 10
23 1
24 1
3
28 10
23 1
24 1
3
27 10
23 1
24 1
5
20 1
21 1
22 1
25 1
19 1
4
20 1
21 1
22 1
25 1
3
26 10
23 1
24 1
0
0
0
0
end_CG
