begin_version
3
end_version
begin_metric
0
end_metric
54
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var60
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1, objective3, low_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective3, low_res)
NegatedAtom communicated_image_data(objective3, low_res)
end_variable
begin_variable
var57
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var54
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var71
-1
2
Atom have_image(rover1, objective7, high_res)
NegatedAtom have_image(rover1, objective7, high_res)
end_variable
begin_variable
var36
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover1, objective6, high_res)
NegatedAtom have_image(rover1, objective6, high_res)
end_variable
begin_variable
var33
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var65
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var59
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var55
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variab




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




_DTG
0
6
0
272
2
2 3
15 0
0
274
2
2 3
14 0
0
275
2
2 3
3 0
0
302
2
2 5
15 0
0
304
2
2 5
14 0
0
305
2
2 5
3 0
end_DTG
begin_DTG
0
3
0
52
2
2 0
18 0
0
53
2
2 4
18 0
0
54
2
2 6
18 0
end_DTG
begin_DTG
0
3
0
266
2
2 3
15 0
0
268
2
2 3
14 0
0
269
2
2 3
3 0
end_DTG
begin_DTG
0
3
0
46
2
2 0
20 0
0
47
2
2 4
20 0
0
48
2
2 6
20 0
end_DTG
begin_DTG
0
9
0
206
2
2 1
15 0
0
208
2
2 1
14 0
0
209
2
2 1
3 0
0
260
2
2 3
15 0
0
262
2
2 3
14 0
0
263
2
2 3
3 0
0
284
2
2 4
15 0
0
286
2
2 4
14 0
0
287
2
2 4
3 0
end_DTG
begin_DTG
0
3
0
40
2
2 0
22 0
0
41
2
2 4
22 0
0
42
2
2 6
22 0
end_DTG
begin_DTG
0
15
0
188
2
2 0
15 0
0
190
2
2 0
14 0
0
191
2
2 0
3 0
0
230
2
2 2
15 0
0
232
2
2 2
14 0
0
233
2
2 2
3 0
0
254
2
2 3
15 0
0
256
2
2 3
14 0
0
257
2
2 3
3 0
0
296
2
2 5
15 0
0
298
2
2 5
14 0
0
299
2
2 5
3 0
0
326
2
2 6
15 0
0
328
2
2 6
14 0
0
329
2
2 6
3 0
end_DTG
begin_DTG
0
3
0
34
2
2 0
24 0
0
35
2
2 4
24 0
0
36
2
2 6
24 0
end_DTG
begin_DTG
0
21
0
250
2
2 3
14 0
0
323
2
2 6
3 0
0
322
2
2 6
14 0
0
320
2
2 6
15 0
0
293
2
2 5
3 0
0
292
2
2 5
14 0
0
290
2
2 5
15 0
0
281
2
2 4
3 0
0
280
2
2 4
14 0
0
278
2
2 4
15 0
0
251
2
2 3
3 0
0
182
2
2 0
15 0
0
248
2
2 3
15 0
0
227
2
2 2
3 0
0
226
2
2 2
14 0
0
224
2
2 2
15 0
0
203
2
2 1
3 0
0
202
2
2 1
14 0
0
200
2
2 1
15 0
0
185
2
2 0
3 0
0
184
2
2 0
14 0
end_DTG
begin_DTG
0
3
0
28
2
2 0
26 0
0
29
2
2 4
26 0
0
30
2
2 6
26 0
end_DTG
begin_DTG
0
14
0
181
2
2 0
15 0
0
183
2
2 0
14 0
0
199
2
2 1
15 0
0
201
2
2 1
14 0
0
223
2
2 2
15 0
0
225
2
2 2
14 0
0
247
2
2 3
15 0
0
249
2
2 3
14 0
0
277
2
2 4
15 0
0
279
2
2 4
14 0
0
289
2
2 5
15 0
0
291
2
2 5
14 0
0
319
2
2 6
15 0
0
321
2
2 6
14 0
end_DTG
begin_DTG
0
3
0
25
2
2 0
28 0
0
26
2
2 4
28 0
0
27
2
2 6
28 0
end_DTG
begin_DTG
0
18
0
242
2
2 3
15 0
0
335
2
2 7
3 0
0
334
2
2 7
14 0
0
332
2
2 7
15 0
0
317
2
2 6
3 0
0
316
2
2 6
14 0
0
314
2
2 6
15 0
0
245
2
2 3
3 0
0
244
2
2 3
14 0
0
176
2
2 0
15 0
0
221
2
2 2
3 0
0
220
2
2 2
14 0
0
218
2
2 2
15 0
0
197
2
2 1
3 0
0
196
2
2 1
14 0
0
194
2
2 1
15 0
0
179
2
2 0
3 0
0
178
2
2 0
14 0
end_DTG
begin_DTG
0
3
0
19
2
2 0
30 0
0
20
2
2 4
30 0
0
21
2
2 6
30 0
end_DTG
begin_DTG
0
12
0
175
2
2 0
15 0
0
177
2
2 0
14 0
0
193
2
2 1
15 0
0
195
2
2 1
14 0
0
217
2
2 2
15 0
0
219
2
2 2
14 0
0
241
2
2 3
15 0
0
243
2
2 3
14 0
0
313
2
2 6
15 0
0
315
2
2 6
14 0
0
331
2
2 7
15 0
0
333
2
2 7
14 0
end_DTG
begin_DTG
0
3
0
16
2
2 0
32 0
0
17
2
2 4
32 0
0
18
2
2 6
32 0
end_DTG
begin_DTG
2
1
153
2
2 0
45 0
2
159
2
0 0
39 0
0
0
end_DTG
begin_DTG
2
1
154
2
2 1
45 0
2
160
2
0 1
39 0
0
0
end_DTG
begin_DTG
2
1
155
2
2 2
45 0
2
161
2
0 2
39 0
0
0
end_DTG
begin_DTG
2
1
156
2
2 3
45 0
2
162
2
0 3
39 0
0
0
end_DTG
begin_DTG
2
1
157
2
2 4
45 0
2
163
2
0 4
39 0
0
0
end_DTG
begin_DTG
6
1
159
2
0 0
34 0
1
160
2
0 1
35 0
1
161
2
0 2
36 0
1
162
2
0 3
37 0
1
163
2
0 4
38 0
1
164
2
0 6
40 0
1
0
96
0
end_DTG
begin_DTG
2
1
158
2
2 6
45 0
2
164
2
0 6
39 0
0
0
end_DTG
begin_DTG
2
1
165
2
2 1
45 0
2
170
2
1 1
46 0
0
0
end_DTG
begin_DTG
2
1
166
2
2 2
45 0
2
171
2
1 2
46 0
0
0
end_DTG
begin_DTG
2
1
167
2
2 3
45 0
2
172
2
1 3
46 0
0
0
end_DTG
begin_DTG
2
1
168
2
2 5
45 0
2
173
2
1 5
46 0
0
0
end_DTG
begin_DTG
11
1
153
2
2 0
34 0
1
154
2
2 1
35 0
1
155
2
2 2
36 0
1
156
2
2 3
37 0
1
157
2
2 4
38 0
1
158
2
2 6
40 0
1
165
2
2 1
41 0
1
166
2
2 2
42 0
1
167
2
2 3
43 0
1
168
2
2 5
44 0
1
169
2
2 6
47 0
1
0
94
0
end_DTG
begin_DTG
5
1
170
2
1 1
41 0
1
171
2
1 2
42 0
1
172
2
1 3
43 0
1
173
2
1 5
44 0
1
174
2
1 6
47 0
1
0
95
0
end_DTG
begin_DTG
2
1
169
2
2 6
45 0
2
174
2
1 6
46 0
0
0
end_DTG
begin_DTG
0
6
0
76
2
2 0
47 1
0
77
2
2 4
47 1
0
78
2
2 6
47 1
0
91
2
1 0
47 2
0
92
2
1 4
47 2
0
93
2
1 6
47 2
end_DTG
begin_DTG
0
6
0
73
2
2 0
44 1
0
74
2
2 4
44 1
0
75
2
2 6
44 1
0
88
2
1 0
44 2
0
89
2
1 4
44 2
0
90
2
1 6
44 2
end_DTG
begin_DTG
0
6
0
70
2
2 0
43 1
0
71
2
2 4
43 1
0
72
2
2 6
43 1
0
85
2
1 0
43 2
0
86
2
1 4
43 2
0
87
2
1 6
43 2
end_DTG
begin_DTG
0
6
0
67
2
2 0
42 1
0
68
2
2 4
42 1
0
69
2
2 6
42 1
0
82
2
1 0
42 2
0
83
2
1 4
42 2
0
84
2
1 6
42 2
end_DTG
begin_DTG
0
6
0
64
2
2 0
41 1
0
65
2
2 4
41 1
0
66
2
2 6
41 1
0
79
2
1 0
41 2
0
80
2
1 4
41 2
0
81
2
1 6
41 2
end_DTG
begin_DTG
0
6
0
58
2
2 0
37 1
0
59
2
2 4
37 1
0
60
2
2 6
37 1
0
61
2
0 0
37 2
0
62
2
0 4
37 2
0
63
2
0 6
37 2
end_DTG
begin_CG
8
34 1
35 1
36 1
37 1
38 1
40 1
53 3
39 6
11
41 1
42 1
43 1
44 1
47 1
52 3
51 3
50 3
49 3
48 3
46 5
49
34 1
35 1
36 1
37 1
38 1
40 1
41 1
42 1
43 1
44 1
47 1
15 60
14 59
3 59
33 3
31 3
13 3
29 3
27 3
11 3
25 3
9 3
23 3
7 3
21 3
5 3
19 3
17 3
53 3
52 3
51 3
50 3
49 3
48 3
45 11
32 12
30 18
12 6
28 14
26 21
10 7
24 15
8 5
22 9
6 3
20 3
4 1
18 6
16 9
12
30 6
12 6
26 7
10 7
24 5
8 5
22 3
6 3
20 1
4 1
18 2
16 3
1
5 3
0
1
7 3
0
1
9 3
0
1
11 3
0
1
13 3
0
9
32 6
30 6
28 7
26 7
24 5
22 3
20 1
18 2
16 3
9
32 6
30 6
28 7
26 7
24 5
22 3
20 1
18 2
16 3
1
17 3
0
1
19 3
0
1
21 3
0
1
23 3
0
1
25 3
0
1
27 3
0
1
29 3
0
1
31 3
0
1
33 3
0
2
45 1
39 1
2
45 1
39 1
2
45 1
39 1
3
53 6
45 1
39 1
2
45 1
39 1
6
34 1
35 1
36 1
37 1
38 1
40 1
2
45 1
39 1
3
52 6
45 1
46 1
3
51 6
45 1
46 1
3
50 6
45 1
46 1
3
49 6
45 1
46 1
11
34 1
35 1
36 1
37 1
38 1
40 1
41 1
42 1
43 1
44 1
47 1
5
41 1
42 1
43 1
44 1
47 1
3
48 6
45 1
46 1
0
0
0
0
0
0
end_CG
