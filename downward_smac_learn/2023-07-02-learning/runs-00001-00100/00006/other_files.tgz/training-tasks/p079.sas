begin_version
3
end_version
begin_metric
0
end_metric
70
begin_variable
var3
-1
9
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera4, rover4)
NegatedAtom calibrated(camera4, rover4)
end_variable
begin_variable
var87
-1
2
Atom have_image(rover4, objective8, colour)
NegatedAtom have_image(rover4, objective8, colour)
end_variable
begin_variable
var84
-1
2
Atom have_image(rover4, objective7, colour)
NegatedAtom have_image(rover4, objective7, colour)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover4, objective5, colour)
NegatedAtom have_image(rover4, objective5, colour)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover4, objective4, colour)
NegatedAtom have_image(rover4, objective4, colour)
end_variable
begin_variable
var72
-1
2
Atom have_image(rover4, objective3, colour)
NegatedAtom have_image(rover4, objective3, colour)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover4)
NegatedAtom calibrated(camera1, rover4)
end_variable
begin_variable
var89
-1
2
Atom have_image(rover4, objective8, low_res)
NegatedAtom have_image(rover4, objective8, low_res)
end_variable
begin_variable
var88
-1
2
Atom have_image(rover4, objective8, high_res)
NegatedAtom have_image(rover4, objective8, high_res)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective8, high_res)
NegatedAtom communicated_image_data(objective8, high_res)
end_variable
begin_variable
var86
-1
2
Atom have_image(rover4, objective7, low_res)
NegatedAtom have_image(rover4, objective7, low_res)
end_variable
begin_variable
var85
-1
2
Atom have_image(rover4, objective7, high_res)
NegatedAtom have_image(rover4, objective7, high_res)
end_variable
begin_variable
var35
-1
2
Atom communicated_image_data(objective7, high_res)
NegatedAtom communicated_image_data(objective7, high_res)
end_variable
begin_variable
var82
-1
2
Atom have_image(rover4, objective6, high_res)
NegatedAtom have_image(rover4, objective6, high_res)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective6, high_res)
NegatedAtom communicated_image_data(objective6, high_res)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover4, objective4, low_res)
NegatedAtom have_image(rover4, objective4, low_res)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover4, objective4, high_res)
NegatedAtom have_image(rover4, objective4, high_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover4, objective3, low_res)
NegatedAtom have_image(rover4, objective3, low_res)
end_variable
begin_variable
var73
-1
2
Atom have_image(rover4, objective3, high_res)
NegatedAtom have_image(rover4, objective3, high_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var71
-1
2
Atom have_image(rover4, objective2, low_res)
NegatedAtom have_image(rover4, objective2, low_res)
end_variable
begin_variable
var70
-1
2
Atom have_image(rover4, objective2, high_res)
NegatedAtom have_image(rover4, objective2, high_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var68
-1
2
Atom have_image(rover4, objective1, low_res)
NegatedAtom have_image(rover4, objective1, low_res)
end_variable
begin_variable
var67
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var1
-1
9
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint6)
Atom have_rock_analysis(rover2, waypoint6)
end_variable
begin_variable
var6
-1
2
Atom at_rock_sample(waypoint9)
Atom have_rock_analysis(rover2, waypoint9)
end_variable
begin_variable
var49
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var42
-1
2
Atom communicated_rock_data(waypoint9)
NegatedAtom communicated_rock_data(waypoint9)
end_variable
begin_variable
var41
-1
2
Atom communicated_rock_data(waypoint6)
NegatedAtom communicated_rock_data(waypoint6)
end_variable
begin_variable
var40
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_vari




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





1
36 4
9
0
1
1
36 0
0
2
1
36 1
0
3
1
36 2
0
4
1
36 3
0
5
1
36 4
0
6
1
36 5
0
7
1
36 6
0
8
1
36 7
0
9
1
36 8
end_DTG
begin_DTG
9
1
234
1
36 6
1
250
1
36 7
1
227
1
36 5
1
267
1
36 8
1
163
1
36 1
1
182
1
36 2
1
155
1
36 0
1
198
1
36 3
1
207
1
36 4
1
0
0
1
36 1
end_DTG
begin_DTG
0
16
0
155
2
36 0
38 0
0
157
2
36 0
37 0
0
179
2
36 1
38 0
0
181
2
36 1
37 0
0
191
2
36 2
38 0
0
193
2
36 2
37 0
0
199
2
36 3
38 0
0
201
2
36 3
37 0
0
227
2
36 5
38 0
0
229
2
36 5
37 0
0
247
2
36 6
38 0
0
249
2
36 6
37 0
0
263
2
36 7
38 0
0
265
2
36 7
37 0
0
283
2
36 8
38 0
0
285
2
36 8
37 0
end_DTG
begin_DTG
0
4
0
38
2
36 1
39 0
0
39
2
36 4
39 0
0
74
2
0 1
8 0
0
75
2
0 4
8 0
end_DTG
begin_DTG
0
16
0
154
2
36 0
38 0
0
156
2
36 0
37 0
0
178
2
36 1
38 0
0
180
2
36 1
37 0
0
190
2
36 2
38 0
0
192
2
36 2
37 0
0
198
2
36 3
38 0
0
200
2
36 3
37 0
0
226
2
36 5
38 0
0
228
2
36 5
37 0
0
246
2
36 6
38 0
0
248
2
36 6
37 0
0
262
2
36 7
38 0
0
264
2
36 7
37 0
0
282
2
36 8
38 0
0
284
2
36 8
37 0
end_DTG
begin_DTG
0
4
0
36
2
36 1
41 0
0
37
2
36 4
41 0
0
70
2
0 1
2 0
0
71
2
0 4
2 0
end_DTG
begin_DTG
0
18
0
209
2
36 4
37 0
0
281
2
36 8
37 0
0
279
2
36 8
38 0
0
261
2
36 7
37 0
0
259
2
36 7
38 0
0
245
2
36 6
37 0
0
243
2
36 6
38 0
0
225
2
36 5
37 0
0
223
2
36 5
38 0
0
151
2
36 0
38 0
0
207
2
36 4
38 0
0
197
2
36 3
37 0
0
195
2
36 3
38 0
0
189
2
36 2
37 0
0
187
2
36 2
38 0
0
177
2
36 1
37 0
0
175
2
36 1
38 0
0
153
2
36 0
37 0
end_DTG
begin_DTG
0
4
0
34
2
36 1
43 0
0
35
2
36 4
43 0
0
68
2
0 1
11 0
0
69
2
0 4
11 0
end_DTG
begin_DTG
0
18
0
208
2
36 4
37 0
0
280
2
36 8
37 0
0
278
2
36 8
38 0
0
260
2
36 7
37 0
0
258
2
36 7
38 0
0
244
2
36 6
37 0
0
242
2
36 6
38 0
0
224
2
36 5
37 0
0
222
2
36 5
38 0
0
150
2
36 0
38 0
0
206
2
36 4
38 0
0
196
2
36 3
37 0
0
194
2
36 3
38 0
0
188
2
36 2
37 0
0
186
2
36 2
38 0
0
176
2
36 1
37 0
0
174
2
36 1
38 0
0
152
2
36 0
37 0
end_DTG
begin_DTG
0
4
0
32
2
36 1
45 0
0
33
2
36 4
45 0
0
64
2
0 1
3 0
0
65
2
0 4
3 0
end_DTG
begin_DTG
0
10
0
170
2
36 1
38 0
0
172
2
36 1
37 0
0
214
2
36 5
38 0
0
216
2
36 5
37 0
0
238
2
36 6
38 0
0
240
2
36 6
37 0
0
254
2
36 7
38 0
0
256
2
36 7
37 0
0
274
2
36 8
38 0
0
276
2
36 8
37 0
end_DTG
begin_DTG
0
4
0
30
2
36 1
47 0
0
31
2
36 4
47 0
0
60
2
0 1
4 0
0
61
2
0 4
4 0
end_DTG
begin_DTG
0
6
0
183
2
36 2
38 0
0
185
2
36 2
37 0
0
211
2
36 5
38 0
0
213
2
36 5
37 0
0
235
2
36 6
38 0
0
237
2
36 6
37 0
end_DTG
begin_DTG
0
4
0
28
2
36 1
49 0
0
29
2
36 4
49 0
0
58
2
0 1
16 0
0
59
2
0 4
16 0
end_DTG
begin_DTG
0
6
0
182
2
36 2
38 0
0
184
2
36 2
37 0
0
210
2
36 5
38 0
0
212
2
36 5
37 0
0
234
2
36 6
38 0
0
236
2
36 6
37 0
end_DTG
begin_DTG
0
4
0
26
2
36 1
51 0
0
27
2
36 4
51 0
0
54
2
0 1
5 0
0
55
2
0 4
5 0
end_DTG
begin_DTG
0
12
0
147
2
36 0
38 0
0
149
2
36 0
37 0
0
167
2
36 1
38 0
0
169
2
36 1
37 0
0
203
2
36 4
38 0
0
205
2
36 4
37 0
0
231
2
36 6
38 0
0
233
2
36 6
37 0
0
251
2
36 7
38 0
0
253
2
36 7
37 0
0
271
2
36 8
38 0
0
273
2
36 8
37 0
end_DTG
begin_DTG
0
4
0
24
2
36 1
53 0
0
25
2
36 4
53 0
0
52
2
0 1
19 0
0
53
2
0 4
19 0
end_DTG
begin_DTG
0
12
0
146
2
36 0
38 0
0
148
2
36 0
37 0
0
166
2
36 1
38 0
0
168
2
36 1
37 0
0
202
2
36 4
38 0
0
204
2
36 4
37 0
0
230
2
36 6
38 0
0
232
2
36 6
37 0
0
250
2
36 7
38 0
0
252
2
36 7
37 0
0
270
2
36 8
38 0
0
272
2
36 8
37 0
end_DTG
begin_DTG
0
4
0
22
2
36 1
55 0
0
23
2
36 4
55 0
0
48
2
0 1
6 0
0
49
2
0 4
6 0
end_DTG
begin_DTG
0
2
0
163
2
36 1
38 0
0
165
2
36 1
37 0
end_DTG
begin_DTG
0
4
0
20
2
36 1
57 0
0
21
2
36 4
57 0
0
46
2
0 1
22 0
0
47
2
0 4
22 0
end_DTG
begin_DTG
0
4
0
159
2
36 1
38 0
0
161
2
36 1
37 0
0
267
2
36 8
38 0
0
269
2
36 8
37 0
end_DTG
begin_DTG
0
4
0
18
2
36 1
59 0
0
19
2
36 4
59 0
0
42
2
0 1
25 0
0
43
2
0 4
25 0
end_DTG
begin_DTG
1
1
141
2
36 0
66 0
0
end_DTG
begin_DTG
1
1
142
2
36 1
66 0
0
end_DTG
begin_DTG
1
1
143
2
36 4
66 0
0
end_DTG
begin_DTG
1
1
144
2
36 5
66 0
0
end_DTG
begin_DTG
1
1
145
2
36 8
66 0
0
end_DTG
begin_DTG
5
1
141
2
36 0
61 0
1
142
2
36 1
62 0
1
143
2
36 4
63 0
1
144
2
36 5
64 0
1
145
2
36 8
65 0
1
0
88
0
end_DTG
begin_DTG
0
2
0
86
2
36 1
65 1
0
87
2
36 4
65 1
end_DTG
begin_DTG
0
2
0
84
2
36 1
64 1
0
85
2
36 4
64 1
end_DTG
begin_DTG
0
2
0
82
2
36 1
62 1
0
83
2
36 4
62 1
end_DTG
begin_CG
38
7 72
1 41
27 2
60 2
24 2
58 2
56 2
21 2
54 2
52 2
18 2
50 2
48 2
15 2
46 2
13 2
44 2
42 2
10 2
40 2
26 2
25 2
23 1
22 1
6 6
20 6
19 6
5 3
17 3
16 3
4 5
14 1
3 9
12 9
11 9
2 8
9 8
8 8
5
6 6
5 3
4 5
3 9
2 8
1
42 2
1
46 2
1
48 2
1
52 2
1
56 2
13
26 2
25 2
23 1
22 1
20 6
19 6
17 3
16 3
14 1
12 9
11 9
9 8
8 8
1
40 2
1
10 2
0
1
44 2
1
13 2
0
1
15 2
0
1
50 2
1
18 2
0
1
54 2
1
21 2
0
1
58 2
1
24 2
0
1
60 2
1
27 2
0
7
29 1
30 1
31 1
35 2
34 2
33 2
32 3
2
35 2
32 1
2
34 2
32 1
2
33 2
32 1
3
29 1
30 1
31 1
0
0
0
33
61 1
62 1
63 1
64 1
65 1
38 71
37 79
60 2
58 2
56 2
54 2
52 2
50 2
48 2
46 2
44 2
42 2
40 2
69 2
68 2
67 2
66 5
59 4
57 2
55 12
53 12
51 6
49 6
47 10
45 18
43 18
41 16
39 16
11
59 2
57 1
55 6
53 6
51 3
49 3
47 5
45 9
43 9
41 8
39 8
11
59 2
57 1
55 6
53 6
51 3
49 3
47 5
45 9
43 9
41 8
39 8
1
40 2
0
1
42 2
0
1
44 2
0
1
46 2
0
1
48 2
0
1
50 2
0
1
52 2
0
1
54 2
0
1
56 2
0
1
58 2
0
1
60 2
0
1
66 1
2
69 2
66 1
1
66 1
2
68 2
66 1
2
67 2
66 1
5
61 1
62 1
63 1
64 1
65 1
0
0
0
end_CG
