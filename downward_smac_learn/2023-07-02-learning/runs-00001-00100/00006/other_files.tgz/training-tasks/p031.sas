begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var1
-1
5
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
end_variable
begin_variable
var0
-1
5
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
end_variable
begin_variable
var2
-1
3
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
end_variable
begin_variable
var5
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var25
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var26
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var24
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var23
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var21
-1
2
Atom communicated_rock_data(waypoint4)
NegatedAtom communicated_rock_data(waypoint4)
end_variable
begin_variable
var20
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var19
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
3
2
0
0
0
0
0
0
0
0
1
1
1
1
1
end_state
begin_goal
5
10 0
11 0
12 0
13 0
14 0
end_goal
54
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint2 waypoint1
2
1 1
2 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint3 waypoint1
2
1 2
2 1
1
0 14 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint2 waypoint1
2
1 1
3 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint3 waypoint3 waypoint1
2
1 2
3 1
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint2 waypoint1
2
1 1
4 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint4 waypoint3 waypoint1
2
1 2
4 1
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint2 waypoint1
2
0 1
2 2
1
0 14 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint1 waypoint3 waypoint1
2
0 2
2 2
1
0 14 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint3 waypoint2 waypoint1
2
0 1
3 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint3 waypoint3 waypoint1
2
0 2
3 2
1
0 13 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint4 waypoint2 waypoint1
2
0 1
4 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_rock_data rover2 general waypoint4 waypoint3 waypoint1
2
0 2
4 2
1
0 12 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint4 waypoint2 waypoint1
2
1 1
6 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint4 waypoint3 waypoint1
2
1 2
6 1
1
0 11 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint5 waypoint2 waypoint1
2
1 1
9 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_soil_data rover1 general waypoint5 waypoint3 waypoint1
2
1 2
9 1
1
0 10 -1 0
0
end_operator
begin_operator
communicate_soil_data rover2 general waypoint4 waypoint2 waypoint1
2
0 1
6 2
1
0 11 -1 0
0
end_operator
begin_operator
communicate_soil_data rover2 general waypoint4 waypoint3 waypoint1
2
0 2
6 2
1
0 11 -1 0
0
end_operator
begin_operator
communicate_soil_data rover2 general waypoint5 waypoint2 waypoint1
2
0 1
9 2
1
0 10 -1 0
0
end_operator
begin_operator
communicate_soil_data rover2 general waypoint5 waypoint3 waypoint1
2
0 2
9 2
1
0 10 -1 0
0
end_operator
begin_operator
drop rover1 rover1store
0
1
0 7 1 0
0
end_operator
begin_operator
drop rover2 rover2store
0
1
0 8 1 0
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint2
0
1
0 1 0 1
0
end_operator
begin_operator
navigate rover1 waypoint1 waypoint3
0
1
0 1 0 2
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint1
0
1
0 1 1 0
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint4
0
1
0 1 1 3
0
end_operator
begin_operator
navigate rover1 waypoint2 waypoint5
0
1
0 1 1 4
0
en




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




t5 waypoint2
0
1
0 0 4 1
0
end_operator
begin_operator
navigate rover2 waypoint5 waypoint3
0
1
0 0 4 2
0
end_operator
begin_operator
navigate rover2 waypoint5 waypoint4
0
1
0 0 4 3
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint1
1
1 0
2
0 2 0 1
0 7 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint3
1
1 2
2
0 3 0 1
0 7 0 1
0
end_operator
begin_operator
sample_rock rover1 rover1store waypoint4
1
1 3
2
0 4 0 1
0 7 0 1
0
end_operator
begin_operator
sample_rock rover2 rover2store waypoint1
1
0 0
2
0 2 0 2
0 8 0 1
0
end_operator
begin_operator
sample_rock rover2 rover2store waypoint3
1
0 2
2
0 3 0 2
0 8 0 1
0
end_operator
begin_operator
sample_rock rover2 rover2store waypoint4
1
0 3
2
0 4 0 2
0 8 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint1
1
1 0
2
0 5 0 1
0 7 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint4
1
1 3
2
0 6 0 1
0 7 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint5
1
1 4
2
0 9 0 1
0 7 0 1
0
end_operator
begin_operator
sample_soil rover2 rover2store waypoint1
1
0 0
2
0 5 0 2
0 8 0 1
0
end_operator
begin_operator
sample_soil rover2 rover2store waypoint4
1
0 3
2
0 6 0 2
0 8 0 1
0
end_operator
begin_operator
sample_soil rover2 rover2store waypoint5
1
0 4
2
0 9 0 2
0 8 0 1
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 2
22
23
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 7
check 0
check 1
42
check 0
check 0
check 0
check 0
switch 5
check 0
switch 7
check 0
check 1
48
check 0
check 0
check 0
check 0
check 0
switch 0
check 3
24
25
26
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
0
check 0
switch 3
check 0
check 0
check 1
2
check 0
switch 4
check 0
check 0
check 1
4
check 0
switch 6
check 0
check 0
check 1
12
check 0
switch 9
check 0
check 0
check 1
14
check 0
check 0
switch 0
check 2
27
28
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
1
check 0
switch 3
check 0
switch 7
check 0
check 1
43
check 0
check 0
check 1
3
check 0
switch 4
check 0
check 0
check 1
5
check 0
switch 6
check 0
check 0
check 1
13
check 0
switch 9
check 0
check 0
check 1
15
check 0
check 0
switch 0
check 1
29
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 7
check 0
check 1
44
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 1
49
check 0
check 0
check 0
check 0
check 0
switch 0
check 2
30
31
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
switch 7
check 0
check 1
50
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
switch 2
check 1
32
switch 8
check 0
check 1
45
check 0
check 0
check 0
check 0
switch 5
check 0
switch 8
check 0
check 1
51
check 0
check 0
check 0
check 0
check 0
switch 2
check 2
33
34
check 0
check 0
check 1
6
switch 3
check 0
check 0
check 0
check 1
8
switch 4
check 0
check 0
check 0
check 1
10
switch 6
check 0
check 0
check 0
check 1
16
switch 9
check 0
check 0
check 0
check 1
18
check 0
switch 2
check 2
35
36
check 0
check 0
check 1
7
switch 3
check 0
switch 8
check 0
check 1
46
check 0
check 0
check 0
check 1
9
switch 4
check 0
check 0
check 0
check 1
11
switch 6
check 0
check 0
check 0
check 1
17
switch 9
check 0
check 0
check 0
check 1
19
check 0
switch 2
check 2
37
38
check 0
check 0
check 0
switch 4
check 0
switch 8
check 0
check 1
47
check 0
check 0
check 0
check 0
switch 6
check 0
switch 8
check 0
check 1
52
check 0
check 0
check 0
check 0
check 0
switch 2
check 3
39
40
41
check 0
check 0
check 0
switch 9
check 0
switch 8
check 0
check 1
53
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 0
check 1
20
switch 8
check 0
check 0
check 1
21
check 0
end_SG
begin_DTG
1
2
32
0
2
3
33
0
4
34
0
2
0
35
0
4
36
0
2
1
37
0
4
38
0
3
1
39
0
2
40
0
3
41
0
end_DTG
begin_DTG
2
1
22
0
2
23
0
3
0
24
0
3
25
0
4
26
0
2
0
27
0
4
28
0
1
1
29
0
2
1
30
0
2
31
0
end_DTG
begin_DTG
2
1
42
2
1 0
7 0
2
45
2
0 0
8 0
0
0
end_DTG
begin_DTG
2
1
43
2
1 2
7 0
2
46
2
0 2
8 0
0
0
end_DTG
begin_DTG
2
1
44
2
1 3
7 0
2
47
2
0 3
8 0
0
0
end_DTG
begin_DTG
2
1
48
2
1 0
7 0
2
51
2
0 0
8 0
0
0
end_DTG
begin_DTG
2
1
49
2
1 3
7 0
2
52
2
0 3
8 0
0
0
end_DTG
begin_DTG
6
1
42
2
1 0
2 0
1
43
2
1 2
3 0
1
44
2
1 3
4 0
1
48
2
1 0
5 0
1
49
2
1 3
6 0
1
50
2
1 4
9 0
1
0
20
0
end_DTG
begin_DTG
6
1
45
2
0 0
2 0
1
46
2
0 2
3 0
1
47
2
0 3
4 0
1
51
2
0 0
5 0
1
52
2
0 3
6 0
1
53
2
0 4
9 0
1
0
21
0
end_DTG
begin_DTG
2
1
50
2
1 4
7 0
2
53
2
0 4
8 0
0
0
end_DTG
begin_DTG
0
4
0
14
2
1 1
9 1
0
15
2
1 2
9 1
0
18
2
0 1
9 2
0
19
2
0 2
9 2
end_DTG
begin_DTG
0
4
0
12
2
1 1
6 1
0
13
2
1 2
6 1
0
16
2
0 1
6 2
0
17
2
0 2
6 2
end_DTG
begin_DTG
0
4
0
4
2
1 1
4 1
0
5
2
1 2
4 1
0
10
2
0 1
4 2
0
11
2
0 2
4 2
end_DTG
begin_DTG
0
4
0
2
2
1 1
3 1
0
3
2
1 2
3 1
0
8
2
0 1
3 2
0
9
2
0 2
3 2
end_DTG
begin_DTG
0
4
0
0
2
1 1
2 1
0
1
2
1 2
2 1
0
6
2
0 1
2 2
0
7
2
0 2
2 2
end_DTG
begin_CG
12
2 1
3 1
4 1
5 1
6 1
9 1
14 2
13 2
12 2
11 2
10 2
8 6
12
2 1
3 1
4 1
5 1
6 1
9 1
14 2
13 2
12 2
11 2
10 2
7 6
3
14 4
7 1
8 1
3
13 4
7 1
8 1
3
12 4
7 1
8 1
2
7 1
8 1
3
11 4
7 1
8 1
6
2 1
3 1
4 1
5 1
6 1
9 1
6
2 1
3 1
4 1
5 1
6 1
9 1
3
10 4
7 1
8 1
0
0
0
0
0
end_CG
