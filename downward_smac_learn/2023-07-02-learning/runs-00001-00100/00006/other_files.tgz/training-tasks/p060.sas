begin_version
3
end_version
begin_metric
0
end_metric
46
begin_variable
var2
-1
7
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera2, rover3)
NegatedAtom calibrated(camera2, rover3)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera1, rover3)
NegatedAtom calibrated(camera1, rover3)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover3, objective6, colour)
NegatedAtom have_image(rover3, objective6, colour)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover3, objective5, colour)
NegatedAtom have_image(rover3, objective5, colour)
end_variable
begin_variable
var57
-1
2
Atom have_image(rover3, objective4, low_res)
NegatedAtom have_image(rover3, objective4, low_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover3, objective4, high_res)
NegatedAtom have_image(rover3, objective4, high_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover3, objective3, high_res)
NegatedAtom have_image(rover3, objective3, high_res)
end_variable
begin_variable
var20
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover3, objective3, colour)
NegatedAtom have_image(rover3, objective3, colour)
end_variable
begin_variable
var50
-1
2
Atom have_image(rover3, objective2, high_res)
NegatedAtom have_image(rover3, objective2, high_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var49
-1
2
Atom have_image(rover3, objective2, colour)
NegatedAtom have_image(rover3, objective2, colour)
end_variable
begin_variable
var48
-1
2
Atom have_image(rover3, objective1, low_res)
NegatedAtom have_image(rover3, objective1, low_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover3, objective1, high_res)
NegatedAtom have_image(rover3, objective1, high_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var1
-1
7
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
end_variable
begin_variable
var0
-1
7
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var44
-1
2
Atom have_image(rover1, objective5, colour)
NegatedAtom have_image(rover1, objective5, colour)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var42
-1
2
Atom have_image(rover1, objective3, colour)
NegatedAtom have_image(rover1, objective3, colour)
end_variable
begin_variable
var19
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var41
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
end_variable
begin_variable
var4
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var5
-1
2
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
end_variable
begin_variable
var6
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover1, waypoint5)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1,




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





end_DTG
begin_DTG
0
2
0
306
2
0 4
2 0
0
308
2
0 4
1 0
end_DTG
begin_DTG
0
6
0
61
2
0 0
9 0
0
62
2
0 1
9 0
0
63
2
0 2
9 0
0
64
2
0 3
9 0
0
65
2
0 4
9 0
0
66
2
0 5
9 0
end_DTG
begin_DTG
0
1
0
305
2
0 4
2 0
end_DTG
begin_DTG
0
6
0
296
2
0 3
2 0
0
298
2
0 3
1 0
0
321
2
0 5
2 0
0
323
2
0 5
1 0
0
336
2
0 6
2 0
0
338
2
0 6
1 0
end_DTG
begin_DTG
0
6
0
49
2
0 0
12 0
0
50
2
0 1
12 0
0
51
2
0 2
12 0
0
52
2
0 3
12 0
0
53
2
0 4
12 0
0
54
2
0 5
12 0
end_DTG
begin_DTG
0
3
0
295
2
0 3
2 0
0
320
2
0 5
2 0
0
335
2
0 6
2 0
end_DTG
begin_DTG
0
4
0
262
2
0 1
2 0
0
264
2
0 1
1 0
0
282
2
0 2
2 0
0
284
2
0 2
1 0
end_DTG
begin_DTG
0
6
0
37
2
0 0
15 0
0
38
2
0 1
15 0
0
39
2
0 2
15 0
0
40
2
0 3
15 0
0
41
2
0 4
15 0
0
42
2
0 5
15 0
end_DTG
begin_DTG
0
4
0
261
2
0 1
2 0
0
263
2
0 1
1 0
0
281
2
0 2
2 0
0
283
2
0 2
1 0
end_DTG
begin_DTG
0
6
0
31
2
0 0
17 0
0
32
2
0 1
17 0
0
33
2
0 2
17 0
0
34
2
0 3
17 0
0
35
2
0 4
17 0
0
36
2
0 5
17 0
end_DTG
begin_DTG
3
2
175
0
5
176
0
6
177
0
3
2
178
0
4
179
0
5
180
0
4
0
181
0
1
182
0
3
183
0
4
184
0
1
2
185
0
3
1
186
0
2
187
0
6
188
0
2
0
189
0
1
190
0
2
0
191
0
4
192
0
end_DTG
begin_DTG
4
1
153
0
2
154
0
5
155
0
6
156
0
3
0
157
0
2
158
0
4
159
0
5
0
160
0
1
161
0
3
162
0
5
163
0
6
164
0
2
2
165
0
4
166
0
3
1
167
0
3
168
0
5
169
0
3
0
170
0
2
171
0
4
172
0
2
0
173
0
2
174
0
end_DTG
begin_DTG
7
1
235
1
20 3
1
244
1
20 6
1
242
1
20 5
1
239
1
20 4
1
225
1
20 0
1
234
1
20 2
1
231
1
20 1
1
0
0
1
20 4
end_DTG
begin_DTG
0
7
0
227
2
20 0
21 0
0
231
2
20 1
21 0
0
234
2
20 2
21 0
0
236
2
20 3
21 0
0
239
2
20 4
21 0
0
242
2
20 5
21 0
0
244
2
20 6
21 0
end_DTG
begin_DTG
0
12
0
25
2
20 0
22 0
0
26
2
20 1
22 0
0
27
2
20 2
22 0
0
28
2
20 3
22 0
0
29
2
20 4
22 0
0
30
2
20 5
22 0
0
85
2
0 0
3 0
0
86
2
0 1
3 0
0
87
2
0 2
3 0
0
88
2
0 3
3 0
0
89
2
0 4
3 0
0
90
2
0 5
3 0
end_DTG
begin_DTG
0
3
0
226
2
20 0
21 0
0
230
2
20 1
21 0
0
241
2
20 5
21 0
end_DTG
begin_DTG
0
12
0
19
2
20 0
24 0
0
20
2
20 1
24 0
0
21
2
20 2
24 0
0
22
2
20 3
24 0
0
23
2
20 4
24 0
0
24
2
20 5
24 0
0
79
2
0 0
4 0
0
80
2
0 1
4 0
0
81
2
0 2
4 0
0
82
2
0 3
4 0
0
83
2
0 4
4 0
0
84
2
0 5
4 0
end_DTG
begin_DTG
0
1
0
237
2
20 4
21 0
end_DTG
begin_DTG
0
12
0
13
2
20 0
26 0
0
14
2
20 1
26 0
0
15
2
20 2
26 0
0
16
2
20 3
26 0
0
17
2
20 4
26 0
0
18
2
20 5
26 0
0
55
2
0 0
11 0
0
56
2
0 1
11 0
0
57
2
0 2
11 0
0
58
2
0 3
11 0
0
59
2
0 4
11 0
0
60
2
0 5
11 0
end_DTG
begin_DTG
0
3
0
235
2
20 3
21 0
0
240
2
20 5
21 0
0
243
2
20 6
21 0
end_DTG
begin_DTG
0
12
0
7
2
20 0
28 0
0
8
2
20 1
28 0
0
9
2
20 2
28 0
0
10
2
20 3
28 0
0
11
2
20 4
28 0
0
12
2
20 5
28 0
0
43
2
0 0
14 0
0
44
2
0 1
14 0
0
45
2
0 2
14 0
0
46
2
0 3
14 0
0
47
2
0 4
14 0
0
48
2
0 5
14 0
end_DTG
begin_DTG
1
1
215
2
20 1
36 0
0
end_DTG
begin_DTG
1
1
216
2
20 2
36 0
0
end_DTG
begin_DTG
1
1
217
2
20 3
36 0
0
end_DTG
begin_DTG
1
1
218
2
20 4
36 0
0
end_DTG
begin_DTG
2
1
219
2
20 2
36 0
2
222
2
19 2
37 0
0
0
end_DTG
begin_DTG
2
1
220
2
20 3
36 0
2
223
2
19 3
37 0
0
0
end_DTG
begin_DTG
7
1
215
2
20 1
30 0
1
216
2
20 2
31 0
1
217
2
20 3
32 0
1
218
2
20 4
33 0
1
219
2
20 2
34 0
1
220
2
20 3
35 0
1
221
2
20 4
38 0
1
0
151
0
end_DTG
begin_DTG
3
1
222
2
19 2
34 0
1
223
2
19 3
35 0
1
224
2
19 4
38 0
1
0
152
0
end_DTG
begin_DTG
2
1
221
2
20 4
36 0
2
224
2
19 4
37 0
0
0
end_DTG
begin_DTG
0
12
0
127
2
20 0
38 1
0
128
2
20 1
38 1
0
129
2
20 2
38 1
0
130
2
20 3
38 1
0
131
2
20 4
38 1
0
132
2
20 5
38 1
0
145
2
19 0
38 2
0
146
2
19 1
38 2
0
147
2
19 2
38 2
0
148
2
19 3
38 2
0
149
2
19 4
38 2
0
150
2
19 5
38 2
end_DTG
begin_DTG
0
12
0
121
2
20 0
35 1
0
122
2
20 1
35 1
0
123
2
20 2
35 1
0
124
2
20 3
35 1
0
125
2
20 4
35 1
0
126
2
20 5
35 1
0
139
2
19 0
35 2
0
140
2
19 1
35 2
0
141
2
19 2
35 2
0
142
2
19 3
35 2
0
143
2
19 4
35 2
0
144
2
19 5
35 2
end_DTG
begin_DTG
0
12
0
115
2
20 0
34 1
0
116
2
20 1
34 1
0
117
2
20 2
34 1
0
118
2
20 3
34 1
0
119
2
20 4
34 1
0
120
2
20 5
34 1
0
133
2
19 0
34 2
0
134
2
19 1
34 2
0
135
2
19 2
34 2
0
136
2
19 3
34 2
0
137
2
19 4
34 2
0
138
2
19 5
34 2
end_DTG
begin_DTG
0
6
0
109
2
20 0
33 1
0
110
2
20 1
33 1
0
111
2
20 2
33 1
0
112
2
20 3
33 1
0
113
2
20 4
33 1
0
114
2
20 5
33 1
end_DTG
begin_DTG
0
6
0
103
2
20 0
32 1
0
104
2
20 1
32 1
0
105
2
20 2
32 1
0
106
2
20 3
32 1
0
107
2
20 4
32 1
0
108
2
20 5
32 1
end_DTG
begin_DTG
0
6
0
97
2
20 0
31 1
0
98
2
20 1
31 1
0
99
2
20 2
31 1
0
100
2
20 3
31 1
0
101
2
20 4
31 1
0
102
2
20 5
31 1
end_DTG
begin_DTG
0
6
0
91
2
20 0
30 1
0
92
2
20 1
30 1
0
93
2
20 2
30 1
0
94
2
20 3
30 1
0
95
2
20 4
30 1
0
96
2
20 5
30 1
end_DTG
begin_CG
22
2 63
1 43
18 6
16 6
29 6
13 6
27 6
10 6
8 6
6 6
25 6
23 6
17 4
15 4
14 3
12 6
11 1
9 2
7 8
5 8
4 3
3 7
6
17 2
15 2
12 3
9 1
7 4
5 4
10
17 2
15 2
14 3
12 3
11 1
9 1
7 4
5 4
4 3
3 7
1
23 6
1
25 6
1
6 6
0
1
8 6
0
1
10 6
0
1
27 6
1
13 6
0
1
29 6
1
16 6
0
1
18 6
0
7
34 1
35 1
38 1
41 6
40 6
39 6
37 3
24
30 1
31 1
32 1
33 1
34 1
35 1
38 1
21 21
29 6
27 6
25 6
23 6
45 6
44 6
43 6
42 6
41 6
40 6
39 6
36 7
28 3
26 1
24 3
22 7
4
28 3
26 1
24 3
22 7
1
23 6
0
1
25 6
0
1
27 6
0
1
29 6
0
2
45 6
36 1
2
44 6
36 1
2
43 6
36 1
2
42 6
36 1
3
41 12
36 1
37 1
3
40 12
36 1
37 1
7
30 1
31 1
32 1
33 1
34 1
35 1
38 1
3
34 1
35 1
38 1
3
39 12
36 1
37 1
0
0
0
0
0
0
0
end_CG
