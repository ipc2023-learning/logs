begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var0
-1
4
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
end_variable
begin_variable
var7
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var26
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var25
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var12
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var24
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var23
-1
2
Atom have_image(rover1, objective1, low_res)
NegatedAtom have_image(rover1, objective1, low_res)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, low_res)
NegatedAtom communicated_image_data(objective1, low_res)
end_variable
begin_variable
var22
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var9
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var21
-1
2
Atom have_image(rover1, objective1, colour)
NegatedAtom have_image(rover1, objective1, colour)
end_variable
begin_variable
var8
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var1
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover1, waypoint1)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover1, waypoint3)
end_variable
begin_variable
var4
-1
2
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
end_variable
begin_variable
var5
-1
2
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
end_variable
begin_variable
var6
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover1, waypoint4)
end_variable
begin_variable
var20
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var19
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var16
-1
2
Atom communicated_rock_data(waypoint3)
NegatedAtom communicated_rock_data(waypoint3)
end_variable
begin_variable
var15
-1
2
Atom communicated_rock_data(waypoint2)
NegatedAtom communicated_rock_data(waypoint2)
end_variable
begin_variable
var14
-1
2
Atom communicated_rock_data(waypoint1)
NegatedAtom communicated_rock_data(waypoint1)
end_variable
0
begin_state
3
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
1
1
1
1
end_state
begin_goal
10
3 0
5 0
7 0
9 0
11 0
13 0
21 0
22 0
23 0
24 0
end_goal
49
begin_operator
calibrate rover1 camera1 objective2 waypoint2
1
0 1
1
0 1 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint3 waypoint2
2
0 2
12 0
1
0 13 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 colour waypoint4 waypoint2
2
0 3
12 0
1
0 13 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint3 waypoint2
2
0 2
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 high_res waypoint4 waypoint2
2
0 3
10 0
1
0 11 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint3 waypoint2
2
0 2
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective1 low_res waypoint4 waypoint2
2
0 3
8 0
1
0 9 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint3 waypoint2
2
0 2
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint4 waypoint2
2
0 3
6 0
1
0 7 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint3 waypoint2
2
0 2
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 high_res waypoint4 waypoint2
2
0 3
4 0
1
0 5 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint3 waypoint2
2
0 2
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 low_res waypoint4 waypoint2
2
0 3
2 0
1
0 3 -1 0
0
end_operator
begin_operator
communicate_rock_data rover1 general waypoint1 waypoint3 waypoin




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




r1store waypoint3
1
0 2
2
0 16 0 1
0 20 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint1
1
0 0
2
0 17 0 1
0 20 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint3
1
0 2
2
0 18 0 1
0 20 0 1
0
end_operator
begin_operator
sample_soil rover1 rover1store waypoint4
1
0 3
2
0 19 0 1
0 20 0 1
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 colour
1
0 0
2
0 1 0 1
0 12 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 high_res
1
0 0
2
0 1 0 1
0 10 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint1 objective1 camera1 low_res
1
0 0
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 colour
1
0 1
2
0 1 0 1
0 12 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 high_res
1
0 1
2
0 1 0 1
0 10 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective1 camera1 low_res
1
0 1
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 colour
1
0 1
2
0 1 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 high_res
1
0 1
2
0 1 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint2 objective2 camera1 low_res
1
0 1
2
0 1 0 1
0 2 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 colour
1
0 2
2
0 1 0 1
0 12 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 high_res
1
0 2
2
0 1 0 1
0 10 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint3 objective1 camera1 low_res
1
0 2
2
0 1 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 colour
1
0 3
2
0 1 0 1
0 12 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 high_res
1
0 3
2
0 1 0 1
0 10 -1 0
0
end_operator
begin_operator
take_image rover1 waypoint4 objective1 camera1 low_res
1
0 3
2
0 1 0 1
0 8 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 14
check 1
22
switch 20
check 0
check 1
28
check 0
check 0
check 0
switch 17
check 0
switch 20
check 0
check 1
31
check 0
check 0
check 0
switch 1
check 0
check 3
34
35
36
check 0
check 0
switch 14
check 2
0
23
check 0
check 0
switch 15
check 0
switch 20
check 0
check 1
29
check 0
check 0
check 0
switch 1
check 0
check 6
37
38
39
40
41
42
check 0
check 0
switch 14
check 3
24
25
26
check 0
check 1
13
switch 15
check 0
check 0
check 1
15
switch 16
check 0
switch 20
check 0
check 1
30
check 0
check 0
check 1
17
switch 18
check 0
switch 20
check 0
check 1
32
check 0
check 0
check 0
switch 19
check 0
check 0
check 1
19
switch 1
check 0
check 3
43
44
45
check 0
switch 12
check 0
check 1
1
check 0
switch 10
check 0
check 1
3
check 0
switch 8
check 0
check 1
5
check 0
switch 6
check 0
check 1
7
check 0
switch 4
check 0
check 1
9
check 0
switch 2
check 0
check 1
11
check 0
check 0
switch 14
check 1
27
check 0
check 1
14
switch 15
check 0
check 0
check 1
16
switch 16
check 0
check 0
check 1
18
switch 19
check 0
switch 20
check 0
check 1
33
check 0
check 0
check 1
20
switch 1
check 0
check 3
46
47
48
check 0
switch 12
check 0
check 1
2
check 0
switch 10
check 0
check 1
4
check 0
switch 8
check 0
check 1
6
check 0
switch 6
check 0
check 1
8
check 0
switch 4
check 0
check 1
10
check 0
switch 2
check 0
check 1
12
check 0
check 0
switch 20
check 0
check 0
check 1
21
check 0
end_SG
begin_DTG
1
2
22
0
1
2
23
0
3
0
24
0
1
25
0
3
26
0
1
2
27
0
end_DTG
begin_DTG
4
1
34
1
0 0
1
37
1
0 1
1
43
1
0 2
1
46
1
0 3
1
0
0
1
0 1
end_DTG
begin_DTG
0
1
0
42
2
0 1
1 0
end_DTG
begin_DTG
0
2
0
11
2
0 2
2 0
0
12
2
0 3
2 0
end_DTG
begin_DTG
0
1
0
41
2
0 1
1 0
end_DTG
begin_DTG
0
2
0
9
2
0 2
4 0
0
10
2
0 3
4 0
end_DTG
begin_DTG
0
1
0
40
2
0 1
1 0
end_DTG
begin_DTG
0
2
0
7
2
0 2
6 0
0
8
2
0 3
6 0
end_DTG
begin_DTG
0
4
0
36
2
0 0
1 0
0
39
2
0 1
1 0
0
45
2
0 2
1 0
0
48
2
0 3
1 0
end_DTG
begin_DTG
0
2
0
5
2
0 2
8 0
0
6
2
0 3
8 0
end_DTG
begin_DTG
0
4
0
35
2
0 0
1 0
0
38
2
0 1
1 0
0
44
2
0 2
1 0
0
47
2
0 3
1 0
end_DTG
begin_DTG
0
2
0
3
2
0 2
10 0
0
4
2
0 3
10 0
end_DTG
begin_DTG
0
4
0
34
2
0 0
1 0
0
37
2
0 1
1 0
0
43
2
0 2
1 0
0
46
2
0 3
1 0
end_DTG
begin_DTG
0
2
0
1
2
0 2
12 0
0
2
2
0 3
12 0
end_DTG
begin_DTG
1
1
28
2
0 0
20 0
0
end_DTG
begin_DTG
1
1
29
2
0 1
20 0
0
end_DTG
begin_DTG
1
1
30
2
0 2
20 0
0
end_DTG
begin_DTG
1
1
31
2
0 0
20 0
0
end_DTG
begin_DTG
1
1
32
2
0 2
20 0
0
end_DTG
begin_DTG
1
1
33
2
0 3
20 0
0
end_DTG
begin_DTG
6
1
28
2
0 0
14 0
1
29
2
0 1
15 0
1
30
2
0 2
16 0
1
31
2
0 0
17 0
1
32
2
0 2
18 0
1
33
2
0 3
19 0
1
0
21
0
end_DTG
begin_DTG
0
2
0
19
2
0 2
19 1
0
20
2
0 3
19 1
end_DTG
begin_DTG
0
2
0
17
2
0 2
16 1
0
18
2
0 3
16 1
end_DTG
begin_DTG
0
2
0
15
2
0 2
15 1
0
16
2
0 3
15 1
end_DTG
begin_DTG
0
2
0
13
2
0 2
14 1
0
14
2
0 3
14 1
end_DTG
begin_CG
24
14 1
15 1
16 1
17 1
18 1
19 1
1 16
13 2
11 2
9 2
7 2
5 2
3 2
24 2
23 2
22 2
21 2
20 6
12 4
10 4
8 4
6 1
4 1
2 1
6
12 4
10 4
8 4
6 1
4 1
2 1
1
3 2
0
1
5 2
0
1
7 2
0
1
9 2
0
1
11 2
0
1
13 2
0
2
24 2
20 1
2
23 2
20 1
2
22 2
20 1
1
20 1
1
20 1
2
21 2
20 1
6
14 1
15 1
16 1
17 1
18 1
19 1
0
0
0
0
end_CG
