begin_version
3
end_version
begin_metric
0
end_metric
36
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera3, rover2)
NegatedAtom calibrated(camera3, rover2)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover2, objective7, colour)
NegatedAtom have_image(rover2, objective7, colour)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover2, objective6, colour)
NegatedAtom have_image(rover2, objective6, colour)
end_variable
begin_variable
var71
-1
2
Atom have_image(rover2, objective4, colour)
NegatedAtom have_image(rover2, objective4, colour)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover2, objective1, high_res)
NegatedAtom have_image(rover2, objective1, high_res)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover1, objective7, colour)
NegatedAtom have_image(rover1, objective7, colour)
end_variable
begin_variable
var31
-1
2
Atom communicated_image_data(objective7, colour)
NegatedAtom communicated_image_data(objective7, colour)
end_variable
begin_variable
var59
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var53
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var22
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var10
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var49
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var7
-1
2
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var8
-1
2
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
end_variable
begin_variable
var9
-1
2
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var3
-1
4
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover1, waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
Atom have_rock_analysis(rover3, waypoint2)
end_variable
begin_variable
var4
-1
4
Atom at_rock_sample(waypoint4)
Atom have_rock_analysis(rover1, waypoint4)
Atom have_rock_analysis(rover2, waypoint4)
Atom have_rock_analysis(rover3, waypoint4)
end_variable
begin_variable
var41
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var42
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var5
-1
4
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover1, waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var6
-1
4
Atom at_rock_sample(waypoint8)
Atom have_rock_analysis(rover1, waypoint8)
Atom have_rock_analysis(rover2, waypoint8)
Atom have_rock_analysis(rover3, waypoint8)
end_variable
begin_variable
var43
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var40
-1
2
Atom communicated_soil_data(waypoint5)
NegatedAtom communicated_soil_data(waypoint5)
end_variable
begin_variable
var39
-1
2
Atom communicated_soil_data(waypoint4)
NegatedAtom communicated_soil_data(waypoint4)
end_variable
begin_variable
var38
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoin




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 28
check 0
check 0
check 1
79
switch 31
check 0
check 0
check 1
80
check 0
end_SG
begin_DTG
2
4
123
0
6
124
0
4
4
125
0
5
126
0
6
127
0
7
128
0
4
3
129
0
4
130
0
5
131
0
7
132
0
2
2
133
0
5
134
0
4
0
135
0
1
136
0
2
137
0
7
138
0
3
1
139
0
2
140
0
3
141
0
3
0
142
0
1
143
0
7
144
0
4
1
145
0
2
146
0
4
147
0
6
148
0
end_DTG
begin_DTG
1
6
99
0
5
3
100
0
4
101
0
5
102
0
6
103
0
7
104
0
4
3
105
0
4
106
0
5
107
0
7
108
0
3
1
109
0
2
110
0
5
111
0
3
1
112
0
2
113
0
7
114
0
3
1
115
0
2
116
0
3
117
0
2
0
118
0
1
119
0
3
1
120
0
2
121
0
4
122
0
end_DTG
begin_DTG
8
1
363
1
1 4
1
372
1
1 5
1
382
1
1 6
1
391
1
1 7
1
325
1
1 1
1
334
1
1 2
1
321
1
1 0
1
351
1
1 3
4
0
10
1
1 1
0
11
1
1 2
0
12
1
1 4
0
13
1
1 6
end_DTG
begin_DTG
0
5
0
332
2
1 1
2 0
0
344
2
1 2
2 0
0
350
2
1 3
2 0
0
362
2
1 4
2 0
0
372
2
1 5
2 0
end_DTG
begin_DTG
0
8
0
320
2
1 0
2 0
0
330
2
1 1
2 0
0
342
2
1 2
2 0
0
348
2
1 3
2 0
0
360
2
1 4
2 0
0
370
2
1 5
2 0
0
382
2
1 6
2 0
0
390
2
1 7
2 0
end_DTG
begin_DTG
0
5
0
318
2
1 0
2 0
0
346
2
1 3
2 0
0
356
2
1 4
2 0
0
380
2
1 6
2 0
0
386
2
1 7
2 0
end_DTG
begin_DTG
0
6
0
317
2
1 0
2 0
0
323
2
1 1
2 0
0
335
2
1 2
2 0
0
353
2
1 4
2 0
0
365
2
1 5
2 0
0
375
2
1 6
2 0
end_DTG
begin_DTG
2
4
81
0
6
82
0
3
5
83
0
6
84
0
7
85
0
1
3
86
0
3
2
87
0
5
88
0
7
89
0
2
0
90
0
7
91
0
2
1
92
0
3
93
0
2
0
94
0
1
95
0
3
1
96
0
3
97
0
4
98
0
end_DTG
begin_DTG
8
1
259
1
7 4
1
278
1
7 5
1
298
1
7 6
1
315
1
7 7
1
183
1
7 1
1
202
1
7 2
1
175
1
7 0
1
235
1
7 3
5
0
5
1
7 1
0
6
1
7 2
0
7
1
7 3
0
8
1
7 4
0
9
1
7 5
end_DTG
begin_DTG
0
5
0
197
2
7 1
8 0
0
221
2
7 2
8 0
0
233
2
7 3
8 0
0
257
2
7 4
8 0
0
277
2
7 5
8 0
end_DTG
begin_DTG
0
8
0
34
2
7 0
9 0
0
35
2
7 1
9 0
0
36
2
7 2
9 0
0
37
2
7 7
9 0
0
50
2
1 0
3 0
0
51
2
1 1
3 0
0
52
2
1 2
3 0
0
53
2
1 7
3 0
end_DTG
begin_DTG
0
8
0
173
2
7 0
8 0
0
193
2
7 1
8 0
0
217
2
7 2
8 0
0
229
2
7 3
8 0
0
253
2
7 4
8 0
0
273
2
7 5
8 0
0
297
2
7 6
8 0
0
313
2
7 7
8 0
end_DTG
begin_DTG
0
8
0
30
2
7 0
11 0
0
31
2
7 1
11 0
0
32
2
7 2
11 0
0
33
2
7 7
11 0
0
46
2
1 0
4 0
0
47
2
1 1
4 0
0
48
2
1 2
4 0
0
49
2
1 7
4 0
end_DTG
begin_DTG
0
5
0
169
2
7 0
8 0
0
225
2
7 3
8 0
0
245
2
7 4
8 0
0
293
2
7 6
8 0
0
305
2
7 7
8 0
end_DTG
begin_DTG
0
8
0
22
2
7 0
13 0
0
23
2
7 1
13 0
0
24
2
7 2
13 0
0
25
2
7 7
13 0
0
42
2
1 0
5 0
0
43
2
1 1
5 0
0
44
2
1 2
5 0
0
45
2
1 7
5 0
end_DTG
begin_DTG
0
6
0
166
2
7 0
8 0
0
178
2
7 1
8 0
0
202
2
7 2
8 0
0
238
2
7 4
8 0
0
262
2
7 5
8 0
0
282
2
7 6
8 0
end_DTG
begin_DTG
0
8
0
14
2
7 0
15 0
0
15
2
7 1
15 0
0
16
2
7 2
15 0
0
17
2
7 7
15 0
0
38
2
1 0
6 0
0
39
2
1 1
6 0
0
40
2
1 2
6 0
0
41
2
1 7
6 0
end_DTG
begin_DTG
8
1
280
1
7 6
1
244
1
7 4
1
260
1
7 5
1
300
1
7 7
1
204
1
7 2
1
168
1
7 0
1
176
1
7 1
1
224
1
7 3
5
0
0
1
7 1
0
1
1
7 2
0
2
1
7 3
0
3
1
7 4
0
4
1
7 5
end_DTG
begin_DTG
0
10
0
188
2
7 1
17 0
0
191
2
7 1
8 0
0
212
2
7 2
17 0
0
215
2
7 2
8 0
0
248
2
7 4
17 0
0
251
2
7 4
8 0
0
268
2
7 5
17 0
0
271
2
7 5
8 0
0
308
2
7 7
17 0
0
311
2
7 7
8 0
end_DTG
begin_DTG
0
4
0
26
2
7 0
18 0
0
27
2
7 1
18 0
0
28
2
7 2
18 0
0
29
2
7 7
18 0
end_DTG
begin_DTG
0
10
0
180
2
7 1
17 0
0
183
2
7 1
8 0
0
204
2
7 2
17 0
0
207
2
7 2
8 0
0
264
2
7 5
17 0
0
267
2
7 5
8 0
0
284
2
7 6
17 0
0
287
2
7 6
8 0
0
300
2
7 7
17 0
0
303
2
7 7
8 0
end_DTG
begin_DTG
0
4
0
18
2
7 0
20 0
0
19
2
7 1
20 0
0
20
2
7 2
20 0
0
21
2
7 7
20 0
end_DTG
begin_DTG
1
1
161
2
1 1
28 0
0
end_DTG
begin_DTG
1
1
162
2
1 3
28 0
0
end_DTG
begin_DTG
1
1
163
2
1 4
28 0
0
end_DTG
begin_DTG
3
1
149
2
7 1
27 0
2
153
2
1 1
28 0
3
157
2
0 1
31 0
0
0
0
end_DTG
begin_DTG
3
1
150
2
7 3
27 0
2
154
2
1 3
28 0
3
158
2
0 3
31 0
0
0
0
end_DTG
begin_DTG
4
1
149
2
7 1
25 0
1
150
2
7 3
26 0
1
151
2
7 6
29 0
1
152
2
7 7
30 0
1
0
78
0
end_DTG
begin_DTG
7
1
153
2
1 1
25 0
1
154
2
1 3
26 0
1
155
2
1 6
29 0
1
156
2
1 7
30 0
1
161
2
1 1
22 0
1
162
2
1 3
23 0
1
163
2
1 4
24 0
1
0
79
0
end_DTG
begin_DTG
3
1
151
2
7 6
27 0
2
155
2
1 6
28 0
3
159
2
0 6
31 0
0
0
0
end_DTG
begin_DTG
3
1
152
2
7 7
27 0
2
156
2
1 7
28 0
3
160
2
0 7
31 0
0
0
0
end_DTG
begin_DTG
4
1
157
2
0 1
25 0
1
158
2
0 3
26 0
1
159
2
0 6
29 0
1
160
2
0 7
30 0
1
0
80
0
end_DTG
begin_DTG
0
4
0
74
2
1 0
24 1
0
75
2
1 1
24 1
0
76
2
1 2
24 1
0
77
2
1 7
24 1
end_DTG
begin_DTG
0
4
0
70
2
1 0
23 1
0
71
2
1 1
23 1
0
72
2
1 2
23 1
0
73
2
1 7
23 1
end_DTG
begin_DTG
0
4
0
66
2
1 0
22 1
0
67
2
1 1
22 1
0
68
2
1 2
22 1
0
69
2
1 7
22 1
end_DTG
begin_DTG
0
12
0
54
2
7 0
25 1
0
55
2
7 1
25 1
0
56
2
7 2
25 1
0
57
2
7 7
25 1
0
58
2
1 0
25 2
0
59
2
1 1
25 2
0
60
2
1 2
25 2
0
61
2
1 7
25 2
0
62
2
0 0
25 3
0
63
2
0 1
25 3
0
64
2
0 2
25 3
0
65
2
0 7
25 3
end_DTG
begin_CG
6
25 1
26 1
29 1
30 1
35 4
31 4
21
25 1
26 1
29 1
30 1
22 1
23 1
24 1
2 80
16 4
14 4
12 4
10 4
35 4
34 4
33 4
32 4
28 7
6 6
5 5
4 8
3 5
4
6 6
5 5
4 8
3 5
1
10 4
1
12 4
1
14 4
1
16 4
20
25 1
26 1
29 1
30 1
17 43
8 119
16 4
21 4
14 4
19 4
12 4
10 4
35 4
27 4
15 6
20 10
13 5
18 10
11 8
9 5
6
15 6
20 5
13 5
18 5
11 8
9 5
1
10 4
0
1
12 4
0
1
14 4
0
1
16 4
0
2
20 5
18 5
1
19 4
0
1
21 4
0
2
34 4
28 1
2
33 4
28 1
2
32 4
28 1
4
35 12
27 1
28 1
31 1
3
27 1
28 1
31 1
4
25 1
26 1
29 1
30 1
7
25 1
26 1
29 1
30 1
22 1
23 1
24 1
3
27 1
28 1
31 1
3
27 1
28 1
31 1
4
25 1
26 1
29 1
30 1
0
0
0
0
end_CG
