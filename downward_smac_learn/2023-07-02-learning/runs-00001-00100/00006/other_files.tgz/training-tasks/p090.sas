begin_version
3
end_version
begin_metric
0
end_metric
100
begin_variable
var3
-1
10
Atom at(rover4, waypoint1)
Atom at(rover4, waypoint10)
Atom at(rover4, waypoint2)
Atom at(rover4, waypoint3)
Atom at(rover4, waypoint4)
Atom at(rover4, waypoint5)
Atom at(rover4, waypoint6)
Atom at(rover4, waypoint7)
Atom at(rover4, waypoint8)
Atom at(rover4, waypoint9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(camera3, rover4)
NegatedAtom calibrated(camera3, rover4)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera2, rover4)
NegatedAtom calibrated(camera2, rover4)
end_variable
begin_variable
var114
-1
2
Atom have_image(rover4, objective9, high_res)
NegatedAtom have_image(rover4, objective9, high_res)
end_variable
begin_variable
var113
-1
2
Atom have_image(rover4, objective8, high_res)
NegatedAtom have_image(rover4, objective8, high_res)
end_variable
begin_variable
var112
-1
2
Atom have_image(rover4, objective7, high_res)
NegatedAtom have_image(rover4, objective7, high_res)
end_variable
begin_variable
var111
-1
2
Atom have_image(rover4, objective6, high_res)
NegatedAtom have_image(rover4, objective6, high_res)
end_variable
begin_variable
var110
-1
2
Atom have_image(rover4, objective5, high_res)
NegatedAtom have_image(rover4, objective5, high_res)
end_variable
begin_variable
var109
-1
2
Atom have_image(rover4, objective4, high_res)
NegatedAtom have_image(rover4, objective4, high_res)
end_variable
begin_variable
var108
-1
2
Atom have_image(rover4, objective3, high_res)
NegatedAtom have_image(rover4, objective3, high_res)
end_variable
begin_variable
var107
-1
2
Atom have_image(rover4, objective2, high_res)
NegatedAtom have_image(rover4, objective2, high_res)
end_variable
begin_variable
var106
-1
2
Atom have_image(rover4, objective1, high_res)
NegatedAtom have_image(rover4, objective1, high_res)
end_variable
begin_variable
var2
-1
10
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint10)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
Atom at(rover3, waypoint9)
end_variable
begin_variable
var1
-1
10
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint10)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
Atom at(rover2, waypoint9)
end_variable
begin_variable
var18
-1
2
Atom calibrated(camera4, rover2)
NegatedAtom calibrated(camera4, rover2)
end_variable
begin_variable
var105
-1
2
Atom have_image(rover2, objective9, low_res)
NegatedAtom have_image(rover2, objective9, low_res)
end_variable
begin_variable
var104
-1
2
Atom have_image(rover2, objective9, colour)
NegatedAtom have_image(rover2, objective9, colour)
end_variable
begin_variable
var103
-1
2
Atom have_image(rover2, objective8, low_res)
NegatedAtom have_image(rover2, objective8, low_res)
end_variable
begin_variable
var102
-1
2
Atom have_image(rover2, objective8, colour)
NegatedAtom have_image(rover2, objective8, colour)
end_variable
begin_variable
var101
-1
2
Atom have_image(rover2, objective7, low_res)
NegatedAtom have_image(rover2, objective7, low_res)
end_variable
begin_variable
var100
-1
2
Atom have_image(rover2, objective7, colour)
NegatedAtom have_image(rover2, objective7, colour)
end_variable
begin_variable
var99
-1
2
Atom have_image(rover2, objective6, low_res)
NegatedAtom have_image(rover2, objective6, low_res)
end_variable
begin_variable
var97
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var96
-1
2
Atom have_image(rover2, objective5, colour)
NegatedAtom have_image(rover2, objective5, colour)
end_variable
begin_variable
var95
-1
2
Atom have_image(rover2, objective4, low_res)
NegatedAtom have_image(rover2, objective4, low_res)
end_variable
begin_variable
var94
-1
2
Atom have_image(rover2, objective4, colour)
NegatedAtom have_image(rover2, objective4, colour)
end_variable
begin_variable
var93
-1
2
Atom have_image(rover2, objective3, low_res)
NegatedAtom have_image(rover2, objective3, low_res)
end_variable
begin_variable
var92
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var91
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var90
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var88
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var0
-1
10
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint10)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera1, rover1)
NegatedAto




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




11 0
0
344
2
0 6
11 0
0
345
2
0 7
11 0
0
346
2
0 8
11 0
end_DTG
begin_DTG
0
9
0
639
2
31 0
32 0
0
651
2
31 1
32 0
0
663
2
31 2
32 0
0
672
2
31 3
32 0
0
693
2
31 5
32 0
0
702
2
31 6
32 0
0
714
2
31 7
32 0
0
723
2
31 8
32 0
0
732
2
31 9
32 0
end_DTG
begin_DTG
0
16
0
11
2
31 0
81 0
0
12
2
31 1
81 0
0
13
2
31 2
81 0
0
14
2
31 3
81 0
0
15
2
31 5
81 0
0
16
2
31 6
81 0
0
17
2
31 7
81 0
0
18
2
31 8
81 0
0
211
2
13 0
30 0
0
212
2
13 1
30 0
0
213
2
13 2
30 0
0
214
2
13 3
30 0
0
215
2
13 5
30 0
0
216
2
13 6
30 0
0
217
2
13 7
30 0
0
218
2
13 8
30 0
end_DTG
begin_DTG
3
1
621
2
31 0
91 0
2
627
2
12 0
95 0
3
633
2
0 0
96 0
0
0
0
end_DTG
begin_DTG
3
1
622
2
31 2
91 0
2
628
2
12 2
95 0
3
634
2
0 2
96 0
0
0
0
end_DTG
begin_DTG
3
1
623
2
31 3
91 0
2
629
2
12 3
95 0
3
635
2
0 3
96 0
0
0
0
end_DTG
begin_DTG
3
1
624
2
31 4
91 0
2
630
2
12 4
95 0
3
636
2
0 4
96 0
0
0
0
end_DTG
begin_DTG
3
1
625
2
31 6
91 0
2
631
2
12 6
95 0
3
637
2
0 6
96 0
0
0
0
end_DTG
begin_DTG
3
1
626
2
31 9
91 0
2
632
2
12 9
95 0
3
638
2
0 9
96 0
0
0
0
end_DTG
begin_DTG
4
1
601
2
31 1
91 0
2
606
2
13 1
92 0
3
611
2
12 1
95 0
4
616
2
0 1
96 0
0
0
0
0
end_DTG
begin_DTG
4
1
602
2
31 2
91 0
2
607
2
13 2
92 0
3
612
2
12 2
95 0
4
617
2
0 2
96 0
0
0
0
0
end_DTG
begin_DTG
11
1
601
2
31 1
89 0
1
602
2
31 2
90 0
1
603
2
31 4
93 0
1
604
2
31 6
94 0
1
605
2
31 7
97 0
1
621
2
31 0
83 0
1
622
2
31 2
84 0
1
623
2
31 3
85 0
1
624
2
31 4
86 0
1
625
2
31 6
87 0
1
626
2
31 9
88 0
1
0
459
0
end_DTG
begin_DTG
5
1
606
2
13 1
89 0
1
607
2
13 2
90 0
1
608
2
13 4
93 0
1
609
2
13 6
94 0
1
610
2
13 7
97 0
1
0
460
0
end_DTG
begin_DTG
4
1
603
2
31 4
91 0
2
608
2
13 4
92 0
3
613
2
12 4
95 0
4
618
2
0 4
96 0
0
0
0
0
end_DTG
begin_DTG
4
1
604
2
31 6
91 0
2
609
2
13 6
92 0
3
614
2
12 6
95 0
4
619
2
0 6
96 0
0
0
0
0
end_DTG
begin_DTG
11
1
611
2
12 1
89 0
1
612
2
12 2
90 0
1
613
2
12 4
93 0
1
614
2
12 6
94 0
1
615
2
12 7
97 0
1
627
2
12 0
83 0
1
628
2
12 2
84 0
1
629
2
12 3
85 0
1
630
2
12 4
86 0
1
631
2
12 6
87 0
1
632
2
12 9
88 0
1
0
461
0
end_DTG
begin_DTG
11
1
616
2
0 1
89 0
1
617
2
0 2
90 0
1
618
2
0 4
93 0
1
619
2
0 6
94 0
1
620
2
0 7
97 0
1
633
2
0 0
83 0
1
634
2
0 2
84 0
1
635
2
0 3
85 0
1
636
2
0 4
86 0
1
637
2
0 6
87 0
1
638
2
0 9
88 0
1
0
462
0
end_DTG
begin_DTG
4
1
605
2
31 7
91 0
2
610
2
13 7
92 0
3
615
2
12 7
95 0
4
620
2
0 7
96 0
0
0
0
0
end_DTG
begin_DTG
0
24
0
439
2
12 5
85 2
0
458
2
0 8
85 3
0
457
2
0 7
85 3
0
456
2
0 6
85 3
0
455
2
0 5
85 3
0
454
2
0 3
85 3
0
453
2
0 2
85 3
0
452
2
0 1
85 3
0
451
2
0 0
85 3
0
442
2
12 8
85 2
0
441
2
12 7
85 2
0
440
2
12 6
85 2
0
419
2
31 0
85 1
0
438
2
12 3
85 2
0
437
2
12 2
85 2
0
436
2
12 1
85 2
0
435
2
12 0
85 2
0
426
2
31 8
85 1
0
425
2
31 7
85 1
0
424
2
31 6
85 1
0
423
2
31 5
85 1
0
422
2
31 3
85 1
0
421
2
31 2
85 1
0
420
2
31 1
85 1
end_DTG
begin_DTG
0
24
0
431
2
12 5
83 2
0
450
2
0 8
83 3
0
449
2
0 7
83 3
0
448
2
0 6
83 3
0
447
2
0 5
83 3
0
446
2
0 3
83 3
0
445
2
0 2
83 3
0
444
2
0 1
83 3
0
443
2
0 0
83 3
0
434
2
12 8
83 2
0
433
2
12 7
83 2
0
432
2
12 6
83 2
0
411
2
31 0
83 1
0
430
2
12 3
83 2
0
429
2
12 2
83 2
0
428
2
12 1
83 2
0
427
2
12 0
83 2
0
418
2
31 8
83 1
0
417
2
31 7
83 1
0
416
2
31 6
83 1
0
415
2
31 5
83 1
0
414
2
31 3
83 1
0
413
2
31 2
83 1
0
412
2
31 1
83 1
end_DTG
begin_CG
34
89 1
90 1
93 1
94 1
97 1
83 1
84 1
85 1
86 1
87 1
88 1
2 41
1 36
80 8
76 8
70 8
64 8
58 8
54 8
48 8
42 8
36 8
99 8
98 8
96 11
11 18
10 12
9 4
8 4
7 14
6 4
5 2
4 6
3 6
9
11 9
10 6
9 2
8 2
7 7
6 2
5 1
4 3
3 3
9
11 9
10 6
9 2
8 2
7 7
6 2
5 1
4 3
3 3
1
36 8
1
42 8
1
48 8
1
54 8
1
58 8
1
64 8
1
70 8
1
76 8
1
80 8
14
89 1
90 1
93 1
94 1
97 1
83 1
84 1
85 1
86 1
87 1
88 1
99 8
98 8
95 11
39
89 1
90 1
93 1
94 1
97 1
14 72
82 8
78 8
74 8
72 8
68 8
66 8
62 8
60 8
56 8
52 8
50 8
46 8
44 8
40 8
38 8
34 8
92 5
30 9
29 6
28 6
27 2
26 2
25 2
24 2
23 7
22 7
21 2
20 1
19 1
18 3
17 3
16 3
15 3
16
30 9
29 6
28 6
27 2
26 2
25 2
24 2
23 7
22 7
21 2
20 1
19 1
18 3
17 3
16 3
15 3
1
34 8
1
38 8
1
40 8
1
44 8
1
46 8
1
50 8
1
52 8
1
56 8
1
60 8
1
62 8
1
66 8
1
68 8
1
72 8
1
74 8
1
78 8
1
82 8
65
89 1
90 1
93 1
94 1
97 1
83 1
84 1
85 1
86 1
87 1
88 1
32 107
82 8
80 8
78 8
76 8
74 8
72 8
70 8
68 8
66 8
64 8
62 8
60 8
58 8
56 8
54 8
52 8
50 8
48 8
46 8
44 8
42 8
40 8
38 8
36 8
34 8
99 8
98 8
91 11
81 9
79 9
77 6
75 6
73 6
71 2
69 2
67 2
65 2
63 2
61 2
59 7
57 7
55 7
53 2
51 2
49 1
47 1
45 1
43 3
41 3
39 3
37 3
35 3
33 3
25
81 9
79 9
77 6
75 6
73 6
71 2
69 2
67 2
65 2
63 2
61 2
59 7
57 7
55 7
53 2
51 2
49 1
47 1
45 1
43 3
41 3
39 3
37 3
35 3
33 3
1
34 8
0
1
36 8
0
1
38 8
0
1
40 8
0
1
42 8
0
1
44 8
0
1
46 8
0
1
48 8
0
1
50 8
0
1
52 8
0
1
54 8
0
1
56 8
0
1
58 8
0
1
60 8
0
1
62 8
0
1
64 8
0
1
66 8
0
1
68 8
0
1
70 8
0
1
72 8
0
1
74 8
0
1
76 8
0
1
78 8
0
1
80 8
0
1
82 8
0
4
99 24
91 1
95 1
96 1
3
91 1
95 1
96 1
4
98 24
91 1
95 1
96 1
3
91 1
95 1
96 1
3
91 1
95 1
96 1
3
91 1
95 1
96 1
4
91 1
92 1
95 1
96 1
4
91 1
92 1
95 1
96 1
11
89 1
90 1
93 1
94 1
97 1
83 1
84 1
85 1
86 1
87 1
88 1
5
89 1
90 1
93 1
94 1
97 1
4
91 1
92 1
95 1
96 1
4
91 1
92 1
95 1
96 1
11
89 1
90 1
93 1
94 1
97 1
83 1
84 1
85 1
86 1
87 1
88 1
11
89 1
90 1
93 1
94 1
97 1
83 1
84 1
85 1
86 1
87 1
88 1
4
91 1
92 1
95 1
96 1
0
0
end_CG
