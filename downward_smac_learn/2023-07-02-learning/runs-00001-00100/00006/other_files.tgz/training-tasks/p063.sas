begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var2
-1
8
Atom at(rover3, waypoint1)
Atom at(rover3, waypoint2)
Atom at(rover3, waypoint3)
Atom at(rover3, waypoint4)
Atom at(rover3, waypoint5)
Atom at(rover3, waypoint6)
Atom at(rover3, waypoint7)
Atom at(rover3, waypoint8)
end_variable
begin_variable
var1
-1
8
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
Atom at(rover2, waypoint7)
Atom at(rover2, waypoint8)
end_variable
begin_variable
var3
-1
3
Atom at_rock_sample(waypoint2)
Atom have_rock_analysis(rover2, waypoint2)
Atom have_rock_analysis(rover3, waypoint2)
end_variable
begin_variable
var4
-1
3
Atom at_rock_sample(waypoint3)
Atom have_rock_analysis(rover2, waypoint3)
Atom have_rock_analysis(rover3, waypoint3)
end_variable
begin_variable
var5
-1
3
Atom at_rock_sample(waypoint7)
Atom have_rock_analysis(rover2, waypoint7)
Atom have_rock_analysis(rover3, waypoint7)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
Atom have_soil_analysis(rover3, waypoint1)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
Atom have_soil_analysis(rover3, waypoint2)
end_variable
begin_variable
var8
-1
3
Atom at_soil_sample(waypoint4)
Atom have_soil_analysis(rover2, waypoint4)
Atom have_soil_analysis(rover3, waypoint4)
end_variable
begin_variable
var9
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
Atom have_soil_analysis(rover3, waypoint5)
end_variable
begin_variable
var10
-1
3
Atom at_soil_sample(waypoint7)
Atom have_soil_analysis(rover2, waypoint7)
Atom have_soil_analysis(rover3, waypoint7)
end_variable
begin_variable
var45
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var46
-1
2
Atom empty(rover3store)
Atom full(rover3store)
end_variable
begin_variable
var11
-1
3
Atom at_soil_sample(waypoint8)
Atom have_soil_analysis(rover2, waypoint8)
Atom have_soil_analysis(rover3, waypoint8)
end_variable
begin_variable
var43
-1
2
Atom communicated_soil_data(waypoint7)
NegatedAtom communicated_soil_data(waypoint7)
end_variable
begin_variable
var40
-1
2
Atom communicated_soil_data(waypoint2)
NegatedAtom communicated_soil_data(waypoint2)
end_variable
begin_variable
var0
-1
8
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var12
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var57
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var25
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var56
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var50
-1
2
Atom have_image(rover1, objective2, colour)
NegatedAtom have_image(rover1, objective2, colour)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
0
begin_state
6
5
0
0
0
0
0
0
0
0
0
0
0
1
1
0
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
6
13 0
14 0
20 0
22 0
24 0
26 0
end_goal
375
begin_operator
calibrate rover1 camera1 objective5 waypoint3
1
15 2
1
0 18 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective5 waypoint5
1
15 4
1
0 18 -1 0
0
end_operator
begin_operator
calibrate rover1 camera1 objective5 waypoint7
1
15 6
1
0 18 -1 0
0
end_operator
begin_operator
calibrate rover1 camera2 objective2 waypoint7
1
15 6
1
0 17 -1 0
0
end_operator
begin_operator
calibrate rover1 camera3 objective3 waypoint2
1
15 1
1
0 16 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint1 waypoint6
2
15 0
25 0
1
0 26 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint2 waypoint6
2
15 1
25 0
1
0 26 -1 0
0
end_operator
begin_operator
communicate_image_data rover1 general objective2 colour waypoint3 waypoint6
2
15 2
25 0
1
0 26 -1 0
0
end_operator
begin_operator
communicat




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 1
138
check 0
check 0
check 0
check 0
switch 9
check 0
check 0
check 0
check 1
50
check 0
check 3
112
113
114
switch 2
check 4
115
116
117
118
check 0
check 0
check 0
switch 4
check 0
switch 11
check 0
check 1
128
check 0
check 0
check 0
check 0
switch 6
check 0
check 0
check 0
check 1
45
switch 9
check 0
switch 11
check 0
check 1
139
check 0
check 0
check 0
check 1
51
check 0
switch 2
check 4
119
120
121
122
check 0
check 0
check 0
switch 6
check 0
check 0
check 0
check 1
46
switch 9
check 0
check 0
check 0
check 1
52
switch 12
check 0
switch 11
check 0
check 1
140
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
53
switch 11
check 0
check 0
check 1
54
check 0
end_SG
begin_DTG
2
4
99
0
6
100
0
3
2
101
0
6
102
0
7
103
0
4
1
104
0
3
105
0
5
106
0
6
107
0
2
2
108
0
7
109
0
2
0
110
0
5
111
0
3
2
112
0
4
113
0
7
114
0
4
0
115
0
1
116
0
2
117
0
7
118
0
4
1
119
0
3
120
0
5
121
0
6
122
0
end_DTG
begin_DTG
3
4
75
0
6
76
0
7
77
0
2
2
78
0
6
79
0
4
1
80
0
3
81
0
4
82
0
7
83
0
2
2
84
0
4
85
0
3
0
86
0
2
87
0
3
88
0
2
6
89
0
7
90
0
4
0
91
0
1
92
0
5
93
0
7
94
0
4
0
95
0
2
96
0
5
97
0
6
98
0
end_DTG
begin_DTG
2
1
123
2
1 1
10 0
2
126
2
0 1
11 0
0
0
end_DTG
begin_DTG
2
1
124
2
1 2
10 0
2
127
2
0 2
11 0
0
0
end_DTG
begin_DTG
2
1
125
2
1 6
10 0
2
128
2
0 6
11 0
0
0
end_DTG
begin_DTG
2
1
129
2
1 0
10 0
2
135
2
0 0
11 0
0
0
end_DTG
begin_DTG
2
1
130
2
1 1
10 0
2
136
2
0 1
11 0
0
0
end_DTG
begin_DTG
2
1
131
2
1 3
10 0
2
137
2
0 3
11 0
0
0
end_DTG
begin_DTG
2
1
132
2
1 4
10 0
2
138
2
0 4
11 0
0
0
end_DTG
begin_DTG
2
1
133
2
1 6
10 0
2
139
2
0 6
11 0
0
0
end_DTG
begin_DTG
9
1
123
2
1 1
2 0
1
124
2
1 2
3 0
1
125
2
1 6
4 0
1
129
2
1 0
5 0
1
130
2
1 1
6 0
1
131
2
1 3
7 0
1
132
2
1 4
8 0
1
133
2
1 6
9 0
1
134
2
1 7
12 0
1
0
53
0
end_DTG
begin_DTG
9
1
126
2
0 1
2 0
1
127
2
0 2
3 0
1
128
2
0 6
4 0
1
135
2
0 0
5 0
1
136
2
0 1
6 0
1
137
2
0 3
7 0
1
138
2
0 4
8 0
1
139
2
0 6
9 0
1
140
2
0 7
12 0
1
0
54
0
end_DTG
begin_DTG
2
1
134
2
1 7
10 0
2
140
2
0 7
11 0
0
0
end_DTG
begin_DTG
0
12
0
35
2
1 0
9 1
0
36
2
1 1
9 1
0
37
2
1 2
9 1
0
38
2
1 4
9 1
0
39
2
1 6
9 1
0
40
2
1 7
9 1
0
47
2
0 0
9 2
0
48
2
0 1
9 2
0
49
2
0 2
9 2
0
50
2
0 4
9 2
0
51
2
0 6
9 2
0
52
2
0 7
9 2
end_DTG
begin_DTG
0
12
0
29
2
1 0
6 1
0
30
2
1 1
6 1
0
31
2
1 2
6 1
0
32
2
1 4
6 1
0
33
2
1 6
6 1
0
34
2
1 7
6 1
0
41
2
0 0
6 2
0
42
2
0 1
6 2
0
43
2
0 2
6 2
0
44
2
0 4
6 2
0
45
2
0 6
6 2
0
46
2
0 7
6 2
end_DTG
begin_DTG
3
4
55
0
5
56
0
6
57
0
3
2
58
0
5
59
0
6
60
0
2
1
61
0
3
62
0
1
2
63
0
2
0
64
0
5
65
0
4
0
66
0
1
67
0
4
68
0
7
69
0
3
0
70
0
1
71
0
7
72
0
2
5
73
0
6
74
0
end_DTG
begin_DTG
8
1
292
1
15 5
1
319
1
15 6
1
275
1
15 4
1
374
1
15 7
1
175
1
15 0
1
202
1
15 2
1
194
1
15 1
1
230
1
15 3
1
0
4
1
15 1
end_DTG
begin_DTG
8
1
289
1
15 5
1
316
1
15 6
1
272
1
15 4
1
371
1
15 7
1
172
1
15 0
1
199
1
15 2
1
191
1
15 1
1
227
1
15 3
1
0
3
1
15 6
end_DTG
begin_DTG
8
1
286
1
15 5
1
313
1
15 6
1
269
1
15 4
1
368
1
15 7
1
169
1
15 0
1
196
1
15 2
1
188
1
15 1
1
224
1
15 3
3
0
0
1
15 2
0
1
1
15 4
0
2
1
15 6
end_DTG
begin_DTG
0
18
0
278
2
15 5
18 0
0
365
2
15 7
16 0
0
362
2
15 7
17 0
0
359
2
15 7
18 0
0
329
2
15 6
16 0
0
326
2
15 6
17 0
0
323
2
15 6
18 0
0
284
2
15 5
16 0
0
281
2
15 5
17 0
0
152
2
15 0
18 0
0
257
2
15 4
16 0
0
254
2
15 4
17 0
0
251
2
15 4
18 0
0
203
2
15 2
16 0
0
200
2
15 2
17 0
0
197
2
15 2
18 0
0
158
2
15 0
16 0
0
155
2
15 0
17 0
end_DTG
begin_DTG
0
6
0
23
2
15 0
19 0
0
24
2
15 1
19 0
0
25
2
15 2
19 0
0
26
2
15 4
19 0
0
27
2
15 6
19 0
0
28
2
15 7
19 0
end_DTG
begin_DTG
0
18
0
277
2
15 5
18 0
0
364
2
15 7
16 0
0
361
2
15 7
17 0
0
358
2
15 7
18 0
0
328
2
15 6
16 0
0
325
2
15 6
17 0
0
322
2
15 6
18 0
0
283
2
15 5
16 0
0
280
2
15 5
17 0
0
151
2
15 0
18 0
0
256
2
15 4
16 0
0
253
2
15 4
17 0
0
250
2
15 4
18 0
0
202
2
15 2
16 0
0
199
2
15 2
17 0
0
196
2
15 2
18 0
0
157
2
15 0
16 0
0
154
2
15 0
17 0
end_DTG
begin_DTG
0
6
0
17
2
15 0
21 0
0
18
2
15 1
21 0
0
19
2
15 2
21 0
0
20
2
15 4
21 0
0
21
2
15 6
21 0
0
22
2
15 7
21 0
end_DTG
begin_DTG
0
18
0
276
2
15 5
18 0
0
363
2
15 7
16 0
0
360
2
15 7
17 0
0
357
2
15 7
18 0
0
327
2
15 6
16 0
0
324
2
15 6
17 0
0
321
2
15 6
18 0
0
282
2
15 5
16 0
0
279
2
15 5
17 0
0
150
2
15 0
18 0
0
255
2
15 4
16 0
0
252
2
15 4
17 0
0
249
2
15 4
18 0
0
201
2
15 2
16 0
0
198
2
15 2
17 0
0
195
2
15 2
18 0
0
156
2
15 0
16 0
0
153
2
15 0
17 0
end_DTG
begin_DTG
0
6
0
11
2
15 0
23 0
0
12
2
15 1
23 0
0
13
2
15 2
23 0
0
14
2
15 4
23 0
0
15
2
15 6
23 0
0
16
2
15 7
23 0
end_DTG
begin_DTG
0
3
0
312
2
15 6
18 0
0
315
2
15 6
17 0
0
318
2
15 6
16 0
end_DTG
begin_DTG
0
6
0
5
2
15 0
25 0
0
6
2
15 1
25 0
0
7
2
15 2
25 0
0
8
2
15 4
25 0
0
9
2
15 6
25 0
0
10
2
15 7
25 0
end_DTG
begin_CG
12
2 1
3 1
4 1
5 1
6 1
7 1
8 1
9 1
12 1
14 6
13 6
11 9
12
2 1
3 1
4 1
5 1
6 1
7 1
8 1
9 1
12 1
14 6
13 6
10 9
2
10 1
11 1
2
10 1
11 1
2
10 1
11 1
2
10 1
11 1
3
14 12
10 1
11 1
2
10 1
11 1
2
10 1
11 1
3
13 12
10 1
11 1
9
2 1
3 1
4 1
5 1
6 1
7 1
8 1
9 1
12 1
9
2 1
3 1
4 1
5 1
6 1
7 1
8 1
9 1
12 1
2
10 1
11 1
0
0
11
18 81
17 79
16 79
26 6
24 6
22 6
20 6
25 3
23 18
21 18
19 18
4
25 1
23 6
21 6
19 6
4
25 1
23 6
21 6
19 6
4
25 1
23 6
21 6
19 6
1
20 6
0
1
22 6
0
1
24 6
0
1
26 6
0
end_CG
