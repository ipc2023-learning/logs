begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var0
-1
9
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
Atom at(rover1, waypoint7)
Atom at(rover1, waypoint8)
Atom at(rover1, waypoint9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(camera4, rover1)
NegatedAtom calibrated(camera4, rover1)
end_variable
begin_variable
var15
-1
2
Atom calibrated(camera3, rover1)
NegatedAtom calibrated(camera3, rover1)
end_variable
begin_variable
var76
-1
2
Atom have_image(rover1, objective8, high_res)
NegatedAtom have_image(rover1, objective8, high_res)
end_variable
begin_variable
var39
-1
2
Atom communicated_image_data(objective8, high_res)
NegatedAtom communicated_image_data(objective8, high_res)
end_variable
begin_variable
var67
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var30
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var64
-1
2
Atom have_image(rover1, objective4, high_res)
NegatedAtom have_image(rover1, objective4, high_res)
end_variable
begin_variable
var27
-1
2
Atom communicated_image_data(objective4, high_res)
NegatedAtom communicated_image_data(objective4, high_res)
end_variable
begin_variable
var61
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var58
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var21
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var55
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var18
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var14
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var13
-1
2
Atom calibrated(camera1, rover1)
NegatedAtom calibrated(camera1, rover1)
end_variable
begin_variable
var78
-1
2
Atom have_image(rover1, objective9, colour)
NegatedAtom have_image(rover1, objective9, colour)
end_variable
begin_variable
var41
-1
2
Atom communicated_image_data(objective9, colour)
NegatedAtom communicated_image_data(objective9, colour)
end_variable
begin_variable
var77
-1
2
Atom have_image(rover1, objective8, low_res)
NegatedAtom have_image(rover1, objective8, low_res)
end_variable
begin_variable
var40
-1
2
Atom communicated_image_data(objective8, low_res)
NegatedAtom communicated_image_data(objective8, low_res)
end_variable
begin_variable
var75
-1
2
Atom have_image(rover1, objective8, colour)
NegatedAtom have_image(rover1, objective8, colour)
end_variable
begin_variable
var38
-1
2
Atom communicated_image_data(objective8, colour)
NegatedAtom communicated_image_data(objective8, colour)
end_variable
begin_variable
var74
-1
2
Atom have_image(rover1, objective7, low_res)
NegatedAtom have_image(rover1, objective7, low_res)
end_variable
begin_variable
var37
-1
2
Atom communicated_image_data(objective7, low_res)
NegatedAtom communicated_image_data(objective7, low_res)
end_variable
begin_variable
var71
-1
2
Atom have_image(rover1, objective6, low_res)
NegatedAtom have_image(rover1, objective6, low_res)
end_variable
begin_variable
var34
-1
2
Atom communicated_image_data(objective6, low_res)
NegatedAtom communicated_image_data(objective6, low_res)
end_variable
begin_variable
var69
-1
2
Atom have_image(rover1, objective6, colour)
NegatedAtom have_image(rover1, objective6, colour)
end_variable
begin_variable
var32
-1
2
Atom communicated_image_data(objective6, colour)
NegatedAtom communicated_image_data(objective6, colour)
end_variable
begin_variable
var66
-1
2
Atom have_image(rover1, objective5, colour)
NegatedAtom have_image(rover1, objective5, colour)
end_variable
begin_variable
var29
-1
2
Atom communicated_image_data(objective5, colour)
NegatedAtom communicated_image_data(objective5, colour)
end_variable
begin_variable
var65
-1
2
Atom have_image(rover1, objective4, low_res)
NegatedAtom have_image(rover1, objective4, low_res)
end_variable
begin_variable
var28
-1
2
Atom communicated_image_data(objective4, low_res)
NegatedAtom communicated_image_data(objective4, low_res)
end_variable
begin_variable
var63
-1
2
Atom have_image(rover1, objective4, colour)
NegatedAtom have_image(rover1, objective4, colour)
end_variable
begin_variable
var26
-1
2
Atom communicated_image_data(objective4, colour)
NegatedAtom communicated_image_data(objective4, colour)
end_variable
begin_variable
var62
-1
2
Atom have_image(rover1, objective3, low_res)
NegatedAtom have_image(rover1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2 0
0
223
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
25
2
0 6
11 0
end_DTG
begin_DTG
0
10
0
61
2
0 0
2 0
0
63
2
0 0
1 0
0
109
2
0 1
2 0
0
111
2
0 1
1 0
0
325
2
0 6
2 0
0
327
2
0 6
1 0
0
357
2
0 7
2 0
0
359
2
0 7
1 0
0
389
2
0 8
2 0
0
391
2
0 8
1 0
end_DTG
begin_DTG
0
1
0
23
2
0 6
13 0
end_DTG
begin_DTG
9
1
347
1
0 6
1
259
1
0 4
1
275
1
0 5
1
355
1
0 7
1
387
1
0 8
1
155
1
0 2
1
67
1
0 0
1
107
1
0 1
1
187
1
0 3
5
0
5
1
0 0
0
6
1
0 1
0
7
1
0 6
0
8
1
0 7
0
9
1
0 8
end_DTG
begin_DTG
9
1
297
1
0 5
1
338
1
0 6
1
266
1
0 4
1
393
1
0 8
1
378
1
0 7
1
105
1
0 1
1
153
1
0 2
1
98
1
0 0
1
201
1
0 3
5
0
0
1
0 3
0
1
1
0 4
0
2
1
0 5
0
3
1
0 7
0
4
1
0 8
end_DTG
begin_DTG
0
20
0
268
2
0 4
2 0
0
438
2
0 8
1 0
0
436
2
0 8
2 0
0
435
2
0 8
15 0
0
433
2
0 8
16 0
0
318
2
0 5
1 0
0
316
2
0 5
2 0
0
315
2
0 5
15 0
0
313
2
0 5
16 0
0
270
2
0 4
1 0
0
97
2
0 0
16 0
0
267
2
0 4
15 0
0
265
2
0 4
16 0
0
214
2
0 3
1 0
0
212
2
0 3
2 0
0
211
2
0 3
15 0
0
209
2
0 3
16 0
0
102
2
0 0
1 0
0
100
2
0 0
2 0
0
99
2
0 0
15 0
end_DTG
begin_DTG
0
1
0
40
2
0 6
17 0
end_DTG
begin_DTG
0
16
0
90
2
0 0
16 0
0
96
2
0 0
1 0
0
146
2
0 1
16 0
0
152
2
0 1
1 0
0
178
2
0 2
16 0
0
184
2
0 2
1 0
0
202
2
0 3
16 0
0
208
2
0 3
1 0
0
258
2
0 4
16 0
0
264
2
0 4
1 0
0
346
2
0 6
16 0
0
352
2
0 6
1 0
0
378
2
0 7
16 0
0
384
2
0 7
1 0
0
426
2
0 8
16 0
0
432
2
0 8
1 0
end_DTG
begin_DTG
0
1
0
39
2
0 6
19 0
end_DTG
begin_DTG
0
32
0
257
2
0 4
16 0
0
430
2
0 8
1 0
0
428
2
0 8
2 0
0
427
2
0 8
15 0
0
425
2
0 8
16 0
0
382
2
0 7
1 0
0
380
2
0 7
2 0
0
379
2
0 7
15 0
0
377
2
0 7
16 0
0
350
2
0 6
1 0
0
348
2
0 6
2 0
0
347
2
0 6
15 0
0
345
2
0 6
16 0
0
262
2
0 4
1 0
0
260
2
0 4
2 0
0
259
2
0 4
15 0
0
89
2
0 0
16 0
0
206
2
0 3
1 0
0
204
2
0 3
2 0
0
203
2
0 3
15 0
0
201
2
0 3
16 0
0
182
2
0 2
1 0
0
180
2
0 2
2 0
0
179
2
0 2
15 0
0
177
2
0 2
16 0
0
150
2
0 1
1 0
0
148
2
0 1
2 0
0
147
2
0 1
15 0
0
145
2
0 1
16 0
0
94
2
0 0
1 0
0
92
2
0 0
2 0
0
91
2
0 0
15 0
end_DTG
begin_DTG
0
1
0
37
2
0 6
21 0
end_DTG
begin_DTG
0
10
0
138
2
0 1
16 0
0
144
2
0 1
1 0
0
170
2
0 2
16 0
0
176
2
0 2
1 0
0
250
2
0 4
16 0
0
256
2
0 4
1 0
0
306
2
0 5
16 0
0
312
2
0 5
1 0
0
418
2
0 8
16 0
0
424
2
0 8
1 0
end_DTG
begin_DTG
0
1
0
36
2
0 6
23 0
end_DTG
begin_DTG
0
10
0
82
2
0 0
16 0
0
88
2
0 0
1 0
0
130
2
0 1
16 0
0
136
2
0 1
1 0
0
298
2
0 5
16 0
0
304
2
0 5
1 0
0
338
2
0 6
16 0
0
344
2
0 6
1 0
0
410
2
0 8
16 0
0
416
2
0 8
1 0
end_DTG
begin_DTG
0
1
0
35
2
0 6
25 0
end_DTG
begin_DTG
0
20
0
300
2
0 5
2 0
0
414
2
0 8
1 0
0
412
2
0 8
2 0
0
411
2
0 8
15 0
0
409
2
0 8
16 0
0
342
2
0 6
1 0
0
340
2
0 6
2 0
0
339
2
0 6
15 0
0
337
2
0 6
16 0
0
302
2
0 5
1 0
0
81
2
0 0
16 0
0
299
2
0 5
15 0
0
297
2
0 5
16 0
0
134
2
0 1
1 0
0
132
2
0 1
2 0
0
131
2
0 1
15 0
0
129
2
0 1
16 0
0
86
2
0 0
1 0
0
84
2
0 0
2 0
0
83
2
0 0
15 0
end_DTG
begin_DTG
0
1
0
34
2
0 6
27 0
end_DTG
begin_DTG
0
20
0
292
2
0 5
2 0
0
406
2
0 8
1 0
0
404
2
0 8
2 0
0
403
2
0 8
15 0
0
401
2
0 8
16 0
0
374
2
0 7
1 0
0
372
2
0 7
2 0
0
371
2
0 7
15 0
0
369
2
0 7
16 0
0
294
2
0 5
1 0
0
193
2
0 3
16 0
0
291
2
0 5
15 0
0
289
2
0 5
16 0
0
246
2
0 4
1 0
0
244
2
0 4
2 0
0
243
2
0 4
15 0
0
241
2
0 4
16 0
0
198
2
0 3
1 0
0
196
2
0 3
2 0
0
195
2
0 3
15 0
end_DTG
begin_DTG
0
1
0
32
2
0 6
29 0
end_DTG
begin_DTG
0
14
0
74
2
0 0
16 0
0
80
2
0 0
1 0
0
122
2
0 1
16 0
0
128
2
0 1
1 0
0
162
2
0 2
16 0
0
168
2
0 2
1 0
0
234
2
0 4
16 0
0
240
2
0 4
1 0
0
282
2
0 5
16 0
0
288
2
0 5
1 0
0
362
2
0 7
16 0
0
368
2
0 7
1 0
0
394
2
0 8
16 0
0
400
2
0 8
1 0
end_DTG
begin_DTG
0
1
0
31
2
0 6
31 0
end_DTG
begin_DTG
0
28
0
236
2
0 4
2 0
0
398
2
0 8
1 0
0
396
2
0 8
2 0
0
395
2
0 8
15 0
0
393
2
0 8
16 0
0
366
2
0 7
1 0
0
364
2
0 7
2 0
0
363
2
0 7
15 0
0
361
2
0 7
16 0
0
286
2
0 5
1 0
0
284
2
0 5
2 0
0
283
2
0 5
15 0
0
281
2
0 5
16 0
0
238
2
0 4
1 0
0
73
2
0 0
16 0
0
235
2
0 4
15 0
0
233
2
0 4
16 0
0
166
2
0 2
1 0
0
164
2
0 2
2 0
0
163
2
0 2
15 0
0
161
2
0 2
16 0
0
126
2
0 1
1 0
0
124
2
0 1
2 0
0
123
2
0 1
15 0
0
121
2
0 1
16 0
0
78
2
0 0
1 0
0
76
2
0 0
2 0
0
75
2
0 0
15 0
end_DTG
begin_DTG
0
1
0
29
2
0 6
33 0
end_DTG
begin_DTG
0
14
0
66
2
0 0
16 0
0
72
2
0 0
1 0
0
114
2
0 1
16 0
0
120
2
0 1
1 0
0
154
2
0 2
16 0
0
160
2
0 2
1 0
0
186
2
0 3
16 0
0
192
2
0 3
1 0
0
226
2
0 4
16 0
0
232
2
0 4
1 0
0
274
2
0 5
16 0
0
280
2
0 5
1 0
0
330
2
0 6
16 0
0
336
2
0 6
1 0
end_DTG
begin_DTG
0
1
0
28
2
0 6
35 0
end_DTG
begin_DTG
0
2
0
218
2
0 4
16 0
0
224
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
26
2
0 6
37 0
end_DTG
begin_DTG
0
4
0
217
2
0 4
16 0
0
219
2
0 4
15 0
0
220
2
0 4
2 0
0
222
2
0 4
1 0
end_DTG
begin_DTG
0
1
0
24
2
0 6
39 0
end_DTG
begin_CG
40
16 101
15 53
2 104
1 149
14 1
40 1
12 1
38 1
10 1
36 1
34 1
8 1
32 1
30 1
6 1
28 1
26 1
24 1
22 1
4 1
20 1
18 1
13 10
39 4
11 2
37 2
9 14
35 14
33 28
7 14
31 14
29 20
5 10
27 20
25 10
23 10
21 32
3 16
19 16
17 20
18
13 5
39 1
11 1
37 1
9 7
35 7
33 7
7 7
31 7
29 5
5 5
27 5
25 5
23 5
21 8
3 8
19 8
17 5
12
13 5
39 1
11 1
9 7
33 7
7 7
29 5
5 5
27 5
21 8
3 8
17 5
1
4 1
0
1
6 1
0
1
8 1
0
1
10 1
0
1
12 1
0
1
14 1
0
6
39 1
33 7
29 5
27 5
21 8
17 5
12
39 1
37 1
35 7
33 7
31 7
29 5
27 5
25 5
23 5
21 8
19 8
17 5
1
18 1
0
1
20 1
0
1
22 1
0
1
24 1
0
1
26 1
0
1
28 1
0
1
30 1
0
1
32 1
0
1
34 1
0
1
36 1
0
1
38 1
0
1
40 1
0
end_CG
