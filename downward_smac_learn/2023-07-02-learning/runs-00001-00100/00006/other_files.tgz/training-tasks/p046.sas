begin_version
3
end_version
begin_metric
0
end_metric
35
begin_variable
var1
-1
6
Atom at(rover2, waypoint1)
Atom at(rover2, waypoint2)
Atom at(rover2, waypoint3)
Atom at(rover2, waypoint4)
Atom at(rover2, waypoint5)
Atom at(rover2, waypoint6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(camera1, rover2)
NegatedAtom calibrated(camera1, rover2)
end_variable
begin_variable
var52
-1
2
Atom have_image(rover2, objective5, low_res)
NegatedAtom have_image(rover2, objective5, low_res)
end_variable
begin_variable
var47
-1
2
Atom have_image(rover2, objective3, colour)
NegatedAtom have_image(rover2, objective3, colour)
end_variable
begin_variable
var16
-1
2
Atom communicated_image_data(objective3, colour)
NegatedAtom communicated_image_data(objective3, colour)
end_variable
begin_variable
var46
-1
2
Atom have_image(rover2, objective2, low_res)
NegatedAtom have_image(rover2, objective2, low_res)
end_variable
begin_variable
var45
-1
2
Atom have_image(rover2, objective2, colour)
NegatedAtom have_image(rover2, objective2, colour)
end_variable
begin_variable
var13
-1
2
Atom communicated_image_data(objective2, colour)
NegatedAtom communicated_image_data(objective2, colour)
end_variable
begin_variable
var43
-1
2
Atom have_image(rover2, objective1, colour)
NegatedAtom have_image(rover2, objective1, colour)
end_variable
begin_variable
var10
-1
2
Atom communicated_image_data(objective1, colour)
NegatedAtom communicated_image_data(objective1, colour)
end_variable
begin_variable
var0
-1
6
Atom at(rover1, waypoint1)
Atom at(rover1, waypoint2)
Atom at(rover1, waypoint3)
Atom at(rover1, waypoint4)
Atom at(rover1, waypoint5)
Atom at(rover1, waypoint6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(camera2, rover1)
NegatedAtom calibrated(camera2, rover1)
end_variable
begin_variable
var42
-1
2
Atom have_image(rover1, objective5, low_res)
NegatedAtom have_image(rover1, objective5, low_res)
end_variable
begin_variable
var24
-1
2
Atom communicated_image_data(objective5, low_res)
NegatedAtom communicated_image_data(objective5, low_res)
end_variable
begin_variable
var41
-1
2
Atom have_image(rover1, objective5, high_res)
NegatedAtom have_image(rover1, objective5, high_res)
end_variable
begin_variable
var23
-1
2
Atom communicated_image_data(objective5, high_res)
NegatedAtom communicated_image_data(objective5, high_res)
end_variable
begin_variable
var37
-1
2
Atom have_image(rover1, objective3, high_res)
NegatedAtom have_image(rover1, objective3, high_res)
end_variable
begin_variable
var17
-1
2
Atom communicated_image_data(objective3, high_res)
NegatedAtom communicated_image_data(objective3, high_res)
end_variable
begin_variable
var36
-1
2
Atom have_image(rover1, objective2, low_res)
NegatedAtom have_image(rover1, objective2, low_res)
end_variable
begin_variable
var15
-1
2
Atom communicated_image_data(objective2, low_res)
NegatedAtom communicated_image_data(objective2, low_res)
end_variable
begin_variable
var35
-1
2
Atom have_image(rover1, objective2, high_res)
NegatedAtom have_image(rover1, objective2, high_res)
end_variable
begin_variable
var14
-1
2
Atom communicated_image_data(objective2, high_res)
NegatedAtom communicated_image_data(objective2, high_res)
end_variable
begin_variable
var33
-1
2
Atom have_image(rover1, objective1, high_res)
NegatedAtom have_image(rover1, objective1, high_res)
end_variable
begin_variable
var11
-1
2
Atom communicated_image_data(objective1, high_res)
NegatedAtom communicated_image_data(objective1, high_res)
end_variable
begin_variable
var2
-1
2
Atom at_rock_sample(waypoint1)
Atom have_rock_analysis(rover2, waypoint1)
end_variable
begin_variable
var3
-1
2
Atom at_rock_sample(waypoint5)
Atom have_rock_analysis(rover2, waypoint5)
end_variable
begin_variable
var4
-1
3
Atom at_soil_sample(waypoint1)
Atom have_soil_analysis(rover1, waypoint1)
Atom have_soil_analysis(rover2, waypoint1)
end_variable
begin_variable
var5
-1
3
Atom at_soil_sample(waypoint2)
Atom have_soil_analysis(rover1, waypoint2)
Atom have_soil_analysis(rover2, waypoint2)
end_variable
begin_variable
var6
-1
3
Atom at_soil_sample(waypoint3)
Atom have_soil_analysis(rover1, waypoint3)
Atom have_soil_analysis(rover2, waypoint3)
end_variable
begin_variable
var31
-1
2
Atom empty(rover1store)
Atom full(rover1store)
end_variable
begin_variable
var32
-1
2
Atom empty(rover2store)
Atom full(rover2store)
end_variable
begin_variable
var7
-1
3
Atom at_soil_sample(waypoint5)
Atom have_soil_analysis(rover1, waypoint5)
Atom have_soil_analysis(rover2, waypoint5)
end_variable
begin_variable
var29
-1
2
Atom communicated_soil_data(waypoint3)
NegatedAtom communicated_soil_data(waypoint3)
end_variable
begin_variable
var26
-1
2
Atom communicated_rock_data(waypoint5)
NegatedAtom communicated_rock_data(waypoint5)
end_variable
begin_variable
var27
-1
2
Atom communicated_soil_data(waypoint1)
NegatedAtom communicated_soil_data(waypoint1)
end_variable
0
begin_state
2
1
1
1
1
1
1
1
1
1
3
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
1
1
1
end_state
begin_goal
12
4 0
7 0
9 0
13 0
15 0
17 0
19 0
21 0
23 0
32 0
33 0
34 0
end_goal
193
begin_operator
calibrate rover1 camera2 objective4 waypoint1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




heck 0
check 0
switch 25
check 0
check 0
check 1
45
switch 26
check 0
check 0
check 0
check 1
54
switch 28
check 0
switch 30
check 0
check 1
95
check 0
check 0
check 0
check 1
57
switch 1
check 0
check 8
163
164
165
166
167
168
169
170
check 0
switch 8
check 0
check 1
30
check 0
switch 6
check 0
check 1
33
check 0
switch 5
check 0
check 1
36
check 0
switch 3
check 0
check 1
39
check 0
switch 2
check 0
check 1
42
check 0
check 0
switch 24
check 4
8
80
81
82
check 0
check 0
switch 25
check 0
check 0
check 1
46
switch 26
check 0
check 0
check 0
check 1
55
switch 28
check 0
check 0
check 0
check 1
58
switch 1
check 0
check 8
171
172
173
174
175
176
177
178
check 0
switch 8
check 0
check 1
31
check 0
switch 6
check 0
check 1
34
check 0
switch 5
check 0
check 1
37
check 0
switch 3
check 0
check 1
40
check 0
switch 2
check 0
check 1
43
check 0
check 0
switch 24
check 3
9
83
84
check 0
check 0
switch 25
check 0
switch 30
check 0
check 1
88
check 0
check 0
check 0
switch 31
check 0
switch 30
check 0
check 1
96
check 0
check 0
check 0
check 0
switch 1
check 0
check 4
179
180
181
182
check 0
check 0
switch 24
check 3
10
85
86
check 0
check 0
switch 1
check 0
check 10
183
184
185
186
187
188
189
190
191
192
check 0
check 0
switch 29
check 0
check 0
check 1
59
switch 30
check 0
check 0
check 1
60
check 0
end_SG
begin_DTG
2
4
73
0
5
74
0
2
2
75
0
3
76
0
3
1
77
0
3
78
0
4
79
0
3
1
80
0
2
81
0
5
82
0
2
0
83
0
2
84
0
2
0
85
0
3
86
0
end_DTG
begin_DTG
6
1
181
1
0 4
1
170
1
0 2
1
171
1
0 3
1
183
1
0 5
1
157
1
0 1
1
146
1
0 0
6
0
5
1
0 0
0
6
1
0 1
0
7
1
0 2
0
8
1
0 3
0
9
1
0 4
0
10
1
0 5
end_DTG
begin_DTG
0
5
0
152
2
0 0
1 0
0
162
2
0 1
1 0
0
170
2
0 2
1 0
0
182
2
0 4
1 0
0
192
2
0 5
1 0
end_DTG
begin_DTG
0
5
0
147
2
0 0
1 0
0
157
2
0 1
1 0
0
165
2
0 2
1 0
0
175
2
0 3
1 0
0
187
2
0 5
1 0
end_DTG
begin_DTG
0
3
0
38
2
0 0
3 0
0
39
2
0 2
3 0
0
40
2
0 3
3 0
end_DTG
begin_DTG
0
6
0
146
2
0 0
1 0
0
156
2
0 1
1 0
0
164
2
0 2
1 0
0
174
2
0 3
1 0
0
180
2
0 4
1 0
0
186
2
0 5
1 0
end_DTG
begin_DTG
0
6
0
145
2
0 0
1 0
0
155
2
0 1
1 0
0
163
2
0 2
1 0
0
173
2
0 3
1 0
0
179
2
0 4
1 0
0
185
2
0 5
1 0
end_DTG
begin_DTG
0
3
0
32
2
0 0
6 0
0
33
2
0 2
6 0
0
34
2
0 3
6 0
end_DTG
begin_DTG
0
3
0
153
2
0 1
1 0
0
171
2
0 3
1 0
0
183
2
0 5
1 0
end_DTG
begin_DTG
0
3
0
29
2
0 0
8 0
0
30
2
0 2
8 0
0
31
2
0 3
8 0
end_DTG
begin_DTG
3
3
61
0
4
62
0
5
63
0
1
2
64
0
2
1
65
0
4
66
0
2
0
67
0
5
68
0
2
0
69
0
2
70
0
2
0
71
0
3
72
0
end_DTG
begin_DTG
6
1
133
1
10 4
1
122
1
10 2
1
123
1
10 3
1
135
1
10 5
1
109
1
10 1
1
98
1
10 0
5
0
0
1
10 0
0
1
1
10 1
0
2
1
10 2
0
3
1
10 3
0
4
1
10 5
end_DTG
begin_DTG
0
5
0
104
2
10 0
11 0
0
114
2
10 1
11 0
0
122
2
10 2
11 0
0
134
2
10 4
11 0
0
144
2
10 5
11 0
end_DTG
begin_DTG
0
6
0
26
2
10 0
12 0
0
27
2
10 2
12 0
0
28
2
10 3
12 0
0
41
2
0 0
2 0
0
42
2
0 2
2 0
0
43
2
0 3
2 0
end_DTG
begin_DTG
0
5
0
103
2
10 0
11 0
0
113
2
10 1
11 0
0
121
2
10 2
11 0
0
133
2
10 4
11 0
0
143
2
10 5
11 0
end_DTG
begin_DTG
0
3
0
23
2
10 0
14 0
0
24
2
10 2
14 0
0
25
2
10 3
14 0
end_DTG
begin_DTG
0
5
0
99
2
10 0
11 0
0
109
2
10 1
11 0
0
117
2
10 2
11 0
0
127
2
10 3
11 0
0
139
2
10 5
11 0
end_DTG
begin_DTG
0
3
0
20
2
10 0
16 0
0
21
2
10 2
16 0
0
22
2
10 3
16 0
end_DTG
begin_DTG
0
6
0
98
2
10 0
11 0
0
108
2
10 1
11 0
0
116
2
10 2
11 0
0
126
2
10 3
11 0
0
132
2
10 4
11 0
0
138
2
10 5
11 0
end_DTG
begin_DTG
0
6
0
17
2
10 0
18 0
0
18
2
10 2
18 0
0
19
2
10 3
18 0
0
35
2
0 0
5 0
0
36
2
0 2
5 0
0
37
2
0 3
5 0
end_DTG
begin_DTG
0
6
0
97
2
10 0
11 0
0
107
2
10 1
11 0
0
115
2
10 2
11 0
0
125
2
10 3
11 0
0
131
2
10 4
11 0
0
137
2
10 5
11 0
end_DTG
begin_DTG
0
3
0
14
2
10 0
20 0
0
15
2
10 2
20 0
0
16
2
10 3
20 0
end_DTG
begin_DTG
0
3
0
105
2
10 1
11 0
0
123
2
10 3
11 0
0
135
2
10 5
11 0
end_DTG
begin_DTG
0
3
0
11
2
10 0
22 0
0
12
2
10 2
22 0
0
13
2
10 3
22 0
end_DTG
begin_DTG
1
1
87
2
0 0
30 0
0
end_DTG
begin_DTG
1
1
88
2
0 4
30 0
0
end_DTG
begin_DTG
2
1
89
2
10 0
29 0
2
93
2
0 0
30 0
0
0
end_DTG
begin_DTG
2
1
90
2
10 1
29 0
2
94
2
0 1
30 0
0
0
end_DTG
begin_DTG
2
1
91
2
10 2
29 0
2
95
2
0 2
30 0
0
0
end_DTG
begin_DTG
4
1
89
2
10 0
26 0
1
90
2
10 1
27 0
1
91
2
10 2
28 0
1
92
2
10 4
31 0
1
0
59
0
end_DTG
begin_DTG
6
1
87
2
0 0
24 0
1
88
2
0 4
25 0
1
93
2
0 0
26 0
1
94
2
0 1
27 0
1
95
2
0 2
28 0
1
96
2
0 4
31 0
1
0
60
0
end_DTG
begin_DTG
2
1
92
2
10 4
29 0
2
96
2
0 4
30 0
0
0
end_DTG
begin_DTG
0
6
0
50
2
10 0
28 1
0
51
2
10 2
28 1
0
52
2
10 3
28 1
0
56
2
0 0
28 2
0
57
2
0 2
28 2
0
58
2
0 3
28 2
end_DTG
begin_DTG
0
3
0
44
2
0 0
25 1
0
45
2
0 2
25 1
0
46
2
0 3
25 1
end_DTG
begin_DTG
0
6
0
47
2
10 0
26 1
0
48
2
10 2
26 1
0
49
2
10 3
26 1
0
53
2
0 0
26 2
0
54
2
0 2
26 2
0
55
2
0 3
26 2
end_DTG
begin_CG
21
24 1
25 1
26 1
27 1
28 1
31 1
1 54
9 3
7 3
19 3
4 3
13 3
33 3
34 3
32 3
30 6
8 3
6 6
5 6
3 5
2 5
5
8 3
6 6
5 6
3 5
2 5
1
13 3
1
4 3
0
1
19 3
1
7 3
0
1
9 3
0
20
26 1
27 1
28 1
31 1
11 53
23 3
21 3
19 3
17 3
15 3
13 3
34 3
32 3
29 4
22 3
20 6
18 6
16 5
14 5
12 5
6
22 3
20 6
18 6
16 5
14 5
12 5
1
13 3
0
1
15 3
0
1
17 3
0
1
19 3
0
1
21 3
0
1
23 3
0
1
30 1
2
33 3
30 1
3
34 6
29 1
30 1
2
29 1
30 1
3
32 6
29 1
30 1
4
26 1
27 1
28 1
31 1
6
24 1
25 1
26 1
27 1
28 1
31 1
2
29 1
30 1
0
0
0
end_CG
