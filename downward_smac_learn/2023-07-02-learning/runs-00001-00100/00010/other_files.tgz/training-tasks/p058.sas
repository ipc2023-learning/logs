begin_version
3
end_version
begin_metric
0
end_metric
20
begin_variable
var14
-1
12
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var13
-1
12
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var12
-1
12
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var11
-1
12
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var10
-1
12
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var15
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
17
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
17
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
17
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var3
-1
17
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var4
-1
17
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var5
-1
17
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var6
-1
17
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var7
-1
17
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var8
-1
17
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var9
-1
17
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l12)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
9
6
10
1
4
2
2
1
1
1
6
11
5
4
7
3
9
11
2
3
end_state
begin_goal
10
10 3
11 4
12 3
13 1
14 3
15 5
16 1
17 9
18 4
19 4
end_goal
2780
begin_operator
drive v1 l1 l12
0
1
0 4 0 3
0
end_operator
beg




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
2 0
7 1
14
2079
2
2 0
7 2
15
2318
2
1 0
8 1
15
2319
2
1 0
8 2
16
2558
2
0 0
9 1
16
2559
2
0 0
9 2
10
12
1618
2
4 1
5 1
12
1619
2
4 1
5 2
13
1858
2
3 1
6 1
13
1859
2
3 1
6 2
14
2098
2
2 1
7 1
14
2099
2
2 1
7 2
15
2338
2
1 1
8 1
15
2339
2
1 1
8 2
16
2578
2
0 1
9 1
16
2579
2
0 1
9 2
10
12
1638
2
4 2
5 1
12
1639
2
4 2
5 2
13
1878
2
3 2
6 1
13
1879
2
3 2
6 2
14
2118
2
2 2
7 1
14
2119
2
2 2
7 2
15
2358
2
1 2
8 1
15
2359
2
1 2
8 2
16
2598
2
0 2
9 1
16
2599
2
0 2
9 2
10
12
1658
2
4 3
5 1
12
1659
2
4 3
5 2
13
1898
2
3 3
6 1
13
1899
2
3 3
6 2
14
2138
2
2 3
7 1
14
2139
2
2 3
7 2
15
2378
2
1 3
8 1
15
2379
2
1 3
8 2
16
2618
2
0 3
9 1
16
2619
2
0 3
9 2
10
12
1678
2
4 4
5 1
12
1679
2
4 4
5 2
13
1918
2
3 4
6 1
13
1919
2
3 4
6 2
14
2158
2
2 4
7 1
14
2159
2
2 4
7 2
15
2398
2
1 4
8 1
15
2399
2
1 4
8 2
16
2638
2
0 4
9 1
16
2639
2
0 4
9 2
10
12
1698
2
4 5
5 1
12
1699
2
4 5
5 2
13
1938
2
3 5
6 1
13
1939
2
3 5
6 2
14
2178
2
2 5
7 1
14
2179
2
2 5
7 2
15
2418
2
1 5
8 1
15
2419
2
1 5
8 2
16
2658
2
0 5
9 1
16
2659
2
0 5
9 2
10
12
1718
2
4 6
5 1
12
1719
2
4 6
5 2
13
1958
2
3 6
6 1
13
1959
2
3 6
6 2
14
2198
2
2 6
7 1
14
2199
2
2 6
7 2
15
2438
2
1 6
8 1
15
2439
2
1 6
8 2
16
2678
2
0 6
9 1
16
2679
2
0 6
9 2
10
12
1738
2
4 7
5 1
12
1739
2
4 7
5 2
13
1978
2
3 7
6 1
13
1979
2
3 7
6 2
14
2218
2
2 7
7 1
14
2219
2
2 7
7 2
15
2458
2
1 7
8 1
15
2459
2
1 7
8 2
16
2698
2
0 7
9 1
16
2699
2
0 7
9 2
10
12
1758
2
4 8
5 1
12
1759
2
4 8
5 2
13
1998
2
3 8
6 1
13
1999
2
3 8
6 2
14
2238
2
2 8
7 1
14
2239
2
2 8
7 2
15
2478
2
1 8
8 1
15
2479
2
1 8
8 2
16
2718
2
0 8
9 1
16
2719
2
0 8
9 2
10
12
1778
2
4 9
5 1
12
1779
2
4 9
5 2
13
2018
2
3 9
6 1
13
2019
2
3 9
6 2
14
2258
2
2 9
7 1
14
2259
2
2 9
7 2
15
2498
2
1 9
8 1
15
2499
2
1 9
8 2
16
2738
2
0 9
9 1
16
2739
2
0 9
9 2
10
12
1798
2
4 10
5 1
12
1799
2
4 10
5 2
13
2038
2
3 10
6 1
13
2039
2
3 10
6 2
14
2278
2
2 10
7 1
14
2279
2
2 10
7 2
15
2518
2
1 10
8 1
15
2519
2
1 10
8 2
16
2758
2
0 10
9 1
16
2759
2
0 10
9 2
10
12
1818
2
4 11
5 1
12
1819
2
4 11
5 2
13
2058
2
3 11
6 1
13
2059
2
3 11
6 2
14
2298
2
2 11
7 1
14
2299
2
2 11
7 2
15
2538
2
1 11
8 1
15
2539
2
1 11
8 2
16
2778
2
0 11
9 1
16
2779
2
0 11
9 2
24
0
399
2
4 0
5 1
0
398
2
4 0
5 0
1
418
2
4 1
5 0
1
419
2
4 1
5 1
2
438
2
4 2
5 0
2
439
2
4 2
5 1
3
458
2
4 3
5 0
3
459
2
4 3
5 1
4
478
2
4 4
5 0
4
479
2
4 4
5 1
5
498
2
4 5
5 0
5
499
2
4 5
5 1
6
518
2
4 6
5 0
6
519
2
4 6
5 1
7
538
2
4 7
5 0
7
539
2
4 7
5 1
8
558
2
4 8
5 0
8
559
2
4 8
5 1
9
578
2
4 9
5 0
9
579
2
4 9
5 1
10
598
2
4 10
5 0
10
599
2
4 10
5 1
11
618
2
4 11
5 0
11
619
2
4 11
5 1
24
0
639
2
3 0
6 1
0
638
2
3 0
6 0
1
658
2
3 1
6 0
1
659
2
3 1
6 1
2
678
2
3 2
6 0
2
679
2
3 2
6 1
3
698
2
3 3
6 0
3
699
2
3 3
6 1
4
718
2
3 4
6 0
4
719
2
3 4
6 1
5
738
2
3 5
6 0
5
739
2
3 5
6 1
6
758
2
3 6
6 0
6
759
2
3 6
6 1
7
778
2
3 7
6 0
7
779
2
3 7
6 1
8
798
2
3 8
6 0
8
799
2
3 8
6 1
9
818
2
3 9
6 0
9
819
2
3 9
6 1
10
838
2
3 10
6 0
10
839
2
3 10
6 1
11
858
2
3 11
6 0
11
859
2
3 11
6 1
24
0
879
2
2 0
7 1
0
878
2
2 0
7 0
1
898
2
2 1
7 0
1
899
2
2 1
7 1
2
918
2
2 2
7 0
2
919
2
2 2
7 1
3
938
2
2 3
7 0
3
939
2
2 3
7 1
4
958
2
2 4
7 0
4
959
2
2 4
7 1
5
978
2
2 5
7 0
5
979
2
2 5
7 1
6
998
2
2 6
7 0
6
999
2
2 6
7 1
7
1018
2
2 7
7 0
7
1019
2
2 7
7 1
8
1038
2
2 8
7 0
8
1039
2
2 8
7 1
9
1058
2
2 9
7 0
9
1059
2
2 9
7 1
10
1078
2
2 10
7 0
10
1079
2
2 10
7 1
11
1098
2
2 11
7 0
11
1099
2
2 11
7 1
24
0
1119
2
1 0
8 1
0
1118
2
1 0
8 0
1
1138
2
1 1
8 0
1
1139
2
1 1
8 1
2
1158
2
1 2
8 0
2
1159
2
1 2
8 1
3
1178
2
1 3
8 0
3
1179
2
1 3
8 1
4
1198
2
1 4
8 0
4
1199
2
1 4
8 1
5
1218
2
1 5
8 0
5
1219
2
1 5
8 1
6
1238
2
1 6
8 0
6
1239
2
1 6
8 1
7
1258
2
1 7
8 0
7
1259
2
1 7
8 1
8
1278
2
1 8
8 0
8
1279
2
1 8
8 1
9
1298
2
1 9
8 0
9
1299
2
1 9
8 1
10
1318
2
1 10
8 0
10
1319
2
1 10
8 1
11
1338
2
1 11
8 0
11
1339
2
1 11
8 1
24
0
1359
2
0 0
9 1
0
1358
2
0 0
9 0
1
1378
2
0 1
9 0
1
1379
2
0 1
9 1
2
1398
2
0 2
9 0
2
1399
2
0 2
9 1
3
1418
2
0 3
9 0
3
1419
2
0 3
9 1
4
1438
2
0 4
9 0
4
1439
2
0 4
9 1
5
1458
2
0 5
9 0
5
1459
2
0 5
9 1
6
1478
2
0 6
9 0
6
1479
2
0 6
9 1
7
1498
2
0 7
9 0
7
1499
2
0 7
9 1
8
1518
2
0 8
9 0
8
1519
2
0 8
9 1
9
1538
2
0 9
9 0
9
1539
2
0 9
9 1
10
1558
2
0 10
9 0
10
1559
2
0 10
9 1
11
1578
2
0 11
9 0
11
1579
2
0 11
9 1
end_DTG
begin_CG
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
9 480
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
8 480
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
7 480
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
6 480
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
5 480
10
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
10
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
10
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
10
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
10
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
end_CG
