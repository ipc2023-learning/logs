begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var10
-1
9
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var9
-1
9
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var8
-1
9
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var7
-1
9
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var11
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
13
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
13
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
13
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
13
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
13
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
13
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
13
Atom at(p7, l1)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
0
begin_state
2
8
4
3
1
2
2
1
2
4
2
0
6
7
1
end_state
begin_goal
7
8 6
9 0
10 4
11 5
12 8
13 3
14 7
end_goal
1208
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 3 0 8
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l4 l9
0
1
0 3 3 8
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l9
0
1
0 3 4 8
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l9
0
1
0 3 5 8
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
driv




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7 2
8
9
742
2
3 2
4 1
9
743
2
3 2
4 2
10
868
2
2 2
5 1
10
869
2
2 2
5 2
11
994
2
1 2
6 1
11
995
2
1 2
6 2
12
1120
2
0 2
7 1
12
1121
2
0 2
7 2
8
9
756
2
3 3
4 1
9
757
2
3 3
4 2
10
882
2
2 3
5 1
10
883
2
2 3
5 2
11
1008
2
1 3
6 1
11
1009
2
1 3
6 2
12
1134
2
0 3
7 1
12
1135
2
0 3
7 2
8
9
770
2
3 4
4 1
9
771
2
3 4
4 2
10
896
2
2 4
5 1
10
897
2
2 4
5 2
11
1022
2
1 4
6 1
11
1023
2
1 4
6 2
12
1148
2
0 4
7 1
12
1149
2
0 4
7 2
8
9
784
2
3 5
4 1
9
785
2
3 5
4 2
10
910
2
2 5
5 1
10
911
2
2 5
5 2
11
1036
2
1 5
6 1
11
1037
2
1 5
6 2
12
1162
2
0 5
7 1
12
1163
2
0 5
7 2
8
9
798
2
3 6
4 1
9
799
2
3 6
4 2
10
924
2
2 6
5 1
10
925
2
2 6
5 2
11
1050
2
1 6
6 1
11
1051
2
1 6
6 2
12
1176
2
0 6
7 1
12
1177
2
0 6
7 2
8
9
812
2
3 7
4 1
9
813
2
3 7
4 2
10
938
2
2 7
5 1
10
939
2
2 7
5 2
11
1064
2
1 7
6 1
11
1065
2
1 7
6 2
12
1190
2
0 7
7 1
12
1191
2
0 7
7 2
8
9
826
2
3 8
4 1
9
827
2
3 8
4 2
10
952
2
2 8
5 1
10
953
2
2 8
5 2
11
1078
2
1 8
6 1
11
1079
2
1 8
6 2
12
1204
2
0 8
7 1
12
1205
2
0 8
7 2
18
0
211
2
3 0
4 1
0
210
2
3 0
4 0
1
224
2
3 1
4 0
1
225
2
3 1
4 1
2
238
2
3 2
4 0
2
239
2
3 2
4 1
3
252
2
3 3
4 0
3
253
2
3 3
4 1
4
267
2
3 4
4 1
4
266
2
3 4
4 0
5
280
2
3 5
4 0
5
281
2
3 5
4 1
6
294
2
3 6
4 0
6
295
2
3 6
4 1
7
308
2
3 7
4 0
7
309
2
3 7
4 1
8
322
2
3 8
4 0
8
323
2
3 8
4 1
18
0
337
2
2 0
5 1
0
336
2
2 0
5 0
1
350
2
2 1
5 0
1
351
2
2 1
5 1
2
364
2
2 2
5 0
2
365
2
2 2
5 1
3
378
2
2 3
5 0
3
379
2
2 3
5 1
4
393
2
2 4
5 1
4
392
2
2 4
5 0
5
406
2
2 5
5 0
5
407
2
2 5
5 1
6
420
2
2 6
5 0
6
421
2
2 6
5 1
7
434
2
2 7
5 0
7
435
2
2 7
5 1
8
448
2
2 8
5 0
8
449
2
2 8
5 1
18
0
463
2
1 0
6 1
0
462
2
1 0
6 0
1
476
2
1 1
6 0
1
477
2
1 1
6 1
2
490
2
1 2
6 0
2
491
2
1 2
6 1
3
504
2
1 3
6 0
3
505
2
1 3
6 1
4
519
2
1 4
6 1
4
518
2
1 4
6 0
5
532
2
1 5
6 0
5
533
2
1 5
6 1
6
546
2
1 6
6 0
6
547
2
1 6
6 1
7
560
2
1 7
6 0
7
561
2
1 7
6 1
8
574
2
1 8
6 0
8
575
2
1 8
6 1
18
0
589
2
0 0
7 1
0
588
2
0 0
7 0
1
602
2
0 1
7 0
1
603
2
0 1
7 1
2
616
2
0 2
7 0
2
617
2
0 2
7 1
3
630
2
0 3
7 0
3
631
2
0 3
7 1
4
645
2
0 4
7 1
4
644
2
0 4
7 0
5
658
2
0 5
7 0
5
659
2
0 5
7 1
6
672
2
0 6
7 0
6
673
2
0 6
7 1
7
686
2
0 7
7 0
7
687
2
0 7
7 1
8
700
2
0 8
7 0
8
701
2
0 8
7 1
end_DTG
begin_DTG
8
9
716
2
3 0
4 1
9
717
2
3 0
4 2
10
842
2
2 0
5 1
10
843
2
2 0
5 2
11
968
2
1 0
6 1
11
969
2
1 0
6 2
12
1094
2
0 0
7 1
12
1095
2
0 0
7 2
8
9
730
2
3 1
4 1
9
731
2
3 1
4 2
10
856
2
2 1
5 1
10
857
2
2 1
5 2
11
982
2
1 1
6 1
11
983
2
1 1
6 2
12
1108
2
0 1
7 1
12
1109
2
0 1
7 2
8
9
744
2
3 2
4 1
9
745
2
3 2
4 2
10
870
2
2 2
5 1
10
871
2
2 2
5 2
11
996
2
1 2
6 1
11
997
2
1 2
6 2
12
1122
2
0 2
7 1
12
1123
2
0 2
7 2
8
9
758
2
3 3
4 1
9
759
2
3 3
4 2
10
884
2
2 3
5 1
10
885
2
2 3
5 2
11
1010
2
1 3
6 1
11
1011
2
1 3
6 2
12
1136
2
0 3
7 1
12
1137
2
0 3
7 2
8
9
772
2
3 4
4 1
9
773
2
3 4
4 2
10
898
2
2 4
5 1
10
899
2
2 4
5 2
11
1024
2
1 4
6 1
11
1025
2
1 4
6 2
12
1150
2
0 4
7 1
12
1151
2
0 4
7 2
8
9
786
2
3 5
4 1
9
787
2
3 5
4 2
10
912
2
2 5
5 1
10
913
2
2 5
5 2
11
1038
2
1 5
6 1
11
1039
2
1 5
6 2
12
1164
2
0 5
7 1
12
1165
2
0 5
7 2
8
9
800
2
3 6
4 1
9
801
2
3 6
4 2
10
926
2
2 6
5 1
10
927
2
2 6
5 2
11
1052
2
1 6
6 1
11
1053
2
1 6
6 2
12
1178
2
0 6
7 1
12
1179
2
0 6
7 2
8
9
814
2
3 7
4 1
9
815
2
3 7
4 2
10
940
2
2 7
5 1
10
941
2
2 7
5 2
11
1066
2
1 7
6 1
11
1067
2
1 7
6 2
12
1192
2
0 7
7 1
12
1193
2
0 7
7 2
8
9
828
2
3 8
4 1
9
829
2
3 8
4 2
10
954
2
2 8
5 1
10
955
2
2 8
5 2
11
1080
2
1 8
6 1
11
1081
2
1 8
6 2
12
1206
2
0 8
7 1
12
1207
2
0 8
7 2
18
0
213
2
3 0
4 1
0
212
2
3 0
4 0
1
226
2
3 1
4 0
1
227
2
3 1
4 1
2
240
2
3 2
4 0
2
241
2
3 2
4 1
3
254
2
3 3
4 0
3
255
2
3 3
4 1
4
269
2
3 4
4 1
4
268
2
3 4
4 0
5
282
2
3 5
4 0
5
283
2
3 5
4 1
6
296
2
3 6
4 0
6
297
2
3 6
4 1
7
310
2
3 7
4 0
7
311
2
3 7
4 1
8
324
2
3 8
4 0
8
325
2
3 8
4 1
18
0
339
2
2 0
5 1
0
338
2
2 0
5 0
1
352
2
2 1
5 0
1
353
2
2 1
5 1
2
366
2
2 2
5 0
2
367
2
2 2
5 1
3
380
2
2 3
5 0
3
381
2
2 3
5 1
4
395
2
2 4
5 1
4
394
2
2 4
5 0
5
408
2
2 5
5 0
5
409
2
2 5
5 1
6
422
2
2 6
5 0
6
423
2
2 6
5 1
7
436
2
2 7
5 0
7
437
2
2 7
5 1
8
450
2
2 8
5 0
8
451
2
2 8
5 1
18
0
465
2
1 0
6 1
0
464
2
1 0
6 0
1
478
2
1 1
6 0
1
479
2
1 1
6 1
2
492
2
1 2
6 0
2
493
2
1 2
6 1
3
506
2
1 3
6 0
3
507
2
1 3
6 1
4
521
2
1 4
6 1
4
520
2
1 4
6 0
5
534
2
1 5
6 0
5
535
2
1 5
6 1
6
548
2
1 6
6 0
6
549
2
1 6
6 1
7
562
2
1 7
6 0
7
563
2
1 7
6 1
8
576
2
1 8
6 0
8
577
2
1 8
6 1
18
0
591
2
0 0
7 1
0
590
2
0 0
7 0
1
604
2
0 1
7 0
1
605
2
0 1
7 1
2
618
2
0 2
7 0
2
619
2
0 2
7 1
3
632
2
0 3
7 0
3
633
2
0 3
7 1
4
647
2
0 4
7 1
4
646
2
0 4
7 0
5
660
2
0 5
7 0
5
661
2
0 5
7 1
6
674
2
0 6
7 0
6
675
2
0 6
7 1
7
688
2
0 7
7 0
7
689
2
0 7
7 1
8
702
2
0 8
7 0
8
703
2
0 8
7 1
end_DTG
begin_CG
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
6 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
5 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4 252
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
end_CG
