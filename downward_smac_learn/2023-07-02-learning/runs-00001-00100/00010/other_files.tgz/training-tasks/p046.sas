begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var12
-1
10
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var11
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var10
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var8
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var13
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
15
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
15
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
15
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
15
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
15
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
15
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
15
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
15
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
0
begin_state
4
2
1
9
8
1
1
1
2
2
9
6
2
6
0
5
7
2
end_state
begin_goal
8
10 6
11 4
12 0
13 5
14 5
15 6
16 4
17 4
end_goal
1710
begin_operator
drive v1 l1 l2
0
1
0 4 0 2
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l10 l7
0
1
0 4 1 7
0
end_operator
begin_operator
drive v1 l10 l8
0
1
0 4 1 8
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 4 2 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 4 2 3
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 4 2 8
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 4 3 2
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 4 4 6
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 4 5 6
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 4 5 7
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 4 6 4
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 4 6 5
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 4 6 8
0
end_operator
begin_operator
drive v1 l7 l10
0
1
0 4 7 1
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 4 7 5
0
end_operator
begin_operator
drive v1 l7 l9
0
1
0 4 7 9
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 4 8 0
0
end_operator
begin_operator
drive v1 l8 l10
0
1
0 4 8 1
0
end_operator
begin_operator
drive v1 l8 l2
0
1
0 4 8 2
0
end_operator
begin_operator
drive v1 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





2
2 2
7 0
2
475
2
2 2
7 1
3
490
2
2 3
7 0
3
491
2
2 3
7 1
4
506
2
2 4
7 0
4
507
2
2 4
7 1
5
522
2
2 5
7 0
5
523
2
2 5
7 1
6
538
2
2 6
7 0
6
539
2
2 6
7 1
7
554
2
2 7
7 0
7
555
2
2 7
7 1
8
570
2
2 8
7 0
8
571
2
2 8
7 1
9
586
2
2 9
7 0
9
587
2
2 9
7 1
20
0
603
2
1 0
8 1
0
602
2
1 0
8 0
1
618
2
1 1
8 0
1
619
2
1 1
8 1
2
634
2
1 2
8 0
2
635
2
1 2
8 1
3
650
2
1 3
8 0
3
651
2
1 3
8 1
4
666
2
1 4
8 0
4
667
2
1 4
8 1
5
682
2
1 5
8 0
5
683
2
1 5
8 1
6
698
2
1 6
8 0
6
699
2
1 6
8 1
7
714
2
1 7
8 0
7
715
2
1 7
8 1
8
730
2
1 8
8 0
8
731
2
1 8
8 1
9
746
2
1 9
8 0
9
747
2
1 9
8 1
20
0
763
2
0 0
9 1
0
762
2
0 0
9 0
1
778
2
0 1
9 0
1
779
2
0 1
9 1
2
794
2
0 2
9 0
2
795
2
0 2
9 1
3
810
2
0 3
9 0
3
811
2
0 3
9 1
4
826
2
0 4
9 0
4
827
2
0 4
9 1
5
842
2
0 5
9 0
5
843
2
0 5
9 1
6
858
2
0 6
9 0
6
859
2
0 6
9 1
7
874
2
0 7
9 0
7
875
2
0 7
9 1
8
890
2
0 8
9 0
8
891
2
0 8
9 1
9
906
2
0 9
9 0
9
907
2
0 9
9 1
end_DTG
begin_DTG
10
10
924
2
4 0
5 1
10
925
2
4 0
5 2
11
1084
2
3 0
6 1
11
1085
2
3 0
6 2
12
1244
2
2 0
7 1
12
1245
2
2 0
7 2
13
1404
2
1 0
8 1
13
1405
2
1 0
8 2
14
1564
2
0 0
9 1
14
1565
2
0 0
9 2
10
10
940
2
4 1
5 1
10
941
2
4 1
5 2
11
1100
2
3 1
6 1
11
1101
2
3 1
6 2
12
1260
2
2 1
7 1
12
1261
2
2 1
7 2
13
1420
2
1 1
8 1
13
1421
2
1 1
8 2
14
1580
2
0 1
9 1
14
1581
2
0 1
9 2
10
10
956
2
4 2
5 1
10
957
2
4 2
5 2
11
1116
2
3 2
6 1
11
1117
2
3 2
6 2
12
1276
2
2 2
7 1
12
1277
2
2 2
7 2
13
1436
2
1 2
8 1
13
1437
2
1 2
8 2
14
1596
2
0 2
9 1
14
1597
2
0 2
9 2
10
10
972
2
4 3
5 1
10
973
2
4 3
5 2
11
1132
2
3 3
6 1
11
1133
2
3 3
6 2
12
1292
2
2 3
7 1
12
1293
2
2 3
7 2
13
1452
2
1 3
8 1
13
1453
2
1 3
8 2
14
1612
2
0 3
9 1
14
1613
2
0 3
9 2
10
10
988
2
4 4
5 1
10
989
2
4 4
5 2
11
1148
2
3 4
6 1
11
1149
2
3 4
6 2
12
1308
2
2 4
7 1
12
1309
2
2 4
7 2
13
1468
2
1 4
8 1
13
1469
2
1 4
8 2
14
1628
2
0 4
9 1
14
1629
2
0 4
9 2
10
10
1004
2
4 5
5 1
10
1005
2
4 5
5 2
11
1164
2
3 5
6 1
11
1165
2
3 5
6 2
12
1324
2
2 5
7 1
12
1325
2
2 5
7 2
13
1484
2
1 5
8 1
13
1485
2
1 5
8 2
14
1644
2
0 5
9 1
14
1645
2
0 5
9 2
10
10
1020
2
4 6
5 1
10
1021
2
4 6
5 2
11
1180
2
3 6
6 1
11
1181
2
3 6
6 2
12
1340
2
2 6
7 1
12
1341
2
2 6
7 2
13
1500
2
1 6
8 1
13
1501
2
1 6
8 2
14
1660
2
0 6
9 1
14
1661
2
0 6
9 2
10
10
1036
2
4 7
5 1
10
1037
2
4 7
5 2
11
1196
2
3 7
6 1
11
1197
2
3 7
6 2
12
1356
2
2 7
7 1
12
1357
2
2 7
7 2
13
1516
2
1 7
8 1
13
1517
2
1 7
8 2
14
1676
2
0 7
9 1
14
1677
2
0 7
9 2
10
10
1052
2
4 8
5 1
10
1053
2
4 8
5 2
11
1212
2
3 8
6 1
11
1213
2
3 8
6 2
12
1372
2
2 8
7 1
12
1373
2
2 8
7 2
13
1532
2
1 8
8 1
13
1533
2
1 8
8 2
14
1692
2
0 8
9 1
14
1693
2
0 8
9 2
10
10
1068
2
4 9
5 1
10
1069
2
4 9
5 2
11
1228
2
3 9
6 1
11
1229
2
3 9
6 2
12
1388
2
2 9
7 1
12
1389
2
2 9
7 2
13
1548
2
1 9
8 1
13
1549
2
1 9
8 2
14
1708
2
0 9
9 1
14
1709
2
0 9
9 2
20
0
125
2
4 0
5 1
0
124
2
4 0
5 0
1
140
2
4 1
5 0
1
141
2
4 1
5 1
2
156
2
4 2
5 0
2
157
2
4 2
5 1
3
172
2
4 3
5 0
3
173
2
4 3
5 1
4
188
2
4 4
5 0
4
189
2
4 4
5 1
5
204
2
4 5
5 0
5
205
2
4 5
5 1
6
220
2
4 6
5 0
6
221
2
4 6
5 1
7
236
2
4 7
5 0
7
237
2
4 7
5 1
8
252
2
4 8
5 0
8
253
2
4 8
5 1
9
268
2
4 9
5 0
9
269
2
4 9
5 1
20
0
285
2
3 0
6 1
0
284
2
3 0
6 0
1
300
2
3 1
6 0
1
301
2
3 1
6 1
2
316
2
3 2
6 0
2
317
2
3 2
6 1
3
332
2
3 3
6 0
3
333
2
3 3
6 1
4
348
2
3 4
6 0
4
349
2
3 4
6 1
5
364
2
3 5
6 0
5
365
2
3 5
6 1
6
380
2
3 6
6 0
6
381
2
3 6
6 1
7
396
2
3 7
6 0
7
397
2
3 7
6 1
8
412
2
3 8
6 0
8
413
2
3 8
6 1
9
428
2
3 9
6 0
9
429
2
3 9
6 1
20
0
445
2
2 0
7 1
0
444
2
2 0
7 0
1
460
2
2 1
7 0
1
461
2
2 1
7 1
2
476
2
2 2
7 0
2
477
2
2 2
7 1
3
492
2
2 3
7 0
3
493
2
2 3
7 1
4
508
2
2 4
7 0
4
509
2
2 4
7 1
5
524
2
2 5
7 0
5
525
2
2 5
7 1
6
540
2
2 6
7 0
6
541
2
2 6
7 1
7
556
2
2 7
7 0
7
557
2
2 7
7 1
8
572
2
2 8
7 0
8
573
2
2 8
7 1
9
588
2
2 9
7 0
9
589
2
2 9
7 1
20
0
605
2
1 0
8 1
0
604
2
1 0
8 0
1
620
2
1 1
8 0
1
621
2
1 1
8 1
2
636
2
1 2
8 0
2
637
2
1 2
8 1
3
652
2
1 3
8 0
3
653
2
1 3
8 1
4
668
2
1 4
8 0
4
669
2
1 4
8 1
5
684
2
1 5
8 0
5
685
2
1 5
8 1
6
700
2
1 6
8 0
6
701
2
1 6
8 1
7
716
2
1 7
8 0
7
717
2
1 7
8 1
8
732
2
1 8
8 0
8
733
2
1 8
8 1
9
748
2
1 9
8 0
9
749
2
1 9
8 1
20
0
765
2
0 0
9 1
0
764
2
0 0
9 0
1
780
2
0 1
9 0
1
781
2
0 1
9 1
2
796
2
0 2
9 0
2
797
2
0 2
9 1
3
812
2
0 3
9 0
3
813
2
0 3
9 1
4
828
2
0 4
9 0
4
829
2
0 4
9 1
5
844
2
0 5
9 0
5
845
2
0 5
9 1
6
860
2
0 6
9 0
6
861
2
0 6
9 1
7
876
2
0 7
9 0
7
877
2
0 7
9 1
8
892
2
0 8
9 0
8
893
2
0 8
9 1
9
908
2
0 9
9 0
9
909
2
0 9
9 1
end_DTG
begin_CG
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
9 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
7 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
6 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
5 320
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
end_CG
