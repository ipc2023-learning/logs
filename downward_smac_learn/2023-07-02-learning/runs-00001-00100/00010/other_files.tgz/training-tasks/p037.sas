begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var10
-1
9
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var9
-1
9
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var8
-1
9
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var7
-1
9
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var11
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
13
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
13
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
13
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
13
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
13
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
13
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
13
Atom at(p7, l1)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
0
begin_state
2
3
0
8
1
1
2
2
6
0
2
6
3
7
6
end_state
begin_goal
7
8 5
9 8
10 8
11 4
12 1
13 8
14 8
end_goal
1104
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l5 l9
0
1
0 3 4 8
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
end_operator
begin_operator
drive v1 l8 l2
0
1
0 3 7 1
0
end_operator
begin_operator
drive v1 l8 l4
0
1
0 3 7 3
0
end_operator
begin_operator
drive v1 l8 l5
0
1
0 3 7 4
0
end_operator
begin_operator
drive v1 l9 l2
0
1
0 3 8 1
0
end_operator
begin_operator
drive v1 l9 l5
0
1
0 3 8 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v2 l1 l8
0
1
0 2 0 7
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v2 l2 l8
0
1
0 2 1 7
0
end_operator
begin_operator
drive v2 l2 l9
0
1
0 2 1 8
0
end_operator
begin_operator
drive v2 l3 l5
0
1
0 2 2 4
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v2 l4 l6
0
1
0 2 3 5
0
end_operator
begin_operator
drive v2 l4 l7
0
1
0 2 3 6
0
end_operator
begin_operator
drive v2 l4 l8
0
1
0 2 3 7
0
end_operator
begin_operator
drive v2 l5 l3
0
1
0 2 4 2
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
driv




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
2
0 1
7 1
12
1003
2
0 1
7 2
8
9
638
2
3 2
4 1
9
639
2
3 2
4 2
10
764
2
2 2
5 1
10
765
2
2 2
5 2
11
890
2
1 2
6 1
11
891
2
1 2
6 2
12
1016
2
0 2
7 1
12
1017
2
0 2
7 2
8
9
652
2
3 3
4 1
9
653
2
3 3
4 2
10
778
2
2 3
5 1
10
779
2
2 3
5 2
11
904
2
1 3
6 1
11
905
2
1 3
6 2
12
1030
2
0 3
7 1
12
1031
2
0 3
7 2
8
9
666
2
3 4
4 1
9
667
2
3 4
4 2
10
792
2
2 4
5 1
10
793
2
2 4
5 2
11
918
2
1 4
6 1
11
919
2
1 4
6 2
12
1044
2
0 4
7 1
12
1045
2
0 4
7 2
8
9
680
2
3 5
4 1
9
681
2
3 5
4 2
10
806
2
2 5
5 1
10
807
2
2 5
5 2
11
932
2
1 5
6 1
11
933
2
1 5
6 2
12
1058
2
0 5
7 1
12
1059
2
0 5
7 2
8
9
694
2
3 6
4 1
9
695
2
3 6
4 2
10
820
2
2 6
5 1
10
821
2
2 6
5 2
11
946
2
1 6
6 1
11
947
2
1 6
6 2
12
1072
2
0 6
7 1
12
1073
2
0 6
7 2
8
9
708
2
3 7
4 1
9
709
2
3 7
4 2
10
834
2
2 7
5 1
10
835
2
2 7
5 2
11
960
2
1 7
6 1
11
961
2
1 7
6 2
12
1086
2
0 7
7 1
12
1087
2
0 7
7 2
8
9
722
2
3 8
4 1
9
723
2
3 8
4 2
10
848
2
2 8
5 1
10
849
2
2 8
5 2
11
974
2
1 8
6 1
11
975
2
1 8
6 2
12
1100
2
0 8
7 1
12
1101
2
0 8
7 2
18
0
107
2
3 0
4 1
0
106
2
3 0
4 0
1
120
2
3 1
4 0
1
121
2
3 1
4 1
2
134
2
3 2
4 0
2
135
2
3 2
4 1
3
148
2
3 3
4 0
3
149
2
3 3
4 1
4
163
2
3 4
4 1
4
162
2
3 4
4 0
5
176
2
3 5
4 0
5
177
2
3 5
4 1
6
190
2
3 6
4 0
6
191
2
3 6
4 1
7
204
2
3 7
4 0
7
205
2
3 7
4 1
8
218
2
3 8
4 0
8
219
2
3 8
4 1
18
0
233
2
2 0
5 1
0
232
2
2 0
5 0
1
246
2
2 1
5 0
1
247
2
2 1
5 1
2
260
2
2 2
5 0
2
261
2
2 2
5 1
3
274
2
2 3
5 0
3
275
2
2 3
5 1
4
289
2
2 4
5 1
4
288
2
2 4
5 0
5
302
2
2 5
5 0
5
303
2
2 5
5 1
6
316
2
2 6
5 0
6
317
2
2 6
5 1
7
330
2
2 7
5 0
7
331
2
2 7
5 1
8
344
2
2 8
5 0
8
345
2
2 8
5 1
18
0
359
2
1 0
6 1
0
358
2
1 0
6 0
1
372
2
1 1
6 0
1
373
2
1 1
6 1
2
386
2
1 2
6 0
2
387
2
1 2
6 1
3
400
2
1 3
6 0
3
401
2
1 3
6 1
4
415
2
1 4
6 1
4
414
2
1 4
6 0
5
428
2
1 5
6 0
5
429
2
1 5
6 1
6
442
2
1 6
6 0
6
443
2
1 6
6 1
7
456
2
1 7
6 0
7
457
2
1 7
6 1
8
470
2
1 8
6 0
8
471
2
1 8
6 1
18
0
485
2
0 0
7 1
0
484
2
0 0
7 0
1
498
2
0 1
7 0
1
499
2
0 1
7 1
2
512
2
0 2
7 0
2
513
2
0 2
7 1
3
526
2
0 3
7 0
3
527
2
0 3
7 1
4
541
2
0 4
7 1
4
540
2
0 4
7 0
5
554
2
0 5
7 0
5
555
2
0 5
7 1
6
568
2
0 6
7 0
6
569
2
0 6
7 1
7
582
2
0 7
7 0
7
583
2
0 7
7 1
8
596
2
0 8
7 0
8
597
2
0 8
7 1
end_DTG
begin_DTG
8
9
612
2
3 0
4 1
9
613
2
3 0
4 2
10
738
2
2 0
5 1
10
739
2
2 0
5 2
11
864
2
1 0
6 1
11
865
2
1 0
6 2
12
990
2
0 0
7 1
12
991
2
0 0
7 2
8
9
626
2
3 1
4 1
9
627
2
3 1
4 2
10
752
2
2 1
5 1
10
753
2
2 1
5 2
11
878
2
1 1
6 1
11
879
2
1 1
6 2
12
1004
2
0 1
7 1
12
1005
2
0 1
7 2
8
9
640
2
3 2
4 1
9
641
2
3 2
4 2
10
766
2
2 2
5 1
10
767
2
2 2
5 2
11
892
2
1 2
6 1
11
893
2
1 2
6 2
12
1018
2
0 2
7 1
12
1019
2
0 2
7 2
8
9
654
2
3 3
4 1
9
655
2
3 3
4 2
10
780
2
2 3
5 1
10
781
2
2 3
5 2
11
906
2
1 3
6 1
11
907
2
1 3
6 2
12
1032
2
0 3
7 1
12
1033
2
0 3
7 2
8
9
668
2
3 4
4 1
9
669
2
3 4
4 2
10
794
2
2 4
5 1
10
795
2
2 4
5 2
11
920
2
1 4
6 1
11
921
2
1 4
6 2
12
1046
2
0 4
7 1
12
1047
2
0 4
7 2
8
9
682
2
3 5
4 1
9
683
2
3 5
4 2
10
808
2
2 5
5 1
10
809
2
2 5
5 2
11
934
2
1 5
6 1
11
935
2
1 5
6 2
12
1060
2
0 5
7 1
12
1061
2
0 5
7 2
8
9
696
2
3 6
4 1
9
697
2
3 6
4 2
10
822
2
2 6
5 1
10
823
2
2 6
5 2
11
948
2
1 6
6 1
11
949
2
1 6
6 2
12
1074
2
0 6
7 1
12
1075
2
0 6
7 2
8
9
710
2
3 7
4 1
9
711
2
3 7
4 2
10
836
2
2 7
5 1
10
837
2
2 7
5 2
11
962
2
1 7
6 1
11
963
2
1 7
6 2
12
1088
2
0 7
7 1
12
1089
2
0 7
7 2
8
9
724
2
3 8
4 1
9
725
2
3 8
4 2
10
850
2
2 8
5 1
10
851
2
2 8
5 2
11
976
2
1 8
6 1
11
977
2
1 8
6 2
12
1102
2
0 8
7 1
12
1103
2
0 8
7 2
18
0
109
2
3 0
4 1
0
108
2
3 0
4 0
1
122
2
3 1
4 0
1
123
2
3 1
4 1
2
136
2
3 2
4 0
2
137
2
3 2
4 1
3
150
2
3 3
4 0
3
151
2
3 3
4 1
4
165
2
3 4
4 1
4
164
2
3 4
4 0
5
178
2
3 5
4 0
5
179
2
3 5
4 1
6
192
2
3 6
4 0
6
193
2
3 6
4 1
7
206
2
3 7
4 0
7
207
2
3 7
4 1
8
220
2
3 8
4 0
8
221
2
3 8
4 1
18
0
235
2
2 0
5 1
0
234
2
2 0
5 0
1
248
2
2 1
5 0
1
249
2
2 1
5 1
2
262
2
2 2
5 0
2
263
2
2 2
5 1
3
276
2
2 3
5 0
3
277
2
2 3
5 1
4
291
2
2 4
5 1
4
290
2
2 4
5 0
5
304
2
2 5
5 0
5
305
2
2 5
5 1
6
318
2
2 6
5 0
6
319
2
2 6
5 1
7
332
2
2 7
5 0
7
333
2
2 7
5 1
8
346
2
2 8
5 0
8
347
2
2 8
5 1
18
0
361
2
1 0
6 1
0
360
2
1 0
6 0
1
374
2
1 1
6 0
1
375
2
1 1
6 1
2
388
2
1 2
6 0
2
389
2
1 2
6 1
3
402
2
1 3
6 0
3
403
2
1 3
6 1
4
417
2
1 4
6 1
4
416
2
1 4
6 0
5
430
2
1 5
6 0
5
431
2
1 5
6 1
6
444
2
1 6
6 0
6
445
2
1 6
6 1
7
458
2
1 7
6 0
7
459
2
1 7
6 1
8
472
2
1 8
6 0
8
473
2
1 8
6 1
18
0
487
2
0 0
7 1
0
486
2
0 0
7 0
1
500
2
0 1
7 0
1
501
2
0 1
7 1
2
514
2
0 2
7 0
2
515
2
0 2
7 1
3
528
2
0 3
7 0
3
529
2
0 3
7 1
4
543
2
0 4
7 1
4
542
2
0 4
7 0
5
556
2
0 5
7 0
5
557
2
0 5
7 1
6
570
2
0 6
7 0
6
571
2
0 6
7 1
7
584
2
0 7
7 0
7
585
2
0 7
7 1
8
598
2
0 8
7 0
8
599
2
0 8
7 1
end_DTG
begin_CG
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
6 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
5 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4 252
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
end_CG
