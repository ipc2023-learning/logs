begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var12
-1
10
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var11
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var10
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var8
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var13
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
15
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
15
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
15
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
15
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
15
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
15
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
15
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
15
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
0
begin_state
4
0
1
8
3
1
2
1
2
1
3
7
6
4
5
6
2
1
end_state
begin_goal
8
10 6
11 9
12 9
13 0
14 8
15 3
16 5
17 5
end_goal
1830
begin_operator
drive v1 l1 l10
0
1
0 4 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 4 0 3
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 4 0 4
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 4 0 5
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 4 0 6
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 4 0 7
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 4 0 9
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 4 1 0
0
end_operator
begin_operator
drive v1 l10 l5
0
1
0 4 1 5
0
end_operator
begin_operator
drive v1 l10 l6
0
1
0 4 1 6
0
end_operator
begin_operator
drive v1 l10 l7
0
1
0 4 1 7
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 4 2 3
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 4 2 6
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 4 2 7
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 4 2 8
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 4 2 9
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 4 3 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 4 3 2
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 4 3 4
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 4 3 5
0
end_operator
begin_operator
drive v1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





2 2
7 1
3
610
2
2 3
7 0
3
611
2
2 3
7 1
4
626
2
2 4
7 0
4
627
2
2 4
7 1
5
642
2
2 5
7 0
5
643
2
2 5
7 1
6
658
2
2 6
7 0
6
659
2
2 6
7 1
7
674
2
2 7
7 0
7
675
2
2 7
7 1
8
690
2
2 8
7 0
8
691
2
2 8
7 1
9
706
2
2 9
7 0
9
707
2
2 9
7 1
20
0
723
2
1 0
8 1
0
722
2
1 0
8 0
1
738
2
1 1
8 0
1
739
2
1 1
8 1
2
754
2
1 2
8 0
2
755
2
1 2
8 1
3
770
2
1 3
8 0
3
771
2
1 3
8 1
4
786
2
1 4
8 0
4
787
2
1 4
8 1
5
802
2
1 5
8 0
5
803
2
1 5
8 1
6
818
2
1 6
8 0
6
819
2
1 6
8 1
7
834
2
1 7
8 0
7
835
2
1 7
8 1
8
850
2
1 8
8 0
8
851
2
1 8
8 1
9
866
2
1 9
8 0
9
867
2
1 9
8 1
20
0
883
2
0 0
9 1
0
882
2
0 0
9 0
1
898
2
0 1
9 0
1
899
2
0 1
9 1
2
914
2
0 2
9 0
2
915
2
0 2
9 1
3
930
2
0 3
9 0
3
931
2
0 3
9 1
4
946
2
0 4
9 0
4
947
2
0 4
9 1
5
962
2
0 5
9 0
5
963
2
0 5
9 1
6
978
2
0 6
9 0
6
979
2
0 6
9 1
7
994
2
0 7
9 0
7
995
2
0 7
9 1
8
1010
2
0 8
9 0
8
1011
2
0 8
9 1
9
1026
2
0 9
9 0
9
1027
2
0 9
9 1
end_DTG
begin_DTG
10
10
1044
2
4 0
5 1
10
1045
2
4 0
5 2
11
1204
2
3 0
6 1
11
1205
2
3 0
6 2
12
1364
2
2 0
7 1
12
1365
2
2 0
7 2
13
1524
2
1 0
8 1
13
1525
2
1 0
8 2
14
1684
2
0 0
9 1
14
1685
2
0 0
9 2
10
10
1060
2
4 1
5 1
10
1061
2
4 1
5 2
11
1220
2
3 1
6 1
11
1221
2
3 1
6 2
12
1380
2
2 1
7 1
12
1381
2
2 1
7 2
13
1540
2
1 1
8 1
13
1541
2
1 1
8 2
14
1700
2
0 1
9 1
14
1701
2
0 1
9 2
10
10
1076
2
4 2
5 1
10
1077
2
4 2
5 2
11
1236
2
3 2
6 1
11
1237
2
3 2
6 2
12
1396
2
2 2
7 1
12
1397
2
2 2
7 2
13
1556
2
1 2
8 1
13
1557
2
1 2
8 2
14
1716
2
0 2
9 1
14
1717
2
0 2
9 2
10
10
1092
2
4 3
5 1
10
1093
2
4 3
5 2
11
1252
2
3 3
6 1
11
1253
2
3 3
6 2
12
1412
2
2 3
7 1
12
1413
2
2 3
7 2
13
1572
2
1 3
8 1
13
1573
2
1 3
8 2
14
1732
2
0 3
9 1
14
1733
2
0 3
9 2
10
10
1108
2
4 4
5 1
10
1109
2
4 4
5 2
11
1268
2
3 4
6 1
11
1269
2
3 4
6 2
12
1428
2
2 4
7 1
12
1429
2
2 4
7 2
13
1588
2
1 4
8 1
13
1589
2
1 4
8 2
14
1748
2
0 4
9 1
14
1749
2
0 4
9 2
10
10
1124
2
4 5
5 1
10
1125
2
4 5
5 2
11
1284
2
3 5
6 1
11
1285
2
3 5
6 2
12
1444
2
2 5
7 1
12
1445
2
2 5
7 2
13
1604
2
1 5
8 1
13
1605
2
1 5
8 2
14
1764
2
0 5
9 1
14
1765
2
0 5
9 2
10
10
1140
2
4 6
5 1
10
1141
2
4 6
5 2
11
1300
2
3 6
6 1
11
1301
2
3 6
6 2
12
1460
2
2 6
7 1
12
1461
2
2 6
7 2
13
1620
2
1 6
8 1
13
1621
2
1 6
8 2
14
1780
2
0 6
9 1
14
1781
2
0 6
9 2
10
10
1156
2
4 7
5 1
10
1157
2
4 7
5 2
11
1316
2
3 7
6 1
11
1317
2
3 7
6 2
12
1476
2
2 7
7 1
12
1477
2
2 7
7 2
13
1636
2
1 7
8 1
13
1637
2
1 7
8 2
14
1796
2
0 7
9 1
14
1797
2
0 7
9 2
10
10
1172
2
4 8
5 1
10
1173
2
4 8
5 2
11
1332
2
3 8
6 1
11
1333
2
3 8
6 2
12
1492
2
2 8
7 1
12
1493
2
2 8
7 2
13
1652
2
1 8
8 1
13
1653
2
1 8
8 2
14
1812
2
0 8
9 1
14
1813
2
0 8
9 2
10
10
1188
2
4 9
5 1
10
1189
2
4 9
5 2
11
1348
2
3 9
6 1
11
1349
2
3 9
6 2
12
1508
2
2 9
7 1
12
1509
2
2 9
7 2
13
1668
2
1 9
8 1
13
1669
2
1 9
8 2
14
1828
2
0 9
9 1
14
1829
2
0 9
9 2
20
0
245
2
4 0
5 1
0
244
2
4 0
5 0
1
260
2
4 1
5 0
1
261
2
4 1
5 1
2
276
2
4 2
5 0
2
277
2
4 2
5 1
3
292
2
4 3
5 0
3
293
2
4 3
5 1
4
308
2
4 4
5 0
4
309
2
4 4
5 1
5
324
2
4 5
5 0
5
325
2
4 5
5 1
6
340
2
4 6
5 0
6
341
2
4 6
5 1
7
356
2
4 7
5 0
7
357
2
4 7
5 1
8
372
2
4 8
5 0
8
373
2
4 8
5 1
9
388
2
4 9
5 0
9
389
2
4 9
5 1
20
0
405
2
3 0
6 1
0
404
2
3 0
6 0
1
420
2
3 1
6 0
1
421
2
3 1
6 1
2
436
2
3 2
6 0
2
437
2
3 2
6 1
3
452
2
3 3
6 0
3
453
2
3 3
6 1
4
468
2
3 4
6 0
4
469
2
3 4
6 1
5
484
2
3 5
6 0
5
485
2
3 5
6 1
6
500
2
3 6
6 0
6
501
2
3 6
6 1
7
516
2
3 7
6 0
7
517
2
3 7
6 1
8
532
2
3 8
6 0
8
533
2
3 8
6 1
9
548
2
3 9
6 0
9
549
2
3 9
6 1
20
0
565
2
2 0
7 1
0
564
2
2 0
7 0
1
580
2
2 1
7 0
1
581
2
2 1
7 1
2
596
2
2 2
7 0
2
597
2
2 2
7 1
3
612
2
2 3
7 0
3
613
2
2 3
7 1
4
628
2
2 4
7 0
4
629
2
2 4
7 1
5
644
2
2 5
7 0
5
645
2
2 5
7 1
6
660
2
2 6
7 0
6
661
2
2 6
7 1
7
676
2
2 7
7 0
7
677
2
2 7
7 1
8
692
2
2 8
7 0
8
693
2
2 8
7 1
9
708
2
2 9
7 0
9
709
2
2 9
7 1
20
0
725
2
1 0
8 1
0
724
2
1 0
8 0
1
740
2
1 1
8 0
1
741
2
1 1
8 1
2
756
2
1 2
8 0
2
757
2
1 2
8 1
3
772
2
1 3
8 0
3
773
2
1 3
8 1
4
788
2
1 4
8 0
4
789
2
1 4
8 1
5
804
2
1 5
8 0
5
805
2
1 5
8 1
6
820
2
1 6
8 0
6
821
2
1 6
8 1
7
836
2
1 7
8 0
7
837
2
1 7
8 1
8
852
2
1 8
8 0
8
853
2
1 8
8 1
9
868
2
1 9
8 0
9
869
2
1 9
8 1
20
0
885
2
0 0
9 1
0
884
2
0 0
9 0
1
900
2
0 1
9 0
1
901
2
0 1
9 1
2
916
2
0 2
9 0
2
917
2
0 2
9 1
3
932
2
0 3
9 0
3
933
2
0 3
9 1
4
948
2
0 4
9 0
4
949
2
0 4
9 1
5
964
2
0 5
9 0
5
965
2
0 5
9 1
6
980
2
0 6
9 0
6
981
2
0 6
9 1
7
996
2
0 7
9 0
7
997
2
0 7
9 1
8
1012
2
0 8
9 0
8
1013
2
0 8
9 1
9
1028
2
0 9
9 0
9
1029
2
0 9
9 1
end_DTG
begin_CG
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
9 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
7 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
6 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
5 320
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
end_CG
