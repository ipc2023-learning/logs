begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var13
-1
11
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var12
-1
11
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var11
-1
11
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var10
-1
11
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var9
-1
11
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var14
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
16
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
16
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
16
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
16
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
16
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
16
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
16
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
16
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var8
-1
16
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
3
3
8
5
5
1
1
1
2
2
9
9
9
6
5
5
1
7
9
end_state
begin_goal
9
10 10
11 4
12 0
13 1
14 8
15 0
16 2
17 10
18 6
end_goal
2410
begin_operator
drive v1 l1 l10
0
1
0 4 0 1
0
end_operator
begin_operator
drive v1 l1 l11
0
1
0 4 0 2
0
end_operator
begin_operator
drive v1 l1 l2
0
1
0 4 0 3
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 4 0 4
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 4 0 5
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 4 0 6
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 4 0 10
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 4 1 0
0
end_operator
begin_operator
drive v1 l10 l11
0
1
0 4 1 2
0
end_operator
begin_operator
drive v1 l10 l2
0
1
0 4 1 3
0
end_operator
begin_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




37
2
0 0
9 1
0
1236
2
0 0
9 0
1
1254
2
0 1
9 0
1
1255
2
0 1
9 1
2
1272
2
0 2
9 0
2
1273
2
0 2
9 1
3
1290
2
0 3
9 0
3
1291
2
0 3
9 1
4
1308
2
0 4
9 0
4
1309
2
0 4
9 1
5
1327
2
0 5
9 1
5
1326
2
0 5
9 0
6
1344
2
0 6
9 0
6
1345
2
0 6
9 1
7
1362
2
0 7
9 0
7
1363
2
0 7
9 1
8
1380
2
0 8
9 0
8
1381
2
0 8
9 1
9
1398
2
0 9
9 0
9
1399
2
0 9
9 1
10
1416
2
0 10
9 0
10
1417
2
0 10
9 1
end_DTG
begin_DTG
10
11
1436
2
4 0
5 1
11
1437
2
4 0
5 2
12
1634
2
3 0
6 1
12
1635
2
3 0
6 2
13
1832
2
2 0
7 1
13
1833
2
2 0
7 2
14
2030
2
1 0
8 1
14
2031
2
1 0
8 2
15
2228
2
0 0
9 1
15
2229
2
0 0
9 2
10
11
1454
2
4 1
5 1
11
1455
2
4 1
5 2
12
1652
2
3 1
6 1
12
1653
2
3 1
6 2
13
1850
2
2 1
7 1
13
1851
2
2 1
7 2
14
2048
2
1 1
8 1
14
2049
2
1 1
8 2
15
2246
2
0 1
9 1
15
2247
2
0 1
9 2
10
11
1472
2
4 2
5 1
11
1473
2
4 2
5 2
12
1670
2
3 2
6 1
12
1671
2
3 2
6 2
13
1868
2
2 2
7 1
13
1869
2
2 2
7 2
14
2066
2
1 2
8 1
14
2067
2
1 2
8 2
15
2264
2
0 2
9 1
15
2265
2
0 2
9 2
10
11
1490
2
4 3
5 1
11
1491
2
4 3
5 2
12
1688
2
3 3
6 1
12
1689
2
3 3
6 2
13
1886
2
2 3
7 1
13
1887
2
2 3
7 2
14
2084
2
1 3
8 1
14
2085
2
1 3
8 2
15
2282
2
0 3
9 1
15
2283
2
0 3
9 2
10
11
1508
2
4 4
5 1
11
1509
2
4 4
5 2
12
1706
2
3 4
6 1
12
1707
2
3 4
6 2
13
1904
2
2 4
7 1
13
1905
2
2 4
7 2
14
2102
2
1 4
8 1
14
2103
2
1 4
8 2
15
2300
2
0 4
9 1
15
2301
2
0 4
9 2
10
11
1526
2
4 5
5 1
11
1527
2
4 5
5 2
12
1724
2
3 5
6 1
12
1725
2
3 5
6 2
13
1922
2
2 5
7 1
13
1923
2
2 5
7 2
14
2120
2
1 5
8 1
14
2121
2
1 5
8 2
15
2318
2
0 5
9 1
15
2319
2
0 5
9 2
10
11
1544
2
4 6
5 1
11
1545
2
4 6
5 2
12
1742
2
3 6
6 1
12
1743
2
3 6
6 2
13
1940
2
2 6
7 1
13
1941
2
2 6
7 2
14
2138
2
1 6
8 1
14
2139
2
1 6
8 2
15
2336
2
0 6
9 1
15
2337
2
0 6
9 2
10
11
1562
2
4 7
5 1
11
1563
2
4 7
5 2
12
1760
2
3 7
6 1
12
1761
2
3 7
6 2
13
1958
2
2 7
7 1
13
1959
2
2 7
7 2
14
2156
2
1 7
8 1
14
2157
2
1 7
8 2
15
2354
2
0 7
9 1
15
2355
2
0 7
9 2
10
11
1580
2
4 8
5 1
11
1581
2
4 8
5 2
12
1778
2
3 8
6 1
12
1779
2
3 8
6 2
13
1976
2
2 8
7 1
13
1977
2
2 8
7 2
14
2174
2
1 8
8 1
14
2175
2
1 8
8 2
15
2372
2
0 8
9 1
15
2373
2
0 8
9 2
10
11
1598
2
4 9
5 1
11
1599
2
4 9
5 2
12
1796
2
3 9
6 1
12
1797
2
3 9
6 2
13
1994
2
2 9
7 1
13
1995
2
2 9
7 2
14
2192
2
1 9
8 1
14
2193
2
1 9
8 2
15
2390
2
0 9
9 1
15
2391
2
0 9
9 2
10
11
1616
2
4 10
5 1
11
1617
2
4 10
5 2
12
1814
2
3 10
6 1
12
1815
2
3 10
6 2
13
2012
2
2 10
7 1
13
2013
2
2 10
7 2
14
2210
2
1 10
8 1
14
2211
2
1 10
8 2
15
2408
2
0 10
9 1
15
2409
2
0 10
9 2
22
0
447
2
4 0
5 1
0
446
2
4 0
5 0
1
464
2
4 1
5 0
1
465
2
4 1
5 1
2
482
2
4 2
5 0
2
483
2
4 2
5 1
3
500
2
4 3
5 0
3
501
2
4 3
5 1
4
518
2
4 4
5 0
4
519
2
4 4
5 1
5
537
2
4 5
5 1
5
536
2
4 5
5 0
6
554
2
4 6
5 0
6
555
2
4 6
5 1
7
572
2
4 7
5 0
7
573
2
4 7
5 1
8
590
2
4 8
5 0
8
591
2
4 8
5 1
9
608
2
4 9
5 0
9
609
2
4 9
5 1
10
626
2
4 10
5 0
10
627
2
4 10
5 1
22
0
645
2
3 0
6 1
0
644
2
3 0
6 0
1
662
2
3 1
6 0
1
663
2
3 1
6 1
2
680
2
3 2
6 0
2
681
2
3 2
6 1
3
698
2
3 3
6 0
3
699
2
3 3
6 1
4
716
2
3 4
6 0
4
717
2
3 4
6 1
5
735
2
3 5
6 1
5
734
2
3 5
6 0
6
752
2
3 6
6 0
6
753
2
3 6
6 1
7
770
2
3 7
6 0
7
771
2
3 7
6 1
8
788
2
3 8
6 0
8
789
2
3 8
6 1
9
806
2
3 9
6 0
9
807
2
3 9
6 1
10
824
2
3 10
6 0
10
825
2
3 10
6 1
22
0
843
2
2 0
7 1
0
842
2
2 0
7 0
1
860
2
2 1
7 0
1
861
2
2 1
7 1
2
878
2
2 2
7 0
2
879
2
2 2
7 1
3
896
2
2 3
7 0
3
897
2
2 3
7 1
4
914
2
2 4
7 0
4
915
2
2 4
7 1
5
933
2
2 5
7 1
5
932
2
2 5
7 0
6
950
2
2 6
7 0
6
951
2
2 6
7 1
7
968
2
2 7
7 0
7
969
2
2 7
7 1
8
986
2
2 8
7 0
8
987
2
2 8
7 1
9
1004
2
2 9
7 0
9
1005
2
2 9
7 1
10
1022
2
2 10
7 0
10
1023
2
2 10
7 1
22
0
1041
2
1 0
8 1
0
1040
2
1 0
8 0
1
1058
2
1 1
8 0
1
1059
2
1 1
8 1
2
1076
2
1 2
8 0
2
1077
2
1 2
8 1
3
1094
2
1 3
8 0
3
1095
2
1 3
8 1
4
1112
2
1 4
8 0
4
1113
2
1 4
8 1
5
1131
2
1 5
8 1
5
1130
2
1 5
8 0
6
1148
2
1 6
8 0
6
1149
2
1 6
8 1
7
1166
2
1 7
8 0
7
1167
2
1 7
8 1
8
1184
2
1 8
8 0
8
1185
2
1 8
8 1
9
1202
2
1 9
8 0
9
1203
2
1 9
8 1
10
1220
2
1 10
8 0
10
1221
2
1 10
8 1
22
0
1239
2
0 0
9 1
0
1238
2
0 0
9 0
1
1256
2
0 1
9 0
1
1257
2
0 1
9 1
2
1274
2
0 2
9 0
2
1275
2
0 2
9 1
3
1292
2
0 3
9 0
3
1293
2
0 3
9 1
4
1310
2
0 4
9 0
4
1311
2
0 4
9 1
5
1329
2
0 5
9 1
5
1328
2
0 5
9 0
6
1346
2
0 6
9 0
6
1347
2
0 6
9 1
7
1364
2
0 7
9 0
7
1365
2
0 7
9 1
8
1382
2
0 8
9 0
8
1383
2
0 8
9 1
9
1400
2
0 9
9 0
9
1401
2
0 9
9 1
10
1418
2
0 10
9 0
10
1419
2
0 10
9 1
end_DTG
begin_CG
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
8 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
7 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
6 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5 396
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
end_CG
