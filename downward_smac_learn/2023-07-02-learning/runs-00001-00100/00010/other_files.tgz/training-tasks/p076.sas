begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var18
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var13
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var19
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l14)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




11
7 1
15
3411
2
4 11
7 2
16
3774
2
3 11
8 1
16
3775
2
3 11
8 2
17
4138
2
2 11
9 1
17
4139
2
2 11
9 2
18
4502
2
1 11
10 1
18
4503
2
1 11
10 2
19
4866
2
0 11
11 1
19
4867
2
0 11
11 2
12
14
3072
2
5 12
6 1
14
3073
2
5 12
6 2
15
3436
2
4 12
7 1
15
3437
2
4 12
7 2
16
3800
2
3 12
8 1
16
3801
2
3 12
8 2
17
4164
2
2 12
9 1
17
4165
2
2 12
9 2
18
4528
2
1 12
10 1
18
4529
2
1 12
10 2
19
4892
2
0 12
11 1
19
4893
2
0 12
11 2
12
14
3098
2
5 13
6 1
14
3099
2
5 13
6 2
15
3462
2
4 13
7 1
15
3463
2
4 13
7 2
16
3826
2
3 13
8 1
16
3827
2
3 13
8 2
17
4190
2
2 13
9 1
17
4191
2
2 13
9 2
18
4554
2
1 13
10 1
18
4555
2
1 13
10 2
19
4918
2
0 13
11 1
19
4919
2
0 13
11 2
28
0
577
2
5 0
6 1
0
576
2
5 0
6 0
1
602
2
5 1
6 0
1
603
2
5 1
6 1
2
628
2
5 2
6 0
2
629
2
5 2
6 1
3
654
2
5 3
6 0
3
655
2
5 3
6 1
4
680
2
5 4
6 0
4
681
2
5 4
6 1
5
706
2
5 5
6 0
5
707
2
5 5
6 1
6
732
2
5 6
6 0
6
733
2
5 6
6 1
7
758
2
5 7
6 0
7
759
2
5 7
6 1
8
784
2
5 8
6 0
8
785
2
5 8
6 1
9
810
2
5 9
6 0
9
811
2
5 9
6 1
10
836
2
5 10
6 0
10
837
2
5 10
6 1
11
862
2
5 11
6 0
11
863
2
5 11
6 1
12
888
2
5 12
6 0
12
889
2
5 12
6 1
13
914
2
5 13
6 0
13
915
2
5 13
6 1
28
0
941
2
4 0
7 1
0
940
2
4 0
7 0
1
966
2
4 1
7 0
1
967
2
4 1
7 1
2
992
2
4 2
7 0
2
993
2
4 2
7 1
3
1018
2
4 3
7 0
3
1019
2
4 3
7 1
4
1044
2
4 4
7 0
4
1045
2
4 4
7 1
5
1070
2
4 5
7 0
5
1071
2
4 5
7 1
6
1096
2
4 6
7 0
6
1097
2
4 6
7 1
7
1122
2
4 7
7 0
7
1123
2
4 7
7 1
8
1148
2
4 8
7 0
8
1149
2
4 8
7 1
9
1174
2
4 9
7 0
9
1175
2
4 9
7 1
10
1200
2
4 10
7 0
10
1201
2
4 10
7 1
11
1226
2
4 11
7 0
11
1227
2
4 11
7 1
12
1252
2
4 12
7 0
12
1253
2
4 12
7 1
13
1278
2
4 13
7 0
13
1279
2
4 13
7 1
28
0
1305
2
3 0
8 1
0
1304
2
3 0
8 0
1
1330
2
3 1
8 0
1
1331
2
3 1
8 1
2
1356
2
3 2
8 0
2
1357
2
3 2
8 1
3
1382
2
3 3
8 0
3
1383
2
3 3
8 1
4
1408
2
3 4
8 0
4
1409
2
3 4
8 1
5
1434
2
3 5
8 0
5
1435
2
3 5
8 1
6
1460
2
3 6
8 0
6
1461
2
3 6
8 1
7
1486
2
3 7
8 0
7
1487
2
3 7
8 1
8
1512
2
3 8
8 0
8
1513
2
3 8
8 1
9
1538
2
3 9
8 0
9
1539
2
3 9
8 1
10
1564
2
3 10
8 0
10
1565
2
3 10
8 1
11
1590
2
3 11
8 0
11
1591
2
3 11
8 1
12
1616
2
3 12
8 0
12
1617
2
3 12
8 1
13
1642
2
3 13
8 0
13
1643
2
3 13
8 1
28
0
1669
2
2 0
9 1
0
1668
2
2 0
9 0
1
1694
2
2 1
9 0
1
1695
2
2 1
9 1
2
1720
2
2 2
9 0
2
1721
2
2 2
9 1
3
1746
2
2 3
9 0
3
1747
2
2 3
9 1
4
1772
2
2 4
9 0
4
1773
2
2 4
9 1
5
1798
2
2 5
9 0
5
1799
2
2 5
9 1
6
1824
2
2 6
9 0
6
1825
2
2 6
9 1
7
1850
2
2 7
9 0
7
1851
2
2 7
9 1
8
1876
2
2 8
9 0
8
1877
2
2 8
9 1
9
1902
2
2 9
9 0
9
1903
2
2 9
9 1
10
1928
2
2 10
9 0
10
1929
2
2 10
9 1
11
1954
2
2 11
9 0
11
1955
2
2 11
9 1
12
1980
2
2 12
9 0
12
1981
2
2 12
9 1
13
2006
2
2 13
9 0
13
2007
2
2 13
9 1
28
0
2033
2
1 0
10 1
0
2032
2
1 0
10 0
1
2058
2
1 1
10 0
1
2059
2
1 1
10 1
2
2084
2
1 2
10 0
2
2085
2
1 2
10 1
3
2110
2
1 3
10 0
3
2111
2
1 3
10 1
4
2136
2
1 4
10 0
4
2137
2
1 4
10 1
5
2162
2
1 5
10 0
5
2163
2
1 5
10 1
6
2188
2
1 6
10 0
6
2189
2
1 6
10 1
7
2214
2
1 7
10 0
7
2215
2
1 7
10 1
8
2240
2
1 8
10 0
8
2241
2
1 8
10 1
9
2266
2
1 9
10 0
9
2267
2
1 9
10 1
10
2292
2
1 10
10 0
10
2293
2
1 10
10 1
11
2318
2
1 11
10 0
11
2319
2
1 11
10 1
12
2344
2
1 12
10 0
12
2345
2
1 12
10 1
13
2370
2
1 13
10 0
13
2371
2
1 13
10 1
28
0
2397
2
0 0
11 1
0
2396
2
0 0
11 0
1
2422
2
0 1
11 0
1
2423
2
0 1
11 1
2
2448
2
0 2
11 0
2
2449
2
0 2
11 1
3
2474
2
0 3
11 0
3
2475
2
0 3
11 1
4
2500
2
0 4
11 0
4
2501
2
0 4
11 1
5
2526
2
0 5
11 0
5
2527
2
0 5
11 1
6
2552
2
0 6
11 0
6
2553
2
0 6
11 1
7
2578
2
0 7
11 0
7
2579
2
0 7
11 1
8
2604
2
0 8
11 0
8
2605
2
0 8
11 1
9
2630
2
0 9
11 0
9
2631
2
0 9
11 1
10
2656
2
0 10
11 0
10
2657
2
0 10
11 1
11
2682
2
0 11
11 0
11
2683
2
0 11
11 1
12
2708
2
0 12
11 0
12
2709
2
0 12
11 1
13
2734
2
0 13
11 0
13
2735
2
0 13
11 1
end_DTG
begin_CG
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
11 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
10 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
9 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
8 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
7 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6 728
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
