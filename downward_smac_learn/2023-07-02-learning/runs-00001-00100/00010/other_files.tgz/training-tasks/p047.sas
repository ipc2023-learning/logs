begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var12
-1
10
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var11
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var10
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var8
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var13
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
15
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
15
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
15
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
15
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
15
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
15
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
15
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
15
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
0
begin_state
6
7
8
3
1
2
1
2
1
1
9
0
6
8
3
4
2
3
end_state
begin_goal
8
10 3
11 6
12 5
13 7
14 9
15 1
16 6
17 7
end_goal
1700
begin_operator
drive v1 l1 l10
0
1
0 4 0 1
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 4 1 0
0
end_operator
begin_operator
drive v1 l10 l2
0
1
0 4 1 2
0
end_operator
begin_operator
drive v1 l10 l8
0
1
0 4 1 8
0
end_operator
begin_operator
drive v1 l10 l9
0
1
0 4 1 9
0
end_operator
begin_operator
drive v1 l2 l10
0
1
0 4 2 1
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 4 3 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 4 3 7
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 4 4 8
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 4 5 3
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 4 5 8
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 4 6 8
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 4 7 3
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 4 8 0
0
end_operator
begin_operator
drive v1 l8 l10
0
1
0 4 8 1
0
end_operator
begin_operator
drive v1 l8 l4
0
1
0 4 8 4
0
end_operator
begin_operator
drive v1 l8 l5
0
1
0 4 8 5
0
end_operator
begin_operator
drive v1 l8 l6
0
1
0 4 8 6
0
end_operator
begin_operator
drive v1 l9 l10
0
1
0 4 9 1
0
end_operator
begin_operator
drive




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




64
2
2 2
7 0
2
465
2
2 2
7 1
3
480
2
2 3
7 0
3
481
2
2 3
7 1
4
496
2
2 4
7 0
4
497
2
2 4
7 1
5
512
2
2 5
7 0
5
513
2
2 5
7 1
6
528
2
2 6
7 0
6
529
2
2 6
7 1
7
544
2
2 7
7 0
7
545
2
2 7
7 1
8
560
2
2 8
7 0
8
561
2
2 8
7 1
9
576
2
2 9
7 0
9
577
2
2 9
7 1
20
0
593
2
1 0
8 1
0
592
2
1 0
8 0
1
608
2
1 1
8 0
1
609
2
1 1
8 1
2
624
2
1 2
8 0
2
625
2
1 2
8 1
3
640
2
1 3
8 0
3
641
2
1 3
8 1
4
656
2
1 4
8 0
4
657
2
1 4
8 1
5
672
2
1 5
8 0
5
673
2
1 5
8 1
6
688
2
1 6
8 0
6
689
2
1 6
8 1
7
704
2
1 7
8 0
7
705
2
1 7
8 1
8
720
2
1 8
8 0
8
721
2
1 8
8 1
9
736
2
1 9
8 0
9
737
2
1 9
8 1
20
0
753
2
0 0
9 1
0
752
2
0 0
9 0
1
768
2
0 1
9 0
1
769
2
0 1
9 1
2
784
2
0 2
9 0
2
785
2
0 2
9 1
3
800
2
0 3
9 0
3
801
2
0 3
9 1
4
816
2
0 4
9 0
4
817
2
0 4
9 1
5
832
2
0 5
9 0
5
833
2
0 5
9 1
6
848
2
0 6
9 0
6
849
2
0 6
9 1
7
864
2
0 7
9 0
7
865
2
0 7
9 1
8
880
2
0 8
9 0
8
881
2
0 8
9 1
9
896
2
0 9
9 0
9
897
2
0 9
9 1
end_DTG
begin_DTG
10
10
914
2
4 0
5 1
10
915
2
4 0
5 2
11
1074
2
3 0
6 1
11
1075
2
3 0
6 2
12
1234
2
2 0
7 1
12
1235
2
2 0
7 2
13
1394
2
1 0
8 1
13
1395
2
1 0
8 2
14
1554
2
0 0
9 1
14
1555
2
0 0
9 2
10
10
930
2
4 1
5 1
10
931
2
4 1
5 2
11
1090
2
3 1
6 1
11
1091
2
3 1
6 2
12
1250
2
2 1
7 1
12
1251
2
2 1
7 2
13
1410
2
1 1
8 1
13
1411
2
1 1
8 2
14
1570
2
0 1
9 1
14
1571
2
0 1
9 2
10
10
946
2
4 2
5 1
10
947
2
4 2
5 2
11
1106
2
3 2
6 1
11
1107
2
3 2
6 2
12
1266
2
2 2
7 1
12
1267
2
2 2
7 2
13
1426
2
1 2
8 1
13
1427
2
1 2
8 2
14
1586
2
0 2
9 1
14
1587
2
0 2
9 2
10
10
962
2
4 3
5 1
10
963
2
4 3
5 2
11
1122
2
3 3
6 1
11
1123
2
3 3
6 2
12
1282
2
2 3
7 1
12
1283
2
2 3
7 2
13
1442
2
1 3
8 1
13
1443
2
1 3
8 2
14
1602
2
0 3
9 1
14
1603
2
0 3
9 2
10
10
978
2
4 4
5 1
10
979
2
4 4
5 2
11
1138
2
3 4
6 1
11
1139
2
3 4
6 2
12
1298
2
2 4
7 1
12
1299
2
2 4
7 2
13
1458
2
1 4
8 1
13
1459
2
1 4
8 2
14
1618
2
0 4
9 1
14
1619
2
0 4
9 2
10
10
994
2
4 5
5 1
10
995
2
4 5
5 2
11
1154
2
3 5
6 1
11
1155
2
3 5
6 2
12
1314
2
2 5
7 1
12
1315
2
2 5
7 2
13
1474
2
1 5
8 1
13
1475
2
1 5
8 2
14
1634
2
0 5
9 1
14
1635
2
0 5
9 2
10
10
1010
2
4 6
5 1
10
1011
2
4 6
5 2
11
1170
2
3 6
6 1
11
1171
2
3 6
6 2
12
1330
2
2 6
7 1
12
1331
2
2 6
7 2
13
1490
2
1 6
8 1
13
1491
2
1 6
8 2
14
1650
2
0 6
9 1
14
1651
2
0 6
9 2
10
10
1026
2
4 7
5 1
10
1027
2
4 7
5 2
11
1186
2
3 7
6 1
11
1187
2
3 7
6 2
12
1346
2
2 7
7 1
12
1347
2
2 7
7 2
13
1506
2
1 7
8 1
13
1507
2
1 7
8 2
14
1666
2
0 7
9 1
14
1667
2
0 7
9 2
10
10
1042
2
4 8
5 1
10
1043
2
4 8
5 2
11
1202
2
3 8
6 1
11
1203
2
3 8
6 2
12
1362
2
2 8
7 1
12
1363
2
2 8
7 2
13
1522
2
1 8
8 1
13
1523
2
1 8
8 2
14
1682
2
0 8
9 1
14
1683
2
0 8
9 2
10
10
1058
2
4 9
5 1
10
1059
2
4 9
5 2
11
1218
2
3 9
6 1
11
1219
2
3 9
6 2
12
1378
2
2 9
7 1
12
1379
2
2 9
7 2
13
1538
2
1 9
8 1
13
1539
2
1 9
8 2
14
1698
2
0 9
9 1
14
1699
2
0 9
9 2
20
0
115
2
4 0
5 1
0
114
2
4 0
5 0
1
130
2
4 1
5 0
1
131
2
4 1
5 1
2
146
2
4 2
5 0
2
147
2
4 2
5 1
3
162
2
4 3
5 0
3
163
2
4 3
5 1
4
178
2
4 4
5 0
4
179
2
4 4
5 1
5
194
2
4 5
5 0
5
195
2
4 5
5 1
6
210
2
4 6
5 0
6
211
2
4 6
5 1
7
226
2
4 7
5 0
7
227
2
4 7
5 1
8
242
2
4 8
5 0
8
243
2
4 8
5 1
9
258
2
4 9
5 0
9
259
2
4 9
5 1
20
0
275
2
3 0
6 1
0
274
2
3 0
6 0
1
290
2
3 1
6 0
1
291
2
3 1
6 1
2
306
2
3 2
6 0
2
307
2
3 2
6 1
3
322
2
3 3
6 0
3
323
2
3 3
6 1
4
338
2
3 4
6 0
4
339
2
3 4
6 1
5
354
2
3 5
6 0
5
355
2
3 5
6 1
6
370
2
3 6
6 0
6
371
2
3 6
6 1
7
386
2
3 7
6 0
7
387
2
3 7
6 1
8
402
2
3 8
6 0
8
403
2
3 8
6 1
9
418
2
3 9
6 0
9
419
2
3 9
6 1
20
0
435
2
2 0
7 1
0
434
2
2 0
7 0
1
450
2
2 1
7 0
1
451
2
2 1
7 1
2
466
2
2 2
7 0
2
467
2
2 2
7 1
3
482
2
2 3
7 0
3
483
2
2 3
7 1
4
498
2
2 4
7 0
4
499
2
2 4
7 1
5
514
2
2 5
7 0
5
515
2
2 5
7 1
6
530
2
2 6
7 0
6
531
2
2 6
7 1
7
546
2
2 7
7 0
7
547
2
2 7
7 1
8
562
2
2 8
7 0
8
563
2
2 8
7 1
9
578
2
2 9
7 0
9
579
2
2 9
7 1
20
0
595
2
1 0
8 1
0
594
2
1 0
8 0
1
610
2
1 1
8 0
1
611
2
1 1
8 1
2
626
2
1 2
8 0
2
627
2
1 2
8 1
3
642
2
1 3
8 0
3
643
2
1 3
8 1
4
658
2
1 4
8 0
4
659
2
1 4
8 1
5
674
2
1 5
8 0
5
675
2
1 5
8 1
6
690
2
1 6
8 0
6
691
2
1 6
8 1
7
706
2
1 7
8 0
7
707
2
1 7
8 1
8
722
2
1 8
8 0
8
723
2
1 8
8 1
9
738
2
1 9
8 0
9
739
2
1 9
8 1
20
0
755
2
0 0
9 1
0
754
2
0 0
9 0
1
770
2
0 1
9 0
1
771
2
0 1
9 1
2
786
2
0 2
9 0
2
787
2
0 2
9 1
3
802
2
0 3
9 0
3
803
2
0 3
9 1
4
818
2
0 4
9 0
4
819
2
0 4
9 1
5
834
2
0 5
9 0
5
835
2
0 5
9 1
6
850
2
0 6
9 0
6
851
2
0 6
9 1
7
866
2
0 7
9 0
7
867
2
0 7
9 1
8
882
2
0 8
9 0
8
883
2
0 8
9 1
9
898
2
0 9
9 0
9
899
2
0 9
9 1
end_DTG
begin_CG
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
9 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
7 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
6 320
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
5 320
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
8
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
end_CG
