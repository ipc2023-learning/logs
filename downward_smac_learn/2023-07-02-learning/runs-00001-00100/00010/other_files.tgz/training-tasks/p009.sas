begin_version
3
end_version
begin_metric
0
end_metric
6
begin_variable
var3
-1
4
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
end_variable
begin_variable
var2
-1
4
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
end_variable
begin_variable
var4
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var5
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var0
-1
6
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom in(p1, v1)
Atom in(p1, v2)
end_variable
begin_variable
var1
-1
6
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom in(p2, v1)
Atom in(p2, v2)
end_variable
0
begin_state
0
0
2
2
0
0
end_state
begin_goal
2
4 3
5 2
end_goal
76
begin_operator
drive v1 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
1 0
2
0 4 4 0
0 2 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
1 0
2
0 4 4 0
0 2 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
1 0
2
0 5 4 0
0 2 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
1 0
2
0 5 4 0
0 2 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
1 1
2
0 4 4 1
0 2 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c1 c2
1
1 1
2
0 4 4 1
0 2 1 2
0
end_operator
begin_operator
drop v1 l2 p2 c0 c1
1
1 1
2
0 5 4 1
0 2 0 1
0
end_operator
begin_operator
drop v1 l2 p2 c1 c2
1
1 1
2
0 5 4 1
0 2 1 2
0
end_operator
begin_operator
drop v1 l3 p1 c0 c1
1
1 2
2
0 4 4 2
0 2 0 1
0
end_operator
begin_operator
drop v1 l3 p1 c1 c2
1
1 2
2
0 4 4 2
0 2 1 2
0
end_operator
begin_operator
drop v1 l3 p2 c0 c1
1
1 2
2
0 5 4 2
0 2 0 1
0
end_operator
begin_operator
drop v1 l3 p2 c1 c2
1
1 2
2
0 5 4 2
0 2 1 2
0
end_operator
begin_operator
drop v1 l4 p1 c0 c1
1
1 3
2
0 4 4 3
0 2 0 1
0
end_operator
begin_operator
drop v1 l4 p1 c1 c2
1
1 3
2
0 4 4 3
0 2 1 2
0
end_operator
begin_operator
drop v1 l4 p2 c0 c1
1
1 3
2
0 5 4 3
0 2 0 1
0
end_operator
begin_operator
drop v1 l4 p2 c1 c2
1
1 3
2
0 5 4 3
0 2 1 2
0
end_operator
begin_operator
drop v2 l1 p1 c0 c1
1
0 0
2
0 4 5 0
0 3 0 1
0
end_operator
begin_operator
drop v2 l1 p1 c1 c2
1
0 0
2
0 4 5 0
0 3 1 2
0
end_operator
begin_operator
drop v2 l1 p2 c0 c1
1
0 0
2
0 5 5 0
0 3 0 1
0
end_operator
begin_operator
drop v2 l1 p2 c1 c2
1
0 0
2
0 5 5 0
0 3 1 2
0
end_operator
begin_operator
drop v2 l2 p1 c0 c1
1
0 1
2
0 4 5 1
0 3 0 1
0
end_operator
begin_operator
drop v2 l2 p1 c1 c2
1
0 1
2
0 4 5 1
0 3 1 2
0
end_operator
begin_operator
drop v2 l2 p2 c0 c1
1
0 1
2
0 5 5 1
0 3 0 1
0
end_operator
begin_operator
drop v2 l2 p2 c1 c2
1
0 1
2
0 5 5 1
0 3 1 2
0
end_operator
begin_operator
drop v2 l3 p1 c0 c1
1
0 2
2
0 4 5 2
0 3 0 1
0
end_operator
begin_operator
drop v2 l3 p1 c1 c2
1
0 2
2
0 4 5 2
0 3 1 2
0
end_operator
begin_operator
drop v2 l3 p2 c0 c1
1
0 2
2
0 5 5 2
0 3 0 1
0
end_operator
begin_operator
drop v2 l3 p2 c1 c2
1
0 2
2
0 5 5 2
0 3 1 2
0
end_operator
begin_operator
drop v2 l4 p1 c0 c1
1
0 3
2
0 4 5 3
0 3 0 1
0
end_operator
begin_operator
drop v2 l4 p1 c1 c2
1
0 3
2
0 4 5 3
0 3 1 2
0
end_operator
begin_operator
drop v2 l4 p2 c0 c1
1
0 3
2
0 5 5 3
0 3 0 1
0
end_operator
begin_operator
drop v2 l4 p2 c1 c2
1
0 3
2
0 5 5 3
0 3 1 2
0
end_operator
begin_operator
pick-up v1 l1 p1 c0 c1
1
1 0
2
0 4 0 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l1 p1 c1 c2
1
1 0
2
0 4 0 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l1 p2 c0 c1
1
1 0
2
0 5 0 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l1 p2 c1 c2
1
1 0
2
0 5 0 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l2 p1 c0 c1
1
1 1
2
0 4 1 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l2 p1 c1 c2
1
1 1
2
0 4 1 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l2 p2 c0 c1
1
1 1
2
0 5 1 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l2 p2 c1 c2
1
1 1
2
0 5 1 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l3 p1 c0 c1
1
1 2
2
0 4 2 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l3 p1 c1 c2
1
1 2
2
0 4 2 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l3 p2 c0 c1
1
1 2
2
0 5 2 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l3 p2 c1 c2
1
1 2
2
0 5 2 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l4 p1 c0 c1
1
1 3
2
0 4 3 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l4 p1 c1 c2
1
1 3
2
0 4 3 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l4 p2 c0 c1
1
1 3
2
0 5 3 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l4 p2 c1 c2
1
1 3
2
0 5 3 4
0 2 2 1
0
end_operator
begin_operator
pick-up v2 l1 p1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5
0 3 1 0
0
end_operator
begin_operator
pick-up v2 l4 p2 c1 c2
1
0 3
2
0 5 3 5
0 3 2 1
0
end_operator
0
begin_SG
switch 4
check 0
switch 1
check 0
switch 2
check 0
check 0
check 1
44
check 1
45
check 0
check 0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 0
check 1
60
check 1
61
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
switch 2
check 0
check 0
check 1
48
check 1
49
check 0
check 0
check 0
switch 0
check 0
check 0
switch 3
check 0
check 0
check 1
64
check 1
65
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
52
check 1
53
check 0
check 0
switch 0
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
68
check 1
69
check 0
check 0
check 0
switch 1
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
56
check 1
57
check 0
switch 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
72
check 1
73
check 0
check 0
switch 1
check 0
switch 2
check 0
check 1
12
check 1
13
check 0
check 0
switch 2
check 0
check 1
16
check 1
17
check 0
check 0
switch 2
check 0
check 1
20
check 1
21
check 0
check 0
switch 2
check 0
check 1
24
check 1
25
check 0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 1
28
check 1
29
check 0
check 0
switch 3
check 0
check 1
32
check 1
33
check 0
check 0
switch 3
check 0
check 1
36
check 1
37
check 0
check 0
switch 3
check 0
check 1
40
check 1
41
check 0
check 0
check 0
switch 5
check 0
switch 1
check 0
switch 2
check 0
check 0
check 1
46
check 1
47
check 0
check 0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 0
check 1
62
check 1
63
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
switch 2
check 0
check 0
check 1
50
check 1
51
check 0
check 0
check 0
switch 0
check 0
check 0
switch 3
check 0
check 0
check 1
66
check 1
67
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
54
check 1
55
check 0
check 0
switch 0
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
70
check 1
71
check 0
check 0
check 0
switch 1
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
58
check 1
59
check 0
switch 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
74
check 1
75
check 0
check 0
switch 1
check 0
switch 2
check 0
check 1
14
check 1
15
check 0
check 0
switch 2
check 0
check 1
18
check 1
19
check 0
check 0
switch 2
check 0
check 1
22
check 1
23
check 0
check 0
switch 2
check 0
check 1
26
check 1
27
check 0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 1
30
check 1
31
check 0
check 0
switch 3
check 0
check 1
34
check 1
35
check 0
check 0
switch 3
check 0
check 1
38
check 1
39
check 0
check 0
switch 3
check 0
check 1
42
check 1
43
check 0
check 0
check 0
switch 1
check 0
check 1
0
check 3
1
2
3
check 1
4
check 1
5
switch 0
check 0
check 1
6
check 3
7
8
9
check 1
10
check 1
11
check 0
end_SG
begin_DTG
1
1
6
0
3
0
7
0
2
8
0
3
9
0
1
1
10
0
1
1
11
0
end_DTG
begin_DTG
1
1
0
0
3
0
1
0
2
2
0
3
3
0
1
1
4
0
1
1
5
0
end_DTG
begin_DTG
8
1
12
2
4 4
1 0
1
14
2
5 4
1 0
1
16
2
4 4
1 1
1
18
2
5 4
1 1
1
20
2
4 4
1 2
1
22
2
5 4
1 2
1
24
2
4 4
1 3
1
26
2
5 4
1 3
16
0
44
2
4 0
1 0
0
46
2
5 0
1 0
0
48
2
4 1
1 1
0
50
2
5 1
1 1
0
52
2
4 2
1 2
0
54
2
5 2
1 2
0
56
2
4 3
1 3
0
58
2
5 3
1 3
2
13
2
4 4
1 0
2
15
2
5 4
1 0
2
17
2
4 4
1 1
2
19
2
5 4
1 1
2
21
2
4 4
1 2
2
23
2
5 4
1 2
2
25
2
4 4
1 3
2
27
2
5 4
1 3
8
1
45
2
4 0
1 0
1
47
2
5 0
1 0
1
49
2
4 1
1 1
1
51
2
5 1
1 1
1
53
2
4 2
1 2
1
55
2
5 2
1 2
1
57
2
4 3
1 3
1
59
2
5 3
1 3
end_DTG
begin_DTG
8
1
28
2
4 5
0 0
1
30
2
5 5
0 0
1
32
2
4 5
0 1
1
34
2
5 5
0 1
1
36
2
4 5
0 2
1
38
2
5 5
0 2
1
40
2
4 5
0 3
1
42
2
5 5
0 3
16
0
60
2
4 0
0 0
0
62
2
5 0
0 0
0
64
2
4 1
0 1
0
66
2
5 1
0 1
0
68
2
4 2
0 2
0
70
2
5 2
0 2
0
72
2
4 3
0 3
0
74
2
5 3
0 3
2
29
2
4 5
0 0
2
31
2
5 5
0 0
2
33
2
4 5
0 1
2
35
2
5 5
0 1
2
37
2
4 5
0 2
2
39
2
5 5
0 2
2
41
2
4 5
0 3
2
43
2
5 5
0 3
8
1
61
2
4 0
0 0
1
63
2
5 0
0 0
1
65
2
4 1
0 1
1
67
2
5 1
0 1
1
69
2
4 2
0 2
1
71
2
5 2
0 2
1
73
2
4 3
0 3
1
75
2
5 3
0 3
end_DTG
begin_DTG
4
4
44
2
1 0
2 1
4
45
2
1 0
2 2
5
60
2
0 0
3 1
5
61
2
0 0
3 2
4
4
48
2
1 1
2 1
4
49
2
1 1
2 2
5
64
2
0 1
3 1
5
65
2
0 1
3 2
4
4
52
2
1 2
2 1
4
53
2
1 2
2 2
5
68
2
0 2
3 1
5
69
2
0 2
3 2
4
4
56
2
1 3
2 1
4
57
2
1 3
2 2
5
72
2
0 3
3 1
5
73
2
0 3
3 2
8
0
12
2
1 0
2 0
0
13
2
1 0
2 1
1
16
2
1 1
2 0
1
17
2
1 1
2 1
2
20
2
1 2
2 0
2
21
2
1 2
2 1
3
24
2
1 3
2 0
3
25
2
1 3
2 1
8
0
28
2
0 0
3 0
0
29
2
0 0
3 1
1
32
2
0 1
3 0
1
33
2
0 1
3 1
2
36
2
0 2
3 0
2
37
2
0 2
3 1
3
40
2
0 3
3 0
3
41
2
0 3
3 1
end_DTG
begin_DTG
4
4
46
2
1 0
2 1
4
47
2
1 0
2 2
5
62
2
0 0
3 1
5
63
2
0 0
3 2
4
4
50
2
1 1
2 1
4
51
2
1 1
2 2
5
66
2
0 1
3 1
5
67
2
0 1
3 2
4
4
54
2
1 2
2 1
4
55
2
1 2
2 2
5
70
2
0 2
3 1
5
71
2
0 2
3 2
4
4
58
2
1 3
2 1
4
59
2
1 3
2 2
5
74
2
0 3
3 1
5
75
2
0 3
3 2
8
0
14
2
1 0
2 0
0
15
2
1 0
2 1
1
18
2
1 1
2 0
1
19
2
1 1
2 1
2
22
2
1 2
2 0
2
23
2
1 2
2 1
3
26
2
1 3
2 0
3
27
2
1 3
2 1
8
0
30
2
0 0
3 0
0
31
2
0 0
3 1
1
34
2
0 1
3 0
1
35
2
0 1
3 1
2
38
2
0 2
3 0
2
39
2
0 2
3 1
3
42
2
0 3
3 0
3
43
2
0 3
3 1
end_DTG
begin_CG
3
4 16
5 16
3 32
3
4 16
5 16
2 32
2
4 16
5 16
2
4 16
5 16
2
2 16
3 16
2
2 16
3 16
end_CG
