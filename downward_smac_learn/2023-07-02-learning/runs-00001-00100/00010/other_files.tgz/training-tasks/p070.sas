begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var17
-1
13
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var16
-1
13
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var15
-1
13
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var14
-1
13
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var13
-1
13
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var12
-1
13
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var18
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
19
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
19
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
19
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
19
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
19
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var5
-1
19
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var6
-1
19
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
Atom in(p4, v6)
end_variable
begin_variable
var7
-1
19
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l13)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
Atom in(p5, v6)
end_variable
begin_variable
var8
-1
19
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
16
3191
2
2 8
9 2
17
3502
2
1 8
10 1
17
3503
2
1 8
10 2
18
3814
2
0 8
11 1
18
3815
2
0 8
11 2
12
13
2278
2
5 9
6 1
13
2279
2
5 9
6 2
14
2590
2
4 9
7 1
14
2591
2
4 9
7 2
15
2902
2
3 9
8 1
15
2903
2
3 9
8 2
16
3214
2
2 9
9 1
16
3215
2
2 9
9 2
17
3526
2
1 9
10 1
17
3527
2
1 9
10 2
18
3838
2
0 9
11 1
18
3839
2
0 9
11 2
12
13
2302
2
5 10
6 1
13
2303
2
5 10
6 2
14
2614
2
4 10
7 1
14
2615
2
4 10
7 2
15
2926
2
3 10
8 1
15
2927
2
3 10
8 2
16
3238
2
2 10
9 1
16
3239
2
2 10
9 2
17
3550
2
1 10
10 1
17
3551
2
1 10
10 2
18
3862
2
0 10
11 1
18
3863
2
0 10
11 2
12
13
2326
2
5 11
6 1
13
2327
2
5 11
6 2
14
2638
2
4 11
7 1
14
2639
2
4 11
7 2
15
2950
2
3 11
8 1
15
2951
2
3 11
8 2
16
3262
2
2 11
9 1
16
3263
2
2 11
9 2
17
3574
2
1 11
10 1
17
3575
2
1 11
10 2
18
3886
2
0 11
11 1
18
3887
2
0 11
11 2
12
13
2350
2
5 12
6 1
13
2351
2
5 12
6 2
14
2662
2
4 12
7 1
14
2663
2
4 12
7 2
15
2974
2
3 12
8 1
15
2975
2
3 12
8 2
16
3286
2
2 12
9 1
16
3287
2
2 12
9 2
17
3598
2
1 12
10 1
17
3599
2
1 12
10 2
18
3910
2
0 12
11 1
18
3911
2
0 12
11 2
26
0
191
2
5 0
6 1
0
190
2
5 0
6 0
1
214
2
5 1
6 0
1
215
2
5 1
6 1
2
238
2
5 2
6 0
2
239
2
5 2
6 1
3
262
2
5 3
6 0
3
263
2
5 3
6 1
4
286
2
5 4
6 0
4
287
2
5 4
6 1
5
310
2
5 5
6 0
5
311
2
5 5
6 1
6
335
2
5 6
6 1
6
334
2
5 6
6 0
7
358
2
5 7
6 0
7
359
2
5 7
6 1
8
382
2
5 8
6 0
8
383
2
5 8
6 1
9
406
2
5 9
6 0
9
407
2
5 9
6 1
10
430
2
5 10
6 0
10
431
2
5 10
6 1
11
454
2
5 11
6 0
11
455
2
5 11
6 1
12
478
2
5 12
6 0
12
479
2
5 12
6 1
26
0
503
2
4 0
7 1
0
502
2
4 0
7 0
1
526
2
4 1
7 0
1
527
2
4 1
7 1
2
550
2
4 2
7 0
2
551
2
4 2
7 1
3
574
2
4 3
7 0
3
575
2
4 3
7 1
4
598
2
4 4
7 0
4
599
2
4 4
7 1
5
622
2
4 5
7 0
5
623
2
4 5
7 1
6
647
2
4 6
7 1
6
646
2
4 6
7 0
7
670
2
4 7
7 0
7
671
2
4 7
7 1
8
694
2
4 8
7 0
8
695
2
4 8
7 1
9
718
2
4 9
7 0
9
719
2
4 9
7 1
10
742
2
4 10
7 0
10
743
2
4 10
7 1
11
766
2
4 11
7 0
11
767
2
4 11
7 1
12
790
2
4 12
7 0
12
791
2
4 12
7 1
26
0
815
2
3 0
8 1
0
814
2
3 0
8 0
1
838
2
3 1
8 0
1
839
2
3 1
8 1
2
862
2
3 2
8 0
2
863
2
3 2
8 1
3
886
2
3 3
8 0
3
887
2
3 3
8 1
4
910
2
3 4
8 0
4
911
2
3 4
8 1
5
934
2
3 5
8 0
5
935
2
3 5
8 1
6
959
2
3 6
8 1
6
958
2
3 6
8 0
7
982
2
3 7
8 0
7
983
2
3 7
8 1
8
1006
2
3 8
8 0
8
1007
2
3 8
8 1
9
1030
2
3 9
8 0
9
1031
2
3 9
8 1
10
1054
2
3 10
8 0
10
1055
2
3 10
8 1
11
1078
2
3 11
8 0
11
1079
2
3 11
8 1
12
1102
2
3 12
8 0
12
1103
2
3 12
8 1
26
0
1127
2
2 0
9 1
0
1126
2
2 0
9 0
1
1150
2
2 1
9 0
1
1151
2
2 1
9 1
2
1174
2
2 2
9 0
2
1175
2
2 2
9 1
3
1198
2
2 3
9 0
3
1199
2
2 3
9 1
4
1222
2
2 4
9 0
4
1223
2
2 4
9 1
5
1246
2
2 5
9 0
5
1247
2
2 5
9 1
6
1271
2
2 6
9 1
6
1270
2
2 6
9 0
7
1294
2
2 7
9 0
7
1295
2
2 7
9 1
8
1318
2
2 8
9 0
8
1319
2
2 8
9 1
9
1342
2
2 9
9 0
9
1343
2
2 9
9 1
10
1366
2
2 10
9 0
10
1367
2
2 10
9 1
11
1390
2
2 11
9 0
11
1391
2
2 11
9 1
12
1414
2
2 12
9 0
12
1415
2
2 12
9 1
26
0
1439
2
1 0
10 1
0
1438
2
1 0
10 0
1
1462
2
1 1
10 0
1
1463
2
1 1
10 1
2
1486
2
1 2
10 0
2
1487
2
1 2
10 1
3
1510
2
1 3
10 0
3
1511
2
1 3
10 1
4
1534
2
1 4
10 0
4
1535
2
1 4
10 1
5
1558
2
1 5
10 0
5
1559
2
1 5
10 1
6
1583
2
1 6
10 1
6
1582
2
1 6
10 0
7
1606
2
1 7
10 0
7
1607
2
1 7
10 1
8
1630
2
1 8
10 0
8
1631
2
1 8
10 1
9
1654
2
1 9
10 0
9
1655
2
1 9
10 1
10
1678
2
1 10
10 0
10
1679
2
1 10
10 1
11
1702
2
1 11
10 0
11
1703
2
1 11
10 1
12
1726
2
1 12
10 0
12
1727
2
1 12
10 1
26
0
1751
2
0 0
11 1
0
1750
2
0 0
11 0
1
1774
2
0 1
11 0
1
1775
2
0 1
11 1
2
1798
2
0 2
11 0
2
1799
2
0 2
11 1
3
1822
2
0 3
11 0
3
1823
2
0 3
11 1
4
1846
2
0 4
11 0
4
1847
2
0 4
11 1
5
1870
2
0 5
11 0
5
1871
2
0 5
11 1
6
1895
2
0 6
11 1
6
1894
2
0 6
11 0
7
1918
2
0 7
11 0
7
1919
2
0 7
11 1
8
1942
2
0 8
11 0
8
1943
2
0 8
11 1
9
1966
2
0 9
11 0
9
1967
2
0 9
11 1
10
1990
2
0 10
11 0
10
1991
2
0 10
11 1
11
2014
2
0 11
11 0
11
2015
2
0 11
11 1
12
2038
2
0 12
11 0
12
2039
2
0 12
11 1
end_DTG
begin_CG
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
11 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
10 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
9 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
8 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
7 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
6 624
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
end_CG
