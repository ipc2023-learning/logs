begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var18
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var13
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var19
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l14)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3531
2
4 11
7 2
16
3894
2
3 11
8 1
16
3895
2
3 11
8 2
17
4258
2
2 11
9 1
17
4259
2
2 11
9 2
18
4622
2
1 11
10 1
18
4623
2
1 11
10 2
19
4986
2
0 11
11 1
19
4987
2
0 11
11 2
12
14
3192
2
5 12
6 1
14
3193
2
5 12
6 2
15
3556
2
4 12
7 1
15
3557
2
4 12
7 2
16
3920
2
3 12
8 1
16
3921
2
3 12
8 2
17
4284
2
2 12
9 1
17
4285
2
2 12
9 2
18
4648
2
1 12
10 1
18
4649
2
1 12
10 2
19
5012
2
0 12
11 1
19
5013
2
0 12
11 2
12
14
3218
2
5 13
6 1
14
3219
2
5 13
6 2
15
3582
2
4 13
7 1
15
3583
2
4 13
7 2
16
3946
2
3 13
8 1
16
3947
2
3 13
8 2
17
4310
2
2 13
9 1
17
4311
2
2 13
9 2
18
4674
2
1 13
10 1
18
4675
2
1 13
10 2
19
5038
2
0 13
11 1
19
5039
2
0 13
11 2
28
0
697
2
5 0
6 1
0
696
2
5 0
6 0
1
722
2
5 1
6 0
1
723
2
5 1
6 1
2
748
2
5 2
6 0
2
749
2
5 2
6 1
3
774
2
5 3
6 0
3
775
2
5 3
6 1
4
800
2
5 4
6 0
4
801
2
5 4
6 1
5
826
2
5 5
6 0
5
827
2
5 5
6 1
6
852
2
5 6
6 0
6
853
2
5 6
6 1
7
878
2
5 7
6 0
7
879
2
5 7
6 1
8
904
2
5 8
6 0
8
905
2
5 8
6 1
9
930
2
5 9
6 0
9
931
2
5 9
6 1
10
956
2
5 10
6 0
10
957
2
5 10
6 1
11
982
2
5 11
6 0
11
983
2
5 11
6 1
12
1008
2
5 12
6 0
12
1009
2
5 12
6 1
13
1034
2
5 13
6 0
13
1035
2
5 13
6 1
28
0
1061
2
4 0
7 1
0
1060
2
4 0
7 0
1
1086
2
4 1
7 0
1
1087
2
4 1
7 1
2
1112
2
4 2
7 0
2
1113
2
4 2
7 1
3
1138
2
4 3
7 0
3
1139
2
4 3
7 1
4
1164
2
4 4
7 0
4
1165
2
4 4
7 1
5
1190
2
4 5
7 0
5
1191
2
4 5
7 1
6
1216
2
4 6
7 0
6
1217
2
4 6
7 1
7
1242
2
4 7
7 0
7
1243
2
4 7
7 1
8
1268
2
4 8
7 0
8
1269
2
4 8
7 1
9
1294
2
4 9
7 0
9
1295
2
4 9
7 1
10
1320
2
4 10
7 0
10
1321
2
4 10
7 1
11
1346
2
4 11
7 0
11
1347
2
4 11
7 1
12
1372
2
4 12
7 0
12
1373
2
4 12
7 1
13
1398
2
4 13
7 0
13
1399
2
4 13
7 1
28
0
1425
2
3 0
8 1
0
1424
2
3 0
8 0
1
1450
2
3 1
8 0
1
1451
2
3 1
8 1
2
1476
2
3 2
8 0
2
1477
2
3 2
8 1
3
1502
2
3 3
8 0
3
1503
2
3 3
8 1
4
1528
2
3 4
8 0
4
1529
2
3 4
8 1
5
1554
2
3 5
8 0
5
1555
2
3 5
8 1
6
1580
2
3 6
8 0
6
1581
2
3 6
8 1
7
1606
2
3 7
8 0
7
1607
2
3 7
8 1
8
1632
2
3 8
8 0
8
1633
2
3 8
8 1
9
1658
2
3 9
8 0
9
1659
2
3 9
8 1
10
1684
2
3 10
8 0
10
1685
2
3 10
8 1
11
1710
2
3 11
8 0
11
1711
2
3 11
8 1
12
1736
2
3 12
8 0
12
1737
2
3 12
8 1
13
1762
2
3 13
8 0
13
1763
2
3 13
8 1
28
0
1789
2
2 0
9 1
0
1788
2
2 0
9 0
1
1814
2
2 1
9 0
1
1815
2
2 1
9 1
2
1840
2
2 2
9 0
2
1841
2
2 2
9 1
3
1866
2
2 3
9 0
3
1867
2
2 3
9 1
4
1892
2
2 4
9 0
4
1893
2
2 4
9 1
5
1918
2
2 5
9 0
5
1919
2
2 5
9 1
6
1944
2
2 6
9 0
6
1945
2
2 6
9 1
7
1970
2
2 7
9 0
7
1971
2
2 7
9 1
8
1996
2
2 8
9 0
8
1997
2
2 8
9 1
9
2022
2
2 9
9 0
9
2023
2
2 9
9 1
10
2048
2
2 10
9 0
10
2049
2
2 10
9 1
11
2074
2
2 11
9 0
11
2075
2
2 11
9 1
12
2100
2
2 12
9 0
12
2101
2
2 12
9 1
13
2126
2
2 13
9 0
13
2127
2
2 13
9 1
28
0
2153
2
1 0
10 1
0
2152
2
1 0
10 0
1
2178
2
1 1
10 0
1
2179
2
1 1
10 1
2
2204
2
1 2
10 0
2
2205
2
1 2
10 1
3
2230
2
1 3
10 0
3
2231
2
1 3
10 1
4
2256
2
1 4
10 0
4
2257
2
1 4
10 1
5
2282
2
1 5
10 0
5
2283
2
1 5
10 1
6
2308
2
1 6
10 0
6
2309
2
1 6
10 1
7
2334
2
1 7
10 0
7
2335
2
1 7
10 1
8
2360
2
1 8
10 0
8
2361
2
1 8
10 1
9
2386
2
1 9
10 0
9
2387
2
1 9
10 1
10
2412
2
1 10
10 0
10
2413
2
1 10
10 1
11
2438
2
1 11
10 0
11
2439
2
1 11
10 1
12
2464
2
1 12
10 0
12
2465
2
1 12
10 1
13
2490
2
1 13
10 0
13
2491
2
1 13
10 1
28
0
2517
2
0 0
11 1
0
2516
2
0 0
11 0
1
2542
2
0 1
11 0
1
2543
2
0 1
11 1
2
2568
2
0 2
11 0
2
2569
2
0 2
11 1
3
2594
2
0 3
11 0
3
2595
2
0 3
11 1
4
2620
2
0 4
11 0
4
2621
2
0 4
11 1
5
2646
2
0 5
11 0
5
2647
2
0 5
11 1
6
2672
2
0 6
11 0
6
2673
2
0 6
11 1
7
2698
2
0 7
11 0
7
2699
2
0 7
11 1
8
2724
2
0 8
11 0
8
2725
2
0 8
11 1
9
2750
2
0 9
11 0
9
2751
2
0 9
11 1
10
2776
2
0 10
11 0
10
2777
2
0 10
11 1
11
2802
2
0 11
11 0
11
2803
2
0 11
11 1
12
2828
2
0 12
11 0
12
2829
2
0 12
11 1
13
2854
2
0 13
11 0
13
2855
2
0 13
11 1
end_DTG
begin_CG
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
11 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
10 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
9 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
8 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
7 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6 728
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
