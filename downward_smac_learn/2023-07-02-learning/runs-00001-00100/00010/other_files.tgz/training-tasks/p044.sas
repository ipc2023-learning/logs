begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var11
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var10
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var8
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var12
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
14
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
14
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
14
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
14
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
14
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
14
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
14
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
begin_variable
var7
-1
14
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
end_variable
0
begin_state
1
1
1
4
1
1
2
1
4
8
6
1
4
7
9
9
end_state
begin_goal
8
8 6
9 4
10 3
11 0
12 6
13 9
14 3
15 3
end_goal
1432
begin_operator
drive v1 l1 l10
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 3 0 9
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l10 l3
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l10 l7
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l10 l8
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l10 l9
0
1
0 3 1 9
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 2 9
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l3 l10
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l3 l9
0
1
0 3 3 9
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 6 5
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 6 8
0
end_operator
begin_operator
drive v1 l6 l9
0
1
0 3 6 9
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 7 0
0
end_operator
begin




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1 6
6 2
13
1380
2
0 6
7 1
13
1381
2
0 6
7 2
8
10
916
2
3 7
4 1
10
917
2
3 7
4 2
11
1076
2
2 7
5 1
11
1077
2
2 7
5 2
12
1236
2
1 7
6 1
12
1237
2
1 7
6 2
13
1396
2
0 7
7 1
13
1397
2
0 7
7 2
8
10
932
2
3 8
4 1
10
933
2
3 8
4 2
11
1092
2
2 8
5 1
11
1093
2
2 8
5 2
12
1252
2
1 8
6 1
12
1253
2
1 8
6 2
13
1412
2
0 8
7 1
13
1413
2
0 8
7 2
8
10
948
2
3 9
4 1
10
949
2
3 9
4 2
11
1108
2
2 9
5 1
11
1109
2
2 9
5 2
12
1268
2
1 9
6 1
12
1269
2
1 9
6 2
13
1428
2
0 9
7 1
13
1429
2
0 9
7 2
20
0
165
2
3 0
4 1
0
164
2
3 0
4 0
1
180
2
3 1
4 0
1
181
2
3 1
4 1
2
196
2
3 2
4 0
2
197
2
3 2
4 1
3
212
2
3 3
4 0
3
213
2
3 3
4 1
4
228
2
3 4
4 0
4
229
2
3 4
4 1
5
244
2
3 5
4 0
5
245
2
3 5
4 1
6
260
2
3 6
4 0
6
261
2
3 6
4 1
7
276
2
3 7
4 0
7
277
2
3 7
4 1
8
292
2
3 8
4 0
8
293
2
3 8
4 1
9
308
2
3 9
4 0
9
309
2
3 9
4 1
20
0
325
2
2 0
5 1
0
324
2
2 0
5 0
1
340
2
2 1
5 0
1
341
2
2 1
5 1
2
356
2
2 2
5 0
2
357
2
2 2
5 1
3
372
2
2 3
5 0
3
373
2
2 3
5 1
4
388
2
2 4
5 0
4
389
2
2 4
5 1
5
404
2
2 5
5 0
5
405
2
2 5
5 1
6
420
2
2 6
5 0
6
421
2
2 6
5 1
7
436
2
2 7
5 0
7
437
2
2 7
5 1
8
452
2
2 8
5 0
8
453
2
2 8
5 1
9
468
2
2 9
5 0
9
469
2
2 9
5 1
20
0
485
2
1 0
6 1
0
484
2
1 0
6 0
1
500
2
1 1
6 0
1
501
2
1 1
6 1
2
516
2
1 2
6 0
2
517
2
1 2
6 1
3
532
2
1 3
6 0
3
533
2
1 3
6 1
4
548
2
1 4
6 0
4
549
2
1 4
6 1
5
564
2
1 5
6 0
5
565
2
1 5
6 1
6
580
2
1 6
6 0
6
581
2
1 6
6 1
7
596
2
1 7
6 0
7
597
2
1 7
6 1
8
612
2
1 8
6 0
8
613
2
1 8
6 1
9
628
2
1 9
6 0
9
629
2
1 9
6 1
20
0
645
2
0 0
7 1
0
644
2
0 0
7 0
1
660
2
0 1
7 0
1
661
2
0 1
7 1
2
676
2
0 2
7 0
2
677
2
0 2
7 1
3
692
2
0 3
7 0
3
693
2
0 3
7 1
4
708
2
0 4
7 0
4
709
2
0 4
7 1
5
724
2
0 5
7 0
5
725
2
0 5
7 1
6
740
2
0 6
7 0
6
741
2
0 6
7 1
7
756
2
0 7
7 0
7
757
2
0 7
7 1
8
772
2
0 8
7 0
8
773
2
0 8
7 1
9
788
2
0 9
7 0
9
789
2
0 9
7 1
end_DTG
begin_DTG
8
10
806
2
3 0
4 1
10
807
2
3 0
4 2
11
966
2
2 0
5 1
11
967
2
2 0
5 2
12
1126
2
1 0
6 1
12
1127
2
1 0
6 2
13
1286
2
0 0
7 1
13
1287
2
0 0
7 2
8
10
822
2
3 1
4 1
10
823
2
3 1
4 2
11
982
2
2 1
5 1
11
983
2
2 1
5 2
12
1142
2
1 1
6 1
12
1143
2
1 1
6 2
13
1302
2
0 1
7 1
13
1303
2
0 1
7 2
8
10
838
2
3 2
4 1
10
839
2
3 2
4 2
11
998
2
2 2
5 1
11
999
2
2 2
5 2
12
1158
2
1 2
6 1
12
1159
2
1 2
6 2
13
1318
2
0 2
7 1
13
1319
2
0 2
7 2
8
10
854
2
3 3
4 1
10
855
2
3 3
4 2
11
1014
2
2 3
5 1
11
1015
2
2 3
5 2
12
1174
2
1 3
6 1
12
1175
2
1 3
6 2
13
1334
2
0 3
7 1
13
1335
2
0 3
7 2
8
10
870
2
3 4
4 1
10
871
2
3 4
4 2
11
1030
2
2 4
5 1
11
1031
2
2 4
5 2
12
1190
2
1 4
6 1
12
1191
2
1 4
6 2
13
1350
2
0 4
7 1
13
1351
2
0 4
7 2
8
10
886
2
3 5
4 1
10
887
2
3 5
4 2
11
1046
2
2 5
5 1
11
1047
2
2 5
5 2
12
1206
2
1 5
6 1
12
1207
2
1 5
6 2
13
1366
2
0 5
7 1
13
1367
2
0 5
7 2
8
10
902
2
3 6
4 1
10
903
2
3 6
4 2
11
1062
2
2 6
5 1
11
1063
2
2 6
5 2
12
1222
2
1 6
6 1
12
1223
2
1 6
6 2
13
1382
2
0 6
7 1
13
1383
2
0 6
7 2
8
10
918
2
3 7
4 1
10
919
2
3 7
4 2
11
1078
2
2 7
5 1
11
1079
2
2 7
5 2
12
1238
2
1 7
6 1
12
1239
2
1 7
6 2
13
1398
2
0 7
7 1
13
1399
2
0 7
7 2
8
10
934
2
3 8
4 1
10
935
2
3 8
4 2
11
1094
2
2 8
5 1
11
1095
2
2 8
5 2
12
1254
2
1 8
6 1
12
1255
2
1 8
6 2
13
1414
2
0 8
7 1
13
1415
2
0 8
7 2
8
10
950
2
3 9
4 1
10
951
2
3 9
4 2
11
1110
2
2 9
5 1
11
1111
2
2 9
5 2
12
1270
2
1 9
6 1
12
1271
2
1 9
6 2
13
1430
2
0 9
7 1
13
1431
2
0 9
7 2
20
0
167
2
3 0
4 1
0
166
2
3 0
4 0
1
182
2
3 1
4 0
1
183
2
3 1
4 1
2
198
2
3 2
4 0
2
199
2
3 2
4 1
3
214
2
3 3
4 0
3
215
2
3 3
4 1
4
230
2
3 4
4 0
4
231
2
3 4
4 1
5
246
2
3 5
4 0
5
247
2
3 5
4 1
6
262
2
3 6
4 0
6
263
2
3 6
4 1
7
278
2
3 7
4 0
7
279
2
3 7
4 1
8
294
2
3 8
4 0
8
295
2
3 8
4 1
9
310
2
3 9
4 0
9
311
2
3 9
4 1
20
0
327
2
2 0
5 1
0
326
2
2 0
5 0
1
342
2
2 1
5 0
1
343
2
2 1
5 1
2
358
2
2 2
5 0
2
359
2
2 2
5 1
3
374
2
2 3
5 0
3
375
2
2 3
5 1
4
390
2
2 4
5 0
4
391
2
2 4
5 1
5
406
2
2 5
5 0
5
407
2
2 5
5 1
6
422
2
2 6
5 0
6
423
2
2 6
5 1
7
438
2
2 7
5 0
7
439
2
2 7
5 1
8
454
2
2 8
5 0
8
455
2
2 8
5 1
9
470
2
2 9
5 0
9
471
2
2 9
5 1
20
0
487
2
1 0
6 1
0
486
2
1 0
6 0
1
502
2
1 1
6 0
1
503
2
1 1
6 1
2
518
2
1 2
6 0
2
519
2
1 2
6 1
3
534
2
1 3
6 0
3
535
2
1 3
6 1
4
550
2
1 4
6 0
4
551
2
1 4
6 1
5
566
2
1 5
6 0
5
567
2
1 5
6 1
6
582
2
1 6
6 0
6
583
2
1 6
6 1
7
598
2
1 7
6 0
7
599
2
1 7
6 1
8
614
2
1 8
6 0
8
615
2
1 8
6 1
9
630
2
1 9
6 0
9
631
2
1 9
6 1
20
0
647
2
0 0
7 1
0
646
2
0 0
7 0
1
662
2
0 1
7 0
1
663
2
0 1
7 1
2
678
2
0 2
7 0
2
679
2
0 2
7 1
3
694
2
0 3
7 0
3
695
2
0 3
7 1
4
710
2
0 4
7 0
4
711
2
0 4
7 1
5
726
2
0 5
7 0
5
727
2
0 5
7 1
6
742
2
0 6
7 0
6
743
2
0 6
7 1
7
758
2
0 7
7 0
7
759
2
0 7
7 1
8
774
2
0 8
7 0
8
775
2
0 8
7 1
9
790
2
0 9
7 0
9
791
2
0 9
7 1
end_DTG
begin_CG
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
7 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
6 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
5 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
4 320
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
end_CG
