begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var15
-1
12
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var14
-1
12
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var13
-1
12
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var12
-1
12
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var11
-1
12
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var16
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
17
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
17
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
17
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
end_variable
begin_variable
var3
-1
17
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var4
-1
17
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var5
-1
17
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var6
-1
17
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var7
-1
17
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var8
-1
17
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var9
-1
17
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var10
-1
17
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l12)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
9 2
10
12
1732
2
4 1
5 1
12
1733
2
4 1
5 2
13
1996
2
3 1
6 1
13
1997
2
3 1
6 2
14
2260
2
2 1
7 1
14
2261
2
2 1
7 2
15
2524
2
1 1
8 1
15
2525
2
1 1
8 2
16
2788
2
0 1
9 1
16
2789
2
0 1
9 2
10
12
1754
2
4 2
5 1
12
1755
2
4 2
5 2
13
2018
2
3 2
6 1
13
2019
2
3 2
6 2
14
2282
2
2 2
7 1
14
2283
2
2 2
7 2
15
2546
2
1 2
8 1
15
2547
2
1 2
8 2
16
2810
2
0 2
9 1
16
2811
2
0 2
9 2
10
12
1776
2
4 3
5 1
12
1777
2
4 3
5 2
13
2040
2
3 3
6 1
13
2041
2
3 3
6 2
14
2304
2
2 3
7 1
14
2305
2
2 3
7 2
15
2568
2
1 3
8 1
15
2569
2
1 3
8 2
16
2832
2
0 3
9 1
16
2833
2
0 3
9 2
10
12
1798
2
4 4
5 1
12
1799
2
4 4
5 2
13
2062
2
3 4
6 1
13
2063
2
3 4
6 2
14
2326
2
2 4
7 1
14
2327
2
2 4
7 2
15
2590
2
1 4
8 1
15
2591
2
1 4
8 2
16
2854
2
0 4
9 1
16
2855
2
0 4
9 2
10
12
1820
2
4 5
5 1
12
1821
2
4 5
5 2
13
2084
2
3 5
6 1
13
2085
2
3 5
6 2
14
2348
2
2 5
7 1
14
2349
2
2 5
7 2
15
2612
2
1 5
8 1
15
2613
2
1 5
8 2
16
2876
2
0 5
9 1
16
2877
2
0 5
9 2
10
12
1842
2
4 6
5 1
12
1843
2
4 6
5 2
13
2106
2
3 6
6 1
13
2107
2
3 6
6 2
14
2370
2
2 6
7 1
14
2371
2
2 6
7 2
15
2634
2
1 6
8 1
15
2635
2
1 6
8 2
16
2898
2
0 6
9 1
16
2899
2
0 6
9 2
10
12
1864
2
4 7
5 1
12
1865
2
4 7
5 2
13
2128
2
3 7
6 1
13
2129
2
3 7
6 2
14
2392
2
2 7
7 1
14
2393
2
2 7
7 2
15
2656
2
1 7
8 1
15
2657
2
1 7
8 2
16
2920
2
0 7
9 1
16
2921
2
0 7
9 2
10
12
1886
2
4 8
5 1
12
1887
2
4 8
5 2
13
2150
2
3 8
6 1
13
2151
2
3 8
6 2
14
2414
2
2 8
7 1
14
2415
2
2 8
7 2
15
2678
2
1 8
8 1
15
2679
2
1 8
8 2
16
2942
2
0 8
9 1
16
2943
2
0 8
9 2
10
12
1908
2
4 9
5 1
12
1909
2
4 9
5 2
13
2172
2
3 9
6 1
13
2173
2
3 9
6 2
14
2436
2
2 9
7 1
14
2437
2
2 9
7 2
15
2700
2
1 9
8 1
15
2701
2
1 9
8 2
16
2964
2
0 9
9 1
16
2965
2
0 9
9 2
10
12
1930
2
4 10
5 1
12
1931
2
4 10
5 2
13
2194
2
3 10
6 1
13
2195
2
3 10
6 2
14
2458
2
2 10
7 1
14
2459
2
2 10
7 2
15
2722
2
1 10
8 1
15
2723
2
1 10
8 2
16
2986
2
0 10
9 1
16
2987
2
0 10
9 2
10
12
1952
2
4 11
5 1
12
1953
2
4 11
5 2
13
2216
2
3 11
6 1
13
2217
2
3 11
6 2
14
2480
2
2 11
7 1
14
2481
2
2 11
7 2
15
2744
2
1 11
8 1
15
2745
2
1 11
8 2
16
3008
2
0 11
9 1
16
3009
2
0 11
9 2
24
0
391
2
4 0
5 1
0
390
2
4 0
5 0
1
412
2
4 1
5 0
1
413
2
4 1
5 1
2
434
2
4 2
5 0
2
435
2
4 2
5 1
3
456
2
4 3
5 0
3
457
2
4 3
5 1
4
478
2
4 4
5 0
4
479
2
4 4
5 1
5
500
2
4 5
5 0
5
501
2
4 5
5 1
6
522
2
4 6
5 0
6
523
2
4 6
5 1
7
544
2
4 7
5 0
7
545
2
4 7
5 1
8
566
2
4 8
5 0
8
567
2
4 8
5 1
9
588
2
4 9
5 0
9
589
2
4 9
5 1
10
610
2
4 10
5 0
10
611
2
4 10
5 1
11
632
2
4 11
5 0
11
633
2
4 11
5 1
24
0
655
2
3 0
6 1
0
654
2
3 0
6 0
1
676
2
3 1
6 0
1
677
2
3 1
6 1
2
698
2
3 2
6 0
2
699
2
3 2
6 1
3
720
2
3 3
6 0
3
721
2
3 3
6 1
4
742
2
3 4
6 0
4
743
2
3 4
6 1
5
764
2
3 5
6 0
5
765
2
3 5
6 1
6
786
2
3 6
6 0
6
787
2
3 6
6 1
7
808
2
3 7
6 0
7
809
2
3 7
6 1
8
830
2
3 8
6 0
8
831
2
3 8
6 1
9
852
2
3 9
6 0
9
853
2
3 9
6 1
10
874
2
3 10
6 0
10
875
2
3 10
6 1
11
896
2
3 11
6 0
11
897
2
3 11
6 1
24
0
919
2
2 0
7 1
0
918
2
2 0
7 0
1
940
2
2 1
7 0
1
941
2
2 1
7 1
2
962
2
2 2
7 0
2
963
2
2 2
7 1
3
984
2
2 3
7 0
3
985
2
2 3
7 1
4
1006
2
2 4
7 0
4
1007
2
2 4
7 1
5
1028
2
2 5
7 0
5
1029
2
2 5
7 1
6
1050
2
2 6
7 0
6
1051
2
2 6
7 1
7
1072
2
2 7
7 0
7
1073
2
2 7
7 1
8
1094
2
2 8
7 0
8
1095
2
2 8
7 1
9
1116
2
2 9
7 0
9
1117
2
2 9
7 1
10
1138
2
2 10
7 0
10
1139
2
2 10
7 1
11
1160
2
2 11
7 0
11
1161
2
2 11
7 1
24
0
1183
2
1 0
8 1
0
1182
2
1 0
8 0
1
1204
2
1 1
8 0
1
1205
2
1 1
8 1
2
1226
2
1 2
8 0
2
1227
2
1 2
8 1
3
1248
2
1 3
8 0
3
1249
2
1 3
8 1
4
1270
2
1 4
8 0
4
1271
2
1 4
8 1
5
1292
2
1 5
8 0
5
1293
2
1 5
8 1
6
1314
2
1 6
8 0
6
1315
2
1 6
8 1
7
1336
2
1 7
8 0
7
1337
2
1 7
8 1
8
1358
2
1 8
8 0
8
1359
2
1 8
8 1
9
1380
2
1 9
8 0
9
1381
2
1 9
8 1
10
1402
2
1 10
8 0
10
1403
2
1 10
8 1
11
1424
2
1 11
8 0
11
1425
2
1 11
8 1
24
0
1447
2
0 0
9 1
0
1446
2
0 0
9 0
1
1468
2
0 1
9 0
1
1469
2
0 1
9 1
2
1490
2
0 2
9 0
2
1491
2
0 2
9 1
3
1512
2
0 3
9 0
3
1513
2
0 3
9 1
4
1534
2
0 4
9 0
4
1535
2
0 4
9 1
5
1556
2
0 5
9 0
5
1557
2
0 5
9 1
6
1578
2
0 6
9 0
6
1579
2
0 6
9 1
7
1600
2
0 7
9 0
7
1601
2
0 7
9 1
8
1622
2
0 8
9 0
8
1623
2
0 8
9 1
9
1644
2
0 9
9 0
9
1645
2
0 9
9 1
10
1666
2
0 10
9 0
10
1667
2
0 10
9 1
11
1688
2
0 11
9 0
11
1689
2
0 11
9 1
end_DTG
begin_CG
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
9 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
8 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
7 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
6 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5 528
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
end_CG
