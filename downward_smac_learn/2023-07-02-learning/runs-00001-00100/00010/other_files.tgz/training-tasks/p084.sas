begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var19
-1
15
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var18
-1
15
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var17
-1
15
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var16
-1
15
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var15
-1
15
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var14
-1
15
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var20
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
21
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
21
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
21
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
21
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
21
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
21
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l15)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
21
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l15)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
5106
2
1 13
10 1
19
5107
2
1 13
10 2
20
5526
2
0 13
11 1
20
5527
2
0 13
11 2
12
15
3454
2
5 14
6 1
15
3455
2
5 14
6 2
16
3874
2
4 14
7 1
16
3875
2
4 14
7 2
17
4294
2
3 14
8 1
17
4295
2
3 14
8 2
18
4714
2
2 14
9 1
18
4715
2
2 14
9 2
19
5134
2
1 14
10 1
19
5135
2
1 14
10 2
20
5554
2
0 14
11 1
20
5555
2
0 14
11 2
30
0
543
2
5 0
6 1
0
542
2
5 0
6 0
1
570
2
5 1
6 0
1
571
2
5 1
6 1
2
598
2
5 2
6 0
2
599
2
5 2
6 1
3
626
2
5 3
6 0
3
627
2
5 3
6 1
4
654
2
5 4
6 0
4
655
2
5 4
6 1
5
682
2
5 5
6 0
5
683
2
5 5
6 1
6
710
2
5 6
6 0
6
711
2
5 6
6 1
7
739
2
5 7
6 1
7
738
2
5 7
6 0
8
766
2
5 8
6 0
8
767
2
5 8
6 1
9
794
2
5 9
6 0
9
795
2
5 9
6 1
10
822
2
5 10
6 0
10
823
2
5 10
6 1
11
850
2
5 11
6 0
11
851
2
5 11
6 1
12
878
2
5 12
6 0
12
879
2
5 12
6 1
13
906
2
5 13
6 0
13
907
2
5 13
6 1
14
934
2
5 14
6 0
14
935
2
5 14
6 1
30
0
963
2
4 0
7 1
0
962
2
4 0
7 0
1
990
2
4 1
7 0
1
991
2
4 1
7 1
2
1018
2
4 2
7 0
2
1019
2
4 2
7 1
3
1046
2
4 3
7 0
3
1047
2
4 3
7 1
4
1074
2
4 4
7 0
4
1075
2
4 4
7 1
5
1102
2
4 5
7 0
5
1103
2
4 5
7 1
6
1130
2
4 6
7 0
6
1131
2
4 6
7 1
7
1159
2
4 7
7 1
7
1158
2
4 7
7 0
8
1186
2
4 8
7 0
8
1187
2
4 8
7 1
9
1214
2
4 9
7 0
9
1215
2
4 9
7 1
10
1242
2
4 10
7 0
10
1243
2
4 10
7 1
11
1270
2
4 11
7 0
11
1271
2
4 11
7 1
12
1298
2
4 12
7 0
12
1299
2
4 12
7 1
13
1326
2
4 13
7 0
13
1327
2
4 13
7 1
14
1354
2
4 14
7 0
14
1355
2
4 14
7 1
30
0
1383
2
3 0
8 1
0
1382
2
3 0
8 0
1
1410
2
3 1
8 0
1
1411
2
3 1
8 1
2
1438
2
3 2
8 0
2
1439
2
3 2
8 1
3
1466
2
3 3
8 0
3
1467
2
3 3
8 1
4
1494
2
3 4
8 0
4
1495
2
3 4
8 1
5
1522
2
3 5
8 0
5
1523
2
3 5
8 1
6
1550
2
3 6
8 0
6
1551
2
3 6
8 1
7
1579
2
3 7
8 1
7
1578
2
3 7
8 0
8
1606
2
3 8
8 0
8
1607
2
3 8
8 1
9
1634
2
3 9
8 0
9
1635
2
3 9
8 1
10
1662
2
3 10
8 0
10
1663
2
3 10
8 1
11
1690
2
3 11
8 0
11
1691
2
3 11
8 1
12
1718
2
3 12
8 0
12
1719
2
3 12
8 1
13
1746
2
3 13
8 0
13
1747
2
3 13
8 1
14
1774
2
3 14
8 0
14
1775
2
3 14
8 1
30
0
1803
2
2 0
9 1
0
1802
2
2 0
9 0
1
1830
2
2 1
9 0
1
1831
2
2 1
9 1
2
1858
2
2 2
9 0
2
1859
2
2 2
9 1
3
1886
2
2 3
9 0
3
1887
2
2 3
9 1
4
1914
2
2 4
9 0
4
1915
2
2 4
9 1
5
1942
2
2 5
9 0
5
1943
2
2 5
9 1
6
1970
2
2 6
9 0
6
1971
2
2 6
9 1
7
1999
2
2 7
9 1
7
1998
2
2 7
9 0
8
2026
2
2 8
9 0
8
2027
2
2 8
9 1
9
2054
2
2 9
9 0
9
2055
2
2 9
9 1
10
2082
2
2 10
9 0
10
2083
2
2 10
9 1
11
2110
2
2 11
9 0
11
2111
2
2 11
9 1
12
2138
2
2 12
9 0
12
2139
2
2 12
9 1
13
2166
2
2 13
9 0
13
2167
2
2 13
9 1
14
2194
2
2 14
9 0
14
2195
2
2 14
9 1
30
0
2223
2
1 0
10 1
0
2222
2
1 0
10 0
1
2250
2
1 1
10 0
1
2251
2
1 1
10 1
2
2278
2
1 2
10 0
2
2279
2
1 2
10 1
3
2306
2
1 3
10 0
3
2307
2
1 3
10 1
4
2334
2
1 4
10 0
4
2335
2
1 4
10 1
5
2362
2
1 5
10 0
5
2363
2
1 5
10 1
6
2390
2
1 6
10 0
6
2391
2
1 6
10 1
7
2419
2
1 7
10 1
7
2418
2
1 7
10 0
8
2446
2
1 8
10 0
8
2447
2
1 8
10 1
9
2474
2
1 9
10 0
9
2475
2
1 9
10 1
10
2502
2
1 10
10 0
10
2503
2
1 10
10 1
11
2530
2
1 11
10 0
11
2531
2
1 11
10 1
12
2558
2
1 12
10 0
12
2559
2
1 12
10 1
13
2586
2
1 13
10 0
13
2587
2
1 13
10 1
14
2614
2
1 14
10 0
14
2615
2
1 14
10 1
30
0
2643
2
0 0
11 1
0
2642
2
0 0
11 0
1
2670
2
0 1
11 0
1
2671
2
0 1
11 1
2
2698
2
0 2
11 0
2
2699
2
0 2
11 1
3
2726
2
0 3
11 0
3
2727
2
0 3
11 1
4
2754
2
0 4
11 0
4
2755
2
0 4
11 1
5
2782
2
0 5
11 0
5
2783
2
0 5
11 1
6
2810
2
0 6
11 0
6
2811
2
0 6
11 1
7
2839
2
0 7
11 1
7
2838
2
0 7
11 0
8
2866
2
0 8
11 0
8
2867
2
0 8
11 1
9
2894
2
0 9
11 0
9
2895
2
0 9
11 1
10
2922
2
0 10
11 0
10
2923
2
0 10
11 1
11
2950
2
0 11
11 0
11
2951
2
0 11
11 1
12
2978
2
0 12
11 0
12
2979
2
0 12
11 1
13
3006
2
0 13
11 0
13
3007
2
0 13
11 1
14
3034
2
0 14
11 0
14
3035
2
0 14
11 1
end_DTG
begin_CG
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
11 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
10 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
9 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
8 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
7 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
6 840
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
end_CG
