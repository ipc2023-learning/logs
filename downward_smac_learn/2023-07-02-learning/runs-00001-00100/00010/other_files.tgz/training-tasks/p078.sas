begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var18
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var13
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var19
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l14)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




16
4098
2
3 11
8 1
16
4099
2
3 11
8 2
17
4462
2
2 11
9 1
17
4463
2
2 11
9 2
18
4826
2
1 11
10 1
18
4827
2
1 11
10 2
19
5190
2
0 11
11 1
19
5191
2
0 11
11 2
12
14
3396
2
5 12
6 1
14
3397
2
5 12
6 2
15
3760
2
4 12
7 1
15
3761
2
4 12
7 2
16
4124
2
3 12
8 1
16
4125
2
3 12
8 2
17
4488
2
2 12
9 1
17
4489
2
2 12
9 2
18
4852
2
1 12
10 1
18
4853
2
1 12
10 2
19
5216
2
0 12
11 1
19
5217
2
0 12
11 2
12
14
3422
2
5 13
6 1
14
3423
2
5 13
6 2
15
3786
2
4 13
7 1
15
3787
2
4 13
7 2
16
4150
2
3 13
8 1
16
4151
2
3 13
8 2
17
4514
2
2 13
9 1
17
4515
2
2 13
9 2
18
4878
2
1 13
10 1
18
4879
2
1 13
10 2
19
5242
2
0 13
11 1
19
5243
2
0 13
11 2
28
0
901
2
5 0
6 1
0
900
2
5 0
6 0
1
926
2
5 1
6 0
1
927
2
5 1
6 1
2
952
2
5 2
6 0
2
953
2
5 2
6 1
3
978
2
5 3
6 0
3
979
2
5 3
6 1
4
1004
2
5 4
6 0
4
1005
2
5 4
6 1
5
1030
2
5 5
6 0
5
1031
2
5 5
6 1
6
1056
2
5 6
6 0
6
1057
2
5 6
6 1
7
1082
2
5 7
6 0
7
1083
2
5 7
6 1
8
1108
2
5 8
6 0
8
1109
2
5 8
6 1
9
1134
2
5 9
6 0
9
1135
2
5 9
6 1
10
1160
2
5 10
6 0
10
1161
2
5 10
6 1
11
1186
2
5 11
6 0
11
1187
2
5 11
6 1
12
1212
2
5 12
6 0
12
1213
2
5 12
6 1
13
1238
2
5 13
6 0
13
1239
2
5 13
6 1
28
0
1265
2
4 0
7 1
0
1264
2
4 0
7 0
1
1290
2
4 1
7 0
1
1291
2
4 1
7 1
2
1316
2
4 2
7 0
2
1317
2
4 2
7 1
3
1342
2
4 3
7 0
3
1343
2
4 3
7 1
4
1368
2
4 4
7 0
4
1369
2
4 4
7 1
5
1394
2
4 5
7 0
5
1395
2
4 5
7 1
6
1420
2
4 6
7 0
6
1421
2
4 6
7 1
7
1446
2
4 7
7 0
7
1447
2
4 7
7 1
8
1472
2
4 8
7 0
8
1473
2
4 8
7 1
9
1498
2
4 9
7 0
9
1499
2
4 9
7 1
10
1524
2
4 10
7 0
10
1525
2
4 10
7 1
11
1550
2
4 11
7 0
11
1551
2
4 11
7 1
12
1576
2
4 12
7 0
12
1577
2
4 12
7 1
13
1602
2
4 13
7 0
13
1603
2
4 13
7 1
28
0
1629
2
3 0
8 1
0
1628
2
3 0
8 0
1
1654
2
3 1
8 0
1
1655
2
3 1
8 1
2
1680
2
3 2
8 0
2
1681
2
3 2
8 1
3
1706
2
3 3
8 0
3
1707
2
3 3
8 1
4
1732
2
3 4
8 0
4
1733
2
3 4
8 1
5
1758
2
3 5
8 0
5
1759
2
3 5
8 1
6
1784
2
3 6
8 0
6
1785
2
3 6
8 1
7
1810
2
3 7
8 0
7
1811
2
3 7
8 1
8
1836
2
3 8
8 0
8
1837
2
3 8
8 1
9
1862
2
3 9
8 0
9
1863
2
3 9
8 1
10
1888
2
3 10
8 0
10
1889
2
3 10
8 1
11
1914
2
3 11
8 0
11
1915
2
3 11
8 1
12
1940
2
3 12
8 0
12
1941
2
3 12
8 1
13
1966
2
3 13
8 0
13
1967
2
3 13
8 1
28
0
1993
2
2 0
9 1
0
1992
2
2 0
9 0
1
2018
2
2 1
9 0
1
2019
2
2 1
9 1
2
2044
2
2 2
9 0
2
2045
2
2 2
9 1
3
2070
2
2 3
9 0
3
2071
2
2 3
9 1
4
2096
2
2 4
9 0
4
2097
2
2 4
9 1
5
2122
2
2 5
9 0
5
2123
2
2 5
9 1
6
2148
2
2 6
9 0
6
2149
2
2 6
9 1
7
2174
2
2 7
9 0
7
2175
2
2 7
9 1
8
2200
2
2 8
9 0
8
2201
2
2 8
9 1
9
2226
2
2 9
9 0
9
2227
2
2 9
9 1
10
2252
2
2 10
9 0
10
2253
2
2 10
9 1
11
2278
2
2 11
9 0
11
2279
2
2 11
9 1
12
2304
2
2 12
9 0
12
2305
2
2 12
9 1
13
2330
2
2 13
9 0
13
2331
2
2 13
9 1
28
0
2357
2
1 0
10 1
0
2356
2
1 0
10 0
1
2382
2
1 1
10 0
1
2383
2
1 1
10 1
2
2408
2
1 2
10 0
2
2409
2
1 2
10 1
3
2434
2
1 3
10 0
3
2435
2
1 3
10 1
4
2460
2
1 4
10 0
4
2461
2
1 4
10 1
5
2486
2
1 5
10 0
5
2487
2
1 5
10 1
6
2512
2
1 6
10 0
6
2513
2
1 6
10 1
7
2538
2
1 7
10 0
7
2539
2
1 7
10 1
8
2564
2
1 8
10 0
8
2565
2
1 8
10 1
9
2590
2
1 9
10 0
9
2591
2
1 9
10 1
10
2616
2
1 10
10 0
10
2617
2
1 10
10 1
11
2642
2
1 11
10 0
11
2643
2
1 11
10 1
12
2668
2
1 12
10 0
12
2669
2
1 12
10 1
13
2694
2
1 13
10 0
13
2695
2
1 13
10 1
28
0
2721
2
0 0
11 1
0
2720
2
0 0
11 0
1
2746
2
0 1
11 0
1
2747
2
0 1
11 1
2
2772
2
0 2
11 0
2
2773
2
0 2
11 1
3
2798
2
0 3
11 0
3
2799
2
0 3
11 1
4
2824
2
0 4
11 0
4
2825
2
0 4
11 1
5
2850
2
0 5
11 0
5
2851
2
0 5
11 1
6
2876
2
0 6
11 0
6
2877
2
0 6
11 1
7
2902
2
0 7
11 0
7
2903
2
0 7
11 1
8
2928
2
0 8
11 0
8
2929
2
0 8
11 1
9
2954
2
0 9
11 0
9
2955
2
0 9
11 1
10
2980
2
0 10
11 0
10
2981
2
0 10
11 1
11
3006
2
0 11
11 0
11
3007
2
0 11
11 1
12
3032
2
0 12
11 0
12
3033
2
0 12
11 1
13
3058
2
0 13
11 0
13
3059
2
0 13
11 1
end_DTG
begin_CG
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
11 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
10 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
9 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
8 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
7 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6 728
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
