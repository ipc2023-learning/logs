begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var13
-1
10
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var12
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var11
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var10
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var14
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
15
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
15
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
15
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
15
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
15
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
15
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
15
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
15
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var8
-1
15
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
8
6
7
0
3
1
1
2
2
2
8
1
5
5
8
5
6
2
9
end_state
begin_goal
9
10 1
11 7
12 8
13 3
14 2
15 9
16 3
17 9
18 3
end_goal
1990
begin_operator
drive v1 l1 l2
0
1
0 4 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 4 0 4
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 4 0 5
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 4 0 9
0
end_operator
begin_operator
drive v1 l10 l3
0
1
0 4 1 3
0
end_operator
begin_operator
drive v1 l10 l8
0
1
0 4 1 8
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 4 2 0
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 4 2 5
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 4 2 8
0
end_operator
begin_operator
drive v1 l3 l10
0
1
0 4 3 1
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 4 3 5
0
end_operator
begin_operator
drive v1 l3 l9
0
1
0 4 3 9
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 4 4 0
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 4 4 6
0
end_operator
begin_operator
drive v




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





6
672
2
2 6
7 0
6
673
2
2 6
7 1
7
690
2
2 7
7 0
7
691
2
2 7
7 1
8
708
2
2 8
7 0
8
709
2
2 8
7 1
9
726
2
2 9
7 0
9
727
2
2 9
7 1
20
0
745
2
1 0
8 1
0
744
2
1 0
8 0
1
762
2
1 1
8 0
1
763
2
1 1
8 1
2
780
2
1 2
8 0
2
781
2
1 2
8 1
3
798
2
1 3
8 0
3
799
2
1 3
8 1
4
816
2
1 4
8 0
4
817
2
1 4
8 1
5
834
2
1 5
8 0
5
835
2
1 5
8 1
6
852
2
1 6
8 0
6
853
2
1 6
8 1
7
870
2
1 7
8 0
7
871
2
1 7
8 1
8
888
2
1 8
8 0
8
889
2
1 8
8 1
9
906
2
1 9
8 0
9
907
2
1 9
8 1
20
0
925
2
0 0
9 1
0
924
2
0 0
9 0
1
942
2
0 1
9 0
1
943
2
0 1
9 1
2
960
2
0 2
9 0
2
961
2
0 2
9 1
3
978
2
0 3
9 0
3
979
2
0 3
9 1
4
996
2
0 4
9 0
4
997
2
0 4
9 1
5
1014
2
0 5
9 0
5
1015
2
0 5
9 1
6
1032
2
0 6
9 0
6
1033
2
0 6
9 1
7
1050
2
0 7
9 0
7
1051
2
0 7
9 1
8
1068
2
0 8
9 0
8
1069
2
0 8
9 1
9
1086
2
0 9
9 0
9
1087
2
0 9
9 1
end_DTG
begin_DTG
10
10
1106
2
4 0
5 1
10
1107
2
4 0
5 2
11
1286
2
3 0
6 1
11
1287
2
3 0
6 2
12
1466
2
2 0
7 1
12
1467
2
2 0
7 2
13
1646
2
1 0
8 1
13
1647
2
1 0
8 2
14
1826
2
0 0
9 1
14
1827
2
0 0
9 2
10
10
1124
2
4 1
5 1
10
1125
2
4 1
5 2
11
1304
2
3 1
6 1
11
1305
2
3 1
6 2
12
1484
2
2 1
7 1
12
1485
2
2 1
7 2
13
1664
2
1 1
8 1
13
1665
2
1 1
8 2
14
1844
2
0 1
9 1
14
1845
2
0 1
9 2
10
10
1142
2
4 2
5 1
10
1143
2
4 2
5 2
11
1322
2
3 2
6 1
11
1323
2
3 2
6 2
12
1502
2
2 2
7 1
12
1503
2
2 2
7 2
13
1682
2
1 2
8 1
13
1683
2
1 2
8 2
14
1862
2
0 2
9 1
14
1863
2
0 2
9 2
10
10
1160
2
4 3
5 1
10
1161
2
4 3
5 2
11
1340
2
3 3
6 1
11
1341
2
3 3
6 2
12
1520
2
2 3
7 1
12
1521
2
2 3
7 2
13
1700
2
1 3
8 1
13
1701
2
1 3
8 2
14
1880
2
0 3
9 1
14
1881
2
0 3
9 2
10
10
1178
2
4 4
5 1
10
1179
2
4 4
5 2
11
1358
2
3 4
6 1
11
1359
2
3 4
6 2
12
1538
2
2 4
7 1
12
1539
2
2 4
7 2
13
1718
2
1 4
8 1
13
1719
2
1 4
8 2
14
1898
2
0 4
9 1
14
1899
2
0 4
9 2
10
10
1196
2
4 5
5 1
10
1197
2
4 5
5 2
11
1376
2
3 5
6 1
11
1377
2
3 5
6 2
12
1556
2
2 5
7 1
12
1557
2
2 5
7 2
13
1736
2
1 5
8 1
13
1737
2
1 5
8 2
14
1916
2
0 5
9 1
14
1917
2
0 5
9 2
10
10
1214
2
4 6
5 1
10
1215
2
4 6
5 2
11
1394
2
3 6
6 1
11
1395
2
3 6
6 2
12
1574
2
2 6
7 1
12
1575
2
2 6
7 2
13
1754
2
1 6
8 1
13
1755
2
1 6
8 2
14
1934
2
0 6
9 1
14
1935
2
0 6
9 2
10
10
1232
2
4 7
5 1
10
1233
2
4 7
5 2
11
1412
2
3 7
6 1
11
1413
2
3 7
6 2
12
1592
2
2 7
7 1
12
1593
2
2 7
7 2
13
1772
2
1 7
8 1
13
1773
2
1 7
8 2
14
1952
2
0 7
9 1
14
1953
2
0 7
9 2
10
10
1250
2
4 8
5 1
10
1251
2
4 8
5 2
11
1430
2
3 8
6 1
11
1431
2
3 8
6 2
12
1610
2
2 8
7 1
12
1611
2
2 8
7 2
13
1790
2
1 8
8 1
13
1791
2
1 8
8 2
14
1970
2
0 8
9 1
14
1971
2
0 8
9 2
10
10
1268
2
4 9
5 1
10
1269
2
4 9
5 2
11
1448
2
3 9
6 1
11
1449
2
3 9
6 2
12
1628
2
2 9
7 1
12
1629
2
2 9
7 2
13
1808
2
1 9
8 1
13
1809
2
1 9
8 2
14
1988
2
0 9
9 1
14
1989
2
0 9
9 2
20
0
207
2
4 0
5 1
0
206
2
4 0
5 0
1
224
2
4 1
5 0
1
225
2
4 1
5 1
2
242
2
4 2
5 0
2
243
2
4 2
5 1
3
260
2
4 3
5 0
3
261
2
4 3
5 1
4
278
2
4 4
5 0
4
279
2
4 4
5 1
5
296
2
4 5
5 0
5
297
2
4 5
5 1
6
314
2
4 6
5 0
6
315
2
4 6
5 1
7
332
2
4 7
5 0
7
333
2
4 7
5 1
8
350
2
4 8
5 0
8
351
2
4 8
5 1
9
368
2
4 9
5 0
9
369
2
4 9
5 1
20
0
387
2
3 0
6 1
0
386
2
3 0
6 0
1
404
2
3 1
6 0
1
405
2
3 1
6 1
2
422
2
3 2
6 0
2
423
2
3 2
6 1
3
440
2
3 3
6 0
3
441
2
3 3
6 1
4
458
2
3 4
6 0
4
459
2
3 4
6 1
5
476
2
3 5
6 0
5
477
2
3 5
6 1
6
494
2
3 6
6 0
6
495
2
3 6
6 1
7
512
2
3 7
6 0
7
513
2
3 7
6 1
8
530
2
3 8
6 0
8
531
2
3 8
6 1
9
548
2
3 9
6 0
9
549
2
3 9
6 1
20
0
567
2
2 0
7 1
0
566
2
2 0
7 0
1
584
2
2 1
7 0
1
585
2
2 1
7 1
2
602
2
2 2
7 0
2
603
2
2 2
7 1
3
620
2
2 3
7 0
3
621
2
2 3
7 1
4
638
2
2 4
7 0
4
639
2
2 4
7 1
5
656
2
2 5
7 0
5
657
2
2 5
7 1
6
674
2
2 6
7 0
6
675
2
2 6
7 1
7
692
2
2 7
7 0
7
693
2
2 7
7 1
8
710
2
2 8
7 0
8
711
2
2 8
7 1
9
728
2
2 9
7 0
9
729
2
2 9
7 1
20
0
747
2
1 0
8 1
0
746
2
1 0
8 0
1
764
2
1 1
8 0
1
765
2
1 1
8 1
2
782
2
1 2
8 0
2
783
2
1 2
8 1
3
800
2
1 3
8 0
3
801
2
1 3
8 1
4
818
2
1 4
8 0
4
819
2
1 4
8 1
5
836
2
1 5
8 0
5
837
2
1 5
8 1
6
854
2
1 6
8 0
6
855
2
1 6
8 1
7
872
2
1 7
8 0
7
873
2
1 7
8 1
8
890
2
1 8
8 0
8
891
2
1 8
8 1
9
908
2
1 9
8 0
9
909
2
1 9
8 1
20
0
927
2
0 0
9 1
0
926
2
0 0
9 0
1
944
2
0 1
9 0
1
945
2
0 1
9 1
2
962
2
0 2
9 0
2
963
2
0 2
9 1
3
980
2
0 3
9 0
3
981
2
0 3
9 1
4
998
2
0 4
9 0
4
999
2
0 4
9 1
5
1016
2
0 5
9 0
5
1017
2
0 5
9 1
6
1034
2
0 6
9 0
6
1035
2
0 6
9 1
7
1052
2
0 7
9 0
7
1053
2
0 7
9 1
8
1070
2
0 8
9 0
8
1071
2
0 8
9 1
9
1088
2
0 9
9 0
9
1089
2
0 9
9 1
end_DTG
begin_CG
10
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
9 360
10
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
8 360
10
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
7 360
10
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
6 360
10
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
5 360
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
9
10 40
11 40
12 40
13 40
14 40
15 40
16 40
17 40
18 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
5
5 40
6 40
7 40
8 40
9 40
end_CG
