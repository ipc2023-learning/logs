begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var10
-1
9
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var9
-1
9
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var8
-1
9
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var7
-1
9
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var11
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
13
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
13
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
13
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
13
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
13
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
13
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
13
Atom at(p7, l1)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
0
begin_state
4
7
1
3
1
2
2
1
3
3
7
2
1
5
0
end_state
begin_goal
7
8 8
9 8
10 0
11 8
12 5
13 0
14 6
end_goal
1184
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l9
0
1
0 3 2 8
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l4 l9
0
1
0 3 3 8
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 3 6 5
0
end_operator
begin_operator
drive v1 l7 l8
0
1
0 3 6 7
0
end_operator
begin_operator
drive v1 l7 l9
0
1
0 3 6 8
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
end_operator
begin_operator
driv




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
0 1
7 2
8
9
718
2
3 2
4 1
9
719
2
3 2
4 2
10
844
2
2 2
5 1
10
845
2
2 2
5 2
11
970
2
1 2
6 1
11
971
2
1 2
6 2
12
1096
2
0 2
7 1
12
1097
2
0 2
7 2
8
9
732
2
3 3
4 1
9
733
2
3 3
4 2
10
858
2
2 3
5 1
10
859
2
2 3
5 2
11
984
2
1 3
6 1
11
985
2
1 3
6 2
12
1110
2
0 3
7 1
12
1111
2
0 3
7 2
8
9
746
2
3 4
4 1
9
747
2
3 4
4 2
10
872
2
2 4
5 1
10
873
2
2 4
5 2
11
998
2
1 4
6 1
11
999
2
1 4
6 2
12
1124
2
0 4
7 1
12
1125
2
0 4
7 2
8
9
760
2
3 5
4 1
9
761
2
3 5
4 2
10
886
2
2 5
5 1
10
887
2
2 5
5 2
11
1012
2
1 5
6 1
11
1013
2
1 5
6 2
12
1138
2
0 5
7 1
12
1139
2
0 5
7 2
8
9
774
2
3 6
4 1
9
775
2
3 6
4 2
10
900
2
2 6
5 1
10
901
2
2 6
5 2
11
1026
2
1 6
6 1
11
1027
2
1 6
6 2
12
1152
2
0 6
7 1
12
1153
2
0 6
7 2
8
9
788
2
3 7
4 1
9
789
2
3 7
4 2
10
914
2
2 7
5 1
10
915
2
2 7
5 2
11
1040
2
1 7
6 1
11
1041
2
1 7
6 2
12
1166
2
0 7
7 1
12
1167
2
0 7
7 2
8
9
802
2
3 8
4 1
9
803
2
3 8
4 2
10
928
2
2 8
5 1
10
929
2
2 8
5 2
11
1054
2
1 8
6 1
11
1055
2
1 8
6 2
12
1180
2
0 8
7 1
12
1181
2
0 8
7 2
18
0
187
2
3 0
4 1
0
186
2
3 0
4 0
1
200
2
3 1
4 0
1
201
2
3 1
4 1
2
214
2
3 2
4 0
2
215
2
3 2
4 1
3
228
2
3 3
4 0
3
229
2
3 3
4 1
4
243
2
3 4
4 1
4
242
2
3 4
4 0
5
256
2
3 5
4 0
5
257
2
3 5
4 1
6
270
2
3 6
4 0
6
271
2
3 6
4 1
7
284
2
3 7
4 0
7
285
2
3 7
4 1
8
298
2
3 8
4 0
8
299
2
3 8
4 1
18
0
313
2
2 0
5 1
0
312
2
2 0
5 0
1
326
2
2 1
5 0
1
327
2
2 1
5 1
2
340
2
2 2
5 0
2
341
2
2 2
5 1
3
354
2
2 3
5 0
3
355
2
2 3
5 1
4
369
2
2 4
5 1
4
368
2
2 4
5 0
5
382
2
2 5
5 0
5
383
2
2 5
5 1
6
396
2
2 6
5 0
6
397
2
2 6
5 1
7
410
2
2 7
5 0
7
411
2
2 7
5 1
8
424
2
2 8
5 0
8
425
2
2 8
5 1
18
0
439
2
1 0
6 1
0
438
2
1 0
6 0
1
452
2
1 1
6 0
1
453
2
1 1
6 1
2
466
2
1 2
6 0
2
467
2
1 2
6 1
3
480
2
1 3
6 0
3
481
2
1 3
6 1
4
495
2
1 4
6 1
4
494
2
1 4
6 0
5
508
2
1 5
6 0
5
509
2
1 5
6 1
6
522
2
1 6
6 0
6
523
2
1 6
6 1
7
536
2
1 7
6 0
7
537
2
1 7
6 1
8
550
2
1 8
6 0
8
551
2
1 8
6 1
18
0
565
2
0 0
7 1
0
564
2
0 0
7 0
1
578
2
0 1
7 0
1
579
2
0 1
7 1
2
592
2
0 2
7 0
2
593
2
0 2
7 1
3
606
2
0 3
7 0
3
607
2
0 3
7 1
4
621
2
0 4
7 1
4
620
2
0 4
7 0
5
634
2
0 5
7 0
5
635
2
0 5
7 1
6
648
2
0 6
7 0
6
649
2
0 6
7 1
7
662
2
0 7
7 0
7
663
2
0 7
7 1
8
676
2
0 8
7 0
8
677
2
0 8
7 1
end_DTG
begin_DTG
8
9
692
2
3 0
4 1
9
693
2
3 0
4 2
10
818
2
2 0
5 1
10
819
2
2 0
5 2
11
944
2
1 0
6 1
11
945
2
1 0
6 2
12
1070
2
0 0
7 1
12
1071
2
0 0
7 2
8
9
706
2
3 1
4 1
9
707
2
3 1
4 2
10
832
2
2 1
5 1
10
833
2
2 1
5 2
11
958
2
1 1
6 1
11
959
2
1 1
6 2
12
1084
2
0 1
7 1
12
1085
2
0 1
7 2
8
9
720
2
3 2
4 1
9
721
2
3 2
4 2
10
846
2
2 2
5 1
10
847
2
2 2
5 2
11
972
2
1 2
6 1
11
973
2
1 2
6 2
12
1098
2
0 2
7 1
12
1099
2
0 2
7 2
8
9
734
2
3 3
4 1
9
735
2
3 3
4 2
10
860
2
2 3
5 1
10
861
2
2 3
5 2
11
986
2
1 3
6 1
11
987
2
1 3
6 2
12
1112
2
0 3
7 1
12
1113
2
0 3
7 2
8
9
748
2
3 4
4 1
9
749
2
3 4
4 2
10
874
2
2 4
5 1
10
875
2
2 4
5 2
11
1000
2
1 4
6 1
11
1001
2
1 4
6 2
12
1126
2
0 4
7 1
12
1127
2
0 4
7 2
8
9
762
2
3 5
4 1
9
763
2
3 5
4 2
10
888
2
2 5
5 1
10
889
2
2 5
5 2
11
1014
2
1 5
6 1
11
1015
2
1 5
6 2
12
1140
2
0 5
7 1
12
1141
2
0 5
7 2
8
9
776
2
3 6
4 1
9
777
2
3 6
4 2
10
902
2
2 6
5 1
10
903
2
2 6
5 2
11
1028
2
1 6
6 1
11
1029
2
1 6
6 2
12
1154
2
0 6
7 1
12
1155
2
0 6
7 2
8
9
790
2
3 7
4 1
9
791
2
3 7
4 2
10
916
2
2 7
5 1
10
917
2
2 7
5 2
11
1042
2
1 7
6 1
11
1043
2
1 7
6 2
12
1168
2
0 7
7 1
12
1169
2
0 7
7 2
8
9
804
2
3 8
4 1
9
805
2
3 8
4 2
10
930
2
2 8
5 1
10
931
2
2 8
5 2
11
1056
2
1 8
6 1
11
1057
2
1 8
6 2
12
1182
2
0 8
7 1
12
1183
2
0 8
7 2
18
0
189
2
3 0
4 1
0
188
2
3 0
4 0
1
202
2
3 1
4 0
1
203
2
3 1
4 1
2
216
2
3 2
4 0
2
217
2
3 2
4 1
3
230
2
3 3
4 0
3
231
2
3 3
4 1
4
245
2
3 4
4 1
4
244
2
3 4
4 0
5
258
2
3 5
4 0
5
259
2
3 5
4 1
6
272
2
3 6
4 0
6
273
2
3 6
4 1
7
286
2
3 7
4 0
7
287
2
3 7
4 1
8
300
2
3 8
4 0
8
301
2
3 8
4 1
18
0
315
2
2 0
5 1
0
314
2
2 0
5 0
1
328
2
2 1
5 0
1
329
2
2 1
5 1
2
342
2
2 2
5 0
2
343
2
2 2
5 1
3
356
2
2 3
5 0
3
357
2
2 3
5 1
4
371
2
2 4
5 1
4
370
2
2 4
5 0
5
384
2
2 5
5 0
5
385
2
2 5
5 1
6
398
2
2 6
5 0
6
399
2
2 6
5 1
7
412
2
2 7
5 0
7
413
2
2 7
5 1
8
426
2
2 8
5 0
8
427
2
2 8
5 1
18
0
441
2
1 0
6 1
0
440
2
1 0
6 0
1
454
2
1 1
6 0
1
455
2
1 1
6 1
2
468
2
1 2
6 0
2
469
2
1 2
6 1
3
482
2
1 3
6 0
3
483
2
1 3
6 1
4
497
2
1 4
6 1
4
496
2
1 4
6 0
5
510
2
1 5
6 0
5
511
2
1 5
6 1
6
524
2
1 6
6 0
6
525
2
1 6
6 1
7
538
2
1 7
6 0
7
539
2
1 7
6 1
8
552
2
1 8
6 0
8
553
2
1 8
6 1
18
0
567
2
0 0
7 1
0
566
2
0 0
7 0
1
580
2
0 1
7 0
1
581
2
0 1
7 1
2
594
2
0 2
7 0
2
595
2
0 2
7 1
3
608
2
0 3
7 0
3
609
2
0 3
7 1
4
623
2
0 4
7 1
4
622
2
0 4
7 0
5
636
2
0 5
7 0
5
637
2
0 5
7 1
6
650
2
0 6
7 0
6
651
2
0 6
7 1
7
664
2
0 7
7 0
7
665
2
0 7
7 1
8
678
2
0 8
7 0
8
679
2
0 8
7 1
end_DTG
begin_CG
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
6 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
5 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4 252
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
end_CG
