begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var20
-1
15
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var19
-1
15
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var18
-1
15
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var17
-1
15
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var16
-1
15
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var15
-1
15
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var21
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var26
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
21
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
21
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
21
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
21
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
21
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
21
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l15)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
21
Atom at(p15, l1)
Atom at(p15, l10)
Atom at(p15, l11)
Atom at(p15, l12)
Atom at(p15, l13)
Atom at(p15, l14)
Atom at(p15, l15)
Atom at(p15, l2)
Atom at(p15, l3)
Atom at(p15, l4)
Atom at(p15, l5)
Atom at(p15, l6)
Atom at(p15, l7)
Atom at(p15, l8)
Atom at(p15, l9)
Atom in(p15, v1)
Atom in(p15, v2)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3593
2
5 14
6 2
16
4042
2
4 14
7 1
16
4043
2
4 14
7 2
17
4492
2
3 14
8 1
17
4493
2
3 14
8 2
18
4942
2
2 14
9 1
18
4943
2
2 14
9 2
19
5392
2
1 14
10 1
19
5393
2
1 14
10 2
20
5842
2
0 14
11 1
20
5843
2
0 14
11 2
30
0
473
2
5 0
6 1
0
472
2
5 0
6 0
1
502
2
5 1
6 0
1
503
2
5 1
6 1
2
532
2
5 2
6 0
2
533
2
5 2
6 1
3
562
2
5 3
6 0
3
563
2
5 3
6 1
4
592
2
5 4
6 0
4
593
2
5 4
6 1
5
622
2
5 5
6 0
5
623
2
5 5
6 1
6
652
2
5 6
6 0
6
653
2
5 6
6 1
7
683
2
5 7
6 1
7
682
2
5 7
6 0
8
712
2
5 8
6 0
8
713
2
5 8
6 1
9
742
2
5 9
6 0
9
743
2
5 9
6 1
10
772
2
5 10
6 0
10
773
2
5 10
6 1
11
802
2
5 11
6 0
11
803
2
5 11
6 1
12
832
2
5 12
6 0
12
833
2
5 12
6 1
13
862
2
5 13
6 0
13
863
2
5 13
6 1
14
892
2
5 14
6 0
14
893
2
5 14
6 1
30
0
923
2
4 0
7 1
0
922
2
4 0
7 0
1
952
2
4 1
7 0
1
953
2
4 1
7 1
2
982
2
4 2
7 0
2
983
2
4 2
7 1
3
1012
2
4 3
7 0
3
1013
2
4 3
7 1
4
1042
2
4 4
7 0
4
1043
2
4 4
7 1
5
1072
2
4 5
7 0
5
1073
2
4 5
7 1
6
1102
2
4 6
7 0
6
1103
2
4 6
7 1
7
1133
2
4 7
7 1
7
1132
2
4 7
7 0
8
1162
2
4 8
7 0
8
1163
2
4 8
7 1
9
1192
2
4 9
7 0
9
1193
2
4 9
7 1
10
1222
2
4 10
7 0
10
1223
2
4 10
7 1
11
1252
2
4 11
7 0
11
1253
2
4 11
7 1
12
1282
2
4 12
7 0
12
1283
2
4 12
7 1
13
1312
2
4 13
7 0
13
1313
2
4 13
7 1
14
1342
2
4 14
7 0
14
1343
2
4 14
7 1
30
0
1373
2
3 0
8 1
0
1372
2
3 0
8 0
1
1402
2
3 1
8 0
1
1403
2
3 1
8 1
2
1432
2
3 2
8 0
2
1433
2
3 2
8 1
3
1462
2
3 3
8 0
3
1463
2
3 3
8 1
4
1492
2
3 4
8 0
4
1493
2
3 4
8 1
5
1522
2
3 5
8 0
5
1523
2
3 5
8 1
6
1552
2
3 6
8 0
6
1553
2
3 6
8 1
7
1583
2
3 7
8 1
7
1582
2
3 7
8 0
8
1612
2
3 8
8 0
8
1613
2
3 8
8 1
9
1642
2
3 9
8 0
9
1643
2
3 9
8 1
10
1672
2
3 10
8 0
10
1673
2
3 10
8 1
11
1702
2
3 11
8 0
11
1703
2
3 11
8 1
12
1732
2
3 12
8 0
12
1733
2
3 12
8 1
13
1762
2
3 13
8 0
13
1763
2
3 13
8 1
14
1792
2
3 14
8 0
14
1793
2
3 14
8 1
30
0
1823
2
2 0
9 1
0
1822
2
2 0
9 0
1
1852
2
2 1
9 0
1
1853
2
2 1
9 1
2
1882
2
2 2
9 0
2
1883
2
2 2
9 1
3
1912
2
2 3
9 0
3
1913
2
2 3
9 1
4
1942
2
2 4
9 0
4
1943
2
2 4
9 1
5
1972
2
2 5
9 0
5
1973
2
2 5
9 1
6
2002
2
2 6
9 0
6
2003
2
2 6
9 1
7
2033
2
2 7
9 1
7
2032
2
2 7
9 0
8
2062
2
2 8
9 0
8
2063
2
2 8
9 1
9
2092
2
2 9
9 0
9
2093
2
2 9
9 1
10
2122
2
2 10
9 0
10
2123
2
2 10
9 1
11
2152
2
2 11
9 0
11
2153
2
2 11
9 1
12
2182
2
2 12
9 0
12
2183
2
2 12
9 1
13
2212
2
2 13
9 0
13
2213
2
2 13
9 1
14
2242
2
2 14
9 0
14
2243
2
2 14
9 1
30
0
2273
2
1 0
10 1
0
2272
2
1 0
10 0
1
2302
2
1 1
10 0
1
2303
2
1 1
10 1
2
2332
2
1 2
10 0
2
2333
2
1 2
10 1
3
2362
2
1 3
10 0
3
2363
2
1 3
10 1
4
2392
2
1 4
10 0
4
2393
2
1 4
10 1
5
2422
2
1 5
10 0
5
2423
2
1 5
10 1
6
2452
2
1 6
10 0
6
2453
2
1 6
10 1
7
2483
2
1 7
10 1
7
2482
2
1 7
10 0
8
2512
2
1 8
10 0
8
2513
2
1 8
10 1
9
2542
2
1 9
10 0
9
2543
2
1 9
10 1
10
2572
2
1 10
10 0
10
2573
2
1 10
10 1
11
2602
2
1 11
10 0
11
2603
2
1 11
10 1
12
2632
2
1 12
10 0
12
2633
2
1 12
10 1
13
2662
2
1 13
10 0
13
2663
2
1 13
10 1
14
2692
2
1 14
10 0
14
2693
2
1 14
10 1
30
0
2723
2
0 0
11 1
0
2722
2
0 0
11 0
1
2752
2
0 1
11 0
1
2753
2
0 1
11 1
2
2782
2
0 2
11 0
2
2783
2
0 2
11 1
3
2812
2
0 3
11 0
3
2813
2
0 3
11 1
4
2842
2
0 4
11 0
4
2843
2
0 4
11 1
5
2872
2
0 5
11 0
5
2873
2
0 5
11 1
6
2902
2
0 6
11 0
6
2903
2
0 6
11 1
7
2933
2
0 7
11 1
7
2932
2
0 7
11 0
8
2962
2
0 8
11 0
8
2963
2
0 8
11 1
9
2992
2
0 9
11 0
9
2993
2
0 9
11 1
10
3022
2
0 10
11 0
10
3023
2
0 10
11 1
11
3052
2
0 11
11 0
11
3053
2
0 11
11 1
12
3082
2
0 12
11 0
12
3083
2
0 12
11 1
13
3112
2
0 13
11 0
13
3113
2
0 13
11 1
14
3142
2
0 14
11 0
14
3143
2
0 14
11 1
end_DTG
begin_CG
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
11 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
10 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
9 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
8 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
7 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6 900
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
end_CG
