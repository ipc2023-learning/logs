begin_version
3
end_version
begin_metric
0
end_metric
4
begin_variable
var2
-1
2
Atom at(v1, l1)
Atom at(v1, l2)
end_variable
begin_variable
var3
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var0
-1
3
Atom at(p1, l1)
Atom at(p1, l2)
Atom in(p1, v1)
end_variable
begin_variable
var1
-1
3
Atom at(p2, l1)
Atom at(p2, l2)
Atom in(p2, v1)
end_variable
0
begin_state
0
2
1
1
end_state
begin_goal
2
2 0
3 0
end_goal
18
begin_operator
drive v1 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
0 0
2
0 2 2 0
0 1 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
0 0
2
0 2 2 0
0 1 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
0 0
2
0 3 2 0
0 1 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
0 0
2
0 3 2 0
0 1 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
0 1
2
0 2 2 1
0 1 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c1 c2
1
0 1
2
0 2 2 1
0 1 1 2
0
end_operator
begin_operator
drop v1 l2 p2 c0 c1
1
0 1
2
0 3 2 1
0 1 0 1
0
end_operator
begin_operator
drop v1 l2 p2 c1 c2
1
0 1
2
0 3 2 1
0 1 1 2
0
end_operator
begin_operator
pick-up v1 l1 p1 c0 c1
1
0 0
2
0 2 0 2
0 1 1 0
0
end_operator
begin_operator
pick-up v1 l1 p1 c1 c2
1
0 0
2
0 2 0 2
0 1 2 1
0
end_operator
begin_operator
pick-up v1 l1 p2 c0 c1
1
0 0
2
0 3 0 2
0 1 1 0
0
end_operator
begin_operator
pick-up v1 l1 p2 c1 c2
1
0 0
2
0 3 0 2
0 1 2 1
0
end_operator
begin_operator
pick-up v1 l2 p1 c0 c1
1
0 1
2
0 2 1 2
0 1 1 0
0
end_operator
begin_operator
pick-up v1 l2 p1 c1 c2
1
0 1
2
0 2 1 2
0 1 2 1
0
end_operator
begin_operator
pick-up v1 l2 p2 c0 c1
1
0 1
2
0 3 1 2
0 1 1 0
0
end_operator
begin_operator
pick-up v1 l2 p2 c1 c2
1
0 1
2
0 3 1 2
0 1 2 1
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 1
check 0
check 0
check 1
10
check 1
11
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 0
check 1
14
check 1
15
check 0
check 0
switch 0
check 0
switch 1
check 0
check 1
2
check 1
3
check 0
check 0
switch 1
check 0
check 1
6
check 1
7
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
switch 1
check 0
check 0
check 1
12
check 1
13
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 0
check 1
16
check 1
17
check 0
check 0
switch 0
check 0
switch 1
check 0
check 1
4
check 1
5
check 0
check 0
switch 1
check 0
check 1
8
check 1
9
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 1
1
check 0
end_SG
begin_DTG
1
1
0
0
1
0
1
0
end_DTG
begin_DTG
4
1
2
2
2 2
0 0
1
4
2
3 2
0 0
1
6
2
2 2
0 1
1
8
2
3 2
0 1
8
0
10
2
2 0
0 0
0
12
2
3 0
0 0
0
14
2
2 1
0 1
0
16
2
3 1
0 1
2
3
2
2 2
0 0
2
5
2
3 2
0 0
2
7
2
2 2
0 1
2
9
2
3 2
0 1
4
1
11
2
2 0
0 0
1
13
2
3 0
0 0
1
15
2
2 1
0 1
1
17
2
3 1
0 1
end_DTG
begin_DTG
2
2
10
2
0 0
1 1
2
11
2
0 0
1 2
2
2
14
2
0 1
1 1
2
15
2
0 1
1 2
4
0
2
2
0 0
1 0
0
3
2
0 0
1 1
1
6
2
0 1
1 0
1
7
2
0 1
1 1
end_DTG
begin_DTG
2
2
12
2
0 0
1 1
2
13
2
0 0
1 2
2
2
16
2
0 1
1 1
2
17
2
0 1
1 2
4
0
4
2
0 0
1 0
0
5
2
0 0
1 1
1
8
2
0 1
1 0
1
9
2
0 1
1 1
end_DTG
begin_CG
3
2 8
3 8
1 16
2
2 8
3 8
1
1 8
1
1 8
end_CG
