begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var10
-1
9
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var9
-1
9
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var8
-1
9
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var7
-1
9
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var11
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
13
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
13
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
13
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
13
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
13
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
13
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
13
Atom at(p7, l1)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
0
begin_state
3
6
0
3
2
2
2
2
5
8
6
5
0
8
6
end_state
begin_goal
7
8 0
9 0
10 3
11 1
12 1
13 0
14 2
end_goal
1152
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 3 0 8
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l3 l9
0
1
0 3 2 8
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l9
0
1
0 3 3 8
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l9
0
1
0 3 4 8
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l9
0
1
0 3 5 8
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l8
0
1
0 3 6 7
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
end_operator
begin_operator
drive v1 l8 l2
0
1
0 3 7 1
0
end_operator
begin_operator
drive v1 l8 l3
0
1
0 3 7 2
0
end_operator
begin_operator
drive v1 l8 l7
0
1
0 3 7 6
0
end_operator
begin_operator
drive v1 l8 l9
0
1
0 3 7 8
0
end_operator
begin_operator
drive v1 l9 l1
0
1
0 3 8 0
0
end_operator
begin_operator
drive v1 l9 l2
0
1
0 3 8 1
0
end_operator
begin_operator
drive v1 l9 l3
0
1
0 3 8 2
0
end_operator
begin_operator
drive v1 l9 l4
0
1
0 3 8 3
0
end_operator
begin_operator
drive v1 l9 l5
0
1
0 3 8 4
0
end_operator
begin_operator
drive v1 l9 l6
0
1
0 3 8 5
0
end_operator
begin_operator
drive v1 l9 l8
0
1
0 3 8 7
0
end_operator
begin_operator
driv




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
12
1051
2
0 1
7 2
8
9
686
2
3 2
4 1
9
687
2
3 2
4 2
10
812
2
2 2
5 1
10
813
2
2 2
5 2
11
938
2
1 2
6 1
11
939
2
1 2
6 2
12
1064
2
0 2
7 1
12
1065
2
0 2
7 2
8
9
700
2
3 3
4 1
9
701
2
3 3
4 2
10
826
2
2 3
5 1
10
827
2
2 3
5 2
11
952
2
1 3
6 1
11
953
2
1 3
6 2
12
1078
2
0 3
7 1
12
1079
2
0 3
7 2
8
9
714
2
3 4
4 1
9
715
2
3 4
4 2
10
840
2
2 4
5 1
10
841
2
2 4
5 2
11
966
2
1 4
6 1
11
967
2
1 4
6 2
12
1092
2
0 4
7 1
12
1093
2
0 4
7 2
8
9
728
2
3 5
4 1
9
729
2
3 5
4 2
10
854
2
2 5
5 1
10
855
2
2 5
5 2
11
980
2
1 5
6 1
11
981
2
1 5
6 2
12
1106
2
0 5
7 1
12
1107
2
0 5
7 2
8
9
742
2
3 6
4 1
9
743
2
3 6
4 2
10
868
2
2 6
5 1
10
869
2
2 6
5 2
11
994
2
1 6
6 1
11
995
2
1 6
6 2
12
1120
2
0 6
7 1
12
1121
2
0 6
7 2
8
9
756
2
3 7
4 1
9
757
2
3 7
4 2
10
882
2
2 7
5 1
10
883
2
2 7
5 2
11
1008
2
1 7
6 1
11
1009
2
1 7
6 2
12
1134
2
0 7
7 1
12
1135
2
0 7
7 2
8
9
770
2
3 8
4 1
9
771
2
3 8
4 2
10
896
2
2 8
5 1
10
897
2
2 8
5 2
11
1022
2
1 8
6 1
11
1023
2
1 8
6 2
12
1148
2
0 8
7 1
12
1149
2
0 8
7 2
18
0
155
2
3 0
4 1
0
154
2
3 0
4 0
1
168
2
3 1
4 0
1
169
2
3 1
4 1
2
182
2
3 2
4 0
2
183
2
3 2
4 1
3
196
2
3 3
4 0
3
197
2
3 3
4 1
4
211
2
3 4
4 1
4
210
2
3 4
4 0
5
224
2
3 5
4 0
5
225
2
3 5
4 1
6
238
2
3 6
4 0
6
239
2
3 6
4 1
7
252
2
3 7
4 0
7
253
2
3 7
4 1
8
266
2
3 8
4 0
8
267
2
3 8
4 1
18
0
281
2
2 0
5 1
0
280
2
2 0
5 0
1
294
2
2 1
5 0
1
295
2
2 1
5 1
2
308
2
2 2
5 0
2
309
2
2 2
5 1
3
322
2
2 3
5 0
3
323
2
2 3
5 1
4
337
2
2 4
5 1
4
336
2
2 4
5 0
5
350
2
2 5
5 0
5
351
2
2 5
5 1
6
364
2
2 6
5 0
6
365
2
2 6
5 1
7
378
2
2 7
5 0
7
379
2
2 7
5 1
8
392
2
2 8
5 0
8
393
2
2 8
5 1
18
0
407
2
1 0
6 1
0
406
2
1 0
6 0
1
420
2
1 1
6 0
1
421
2
1 1
6 1
2
434
2
1 2
6 0
2
435
2
1 2
6 1
3
448
2
1 3
6 0
3
449
2
1 3
6 1
4
463
2
1 4
6 1
4
462
2
1 4
6 0
5
476
2
1 5
6 0
5
477
2
1 5
6 1
6
490
2
1 6
6 0
6
491
2
1 6
6 1
7
504
2
1 7
6 0
7
505
2
1 7
6 1
8
518
2
1 8
6 0
8
519
2
1 8
6 1
18
0
533
2
0 0
7 1
0
532
2
0 0
7 0
1
546
2
0 1
7 0
1
547
2
0 1
7 1
2
560
2
0 2
7 0
2
561
2
0 2
7 1
3
574
2
0 3
7 0
3
575
2
0 3
7 1
4
589
2
0 4
7 1
4
588
2
0 4
7 0
5
602
2
0 5
7 0
5
603
2
0 5
7 1
6
616
2
0 6
7 0
6
617
2
0 6
7 1
7
630
2
0 7
7 0
7
631
2
0 7
7 1
8
644
2
0 8
7 0
8
645
2
0 8
7 1
end_DTG
begin_DTG
8
9
660
2
3 0
4 1
9
661
2
3 0
4 2
10
786
2
2 0
5 1
10
787
2
2 0
5 2
11
912
2
1 0
6 1
11
913
2
1 0
6 2
12
1038
2
0 0
7 1
12
1039
2
0 0
7 2
8
9
674
2
3 1
4 1
9
675
2
3 1
4 2
10
800
2
2 1
5 1
10
801
2
2 1
5 2
11
926
2
1 1
6 1
11
927
2
1 1
6 2
12
1052
2
0 1
7 1
12
1053
2
0 1
7 2
8
9
688
2
3 2
4 1
9
689
2
3 2
4 2
10
814
2
2 2
5 1
10
815
2
2 2
5 2
11
940
2
1 2
6 1
11
941
2
1 2
6 2
12
1066
2
0 2
7 1
12
1067
2
0 2
7 2
8
9
702
2
3 3
4 1
9
703
2
3 3
4 2
10
828
2
2 3
5 1
10
829
2
2 3
5 2
11
954
2
1 3
6 1
11
955
2
1 3
6 2
12
1080
2
0 3
7 1
12
1081
2
0 3
7 2
8
9
716
2
3 4
4 1
9
717
2
3 4
4 2
10
842
2
2 4
5 1
10
843
2
2 4
5 2
11
968
2
1 4
6 1
11
969
2
1 4
6 2
12
1094
2
0 4
7 1
12
1095
2
0 4
7 2
8
9
730
2
3 5
4 1
9
731
2
3 5
4 2
10
856
2
2 5
5 1
10
857
2
2 5
5 2
11
982
2
1 5
6 1
11
983
2
1 5
6 2
12
1108
2
0 5
7 1
12
1109
2
0 5
7 2
8
9
744
2
3 6
4 1
9
745
2
3 6
4 2
10
870
2
2 6
5 1
10
871
2
2 6
5 2
11
996
2
1 6
6 1
11
997
2
1 6
6 2
12
1122
2
0 6
7 1
12
1123
2
0 6
7 2
8
9
758
2
3 7
4 1
9
759
2
3 7
4 2
10
884
2
2 7
5 1
10
885
2
2 7
5 2
11
1010
2
1 7
6 1
11
1011
2
1 7
6 2
12
1136
2
0 7
7 1
12
1137
2
0 7
7 2
8
9
772
2
3 8
4 1
9
773
2
3 8
4 2
10
898
2
2 8
5 1
10
899
2
2 8
5 2
11
1024
2
1 8
6 1
11
1025
2
1 8
6 2
12
1150
2
0 8
7 1
12
1151
2
0 8
7 2
18
0
157
2
3 0
4 1
0
156
2
3 0
4 0
1
170
2
3 1
4 0
1
171
2
3 1
4 1
2
184
2
3 2
4 0
2
185
2
3 2
4 1
3
198
2
3 3
4 0
3
199
2
3 3
4 1
4
213
2
3 4
4 1
4
212
2
3 4
4 0
5
226
2
3 5
4 0
5
227
2
3 5
4 1
6
240
2
3 6
4 0
6
241
2
3 6
4 1
7
254
2
3 7
4 0
7
255
2
3 7
4 1
8
268
2
3 8
4 0
8
269
2
3 8
4 1
18
0
283
2
2 0
5 1
0
282
2
2 0
5 0
1
296
2
2 1
5 0
1
297
2
2 1
5 1
2
310
2
2 2
5 0
2
311
2
2 2
5 1
3
324
2
2 3
5 0
3
325
2
2 3
5 1
4
339
2
2 4
5 1
4
338
2
2 4
5 0
5
352
2
2 5
5 0
5
353
2
2 5
5 1
6
366
2
2 6
5 0
6
367
2
2 6
5 1
7
380
2
2 7
5 0
7
381
2
2 7
5 1
8
394
2
2 8
5 0
8
395
2
2 8
5 1
18
0
409
2
1 0
6 1
0
408
2
1 0
6 0
1
422
2
1 1
6 0
1
423
2
1 1
6 1
2
436
2
1 2
6 0
2
437
2
1 2
6 1
3
450
2
1 3
6 0
3
451
2
1 3
6 1
4
465
2
1 4
6 1
4
464
2
1 4
6 0
5
478
2
1 5
6 0
5
479
2
1 5
6 1
6
492
2
1 6
6 0
6
493
2
1 6
6 1
7
506
2
1 7
6 0
7
507
2
1 7
6 1
8
520
2
1 8
6 0
8
521
2
1 8
6 1
18
0
535
2
0 0
7 1
0
534
2
0 0
7 0
1
548
2
0 1
7 0
1
549
2
0 1
7 1
2
562
2
0 2
7 0
2
563
2
0 2
7 1
3
576
2
0 3
7 0
3
577
2
0 3
7 1
4
591
2
0 4
7 1
4
590
2
0 4
7 0
5
604
2
0 5
7 0
5
605
2
0 5
7 1
6
618
2
0 6
7 0
6
619
2
0 6
7 1
7
632
2
0 7
7 0
7
633
2
0 7
7 1
8
646
2
0 8
7 0
8
647
2
0 8
7 1
end_DTG
begin_CG
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
6 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
5 252
8
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4 252
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
7
8 36
9 36
10 36
11 36
12 36
13 36
14 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
end_CG
