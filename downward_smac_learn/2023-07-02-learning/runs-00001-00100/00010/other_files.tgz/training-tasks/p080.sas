begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var19
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var18
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var20
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
19
5726
2
0 11
11 1
19
5727
2
0 11
11 2
12
14
3794
2
5 12
6 1
14
3795
2
5 12
6 2
15
4186
2
4 12
7 1
15
4187
2
4 12
7 2
16
4578
2
3 12
8 1
16
4579
2
3 12
8 2
17
4970
2
2 12
9 1
17
4971
2
2 12
9 2
18
5362
2
1 12
10 1
18
5363
2
1 12
10 2
19
5754
2
0 12
11 1
19
5755
2
0 12
11 2
12
14
3822
2
5 13
6 1
14
3823
2
5 13
6 2
15
4214
2
4 13
7 1
15
4215
2
4 13
7 2
16
4606
2
3 13
8 1
16
4607
2
3 13
8 2
17
4998
2
2 13
9 1
17
4999
2
2 13
9 2
18
5390
2
1 13
10 1
18
5391
2
1 13
10 2
19
5782
2
0 13
11 1
19
5783
2
0 13
11 2
28
0
1107
2
5 0
6 1
0
1106
2
5 0
6 0
1
1134
2
5 1
6 0
1
1135
2
5 1
6 1
2
1162
2
5 2
6 0
2
1163
2
5 2
6 1
3
1190
2
5 3
6 0
3
1191
2
5 3
6 1
4
1218
2
5 4
6 0
4
1219
2
5 4
6 1
5
1246
2
5 5
6 0
5
1247
2
5 5
6 1
6
1274
2
5 6
6 0
6
1275
2
5 6
6 1
7
1302
2
5 7
6 0
7
1303
2
5 7
6 1
8
1330
2
5 8
6 0
8
1331
2
5 8
6 1
9
1358
2
5 9
6 0
9
1359
2
5 9
6 1
10
1386
2
5 10
6 0
10
1387
2
5 10
6 1
11
1414
2
5 11
6 0
11
1415
2
5 11
6 1
12
1442
2
5 12
6 0
12
1443
2
5 12
6 1
13
1470
2
5 13
6 0
13
1471
2
5 13
6 1
28
0
1499
2
4 0
7 1
0
1498
2
4 0
7 0
1
1526
2
4 1
7 0
1
1527
2
4 1
7 1
2
1554
2
4 2
7 0
2
1555
2
4 2
7 1
3
1582
2
4 3
7 0
3
1583
2
4 3
7 1
4
1610
2
4 4
7 0
4
1611
2
4 4
7 1
5
1638
2
4 5
7 0
5
1639
2
4 5
7 1
6
1666
2
4 6
7 0
6
1667
2
4 6
7 1
7
1694
2
4 7
7 0
7
1695
2
4 7
7 1
8
1722
2
4 8
7 0
8
1723
2
4 8
7 1
9
1750
2
4 9
7 0
9
1751
2
4 9
7 1
10
1778
2
4 10
7 0
10
1779
2
4 10
7 1
11
1806
2
4 11
7 0
11
1807
2
4 11
7 1
12
1834
2
4 12
7 0
12
1835
2
4 12
7 1
13
1862
2
4 13
7 0
13
1863
2
4 13
7 1
28
0
1891
2
3 0
8 1
0
1890
2
3 0
8 0
1
1918
2
3 1
8 0
1
1919
2
3 1
8 1
2
1946
2
3 2
8 0
2
1947
2
3 2
8 1
3
1974
2
3 3
8 0
3
1975
2
3 3
8 1
4
2002
2
3 4
8 0
4
2003
2
3 4
8 1
5
2030
2
3 5
8 0
5
2031
2
3 5
8 1
6
2058
2
3 6
8 0
6
2059
2
3 6
8 1
7
2086
2
3 7
8 0
7
2087
2
3 7
8 1
8
2114
2
3 8
8 0
8
2115
2
3 8
8 1
9
2142
2
3 9
8 0
9
2143
2
3 9
8 1
10
2170
2
3 10
8 0
10
2171
2
3 10
8 1
11
2198
2
3 11
8 0
11
2199
2
3 11
8 1
12
2226
2
3 12
8 0
12
2227
2
3 12
8 1
13
2254
2
3 13
8 0
13
2255
2
3 13
8 1
28
0
2283
2
2 0
9 1
0
2282
2
2 0
9 0
1
2310
2
2 1
9 0
1
2311
2
2 1
9 1
2
2338
2
2 2
9 0
2
2339
2
2 2
9 1
3
2366
2
2 3
9 0
3
2367
2
2 3
9 1
4
2394
2
2 4
9 0
4
2395
2
2 4
9 1
5
2422
2
2 5
9 0
5
2423
2
2 5
9 1
6
2450
2
2 6
9 0
6
2451
2
2 6
9 1
7
2478
2
2 7
9 0
7
2479
2
2 7
9 1
8
2506
2
2 8
9 0
8
2507
2
2 8
9 1
9
2534
2
2 9
9 0
9
2535
2
2 9
9 1
10
2562
2
2 10
9 0
10
2563
2
2 10
9 1
11
2590
2
2 11
9 0
11
2591
2
2 11
9 1
12
2618
2
2 12
9 0
12
2619
2
2 12
9 1
13
2646
2
2 13
9 0
13
2647
2
2 13
9 1
28
0
2675
2
1 0
10 1
0
2674
2
1 0
10 0
1
2702
2
1 1
10 0
1
2703
2
1 1
10 1
2
2730
2
1 2
10 0
2
2731
2
1 2
10 1
3
2758
2
1 3
10 0
3
2759
2
1 3
10 1
4
2786
2
1 4
10 0
4
2787
2
1 4
10 1
5
2814
2
1 5
10 0
5
2815
2
1 5
10 1
6
2842
2
1 6
10 0
6
2843
2
1 6
10 1
7
2870
2
1 7
10 0
7
2871
2
1 7
10 1
8
2898
2
1 8
10 0
8
2899
2
1 8
10 1
9
2926
2
1 9
10 0
9
2927
2
1 9
10 1
10
2954
2
1 10
10 0
10
2955
2
1 10
10 1
11
2982
2
1 11
10 0
11
2983
2
1 11
10 1
12
3010
2
1 12
10 0
12
3011
2
1 12
10 1
13
3038
2
1 13
10 0
13
3039
2
1 13
10 1
28
0
3067
2
0 0
11 1
0
3066
2
0 0
11 0
1
3094
2
0 1
11 0
1
3095
2
0 1
11 1
2
3122
2
0 2
11 0
2
3123
2
0 2
11 1
3
3150
2
0 3
11 0
3
3151
2
0 3
11 1
4
3178
2
0 4
11 0
4
3179
2
0 4
11 1
5
3206
2
0 5
11 0
5
3207
2
0 5
11 1
6
3234
2
0 6
11 0
6
3235
2
0 6
11 1
7
3262
2
0 7
11 0
7
3263
2
0 7
11 1
8
3290
2
0 8
11 0
8
3291
2
0 8
11 1
9
3318
2
0 9
11 0
9
3319
2
0 9
11 1
10
3346
2
0 10
11 0
10
3347
2
0 10
11 1
11
3374
2
0 11
11 0
11
3375
2
0 11
11 1
12
3402
2
0 12
11 0
12
3403
2
0 12
11 1
13
3430
2
0 13
11 0
13
3431
2
0 13
11 1
end_DTG
begin_CG
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
11 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
10 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
9 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
8 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
7 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
6 784
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
