begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var8
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var5
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var9
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var10
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
0
begin_state
7
0
1
2
2
1
1
2
7
4
5
7
5
end_state
begin_goal
5
8 4
9 6
10 2
11 0
12 0
end_goal
824
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 3 6 5
0
end_operator
begin_operator
drive v1 l8 l2
0
1
0 3 7 1
0
end_operator
begin_operator
drive v1 l8 l3
0
1
0 3 7 2
0
end_operator
begin_operator
drive v1 l8 l4
0
1
0 3 7 3
0
end_operator
begin_operator
drive v1 l8 l5
0
1
0 3 7 4
0
end_operator
begin_operator
drive v1 l8 l6
0
1
0 3 7 5
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 2 0 3
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
1
359
2
1 1
6 1
2
368
2
1 2
6 0
2
369
2
1 2
6 1
3
378
2
1 3
6 0
3
379
2
1 3
6 1
4
388
2
1 4
6 0
4
389
2
1 4
6 1
5
398
2
1 5
6 0
5
399
2
1 5
6 1
6
408
2
1 6
6 0
6
409
2
1 6
6 1
7
418
2
1 7
6 0
7
419
2
1 7
6 1
16
0
428
2
0 0
7 0
0
429
2
0 0
7 1
1
438
2
0 1
7 0
1
439
2
0 1
7 1
2
448
2
0 2
7 0
2
449
2
0 2
7 1
3
458
2
0 3
7 0
3
459
2
0 3
7 1
4
468
2
0 4
7 0
4
469
2
0 4
7 1
5
478
2
0 5
7 0
5
479
2
0 5
7 1
6
488
2
0 6
7 0
6
489
2
0 6
7 1
7
498
2
0 7
7 0
7
499
2
0 7
7 1
end_DTG
begin_DTG
8
8
510
2
3 0
4 1
8
511
2
3 0
4 2
9
590
2
2 0
5 1
9
591
2
2 0
5 2
10
670
2
1 0
6 1
10
671
2
1 0
6 2
11
750
2
0 0
7 1
11
751
2
0 0
7 2
8
8
520
2
3 1
4 1
8
521
2
3 1
4 2
9
600
2
2 1
5 1
9
601
2
2 1
5 2
10
680
2
1 1
6 1
10
681
2
1 1
6 2
11
760
2
0 1
7 1
11
761
2
0 1
7 2
8
8
530
2
3 2
4 1
8
531
2
3 2
4 2
9
610
2
2 2
5 1
9
611
2
2 2
5 2
10
690
2
1 2
6 1
10
691
2
1 2
6 2
11
770
2
0 2
7 1
11
771
2
0 2
7 2
8
8
540
2
3 3
4 1
8
541
2
3 3
4 2
9
620
2
2 3
5 1
9
621
2
2 3
5 2
10
700
2
1 3
6 1
10
701
2
1 3
6 2
11
780
2
0 3
7 1
11
781
2
0 3
7 2
8
8
550
2
3 4
4 1
8
551
2
3 4
4 2
9
630
2
2 4
5 1
9
631
2
2 4
5 2
10
710
2
1 4
6 1
10
711
2
1 4
6 2
11
790
2
0 4
7 1
11
791
2
0 4
7 2
8
8
560
2
3 5
4 1
8
561
2
3 5
4 2
9
640
2
2 5
5 1
9
641
2
2 5
5 2
10
720
2
1 5
6 1
10
721
2
1 5
6 2
11
800
2
0 5
7 1
11
801
2
0 5
7 2
8
8
570
2
3 6
4 1
8
571
2
3 6
4 2
9
650
2
2 6
5 1
9
651
2
2 6
5 2
10
730
2
1 6
6 1
10
731
2
1 6
6 2
11
810
2
0 6
7 1
11
811
2
0 6
7 2
8
8
580
2
3 7
4 1
8
581
2
3 7
4 2
9
660
2
2 7
5 1
9
661
2
2 7
5 2
10
740
2
1 7
6 1
10
741
2
1 7
6 2
11
820
2
0 7
7 1
11
821
2
0 7
7 2
16
0
190
2
3 0
4 0
0
191
2
3 0
4 1
1
200
2
3 1
4 0
1
201
2
3 1
4 1
2
210
2
3 2
4 0
2
211
2
3 2
4 1
3
220
2
3 3
4 0
3
221
2
3 3
4 1
4
230
2
3 4
4 0
4
231
2
3 4
4 1
5
240
2
3 5
4 0
5
241
2
3 5
4 1
6
250
2
3 6
4 0
6
251
2
3 6
4 1
7
260
2
3 7
4 0
7
261
2
3 7
4 1
16
0
270
2
2 0
5 0
0
271
2
2 0
5 1
1
280
2
2 1
5 0
1
281
2
2 1
5 1
2
290
2
2 2
5 0
2
291
2
2 2
5 1
3
300
2
2 3
5 0
3
301
2
2 3
5 1
4
310
2
2 4
5 0
4
311
2
2 4
5 1
5
320
2
2 5
5 0
5
321
2
2 5
5 1
6
330
2
2 6
5 0
6
331
2
2 6
5 1
7
340
2
2 7
5 0
7
341
2
2 7
5 1
16
0
350
2
1 0
6 0
0
351
2
1 0
6 1
1
360
2
1 1
6 0
1
361
2
1 1
6 1
2
370
2
1 2
6 0
2
371
2
1 2
6 1
3
380
2
1 3
6 0
3
381
2
1 3
6 1
4
390
2
1 4
6 0
4
391
2
1 4
6 1
5
400
2
1 5
6 0
5
401
2
1 5
6 1
6
410
2
1 6
6 0
6
411
2
1 6
6 1
7
420
2
1 7
6 0
7
421
2
1 7
6 1
16
0
430
2
0 0
7 0
0
431
2
0 0
7 1
1
440
2
0 1
7 0
1
441
2
0 1
7 1
2
450
2
0 2
7 0
2
451
2
0 2
7 1
3
460
2
0 3
7 0
3
461
2
0 3
7 1
4
470
2
0 4
7 0
4
471
2
0 4
7 1
5
480
2
0 5
7 0
5
481
2
0 5
7 1
6
490
2
0 6
7 0
6
491
2
0 6
7 1
7
500
2
0 7
7 0
7
501
2
0 7
7 1
end_DTG
begin_DTG
8
8
512
2
3 0
4 1
8
513
2
3 0
4 2
9
592
2
2 0
5 1
9
593
2
2 0
5 2
10
672
2
1 0
6 1
10
673
2
1 0
6 2
11
752
2
0 0
7 1
11
753
2
0 0
7 2
8
8
522
2
3 1
4 1
8
523
2
3 1
4 2
9
602
2
2 1
5 1
9
603
2
2 1
5 2
10
682
2
1 1
6 1
10
683
2
1 1
6 2
11
762
2
0 1
7 1
11
763
2
0 1
7 2
8
8
532
2
3 2
4 1
8
533
2
3 2
4 2
9
612
2
2 2
5 1
9
613
2
2 2
5 2
10
692
2
1 2
6 1
10
693
2
1 2
6 2
11
772
2
0 2
7 1
11
773
2
0 2
7 2
8
8
542
2
3 3
4 1
8
543
2
3 3
4 2
9
622
2
2 3
5 1
9
623
2
2 3
5 2
10
702
2
1 3
6 1
10
703
2
1 3
6 2
11
782
2
0 3
7 1
11
783
2
0 3
7 2
8
8
552
2
3 4
4 1
8
553
2
3 4
4 2
9
632
2
2 4
5 1
9
633
2
2 4
5 2
10
712
2
1 4
6 1
10
713
2
1 4
6 2
11
792
2
0 4
7 1
11
793
2
0 4
7 2
8
8
562
2
3 5
4 1
8
563
2
3 5
4 2
9
642
2
2 5
5 1
9
643
2
2 5
5 2
10
722
2
1 5
6 1
10
723
2
1 5
6 2
11
802
2
0 5
7 1
11
803
2
0 5
7 2
8
8
572
2
3 6
4 1
8
573
2
3 6
4 2
9
652
2
2 6
5 1
9
653
2
2 6
5 2
10
732
2
1 6
6 1
10
733
2
1 6
6 2
11
812
2
0 6
7 1
11
813
2
0 6
7 2
8
8
582
2
3 7
4 1
8
583
2
3 7
4 2
9
662
2
2 7
5 1
9
663
2
2 7
5 2
10
742
2
1 7
6 1
10
743
2
1 7
6 2
11
822
2
0 7
7 1
11
823
2
0 7
7 2
16
0
192
2
3 0
4 0
0
193
2
3 0
4 1
1
202
2
3 1
4 0
1
203
2
3 1
4 1
2
212
2
3 2
4 0
2
213
2
3 2
4 1
3
222
2
3 3
4 0
3
223
2
3 3
4 1
4
232
2
3 4
4 0
4
233
2
3 4
4 1
5
242
2
3 5
4 0
5
243
2
3 5
4 1
6
252
2
3 6
4 0
6
253
2
3 6
4 1
7
262
2
3 7
4 0
7
263
2
3 7
4 1
16
0
272
2
2 0
5 0
0
273
2
2 0
5 1
1
282
2
2 1
5 0
1
283
2
2 1
5 1
2
292
2
2 2
5 0
2
293
2
2 2
5 1
3
302
2
2 3
5 0
3
303
2
2 3
5 1
4
312
2
2 4
5 0
4
313
2
2 4
5 1
5
322
2
2 5
5 0
5
323
2
2 5
5 1
6
332
2
2 6
5 0
6
333
2
2 6
5 1
7
342
2
2 7
5 0
7
343
2
2 7
5 1
16
0
352
2
1 0
6 0
0
353
2
1 0
6 1
1
362
2
1 1
6 0
1
363
2
1 1
6 1
2
372
2
1 2
6 0
2
373
2
1 2
6 1
3
382
2
1 3
6 0
3
383
2
1 3
6 1
4
392
2
1 4
6 0
4
393
2
1 4
6 1
5
402
2
1 5
6 0
5
403
2
1 5
6 1
6
412
2
1 6
6 0
6
413
2
1 6
6 1
7
422
2
1 7
6 0
7
423
2
1 7
6 1
16
0
432
2
0 0
7 0
0
433
2
0 0
7 1
1
442
2
0 1
7 0
1
443
2
0 1
7 1
2
452
2
0 2
7 0
2
453
2
0 2
7 1
3
462
2
0 3
7 0
3
463
2
0 3
7 1
4
472
2
0 4
7 0
4
473
2
0 4
7 1
5
482
2
0 5
7 0
5
483
2
0 5
7 1
6
492
2
0 6
7 0
6
493
2
0 6
7 1
7
502
2
0 7
7 0
7
503
2
0 7
7 1
end_DTG
begin_CG
6
8 32
9 32
10 32
11 32
12 32
7 160
6
8 32
9 32
10 32
11 32
12 32
6 160
6
8 32
9 32
10 32
11 32
12 32
5 160
6
8 32
9 32
10 32
11 32
12 32
4 160
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
