begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var8
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var5
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var9
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var10
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
0
begin_state
2
7
5
7
1
1
1
1
5
5
6
7
6
end_state
begin_goal
5
8 0
9 4
10 1
11 1
12 4
end_goal
848
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 3 6 5
0
end_operator
begin_operator
drive v1 l7 l8
0
1
0 3 6 7
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
end_operator
begin_operator
drive v1 l8 l3
0
1
0 3 7 2
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
1
383
2
1 1
6 1
2
392
2
1 2
6 0
2
393
2
1 2
6 1
3
402
2
1 3
6 0
3
403
2
1 3
6 1
4
412
2
1 4
6 0
4
413
2
1 4
6 1
5
422
2
1 5
6 0
5
423
2
1 5
6 1
6
432
2
1 6
6 0
6
433
2
1 6
6 1
7
442
2
1 7
6 0
7
443
2
1 7
6 1
16
0
452
2
0 0
7 0
0
453
2
0 0
7 1
1
462
2
0 1
7 0
1
463
2
0 1
7 1
2
472
2
0 2
7 0
2
473
2
0 2
7 1
3
482
2
0 3
7 0
3
483
2
0 3
7 1
4
492
2
0 4
7 0
4
493
2
0 4
7 1
5
502
2
0 5
7 0
5
503
2
0 5
7 1
6
512
2
0 6
7 0
6
513
2
0 6
7 1
7
522
2
0 7
7 0
7
523
2
0 7
7 1
end_DTG
begin_DTG
8
8
534
2
3 0
4 1
8
535
2
3 0
4 2
9
614
2
2 0
5 1
9
615
2
2 0
5 2
10
694
2
1 0
6 1
10
695
2
1 0
6 2
11
774
2
0 0
7 1
11
775
2
0 0
7 2
8
8
544
2
3 1
4 1
8
545
2
3 1
4 2
9
624
2
2 1
5 1
9
625
2
2 1
5 2
10
704
2
1 1
6 1
10
705
2
1 1
6 2
11
784
2
0 1
7 1
11
785
2
0 1
7 2
8
8
554
2
3 2
4 1
8
555
2
3 2
4 2
9
634
2
2 2
5 1
9
635
2
2 2
5 2
10
714
2
1 2
6 1
10
715
2
1 2
6 2
11
794
2
0 2
7 1
11
795
2
0 2
7 2
8
8
564
2
3 3
4 1
8
565
2
3 3
4 2
9
644
2
2 3
5 1
9
645
2
2 3
5 2
10
724
2
1 3
6 1
10
725
2
1 3
6 2
11
804
2
0 3
7 1
11
805
2
0 3
7 2
8
8
574
2
3 4
4 1
8
575
2
3 4
4 2
9
654
2
2 4
5 1
9
655
2
2 4
5 2
10
734
2
1 4
6 1
10
735
2
1 4
6 2
11
814
2
0 4
7 1
11
815
2
0 4
7 2
8
8
584
2
3 5
4 1
8
585
2
3 5
4 2
9
664
2
2 5
5 1
9
665
2
2 5
5 2
10
744
2
1 5
6 1
10
745
2
1 5
6 2
11
824
2
0 5
7 1
11
825
2
0 5
7 2
8
8
594
2
3 6
4 1
8
595
2
3 6
4 2
9
674
2
2 6
5 1
9
675
2
2 6
5 2
10
754
2
1 6
6 1
10
755
2
1 6
6 2
11
834
2
0 6
7 1
11
835
2
0 6
7 2
8
8
604
2
3 7
4 1
8
605
2
3 7
4 2
9
684
2
2 7
5 1
9
685
2
2 7
5 2
10
764
2
1 7
6 1
10
765
2
1 7
6 2
11
844
2
0 7
7 1
11
845
2
0 7
7 2
16
0
214
2
3 0
4 0
0
215
2
3 0
4 1
1
224
2
3 1
4 0
1
225
2
3 1
4 1
2
234
2
3 2
4 0
2
235
2
3 2
4 1
3
244
2
3 3
4 0
3
245
2
3 3
4 1
4
254
2
3 4
4 0
4
255
2
3 4
4 1
5
264
2
3 5
4 0
5
265
2
3 5
4 1
6
274
2
3 6
4 0
6
275
2
3 6
4 1
7
284
2
3 7
4 0
7
285
2
3 7
4 1
16
0
294
2
2 0
5 0
0
295
2
2 0
5 1
1
304
2
2 1
5 0
1
305
2
2 1
5 1
2
314
2
2 2
5 0
2
315
2
2 2
5 1
3
324
2
2 3
5 0
3
325
2
2 3
5 1
4
334
2
2 4
5 0
4
335
2
2 4
5 1
5
344
2
2 5
5 0
5
345
2
2 5
5 1
6
354
2
2 6
5 0
6
355
2
2 6
5 1
7
364
2
2 7
5 0
7
365
2
2 7
5 1
16
0
374
2
1 0
6 0
0
375
2
1 0
6 1
1
384
2
1 1
6 0
1
385
2
1 1
6 1
2
394
2
1 2
6 0
2
395
2
1 2
6 1
3
404
2
1 3
6 0
3
405
2
1 3
6 1
4
414
2
1 4
6 0
4
415
2
1 4
6 1
5
424
2
1 5
6 0
5
425
2
1 5
6 1
6
434
2
1 6
6 0
6
435
2
1 6
6 1
7
444
2
1 7
6 0
7
445
2
1 7
6 1
16
0
454
2
0 0
7 0
0
455
2
0 0
7 1
1
464
2
0 1
7 0
1
465
2
0 1
7 1
2
474
2
0 2
7 0
2
475
2
0 2
7 1
3
484
2
0 3
7 0
3
485
2
0 3
7 1
4
494
2
0 4
7 0
4
495
2
0 4
7 1
5
504
2
0 5
7 0
5
505
2
0 5
7 1
6
514
2
0 6
7 0
6
515
2
0 6
7 1
7
524
2
0 7
7 0
7
525
2
0 7
7 1
end_DTG
begin_DTG
8
8
536
2
3 0
4 1
8
537
2
3 0
4 2
9
616
2
2 0
5 1
9
617
2
2 0
5 2
10
696
2
1 0
6 1
10
697
2
1 0
6 2
11
776
2
0 0
7 1
11
777
2
0 0
7 2
8
8
546
2
3 1
4 1
8
547
2
3 1
4 2
9
626
2
2 1
5 1
9
627
2
2 1
5 2
10
706
2
1 1
6 1
10
707
2
1 1
6 2
11
786
2
0 1
7 1
11
787
2
0 1
7 2
8
8
556
2
3 2
4 1
8
557
2
3 2
4 2
9
636
2
2 2
5 1
9
637
2
2 2
5 2
10
716
2
1 2
6 1
10
717
2
1 2
6 2
11
796
2
0 2
7 1
11
797
2
0 2
7 2
8
8
566
2
3 3
4 1
8
567
2
3 3
4 2
9
646
2
2 3
5 1
9
647
2
2 3
5 2
10
726
2
1 3
6 1
10
727
2
1 3
6 2
11
806
2
0 3
7 1
11
807
2
0 3
7 2
8
8
576
2
3 4
4 1
8
577
2
3 4
4 2
9
656
2
2 4
5 1
9
657
2
2 4
5 2
10
736
2
1 4
6 1
10
737
2
1 4
6 2
11
816
2
0 4
7 1
11
817
2
0 4
7 2
8
8
586
2
3 5
4 1
8
587
2
3 5
4 2
9
666
2
2 5
5 1
9
667
2
2 5
5 2
10
746
2
1 5
6 1
10
747
2
1 5
6 2
11
826
2
0 5
7 1
11
827
2
0 5
7 2
8
8
596
2
3 6
4 1
8
597
2
3 6
4 2
9
676
2
2 6
5 1
9
677
2
2 6
5 2
10
756
2
1 6
6 1
10
757
2
1 6
6 2
11
836
2
0 6
7 1
11
837
2
0 6
7 2
8
8
606
2
3 7
4 1
8
607
2
3 7
4 2
9
686
2
2 7
5 1
9
687
2
2 7
5 2
10
766
2
1 7
6 1
10
767
2
1 7
6 2
11
846
2
0 7
7 1
11
847
2
0 7
7 2
16
0
216
2
3 0
4 0
0
217
2
3 0
4 1
1
226
2
3 1
4 0
1
227
2
3 1
4 1
2
236
2
3 2
4 0
2
237
2
3 2
4 1
3
246
2
3 3
4 0
3
247
2
3 3
4 1
4
256
2
3 4
4 0
4
257
2
3 4
4 1
5
266
2
3 5
4 0
5
267
2
3 5
4 1
6
276
2
3 6
4 0
6
277
2
3 6
4 1
7
286
2
3 7
4 0
7
287
2
3 7
4 1
16
0
296
2
2 0
5 0
0
297
2
2 0
5 1
1
306
2
2 1
5 0
1
307
2
2 1
5 1
2
316
2
2 2
5 0
2
317
2
2 2
5 1
3
326
2
2 3
5 0
3
327
2
2 3
5 1
4
336
2
2 4
5 0
4
337
2
2 4
5 1
5
346
2
2 5
5 0
5
347
2
2 5
5 1
6
356
2
2 6
5 0
6
357
2
2 6
5 1
7
366
2
2 7
5 0
7
367
2
2 7
5 1
16
0
376
2
1 0
6 0
0
377
2
1 0
6 1
1
386
2
1 1
6 0
1
387
2
1 1
6 1
2
396
2
1 2
6 0
2
397
2
1 2
6 1
3
406
2
1 3
6 0
3
407
2
1 3
6 1
4
416
2
1 4
6 0
4
417
2
1 4
6 1
5
426
2
1 5
6 0
5
427
2
1 5
6 1
6
436
2
1 6
6 0
6
437
2
1 6
6 1
7
446
2
1 7
6 0
7
447
2
1 7
6 1
16
0
456
2
0 0
7 0
0
457
2
0 0
7 1
1
466
2
0 1
7 0
1
467
2
0 1
7 1
2
476
2
0 2
7 0
2
477
2
0 2
7 1
3
486
2
0 3
7 0
3
487
2
0 3
7 1
4
496
2
0 4
7 0
4
497
2
0 4
7 1
5
506
2
0 5
7 0
5
507
2
0 5
7 1
6
516
2
0 6
7 0
6
517
2
0 6
7 1
7
526
2
0 7
7 0
7
527
2
0 7
7 1
end_DTG
begin_CG
6
8 32
9 32
10 32
11 32
12 32
7 160
6
8 32
9 32
10 32
11 32
12 32
6 160
6
8 32
9 32
10 32
11 32
12 32
5 160
6
8 32
9 32
10 32
11 32
12 32
4 160
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
