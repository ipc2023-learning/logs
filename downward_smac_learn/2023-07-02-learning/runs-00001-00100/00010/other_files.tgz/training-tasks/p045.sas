begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var11
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var10
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var8
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var12
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
14
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
14
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
14
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
14
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
14
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
14
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
14
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
begin_variable
var7
-1
14
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
end_variable
0
begin_state
4
4
1
0
1
2
1
1
9
5
7
2
9
2
7
8
end_state
begin_goal
8
8 8
9 4
10 8
11 0
12 5
13 3
14 6
15 7
end_goal
1456
begin_operator
drive v1 l1 l10
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l2
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 3 0 9
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l10 l5
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l10 l6
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l10 l7
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l10 l9
0
1
0 3 1 9
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 2 8
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 3 8
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 4 8
0
end_operator
begin_operator
drive v1 l5 l10
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 5 8
0
end_operator
begin_operator
drive v1 l5 l9
0
1
0 3 5 9
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l6 l10
0
1
0 3 6 1
0
end_operator
begi




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




6 2
13
1404
2
0 6
7 1
13
1405
2
0 6
7 2
8
10
940
2
3 7
4 1
10
941
2
3 7
4 2
11
1100
2
2 7
5 1
11
1101
2
2 7
5 2
12
1260
2
1 7
6 1
12
1261
2
1 7
6 2
13
1420
2
0 7
7 1
13
1421
2
0 7
7 2
8
10
956
2
3 8
4 1
10
957
2
3 8
4 2
11
1116
2
2 8
5 1
11
1117
2
2 8
5 2
12
1276
2
1 8
6 1
12
1277
2
1 8
6 2
13
1436
2
0 8
7 1
13
1437
2
0 8
7 2
8
10
972
2
3 9
4 1
10
973
2
3 9
4 2
11
1132
2
2 9
5 1
11
1133
2
2 9
5 2
12
1292
2
1 9
6 1
12
1293
2
1 9
6 2
13
1452
2
0 9
7 1
13
1453
2
0 9
7 2
20
0
189
2
3 0
4 1
0
188
2
3 0
4 0
1
204
2
3 1
4 0
1
205
2
3 1
4 1
2
220
2
3 2
4 0
2
221
2
3 2
4 1
3
236
2
3 3
4 0
3
237
2
3 3
4 1
4
252
2
3 4
4 0
4
253
2
3 4
4 1
5
268
2
3 5
4 0
5
269
2
3 5
4 1
6
284
2
3 6
4 0
6
285
2
3 6
4 1
7
300
2
3 7
4 0
7
301
2
3 7
4 1
8
316
2
3 8
4 0
8
317
2
3 8
4 1
9
332
2
3 9
4 0
9
333
2
3 9
4 1
20
0
349
2
2 0
5 1
0
348
2
2 0
5 0
1
364
2
2 1
5 0
1
365
2
2 1
5 1
2
380
2
2 2
5 0
2
381
2
2 2
5 1
3
396
2
2 3
5 0
3
397
2
2 3
5 1
4
412
2
2 4
5 0
4
413
2
2 4
5 1
5
428
2
2 5
5 0
5
429
2
2 5
5 1
6
444
2
2 6
5 0
6
445
2
2 6
5 1
7
460
2
2 7
5 0
7
461
2
2 7
5 1
8
476
2
2 8
5 0
8
477
2
2 8
5 1
9
492
2
2 9
5 0
9
493
2
2 9
5 1
20
0
509
2
1 0
6 1
0
508
2
1 0
6 0
1
524
2
1 1
6 0
1
525
2
1 1
6 1
2
540
2
1 2
6 0
2
541
2
1 2
6 1
3
556
2
1 3
6 0
3
557
2
1 3
6 1
4
572
2
1 4
6 0
4
573
2
1 4
6 1
5
588
2
1 5
6 0
5
589
2
1 5
6 1
6
604
2
1 6
6 0
6
605
2
1 6
6 1
7
620
2
1 7
6 0
7
621
2
1 7
6 1
8
636
2
1 8
6 0
8
637
2
1 8
6 1
9
652
2
1 9
6 0
9
653
2
1 9
6 1
20
0
669
2
0 0
7 1
0
668
2
0 0
7 0
1
684
2
0 1
7 0
1
685
2
0 1
7 1
2
700
2
0 2
7 0
2
701
2
0 2
7 1
3
716
2
0 3
7 0
3
717
2
0 3
7 1
4
732
2
0 4
7 0
4
733
2
0 4
7 1
5
748
2
0 5
7 0
5
749
2
0 5
7 1
6
764
2
0 6
7 0
6
765
2
0 6
7 1
7
780
2
0 7
7 0
7
781
2
0 7
7 1
8
796
2
0 8
7 0
8
797
2
0 8
7 1
9
812
2
0 9
7 0
9
813
2
0 9
7 1
end_DTG
begin_DTG
8
10
830
2
3 0
4 1
10
831
2
3 0
4 2
11
990
2
2 0
5 1
11
991
2
2 0
5 2
12
1150
2
1 0
6 1
12
1151
2
1 0
6 2
13
1310
2
0 0
7 1
13
1311
2
0 0
7 2
8
10
846
2
3 1
4 1
10
847
2
3 1
4 2
11
1006
2
2 1
5 1
11
1007
2
2 1
5 2
12
1166
2
1 1
6 1
12
1167
2
1 1
6 2
13
1326
2
0 1
7 1
13
1327
2
0 1
7 2
8
10
862
2
3 2
4 1
10
863
2
3 2
4 2
11
1022
2
2 2
5 1
11
1023
2
2 2
5 2
12
1182
2
1 2
6 1
12
1183
2
1 2
6 2
13
1342
2
0 2
7 1
13
1343
2
0 2
7 2
8
10
878
2
3 3
4 1
10
879
2
3 3
4 2
11
1038
2
2 3
5 1
11
1039
2
2 3
5 2
12
1198
2
1 3
6 1
12
1199
2
1 3
6 2
13
1358
2
0 3
7 1
13
1359
2
0 3
7 2
8
10
894
2
3 4
4 1
10
895
2
3 4
4 2
11
1054
2
2 4
5 1
11
1055
2
2 4
5 2
12
1214
2
1 4
6 1
12
1215
2
1 4
6 2
13
1374
2
0 4
7 1
13
1375
2
0 4
7 2
8
10
910
2
3 5
4 1
10
911
2
3 5
4 2
11
1070
2
2 5
5 1
11
1071
2
2 5
5 2
12
1230
2
1 5
6 1
12
1231
2
1 5
6 2
13
1390
2
0 5
7 1
13
1391
2
0 5
7 2
8
10
926
2
3 6
4 1
10
927
2
3 6
4 2
11
1086
2
2 6
5 1
11
1087
2
2 6
5 2
12
1246
2
1 6
6 1
12
1247
2
1 6
6 2
13
1406
2
0 6
7 1
13
1407
2
0 6
7 2
8
10
942
2
3 7
4 1
10
943
2
3 7
4 2
11
1102
2
2 7
5 1
11
1103
2
2 7
5 2
12
1262
2
1 7
6 1
12
1263
2
1 7
6 2
13
1422
2
0 7
7 1
13
1423
2
0 7
7 2
8
10
958
2
3 8
4 1
10
959
2
3 8
4 2
11
1118
2
2 8
5 1
11
1119
2
2 8
5 2
12
1278
2
1 8
6 1
12
1279
2
1 8
6 2
13
1438
2
0 8
7 1
13
1439
2
0 8
7 2
8
10
974
2
3 9
4 1
10
975
2
3 9
4 2
11
1134
2
2 9
5 1
11
1135
2
2 9
5 2
12
1294
2
1 9
6 1
12
1295
2
1 9
6 2
13
1454
2
0 9
7 1
13
1455
2
0 9
7 2
20
0
191
2
3 0
4 1
0
190
2
3 0
4 0
1
206
2
3 1
4 0
1
207
2
3 1
4 1
2
222
2
3 2
4 0
2
223
2
3 2
4 1
3
238
2
3 3
4 0
3
239
2
3 3
4 1
4
254
2
3 4
4 0
4
255
2
3 4
4 1
5
270
2
3 5
4 0
5
271
2
3 5
4 1
6
286
2
3 6
4 0
6
287
2
3 6
4 1
7
302
2
3 7
4 0
7
303
2
3 7
4 1
8
318
2
3 8
4 0
8
319
2
3 8
4 1
9
334
2
3 9
4 0
9
335
2
3 9
4 1
20
0
351
2
2 0
5 1
0
350
2
2 0
5 0
1
366
2
2 1
5 0
1
367
2
2 1
5 1
2
382
2
2 2
5 0
2
383
2
2 2
5 1
3
398
2
2 3
5 0
3
399
2
2 3
5 1
4
414
2
2 4
5 0
4
415
2
2 4
5 1
5
430
2
2 5
5 0
5
431
2
2 5
5 1
6
446
2
2 6
5 0
6
447
2
2 6
5 1
7
462
2
2 7
5 0
7
463
2
2 7
5 1
8
478
2
2 8
5 0
8
479
2
2 8
5 1
9
494
2
2 9
5 0
9
495
2
2 9
5 1
20
0
511
2
1 0
6 1
0
510
2
1 0
6 0
1
526
2
1 1
6 0
1
527
2
1 1
6 1
2
542
2
1 2
6 0
2
543
2
1 2
6 1
3
558
2
1 3
6 0
3
559
2
1 3
6 1
4
574
2
1 4
6 0
4
575
2
1 4
6 1
5
590
2
1 5
6 0
5
591
2
1 5
6 1
6
606
2
1 6
6 0
6
607
2
1 6
6 1
7
622
2
1 7
6 0
7
623
2
1 7
6 1
8
638
2
1 8
6 0
8
639
2
1 8
6 1
9
654
2
1 9
6 0
9
655
2
1 9
6 1
20
0
671
2
0 0
7 1
0
670
2
0 0
7 0
1
686
2
0 1
7 0
1
687
2
0 1
7 1
2
702
2
0 2
7 0
2
703
2
0 2
7 1
3
718
2
0 3
7 0
3
719
2
0 3
7 1
4
734
2
0 4
7 0
4
735
2
0 4
7 1
5
750
2
0 5
7 0
5
751
2
0 5
7 1
6
766
2
0 6
7 0
6
767
2
0 6
7 1
7
782
2
0 7
7 0
7
783
2
0 7
7 1
8
798
2
0 8
7 0
8
799
2
0 8
7 1
9
814
2
0 9
7 0
9
815
2
0 9
7 1
end_DTG
begin_CG
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
7 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
6 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
5 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
4 320
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
end_CG
