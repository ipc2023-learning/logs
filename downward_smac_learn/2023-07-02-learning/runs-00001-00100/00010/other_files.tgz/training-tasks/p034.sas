begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var9
-1
9
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var8
-1
9
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var7
-1
9
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var6
-1
9
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var10
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
13
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
13
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
13
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
13
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
13
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
13
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
0
begin_state
5
7
4
4
2
2
2
1
8
7
5
1
5
1
end_state
begin_goal
6
8 0
9 4
10 7
11 4
12 0
13 8
end_goal
928
begin_operator
drive v1 l1 l9
0
1
0 3 0 8
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l8 l5
0
1
0 3 7 4
0
end_operator
begin_operator
drive v1 l9 l1
0
1
0 3 8 0
0
end_operator
begin_operator
drive v1 l9 l2
0
1
0 3 8 1
0
end_operator
begin_operator
drive v2 l1 l9
0
1
0 2 0 8
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v2 l2 l9
0
1
0 2 1 8
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v2 l3 l7
0
1
0 2 2 6
0
end_operator
begin_operator
drive v2 l4 l7
0
1
0 2 3 6
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v2 l5 l8
0
1
0 2 4 7
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v2 l6 l5
0
1
0 2 5 4
0
end_operator
begin_operator
drive v2 l7 l3
0
1
0 2 6 2
0
end_operator
begin_operator
drive v2 l7 l4
0
1
0 2 6 3
0
end_operator
begin_operator
drive v2 l8 l5
0
1
0 2 7 4
0
end_operator
begin_operator
drive v2 l9 l1
0
1
0 2 8 0
0
end_operator
begin_operator
drive v2 l9 l2
0
1
0 2 8 1
0
end_operator
begin_operator
drive v3 l1 l9
0
1
0 1 0 8
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v3 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v3 l2 l9
0
1
0 1 1 8
0
end_operator
begin_operator
drive v3 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v3 l3 l7
0
1
0 1 2 6
0
end_operator
begin_operator
drive v3 l4 l7
0
1
0 1 3 6
0
end_operator
begin_operator
drive v3 l5 l6
0
1
0 1 4 5
0
end_operator
begin_operator
drive v3 l5 l8
0
1
0 1 4 7
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
7 2
8
9
516
2
3 1
4 1
9
517
2
3 1
4 2
10
624
2
2 1
5 1
10
625
2
2 1
5 2
11
732
2
1 1
6 1
11
733
2
1 1
6 2
12
840
2
0 1
7 1
12
841
2
0 1
7 2
8
9
528
2
3 2
4 1
9
529
2
3 2
4 2
10
636
2
2 2
5 1
10
637
2
2 2
5 2
11
744
2
1 2
6 1
11
745
2
1 2
6 2
12
852
2
0 2
7 1
12
853
2
0 2
7 2
8
9
540
2
3 3
4 1
9
541
2
3 3
4 2
10
648
2
2 3
5 1
10
649
2
2 3
5 2
11
756
2
1 3
6 1
11
757
2
1 3
6 2
12
864
2
0 3
7 1
12
865
2
0 3
7 2
8
9
552
2
3 4
4 1
9
553
2
3 4
4 2
10
660
2
2 4
5 1
10
661
2
2 4
5 2
11
768
2
1 4
6 1
11
769
2
1 4
6 2
12
876
2
0 4
7 1
12
877
2
0 4
7 2
8
9
564
2
3 5
4 1
9
565
2
3 5
4 2
10
672
2
2 5
5 1
10
673
2
2 5
5 2
11
780
2
1 5
6 1
11
781
2
1 5
6 2
12
888
2
0 5
7 1
12
889
2
0 5
7 2
8
9
576
2
3 6
4 1
9
577
2
3 6
4 2
10
684
2
2 6
5 1
10
685
2
2 6
5 2
11
792
2
1 6
6 1
11
793
2
1 6
6 2
12
900
2
0 6
7 1
12
901
2
0 6
7 2
8
9
588
2
3 7
4 1
9
589
2
3 7
4 2
10
696
2
2 7
5 1
10
697
2
2 7
5 2
11
804
2
1 7
6 1
11
805
2
1 7
6 2
12
912
2
0 7
7 1
12
913
2
0 7
7 2
8
9
600
2
3 8
4 1
9
601
2
3 8
4 2
10
708
2
2 8
5 1
10
709
2
2 8
5 2
11
816
2
1 8
6 1
11
817
2
1 8
6 2
12
924
2
0 8
7 1
12
925
2
0 8
7 2
18
0
73
2
3 0
4 1
0
72
2
3 0
4 0
1
84
2
3 1
4 0
1
85
2
3 1
4 1
2
96
2
3 2
4 0
2
97
2
3 2
4 1
3
108
2
3 3
4 0
3
109
2
3 3
4 1
4
121
2
3 4
4 1
4
120
2
3 4
4 0
5
132
2
3 5
4 0
5
133
2
3 5
4 1
6
144
2
3 6
4 0
6
145
2
3 6
4 1
7
156
2
3 7
4 0
7
157
2
3 7
4 1
8
168
2
3 8
4 0
8
169
2
3 8
4 1
18
0
181
2
2 0
5 1
0
180
2
2 0
5 0
1
192
2
2 1
5 0
1
193
2
2 1
5 1
2
204
2
2 2
5 0
2
205
2
2 2
5 1
3
216
2
2 3
5 0
3
217
2
2 3
5 1
4
229
2
2 4
5 1
4
228
2
2 4
5 0
5
240
2
2 5
5 0
5
241
2
2 5
5 1
6
252
2
2 6
5 0
6
253
2
2 6
5 1
7
264
2
2 7
5 0
7
265
2
2 7
5 1
8
276
2
2 8
5 0
8
277
2
2 8
5 1
18
0
289
2
1 0
6 1
0
288
2
1 0
6 0
1
300
2
1 1
6 0
1
301
2
1 1
6 1
2
312
2
1 2
6 0
2
313
2
1 2
6 1
3
324
2
1 3
6 0
3
325
2
1 3
6 1
4
337
2
1 4
6 1
4
336
2
1 4
6 0
5
348
2
1 5
6 0
5
349
2
1 5
6 1
6
360
2
1 6
6 0
6
361
2
1 6
6 1
7
372
2
1 7
6 0
7
373
2
1 7
6 1
8
384
2
1 8
6 0
8
385
2
1 8
6 1
18
0
397
2
0 0
7 1
0
396
2
0 0
7 0
1
408
2
0 1
7 0
1
409
2
0 1
7 1
2
420
2
0 2
7 0
2
421
2
0 2
7 1
3
432
2
0 3
7 0
3
433
2
0 3
7 1
4
445
2
0 4
7 1
4
444
2
0 4
7 0
5
456
2
0 5
7 0
5
457
2
0 5
7 1
6
468
2
0 6
7 0
6
469
2
0 6
7 1
7
480
2
0 7
7 0
7
481
2
0 7
7 1
8
492
2
0 8
7 0
8
493
2
0 8
7 1
end_DTG
begin_DTG
8
9
506
2
3 0
4 1
9
507
2
3 0
4 2
10
614
2
2 0
5 1
10
615
2
2 0
5 2
11
722
2
1 0
6 1
11
723
2
1 0
6 2
12
830
2
0 0
7 1
12
831
2
0 0
7 2
8
9
518
2
3 1
4 1
9
519
2
3 1
4 2
10
626
2
2 1
5 1
10
627
2
2 1
5 2
11
734
2
1 1
6 1
11
735
2
1 1
6 2
12
842
2
0 1
7 1
12
843
2
0 1
7 2
8
9
530
2
3 2
4 1
9
531
2
3 2
4 2
10
638
2
2 2
5 1
10
639
2
2 2
5 2
11
746
2
1 2
6 1
11
747
2
1 2
6 2
12
854
2
0 2
7 1
12
855
2
0 2
7 2
8
9
542
2
3 3
4 1
9
543
2
3 3
4 2
10
650
2
2 3
5 1
10
651
2
2 3
5 2
11
758
2
1 3
6 1
11
759
2
1 3
6 2
12
866
2
0 3
7 1
12
867
2
0 3
7 2
8
9
554
2
3 4
4 1
9
555
2
3 4
4 2
10
662
2
2 4
5 1
10
663
2
2 4
5 2
11
770
2
1 4
6 1
11
771
2
1 4
6 2
12
878
2
0 4
7 1
12
879
2
0 4
7 2
8
9
566
2
3 5
4 1
9
567
2
3 5
4 2
10
674
2
2 5
5 1
10
675
2
2 5
5 2
11
782
2
1 5
6 1
11
783
2
1 5
6 2
12
890
2
0 5
7 1
12
891
2
0 5
7 2
8
9
578
2
3 6
4 1
9
579
2
3 6
4 2
10
686
2
2 6
5 1
10
687
2
2 6
5 2
11
794
2
1 6
6 1
11
795
2
1 6
6 2
12
902
2
0 6
7 1
12
903
2
0 6
7 2
8
9
590
2
3 7
4 1
9
591
2
3 7
4 2
10
698
2
2 7
5 1
10
699
2
2 7
5 2
11
806
2
1 7
6 1
11
807
2
1 7
6 2
12
914
2
0 7
7 1
12
915
2
0 7
7 2
8
9
602
2
3 8
4 1
9
603
2
3 8
4 2
10
710
2
2 8
5 1
10
711
2
2 8
5 2
11
818
2
1 8
6 1
11
819
2
1 8
6 2
12
926
2
0 8
7 1
12
927
2
0 8
7 2
18
0
75
2
3 0
4 1
0
74
2
3 0
4 0
1
86
2
3 1
4 0
1
87
2
3 1
4 1
2
98
2
3 2
4 0
2
99
2
3 2
4 1
3
110
2
3 3
4 0
3
111
2
3 3
4 1
4
123
2
3 4
4 1
4
122
2
3 4
4 0
5
134
2
3 5
4 0
5
135
2
3 5
4 1
6
146
2
3 6
4 0
6
147
2
3 6
4 1
7
158
2
3 7
4 0
7
159
2
3 7
4 1
8
170
2
3 8
4 0
8
171
2
3 8
4 1
18
0
183
2
2 0
5 1
0
182
2
2 0
5 0
1
194
2
2 1
5 0
1
195
2
2 1
5 1
2
206
2
2 2
5 0
2
207
2
2 2
5 1
3
218
2
2 3
5 0
3
219
2
2 3
5 1
4
231
2
2 4
5 1
4
230
2
2 4
5 0
5
242
2
2 5
5 0
5
243
2
2 5
5 1
6
254
2
2 6
5 0
6
255
2
2 6
5 1
7
266
2
2 7
5 0
7
267
2
2 7
5 1
8
278
2
2 8
5 0
8
279
2
2 8
5 1
18
0
291
2
1 0
6 1
0
290
2
1 0
6 0
1
302
2
1 1
6 0
1
303
2
1 1
6 1
2
314
2
1 2
6 0
2
315
2
1 2
6 1
3
326
2
1 3
6 0
3
327
2
1 3
6 1
4
339
2
1 4
6 1
4
338
2
1 4
6 0
5
350
2
1 5
6 0
5
351
2
1 5
6 1
6
362
2
1 6
6 0
6
363
2
1 6
6 1
7
374
2
1 7
6 0
7
375
2
1 7
6 1
8
386
2
1 8
6 0
8
387
2
1 8
6 1
18
0
399
2
0 0
7 1
0
398
2
0 0
7 0
1
410
2
0 1
7 0
1
411
2
0 1
7 1
2
422
2
0 2
7 0
2
423
2
0 2
7 1
3
434
2
0 3
7 0
3
435
2
0 3
7 1
4
447
2
0 4
7 1
4
446
2
0 4
7 0
5
458
2
0 5
7 0
5
459
2
0 5
7 1
6
470
2
0 6
7 0
6
471
2
0 6
7 1
7
482
2
0 7
7 0
7
483
2
0 7
7 1
8
494
2
0 8
7 0
8
495
2
0 8
7 1
end_DTG
begin_CG
7
8 36
9 36
10 36
11 36
12 36
13 36
7 216
7
8 36
9 36
10 36
11 36
12 36
13 36
6 216
7
8 36
9 36
10 36
11 36
12 36
13 36
5 216
7
8 36
9 36
10 36
11 36
12 36
13 36
4 216
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
end_CG
