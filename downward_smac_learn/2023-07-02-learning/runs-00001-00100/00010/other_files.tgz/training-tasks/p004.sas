begin_version
3
end_version
begin_metric
0
end_metric
3
begin_variable
var1
-1
3
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
end_variable
begin_variable
var2
-1
2
Atom capacity(v1, c0)
Atom capacity(v1, c1)
end_variable
begin_variable
var0
-1
4
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom in(p1, v1)
end_variable
0
begin_state
2
1
0
end_state
begin_goal
1
2 1
end_goal
10
begin_operator
drive v1 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
0 0
2
0 2 3 0
0 1 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
0 1
2
0 2 3 1
0 1 0 1
0
end_operator
begin_operator
drop v1 l3 p1 c0 c1
1
0 2
2
0 2 3 2
0 1 0 1
0
end_operator
begin_operator
pick-up v1 l1 p1 c0 c1
1
0 0
2
0 2 0 3
0 1 1 0
0
end_operator
begin_operator
pick-up v1 l2 p1 c0 c1
1
0 1
2
0 2 1 3
0 1 1 0
0
end_operator
begin_operator
pick-up v1 l3 p1 c0 c1
1
0 2
2
0 2 2 3
0 1 1 0
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 1
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 0
check 1
8
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 0
check 1
9
check 0
check 0
switch 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 2
1
2
check 1
3
check 0
end_SG
begin_DTG
1
1
0
0
2
0
1
0
2
2
0
1
1
3
0
end_DTG
begin_DTG
3
1
4
2
2 3
0 0
1
5
2
2 3
0 1
1
6
2
2 3
0 2
3
0
7
2
2 0
0 0
0
8
2
2 1
0 1
0
9
2
2 2
0 2
end_DTG
begin_DTG
1
3
7
2
0 0
1 1
1
3
8
2
0 1
1 1
1
3
9
2
0 2
1 1
3
0
4
2
0 0
1 0
1
5
2
0 1
1 0
2
6
2
0 2
1 0
end_DTG
begin_CG
2
2 6
1 6
1
2 6
1
1 6
end_CG
