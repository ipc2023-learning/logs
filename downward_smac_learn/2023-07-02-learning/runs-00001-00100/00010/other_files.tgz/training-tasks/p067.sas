begin_version
3
end_version
begin_metric
0
end_metric
22
begin_variable
var16
-1
13
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var15
-1
13
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var14
-1
13
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var13
-1
13
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var12
-1
13
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var17
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
18
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
18
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
18
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
end_variable
begin_variable
var3
-1
18
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
end_variable
begin_variable
var4
-1
18
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var5
-1
18
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var6
-1
18
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var7
-1
18
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l13)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var8
-1
18
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l13)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var9
-1
18
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l13)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8
2
2 3
7 1
15
2409
2
2 3
7 2
16
2720
2
1 3
8 1
16
2721
2
1 3
8 2
17
3032
2
0 3
9 1
17
3033
2
0 3
9 2
10
13
1808
2
4 4
5 1
13
1809
2
4 4
5 2
14
2120
2
3 4
6 1
14
2121
2
3 4
6 2
15
2432
2
2 4
7 1
15
2433
2
2 4
7 2
16
2744
2
1 4
8 1
16
2745
2
1 4
8 2
17
3056
2
0 4
9 1
17
3057
2
0 4
9 2
10
13
1832
2
4 5
5 1
13
1833
2
4 5
5 2
14
2144
2
3 5
6 1
14
2145
2
3 5
6 2
15
2456
2
2 5
7 1
15
2457
2
2 5
7 2
16
2768
2
1 5
8 1
16
2769
2
1 5
8 2
17
3080
2
0 5
9 1
17
3081
2
0 5
9 2
10
13
1856
2
4 6
5 1
13
1857
2
4 6
5 2
14
2168
2
3 6
6 1
14
2169
2
3 6
6 2
15
2480
2
2 6
7 1
15
2481
2
2 6
7 2
16
2792
2
1 6
8 1
16
2793
2
1 6
8 2
17
3104
2
0 6
9 1
17
3105
2
0 6
9 2
10
13
1880
2
4 7
5 1
13
1881
2
4 7
5 2
14
2192
2
3 7
6 1
14
2193
2
3 7
6 2
15
2504
2
2 7
7 1
15
2505
2
2 7
7 2
16
2816
2
1 7
8 1
16
2817
2
1 7
8 2
17
3128
2
0 7
9 1
17
3129
2
0 7
9 2
10
13
1904
2
4 8
5 1
13
1905
2
4 8
5 2
14
2216
2
3 8
6 1
14
2217
2
3 8
6 2
15
2528
2
2 8
7 1
15
2529
2
2 8
7 2
16
2840
2
1 8
8 1
16
2841
2
1 8
8 2
17
3152
2
0 8
9 1
17
3153
2
0 8
9 2
10
13
1928
2
4 9
5 1
13
1929
2
4 9
5 2
14
2240
2
3 9
6 1
14
2241
2
3 9
6 2
15
2552
2
2 9
7 1
15
2553
2
2 9
7 2
16
2864
2
1 9
8 1
16
2865
2
1 9
8 2
17
3176
2
0 9
9 1
17
3177
2
0 9
9 2
10
13
1952
2
4 10
5 1
13
1953
2
4 10
5 2
14
2264
2
3 10
6 1
14
2265
2
3 10
6 2
15
2576
2
2 10
7 1
15
2577
2
2 10
7 2
16
2888
2
1 10
8 1
16
2889
2
1 10
8 2
17
3200
2
0 10
9 1
17
3201
2
0 10
9 2
10
13
1976
2
4 11
5 1
13
1977
2
4 11
5 2
14
2288
2
3 11
6 1
14
2289
2
3 11
6 2
15
2600
2
2 11
7 1
15
2601
2
2 11
7 2
16
2912
2
1 11
8 1
16
2913
2
1 11
8 2
17
3224
2
0 11
9 1
17
3225
2
0 11
9 2
10
13
2000
2
4 12
5 1
13
2001
2
4 12
5 2
14
2312
2
3 12
6 1
14
2313
2
3 12
6 2
15
2624
2
2 12
7 1
15
2625
2
2 12
7 2
16
2936
2
1 12
8 1
16
2937
2
1 12
8 2
17
3248
2
0 12
9 1
17
3249
2
0 12
9 2
26
0
153
2
4 0
5 1
0
152
2
4 0
5 0
1
176
2
4 1
5 0
1
177
2
4 1
5 1
2
200
2
4 2
5 0
2
201
2
4 2
5 1
3
224
2
4 3
5 0
3
225
2
4 3
5 1
4
248
2
4 4
5 0
4
249
2
4 4
5 1
5
272
2
4 5
5 0
5
273
2
4 5
5 1
6
297
2
4 6
5 1
6
296
2
4 6
5 0
7
320
2
4 7
5 0
7
321
2
4 7
5 1
8
344
2
4 8
5 0
8
345
2
4 8
5 1
9
368
2
4 9
5 0
9
369
2
4 9
5 1
10
392
2
4 10
5 0
10
393
2
4 10
5 1
11
416
2
4 11
5 0
11
417
2
4 11
5 1
12
440
2
4 12
5 0
12
441
2
4 12
5 1
26
0
465
2
3 0
6 1
0
464
2
3 0
6 0
1
488
2
3 1
6 0
1
489
2
3 1
6 1
2
512
2
3 2
6 0
2
513
2
3 2
6 1
3
536
2
3 3
6 0
3
537
2
3 3
6 1
4
560
2
3 4
6 0
4
561
2
3 4
6 1
5
584
2
3 5
6 0
5
585
2
3 5
6 1
6
609
2
3 6
6 1
6
608
2
3 6
6 0
7
632
2
3 7
6 0
7
633
2
3 7
6 1
8
656
2
3 8
6 0
8
657
2
3 8
6 1
9
680
2
3 9
6 0
9
681
2
3 9
6 1
10
704
2
3 10
6 0
10
705
2
3 10
6 1
11
728
2
3 11
6 0
11
729
2
3 11
6 1
12
752
2
3 12
6 0
12
753
2
3 12
6 1
26
0
777
2
2 0
7 1
0
776
2
2 0
7 0
1
800
2
2 1
7 0
1
801
2
2 1
7 1
2
824
2
2 2
7 0
2
825
2
2 2
7 1
3
848
2
2 3
7 0
3
849
2
2 3
7 1
4
872
2
2 4
7 0
4
873
2
2 4
7 1
5
896
2
2 5
7 0
5
897
2
2 5
7 1
6
921
2
2 6
7 1
6
920
2
2 6
7 0
7
944
2
2 7
7 0
7
945
2
2 7
7 1
8
968
2
2 8
7 0
8
969
2
2 8
7 1
9
992
2
2 9
7 0
9
993
2
2 9
7 1
10
1016
2
2 10
7 0
10
1017
2
2 10
7 1
11
1040
2
2 11
7 0
11
1041
2
2 11
7 1
12
1064
2
2 12
7 0
12
1065
2
2 12
7 1
26
0
1089
2
1 0
8 1
0
1088
2
1 0
8 0
1
1112
2
1 1
8 0
1
1113
2
1 1
8 1
2
1136
2
1 2
8 0
2
1137
2
1 2
8 1
3
1160
2
1 3
8 0
3
1161
2
1 3
8 1
4
1184
2
1 4
8 0
4
1185
2
1 4
8 1
5
1208
2
1 5
8 0
5
1209
2
1 5
8 1
6
1233
2
1 6
8 1
6
1232
2
1 6
8 0
7
1256
2
1 7
8 0
7
1257
2
1 7
8 1
8
1280
2
1 8
8 0
8
1281
2
1 8
8 1
9
1304
2
1 9
8 0
9
1305
2
1 9
8 1
10
1328
2
1 10
8 0
10
1329
2
1 10
8 1
11
1352
2
1 11
8 0
11
1353
2
1 11
8 1
12
1376
2
1 12
8 0
12
1377
2
1 12
8 1
26
0
1401
2
0 0
9 1
0
1400
2
0 0
9 0
1
1424
2
0 1
9 0
1
1425
2
0 1
9 1
2
1448
2
0 2
9 0
2
1449
2
0 2
9 1
3
1472
2
0 3
9 0
3
1473
2
0 3
9 1
4
1496
2
0 4
9 0
4
1497
2
0 4
9 1
5
1520
2
0 5
9 0
5
1521
2
0 5
9 1
6
1545
2
0 6
9 1
6
1544
2
0 6
9 0
7
1568
2
0 7
9 0
7
1569
2
0 7
9 1
8
1592
2
0 8
9 0
8
1593
2
0 8
9 1
9
1616
2
0 9
9 0
9
1617
2
0 9
9 1
10
1640
2
0 10
9 0
10
1641
2
0 10
9 1
11
1664
2
0 11
9 0
11
1665
2
0 11
9 1
12
1688
2
0 12
9 0
12
1689
2
0 12
9 1
end_DTG
begin_CG
13
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
9 624
13
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
8 624
13
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
7 624
13
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
6 624
13
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
5 624
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
end_CG
