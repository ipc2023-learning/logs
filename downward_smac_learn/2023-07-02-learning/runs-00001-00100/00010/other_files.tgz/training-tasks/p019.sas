begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var6
-1
7
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
end_variable
begin_variable
var5
-1
7
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
end_variable
begin_variable
var4
-1
7
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
end_variable
begin_variable
var7
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var9
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
10
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
10
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
10
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
begin_variable
var3
-1
10
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
end_variable
0
begin_state
0
2
3
2
2
1
2
1
6
3
end_state
begin_goal
4
6 4
7 2
8 0
9 1
end_goal
396
begin_operator
drive v1 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 2 2 3
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 2 2 5
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 2 3 2
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 2 3 6
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 2 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 2 5 2
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 2 5 4
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 2 6 3
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 1 0 5
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v2 l3 l4
0
1
0 1 2 3
0
end_operator
begin_operator
drive v2 l3 l6
0
1
0 1 2 5
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l3
0
1
0 1 3 2
0
end_operator
begin_operator
drive v2 l4 l7
0
1
0 1 3 6
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 1 4 5
0
end_operator
begin_operator
drive v2 l6 l1
0
1
0 1 5 0
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 1 5 1
0
end_operator
begin_operator
drive v2 l6 l3
0
1
0 1 5 2
0
end_operator
begin_operator
drive v2 l6 l5
0
1
0 1 5 4
0
end_operator
begin_operator
drive v2 l7 l4
0
1
0 1 6 3
0
end_operator
begin_operator
drive v3 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l6
0
1
0 0 0 5
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v3 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v3 l2 l6
0
1
0 0 1 5
0
end_operator
begin_operator
drive v3 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drive v3 l3 l4
0
1
0 0 2 3
0
end_operator
begin_operator
drive v3 l3 l6
0
1
0 0 2 5
0
end_operator
begin_operator
drive v3 l4 l1
0
1
0 0 3 0
0
end_operator
begin_operator
drive v3 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drive v3 l4 l3
0
1
0 0 3 2
0
end_operator
begin_operator
drive v3 l4 l7
0
1
0 0 3 6
0
end_operator
begin_operator
drive v3 l5 l1
0
1
0 0 4 0
0
end_operator
begin_operator
drive v3 l5 l6
0
1
0 0 4 5
0
end_operator
begin_operator
drive v3 l6 l1
0
1
0 0 5 0
0
end_operator
begin_operator
drive v3 l6 l2
0
1
0 0 5 1
0
end_operator
begin_operator
drive v3 l6 l3
0
1
0 0 5 2
0
end_operator
begin_operator
drive v3 l6 l5
0
1
0 0 5 4
0
end_operator
begin_operator
drive v3 l7 l4
0
1
0 0 6 3
0
end_operator




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
7
277
2
2 6
3 2
8
332
2
1 6
4 1
8
333
2
1 6
4 2
9
388
2
0 6
5 1
9
389
2
0 6
5 2
14
0
60
2
2 0
3 0
0
61
2
2 0
3 1
1
68
2
2 1
3 0
1
69
2
2 1
3 1
2
76
2
2 2
3 0
2
77
2
2 2
3 1
3
84
2
2 3
3 0
3
85
2
2 3
3 1
4
92
2
2 4
3 0
4
93
2
2 4
3 1
5
100
2
2 5
3 0
5
101
2
2 5
3 1
6
108
2
2 6
3 0
6
109
2
2 6
3 1
14
0
116
2
1 0
4 0
0
117
2
1 0
4 1
1
124
2
1 1
4 0
1
125
2
1 1
4 1
2
132
2
1 2
4 0
2
133
2
1 2
4 1
3
140
2
1 3
4 0
3
141
2
1 3
4 1
4
148
2
1 4
4 0
4
149
2
1 4
4 1
5
156
2
1 5
4 0
5
157
2
1 5
4 1
6
164
2
1 6
4 0
6
165
2
1 6
4 1
14
0
172
2
0 0
5 0
0
173
2
0 0
5 1
1
180
2
0 1
5 0
1
181
2
0 1
5 1
2
188
2
0 2
5 0
2
189
2
0 2
5 1
3
196
2
0 3
5 0
3
197
2
0 3
5 1
4
204
2
0 4
5 0
4
205
2
0 4
5 1
5
212
2
0 5
5 0
5
213
2
0 5
5 1
6
220
2
0 6
5 0
6
221
2
0 6
5 1
end_DTG
begin_DTG
6
7
230
2
2 0
3 1
7
231
2
2 0
3 2
8
286
2
1 0
4 1
8
287
2
1 0
4 2
9
342
2
0 0
5 1
9
343
2
0 0
5 2
6
7
238
2
2 1
3 1
7
239
2
2 1
3 2
8
294
2
1 1
4 1
8
295
2
1 1
4 2
9
350
2
0 1
5 1
9
351
2
0 1
5 2
6
7
246
2
2 2
3 1
7
247
2
2 2
3 2
8
302
2
1 2
4 1
8
303
2
1 2
4 2
9
358
2
0 2
5 1
9
359
2
0 2
5 2
6
7
254
2
2 3
3 1
7
255
2
2 3
3 2
8
310
2
1 3
4 1
8
311
2
1 3
4 2
9
366
2
0 3
5 1
9
367
2
0 3
5 2
6
7
262
2
2 4
3 1
7
263
2
2 4
3 2
8
318
2
1 4
4 1
8
319
2
1 4
4 2
9
374
2
0 4
5 1
9
375
2
0 4
5 2
6
7
270
2
2 5
3 1
7
271
2
2 5
3 2
8
326
2
1 5
4 1
8
327
2
1 5
4 2
9
382
2
0 5
5 1
9
383
2
0 5
5 2
6
7
278
2
2 6
3 1
7
279
2
2 6
3 2
8
334
2
1 6
4 1
8
335
2
1 6
4 2
9
390
2
0 6
5 1
9
391
2
0 6
5 2
14
0
62
2
2 0
3 0
0
63
2
2 0
3 1
1
70
2
2 1
3 0
1
71
2
2 1
3 1
2
78
2
2 2
3 0
2
79
2
2 2
3 1
3
86
2
2 3
3 0
3
87
2
2 3
3 1
4
94
2
2 4
3 0
4
95
2
2 4
3 1
5
102
2
2 5
3 0
5
103
2
2 5
3 1
6
110
2
2 6
3 0
6
111
2
2 6
3 1
14
0
118
2
1 0
4 0
0
119
2
1 0
4 1
1
126
2
1 1
4 0
1
127
2
1 1
4 1
2
134
2
1 2
4 0
2
135
2
1 2
4 1
3
142
2
1 3
4 0
3
143
2
1 3
4 1
4
150
2
1 4
4 0
4
151
2
1 4
4 1
5
158
2
1 5
4 0
5
159
2
1 5
4 1
6
166
2
1 6
4 0
6
167
2
1 6
4 1
14
0
174
2
0 0
5 0
0
175
2
0 0
5 1
1
182
2
0 1
5 0
1
183
2
0 1
5 1
2
190
2
0 2
5 0
2
191
2
0 2
5 1
3
198
2
0 3
5 0
3
199
2
0 3
5 1
4
206
2
0 4
5 0
4
207
2
0 4
5 1
5
214
2
0 5
5 0
5
215
2
0 5
5 1
6
222
2
0 6
5 0
6
223
2
0 6
5 1
end_DTG
begin_DTG
6
7
232
2
2 0
3 1
7
233
2
2 0
3 2
8
288
2
1 0
4 1
8
289
2
1 0
4 2
9
344
2
0 0
5 1
9
345
2
0 0
5 2
6
7
240
2
2 1
3 1
7
241
2
2 1
3 2
8
296
2
1 1
4 1
8
297
2
1 1
4 2
9
352
2
0 1
5 1
9
353
2
0 1
5 2
6
7
248
2
2 2
3 1
7
249
2
2 2
3 2
8
304
2
1 2
4 1
8
305
2
1 2
4 2
9
360
2
0 2
5 1
9
361
2
0 2
5 2
6
7
256
2
2 3
3 1
7
257
2
2 3
3 2
8
312
2
1 3
4 1
8
313
2
1 3
4 2
9
368
2
0 3
5 1
9
369
2
0 3
5 2
6
7
264
2
2 4
3 1
7
265
2
2 4
3 2
8
320
2
1 4
4 1
8
321
2
1 4
4 2
9
376
2
0 4
5 1
9
377
2
0 4
5 2
6
7
272
2
2 5
3 1
7
273
2
2 5
3 2
8
328
2
1 5
4 1
8
329
2
1 5
4 2
9
384
2
0 5
5 1
9
385
2
0 5
5 2
6
7
280
2
2 6
3 1
7
281
2
2 6
3 2
8
336
2
1 6
4 1
8
337
2
1 6
4 2
9
392
2
0 6
5 1
9
393
2
0 6
5 2
14
0
64
2
2 0
3 0
0
65
2
2 0
3 1
1
72
2
2 1
3 0
1
73
2
2 1
3 1
2
80
2
2 2
3 0
2
81
2
2 2
3 1
3
88
2
2 3
3 0
3
89
2
2 3
3 1
4
96
2
2 4
3 0
4
97
2
2 4
3 1
5
104
2
2 5
3 0
5
105
2
2 5
3 1
6
112
2
2 6
3 0
6
113
2
2 6
3 1
14
0
120
2
1 0
4 0
0
121
2
1 0
4 1
1
128
2
1 1
4 0
1
129
2
1 1
4 1
2
136
2
1 2
4 0
2
137
2
1 2
4 1
3
144
2
1 3
4 0
3
145
2
1 3
4 1
4
152
2
1 4
4 0
4
153
2
1 4
4 1
5
160
2
1 5
4 0
5
161
2
1 5
4 1
6
168
2
1 6
4 0
6
169
2
1 6
4 1
14
0
176
2
0 0
5 0
0
177
2
0 0
5 1
1
184
2
0 1
5 0
1
185
2
0 1
5 1
2
192
2
0 2
5 0
2
193
2
0 2
5 1
3
200
2
0 3
5 0
3
201
2
0 3
5 1
4
208
2
0 4
5 0
4
209
2
0 4
5 1
5
216
2
0 5
5 0
5
217
2
0 5
5 1
6
224
2
0 6
5 0
6
225
2
0 6
5 1
end_DTG
begin_DTG
6
7
234
2
2 0
3 1
7
235
2
2 0
3 2
8
290
2
1 0
4 1
8
291
2
1 0
4 2
9
346
2
0 0
5 1
9
347
2
0 0
5 2
6
7
242
2
2 1
3 1
7
243
2
2 1
3 2
8
298
2
1 1
4 1
8
299
2
1 1
4 2
9
354
2
0 1
5 1
9
355
2
0 1
5 2
6
7
250
2
2 2
3 1
7
251
2
2 2
3 2
8
306
2
1 2
4 1
8
307
2
1 2
4 2
9
362
2
0 2
5 1
9
363
2
0 2
5 2
6
7
258
2
2 3
3 1
7
259
2
2 3
3 2
8
314
2
1 3
4 1
8
315
2
1 3
4 2
9
370
2
0 3
5 1
9
371
2
0 3
5 2
6
7
266
2
2 4
3 1
7
267
2
2 4
3 2
8
322
2
1 4
4 1
8
323
2
1 4
4 2
9
378
2
0 4
5 1
9
379
2
0 4
5 2
6
7
274
2
2 5
3 1
7
275
2
2 5
3 2
8
330
2
1 5
4 1
8
331
2
1 5
4 2
9
386
2
0 5
5 1
9
387
2
0 5
5 2
6
7
282
2
2 6
3 1
7
283
2
2 6
3 2
8
338
2
1 6
4 1
8
339
2
1 6
4 2
9
394
2
0 6
5 1
9
395
2
0 6
5 2
14
0
66
2
2 0
3 0
0
67
2
2 0
3 1
1
74
2
2 1
3 0
1
75
2
2 1
3 1
2
82
2
2 2
3 0
2
83
2
2 2
3 1
3
90
2
2 3
3 0
3
91
2
2 3
3 1
4
98
2
2 4
3 0
4
99
2
2 4
3 1
5
106
2
2 5
3 0
5
107
2
2 5
3 1
6
114
2
2 6
3 0
6
115
2
2 6
3 1
14
0
122
2
1 0
4 0
0
123
2
1 0
4 1
1
130
2
1 1
4 0
1
131
2
1 1
4 1
2
138
2
1 2
4 0
2
139
2
1 2
4 1
3
146
2
1 3
4 0
3
147
2
1 3
4 1
4
154
2
1 4
4 0
4
155
2
1 4
4 1
5
162
2
1 5
4 0
5
163
2
1 5
4 1
6
170
2
1 6
4 0
6
171
2
1 6
4 1
14
0
178
2
0 0
5 0
0
179
2
0 0
5 1
1
186
2
0 1
5 0
1
187
2
0 1
5 1
2
194
2
0 2
5 0
2
195
2
0 2
5 1
3
202
2
0 3
5 0
3
203
2
0 3
5 1
4
210
2
0 4
5 0
4
211
2
0 4
5 1
5
218
2
0 5
5 0
5
219
2
0 5
5 1
6
226
2
0 6
5 0
6
227
2
0 6
5 1
end_DTG
begin_CG
5
6 28
7 28
8 28
9 28
5 112
5
6 28
7 28
8 28
9 28
4 112
5
6 28
7 28
8 28
9 28
3 112
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
end_CG
