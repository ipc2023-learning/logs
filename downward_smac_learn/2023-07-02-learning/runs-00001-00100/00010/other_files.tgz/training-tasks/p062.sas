begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var15
-1
12
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var14
-1
12
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var13
-1
12
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var12
-1
12
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var11
-1
12
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var16
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
17
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
17
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
17
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
end_variable
begin_variable
var3
-1
17
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var4
-1
17
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var5
-1
17
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var6
-1
17
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var7
-1
17
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var8
-1
17
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var9
-1
17
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var10
-1
17
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l12)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 1
16
2627
2
0 0
9 2
10
12
1592
2
4 1
5 1
12
1593
2
4 1
5 2
13
1856
2
3 1
6 1
13
1857
2
3 1
6 2
14
2120
2
2 1
7 1
14
2121
2
2 1
7 2
15
2384
2
1 1
8 1
15
2385
2
1 1
8 2
16
2648
2
0 1
9 1
16
2649
2
0 1
9 2
10
12
1614
2
4 2
5 1
12
1615
2
4 2
5 2
13
1878
2
3 2
6 1
13
1879
2
3 2
6 2
14
2142
2
2 2
7 1
14
2143
2
2 2
7 2
15
2406
2
1 2
8 1
15
2407
2
1 2
8 2
16
2670
2
0 2
9 1
16
2671
2
0 2
9 2
10
12
1636
2
4 3
5 1
12
1637
2
4 3
5 2
13
1900
2
3 3
6 1
13
1901
2
3 3
6 2
14
2164
2
2 3
7 1
14
2165
2
2 3
7 2
15
2428
2
1 3
8 1
15
2429
2
1 3
8 2
16
2692
2
0 3
9 1
16
2693
2
0 3
9 2
10
12
1658
2
4 4
5 1
12
1659
2
4 4
5 2
13
1922
2
3 4
6 1
13
1923
2
3 4
6 2
14
2186
2
2 4
7 1
14
2187
2
2 4
7 2
15
2450
2
1 4
8 1
15
2451
2
1 4
8 2
16
2714
2
0 4
9 1
16
2715
2
0 4
9 2
10
12
1680
2
4 5
5 1
12
1681
2
4 5
5 2
13
1944
2
3 5
6 1
13
1945
2
3 5
6 2
14
2208
2
2 5
7 1
14
2209
2
2 5
7 2
15
2472
2
1 5
8 1
15
2473
2
1 5
8 2
16
2736
2
0 5
9 1
16
2737
2
0 5
9 2
10
12
1702
2
4 6
5 1
12
1703
2
4 6
5 2
13
1966
2
3 6
6 1
13
1967
2
3 6
6 2
14
2230
2
2 6
7 1
14
2231
2
2 6
7 2
15
2494
2
1 6
8 1
15
2495
2
1 6
8 2
16
2758
2
0 6
9 1
16
2759
2
0 6
9 2
10
12
1724
2
4 7
5 1
12
1725
2
4 7
5 2
13
1988
2
3 7
6 1
13
1989
2
3 7
6 2
14
2252
2
2 7
7 1
14
2253
2
2 7
7 2
15
2516
2
1 7
8 1
15
2517
2
1 7
8 2
16
2780
2
0 7
9 1
16
2781
2
0 7
9 2
10
12
1746
2
4 8
5 1
12
1747
2
4 8
5 2
13
2010
2
3 8
6 1
13
2011
2
3 8
6 2
14
2274
2
2 8
7 1
14
2275
2
2 8
7 2
15
2538
2
1 8
8 1
15
2539
2
1 8
8 2
16
2802
2
0 8
9 1
16
2803
2
0 8
9 2
10
12
1768
2
4 9
5 1
12
1769
2
4 9
5 2
13
2032
2
3 9
6 1
13
2033
2
3 9
6 2
14
2296
2
2 9
7 1
14
2297
2
2 9
7 2
15
2560
2
1 9
8 1
15
2561
2
1 9
8 2
16
2824
2
0 9
9 1
16
2825
2
0 9
9 2
10
12
1790
2
4 10
5 1
12
1791
2
4 10
5 2
13
2054
2
3 10
6 1
13
2055
2
3 10
6 2
14
2318
2
2 10
7 1
14
2319
2
2 10
7 2
15
2582
2
1 10
8 1
15
2583
2
1 10
8 2
16
2846
2
0 10
9 1
16
2847
2
0 10
9 2
10
12
1812
2
4 11
5 1
12
1813
2
4 11
5 2
13
2076
2
3 11
6 1
13
2077
2
3 11
6 2
14
2340
2
2 11
7 1
14
2341
2
2 11
7 2
15
2604
2
1 11
8 1
15
2605
2
1 11
8 2
16
2868
2
0 11
9 1
16
2869
2
0 11
9 2
24
0
251
2
4 0
5 1
0
250
2
4 0
5 0
1
272
2
4 1
5 0
1
273
2
4 1
5 1
2
294
2
4 2
5 0
2
295
2
4 2
5 1
3
316
2
4 3
5 0
3
317
2
4 3
5 1
4
338
2
4 4
5 0
4
339
2
4 4
5 1
5
360
2
4 5
5 0
5
361
2
4 5
5 1
6
382
2
4 6
5 0
6
383
2
4 6
5 1
7
404
2
4 7
5 0
7
405
2
4 7
5 1
8
426
2
4 8
5 0
8
427
2
4 8
5 1
9
448
2
4 9
5 0
9
449
2
4 9
5 1
10
470
2
4 10
5 0
10
471
2
4 10
5 1
11
492
2
4 11
5 0
11
493
2
4 11
5 1
24
0
515
2
3 0
6 1
0
514
2
3 0
6 0
1
536
2
3 1
6 0
1
537
2
3 1
6 1
2
558
2
3 2
6 0
2
559
2
3 2
6 1
3
580
2
3 3
6 0
3
581
2
3 3
6 1
4
602
2
3 4
6 0
4
603
2
3 4
6 1
5
624
2
3 5
6 0
5
625
2
3 5
6 1
6
646
2
3 6
6 0
6
647
2
3 6
6 1
7
668
2
3 7
6 0
7
669
2
3 7
6 1
8
690
2
3 8
6 0
8
691
2
3 8
6 1
9
712
2
3 9
6 0
9
713
2
3 9
6 1
10
734
2
3 10
6 0
10
735
2
3 10
6 1
11
756
2
3 11
6 0
11
757
2
3 11
6 1
24
0
779
2
2 0
7 1
0
778
2
2 0
7 0
1
800
2
2 1
7 0
1
801
2
2 1
7 1
2
822
2
2 2
7 0
2
823
2
2 2
7 1
3
844
2
2 3
7 0
3
845
2
2 3
7 1
4
866
2
2 4
7 0
4
867
2
2 4
7 1
5
888
2
2 5
7 0
5
889
2
2 5
7 1
6
910
2
2 6
7 0
6
911
2
2 6
7 1
7
932
2
2 7
7 0
7
933
2
2 7
7 1
8
954
2
2 8
7 0
8
955
2
2 8
7 1
9
976
2
2 9
7 0
9
977
2
2 9
7 1
10
998
2
2 10
7 0
10
999
2
2 10
7 1
11
1020
2
2 11
7 0
11
1021
2
2 11
7 1
24
0
1043
2
1 0
8 1
0
1042
2
1 0
8 0
1
1064
2
1 1
8 0
1
1065
2
1 1
8 1
2
1086
2
1 2
8 0
2
1087
2
1 2
8 1
3
1108
2
1 3
8 0
3
1109
2
1 3
8 1
4
1130
2
1 4
8 0
4
1131
2
1 4
8 1
5
1152
2
1 5
8 0
5
1153
2
1 5
8 1
6
1174
2
1 6
8 0
6
1175
2
1 6
8 1
7
1196
2
1 7
8 0
7
1197
2
1 7
8 1
8
1218
2
1 8
8 0
8
1219
2
1 8
8 1
9
1240
2
1 9
8 0
9
1241
2
1 9
8 1
10
1262
2
1 10
8 0
10
1263
2
1 10
8 1
11
1284
2
1 11
8 0
11
1285
2
1 11
8 1
24
0
1307
2
0 0
9 1
0
1306
2
0 0
9 0
1
1328
2
0 1
9 0
1
1329
2
0 1
9 1
2
1350
2
0 2
9 0
2
1351
2
0 2
9 1
3
1372
2
0 3
9 0
3
1373
2
0 3
9 1
4
1394
2
0 4
9 0
4
1395
2
0 4
9 1
5
1416
2
0 5
9 0
5
1417
2
0 5
9 1
6
1438
2
0 6
9 0
6
1439
2
0 6
9 1
7
1460
2
0 7
9 0
7
1461
2
0 7
9 1
8
1482
2
0 8
9 0
8
1483
2
0 8
9 1
9
1504
2
0 9
9 0
9
1505
2
0 9
9 1
10
1526
2
0 10
9 0
10
1527
2
0 10
9 1
11
1548
2
0 11
9 0
11
1549
2
0 11
9 1
end_DTG
begin_CG
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
9 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
8 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
7 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
6 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5 528
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
end_CG
