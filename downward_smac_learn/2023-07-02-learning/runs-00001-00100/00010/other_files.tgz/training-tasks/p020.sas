begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var6
-1
7
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
end_variable
begin_variable
var5
-1
7
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
end_variable
begin_variable
var4
-1
7
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
end_variable
begin_variable
var7
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var9
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
10
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
10
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
10
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
begin_variable
var3
-1
10
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
end_variable
0
begin_state
0
5
6
2
1
1
6
2
2
2
end_state
begin_goal
4
6 5
7 5
8 1
9 6
end_goal
384
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 2 0 6
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 2 2 3
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 2 2 5
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 2 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 2 4 6
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 2 5 2
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 2 5 6
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 2 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 2 6 1
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 2 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 2 6 5
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l7
0
1
0 1 0 6
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 1 1 6
0
end_operator
begin_operator
drive v2 l3 l4
0
1
0 1 2 3
0
end_operator
begin_operator
drive v2 l3 l6
0
1
0 1 2 5
0
end_operator
begin_operator
drive v2 l4 l3
0
1
0 1 3 2
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l5 l7
0
1
0 1 4 6
0
end_operator
begin_operator
drive v2 l6 l3
0
1
0 1 5 2
0
end_operator
begin_operator
drive v2 l6 l7
0
1
0 1 5 6
0
end_operator
begin_operator
drive v2 l7 l1
0
1
0 1 6 0
0
end_operator
begin_operator
drive v2 l7 l2
0
1
0 1 6 1
0
end_operator
begin_operator
drive v2 l7 l5
0
1
0 1 6 4
0
end_operator
begin_operator
drive v2 l7 l6
0
1
0 1 6 5
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l7
0
1
0 0 0 6
0
end_operator
begin_operator
drive v3 l2 l7
0
1
0 0 1 6
0
end_operator
begin_operator
drive v3 l3 l4
0
1
0 0 2 3
0
end_operator
begin_operator
drive v3 l3 l6
0
1
0 0 2 5
0
end_operator
begin_operator
drive v3 l4 l3
0
1
0 0 3 2
0
end_operator
begin_operator
drive v3 l4 l5
0
1
0 0 3 4
0
end_operator
begin_operator
drive v3 l5 l1
0
1
0 0 4 0
0
end_operator
begin_operator
drive v3 l5 l4
0
1
0 0 4 3
0
end_operator
begin_operator
drive v3 l5 l7
0
1
0 0 4 6
0
end_operator
begin_operator
drive v3 l6 l3
0
1
0 0 5 2
0
end_operator
begin_operator
drive v3 l6 l7
0
1
0 0 5 6
0
end_operator
begin_operator
drive v3 l7 l1
0
1
0 0 6 0
0
end_operator
begin_operator
drive v3 l7 l2
0
1
0 0 6 1
0
end_operator
begin_operator
drive v3 l7 l5
0
1
0 0 6 4
0
end_operator
begin_operator
drive v3 l7 l6
0
1
0 0 6 5
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
2 0
2
0 6 7 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
2 0
2
0 6 7 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
2 0
2
0 7 7 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
2 0
2
0 7 7 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p3 c0 c1
1
2 0
2
0 8 7 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p3 c1 c2
1
2 0
2
0 8 7 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p4 c0 c1
1
2 0
2
0 9 7 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p4 c1 c2
1
2 0
2
0 9 7 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
2 1
2
0 6 7 1
0 3 0 1
0
end_operator
begin_operator
dr




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




264
2
2 6
3 1
7
265
2
2 6
3 2
8
320
2
1 6
4 1
8
321
2
1 6
4 2
9
376
2
0 6
5 1
9
377
2
0 6
5 2
14
0
48
2
2 0
3 0
0
49
2
2 0
3 1
1
56
2
2 1
3 0
1
57
2
2 1
3 1
2
64
2
2 2
3 0
2
65
2
2 2
3 1
3
72
2
2 3
3 0
3
73
2
2 3
3 1
4
80
2
2 4
3 0
4
81
2
2 4
3 1
5
88
2
2 5
3 0
5
89
2
2 5
3 1
6
96
2
2 6
3 0
6
97
2
2 6
3 1
14
0
104
2
1 0
4 0
0
105
2
1 0
4 1
1
112
2
1 1
4 0
1
113
2
1 1
4 1
2
120
2
1 2
4 0
2
121
2
1 2
4 1
3
128
2
1 3
4 0
3
129
2
1 3
4 1
4
136
2
1 4
4 0
4
137
2
1 4
4 1
5
144
2
1 5
4 0
5
145
2
1 5
4 1
6
152
2
1 6
4 0
6
153
2
1 6
4 1
14
0
160
2
0 0
5 0
0
161
2
0 0
5 1
1
168
2
0 1
5 0
1
169
2
0 1
5 1
2
176
2
0 2
5 0
2
177
2
0 2
5 1
3
184
2
0 3
5 0
3
185
2
0 3
5 1
4
192
2
0 4
5 0
4
193
2
0 4
5 1
5
200
2
0 5
5 0
5
201
2
0 5
5 1
6
208
2
0 6
5 0
6
209
2
0 6
5 1
end_DTG
begin_DTG
6
7
218
2
2 0
3 1
7
219
2
2 0
3 2
8
274
2
1 0
4 1
8
275
2
1 0
4 2
9
330
2
0 0
5 1
9
331
2
0 0
5 2
6
7
226
2
2 1
3 1
7
227
2
2 1
3 2
8
282
2
1 1
4 1
8
283
2
1 1
4 2
9
338
2
0 1
5 1
9
339
2
0 1
5 2
6
7
234
2
2 2
3 1
7
235
2
2 2
3 2
8
290
2
1 2
4 1
8
291
2
1 2
4 2
9
346
2
0 2
5 1
9
347
2
0 2
5 2
6
7
242
2
2 3
3 1
7
243
2
2 3
3 2
8
298
2
1 3
4 1
8
299
2
1 3
4 2
9
354
2
0 3
5 1
9
355
2
0 3
5 2
6
7
250
2
2 4
3 1
7
251
2
2 4
3 2
8
306
2
1 4
4 1
8
307
2
1 4
4 2
9
362
2
0 4
5 1
9
363
2
0 4
5 2
6
7
258
2
2 5
3 1
7
259
2
2 5
3 2
8
314
2
1 5
4 1
8
315
2
1 5
4 2
9
370
2
0 5
5 1
9
371
2
0 5
5 2
6
7
266
2
2 6
3 1
7
267
2
2 6
3 2
8
322
2
1 6
4 1
8
323
2
1 6
4 2
9
378
2
0 6
5 1
9
379
2
0 6
5 2
14
0
50
2
2 0
3 0
0
51
2
2 0
3 1
1
58
2
2 1
3 0
1
59
2
2 1
3 1
2
66
2
2 2
3 0
2
67
2
2 2
3 1
3
74
2
2 3
3 0
3
75
2
2 3
3 1
4
82
2
2 4
3 0
4
83
2
2 4
3 1
5
90
2
2 5
3 0
5
91
2
2 5
3 1
6
98
2
2 6
3 0
6
99
2
2 6
3 1
14
0
106
2
1 0
4 0
0
107
2
1 0
4 1
1
114
2
1 1
4 0
1
115
2
1 1
4 1
2
122
2
1 2
4 0
2
123
2
1 2
4 1
3
130
2
1 3
4 0
3
131
2
1 3
4 1
4
138
2
1 4
4 0
4
139
2
1 4
4 1
5
146
2
1 5
4 0
5
147
2
1 5
4 1
6
154
2
1 6
4 0
6
155
2
1 6
4 1
14
0
162
2
0 0
5 0
0
163
2
0 0
5 1
1
170
2
0 1
5 0
1
171
2
0 1
5 1
2
178
2
0 2
5 0
2
179
2
0 2
5 1
3
186
2
0 3
5 0
3
187
2
0 3
5 1
4
194
2
0 4
5 0
4
195
2
0 4
5 1
5
202
2
0 5
5 0
5
203
2
0 5
5 1
6
210
2
0 6
5 0
6
211
2
0 6
5 1
end_DTG
begin_DTG
6
7
220
2
2 0
3 1
7
221
2
2 0
3 2
8
276
2
1 0
4 1
8
277
2
1 0
4 2
9
332
2
0 0
5 1
9
333
2
0 0
5 2
6
7
228
2
2 1
3 1
7
229
2
2 1
3 2
8
284
2
1 1
4 1
8
285
2
1 1
4 2
9
340
2
0 1
5 1
9
341
2
0 1
5 2
6
7
236
2
2 2
3 1
7
237
2
2 2
3 2
8
292
2
1 2
4 1
8
293
2
1 2
4 2
9
348
2
0 2
5 1
9
349
2
0 2
5 2
6
7
244
2
2 3
3 1
7
245
2
2 3
3 2
8
300
2
1 3
4 1
8
301
2
1 3
4 2
9
356
2
0 3
5 1
9
357
2
0 3
5 2
6
7
252
2
2 4
3 1
7
253
2
2 4
3 2
8
308
2
1 4
4 1
8
309
2
1 4
4 2
9
364
2
0 4
5 1
9
365
2
0 4
5 2
6
7
260
2
2 5
3 1
7
261
2
2 5
3 2
8
316
2
1 5
4 1
8
317
2
1 5
4 2
9
372
2
0 5
5 1
9
373
2
0 5
5 2
6
7
268
2
2 6
3 1
7
269
2
2 6
3 2
8
324
2
1 6
4 1
8
325
2
1 6
4 2
9
380
2
0 6
5 1
9
381
2
0 6
5 2
14
0
52
2
2 0
3 0
0
53
2
2 0
3 1
1
60
2
2 1
3 0
1
61
2
2 1
3 1
2
68
2
2 2
3 0
2
69
2
2 2
3 1
3
76
2
2 3
3 0
3
77
2
2 3
3 1
4
84
2
2 4
3 0
4
85
2
2 4
3 1
5
92
2
2 5
3 0
5
93
2
2 5
3 1
6
100
2
2 6
3 0
6
101
2
2 6
3 1
14
0
108
2
1 0
4 0
0
109
2
1 0
4 1
1
116
2
1 1
4 0
1
117
2
1 1
4 1
2
124
2
1 2
4 0
2
125
2
1 2
4 1
3
132
2
1 3
4 0
3
133
2
1 3
4 1
4
140
2
1 4
4 0
4
141
2
1 4
4 1
5
148
2
1 5
4 0
5
149
2
1 5
4 1
6
156
2
1 6
4 0
6
157
2
1 6
4 1
14
0
164
2
0 0
5 0
0
165
2
0 0
5 1
1
172
2
0 1
5 0
1
173
2
0 1
5 1
2
180
2
0 2
5 0
2
181
2
0 2
5 1
3
188
2
0 3
5 0
3
189
2
0 3
5 1
4
196
2
0 4
5 0
4
197
2
0 4
5 1
5
204
2
0 5
5 0
5
205
2
0 5
5 1
6
212
2
0 6
5 0
6
213
2
0 6
5 1
end_DTG
begin_DTG
6
7
222
2
2 0
3 1
7
223
2
2 0
3 2
8
278
2
1 0
4 1
8
279
2
1 0
4 2
9
334
2
0 0
5 1
9
335
2
0 0
5 2
6
7
230
2
2 1
3 1
7
231
2
2 1
3 2
8
286
2
1 1
4 1
8
287
2
1 1
4 2
9
342
2
0 1
5 1
9
343
2
0 1
5 2
6
7
238
2
2 2
3 1
7
239
2
2 2
3 2
8
294
2
1 2
4 1
8
295
2
1 2
4 2
9
350
2
0 2
5 1
9
351
2
0 2
5 2
6
7
246
2
2 3
3 1
7
247
2
2 3
3 2
8
302
2
1 3
4 1
8
303
2
1 3
4 2
9
358
2
0 3
5 1
9
359
2
0 3
5 2
6
7
254
2
2 4
3 1
7
255
2
2 4
3 2
8
310
2
1 4
4 1
8
311
2
1 4
4 2
9
366
2
0 4
5 1
9
367
2
0 4
5 2
6
7
262
2
2 5
3 1
7
263
2
2 5
3 2
8
318
2
1 5
4 1
8
319
2
1 5
4 2
9
374
2
0 5
5 1
9
375
2
0 5
5 2
6
7
270
2
2 6
3 1
7
271
2
2 6
3 2
8
326
2
1 6
4 1
8
327
2
1 6
4 2
9
382
2
0 6
5 1
9
383
2
0 6
5 2
14
0
54
2
2 0
3 0
0
55
2
2 0
3 1
1
62
2
2 1
3 0
1
63
2
2 1
3 1
2
70
2
2 2
3 0
2
71
2
2 2
3 1
3
78
2
2 3
3 0
3
79
2
2 3
3 1
4
86
2
2 4
3 0
4
87
2
2 4
3 1
5
94
2
2 5
3 0
5
95
2
2 5
3 1
6
102
2
2 6
3 0
6
103
2
2 6
3 1
14
0
110
2
1 0
4 0
0
111
2
1 0
4 1
1
118
2
1 1
4 0
1
119
2
1 1
4 1
2
126
2
1 2
4 0
2
127
2
1 2
4 1
3
134
2
1 3
4 0
3
135
2
1 3
4 1
4
142
2
1 4
4 0
4
143
2
1 4
4 1
5
150
2
1 5
4 0
5
151
2
1 5
4 1
6
158
2
1 6
4 0
6
159
2
1 6
4 1
14
0
166
2
0 0
5 0
0
167
2
0 0
5 1
1
174
2
0 1
5 0
1
175
2
0 1
5 1
2
182
2
0 2
5 0
2
183
2
0 2
5 1
3
190
2
0 3
5 0
3
191
2
0 3
5 1
4
198
2
0 4
5 0
4
199
2
0 4
5 1
5
206
2
0 5
5 0
5
207
2
0 5
5 1
6
214
2
0 6
5 0
6
215
2
0 6
5 1
end_DTG
begin_CG
5
6 28
7 28
8 28
9 28
5 112
5
6 28
7 28
8 28
9 28
4 112
5
6 28
7 28
8 28
9 28
3 112
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
end_CG
