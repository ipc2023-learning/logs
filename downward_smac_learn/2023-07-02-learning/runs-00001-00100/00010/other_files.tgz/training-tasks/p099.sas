begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var23
-1
17
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l17)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var22
-1
17
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l17)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var21
-1
17
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l17)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var20
-1
17
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l17)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var19
-1
17
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l17)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var18
-1
17
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l17)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var17
-1
17
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l17)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var24
-1
4
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
Atom capacity(v1, c3)
end_variable
begin_variable
var25
-1
4
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
Atom capacity(v2, c3)
end_variable
begin_variable
var26
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var27
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var28
-1
4
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
Atom capacity(v5, c3)
end_variable
begin_variable
var29
-1
4
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
Atom capacity(v6, c3)
end_variable
begin_variable
var30
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var0
-1
24
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l17)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var1
-1
24
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l17)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var2
-1
24
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l17)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var3
-1
24
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l17)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var4
-1
24
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
2 6
11 2
7
5175
2
2 7
11 0
7
5176
2
2 7
11 1
7
5177
2
2 7
11 2
8
5228
2
2 8
11 2
8
5227
2
2 8
11 1
8
5226
2
2 8
11 0
9
5277
2
2 9
11 0
9
5278
2
2 9
11 1
9
5279
2
2 9
11 2
10
5328
2
2 10
11 0
10
5329
2
2 10
11 1
10
5330
2
2 10
11 2
11
5379
2
2 11
11 0
11
5380
2
2 11
11 1
11
5381
2
2 11
11 2
12
5432
2
2 12
11 2
12
5431
2
2 12
11 1
12
5430
2
2 12
11 0
13
5481
2
2 13
11 0
13
5482
2
2 13
11 1
13
5483
2
2 13
11 2
14
5532
2
2 14
11 0
14
5533
2
2 14
11 1
14
5534
2
2 14
11 2
15
5583
2
2 15
11 0
15
5584
2
2 15
11 1
15
5585
2
2 15
11 2
16
5634
2
2 16
11 0
16
5635
2
2 16
11 1
16
5636
2
2 16
11 2
51
0
5686
2
1 0
12 1
0
5685
2
1 0
12 0
0
5687
2
1 0
12 2
1
5736
2
1 1
12 0
1
5737
2
1 1
12 1
1
5738
2
1 1
12 2
2
5787
2
1 2
12 0
2
5788
2
1 2
12 1
2
5789
2
1 2
12 2
3
5838
2
1 3
12 0
3
5839
2
1 3
12 1
3
5840
2
1 3
12 2
4
5891
2
1 4
12 2
4
5890
2
1 4
12 1
4
5889
2
1 4
12 0
5
5940
2
1 5
12 0
5
5941
2
1 5
12 1
5
5942
2
1 5
12 2
6
5991
2
1 6
12 0
6
5992
2
1 6
12 1
6
5993
2
1 6
12 2
7
6042
2
1 7
12 0
7
6043
2
1 7
12 1
7
6044
2
1 7
12 2
8
6095
2
1 8
12 2
8
6094
2
1 8
12 1
8
6093
2
1 8
12 0
9
6144
2
1 9
12 0
9
6145
2
1 9
12 1
9
6146
2
1 9
12 2
10
6195
2
1 10
12 0
10
6196
2
1 10
12 1
10
6197
2
1 10
12 2
11
6246
2
1 11
12 0
11
6247
2
1 11
12 1
11
6248
2
1 11
12 2
12
6299
2
1 12
12 2
12
6298
2
1 12
12 1
12
6297
2
1 12
12 0
13
6348
2
1 13
12 0
13
6349
2
1 13
12 1
13
6350
2
1 13
12 2
14
6399
2
1 14
12 0
14
6400
2
1 14
12 1
14
6401
2
1 14
12 2
15
6450
2
1 15
12 0
15
6451
2
1 15
12 1
15
6452
2
1 15
12 2
16
6501
2
1 16
12 0
16
6502
2
1 16
12 1
16
6503
2
1 16
12 2
51
0
6553
2
0 0
13 1
0
6552
2
0 0
13 0
0
6554
2
0 0
13 2
1
6603
2
0 1
13 0
1
6604
2
0 1
13 1
1
6605
2
0 1
13 2
2
6654
2
0 2
13 0
2
6655
2
0 2
13 1
2
6656
2
0 2
13 2
3
6705
2
0 3
13 0
3
6706
2
0 3
13 1
3
6707
2
0 3
13 2
4
6758
2
0 4
13 2
4
6757
2
0 4
13 1
4
6756
2
0 4
13 0
5
6807
2
0 5
13 0
5
6808
2
0 5
13 1
5
6809
2
0 5
13 2
6
6858
2
0 6
13 0
6
6859
2
0 6
13 1
6
6860
2
0 6
13 2
7
6909
2
0 7
13 0
7
6910
2
0 7
13 1
7
6911
2
0 7
13 2
8
6962
2
0 8
13 2
8
6961
2
0 8
13 1
8
6960
2
0 8
13 0
9
7011
2
0 9
13 0
9
7012
2
0 9
13 1
9
7013
2
0 9
13 2
10
7062
2
0 10
13 0
10
7063
2
0 10
13 1
10
7064
2
0 10
13 2
11
7113
2
0 11
13 0
11
7114
2
0 11
13 1
11
7115
2
0 11
13 2
12
7166
2
0 12
13 2
12
7165
2
0 12
13 1
12
7164
2
0 12
13 0
13
7215
2
0 13
13 0
13
7216
2
0 13
13 1
13
7217
2
0 13
13 2
14
7266
2
0 14
13 0
14
7267
2
0 14
13 1
14
7268
2
0 14
13 2
15
7317
2
0 15
13 0
15
7318
2
0 15
13 1
15
7319
2
0 15
13 2
16
7368
2
0 16
13 0
16
7369
2
0 16
13 1
16
7370
2
0 16
13 2
end_DTG
begin_CG
18
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
13 1734
18
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
12 1734
18
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
11 1734
18
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
10 1734
18
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
9 1734
18
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
8 1734
18
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
7 1734
17
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
17
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
17
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
17
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
17
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
17
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
17
14 102
15 102
16 102
17 102
18 102
19 102
20 102
21 102
22 102
23 102
24 102
25 102
26 102
27 102
28 102
29 102
30 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
7
7 102
8 102
9 102
10 102
11 102
12 102
13 102
end_CG
