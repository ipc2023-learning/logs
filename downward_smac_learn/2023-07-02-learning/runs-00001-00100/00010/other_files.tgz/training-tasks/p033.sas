begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var9
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var8
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var10
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
12
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
0
begin_state
5
2
7
4
1
2
1
2
2
3
5
1
7
7
end_state
begin_goal
6
8 6
9 7
10 7
11 6
12 1
13 3
end_goal
992
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




59
2
1 3
6 1
4
470
2
1 4
6 0
4
471
2
1 4
6 1
5
482
2
1 5
6 0
5
483
2
1 5
6 1
6
494
2
1 6
6 0
6
495
2
1 6
6 1
7
506
2
1 7
6 0
7
507
2
1 7
6 1
16
0
518
2
0 0
7 0
0
519
2
0 0
7 1
1
530
2
0 1
7 0
1
531
2
0 1
7 1
2
542
2
0 2
7 0
2
543
2
0 2
7 1
3
554
2
0 3
7 0
3
555
2
0 3
7 1
4
566
2
0 4
7 0
4
567
2
0 4
7 1
5
578
2
0 5
7 0
5
579
2
0 5
7 1
6
590
2
0 6
7 0
6
591
2
0 6
7 1
7
602
2
0 7
7 0
7
603
2
0 7
7 1
end_DTG
begin_DTG
8
8
616
2
3 0
4 1
8
617
2
3 0
4 2
9
712
2
2 0
5 1
9
713
2
2 0
5 2
10
808
2
1 0
6 1
10
809
2
1 0
6 2
11
904
2
0 0
7 1
11
905
2
0 0
7 2
8
8
628
2
3 1
4 1
8
629
2
3 1
4 2
9
724
2
2 1
5 1
9
725
2
2 1
5 2
10
820
2
1 1
6 1
10
821
2
1 1
6 2
11
916
2
0 1
7 1
11
917
2
0 1
7 2
8
8
640
2
3 2
4 1
8
641
2
3 2
4 2
9
736
2
2 2
5 1
9
737
2
2 2
5 2
10
832
2
1 2
6 1
10
833
2
1 2
6 2
11
928
2
0 2
7 1
11
929
2
0 2
7 2
8
8
652
2
3 3
4 1
8
653
2
3 3
4 2
9
748
2
2 3
5 1
9
749
2
2 3
5 2
10
844
2
1 3
6 1
10
845
2
1 3
6 2
11
940
2
0 3
7 1
11
941
2
0 3
7 2
8
8
664
2
3 4
4 1
8
665
2
3 4
4 2
9
760
2
2 4
5 1
9
761
2
2 4
5 2
10
856
2
1 4
6 1
10
857
2
1 4
6 2
11
952
2
0 4
7 1
11
953
2
0 4
7 2
8
8
676
2
3 5
4 1
8
677
2
3 5
4 2
9
772
2
2 5
5 1
9
773
2
2 5
5 2
10
868
2
1 5
6 1
10
869
2
1 5
6 2
11
964
2
0 5
7 1
11
965
2
0 5
7 2
8
8
688
2
3 6
4 1
8
689
2
3 6
4 2
9
784
2
2 6
5 1
9
785
2
2 6
5 2
10
880
2
1 6
6 1
10
881
2
1 6
6 2
11
976
2
0 6
7 1
11
977
2
0 6
7 2
8
8
700
2
3 7
4 1
8
701
2
3 7
4 2
9
796
2
2 7
5 1
9
797
2
2 7
5 2
10
892
2
1 7
6 1
10
893
2
1 7
6 2
11
988
2
0 7
7 1
11
989
2
0 7
7 2
16
0
232
2
3 0
4 0
0
233
2
3 0
4 1
1
244
2
3 1
4 0
1
245
2
3 1
4 1
2
256
2
3 2
4 0
2
257
2
3 2
4 1
3
268
2
3 3
4 0
3
269
2
3 3
4 1
4
280
2
3 4
4 0
4
281
2
3 4
4 1
5
292
2
3 5
4 0
5
293
2
3 5
4 1
6
304
2
3 6
4 0
6
305
2
3 6
4 1
7
316
2
3 7
4 0
7
317
2
3 7
4 1
16
0
328
2
2 0
5 0
0
329
2
2 0
5 1
1
340
2
2 1
5 0
1
341
2
2 1
5 1
2
352
2
2 2
5 0
2
353
2
2 2
5 1
3
364
2
2 3
5 0
3
365
2
2 3
5 1
4
376
2
2 4
5 0
4
377
2
2 4
5 1
5
388
2
2 5
5 0
5
389
2
2 5
5 1
6
400
2
2 6
5 0
6
401
2
2 6
5 1
7
412
2
2 7
5 0
7
413
2
2 7
5 1
16
0
424
2
1 0
6 0
0
425
2
1 0
6 1
1
436
2
1 1
6 0
1
437
2
1 1
6 1
2
448
2
1 2
6 0
2
449
2
1 2
6 1
3
460
2
1 3
6 0
3
461
2
1 3
6 1
4
472
2
1 4
6 0
4
473
2
1 4
6 1
5
484
2
1 5
6 0
5
485
2
1 5
6 1
6
496
2
1 6
6 0
6
497
2
1 6
6 1
7
508
2
1 7
6 0
7
509
2
1 7
6 1
16
0
520
2
0 0
7 0
0
521
2
0 0
7 1
1
532
2
0 1
7 0
1
533
2
0 1
7 1
2
544
2
0 2
7 0
2
545
2
0 2
7 1
3
556
2
0 3
7 0
3
557
2
0 3
7 1
4
568
2
0 4
7 0
4
569
2
0 4
7 1
5
580
2
0 5
7 0
5
581
2
0 5
7 1
6
592
2
0 6
7 0
6
593
2
0 6
7 1
7
604
2
0 7
7 0
7
605
2
0 7
7 1
end_DTG
begin_DTG
8
8
618
2
3 0
4 1
8
619
2
3 0
4 2
9
714
2
2 0
5 1
9
715
2
2 0
5 2
10
810
2
1 0
6 1
10
811
2
1 0
6 2
11
906
2
0 0
7 1
11
907
2
0 0
7 2
8
8
630
2
3 1
4 1
8
631
2
3 1
4 2
9
726
2
2 1
5 1
9
727
2
2 1
5 2
10
822
2
1 1
6 1
10
823
2
1 1
6 2
11
918
2
0 1
7 1
11
919
2
0 1
7 2
8
8
642
2
3 2
4 1
8
643
2
3 2
4 2
9
738
2
2 2
5 1
9
739
2
2 2
5 2
10
834
2
1 2
6 1
10
835
2
1 2
6 2
11
930
2
0 2
7 1
11
931
2
0 2
7 2
8
8
654
2
3 3
4 1
8
655
2
3 3
4 2
9
750
2
2 3
5 1
9
751
2
2 3
5 2
10
846
2
1 3
6 1
10
847
2
1 3
6 2
11
942
2
0 3
7 1
11
943
2
0 3
7 2
8
8
666
2
3 4
4 1
8
667
2
3 4
4 2
9
762
2
2 4
5 1
9
763
2
2 4
5 2
10
858
2
1 4
6 1
10
859
2
1 4
6 2
11
954
2
0 4
7 1
11
955
2
0 4
7 2
8
8
678
2
3 5
4 1
8
679
2
3 5
4 2
9
774
2
2 5
5 1
9
775
2
2 5
5 2
10
870
2
1 5
6 1
10
871
2
1 5
6 2
11
966
2
0 5
7 1
11
967
2
0 5
7 2
8
8
690
2
3 6
4 1
8
691
2
3 6
4 2
9
786
2
2 6
5 1
9
787
2
2 6
5 2
10
882
2
1 6
6 1
10
883
2
1 6
6 2
11
978
2
0 6
7 1
11
979
2
0 6
7 2
8
8
702
2
3 7
4 1
8
703
2
3 7
4 2
9
798
2
2 7
5 1
9
799
2
2 7
5 2
10
894
2
1 7
6 1
10
895
2
1 7
6 2
11
990
2
0 7
7 1
11
991
2
0 7
7 2
16
0
234
2
3 0
4 0
0
235
2
3 0
4 1
1
246
2
3 1
4 0
1
247
2
3 1
4 1
2
258
2
3 2
4 0
2
259
2
3 2
4 1
3
270
2
3 3
4 0
3
271
2
3 3
4 1
4
282
2
3 4
4 0
4
283
2
3 4
4 1
5
294
2
3 5
4 0
5
295
2
3 5
4 1
6
306
2
3 6
4 0
6
307
2
3 6
4 1
7
318
2
3 7
4 0
7
319
2
3 7
4 1
16
0
330
2
2 0
5 0
0
331
2
2 0
5 1
1
342
2
2 1
5 0
1
343
2
2 1
5 1
2
354
2
2 2
5 0
2
355
2
2 2
5 1
3
366
2
2 3
5 0
3
367
2
2 3
5 1
4
378
2
2 4
5 0
4
379
2
2 4
5 1
5
390
2
2 5
5 0
5
391
2
2 5
5 1
6
402
2
2 6
5 0
6
403
2
2 6
5 1
7
414
2
2 7
5 0
7
415
2
2 7
5 1
16
0
426
2
1 0
6 0
0
427
2
1 0
6 1
1
438
2
1 1
6 0
1
439
2
1 1
6 1
2
450
2
1 2
6 0
2
451
2
1 2
6 1
3
462
2
1 3
6 0
3
463
2
1 3
6 1
4
474
2
1 4
6 0
4
475
2
1 4
6 1
5
486
2
1 5
6 0
5
487
2
1 5
6 1
6
498
2
1 6
6 0
6
499
2
1 6
6 1
7
510
2
1 7
6 0
7
511
2
1 7
6 1
16
0
522
2
0 0
7 0
0
523
2
0 0
7 1
1
534
2
0 1
7 0
1
535
2
0 1
7 1
2
546
2
0 2
7 0
2
547
2
0 2
7 1
3
558
2
0 3
7 0
3
559
2
0 3
7 1
4
570
2
0 4
7 0
4
571
2
0 4
7 1
5
582
2
0 5
7 0
5
583
2
0 5
7 1
6
594
2
0 6
7 0
6
595
2
0 6
7 1
7
606
2
0 7
7 0
7
607
2
0 7
7 1
end_DTG
begin_CG
7
8 32
9 32
10 32
11 32
12 32
13 32
7 192
7
8 32
9 32
10 32
11 32
12 32
13 32
6 192
7
8 32
9 32
10 32
11 32
12 32
13 32
5 192
7
8 32
9 32
10 32
11 32
12 32
13 32
4 192
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
