begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var8
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var5
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var9
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var10
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
0
begin_state
4
2
0
3
1
1
2
2
6
4
6
7
4
end_state
begin_goal
5
8 5
9 3
10 0
11 2
12 0
end_goal
856
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 3 6 5
0
end_operator
begin_operator
drive v1 l7 l8
0
1
0 3 6 7
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
1
391
2
1 1
6 1
2
400
2
1 2
6 0
2
401
2
1 2
6 1
3
410
2
1 3
6 0
3
411
2
1 3
6 1
4
420
2
1 4
6 0
4
421
2
1 4
6 1
5
430
2
1 5
6 0
5
431
2
1 5
6 1
6
440
2
1 6
6 0
6
441
2
1 6
6 1
7
450
2
1 7
6 0
7
451
2
1 7
6 1
16
0
460
2
0 0
7 0
0
461
2
0 0
7 1
1
470
2
0 1
7 0
1
471
2
0 1
7 1
2
480
2
0 2
7 0
2
481
2
0 2
7 1
3
490
2
0 3
7 0
3
491
2
0 3
7 1
4
500
2
0 4
7 0
4
501
2
0 4
7 1
5
510
2
0 5
7 0
5
511
2
0 5
7 1
6
520
2
0 6
7 0
6
521
2
0 6
7 1
7
530
2
0 7
7 0
7
531
2
0 7
7 1
end_DTG
begin_DTG
8
8
542
2
3 0
4 1
8
543
2
3 0
4 2
9
622
2
2 0
5 1
9
623
2
2 0
5 2
10
702
2
1 0
6 1
10
703
2
1 0
6 2
11
782
2
0 0
7 1
11
783
2
0 0
7 2
8
8
552
2
3 1
4 1
8
553
2
3 1
4 2
9
632
2
2 1
5 1
9
633
2
2 1
5 2
10
712
2
1 1
6 1
10
713
2
1 1
6 2
11
792
2
0 1
7 1
11
793
2
0 1
7 2
8
8
562
2
3 2
4 1
8
563
2
3 2
4 2
9
642
2
2 2
5 1
9
643
2
2 2
5 2
10
722
2
1 2
6 1
10
723
2
1 2
6 2
11
802
2
0 2
7 1
11
803
2
0 2
7 2
8
8
572
2
3 3
4 1
8
573
2
3 3
4 2
9
652
2
2 3
5 1
9
653
2
2 3
5 2
10
732
2
1 3
6 1
10
733
2
1 3
6 2
11
812
2
0 3
7 1
11
813
2
0 3
7 2
8
8
582
2
3 4
4 1
8
583
2
3 4
4 2
9
662
2
2 4
5 1
9
663
2
2 4
5 2
10
742
2
1 4
6 1
10
743
2
1 4
6 2
11
822
2
0 4
7 1
11
823
2
0 4
7 2
8
8
592
2
3 5
4 1
8
593
2
3 5
4 2
9
672
2
2 5
5 1
9
673
2
2 5
5 2
10
752
2
1 5
6 1
10
753
2
1 5
6 2
11
832
2
0 5
7 1
11
833
2
0 5
7 2
8
8
602
2
3 6
4 1
8
603
2
3 6
4 2
9
682
2
2 6
5 1
9
683
2
2 6
5 2
10
762
2
1 6
6 1
10
763
2
1 6
6 2
11
842
2
0 6
7 1
11
843
2
0 6
7 2
8
8
612
2
3 7
4 1
8
613
2
3 7
4 2
9
692
2
2 7
5 1
9
693
2
2 7
5 2
10
772
2
1 7
6 1
10
773
2
1 7
6 2
11
852
2
0 7
7 1
11
853
2
0 7
7 2
16
0
222
2
3 0
4 0
0
223
2
3 0
4 1
1
232
2
3 1
4 0
1
233
2
3 1
4 1
2
242
2
3 2
4 0
2
243
2
3 2
4 1
3
252
2
3 3
4 0
3
253
2
3 3
4 1
4
262
2
3 4
4 0
4
263
2
3 4
4 1
5
272
2
3 5
4 0
5
273
2
3 5
4 1
6
282
2
3 6
4 0
6
283
2
3 6
4 1
7
292
2
3 7
4 0
7
293
2
3 7
4 1
16
0
302
2
2 0
5 0
0
303
2
2 0
5 1
1
312
2
2 1
5 0
1
313
2
2 1
5 1
2
322
2
2 2
5 0
2
323
2
2 2
5 1
3
332
2
2 3
5 0
3
333
2
2 3
5 1
4
342
2
2 4
5 0
4
343
2
2 4
5 1
5
352
2
2 5
5 0
5
353
2
2 5
5 1
6
362
2
2 6
5 0
6
363
2
2 6
5 1
7
372
2
2 7
5 0
7
373
2
2 7
5 1
16
0
382
2
1 0
6 0
0
383
2
1 0
6 1
1
392
2
1 1
6 0
1
393
2
1 1
6 1
2
402
2
1 2
6 0
2
403
2
1 2
6 1
3
412
2
1 3
6 0
3
413
2
1 3
6 1
4
422
2
1 4
6 0
4
423
2
1 4
6 1
5
432
2
1 5
6 0
5
433
2
1 5
6 1
6
442
2
1 6
6 0
6
443
2
1 6
6 1
7
452
2
1 7
6 0
7
453
2
1 7
6 1
16
0
462
2
0 0
7 0
0
463
2
0 0
7 1
1
472
2
0 1
7 0
1
473
2
0 1
7 1
2
482
2
0 2
7 0
2
483
2
0 2
7 1
3
492
2
0 3
7 0
3
493
2
0 3
7 1
4
502
2
0 4
7 0
4
503
2
0 4
7 1
5
512
2
0 5
7 0
5
513
2
0 5
7 1
6
522
2
0 6
7 0
6
523
2
0 6
7 1
7
532
2
0 7
7 0
7
533
2
0 7
7 1
end_DTG
begin_DTG
8
8
544
2
3 0
4 1
8
545
2
3 0
4 2
9
624
2
2 0
5 1
9
625
2
2 0
5 2
10
704
2
1 0
6 1
10
705
2
1 0
6 2
11
784
2
0 0
7 1
11
785
2
0 0
7 2
8
8
554
2
3 1
4 1
8
555
2
3 1
4 2
9
634
2
2 1
5 1
9
635
2
2 1
5 2
10
714
2
1 1
6 1
10
715
2
1 1
6 2
11
794
2
0 1
7 1
11
795
2
0 1
7 2
8
8
564
2
3 2
4 1
8
565
2
3 2
4 2
9
644
2
2 2
5 1
9
645
2
2 2
5 2
10
724
2
1 2
6 1
10
725
2
1 2
6 2
11
804
2
0 2
7 1
11
805
2
0 2
7 2
8
8
574
2
3 3
4 1
8
575
2
3 3
4 2
9
654
2
2 3
5 1
9
655
2
2 3
5 2
10
734
2
1 3
6 1
10
735
2
1 3
6 2
11
814
2
0 3
7 1
11
815
2
0 3
7 2
8
8
584
2
3 4
4 1
8
585
2
3 4
4 2
9
664
2
2 4
5 1
9
665
2
2 4
5 2
10
744
2
1 4
6 1
10
745
2
1 4
6 2
11
824
2
0 4
7 1
11
825
2
0 4
7 2
8
8
594
2
3 5
4 1
8
595
2
3 5
4 2
9
674
2
2 5
5 1
9
675
2
2 5
5 2
10
754
2
1 5
6 1
10
755
2
1 5
6 2
11
834
2
0 5
7 1
11
835
2
0 5
7 2
8
8
604
2
3 6
4 1
8
605
2
3 6
4 2
9
684
2
2 6
5 1
9
685
2
2 6
5 2
10
764
2
1 6
6 1
10
765
2
1 6
6 2
11
844
2
0 6
7 1
11
845
2
0 6
7 2
8
8
614
2
3 7
4 1
8
615
2
3 7
4 2
9
694
2
2 7
5 1
9
695
2
2 7
5 2
10
774
2
1 7
6 1
10
775
2
1 7
6 2
11
854
2
0 7
7 1
11
855
2
0 7
7 2
16
0
224
2
3 0
4 0
0
225
2
3 0
4 1
1
234
2
3 1
4 0
1
235
2
3 1
4 1
2
244
2
3 2
4 0
2
245
2
3 2
4 1
3
254
2
3 3
4 0
3
255
2
3 3
4 1
4
264
2
3 4
4 0
4
265
2
3 4
4 1
5
274
2
3 5
4 0
5
275
2
3 5
4 1
6
284
2
3 6
4 0
6
285
2
3 6
4 1
7
294
2
3 7
4 0
7
295
2
3 7
4 1
16
0
304
2
2 0
5 0
0
305
2
2 0
5 1
1
314
2
2 1
5 0
1
315
2
2 1
5 1
2
324
2
2 2
5 0
2
325
2
2 2
5 1
3
334
2
2 3
5 0
3
335
2
2 3
5 1
4
344
2
2 4
5 0
4
345
2
2 4
5 1
5
354
2
2 5
5 0
5
355
2
2 5
5 1
6
364
2
2 6
5 0
6
365
2
2 6
5 1
7
374
2
2 7
5 0
7
375
2
2 7
5 1
16
0
384
2
1 0
6 0
0
385
2
1 0
6 1
1
394
2
1 1
6 0
1
395
2
1 1
6 1
2
404
2
1 2
6 0
2
405
2
1 2
6 1
3
414
2
1 3
6 0
3
415
2
1 3
6 1
4
424
2
1 4
6 0
4
425
2
1 4
6 1
5
434
2
1 5
6 0
5
435
2
1 5
6 1
6
444
2
1 6
6 0
6
445
2
1 6
6 1
7
454
2
1 7
6 0
7
455
2
1 7
6 1
16
0
464
2
0 0
7 0
0
465
2
0 0
7 1
1
474
2
0 1
7 0
1
475
2
0 1
7 1
2
484
2
0 2
7 0
2
485
2
0 2
7 1
3
494
2
0 3
7 0
3
495
2
0 3
7 1
4
504
2
0 4
7 0
4
505
2
0 4
7 1
5
514
2
0 5
7 0
5
515
2
0 5
7 1
6
524
2
0 6
7 0
6
525
2
0 6
7 1
7
534
2
0 7
7 0
7
535
2
0 7
7 1
end_DTG
begin_CG
6
8 32
9 32
10 32
11 32
12 32
7 160
6
8 32
9 32
10 32
11 32
12 32
6 160
6
8 32
9 32
10 32
11 32
12 32
5 160
6
8 32
9 32
10 32
11 32
12 32
4 160
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
