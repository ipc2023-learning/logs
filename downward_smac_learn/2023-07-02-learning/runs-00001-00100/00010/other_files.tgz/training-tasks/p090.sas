begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var22
-1
16
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var21
-1
16
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var20
-1
16
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var19
-1
16
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var18
-1
16
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var17
-1
16
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var16
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var23
-1
4
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
Atom capacity(v1, c3)
end_variable
begin_variable
var24
-1
4
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
Atom capacity(v2, c3)
end_variable
begin_variable
var25
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var26
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var27
-1
4
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
Atom capacity(v5, c3)
end_variable
begin_variable
var28
-1
4
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
Atom capacity(v6, c3)
end_variable
begin_variable
var29
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var0
-1
23
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var1
-1
23
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var2
-1
23
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var3
-1
23
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var4
-1
23
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l16)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
3 11
10 0
11
3214
2
3 11
10 1
11
3215
2
3 11
10 2
12
3262
2
3 12
10 1
12
3263
2
3 12
10 2
12
3261
2
3 12
10 0
13
3309
2
3 13
10 0
13
3310
2
3 13
10 1
13
3311
2
3 13
10 2
14
3357
2
3 14
10 0
14
3358
2
3 14
10 1
14
3359
2
3 14
10 2
15
3405
2
3 15
10 0
15
3406
2
3 15
10 1
15
3407
2
3 15
10 2
48
0
3454
2
2 0
11 1
0
3455
2
2 0
11 2
0
3453
2
2 0
11 0
1
3501
2
2 1
11 0
1
3502
2
2 1
11 1
1
3503
2
2 1
11 2
2
3549
2
2 2
11 0
2
3550
2
2 2
11 1
2
3551
2
2 2
11 2
3
3597
2
2 3
11 0
3
3598
2
2 3
11 1
3
3599
2
2 3
11 2
4
3646
2
2 4
11 1
4
3647
2
2 4
11 2
4
3645
2
2 4
11 0
5
3693
2
2 5
11 0
5
3694
2
2 5
11 1
5
3695
2
2 5
11 2
6
3741
2
2 6
11 0
6
3742
2
2 6
11 1
6
3743
2
2 6
11 2
7
3789
2
2 7
11 0
7
3790
2
2 7
11 1
7
3791
2
2 7
11 2
8
3837
2
2 8
11 0
8
3839
2
2 8
11 2
8
3838
2
2 8
11 1
9
3885
2
2 9
11 0
9
3886
2
2 9
11 1
9
3887
2
2 9
11 2
10
3933
2
2 10
11 0
10
3934
2
2 10
11 1
10
3935
2
2 10
11 2
11
3981
2
2 11
11 0
11
3982
2
2 11
11 1
11
3983
2
2 11
11 2
12
4030
2
2 12
11 1
12
4031
2
2 12
11 2
12
4029
2
2 12
11 0
13
4077
2
2 13
11 0
13
4078
2
2 13
11 1
13
4079
2
2 13
11 2
14
4125
2
2 14
11 0
14
4126
2
2 14
11 1
14
4127
2
2 14
11 2
15
4173
2
2 15
11 0
15
4174
2
2 15
11 1
15
4175
2
2 15
11 2
48
0
4222
2
1 0
12 1
0
4223
2
1 0
12 2
0
4221
2
1 0
12 0
1
4269
2
1 1
12 0
1
4270
2
1 1
12 1
1
4271
2
1 1
12 2
2
4317
2
1 2
12 0
2
4318
2
1 2
12 1
2
4319
2
1 2
12 2
3
4365
2
1 3
12 0
3
4366
2
1 3
12 1
3
4367
2
1 3
12 2
4
4414
2
1 4
12 1
4
4415
2
1 4
12 2
4
4413
2
1 4
12 0
5
4461
2
1 5
12 0
5
4462
2
1 5
12 1
5
4463
2
1 5
12 2
6
4509
2
1 6
12 0
6
4510
2
1 6
12 1
6
4511
2
1 6
12 2
7
4557
2
1 7
12 0
7
4558
2
1 7
12 1
7
4559
2
1 7
12 2
8
4605
2
1 8
12 0
8
4607
2
1 8
12 2
8
4606
2
1 8
12 1
9
4653
2
1 9
12 0
9
4654
2
1 9
12 1
9
4655
2
1 9
12 2
10
4701
2
1 10
12 0
10
4702
2
1 10
12 1
10
4703
2
1 10
12 2
11
4749
2
1 11
12 0
11
4750
2
1 11
12 1
11
4751
2
1 11
12 2
12
4798
2
1 12
12 1
12
4799
2
1 12
12 2
12
4797
2
1 12
12 0
13
4845
2
1 13
12 0
13
4846
2
1 13
12 1
13
4847
2
1 13
12 2
14
4893
2
1 14
12 0
14
4894
2
1 14
12 1
14
4895
2
1 14
12 2
15
4941
2
1 15
12 0
15
4942
2
1 15
12 1
15
4943
2
1 15
12 2
48
0
4990
2
0 0
13 1
0
4991
2
0 0
13 2
0
4989
2
0 0
13 0
1
5037
2
0 1
13 0
1
5038
2
0 1
13 1
1
5039
2
0 1
13 2
2
5085
2
0 2
13 0
2
5086
2
0 2
13 1
2
5087
2
0 2
13 2
3
5133
2
0 3
13 0
3
5134
2
0 3
13 1
3
5135
2
0 3
13 2
4
5182
2
0 4
13 1
4
5183
2
0 4
13 2
4
5181
2
0 4
13 0
5
5229
2
0 5
13 0
5
5230
2
0 5
13 1
5
5231
2
0 5
13 2
6
5277
2
0 6
13 0
6
5278
2
0 6
13 1
6
5279
2
0 6
13 2
7
5325
2
0 7
13 0
7
5326
2
0 7
13 1
7
5327
2
0 7
13 2
8
5373
2
0 8
13 0
8
5375
2
0 8
13 2
8
5374
2
0 8
13 1
9
5421
2
0 9
13 0
9
5422
2
0 9
13 1
9
5423
2
0 9
13 2
10
5469
2
0 10
13 0
10
5470
2
0 10
13 1
10
5471
2
0 10
13 2
11
5517
2
0 11
13 0
11
5518
2
0 11
13 1
11
5519
2
0 11
13 2
12
5566
2
0 12
13 1
12
5567
2
0 12
13 2
12
5565
2
0 12
13 0
13
5613
2
0 13
13 0
13
5614
2
0 13
13 1
13
5615
2
0 13
13 2
14
5661
2
0 14
13 0
14
5662
2
0 14
13 1
14
5663
2
0 14
13 2
15
5709
2
0 15
13 0
15
5710
2
0 15
13 1
15
5711
2
0 15
13 2
end_DTG
begin_CG
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
13 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
12 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
11 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
10 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
9 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
8 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
7 1536
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
end_CG
