begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var15
-1
13
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var14
-1
13
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var13
-1
13
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var12
-1
13
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var11
-1
13
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var16
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
18
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
18
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
18
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
end_variable
begin_variable
var3
-1
18
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var4
-1
18
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var5
-1
18
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var6
-1
18
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l13)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var7
-1
18
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l13)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var8
-1
18
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l13)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var9
-1
18
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l13)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





5 2
14
2432
2
3 3
6 1
14
2433
2
3 3
6 2
15
2718
2
2 3
7 1
15
2719
2
2 3
7 2
16
3004
2
1 3
8 1
16
3005
2
1 3
8 2
17
3290
2
0 3
9 1
17
3291
2
0 3
9 2
10
13
2168
2
4 4
5 1
13
2169
2
4 4
5 2
14
2454
2
3 4
6 1
14
2455
2
3 4
6 2
15
2740
2
2 4
7 1
15
2741
2
2 4
7 2
16
3026
2
1 4
8 1
16
3027
2
1 4
8 2
17
3312
2
0 4
9 1
17
3313
2
0 4
9 2
10
13
2190
2
4 5
5 1
13
2191
2
4 5
5 2
14
2476
2
3 5
6 1
14
2477
2
3 5
6 2
15
2762
2
2 5
7 1
15
2763
2
2 5
7 2
16
3048
2
1 5
8 1
16
3049
2
1 5
8 2
17
3334
2
0 5
9 1
17
3335
2
0 5
9 2
10
13
2212
2
4 6
5 1
13
2213
2
4 6
5 2
14
2498
2
3 6
6 1
14
2499
2
3 6
6 2
15
2784
2
2 6
7 1
15
2785
2
2 6
7 2
16
3070
2
1 6
8 1
16
3071
2
1 6
8 2
17
3356
2
0 6
9 1
17
3357
2
0 6
9 2
10
13
2234
2
4 7
5 1
13
2235
2
4 7
5 2
14
2520
2
3 7
6 1
14
2521
2
3 7
6 2
15
2806
2
2 7
7 1
15
2807
2
2 7
7 2
16
3092
2
1 7
8 1
16
3093
2
1 7
8 2
17
3378
2
0 7
9 1
17
3379
2
0 7
9 2
10
13
2256
2
4 8
5 1
13
2257
2
4 8
5 2
14
2542
2
3 8
6 1
14
2543
2
3 8
6 2
15
2828
2
2 8
7 1
15
2829
2
2 8
7 2
16
3114
2
1 8
8 1
16
3115
2
1 8
8 2
17
3400
2
0 8
9 1
17
3401
2
0 8
9 2
10
13
2278
2
4 9
5 1
13
2279
2
4 9
5 2
14
2564
2
3 9
6 1
14
2565
2
3 9
6 2
15
2850
2
2 9
7 1
15
2851
2
2 9
7 2
16
3136
2
1 9
8 1
16
3137
2
1 9
8 2
17
3422
2
0 9
9 1
17
3423
2
0 9
9 2
10
13
2300
2
4 10
5 1
13
2301
2
4 10
5 2
14
2586
2
3 10
6 1
14
2587
2
3 10
6 2
15
2872
2
2 10
7 1
15
2873
2
2 10
7 2
16
3158
2
1 10
8 1
16
3159
2
1 10
8 2
17
3444
2
0 10
9 1
17
3445
2
0 10
9 2
10
13
2322
2
4 11
5 1
13
2323
2
4 11
5 2
14
2608
2
3 11
6 1
14
2609
2
3 11
6 2
15
2894
2
2 11
7 1
15
2895
2
2 11
7 2
16
3180
2
1 11
8 1
16
3181
2
1 11
8 2
17
3466
2
0 11
9 1
17
3467
2
0 11
9 2
10
13
2344
2
4 12
5 1
13
2345
2
4 12
5 2
14
2630
2
3 12
6 1
14
2631
2
3 12
6 2
15
2916
2
2 12
7 1
15
2917
2
2 12
7 2
16
3202
2
1 12
8 1
16
3203
2
1 12
8 2
17
3488
2
0 12
9 1
17
3489
2
0 12
9 2
26
0
651
2
4 0
5 1
0
650
2
4 0
5 0
1
672
2
4 1
5 0
1
673
2
4 1
5 1
2
694
2
4 2
5 0
2
695
2
4 2
5 1
3
716
2
4 3
5 0
3
717
2
4 3
5 1
4
738
2
4 4
5 0
4
739
2
4 4
5 1
5
760
2
4 5
5 0
5
761
2
4 5
5 1
6
783
2
4 6
5 1
6
782
2
4 6
5 0
7
804
2
4 7
5 0
7
805
2
4 7
5 1
8
826
2
4 8
5 0
8
827
2
4 8
5 1
9
848
2
4 9
5 0
9
849
2
4 9
5 1
10
870
2
4 10
5 0
10
871
2
4 10
5 1
11
892
2
4 11
5 0
11
893
2
4 11
5 1
12
914
2
4 12
5 0
12
915
2
4 12
5 1
26
0
937
2
3 0
6 1
0
936
2
3 0
6 0
1
958
2
3 1
6 0
1
959
2
3 1
6 1
2
980
2
3 2
6 0
2
981
2
3 2
6 1
3
1002
2
3 3
6 0
3
1003
2
3 3
6 1
4
1024
2
3 4
6 0
4
1025
2
3 4
6 1
5
1046
2
3 5
6 0
5
1047
2
3 5
6 1
6
1069
2
3 6
6 1
6
1068
2
3 6
6 0
7
1090
2
3 7
6 0
7
1091
2
3 7
6 1
8
1112
2
3 8
6 0
8
1113
2
3 8
6 1
9
1134
2
3 9
6 0
9
1135
2
3 9
6 1
10
1156
2
3 10
6 0
10
1157
2
3 10
6 1
11
1178
2
3 11
6 0
11
1179
2
3 11
6 1
12
1200
2
3 12
6 0
12
1201
2
3 12
6 1
26
0
1223
2
2 0
7 1
0
1222
2
2 0
7 0
1
1244
2
2 1
7 0
1
1245
2
2 1
7 1
2
1266
2
2 2
7 0
2
1267
2
2 2
7 1
3
1288
2
2 3
7 0
3
1289
2
2 3
7 1
4
1310
2
2 4
7 0
4
1311
2
2 4
7 1
5
1332
2
2 5
7 0
5
1333
2
2 5
7 1
6
1355
2
2 6
7 1
6
1354
2
2 6
7 0
7
1376
2
2 7
7 0
7
1377
2
2 7
7 1
8
1398
2
2 8
7 0
8
1399
2
2 8
7 1
9
1420
2
2 9
7 0
9
1421
2
2 9
7 1
10
1442
2
2 10
7 0
10
1443
2
2 10
7 1
11
1464
2
2 11
7 0
11
1465
2
2 11
7 1
12
1486
2
2 12
7 0
12
1487
2
2 12
7 1
26
0
1509
2
1 0
8 1
0
1508
2
1 0
8 0
1
1530
2
1 1
8 0
1
1531
2
1 1
8 1
2
1552
2
1 2
8 0
2
1553
2
1 2
8 1
3
1574
2
1 3
8 0
3
1575
2
1 3
8 1
4
1596
2
1 4
8 0
4
1597
2
1 4
8 1
5
1618
2
1 5
8 0
5
1619
2
1 5
8 1
6
1641
2
1 6
8 1
6
1640
2
1 6
8 0
7
1662
2
1 7
8 0
7
1663
2
1 7
8 1
8
1684
2
1 8
8 0
8
1685
2
1 8
8 1
9
1706
2
1 9
8 0
9
1707
2
1 9
8 1
10
1728
2
1 10
8 0
10
1729
2
1 10
8 1
11
1750
2
1 11
8 0
11
1751
2
1 11
8 1
12
1772
2
1 12
8 0
12
1773
2
1 12
8 1
26
0
1795
2
0 0
9 1
0
1794
2
0 0
9 0
1
1816
2
0 1
9 0
1
1817
2
0 1
9 1
2
1838
2
0 2
9 0
2
1839
2
0 2
9 1
3
1860
2
0 3
9 0
3
1861
2
0 3
9 1
4
1882
2
0 4
9 0
4
1883
2
0 4
9 1
5
1904
2
0 5
9 0
5
1905
2
0 5
9 1
6
1927
2
0 6
9 1
6
1926
2
0 6
9 0
7
1948
2
0 7
9 0
7
1949
2
0 7
9 1
8
1970
2
0 8
9 0
8
1971
2
0 8
9 1
9
1992
2
0 9
9 0
9
1993
2
0 9
9 1
10
2014
2
0 10
9 0
10
2015
2
0 10
9 1
11
2036
2
0 11
9 0
11
2037
2
0 11
9 1
12
2058
2
0 12
9 0
12
2059
2
0 12
9 1
end_DTG
begin_CG
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
9 572
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
8 572
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
7 572
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
6 572
12
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
5 572
11
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
11
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
11
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
11
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
11
10 52
11 52
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
5
5 52
6 52
7 52
8 52
9 52
end_CG
