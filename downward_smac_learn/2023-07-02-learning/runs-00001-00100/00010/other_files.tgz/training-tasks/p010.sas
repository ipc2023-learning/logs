begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var5
-1
4
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
end_variable
begin_variable
var4
-1
4
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
end_variable
begin_variable
var6
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var0
-1
6
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom in(p1, v1)
Atom in(p1, v2)
end_variable
begin_variable
var1
-1
6
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom in(p2, v1)
Atom in(p2, v2)
end_variable
begin_variable
var2
-1
6
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom in(p3, v1)
Atom in(p3, v2)
end_variable
begin_variable
var3
-1
6
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom in(p4, v1)
Atom in(p4, v2)
end_variable
0
begin_state
1
3
2
2
2
2
1
0
end_state
begin_goal
4
4 3
5 1
6 2
7 3
end_goal
140
begin_operator
drive v1 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 0 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
1 0
2
0 4 4 0
0 2 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
1 0
2
0 4 4 0
0 2 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
1 0
2
0 5 4 0
0 2 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
1 0
2
0 5 4 0
0 2 1 2
0
end_operator
begin_operator
drop v1 l1 p3 c0 c1
1
1 0
2
0 6 4 0
0 2 0 1
0
end_operator
begin_operator
drop v1 l1 p3 c1 c2
1
1 0
2
0 6 4 0
0 2 1 2
0
end_operator
begin_operator
drop v1 l1 p4 c0 c1
1
1 0
2
0 7 4 0
0 2 0 1
0
end_operator
begin_operator
drop v1 l1 p4 c1 c2
1
1 0
2
0 7 4 0
0 2 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
1 1
2
0 4 4 1
0 2 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c1 c2
1
1 1
2
0 4 4 1
0 2 1 2
0
end_operator
begin_operator
drop v1 l2 p2 c0 c1
1
1 1
2
0 5 4 1
0 2 0 1
0
end_operator
begin_operator
drop v1 l2 p2 c1 c2
1
1 1
2
0 5 4 1
0 2 1 2
0
end_operator
begin_operator
drop v1 l2 p3 c0 c1
1
1 1
2
0 6 4 1
0 2 0 1
0
end_operator
begin_operator
drop v1 l2 p3 c1 c2
1
1 1
2
0 6 4 1
0 2 1 2
0
end_operator
begin_operator
drop v1 l2 p4 c0 c1
1
1 1
2
0 7 4 1
0 2 0 1
0
end_operator
begin_operator
drop v1 l2 p4 c1 c2
1
1 1
2
0 7 4 1
0 2 1 2
0
end_operator
begin_operator
drop v1 l3 p1 c0 c1
1
1 2
2
0 4 4 2
0 2 0 1
0
end_operator
begin_operator
drop v1 l3 p1 c1 c2
1
1 2
2
0 4 4 2
0 2 1 2
0
end_operator
begin_operator
drop v1 l3 p2 c0 c1
1
1 2
2
0 5 4 2
0 2 0 1
0
end_operator
begin_operator
drop v1 l3 p2 c1 c2
1
1 2
2
0 5 4 2
0 2 1 2
0
end_operator
begin_operator
drop v1 l3 p3 c0 c1
1
1 2
2
0 6 4 2
0 2 0 1
0
end_operator
begin_operator
drop v1 l3 p3 c1 c2
1
1 2
2
0 6 4 2
0 2 1 2
0
end_operator
begin_operator
drop v1 l3 p4 c0 c1
1
1 2
2
0 7 4 2
0 2 0 1
0
end_operator
begin_operator
drop v1 l3 p4 c1 c2
1
1 2
2
0 7 4 2
0 2 1 2
0
end_operator
begin_operator
drop v1 l4 p1 c0 c1
1
1 3
2
0 4 4 3
0 2 0 1
0
end_operator
begin_operator
drop v1 l4 p1 c1 c2
1
1 3
2
0 4 4 3
0 2 1 2
0
end_operator
begin_operator
drop v1 l4 p2 c0 c1
1
1 3
2
0 5 4 3
0 2 0 1
0
end_operator
begin_operator
drop v1 l4 p2 c1 c2
1
1 3
2
0 5 4 3
0 2 1 2
0
end_operator
begin_operator
drop v1 l4 p3 c0 c1
1
1 3
2
0 6 4 3
0 2 0 1
0
end_operator
begin_operator
drop v1 l4 p3 c1 c2
1
1 3
2
0 6 4 3
0 2 1 2
0
end_operator
begin_operator
drop v1 l4 p4 c0 c1
1
1 3
2
0 7 4 3
0 2 0 1
0
end_operator
begin_operator
drop v1 l4 p4 c1 c2
1
1 3
2
0 7 4 3
0 2 1 2
0
end_operator
begin_operator
drop v2 l1 p1 c0 c1
1
0 0
2
0 4 5 0
0 3 0 1
0
end_operator
begin_operator
drop v2 l1 p1 c1 c2
1
0 0
2
0 4 5 0
0 3 1 2
0
end_operator
begin_operator
drop v2 l1 p2 c0 c1
1
0 0
2
0 5 5 0
0 3 0 1
0
end_operator
begin_operator
drop v2 l1 p2 c1 c2
1
0 0
2
0 5 5 0
0 3 1 2
0
end_operator
begin_operator
drop v2 l1 p3 c0 c1
1
0 0
2
0 6 5 0
0 3 0 1
0
end_operator
begin_operator
drop v2 l1 p3 c1 c2
1
0 0
2
0 6 5 0
0 3 1 2
0
end_operator
begin_operator
drop v2 l1 p4 c0 c1
1
0 0
2
0 7 5 0
0 3 0 1
0
end_operator
begin_operator
drop v2 l1 p4 c1 c2
1
0 0
2
0 7 5 0
0 3 1 2
0
end_operator
begin_operator
drop v2 l2 p1 c0 c1
1
0 1
2
0 4 5 1
0 3 0 1
0
end_operator
begin_operator
drop v2 l2 p1 c1 c2
1
0 1
2
0 4 5 1
0 3 1 2
0
end_operator
begin_operator
drop v2 l2 p2 c0 c1
1
0 1
2
0 5 5 1
0 3 0 1
0
end_operator
begin_operator
drop v2 l2 p2 c1 c2
1
0 1
2
0 5 5 1
0 3 1 2
0
end_operator
begin_operator
drop v2 l2 p3 c0 c1
1
0 1
2
0 6 5 1
0 3 0 1
0
end_operator
begin_operator
drop 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
switch 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
138
check 1
139
check 0
check 0
switch 1
check 0
switch 2
check 0
check 1
18
check 1
19
check 0
check 0
switch 2
check 0
check 1
26
check 1
27
check 0
check 0
switch 2
check 0
check 1
34
check 1
35
check 0
check 0
switch 2
check 0
check 1
42
check 1
43
check 0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 1
50
check 1
51
check 0
check 0
switch 3
check 0
check 1
58
check 1
59
check 0
check 0
switch 3
check 0
check 1
66
check 1
67
check 0
check 0
switch 3
check 0
check 1
74
check 1
75
check 0
check 0
check 0
switch 1
check 0
check 1
0
check 2
1
2
check 1
3
check 2
4
5
switch 0
check 0
check 1
6
check 2
7
8
check 1
9
check 2
10
11
check 0
end_SG
begin_DTG
1
3
6
0
2
2
7
0
3
8
0
1
1
9
0
2
0
10
0
1
11
0
end_DTG
begin_DTG
1
3
0
0
2
2
1
0
3
2
0
1
1
3
0
2
0
4
0
1
5
0
end_DTG
begin_DTG
16
1
12
2
4 4
1 0
1
14
2
5 4
1 0
1
16
2
6 4
1 0
1
18
2
7 4
1 0
1
20
2
4 4
1 1
1
22
2
5 4
1 1
1
24
2
6 4
1 1
1
26
2
7 4
1 1
1
28
2
4 4
1 2
1
30
2
5 4
1 2
1
32
2
6 4
1 2
1
34
2
7 4
1 2
1
36
2
4 4
1 3
1
38
2
5 4
1 3
1
40
2
6 4
1 3
1
42
2
7 4
1 3
32
0
76
2
4 0
1 0
0
106
2
7 3
1 3
0
104
2
6 3
1 3
0
102
2
5 3
1 3
0
100
2
4 3
1 3
0
98
2
7 2
1 2
0
96
2
6 2
1 2
0
94
2
5 2
1 2
0
92
2
4 2
1 2
0
90
2
7 1
1 1
0
88
2
6 1
1 1
0
86
2
5 1
1 1
0
84
2
4 1
1 1
0
82
2
7 0
1 0
0
80
2
6 0
1 0
0
78
2
5 0
1 0
2
13
2
4 4
1 0
2
43
2
7 4
1 3
2
41
2
6 4
1 3
2
39
2
5 4
1 3
2
37
2
4 4
1 3
2
35
2
7 4
1 2
2
33
2
6 4
1 2
2
31
2
5 4
1 2
2
29
2
4 4
1 2
2
27
2
7 4
1 1
2
25
2
6 4
1 1
2
23
2
5 4
1 1
2
21
2
4 4
1 1
2
19
2
7 4
1 0
2
17
2
6 4
1 0
2
15
2
5 4
1 0
16
1
77
2
4 0
1 0
1
79
2
5 0
1 0
1
81
2
6 0
1 0
1
83
2
7 0
1 0
1
85
2
4 1
1 1
1
87
2
5 1
1 1
1
89
2
6 1
1 1
1
91
2
7 1
1 1
1
93
2
4 2
1 2
1
95
2
5 2
1 2
1
97
2
6 2
1 2
1
99
2
7 2
1 2
1
101
2
4 3
1 3
1
103
2
5 3
1 3
1
105
2
6 3
1 3
1
107
2
7 3
1 3
end_DTG
begin_DTG
16
1
44
2
4 5
0 0
1
46
2
5 5
0 0
1
48
2
6 5
0 0
1
50
2
7 5
0 0
1
52
2
4 5
0 1
1
54
2
5 5
0 1
1
56
2
6 5
0 1
1
58
2
7 5
0 1
1
60
2
4 5
0 2
1
62
2
5 5
0 2
1
64
2
6 5
0 2
1
66
2
7 5
0 2
1
68
2
4 5
0 3
1
70
2
5 5
0 3
1
72
2
6 5
0 3
1
74
2
7 5
0 3
32
0
108
2
4 0
0 0
0
138
2
7 3
0 3
0
136
2
6 3
0 3
0
134
2
5 3
0 3
0
132
2
4 3
0 3
0
130
2
7 2
0 2
0
128
2
6 2
0 2
0
126
2
5 2
0 2
0
124
2
4 2
0 2
0
122
2
7 1
0 1
0
120
2
6 1
0 1
0
118
2
5 1
0 1
0
116
2
4 1
0 1
0
114
2
7 0
0 0
0
112
2
6 0
0 0
0
110
2
5 0
0 0
2
45
2
4 5
0 0
2
75
2
7 5
0 3
2
73
2
6 5
0 3
2
71
2
5 5
0 3
2
69
2
4 5
0 3
2
67
2
7 5
0 2
2
65
2
6 5
0 2
2
63
2
5 5
0 2
2
61
2
4 5
0 2
2
59
2
7 5
0 1
2
57
2
6 5
0 1
2
55
2
5 5
0 1
2
53
2
4 5
0 1
2
51
2
7 5
0 0
2
49
2
6 5
0 0
2
47
2
5 5
0 0
16
1
109
2
4 0
0 0
1
111
2
5 0
0 0
1
113
2
6 0
0 0
1
115
2
7 0
0 0
1
117
2
4 1
0 1
1
119
2
5 1
0 1
1
121
2
6 1
0 1
1
123
2
7 1
0 1
1
125
2
4 2
0 2
1
127
2
5 2
0 2
1
129
2
6 2
0 2
1
131
2
7 2
0 2
1
133
2
4 3
0 3
1
135
2
5 3
0 3
1
137
2
6 3
0 3
1
139
2
7 3
0 3
end_DTG
begin_DTG
4
4
76
2
1 0
2 1
4
77
2
1 0
2 2
5
108
2
0 0
3 1
5
109
2
0 0
3 2
4
4
84
2
1 1
2 1
4
85
2
1 1
2 2
5
116
2
0 1
3 1
5
117
2
0 1
3 2
4
4
92
2
1 2
2 1
4
93
2
1 2
2 2
5
124
2
0 2
3 1
5
125
2
0 2
3 2
4
4
100
2
1 3
2 1
4
101
2
1 3
2 2
5
132
2
0 3
3 1
5
133
2
0 3
3 2
8
0
12
2
1 0
2 0
0
13
2
1 0
2 1
1
20
2
1 1
2 0
1
21
2
1 1
2 1
2
28
2
1 2
2 0
2
29
2
1 2
2 1
3
36
2
1 3
2 0
3
37
2
1 3
2 1
8
0
44
2
0 0
3 0
0
45
2
0 0
3 1
1
52
2
0 1
3 0
1
53
2
0 1
3 1
2
60
2
0 2
3 0
2
61
2
0 2
3 1
3
68
2
0 3
3 0
3
69
2
0 3
3 1
end_DTG
begin_DTG
4
4
78
2
1 0
2 1
4
79
2
1 0
2 2
5
110
2
0 0
3 1
5
111
2
0 0
3 2
4
4
86
2
1 1
2 1
4
87
2
1 1
2 2
5
118
2
0 1
3 1
5
119
2
0 1
3 2
4
4
94
2
1 2
2 1
4
95
2
1 2
2 2
5
126
2
0 2
3 1
5
127
2
0 2
3 2
4
4
102
2
1 3
2 1
4
103
2
1 3
2 2
5
134
2
0 3
3 1
5
135
2
0 3
3 2
8
0
14
2
1 0
2 0
0
15
2
1 0
2 1
1
22
2
1 1
2 0
1
23
2
1 1
2 1
2
30
2
1 2
2 0
2
31
2
1 2
2 1
3
38
2
1 3
2 0
3
39
2
1 3
2 1
8
0
46
2
0 0
3 0
0
47
2
0 0
3 1
1
54
2
0 1
3 0
1
55
2
0 1
3 1
2
62
2
0 2
3 0
2
63
2
0 2
3 1
3
70
2
0 3
3 0
3
71
2
0 3
3 1
end_DTG
begin_DTG
4
4
80
2
1 0
2 1
4
81
2
1 0
2 2
5
112
2
0 0
3 1
5
113
2
0 0
3 2
4
4
88
2
1 1
2 1
4
89
2
1 1
2 2
5
120
2
0 1
3 1
5
121
2
0 1
3 2
4
4
96
2
1 2
2 1
4
97
2
1 2
2 2
5
128
2
0 2
3 1
5
129
2
0 2
3 2
4
4
104
2
1 3
2 1
4
105
2
1 3
2 2
5
136
2
0 3
3 1
5
137
2
0 3
3 2
8
0
16
2
1 0
2 0
0
17
2
1 0
2 1
1
24
2
1 1
2 0
1
25
2
1 1
2 1
2
32
2
1 2
2 0
2
33
2
1 2
2 1
3
40
2
1 3
2 0
3
41
2
1 3
2 1
8
0
48
2
0 0
3 0
0
49
2
0 0
3 1
1
56
2
0 1
3 0
1
57
2
0 1
3 1
2
64
2
0 2
3 0
2
65
2
0 2
3 1
3
72
2
0 3
3 0
3
73
2
0 3
3 1
end_DTG
begin_DTG
4
4
82
2
1 0
2 1
4
83
2
1 0
2 2
5
114
2
0 0
3 1
5
115
2
0 0
3 2
4
4
90
2
1 1
2 1
4
91
2
1 1
2 2
5
122
2
0 1
3 1
5
123
2
0 1
3 2
4
4
98
2
1 2
2 1
4
99
2
1 2
2 2
5
130
2
0 2
3 1
5
131
2
0 2
3 2
4
4
106
2
1 3
2 1
4
107
2
1 3
2 2
5
138
2
0 3
3 1
5
139
2
0 3
3 2
8
0
18
2
1 0
2 0
0
19
2
1 0
2 1
1
26
2
1 1
2 0
1
27
2
1 1
2 1
2
34
2
1 2
2 0
2
35
2
1 2
2 1
3
42
2
1 3
2 0
3
43
2
1 3
2 1
8
0
50
2
0 0
3 0
0
51
2
0 0
3 1
1
58
2
0 1
3 0
1
59
2
0 1
3 1
2
66
2
0 2
3 0
2
67
2
0 2
3 1
3
74
2
0 3
3 0
3
75
2
0 3
3 1
end_DTG
begin_CG
5
4 16
5 16
6 16
7 16
3 64
5
4 16
5 16
6 16
7 16
2 64
4
4 16
5 16
6 16
7 16
4
4 16
5 16
6 16
7 16
2
2 16
3 16
2
2 16
3 16
2
2 16
3 16
2
2 16
3 16
end_CG
