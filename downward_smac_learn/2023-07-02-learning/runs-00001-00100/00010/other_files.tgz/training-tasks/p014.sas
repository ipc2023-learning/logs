begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var5
-1
6
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
end_variable
begin_variable
var4
-1
6
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
end_variable
begin_variable
var3
-1
6
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
end_variable
begin_variable
var6
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
9
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
9
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
9
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
0
begin_state
2
1
5
1
1
1
5
2
0
end_state
begin_goal
3
6 3
7 1
8 4
end_goal
306
begin_operator
drive v1 l1 l2
0
1
0 2 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 2 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 2 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 2 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 2 2 5
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 2 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 2 3 5
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 2 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 2 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 2 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 2 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 2 5 4
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 1 0 5
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 1 1 4
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v2 l3 l4
0
1
0 1 2 3
0
end_operator
begin_operator
drive v2 l3 l5
0
1
0 1 2 4
0
end_operator
begin_operator
drive v2 l3 l6
0
1
0 1 2 5
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l3
0
1
0 1 3 2
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l4 l6
0
1
0 1 3 5
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 1 4 1
0
end_operator
begin_operator
drive v2 l5 l3
0
1
0 1 4 2
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 1 4 5
0
end_operator
begin_operator
drive v2 l6 l1
0
1
0 1 5 0
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 1 5 1
0
end_operator
begin_operator
drive v2 l6 l3
0
1
0 1 5 2
0
end_operator
begin_operator
drive v2 l6 l4
0
1
0 1 5 3
0
end_operator
begin_operator
drive v2 l6 l5
0
1
0 1 5 4
0
end_operator
begin_operator
drive v3 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v3 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l6
0
1
0 0 0 5
0
end_operator
begin_operator
driv




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
6 4
1 4
1
257
2
8 3
1 3
1
255
2
7 3
1 3
1
235
2
6 0
1 0
1
251
2
8 2
1 2
1
249
2
7 2
1 2
1
247
2
6 2
1 2
1
245
2
8 1
1 1
1
243
2
7 1
1 1
1
241
2
6 1
1 1
1
239
2
8 0
1 0
1
237
2
7 0
1 0
end_DTG
begin_DTG
18
1
180
2
6 8
0 3
1
196
2
8 8
0 5
1
194
2
7 8
0 5
1
192
2
6 8
0 5
1
190
2
8 8
0 4
1
188
2
7 8
0 4
1
186
2
6 8
0 4
1
184
2
8 8
0 3
1
182
2
7 8
0 3
1
162
2
6 8
0 0
1
178
2
8 8
0 2
1
176
2
7 8
0 2
1
174
2
6 8
0 2
1
172
2
8 8
0 1
1
170
2
7 8
0 1
1
168
2
6 8
0 1
1
166
2
8 8
0 0
1
164
2
7 8
0 0
36
0
288
2
6 3
0 3
0
272
2
7 0
0 0
0
274
2
8 0
0 0
0
276
2
6 1
0 1
0
278
2
7 1
0 1
0
280
2
8 1
0 1
0
282
2
6 2
0 2
0
284
2
7 2
0 2
0
286
2
8 2
0 2
0
270
2
6 0
0 0
0
290
2
7 3
0 3
0
292
2
8 3
0 3
0
294
2
6 4
0 4
0
296
2
7 4
0 4
0
298
2
8 4
0 4
0
300
2
6 5
0 5
0
302
2
7 5
0 5
0
304
2
8 5
0 5
2
181
2
6 8
0 3
2
165
2
7 8
0 0
2
167
2
8 8
0 0
2
169
2
6 8
0 1
2
171
2
7 8
0 1
2
173
2
8 8
0 1
2
175
2
6 8
0 2
2
177
2
7 8
0 2
2
179
2
8 8
0 2
2
163
2
6 8
0 0
2
183
2
7 8
0 3
2
185
2
8 8
0 3
2
187
2
6 8
0 4
2
189
2
7 8
0 4
2
191
2
8 8
0 4
2
193
2
6 8
0 5
2
195
2
7 8
0 5
2
197
2
8 8
0 5
18
1
289
2
6 3
0 3
1
305
2
8 5
0 5
1
303
2
7 5
0 5
1
301
2
6 5
0 5
1
299
2
8 4
0 4
1
297
2
7 4
0 4
1
295
2
6 4
0 4
1
293
2
8 3
0 3
1
291
2
7 3
0 3
1
271
2
6 0
0 0
1
287
2
8 2
0 2
1
285
2
7 2
0 2
1
283
2
6 2
0 2
1
281
2
8 1
0 1
1
279
2
7 1
0 1
1
277
2
6 1
0 1
1
275
2
8 0
0 0
1
273
2
7 0
0 0
end_DTG
begin_DTG
6
6
198
2
2 0
3 1
6
199
2
2 0
3 2
7
234
2
1 0
4 1
7
235
2
1 0
4 2
8
270
2
0 0
5 1
8
271
2
0 0
5 2
6
6
204
2
2 1
3 1
6
205
2
2 1
3 2
7
240
2
1 1
4 1
7
241
2
1 1
4 2
8
276
2
0 1
5 1
8
277
2
0 1
5 2
6
6
210
2
2 2
3 1
6
211
2
2 2
3 2
7
246
2
1 2
4 1
7
247
2
1 2
4 2
8
282
2
0 2
5 1
8
283
2
0 2
5 2
6
6
216
2
2 3
3 1
6
217
2
2 3
3 2
7
252
2
1 3
4 1
7
253
2
1 3
4 2
8
288
2
0 3
5 1
8
289
2
0 3
5 2
6
6
222
2
2 4
3 1
6
223
2
2 4
3 2
7
258
2
1 4
4 1
7
259
2
1 4
4 2
8
294
2
0 4
5 1
8
295
2
0 4
5 2
6
6
228
2
2 5
3 1
6
229
2
2 5
3 2
7
264
2
1 5
4 1
7
265
2
1 5
4 2
8
300
2
0 5
5 1
8
301
2
0 5
5 2
12
0
90
2
2 0
3 0
0
91
2
2 0
3 1
1
96
2
2 1
3 0
1
97
2
2 1
3 1
2
102
2
2 2
3 0
2
103
2
2 2
3 1
3
108
2
2 3
3 0
3
109
2
2 3
3 1
4
114
2
2 4
3 0
4
115
2
2 4
3 1
5
120
2
2 5
3 0
5
121
2
2 5
3 1
12
0
126
2
1 0
4 0
0
127
2
1 0
4 1
1
132
2
1 1
4 0
1
133
2
1 1
4 1
2
138
2
1 2
4 0
2
139
2
1 2
4 1
3
144
2
1 3
4 0
3
145
2
1 3
4 1
4
150
2
1 4
4 0
4
151
2
1 4
4 1
5
156
2
1 5
4 0
5
157
2
1 5
4 1
12
0
162
2
0 0
5 0
0
163
2
0 0
5 1
1
168
2
0 1
5 0
1
169
2
0 1
5 1
2
174
2
0 2
5 0
2
175
2
0 2
5 1
3
180
2
0 3
5 0
3
181
2
0 3
5 1
4
186
2
0 4
5 0
4
187
2
0 4
5 1
5
192
2
0 5
5 0
5
193
2
0 5
5 1
end_DTG
begin_DTG
6
6
200
2
2 0
3 1
6
201
2
2 0
3 2
7
236
2
1 0
4 1
7
237
2
1 0
4 2
8
272
2
0 0
5 1
8
273
2
0 0
5 2
6
6
206
2
2 1
3 1
6
207
2
2 1
3 2
7
242
2
1 1
4 1
7
243
2
1 1
4 2
8
278
2
0 1
5 1
8
279
2
0 1
5 2
6
6
212
2
2 2
3 1
6
213
2
2 2
3 2
7
248
2
1 2
4 1
7
249
2
1 2
4 2
8
284
2
0 2
5 1
8
285
2
0 2
5 2
6
6
218
2
2 3
3 1
6
219
2
2 3
3 2
7
254
2
1 3
4 1
7
255
2
1 3
4 2
8
290
2
0 3
5 1
8
291
2
0 3
5 2
6
6
224
2
2 4
3 1
6
225
2
2 4
3 2
7
260
2
1 4
4 1
7
261
2
1 4
4 2
8
296
2
0 4
5 1
8
297
2
0 4
5 2
6
6
230
2
2 5
3 1
6
231
2
2 5
3 2
7
266
2
1 5
4 1
7
267
2
1 5
4 2
8
302
2
0 5
5 1
8
303
2
0 5
5 2
12
0
92
2
2 0
3 0
0
93
2
2 0
3 1
1
98
2
2 1
3 0
1
99
2
2 1
3 1
2
104
2
2 2
3 0
2
105
2
2 2
3 1
3
110
2
2 3
3 0
3
111
2
2 3
3 1
4
116
2
2 4
3 0
4
117
2
2 4
3 1
5
122
2
2 5
3 0
5
123
2
2 5
3 1
12
0
128
2
1 0
4 0
0
129
2
1 0
4 1
1
134
2
1 1
4 0
1
135
2
1 1
4 1
2
140
2
1 2
4 0
2
141
2
1 2
4 1
3
146
2
1 3
4 0
3
147
2
1 3
4 1
4
152
2
1 4
4 0
4
153
2
1 4
4 1
5
158
2
1 5
4 0
5
159
2
1 5
4 1
12
0
164
2
0 0
5 0
0
165
2
0 0
5 1
1
170
2
0 1
5 0
1
171
2
0 1
5 1
2
176
2
0 2
5 0
2
177
2
0 2
5 1
3
182
2
0 3
5 0
3
183
2
0 3
5 1
4
188
2
0 4
5 0
4
189
2
0 4
5 1
5
194
2
0 5
5 0
5
195
2
0 5
5 1
end_DTG
begin_DTG
6
6
202
2
2 0
3 1
6
203
2
2 0
3 2
7
238
2
1 0
4 1
7
239
2
1 0
4 2
8
274
2
0 0
5 1
8
275
2
0 0
5 2
6
6
208
2
2 1
3 1
6
209
2
2 1
3 2
7
244
2
1 1
4 1
7
245
2
1 1
4 2
8
280
2
0 1
5 1
8
281
2
0 1
5 2
6
6
214
2
2 2
3 1
6
215
2
2 2
3 2
7
250
2
1 2
4 1
7
251
2
1 2
4 2
8
286
2
0 2
5 1
8
287
2
0 2
5 2
6
6
220
2
2 3
3 1
6
221
2
2 3
3 2
7
256
2
1 3
4 1
7
257
2
1 3
4 2
8
292
2
0 3
5 1
8
293
2
0 3
5 2
6
6
226
2
2 4
3 1
6
227
2
2 4
3 2
7
262
2
1 4
4 1
7
263
2
1 4
4 2
8
298
2
0 4
5 1
8
299
2
0 4
5 2
6
6
232
2
2 5
3 1
6
233
2
2 5
3 2
7
268
2
1 5
4 1
7
269
2
1 5
4 2
8
304
2
0 5
5 1
8
305
2
0 5
5 2
12
0
94
2
2 0
3 0
0
95
2
2 0
3 1
1
100
2
2 1
3 0
1
101
2
2 1
3 1
2
106
2
2 2
3 0
2
107
2
2 2
3 1
3
112
2
2 3
3 0
3
113
2
2 3
3 1
4
118
2
2 4
3 0
4
119
2
2 4
3 1
5
124
2
2 5
3 0
5
125
2
2 5
3 1
12
0
130
2
1 0
4 0
0
131
2
1 0
4 1
1
136
2
1 1
4 0
1
137
2
1 1
4 1
2
142
2
1 2
4 0
2
143
2
1 2
4 1
3
148
2
1 3
4 0
3
149
2
1 3
4 1
4
154
2
1 4
4 0
4
155
2
1 4
4 1
5
160
2
1 5
4 0
5
161
2
1 5
4 1
12
0
166
2
0 0
5 0
0
167
2
0 0
5 1
1
172
2
0 1
5 0
1
173
2
0 1
5 1
2
178
2
0 2
5 0
2
179
2
0 2
5 1
3
184
2
0 3
5 0
3
185
2
0 3
5 1
4
190
2
0 4
5 0
4
191
2
0 4
5 1
5
196
2
0 5
5 0
5
197
2
0 5
5 1
end_DTG
begin_CG
4
6 24
7 24
8 24
5 72
4
6 24
7 24
8 24
4 72
4
6 24
7 24
8 24
3 72
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
end_CG
