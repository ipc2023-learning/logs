begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var5
-1
6
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
end_variable
begin_variable
var4
-1
6
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
end_variable
begin_variable
var3
-1
6
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
end_variable
begin_variable
var6
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
9
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
9
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
9
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
0
begin_state
2
0
1
1
2
2
4
3
5
end_state
begin_goal
3
6 0
7 4
8 1
end_goal
300
begin_operator
drive v1 l1 l2
0
1
0 2 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 2 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 2 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 2 2 4
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 2 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 2 3 5
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 2 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 2 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 2 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 2 5 4
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 1 0 5
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 1 1 4
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v2 l3 l4
0
1
0 1 2 3
0
end_operator
begin_operator
drive v2 l3 l5
0
1
0 1 2 4
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l3
0
1
0 1 3 2
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l4 l6
0
1
0 1 3 5
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 1 4 1
0
end_operator
begin_operator
drive v2 l5 l3
0
1
0 1 4 2
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 1 4 5
0
end_operator
begin_operator
drive v2 l6 l1
0
1
0 1 5 0
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 1 5 1
0
end_operator
begin_operator
drive v2 l6 l4
0
1
0 1 5 3
0
end_operator
begin_operator
drive v2 l6 l5
0
1
0 1 5 4
0
end_operator
begin_operator
drive v3 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v3 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l6
0
1
0 0 0 5
0
end_operator
begin_operator
drive v3 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v3 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v3 l2 l5
0
1
0 0 1 4
0
end_operator
begin_operator
driv




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
253
2
6 4
1 4
1
251
2
8 3
1 3
1
249
2
7 3
1 3
1
229
2
6 0
1 0
1
245
2
8 2
1 2
1
243
2
7 2
1 2
1
241
2
6 2
1 2
1
239
2
8 1
1 1
1
237
2
7 1
1 1
1
235
2
6 1
1 1
1
233
2
8 0
1 0
1
231
2
7 0
1 0
end_DTG
begin_DTG
18
1
174
2
6 8
0 3
1
190
2
8 8
0 5
1
188
2
7 8
0 5
1
186
2
6 8
0 5
1
184
2
8 8
0 4
1
182
2
7 8
0 4
1
180
2
6 8
0 4
1
178
2
8 8
0 3
1
176
2
7 8
0 3
1
156
2
6 8
0 0
1
172
2
8 8
0 2
1
170
2
7 8
0 2
1
168
2
6 8
0 2
1
166
2
8 8
0 1
1
164
2
7 8
0 1
1
162
2
6 8
0 1
1
160
2
8 8
0 0
1
158
2
7 8
0 0
36
0
282
2
6 3
0 3
0
266
2
7 0
0 0
0
268
2
8 0
0 0
0
270
2
6 1
0 1
0
272
2
7 1
0 1
0
274
2
8 1
0 1
0
276
2
6 2
0 2
0
278
2
7 2
0 2
0
280
2
8 2
0 2
0
264
2
6 0
0 0
0
284
2
7 3
0 3
0
286
2
8 3
0 3
0
288
2
6 4
0 4
0
290
2
7 4
0 4
0
292
2
8 4
0 4
0
294
2
6 5
0 5
0
296
2
7 5
0 5
0
298
2
8 5
0 5
2
175
2
6 8
0 3
2
159
2
7 8
0 0
2
161
2
8 8
0 0
2
163
2
6 8
0 1
2
165
2
7 8
0 1
2
167
2
8 8
0 1
2
169
2
6 8
0 2
2
171
2
7 8
0 2
2
173
2
8 8
0 2
2
157
2
6 8
0 0
2
177
2
7 8
0 3
2
179
2
8 8
0 3
2
181
2
6 8
0 4
2
183
2
7 8
0 4
2
185
2
8 8
0 4
2
187
2
6 8
0 5
2
189
2
7 8
0 5
2
191
2
8 8
0 5
18
1
283
2
6 3
0 3
1
299
2
8 5
0 5
1
297
2
7 5
0 5
1
295
2
6 5
0 5
1
293
2
8 4
0 4
1
291
2
7 4
0 4
1
289
2
6 4
0 4
1
287
2
8 3
0 3
1
285
2
7 3
0 3
1
265
2
6 0
0 0
1
281
2
8 2
0 2
1
279
2
7 2
0 2
1
277
2
6 2
0 2
1
275
2
8 1
0 1
1
273
2
7 1
0 1
1
271
2
6 1
0 1
1
269
2
8 0
0 0
1
267
2
7 0
0 0
end_DTG
begin_DTG
6
6
192
2
2 0
3 1
6
193
2
2 0
3 2
7
228
2
1 0
4 1
7
229
2
1 0
4 2
8
264
2
0 0
5 1
8
265
2
0 0
5 2
6
6
198
2
2 1
3 1
6
199
2
2 1
3 2
7
234
2
1 1
4 1
7
235
2
1 1
4 2
8
270
2
0 1
5 1
8
271
2
0 1
5 2
6
6
204
2
2 2
3 1
6
205
2
2 2
3 2
7
240
2
1 2
4 1
7
241
2
1 2
4 2
8
276
2
0 2
5 1
8
277
2
0 2
5 2
6
6
210
2
2 3
3 1
6
211
2
2 3
3 2
7
246
2
1 3
4 1
7
247
2
1 3
4 2
8
282
2
0 3
5 1
8
283
2
0 3
5 2
6
6
216
2
2 4
3 1
6
217
2
2 4
3 2
7
252
2
1 4
4 1
7
253
2
1 4
4 2
8
288
2
0 4
5 1
8
289
2
0 4
5 2
6
6
222
2
2 5
3 1
6
223
2
2 5
3 2
7
258
2
1 5
4 1
7
259
2
1 5
4 2
8
294
2
0 5
5 1
8
295
2
0 5
5 2
12
0
84
2
2 0
3 0
0
85
2
2 0
3 1
1
90
2
2 1
3 0
1
91
2
2 1
3 1
2
96
2
2 2
3 0
2
97
2
2 2
3 1
3
102
2
2 3
3 0
3
103
2
2 3
3 1
4
108
2
2 4
3 0
4
109
2
2 4
3 1
5
114
2
2 5
3 0
5
115
2
2 5
3 1
12
0
120
2
1 0
4 0
0
121
2
1 0
4 1
1
126
2
1 1
4 0
1
127
2
1 1
4 1
2
132
2
1 2
4 0
2
133
2
1 2
4 1
3
138
2
1 3
4 0
3
139
2
1 3
4 1
4
144
2
1 4
4 0
4
145
2
1 4
4 1
5
150
2
1 5
4 0
5
151
2
1 5
4 1
12
0
156
2
0 0
5 0
0
157
2
0 0
5 1
1
162
2
0 1
5 0
1
163
2
0 1
5 1
2
168
2
0 2
5 0
2
169
2
0 2
5 1
3
174
2
0 3
5 0
3
175
2
0 3
5 1
4
180
2
0 4
5 0
4
181
2
0 4
5 1
5
186
2
0 5
5 0
5
187
2
0 5
5 1
end_DTG
begin_DTG
6
6
194
2
2 0
3 1
6
195
2
2 0
3 2
7
230
2
1 0
4 1
7
231
2
1 0
4 2
8
266
2
0 0
5 1
8
267
2
0 0
5 2
6
6
200
2
2 1
3 1
6
201
2
2 1
3 2
7
236
2
1 1
4 1
7
237
2
1 1
4 2
8
272
2
0 1
5 1
8
273
2
0 1
5 2
6
6
206
2
2 2
3 1
6
207
2
2 2
3 2
7
242
2
1 2
4 1
7
243
2
1 2
4 2
8
278
2
0 2
5 1
8
279
2
0 2
5 2
6
6
212
2
2 3
3 1
6
213
2
2 3
3 2
7
248
2
1 3
4 1
7
249
2
1 3
4 2
8
284
2
0 3
5 1
8
285
2
0 3
5 2
6
6
218
2
2 4
3 1
6
219
2
2 4
3 2
7
254
2
1 4
4 1
7
255
2
1 4
4 2
8
290
2
0 4
5 1
8
291
2
0 4
5 2
6
6
224
2
2 5
3 1
6
225
2
2 5
3 2
7
260
2
1 5
4 1
7
261
2
1 5
4 2
8
296
2
0 5
5 1
8
297
2
0 5
5 2
12
0
86
2
2 0
3 0
0
87
2
2 0
3 1
1
92
2
2 1
3 0
1
93
2
2 1
3 1
2
98
2
2 2
3 0
2
99
2
2 2
3 1
3
104
2
2 3
3 0
3
105
2
2 3
3 1
4
110
2
2 4
3 0
4
111
2
2 4
3 1
5
116
2
2 5
3 0
5
117
2
2 5
3 1
12
0
122
2
1 0
4 0
0
123
2
1 0
4 1
1
128
2
1 1
4 0
1
129
2
1 1
4 1
2
134
2
1 2
4 0
2
135
2
1 2
4 1
3
140
2
1 3
4 0
3
141
2
1 3
4 1
4
146
2
1 4
4 0
4
147
2
1 4
4 1
5
152
2
1 5
4 0
5
153
2
1 5
4 1
12
0
158
2
0 0
5 0
0
159
2
0 0
5 1
1
164
2
0 1
5 0
1
165
2
0 1
5 1
2
170
2
0 2
5 0
2
171
2
0 2
5 1
3
176
2
0 3
5 0
3
177
2
0 3
5 1
4
182
2
0 4
5 0
4
183
2
0 4
5 1
5
188
2
0 5
5 0
5
189
2
0 5
5 1
end_DTG
begin_DTG
6
6
196
2
2 0
3 1
6
197
2
2 0
3 2
7
232
2
1 0
4 1
7
233
2
1 0
4 2
8
268
2
0 0
5 1
8
269
2
0 0
5 2
6
6
202
2
2 1
3 1
6
203
2
2 1
3 2
7
238
2
1 1
4 1
7
239
2
1 1
4 2
8
274
2
0 1
5 1
8
275
2
0 1
5 2
6
6
208
2
2 2
3 1
6
209
2
2 2
3 2
7
244
2
1 2
4 1
7
245
2
1 2
4 2
8
280
2
0 2
5 1
8
281
2
0 2
5 2
6
6
214
2
2 3
3 1
6
215
2
2 3
3 2
7
250
2
1 3
4 1
7
251
2
1 3
4 2
8
286
2
0 3
5 1
8
287
2
0 3
5 2
6
6
220
2
2 4
3 1
6
221
2
2 4
3 2
7
256
2
1 4
4 1
7
257
2
1 4
4 2
8
292
2
0 4
5 1
8
293
2
0 4
5 2
6
6
226
2
2 5
3 1
6
227
2
2 5
3 2
7
262
2
1 5
4 1
7
263
2
1 5
4 2
8
298
2
0 5
5 1
8
299
2
0 5
5 2
12
0
88
2
2 0
3 0
0
89
2
2 0
3 1
1
94
2
2 1
3 0
1
95
2
2 1
3 1
2
100
2
2 2
3 0
2
101
2
2 2
3 1
3
106
2
2 3
3 0
3
107
2
2 3
3 1
4
112
2
2 4
3 0
4
113
2
2 4
3 1
5
118
2
2 5
3 0
5
119
2
2 5
3 1
12
0
124
2
1 0
4 0
0
125
2
1 0
4 1
1
130
2
1 1
4 0
1
131
2
1 1
4 1
2
136
2
1 2
4 0
2
137
2
1 2
4 1
3
142
2
1 3
4 0
3
143
2
1 3
4 1
4
148
2
1 4
4 0
4
149
2
1 4
4 1
5
154
2
1 5
4 0
5
155
2
1 5
4 1
12
0
160
2
0 0
5 0
0
161
2
0 0
5 1
1
166
2
0 1
5 0
1
167
2
0 1
5 1
2
172
2
0 2
5 0
2
173
2
0 2
5 1
3
178
2
0 3
5 0
3
179
2
0 3
5 1
4
184
2
0 4
5 0
4
185
2
0 4
5 1
5
190
2
0 5
5 0
5
191
2
0 5
5 1
end_DTG
begin_CG
4
6 24
7 24
8 24
5 72
4
6 24
7 24
8 24
4 72
4
6 24
7 24
8 24
3 72
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
end_CG
