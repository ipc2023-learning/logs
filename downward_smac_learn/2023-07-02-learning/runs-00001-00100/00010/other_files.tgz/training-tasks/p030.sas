begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var8
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var5
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var9
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var10
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
0
begin_state
7
5
0
3
2
1
2
1
3
4
1
3
0
end_state
begin_goal
5
8 6
9 7
10 7
11 5
12 4
end_goal
864
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 3 6 5
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
1
399
2
1 1
6 1
2
408
2
1 2
6 0
2
409
2
1 2
6 1
3
418
2
1 3
6 0
3
419
2
1 3
6 1
4
428
2
1 4
6 0
4
429
2
1 4
6 1
5
438
2
1 5
6 0
5
439
2
1 5
6 1
6
448
2
1 6
6 0
6
449
2
1 6
6 1
7
458
2
1 7
6 0
7
459
2
1 7
6 1
16
0
468
2
0 0
7 0
0
469
2
0 0
7 1
1
478
2
0 1
7 0
1
479
2
0 1
7 1
2
488
2
0 2
7 0
2
489
2
0 2
7 1
3
498
2
0 3
7 0
3
499
2
0 3
7 1
4
508
2
0 4
7 0
4
509
2
0 4
7 1
5
518
2
0 5
7 0
5
519
2
0 5
7 1
6
528
2
0 6
7 0
6
529
2
0 6
7 1
7
538
2
0 7
7 0
7
539
2
0 7
7 1
end_DTG
begin_DTG
8
8
550
2
3 0
4 1
8
551
2
3 0
4 2
9
630
2
2 0
5 1
9
631
2
2 0
5 2
10
710
2
1 0
6 1
10
711
2
1 0
6 2
11
790
2
0 0
7 1
11
791
2
0 0
7 2
8
8
560
2
3 1
4 1
8
561
2
3 1
4 2
9
640
2
2 1
5 1
9
641
2
2 1
5 2
10
720
2
1 1
6 1
10
721
2
1 1
6 2
11
800
2
0 1
7 1
11
801
2
0 1
7 2
8
8
570
2
3 2
4 1
8
571
2
3 2
4 2
9
650
2
2 2
5 1
9
651
2
2 2
5 2
10
730
2
1 2
6 1
10
731
2
1 2
6 2
11
810
2
0 2
7 1
11
811
2
0 2
7 2
8
8
580
2
3 3
4 1
8
581
2
3 3
4 2
9
660
2
2 3
5 1
9
661
2
2 3
5 2
10
740
2
1 3
6 1
10
741
2
1 3
6 2
11
820
2
0 3
7 1
11
821
2
0 3
7 2
8
8
590
2
3 4
4 1
8
591
2
3 4
4 2
9
670
2
2 4
5 1
9
671
2
2 4
5 2
10
750
2
1 4
6 1
10
751
2
1 4
6 2
11
830
2
0 4
7 1
11
831
2
0 4
7 2
8
8
600
2
3 5
4 1
8
601
2
3 5
4 2
9
680
2
2 5
5 1
9
681
2
2 5
5 2
10
760
2
1 5
6 1
10
761
2
1 5
6 2
11
840
2
0 5
7 1
11
841
2
0 5
7 2
8
8
610
2
3 6
4 1
8
611
2
3 6
4 2
9
690
2
2 6
5 1
9
691
2
2 6
5 2
10
770
2
1 6
6 1
10
771
2
1 6
6 2
11
850
2
0 6
7 1
11
851
2
0 6
7 2
8
8
620
2
3 7
4 1
8
621
2
3 7
4 2
9
700
2
2 7
5 1
9
701
2
2 7
5 2
10
780
2
1 7
6 1
10
781
2
1 7
6 2
11
860
2
0 7
7 1
11
861
2
0 7
7 2
16
0
230
2
3 0
4 0
0
231
2
3 0
4 1
1
240
2
3 1
4 0
1
241
2
3 1
4 1
2
250
2
3 2
4 0
2
251
2
3 2
4 1
3
260
2
3 3
4 0
3
261
2
3 3
4 1
4
270
2
3 4
4 0
4
271
2
3 4
4 1
5
280
2
3 5
4 0
5
281
2
3 5
4 1
6
290
2
3 6
4 0
6
291
2
3 6
4 1
7
300
2
3 7
4 0
7
301
2
3 7
4 1
16
0
310
2
2 0
5 0
0
311
2
2 0
5 1
1
320
2
2 1
5 0
1
321
2
2 1
5 1
2
330
2
2 2
5 0
2
331
2
2 2
5 1
3
340
2
2 3
5 0
3
341
2
2 3
5 1
4
350
2
2 4
5 0
4
351
2
2 4
5 1
5
360
2
2 5
5 0
5
361
2
2 5
5 1
6
370
2
2 6
5 0
6
371
2
2 6
5 1
7
380
2
2 7
5 0
7
381
2
2 7
5 1
16
0
390
2
1 0
6 0
0
391
2
1 0
6 1
1
400
2
1 1
6 0
1
401
2
1 1
6 1
2
410
2
1 2
6 0
2
411
2
1 2
6 1
3
420
2
1 3
6 0
3
421
2
1 3
6 1
4
430
2
1 4
6 0
4
431
2
1 4
6 1
5
440
2
1 5
6 0
5
441
2
1 5
6 1
6
450
2
1 6
6 0
6
451
2
1 6
6 1
7
460
2
1 7
6 0
7
461
2
1 7
6 1
16
0
470
2
0 0
7 0
0
471
2
0 0
7 1
1
480
2
0 1
7 0
1
481
2
0 1
7 1
2
490
2
0 2
7 0
2
491
2
0 2
7 1
3
500
2
0 3
7 0
3
501
2
0 3
7 1
4
510
2
0 4
7 0
4
511
2
0 4
7 1
5
520
2
0 5
7 0
5
521
2
0 5
7 1
6
530
2
0 6
7 0
6
531
2
0 6
7 1
7
540
2
0 7
7 0
7
541
2
0 7
7 1
end_DTG
begin_DTG
8
8
552
2
3 0
4 1
8
553
2
3 0
4 2
9
632
2
2 0
5 1
9
633
2
2 0
5 2
10
712
2
1 0
6 1
10
713
2
1 0
6 2
11
792
2
0 0
7 1
11
793
2
0 0
7 2
8
8
562
2
3 1
4 1
8
563
2
3 1
4 2
9
642
2
2 1
5 1
9
643
2
2 1
5 2
10
722
2
1 1
6 1
10
723
2
1 1
6 2
11
802
2
0 1
7 1
11
803
2
0 1
7 2
8
8
572
2
3 2
4 1
8
573
2
3 2
4 2
9
652
2
2 2
5 1
9
653
2
2 2
5 2
10
732
2
1 2
6 1
10
733
2
1 2
6 2
11
812
2
0 2
7 1
11
813
2
0 2
7 2
8
8
582
2
3 3
4 1
8
583
2
3 3
4 2
9
662
2
2 3
5 1
9
663
2
2 3
5 2
10
742
2
1 3
6 1
10
743
2
1 3
6 2
11
822
2
0 3
7 1
11
823
2
0 3
7 2
8
8
592
2
3 4
4 1
8
593
2
3 4
4 2
9
672
2
2 4
5 1
9
673
2
2 4
5 2
10
752
2
1 4
6 1
10
753
2
1 4
6 2
11
832
2
0 4
7 1
11
833
2
0 4
7 2
8
8
602
2
3 5
4 1
8
603
2
3 5
4 2
9
682
2
2 5
5 1
9
683
2
2 5
5 2
10
762
2
1 5
6 1
10
763
2
1 5
6 2
11
842
2
0 5
7 1
11
843
2
0 5
7 2
8
8
612
2
3 6
4 1
8
613
2
3 6
4 2
9
692
2
2 6
5 1
9
693
2
2 6
5 2
10
772
2
1 6
6 1
10
773
2
1 6
6 2
11
852
2
0 6
7 1
11
853
2
0 6
7 2
8
8
622
2
3 7
4 1
8
623
2
3 7
4 2
9
702
2
2 7
5 1
9
703
2
2 7
5 2
10
782
2
1 7
6 1
10
783
2
1 7
6 2
11
862
2
0 7
7 1
11
863
2
0 7
7 2
16
0
232
2
3 0
4 0
0
233
2
3 0
4 1
1
242
2
3 1
4 0
1
243
2
3 1
4 1
2
252
2
3 2
4 0
2
253
2
3 2
4 1
3
262
2
3 3
4 0
3
263
2
3 3
4 1
4
272
2
3 4
4 0
4
273
2
3 4
4 1
5
282
2
3 5
4 0
5
283
2
3 5
4 1
6
292
2
3 6
4 0
6
293
2
3 6
4 1
7
302
2
3 7
4 0
7
303
2
3 7
4 1
16
0
312
2
2 0
5 0
0
313
2
2 0
5 1
1
322
2
2 1
5 0
1
323
2
2 1
5 1
2
332
2
2 2
5 0
2
333
2
2 2
5 1
3
342
2
2 3
5 0
3
343
2
2 3
5 1
4
352
2
2 4
5 0
4
353
2
2 4
5 1
5
362
2
2 5
5 0
5
363
2
2 5
5 1
6
372
2
2 6
5 0
6
373
2
2 6
5 1
7
382
2
2 7
5 0
7
383
2
2 7
5 1
16
0
392
2
1 0
6 0
0
393
2
1 0
6 1
1
402
2
1 1
6 0
1
403
2
1 1
6 1
2
412
2
1 2
6 0
2
413
2
1 2
6 1
3
422
2
1 3
6 0
3
423
2
1 3
6 1
4
432
2
1 4
6 0
4
433
2
1 4
6 1
5
442
2
1 5
6 0
5
443
2
1 5
6 1
6
452
2
1 6
6 0
6
453
2
1 6
6 1
7
462
2
1 7
6 0
7
463
2
1 7
6 1
16
0
472
2
0 0
7 0
0
473
2
0 0
7 1
1
482
2
0 1
7 0
1
483
2
0 1
7 1
2
492
2
0 2
7 0
2
493
2
0 2
7 1
3
502
2
0 3
7 0
3
503
2
0 3
7 1
4
512
2
0 4
7 0
4
513
2
0 4
7 1
5
522
2
0 5
7 0
5
523
2
0 5
7 1
6
532
2
0 6
7 0
6
533
2
0 6
7 1
7
542
2
0 7
7 0
7
543
2
0 7
7 1
end_DTG
begin_CG
6
8 32
9 32
10 32
11 32
12 32
7 160
6
8 32
9 32
10 32
11 32
12 32
6 160
6
8 32
9 32
10 32
11 32
12 32
5 160
6
8 32
9 32
10 32
11 32
12 32
4 160
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
