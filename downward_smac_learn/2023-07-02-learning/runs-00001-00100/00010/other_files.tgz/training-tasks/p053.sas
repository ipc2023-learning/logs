begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var13
-1
11
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var12
-1
11
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var11
-1
11
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var10
-1
11
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var9
-1
11
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var14
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
16
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
16
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
16
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
16
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
16
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
16
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
16
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
16
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var8
-1
16
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
7
8
0
8
0
1
1
2
2
2
0
2
9
7
6
8
1
6
10
end_state
begin_goal
9
10 10
11 8
12 5
13 2
14 8
15 4
16 10
17 2
18 1
end_goal
2090
begin_operator
drive v1 l1 l3
0
1
0 4 0 4
0
end_operator
begin_operator
drive v1 l10 l11
0
1
0 4 1 2
0
end_operator
begin_operator
drive v1 l10 l5
0
1
0 4 1 6
0
end_operator
begin_operator
drive v1 l11 l10
0
1
0 4 2 1
0
end_operator
begin_operator
drive v1 l11 l2
0
1
0 4 2 3
0
end_operator
begin_operator
drive v1 l11 l3
0
1
0 4 2 4
0
end_operator
begin_operator
drive v1 l11 l9
0
1
0 4 2 10
0
end_operator
begin_operator
drive v1 l2 l11
0
1
0 4 3 2
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 4 4 0
0
end_operator
begin_operator
drive v1 l3 l11
0
1
0 4 4 2
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 4 5 7
0
end_operator
b




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 1
10
898
2
1 10
8 0
10
899
2
1 10
8 1
22
0
917
2
0 0
9 1
0
916
2
0 0
9 0
1
934
2
0 1
9 0
1
935
2
0 1
9 1
2
952
2
0 2
9 0
2
953
2
0 2
9 1
3
970
2
0 3
9 0
3
971
2
0 3
9 1
4
988
2
0 4
9 0
4
989
2
0 4
9 1
5
1007
2
0 5
9 1
5
1006
2
0 5
9 0
6
1024
2
0 6
9 0
6
1025
2
0 6
9 1
7
1042
2
0 7
9 0
7
1043
2
0 7
9 1
8
1060
2
0 8
9 0
8
1061
2
0 8
9 1
9
1078
2
0 9
9 0
9
1079
2
0 9
9 1
10
1096
2
0 10
9 0
10
1097
2
0 10
9 1
end_DTG
begin_DTG
10
11
1116
2
4 0
5 1
11
1117
2
4 0
5 2
12
1314
2
3 0
6 1
12
1315
2
3 0
6 2
13
1512
2
2 0
7 1
13
1513
2
2 0
7 2
14
1710
2
1 0
8 1
14
1711
2
1 0
8 2
15
1908
2
0 0
9 1
15
1909
2
0 0
9 2
10
11
1134
2
4 1
5 1
11
1135
2
4 1
5 2
12
1332
2
3 1
6 1
12
1333
2
3 1
6 2
13
1530
2
2 1
7 1
13
1531
2
2 1
7 2
14
1728
2
1 1
8 1
14
1729
2
1 1
8 2
15
1926
2
0 1
9 1
15
1927
2
0 1
9 2
10
11
1152
2
4 2
5 1
11
1153
2
4 2
5 2
12
1350
2
3 2
6 1
12
1351
2
3 2
6 2
13
1548
2
2 2
7 1
13
1549
2
2 2
7 2
14
1746
2
1 2
8 1
14
1747
2
1 2
8 2
15
1944
2
0 2
9 1
15
1945
2
0 2
9 2
10
11
1170
2
4 3
5 1
11
1171
2
4 3
5 2
12
1368
2
3 3
6 1
12
1369
2
3 3
6 2
13
1566
2
2 3
7 1
13
1567
2
2 3
7 2
14
1764
2
1 3
8 1
14
1765
2
1 3
8 2
15
1962
2
0 3
9 1
15
1963
2
0 3
9 2
10
11
1188
2
4 4
5 1
11
1189
2
4 4
5 2
12
1386
2
3 4
6 1
12
1387
2
3 4
6 2
13
1584
2
2 4
7 1
13
1585
2
2 4
7 2
14
1782
2
1 4
8 1
14
1783
2
1 4
8 2
15
1980
2
0 4
9 1
15
1981
2
0 4
9 2
10
11
1206
2
4 5
5 1
11
1207
2
4 5
5 2
12
1404
2
3 5
6 1
12
1405
2
3 5
6 2
13
1602
2
2 5
7 1
13
1603
2
2 5
7 2
14
1800
2
1 5
8 1
14
1801
2
1 5
8 2
15
1998
2
0 5
9 1
15
1999
2
0 5
9 2
10
11
1224
2
4 6
5 1
11
1225
2
4 6
5 2
12
1422
2
3 6
6 1
12
1423
2
3 6
6 2
13
1620
2
2 6
7 1
13
1621
2
2 6
7 2
14
1818
2
1 6
8 1
14
1819
2
1 6
8 2
15
2016
2
0 6
9 1
15
2017
2
0 6
9 2
10
11
1242
2
4 7
5 1
11
1243
2
4 7
5 2
12
1440
2
3 7
6 1
12
1441
2
3 7
6 2
13
1638
2
2 7
7 1
13
1639
2
2 7
7 2
14
1836
2
1 7
8 1
14
1837
2
1 7
8 2
15
2034
2
0 7
9 1
15
2035
2
0 7
9 2
10
11
1260
2
4 8
5 1
11
1261
2
4 8
5 2
12
1458
2
3 8
6 1
12
1459
2
3 8
6 2
13
1656
2
2 8
7 1
13
1657
2
2 8
7 2
14
1854
2
1 8
8 1
14
1855
2
1 8
8 2
15
2052
2
0 8
9 1
15
2053
2
0 8
9 2
10
11
1278
2
4 9
5 1
11
1279
2
4 9
5 2
12
1476
2
3 9
6 1
12
1477
2
3 9
6 2
13
1674
2
2 9
7 1
13
1675
2
2 9
7 2
14
1872
2
1 9
8 1
14
1873
2
1 9
8 2
15
2070
2
0 9
9 1
15
2071
2
0 9
9 2
10
11
1296
2
4 10
5 1
11
1297
2
4 10
5 2
12
1494
2
3 10
6 1
12
1495
2
3 10
6 2
13
1692
2
2 10
7 1
13
1693
2
2 10
7 2
14
1890
2
1 10
8 1
14
1891
2
1 10
8 2
15
2088
2
0 10
9 1
15
2089
2
0 10
9 2
22
0
127
2
4 0
5 1
0
126
2
4 0
5 0
1
144
2
4 1
5 0
1
145
2
4 1
5 1
2
162
2
4 2
5 0
2
163
2
4 2
5 1
3
180
2
4 3
5 0
3
181
2
4 3
5 1
4
198
2
4 4
5 0
4
199
2
4 4
5 1
5
217
2
4 5
5 1
5
216
2
4 5
5 0
6
234
2
4 6
5 0
6
235
2
4 6
5 1
7
252
2
4 7
5 0
7
253
2
4 7
5 1
8
270
2
4 8
5 0
8
271
2
4 8
5 1
9
288
2
4 9
5 0
9
289
2
4 9
5 1
10
306
2
4 10
5 0
10
307
2
4 10
5 1
22
0
325
2
3 0
6 1
0
324
2
3 0
6 0
1
342
2
3 1
6 0
1
343
2
3 1
6 1
2
360
2
3 2
6 0
2
361
2
3 2
6 1
3
378
2
3 3
6 0
3
379
2
3 3
6 1
4
396
2
3 4
6 0
4
397
2
3 4
6 1
5
415
2
3 5
6 1
5
414
2
3 5
6 0
6
432
2
3 6
6 0
6
433
2
3 6
6 1
7
450
2
3 7
6 0
7
451
2
3 7
6 1
8
468
2
3 8
6 0
8
469
2
3 8
6 1
9
486
2
3 9
6 0
9
487
2
3 9
6 1
10
504
2
3 10
6 0
10
505
2
3 10
6 1
22
0
523
2
2 0
7 1
0
522
2
2 0
7 0
1
540
2
2 1
7 0
1
541
2
2 1
7 1
2
558
2
2 2
7 0
2
559
2
2 2
7 1
3
576
2
2 3
7 0
3
577
2
2 3
7 1
4
594
2
2 4
7 0
4
595
2
2 4
7 1
5
613
2
2 5
7 1
5
612
2
2 5
7 0
6
630
2
2 6
7 0
6
631
2
2 6
7 1
7
648
2
2 7
7 0
7
649
2
2 7
7 1
8
666
2
2 8
7 0
8
667
2
2 8
7 1
9
684
2
2 9
7 0
9
685
2
2 9
7 1
10
702
2
2 10
7 0
10
703
2
2 10
7 1
22
0
721
2
1 0
8 1
0
720
2
1 0
8 0
1
738
2
1 1
8 0
1
739
2
1 1
8 1
2
756
2
1 2
8 0
2
757
2
1 2
8 1
3
774
2
1 3
8 0
3
775
2
1 3
8 1
4
792
2
1 4
8 0
4
793
2
1 4
8 1
5
811
2
1 5
8 1
5
810
2
1 5
8 0
6
828
2
1 6
8 0
6
829
2
1 6
8 1
7
846
2
1 7
8 0
7
847
2
1 7
8 1
8
864
2
1 8
8 0
8
865
2
1 8
8 1
9
882
2
1 9
8 0
9
883
2
1 9
8 1
10
900
2
1 10
8 0
10
901
2
1 10
8 1
22
0
919
2
0 0
9 1
0
918
2
0 0
9 0
1
936
2
0 1
9 0
1
937
2
0 1
9 1
2
954
2
0 2
9 0
2
955
2
0 2
9 1
3
972
2
0 3
9 0
3
973
2
0 3
9 1
4
990
2
0 4
9 0
4
991
2
0 4
9 1
5
1009
2
0 5
9 1
5
1008
2
0 5
9 0
6
1026
2
0 6
9 0
6
1027
2
0 6
9 1
7
1044
2
0 7
9 0
7
1045
2
0 7
9 1
8
1062
2
0 8
9 0
8
1063
2
0 8
9 1
9
1080
2
0 9
9 0
9
1081
2
0 9
9 1
10
1098
2
0 10
9 0
10
1099
2
0 10
9 1
end_DTG
begin_CG
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
8 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
7 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
6 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5 396
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
end_CG
