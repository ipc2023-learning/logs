begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var23
-1
16
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var22
-1
16
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var21
-1
16
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var20
-1
16
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var19
-1
16
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var18
-1
16
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var17
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var24
-1
4
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
Atom capacity(v1, c3)
end_variable
begin_variable
var25
-1
4
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
Atom capacity(v2, c3)
end_variable
begin_variable
var26
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var27
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var28
-1
4
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
Atom capacity(v5, c3)
end_variable
begin_variable
var29
-1
4
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
Atom capacity(v6, c3)
end_variable
begin_variable
var30
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var0
-1
23
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var1
-1
23
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var2
-1
23
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var3
-1
23
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var4
-1
23
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l16)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
10 0
13
3734
2
3 13
10 1
13
3735
2
3 13
10 2
14
3784
2
3 14
10 0
14
3785
2
3 14
10 1
14
3786
2
3 14
10 2
15
3835
2
3 15
10 0
15
3836
2
3 15
10 1
15
3837
2
3 15
10 2
48
0
3887
2
2 0
11 1
0
3888
2
2 0
11 2
0
3886
2
2 0
11 0
1
3937
2
2 1
11 0
1
3938
2
2 1
11 1
1
3939
2
2 1
11 2
2
3988
2
2 2
11 0
2
3989
2
2 2
11 1
2
3990
2
2 2
11 2
3
4039
2
2 3
11 0
3
4040
2
2 3
11 1
3
4041
2
2 3
11 2
4
4091
2
2 4
11 1
4
4092
2
2 4
11 2
4
4090
2
2 4
11 0
5
4141
2
2 5
11 0
5
4142
2
2 5
11 1
5
4143
2
2 5
11 2
6
4192
2
2 6
11 0
6
4193
2
2 6
11 1
6
4194
2
2 6
11 2
7
4243
2
2 7
11 0
7
4244
2
2 7
11 1
7
4245
2
2 7
11 2
8
4294
2
2 8
11 0
8
4296
2
2 8
11 2
8
4295
2
2 8
11 1
9
4345
2
2 9
11 0
9
4346
2
2 9
11 1
9
4347
2
2 9
11 2
10
4396
2
2 10
11 0
10
4397
2
2 10
11 1
10
4398
2
2 10
11 2
11
4447
2
2 11
11 0
11
4448
2
2 11
11 1
11
4449
2
2 11
11 2
12
4499
2
2 12
11 1
12
4500
2
2 12
11 2
12
4498
2
2 12
11 0
13
4549
2
2 13
11 0
13
4550
2
2 13
11 1
13
4551
2
2 13
11 2
14
4600
2
2 14
11 0
14
4601
2
2 14
11 1
14
4602
2
2 14
11 2
15
4651
2
2 15
11 0
15
4652
2
2 15
11 1
15
4653
2
2 15
11 2
48
0
4703
2
1 0
12 1
0
4704
2
1 0
12 2
0
4702
2
1 0
12 0
1
4753
2
1 1
12 0
1
4754
2
1 1
12 1
1
4755
2
1 1
12 2
2
4804
2
1 2
12 0
2
4805
2
1 2
12 1
2
4806
2
1 2
12 2
3
4855
2
1 3
12 0
3
4856
2
1 3
12 1
3
4857
2
1 3
12 2
4
4907
2
1 4
12 1
4
4908
2
1 4
12 2
4
4906
2
1 4
12 0
5
4957
2
1 5
12 0
5
4958
2
1 5
12 1
5
4959
2
1 5
12 2
6
5008
2
1 6
12 0
6
5009
2
1 6
12 1
6
5010
2
1 6
12 2
7
5059
2
1 7
12 0
7
5060
2
1 7
12 1
7
5061
2
1 7
12 2
8
5110
2
1 8
12 0
8
5112
2
1 8
12 2
8
5111
2
1 8
12 1
9
5161
2
1 9
12 0
9
5162
2
1 9
12 1
9
5163
2
1 9
12 2
10
5212
2
1 10
12 0
10
5213
2
1 10
12 1
10
5214
2
1 10
12 2
11
5263
2
1 11
12 0
11
5264
2
1 11
12 1
11
5265
2
1 11
12 2
12
5315
2
1 12
12 1
12
5316
2
1 12
12 2
12
5314
2
1 12
12 0
13
5365
2
1 13
12 0
13
5366
2
1 13
12 1
13
5367
2
1 13
12 2
14
5416
2
1 14
12 0
14
5417
2
1 14
12 1
14
5418
2
1 14
12 2
15
5467
2
1 15
12 0
15
5468
2
1 15
12 1
15
5469
2
1 15
12 2
48
0
5519
2
0 0
13 1
0
5520
2
0 0
13 2
0
5518
2
0 0
13 0
1
5569
2
0 1
13 0
1
5570
2
0 1
13 1
1
5571
2
0 1
13 2
2
5620
2
0 2
13 0
2
5621
2
0 2
13 1
2
5622
2
0 2
13 2
3
5671
2
0 3
13 0
3
5672
2
0 3
13 1
3
5673
2
0 3
13 2
4
5723
2
0 4
13 1
4
5724
2
0 4
13 2
4
5722
2
0 4
13 0
5
5773
2
0 5
13 0
5
5774
2
0 5
13 1
5
5775
2
0 5
13 2
6
5824
2
0 6
13 0
6
5825
2
0 6
13 1
6
5826
2
0 6
13 2
7
5875
2
0 7
13 0
7
5876
2
0 7
13 1
7
5877
2
0 7
13 2
8
5926
2
0 8
13 0
8
5928
2
0 8
13 2
8
5927
2
0 8
13 1
9
5977
2
0 9
13 0
9
5978
2
0 9
13 1
9
5979
2
0 9
13 2
10
6028
2
0 10
13 0
10
6029
2
0 10
13 1
10
6030
2
0 10
13 2
11
6079
2
0 11
13 0
11
6080
2
0 11
13 1
11
6081
2
0 11
13 2
12
6131
2
0 12
13 1
12
6132
2
0 12
13 2
12
6130
2
0 12
13 0
13
6181
2
0 13
13 0
13
6182
2
0 13
13 1
13
6183
2
0 13
13 2
14
6232
2
0 14
13 0
14
6233
2
0 14
13 1
14
6234
2
0 14
13 2
15
6283
2
0 15
13 0
15
6284
2
0 15
13 1
15
6285
2
0 15
13 2
end_DTG
begin_CG
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
13 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
12 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
11 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
10 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
9 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
8 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
7 1632
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
end_CG
