begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var4
-1
6
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
end_variable
begin_variable
var3
-1
6
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
end_variable
begin_variable
var2
-1
6
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
end_variable
begin_variable
var5
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var6
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
9
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
9
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
0
begin_state
3
5
2
1
2
2
5
4
end_state
begin_goal
2
6 4
7 5
end_goal
174
begin_operator
drive v1 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 1 5 1
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v3 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v3 l2 l6
0
1
0 0 1 5
0
end_operator
begin_operator
drive v3 l3 l1
0
1
0 0 2 0
0
end_operator
begin_operator
drive v3 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drive v3 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drive v3 l4 l5
0
1
0 0 3 4
0
end_operator
begin_operator
drive v3 l5 l4
0
1
0 0 4 3
0
end_operator
begin_operator
drive v3 l6 l2
0
1
0 0 5 1
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
2 0
2
0 6 6 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
2 0
2
0 6 6 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
2 0
2
0 7 6 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
2 0
2
0 7 6 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
2 1
2
0 6 6 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c1 c2
1
2 1
2
0 6 6 1
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p2 c0 c1
1
2 1
2
0 7 6 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p2 c1 c2
1
2 1
2
0 7 6 1
0 3 1 2
0
end_operator
begin_operator
drop v1 l3 p1 c0 c1
1
2 2
2
0 6 6 2
0 3 0 1
0
end_operator
begin_operator
drop v1 l3 p1 c1 c2
1
2 2
2
0 6 6 2
0 3 1 2
0
end_operator
begin_operator
drop v1 l3 p2 c0 c1
1
2 2
2
0 7 6 2
0 3 0 1
0
end_operator
begin_operator
drop v1 l3 p2 c1 c2
1
2 2
2
0 7 6 2
0 3 1 2
0
end_operator
begin_operator
drop v1 l4 p1 c0 c1
1
2 3
2
0 6 6 3
0 3 0 1
0
end_operator
begin_operator
drop v1 l4 p1 c1 c2
1
2 3
2
0 6 6 3
0 3 1 2
0
end_operator
begin_operator
drop v1 l4 p2 c0 c1
1
2 3
2
0 7 6 3
0 3 0 1
0
end_operator
begin_operator
drop v1 l4 p2 c1 c2
1
2 3
2
0 7 6 3
0 3 1 2
0
end_operator
begin_operator
drop v1 l5 p1 c0 c1
1
2 4
2
0 6 6 4
0 3 0 1
0
end_operator
begin_operator
drop v1 l5 p1 c1 c2
1
2 4
2
0 6 6 4
0 3 1 2
0
end_operator
begin_operator
drop v1 l5 p2 c0 c1
1
2 4
2
0 7 6 4
0 3 0 1
0
end_operator
begin_operator
drop v1 l5 p2 c1 c2
1
2 4
2
0 7 6 4
0 3 1 2
0
end_operator
begin_operator
drop v1 l6 p1 c0 c1
1
2 5
2
0 6 6 5
0 3 0 1
0
end_operator
begin_operator
drop v1 l6 p1 c1 c2
1
2 5
2
0 6 6 5
0 3 1 2
0
end_operator
begin_operator
drop v1 l6 p2 c0 c1
1
2 5
2
0 7 6 5
0 3 0 1
0
end_operator
begin_operator
drop v1 l6 p2 c1 c2
1
2 5
2
0 7 6 5
0 3 1 2
0
end_operator
begin_operator
drop v2 l1 p1 c0 c1
1
1 0
2
0 6 7 0
0 4 0 1
0
end_operator
begin_operator
drop v2 l1 p1 c1 c2
1
1 0
2
0 6 7 0
0 4 1 2
0
end_operator
begin_operator
drop v2 l1 p2 c0 c1
1
1 0
2
0 7 7 0
0 4 0 1
0
end_operator
begin_operator
drop v2 l1 p2 c1 c2
1
1 0
2
0 7 7 0
0 4 1 2
0
end_operator
begin_operator
drop v2 l2 p1 c0 c1
1
1 1
2
0 6 7 1
0 4 0 1
0
end_operator
begin_operator
drop v2 l2 p1 c1 c2
1
1 1
2
0 6 7 1
0 4 1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 2
24
25
check 2
26
27
check 1
28
check 1
29
check 0
end_SG
begin_DTG
1
2
20
0
3
2
21
0
3
22
0
5
23
0
2
0
24
0
1
25
0
2
1
26
0
4
27
0
1
3
28
0
1
1
29
0
end_DTG
begin_DTG
1
2
10
0
3
2
11
0
3
12
0
5
13
0
2
0
14
0
1
15
0
2
1
16
0
4
17
0
1
3
18
0
1
1
19
0
end_DTG
begin_DTG
1
2
0
0
3
2
1
0
3
2
0
5
3
0
2
0
4
0
1
5
0
2
1
6
0
4
7
0
1
3
8
0
1
1
9
0
end_DTG
begin_DTG
12
1
30
2
6 6
2 0
1
32
2
7 6
2 0
1
34
2
6 6
2 1
1
36
2
7 6
2 1
1
38
2
6 6
2 2
1
40
2
7 6
2 2
1
42
2
6 6
2 3
1
44
2
7 6
2 3
1
46
2
6 6
2 4
1
48
2
7 6
2 4
1
50
2
6 6
2 5
1
52
2
7 6
2 5
24
0
102
2
6 0
2 0
0
124
2
7 5
2 5
0
122
2
6 5
2 5
0
120
2
7 4
2 4
0
118
2
6 4
2 4
0
116
2
7 3
2 3
0
114
2
6 3
2 3
0
112
2
7 2
2 2
0
110
2
6 2
2 2
0
108
2
7 1
2 1
0
106
2
6 1
2 1
0
104
2
7 0
2 0
2
31
2
6 6
2 0
2
53
2
7 6
2 5
2
51
2
6 6
2 5
2
49
2
7 6
2 4
2
47
2
6 6
2 4
2
45
2
7 6
2 3
2
43
2
6 6
2 3
2
41
2
7 6
2 2
2
39
2
6 6
2 2
2
37
2
7 6
2 1
2
35
2
6 6
2 1
2
33
2
7 6
2 0
12
1
103
2
6 0
2 0
1
105
2
7 0
2 0
1
107
2
6 1
2 1
1
109
2
7 1
2 1
1
111
2
6 2
2 2
1
113
2
7 2
2 2
1
115
2
6 3
2 3
1
117
2
7 3
2 3
1
119
2
6 4
2 4
1
121
2
7 4
2 4
1
123
2
6 5
2 5
1
125
2
7 5
2 5
end_DTG
begin_DTG
12
1
54
2
6 7
1 0
1
56
2
7 7
1 0
1
58
2
6 7
1 1
1
60
2
7 7
1 1
1
62
2
6 7
1 2
1
64
2
7 7
1 2
1
66
2
6 7
1 3
1
68
2
7 7
1 3
1
70
2
6 7
1 4
1
72
2
7 7
1 4
1
74
2
6 7
1 5
1
76
2
7 7
1 5
24
0
126
2
6 0
1 0
0
148
2
7 5
1 5
0
146
2
6 5
1 5
0
144
2
7 4
1 4
0
142
2
6 4
1 4
0
140
2
7 3
1 3
0
138
2
6 3
1 3
0
136
2
7 2
1 2
0
134
2
6 2
1 2
0
132
2
7 1
1 1
0
130
2
6 1
1 1
0
128
2
7 0
1 0
2
55
2
6 7
1 0
2
77
2
7 7
1 5
2
75
2
6 7
1 5
2
73
2
7 7
1 4
2
71
2
6 7
1 4
2
69
2
7 7
1 3
2
67
2
6 7
1 3
2
65
2
7 7
1 2
2
63
2
6 7
1 2
2
61
2
7 7
1 1
2
59
2
6 7
1 1
2
57
2
7 7
1 0
12
1
127
2
6 0
1 0
1
129
2
7 0
1 0
1
131
2
6 1
1 1
1
133
2
7 1
1 1
1
135
2
6 2
1 2
1
137
2
7 2
1 2
1
139
2
6 3
1 3
1
141
2
7 3
1 3
1
143
2
6 4
1 4
1
145
2
7 4
1 4
1
147
2
6 5
1 5
1
149
2
7 5
1 5
end_DTG
begin_DTG
12
1
78
2
6 8
0 0
1
80
2
7 8
0 0
1
82
2
6 8
0 1
1
84
2
7 8
0 1
1
86
2
6 8
0 2
1
88
2
7 8
0 2
1
90
2
6 8
0 3
1
92
2
7 8
0 3
1
94
2
6 8
0 4
1
96
2
7 8
0 4
1
98
2
6 8
0 5
1
100
2
7 8
0 5
24
0
150
2
6 0
0 0
0
172
2
7 5
0 5
0
170
2
6 5
0 5
0
168
2
7 4
0 4
0
166
2
6 4
0 4
0
164
2
7 3
0 3
0
162
2
6 3
0 3
0
160
2
7 2
0 2
0
158
2
6 2
0 2
0
156
2
7 1
0 1
0
154
2
6 1
0 1
0
152
2
7 0
0 0
2
79
2
6 8
0 0
2
101
2
7 8
0 5
2
99
2
6 8
0 5
2
97
2
7 8
0 4
2
95
2
6 8
0 4
2
93
2
7 8
0 3
2
91
2
6 8
0 3
2
89
2
7 8
0 2
2
87
2
6 8
0 2
2
85
2
7 8
0 1
2
83
2
6 8
0 1
2
81
2
7 8
0 0
12
1
151
2
6 0
0 0
1
153
2
7 0
0 0
1
155
2
6 1
0 1
1
157
2
7 1
0 1
1
159
2
6 2
0 2
1
161
2
7 2
0 2
1
163
2
6 3
0 3
1
165
2
7 3
0 3
1
167
2
6 4
0 4
1
169
2
7 4
0 4
1
171
2
6 5
0 5
1
173
2
7 5
0 5
end_DTG
begin_DTG
6
6
102
2
2 0
3 1
6
103
2
2 0
3 2
7
126
2
1 0
4 1
7
127
2
1 0
4 2
8
150
2
0 0
5 1
8
151
2
0 0
5 2
6
6
106
2
2 1
3 1
6
107
2
2 1
3 2
7
130
2
1 1
4 1
7
131
2
1 1
4 2
8
154
2
0 1
5 1
8
155
2
0 1
5 2
6
6
110
2
2 2
3 1
6
111
2
2 2
3 2
7
134
2
1 2
4 1
7
135
2
1 2
4 2
8
158
2
0 2
5 1
8
159
2
0 2
5 2
6
6
114
2
2 3
3 1
6
115
2
2 3
3 2
7
138
2
1 3
4 1
7
139
2
1 3
4 2
8
162
2
0 3
5 1
8
163
2
0 3
5 2
6
6
118
2
2 4
3 1
6
119
2
2 4
3 2
7
142
2
1 4
4 1
7
143
2
1 4
4 2
8
166
2
0 4
5 1
8
167
2
0 4
5 2
6
6
122
2
2 5
3 1
6
123
2
2 5
3 2
7
146
2
1 5
4 1
7
147
2
1 5
4 2
8
170
2
0 5
5 1
8
171
2
0 5
5 2
12
0
30
2
2 0
3 0
0
31
2
2 0
3 1
1
34
2
2 1
3 0
1
35
2
2 1
3 1
2
38
2
2 2
3 0
2
39
2
2 2
3 1
3
42
2
2 3
3 0
3
43
2
2 3
3 1
4
46
2
2 4
3 0
4
47
2
2 4
3 1
5
50
2
2 5
3 0
5
51
2
2 5
3 1
12
0
54
2
1 0
4 0
0
55
2
1 0
4 1
1
58
2
1 1
4 0
1
59
2
1 1
4 1
2
62
2
1 2
4 0
2
63
2
1 2
4 1
3
66
2
1 3
4 0
3
67
2
1 3
4 1
4
70
2
1 4
4 0
4
71
2
1 4
4 1
5
74
2
1 5
4 0
5
75
2
1 5
4 1
12
0
78
2
0 0
5 0
0
79
2
0 0
5 1
1
82
2
0 1
5 0
1
83
2
0 1
5 1
2
86
2
0 2
5 0
2
87
2
0 2
5 1
3
90
2
0 3
5 0
3
91
2
0 3
5 1
4
94
2
0 4
5 0
4
95
2
0 4
5 1
5
98
2
0 5
5 0
5
99
2
0 5
5 1
end_DTG
begin_DTG
6
6
104
2
2 0
3 1
6
105
2
2 0
3 2
7
128
2
1 0
4 1
7
129
2
1 0
4 2
8
152
2
0 0
5 1
8
153
2
0 0
5 2
6
6
108
2
2 1
3 1
6
109
2
2 1
3 2
7
132
2
1 1
4 1
7
133
2
1 1
4 2
8
156
2
0 1
5 1
8
157
2
0 1
5 2
6
6
112
2
2 2
3 1
6
113
2
2 2
3 2
7
136
2
1 2
4 1
7
137
2
1 2
4 2
8
160
2
0 2
5 1
8
161
2
0 2
5 2
6
6
116
2
2 3
3 1
6
117
2
2 3
3 2
7
140
2
1 3
4 1
7
141
2
1 3
4 2
8
164
2
0 3
5 1
8
165
2
0 3
5 2
6
6
120
2
2 4
3 1
6
121
2
2 4
3 2
7
144
2
1 4
4 1
7
145
2
1 4
4 2
8
168
2
0 4
5 1
8
169
2
0 4
5 2
6
6
124
2
2 5
3 1
6
125
2
2 5
3 2
7
148
2
1 5
4 1
7
149
2
1 5
4 2
8
172
2
0 5
5 1
8
173
2
0 5
5 2
12
0
32
2
2 0
3 0
0
33
2
2 0
3 1
1
36
2
2 1
3 0
1
37
2
2 1
3 1
2
40
2
2 2
3 0
2
41
2
2 2
3 1
3
44
2
2 3
3 0
3
45
2
2 3
3 1
4
48
2
2 4
3 0
4
49
2
2 4
3 1
5
52
2
2 5
3 0
5
53
2
2 5
3 1
12
0
56
2
1 0
4 0
0
57
2
1 0
4 1
1
60
2
1 1
4 0
1
61
2
1 1
4 1
2
64
2
1 2
4 0
2
65
2
1 2
4 1
3
68
2
1 3
4 0
3
69
2
1 3
4 1
4
72
2
1 4
4 0
4
73
2
1 4
4 1
5
76
2
1 5
4 0
5
77
2
1 5
4 1
12
0
80
2
0 0
5 0
0
81
2
0 0
5 1
1
84
2
0 1
5 0
1
85
2
0 1
5 1
2
88
2
0 2
5 0
2
89
2
0 2
5 1
3
92
2
0 3
5 0
3
93
2
0 3
5 1
4
96
2
0 4
5 0
4
97
2
0 4
5 1
5
100
2
0 5
5 0
5
101
2
0 5
5 1
end_DTG
begin_CG
3
6 24
7 24
5 48
3
6 24
7 24
4 48
3
6 24
7 24
3 48
2
6 24
7 24
2
6 24
7 24
2
6 24
7 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
end_CG
