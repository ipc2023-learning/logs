begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var18
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var13
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var19
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l14)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
6 2
15
3170
2
4 11
7 1
15
3171
2
4 11
7 2
16
3534
2
3 11
8 1
16
3535
2
3 11
8 2
17
3898
2
2 11
9 1
17
3899
2
2 11
9 2
18
4262
2
1 11
10 1
18
4263
2
1 11
10 2
19
4626
2
0 11
11 1
19
4627
2
0 11
11 2
12
14
2832
2
5 12
6 1
14
2833
2
5 12
6 2
15
3196
2
4 12
7 1
15
3197
2
4 12
7 2
16
3560
2
3 12
8 1
16
3561
2
3 12
8 2
17
3924
2
2 12
9 1
17
3925
2
2 12
9 2
18
4288
2
1 12
10 1
18
4289
2
1 12
10 2
19
4652
2
0 12
11 1
19
4653
2
0 12
11 2
12
14
2858
2
5 13
6 1
14
2859
2
5 13
6 2
15
3222
2
4 13
7 1
15
3223
2
4 13
7 2
16
3586
2
3 13
8 1
16
3587
2
3 13
8 2
17
3950
2
2 13
9 1
17
3951
2
2 13
9 2
18
4314
2
1 13
10 1
18
4315
2
1 13
10 2
19
4678
2
0 13
11 1
19
4679
2
0 13
11 2
28
0
337
2
5 0
6 1
0
336
2
5 0
6 0
1
362
2
5 1
6 0
1
363
2
5 1
6 1
2
388
2
5 2
6 0
2
389
2
5 2
6 1
3
414
2
5 3
6 0
3
415
2
5 3
6 1
4
440
2
5 4
6 0
4
441
2
5 4
6 1
5
466
2
5 5
6 0
5
467
2
5 5
6 1
6
492
2
5 6
6 0
6
493
2
5 6
6 1
7
518
2
5 7
6 0
7
519
2
5 7
6 1
8
544
2
5 8
6 0
8
545
2
5 8
6 1
9
570
2
5 9
6 0
9
571
2
5 9
6 1
10
596
2
5 10
6 0
10
597
2
5 10
6 1
11
622
2
5 11
6 0
11
623
2
5 11
6 1
12
648
2
5 12
6 0
12
649
2
5 12
6 1
13
674
2
5 13
6 0
13
675
2
5 13
6 1
28
0
701
2
4 0
7 1
0
700
2
4 0
7 0
1
726
2
4 1
7 0
1
727
2
4 1
7 1
2
752
2
4 2
7 0
2
753
2
4 2
7 1
3
778
2
4 3
7 0
3
779
2
4 3
7 1
4
804
2
4 4
7 0
4
805
2
4 4
7 1
5
830
2
4 5
7 0
5
831
2
4 5
7 1
6
856
2
4 6
7 0
6
857
2
4 6
7 1
7
882
2
4 7
7 0
7
883
2
4 7
7 1
8
908
2
4 8
7 0
8
909
2
4 8
7 1
9
934
2
4 9
7 0
9
935
2
4 9
7 1
10
960
2
4 10
7 0
10
961
2
4 10
7 1
11
986
2
4 11
7 0
11
987
2
4 11
7 1
12
1012
2
4 12
7 0
12
1013
2
4 12
7 1
13
1038
2
4 13
7 0
13
1039
2
4 13
7 1
28
0
1065
2
3 0
8 1
0
1064
2
3 0
8 0
1
1090
2
3 1
8 0
1
1091
2
3 1
8 1
2
1116
2
3 2
8 0
2
1117
2
3 2
8 1
3
1142
2
3 3
8 0
3
1143
2
3 3
8 1
4
1168
2
3 4
8 0
4
1169
2
3 4
8 1
5
1194
2
3 5
8 0
5
1195
2
3 5
8 1
6
1220
2
3 6
8 0
6
1221
2
3 6
8 1
7
1246
2
3 7
8 0
7
1247
2
3 7
8 1
8
1272
2
3 8
8 0
8
1273
2
3 8
8 1
9
1298
2
3 9
8 0
9
1299
2
3 9
8 1
10
1324
2
3 10
8 0
10
1325
2
3 10
8 1
11
1350
2
3 11
8 0
11
1351
2
3 11
8 1
12
1376
2
3 12
8 0
12
1377
2
3 12
8 1
13
1402
2
3 13
8 0
13
1403
2
3 13
8 1
28
0
1429
2
2 0
9 1
0
1428
2
2 0
9 0
1
1454
2
2 1
9 0
1
1455
2
2 1
9 1
2
1480
2
2 2
9 0
2
1481
2
2 2
9 1
3
1506
2
2 3
9 0
3
1507
2
2 3
9 1
4
1532
2
2 4
9 0
4
1533
2
2 4
9 1
5
1558
2
2 5
9 0
5
1559
2
2 5
9 1
6
1584
2
2 6
9 0
6
1585
2
2 6
9 1
7
1610
2
2 7
9 0
7
1611
2
2 7
9 1
8
1636
2
2 8
9 0
8
1637
2
2 8
9 1
9
1662
2
2 9
9 0
9
1663
2
2 9
9 1
10
1688
2
2 10
9 0
10
1689
2
2 10
9 1
11
1714
2
2 11
9 0
11
1715
2
2 11
9 1
12
1740
2
2 12
9 0
12
1741
2
2 12
9 1
13
1766
2
2 13
9 0
13
1767
2
2 13
9 1
28
0
1793
2
1 0
10 1
0
1792
2
1 0
10 0
1
1818
2
1 1
10 0
1
1819
2
1 1
10 1
2
1844
2
1 2
10 0
2
1845
2
1 2
10 1
3
1870
2
1 3
10 0
3
1871
2
1 3
10 1
4
1896
2
1 4
10 0
4
1897
2
1 4
10 1
5
1922
2
1 5
10 0
5
1923
2
1 5
10 1
6
1948
2
1 6
10 0
6
1949
2
1 6
10 1
7
1974
2
1 7
10 0
7
1975
2
1 7
10 1
8
2000
2
1 8
10 0
8
2001
2
1 8
10 1
9
2026
2
1 9
10 0
9
2027
2
1 9
10 1
10
2052
2
1 10
10 0
10
2053
2
1 10
10 1
11
2078
2
1 11
10 0
11
2079
2
1 11
10 1
12
2104
2
1 12
10 0
12
2105
2
1 12
10 1
13
2130
2
1 13
10 0
13
2131
2
1 13
10 1
28
0
2157
2
0 0
11 1
0
2156
2
0 0
11 0
1
2182
2
0 1
11 0
1
2183
2
0 1
11 1
2
2208
2
0 2
11 0
2
2209
2
0 2
11 1
3
2234
2
0 3
11 0
3
2235
2
0 3
11 1
4
2260
2
0 4
11 0
4
2261
2
0 4
11 1
5
2286
2
0 5
11 0
5
2287
2
0 5
11 1
6
2312
2
0 6
11 0
6
2313
2
0 6
11 1
7
2338
2
0 7
11 0
7
2339
2
0 7
11 1
8
2364
2
0 8
11 0
8
2365
2
0 8
11 1
9
2390
2
0 9
11 0
9
2391
2
0 9
11 1
10
2416
2
0 10
11 0
10
2417
2
0 10
11 1
11
2442
2
0 11
11 0
11
2443
2
0 11
11 1
12
2468
2
0 12
11 0
12
2469
2
0 12
11 1
13
2494
2
0 13
11 0
13
2495
2
0 13
11 1
end_DTG
begin_CG
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
11 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
10 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
9 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
8 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
7 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6 728
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
