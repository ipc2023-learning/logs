begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var10
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var8
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var7
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var11
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
14
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
14
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
14
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
14
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
14
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
14
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
14
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
0
begin_state
3
7
0
2
2
2
1
1
7
0
0
4
4
3
5
end_state
begin_goal
7
8 2
9 3
10 2
11 1
12 7
13 1
14 1
end_goal
1352
begin_operator
drive v1 l1 l2
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 3 0 9
0
end_operator
begin_operator
drive v1 l10 l2
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l10 l4
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l10 l5
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l10 l7
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l2 l10
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 2 8
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 2 9
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l3 l9
0
1
0 3 3 9
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l4 l10
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 4 8
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l5 l10
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 5 2
0
end_o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3 6
4 2
11
1026
2
2 6
5 1
11
1027
2
2 6
5 2
12
1166
2
1 6
6 1
12
1167
2
1 6
6 2
13
1306
2
0 6
7 1
13
1307
2
0 6
7 2
8
10
900
2
3 7
4 1
10
901
2
3 7
4 2
11
1040
2
2 7
5 1
11
1041
2
2 7
5 2
12
1180
2
1 7
6 1
12
1181
2
1 7
6 2
13
1320
2
0 7
7 1
13
1321
2
0 7
7 2
8
10
914
2
3 8
4 1
10
915
2
3 8
4 2
11
1054
2
2 8
5 1
11
1055
2
2 8
5 2
12
1194
2
1 8
6 1
12
1195
2
1 8
6 2
13
1334
2
0 8
7 1
13
1335
2
0 8
7 2
8
10
928
2
3 9
4 1
10
929
2
3 9
4 2
11
1068
2
2 9
5 1
11
1069
2
2 9
5 2
12
1208
2
1 9
6 1
12
1209
2
1 9
6 2
13
1348
2
0 9
7 1
13
1349
2
0 9
7 2
20
0
243
2
3 0
4 1
0
242
2
3 0
4 0
1
256
2
3 1
4 0
1
257
2
3 1
4 1
2
270
2
3 2
4 0
2
271
2
3 2
4 1
3
284
2
3 3
4 0
3
285
2
3 3
4 1
4
298
2
3 4
4 0
4
299
2
3 4
4 1
5
312
2
3 5
4 0
5
313
2
3 5
4 1
6
326
2
3 6
4 0
6
327
2
3 6
4 1
7
340
2
3 7
4 0
7
341
2
3 7
4 1
8
354
2
3 8
4 0
8
355
2
3 8
4 1
9
368
2
3 9
4 0
9
369
2
3 9
4 1
20
0
383
2
2 0
5 1
0
382
2
2 0
5 0
1
396
2
2 1
5 0
1
397
2
2 1
5 1
2
410
2
2 2
5 0
2
411
2
2 2
5 1
3
424
2
2 3
5 0
3
425
2
2 3
5 1
4
438
2
2 4
5 0
4
439
2
2 4
5 1
5
452
2
2 5
5 0
5
453
2
2 5
5 1
6
466
2
2 6
5 0
6
467
2
2 6
5 1
7
480
2
2 7
5 0
7
481
2
2 7
5 1
8
494
2
2 8
5 0
8
495
2
2 8
5 1
9
508
2
2 9
5 0
9
509
2
2 9
5 1
20
0
523
2
1 0
6 1
0
522
2
1 0
6 0
1
536
2
1 1
6 0
1
537
2
1 1
6 1
2
550
2
1 2
6 0
2
551
2
1 2
6 1
3
564
2
1 3
6 0
3
565
2
1 3
6 1
4
578
2
1 4
6 0
4
579
2
1 4
6 1
5
592
2
1 5
6 0
5
593
2
1 5
6 1
6
606
2
1 6
6 0
6
607
2
1 6
6 1
7
620
2
1 7
6 0
7
621
2
1 7
6 1
8
634
2
1 8
6 0
8
635
2
1 8
6 1
9
648
2
1 9
6 0
9
649
2
1 9
6 1
20
0
663
2
0 0
7 1
0
662
2
0 0
7 0
1
676
2
0 1
7 0
1
677
2
0 1
7 1
2
690
2
0 2
7 0
2
691
2
0 2
7 1
3
704
2
0 3
7 0
3
705
2
0 3
7 1
4
718
2
0 4
7 0
4
719
2
0 4
7 1
5
732
2
0 5
7 0
5
733
2
0 5
7 1
6
746
2
0 6
7 0
6
747
2
0 6
7 1
7
760
2
0 7
7 0
7
761
2
0 7
7 1
8
774
2
0 8
7 0
8
775
2
0 8
7 1
9
788
2
0 9
7 0
9
789
2
0 9
7 1
end_DTG
begin_DTG
8
10
804
2
3 0
4 1
10
805
2
3 0
4 2
11
944
2
2 0
5 1
11
945
2
2 0
5 2
12
1084
2
1 0
6 1
12
1085
2
1 0
6 2
13
1224
2
0 0
7 1
13
1225
2
0 0
7 2
8
10
818
2
3 1
4 1
10
819
2
3 1
4 2
11
958
2
2 1
5 1
11
959
2
2 1
5 2
12
1098
2
1 1
6 1
12
1099
2
1 1
6 2
13
1238
2
0 1
7 1
13
1239
2
0 1
7 2
8
10
832
2
3 2
4 1
10
833
2
3 2
4 2
11
972
2
2 2
5 1
11
973
2
2 2
5 2
12
1112
2
1 2
6 1
12
1113
2
1 2
6 2
13
1252
2
0 2
7 1
13
1253
2
0 2
7 2
8
10
846
2
3 3
4 1
10
847
2
3 3
4 2
11
986
2
2 3
5 1
11
987
2
2 3
5 2
12
1126
2
1 3
6 1
12
1127
2
1 3
6 2
13
1266
2
0 3
7 1
13
1267
2
0 3
7 2
8
10
860
2
3 4
4 1
10
861
2
3 4
4 2
11
1000
2
2 4
5 1
11
1001
2
2 4
5 2
12
1140
2
1 4
6 1
12
1141
2
1 4
6 2
13
1280
2
0 4
7 1
13
1281
2
0 4
7 2
8
10
874
2
3 5
4 1
10
875
2
3 5
4 2
11
1014
2
2 5
5 1
11
1015
2
2 5
5 2
12
1154
2
1 5
6 1
12
1155
2
1 5
6 2
13
1294
2
0 5
7 1
13
1295
2
0 5
7 2
8
10
888
2
3 6
4 1
10
889
2
3 6
4 2
11
1028
2
2 6
5 1
11
1029
2
2 6
5 2
12
1168
2
1 6
6 1
12
1169
2
1 6
6 2
13
1308
2
0 6
7 1
13
1309
2
0 6
7 2
8
10
902
2
3 7
4 1
10
903
2
3 7
4 2
11
1042
2
2 7
5 1
11
1043
2
2 7
5 2
12
1182
2
1 7
6 1
12
1183
2
1 7
6 2
13
1322
2
0 7
7 1
13
1323
2
0 7
7 2
8
10
916
2
3 8
4 1
10
917
2
3 8
4 2
11
1056
2
2 8
5 1
11
1057
2
2 8
5 2
12
1196
2
1 8
6 1
12
1197
2
1 8
6 2
13
1336
2
0 8
7 1
13
1337
2
0 8
7 2
8
10
930
2
3 9
4 1
10
931
2
3 9
4 2
11
1070
2
2 9
5 1
11
1071
2
2 9
5 2
12
1210
2
1 9
6 1
12
1211
2
1 9
6 2
13
1350
2
0 9
7 1
13
1351
2
0 9
7 2
20
0
245
2
3 0
4 1
0
244
2
3 0
4 0
1
258
2
3 1
4 0
1
259
2
3 1
4 1
2
272
2
3 2
4 0
2
273
2
3 2
4 1
3
286
2
3 3
4 0
3
287
2
3 3
4 1
4
300
2
3 4
4 0
4
301
2
3 4
4 1
5
314
2
3 5
4 0
5
315
2
3 5
4 1
6
328
2
3 6
4 0
6
329
2
3 6
4 1
7
342
2
3 7
4 0
7
343
2
3 7
4 1
8
356
2
3 8
4 0
8
357
2
3 8
4 1
9
370
2
3 9
4 0
9
371
2
3 9
4 1
20
0
385
2
2 0
5 1
0
384
2
2 0
5 0
1
398
2
2 1
5 0
1
399
2
2 1
5 1
2
412
2
2 2
5 0
2
413
2
2 2
5 1
3
426
2
2 3
5 0
3
427
2
2 3
5 1
4
440
2
2 4
5 0
4
441
2
2 4
5 1
5
454
2
2 5
5 0
5
455
2
2 5
5 1
6
468
2
2 6
5 0
6
469
2
2 6
5 1
7
482
2
2 7
5 0
7
483
2
2 7
5 1
8
496
2
2 8
5 0
8
497
2
2 8
5 1
9
510
2
2 9
5 0
9
511
2
2 9
5 1
20
0
525
2
1 0
6 1
0
524
2
1 0
6 0
1
538
2
1 1
6 0
1
539
2
1 1
6 1
2
552
2
1 2
6 0
2
553
2
1 2
6 1
3
566
2
1 3
6 0
3
567
2
1 3
6 1
4
580
2
1 4
6 0
4
581
2
1 4
6 1
5
594
2
1 5
6 0
5
595
2
1 5
6 1
6
608
2
1 6
6 0
6
609
2
1 6
6 1
7
622
2
1 7
6 0
7
623
2
1 7
6 1
8
636
2
1 8
6 0
8
637
2
1 8
6 1
9
650
2
1 9
6 0
9
651
2
1 9
6 1
20
0
665
2
0 0
7 1
0
664
2
0 0
7 0
1
678
2
0 1
7 0
1
679
2
0 1
7 1
2
692
2
0 2
7 0
2
693
2
0 2
7 1
3
706
2
0 3
7 0
3
707
2
0 3
7 1
4
720
2
0 4
7 0
4
721
2
0 4
7 1
5
734
2
0 5
7 0
5
735
2
0 5
7 1
6
748
2
0 6
7 0
6
749
2
0 6
7 1
7
762
2
0 7
7 0
7
763
2
0 7
7 1
8
776
2
0 8
7 0
8
777
2
0 8
7 1
9
790
2
0 9
7 0
9
791
2
0 9
7 1
end_DTG
begin_CG
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
7 280
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
6 280
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
5 280
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
4 280
7
8 40
9 40
10 40
11 40
12 40
13 40
14 40
7
8 40
9 40
10 40
11 40
12 40
13 40
14 40
7
8 40
9 40
10 40
11 40
12 40
13 40
14 40
7
8 40
9 40
10 40
11 40
12 40
13 40
14 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
end_CG
