begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var20
-1
15
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var19
-1
15
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var18
-1
15
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var17
-1
15
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var16
-1
15
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var15
-1
15
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var21
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var26
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
21
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
21
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
21
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
21
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
21
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
21
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l15)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
21
Atom at(p15, l1)
Atom at(p15, l10)
Atom at(p15, l11)
Atom at(p15, l12)
Atom at(p15, l13)
Atom at(p15, l14)
Atom at(p15, l15)
Atom at(p15, l2)
Atom at(p15, l3)
Atom at(p15, l4)
Atom at(p15, l5)
Atom at(p15, l6)
Atom at(p15, l7)
Atom at(p15, l8)
Atom at(p15, l9)
Atom in(p15, v1)
Atom in(p15, v2)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
4 14
7 1
16
4391
2
4 14
7 2
17
4840
2
3 14
8 1
17
4841
2
3 14
8 2
18
5290
2
2 14
9 1
18
5291
2
2 14
9 2
19
5740
2
1 14
10 1
19
5741
2
1 14
10 2
20
6190
2
0 14
11 1
20
6191
2
0 14
11 2
30
0
821
2
5 0
6 1
0
820
2
5 0
6 0
1
850
2
5 1
6 0
1
851
2
5 1
6 1
2
880
2
5 2
6 0
2
881
2
5 2
6 1
3
910
2
5 3
6 0
3
911
2
5 3
6 1
4
940
2
5 4
6 0
4
941
2
5 4
6 1
5
970
2
5 5
6 0
5
971
2
5 5
6 1
6
1000
2
5 6
6 0
6
1001
2
5 6
6 1
7
1031
2
5 7
6 1
7
1030
2
5 7
6 0
8
1060
2
5 8
6 0
8
1061
2
5 8
6 1
9
1090
2
5 9
6 0
9
1091
2
5 9
6 1
10
1120
2
5 10
6 0
10
1121
2
5 10
6 1
11
1150
2
5 11
6 0
11
1151
2
5 11
6 1
12
1180
2
5 12
6 0
12
1181
2
5 12
6 1
13
1210
2
5 13
6 0
13
1211
2
5 13
6 1
14
1240
2
5 14
6 0
14
1241
2
5 14
6 1
30
0
1271
2
4 0
7 1
0
1270
2
4 0
7 0
1
1300
2
4 1
7 0
1
1301
2
4 1
7 1
2
1330
2
4 2
7 0
2
1331
2
4 2
7 1
3
1360
2
4 3
7 0
3
1361
2
4 3
7 1
4
1390
2
4 4
7 0
4
1391
2
4 4
7 1
5
1420
2
4 5
7 0
5
1421
2
4 5
7 1
6
1450
2
4 6
7 0
6
1451
2
4 6
7 1
7
1481
2
4 7
7 1
7
1480
2
4 7
7 0
8
1510
2
4 8
7 0
8
1511
2
4 8
7 1
9
1540
2
4 9
7 0
9
1541
2
4 9
7 1
10
1570
2
4 10
7 0
10
1571
2
4 10
7 1
11
1600
2
4 11
7 0
11
1601
2
4 11
7 1
12
1630
2
4 12
7 0
12
1631
2
4 12
7 1
13
1660
2
4 13
7 0
13
1661
2
4 13
7 1
14
1690
2
4 14
7 0
14
1691
2
4 14
7 1
30
0
1721
2
3 0
8 1
0
1720
2
3 0
8 0
1
1750
2
3 1
8 0
1
1751
2
3 1
8 1
2
1780
2
3 2
8 0
2
1781
2
3 2
8 1
3
1810
2
3 3
8 0
3
1811
2
3 3
8 1
4
1840
2
3 4
8 0
4
1841
2
3 4
8 1
5
1870
2
3 5
8 0
5
1871
2
3 5
8 1
6
1900
2
3 6
8 0
6
1901
2
3 6
8 1
7
1931
2
3 7
8 1
7
1930
2
3 7
8 0
8
1960
2
3 8
8 0
8
1961
2
3 8
8 1
9
1990
2
3 9
8 0
9
1991
2
3 9
8 1
10
2020
2
3 10
8 0
10
2021
2
3 10
8 1
11
2050
2
3 11
8 0
11
2051
2
3 11
8 1
12
2080
2
3 12
8 0
12
2081
2
3 12
8 1
13
2110
2
3 13
8 0
13
2111
2
3 13
8 1
14
2140
2
3 14
8 0
14
2141
2
3 14
8 1
30
0
2171
2
2 0
9 1
0
2170
2
2 0
9 0
1
2200
2
2 1
9 0
1
2201
2
2 1
9 1
2
2230
2
2 2
9 0
2
2231
2
2 2
9 1
3
2260
2
2 3
9 0
3
2261
2
2 3
9 1
4
2290
2
2 4
9 0
4
2291
2
2 4
9 1
5
2320
2
2 5
9 0
5
2321
2
2 5
9 1
6
2350
2
2 6
9 0
6
2351
2
2 6
9 1
7
2381
2
2 7
9 1
7
2380
2
2 7
9 0
8
2410
2
2 8
9 0
8
2411
2
2 8
9 1
9
2440
2
2 9
9 0
9
2441
2
2 9
9 1
10
2470
2
2 10
9 0
10
2471
2
2 10
9 1
11
2500
2
2 11
9 0
11
2501
2
2 11
9 1
12
2530
2
2 12
9 0
12
2531
2
2 12
9 1
13
2560
2
2 13
9 0
13
2561
2
2 13
9 1
14
2590
2
2 14
9 0
14
2591
2
2 14
9 1
30
0
2621
2
1 0
10 1
0
2620
2
1 0
10 0
1
2650
2
1 1
10 0
1
2651
2
1 1
10 1
2
2680
2
1 2
10 0
2
2681
2
1 2
10 1
3
2710
2
1 3
10 0
3
2711
2
1 3
10 1
4
2740
2
1 4
10 0
4
2741
2
1 4
10 1
5
2770
2
1 5
10 0
5
2771
2
1 5
10 1
6
2800
2
1 6
10 0
6
2801
2
1 6
10 1
7
2831
2
1 7
10 1
7
2830
2
1 7
10 0
8
2860
2
1 8
10 0
8
2861
2
1 8
10 1
9
2890
2
1 9
10 0
9
2891
2
1 9
10 1
10
2920
2
1 10
10 0
10
2921
2
1 10
10 1
11
2950
2
1 11
10 0
11
2951
2
1 11
10 1
12
2980
2
1 12
10 0
12
2981
2
1 12
10 1
13
3010
2
1 13
10 0
13
3011
2
1 13
10 1
14
3040
2
1 14
10 0
14
3041
2
1 14
10 1
30
0
3071
2
0 0
11 1
0
3070
2
0 0
11 0
1
3100
2
0 1
11 0
1
3101
2
0 1
11 1
2
3130
2
0 2
11 0
2
3131
2
0 2
11 1
3
3160
2
0 3
11 0
3
3161
2
0 3
11 1
4
3190
2
0 4
11 0
4
3191
2
0 4
11 1
5
3220
2
0 5
11 0
5
3221
2
0 5
11 1
6
3250
2
0 6
11 0
6
3251
2
0 6
11 1
7
3281
2
0 7
11 1
7
3280
2
0 7
11 0
8
3310
2
0 8
11 0
8
3311
2
0 8
11 1
9
3340
2
0 9
11 0
9
3341
2
0 9
11 1
10
3370
2
0 10
11 0
10
3371
2
0 10
11 1
11
3400
2
0 11
11 0
11
3401
2
0 11
11 1
12
3430
2
0 12
11 0
12
3431
2
0 12
11 1
13
3460
2
0 13
11 0
13
3461
2
0 13
11 1
14
3490
2
0 14
11 0
14
3491
2
0 14
11 1
end_DTG
begin_CG
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
11 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
10 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
9 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
8 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
7 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6 900
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
end_CG
