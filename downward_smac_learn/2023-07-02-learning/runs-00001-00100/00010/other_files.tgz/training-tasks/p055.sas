begin_version
3
end_version
begin_metric
0
end_metric
20
begin_variable
var14
-1
11
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var13
-1
11
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var12
-1
11
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var11
-1
11
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var10
-1
11
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var15
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
16
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
16
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
16
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var3
-1
16
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var4
-1
16
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var5
-1
16
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var6
-1
16
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var7
-1
16
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var8
-1
16
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var9
-1
16
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
0
10
4
6
7
2
2
2
1
1
7
7
0
0
4
8
2
7
3
6
end_state
begin_goal
10
10 2
11 4
12 4
13 2
14 0
15 7
16 4
17 2
18 10
19 5
end_goal
2380
begin_operator
drive v1 l1 l11
0
1
0 4 0 2
0
end_operator
begin_operator
drive v1 l1 l2
0
1
0 4 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 4 0 6
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 4 0 7
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l10 l11





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0 2
9 0
2
1117
2
0 2
9 1
3
1136
2
0 3
9 0
3
1137
2
0 3
9 1
4
1156
2
0 4
9 0
4
1157
2
0 4
9 1
5
1177
2
0 5
9 1
5
1176
2
0 5
9 0
6
1196
2
0 6
9 0
6
1197
2
0 6
9 1
7
1216
2
0 7
9 0
7
1217
2
0 7
9 1
8
1236
2
0 8
9 0
8
1237
2
0 8
9 1
9
1256
2
0 9
9 0
9
1257
2
0 9
9 1
10
1276
2
0 10
9 0
10
1277
2
0 10
9 1
end_DTG
begin_DTG
10
11
1298
2
4 0
5 1
11
1299
2
4 0
5 2
12
1518
2
3 0
6 1
12
1519
2
3 0
6 2
13
1738
2
2 0
7 1
13
1739
2
2 0
7 2
14
1958
2
1 0
8 1
14
1959
2
1 0
8 2
15
2178
2
0 0
9 1
15
2179
2
0 0
9 2
10
11
1318
2
4 1
5 1
11
1319
2
4 1
5 2
12
1538
2
3 1
6 1
12
1539
2
3 1
6 2
13
1758
2
2 1
7 1
13
1759
2
2 1
7 2
14
1978
2
1 1
8 1
14
1979
2
1 1
8 2
15
2198
2
0 1
9 1
15
2199
2
0 1
9 2
10
11
1338
2
4 2
5 1
11
1339
2
4 2
5 2
12
1558
2
3 2
6 1
12
1559
2
3 2
6 2
13
1778
2
2 2
7 1
13
1779
2
2 2
7 2
14
1998
2
1 2
8 1
14
1999
2
1 2
8 2
15
2218
2
0 2
9 1
15
2219
2
0 2
9 2
10
11
1358
2
4 3
5 1
11
1359
2
4 3
5 2
12
1578
2
3 3
6 1
12
1579
2
3 3
6 2
13
1798
2
2 3
7 1
13
1799
2
2 3
7 2
14
2018
2
1 3
8 1
14
2019
2
1 3
8 2
15
2238
2
0 3
9 1
15
2239
2
0 3
9 2
10
11
1378
2
4 4
5 1
11
1379
2
4 4
5 2
12
1598
2
3 4
6 1
12
1599
2
3 4
6 2
13
1818
2
2 4
7 1
13
1819
2
2 4
7 2
14
2038
2
1 4
8 1
14
2039
2
1 4
8 2
15
2258
2
0 4
9 1
15
2259
2
0 4
9 2
10
11
1398
2
4 5
5 1
11
1399
2
4 5
5 2
12
1618
2
3 5
6 1
12
1619
2
3 5
6 2
13
1838
2
2 5
7 1
13
1839
2
2 5
7 2
14
2058
2
1 5
8 1
14
2059
2
1 5
8 2
15
2278
2
0 5
9 1
15
2279
2
0 5
9 2
10
11
1418
2
4 6
5 1
11
1419
2
4 6
5 2
12
1638
2
3 6
6 1
12
1639
2
3 6
6 2
13
1858
2
2 6
7 1
13
1859
2
2 6
7 2
14
2078
2
1 6
8 1
14
2079
2
1 6
8 2
15
2298
2
0 6
9 1
15
2299
2
0 6
9 2
10
11
1438
2
4 7
5 1
11
1439
2
4 7
5 2
12
1658
2
3 7
6 1
12
1659
2
3 7
6 2
13
1878
2
2 7
7 1
13
1879
2
2 7
7 2
14
2098
2
1 7
8 1
14
2099
2
1 7
8 2
15
2318
2
0 7
9 1
15
2319
2
0 7
9 2
10
11
1458
2
4 8
5 1
11
1459
2
4 8
5 2
12
1678
2
3 8
6 1
12
1679
2
3 8
6 2
13
1898
2
2 8
7 1
13
1899
2
2 8
7 2
14
2118
2
1 8
8 1
14
2119
2
1 8
8 2
15
2338
2
0 8
9 1
15
2339
2
0 8
9 2
10
11
1478
2
4 9
5 1
11
1479
2
4 9
5 2
12
1698
2
3 9
6 1
12
1699
2
3 9
6 2
13
1918
2
2 9
7 1
13
1919
2
2 9
7 2
14
2138
2
1 9
8 1
14
2139
2
1 9
8 2
15
2358
2
0 9
9 1
15
2359
2
0 9
9 2
10
11
1498
2
4 10
5 1
11
1499
2
4 10
5 2
12
1718
2
3 10
6 1
12
1719
2
3 10
6 2
13
1938
2
2 10
7 1
13
1939
2
2 10
7 2
14
2158
2
1 10
8 1
14
2159
2
1 10
8 2
15
2378
2
0 10
9 1
15
2379
2
0 10
9 2
22
0
199
2
4 0
5 1
0
198
2
4 0
5 0
1
218
2
4 1
5 0
1
219
2
4 1
5 1
2
238
2
4 2
5 0
2
239
2
4 2
5 1
3
258
2
4 3
5 0
3
259
2
4 3
5 1
4
278
2
4 4
5 0
4
279
2
4 4
5 1
5
299
2
4 5
5 1
5
298
2
4 5
5 0
6
318
2
4 6
5 0
6
319
2
4 6
5 1
7
338
2
4 7
5 0
7
339
2
4 7
5 1
8
358
2
4 8
5 0
8
359
2
4 8
5 1
9
378
2
4 9
5 0
9
379
2
4 9
5 1
10
398
2
4 10
5 0
10
399
2
4 10
5 1
22
0
419
2
3 0
6 1
0
418
2
3 0
6 0
1
438
2
3 1
6 0
1
439
2
3 1
6 1
2
458
2
3 2
6 0
2
459
2
3 2
6 1
3
478
2
3 3
6 0
3
479
2
3 3
6 1
4
498
2
3 4
6 0
4
499
2
3 4
6 1
5
519
2
3 5
6 1
5
518
2
3 5
6 0
6
538
2
3 6
6 0
6
539
2
3 6
6 1
7
558
2
3 7
6 0
7
559
2
3 7
6 1
8
578
2
3 8
6 0
8
579
2
3 8
6 1
9
598
2
3 9
6 0
9
599
2
3 9
6 1
10
618
2
3 10
6 0
10
619
2
3 10
6 1
22
0
639
2
2 0
7 1
0
638
2
2 0
7 0
1
658
2
2 1
7 0
1
659
2
2 1
7 1
2
678
2
2 2
7 0
2
679
2
2 2
7 1
3
698
2
2 3
7 0
3
699
2
2 3
7 1
4
718
2
2 4
7 0
4
719
2
2 4
7 1
5
739
2
2 5
7 1
5
738
2
2 5
7 0
6
758
2
2 6
7 0
6
759
2
2 6
7 1
7
778
2
2 7
7 0
7
779
2
2 7
7 1
8
798
2
2 8
7 0
8
799
2
2 8
7 1
9
818
2
2 9
7 0
9
819
2
2 9
7 1
10
838
2
2 10
7 0
10
839
2
2 10
7 1
22
0
859
2
1 0
8 1
0
858
2
1 0
8 0
1
878
2
1 1
8 0
1
879
2
1 1
8 1
2
898
2
1 2
8 0
2
899
2
1 2
8 1
3
918
2
1 3
8 0
3
919
2
1 3
8 1
4
938
2
1 4
8 0
4
939
2
1 4
8 1
5
959
2
1 5
8 1
5
958
2
1 5
8 0
6
978
2
1 6
8 0
6
979
2
1 6
8 1
7
998
2
1 7
8 0
7
999
2
1 7
8 1
8
1018
2
1 8
8 0
8
1019
2
1 8
8 1
9
1038
2
1 9
8 0
9
1039
2
1 9
8 1
10
1058
2
1 10
8 0
10
1059
2
1 10
8 1
22
0
1079
2
0 0
9 1
0
1078
2
0 0
9 0
1
1098
2
0 1
9 0
1
1099
2
0 1
9 1
2
1118
2
0 2
9 0
2
1119
2
0 2
9 1
3
1138
2
0 3
9 0
3
1139
2
0 3
9 1
4
1158
2
0 4
9 0
4
1159
2
0 4
9 1
5
1179
2
0 5
9 1
5
1178
2
0 5
9 0
6
1198
2
0 6
9 0
6
1199
2
0 6
9 1
7
1218
2
0 7
9 0
7
1219
2
0 7
9 1
8
1238
2
0 8
9 0
8
1239
2
0 8
9 1
9
1258
2
0 9
9 0
9
1259
2
0 9
9 1
10
1278
2
0 10
9 0
10
1279
2
0 10
9 1
end_DTG
begin_CG
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
9 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
8 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
7 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
6 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
5 440
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
end_CG
