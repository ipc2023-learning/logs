begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var9
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var8
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var10
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
12
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
0
begin_state
4
0
1
7
2
1
2
1
7
4
1
7
6
3
end_state
begin_goal
6
8 3
9 2
10 2
11 3
12 5
13 4
end_goal
872
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
end_operator
begin_operator
drive v1 l8 l4
0
1
0 3 7 3
0
end_operator
begin_operator
drive v1 l8 l5
0
1
0 3 7 4
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v2 l1 l8
0
1
0 2 0 7
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v2 l3 l6
0
1
0 2 2 5
0
end_operator
begin_operator
drive v2 l4 l6
0
1
0 2 3 5
0
end_operator
begin_operator
drive v2 l4 l7
0
1
0 2 3 6
0
end_operator
begin_operator
drive v2 l4 l8
0
1
0 2 3 7
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v2 l5 l8
0
1
0 2 4 7
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




39
2
1 3
6 1
4
350
2
1 4
6 0
4
351
2
1 4
6 1
5
362
2
1 5
6 0
5
363
2
1 5
6 1
6
374
2
1 6
6 0
6
375
2
1 6
6 1
7
386
2
1 7
6 0
7
387
2
1 7
6 1
16
0
398
2
0 0
7 0
0
399
2
0 0
7 1
1
410
2
0 1
7 0
1
411
2
0 1
7 1
2
422
2
0 2
7 0
2
423
2
0 2
7 1
3
434
2
0 3
7 0
3
435
2
0 3
7 1
4
446
2
0 4
7 0
4
447
2
0 4
7 1
5
458
2
0 5
7 0
5
459
2
0 5
7 1
6
470
2
0 6
7 0
6
471
2
0 6
7 1
7
482
2
0 7
7 0
7
483
2
0 7
7 1
end_DTG
begin_DTG
8
8
496
2
3 0
4 1
8
497
2
3 0
4 2
9
592
2
2 0
5 1
9
593
2
2 0
5 2
10
688
2
1 0
6 1
10
689
2
1 0
6 2
11
784
2
0 0
7 1
11
785
2
0 0
7 2
8
8
508
2
3 1
4 1
8
509
2
3 1
4 2
9
604
2
2 1
5 1
9
605
2
2 1
5 2
10
700
2
1 1
6 1
10
701
2
1 1
6 2
11
796
2
0 1
7 1
11
797
2
0 1
7 2
8
8
520
2
3 2
4 1
8
521
2
3 2
4 2
9
616
2
2 2
5 1
9
617
2
2 2
5 2
10
712
2
1 2
6 1
10
713
2
1 2
6 2
11
808
2
0 2
7 1
11
809
2
0 2
7 2
8
8
532
2
3 3
4 1
8
533
2
3 3
4 2
9
628
2
2 3
5 1
9
629
2
2 3
5 2
10
724
2
1 3
6 1
10
725
2
1 3
6 2
11
820
2
0 3
7 1
11
821
2
0 3
7 2
8
8
544
2
3 4
4 1
8
545
2
3 4
4 2
9
640
2
2 4
5 1
9
641
2
2 4
5 2
10
736
2
1 4
6 1
10
737
2
1 4
6 2
11
832
2
0 4
7 1
11
833
2
0 4
7 2
8
8
556
2
3 5
4 1
8
557
2
3 5
4 2
9
652
2
2 5
5 1
9
653
2
2 5
5 2
10
748
2
1 5
6 1
10
749
2
1 5
6 2
11
844
2
0 5
7 1
11
845
2
0 5
7 2
8
8
568
2
3 6
4 1
8
569
2
3 6
4 2
9
664
2
2 6
5 1
9
665
2
2 6
5 2
10
760
2
1 6
6 1
10
761
2
1 6
6 2
11
856
2
0 6
7 1
11
857
2
0 6
7 2
8
8
580
2
3 7
4 1
8
581
2
3 7
4 2
9
676
2
2 7
5 1
9
677
2
2 7
5 2
10
772
2
1 7
6 1
10
773
2
1 7
6 2
11
868
2
0 7
7 1
11
869
2
0 7
7 2
16
0
112
2
3 0
4 0
0
113
2
3 0
4 1
1
124
2
3 1
4 0
1
125
2
3 1
4 1
2
136
2
3 2
4 0
2
137
2
3 2
4 1
3
148
2
3 3
4 0
3
149
2
3 3
4 1
4
160
2
3 4
4 0
4
161
2
3 4
4 1
5
172
2
3 5
4 0
5
173
2
3 5
4 1
6
184
2
3 6
4 0
6
185
2
3 6
4 1
7
196
2
3 7
4 0
7
197
2
3 7
4 1
16
0
208
2
2 0
5 0
0
209
2
2 0
5 1
1
220
2
2 1
5 0
1
221
2
2 1
5 1
2
232
2
2 2
5 0
2
233
2
2 2
5 1
3
244
2
2 3
5 0
3
245
2
2 3
5 1
4
256
2
2 4
5 0
4
257
2
2 4
5 1
5
268
2
2 5
5 0
5
269
2
2 5
5 1
6
280
2
2 6
5 0
6
281
2
2 6
5 1
7
292
2
2 7
5 0
7
293
2
2 7
5 1
16
0
304
2
1 0
6 0
0
305
2
1 0
6 1
1
316
2
1 1
6 0
1
317
2
1 1
6 1
2
328
2
1 2
6 0
2
329
2
1 2
6 1
3
340
2
1 3
6 0
3
341
2
1 3
6 1
4
352
2
1 4
6 0
4
353
2
1 4
6 1
5
364
2
1 5
6 0
5
365
2
1 5
6 1
6
376
2
1 6
6 0
6
377
2
1 6
6 1
7
388
2
1 7
6 0
7
389
2
1 7
6 1
16
0
400
2
0 0
7 0
0
401
2
0 0
7 1
1
412
2
0 1
7 0
1
413
2
0 1
7 1
2
424
2
0 2
7 0
2
425
2
0 2
7 1
3
436
2
0 3
7 0
3
437
2
0 3
7 1
4
448
2
0 4
7 0
4
449
2
0 4
7 1
5
460
2
0 5
7 0
5
461
2
0 5
7 1
6
472
2
0 6
7 0
6
473
2
0 6
7 1
7
484
2
0 7
7 0
7
485
2
0 7
7 1
end_DTG
begin_DTG
8
8
498
2
3 0
4 1
8
499
2
3 0
4 2
9
594
2
2 0
5 1
9
595
2
2 0
5 2
10
690
2
1 0
6 1
10
691
2
1 0
6 2
11
786
2
0 0
7 1
11
787
2
0 0
7 2
8
8
510
2
3 1
4 1
8
511
2
3 1
4 2
9
606
2
2 1
5 1
9
607
2
2 1
5 2
10
702
2
1 1
6 1
10
703
2
1 1
6 2
11
798
2
0 1
7 1
11
799
2
0 1
7 2
8
8
522
2
3 2
4 1
8
523
2
3 2
4 2
9
618
2
2 2
5 1
9
619
2
2 2
5 2
10
714
2
1 2
6 1
10
715
2
1 2
6 2
11
810
2
0 2
7 1
11
811
2
0 2
7 2
8
8
534
2
3 3
4 1
8
535
2
3 3
4 2
9
630
2
2 3
5 1
9
631
2
2 3
5 2
10
726
2
1 3
6 1
10
727
2
1 3
6 2
11
822
2
0 3
7 1
11
823
2
0 3
7 2
8
8
546
2
3 4
4 1
8
547
2
3 4
4 2
9
642
2
2 4
5 1
9
643
2
2 4
5 2
10
738
2
1 4
6 1
10
739
2
1 4
6 2
11
834
2
0 4
7 1
11
835
2
0 4
7 2
8
8
558
2
3 5
4 1
8
559
2
3 5
4 2
9
654
2
2 5
5 1
9
655
2
2 5
5 2
10
750
2
1 5
6 1
10
751
2
1 5
6 2
11
846
2
0 5
7 1
11
847
2
0 5
7 2
8
8
570
2
3 6
4 1
8
571
2
3 6
4 2
9
666
2
2 6
5 1
9
667
2
2 6
5 2
10
762
2
1 6
6 1
10
763
2
1 6
6 2
11
858
2
0 6
7 1
11
859
2
0 6
7 2
8
8
582
2
3 7
4 1
8
583
2
3 7
4 2
9
678
2
2 7
5 1
9
679
2
2 7
5 2
10
774
2
1 7
6 1
10
775
2
1 7
6 2
11
870
2
0 7
7 1
11
871
2
0 7
7 2
16
0
114
2
3 0
4 0
0
115
2
3 0
4 1
1
126
2
3 1
4 0
1
127
2
3 1
4 1
2
138
2
3 2
4 0
2
139
2
3 2
4 1
3
150
2
3 3
4 0
3
151
2
3 3
4 1
4
162
2
3 4
4 0
4
163
2
3 4
4 1
5
174
2
3 5
4 0
5
175
2
3 5
4 1
6
186
2
3 6
4 0
6
187
2
3 6
4 1
7
198
2
3 7
4 0
7
199
2
3 7
4 1
16
0
210
2
2 0
5 0
0
211
2
2 0
5 1
1
222
2
2 1
5 0
1
223
2
2 1
5 1
2
234
2
2 2
5 0
2
235
2
2 2
5 1
3
246
2
2 3
5 0
3
247
2
2 3
5 1
4
258
2
2 4
5 0
4
259
2
2 4
5 1
5
270
2
2 5
5 0
5
271
2
2 5
5 1
6
282
2
2 6
5 0
6
283
2
2 6
5 1
7
294
2
2 7
5 0
7
295
2
2 7
5 1
16
0
306
2
1 0
6 0
0
307
2
1 0
6 1
1
318
2
1 1
6 0
1
319
2
1 1
6 1
2
330
2
1 2
6 0
2
331
2
1 2
6 1
3
342
2
1 3
6 0
3
343
2
1 3
6 1
4
354
2
1 4
6 0
4
355
2
1 4
6 1
5
366
2
1 5
6 0
5
367
2
1 5
6 1
6
378
2
1 6
6 0
6
379
2
1 6
6 1
7
390
2
1 7
6 0
7
391
2
1 7
6 1
16
0
402
2
0 0
7 0
0
403
2
0 0
7 1
1
414
2
0 1
7 0
1
415
2
0 1
7 1
2
426
2
0 2
7 0
2
427
2
0 2
7 1
3
438
2
0 3
7 0
3
439
2
0 3
7 1
4
450
2
0 4
7 0
4
451
2
0 4
7 1
5
462
2
0 5
7 0
5
463
2
0 5
7 1
6
474
2
0 6
7 0
6
475
2
0 6
7 1
7
486
2
0 7
7 0
7
487
2
0 7
7 1
end_DTG
begin_CG
7
8 32
9 32
10 32
11 32
12 32
13 32
7 192
7
8 32
9 32
10 32
11 32
12 32
13 32
6 192
7
8 32
9 32
10 32
11 32
12 32
13 32
5 192
7
8 32
9 32
10 32
11 32
12 32
13 32
4 192
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
