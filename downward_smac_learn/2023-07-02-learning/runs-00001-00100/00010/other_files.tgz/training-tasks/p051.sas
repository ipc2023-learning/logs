begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var13
-1
11
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var12
-1
11
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var11
-1
11
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var10
-1
11
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var9
-1
11
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var14
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
16
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
16
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
16
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
16
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
16
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
16
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
16
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
16
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var8
-1
16
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
1
4
1
4
2
2
2
1
2
1
3
1
2
2
7
0
0
0
2
end_state
begin_goal
9
10 4
11 10
12 7
13 10
14 3
15 10
16 3
17 8
18 8
end_goal
2460
begin_operator
drive v1 l1 l10
0
1
0 4 0 1
0
end_operator
begin_operator
drive v1 l1 l11
0
1
0 4 0 2
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 4 0 4
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 4 0 5
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 4 0 6
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 4 0 7
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 4 0 9
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 4 0 10
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 4 1 0
0
end_operator
begin_operator
drive v1 l10 l11
0
1
0 4 1 2
0
end_operator
begin_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
9 1
0
1286
2
0 0
9 0
1
1304
2
0 1
9 0
1
1305
2
0 1
9 1
2
1322
2
0 2
9 0
2
1323
2
0 2
9 1
3
1340
2
0 3
9 0
3
1341
2
0 3
9 1
4
1358
2
0 4
9 0
4
1359
2
0 4
9 1
5
1377
2
0 5
9 1
5
1376
2
0 5
9 0
6
1394
2
0 6
9 0
6
1395
2
0 6
9 1
7
1412
2
0 7
9 0
7
1413
2
0 7
9 1
8
1430
2
0 8
9 0
8
1431
2
0 8
9 1
9
1448
2
0 9
9 0
9
1449
2
0 9
9 1
10
1466
2
0 10
9 0
10
1467
2
0 10
9 1
end_DTG
begin_DTG
10
11
1486
2
4 0
5 1
11
1487
2
4 0
5 2
12
1684
2
3 0
6 1
12
1685
2
3 0
6 2
13
1882
2
2 0
7 1
13
1883
2
2 0
7 2
14
2080
2
1 0
8 1
14
2081
2
1 0
8 2
15
2278
2
0 0
9 1
15
2279
2
0 0
9 2
10
11
1504
2
4 1
5 1
11
1505
2
4 1
5 2
12
1702
2
3 1
6 1
12
1703
2
3 1
6 2
13
1900
2
2 1
7 1
13
1901
2
2 1
7 2
14
2098
2
1 1
8 1
14
2099
2
1 1
8 2
15
2296
2
0 1
9 1
15
2297
2
0 1
9 2
10
11
1522
2
4 2
5 1
11
1523
2
4 2
5 2
12
1720
2
3 2
6 1
12
1721
2
3 2
6 2
13
1918
2
2 2
7 1
13
1919
2
2 2
7 2
14
2116
2
1 2
8 1
14
2117
2
1 2
8 2
15
2314
2
0 2
9 1
15
2315
2
0 2
9 2
10
11
1540
2
4 3
5 1
11
1541
2
4 3
5 2
12
1738
2
3 3
6 1
12
1739
2
3 3
6 2
13
1936
2
2 3
7 1
13
1937
2
2 3
7 2
14
2134
2
1 3
8 1
14
2135
2
1 3
8 2
15
2332
2
0 3
9 1
15
2333
2
0 3
9 2
10
11
1558
2
4 4
5 1
11
1559
2
4 4
5 2
12
1756
2
3 4
6 1
12
1757
2
3 4
6 2
13
1954
2
2 4
7 1
13
1955
2
2 4
7 2
14
2152
2
1 4
8 1
14
2153
2
1 4
8 2
15
2350
2
0 4
9 1
15
2351
2
0 4
9 2
10
11
1576
2
4 5
5 1
11
1577
2
4 5
5 2
12
1774
2
3 5
6 1
12
1775
2
3 5
6 2
13
1972
2
2 5
7 1
13
1973
2
2 5
7 2
14
2170
2
1 5
8 1
14
2171
2
1 5
8 2
15
2368
2
0 5
9 1
15
2369
2
0 5
9 2
10
11
1594
2
4 6
5 1
11
1595
2
4 6
5 2
12
1792
2
3 6
6 1
12
1793
2
3 6
6 2
13
1990
2
2 6
7 1
13
1991
2
2 6
7 2
14
2188
2
1 6
8 1
14
2189
2
1 6
8 2
15
2386
2
0 6
9 1
15
2387
2
0 6
9 2
10
11
1612
2
4 7
5 1
11
1613
2
4 7
5 2
12
1810
2
3 7
6 1
12
1811
2
3 7
6 2
13
2008
2
2 7
7 1
13
2009
2
2 7
7 2
14
2206
2
1 7
8 1
14
2207
2
1 7
8 2
15
2404
2
0 7
9 1
15
2405
2
0 7
9 2
10
11
1630
2
4 8
5 1
11
1631
2
4 8
5 2
12
1828
2
3 8
6 1
12
1829
2
3 8
6 2
13
2026
2
2 8
7 1
13
2027
2
2 8
7 2
14
2224
2
1 8
8 1
14
2225
2
1 8
8 2
15
2422
2
0 8
9 1
15
2423
2
0 8
9 2
10
11
1648
2
4 9
5 1
11
1649
2
4 9
5 2
12
1846
2
3 9
6 1
12
1847
2
3 9
6 2
13
2044
2
2 9
7 1
13
2045
2
2 9
7 2
14
2242
2
1 9
8 1
14
2243
2
1 9
8 2
15
2440
2
0 9
9 1
15
2441
2
0 9
9 2
10
11
1666
2
4 10
5 1
11
1667
2
4 10
5 2
12
1864
2
3 10
6 1
12
1865
2
3 10
6 2
13
2062
2
2 10
7 1
13
2063
2
2 10
7 2
14
2260
2
1 10
8 1
14
2261
2
1 10
8 2
15
2458
2
0 10
9 1
15
2459
2
0 10
9 2
22
0
497
2
4 0
5 1
0
496
2
4 0
5 0
1
514
2
4 1
5 0
1
515
2
4 1
5 1
2
532
2
4 2
5 0
2
533
2
4 2
5 1
3
550
2
4 3
5 0
3
551
2
4 3
5 1
4
568
2
4 4
5 0
4
569
2
4 4
5 1
5
587
2
4 5
5 1
5
586
2
4 5
5 0
6
604
2
4 6
5 0
6
605
2
4 6
5 1
7
622
2
4 7
5 0
7
623
2
4 7
5 1
8
640
2
4 8
5 0
8
641
2
4 8
5 1
9
658
2
4 9
5 0
9
659
2
4 9
5 1
10
676
2
4 10
5 0
10
677
2
4 10
5 1
22
0
695
2
3 0
6 1
0
694
2
3 0
6 0
1
712
2
3 1
6 0
1
713
2
3 1
6 1
2
730
2
3 2
6 0
2
731
2
3 2
6 1
3
748
2
3 3
6 0
3
749
2
3 3
6 1
4
766
2
3 4
6 0
4
767
2
3 4
6 1
5
785
2
3 5
6 1
5
784
2
3 5
6 0
6
802
2
3 6
6 0
6
803
2
3 6
6 1
7
820
2
3 7
6 0
7
821
2
3 7
6 1
8
838
2
3 8
6 0
8
839
2
3 8
6 1
9
856
2
3 9
6 0
9
857
2
3 9
6 1
10
874
2
3 10
6 0
10
875
2
3 10
6 1
22
0
893
2
2 0
7 1
0
892
2
2 0
7 0
1
910
2
2 1
7 0
1
911
2
2 1
7 1
2
928
2
2 2
7 0
2
929
2
2 2
7 1
3
946
2
2 3
7 0
3
947
2
2 3
7 1
4
964
2
2 4
7 0
4
965
2
2 4
7 1
5
983
2
2 5
7 1
5
982
2
2 5
7 0
6
1000
2
2 6
7 0
6
1001
2
2 6
7 1
7
1018
2
2 7
7 0
7
1019
2
2 7
7 1
8
1036
2
2 8
7 0
8
1037
2
2 8
7 1
9
1054
2
2 9
7 0
9
1055
2
2 9
7 1
10
1072
2
2 10
7 0
10
1073
2
2 10
7 1
22
0
1091
2
1 0
8 1
0
1090
2
1 0
8 0
1
1108
2
1 1
8 0
1
1109
2
1 1
8 1
2
1126
2
1 2
8 0
2
1127
2
1 2
8 1
3
1144
2
1 3
8 0
3
1145
2
1 3
8 1
4
1162
2
1 4
8 0
4
1163
2
1 4
8 1
5
1181
2
1 5
8 1
5
1180
2
1 5
8 0
6
1198
2
1 6
8 0
6
1199
2
1 6
8 1
7
1216
2
1 7
8 0
7
1217
2
1 7
8 1
8
1234
2
1 8
8 0
8
1235
2
1 8
8 1
9
1252
2
1 9
8 0
9
1253
2
1 9
8 1
10
1270
2
1 10
8 0
10
1271
2
1 10
8 1
22
0
1289
2
0 0
9 1
0
1288
2
0 0
9 0
1
1306
2
0 1
9 0
1
1307
2
0 1
9 1
2
1324
2
0 2
9 0
2
1325
2
0 2
9 1
3
1342
2
0 3
9 0
3
1343
2
0 3
9 1
4
1360
2
0 4
9 0
4
1361
2
0 4
9 1
5
1379
2
0 5
9 1
5
1378
2
0 5
9 0
6
1396
2
0 6
9 0
6
1397
2
0 6
9 1
7
1414
2
0 7
9 0
7
1415
2
0 7
9 1
8
1432
2
0 8
9 0
8
1433
2
0 8
9 1
9
1450
2
0 9
9 0
9
1451
2
0 9
9 1
10
1468
2
0 10
9 0
10
1469
2
0 10
9 1
end_DTG
begin_CG
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
8 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
7 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
6 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5 396
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
end_CG
