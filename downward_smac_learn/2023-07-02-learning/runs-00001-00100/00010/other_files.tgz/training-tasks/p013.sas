begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var5
-1
6
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
end_variable
begin_variable
var4
-1
6
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
end_variable
begin_variable
var3
-1
6
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
end_variable
begin_variable
var6
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
9
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
9
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
9
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
0
begin_state
2
3
1
1
2
2
3
3
3
end_state
begin_goal
3
6 2
7 4
8 0
end_goal
252
begin_operator
drive v1 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 2 5 0
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 2 5 4
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 1 0 5
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 1 4 5
0
end_operator
begin_operator
drive v2 l6 l1
0
1
0 1 5 0
0
end_operator
begin_operator
drive v2 l6 l5
0
1
0 1 5 4
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v3 l1 l6
0
1
0 0 0 5
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v3 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v3 l3 l1
0
1
0 0 2 0
0
end_operator
begin_operator
drive v3 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drive v3 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drive v3 l4 l5
0
1
0 0 3 4
0
end_operator
begin_operator
drive v3 l5 l4
0
1
0 0 4 3
0
end_operator
begin_operator
drive v3 l5 l6
0
1
0 0 4 5
0
end_operator
begin_operator
drive v3 l6 l1
0
1
0 0 5 0
0
end_operator
begin_operator
drive v3 l6 l5
0
1
0 0 5 4
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
2 0
2
0 6 6 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
2 0
2
0 6 6 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
2 0
2
0 7 6 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
2 0
2
0 7 6 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p3 c0 c1
1
2 0
2
0 8 6 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p3 c1 c2
1
2 0
2
0 8 6 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
2 1
2
0 6 6 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c1 c2
1
2 1
2
0 6 6 1
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p2 c0 c1
1
2 1
2
0 7 6 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p2 c1 c2
1
2 1
2
0 7 6 1
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p3 c0 c1
1
2 1
2
0 8 6 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p3 c1 c2
1
2 1
2
0 8 6 1
0 3 1 2
0
end_operator
begin_operator
drop v1 l3 p1 c0 c1
1
2 2
2
0 6 6 2
0 3 0 1
0
end_operator
begin_operator
drop v1 l3 p1 c1 c2
1
2 2
2
0 6 6 2
0 3 1 2
0
end_operator
begin_operator
drop v1 l3 p2 c0 c1
1
2 2
2
0 7 6 2
0 3 0 1
0
end_operator
begin_operator
drop v1 l3 p2 c1 c2
1
2 2
2
0 7 6 2
0 3 1 2
0
end_operator
begin_operator
drop v1 l3 p3 c0 c1
1
2 2
2
0 8 6 2
0 3 0 1
0
end_operator
begin_operator
drop v1 l3 p3 c1 c2
1
2 2
2
0 8 6 2
0 3 1 2
0
end_operator
begin_operator
drop v1 l4 p1 c0 c1
1
2 3
2
0 6 6 3
0 3 0 1
0
end_operator
begin_operator
drop v1 l4 p1 c1 c2
1
2 3
2
0 6 6 3
0 3 1 2
0
end_operator
begin_operator
drop v1 l4 p2 c0 c1
1
2 3
2
0 7 6 3
0 3 0 1
0
end_operator
begin_operator
drop v1 l4 p2 c1 c2
1
2 3
2
0 7 6 3
0 3 1 2
0
end_operator
begin_operator
drop v1 l4 p3 c0 c1
1
2 3
2
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
211
2
6 5
1 5
1
209
2
8 4
1 4
1
207
2
7 4
1 4
1
205
2
6 4
1 4
1
203
2
8 3
1 3
1
201
2
7 3
1 3
1
181
2
6 0
1 0
1
197
2
8 2
1 2
1
195
2
7 2
1 2
1
193
2
6 2
1 2
1
191
2
8 1
1 1
1
189
2
7 1
1 1
1
187
2
6 1
1 1
1
185
2
8 0
1 0
1
183
2
7 0
1 0
end_DTG
begin_DTG
18
1
126
2
6 8
0 3
1
142
2
8 8
0 5
1
140
2
7 8
0 5
1
138
2
6 8
0 5
1
136
2
8 8
0 4
1
134
2
7 8
0 4
1
132
2
6 8
0 4
1
130
2
8 8
0 3
1
128
2
7 8
0 3
1
108
2
6 8
0 0
1
124
2
8 8
0 2
1
122
2
7 8
0 2
1
120
2
6 8
0 2
1
118
2
8 8
0 1
1
116
2
7 8
0 1
1
114
2
6 8
0 1
1
112
2
8 8
0 0
1
110
2
7 8
0 0
36
0
234
2
6 3
0 3
0
218
2
7 0
0 0
0
220
2
8 0
0 0
0
222
2
6 1
0 1
0
224
2
7 1
0 1
0
226
2
8 1
0 1
0
228
2
6 2
0 2
0
230
2
7 2
0 2
0
232
2
8 2
0 2
0
216
2
6 0
0 0
0
236
2
7 3
0 3
0
238
2
8 3
0 3
0
240
2
6 4
0 4
0
242
2
7 4
0 4
0
244
2
8 4
0 4
0
246
2
6 5
0 5
0
248
2
7 5
0 5
0
250
2
8 5
0 5
2
127
2
6 8
0 3
2
111
2
7 8
0 0
2
113
2
8 8
0 0
2
115
2
6 8
0 1
2
117
2
7 8
0 1
2
119
2
8 8
0 1
2
121
2
6 8
0 2
2
123
2
7 8
0 2
2
125
2
8 8
0 2
2
109
2
6 8
0 0
2
129
2
7 8
0 3
2
131
2
8 8
0 3
2
133
2
6 8
0 4
2
135
2
7 8
0 4
2
137
2
8 8
0 4
2
139
2
6 8
0 5
2
141
2
7 8
0 5
2
143
2
8 8
0 5
18
1
235
2
6 3
0 3
1
251
2
8 5
0 5
1
249
2
7 5
0 5
1
247
2
6 5
0 5
1
245
2
8 4
0 4
1
243
2
7 4
0 4
1
241
2
6 4
0 4
1
239
2
8 3
0 3
1
237
2
7 3
0 3
1
217
2
6 0
0 0
1
233
2
8 2
0 2
1
231
2
7 2
0 2
1
229
2
6 2
0 2
1
227
2
8 1
0 1
1
225
2
7 1
0 1
1
223
2
6 1
0 1
1
221
2
8 0
0 0
1
219
2
7 0
0 0
end_DTG
begin_DTG
6
6
144
2
2 0
3 1
6
145
2
2 0
3 2
7
180
2
1 0
4 1
7
181
2
1 0
4 2
8
216
2
0 0
5 1
8
217
2
0 0
5 2
6
6
150
2
2 1
3 1
6
151
2
2 1
3 2
7
186
2
1 1
4 1
7
187
2
1 1
4 2
8
222
2
0 1
5 1
8
223
2
0 1
5 2
6
6
156
2
2 2
3 1
6
157
2
2 2
3 2
7
192
2
1 2
4 1
7
193
2
1 2
4 2
8
228
2
0 2
5 1
8
229
2
0 2
5 2
6
6
162
2
2 3
3 1
6
163
2
2 3
3 2
7
198
2
1 3
4 1
7
199
2
1 3
4 2
8
234
2
0 3
5 1
8
235
2
0 3
5 2
6
6
168
2
2 4
3 1
6
169
2
2 4
3 2
7
204
2
1 4
4 1
7
205
2
1 4
4 2
8
240
2
0 4
5 1
8
241
2
0 4
5 2
6
6
174
2
2 5
3 1
6
175
2
2 5
3 2
7
210
2
1 5
4 1
7
211
2
1 5
4 2
8
246
2
0 5
5 1
8
247
2
0 5
5 2
12
0
36
2
2 0
3 0
0
37
2
2 0
3 1
1
42
2
2 1
3 0
1
43
2
2 1
3 1
2
48
2
2 2
3 0
2
49
2
2 2
3 1
3
54
2
2 3
3 0
3
55
2
2 3
3 1
4
60
2
2 4
3 0
4
61
2
2 4
3 1
5
66
2
2 5
3 0
5
67
2
2 5
3 1
12
0
72
2
1 0
4 0
0
73
2
1 0
4 1
1
78
2
1 1
4 0
1
79
2
1 1
4 1
2
84
2
1 2
4 0
2
85
2
1 2
4 1
3
90
2
1 3
4 0
3
91
2
1 3
4 1
4
96
2
1 4
4 0
4
97
2
1 4
4 1
5
102
2
1 5
4 0
5
103
2
1 5
4 1
12
0
108
2
0 0
5 0
0
109
2
0 0
5 1
1
114
2
0 1
5 0
1
115
2
0 1
5 1
2
120
2
0 2
5 0
2
121
2
0 2
5 1
3
126
2
0 3
5 0
3
127
2
0 3
5 1
4
132
2
0 4
5 0
4
133
2
0 4
5 1
5
138
2
0 5
5 0
5
139
2
0 5
5 1
end_DTG
begin_DTG
6
6
146
2
2 0
3 1
6
147
2
2 0
3 2
7
182
2
1 0
4 1
7
183
2
1 0
4 2
8
218
2
0 0
5 1
8
219
2
0 0
5 2
6
6
152
2
2 1
3 1
6
153
2
2 1
3 2
7
188
2
1 1
4 1
7
189
2
1 1
4 2
8
224
2
0 1
5 1
8
225
2
0 1
5 2
6
6
158
2
2 2
3 1
6
159
2
2 2
3 2
7
194
2
1 2
4 1
7
195
2
1 2
4 2
8
230
2
0 2
5 1
8
231
2
0 2
5 2
6
6
164
2
2 3
3 1
6
165
2
2 3
3 2
7
200
2
1 3
4 1
7
201
2
1 3
4 2
8
236
2
0 3
5 1
8
237
2
0 3
5 2
6
6
170
2
2 4
3 1
6
171
2
2 4
3 2
7
206
2
1 4
4 1
7
207
2
1 4
4 2
8
242
2
0 4
5 1
8
243
2
0 4
5 2
6
6
176
2
2 5
3 1
6
177
2
2 5
3 2
7
212
2
1 5
4 1
7
213
2
1 5
4 2
8
248
2
0 5
5 1
8
249
2
0 5
5 2
12
0
38
2
2 0
3 0
0
39
2
2 0
3 1
1
44
2
2 1
3 0
1
45
2
2 1
3 1
2
50
2
2 2
3 0
2
51
2
2 2
3 1
3
56
2
2 3
3 0
3
57
2
2 3
3 1
4
62
2
2 4
3 0
4
63
2
2 4
3 1
5
68
2
2 5
3 0
5
69
2
2 5
3 1
12
0
74
2
1 0
4 0
0
75
2
1 0
4 1
1
80
2
1 1
4 0
1
81
2
1 1
4 1
2
86
2
1 2
4 0
2
87
2
1 2
4 1
3
92
2
1 3
4 0
3
93
2
1 3
4 1
4
98
2
1 4
4 0
4
99
2
1 4
4 1
5
104
2
1 5
4 0
5
105
2
1 5
4 1
12
0
110
2
0 0
5 0
0
111
2
0 0
5 1
1
116
2
0 1
5 0
1
117
2
0 1
5 1
2
122
2
0 2
5 0
2
123
2
0 2
5 1
3
128
2
0 3
5 0
3
129
2
0 3
5 1
4
134
2
0 4
5 0
4
135
2
0 4
5 1
5
140
2
0 5
5 0
5
141
2
0 5
5 1
end_DTG
begin_DTG
6
6
148
2
2 0
3 1
6
149
2
2 0
3 2
7
184
2
1 0
4 1
7
185
2
1 0
4 2
8
220
2
0 0
5 1
8
221
2
0 0
5 2
6
6
154
2
2 1
3 1
6
155
2
2 1
3 2
7
190
2
1 1
4 1
7
191
2
1 1
4 2
8
226
2
0 1
5 1
8
227
2
0 1
5 2
6
6
160
2
2 2
3 1
6
161
2
2 2
3 2
7
196
2
1 2
4 1
7
197
2
1 2
4 2
8
232
2
0 2
5 1
8
233
2
0 2
5 2
6
6
166
2
2 3
3 1
6
167
2
2 3
3 2
7
202
2
1 3
4 1
7
203
2
1 3
4 2
8
238
2
0 3
5 1
8
239
2
0 3
5 2
6
6
172
2
2 4
3 1
6
173
2
2 4
3 2
7
208
2
1 4
4 1
7
209
2
1 4
4 2
8
244
2
0 4
5 1
8
245
2
0 4
5 2
6
6
178
2
2 5
3 1
6
179
2
2 5
3 2
7
214
2
1 5
4 1
7
215
2
1 5
4 2
8
250
2
0 5
5 1
8
251
2
0 5
5 2
12
0
40
2
2 0
3 0
0
41
2
2 0
3 1
1
46
2
2 1
3 0
1
47
2
2 1
3 1
2
52
2
2 2
3 0
2
53
2
2 2
3 1
3
58
2
2 3
3 0
3
59
2
2 3
3 1
4
64
2
2 4
3 0
4
65
2
2 4
3 1
5
70
2
2 5
3 0
5
71
2
2 5
3 1
12
0
76
2
1 0
4 0
0
77
2
1 0
4 1
1
82
2
1 1
4 0
1
83
2
1 1
4 1
2
88
2
1 2
4 0
2
89
2
1 2
4 1
3
94
2
1 3
4 0
3
95
2
1 3
4 1
4
100
2
1 4
4 0
4
101
2
1 4
4 1
5
106
2
1 5
4 0
5
107
2
1 5
4 1
12
0
112
2
0 0
5 0
0
113
2
0 0
5 1
1
118
2
0 1
5 0
1
119
2
0 1
5 1
2
124
2
0 2
5 0
2
125
2
0 2
5 1
3
130
2
0 3
5 0
3
131
2
0 3
5 1
4
136
2
0 4
5 0
4
137
2
0 4
5 1
5
142
2
0 5
5 0
5
143
2
0 5
5 1
end_DTG
begin_CG
4
6 24
7 24
8 24
5 72
4
6 24
7 24
8 24
4 72
4
6 24
7 24
8 24
3 72
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
end_CG
