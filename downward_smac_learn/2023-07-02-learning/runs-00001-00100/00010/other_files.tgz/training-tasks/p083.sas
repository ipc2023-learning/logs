begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var19
-1
15
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var18
-1
15
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var17
-1
15
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var16
-1
15
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var15
-1
15
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var14
-1
15
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var20
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
21
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
21
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
21
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
21
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
21
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
21
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l15)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
21
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l15)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




10 2
20
6162
2
0 13
11 1
20
6163
2
0 13
11 2
12
15
4090
2
5 14
6 1
15
4091
2
5 14
6 2
16
4510
2
4 14
7 1
16
4511
2
4 14
7 2
17
4930
2
3 14
8 1
17
4931
2
3 14
8 2
18
5350
2
2 14
9 1
18
5351
2
2 14
9 2
19
5770
2
1 14
10 1
19
5771
2
1 14
10 2
20
6190
2
0 14
11 1
20
6191
2
0 14
11 2
30
0
1179
2
5 0
6 1
0
1178
2
5 0
6 0
1
1206
2
5 1
6 0
1
1207
2
5 1
6 1
2
1234
2
5 2
6 0
2
1235
2
5 2
6 1
3
1262
2
5 3
6 0
3
1263
2
5 3
6 1
4
1290
2
5 4
6 0
4
1291
2
5 4
6 1
5
1318
2
5 5
6 0
5
1319
2
5 5
6 1
6
1346
2
5 6
6 0
6
1347
2
5 6
6 1
7
1375
2
5 7
6 1
7
1374
2
5 7
6 0
8
1402
2
5 8
6 0
8
1403
2
5 8
6 1
9
1430
2
5 9
6 0
9
1431
2
5 9
6 1
10
1458
2
5 10
6 0
10
1459
2
5 10
6 1
11
1486
2
5 11
6 0
11
1487
2
5 11
6 1
12
1514
2
5 12
6 0
12
1515
2
5 12
6 1
13
1542
2
5 13
6 0
13
1543
2
5 13
6 1
14
1570
2
5 14
6 0
14
1571
2
5 14
6 1
30
0
1599
2
4 0
7 1
0
1598
2
4 0
7 0
1
1626
2
4 1
7 0
1
1627
2
4 1
7 1
2
1654
2
4 2
7 0
2
1655
2
4 2
7 1
3
1682
2
4 3
7 0
3
1683
2
4 3
7 1
4
1710
2
4 4
7 0
4
1711
2
4 4
7 1
5
1738
2
4 5
7 0
5
1739
2
4 5
7 1
6
1766
2
4 6
7 0
6
1767
2
4 6
7 1
7
1795
2
4 7
7 1
7
1794
2
4 7
7 0
8
1822
2
4 8
7 0
8
1823
2
4 8
7 1
9
1850
2
4 9
7 0
9
1851
2
4 9
7 1
10
1878
2
4 10
7 0
10
1879
2
4 10
7 1
11
1906
2
4 11
7 0
11
1907
2
4 11
7 1
12
1934
2
4 12
7 0
12
1935
2
4 12
7 1
13
1962
2
4 13
7 0
13
1963
2
4 13
7 1
14
1990
2
4 14
7 0
14
1991
2
4 14
7 1
30
0
2019
2
3 0
8 1
0
2018
2
3 0
8 0
1
2046
2
3 1
8 0
1
2047
2
3 1
8 1
2
2074
2
3 2
8 0
2
2075
2
3 2
8 1
3
2102
2
3 3
8 0
3
2103
2
3 3
8 1
4
2130
2
3 4
8 0
4
2131
2
3 4
8 1
5
2158
2
3 5
8 0
5
2159
2
3 5
8 1
6
2186
2
3 6
8 0
6
2187
2
3 6
8 1
7
2215
2
3 7
8 1
7
2214
2
3 7
8 0
8
2242
2
3 8
8 0
8
2243
2
3 8
8 1
9
2270
2
3 9
8 0
9
2271
2
3 9
8 1
10
2298
2
3 10
8 0
10
2299
2
3 10
8 1
11
2326
2
3 11
8 0
11
2327
2
3 11
8 1
12
2354
2
3 12
8 0
12
2355
2
3 12
8 1
13
2382
2
3 13
8 0
13
2383
2
3 13
8 1
14
2410
2
3 14
8 0
14
2411
2
3 14
8 1
30
0
2439
2
2 0
9 1
0
2438
2
2 0
9 0
1
2466
2
2 1
9 0
1
2467
2
2 1
9 1
2
2494
2
2 2
9 0
2
2495
2
2 2
9 1
3
2522
2
2 3
9 0
3
2523
2
2 3
9 1
4
2550
2
2 4
9 0
4
2551
2
2 4
9 1
5
2578
2
2 5
9 0
5
2579
2
2 5
9 1
6
2606
2
2 6
9 0
6
2607
2
2 6
9 1
7
2635
2
2 7
9 1
7
2634
2
2 7
9 0
8
2662
2
2 8
9 0
8
2663
2
2 8
9 1
9
2690
2
2 9
9 0
9
2691
2
2 9
9 1
10
2718
2
2 10
9 0
10
2719
2
2 10
9 1
11
2746
2
2 11
9 0
11
2747
2
2 11
9 1
12
2774
2
2 12
9 0
12
2775
2
2 12
9 1
13
2802
2
2 13
9 0
13
2803
2
2 13
9 1
14
2830
2
2 14
9 0
14
2831
2
2 14
9 1
30
0
2859
2
1 0
10 1
0
2858
2
1 0
10 0
1
2886
2
1 1
10 0
1
2887
2
1 1
10 1
2
2914
2
1 2
10 0
2
2915
2
1 2
10 1
3
2942
2
1 3
10 0
3
2943
2
1 3
10 1
4
2970
2
1 4
10 0
4
2971
2
1 4
10 1
5
2998
2
1 5
10 0
5
2999
2
1 5
10 1
6
3026
2
1 6
10 0
6
3027
2
1 6
10 1
7
3055
2
1 7
10 1
7
3054
2
1 7
10 0
8
3082
2
1 8
10 0
8
3083
2
1 8
10 1
9
3110
2
1 9
10 0
9
3111
2
1 9
10 1
10
3138
2
1 10
10 0
10
3139
2
1 10
10 1
11
3166
2
1 11
10 0
11
3167
2
1 11
10 1
12
3194
2
1 12
10 0
12
3195
2
1 12
10 1
13
3222
2
1 13
10 0
13
3223
2
1 13
10 1
14
3250
2
1 14
10 0
14
3251
2
1 14
10 1
30
0
3279
2
0 0
11 1
0
3278
2
0 0
11 0
1
3306
2
0 1
11 0
1
3307
2
0 1
11 1
2
3334
2
0 2
11 0
2
3335
2
0 2
11 1
3
3362
2
0 3
11 0
3
3363
2
0 3
11 1
4
3390
2
0 4
11 0
4
3391
2
0 4
11 1
5
3418
2
0 5
11 0
5
3419
2
0 5
11 1
6
3446
2
0 6
11 0
6
3447
2
0 6
11 1
7
3475
2
0 7
11 1
7
3474
2
0 7
11 0
8
3502
2
0 8
11 0
8
3503
2
0 8
11 1
9
3530
2
0 9
11 0
9
3531
2
0 9
11 1
10
3558
2
0 10
11 0
10
3559
2
0 10
11 1
11
3586
2
0 11
11 0
11
3587
2
0 11
11 1
12
3614
2
0 12
11 0
12
3615
2
0 12
11 1
13
3642
2
0 13
11 0
13
3643
2
0 13
11 1
14
3670
2
0 14
11 0
14
3671
2
0 14
11 1
end_DTG
begin_CG
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
11 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
10 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
9 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
8 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
7 840
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
6 840
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
14
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
end_CG
