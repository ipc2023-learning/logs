begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var9
-1
9
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var8
-1
9
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var7
-1
9
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var6
-1
9
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var10
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
13
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
13
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
13
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
13
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
13
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
13
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
0
begin_state
0
8
8
2
2
2
1
1
3
1
4
7
8
3
end_state
begin_goal
6
8 6
9 8
10 3
11 3
12 7
13 6
end_goal
1064
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l4 l9
0
1
0 3 3 8
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l6 l9
0
1
0 3 5 8
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l8
0
1
0 3 6 7
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
en




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




4 2
10
760
2
2 1
5 1
10
761
2
2 1
5 2
11
868
2
1 1
6 1
11
869
2
1 1
6 2
12
976
2
0 1
7 1
12
977
2
0 1
7 2
8
9
664
2
3 2
4 1
9
665
2
3 2
4 2
10
772
2
2 2
5 1
10
773
2
2 2
5 2
11
880
2
1 2
6 1
11
881
2
1 2
6 2
12
988
2
0 2
7 1
12
989
2
0 2
7 2
8
9
676
2
3 3
4 1
9
677
2
3 3
4 2
10
784
2
2 3
5 1
10
785
2
2 3
5 2
11
892
2
1 3
6 1
11
893
2
1 3
6 2
12
1000
2
0 3
7 1
12
1001
2
0 3
7 2
8
9
688
2
3 4
4 1
9
689
2
3 4
4 2
10
796
2
2 4
5 1
10
797
2
2 4
5 2
11
904
2
1 4
6 1
11
905
2
1 4
6 2
12
1012
2
0 4
7 1
12
1013
2
0 4
7 2
8
9
700
2
3 5
4 1
9
701
2
3 5
4 2
10
808
2
2 5
5 1
10
809
2
2 5
5 2
11
916
2
1 5
6 1
11
917
2
1 5
6 2
12
1024
2
0 5
7 1
12
1025
2
0 5
7 2
8
9
712
2
3 6
4 1
9
713
2
3 6
4 2
10
820
2
2 6
5 1
10
821
2
2 6
5 2
11
928
2
1 6
6 1
11
929
2
1 6
6 2
12
1036
2
0 6
7 1
12
1037
2
0 6
7 2
8
9
724
2
3 7
4 1
9
725
2
3 7
4 2
10
832
2
2 7
5 1
10
833
2
2 7
5 2
11
940
2
1 7
6 1
11
941
2
1 7
6 2
12
1048
2
0 7
7 1
12
1049
2
0 7
7 2
8
9
736
2
3 8
4 1
9
737
2
3 8
4 2
10
844
2
2 8
5 1
10
845
2
2 8
5 2
11
952
2
1 8
6 1
11
953
2
1 8
6 2
12
1060
2
0 8
7 1
12
1061
2
0 8
7 2
18
0
209
2
3 0
4 1
0
208
2
3 0
4 0
1
220
2
3 1
4 0
1
221
2
3 1
4 1
2
232
2
3 2
4 0
2
233
2
3 2
4 1
3
244
2
3 3
4 0
3
245
2
3 3
4 1
4
257
2
3 4
4 1
4
256
2
3 4
4 0
5
268
2
3 5
4 0
5
269
2
3 5
4 1
6
280
2
3 6
4 0
6
281
2
3 6
4 1
7
292
2
3 7
4 0
7
293
2
3 7
4 1
8
304
2
3 8
4 0
8
305
2
3 8
4 1
18
0
317
2
2 0
5 1
0
316
2
2 0
5 0
1
328
2
2 1
5 0
1
329
2
2 1
5 1
2
340
2
2 2
5 0
2
341
2
2 2
5 1
3
352
2
2 3
5 0
3
353
2
2 3
5 1
4
365
2
2 4
5 1
4
364
2
2 4
5 0
5
376
2
2 5
5 0
5
377
2
2 5
5 1
6
388
2
2 6
5 0
6
389
2
2 6
5 1
7
400
2
2 7
5 0
7
401
2
2 7
5 1
8
412
2
2 8
5 0
8
413
2
2 8
5 1
18
0
425
2
1 0
6 1
0
424
2
1 0
6 0
1
436
2
1 1
6 0
1
437
2
1 1
6 1
2
448
2
1 2
6 0
2
449
2
1 2
6 1
3
460
2
1 3
6 0
3
461
2
1 3
6 1
4
473
2
1 4
6 1
4
472
2
1 4
6 0
5
484
2
1 5
6 0
5
485
2
1 5
6 1
6
496
2
1 6
6 0
6
497
2
1 6
6 1
7
508
2
1 7
6 0
7
509
2
1 7
6 1
8
520
2
1 8
6 0
8
521
2
1 8
6 1
18
0
533
2
0 0
7 1
0
532
2
0 0
7 0
1
544
2
0 1
7 0
1
545
2
0 1
7 1
2
556
2
0 2
7 0
2
557
2
0 2
7 1
3
568
2
0 3
7 0
3
569
2
0 3
7 1
4
581
2
0 4
7 1
4
580
2
0 4
7 0
5
592
2
0 5
7 0
5
593
2
0 5
7 1
6
604
2
0 6
7 0
6
605
2
0 6
7 1
7
616
2
0 7
7 0
7
617
2
0 7
7 1
8
628
2
0 8
7 0
8
629
2
0 8
7 1
end_DTG
begin_DTG
8
9
642
2
3 0
4 1
9
643
2
3 0
4 2
10
750
2
2 0
5 1
10
751
2
2 0
5 2
11
858
2
1 0
6 1
11
859
2
1 0
6 2
12
966
2
0 0
7 1
12
967
2
0 0
7 2
8
9
654
2
3 1
4 1
9
655
2
3 1
4 2
10
762
2
2 1
5 1
10
763
2
2 1
5 2
11
870
2
1 1
6 1
11
871
2
1 1
6 2
12
978
2
0 1
7 1
12
979
2
0 1
7 2
8
9
666
2
3 2
4 1
9
667
2
3 2
4 2
10
774
2
2 2
5 1
10
775
2
2 2
5 2
11
882
2
1 2
6 1
11
883
2
1 2
6 2
12
990
2
0 2
7 1
12
991
2
0 2
7 2
8
9
678
2
3 3
4 1
9
679
2
3 3
4 2
10
786
2
2 3
5 1
10
787
2
2 3
5 2
11
894
2
1 3
6 1
11
895
2
1 3
6 2
12
1002
2
0 3
7 1
12
1003
2
0 3
7 2
8
9
690
2
3 4
4 1
9
691
2
3 4
4 2
10
798
2
2 4
5 1
10
799
2
2 4
5 2
11
906
2
1 4
6 1
11
907
2
1 4
6 2
12
1014
2
0 4
7 1
12
1015
2
0 4
7 2
8
9
702
2
3 5
4 1
9
703
2
3 5
4 2
10
810
2
2 5
5 1
10
811
2
2 5
5 2
11
918
2
1 5
6 1
11
919
2
1 5
6 2
12
1026
2
0 5
7 1
12
1027
2
0 5
7 2
8
9
714
2
3 6
4 1
9
715
2
3 6
4 2
10
822
2
2 6
5 1
10
823
2
2 6
5 2
11
930
2
1 6
6 1
11
931
2
1 6
6 2
12
1038
2
0 6
7 1
12
1039
2
0 6
7 2
8
9
726
2
3 7
4 1
9
727
2
3 7
4 2
10
834
2
2 7
5 1
10
835
2
2 7
5 2
11
942
2
1 7
6 1
11
943
2
1 7
6 2
12
1050
2
0 7
7 1
12
1051
2
0 7
7 2
8
9
738
2
3 8
4 1
9
739
2
3 8
4 2
10
846
2
2 8
5 1
10
847
2
2 8
5 2
11
954
2
1 8
6 1
11
955
2
1 8
6 2
12
1062
2
0 8
7 1
12
1063
2
0 8
7 2
18
0
211
2
3 0
4 1
0
210
2
3 0
4 0
1
222
2
3 1
4 0
1
223
2
3 1
4 1
2
234
2
3 2
4 0
2
235
2
3 2
4 1
3
246
2
3 3
4 0
3
247
2
3 3
4 1
4
259
2
3 4
4 1
4
258
2
3 4
4 0
5
270
2
3 5
4 0
5
271
2
3 5
4 1
6
282
2
3 6
4 0
6
283
2
3 6
4 1
7
294
2
3 7
4 0
7
295
2
3 7
4 1
8
306
2
3 8
4 0
8
307
2
3 8
4 1
18
0
319
2
2 0
5 1
0
318
2
2 0
5 0
1
330
2
2 1
5 0
1
331
2
2 1
5 1
2
342
2
2 2
5 0
2
343
2
2 2
5 1
3
354
2
2 3
5 0
3
355
2
2 3
5 1
4
367
2
2 4
5 1
4
366
2
2 4
5 0
5
378
2
2 5
5 0
5
379
2
2 5
5 1
6
390
2
2 6
5 0
6
391
2
2 6
5 1
7
402
2
2 7
5 0
7
403
2
2 7
5 1
8
414
2
2 8
5 0
8
415
2
2 8
5 1
18
0
427
2
1 0
6 1
0
426
2
1 0
6 0
1
438
2
1 1
6 0
1
439
2
1 1
6 1
2
450
2
1 2
6 0
2
451
2
1 2
6 1
3
462
2
1 3
6 0
3
463
2
1 3
6 1
4
475
2
1 4
6 1
4
474
2
1 4
6 0
5
486
2
1 5
6 0
5
487
2
1 5
6 1
6
498
2
1 6
6 0
6
499
2
1 6
6 1
7
510
2
1 7
6 0
7
511
2
1 7
6 1
8
522
2
1 8
6 0
8
523
2
1 8
6 1
18
0
535
2
0 0
7 1
0
534
2
0 0
7 0
1
546
2
0 1
7 0
1
547
2
0 1
7 1
2
558
2
0 2
7 0
2
559
2
0 2
7 1
3
570
2
0 3
7 0
3
571
2
0 3
7 1
4
583
2
0 4
7 1
4
582
2
0 4
7 0
5
594
2
0 5
7 0
5
595
2
0 5
7 1
6
606
2
0 6
7 0
6
607
2
0 6
7 1
7
618
2
0 7
7 0
7
619
2
0 7
7 1
8
630
2
0 8
7 0
8
631
2
0 8
7 1
end_DTG
begin_CG
7
8 36
9 36
10 36
11 36
12 36
13 36
7 216
7
8 36
9 36
10 36
11 36
12 36
13 36
6 216
7
8 36
9 36
10 36
11 36
12 36
13 36
5 216
7
8 36
9 36
10 36
11 36
12 36
13 36
4 216
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
end_CG
