begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var22
-1
16
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var21
-1
16
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var20
-1
16
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var19
-1
16
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var18
-1
16
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var17
-1
16
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var16
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var23
-1
4
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
Atom capacity(v1, c3)
end_variable
begin_variable
var24
-1
4
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
Atom capacity(v2, c3)
end_variable
begin_variable
var25
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var26
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var27
-1
4
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
Atom capacity(v5, c3)
end_variable
begin_variable
var28
-1
4
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
Atom capacity(v6, c3)
end_variable
begin_variable
var29
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var0
-1
23
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var1
-1
23
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var2
-1
23
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var3
-1
23
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var4
-1
23
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l16)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
3 11
10 0
11
3228
2
3 11
10 1
11
3229
2
3 11
10 2
12
3276
2
3 12
10 1
12
3277
2
3 12
10 2
12
3275
2
3 12
10 0
13
3323
2
3 13
10 0
13
3324
2
3 13
10 1
13
3325
2
3 13
10 2
14
3371
2
3 14
10 0
14
3372
2
3 14
10 1
14
3373
2
3 14
10 2
15
3419
2
3 15
10 0
15
3420
2
3 15
10 1
15
3421
2
3 15
10 2
48
0
3468
2
2 0
11 1
0
3469
2
2 0
11 2
0
3467
2
2 0
11 0
1
3515
2
2 1
11 0
1
3516
2
2 1
11 1
1
3517
2
2 1
11 2
2
3563
2
2 2
11 0
2
3564
2
2 2
11 1
2
3565
2
2 2
11 2
3
3611
2
2 3
11 0
3
3612
2
2 3
11 1
3
3613
2
2 3
11 2
4
3660
2
2 4
11 1
4
3661
2
2 4
11 2
4
3659
2
2 4
11 0
5
3707
2
2 5
11 0
5
3708
2
2 5
11 1
5
3709
2
2 5
11 2
6
3755
2
2 6
11 0
6
3756
2
2 6
11 1
6
3757
2
2 6
11 2
7
3803
2
2 7
11 0
7
3804
2
2 7
11 1
7
3805
2
2 7
11 2
8
3851
2
2 8
11 0
8
3853
2
2 8
11 2
8
3852
2
2 8
11 1
9
3899
2
2 9
11 0
9
3900
2
2 9
11 1
9
3901
2
2 9
11 2
10
3947
2
2 10
11 0
10
3948
2
2 10
11 1
10
3949
2
2 10
11 2
11
3995
2
2 11
11 0
11
3996
2
2 11
11 1
11
3997
2
2 11
11 2
12
4044
2
2 12
11 1
12
4045
2
2 12
11 2
12
4043
2
2 12
11 0
13
4091
2
2 13
11 0
13
4092
2
2 13
11 1
13
4093
2
2 13
11 2
14
4139
2
2 14
11 0
14
4140
2
2 14
11 1
14
4141
2
2 14
11 2
15
4187
2
2 15
11 0
15
4188
2
2 15
11 1
15
4189
2
2 15
11 2
48
0
4236
2
1 0
12 1
0
4237
2
1 0
12 2
0
4235
2
1 0
12 0
1
4283
2
1 1
12 0
1
4284
2
1 1
12 1
1
4285
2
1 1
12 2
2
4331
2
1 2
12 0
2
4332
2
1 2
12 1
2
4333
2
1 2
12 2
3
4379
2
1 3
12 0
3
4380
2
1 3
12 1
3
4381
2
1 3
12 2
4
4428
2
1 4
12 1
4
4429
2
1 4
12 2
4
4427
2
1 4
12 0
5
4475
2
1 5
12 0
5
4476
2
1 5
12 1
5
4477
2
1 5
12 2
6
4523
2
1 6
12 0
6
4524
2
1 6
12 1
6
4525
2
1 6
12 2
7
4571
2
1 7
12 0
7
4572
2
1 7
12 1
7
4573
2
1 7
12 2
8
4619
2
1 8
12 0
8
4621
2
1 8
12 2
8
4620
2
1 8
12 1
9
4667
2
1 9
12 0
9
4668
2
1 9
12 1
9
4669
2
1 9
12 2
10
4715
2
1 10
12 0
10
4716
2
1 10
12 1
10
4717
2
1 10
12 2
11
4763
2
1 11
12 0
11
4764
2
1 11
12 1
11
4765
2
1 11
12 2
12
4812
2
1 12
12 1
12
4813
2
1 12
12 2
12
4811
2
1 12
12 0
13
4859
2
1 13
12 0
13
4860
2
1 13
12 1
13
4861
2
1 13
12 2
14
4907
2
1 14
12 0
14
4908
2
1 14
12 1
14
4909
2
1 14
12 2
15
4955
2
1 15
12 0
15
4956
2
1 15
12 1
15
4957
2
1 15
12 2
48
0
5004
2
0 0
13 1
0
5005
2
0 0
13 2
0
5003
2
0 0
13 0
1
5051
2
0 1
13 0
1
5052
2
0 1
13 1
1
5053
2
0 1
13 2
2
5099
2
0 2
13 0
2
5100
2
0 2
13 1
2
5101
2
0 2
13 2
3
5147
2
0 3
13 0
3
5148
2
0 3
13 1
3
5149
2
0 3
13 2
4
5196
2
0 4
13 1
4
5197
2
0 4
13 2
4
5195
2
0 4
13 0
5
5243
2
0 5
13 0
5
5244
2
0 5
13 1
5
5245
2
0 5
13 2
6
5291
2
0 6
13 0
6
5292
2
0 6
13 1
6
5293
2
0 6
13 2
7
5339
2
0 7
13 0
7
5340
2
0 7
13 1
7
5341
2
0 7
13 2
8
5387
2
0 8
13 0
8
5389
2
0 8
13 2
8
5388
2
0 8
13 1
9
5435
2
0 9
13 0
9
5436
2
0 9
13 1
9
5437
2
0 9
13 2
10
5483
2
0 10
13 0
10
5484
2
0 10
13 1
10
5485
2
0 10
13 2
11
5531
2
0 11
13 0
11
5532
2
0 11
13 1
11
5533
2
0 11
13 2
12
5580
2
0 12
13 1
12
5581
2
0 12
13 2
12
5579
2
0 12
13 0
13
5627
2
0 13
13 0
13
5628
2
0 13
13 1
13
5629
2
0 13
13 2
14
5675
2
0 14
13 0
14
5676
2
0 14
13 1
14
5677
2
0 14
13 2
15
5723
2
0 15
13 0
15
5724
2
0 15
13 1
15
5725
2
0 15
13 2
end_DTG
begin_CG
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
13 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
12 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
11 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
10 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
9 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
8 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
7 1536
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
end_CG
