begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var18
-1
13
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var17
-1
13
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var16
-1
13
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var15
-1
13
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var14
-1
13
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var13
-1
13
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var19
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
19
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
19
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
19
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
19
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
19
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
19
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var6
-1
19
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var7
-1
19
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
Atom in(p4, v6)
end_variable
begin_variable
var8
-1
19
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





7 2
15
3838
2
3 9
8 1
15
3839
2
3 9
8 2
16
4176
2
2 9
9 1
16
4177
2
2 9
9 2
17
4514
2
1 9
10 1
17
4515
2
1 9
10 2
18
4852
2
0 9
11 1
18
4853
2
0 9
11 2
12
13
3188
2
5 10
6 1
13
3189
2
5 10
6 2
14
3526
2
4 10
7 1
14
3527
2
4 10
7 2
15
3864
2
3 10
8 1
15
3865
2
3 10
8 2
16
4202
2
2 10
9 1
16
4203
2
2 10
9 2
17
4540
2
1 10
10 1
17
4541
2
1 10
10 2
18
4878
2
0 10
11 1
18
4879
2
0 10
11 2
12
13
3214
2
5 11
6 1
13
3215
2
5 11
6 2
14
3552
2
4 11
7 1
14
3553
2
4 11
7 2
15
3890
2
3 11
8 1
15
3891
2
3 11
8 2
16
4228
2
2 11
9 1
16
4229
2
2 11
9 2
17
4566
2
1 11
10 1
17
4567
2
1 11
10 2
18
4904
2
0 11
11 1
18
4905
2
0 11
11 2
12
13
3240
2
5 12
6 1
13
3241
2
5 12
6 2
14
3578
2
4 12
7 1
14
3579
2
4 12
7 2
15
3916
2
3 12
8 1
15
3917
2
3 12
8 2
16
4254
2
2 12
9 1
16
4255
2
2 12
9 2
17
4592
2
1 12
10 1
17
4593
2
1 12
10 2
18
4930
2
0 12
11 1
18
4931
2
0 12
11 2
26
0
901
2
5 0
6 1
0
900
2
5 0
6 0
1
926
2
5 1
6 0
1
927
2
5 1
6 1
2
952
2
5 2
6 0
2
953
2
5 2
6 1
3
978
2
5 3
6 0
3
979
2
5 3
6 1
4
1004
2
5 4
6 0
4
1005
2
5 4
6 1
5
1030
2
5 5
6 0
5
1031
2
5 5
6 1
6
1057
2
5 6
6 1
6
1056
2
5 6
6 0
7
1082
2
5 7
6 0
7
1083
2
5 7
6 1
8
1108
2
5 8
6 0
8
1109
2
5 8
6 1
9
1134
2
5 9
6 0
9
1135
2
5 9
6 1
10
1160
2
5 10
6 0
10
1161
2
5 10
6 1
11
1186
2
5 11
6 0
11
1187
2
5 11
6 1
12
1212
2
5 12
6 0
12
1213
2
5 12
6 1
26
0
1239
2
4 0
7 1
0
1238
2
4 0
7 0
1
1264
2
4 1
7 0
1
1265
2
4 1
7 1
2
1290
2
4 2
7 0
2
1291
2
4 2
7 1
3
1316
2
4 3
7 0
3
1317
2
4 3
7 1
4
1342
2
4 4
7 0
4
1343
2
4 4
7 1
5
1368
2
4 5
7 0
5
1369
2
4 5
7 1
6
1395
2
4 6
7 1
6
1394
2
4 6
7 0
7
1420
2
4 7
7 0
7
1421
2
4 7
7 1
8
1446
2
4 8
7 0
8
1447
2
4 8
7 1
9
1472
2
4 9
7 0
9
1473
2
4 9
7 1
10
1498
2
4 10
7 0
10
1499
2
4 10
7 1
11
1524
2
4 11
7 0
11
1525
2
4 11
7 1
12
1550
2
4 12
7 0
12
1551
2
4 12
7 1
26
0
1577
2
3 0
8 1
0
1576
2
3 0
8 0
1
1602
2
3 1
8 0
1
1603
2
3 1
8 1
2
1628
2
3 2
8 0
2
1629
2
3 2
8 1
3
1654
2
3 3
8 0
3
1655
2
3 3
8 1
4
1680
2
3 4
8 0
4
1681
2
3 4
8 1
5
1706
2
3 5
8 0
5
1707
2
3 5
8 1
6
1733
2
3 6
8 1
6
1732
2
3 6
8 0
7
1758
2
3 7
8 0
7
1759
2
3 7
8 1
8
1784
2
3 8
8 0
8
1785
2
3 8
8 1
9
1810
2
3 9
8 0
9
1811
2
3 9
8 1
10
1836
2
3 10
8 0
10
1837
2
3 10
8 1
11
1862
2
3 11
8 0
11
1863
2
3 11
8 1
12
1888
2
3 12
8 0
12
1889
2
3 12
8 1
26
0
1915
2
2 0
9 1
0
1914
2
2 0
9 0
1
1940
2
2 1
9 0
1
1941
2
2 1
9 1
2
1966
2
2 2
9 0
2
1967
2
2 2
9 1
3
1992
2
2 3
9 0
3
1993
2
2 3
9 1
4
2018
2
2 4
9 0
4
2019
2
2 4
9 1
5
2044
2
2 5
9 0
5
2045
2
2 5
9 1
6
2071
2
2 6
9 1
6
2070
2
2 6
9 0
7
2096
2
2 7
9 0
7
2097
2
2 7
9 1
8
2122
2
2 8
9 0
8
2123
2
2 8
9 1
9
2148
2
2 9
9 0
9
2149
2
2 9
9 1
10
2174
2
2 10
9 0
10
2175
2
2 10
9 1
11
2200
2
2 11
9 0
11
2201
2
2 11
9 1
12
2226
2
2 12
9 0
12
2227
2
2 12
9 1
26
0
2253
2
1 0
10 1
0
2252
2
1 0
10 0
1
2278
2
1 1
10 0
1
2279
2
1 1
10 1
2
2304
2
1 2
10 0
2
2305
2
1 2
10 1
3
2330
2
1 3
10 0
3
2331
2
1 3
10 1
4
2356
2
1 4
10 0
4
2357
2
1 4
10 1
5
2382
2
1 5
10 0
5
2383
2
1 5
10 1
6
2409
2
1 6
10 1
6
2408
2
1 6
10 0
7
2434
2
1 7
10 0
7
2435
2
1 7
10 1
8
2460
2
1 8
10 0
8
2461
2
1 8
10 1
9
2486
2
1 9
10 0
9
2487
2
1 9
10 1
10
2512
2
1 10
10 0
10
2513
2
1 10
10 1
11
2538
2
1 11
10 0
11
2539
2
1 11
10 1
12
2564
2
1 12
10 0
12
2565
2
1 12
10 1
26
0
2591
2
0 0
11 1
0
2590
2
0 0
11 0
1
2616
2
0 1
11 0
1
2617
2
0 1
11 1
2
2642
2
0 2
11 0
2
2643
2
0 2
11 1
3
2668
2
0 3
11 0
3
2669
2
0 3
11 1
4
2694
2
0 4
11 0
4
2695
2
0 4
11 1
5
2720
2
0 5
11 0
5
2721
2
0 5
11 1
6
2747
2
0 6
11 1
6
2746
2
0 6
11 0
7
2772
2
0 7
11 0
7
2773
2
0 7
11 1
8
2798
2
0 8
11 0
8
2799
2
0 8
11 1
9
2824
2
0 9
11 0
9
2825
2
0 9
11 1
10
2850
2
0 10
11 0
10
2851
2
0 10
11 1
11
2876
2
0 11
11 0
11
2877
2
0 11
11 1
12
2902
2
0 12
11 0
12
2903
2
0 12
11 1
end_DTG
begin_CG
14
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
11 676
14
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
10 676
14
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
9 676
14
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
8 676
14
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
7 676
14
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
6 676
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
24 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
end_CG
