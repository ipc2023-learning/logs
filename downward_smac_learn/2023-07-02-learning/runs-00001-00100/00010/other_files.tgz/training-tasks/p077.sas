begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var18
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var13
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var19
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l14)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
15
3230
2
4 11
7 1
15
3231
2
4 11
7 2
16
3594
2
3 11
8 1
16
3595
2
3 11
8 2
17
3958
2
2 11
9 1
17
3959
2
2 11
9 2
18
4322
2
1 11
10 1
18
4323
2
1 11
10 2
19
4686
2
0 11
11 1
19
4687
2
0 11
11 2
12
14
2892
2
5 12
6 1
14
2893
2
5 12
6 2
15
3256
2
4 12
7 1
15
3257
2
4 12
7 2
16
3620
2
3 12
8 1
16
3621
2
3 12
8 2
17
3984
2
2 12
9 1
17
3985
2
2 12
9 2
18
4348
2
1 12
10 1
18
4349
2
1 12
10 2
19
4712
2
0 12
11 1
19
4713
2
0 12
11 2
12
14
2918
2
5 13
6 1
14
2919
2
5 13
6 2
15
3282
2
4 13
7 1
15
3283
2
4 13
7 2
16
3646
2
3 13
8 1
16
3647
2
3 13
8 2
17
4010
2
2 13
9 1
17
4011
2
2 13
9 2
18
4374
2
1 13
10 1
18
4375
2
1 13
10 2
19
4738
2
0 13
11 1
19
4739
2
0 13
11 2
28
0
397
2
5 0
6 1
0
396
2
5 0
6 0
1
422
2
5 1
6 0
1
423
2
5 1
6 1
2
448
2
5 2
6 0
2
449
2
5 2
6 1
3
474
2
5 3
6 0
3
475
2
5 3
6 1
4
500
2
5 4
6 0
4
501
2
5 4
6 1
5
526
2
5 5
6 0
5
527
2
5 5
6 1
6
552
2
5 6
6 0
6
553
2
5 6
6 1
7
578
2
5 7
6 0
7
579
2
5 7
6 1
8
604
2
5 8
6 0
8
605
2
5 8
6 1
9
630
2
5 9
6 0
9
631
2
5 9
6 1
10
656
2
5 10
6 0
10
657
2
5 10
6 1
11
682
2
5 11
6 0
11
683
2
5 11
6 1
12
708
2
5 12
6 0
12
709
2
5 12
6 1
13
734
2
5 13
6 0
13
735
2
5 13
6 1
28
0
761
2
4 0
7 1
0
760
2
4 0
7 0
1
786
2
4 1
7 0
1
787
2
4 1
7 1
2
812
2
4 2
7 0
2
813
2
4 2
7 1
3
838
2
4 3
7 0
3
839
2
4 3
7 1
4
864
2
4 4
7 0
4
865
2
4 4
7 1
5
890
2
4 5
7 0
5
891
2
4 5
7 1
6
916
2
4 6
7 0
6
917
2
4 6
7 1
7
942
2
4 7
7 0
7
943
2
4 7
7 1
8
968
2
4 8
7 0
8
969
2
4 8
7 1
9
994
2
4 9
7 0
9
995
2
4 9
7 1
10
1020
2
4 10
7 0
10
1021
2
4 10
7 1
11
1046
2
4 11
7 0
11
1047
2
4 11
7 1
12
1072
2
4 12
7 0
12
1073
2
4 12
7 1
13
1098
2
4 13
7 0
13
1099
2
4 13
7 1
28
0
1125
2
3 0
8 1
0
1124
2
3 0
8 0
1
1150
2
3 1
8 0
1
1151
2
3 1
8 1
2
1176
2
3 2
8 0
2
1177
2
3 2
8 1
3
1202
2
3 3
8 0
3
1203
2
3 3
8 1
4
1228
2
3 4
8 0
4
1229
2
3 4
8 1
5
1254
2
3 5
8 0
5
1255
2
3 5
8 1
6
1280
2
3 6
8 0
6
1281
2
3 6
8 1
7
1306
2
3 7
8 0
7
1307
2
3 7
8 1
8
1332
2
3 8
8 0
8
1333
2
3 8
8 1
9
1358
2
3 9
8 0
9
1359
2
3 9
8 1
10
1384
2
3 10
8 0
10
1385
2
3 10
8 1
11
1410
2
3 11
8 0
11
1411
2
3 11
8 1
12
1436
2
3 12
8 0
12
1437
2
3 12
8 1
13
1462
2
3 13
8 0
13
1463
2
3 13
8 1
28
0
1489
2
2 0
9 1
0
1488
2
2 0
9 0
1
1514
2
2 1
9 0
1
1515
2
2 1
9 1
2
1540
2
2 2
9 0
2
1541
2
2 2
9 1
3
1566
2
2 3
9 0
3
1567
2
2 3
9 1
4
1592
2
2 4
9 0
4
1593
2
2 4
9 1
5
1618
2
2 5
9 0
5
1619
2
2 5
9 1
6
1644
2
2 6
9 0
6
1645
2
2 6
9 1
7
1670
2
2 7
9 0
7
1671
2
2 7
9 1
8
1696
2
2 8
9 0
8
1697
2
2 8
9 1
9
1722
2
2 9
9 0
9
1723
2
2 9
9 1
10
1748
2
2 10
9 0
10
1749
2
2 10
9 1
11
1774
2
2 11
9 0
11
1775
2
2 11
9 1
12
1800
2
2 12
9 0
12
1801
2
2 12
9 1
13
1826
2
2 13
9 0
13
1827
2
2 13
9 1
28
0
1853
2
1 0
10 1
0
1852
2
1 0
10 0
1
1878
2
1 1
10 0
1
1879
2
1 1
10 1
2
1904
2
1 2
10 0
2
1905
2
1 2
10 1
3
1930
2
1 3
10 0
3
1931
2
1 3
10 1
4
1956
2
1 4
10 0
4
1957
2
1 4
10 1
5
1982
2
1 5
10 0
5
1983
2
1 5
10 1
6
2008
2
1 6
10 0
6
2009
2
1 6
10 1
7
2034
2
1 7
10 0
7
2035
2
1 7
10 1
8
2060
2
1 8
10 0
8
2061
2
1 8
10 1
9
2086
2
1 9
10 0
9
2087
2
1 9
10 1
10
2112
2
1 10
10 0
10
2113
2
1 10
10 1
11
2138
2
1 11
10 0
11
2139
2
1 11
10 1
12
2164
2
1 12
10 0
12
2165
2
1 12
10 1
13
2190
2
1 13
10 0
13
2191
2
1 13
10 1
28
0
2217
2
0 0
11 1
0
2216
2
0 0
11 0
1
2242
2
0 1
11 0
1
2243
2
0 1
11 1
2
2268
2
0 2
11 0
2
2269
2
0 2
11 1
3
2294
2
0 3
11 0
3
2295
2
0 3
11 1
4
2320
2
0 4
11 0
4
2321
2
0 4
11 1
5
2346
2
0 5
11 0
5
2347
2
0 5
11 1
6
2372
2
0 6
11 0
6
2373
2
0 6
11 1
7
2398
2
0 7
11 0
7
2399
2
0 7
11 1
8
2424
2
0 8
11 0
8
2425
2
0 8
11 1
9
2450
2
0 9
11 0
9
2451
2
0 9
11 1
10
2476
2
0 10
11 0
10
2477
2
0 10
11 1
11
2502
2
0 11
11 0
11
2503
2
0 11
11 1
12
2528
2
0 12
11 0
12
2529
2
0 12
11 1
13
2554
2
0 13
11 0
13
2555
2
0 13
11 1
end_DTG
begin_CG
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
11 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
10 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
9 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
8 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
7 728
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6 728
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
13
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
