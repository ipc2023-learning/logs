begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var8
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var5
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var9
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var10
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
0
begin_state
6
3
6
6
1
2
2
2
2
5
1
2
3
end_state
begin_goal
5
8 1
9 3
10 2
11 1
12 4
end_goal
760
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l8
0
1
0 3 6 7
0
end_operator
begin_operator
drive v1 l8 l3
0
1
0 3 7 2
0
end_operator
begin_operator
drive v1 l8 l4
0
1
0 3 7 3
0
end_operator
begin_operator
drive v1 l8 l6
0
1
0 3 7 5
0
end_operator
begin_operator
drive v1 l8 l7
0
1
0 3 7 6
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v2 l1 l7
0
1
0 2 0 6
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v2 l3 l5
0
1
0 2 2 4
0
end_operator
begin_operator
drive v2 l3 l7
0
1
0 2 2 6
0
end_operator
begin_operator
drive v2 l3 l8
0
1
0 2 2 7
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v2 l4 l8
0
1
0 2 3 7
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v2 l5 l3
0
1
0 2 4 2
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v2 l5 l7
0
1
0 2 4 6
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
1
295
2
1 1
6 1
2
304
2
1 2
6 0
2
305
2
1 2
6 1
3
314
2
1 3
6 0
3
315
2
1 3
6 1
4
324
2
1 4
6 0
4
325
2
1 4
6 1
5
334
2
1 5
6 0
5
335
2
1 5
6 1
6
344
2
1 6
6 0
6
345
2
1 6
6 1
7
354
2
1 7
6 0
7
355
2
1 7
6 1
16
0
364
2
0 0
7 0
0
365
2
0 0
7 1
1
374
2
0 1
7 0
1
375
2
0 1
7 1
2
384
2
0 2
7 0
2
385
2
0 2
7 1
3
394
2
0 3
7 0
3
395
2
0 3
7 1
4
404
2
0 4
7 0
4
405
2
0 4
7 1
5
414
2
0 5
7 0
5
415
2
0 5
7 1
6
424
2
0 6
7 0
6
425
2
0 6
7 1
7
434
2
0 7
7 0
7
435
2
0 7
7 1
end_DTG
begin_DTG
8
8
446
2
3 0
4 1
8
447
2
3 0
4 2
9
526
2
2 0
5 1
9
527
2
2 0
5 2
10
606
2
1 0
6 1
10
607
2
1 0
6 2
11
686
2
0 0
7 1
11
687
2
0 0
7 2
8
8
456
2
3 1
4 1
8
457
2
3 1
4 2
9
536
2
2 1
5 1
9
537
2
2 1
5 2
10
616
2
1 1
6 1
10
617
2
1 1
6 2
11
696
2
0 1
7 1
11
697
2
0 1
7 2
8
8
466
2
3 2
4 1
8
467
2
3 2
4 2
9
546
2
2 2
5 1
9
547
2
2 2
5 2
10
626
2
1 2
6 1
10
627
2
1 2
6 2
11
706
2
0 2
7 1
11
707
2
0 2
7 2
8
8
476
2
3 3
4 1
8
477
2
3 3
4 2
9
556
2
2 3
5 1
9
557
2
2 3
5 2
10
636
2
1 3
6 1
10
637
2
1 3
6 2
11
716
2
0 3
7 1
11
717
2
0 3
7 2
8
8
486
2
3 4
4 1
8
487
2
3 4
4 2
9
566
2
2 4
5 1
9
567
2
2 4
5 2
10
646
2
1 4
6 1
10
647
2
1 4
6 2
11
726
2
0 4
7 1
11
727
2
0 4
7 2
8
8
496
2
3 5
4 1
8
497
2
3 5
4 2
9
576
2
2 5
5 1
9
577
2
2 5
5 2
10
656
2
1 5
6 1
10
657
2
1 5
6 2
11
736
2
0 5
7 1
11
737
2
0 5
7 2
8
8
506
2
3 6
4 1
8
507
2
3 6
4 2
9
586
2
2 6
5 1
9
587
2
2 6
5 2
10
666
2
1 6
6 1
10
667
2
1 6
6 2
11
746
2
0 6
7 1
11
747
2
0 6
7 2
8
8
516
2
3 7
4 1
8
517
2
3 7
4 2
9
596
2
2 7
5 1
9
597
2
2 7
5 2
10
676
2
1 7
6 1
10
677
2
1 7
6 2
11
756
2
0 7
7 1
11
757
2
0 7
7 2
16
0
126
2
3 0
4 0
0
127
2
3 0
4 1
1
136
2
3 1
4 0
1
137
2
3 1
4 1
2
146
2
3 2
4 0
2
147
2
3 2
4 1
3
156
2
3 3
4 0
3
157
2
3 3
4 1
4
166
2
3 4
4 0
4
167
2
3 4
4 1
5
176
2
3 5
4 0
5
177
2
3 5
4 1
6
186
2
3 6
4 0
6
187
2
3 6
4 1
7
196
2
3 7
4 0
7
197
2
3 7
4 1
16
0
206
2
2 0
5 0
0
207
2
2 0
5 1
1
216
2
2 1
5 0
1
217
2
2 1
5 1
2
226
2
2 2
5 0
2
227
2
2 2
5 1
3
236
2
2 3
5 0
3
237
2
2 3
5 1
4
246
2
2 4
5 0
4
247
2
2 4
5 1
5
256
2
2 5
5 0
5
257
2
2 5
5 1
6
266
2
2 6
5 0
6
267
2
2 6
5 1
7
276
2
2 7
5 0
7
277
2
2 7
5 1
16
0
286
2
1 0
6 0
0
287
2
1 0
6 1
1
296
2
1 1
6 0
1
297
2
1 1
6 1
2
306
2
1 2
6 0
2
307
2
1 2
6 1
3
316
2
1 3
6 0
3
317
2
1 3
6 1
4
326
2
1 4
6 0
4
327
2
1 4
6 1
5
336
2
1 5
6 0
5
337
2
1 5
6 1
6
346
2
1 6
6 0
6
347
2
1 6
6 1
7
356
2
1 7
6 0
7
357
2
1 7
6 1
16
0
366
2
0 0
7 0
0
367
2
0 0
7 1
1
376
2
0 1
7 0
1
377
2
0 1
7 1
2
386
2
0 2
7 0
2
387
2
0 2
7 1
3
396
2
0 3
7 0
3
397
2
0 3
7 1
4
406
2
0 4
7 0
4
407
2
0 4
7 1
5
416
2
0 5
7 0
5
417
2
0 5
7 1
6
426
2
0 6
7 0
6
427
2
0 6
7 1
7
436
2
0 7
7 0
7
437
2
0 7
7 1
end_DTG
begin_DTG
8
8
448
2
3 0
4 1
8
449
2
3 0
4 2
9
528
2
2 0
5 1
9
529
2
2 0
5 2
10
608
2
1 0
6 1
10
609
2
1 0
6 2
11
688
2
0 0
7 1
11
689
2
0 0
7 2
8
8
458
2
3 1
4 1
8
459
2
3 1
4 2
9
538
2
2 1
5 1
9
539
2
2 1
5 2
10
618
2
1 1
6 1
10
619
2
1 1
6 2
11
698
2
0 1
7 1
11
699
2
0 1
7 2
8
8
468
2
3 2
4 1
8
469
2
3 2
4 2
9
548
2
2 2
5 1
9
549
2
2 2
5 2
10
628
2
1 2
6 1
10
629
2
1 2
6 2
11
708
2
0 2
7 1
11
709
2
0 2
7 2
8
8
478
2
3 3
4 1
8
479
2
3 3
4 2
9
558
2
2 3
5 1
9
559
2
2 3
5 2
10
638
2
1 3
6 1
10
639
2
1 3
6 2
11
718
2
0 3
7 1
11
719
2
0 3
7 2
8
8
488
2
3 4
4 1
8
489
2
3 4
4 2
9
568
2
2 4
5 1
9
569
2
2 4
5 2
10
648
2
1 4
6 1
10
649
2
1 4
6 2
11
728
2
0 4
7 1
11
729
2
0 4
7 2
8
8
498
2
3 5
4 1
8
499
2
3 5
4 2
9
578
2
2 5
5 1
9
579
2
2 5
5 2
10
658
2
1 5
6 1
10
659
2
1 5
6 2
11
738
2
0 5
7 1
11
739
2
0 5
7 2
8
8
508
2
3 6
4 1
8
509
2
3 6
4 2
9
588
2
2 6
5 1
9
589
2
2 6
5 2
10
668
2
1 6
6 1
10
669
2
1 6
6 2
11
748
2
0 6
7 1
11
749
2
0 6
7 2
8
8
518
2
3 7
4 1
8
519
2
3 7
4 2
9
598
2
2 7
5 1
9
599
2
2 7
5 2
10
678
2
1 7
6 1
10
679
2
1 7
6 2
11
758
2
0 7
7 1
11
759
2
0 7
7 2
16
0
128
2
3 0
4 0
0
129
2
3 0
4 1
1
138
2
3 1
4 0
1
139
2
3 1
4 1
2
148
2
3 2
4 0
2
149
2
3 2
4 1
3
158
2
3 3
4 0
3
159
2
3 3
4 1
4
168
2
3 4
4 0
4
169
2
3 4
4 1
5
178
2
3 5
4 0
5
179
2
3 5
4 1
6
188
2
3 6
4 0
6
189
2
3 6
4 1
7
198
2
3 7
4 0
7
199
2
3 7
4 1
16
0
208
2
2 0
5 0
0
209
2
2 0
5 1
1
218
2
2 1
5 0
1
219
2
2 1
5 1
2
228
2
2 2
5 0
2
229
2
2 2
5 1
3
238
2
2 3
5 0
3
239
2
2 3
5 1
4
248
2
2 4
5 0
4
249
2
2 4
5 1
5
258
2
2 5
5 0
5
259
2
2 5
5 1
6
268
2
2 6
5 0
6
269
2
2 6
5 1
7
278
2
2 7
5 0
7
279
2
2 7
5 1
16
0
288
2
1 0
6 0
0
289
2
1 0
6 1
1
298
2
1 1
6 0
1
299
2
1 1
6 1
2
308
2
1 2
6 0
2
309
2
1 2
6 1
3
318
2
1 3
6 0
3
319
2
1 3
6 1
4
328
2
1 4
6 0
4
329
2
1 4
6 1
5
338
2
1 5
6 0
5
339
2
1 5
6 1
6
348
2
1 6
6 0
6
349
2
1 6
6 1
7
358
2
1 7
6 0
7
359
2
1 7
6 1
16
0
368
2
0 0
7 0
0
369
2
0 0
7 1
1
378
2
0 1
7 0
1
379
2
0 1
7 1
2
388
2
0 2
7 0
2
389
2
0 2
7 1
3
398
2
0 3
7 0
3
399
2
0 3
7 1
4
408
2
0 4
7 0
4
409
2
0 4
7 1
5
418
2
0 5
7 0
5
419
2
0 5
7 1
6
428
2
0 6
7 0
6
429
2
0 6
7 1
7
438
2
0 7
7 0
7
439
2
0 7
7 1
end_DTG
begin_CG
6
8 32
9 32
10 32
11 32
12 32
7 160
6
8 32
9 32
10 32
11 32
12 32
6 160
6
8 32
9 32
10 32
11 32
12 32
5 160
6
8 32
9 32
10 32
11 32
12 32
4 160
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
5
8 32
9 32
10 32
11 32
12 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
