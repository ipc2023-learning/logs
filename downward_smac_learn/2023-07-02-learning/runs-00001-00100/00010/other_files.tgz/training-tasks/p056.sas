begin_version
3
end_version
begin_metric
0
end_metric
20
begin_variable
var14
-1
11
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var13
-1
11
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var12
-1
11
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var11
-1
11
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var10
-1
11
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var15
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
16
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
16
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
16
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var3
-1
16
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var4
-1
16
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var5
-1
16
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var6
-1
16
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var7
-1
16
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var8
-1
16
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var9
-1
16
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
6
5
7
3
2
1
2
2
1
1
10
9
0
0
6
7
0
3
2
9
end_state
begin_goal
10
10 3
11 4
12 1
13 7
14 1
15 6
16 7
17 0
18 5
19 5
end_goal
2450
begin_operator
drive v1 l1 l10
0
1
0 4 0 1
0
end_operator
begin_operator
drive v1 l1 l11
0
1
0 4 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 4 0 5
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 4 0 6
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l1 l9
0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





2
1187
2
0 2
9 1
3
1206
2
0 3
9 0
3
1207
2
0 3
9 1
4
1226
2
0 4
9 0
4
1227
2
0 4
9 1
5
1247
2
0 5
9 1
5
1246
2
0 5
9 0
6
1266
2
0 6
9 0
6
1267
2
0 6
9 1
7
1286
2
0 7
9 0
7
1287
2
0 7
9 1
8
1306
2
0 8
9 0
8
1307
2
0 8
9 1
9
1326
2
0 9
9 0
9
1327
2
0 9
9 1
10
1346
2
0 10
9 0
10
1347
2
0 10
9 1
end_DTG
begin_DTG
10
11
1368
2
4 0
5 1
11
1369
2
4 0
5 2
12
1588
2
3 0
6 1
12
1589
2
3 0
6 2
13
1808
2
2 0
7 1
13
1809
2
2 0
7 2
14
2028
2
1 0
8 1
14
2029
2
1 0
8 2
15
2248
2
0 0
9 1
15
2249
2
0 0
9 2
10
11
1388
2
4 1
5 1
11
1389
2
4 1
5 2
12
1608
2
3 1
6 1
12
1609
2
3 1
6 2
13
1828
2
2 1
7 1
13
1829
2
2 1
7 2
14
2048
2
1 1
8 1
14
2049
2
1 1
8 2
15
2268
2
0 1
9 1
15
2269
2
0 1
9 2
10
11
1408
2
4 2
5 1
11
1409
2
4 2
5 2
12
1628
2
3 2
6 1
12
1629
2
3 2
6 2
13
1848
2
2 2
7 1
13
1849
2
2 2
7 2
14
2068
2
1 2
8 1
14
2069
2
1 2
8 2
15
2288
2
0 2
9 1
15
2289
2
0 2
9 2
10
11
1428
2
4 3
5 1
11
1429
2
4 3
5 2
12
1648
2
3 3
6 1
12
1649
2
3 3
6 2
13
1868
2
2 3
7 1
13
1869
2
2 3
7 2
14
2088
2
1 3
8 1
14
2089
2
1 3
8 2
15
2308
2
0 3
9 1
15
2309
2
0 3
9 2
10
11
1448
2
4 4
5 1
11
1449
2
4 4
5 2
12
1668
2
3 4
6 1
12
1669
2
3 4
6 2
13
1888
2
2 4
7 1
13
1889
2
2 4
7 2
14
2108
2
1 4
8 1
14
2109
2
1 4
8 2
15
2328
2
0 4
9 1
15
2329
2
0 4
9 2
10
11
1468
2
4 5
5 1
11
1469
2
4 5
5 2
12
1688
2
3 5
6 1
12
1689
2
3 5
6 2
13
1908
2
2 5
7 1
13
1909
2
2 5
7 2
14
2128
2
1 5
8 1
14
2129
2
1 5
8 2
15
2348
2
0 5
9 1
15
2349
2
0 5
9 2
10
11
1488
2
4 6
5 1
11
1489
2
4 6
5 2
12
1708
2
3 6
6 1
12
1709
2
3 6
6 2
13
1928
2
2 6
7 1
13
1929
2
2 6
7 2
14
2148
2
1 6
8 1
14
2149
2
1 6
8 2
15
2368
2
0 6
9 1
15
2369
2
0 6
9 2
10
11
1508
2
4 7
5 1
11
1509
2
4 7
5 2
12
1728
2
3 7
6 1
12
1729
2
3 7
6 2
13
1948
2
2 7
7 1
13
1949
2
2 7
7 2
14
2168
2
1 7
8 1
14
2169
2
1 7
8 2
15
2388
2
0 7
9 1
15
2389
2
0 7
9 2
10
11
1528
2
4 8
5 1
11
1529
2
4 8
5 2
12
1748
2
3 8
6 1
12
1749
2
3 8
6 2
13
1968
2
2 8
7 1
13
1969
2
2 8
7 2
14
2188
2
1 8
8 1
14
2189
2
1 8
8 2
15
2408
2
0 8
9 1
15
2409
2
0 8
9 2
10
11
1548
2
4 9
5 1
11
1549
2
4 9
5 2
12
1768
2
3 9
6 1
12
1769
2
3 9
6 2
13
1988
2
2 9
7 1
13
1989
2
2 9
7 2
14
2208
2
1 9
8 1
14
2209
2
1 9
8 2
15
2428
2
0 9
9 1
15
2429
2
0 9
9 2
10
11
1568
2
4 10
5 1
11
1569
2
4 10
5 2
12
1788
2
3 10
6 1
12
1789
2
3 10
6 2
13
2008
2
2 10
7 1
13
2009
2
2 10
7 2
14
2228
2
1 10
8 1
14
2229
2
1 10
8 2
15
2448
2
0 10
9 1
15
2449
2
0 10
9 2
22
0
269
2
4 0
5 1
0
268
2
4 0
5 0
1
288
2
4 1
5 0
1
289
2
4 1
5 1
2
308
2
4 2
5 0
2
309
2
4 2
5 1
3
328
2
4 3
5 0
3
329
2
4 3
5 1
4
348
2
4 4
5 0
4
349
2
4 4
5 1
5
369
2
4 5
5 1
5
368
2
4 5
5 0
6
388
2
4 6
5 0
6
389
2
4 6
5 1
7
408
2
4 7
5 0
7
409
2
4 7
5 1
8
428
2
4 8
5 0
8
429
2
4 8
5 1
9
448
2
4 9
5 0
9
449
2
4 9
5 1
10
468
2
4 10
5 0
10
469
2
4 10
5 1
22
0
489
2
3 0
6 1
0
488
2
3 0
6 0
1
508
2
3 1
6 0
1
509
2
3 1
6 1
2
528
2
3 2
6 0
2
529
2
3 2
6 1
3
548
2
3 3
6 0
3
549
2
3 3
6 1
4
568
2
3 4
6 0
4
569
2
3 4
6 1
5
589
2
3 5
6 1
5
588
2
3 5
6 0
6
608
2
3 6
6 0
6
609
2
3 6
6 1
7
628
2
3 7
6 0
7
629
2
3 7
6 1
8
648
2
3 8
6 0
8
649
2
3 8
6 1
9
668
2
3 9
6 0
9
669
2
3 9
6 1
10
688
2
3 10
6 0
10
689
2
3 10
6 1
22
0
709
2
2 0
7 1
0
708
2
2 0
7 0
1
728
2
2 1
7 0
1
729
2
2 1
7 1
2
748
2
2 2
7 0
2
749
2
2 2
7 1
3
768
2
2 3
7 0
3
769
2
2 3
7 1
4
788
2
2 4
7 0
4
789
2
2 4
7 1
5
809
2
2 5
7 1
5
808
2
2 5
7 0
6
828
2
2 6
7 0
6
829
2
2 6
7 1
7
848
2
2 7
7 0
7
849
2
2 7
7 1
8
868
2
2 8
7 0
8
869
2
2 8
7 1
9
888
2
2 9
7 0
9
889
2
2 9
7 1
10
908
2
2 10
7 0
10
909
2
2 10
7 1
22
0
929
2
1 0
8 1
0
928
2
1 0
8 0
1
948
2
1 1
8 0
1
949
2
1 1
8 1
2
968
2
1 2
8 0
2
969
2
1 2
8 1
3
988
2
1 3
8 0
3
989
2
1 3
8 1
4
1008
2
1 4
8 0
4
1009
2
1 4
8 1
5
1029
2
1 5
8 1
5
1028
2
1 5
8 0
6
1048
2
1 6
8 0
6
1049
2
1 6
8 1
7
1068
2
1 7
8 0
7
1069
2
1 7
8 1
8
1088
2
1 8
8 0
8
1089
2
1 8
8 1
9
1108
2
1 9
8 0
9
1109
2
1 9
8 1
10
1128
2
1 10
8 0
10
1129
2
1 10
8 1
22
0
1149
2
0 0
9 1
0
1148
2
0 0
9 0
1
1168
2
0 1
9 0
1
1169
2
0 1
9 1
2
1188
2
0 2
9 0
2
1189
2
0 2
9 1
3
1208
2
0 3
9 0
3
1209
2
0 3
9 1
4
1228
2
0 4
9 0
4
1229
2
0 4
9 1
5
1249
2
0 5
9 1
5
1248
2
0 5
9 0
6
1268
2
0 6
9 0
6
1269
2
0 6
9 1
7
1288
2
0 7
9 0
7
1289
2
0 7
9 1
8
1308
2
0 8
9 0
8
1309
2
0 8
9 1
9
1328
2
0 9
9 0
9
1329
2
0 9
9 1
10
1348
2
0 10
9 0
10
1349
2
0 10
9 1
end_DTG
begin_CG
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
9 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
8 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
7 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
6 440
11
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
5 440
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
19 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
end_CG
