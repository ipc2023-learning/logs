begin_version
3
end_version
begin_metric
0
end_metric
12
begin_variable
var7
-1
7
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
end_variable
begin_variable
var6
-1
7
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
end_variable
begin_variable
var5
-1
7
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
end_variable
begin_variable
var4
-1
7
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
end_variable
begin_variable
var8
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var9
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var10
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
11
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
11
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
11
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
11
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
0
begin_state
5
6
2
4
2
2
2
1
3
3
4
3
end_state
begin_goal
4
8 0
9 5
10 1
11 6
end_goal
528
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 2 0 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 2 1 0
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v2 l3 l5
0
1
0 2 2 4
0
end_operator
begin_operator
drive v2 l3 l6
0
1
0 2 2 5
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v2 l4 l6
0
1
0 2 3 5
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v2 l5 l3
0
1
0 2 4 2
0
end_operator
begin_operator
drive v2 l5 l7
0
1
0 2 4 6
0
end_operator
begin_operator
drive v2 l6 l3
0
1
0 2 5 2
0
end_operator
begin_operator
drive v2 l6 l4
0
1
0 2 5 3
0
end_operator
begin_operator
drive v2 l7 l2
0
1
0 2 6 1
0
end_operator
begin_operator
drive v2 l7 l5
0
1
0 2 6 4
0
end_operator
begin_operator
drive v3 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v3 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v3 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v3 l2 l5
0
1
0 1 1 4
0
end_operator
begin_operator
drive v3 l2 l7
0
1
0 1 1 6
0
end_operator
begin_operator
drive v3 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v3 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v3 l3 l5
0
1
0 1 2 4
0
end_operator
begin_operator
drive v3 l3 l6
0
1
0 1 2 5
0
end_operator
begin_operator
drive v3 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v3 l4 l6
0
1
0 1 3 5
0
end_operator
begin_operator
drive v3 l5 l2
0
1
0 1 4 1
0
end_operator
begin_operator





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
458
2
1 5
6 1
9
459
2
1 5
6 2
10
514
2
0 5
7 1
10
515
2
0 5
7 2
8
7
354
2
3 6
4 1
7
355
2
3 6
4 2
8
410
2
2 6
5 1
8
411
2
2 6
5 2
9
466
2
1 6
6 1
9
467
2
1 6
6 2
10
522
2
0 6
7 1
10
523
2
0 6
7 2
14
0
82
2
3 0
4 0
0
83
2
3 0
4 1
1
90
2
3 1
4 0
1
91
2
3 1
4 1
2
98
2
3 2
4 0
2
99
2
3 2
4 1
3
106
2
3 3
4 0
3
107
2
3 3
4 1
4
114
2
3 4
4 0
4
115
2
3 4
4 1
5
122
2
3 5
4 0
5
123
2
3 5
4 1
6
130
2
3 6
4 0
6
131
2
3 6
4 1
14
0
138
2
2 0
5 0
0
139
2
2 0
5 1
1
146
2
2 1
5 0
1
147
2
2 1
5 1
2
154
2
2 2
5 0
2
155
2
2 2
5 1
3
162
2
2 3
5 0
3
163
2
2 3
5 1
4
170
2
2 4
5 0
4
171
2
2 4
5 1
5
178
2
2 5
5 0
5
179
2
2 5
5 1
6
186
2
2 6
5 0
6
187
2
2 6
5 1
14
0
194
2
1 0
6 0
0
195
2
1 0
6 1
1
202
2
1 1
6 0
1
203
2
1 1
6 1
2
210
2
1 2
6 0
2
211
2
1 2
6 1
3
218
2
1 3
6 0
3
219
2
1 3
6 1
4
226
2
1 4
6 0
4
227
2
1 4
6 1
5
234
2
1 5
6 0
5
235
2
1 5
6 1
6
242
2
1 6
6 0
6
243
2
1 6
6 1
14
0
250
2
0 0
7 0
0
251
2
0 0
7 1
1
258
2
0 1
7 0
1
259
2
0 1
7 1
2
266
2
0 2
7 0
2
267
2
0 2
7 1
3
274
2
0 3
7 0
3
275
2
0 3
7 1
4
282
2
0 4
7 0
4
283
2
0 4
7 1
5
290
2
0 5
7 0
5
291
2
0 5
7 1
6
298
2
0 6
7 0
6
299
2
0 6
7 1
end_DTG
begin_DTG
8
7
308
2
3 0
4 1
7
309
2
3 0
4 2
8
364
2
2 0
5 1
8
365
2
2 0
5 2
9
420
2
1 0
6 1
9
421
2
1 0
6 2
10
476
2
0 0
7 1
10
477
2
0 0
7 2
8
7
316
2
3 1
4 1
7
317
2
3 1
4 2
8
372
2
2 1
5 1
8
373
2
2 1
5 2
9
428
2
1 1
6 1
9
429
2
1 1
6 2
10
484
2
0 1
7 1
10
485
2
0 1
7 2
8
7
324
2
3 2
4 1
7
325
2
3 2
4 2
8
380
2
2 2
5 1
8
381
2
2 2
5 2
9
436
2
1 2
6 1
9
437
2
1 2
6 2
10
492
2
0 2
7 1
10
493
2
0 2
7 2
8
7
332
2
3 3
4 1
7
333
2
3 3
4 2
8
388
2
2 3
5 1
8
389
2
2 3
5 2
9
444
2
1 3
6 1
9
445
2
1 3
6 2
10
500
2
0 3
7 1
10
501
2
0 3
7 2
8
7
340
2
3 4
4 1
7
341
2
3 4
4 2
8
396
2
2 4
5 1
8
397
2
2 4
5 2
9
452
2
1 4
6 1
9
453
2
1 4
6 2
10
508
2
0 4
7 1
10
509
2
0 4
7 2
8
7
348
2
3 5
4 1
7
349
2
3 5
4 2
8
404
2
2 5
5 1
8
405
2
2 5
5 2
9
460
2
1 5
6 1
9
461
2
1 5
6 2
10
516
2
0 5
7 1
10
517
2
0 5
7 2
8
7
356
2
3 6
4 1
7
357
2
3 6
4 2
8
412
2
2 6
5 1
8
413
2
2 6
5 2
9
468
2
1 6
6 1
9
469
2
1 6
6 2
10
524
2
0 6
7 1
10
525
2
0 6
7 2
14
0
84
2
3 0
4 0
0
85
2
3 0
4 1
1
92
2
3 1
4 0
1
93
2
3 1
4 1
2
100
2
3 2
4 0
2
101
2
3 2
4 1
3
108
2
3 3
4 0
3
109
2
3 3
4 1
4
116
2
3 4
4 0
4
117
2
3 4
4 1
5
124
2
3 5
4 0
5
125
2
3 5
4 1
6
132
2
3 6
4 0
6
133
2
3 6
4 1
14
0
140
2
2 0
5 0
0
141
2
2 0
5 1
1
148
2
2 1
5 0
1
149
2
2 1
5 1
2
156
2
2 2
5 0
2
157
2
2 2
5 1
3
164
2
2 3
5 0
3
165
2
2 3
5 1
4
172
2
2 4
5 0
4
173
2
2 4
5 1
5
180
2
2 5
5 0
5
181
2
2 5
5 1
6
188
2
2 6
5 0
6
189
2
2 6
5 1
14
0
196
2
1 0
6 0
0
197
2
1 0
6 1
1
204
2
1 1
6 0
1
205
2
1 1
6 1
2
212
2
1 2
6 0
2
213
2
1 2
6 1
3
220
2
1 3
6 0
3
221
2
1 3
6 1
4
228
2
1 4
6 0
4
229
2
1 4
6 1
5
236
2
1 5
6 0
5
237
2
1 5
6 1
6
244
2
1 6
6 0
6
245
2
1 6
6 1
14
0
252
2
0 0
7 0
0
253
2
0 0
7 1
1
260
2
0 1
7 0
1
261
2
0 1
7 1
2
268
2
0 2
7 0
2
269
2
0 2
7 1
3
276
2
0 3
7 0
3
277
2
0 3
7 1
4
284
2
0 4
7 0
4
285
2
0 4
7 1
5
292
2
0 5
7 0
5
293
2
0 5
7 1
6
300
2
0 6
7 0
6
301
2
0 6
7 1
end_DTG
begin_DTG
8
7
310
2
3 0
4 1
7
311
2
3 0
4 2
8
366
2
2 0
5 1
8
367
2
2 0
5 2
9
422
2
1 0
6 1
9
423
2
1 0
6 2
10
478
2
0 0
7 1
10
479
2
0 0
7 2
8
7
318
2
3 1
4 1
7
319
2
3 1
4 2
8
374
2
2 1
5 1
8
375
2
2 1
5 2
9
430
2
1 1
6 1
9
431
2
1 1
6 2
10
486
2
0 1
7 1
10
487
2
0 1
7 2
8
7
326
2
3 2
4 1
7
327
2
3 2
4 2
8
382
2
2 2
5 1
8
383
2
2 2
5 2
9
438
2
1 2
6 1
9
439
2
1 2
6 2
10
494
2
0 2
7 1
10
495
2
0 2
7 2
8
7
334
2
3 3
4 1
7
335
2
3 3
4 2
8
390
2
2 3
5 1
8
391
2
2 3
5 2
9
446
2
1 3
6 1
9
447
2
1 3
6 2
10
502
2
0 3
7 1
10
503
2
0 3
7 2
8
7
342
2
3 4
4 1
7
343
2
3 4
4 2
8
398
2
2 4
5 1
8
399
2
2 4
5 2
9
454
2
1 4
6 1
9
455
2
1 4
6 2
10
510
2
0 4
7 1
10
511
2
0 4
7 2
8
7
350
2
3 5
4 1
7
351
2
3 5
4 2
8
406
2
2 5
5 1
8
407
2
2 5
5 2
9
462
2
1 5
6 1
9
463
2
1 5
6 2
10
518
2
0 5
7 1
10
519
2
0 5
7 2
8
7
358
2
3 6
4 1
7
359
2
3 6
4 2
8
414
2
2 6
5 1
8
415
2
2 6
5 2
9
470
2
1 6
6 1
9
471
2
1 6
6 2
10
526
2
0 6
7 1
10
527
2
0 6
7 2
14
0
86
2
3 0
4 0
0
87
2
3 0
4 1
1
94
2
3 1
4 0
1
95
2
3 1
4 1
2
102
2
3 2
4 0
2
103
2
3 2
4 1
3
110
2
3 3
4 0
3
111
2
3 3
4 1
4
118
2
3 4
4 0
4
119
2
3 4
4 1
5
126
2
3 5
4 0
5
127
2
3 5
4 1
6
134
2
3 6
4 0
6
135
2
3 6
4 1
14
0
142
2
2 0
5 0
0
143
2
2 0
5 1
1
150
2
2 1
5 0
1
151
2
2 1
5 1
2
158
2
2 2
5 0
2
159
2
2 2
5 1
3
166
2
2 3
5 0
3
167
2
2 3
5 1
4
174
2
2 4
5 0
4
175
2
2 4
5 1
5
182
2
2 5
5 0
5
183
2
2 5
5 1
6
190
2
2 6
5 0
6
191
2
2 6
5 1
14
0
198
2
1 0
6 0
0
199
2
1 0
6 1
1
206
2
1 1
6 0
1
207
2
1 1
6 1
2
214
2
1 2
6 0
2
215
2
1 2
6 1
3
222
2
1 3
6 0
3
223
2
1 3
6 1
4
230
2
1 4
6 0
4
231
2
1 4
6 1
5
238
2
1 5
6 0
5
239
2
1 5
6 1
6
246
2
1 6
6 0
6
247
2
1 6
6 1
14
0
254
2
0 0
7 0
0
255
2
0 0
7 1
1
262
2
0 1
7 0
1
263
2
0 1
7 1
2
270
2
0 2
7 0
2
271
2
0 2
7 1
3
278
2
0 3
7 0
3
279
2
0 3
7 1
4
286
2
0 4
7 0
4
287
2
0 4
7 1
5
294
2
0 5
7 0
5
295
2
0 5
7 1
6
302
2
0 6
7 0
6
303
2
0 6
7 1
end_DTG
begin_CG
5
8 28
9 28
10 28
11 28
7 112
5
8 28
9 28
10 28
11 28
6 112
5
8 28
9 28
10 28
11 28
5 112
5
8 28
9 28
10 28
11 28
4 112
4
8 28
9 28
10 28
11 28
4
8 28
9 28
10 28
11 28
4
8 28
9 28
10 28
11 28
4
8 28
9 28
10 28
11 28
4
4 28
5 28
6 28
7 28
4
4 28
5 28
6 28
7 28
4
4 28
5 28
6 28
7 28
4
4 28
5 28
6 28
7 28
end_CG
