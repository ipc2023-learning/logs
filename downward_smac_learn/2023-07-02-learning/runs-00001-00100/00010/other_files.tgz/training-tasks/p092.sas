begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var22
-1
16
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var21
-1
16
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var20
-1
16
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var19
-1
16
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var18
-1
16
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var17
-1
16
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var16
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var23
-1
4
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
Atom capacity(v1, c3)
end_variable
begin_variable
var24
-1
4
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
Atom capacity(v2, c3)
end_variable
begin_variable
var25
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var26
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var27
-1
4
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
Atom capacity(v5, c3)
end_variable
begin_variable
var28
-1
4
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
Atom capacity(v6, c3)
end_variable
begin_variable
var29
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var0
-1
23
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var1
-1
23
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var2
-1
23
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var3
-1
23
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var4
-1
23
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l16)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
3 11
10 0
11
3844
2
3 11
10 1
11
3845
2
3 11
10 2
12
3892
2
3 12
10 1
12
3893
2
3 12
10 2
12
3891
2
3 12
10 0
13
3939
2
3 13
10 0
13
3940
2
3 13
10 1
13
3941
2
3 13
10 2
14
3987
2
3 14
10 0
14
3988
2
3 14
10 1
14
3989
2
3 14
10 2
15
4035
2
3 15
10 0
15
4036
2
3 15
10 1
15
4037
2
3 15
10 2
48
0
4084
2
2 0
11 1
0
4085
2
2 0
11 2
0
4083
2
2 0
11 0
1
4131
2
2 1
11 0
1
4132
2
2 1
11 1
1
4133
2
2 1
11 2
2
4179
2
2 2
11 0
2
4180
2
2 2
11 1
2
4181
2
2 2
11 2
3
4227
2
2 3
11 0
3
4228
2
2 3
11 1
3
4229
2
2 3
11 2
4
4276
2
2 4
11 1
4
4277
2
2 4
11 2
4
4275
2
2 4
11 0
5
4323
2
2 5
11 0
5
4324
2
2 5
11 1
5
4325
2
2 5
11 2
6
4371
2
2 6
11 0
6
4372
2
2 6
11 1
6
4373
2
2 6
11 2
7
4419
2
2 7
11 0
7
4420
2
2 7
11 1
7
4421
2
2 7
11 2
8
4467
2
2 8
11 0
8
4469
2
2 8
11 2
8
4468
2
2 8
11 1
9
4515
2
2 9
11 0
9
4516
2
2 9
11 1
9
4517
2
2 9
11 2
10
4563
2
2 10
11 0
10
4564
2
2 10
11 1
10
4565
2
2 10
11 2
11
4611
2
2 11
11 0
11
4612
2
2 11
11 1
11
4613
2
2 11
11 2
12
4660
2
2 12
11 1
12
4661
2
2 12
11 2
12
4659
2
2 12
11 0
13
4707
2
2 13
11 0
13
4708
2
2 13
11 1
13
4709
2
2 13
11 2
14
4755
2
2 14
11 0
14
4756
2
2 14
11 1
14
4757
2
2 14
11 2
15
4803
2
2 15
11 0
15
4804
2
2 15
11 1
15
4805
2
2 15
11 2
48
0
4852
2
1 0
12 1
0
4853
2
1 0
12 2
0
4851
2
1 0
12 0
1
4899
2
1 1
12 0
1
4900
2
1 1
12 1
1
4901
2
1 1
12 2
2
4947
2
1 2
12 0
2
4948
2
1 2
12 1
2
4949
2
1 2
12 2
3
4995
2
1 3
12 0
3
4996
2
1 3
12 1
3
4997
2
1 3
12 2
4
5044
2
1 4
12 1
4
5045
2
1 4
12 2
4
5043
2
1 4
12 0
5
5091
2
1 5
12 0
5
5092
2
1 5
12 1
5
5093
2
1 5
12 2
6
5139
2
1 6
12 0
6
5140
2
1 6
12 1
6
5141
2
1 6
12 2
7
5187
2
1 7
12 0
7
5188
2
1 7
12 1
7
5189
2
1 7
12 2
8
5235
2
1 8
12 0
8
5237
2
1 8
12 2
8
5236
2
1 8
12 1
9
5283
2
1 9
12 0
9
5284
2
1 9
12 1
9
5285
2
1 9
12 2
10
5331
2
1 10
12 0
10
5332
2
1 10
12 1
10
5333
2
1 10
12 2
11
5379
2
1 11
12 0
11
5380
2
1 11
12 1
11
5381
2
1 11
12 2
12
5428
2
1 12
12 1
12
5429
2
1 12
12 2
12
5427
2
1 12
12 0
13
5475
2
1 13
12 0
13
5476
2
1 13
12 1
13
5477
2
1 13
12 2
14
5523
2
1 14
12 0
14
5524
2
1 14
12 1
14
5525
2
1 14
12 2
15
5571
2
1 15
12 0
15
5572
2
1 15
12 1
15
5573
2
1 15
12 2
48
0
5620
2
0 0
13 1
0
5621
2
0 0
13 2
0
5619
2
0 0
13 0
1
5667
2
0 1
13 0
1
5668
2
0 1
13 1
1
5669
2
0 1
13 2
2
5715
2
0 2
13 0
2
5716
2
0 2
13 1
2
5717
2
0 2
13 2
3
5763
2
0 3
13 0
3
5764
2
0 3
13 1
3
5765
2
0 3
13 2
4
5812
2
0 4
13 1
4
5813
2
0 4
13 2
4
5811
2
0 4
13 0
5
5859
2
0 5
13 0
5
5860
2
0 5
13 1
5
5861
2
0 5
13 2
6
5907
2
0 6
13 0
6
5908
2
0 6
13 1
6
5909
2
0 6
13 2
7
5955
2
0 7
13 0
7
5956
2
0 7
13 1
7
5957
2
0 7
13 2
8
6003
2
0 8
13 0
8
6005
2
0 8
13 2
8
6004
2
0 8
13 1
9
6051
2
0 9
13 0
9
6052
2
0 9
13 1
9
6053
2
0 9
13 2
10
6099
2
0 10
13 0
10
6100
2
0 10
13 1
10
6101
2
0 10
13 2
11
6147
2
0 11
13 0
11
6148
2
0 11
13 1
11
6149
2
0 11
13 2
12
6196
2
0 12
13 1
12
6197
2
0 12
13 2
12
6195
2
0 12
13 0
13
6243
2
0 13
13 0
13
6244
2
0 13
13 1
13
6245
2
0 13
13 2
14
6291
2
0 14
13 0
14
6292
2
0 14
13 1
14
6293
2
0 14
13 2
15
6339
2
0 15
13 0
15
6340
2
0 15
13 1
15
6341
2
0 15
13 2
end_DTG
begin_CG
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
13 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
12 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
11 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
10 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
9 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
8 1536
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
7 1536
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
16
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
end_CG
