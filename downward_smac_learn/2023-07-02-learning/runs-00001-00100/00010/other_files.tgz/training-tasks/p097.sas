begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var23
-1
16
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var22
-1
16
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var21
-1
16
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var20
-1
16
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var19
-1
16
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var18
-1
16
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var17
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var24
-1
4
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
Atom capacity(v1, c3)
end_variable
begin_variable
var25
-1
4
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
Atom capacity(v2, c3)
end_variable
begin_variable
var26
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var27
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var28
-1
4
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
Atom capacity(v5, c3)
end_variable
begin_variable
var29
-1
4
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
Atom capacity(v6, c3)
end_variable
begin_variable
var30
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var0
-1
23
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var1
-1
23
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var2
-1
23
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var3
-1
23
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var4
-1
23
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l16)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
10 0
13
3636
2
3 13
10 1
13
3637
2
3 13
10 2
14
3686
2
3 14
10 0
14
3687
2
3 14
10 1
14
3688
2
3 14
10 2
15
3737
2
3 15
10 0
15
3738
2
3 15
10 1
15
3739
2
3 15
10 2
48
0
3789
2
2 0
11 1
0
3790
2
2 0
11 2
0
3788
2
2 0
11 0
1
3839
2
2 1
11 0
1
3840
2
2 1
11 1
1
3841
2
2 1
11 2
2
3890
2
2 2
11 0
2
3891
2
2 2
11 1
2
3892
2
2 2
11 2
3
3941
2
2 3
11 0
3
3942
2
2 3
11 1
3
3943
2
2 3
11 2
4
3993
2
2 4
11 1
4
3994
2
2 4
11 2
4
3992
2
2 4
11 0
5
4043
2
2 5
11 0
5
4044
2
2 5
11 1
5
4045
2
2 5
11 2
6
4094
2
2 6
11 0
6
4095
2
2 6
11 1
6
4096
2
2 6
11 2
7
4145
2
2 7
11 0
7
4146
2
2 7
11 1
7
4147
2
2 7
11 2
8
4196
2
2 8
11 0
8
4198
2
2 8
11 2
8
4197
2
2 8
11 1
9
4247
2
2 9
11 0
9
4248
2
2 9
11 1
9
4249
2
2 9
11 2
10
4298
2
2 10
11 0
10
4299
2
2 10
11 1
10
4300
2
2 10
11 2
11
4349
2
2 11
11 0
11
4350
2
2 11
11 1
11
4351
2
2 11
11 2
12
4401
2
2 12
11 1
12
4402
2
2 12
11 2
12
4400
2
2 12
11 0
13
4451
2
2 13
11 0
13
4452
2
2 13
11 1
13
4453
2
2 13
11 2
14
4502
2
2 14
11 0
14
4503
2
2 14
11 1
14
4504
2
2 14
11 2
15
4553
2
2 15
11 0
15
4554
2
2 15
11 1
15
4555
2
2 15
11 2
48
0
4605
2
1 0
12 1
0
4606
2
1 0
12 2
0
4604
2
1 0
12 0
1
4655
2
1 1
12 0
1
4656
2
1 1
12 1
1
4657
2
1 1
12 2
2
4706
2
1 2
12 0
2
4707
2
1 2
12 1
2
4708
2
1 2
12 2
3
4757
2
1 3
12 0
3
4758
2
1 3
12 1
3
4759
2
1 3
12 2
4
4809
2
1 4
12 1
4
4810
2
1 4
12 2
4
4808
2
1 4
12 0
5
4859
2
1 5
12 0
5
4860
2
1 5
12 1
5
4861
2
1 5
12 2
6
4910
2
1 6
12 0
6
4911
2
1 6
12 1
6
4912
2
1 6
12 2
7
4961
2
1 7
12 0
7
4962
2
1 7
12 1
7
4963
2
1 7
12 2
8
5012
2
1 8
12 0
8
5014
2
1 8
12 2
8
5013
2
1 8
12 1
9
5063
2
1 9
12 0
9
5064
2
1 9
12 1
9
5065
2
1 9
12 2
10
5114
2
1 10
12 0
10
5115
2
1 10
12 1
10
5116
2
1 10
12 2
11
5165
2
1 11
12 0
11
5166
2
1 11
12 1
11
5167
2
1 11
12 2
12
5217
2
1 12
12 1
12
5218
2
1 12
12 2
12
5216
2
1 12
12 0
13
5267
2
1 13
12 0
13
5268
2
1 13
12 1
13
5269
2
1 13
12 2
14
5318
2
1 14
12 0
14
5319
2
1 14
12 1
14
5320
2
1 14
12 2
15
5369
2
1 15
12 0
15
5370
2
1 15
12 1
15
5371
2
1 15
12 2
48
0
5421
2
0 0
13 1
0
5422
2
0 0
13 2
0
5420
2
0 0
13 0
1
5471
2
0 1
13 0
1
5472
2
0 1
13 1
1
5473
2
0 1
13 2
2
5522
2
0 2
13 0
2
5523
2
0 2
13 1
2
5524
2
0 2
13 2
3
5573
2
0 3
13 0
3
5574
2
0 3
13 1
3
5575
2
0 3
13 2
4
5625
2
0 4
13 1
4
5626
2
0 4
13 2
4
5624
2
0 4
13 0
5
5675
2
0 5
13 0
5
5676
2
0 5
13 1
5
5677
2
0 5
13 2
6
5726
2
0 6
13 0
6
5727
2
0 6
13 1
6
5728
2
0 6
13 2
7
5777
2
0 7
13 0
7
5778
2
0 7
13 1
7
5779
2
0 7
13 2
8
5828
2
0 8
13 0
8
5830
2
0 8
13 2
8
5829
2
0 8
13 1
9
5879
2
0 9
13 0
9
5880
2
0 9
13 1
9
5881
2
0 9
13 2
10
5930
2
0 10
13 0
10
5931
2
0 10
13 1
10
5932
2
0 10
13 2
11
5981
2
0 11
13 0
11
5982
2
0 11
13 1
11
5983
2
0 11
13 2
12
6033
2
0 12
13 1
12
6034
2
0 12
13 2
12
6032
2
0 12
13 0
13
6083
2
0 13
13 0
13
6084
2
0 13
13 1
13
6085
2
0 13
13 2
14
6134
2
0 14
13 0
14
6135
2
0 14
13 1
14
6136
2
0 14
13 2
15
6185
2
0 15
13 0
15
6186
2
0 15
13 1
15
6187
2
0 15
13 2
end_DTG
begin_CG
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
13 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
12 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
11 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
10 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
9 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
8 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
7 1632
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
end_CG
