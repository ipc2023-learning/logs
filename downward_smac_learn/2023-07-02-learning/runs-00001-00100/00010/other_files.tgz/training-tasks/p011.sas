begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var4
-1
6
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
end_variable
begin_variable
var3
-1
6
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
end_variable
begin_variable
var2
-1
6
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
end_variable
begin_variable
var5
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var6
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
9
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
9
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
0
begin_state
1
1
0
2
1
2
2
3
end_state
begin_goal
2
6 0
7 0
end_goal
180
begin_operator
drive v1 l1 l2
0
1
0 2 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 2 1 0
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 2 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 1 0 5
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l6 l1
0
1
0 1 5 0
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 1 5 1
0
end_operator
begin_operator
drive v3 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v3 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l6
0
1
0 0 0 5
0
end_operator
begin_operator
drive v3 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drive v3 l2 l6
0
1
0 0 1 5
0
end_operator
begin_operator
drive v3 l3 l1
0
1
0 0 2 0
0
end_operator
begin_operator
drive v3 l4 l1
0
1
0 0 3 0
0
end_operator
begin_operator
drive v3 l5 l1
0
1
0 0 4 0
0
end_operator
begin_operator
drive v3 l6 l1
0
1
0 0 5 0
0
end_operator
begin_operator
drive v3 l6 l2
0
1
0 0 5 1
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
2 0
2
0 6 6 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
2 0
2
0 6 6 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
2 0
2
0 7 6 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
2 0
2
0 7 6 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
2 1
2
0 6 6 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c1 c2
1
2 1
2
0 6 6 1
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p2 c0 c1
1
2 1
2
0 7 6 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p2 c1 c2
1
2 1
2
0 7 6 1
0 3 1 2
0
end_operator
begin_operator
drop v1 l3 p1 c0 c1
1
2 2
2
0 6 6 2
0 3 0 1
0
end_operator
begin_operator
drop v1 l3 p1 c1 c2
1
2 2
2
0 6 6 2
0 3 1 2
0
end_operator
begin_operator
drop v1 l3 p2 c0 c1
1
2 2
2
0 7 6 2
0 3 0 1
0
end_operator
begin_operator
drop v1 l3 p2 c1 c2
1
2 2
2
0 7 6 2
0 3 1 2
0
end_operator
begin_operator
drop v1 l4 p1 c0 c1
1
2 3
2
0 6 6 3
0 3 0 1
0
end_operator
begin_operator
drop v1 l4 p1 c1 c2
1
2 3
2
0 6 6 3
0 3 1 2
0
end_operator
begin_operator
drop v1 l4 p2 c0 c1
1
2 3
2
0 7 6 3
0 3 0 1
0
end_operator
begin_operator
drop v1 l4 p2 c1 c2
1
2 3
2
0 7 6 3
0 3 1 2
0
end_operator
begin_operator
drop v1 l5 p1 c0 c1
1
2 4
2
0 6 6 4
0 3 0 1
0
end_operator
begin_operator
drop v1 l5 p1 c1 c2
1
2 4
2
0 6 6 4
0 3 1 2
0
end_operator
begin_operator
drop v1 l5 p2 c0 c1
1
2 4
2
0 7 6 4
0 3 0 1
0
end_operator
begin_operator
drop v1 l5 p2 c1 c2
1
2 4
2
0 7 6 4
0 3 1 2
0
end_operator
begin_operator
drop v1 l6 p1 c0 c1
1
2 5
2
0 6 6 5
0 3 0 1
0
end_operator
begin_operator
drop v1 l6 p1 c1 c2
1
2 5
2
0 6 6 5
0 3 1 2
0
end_operator
begin_operator
drop v1 l6 p2 c0 c1
1
2 5
2
0 7 6 5
0 3 0 1
0
end_operator
begin_operator
drop v1 l6 p2 c1 c2
1
2 5
2
0 7 6 5
0 3 1 2
0
end_operator
begin_operator
drop v2 l1 p1 c0 c1
1
1 0
2
0 6 7 0
0 4 0 1
0
end_operator
begin_oper




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 0
end_SG
begin_DTG
5
1
24
0
2
25
0
3
26
0
4
27
0
5
28
0
2
0
29
0
5
30
0
1
0
31
0
1
0
32
0
1
0
33
0
2
0
34
0
1
35
0
end_DTG
begin_DTG
5
1
12
0
2
13
0
3
14
0
4
15
0
5
16
0
2
0
17
0
5
18
0
1
0
19
0
1
0
20
0
1
0
21
0
2
0
22
0
1
23
0
end_DTG
begin_DTG
5
1
0
0
2
1
0
3
2
0
4
3
0
5
4
0
2
0
5
0
5
6
0
1
0
7
0
1
0
8
0
1
0
9
0
2
0
10
0
1
11
0
end_DTG
begin_DTG
12
1
36
2
6 6
2 0
1
38
2
7 6
2 0
1
40
2
6 6
2 1
1
42
2
7 6
2 1
1
44
2
6 6
2 2
1
46
2
7 6
2 2
1
48
2
6 6
2 3
1
50
2
7 6
2 3
1
52
2
6 6
2 4
1
54
2
7 6
2 4
1
56
2
6 6
2 5
1
58
2
7 6
2 5
24
0
108
2
6 0
2 0
0
130
2
7 5
2 5
0
128
2
6 5
2 5
0
126
2
7 4
2 4
0
124
2
6 4
2 4
0
122
2
7 3
2 3
0
120
2
6 3
2 3
0
118
2
7 2
2 2
0
116
2
6 2
2 2
0
114
2
7 1
2 1
0
112
2
6 1
2 1
0
110
2
7 0
2 0
2
37
2
6 6
2 0
2
59
2
7 6
2 5
2
57
2
6 6
2 5
2
55
2
7 6
2 4
2
53
2
6 6
2 4
2
51
2
7 6
2 3
2
49
2
6 6
2 3
2
47
2
7 6
2 2
2
45
2
6 6
2 2
2
43
2
7 6
2 1
2
41
2
6 6
2 1
2
39
2
7 6
2 0
12
1
109
2
6 0
2 0
1
111
2
7 0
2 0
1
113
2
6 1
2 1
1
115
2
7 1
2 1
1
117
2
6 2
2 2
1
119
2
7 2
2 2
1
121
2
6 3
2 3
1
123
2
7 3
2 3
1
125
2
6 4
2 4
1
127
2
7 4
2 4
1
129
2
6 5
2 5
1
131
2
7 5
2 5
end_DTG
begin_DTG
12
1
60
2
6 7
1 0
1
62
2
7 7
1 0
1
64
2
6 7
1 1
1
66
2
7 7
1 1
1
68
2
6 7
1 2
1
70
2
7 7
1 2
1
72
2
6 7
1 3
1
74
2
7 7
1 3
1
76
2
6 7
1 4
1
78
2
7 7
1 4
1
80
2
6 7
1 5
1
82
2
7 7
1 5
24
0
132
2
6 0
1 0
0
154
2
7 5
1 5
0
152
2
6 5
1 5
0
150
2
7 4
1 4
0
148
2
6 4
1 4
0
146
2
7 3
1 3
0
144
2
6 3
1 3
0
142
2
7 2
1 2
0
140
2
6 2
1 2
0
138
2
7 1
1 1
0
136
2
6 1
1 1
0
134
2
7 0
1 0
2
61
2
6 7
1 0
2
83
2
7 7
1 5
2
81
2
6 7
1 5
2
79
2
7 7
1 4
2
77
2
6 7
1 4
2
75
2
7 7
1 3
2
73
2
6 7
1 3
2
71
2
7 7
1 2
2
69
2
6 7
1 2
2
67
2
7 7
1 1
2
65
2
6 7
1 1
2
63
2
7 7
1 0
12
1
133
2
6 0
1 0
1
135
2
7 0
1 0
1
137
2
6 1
1 1
1
139
2
7 1
1 1
1
141
2
6 2
1 2
1
143
2
7 2
1 2
1
145
2
6 3
1 3
1
147
2
7 3
1 3
1
149
2
6 4
1 4
1
151
2
7 4
1 4
1
153
2
6 5
1 5
1
155
2
7 5
1 5
end_DTG
begin_DTG
12
1
84
2
6 8
0 0
1
86
2
7 8
0 0
1
88
2
6 8
0 1
1
90
2
7 8
0 1
1
92
2
6 8
0 2
1
94
2
7 8
0 2
1
96
2
6 8
0 3
1
98
2
7 8
0 3
1
100
2
6 8
0 4
1
102
2
7 8
0 4
1
104
2
6 8
0 5
1
106
2
7 8
0 5
24
0
156
2
6 0
0 0
0
178
2
7 5
0 5
0
176
2
6 5
0 5
0
174
2
7 4
0 4
0
172
2
6 4
0 4
0
170
2
7 3
0 3
0
168
2
6 3
0 3
0
166
2
7 2
0 2
0
164
2
6 2
0 2
0
162
2
7 1
0 1
0
160
2
6 1
0 1
0
158
2
7 0
0 0
2
85
2
6 8
0 0
2
107
2
7 8
0 5
2
105
2
6 8
0 5
2
103
2
7 8
0 4
2
101
2
6 8
0 4
2
99
2
7 8
0 3
2
97
2
6 8
0 3
2
95
2
7 8
0 2
2
93
2
6 8
0 2
2
91
2
7 8
0 1
2
89
2
6 8
0 1
2
87
2
7 8
0 0
12
1
157
2
6 0
0 0
1
159
2
7 0
0 0
1
161
2
6 1
0 1
1
163
2
7 1
0 1
1
165
2
6 2
0 2
1
167
2
7 2
0 2
1
169
2
6 3
0 3
1
171
2
7 3
0 3
1
173
2
6 4
0 4
1
175
2
7 4
0 4
1
177
2
6 5
0 5
1
179
2
7 5
0 5
end_DTG
begin_DTG
6
6
108
2
2 0
3 1
6
109
2
2 0
3 2
7
132
2
1 0
4 1
7
133
2
1 0
4 2
8
156
2
0 0
5 1
8
157
2
0 0
5 2
6
6
112
2
2 1
3 1
6
113
2
2 1
3 2
7
136
2
1 1
4 1
7
137
2
1 1
4 2
8
160
2
0 1
5 1
8
161
2
0 1
5 2
6
6
116
2
2 2
3 1
6
117
2
2 2
3 2
7
140
2
1 2
4 1
7
141
2
1 2
4 2
8
164
2
0 2
5 1
8
165
2
0 2
5 2
6
6
120
2
2 3
3 1
6
121
2
2 3
3 2
7
144
2
1 3
4 1
7
145
2
1 3
4 2
8
168
2
0 3
5 1
8
169
2
0 3
5 2
6
6
124
2
2 4
3 1
6
125
2
2 4
3 2
7
148
2
1 4
4 1
7
149
2
1 4
4 2
8
172
2
0 4
5 1
8
173
2
0 4
5 2
6
6
128
2
2 5
3 1
6
129
2
2 5
3 2
7
152
2
1 5
4 1
7
153
2
1 5
4 2
8
176
2
0 5
5 1
8
177
2
0 5
5 2
12
0
36
2
2 0
3 0
0
37
2
2 0
3 1
1
40
2
2 1
3 0
1
41
2
2 1
3 1
2
44
2
2 2
3 0
2
45
2
2 2
3 1
3
48
2
2 3
3 0
3
49
2
2 3
3 1
4
52
2
2 4
3 0
4
53
2
2 4
3 1
5
56
2
2 5
3 0
5
57
2
2 5
3 1
12
0
60
2
1 0
4 0
0
61
2
1 0
4 1
1
64
2
1 1
4 0
1
65
2
1 1
4 1
2
68
2
1 2
4 0
2
69
2
1 2
4 1
3
72
2
1 3
4 0
3
73
2
1 3
4 1
4
76
2
1 4
4 0
4
77
2
1 4
4 1
5
80
2
1 5
4 0
5
81
2
1 5
4 1
12
0
84
2
0 0
5 0
0
85
2
0 0
5 1
1
88
2
0 1
5 0
1
89
2
0 1
5 1
2
92
2
0 2
5 0
2
93
2
0 2
5 1
3
96
2
0 3
5 0
3
97
2
0 3
5 1
4
100
2
0 4
5 0
4
101
2
0 4
5 1
5
104
2
0 5
5 0
5
105
2
0 5
5 1
end_DTG
begin_DTG
6
6
110
2
2 0
3 1
6
111
2
2 0
3 2
7
134
2
1 0
4 1
7
135
2
1 0
4 2
8
158
2
0 0
5 1
8
159
2
0 0
5 2
6
6
114
2
2 1
3 1
6
115
2
2 1
3 2
7
138
2
1 1
4 1
7
139
2
1 1
4 2
8
162
2
0 1
5 1
8
163
2
0 1
5 2
6
6
118
2
2 2
3 1
6
119
2
2 2
3 2
7
142
2
1 2
4 1
7
143
2
1 2
4 2
8
166
2
0 2
5 1
8
167
2
0 2
5 2
6
6
122
2
2 3
3 1
6
123
2
2 3
3 2
7
146
2
1 3
4 1
7
147
2
1 3
4 2
8
170
2
0 3
5 1
8
171
2
0 3
5 2
6
6
126
2
2 4
3 1
6
127
2
2 4
3 2
7
150
2
1 4
4 1
7
151
2
1 4
4 2
8
174
2
0 4
5 1
8
175
2
0 4
5 2
6
6
130
2
2 5
3 1
6
131
2
2 5
3 2
7
154
2
1 5
4 1
7
155
2
1 5
4 2
8
178
2
0 5
5 1
8
179
2
0 5
5 2
12
0
38
2
2 0
3 0
0
39
2
2 0
3 1
1
42
2
2 1
3 0
1
43
2
2 1
3 1
2
46
2
2 2
3 0
2
47
2
2 2
3 1
3
50
2
2 3
3 0
3
51
2
2 3
3 1
4
54
2
2 4
3 0
4
55
2
2 4
3 1
5
58
2
2 5
3 0
5
59
2
2 5
3 1
12
0
62
2
1 0
4 0
0
63
2
1 0
4 1
1
66
2
1 1
4 0
1
67
2
1 1
4 1
2
70
2
1 2
4 0
2
71
2
1 2
4 1
3
74
2
1 3
4 0
3
75
2
1 3
4 1
4
78
2
1 4
4 0
4
79
2
1 4
4 1
5
82
2
1 5
4 0
5
83
2
1 5
4 1
12
0
86
2
0 0
5 0
0
87
2
0 0
5 1
1
90
2
0 1
5 0
1
91
2
0 1
5 1
2
94
2
0 2
5 0
2
95
2
0 2
5 1
3
98
2
0 3
5 0
3
99
2
0 3
5 1
4
102
2
0 4
5 0
4
103
2
0 4
5 1
5
106
2
0 5
5 0
5
107
2
0 5
5 1
end_DTG
begin_CG
3
6 24
7 24
5 48
3
6 24
7 24
4 48
3
6 24
7 24
3 48
2
6 24
7 24
2
6 24
7 24
2
6 24
7 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
end_CG
