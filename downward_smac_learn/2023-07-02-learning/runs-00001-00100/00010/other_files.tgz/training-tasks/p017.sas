begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var5
-1
6
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
end_variable
begin_variable
var4
-1
6
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
end_variable
begin_variable
var3
-1
6
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
end_variable
begin_variable
var6
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
9
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
9
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
9
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
0
begin_state
2
2
3
1
1
1
0
1
3
end_state
begin_goal
3
6 2
7 2
8 1
end_goal
288
begin_operator
drive v1 l1 l2
0
1
0 2 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 2 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 2 2 3
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 2 2 5
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 2 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 2 3 5
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 2 5 0
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 2 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 2 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 2 5 4
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 1 0 5
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v2 l3 l4
0
1
0 1 2 3
0
end_operator
begin_operator
drive v2 l3 l6
0
1
0 1 2 5
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l3
0
1
0 1 3 2
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l4 l6
0
1
0 1 3 5
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 1 4 5
0
end_operator
begin_operator
drive v2 l6 l1
0
1
0 1 5 0
0
end_operator
begin_operator
drive v2 l6 l3
0
1
0 1 5 2
0
end_operator
begin_operator
drive v2 l6 l4
0
1
0 1 5 3
0
end_operator
begin_operator
drive v2 l6 l5
0
1
0 1 5 4
0
end_operator
begin_operator
drive v3 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v3 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l6
0
1
0 0 0 5
0
end_operator
begin_operator
drive v3 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v3 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v3 l3 l1
0
1
0 0 2 0
0
end_operator
begin_operator
drive v3 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drive v3 l3 l4
0
1
0 0 2 3
0
end_operator
begin_operator
drive v3 l3 l6
0
1
0 0 2 5
0
end_operator
begin_operator
drive v3 l4 l1
0
1
0 0 3 0
0
end_operator
begin_operator
drive v3 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drive v3 l4 l3
0
1
0 0 3 2
0
end_operator
begin_operator
drive v3 l4 l5
0
1
0 0 3 4
0
end_operator
begin_operator
drive v3 l4 l6
0
1
0 0 3 5
0
end_operator
begin_operator
driv




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
2
7 4
1 4
1
241
2
6 4
1 4
1
239
2
8 3
1 3
1
237
2
7 3
1 3
1
217
2
6 0
1 0
1
233
2
8 2
1 2
1
231
2
7 2
1 2
1
229
2
6 2
1 2
1
227
2
8 1
1 1
1
225
2
7 1
1 1
1
223
2
6 1
1 1
1
221
2
8 0
1 0
1
219
2
7 0
1 0
end_DTG
begin_DTG
18
1
162
2
6 8
0 3
1
178
2
8 8
0 5
1
176
2
7 8
0 5
1
174
2
6 8
0 5
1
172
2
8 8
0 4
1
170
2
7 8
0 4
1
168
2
6 8
0 4
1
166
2
8 8
0 3
1
164
2
7 8
0 3
1
144
2
6 8
0 0
1
160
2
8 8
0 2
1
158
2
7 8
0 2
1
156
2
6 8
0 2
1
154
2
8 8
0 1
1
152
2
7 8
0 1
1
150
2
6 8
0 1
1
148
2
8 8
0 0
1
146
2
7 8
0 0
36
0
270
2
6 3
0 3
0
254
2
7 0
0 0
0
256
2
8 0
0 0
0
258
2
6 1
0 1
0
260
2
7 1
0 1
0
262
2
8 1
0 1
0
264
2
6 2
0 2
0
266
2
7 2
0 2
0
268
2
8 2
0 2
0
252
2
6 0
0 0
0
272
2
7 3
0 3
0
274
2
8 3
0 3
0
276
2
6 4
0 4
0
278
2
7 4
0 4
0
280
2
8 4
0 4
0
282
2
6 5
0 5
0
284
2
7 5
0 5
0
286
2
8 5
0 5
2
163
2
6 8
0 3
2
147
2
7 8
0 0
2
149
2
8 8
0 0
2
151
2
6 8
0 1
2
153
2
7 8
0 1
2
155
2
8 8
0 1
2
157
2
6 8
0 2
2
159
2
7 8
0 2
2
161
2
8 8
0 2
2
145
2
6 8
0 0
2
165
2
7 8
0 3
2
167
2
8 8
0 3
2
169
2
6 8
0 4
2
171
2
7 8
0 4
2
173
2
8 8
0 4
2
175
2
6 8
0 5
2
177
2
7 8
0 5
2
179
2
8 8
0 5
18
1
271
2
6 3
0 3
1
287
2
8 5
0 5
1
285
2
7 5
0 5
1
283
2
6 5
0 5
1
281
2
8 4
0 4
1
279
2
7 4
0 4
1
277
2
6 4
0 4
1
275
2
8 3
0 3
1
273
2
7 3
0 3
1
253
2
6 0
0 0
1
269
2
8 2
0 2
1
267
2
7 2
0 2
1
265
2
6 2
0 2
1
263
2
8 1
0 1
1
261
2
7 1
0 1
1
259
2
6 1
0 1
1
257
2
8 0
0 0
1
255
2
7 0
0 0
end_DTG
begin_DTG
6
6
180
2
2 0
3 1
6
181
2
2 0
3 2
7
216
2
1 0
4 1
7
217
2
1 0
4 2
8
252
2
0 0
5 1
8
253
2
0 0
5 2
6
6
186
2
2 1
3 1
6
187
2
2 1
3 2
7
222
2
1 1
4 1
7
223
2
1 1
4 2
8
258
2
0 1
5 1
8
259
2
0 1
5 2
6
6
192
2
2 2
3 1
6
193
2
2 2
3 2
7
228
2
1 2
4 1
7
229
2
1 2
4 2
8
264
2
0 2
5 1
8
265
2
0 2
5 2
6
6
198
2
2 3
3 1
6
199
2
2 3
3 2
7
234
2
1 3
4 1
7
235
2
1 3
4 2
8
270
2
0 3
5 1
8
271
2
0 3
5 2
6
6
204
2
2 4
3 1
6
205
2
2 4
3 2
7
240
2
1 4
4 1
7
241
2
1 4
4 2
8
276
2
0 4
5 1
8
277
2
0 4
5 2
6
6
210
2
2 5
3 1
6
211
2
2 5
3 2
7
246
2
1 5
4 1
7
247
2
1 5
4 2
8
282
2
0 5
5 1
8
283
2
0 5
5 2
12
0
72
2
2 0
3 0
0
73
2
2 0
3 1
1
78
2
2 1
3 0
1
79
2
2 1
3 1
2
84
2
2 2
3 0
2
85
2
2 2
3 1
3
90
2
2 3
3 0
3
91
2
2 3
3 1
4
96
2
2 4
3 0
4
97
2
2 4
3 1
5
102
2
2 5
3 0
5
103
2
2 5
3 1
12
0
108
2
1 0
4 0
0
109
2
1 0
4 1
1
114
2
1 1
4 0
1
115
2
1 1
4 1
2
120
2
1 2
4 0
2
121
2
1 2
4 1
3
126
2
1 3
4 0
3
127
2
1 3
4 1
4
132
2
1 4
4 0
4
133
2
1 4
4 1
5
138
2
1 5
4 0
5
139
2
1 5
4 1
12
0
144
2
0 0
5 0
0
145
2
0 0
5 1
1
150
2
0 1
5 0
1
151
2
0 1
5 1
2
156
2
0 2
5 0
2
157
2
0 2
5 1
3
162
2
0 3
5 0
3
163
2
0 3
5 1
4
168
2
0 4
5 0
4
169
2
0 4
5 1
5
174
2
0 5
5 0
5
175
2
0 5
5 1
end_DTG
begin_DTG
6
6
182
2
2 0
3 1
6
183
2
2 0
3 2
7
218
2
1 0
4 1
7
219
2
1 0
4 2
8
254
2
0 0
5 1
8
255
2
0 0
5 2
6
6
188
2
2 1
3 1
6
189
2
2 1
3 2
7
224
2
1 1
4 1
7
225
2
1 1
4 2
8
260
2
0 1
5 1
8
261
2
0 1
5 2
6
6
194
2
2 2
3 1
6
195
2
2 2
3 2
7
230
2
1 2
4 1
7
231
2
1 2
4 2
8
266
2
0 2
5 1
8
267
2
0 2
5 2
6
6
200
2
2 3
3 1
6
201
2
2 3
3 2
7
236
2
1 3
4 1
7
237
2
1 3
4 2
8
272
2
0 3
5 1
8
273
2
0 3
5 2
6
6
206
2
2 4
3 1
6
207
2
2 4
3 2
7
242
2
1 4
4 1
7
243
2
1 4
4 2
8
278
2
0 4
5 1
8
279
2
0 4
5 2
6
6
212
2
2 5
3 1
6
213
2
2 5
3 2
7
248
2
1 5
4 1
7
249
2
1 5
4 2
8
284
2
0 5
5 1
8
285
2
0 5
5 2
12
0
74
2
2 0
3 0
0
75
2
2 0
3 1
1
80
2
2 1
3 0
1
81
2
2 1
3 1
2
86
2
2 2
3 0
2
87
2
2 2
3 1
3
92
2
2 3
3 0
3
93
2
2 3
3 1
4
98
2
2 4
3 0
4
99
2
2 4
3 1
5
104
2
2 5
3 0
5
105
2
2 5
3 1
12
0
110
2
1 0
4 0
0
111
2
1 0
4 1
1
116
2
1 1
4 0
1
117
2
1 1
4 1
2
122
2
1 2
4 0
2
123
2
1 2
4 1
3
128
2
1 3
4 0
3
129
2
1 3
4 1
4
134
2
1 4
4 0
4
135
2
1 4
4 1
5
140
2
1 5
4 0
5
141
2
1 5
4 1
12
0
146
2
0 0
5 0
0
147
2
0 0
5 1
1
152
2
0 1
5 0
1
153
2
0 1
5 1
2
158
2
0 2
5 0
2
159
2
0 2
5 1
3
164
2
0 3
5 0
3
165
2
0 3
5 1
4
170
2
0 4
5 0
4
171
2
0 4
5 1
5
176
2
0 5
5 0
5
177
2
0 5
5 1
end_DTG
begin_DTG
6
6
184
2
2 0
3 1
6
185
2
2 0
3 2
7
220
2
1 0
4 1
7
221
2
1 0
4 2
8
256
2
0 0
5 1
8
257
2
0 0
5 2
6
6
190
2
2 1
3 1
6
191
2
2 1
3 2
7
226
2
1 1
4 1
7
227
2
1 1
4 2
8
262
2
0 1
5 1
8
263
2
0 1
5 2
6
6
196
2
2 2
3 1
6
197
2
2 2
3 2
7
232
2
1 2
4 1
7
233
2
1 2
4 2
8
268
2
0 2
5 1
8
269
2
0 2
5 2
6
6
202
2
2 3
3 1
6
203
2
2 3
3 2
7
238
2
1 3
4 1
7
239
2
1 3
4 2
8
274
2
0 3
5 1
8
275
2
0 3
5 2
6
6
208
2
2 4
3 1
6
209
2
2 4
3 2
7
244
2
1 4
4 1
7
245
2
1 4
4 2
8
280
2
0 4
5 1
8
281
2
0 4
5 2
6
6
214
2
2 5
3 1
6
215
2
2 5
3 2
7
250
2
1 5
4 1
7
251
2
1 5
4 2
8
286
2
0 5
5 1
8
287
2
0 5
5 2
12
0
76
2
2 0
3 0
0
77
2
2 0
3 1
1
82
2
2 1
3 0
1
83
2
2 1
3 1
2
88
2
2 2
3 0
2
89
2
2 2
3 1
3
94
2
2 3
3 0
3
95
2
2 3
3 1
4
100
2
2 4
3 0
4
101
2
2 4
3 1
5
106
2
2 5
3 0
5
107
2
2 5
3 1
12
0
112
2
1 0
4 0
0
113
2
1 0
4 1
1
118
2
1 1
4 0
1
119
2
1 1
4 1
2
124
2
1 2
4 0
2
125
2
1 2
4 1
3
130
2
1 3
4 0
3
131
2
1 3
4 1
4
136
2
1 4
4 0
4
137
2
1 4
4 1
5
142
2
1 5
4 0
5
143
2
1 5
4 1
12
0
148
2
0 0
5 0
0
149
2
0 0
5 1
1
154
2
0 1
5 0
1
155
2
0 1
5 1
2
160
2
0 2
5 0
2
161
2
0 2
5 1
3
166
2
0 3
5 0
3
167
2
0 3
5 1
4
172
2
0 4
5 0
4
173
2
0 4
5 1
5
178
2
0 5
5 0
5
179
2
0 5
5 1
end_DTG
begin_CG
4
6 24
7 24
8 24
5 72
4
6 24
7 24
8 24
4 72
4
6 24
7 24
8 24
3 72
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
6 24
7 24
8 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
3
3 24
4 24
5 24
end_CG
