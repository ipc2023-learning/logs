begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var5
-1
7
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
end_variable
begin_variable
var4
-1
7
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
end_variable
begin_variable
var3
-1
7
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
end_variable
begin_variable
var6
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var7
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
10
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
10
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
10
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
0
begin_state
0
5
2
1
1
2
0
1
6
end_state
begin_goal
3
6 5
7 4
8 5
end_goal
306
begin_operator
drive v1 l1 l2
0
1
0 2 0 1
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 2 0 6
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 2 1 0
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 2 2 4
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 2 2 6
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 2 4 2
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 2 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 2 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 2 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 2 6 2
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 1 0 5
0
end_operator
begin_operator
drive v2 l1 l7
0
1
0 1 0 6
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 1 1 6
0
end_operator
begin_operator
drive v2 l3 l5
0
1
0 1 2 4
0
end_operator
begin_operator
drive v2 l3 l7
0
1
0 1 2 6
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l3
0
1
0 1 4 2
0
end_operator
begin_operator
drive v2 l6 l1
0
1
0 1 5 0
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 1 5 1
0
end_operator
begin_operator
drive v2 l7 l1
0
1
0 1 6 0
0
end_operator
begin_operator
drive v2 l7 l2
0
1
0 1 6 1
0
end_operator
begin_operator
drive v2 l7 l3
0
1
0 1 6 2
0
end_operator
begin_operator
drive v3 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l6
0
1
0 0 0 5
0
end_operator
begin_operator
drive v3 l1 l7
0
1
0 0 0 6
0
end_operator
begin_operator
drive v3 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drive v3 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v3 l2 l6
0
1
0 0 1 5
0
end_operator
begin_operator
drive v3 l2 l7
0
1
0 0 1 6
0
end_operator
begin_operator
drive v3 l3 l5
0
1
0 0 2 4
0
end_operator
begin_operator
drive v3 l3 l7
0
1
0 0 2 6
0
end_operator
begin_operator
drive v3 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drive v3 l5 l1
0
1
0 0 4 0
0
end_operator
begin_operator
drive v3 l5 l3
0
1
0 0 4 2
0
end_operator
begin_operator
drive v3 l6 l1
0
1
0 0 5 0
0
end_operator
begin_operator
drive v3 l6 l2
0
1
0 0 5 1
0
end_operator
begin_operator
drive v3 l7 l1
0
1
0 0 6 0
0
end_operator
begin_operator
drive v3 l7 l2
0
1
0 0 6 1
0
end_operator
begin_operator
drive v3 l7 l3
0
1
0 0 6 2
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
2 0
2
0 6 7 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
2 0
2
0 6 7 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p2 c0 c1
1
2 0
2
0 7 7 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p2 c1 c2
1
2 0
2
0 7 7 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l1 p3 c0 c1
1
2 0
2
0 8 7 0
0 3 0 1
0
end_operator
begin_operator
drop v1 l1 p3 c1 c2
1
2 0
2
0 8 7 0
0 3 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
2 1
2
0 6 7 1
0 3 0 1
0
end_operator
begin_operator
drop v1 l2 p1 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
288
2
6 4
0 4
0
290
2
7 4
0 4
0
292
2
8 4
0 4
0
294
2
6 5
0 5
0
296
2
7 5
0 5
0
298
2
8 5
0 5
0
300
2
6 6
0 6
0
302
2
7 6
0 6
0
304
2
8 6
0 6
2
161
2
8 9
0 3
2
141
2
7 9
0 0
2
143
2
8 9
0 0
2
145
2
6 9
0 1
2
147
2
7 9
0 1
2
149
2
8 9
0 1
2
151
2
6 9
0 2
2
153
2
7 9
0 2
2
155
2
8 9
0 2
2
157
2
6 9
0 3
2
159
2
7 9
0 3
2
139
2
6 9
0 0
2
163
2
6 9
0 4
2
165
2
7 9
0 4
2
167
2
8 9
0 4
2
169
2
6 9
0 5
2
171
2
7 9
0 5
2
173
2
8 9
0 5
2
175
2
6 9
0 6
2
177
2
7 9
0 6
2
179
2
8 9
0 6
21
1
285
2
7 3
0 3
1
305
2
8 6
0 6
1
303
2
7 6
0 6
1
301
2
6 6
0 6
1
299
2
8 5
0 5
1
297
2
7 5
0 5
1
295
2
6 5
0 5
1
293
2
8 4
0 4
1
291
2
7 4
0 4
1
289
2
6 4
0 4
1
287
2
8 3
0 3
1
265
2
6 0
0 0
1
283
2
6 3
0 3
1
281
2
8 2
0 2
1
279
2
7 2
0 2
1
277
2
6 2
0 2
1
275
2
8 1
0 1
1
273
2
7 1
0 1
1
271
2
6 1
0 1
1
269
2
8 0
0 0
1
267
2
7 0
0 0
end_DTG
begin_DTG
6
7
180
2
2 0
3 1
7
181
2
2 0
3 2
8
222
2
1 0
4 1
8
223
2
1 0
4 2
9
264
2
0 0
5 1
9
265
2
0 0
5 2
6
7
186
2
2 1
3 1
7
187
2
2 1
3 2
8
228
2
1 1
4 1
8
229
2
1 1
4 2
9
270
2
0 1
5 1
9
271
2
0 1
5 2
6
7
192
2
2 2
3 1
7
193
2
2 2
3 2
8
234
2
1 2
4 1
8
235
2
1 2
4 2
9
276
2
0 2
5 1
9
277
2
0 2
5 2
6
7
198
2
2 3
3 1
7
199
2
2 3
3 2
8
240
2
1 3
4 1
8
241
2
1 3
4 2
9
282
2
0 3
5 1
9
283
2
0 3
5 2
6
7
204
2
2 4
3 1
7
205
2
2 4
3 2
8
246
2
1 4
4 1
8
247
2
1 4
4 2
9
288
2
0 4
5 1
9
289
2
0 4
5 2
6
7
210
2
2 5
3 1
7
211
2
2 5
3 2
8
252
2
1 5
4 1
8
253
2
1 5
4 2
9
294
2
0 5
5 1
9
295
2
0 5
5 2
6
7
216
2
2 6
3 1
7
217
2
2 6
3 2
8
258
2
1 6
4 1
8
259
2
1 6
4 2
9
300
2
0 6
5 1
9
301
2
0 6
5 2
14
0
54
2
2 0
3 0
0
55
2
2 0
3 1
1
60
2
2 1
3 0
1
61
2
2 1
3 1
2
66
2
2 2
3 0
2
67
2
2 2
3 1
3
72
2
2 3
3 0
3
73
2
2 3
3 1
4
78
2
2 4
3 0
4
79
2
2 4
3 1
5
84
2
2 5
3 0
5
85
2
2 5
3 1
6
90
2
2 6
3 0
6
91
2
2 6
3 1
14
0
96
2
1 0
4 0
0
97
2
1 0
4 1
1
102
2
1 1
4 0
1
103
2
1 1
4 1
2
108
2
1 2
4 0
2
109
2
1 2
4 1
3
114
2
1 3
4 0
3
115
2
1 3
4 1
4
120
2
1 4
4 0
4
121
2
1 4
4 1
5
126
2
1 5
4 0
5
127
2
1 5
4 1
6
132
2
1 6
4 0
6
133
2
1 6
4 1
14
0
138
2
0 0
5 0
0
139
2
0 0
5 1
1
144
2
0 1
5 0
1
145
2
0 1
5 1
2
150
2
0 2
5 0
2
151
2
0 2
5 1
3
156
2
0 3
5 0
3
157
2
0 3
5 1
4
162
2
0 4
5 0
4
163
2
0 4
5 1
5
168
2
0 5
5 0
5
169
2
0 5
5 1
6
174
2
0 6
5 0
6
175
2
0 6
5 1
end_DTG
begin_DTG
6
7
182
2
2 0
3 1
7
183
2
2 0
3 2
8
224
2
1 0
4 1
8
225
2
1 0
4 2
9
266
2
0 0
5 1
9
267
2
0 0
5 2
6
7
188
2
2 1
3 1
7
189
2
2 1
3 2
8
230
2
1 1
4 1
8
231
2
1 1
4 2
9
272
2
0 1
5 1
9
273
2
0 1
5 2
6
7
194
2
2 2
3 1
7
195
2
2 2
3 2
8
236
2
1 2
4 1
8
237
2
1 2
4 2
9
278
2
0 2
5 1
9
279
2
0 2
5 2
6
7
200
2
2 3
3 1
7
201
2
2 3
3 2
8
242
2
1 3
4 1
8
243
2
1 3
4 2
9
284
2
0 3
5 1
9
285
2
0 3
5 2
6
7
206
2
2 4
3 1
7
207
2
2 4
3 2
8
248
2
1 4
4 1
8
249
2
1 4
4 2
9
290
2
0 4
5 1
9
291
2
0 4
5 2
6
7
212
2
2 5
3 1
7
213
2
2 5
3 2
8
254
2
1 5
4 1
8
255
2
1 5
4 2
9
296
2
0 5
5 1
9
297
2
0 5
5 2
6
7
218
2
2 6
3 1
7
219
2
2 6
3 2
8
260
2
1 6
4 1
8
261
2
1 6
4 2
9
302
2
0 6
5 1
9
303
2
0 6
5 2
14
0
56
2
2 0
3 0
0
57
2
2 0
3 1
1
62
2
2 1
3 0
1
63
2
2 1
3 1
2
68
2
2 2
3 0
2
69
2
2 2
3 1
3
74
2
2 3
3 0
3
75
2
2 3
3 1
4
80
2
2 4
3 0
4
81
2
2 4
3 1
5
86
2
2 5
3 0
5
87
2
2 5
3 1
6
92
2
2 6
3 0
6
93
2
2 6
3 1
14
0
98
2
1 0
4 0
0
99
2
1 0
4 1
1
104
2
1 1
4 0
1
105
2
1 1
4 1
2
110
2
1 2
4 0
2
111
2
1 2
4 1
3
116
2
1 3
4 0
3
117
2
1 3
4 1
4
122
2
1 4
4 0
4
123
2
1 4
4 1
5
128
2
1 5
4 0
5
129
2
1 5
4 1
6
134
2
1 6
4 0
6
135
2
1 6
4 1
14
0
140
2
0 0
5 0
0
141
2
0 0
5 1
1
146
2
0 1
5 0
1
147
2
0 1
5 1
2
152
2
0 2
5 0
2
153
2
0 2
5 1
3
158
2
0 3
5 0
3
159
2
0 3
5 1
4
164
2
0 4
5 0
4
165
2
0 4
5 1
5
170
2
0 5
5 0
5
171
2
0 5
5 1
6
176
2
0 6
5 0
6
177
2
0 6
5 1
end_DTG
begin_DTG
6
7
184
2
2 0
3 1
7
185
2
2 0
3 2
8
226
2
1 0
4 1
8
227
2
1 0
4 2
9
268
2
0 0
5 1
9
269
2
0 0
5 2
6
7
190
2
2 1
3 1
7
191
2
2 1
3 2
8
232
2
1 1
4 1
8
233
2
1 1
4 2
9
274
2
0 1
5 1
9
275
2
0 1
5 2
6
7
196
2
2 2
3 1
7
197
2
2 2
3 2
8
238
2
1 2
4 1
8
239
2
1 2
4 2
9
280
2
0 2
5 1
9
281
2
0 2
5 2
6
7
202
2
2 3
3 1
7
203
2
2 3
3 2
8
244
2
1 3
4 1
8
245
2
1 3
4 2
9
286
2
0 3
5 1
9
287
2
0 3
5 2
6
7
208
2
2 4
3 1
7
209
2
2 4
3 2
8
250
2
1 4
4 1
8
251
2
1 4
4 2
9
292
2
0 4
5 1
9
293
2
0 4
5 2
6
7
214
2
2 5
3 1
7
215
2
2 5
3 2
8
256
2
1 5
4 1
8
257
2
1 5
4 2
9
298
2
0 5
5 1
9
299
2
0 5
5 2
6
7
220
2
2 6
3 1
7
221
2
2 6
3 2
8
262
2
1 6
4 1
8
263
2
1 6
4 2
9
304
2
0 6
5 1
9
305
2
0 6
5 2
14
0
58
2
2 0
3 0
0
59
2
2 0
3 1
1
64
2
2 1
3 0
1
65
2
2 1
3 1
2
70
2
2 2
3 0
2
71
2
2 2
3 1
3
76
2
2 3
3 0
3
77
2
2 3
3 1
4
82
2
2 4
3 0
4
83
2
2 4
3 1
5
88
2
2 5
3 0
5
89
2
2 5
3 1
6
94
2
2 6
3 0
6
95
2
2 6
3 1
14
0
100
2
1 0
4 0
0
101
2
1 0
4 1
1
106
2
1 1
4 0
1
107
2
1 1
4 1
2
112
2
1 2
4 0
2
113
2
1 2
4 1
3
118
2
1 3
4 0
3
119
2
1 3
4 1
4
124
2
1 4
4 0
4
125
2
1 4
4 1
5
130
2
1 5
4 0
5
131
2
1 5
4 1
6
136
2
1 6
4 0
6
137
2
1 6
4 1
14
0
142
2
0 0
5 0
0
143
2
0 0
5 1
1
148
2
0 1
5 0
1
149
2
0 1
5 1
2
154
2
0 2
5 0
2
155
2
0 2
5 1
3
160
2
0 3
5 0
3
161
2
0 3
5 1
4
166
2
0 4
5 0
4
167
2
0 4
5 1
5
172
2
0 5
5 0
5
173
2
0 5
5 1
6
178
2
0 6
5 0
6
179
2
0 6
5 1
end_DTG
begin_CG
4
6 28
7 28
8 28
5 84
4
6 28
7 28
8 28
4 84
4
6 28
7 28
8 28
3 84
3
6 28
7 28
8 28
3
6 28
7 28
8 28
3
6 28
7 28
8 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
end_CG
