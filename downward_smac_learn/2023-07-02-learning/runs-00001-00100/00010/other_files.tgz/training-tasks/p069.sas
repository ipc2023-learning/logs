begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var17
-1
13
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var16
-1
13
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var15
-1
13
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var14
-1
13
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var13
-1
13
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var12
-1
13
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var18
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
19
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
19
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
19
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
19
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
19
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var5
-1
19
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var6
-1
19
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
Atom in(p4, v6)
end_variable
begin_variable
var7
-1
19
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l13)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
Atom in(p5, v6)
end_variable
begin_variable
var8
-1
19
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
1 8
10 1
17
3851
2
1 8
10 2
18
4162
2
0 8
11 1
18
4163
2
0 8
11 2
12
13
2626
2
5 9
6 1
13
2627
2
5 9
6 2
14
2938
2
4 9
7 1
14
2939
2
4 9
7 2
15
3250
2
3 9
8 1
15
3251
2
3 9
8 2
16
3562
2
2 9
9 1
16
3563
2
2 9
9 2
17
3874
2
1 9
10 1
17
3875
2
1 9
10 2
18
4186
2
0 9
11 1
18
4187
2
0 9
11 2
12
13
2650
2
5 10
6 1
13
2651
2
5 10
6 2
14
2962
2
4 10
7 1
14
2963
2
4 10
7 2
15
3274
2
3 10
8 1
15
3275
2
3 10
8 2
16
3586
2
2 10
9 1
16
3587
2
2 10
9 2
17
3898
2
1 10
10 1
17
3899
2
1 10
10 2
18
4210
2
0 10
11 1
18
4211
2
0 10
11 2
12
13
2674
2
5 11
6 1
13
2675
2
5 11
6 2
14
2986
2
4 11
7 1
14
2987
2
4 11
7 2
15
3298
2
3 11
8 1
15
3299
2
3 11
8 2
16
3610
2
2 11
9 1
16
3611
2
2 11
9 2
17
3922
2
1 11
10 1
17
3923
2
1 11
10 2
18
4234
2
0 11
11 1
18
4235
2
0 11
11 2
12
13
2698
2
5 12
6 1
13
2699
2
5 12
6 2
14
3010
2
4 12
7 1
14
3011
2
4 12
7 2
15
3322
2
3 12
8 1
15
3323
2
3 12
8 2
16
3634
2
2 12
9 1
16
3635
2
2 12
9 2
17
3946
2
1 12
10 1
17
3947
2
1 12
10 2
18
4258
2
0 12
11 1
18
4259
2
0 12
11 2
26
0
539
2
5 0
6 1
0
538
2
5 0
6 0
1
562
2
5 1
6 0
1
563
2
5 1
6 1
2
586
2
5 2
6 0
2
587
2
5 2
6 1
3
610
2
5 3
6 0
3
611
2
5 3
6 1
4
634
2
5 4
6 0
4
635
2
5 4
6 1
5
658
2
5 5
6 0
5
659
2
5 5
6 1
6
683
2
5 6
6 1
6
682
2
5 6
6 0
7
706
2
5 7
6 0
7
707
2
5 7
6 1
8
730
2
5 8
6 0
8
731
2
5 8
6 1
9
754
2
5 9
6 0
9
755
2
5 9
6 1
10
778
2
5 10
6 0
10
779
2
5 10
6 1
11
802
2
5 11
6 0
11
803
2
5 11
6 1
12
826
2
5 12
6 0
12
827
2
5 12
6 1
26
0
851
2
4 0
7 1
0
850
2
4 0
7 0
1
874
2
4 1
7 0
1
875
2
4 1
7 1
2
898
2
4 2
7 0
2
899
2
4 2
7 1
3
922
2
4 3
7 0
3
923
2
4 3
7 1
4
946
2
4 4
7 0
4
947
2
4 4
7 1
5
970
2
4 5
7 0
5
971
2
4 5
7 1
6
995
2
4 6
7 1
6
994
2
4 6
7 0
7
1018
2
4 7
7 0
7
1019
2
4 7
7 1
8
1042
2
4 8
7 0
8
1043
2
4 8
7 1
9
1066
2
4 9
7 0
9
1067
2
4 9
7 1
10
1090
2
4 10
7 0
10
1091
2
4 10
7 1
11
1114
2
4 11
7 0
11
1115
2
4 11
7 1
12
1138
2
4 12
7 0
12
1139
2
4 12
7 1
26
0
1163
2
3 0
8 1
0
1162
2
3 0
8 0
1
1186
2
3 1
8 0
1
1187
2
3 1
8 1
2
1210
2
3 2
8 0
2
1211
2
3 2
8 1
3
1234
2
3 3
8 0
3
1235
2
3 3
8 1
4
1258
2
3 4
8 0
4
1259
2
3 4
8 1
5
1282
2
3 5
8 0
5
1283
2
3 5
8 1
6
1307
2
3 6
8 1
6
1306
2
3 6
8 0
7
1330
2
3 7
8 0
7
1331
2
3 7
8 1
8
1354
2
3 8
8 0
8
1355
2
3 8
8 1
9
1378
2
3 9
8 0
9
1379
2
3 9
8 1
10
1402
2
3 10
8 0
10
1403
2
3 10
8 1
11
1426
2
3 11
8 0
11
1427
2
3 11
8 1
12
1450
2
3 12
8 0
12
1451
2
3 12
8 1
26
0
1475
2
2 0
9 1
0
1474
2
2 0
9 0
1
1498
2
2 1
9 0
1
1499
2
2 1
9 1
2
1522
2
2 2
9 0
2
1523
2
2 2
9 1
3
1546
2
2 3
9 0
3
1547
2
2 3
9 1
4
1570
2
2 4
9 0
4
1571
2
2 4
9 1
5
1594
2
2 5
9 0
5
1595
2
2 5
9 1
6
1619
2
2 6
9 1
6
1618
2
2 6
9 0
7
1642
2
2 7
9 0
7
1643
2
2 7
9 1
8
1666
2
2 8
9 0
8
1667
2
2 8
9 1
9
1690
2
2 9
9 0
9
1691
2
2 9
9 1
10
1714
2
2 10
9 0
10
1715
2
2 10
9 1
11
1738
2
2 11
9 0
11
1739
2
2 11
9 1
12
1762
2
2 12
9 0
12
1763
2
2 12
9 1
26
0
1787
2
1 0
10 1
0
1786
2
1 0
10 0
1
1810
2
1 1
10 0
1
1811
2
1 1
10 1
2
1834
2
1 2
10 0
2
1835
2
1 2
10 1
3
1858
2
1 3
10 0
3
1859
2
1 3
10 1
4
1882
2
1 4
10 0
4
1883
2
1 4
10 1
5
1906
2
1 5
10 0
5
1907
2
1 5
10 1
6
1931
2
1 6
10 1
6
1930
2
1 6
10 0
7
1954
2
1 7
10 0
7
1955
2
1 7
10 1
8
1978
2
1 8
10 0
8
1979
2
1 8
10 1
9
2002
2
1 9
10 0
9
2003
2
1 9
10 1
10
2026
2
1 10
10 0
10
2027
2
1 10
10 1
11
2050
2
1 11
10 0
11
2051
2
1 11
10 1
12
2074
2
1 12
10 0
12
2075
2
1 12
10 1
26
0
2099
2
0 0
11 1
0
2098
2
0 0
11 0
1
2122
2
0 1
11 0
1
2123
2
0 1
11 1
2
2146
2
0 2
11 0
2
2147
2
0 2
11 1
3
2170
2
0 3
11 0
3
2171
2
0 3
11 1
4
2194
2
0 4
11 0
4
2195
2
0 4
11 1
5
2218
2
0 5
11 0
5
2219
2
0 5
11 1
6
2243
2
0 6
11 1
6
2242
2
0 6
11 0
7
2266
2
0 7
11 0
7
2267
2
0 7
11 1
8
2290
2
0 8
11 0
8
2291
2
0 8
11 1
9
2314
2
0 9
11 0
9
2315
2
0 9
11 1
10
2338
2
0 10
11 0
10
2339
2
0 10
11 1
11
2362
2
0 11
11 0
11
2363
2
0 11
11 1
12
2386
2
0 12
11 0
12
2387
2
0 12
11 1
end_DTG
begin_CG
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
11 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
10 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
9 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
8 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
7 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
6 624
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
end_CG
