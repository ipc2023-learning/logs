begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var23
-1
16
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var22
-1
16
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var21
-1
16
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var20
-1
16
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var19
-1
16
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var18
-1
16
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var17
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var24
-1
4
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
Atom capacity(v1, c3)
end_variable
begin_variable
var25
-1
4
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
Atom capacity(v2, c3)
end_variable
begin_variable
var26
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var27
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var28
-1
4
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
Atom capacity(v5, c3)
end_variable
begin_variable
var29
-1
4
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
Atom capacity(v6, c3)
end_variable
begin_variable
var30
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var0
-1
23
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var1
-1
23
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var2
-1
23
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var3
-1
23
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var4
-1
23
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l16)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
10 0
13
3776
2
3 13
10 1
13
3777
2
3 13
10 2
14
3826
2
3 14
10 0
14
3827
2
3 14
10 1
14
3828
2
3 14
10 2
15
3877
2
3 15
10 0
15
3878
2
3 15
10 1
15
3879
2
3 15
10 2
48
0
3929
2
2 0
11 1
0
3930
2
2 0
11 2
0
3928
2
2 0
11 0
1
3979
2
2 1
11 0
1
3980
2
2 1
11 1
1
3981
2
2 1
11 2
2
4030
2
2 2
11 0
2
4031
2
2 2
11 1
2
4032
2
2 2
11 2
3
4081
2
2 3
11 0
3
4082
2
2 3
11 1
3
4083
2
2 3
11 2
4
4133
2
2 4
11 1
4
4134
2
2 4
11 2
4
4132
2
2 4
11 0
5
4183
2
2 5
11 0
5
4184
2
2 5
11 1
5
4185
2
2 5
11 2
6
4234
2
2 6
11 0
6
4235
2
2 6
11 1
6
4236
2
2 6
11 2
7
4285
2
2 7
11 0
7
4286
2
2 7
11 1
7
4287
2
2 7
11 2
8
4336
2
2 8
11 0
8
4338
2
2 8
11 2
8
4337
2
2 8
11 1
9
4387
2
2 9
11 0
9
4388
2
2 9
11 1
9
4389
2
2 9
11 2
10
4438
2
2 10
11 0
10
4439
2
2 10
11 1
10
4440
2
2 10
11 2
11
4489
2
2 11
11 0
11
4490
2
2 11
11 1
11
4491
2
2 11
11 2
12
4541
2
2 12
11 1
12
4542
2
2 12
11 2
12
4540
2
2 12
11 0
13
4591
2
2 13
11 0
13
4592
2
2 13
11 1
13
4593
2
2 13
11 2
14
4642
2
2 14
11 0
14
4643
2
2 14
11 1
14
4644
2
2 14
11 2
15
4693
2
2 15
11 0
15
4694
2
2 15
11 1
15
4695
2
2 15
11 2
48
0
4745
2
1 0
12 1
0
4746
2
1 0
12 2
0
4744
2
1 0
12 0
1
4795
2
1 1
12 0
1
4796
2
1 1
12 1
1
4797
2
1 1
12 2
2
4846
2
1 2
12 0
2
4847
2
1 2
12 1
2
4848
2
1 2
12 2
3
4897
2
1 3
12 0
3
4898
2
1 3
12 1
3
4899
2
1 3
12 2
4
4949
2
1 4
12 1
4
4950
2
1 4
12 2
4
4948
2
1 4
12 0
5
4999
2
1 5
12 0
5
5000
2
1 5
12 1
5
5001
2
1 5
12 2
6
5050
2
1 6
12 0
6
5051
2
1 6
12 1
6
5052
2
1 6
12 2
7
5101
2
1 7
12 0
7
5102
2
1 7
12 1
7
5103
2
1 7
12 2
8
5152
2
1 8
12 0
8
5154
2
1 8
12 2
8
5153
2
1 8
12 1
9
5203
2
1 9
12 0
9
5204
2
1 9
12 1
9
5205
2
1 9
12 2
10
5254
2
1 10
12 0
10
5255
2
1 10
12 1
10
5256
2
1 10
12 2
11
5305
2
1 11
12 0
11
5306
2
1 11
12 1
11
5307
2
1 11
12 2
12
5357
2
1 12
12 1
12
5358
2
1 12
12 2
12
5356
2
1 12
12 0
13
5407
2
1 13
12 0
13
5408
2
1 13
12 1
13
5409
2
1 13
12 2
14
5458
2
1 14
12 0
14
5459
2
1 14
12 1
14
5460
2
1 14
12 2
15
5509
2
1 15
12 0
15
5510
2
1 15
12 1
15
5511
2
1 15
12 2
48
0
5561
2
0 0
13 1
0
5562
2
0 0
13 2
0
5560
2
0 0
13 0
1
5611
2
0 1
13 0
1
5612
2
0 1
13 1
1
5613
2
0 1
13 2
2
5662
2
0 2
13 0
2
5663
2
0 2
13 1
2
5664
2
0 2
13 2
3
5713
2
0 3
13 0
3
5714
2
0 3
13 1
3
5715
2
0 3
13 2
4
5765
2
0 4
13 1
4
5766
2
0 4
13 2
4
5764
2
0 4
13 0
5
5815
2
0 5
13 0
5
5816
2
0 5
13 1
5
5817
2
0 5
13 2
6
5866
2
0 6
13 0
6
5867
2
0 6
13 1
6
5868
2
0 6
13 2
7
5917
2
0 7
13 0
7
5918
2
0 7
13 1
7
5919
2
0 7
13 2
8
5968
2
0 8
13 0
8
5970
2
0 8
13 2
8
5969
2
0 8
13 1
9
6019
2
0 9
13 0
9
6020
2
0 9
13 1
9
6021
2
0 9
13 2
10
6070
2
0 10
13 0
10
6071
2
0 10
13 1
10
6072
2
0 10
13 2
11
6121
2
0 11
13 0
11
6122
2
0 11
13 1
11
6123
2
0 11
13 2
12
6173
2
0 12
13 1
12
6174
2
0 12
13 2
12
6172
2
0 12
13 0
13
6223
2
0 13
13 0
13
6224
2
0 13
13 1
13
6225
2
0 13
13 2
14
6274
2
0 14
13 0
14
6275
2
0 14
13 1
14
6276
2
0 14
13 2
15
6325
2
0 15
13 0
15
6326
2
0 15
13 1
15
6327
2
0 15
13 2
end_DTG
begin_CG
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
13 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
12 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
11 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
10 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
9 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
8 1632
18
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
7 1632
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
17
14 96
15 96
16 96
17 96
18 96
19 96
20 96
21 96
22 96
23 96
24 96
25 96
26 96
27 96
28 96
29 96
30 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
7
7 96
8 96
9 96
10 96
11 96
12 96
13 96
end_CG
