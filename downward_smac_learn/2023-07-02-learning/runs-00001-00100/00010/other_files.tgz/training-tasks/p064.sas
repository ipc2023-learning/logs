begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var15
-1
12
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var14
-1
12
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var13
-1
12
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var12
-1
12
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var11
-1
12
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var16
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
17
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
17
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
17
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
end_variable
begin_variable
var3
-1
17
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var4
-1
17
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var5
-1
17
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var6
-1
17
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var7
-1
17
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var8
-1
17
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var9
-1
17
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var10
-1
17
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l12)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
2
4 1
5 1
12
1923
2
4 1
5 2
13
2186
2
3 1
6 1
13
2187
2
3 1
6 2
14
2450
2
2 1
7 1
14
2451
2
2 1
7 2
15
2714
2
1 1
8 1
15
2715
2
1 1
8 2
16
2978
2
0 1
9 1
16
2979
2
0 1
9 2
10
12
1944
2
4 2
5 1
12
1945
2
4 2
5 2
13
2208
2
3 2
6 1
13
2209
2
3 2
6 2
14
2472
2
2 2
7 1
14
2473
2
2 2
7 2
15
2736
2
1 2
8 1
15
2737
2
1 2
8 2
16
3000
2
0 2
9 1
16
3001
2
0 2
9 2
10
12
1966
2
4 3
5 1
12
1967
2
4 3
5 2
13
2230
2
3 3
6 1
13
2231
2
3 3
6 2
14
2494
2
2 3
7 1
14
2495
2
2 3
7 2
15
2758
2
1 3
8 1
15
2759
2
1 3
8 2
16
3022
2
0 3
9 1
16
3023
2
0 3
9 2
10
12
1988
2
4 4
5 1
12
1989
2
4 4
5 2
13
2252
2
3 4
6 1
13
2253
2
3 4
6 2
14
2516
2
2 4
7 1
14
2517
2
2 4
7 2
15
2780
2
1 4
8 1
15
2781
2
1 4
8 2
16
3044
2
0 4
9 1
16
3045
2
0 4
9 2
10
12
2010
2
4 5
5 1
12
2011
2
4 5
5 2
13
2274
2
3 5
6 1
13
2275
2
3 5
6 2
14
2538
2
2 5
7 1
14
2539
2
2 5
7 2
15
2802
2
1 5
8 1
15
2803
2
1 5
8 2
16
3066
2
0 5
9 1
16
3067
2
0 5
9 2
10
12
2032
2
4 6
5 1
12
2033
2
4 6
5 2
13
2296
2
3 6
6 1
13
2297
2
3 6
6 2
14
2560
2
2 6
7 1
14
2561
2
2 6
7 2
15
2824
2
1 6
8 1
15
2825
2
1 6
8 2
16
3088
2
0 6
9 1
16
3089
2
0 6
9 2
10
12
2054
2
4 7
5 1
12
2055
2
4 7
5 2
13
2318
2
3 7
6 1
13
2319
2
3 7
6 2
14
2582
2
2 7
7 1
14
2583
2
2 7
7 2
15
2846
2
1 7
8 1
15
2847
2
1 7
8 2
16
3110
2
0 7
9 1
16
3111
2
0 7
9 2
10
12
2076
2
4 8
5 1
12
2077
2
4 8
5 2
13
2340
2
3 8
6 1
13
2341
2
3 8
6 2
14
2604
2
2 8
7 1
14
2605
2
2 8
7 2
15
2868
2
1 8
8 1
15
2869
2
1 8
8 2
16
3132
2
0 8
9 1
16
3133
2
0 8
9 2
10
12
2098
2
4 9
5 1
12
2099
2
4 9
5 2
13
2362
2
3 9
6 1
13
2363
2
3 9
6 2
14
2626
2
2 9
7 1
14
2627
2
2 9
7 2
15
2890
2
1 9
8 1
15
2891
2
1 9
8 2
16
3154
2
0 9
9 1
16
3155
2
0 9
9 2
10
12
2120
2
4 10
5 1
12
2121
2
4 10
5 2
13
2384
2
3 10
6 1
13
2385
2
3 10
6 2
14
2648
2
2 10
7 1
14
2649
2
2 10
7 2
15
2912
2
1 10
8 1
15
2913
2
1 10
8 2
16
3176
2
0 10
9 1
16
3177
2
0 10
9 2
10
12
2142
2
4 11
5 1
12
2143
2
4 11
5 2
13
2406
2
3 11
6 1
13
2407
2
3 11
6 2
14
2670
2
2 11
7 1
14
2671
2
2 11
7 2
15
2934
2
1 11
8 1
15
2935
2
1 11
8 2
16
3198
2
0 11
9 1
16
3199
2
0 11
9 2
24
0
581
2
4 0
5 1
0
580
2
4 0
5 0
1
602
2
4 1
5 0
1
603
2
4 1
5 1
2
624
2
4 2
5 0
2
625
2
4 2
5 1
3
646
2
4 3
5 0
3
647
2
4 3
5 1
4
668
2
4 4
5 0
4
669
2
4 4
5 1
5
690
2
4 5
5 0
5
691
2
4 5
5 1
6
712
2
4 6
5 0
6
713
2
4 6
5 1
7
734
2
4 7
5 0
7
735
2
4 7
5 1
8
756
2
4 8
5 0
8
757
2
4 8
5 1
9
778
2
4 9
5 0
9
779
2
4 9
5 1
10
800
2
4 10
5 0
10
801
2
4 10
5 1
11
822
2
4 11
5 0
11
823
2
4 11
5 1
24
0
845
2
3 0
6 1
0
844
2
3 0
6 0
1
866
2
3 1
6 0
1
867
2
3 1
6 1
2
888
2
3 2
6 0
2
889
2
3 2
6 1
3
910
2
3 3
6 0
3
911
2
3 3
6 1
4
932
2
3 4
6 0
4
933
2
3 4
6 1
5
954
2
3 5
6 0
5
955
2
3 5
6 1
6
976
2
3 6
6 0
6
977
2
3 6
6 1
7
998
2
3 7
6 0
7
999
2
3 7
6 1
8
1020
2
3 8
6 0
8
1021
2
3 8
6 1
9
1042
2
3 9
6 0
9
1043
2
3 9
6 1
10
1064
2
3 10
6 0
10
1065
2
3 10
6 1
11
1086
2
3 11
6 0
11
1087
2
3 11
6 1
24
0
1109
2
2 0
7 1
0
1108
2
2 0
7 0
1
1130
2
2 1
7 0
1
1131
2
2 1
7 1
2
1152
2
2 2
7 0
2
1153
2
2 2
7 1
3
1174
2
2 3
7 0
3
1175
2
2 3
7 1
4
1196
2
2 4
7 0
4
1197
2
2 4
7 1
5
1218
2
2 5
7 0
5
1219
2
2 5
7 1
6
1240
2
2 6
7 0
6
1241
2
2 6
7 1
7
1262
2
2 7
7 0
7
1263
2
2 7
7 1
8
1284
2
2 8
7 0
8
1285
2
2 8
7 1
9
1306
2
2 9
7 0
9
1307
2
2 9
7 1
10
1328
2
2 10
7 0
10
1329
2
2 10
7 1
11
1350
2
2 11
7 0
11
1351
2
2 11
7 1
24
0
1373
2
1 0
8 1
0
1372
2
1 0
8 0
1
1394
2
1 1
8 0
1
1395
2
1 1
8 1
2
1416
2
1 2
8 0
2
1417
2
1 2
8 1
3
1438
2
1 3
8 0
3
1439
2
1 3
8 1
4
1460
2
1 4
8 0
4
1461
2
1 4
8 1
5
1482
2
1 5
8 0
5
1483
2
1 5
8 1
6
1504
2
1 6
8 0
6
1505
2
1 6
8 1
7
1526
2
1 7
8 0
7
1527
2
1 7
8 1
8
1548
2
1 8
8 0
8
1549
2
1 8
8 1
9
1570
2
1 9
8 0
9
1571
2
1 9
8 1
10
1592
2
1 10
8 0
10
1593
2
1 10
8 1
11
1614
2
1 11
8 0
11
1615
2
1 11
8 1
24
0
1637
2
0 0
9 1
0
1636
2
0 0
9 0
1
1658
2
0 1
9 0
1
1659
2
0 1
9 1
2
1680
2
0 2
9 0
2
1681
2
0 2
9 1
3
1702
2
0 3
9 0
3
1703
2
0 3
9 1
4
1724
2
0 4
9 0
4
1725
2
0 4
9 1
5
1746
2
0 5
9 0
5
1747
2
0 5
9 1
6
1768
2
0 6
9 0
6
1769
2
0 6
9 1
7
1790
2
0 7
9 0
7
1791
2
0 7
9 1
8
1812
2
0 8
9 0
8
1813
2
0 8
9 1
9
1834
2
0 9
9 0
9
1835
2
0 9
9 1
10
1856
2
0 10
9 0
10
1857
2
0 10
9 1
11
1878
2
0 11
9 0
11
1879
2
0 11
9 1
end_DTG
begin_CG
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
9 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
8 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
7 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
6 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5 528
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
end_CG
