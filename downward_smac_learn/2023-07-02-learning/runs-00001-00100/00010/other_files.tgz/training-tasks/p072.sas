begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var17
-1
13
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var16
-1
13
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var15
-1
13
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var14
-1
13
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var13
-1
13
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var12
-1
13
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var18
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
19
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
19
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
19
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
19
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
19
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var5
-1
19
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
Atom in(p3, v6)
end_variable
begin_variable
var6
-1
19
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l13)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
Atom in(p4, v6)
end_variable
begin_variable
var7
-1
19
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l13)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
Atom in(p5, v6)
end_variable
begin_variable
var8
-1
19
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9 2
17
3706
2
1 8
10 1
17
3707
2
1 8
10 2
18
4018
2
0 8
11 1
18
4019
2
0 8
11 2
12
13
2482
2
5 9
6 1
13
2483
2
5 9
6 2
14
2794
2
4 9
7 1
14
2795
2
4 9
7 2
15
3106
2
3 9
8 1
15
3107
2
3 9
8 2
16
3418
2
2 9
9 1
16
3419
2
2 9
9 2
17
3730
2
1 9
10 1
17
3731
2
1 9
10 2
18
4042
2
0 9
11 1
18
4043
2
0 9
11 2
12
13
2506
2
5 10
6 1
13
2507
2
5 10
6 2
14
2818
2
4 10
7 1
14
2819
2
4 10
7 2
15
3130
2
3 10
8 1
15
3131
2
3 10
8 2
16
3442
2
2 10
9 1
16
3443
2
2 10
9 2
17
3754
2
1 10
10 1
17
3755
2
1 10
10 2
18
4066
2
0 10
11 1
18
4067
2
0 10
11 2
12
13
2530
2
5 11
6 1
13
2531
2
5 11
6 2
14
2842
2
4 11
7 1
14
2843
2
4 11
7 2
15
3154
2
3 11
8 1
15
3155
2
3 11
8 2
16
3466
2
2 11
9 1
16
3467
2
2 11
9 2
17
3778
2
1 11
10 1
17
3779
2
1 11
10 2
18
4090
2
0 11
11 1
18
4091
2
0 11
11 2
12
13
2554
2
5 12
6 1
13
2555
2
5 12
6 2
14
2866
2
4 12
7 1
14
2867
2
4 12
7 2
15
3178
2
3 12
8 1
15
3179
2
3 12
8 2
16
3490
2
2 12
9 1
16
3491
2
2 12
9 2
17
3802
2
1 12
10 1
17
3803
2
1 12
10 2
18
4114
2
0 12
11 1
18
4115
2
0 12
11 2
26
0
395
2
5 0
6 1
0
394
2
5 0
6 0
1
418
2
5 1
6 0
1
419
2
5 1
6 1
2
442
2
5 2
6 0
2
443
2
5 2
6 1
3
466
2
5 3
6 0
3
467
2
5 3
6 1
4
490
2
5 4
6 0
4
491
2
5 4
6 1
5
514
2
5 5
6 0
5
515
2
5 5
6 1
6
539
2
5 6
6 1
6
538
2
5 6
6 0
7
562
2
5 7
6 0
7
563
2
5 7
6 1
8
586
2
5 8
6 0
8
587
2
5 8
6 1
9
610
2
5 9
6 0
9
611
2
5 9
6 1
10
634
2
5 10
6 0
10
635
2
5 10
6 1
11
658
2
5 11
6 0
11
659
2
5 11
6 1
12
682
2
5 12
6 0
12
683
2
5 12
6 1
26
0
707
2
4 0
7 1
0
706
2
4 0
7 0
1
730
2
4 1
7 0
1
731
2
4 1
7 1
2
754
2
4 2
7 0
2
755
2
4 2
7 1
3
778
2
4 3
7 0
3
779
2
4 3
7 1
4
802
2
4 4
7 0
4
803
2
4 4
7 1
5
826
2
4 5
7 0
5
827
2
4 5
7 1
6
851
2
4 6
7 1
6
850
2
4 6
7 0
7
874
2
4 7
7 0
7
875
2
4 7
7 1
8
898
2
4 8
7 0
8
899
2
4 8
7 1
9
922
2
4 9
7 0
9
923
2
4 9
7 1
10
946
2
4 10
7 0
10
947
2
4 10
7 1
11
970
2
4 11
7 0
11
971
2
4 11
7 1
12
994
2
4 12
7 0
12
995
2
4 12
7 1
26
0
1019
2
3 0
8 1
0
1018
2
3 0
8 0
1
1042
2
3 1
8 0
1
1043
2
3 1
8 1
2
1066
2
3 2
8 0
2
1067
2
3 2
8 1
3
1090
2
3 3
8 0
3
1091
2
3 3
8 1
4
1114
2
3 4
8 0
4
1115
2
3 4
8 1
5
1138
2
3 5
8 0
5
1139
2
3 5
8 1
6
1163
2
3 6
8 1
6
1162
2
3 6
8 0
7
1186
2
3 7
8 0
7
1187
2
3 7
8 1
8
1210
2
3 8
8 0
8
1211
2
3 8
8 1
9
1234
2
3 9
8 0
9
1235
2
3 9
8 1
10
1258
2
3 10
8 0
10
1259
2
3 10
8 1
11
1282
2
3 11
8 0
11
1283
2
3 11
8 1
12
1306
2
3 12
8 0
12
1307
2
3 12
8 1
26
0
1331
2
2 0
9 1
0
1330
2
2 0
9 0
1
1354
2
2 1
9 0
1
1355
2
2 1
9 1
2
1378
2
2 2
9 0
2
1379
2
2 2
9 1
3
1402
2
2 3
9 0
3
1403
2
2 3
9 1
4
1426
2
2 4
9 0
4
1427
2
2 4
9 1
5
1450
2
2 5
9 0
5
1451
2
2 5
9 1
6
1475
2
2 6
9 1
6
1474
2
2 6
9 0
7
1498
2
2 7
9 0
7
1499
2
2 7
9 1
8
1522
2
2 8
9 0
8
1523
2
2 8
9 1
9
1546
2
2 9
9 0
9
1547
2
2 9
9 1
10
1570
2
2 10
9 0
10
1571
2
2 10
9 1
11
1594
2
2 11
9 0
11
1595
2
2 11
9 1
12
1618
2
2 12
9 0
12
1619
2
2 12
9 1
26
0
1643
2
1 0
10 1
0
1642
2
1 0
10 0
1
1666
2
1 1
10 0
1
1667
2
1 1
10 1
2
1690
2
1 2
10 0
2
1691
2
1 2
10 1
3
1714
2
1 3
10 0
3
1715
2
1 3
10 1
4
1738
2
1 4
10 0
4
1739
2
1 4
10 1
5
1762
2
1 5
10 0
5
1763
2
1 5
10 1
6
1787
2
1 6
10 1
6
1786
2
1 6
10 0
7
1810
2
1 7
10 0
7
1811
2
1 7
10 1
8
1834
2
1 8
10 0
8
1835
2
1 8
10 1
9
1858
2
1 9
10 0
9
1859
2
1 9
10 1
10
1882
2
1 10
10 0
10
1883
2
1 10
10 1
11
1906
2
1 11
10 0
11
1907
2
1 11
10 1
12
1930
2
1 12
10 0
12
1931
2
1 12
10 1
26
0
1955
2
0 0
11 1
0
1954
2
0 0
11 0
1
1978
2
0 1
11 0
1
1979
2
0 1
11 1
2
2002
2
0 2
11 0
2
2003
2
0 2
11 1
3
2026
2
0 3
11 0
3
2027
2
0 3
11 1
4
2050
2
0 4
11 0
4
2051
2
0 4
11 1
5
2074
2
0 5
11 0
5
2075
2
0 5
11 1
6
2099
2
0 6
11 1
6
2098
2
0 6
11 0
7
2122
2
0 7
11 0
7
2123
2
0 7
11 1
8
2146
2
0 8
11 0
8
2147
2
0 8
11 1
9
2170
2
0 9
11 0
9
2171
2
0 9
11 1
10
2194
2
0 10
11 0
10
2195
2
0 10
11 1
11
2218
2
0 11
11 0
11
2219
2
0 11
11 1
12
2242
2
0 12
11 0
12
2243
2
0 12
11 1
end_DTG
begin_CG
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
11 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
10 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
9 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
8 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
7 624
13
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
6 624
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
12
12 52
13 52
14 52
15 52
16 52
17 52
18 52
19 52
20 52
21 52
22 52
23 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
6
6 52
7 52
8 52
9 52
10 52
11 52
end_CG
