begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var9
-1
8
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
end_variable
begin_variable
var8
-1
8
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
end_variable
begin_variable
var7
-1
8
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
end_variable
begin_variable
var6
-1
8
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
end_variable
begin_variable
var10
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
12
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
12
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
12
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
12
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
12
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
12
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
0
begin_state
0
7
3
0
1
1
2
2
4
2
5
3
6
2
end_state
begin_goal
6
8 2
9 4
10 0
11 7
12 7
13 0
end_goal
944
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l3 l8
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l4 l8
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l5 l8
0
1
0 3 4 7
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l6 l8
0
1
0 3 5 7
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 3 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 3 6 5
0
end_operator
begin_operator
drive v1 l8 l2
0
1
0 3 7 1
0
end_operator
begin_operator
drive v1 l8 l3
0
1
0 3 7 2
0
end_operator
begin_operator
drive v1 l8 l4
0
1
0 3 7 3
0
end_operator
begin_operator
drive v1 l8 l5
0
1
0 3 7 4
0
end_operator
begin_operator
drive v1 l8 l6
0
1
0 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




11
2
1 3
6 1
4
422
2
1 4
6 0
4
423
2
1 4
6 1
5
434
2
1 5
6 0
5
435
2
1 5
6 1
6
446
2
1 6
6 0
6
447
2
1 6
6 1
7
458
2
1 7
6 0
7
459
2
1 7
6 1
16
0
470
2
0 0
7 0
0
471
2
0 0
7 1
1
482
2
0 1
7 0
1
483
2
0 1
7 1
2
494
2
0 2
7 0
2
495
2
0 2
7 1
3
506
2
0 3
7 0
3
507
2
0 3
7 1
4
518
2
0 4
7 0
4
519
2
0 4
7 1
5
530
2
0 5
7 0
5
531
2
0 5
7 1
6
542
2
0 6
7 0
6
543
2
0 6
7 1
7
554
2
0 7
7 0
7
555
2
0 7
7 1
end_DTG
begin_DTG
8
8
568
2
3 0
4 1
8
569
2
3 0
4 2
9
664
2
2 0
5 1
9
665
2
2 0
5 2
10
760
2
1 0
6 1
10
761
2
1 0
6 2
11
856
2
0 0
7 1
11
857
2
0 0
7 2
8
8
580
2
3 1
4 1
8
581
2
3 1
4 2
9
676
2
2 1
5 1
9
677
2
2 1
5 2
10
772
2
1 1
6 1
10
773
2
1 1
6 2
11
868
2
0 1
7 1
11
869
2
0 1
7 2
8
8
592
2
3 2
4 1
8
593
2
3 2
4 2
9
688
2
2 2
5 1
9
689
2
2 2
5 2
10
784
2
1 2
6 1
10
785
2
1 2
6 2
11
880
2
0 2
7 1
11
881
2
0 2
7 2
8
8
604
2
3 3
4 1
8
605
2
3 3
4 2
9
700
2
2 3
5 1
9
701
2
2 3
5 2
10
796
2
1 3
6 1
10
797
2
1 3
6 2
11
892
2
0 3
7 1
11
893
2
0 3
7 2
8
8
616
2
3 4
4 1
8
617
2
3 4
4 2
9
712
2
2 4
5 1
9
713
2
2 4
5 2
10
808
2
1 4
6 1
10
809
2
1 4
6 2
11
904
2
0 4
7 1
11
905
2
0 4
7 2
8
8
628
2
3 5
4 1
8
629
2
3 5
4 2
9
724
2
2 5
5 1
9
725
2
2 5
5 2
10
820
2
1 5
6 1
10
821
2
1 5
6 2
11
916
2
0 5
7 1
11
917
2
0 5
7 2
8
8
640
2
3 6
4 1
8
641
2
3 6
4 2
9
736
2
2 6
5 1
9
737
2
2 6
5 2
10
832
2
1 6
6 1
10
833
2
1 6
6 2
11
928
2
0 6
7 1
11
929
2
0 6
7 2
8
8
652
2
3 7
4 1
8
653
2
3 7
4 2
9
748
2
2 7
5 1
9
749
2
2 7
5 2
10
844
2
1 7
6 1
10
845
2
1 7
6 2
11
940
2
0 7
7 1
11
941
2
0 7
7 2
16
0
184
2
3 0
4 0
0
185
2
3 0
4 1
1
196
2
3 1
4 0
1
197
2
3 1
4 1
2
208
2
3 2
4 0
2
209
2
3 2
4 1
3
220
2
3 3
4 0
3
221
2
3 3
4 1
4
232
2
3 4
4 0
4
233
2
3 4
4 1
5
244
2
3 5
4 0
5
245
2
3 5
4 1
6
256
2
3 6
4 0
6
257
2
3 6
4 1
7
268
2
3 7
4 0
7
269
2
3 7
4 1
16
0
280
2
2 0
5 0
0
281
2
2 0
5 1
1
292
2
2 1
5 0
1
293
2
2 1
5 1
2
304
2
2 2
5 0
2
305
2
2 2
5 1
3
316
2
2 3
5 0
3
317
2
2 3
5 1
4
328
2
2 4
5 0
4
329
2
2 4
5 1
5
340
2
2 5
5 0
5
341
2
2 5
5 1
6
352
2
2 6
5 0
6
353
2
2 6
5 1
7
364
2
2 7
5 0
7
365
2
2 7
5 1
16
0
376
2
1 0
6 0
0
377
2
1 0
6 1
1
388
2
1 1
6 0
1
389
2
1 1
6 1
2
400
2
1 2
6 0
2
401
2
1 2
6 1
3
412
2
1 3
6 0
3
413
2
1 3
6 1
4
424
2
1 4
6 0
4
425
2
1 4
6 1
5
436
2
1 5
6 0
5
437
2
1 5
6 1
6
448
2
1 6
6 0
6
449
2
1 6
6 1
7
460
2
1 7
6 0
7
461
2
1 7
6 1
16
0
472
2
0 0
7 0
0
473
2
0 0
7 1
1
484
2
0 1
7 0
1
485
2
0 1
7 1
2
496
2
0 2
7 0
2
497
2
0 2
7 1
3
508
2
0 3
7 0
3
509
2
0 3
7 1
4
520
2
0 4
7 0
4
521
2
0 4
7 1
5
532
2
0 5
7 0
5
533
2
0 5
7 1
6
544
2
0 6
7 0
6
545
2
0 6
7 1
7
556
2
0 7
7 0
7
557
2
0 7
7 1
end_DTG
begin_DTG
8
8
570
2
3 0
4 1
8
571
2
3 0
4 2
9
666
2
2 0
5 1
9
667
2
2 0
5 2
10
762
2
1 0
6 1
10
763
2
1 0
6 2
11
858
2
0 0
7 1
11
859
2
0 0
7 2
8
8
582
2
3 1
4 1
8
583
2
3 1
4 2
9
678
2
2 1
5 1
9
679
2
2 1
5 2
10
774
2
1 1
6 1
10
775
2
1 1
6 2
11
870
2
0 1
7 1
11
871
2
0 1
7 2
8
8
594
2
3 2
4 1
8
595
2
3 2
4 2
9
690
2
2 2
5 1
9
691
2
2 2
5 2
10
786
2
1 2
6 1
10
787
2
1 2
6 2
11
882
2
0 2
7 1
11
883
2
0 2
7 2
8
8
606
2
3 3
4 1
8
607
2
3 3
4 2
9
702
2
2 3
5 1
9
703
2
2 3
5 2
10
798
2
1 3
6 1
10
799
2
1 3
6 2
11
894
2
0 3
7 1
11
895
2
0 3
7 2
8
8
618
2
3 4
4 1
8
619
2
3 4
4 2
9
714
2
2 4
5 1
9
715
2
2 4
5 2
10
810
2
1 4
6 1
10
811
2
1 4
6 2
11
906
2
0 4
7 1
11
907
2
0 4
7 2
8
8
630
2
3 5
4 1
8
631
2
3 5
4 2
9
726
2
2 5
5 1
9
727
2
2 5
5 2
10
822
2
1 5
6 1
10
823
2
1 5
6 2
11
918
2
0 5
7 1
11
919
2
0 5
7 2
8
8
642
2
3 6
4 1
8
643
2
3 6
4 2
9
738
2
2 6
5 1
9
739
2
2 6
5 2
10
834
2
1 6
6 1
10
835
2
1 6
6 2
11
930
2
0 6
7 1
11
931
2
0 6
7 2
8
8
654
2
3 7
4 1
8
655
2
3 7
4 2
9
750
2
2 7
5 1
9
751
2
2 7
5 2
10
846
2
1 7
6 1
10
847
2
1 7
6 2
11
942
2
0 7
7 1
11
943
2
0 7
7 2
16
0
186
2
3 0
4 0
0
187
2
3 0
4 1
1
198
2
3 1
4 0
1
199
2
3 1
4 1
2
210
2
3 2
4 0
2
211
2
3 2
4 1
3
222
2
3 3
4 0
3
223
2
3 3
4 1
4
234
2
3 4
4 0
4
235
2
3 4
4 1
5
246
2
3 5
4 0
5
247
2
3 5
4 1
6
258
2
3 6
4 0
6
259
2
3 6
4 1
7
270
2
3 7
4 0
7
271
2
3 7
4 1
16
0
282
2
2 0
5 0
0
283
2
2 0
5 1
1
294
2
2 1
5 0
1
295
2
2 1
5 1
2
306
2
2 2
5 0
2
307
2
2 2
5 1
3
318
2
2 3
5 0
3
319
2
2 3
5 1
4
330
2
2 4
5 0
4
331
2
2 4
5 1
5
342
2
2 5
5 0
5
343
2
2 5
5 1
6
354
2
2 6
5 0
6
355
2
2 6
5 1
7
366
2
2 7
5 0
7
367
2
2 7
5 1
16
0
378
2
1 0
6 0
0
379
2
1 0
6 1
1
390
2
1 1
6 0
1
391
2
1 1
6 1
2
402
2
1 2
6 0
2
403
2
1 2
6 1
3
414
2
1 3
6 0
3
415
2
1 3
6 1
4
426
2
1 4
6 0
4
427
2
1 4
6 1
5
438
2
1 5
6 0
5
439
2
1 5
6 1
6
450
2
1 6
6 0
6
451
2
1 6
6 1
7
462
2
1 7
6 0
7
463
2
1 7
6 1
16
0
474
2
0 0
7 0
0
475
2
0 0
7 1
1
486
2
0 1
7 0
1
487
2
0 1
7 1
2
498
2
0 2
7 0
2
499
2
0 2
7 1
3
510
2
0 3
7 0
3
511
2
0 3
7 1
4
522
2
0 4
7 0
4
523
2
0 4
7 1
5
534
2
0 5
7 0
5
535
2
0 5
7 1
6
546
2
0 6
7 0
6
547
2
0 6
7 1
7
558
2
0 7
7 0
7
559
2
0 7
7 1
end_DTG
begin_CG
7
8 32
9 32
10 32
11 32
12 32
13 32
7 192
7
8 32
9 32
10 32
11 32
12 32
13 32
6 192
7
8 32
9 32
10 32
11 32
12 32
13 32
5 192
7
8 32
9 32
10 32
11 32
12 32
13 32
4 192
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
6
8 32
9 32
10 32
11 32
12 32
13 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
4
4 32
5 32
6 32
7 32
end_CG
