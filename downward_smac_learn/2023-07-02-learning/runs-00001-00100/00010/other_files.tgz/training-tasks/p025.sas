begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var8
-1
7
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
end_variable
begin_variable
var7
-1
7
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
end_variable
begin_variable
var6
-1
7
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
end_variable
begin_variable
var5
-1
7
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
end_variable
begin_variable
var9
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var10
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
11
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
11
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
11
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
11
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
11
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
0
begin_state
5
0
4
6
1
2
2
1
6
3
2
2
6
end_state
begin_goal
5
8 5
9 2
10 4
11 3
12 2
end_goal
720
begin_operator
drive v1 l1 l2
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 5
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 3 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 1 6
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 2 3
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 3 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 3 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 3 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 3 4 5
0
end_operator
begin_operator
drive v1 l5 l7
0
1
0 3 4 6
0
end_operator
begin_operator
drive v1 l6 l1
0
1
0 3 5 0
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 3 5 2
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 3 5 3
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 3 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 3 5 6
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 3 6 1
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 3 6 3
0
end_operator
begin_operator
drive v1 l7 l5
0
1
0 3 6 4
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 3 6 5
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 2 0 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v2 l1 l6
0
1
0 2 0 5
0
end_operator
begin_operator
drive v2 l1 l7
0
1
0 2 0 6
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 2 1 0
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7
505
2
3 6
4 2
8
574
2
2 6
5 1
8
575
2
2 6
5 2
9
644
2
1 6
6 1
9
645
2
1 6
6 2
10
714
2
0 6
7 1
10
715
2
0 6
7 2
14
0
164
2
3 0
4 0
0
165
2
3 0
4 1
1
174
2
3 1
4 0
1
175
2
3 1
4 1
2
184
2
3 2
4 0
2
185
2
3 2
4 1
3
194
2
3 3
4 0
3
195
2
3 3
4 1
4
204
2
3 4
4 0
4
205
2
3 4
4 1
5
214
2
3 5
4 0
5
215
2
3 5
4 1
6
224
2
3 6
4 0
6
225
2
3 6
4 1
14
0
234
2
2 0
5 0
0
235
2
2 0
5 1
1
244
2
2 1
5 0
1
245
2
2 1
5 1
2
254
2
2 2
5 0
2
255
2
2 2
5 1
3
264
2
2 3
5 0
3
265
2
2 3
5 1
4
274
2
2 4
5 0
4
275
2
2 4
5 1
5
284
2
2 5
5 0
5
285
2
2 5
5 1
6
294
2
2 6
5 0
6
295
2
2 6
5 1
14
0
304
2
1 0
6 0
0
305
2
1 0
6 1
1
314
2
1 1
6 0
1
315
2
1 1
6 1
2
324
2
1 2
6 0
2
325
2
1 2
6 1
3
334
2
1 3
6 0
3
335
2
1 3
6 1
4
344
2
1 4
6 0
4
345
2
1 4
6 1
5
354
2
1 5
6 0
5
355
2
1 5
6 1
6
364
2
1 6
6 0
6
365
2
1 6
6 1
14
0
374
2
0 0
7 0
0
375
2
0 0
7 1
1
384
2
0 1
7 0
1
385
2
0 1
7 1
2
394
2
0 2
7 0
2
395
2
0 2
7 1
3
404
2
0 3
7 0
3
405
2
0 3
7 1
4
414
2
0 4
7 0
4
415
2
0 4
7 1
5
424
2
0 5
7 0
5
425
2
0 5
7 1
6
434
2
0 6
7 0
6
435
2
0 6
7 1
end_DTG
begin_DTG
8
7
446
2
3 0
4 1
7
447
2
3 0
4 2
8
516
2
2 0
5 1
8
517
2
2 0
5 2
9
586
2
1 0
6 1
9
587
2
1 0
6 2
10
656
2
0 0
7 1
10
657
2
0 0
7 2
8
7
456
2
3 1
4 1
7
457
2
3 1
4 2
8
526
2
2 1
5 1
8
527
2
2 1
5 2
9
596
2
1 1
6 1
9
597
2
1 1
6 2
10
666
2
0 1
7 1
10
667
2
0 1
7 2
8
7
466
2
3 2
4 1
7
467
2
3 2
4 2
8
536
2
2 2
5 1
8
537
2
2 2
5 2
9
606
2
1 2
6 1
9
607
2
1 2
6 2
10
676
2
0 2
7 1
10
677
2
0 2
7 2
8
7
476
2
3 3
4 1
7
477
2
3 3
4 2
8
546
2
2 3
5 1
8
547
2
2 3
5 2
9
616
2
1 3
6 1
9
617
2
1 3
6 2
10
686
2
0 3
7 1
10
687
2
0 3
7 2
8
7
486
2
3 4
4 1
7
487
2
3 4
4 2
8
556
2
2 4
5 1
8
557
2
2 4
5 2
9
626
2
1 4
6 1
9
627
2
1 4
6 2
10
696
2
0 4
7 1
10
697
2
0 4
7 2
8
7
496
2
3 5
4 1
7
497
2
3 5
4 2
8
566
2
2 5
5 1
8
567
2
2 5
5 2
9
636
2
1 5
6 1
9
637
2
1 5
6 2
10
706
2
0 5
7 1
10
707
2
0 5
7 2
8
7
506
2
3 6
4 1
7
507
2
3 6
4 2
8
576
2
2 6
5 1
8
577
2
2 6
5 2
9
646
2
1 6
6 1
9
647
2
1 6
6 2
10
716
2
0 6
7 1
10
717
2
0 6
7 2
14
0
166
2
3 0
4 0
0
167
2
3 0
4 1
1
176
2
3 1
4 0
1
177
2
3 1
4 1
2
186
2
3 2
4 0
2
187
2
3 2
4 1
3
196
2
3 3
4 0
3
197
2
3 3
4 1
4
206
2
3 4
4 0
4
207
2
3 4
4 1
5
216
2
3 5
4 0
5
217
2
3 5
4 1
6
226
2
3 6
4 0
6
227
2
3 6
4 1
14
0
236
2
2 0
5 0
0
237
2
2 0
5 1
1
246
2
2 1
5 0
1
247
2
2 1
5 1
2
256
2
2 2
5 0
2
257
2
2 2
5 1
3
266
2
2 3
5 0
3
267
2
2 3
5 1
4
276
2
2 4
5 0
4
277
2
2 4
5 1
5
286
2
2 5
5 0
5
287
2
2 5
5 1
6
296
2
2 6
5 0
6
297
2
2 6
5 1
14
0
306
2
1 0
6 0
0
307
2
1 0
6 1
1
316
2
1 1
6 0
1
317
2
1 1
6 1
2
326
2
1 2
6 0
2
327
2
1 2
6 1
3
336
2
1 3
6 0
3
337
2
1 3
6 1
4
346
2
1 4
6 0
4
347
2
1 4
6 1
5
356
2
1 5
6 0
5
357
2
1 5
6 1
6
366
2
1 6
6 0
6
367
2
1 6
6 1
14
0
376
2
0 0
7 0
0
377
2
0 0
7 1
1
386
2
0 1
7 0
1
387
2
0 1
7 1
2
396
2
0 2
7 0
2
397
2
0 2
7 1
3
406
2
0 3
7 0
3
407
2
0 3
7 1
4
416
2
0 4
7 0
4
417
2
0 4
7 1
5
426
2
0 5
7 0
5
427
2
0 5
7 1
6
436
2
0 6
7 0
6
437
2
0 6
7 1
end_DTG
begin_DTG
8
7
448
2
3 0
4 1
7
449
2
3 0
4 2
8
518
2
2 0
5 1
8
519
2
2 0
5 2
9
588
2
1 0
6 1
9
589
2
1 0
6 2
10
658
2
0 0
7 1
10
659
2
0 0
7 2
8
7
458
2
3 1
4 1
7
459
2
3 1
4 2
8
528
2
2 1
5 1
8
529
2
2 1
5 2
9
598
2
1 1
6 1
9
599
2
1 1
6 2
10
668
2
0 1
7 1
10
669
2
0 1
7 2
8
7
468
2
3 2
4 1
7
469
2
3 2
4 2
8
538
2
2 2
5 1
8
539
2
2 2
5 2
9
608
2
1 2
6 1
9
609
2
1 2
6 2
10
678
2
0 2
7 1
10
679
2
0 2
7 2
8
7
478
2
3 3
4 1
7
479
2
3 3
4 2
8
548
2
2 3
5 1
8
549
2
2 3
5 2
9
618
2
1 3
6 1
9
619
2
1 3
6 2
10
688
2
0 3
7 1
10
689
2
0 3
7 2
8
7
488
2
3 4
4 1
7
489
2
3 4
4 2
8
558
2
2 4
5 1
8
559
2
2 4
5 2
9
628
2
1 4
6 1
9
629
2
1 4
6 2
10
698
2
0 4
7 1
10
699
2
0 4
7 2
8
7
498
2
3 5
4 1
7
499
2
3 5
4 2
8
568
2
2 5
5 1
8
569
2
2 5
5 2
9
638
2
1 5
6 1
9
639
2
1 5
6 2
10
708
2
0 5
7 1
10
709
2
0 5
7 2
8
7
508
2
3 6
4 1
7
509
2
3 6
4 2
8
578
2
2 6
5 1
8
579
2
2 6
5 2
9
648
2
1 6
6 1
9
649
2
1 6
6 2
10
718
2
0 6
7 1
10
719
2
0 6
7 2
14
0
168
2
3 0
4 0
0
169
2
3 0
4 1
1
178
2
3 1
4 0
1
179
2
3 1
4 1
2
188
2
3 2
4 0
2
189
2
3 2
4 1
3
198
2
3 3
4 0
3
199
2
3 3
4 1
4
208
2
3 4
4 0
4
209
2
3 4
4 1
5
218
2
3 5
4 0
5
219
2
3 5
4 1
6
228
2
3 6
4 0
6
229
2
3 6
4 1
14
0
238
2
2 0
5 0
0
239
2
2 0
5 1
1
248
2
2 1
5 0
1
249
2
2 1
5 1
2
258
2
2 2
5 0
2
259
2
2 2
5 1
3
268
2
2 3
5 0
3
269
2
2 3
5 1
4
278
2
2 4
5 0
4
279
2
2 4
5 1
5
288
2
2 5
5 0
5
289
2
2 5
5 1
6
298
2
2 6
5 0
6
299
2
2 6
5 1
14
0
308
2
1 0
6 0
0
309
2
1 0
6 1
1
318
2
1 1
6 0
1
319
2
1 1
6 1
2
328
2
1 2
6 0
2
329
2
1 2
6 1
3
338
2
1 3
6 0
3
339
2
1 3
6 1
4
348
2
1 4
6 0
4
349
2
1 4
6 1
5
358
2
1 5
6 0
5
359
2
1 5
6 1
6
368
2
1 6
6 0
6
369
2
1 6
6 1
14
0
378
2
0 0
7 0
0
379
2
0 0
7 1
1
388
2
0 1
7 0
1
389
2
0 1
7 1
2
398
2
0 2
7 0
2
399
2
0 2
7 1
3
408
2
0 3
7 0
3
409
2
0 3
7 1
4
418
2
0 4
7 0
4
419
2
0 4
7 1
5
428
2
0 5
7 0
5
429
2
0 5
7 1
6
438
2
0 6
7 0
6
439
2
0 6
7 1
end_DTG
begin_CG
6
8 28
9 28
10 28
11 28
12 28
7 140
6
8 28
9 28
10 28
11 28
12 28
6 140
6
8 28
9 28
10 28
11 28
12 28
5 140
6
8 28
9 28
10 28
11 28
12 28
4 140
5
8 28
9 28
10 28
11 28
12 28
5
8 28
9 28
10 28
11 28
12 28
5
8 28
9 28
10 28
11 28
12 28
5
8 28
9 28
10 28
11 28
12 28
4
4 28
5 28
6 28
7 28
4
4 28
5 28
6 28
7 28
4
4 28
5 28
6 28
7 28
4
4 28
5 28
6 28
7 28
4
4 28
5 28
6 28
7 28
end_CG
