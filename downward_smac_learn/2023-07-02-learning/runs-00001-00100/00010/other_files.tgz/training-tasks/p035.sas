begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var9
-1
9
Atom at(v4, l1)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var8
-1
9
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var7
-1
9
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var6
-1
9
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var10
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var11
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var12
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
13
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
13
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
13
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
13
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
13
Atom at(p5, l1)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
13
Atom at(p6, l1)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
0
begin_state
1
3
7
7
2
2
2
1
4
0
6
3
4
4
end_state
begin_goal
6
8 6
9 3
10 7
11 5
12 6
13 2
end_goal
960
begin_operator
drive v1 l1 l7
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 3 0 8
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 1 7
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 2 4
0
end_operator
begin_operator
drive v1 l3 l9
0
1
0 3 2 8
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l4 l9
0
1
0 3 3 8
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 3 4 1
0
end_operator
begin_operator
drive v1 l5 l3
0
1
0 3 4 2
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 3 4 3
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 3 5 1
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 3 6 0
0
end_operator
begin_operator
drive v1 l7 l9
0
1
0 3 6 8
0
end_operator
begin_operator
drive v1 l8 l1
0
1
0 3 7 0
0
end_operator
begin_operator
drive v1 l8 l2
0
1
0 3 7 1
0
end_operator
begin_operator
drive v1 l9 l1
0
1
0 3 8 0
0
end_operator
begin_operator
drive v1 l9 l2
0
1
0 3 8 1
0
end_operator
begin_operator
drive v1 l9 l3
0
1
0 3 8 2
0
end_operator
begin_operator
drive v1 l9 l4
0
1
0 3 8 3
0
end_operator
begin_operator
drive v1 l9 l7
0
1
0 3 8 6
0
end_operator
begin_operator
drive v2 l1 l7
0
1
0 2 0 6
0
end_operator
begin_operator
drive v2 l1 l8
0
1
0 2 0 7
0
end_operator
begin_operator
drive v2 l1 l9
0
1
0 2 0 8
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v2 l2 l8
0
1
0 2 1 7
0
end_operator
begin_operator
drive v2 l2 l9
0
1
0 2 1 8
0
end_operator
begin_operator
drive v2 l3 l5
0
1
0 2 2 4
0
end_operator
begin_operator
drive v2 l3 l9
0
1
0 2 2 8
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v2 l4 l9
0
1
0 2 3 8
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v2 l5 l3
0
1
0 2 4 2
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v2 l7 l1
0
1
0 2 6 0
0
end_operator
begin_operator
drive v2 l7 l9
0
1
0 2 6 8
0
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8
2
3 1
4 1
9
549
2
3 1
4 2
10
656
2
2 1
5 1
10
657
2
2 1
5 2
11
764
2
1 1
6 1
11
765
2
1 1
6 2
12
872
2
0 1
7 1
12
873
2
0 1
7 2
8
9
560
2
3 2
4 1
9
561
2
3 2
4 2
10
668
2
2 2
5 1
10
669
2
2 2
5 2
11
776
2
1 2
6 1
11
777
2
1 2
6 2
12
884
2
0 2
7 1
12
885
2
0 2
7 2
8
9
572
2
3 3
4 1
9
573
2
3 3
4 2
10
680
2
2 3
5 1
10
681
2
2 3
5 2
11
788
2
1 3
6 1
11
789
2
1 3
6 2
12
896
2
0 3
7 1
12
897
2
0 3
7 2
8
9
584
2
3 4
4 1
9
585
2
3 4
4 2
10
692
2
2 4
5 1
10
693
2
2 4
5 2
11
800
2
1 4
6 1
11
801
2
1 4
6 2
12
908
2
0 4
7 1
12
909
2
0 4
7 2
8
9
596
2
3 5
4 1
9
597
2
3 5
4 2
10
704
2
2 5
5 1
10
705
2
2 5
5 2
11
812
2
1 5
6 1
11
813
2
1 5
6 2
12
920
2
0 5
7 1
12
921
2
0 5
7 2
8
9
608
2
3 6
4 1
9
609
2
3 6
4 2
10
716
2
2 6
5 1
10
717
2
2 6
5 2
11
824
2
1 6
6 1
11
825
2
1 6
6 2
12
932
2
0 6
7 1
12
933
2
0 6
7 2
8
9
620
2
3 7
4 1
9
621
2
3 7
4 2
10
728
2
2 7
5 1
10
729
2
2 7
5 2
11
836
2
1 7
6 1
11
837
2
1 7
6 2
12
944
2
0 7
7 1
12
945
2
0 7
7 2
8
9
632
2
3 8
4 1
9
633
2
3 8
4 2
10
740
2
2 8
5 1
10
741
2
2 8
5 2
11
848
2
1 8
6 1
11
849
2
1 8
6 2
12
956
2
0 8
7 1
12
957
2
0 8
7 2
18
0
105
2
3 0
4 1
0
104
2
3 0
4 0
1
116
2
3 1
4 0
1
117
2
3 1
4 1
2
128
2
3 2
4 0
2
129
2
3 2
4 1
3
140
2
3 3
4 0
3
141
2
3 3
4 1
4
153
2
3 4
4 1
4
152
2
3 4
4 0
5
164
2
3 5
4 0
5
165
2
3 5
4 1
6
176
2
3 6
4 0
6
177
2
3 6
4 1
7
188
2
3 7
4 0
7
189
2
3 7
4 1
8
200
2
3 8
4 0
8
201
2
3 8
4 1
18
0
213
2
2 0
5 1
0
212
2
2 0
5 0
1
224
2
2 1
5 0
1
225
2
2 1
5 1
2
236
2
2 2
5 0
2
237
2
2 2
5 1
3
248
2
2 3
5 0
3
249
2
2 3
5 1
4
261
2
2 4
5 1
4
260
2
2 4
5 0
5
272
2
2 5
5 0
5
273
2
2 5
5 1
6
284
2
2 6
5 0
6
285
2
2 6
5 1
7
296
2
2 7
5 0
7
297
2
2 7
5 1
8
308
2
2 8
5 0
8
309
2
2 8
5 1
18
0
321
2
1 0
6 1
0
320
2
1 0
6 0
1
332
2
1 1
6 0
1
333
2
1 1
6 1
2
344
2
1 2
6 0
2
345
2
1 2
6 1
3
356
2
1 3
6 0
3
357
2
1 3
6 1
4
369
2
1 4
6 1
4
368
2
1 4
6 0
5
380
2
1 5
6 0
5
381
2
1 5
6 1
6
392
2
1 6
6 0
6
393
2
1 6
6 1
7
404
2
1 7
6 0
7
405
2
1 7
6 1
8
416
2
1 8
6 0
8
417
2
1 8
6 1
18
0
429
2
0 0
7 1
0
428
2
0 0
7 0
1
440
2
0 1
7 0
1
441
2
0 1
7 1
2
452
2
0 2
7 0
2
453
2
0 2
7 1
3
464
2
0 3
7 0
3
465
2
0 3
7 1
4
477
2
0 4
7 1
4
476
2
0 4
7 0
5
488
2
0 5
7 0
5
489
2
0 5
7 1
6
500
2
0 6
7 0
6
501
2
0 6
7 1
7
512
2
0 7
7 0
7
513
2
0 7
7 1
8
524
2
0 8
7 0
8
525
2
0 8
7 1
end_DTG
begin_DTG
8
9
538
2
3 0
4 1
9
539
2
3 0
4 2
10
646
2
2 0
5 1
10
647
2
2 0
5 2
11
754
2
1 0
6 1
11
755
2
1 0
6 2
12
862
2
0 0
7 1
12
863
2
0 0
7 2
8
9
550
2
3 1
4 1
9
551
2
3 1
4 2
10
658
2
2 1
5 1
10
659
2
2 1
5 2
11
766
2
1 1
6 1
11
767
2
1 1
6 2
12
874
2
0 1
7 1
12
875
2
0 1
7 2
8
9
562
2
3 2
4 1
9
563
2
3 2
4 2
10
670
2
2 2
5 1
10
671
2
2 2
5 2
11
778
2
1 2
6 1
11
779
2
1 2
6 2
12
886
2
0 2
7 1
12
887
2
0 2
7 2
8
9
574
2
3 3
4 1
9
575
2
3 3
4 2
10
682
2
2 3
5 1
10
683
2
2 3
5 2
11
790
2
1 3
6 1
11
791
2
1 3
6 2
12
898
2
0 3
7 1
12
899
2
0 3
7 2
8
9
586
2
3 4
4 1
9
587
2
3 4
4 2
10
694
2
2 4
5 1
10
695
2
2 4
5 2
11
802
2
1 4
6 1
11
803
2
1 4
6 2
12
910
2
0 4
7 1
12
911
2
0 4
7 2
8
9
598
2
3 5
4 1
9
599
2
3 5
4 2
10
706
2
2 5
5 1
10
707
2
2 5
5 2
11
814
2
1 5
6 1
11
815
2
1 5
6 2
12
922
2
0 5
7 1
12
923
2
0 5
7 2
8
9
610
2
3 6
4 1
9
611
2
3 6
4 2
10
718
2
2 6
5 1
10
719
2
2 6
5 2
11
826
2
1 6
6 1
11
827
2
1 6
6 2
12
934
2
0 6
7 1
12
935
2
0 6
7 2
8
9
622
2
3 7
4 1
9
623
2
3 7
4 2
10
730
2
2 7
5 1
10
731
2
2 7
5 2
11
838
2
1 7
6 1
11
839
2
1 7
6 2
12
946
2
0 7
7 1
12
947
2
0 7
7 2
8
9
634
2
3 8
4 1
9
635
2
3 8
4 2
10
742
2
2 8
5 1
10
743
2
2 8
5 2
11
850
2
1 8
6 1
11
851
2
1 8
6 2
12
958
2
0 8
7 1
12
959
2
0 8
7 2
18
0
107
2
3 0
4 1
0
106
2
3 0
4 0
1
118
2
3 1
4 0
1
119
2
3 1
4 1
2
130
2
3 2
4 0
2
131
2
3 2
4 1
3
142
2
3 3
4 0
3
143
2
3 3
4 1
4
155
2
3 4
4 1
4
154
2
3 4
4 0
5
166
2
3 5
4 0
5
167
2
3 5
4 1
6
178
2
3 6
4 0
6
179
2
3 6
4 1
7
190
2
3 7
4 0
7
191
2
3 7
4 1
8
202
2
3 8
4 0
8
203
2
3 8
4 1
18
0
215
2
2 0
5 1
0
214
2
2 0
5 0
1
226
2
2 1
5 0
1
227
2
2 1
5 1
2
238
2
2 2
5 0
2
239
2
2 2
5 1
3
250
2
2 3
5 0
3
251
2
2 3
5 1
4
263
2
2 4
5 1
4
262
2
2 4
5 0
5
274
2
2 5
5 0
5
275
2
2 5
5 1
6
286
2
2 6
5 0
6
287
2
2 6
5 1
7
298
2
2 7
5 0
7
299
2
2 7
5 1
8
310
2
2 8
5 0
8
311
2
2 8
5 1
18
0
323
2
1 0
6 1
0
322
2
1 0
6 0
1
334
2
1 1
6 0
1
335
2
1 1
6 1
2
346
2
1 2
6 0
2
347
2
1 2
6 1
3
358
2
1 3
6 0
3
359
2
1 3
6 1
4
371
2
1 4
6 1
4
370
2
1 4
6 0
5
382
2
1 5
6 0
5
383
2
1 5
6 1
6
394
2
1 6
6 0
6
395
2
1 6
6 1
7
406
2
1 7
6 0
7
407
2
1 7
6 1
8
418
2
1 8
6 0
8
419
2
1 8
6 1
18
0
431
2
0 0
7 1
0
430
2
0 0
7 0
1
442
2
0 1
7 0
1
443
2
0 1
7 1
2
454
2
0 2
7 0
2
455
2
0 2
7 1
3
466
2
0 3
7 0
3
467
2
0 3
7 1
4
479
2
0 4
7 1
4
478
2
0 4
7 0
5
490
2
0 5
7 0
5
491
2
0 5
7 1
6
502
2
0 6
7 0
6
503
2
0 6
7 1
7
514
2
0 7
7 0
7
515
2
0 7
7 1
8
526
2
0 8
7 0
8
527
2
0 8
7 1
end_DTG
begin_CG
7
8 36
9 36
10 36
11 36
12 36
13 36
7 216
7
8 36
9 36
10 36
11 36
12 36
13 36
6 216
7
8 36
9 36
10 36
11 36
12 36
13 36
5 216
7
8 36
9 36
10 36
11 36
12 36
13 36
4 216
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
6
8 36
9 36
10 36
11 36
12 36
13 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
4
4 36
5 36
6 36
7 36
end_CG
