begin_version
3
end_version
begin_metric
0
end_metric
5
begin_variable
var2
-1
4
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
end_variable
begin_variable
var1
-1
4
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
end_variable
begin_variable
var3
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var4
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var0
-1
6
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom in(p1, v1)
Atom in(p1, v2)
end_variable
0
begin_state
0
3
2
2
1
end_state
begin_goal
1
4 2
end_goal
56
begin_operator
drive v1 l1 l2
0
1
0 1 0 1
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 1 1 0
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 1 2 3
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 1 3 2
0
end_operator
begin_operator
drive v2 l1 l2
0
1
0 0 0 1
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v2 l2 l1
0
1
0 0 1 0
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 0 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 0 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 0 2 1
0
end_operator
begin_operator
drive v2 l3 l4
0
1
0 0 2 3
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 0 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drive v2 l4 l3
0
1
0 0 3 2
0
end_operator
begin_operator
drop v1 l1 p1 c0 c1
1
1 0
2
0 4 4 0
0 2 0 1
0
end_operator
begin_operator
drop v1 l1 p1 c1 c2
1
1 0
2
0 4 4 0
0 2 1 2
0
end_operator
begin_operator
drop v1 l2 p1 c0 c1
1
1 1
2
0 4 4 1
0 2 0 1
0
end_operator
begin_operator
drop v1 l2 p1 c1 c2
1
1 1
2
0 4 4 1
0 2 1 2
0
end_operator
begin_operator
drop v1 l3 p1 c0 c1
1
1 2
2
0 4 4 2
0 2 0 1
0
end_operator
begin_operator
drop v1 l3 p1 c1 c2
1
1 2
2
0 4 4 2
0 2 1 2
0
end_operator
begin_operator
drop v1 l4 p1 c0 c1
1
1 3
2
0 4 4 3
0 2 0 1
0
end_operator
begin_operator
drop v1 l4 p1 c1 c2
1
1 3
2
0 4 4 3
0 2 1 2
0
end_operator
begin_operator
drop v2 l1 p1 c0 c1
1
0 0
2
0 4 5 0
0 3 0 1
0
end_operator
begin_operator
drop v2 l1 p1 c1 c2
1
0 0
2
0 4 5 0
0 3 1 2
0
end_operator
begin_operator
drop v2 l2 p1 c0 c1
1
0 1
2
0 4 5 1
0 3 0 1
0
end_operator
begin_operator
drop v2 l2 p1 c1 c2
1
0 1
2
0 4 5 1
0 3 1 2
0
end_operator
begin_operator
drop v2 l3 p1 c0 c1
1
0 2
2
0 4 5 2
0 3 0 1
0
end_operator
begin_operator
drop v2 l3 p1 c1 c2
1
0 2
2
0 4 5 2
0 3 1 2
0
end_operator
begin_operator
drop v2 l4 p1 c0 c1
1
0 3
2
0 4 5 3
0 3 0 1
0
end_operator
begin_operator
drop v2 l4 p1 c1 c2
1
0 3
2
0 4 5 3
0 3 1 2
0
end_operator
begin_operator
pick-up v1 l1 p1 c0 c1
1
1 0
2
0 4 0 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l1 p1 c1 c2
1
1 0
2
0 4 0 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l2 p1 c0 c1
1
1 1
2
0 4 1 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l2 p1 c1 c2
1
1 1
2
0 4 1 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l3 p1 c0 c1
1
1 2
2
0 4 2 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l3 p1 c1 c2
1
1 2
2
0 4 2 4
0 2 2 1
0
end_operator
begin_operator
pick-up v1 l4 p1 c0 c1
1
1 3
2
0 4 3 4
0 2 1 0
0
end_operator
begin_operator
pick-up v1 l4 p1 c1 c2
1
1 3
2
0 4 3 4
0 2 2 1
0
end_operator
begin_operator
pick-up v2 l1 p1 c0 c1
1
0 0
2
0 4 0 5
0 3 1 0
0
end_operator
begin_operator
pick-up v2 l1 p1 c1 c2
1
0 0
2
0 4 0 5
0 3 2 1
0
end_operator
begin_operator
pick-up v2 l2 p1 c0 c1
1
0 1
2
0 4 1 5
0 3 1 0
0
end_operator
begin_operator
pick-up v2 l2 p1 c1 c2
1
0 1
2
0 4 1 5
0 3 2 1
0
end_operator
begin_operator
pick-up v2 l3 p1 c0 c1
1
0 2
2
0 4 2 5
0 3 1 0
0
end_operator
begin_operator
pick-up v2 l3 p1 c1 c2
1
0 2
2
0 4 2 5
0 3 2 1
0
end_operator
begin_operator
pick-up v2 l4 p1 c0 c1
1
0 3
2
0 4 3 5
0 3 1 0
0
end_operator
begin_operator
pick-up v2 l4 p1 c1 c2
1
0 3
2
0 4 3 5
0 3 2 1
0
end_operator
0
begin_SG
switch 4
check 0
switch 1
check 0
switch 2
check 0
check 0
check 1
40
check 1
41
check 0
check 0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 0
check 1
48
check 1
49
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
switch 2
check 0
check 0
check 1
42
check 1
43
check 0
check 0
check 0
switch 0
check 0
check 0
switch 3
check 0
check 0
check 1
50
check 1
51
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
44
check 1
45
check 0
check 0
switch 0
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
52
check 1
53
check 0
check 0
check 0
switch 1
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
check 1
46
check 1
47
check 0
switch 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 0
check 1
54
check 1
55
check 0
check 0
switch 1
check 0
switch 2
check 0
check 1
24
check 1
25
check 0
check 0
switch 2
check 0
check 1
26
check 1
27
check 0
check 0
switch 2
check 0
check 1
28
check 1
29
check 0
check 0
switch 2
check 0
check 1
30
check 1
31
check 0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 1
32
check 1
33
check 0
check 0
switch 3
check 0
check 1
34
check 1
35
check 0
check 0
switch 3
check 0
check 1
36
check 1
37
check 0
check 0
switch 3
check 0
check 1
38
check 1
39
check 0
check 0
check 0
switch 1
check 0
check 3
0
1
2
check 3
3
4
5
check 3
6
7
8
check 3
9
10
11
switch 0
check 0
check 3
12
13
14
check 3
15
16
17
check 3
18
19
20
check 3
21
22
23
check 0
end_SG
begin_DTG
3
1
12
0
2
13
0
3
14
0
3
0
15
0
2
16
0
3
17
0
3
0
18
0
1
19
0
3
20
0
3
0
21
0
1
22
0
2
23
0
end_DTG
begin_DTG
3
1
0
0
2
1
0
3
2
0
3
0
3
0
2
4
0
3
5
0
3
0
6
0
1
7
0
3
8
0
3
0
9
0
1
10
0
2
11
0
end_DTG
begin_DTG
4
1
24
2
4 4
1 0
1
26
2
4 4
1 1
1
28
2
4 4
1 2
1
30
2
4 4
1 3
8
0
40
2
4 0
1 0
0
42
2
4 1
1 1
0
44
2
4 2
1 2
0
46
2
4 3
1 3
2
25
2
4 4
1 0
2
27
2
4 4
1 1
2
29
2
4 4
1 2
2
31
2
4 4
1 3
4
1
41
2
4 0
1 0
1
43
2
4 1
1 1
1
45
2
4 2
1 2
1
47
2
4 3
1 3
end_DTG
begin_DTG
4
1
32
2
4 5
0 0
1
34
2
4 5
0 1
1
36
2
4 5
0 2
1
38
2
4 5
0 3
8
0
48
2
4 0
0 0
0
50
2
4 1
0 1
0
52
2
4 2
0 2
0
54
2
4 3
0 3
2
33
2
4 5
0 0
2
35
2
4 5
0 1
2
37
2
4 5
0 2
2
39
2
4 5
0 3
4
1
49
2
4 0
0 0
1
51
2
4 1
0 1
1
53
2
4 2
0 2
1
55
2
4 3
0 3
end_DTG
begin_DTG
4
4
40
2
1 0
2 1
4
41
2
1 0
2 2
5
48
2
0 0
3 1
5
49
2
0 0
3 2
4
4
42
2
1 1
2 1
4
43
2
1 1
2 2
5
50
2
0 1
3 1
5
51
2
0 1
3 2
4
4
44
2
1 2
2 1
4
45
2
1 2
2 2
5
52
2
0 2
3 1
5
53
2
0 2
3 2
4
4
46
2
1 3
2 1
4
47
2
1 3
2 2
5
54
2
0 3
3 1
5
55
2
0 3
3 2
8
0
24
2
1 0
2 0
0
25
2
1 0
2 1
1
26
2
1 1
2 0
1
27
2
1 1
2 1
2
28
2
1 2
2 0
2
29
2
1 2
2 1
3
30
2
1 3
2 0
3
31
2
1 3
2 1
8
0
32
2
0 0
3 0
0
33
2
0 0
3 1
1
34
2
0 1
3 0
1
35
2
0 1
3 1
2
36
2
0 2
3 0
2
37
2
0 2
3 1
3
38
2
0 3
3 0
3
39
2
0 3
3 1
end_DTG
begin_CG
2
4 16
3 16
2
4 16
2 16
1
4 16
1
4 16
2
2 16
3 16
end_CG
