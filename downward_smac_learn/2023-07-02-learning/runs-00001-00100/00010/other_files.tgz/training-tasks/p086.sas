begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var20
-1
15
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var19
-1
15
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var18
-1
15
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var17
-1
15
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var16
-1
15
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var15
-1
15
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var21
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var26
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
21
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
21
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
21
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
21
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
21
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
21
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l15)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
21
Atom at(p15, l1)
Atom at(p15, l10)
Atom at(p15, l11)
Atom at(p15, l12)
Atom at(p15, l13)
Atom at(p15, l14)
Atom at(p15, l15)
Atom at(p15, l2)
Atom at(p15, l3)
Atom at(p15, l4)
Atom at(p15, l5)
Atom at(p15, l6)
Atom at(p15, l7)
Atom at(p15, l8)
Atom at(p15, l9)
Atom in(p15, v1)
Atom in(p15, v2)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




17
2
5 14
6 2
16
4066
2
4 14
7 1
16
4067
2
4 14
7 2
17
4516
2
3 14
8 1
17
4517
2
3 14
8 2
18
4966
2
2 14
9 1
18
4967
2
2 14
9 2
19
5416
2
1 14
10 1
19
5417
2
1 14
10 2
20
5866
2
0 14
11 1
20
5867
2
0 14
11 2
30
0
497
2
5 0
6 1
0
496
2
5 0
6 0
1
526
2
5 1
6 0
1
527
2
5 1
6 1
2
556
2
5 2
6 0
2
557
2
5 2
6 1
3
586
2
5 3
6 0
3
587
2
5 3
6 1
4
616
2
5 4
6 0
4
617
2
5 4
6 1
5
646
2
5 5
6 0
5
647
2
5 5
6 1
6
676
2
5 6
6 0
6
677
2
5 6
6 1
7
707
2
5 7
6 1
7
706
2
5 7
6 0
8
736
2
5 8
6 0
8
737
2
5 8
6 1
9
766
2
5 9
6 0
9
767
2
5 9
6 1
10
796
2
5 10
6 0
10
797
2
5 10
6 1
11
826
2
5 11
6 0
11
827
2
5 11
6 1
12
856
2
5 12
6 0
12
857
2
5 12
6 1
13
886
2
5 13
6 0
13
887
2
5 13
6 1
14
916
2
5 14
6 0
14
917
2
5 14
6 1
30
0
947
2
4 0
7 1
0
946
2
4 0
7 0
1
976
2
4 1
7 0
1
977
2
4 1
7 1
2
1006
2
4 2
7 0
2
1007
2
4 2
7 1
3
1036
2
4 3
7 0
3
1037
2
4 3
7 1
4
1066
2
4 4
7 0
4
1067
2
4 4
7 1
5
1096
2
4 5
7 0
5
1097
2
4 5
7 1
6
1126
2
4 6
7 0
6
1127
2
4 6
7 1
7
1157
2
4 7
7 1
7
1156
2
4 7
7 0
8
1186
2
4 8
7 0
8
1187
2
4 8
7 1
9
1216
2
4 9
7 0
9
1217
2
4 9
7 1
10
1246
2
4 10
7 0
10
1247
2
4 10
7 1
11
1276
2
4 11
7 0
11
1277
2
4 11
7 1
12
1306
2
4 12
7 0
12
1307
2
4 12
7 1
13
1336
2
4 13
7 0
13
1337
2
4 13
7 1
14
1366
2
4 14
7 0
14
1367
2
4 14
7 1
30
0
1397
2
3 0
8 1
0
1396
2
3 0
8 0
1
1426
2
3 1
8 0
1
1427
2
3 1
8 1
2
1456
2
3 2
8 0
2
1457
2
3 2
8 1
3
1486
2
3 3
8 0
3
1487
2
3 3
8 1
4
1516
2
3 4
8 0
4
1517
2
3 4
8 1
5
1546
2
3 5
8 0
5
1547
2
3 5
8 1
6
1576
2
3 6
8 0
6
1577
2
3 6
8 1
7
1607
2
3 7
8 1
7
1606
2
3 7
8 0
8
1636
2
3 8
8 0
8
1637
2
3 8
8 1
9
1666
2
3 9
8 0
9
1667
2
3 9
8 1
10
1696
2
3 10
8 0
10
1697
2
3 10
8 1
11
1726
2
3 11
8 0
11
1727
2
3 11
8 1
12
1756
2
3 12
8 0
12
1757
2
3 12
8 1
13
1786
2
3 13
8 0
13
1787
2
3 13
8 1
14
1816
2
3 14
8 0
14
1817
2
3 14
8 1
30
0
1847
2
2 0
9 1
0
1846
2
2 0
9 0
1
1876
2
2 1
9 0
1
1877
2
2 1
9 1
2
1906
2
2 2
9 0
2
1907
2
2 2
9 1
3
1936
2
2 3
9 0
3
1937
2
2 3
9 1
4
1966
2
2 4
9 0
4
1967
2
2 4
9 1
5
1996
2
2 5
9 0
5
1997
2
2 5
9 1
6
2026
2
2 6
9 0
6
2027
2
2 6
9 1
7
2057
2
2 7
9 1
7
2056
2
2 7
9 0
8
2086
2
2 8
9 0
8
2087
2
2 8
9 1
9
2116
2
2 9
9 0
9
2117
2
2 9
9 1
10
2146
2
2 10
9 0
10
2147
2
2 10
9 1
11
2176
2
2 11
9 0
11
2177
2
2 11
9 1
12
2206
2
2 12
9 0
12
2207
2
2 12
9 1
13
2236
2
2 13
9 0
13
2237
2
2 13
9 1
14
2266
2
2 14
9 0
14
2267
2
2 14
9 1
30
0
2297
2
1 0
10 1
0
2296
2
1 0
10 0
1
2326
2
1 1
10 0
1
2327
2
1 1
10 1
2
2356
2
1 2
10 0
2
2357
2
1 2
10 1
3
2386
2
1 3
10 0
3
2387
2
1 3
10 1
4
2416
2
1 4
10 0
4
2417
2
1 4
10 1
5
2446
2
1 5
10 0
5
2447
2
1 5
10 1
6
2476
2
1 6
10 0
6
2477
2
1 6
10 1
7
2507
2
1 7
10 1
7
2506
2
1 7
10 0
8
2536
2
1 8
10 0
8
2537
2
1 8
10 1
9
2566
2
1 9
10 0
9
2567
2
1 9
10 1
10
2596
2
1 10
10 0
10
2597
2
1 10
10 1
11
2626
2
1 11
10 0
11
2627
2
1 11
10 1
12
2656
2
1 12
10 0
12
2657
2
1 12
10 1
13
2686
2
1 13
10 0
13
2687
2
1 13
10 1
14
2716
2
1 14
10 0
14
2717
2
1 14
10 1
30
0
2747
2
0 0
11 1
0
2746
2
0 0
11 0
1
2776
2
0 1
11 0
1
2777
2
0 1
11 1
2
2806
2
0 2
11 0
2
2807
2
0 2
11 1
3
2836
2
0 3
11 0
3
2837
2
0 3
11 1
4
2866
2
0 4
11 0
4
2867
2
0 4
11 1
5
2896
2
0 5
11 0
5
2897
2
0 5
11 1
6
2926
2
0 6
11 0
6
2927
2
0 6
11 1
7
2957
2
0 7
11 1
7
2956
2
0 7
11 0
8
2986
2
0 8
11 0
8
2987
2
0 8
11 1
9
3016
2
0 9
11 0
9
3017
2
0 9
11 1
10
3046
2
0 10
11 0
10
3047
2
0 10
11 1
11
3076
2
0 11
11 0
11
3077
2
0 11
11 1
12
3106
2
0 12
11 0
12
3107
2
0 12
11 1
13
3136
2
0 13
11 0
13
3137
2
0 13
11 1
14
3166
2
0 14
11 0
14
3167
2
0 14
11 1
end_DTG
begin_CG
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
11 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
10 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
9 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
8 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
7 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6 900
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
end_CG
