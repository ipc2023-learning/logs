begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var13
-1
11
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var12
-1
11
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var11
-1
11
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var10
-1
11
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var9
-1
11
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var14
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var16
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
16
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
16
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var2
-1
16
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var3
-1
16
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var4
-1
16
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var5
-1
16
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var6
-1
16
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var7
-1
16
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var8
-1
16
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
0
begin_state
8
7
1
2
3
2
2
1
1
2
4
4
8
3
4
1
0
1
10
end_state
begin_goal
9
10 6
11 2
12 5
13 0
14 7
15 0
16 4
17 2
18 3
end_goal
2260
begin_operator
drive v1 l1 l10
0
1
0 4 0 1
0
end_operator
begin_operator
drive v1 l1 l11
0
1
0 4 0 2
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 4 0 4
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 4 0 6
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 4 0 7
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 4 0 8
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 4 0 9
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 4 0 10
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 4 1 0
0
end_operator
begin_operator
drive v1 l10 l3
0
1
0 4 1 4
0
end_operator
begin_operator
drive v1 l10 l5
0
1
0 4 1 6
0
end_operator
begin_op




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
1 10
8 1
22
0
1087
2
0 0
9 1
0
1086
2
0 0
9 0
1
1104
2
0 1
9 0
1
1105
2
0 1
9 1
2
1122
2
0 2
9 0
2
1123
2
0 2
9 1
3
1140
2
0 3
9 0
3
1141
2
0 3
9 1
4
1158
2
0 4
9 0
4
1159
2
0 4
9 1
5
1177
2
0 5
9 1
5
1176
2
0 5
9 0
6
1194
2
0 6
9 0
6
1195
2
0 6
9 1
7
1212
2
0 7
9 0
7
1213
2
0 7
9 1
8
1230
2
0 8
9 0
8
1231
2
0 8
9 1
9
1248
2
0 9
9 0
9
1249
2
0 9
9 1
10
1266
2
0 10
9 0
10
1267
2
0 10
9 1
end_DTG
begin_DTG
10
11
1286
2
4 0
5 1
11
1287
2
4 0
5 2
12
1484
2
3 0
6 1
12
1485
2
3 0
6 2
13
1682
2
2 0
7 1
13
1683
2
2 0
7 2
14
1880
2
1 0
8 1
14
1881
2
1 0
8 2
15
2078
2
0 0
9 1
15
2079
2
0 0
9 2
10
11
1304
2
4 1
5 1
11
1305
2
4 1
5 2
12
1502
2
3 1
6 1
12
1503
2
3 1
6 2
13
1700
2
2 1
7 1
13
1701
2
2 1
7 2
14
1898
2
1 1
8 1
14
1899
2
1 1
8 2
15
2096
2
0 1
9 1
15
2097
2
0 1
9 2
10
11
1322
2
4 2
5 1
11
1323
2
4 2
5 2
12
1520
2
3 2
6 1
12
1521
2
3 2
6 2
13
1718
2
2 2
7 1
13
1719
2
2 2
7 2
14
1916
2
1 2
8 1
14
1917
2
1 2
8 2
15
2114
2
0 2
9 1
15
2115
2
0 2
9 2
10
11
1340
2
4 3
5 1
11
1341
2
4 3
5 2
12
1538
2
3 3
6 1
12
1539
2
3 3
6 2
13
1736
2
2 3
7 1
13
1737
2
2 3
7 2
14
1934
2
1 3
8 1
14
1935
2
1 3
8 2
15
2132
2
0 3
9 1
15
2133
2
0 3
9 2
10
11
1358
2
4 4
5 1
11
1359
2
4 4
5 2
12
1556
2
3 4
6 1
12
1557
2
3 4
6 2
13
1754
2
2 4
7 1
13
1755
2
2 4
7 2
14
1952
2
1 4
8 1
14
1953
2
1 4
8 2
15
2150
2
0 4
9 1
15
2151
2
0 4
9 2
10
11
1376
2
4 5
5 1
11
1377
2
4 5
5 2
12
1574
2
3 5
6 1
12
1575
2
3 5
6 2
13
1772
2
2 5
7 1
13
1773
2
2 5
7 2
14
1970
2
1 5
8 1
14
1971
2
1 5
8 2
15
2168
2
0 5
9 1
15
2169
2
0 5
9 2
10
11
1394
2
4 6
5 1
11
1395
2
4 6
5 2
12
1592
2
3 6
6 1
12
1593
2
3 6
6 2
13
1790
2
2 6
7 1
13
1791
2
2 6
7 2
14
1988
2
1 6
8 1
14
1989
2
1 6
8 2
15
2186
2
0 6
9 1
15
2187
2
0 6
9 2
10
11
1412
2
4 7
5 1
11
1413
2
4 7
5 2
12
1610
2
3 7
6 1
12
1611
2
3 7
6 2
13
1808
2
2 7
7 1
13
1809
2
2 7
7 2
14
2006
2
1 7
8 1
14
2007
2
1 7
8 2
15
2204
2
0 7
9 1
15
2205
2
0 7
9 2
10
11
1430
2
4 8
5 1
11
1431
2
4 8
5 2
12
1628
2
3 8
6 1
12
1629
2
3 8
6 2
13
1826
2
2 8
7 1
13
1827
2
2 8
7 2
14
2024
2
1 8
8 1
14
2025
2
1 8
8 2
15
2222
2
0 8
9 1
15
2223
2
0 8
9 2
10
11
1448
2
4 9
5 1
11
1449
2
4 9
5 2
12
1646
2
3 9
6 1
12
1647
2
3 9
6 2
13
1844
2
2 9
7 1
13
1845
2
2 9
7 2
14
2042
2
1 9
8 1
14
2043
2
1 9
8 2
15
2240
2
0 9
9 1
15
2241
2
0 9
9 2
10
11
1466
2
4 10
5 1
11
1467
2
4 10
5 2
12
1664
2
3 10
6 1
12
1665
2
3 10
6 2
13
1862
2
2 10
7 1
13
1863
2
2 10
7 2
14
2060
2
1 10
8 1
14
2061
2
1 10
8 2
15
2258
2
0 10
9 1
15
2259
2
0 10
9 2
22
0
297
2
4 0
5 1
0
296
2
4 0
5 0
1
314
2
4 1
5 0
1
315
2
4 1
5 1
2
332
2
4 2
5 0
2
333
2
4 2
5 1
3
350
2
4 3
5 0
3
351
2
4 3
5 1
4
368
2
4 4
5 0
4
369
2
4 4
5 1
5
387
2
4 5
5 1
5
386
2
4 5
5 0
6
404
2
4 6
5 0
6
405
2
4 6
5 1
7
422
2
4 7
5 0
7
423
2
4 7
5 1
8
440
2
4 8
5 0
8
441
2
4 8
5 1
9
458
2
4 9
5 0
9
459
2
4 9
5 1
10
476
2
4 10
5 0
10
477
2
4 10
5 1
22
0
495
2
3 0
6 1
0
494
2
3 0
6 0
1
512
2
3 1
6 0
1
513
2
3 1
6 1
2
530
2
3 2
6 0
2
531
2
3 2
6 1
3
548
2
3 3
6 0
3
549
2
3 3
6 1
4
566
2
3 4
6 0
4
567
2
3 4
6 1
5
585
2
3 5
6 1
5
584
2
3 5
6 0
6
602
2
3 6
6 0
6
603
2
3 6
6 1
7
620
2
3 7
6 0
7
621
2
3 7
6 1
8
638
2
3 8
6 0
8
639
2
3 8
6 1
9
656
2
3 9
6 0
9
657
2
3 9
6 1
10
674
2
3 10
6 0
10
675
2
3 10
6 1
22
0
693
2
2 0
7 1
0
692
2
2 0
7 0
1
710
2
2 1
7 0
1
711
2
2 1
7 1
2
728
2
2 2
7 0
2
729
2
2 2
7 1
3
746
2
2 3
7 0
3
747
2
2 3
7 1
4
764
2
2 4
7 0
4
765
2
2 4
7 1
5
783
2
2 5
7 1
5
782
2
2 5
7 0
6
800
2
2 6
7 0
6
801
2
2 6
7 1
7
818
2
2 7
7 0
7
819
2
2 7
7 1
8
836
2
2 8
7 0
8
837
2
2 8
7 1
9
854
2
2 9
7 0
9
855
2
2 9
7 1
10
872
2
2 10
7 0
10
873
2
2 10
7 1
22
0
891
2
1 0
8 1
0
890
2
1 0
8 0
1
908
2
1 1
8 0
1
909
2
1 1
8 1
2
926
2
1 2
8 0
2
927
2
1 2
8 1
3
944
2
1 3
8 0
3
945
2
1 3
8 1
4
962
2
1 4
8 0
4
963
2
1 4
8 1
5
981
2
1 5
8 1
5
980
2
1 5
8 0
6
998
2
1 6
8 0
6
999
2
1 6
8 1
7
1016
2
1 7
8 0
7
1017
2
1 7
8 1
8
1034
2
1 8
8 0
8
1035
2
1 8
8 1
9
1052
2
1 9
8 0
9
1053
2
1 9
8 1
10
1070
2
1 10
8 0
10
1071
2
1 10
8 1
22
0
1089
2
0 0
9 1
0
1088
2
0 0
9 0
1
1106
2
0 1
9 0
1
1107
2
0 1
9 1
2
1124
2
0 2
9 0
2
1125
2
0 2
9 1
3
1142
2
0 3
9 0
3
1143
2
0 3
9 1
4
1160
2
0 4
9 0
4
1161
2
0 4
9 1
5
1179
2
0 5
9 1
5
1178
2
0 5
9 0
6
1196
2
0 6
9 0
6
1197
2
0 6
9 1
7
1214
2
0 7
9 0
7
1215
2
0 7
9 1
8
1232
2
0 8
9 0
8
1233
2
0 8
9 1
9
1250
2
0 9
9 0
9
1251
2
0 9
9 1
10
1268
2
0 10
9 0
10
1269
2
0 10
9 1
end_DTG
begin_CG
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
8 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
7 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
6 396
10
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5 396
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
9
10 44
11 44
12 44
13 44
14 44
15 44
16 44
17 44
18 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
5
5 44
6 44
7 44
8 44
9 44
end_CG
