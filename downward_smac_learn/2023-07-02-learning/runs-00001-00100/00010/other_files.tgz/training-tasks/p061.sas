begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var15
-1
12
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var14
-1
12
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var13
-1
12
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var12
-1
12
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var11
-1
12
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var16
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
17
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
17
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
17
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
end_variable
begin_variable
var3
-1
17
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var4
-1
17
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var5
-1
17
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var6
-1
17
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var7
-1
17
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var8
-1
17
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var9
-1
17
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var10
-1
17
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l12)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
2
4 1
5 1
12
1913
2
4 1
5 2
13
2176
2
3 1
6 1
13
2177
2
3 1
6 2
14
2440
2
2 1
7 1
14
2441
2
2 1
7 2
15
2704
2
1 1
8 1
15
2705
2
1 1
8 2
16
2968
2
0 1
9 1
16
2969
2
0 1
9 2
10
12
1934
2
4 2
5 1
12
1935
2
4 2
5 2
13
2198
2
3 2
6 1
13
2199
2
3 2
6 2
14
2462
2
2 2
7 1
14
2463
2
2 2
7 2
15
2726
2
1 2
8 1
15
2727
2
1 2
8 2
16
2990
2
0 2
9 1
16
2991
2
0 2
9 2
10
12
1956
2
4 3
5 1
12
1957
2
4 3
5 2
13
2220
2
3 3
6 1
13
2221
2
3 3
6 2
14
2484
2
2 3
7 1
14
2485
2
2 3
7 2
15
2748
2
1 3
8 1
15
2749
2
1 3
8 2
16
3012
2
0 3
9 1
16
3013
2
0 3
9 2
10
12
1978
2
4 4
5 1
12
1979
2
4 4
5 2
13
2242
2
3 4
6 1
13
2243
2
3 4
6 2
14
2506
2
2 4
7 1
14
2507
2
2 4
7 2
15
2770
2
1 4
8 1
15
2771
2
1 4
8 2
16
3034
2
0 4
9 1
16
3035
2
0 4
9 2
10
12
2000
2
4 5
5 1
12
2001
2
4 5
5 2
13
2264
2
3 5
6 1
13
2265
2
3 5
6 2
14
2528
2
2 5
7 1
14
2529
2
2 5
7 2
15
2792
2
1 5
8 1
15
2793
2
1 5
8 2
16
3056
2
0 5
9 1
16
3057
2
0 5
9 2
10
12
2022
2
4 6
5 1
12
2023
2
4 6
5 2
13
2286
2
3 6
6 1
13
2287
2
3 6
6 2
14
2550
2
2 6
7 1
14
2551
2
2 6
7 2
15
2814
2
1 6
8 1
15
2815
2
1 6
8 2
16
3078
2
0 6
9 1
16
3079
2
0 6
9 2
10
12
2044
2
4 7
5 1
12
2045
2
4 7
5 2
13
2308
2
3 7
6 1
13
2309
2
3 7
6 2
14
2572
2
2 7
7 1
14
2573
2
2 7
7 2
15
2836
2
1 7
8 1
15
2837
2
1 7
8 2
16
3100
2
0 7
9 1
16
3101
2
0 7
9 2
10
12
2066
2
4 8
5 1
12
2067
2
4 8
5 2
13
2330
2
3 8
6 1
13
2331
2
3 8
6 2
14
2594
2
2 8
7 1
14
2595
2
2 8
7 2
15
2858
2
1 8
8 1
15
2859
2
1 8
8 2
16
3122
2
0 8
9 1
16
3123
2
0 8
9 2
10
12
2088
2
4 9
5 1
12
2089
2
4 9
5 2
13
2352
2
3 9
6 1
13
2353
2
3 9
6 2
14
2616
2
2 9
7 1
14
2617
2
2 9
7 2
15
2880
2
1 9
8 1
15
2881
2
1 9
8 2
16
3144
2
0 9
9 1
16
3145
2
0 9
9 2
10
12
2110
2
4 10
5 1
12
2111
2
4 10
5 2
13
2374
2
3 10
6 1
13
2375
2
3 10
6 2
14
2638
2
2 10
7 1
14
2639
2
2 10
7 2
15
2902
2
1 10
8 1
15
2903
2
1 10
8 2
16
3166
2
0 10
9 1
16
3167
2
0 10
9 2
10
12
2132
2
4 11
5 1
12
2133
2
4 11
5 2
13
2396
2
3 11
6 1
13
2397
2
3 11
6 2
14
2660
2
2 11
7 1
14
2661
2
2 11
7 2
15
2924
2
1 11
8 1
15
2925
2
1 11
8 2
16
3188
2
0 11
9 1
16
3189
2
0 11
9 2
24
0
571
2
4 0
5 1
0
570
2
4 0
5 0
1
592
2
4 1
5 0
1
593
2
4 1
5 1
2
614
2
4 2
5 0
2
615
2
4 2
5 1
3
636
2
4 3
5 0
3
637
2
4 3
5 1
4
658
2
4 4
5 0
4
659
2
4 4
5 1
5
680
2
4 5
5 0
5
681
2
4 5
5 1
6
702
2
4 6
5 0
6
703
2
4 6
5 1
7
724
2
4 7
5 0
7
725
2
4 7
5 1
8
746
2
4 8
5 0
8
747
2
4 8
5 1
9
768
2
4 9
5 0
9
769
2
4 9
5 1
10
790
2
4 10
5 0
10
791
2
4 10
5 1
11
812
2
4 11
5 0
11
813
2
4 11
5 1
24
0
835
2
3 0
6 1
0
834
2
3 0
6 0
1
856
2
3 1
6 0
1
857
2
3 1
6 1
2
878
2
3 2
6 0
2
879
2
3 2
6 1
3
900
2
3 3
6 0
3
901
2
3 3
6 1
4
922
2
3 4
6 0
4
923
2
3 4
6 1
5
944
2
3 5
6 0
5
945
2
3 5
6 1
6
966
2
3 6
6 0
6
967
2
3 6
6 1
7
988
2
3 7
6 0
7
989
2
3 7
6 1
8
1010
2
3 8
6 0
8
1011
2
3 8
6 1
9
1032
2
3 9
6 0
9
1033
2
3 9
6 1
10
1054
2
3 10
6 0
10
1055
2
3 10
6 1
11
1076
2
3 11
6 0
11
1077
2
3 11
6 1
24
0
1099
2
2 0
7 1
0
1098
2
2 0
7 0
1
1120
2
2 1
7 0
1
1121
2
2 1
7 1
2
1142
2
2 2
7 0
2
1143
2
2 2
7 1
3
1164
2
2 3
7 0
3
1165
2
2 3
7 1
4
1186
2
2 4
7 0
4
1187
2
2 4
7 1
5
1208
2
2 5
7 0
5
1209
2
2 5
7 1
6
1230
2
2 6
7 0
6
1231
2
2 6
7 1
7
1252
2
2 7
7 0
7
1253
2
2 7
7 1
8
1274
2
2 8
7 0
8
1275
2
2 8
7 1
9
1296
2
2 9
7 0
9
1297
2
2 9
7 1
10
1318
2
2 10
7 0
10
1319
2
2 10
7 1
11
1340
2
2 11
7 0
11
1341
2
2 11
7 1
24
0
1363
2
1 0
8 1
0
1362
2
1 0
8 0
1
1384
2
1 1
8 0
1
1385
2
1 1
8 1
2
1406
2
1 2
8 0
2
1407
2
1 2
8 1
3
1428
2
1 3
8 0
3
1429
2
1 3
8 1
4
1450
2
1 4
8 0
4
1451
2
1 4
8 1
5
1472
2
1 5
8 0
5
1473
2
1 5
8 1
6
1494
2
1 6
8 0
6
1495
2
1 6
8 1
7
1516
2
1 7
8 0
7
1517
2
1 7
8 1
8
1538
2
1 8
8 0
8
1539
2
1 8
8 1
9
1560
2
1 9
8 0
9
1561
2
1 9
8 1
10
1582
2
1 10
8 0
10
1583
2
1 10
8 1
11
1604
2
1 11
8 0
11
1605
2
1 11
8 1
24
0
1627
2
0 0
9 1
0
1626
2
0 0
9 0
1
1648
2
0 1
9 0
1
1649
2
0 1
9 1
2
1670
2
0 2
9 0
2
1671
2
0 2
9 1
3
1692
2
0 3
9 0
3
1693
2
0 3
9 1
4
1714
2
0 4
9 0
4
1715
2
0 4
9 1
5
1736
2
0 5
9 0
5
1737
2
0 5
9 1
6
1758
2
0 6
9 0
6
1759
2
0 6
9 1
7
1780
2
0 7
9 0
7
1781
2
0 7
9 1
8
1802
2
0 8
9 0
8
1803
2
0 8
9 1
9
1824
2
0 9
9 0
9
1825
2
0 9
9 1
10
1846
2
0 10
9 0
10
1847
2
0 10
9 1
11
1868
2
0 11
9 0
11
1869
2
0 11
9 1
end_DTG
begin_CG
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
9 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
8 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
7 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
6 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5 528
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
end_CG
