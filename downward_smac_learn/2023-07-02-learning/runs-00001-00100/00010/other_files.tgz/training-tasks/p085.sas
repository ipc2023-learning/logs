begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var20
-1
15
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var19
-1
15
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var18
-1
15
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var17
-1
15
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var16
-1
15
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var15
-1
15
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var21
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var26
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
21
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
21
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
21
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
21
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
21
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
21
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l15)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
21
Atom at(p15, l1)
Atom at(p15, l10)
Atom at(p15, l11)
Atom at(p15, l12)
Atom at(p15, l13)
Atom at(p15, l14)
Atom at(p15, l15)
Atom at(p15, l2)
Atom at(p15, l3)
Atom at(p15, l4)
Atom at(p15, l5)
Atom at(p15, l6)
Atom at(p15, l7)
Atom at(p15, l8)
Atom at(p15, l9)
Atom in(p15, v1)
Atom in(p15, v2)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




6
4835
2
4 14
7 2
17
5284
2
3 14
8 1
17
5285
2
3 14
8 2
18
5734
2
2 14
9 1
18
5735
2
2 14
9 2
19
6184
2
1 14
10 1
19
6185
2
1 14
10 2
20
6634
2
0 14
11 1
20
6635
2
0 14
11 2
30
0
1265
2
5 0
6 1
0
1264
2
5 0
6 0
1
1294
2
5 1
6 0
1
1295
2
5 1
6 1
2
1324
2
5 2
6 0
2
1325
2
5 2
6 1
3
1354
2
5 3
6 0
3
1355
2
5 3
6 1
4
1384
2
5 4
6 0
4
1385
2
5 4
6 1
5
1414
2
5 5
6 0
5
1415
2
5 5
6 1
6
1444
2
5 6
6 0
6
1445
2
5 6
6 1
7
1475
2
5 7
6 1
7
1474
2
5 7
6 0
8
1504
2
5 8
6 0
8
1505
2
5 8
6 1
9
1534
2
5 9
6 0
9
1535
2
5 9
6 1
10
1564
2
5 10
6 0
10
1565
2
5 10
6 1
11
1594
2
5 11
6 0
11
1595
2
5 11
6 1
12
1624
2
5 12
6 0
12
1625
2
5 12
6 1
13
1654
2
5 13
6 0
13
1655
2
5 13
6 1
14
1684
2
5 14
6 0
14
1685
2
5 14
6 1
30
0
1715
2
4 0
7 1
0
1714
2
4 0
7 0
1
1744
2
4 1
7 0
1
1745
2
4 1
7 1
2
1774
2
4 2
7 0
2
1775
2
4 2
7 1
3
1804
2
4 3
7 0
3
1805
2
4 3
7 1
4
1834
2
4 4
7 0
4
1835
2
4 4
7 1
5
1864
2
4 5
7 0
5
1865
2
4 5
7 1
6
1894
2
4 6
7 0
6
1895
2
4 6
7 1
7
1925
2
4 7
7 1
7
1924
2
4 7
7 0
8
1954
2
4 8
7 0
8
1955
2
4 8
7 1
9
1984
2
4 9
7 0
9
1985
2
4 9
7 1
10
2014
2
4 10
7 0
10
2015
2
4 10
7 1
11
2044
2
4 11
7 0
11
2045
2
4 11
7 1
12
2074
2
4 12
7 0
12
2075
2
4 12
7 1
13
2104
2
4 13
7 0
13
2105
2
4 13
7 1
14
2134
2
4 14
7 0
14
2135
2
4 14
7 1
30
0
2165
2
3 0
8 1
0
2164
2
3 0
8 0
1
2194
2
3 1
8 0
1
2195
2
3 1
8 1
2
2224
2
3 2
8 0
2
2225
2
3 2
8 1
3
2254
2
3 3
8 0
3
2255
2
3 3
8 1
4
2284
2
3 4
8 0
4
2285
2
3 4
8 1
5
2314
2
3 5
8 0
5
2315
2
3 5
8 1
6
2344
2
3 6
8 0
6
2345
2
3 6
8 1
7
2375
2
3 7
8 1
7
2374
2
3 7
8 0
8
2404
2
3 8
8 0
8
2405
2
3 8
8 1
9
2434
2
3 9
8 0
9
2435
2
3 9
8 1
10
2464
2
3 10
8 0
10
2465
2
3 10
8 1
11
2494
2
3 11
8 0
11
2495
2
3 11
8 1
12
2524
2
3 12
8 0
12
2525
2
3 12
8 1
13
2554
2
3 13
8 0
13
2555
2
3 13
8 1
14
2584
2
3 14
8 0
14
2585
2
3 14
8 1
30
0
2615
2
2 0
9 1
0
2614
2
2 0
9 0
1
2644
2
2 1
9 0
1
2645
2
2 1
9 1
2
2674
2
2 2
9 0
2
2675
2
2 2
9 1
3
2704
2
2 3
9 0
3
2705
2
2 3
9 1
4
2734
2
2 4
9 0
4
2735
2
2 4
9 1
5
2764
2
2 5
9 0
5
2765
2
2 5
9 1
6
2794
2
2 6
9 0
6
2795
2
2 6
9 1
7
2825
2
2 7
9 1
7
2824
2
2 7
9 0
8
2854
2
2 8
9 0
8
2855
2
2 8
9 1
9
2884
2
2 9
9 0
9
2885
2
2 9
9 1
10
2914
2
2 10
9 0
10
2915
2
2 10
9 1
11
2944
2
2 11
9 0
11
2945
2
2 11
9 1
12
2974
2
2 12
9 0
12
2975
2
2 12
9 1
13
3004
2
2 13
9 0
13
3005
2
2 13
9 1
14
3034
2
2 14
9 0
14
3035
2
2 14
9 1
30
0
3065
2
1 0
10 1
0
3064
2
1 0
10 0
1
3094
2
1 1
10 0
1
3095
2
1 1
10 1
2
3124
2
1 2
10 0
2
3125
2
1 2
10 1
3
3154
2
1 3
10 0
3
3155
2
1 3
10 1
4
3184
2
1 4
10 0
4
3185
2
1 4
10 1
5
3214
2
1 5
10 0
5
3215
2
1 5
10 1
6
3244
2
1 6
10 0
6
3245
2
1 6
10 1
7
3275
2
1 7
10 1
7
3274
2
1 7
10 0
8
3304
2
1 8
10 0
8
3305
2
1 8
10 1
9
3334
2
1 9
10 0
9
3335
2
1 9
10 1
10
3364
2
1 10
10 0
10
3365
2
1 10
10 1
11
3394
2
1 11
10 0
11
3395
2
1 11
10 1
12
3424
2
1 12
10 0
12
3425
2
1 12
10 1
13
3454
2
1 13
10 0
13
3455
2
1 13
10 1
14
3484
2
1 14
10 0
14
3485
2
1 14
10 1
30
0
3515
2
0 0
11 1
0
3514
2
0 0
11 0
1
3544
2
0 1
11 0
1
3545
2
0 1
11 1
2
3574
2
0 2
11 0
2
3575
2
0 2
11 1
3
3604
2
0 3
11 0
3
3605
2
0 3
11 1
4
3634
2
0 4
11 0
4
3635
2
0 4
11 1
5
3664
2
0 5
11 0
5
3665
2
0 5
11 1
6
3694
2
0 6
11 0
6
3695
2
0 6
11 1
7
3725
2
0 7
11 1
7
3724
2
0 7
11 0
8
3754
2
0 8
11 0
8
3755
2
0 8
11 1
9
3784
2
0 9
11 0
9
3785
2
0 9
11 1
10
3814
2
0 10
11 0
10
3815
2
0 10
11 1
11
3844
2
0 11
11 0
11
3845
2
0 11
11 1
12
3874
2
0 12
11 0
12
3875
2
0 12
11 1
13
3904
2
0 13
11 0
13
3905
2
0 13
11 1
14
3934
2
0 14
11 0
14
3935
2
0 14
11 1
end_DTG
begin_CG
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
11 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
10 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
9 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
8 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
7 900
16
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6 900
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
15
12 60
13 60
14 60
15 60
16 60
17 60
18 60
19 60
20 60
21 60
22 60
23 60
24 60
25 60
26 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
6
6 60
7 60
8 60
9 60
10 60
11 60
end_CG
