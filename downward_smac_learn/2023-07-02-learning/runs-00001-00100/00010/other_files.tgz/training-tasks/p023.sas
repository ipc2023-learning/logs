begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var6
-1
7
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
end_variable
begin_variable
var5
-1
7
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
end_variable
begin_variable
var4
-1
7
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
end_variable
begin_variable
var7
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var9
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
10
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
10
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
10
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
begin_variable
var3
-1
10
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
end_variable
0
begin_state
6
5
2
2
1
2
4
5
0
1
end_state
begin_goal
4
6 5
7 1
8 4
9 3
end_goal
402
begin_operator
drive v1 l1 l4
0
1
0 2 0 3
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 2 0 6
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 2 2 3
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 2 2 6
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 2 3 0
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l3
0
1
0 2 3 2
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l4 l6
0
1
0 2 3 5
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l6 l4
0
1
0 2 5 3
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 2 5 6
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 2 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 2 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 2 6 2
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 2 6 5
0
end_operator
begin_operator
drive v2 l1 l4
0
1
0 1 0 3
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l7
0
1
0 1 0 6
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 1 1 4
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 1 1 6
0
end_operator
begin_operator
drive v2 l3 l4
0
1
0 1 2 3
0
end_operator
begin_operator
drive v2 l3 l7
0
1
0 1 2 6
0
end_operator
begin_operator
drive v2 l4 l1
0
1
0 1 3 0
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l3
0
1
0 1 3 2
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l4 l6
0
1
0 1 3 5
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 1 4 1
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l6 l4
0
1
0 1 5 3
0
end_operator
begin_operator
drive v2 l6 l7
0
1
0 1 5 6
0
end_operator
begin_operator
drive v2 l7 l1
0
1
0 1 6 0
0
end_operator
begin_operator
drive v2 l7 l2
0
1
0 1 6 1
0
end_operator
begin_operator
drive v2 l7 l3
0
1
0 1 6 2
0
end_operator
begin_operator
drive v2 l7 l6
0
1
0 1 6 5
0
end_operator
begin_operator
drive v3 l1 l4
0
1
0 0 0 3
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l7
0
1
0 0 0 6
0
end_operator
begin_operator
drive v3 l2 l4
0
1
0 0 1 3
0
end_operator
begin_operator
drive v3 l2 l5
0
1
0 0 1 4
0
end_operator
begin_operator
drive v3 l2 l7
0
1
0 0 1 6
0
end_operator
begin_operator
drive v3 l3 l4
0
1
0 0 2 3
0
end_operator
begin_operator
drive v3 l3 l7
0
1
0 0 2 6
0
end_operator
begin_operator
drive v3 l4 l1
0
1
0 0 3 0
0
end_operator
begin_operator
drive v3 l4 l2
0
1
0 0 3 1
0
end_operator
begin_operator
drive v3 l4 l3
0
1
0 0 3 2
0
end_operator
begin_operator
drive v3 l4 l5
0
1
0 0 3 4
0
end_operator
begin_operator
drive v3 l4 l6
0
1
0 0 3 5
0
end_operator
begin_operator
drive v3 l5 l1
0
1
0 0 4 0
0
end_operator
begin_operator
drive v3 l5 l2
0
1
0 0 4 1
0
end_operator
begin_operator
drive v3 l5 l4
0
1
0 0 4 3
0
end_operator




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
2
2 6
3 2
8
338
2
1 6
4 1
8
339
2
1 6
4 2
9
394
2
0 6
5 1
9
395
2
0 6
5 2
14
0
66
2
2 0
3 0
0
67
2
2 0
3 1
1
74
2
2 1
3 0
1
75
2
2 1
3 1
2
82
2
2 2
3 0
2
83
2
2 2
3 1
3
90
2
2 3
3 0
3
91
2
2 3
3 1
4
98
2
2 4
3 0
4
99
2
2 4
3 1
5
106
2
2 5
3 0
5
107
2
2 5
3 1
6
114
2
2 6
3 0
6
115
2
2 6
3 1
14
0
122
2
1 0
4 0
0
123
2
1 0
4 1
1
130
2
1 1
4 0
1
131
2
1 1
4 1
2
138
2
1 2
4 0
2
139
2
1 2
4 1
3
146
2
1 3
4 0
3
147
2
1 3
4 1
4
154
2
1 4
4 0
4
155
2
1 4
4 1
5
162
2
1 5
4 0
5
163
2
1 5
4 1
6
170
2
1 6
4 0
6
171
2
1 6
4 1
14
0
178
2
0 0
5 0
0
179
2
0 0
5 1
1
186
2
0 1
5 0
1
187
2
0 1
5 1
2
194
2
0 2
5 0
2
195
2
0 2
5 1
3
202
2
0 3
5 0
3
203
2
0 3
5 1
4
210
2
0 4
5 0
4
211
2
0 4
5 1
5
218
2
0 5
5 0
5
219
2
0 5
5 1
6
226
2
0 6
5 0
6
227
2
0 6
5 1
end_DTG
begin_DTG
6
7
236
2
2 0
3 1
7
237
2
2 0
3 2
8
292
2
1 0
4 1
8
293
2
1 0
4 2
9
348
2
0 0
5 1
9
349
2
0 0
5 2
6
7
244
2
2 1
3 1
7
245
2
2 1
3 2
8
300
2
1 1
4 1
8
301
2
1 1
4 2
9
356
2
0 1
5 1
9
357
2
0 1
5 2
6
7
252
2
2 2
3 1
7
253
2
2 2
3 2
8
308
2
1 2
4 1
8
309
2
1 2
4 2
9
364
2
0 2
5 1
9
365
2
0 2
5 2
6
7
260
2
2 3
3 1
7
261
2
2 3
3 2
8
316
2
1 3
4 1
8
317
2
1 3
4 2
9
372
2
0 3
5 1
9
373
2
0 3
5 2
6
7
268
2
2 4
3 1
7
269
2
2 4
3 2
8
324
2
1 4
4 1
8
325
2
1 4
4 2
9
380
2
0 4
5 1
9
381
2
0 4
5 2
6
7
276
2
2 5
3 1
7
277
2
2 5
3 2
8
332
2
1 5
4 1
8
333
2
1 5
4 2
9
388
2
0 5
5 1
9
389
2
0 5
5 2
6
7
284
2
2 6
3 1
7
285
2
2 6
3 2
8
340
2
1 6
4 1
8
341
2
1 6
4 2
9
396
2
0 6
5 1
9
397
2
0 6
5 2
14
0
68
2
2 0
3 0
0
69
2
2 0
3 1
1
76
2
2 1
3 0
1
77
2
2 1
3 1
2
84
2
2 2
3 0
2
85
2
2 2
3 1
3
92
2
2 3
3 0
3
93
2
2 3
3 1
4
100
2
2 4
3 0
4
101
2
2 4
3 1
5
108
2
2 5
3 0
5
109
2
2 5
3 1
6
116
2
2 6
3 0
6
117
2
2 6
3 1
14
0
124
2
1 0
4 0
0
125
2
1 0
4 1
1
132
2
1 1
4 0
1
133
2
1 1
4 1
2
140
2
1 2
4 0
2
141
2
1 2
4 1
3
148
2
1 3
4 0
3
149
2
1 3
4 1
4
156
2
1 4
4 0
4
157
2
1 4
4 1
5
164
2
1 5
4 0
5
165
2
1 5
4 1
6
172
2
1 6
4 0
6
173
2
1 6
4 1
14
0
180
2
0 0
5 0
0
181
2
0 0
5 1
1
188
2
0 1
5 0
1
189
2
0 1
5 1
2
196
2
0 2
5 0
2
197
2
0 2
5 1
3
204
2
0 3
5 0
3
205
2
0 3
5 1
4
212
2
0 4
5 0
4
213
2
0 4
5 1
5
220
2
0 5
5 0
5
221
2
0 5
5 1
6
228
2
0 6
5 0
6
229
2
0 6
5 1
end_DTG
begin_DTG
6
7
238
2
2 0
3 1
7
239
2
2 0
3 2
8
294
2
1 0
4 1
8
295
2
1 0
4 2
9
350
2
0 0
5 1
9
351
2
0 0
5 2
6
7
246
2
2 1
3 1
7
247
2
2 1
3 2
8
302
2
1 1
4 1
8
303
2
1 1
4 2
9
358
2
0 1
5 1
9
359
2
0 1
5 2
6
7
254
2
2 2
3 1
7
255
2
2 2
3 2
8
310
2
1 2
4 1
8
311
2
1 2
4 2
9
366
2
0 2
5 1
9
367
2
0 2
5 2
6
7
262
2
2 3
3 1
7
263
2
2 3
3 2
8
318
2
1 3
4 1
8
319
2
1 3
4 2
9
374
2
0 3
5 1
9
375
2
0 3
5 2
6
7
270
2
2 4
3 1
7
271
2
2 4
3 2
8
326
2
1 4
4 1
8
327
2
1 4
4 2
9
382
2
0 4
5 1
9
383
2
0 4
5 2
6
7
278
2
2 5
3 1
7
279
2
2 5
3 2
8
334
2
1 5
4 1
8
335
2
1 5
4 2
9
390
2
0 5
5 1
9
391
2
0 5
5 2
6
7
286
2
2 6
3 1
7
287
2
2 6
3 2
8
342
2
1 6
4 1
8
343
2
1 6
4 2
9
398
2
0 6
5 1
9
399
2
0 6
5 2
14
0
70
2
2 0
3 0
0
71
2
2 0
3 1
1
78
2
2 1
3 0
1
79
2
2 1
3 1
2
86
2
2 2
3 0
2
87
2
2 2
3 1
3
94
2
2 3
3 0
3
95
2
2 3
3 1
4
102
2
2 4
3 0
4
103
2
2 4
3 1
5
110
2
2 5
3 0
5
111
2
2 5
3 1
6
118
2
2 6
3 0
6
119
2
2 6
3 1
14
0
126
2
1 0
4 0
0
127
2
1 0
4 1
1
134
2
1 1
4 0
1
135
2
1 1
4 1
2
142
2
1 2
4 0
2
143
2
1 2
4 1
3
150
2
1 3
4 0
3
151
2
1 3
4 1
4
158
2
1 4
4 0
4
159
2
1 4
4 1
5
166
2
1 5
4 0
5
167
2
1 5
4 1
6
174
2
1 6
4 0
6
175
2
1 6
4 1
14
0
182
2
0 0
5 0
0
183
2
0 0
5 1
1
190
2
0 1
5 0
1
191
2
0 1
5 1
2
198
2
0 2
5 0
2
199
2
0 2
5 1
3
206
2
0 3
5 0
3
207
2
0 3
5 1
4
214
2
0 4
5 0
4
215
2
0 4
5 1
5
222
2
0 5
5 0
5
223
2
0 5
5 1
6
230
2
0 6
5 0
6
231
2
0 6
5 1
end_DTG
begin_DTG
6
7
240
2
2 0
3 1
7
241
2
2 0
3 2
8
296
2
1 0
4 1
8
297
2
1 0
4 2
9
352
2
0 0
5 1
9
353
2
0 0
5 2
6
7
248
2
2 1
3 1
7
249
2
2 1
3 2
8
304
2
1 1
4 1
8
305
2
1 1
4 2
9
360
2
0 1
5 1
9
361
2
0 1
5 2
6
7
256
2
2 2
3 1
7
257
2
2 2
3 2
8
312
2
1 2
4 1
8
313
2
1 2
4 2
9
368
2
0 2
5 1
9
369
2
0 2
5 2
6
7
264
2
2 3
3 1
7
265
2
2 3
3 2
8
320
2
1 3
4 1
8
321
2
1 3
4 2
9
376
2
0 3
5 1
9
377
2
0 3
5 2
6
7
272
2
2 4
3 1
7
273
2
2 4
3 2
8
328
2
1 4
4 1
8
329
2
1 4
4 2
9
384
2
0 4
5 1
9
385
2
0 4
5 2
6
7
280
2
2 5
3 1
7
281
2
2 5
3 2
8
336
2
1 5
4 1
8
337
2
1 5
4 2
9
392
2
0 5
5 1
9
393
2
0 5
5 2
6
7
288
2
2 6
3 1
7
289
2
2 6
3 2
8
344
2
1 6
4 1
8
345
2
1 6
4 2
9
400
2
0 6
5 1
9
401
2
0 6
5 2
14
0
72
2
2 0
3 0
0
73
2
2 0
3 1
1
80
2
2 1
3 0
1
81
2
2 1
3 1
2
88
2
2 2
3 0
2
89
2
2 2
3 1
3
96
2
2 3
3 0
3
97
2
2 3
3 1
4
104
2
2 4
3 0
4
105
2
2 4
3 1
5
112
2
2 5
3 0
5
113
2
2 5
3 1
6
120
2
2 6
3 0
6
121
2
2 6
3 1
14
0
128
2
1 0
4 0
0
129
2
1 0
4 1
1
136
2
1 1
4 0
1
137
2
1 1
4 1
2
144
2
1 2
4 0
2
145
2
1 2
4 1
3
152
2
1 3
4 0
3
153
2
1 3
4 1
4
160
2
1 4
4 0
4
161
2
1 4
4 1
5
168
2
1 5
4 0
5
169
2
1 5
4 1
6
176
2
1 6
4 0
6
177
2
1 6
4 1
14
0
184
2
0 0
5 0
0
185
2
0 0
5 1
1
192
2
0 1
5 0
1
193
2
0 1
5 1
2
200
2
0 2
5 0
2
201
2
0 2
5 1
3
208
2
0 3
5 0
3
209
2
0 3
5 1
4
216
2
0 4
5 0
4
217
2
0 4
5 1
5
224
2
0 5
5 0
5
225
2
0 5
5 1
6
232
2
0 6
5 0
6
233
2
0 6
5 1
end_DTG
begin_CG
5
6 28
7 28
8 28
9 28
5 112
5
6 28
7 28
8 28
9 28
4 112
5
6 28
7 28
8 28
9 28
3 112
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
end_CG
