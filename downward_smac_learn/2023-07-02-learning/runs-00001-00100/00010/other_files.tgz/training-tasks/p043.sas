begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var11
-1
10
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var10
-1
10
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var9
-1
10
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var8
-1
10
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var12
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var13
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var14
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var15
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var0
-1
14
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
end_variable
begin_variable
var1
-1
14
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
end_variable
begin_variable
var2
-1
14
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
end_variable
begin_variable
var3
-1
14
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
end_variable
begin_variable
var4
-1
14
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
end_variable
begin_variable
var5
-1
14
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
end_variable
begin_variable
var6
-1
14
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
end_variable
begin_variable
var7
-1
14
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
end_variable
0
begin_state
9
5
9
3
2
1
2
1
9
6
4
8
8
9
6
1
end_state
begin_goal
8
8 8
9 4
10 1
11 5
12 2
13 3
14 7
15 9
end_goal
1568
begin_operator
drive v1 l1 l10
0
1
0 3 0 1
0
end_operator
begin_operator
drive v1 l1 l2
0
1
0 3 0 2
0
end_operator
begin_operator
drive v1 l1 l3
0
1
0 3 0 3
0
end_operator
begin_operator
drive v1 l1 l4
0
1
0 3 0 4
0
end_operator
begin_operator
drive v1 l1 l6
0
1
0 3 0 6
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 3 0 7
0
end_operator
begin_operator
drive v1 l1 l8
0
1
0 3 0 8
0
end_operator
begin_operator
drive v1 l1 l9
0
1
0 3 0 9
0
end_operator
begin_operator
drive v1 l10 l1
0
1
0 3 1 0
0
end_operator
begin_operator
drive v1 l10 l2
0
1
0 3 1 2
0
end_operator
begin_operator
drive v1 l10 l4
0
1
0 3 1 4
0
end_operator
begin_operator
drive v1 l10 l5
0
1
0 3 1 5
0
end_operator
begin_operator
drive v1 l10 l8
0
1
0 3 1 8
0
end_operator
begin_operator
drive v1 l10 l9
0
1
0 3 1 9
0
end_operator
begin_operator
drive v1 l2 l1
0
1
0 3 2 0
0
end_operator
begin_operator
drive v1 l2 l10
0
1
0 3 2 1
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 3 2 5
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 3 2 6
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 3 2 7
0
end_operator
begin_operator
drive v1 l2 l8
0
1
0 3 2 8
0
end_operator
begin_operator
drive v1 l2 l9
0
1
0 3 2 9
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 3 3 0
0
end_operator
begin_operator
drive v1 l3 l4
0
1
0 3 3 4
0
end_operator
begin_operator
drive v1 l3 l5
0
1
0 3 3 5
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 3 3 6
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 3 3 7
0
end_operator
begin_operator
drive v1 l3 l9
0
1
0 3 3 9
0
end_operator
begin_operator
drive v1 l4 l1
0
1
0 3 4 0
0
end_operator
begi




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
13
1517
2
0 6
7 2
8
10
1052
2
3 7
4 1
10
1053
2
3 7
4 2
11
1212
2
2 7
5 1
11
1213
2
2 7
5 2
12
1372
2
1 7
6 1
12
1373
2
1 7
6 2
13
1532
2
0 7
7 1
13
1533
2
0 7
7 2
8
10
1068
2
3 8
4 1
10
1069
2
3 8
4 2
11
1228
2
2 8
5 1
11
1229
2
2 8
5 2
12
1388
2
1 8
6 1
12
1389
2
1 8
6 2
13
1548
2
0 8
7 1
13
1549
2
0 8
7 2
8
10
1084
2
3 9
4 1
10
1085
2
3 9
4 2
11
1244
2
2 9
5 1
11
1245
2
2 9
5 2
12
1404
2
1 9
6 1
12
1405
2
1 9
6 2
13
1564
2
0 9
7 1
13
1565
2
0 9
7 2
20
0
301
2
3 0
4 1
0
300
2
3 0
4 0
1
316
2
3 1
4 0
1
317
2
3 1
4 1
2
332
2
3 2
4 0
2
333
2
3 2
4 1
3
348
2
3 3
4 0
3
349
2
3 3
4 1
4
364
2
3 4
4 0
4
365
2
3 4
4 1
5
380
2
3 5
4 0
5
381
2
3 5
4 1
6
396
2
3 6
4 0
6
397
2
3 6
4 1
7
412
2
3 7
4 0
7
413
2
3 7
4 1
8
428
2
3 8
4 0
8
429
2
3 8
4 1
9
444
2
3 9
4 0
9
445
2
3 9
4 1
20
0
461
2
2 0
5 1
0
460
2
2 0
5 0
1
476
2
2 1
5 0
1
477
2
2 1
5 1
2
492
2
2 2
5 0
2
493
2
2 2
5 1
3
508
2
2 3
5 0
3
509
2
2 3
5 1
4
524
2
2 4
5 0
4
525
2
2 4
5 1
5
540
2
2 5
5 0
5
541
2
2 5
5 1
6
556
2
2 6
5 0
6
557
2
2 6
5 1
7
572
2
2 7
5 0
7
573
2
2 7
5 1
8
588
2
2 8
5 0
8
589
2
2 8
5 1
9
604
2
2 9
5 0
9
605
2
2 9
5 1
20
0
621
2
1 0
6 1
0
620
2
1 0
6 0
1
636
2
1 1
6 0
1
637
2
1 1
6 1
2
652
2
1 2
6 0
2
653
2
1 2
6 1
3
668
2
1 3
6 0
3
669
2
1 3
6 1
4
684
2
1 4
6 0
4
685
2
1 4
6 1
5
700
2
1 5
6 0
5
701
2
1 5
6 1
6
716
2
1 6
6 0
6
717
2
1 6
6 1
7
732
2
1 7
6 0
7
733
2
1 7
6 1
8
748
2
1 8
6 0
8
749
2
1 8
6 1
9
764
2
1 9
6 0
9
765
2
1 9
6 1
20
0
781
2
0 0
7 1
0
780
2
0 0
7 0
1
796
2
0 1
7 0
1
797
2
0 1
7 1
2
812
2
0 2
7 0
2
813
2
0 2
7 1
3
828
2
0 3
7 0
3
829
2
0 3
7 1
4
844
2
0 4
7 0
4
845
2
0 4
7 1
5
860
2
0 5
7 0
5
861
2
0 5
7 1
6
876
2
0 6
7 0
6
877
2
0 6
7 1
7
892
2
0 7
7 0
7
893
2
0 7
7 1
8
908
2
0 8
7 0
8
909
2
0 8
7 1
9
924
2
0 9
7 0
9
925
2
0 9
7 1
end_DTG
begin_DTG
8
10
942
2
3 0
4 1
10
943
2
3 0
4 2
11
1102
2
2 0
5 1
11
1103
2
2 0
5 2
12
1262
2
1 0
6 1
12
1263
2
1 0
6 2
13
1422
2
0 0
7 1
13
1423
2
0 0
7 2
8
10
958
2
3 1
4 1
10
959
2
3 1
4 2
11
1118
2
2 1
5 1
11
1119
2
2 1
5 2
12
1278
2
1 1
6 1
12
1279
2
1 1
6 2
13
1438
2
0 1
7 1
13
1439
2
0 1
7 2
8
10
974
2
3 2
4 1
10
975
2
3 2
4 2
11
1134
2
2 2
5 1
11
1135
2
2 2
5 2
12
1294
2
1 2
6 1
12
1295
2
1 2
6 2
13
1454
2
0 2
7 1
13
1455
2
0 2
7 2
8
10
990
2
3 3
4 1
10
991
2
3 3
4 2
11
1150
2
2 3
5 1
11
1151
2
2 3
5 2
12
1310
2
1 3
6 1
12
1311
2
1 3
6 2
13
1470
2
0 3
7 1
13
1471
2
0 3
7 2
8
10
1006
2
3 4
4 1
10
1007
2
3 4
4 2
11
1166
2
2 4
5 1
11
1167
2
2 4
5 2
12
1326
2
1 4
6 1
12
1327
2
1 4
6 2
13
1486
2
0 4
7 1
13
1487
2
0 4
7 2
8
10
1022
2
3 5
4 1
10
1023
2
3 5
4 2
11
1182
2
2 5
5 1
11
1183
2
2 5
5 2
12
1342
2
1 5
6 1
12
1343
2
1 5
6 2
13
1502
2
0 5
7 1
13
1503
2
0 5
7 2
8
10
1038
2
3 6
4 1
10
1039
2
3 6
4 2
11
1198
2
2 6
5 1
11
1199
2
2 6
5 2
12
1358
2
1 6
6 1
12
1359
2
1 6
6 2
13
1518
2
0 6
7 1
13
1519
2
0 6
7 2
8
10
1054
2
3 7
4 1
10
1055
2
3 7
4 2
11
1214
2
2 7
5 1
11
1215
2
2 7
5 2
12
1374
2
1 7
6 1
12
1375
2
1 7
6 2
13
1534
2
0 7
7 1
13
1535
2
0 7
7 2
8
10
1070
2
3 8
4 1
10
1071
2
3 8
4 2
11
1230
2
2 8
5 1
11
1231
2
2 8
5 2
12
1390
2
1 8
6 1
12
1391
2
1 8
6 2
13
1550
2
0 8
7 1
13
1551
2
0 8
7 2
8
10
1086
2
3 9
4 1
10
1087
2
3 9
4 2
11
1246
2
2 9
5 1
11
1247
2
2 9
5 2
12
1406
2
1 9
6 1
12
1407
2
1 9
6 2
13
1566
2
0 9
7 1
13
1567
2
0 9
7 2
20
0
303
2
3 0
4 1
0
302
2
3 0
4 0
1
318
2
3 1
4 0
1
319
2
3 1
4 1
2
334
2
3 2
4 0
2
335
2
3 2
4 1
3
350
2
3 3
4 0
3
351
2
3 3
4 1
4
366
2
3 4
4 0
4
367
2
3 4
4 1
5
382
2
3 5
4 0
5
383
2
3 5
4 1
6
398
2
3 6
4 0
6
399
2
3 6
4 1
7
414
2
3 7
4 0
7
415
2
3 7
4 1
8
430
2
3 8
4 0
8
431
2
3 8
4 1
9
446
2
3 9
4 0
9
447
2
3 9
4 1
20
0
463
2
2 0
5 1
0
462
2
2 0
5 0
1
478
2
2 1
5 0
1
479
2
2 1
5 1
2
494
2
2 2
5 0
2
495
2
2 2
5 1
3
510
2
2 3
5 0
3
511
2
2 3
5 1
4
526
2
2 4
5 0
4
527
2
2 4
5 1
5
542
2
2 5
5 0
5
543
2
2 5
5 1
6
558
2
2 6
5 0
6
559
2
2 6
5 1
7
574
2
2 7
5 0
7
575
2
2 7
5 1
8
590
2
2 8
5 0
8
591
2
2 8
5 1
9
606
2
2 9
5 0
9
607
2
2 9
5 1
20
0
623
2
1 0
6 1
0
622
2
1 0
6 0
1
638
2
1 1
6 0
1
639
2
1 1
6 1
2
654
2
1 2
6 0
2
655
2
1 2
6 1
3
670
2
1 3
6 0
3
671
2
1 3
6 1
4
686
2
1 4
6 0
4
687
2
1 4
6 1
5
702
2
1 5
6 0
5
703
2
1 5
6 1
6
718
2
1 6
6 0
6
719
2
1 6
6 1
7
734
2
1 7
6 0
7
735
2
1 7
6 1
8
750
2
1 8
6 0
8
751
2
1 8
6 1
9
766
2
1 9
6 0
9
767
2
1 9
6 1
20
0
783
2
0 0
7 1
0
782
2
0 0
7 0
1
798
2
0 1
7 0
1
799
2
0 1
7 1
2
814
2
0 2
7 0
2
815
2
0 2
7 1
3
830
2
0 3
7 0
3
831
2
0 3
7 1
4
846
2
0 4
7 0
4
847
2
0 4
7 1
5
862
2
0 5
7 0
5
863
2
0 5
7 1
6
878
2
0 6
7 0
6
879
2
0 6
7 1
7
894
2
0 7
7 0
7
895
2
0 7
7 1
8
910
2
0 8
7 0
8
911
2
0 8
7 1
9
926
2
0 9
7 0
9
927
2
0 9
7 1
end_DTG
begin_CG
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
7 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
6 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
5 320
9
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
4 320
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
8
8 40
9 40
10 40
11 40
12 40
13 40
14 40
15 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
4
4 40
5 40
6 40
7 40
end_CG
