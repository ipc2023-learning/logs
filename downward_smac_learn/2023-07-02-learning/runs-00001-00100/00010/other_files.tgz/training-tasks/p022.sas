begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var6
-1
7
Atom at(v3, l1)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
end_variable
begin_variable
var5
-1
7
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
end_variable
begin_variable
var4
-1
7
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
end_variable
begin_variable
var7
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var8
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var9
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var0
-1
10
Atom at(p1, l1)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
end_variable
begin_variable
var1
-1
10
Atom at(p2, l1)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
end_variable
begin_variable
var2
-1
10
Atom at(p3, l1)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
begin_variable
var3
-1
10
Atom at(p4, l1)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
end_variable
0
begin_state
0
5
3
2
2
2
2
3
5
0
end_state
begin_goal
4
6 0
7 0
8 0
9 2
end_goal
420
begin_operator
drive v1 l1 l3
0
1
0 2 0 2
0
end_operator
begin_operator
drive v1 l1 l5
0
1
0 2 0 4
0
end_operator
begin_operator
drive v1 l1 l7
0
1
0 2 0 6
0
end_operator
begin_operator
drive v1 l2 l3
0
1
0 2 1 2
0
end_operator
begin_operator
drive v1 l2 l4
0
1
0 2 1 3
0
end_operator
begin_operator
drive v1 l2 l5
0
1
0 2 1 4
0
end_operator
begin_operator
drive v1 l2 l6
0
1
0 2 1 5
0
end_operator
begin_operator
drive v1 l2 l7
0
1
0 2 1 6
0
end_operator
begin_operator
drive v1 l3 l1
0
1
0 2 2 0
0
end_operator
begin_operator
drive v1 l3 l2
0
1
0 2 2 1
0
end_operator
begin_operator
drive v1 l3 l6
0
1
0 2 2 5
0
end_operator
begin_operator
drive v1 l3 l7
0
1
0 2 2 6
0
end_operator
begin_operator
drive v1 l4 l2
0
1
0 2 3 1
0
end_operator
begin_operator
drive v1 l4 l5
0
1
0 2 3 4
0
end_operator
begin_operator
drive v1 l4 l7
0
1
0 2 3 6
0
end_operator
begin_operator
drive v1 l5 l1
0
1
0 2 4 0
0
end_operator
begin_operator
drive v1 l5 l2
0
1
0 2 4 1
0
end_operator
begin_operator
drive v1 l5 l4
0
1
0 2 4 3
0
end_operator
begin_operator
drive v1 l5 l6
0
1
0 2 4 5
0
end_operator
begin_operator
drive v1 l6 l2
0
1
0 2 5 1
0
end_operator
begin_operator
drive v1 l6 l3
0
1
0 2 5 2
0
end_operator
begin_operator
drive v1 l6 l5
0
1
0 2 5 4
0
end_operator
begin_operator
drive v1 l6 l7
0
1
0 2 5 6
0
end_operator
begin_operator
drive v1 l7 l1
0
1
0 2 6 0
0
end_operator
begin_operator
drive v1 l7 l2
0
1
0 2 6 1
0
end_operator
begin_operator
drive v1 l7 l3
0
1
0 2 6 2
0
end_operator
begin_operator
drive v1 l7 l4
0
1
0 2 6 3
0
end_operator
begin_operator
drive v1 l7 l6
0
1
0 2 6 5
0
end_operator
begin_operator
drive v2 l1 l3
0
1
0 1 0 2
0
end_operator
begin_operator
drive v2 l1 l5
0
1
0 1 0 4
0
end_operator
begin_operator
drive v2 l1 l7
0
1
0 1 0 6
0
end_operator
begin_operator
drive v2 l2 l3
0
1
0 1 1 2
0
end_operator
begin_operator
drive v2 l2 l4
0
1
0 1 1 3
0
end_operator
begin_operator
drive v2 l2 l5
0
1
0 1 1 4
0
end_operator
begin_operator
drive v2 l2 l6
0
1
0 1 1 5
0
end_operator
begin_operator
drive v2 l2 l7
0
1
0 1 1 6
0
end_operator
begin_operator
drive v2 l3 l1
0
1
0 1 2 0
0
end_operator
begin_operator
drive v2 l3 l2
0
1
0 1 2 1
0
end_operator
begin_operator
drive v2 l3 l6
0
1
0 1 2 5
0
end_operator
begin_operator
drive v2 l3 l7
0
1
0 1 2 6
0
end_operator
begin_operator
drive v2 l4 l2
0
1
0 1 3 1
0
end_operator
begin_operator
drive v2 l4 l5
0
1
0 1 3 4
0
end_operator
begin_operator
drive v2 l4 l7
0
1
0 1 3 6
0
end_operator
begin_operator
drive v2 l5 l1
0
1
0 1 4 0
0
end_operator
begin_operator
drive v2 l5 l2
0
1
0 1 4 1
0
end_operator
begin_operator
drive v2 l5 l4
0
1
0 1 4 3
0
end_operator
begin_operator
drive v2 l5 l6
0
1
0 1 4 5
0
end_operator
begin_operator
drive v2 l6 l2
0
1
0 1 5 1
0
end_operator
begin_operator
drive v2 l6 l3
0
1
0 1 5 2
0
end_operator
begin_operator
drive v2 l6 l5
0
1
0 1 5 4
0
end_operator
begin_operator
drive v2 l6 l7
0
1
0 1 5 6
0
end_operator
begin_operator
drive v2 l7 l1
0
1
0 1 6 0
0
end_operator
begin_operator
drive v2 l7 l2
0
1
0 1 6 1
0
end_operator
begin_operator
drive v2 l7 l3
0
1
0 1 6 2
0
end_operator
begin_operator
drive v2 l7 l4
0
1
0 1 6 3
0
end_operator
begin_operator
drive v2 l7 l6
0
1
0 1 6 5
0
end_operator
begin_operator
drive v3 l1 l3
0
1
0 0 0 2
0
end_operator
begin_operator
drive v3 l1 l5
0
1
0 0 0 4
0
end_operator
begin_operator
drive v3 l1 l7
0
1
0 0 0 6
0
end_operator
begin_operator
drive v3 l2 l3
0
1
0 0 1 2
0
end_operator




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
1 6
4 1
8
357
2
1 6
4 2
9
412
2
0 6
5 1
9
413
2
0 6
5 2
14
0
84
2
2 0
3 0
0
85
2
2 0
3 1
1
92
2
2 1
3 0
1
93
2
2 1
3 1
2
100
2
2 2
3 0
2
101
2
2 2
3 1
3
108
2
2 3
3 0
3
109
2
2 3
3 1
4
116
2
2 4
3 0
4
117
2
2 4
3 1
5
124
2
2 5
3 0
5
125
2
2 5
3 1
6
132
2
2 6
3 0
6
133
2
2 6
3 1
14
0
140
2
1 0
4 0
0
141
2
1 0
4 1
1
148
2
1 1
4 0
1
149
2
1 1
4 1
2
156
2
1 2
4 0
2
157
2
1 2
4 1
3
164
2
1 3
4 0
3
165
2
1 3
4 1
4
172
2
1 4
4 0
4
173
2
1 4
4 1
5
180
2
1 5
4 0
5
181
2
1 5
4 1
6
188
2
1 6
4 0
6
189
2
1 6
4 1
14
0
196
2
0 0
5 0
0
197
2
0 0
5 1
1
204
2
0 1
5 0
1
205
2
0 1
5 1
2
212
2
0 2
5 0
2
213
2
0 2
5 1
3
220
2
0 3
5 0
3
221
2
0 3
5 1
4
228
2
0 4
5 0
4
229
2
0 4
5 1
5
236
2
0 5
5 0
5
237
2
0 5
5 1
6
244
2
0 6
5 0
6
245
2
0 6
5 1
end_DTG
begin_DTG
6
7
254
2
2 0
3 1
7
255
2
2 0
3 2
8
310
2
1 0
4 1
8
311
2
1 0
4 2
9
366
2
0 0
5 1
9
367
2
0 0
5 2
6
7
262
2
2 1
3 1
7
263
2
2 1
3 2
8
318
2
1 1
4 1
8
319
2
1 1
4 2
9
374
2
0 1
5 1
9
375
2
0 1
5 2
6
7
270
2
2 2
3 1
7
271
2
2 2
3 2
8
326
2
1 2
4 1
8
327
2
1 2
4 2
9
382
2
0 2
5 1
9
383
2
0 2
5 2
6
7
278
2
2 3
3 1
7
279
2
2 3
3 2
8
334
2
1 3
4 1
8
335
2
1 3
4 2
9
390
2
0 3
5 1
9
391
2
0 3
5 2
6
7
286
2
2 4
3 1
7
287
2
2 4
3 2
8
342
2
1 4
4 1
8
343
2
1 4
4 2
9
398
2
0 4
5 1
9
399
2
0 4
5 2
6
7
294
2
2 5
3 1
7
295
2
2 5
3 2
8
350
2
1 5
4 1
8
351
2
1 5
4 2
9
406
2
0 5
5 1
9
407
2
0 5
5 2
6
7
302
2
2 6
3 1
7
303
2
2 6
3 2
8
358
2
1 6
4 1
8
359
2
1 6
4 2
9
414
2
0 6
5 1
9
415
2
0 6
5 2
14
0
86
2
2 0
3 0
0
87
2
2 0
3 1
1
94
2
2 1
3 0
1
95
2
2 1
3 1
2
102
2
2 2
3 0
2
103
2
2 2
3 1
3
110
2
2 3
3 0
3
111
2
2 3
3 1
4
118
2
2 4
3 0
4
119
2
2 4
3 1
5
126
2
2 5
3 0
5
127
2
2 5
3 1
6
134
2
2 6
3 0
6
135
2
2 6
3 1
14
0
142
2
1 0
4 0
0
143
2
1 0
4 1
1
150
2
1 1
4 0
1
151
2
1 1
4 1
2
158
2
1 2
4 0
2
159
2
1 2
4 1
3
166
2
1 3
4 0
3
167
2
1 3
4 1
4
174
2
1 4
4 0
4
175
2
1 4
4 1
5
182
2
1 5
4 0
5
183
2
1 5
4 1
6
190
2
1 6
4 0
6
191
2
1 6
4 1
14
0
198
2
0 0
5 0
0
199
2
0 0
5 1
1
206
2
0 1
5 0
1
207
2
0 1
5 1
2
214
2
0 2
5 0
2
215
2
0 2
5 1
3
222
2
0 3
5 0
3
223
2
0 3
5 1
4
230
2
0 4
5 0
4
231
2
0 4
5 1
5
238
2
0 5
5 0
5
239
2
0 5
5 1
6
246
2
0 6
5 0
6
247
2
0 6
5 1
end_DTG
begin_DTG
6
7
256
2
2 0
3 1
7
257
2
2 0
3 2
8
312
2
1 0
4 1
8
313
2
1 0
4 2
9
368
2
0 0
5 1
9
369
2
0 0
5 2
6
7
264
2
2 1
3 1
7
265
2
2 1
3 2
8
320
2
1 1
4 1
8
321
2
1 1
4 2
9
376
2
0 1
5 1
9
377
2
0 1
5 2
6
7
272
2
2 2
3 1
7
273
2
2 2
3 2
8
328
2
1 2
4 1
8
329
2
1 2
4 2
9
384
2
0 2
5 1
9
385
2
0 2
5 2
6
7
280
2
2 3
3 1
7
281
2
2 3
3 2
8
336
2
1 3
4 1
8
337
2
1 3
4 2
9
392
2
0 3
5 1
9
393
2
0 3
5 2
6
7
288
2
2 4
3 1
7
289
2
2 4
3 2
8
344
2
1 4
4 1
8
345
2
1 4
4 2
9
400
2
0 4
5 1
9
401
2
0 4
5 2
6
7
296
2
2 5
3 1
7
297
2
2 5
3 2
8
352
2
1 5
4 1
8
353
2
1 5
4 2
9
408
2
0 5
5 1
9
409
2
0 5
5 2
6
7
304
2
2 6
3 1
7
305
2
2 6
3 2
8
360
2
1 6
4 1
8
361
2
1 6
4 2
9
416
2
0 6
5 1
9
417
2
0 6
5 2
14
0
88
2
2 0
3 0
0
89
2
2 0
3 1
1
96
2
2 1
3 0
1
97
2
2 1
3 1
2
104
2
2 2
3 0
2
105
2
2 2
3 1
3
112
2
2 3
3 0
3
113
2
2 3
3 1
4
120
2
2 4
3 0
4
121
2
2 4
3 1
5
128
2
2 5
3 0
5
129
2
2 5
3 1
6
136
2
2 6
3 0
6
137
2
2 6
3 1
14
0
144
2
1 0
4 0
0
145
2
1 0
4 1
1
152
2
1 1
4 0
1
153
2
1 1
4 1
2
160
2
1 2
4 0
2
161
2
1 2
4 1
3
168
2
1 3
4 0
3
169
2
1 3
4 1
4
176
2
1 4
4 0
4
177
2
1 4
4 1
5
184
2
1 5
4 0
5
185
2
1 5
4 1
6
192
2
1 6
4 0
6
193
2
1 6
4 1
14
0
200
2
0 0
5 0
0
201
2
0 0
5 1
1
208
2
0 1
5 0
1
209
2
0 1
5 1
2
216
2
0 2
5 0
2
217
2
0 2
5 1
3
224
2
0 3
5 0
3
225
2
0 3
5 1
4
232
2
0 4
5 0
4
233
2
0 4
5 1
5
240
2
0 5
5 0
5
241
2
0 5
5 1
6
248
2
0 6
5 0
6
249
2
0 6
5 1
end_DTG
begin_DTG
6
7
258
2
2 0
3 1
7
259
2
2 0
3 2
8
314
2
1 0
4 1
8
315
2
1 0
4 2
9
370
2
0 0
5 1
9
371
2
0 0
5 2
6
7
266
2
2 1
3 1
7
267
2
2 1
3 2
8
322
2
1 1
4 1
8
323
2
1 1
4 2
9
378
2
0 1
5 1
9
379
2
0 1
5 2
6
7
274
2
2 2
3 1
7
275
2
2 2
3 2
8
330
2
1 2
4 1
8
331
2
1 2
4 2
9
386
2
0 2
5 1
9
387
2
0 2
5 2
6
7
282
2
2 3
3 1
7
283
2
2 3
3 2
8
338
2
1 3
4 1
8
339
2
1 3
4 2
9
394
2
0 3
5 1
9
395
2
0 3
5 2
6
7
290
2
2 4
3 1
7
291
2
2 4
3 2
8
346
2
1 4
4 1
8
347
2
1 4
4 2
9
402
2
0 4
5 1
9
403
2
0 4
5 2
6
7
298
2
2 5
3 1
7
299
2
2 5
3 2
8
354
2
1 5
4 1
8
355
2
1 5
4 2
9
410
2
0 5
5 1
9
411
2
0 5
5 2
6
7
306
2
2 6
3 1
7
307
2
2 6
3 2
8
362
2
1 6
4 1
8
363
2
1 6
4 2
9
418
2
0 6
5 1
9
419
2
0 6
5 2
14
0
90
2
2 0
3 0
0
91
2
2 0
3 1
1
98
2
2 1
3 0
1
99
2
2 1
3 1
2
106
2
2 2
3 0
2
107
2
2 2
3 1
3
114
2
2 3
3 0
3
115
2
2 3
3 1
4
122
2
2 4
3 0
4
123
2
2 4
3 1
5
130
2
2 5
3 0
5
131
2
2 5
3 1
6
138
2
2 6
3 0
6
139
2
2 6
3 1
14
0
146
2
1 0
4 0
0
147
2
1 0
4 1
1
154
2
1 1
4 0
1
155
2
1 1
4 1
2
162
2
1 2
4 0
2
163
2
1 2
4 1
3
170
2
1 3
4 0
3
171
2
1 3
4 1
4
178
2
1 4
4 0
4
179
2
1 4
4 1
5
186
2
1 5
4 0
5
187
2
1 5
4 1
6
194
2
1 6
4 0
6
195
2
1 6
4 1
14
0
202
2
0 0
5 0
0
203
2
0 0
5 1
1
210
2
0 1
5 0
1
211
2
0 1
5 1
2
218
2
0 2
5 0
2
219
2
0 2
5 1
3
226
2
0 3
5 0
3
227
2
0 3
5 1
4
234
2
0 4
5 0
4
235
2
0 4
5 1
5
242
2
0 5
5 0
5
243
2
0 5
5 1
6
250
2
0 6
5 0
6
251
2
0 6
5 1
end_DTG
begin_CG
5
6 28
7 28
8 28
9 28
5 112
5
6 28
7 28
8 28
9 28
4 112
5
6 28
7 28
8 28
9 28
3 112
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
4
6 28
7 28
8 28
9 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
3
3 28
4 28
5 28
end_CG
