begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var19
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var18
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var20
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





17
4031
2
2 11
9 2
18
4422
2
1 11
10 1
18
4423
2
1 11
10 2
19
4814
2
0 11
11 1
19
4815
2
0 11
11 2
12
14
2882
2
5 12
6 1
14
2883
2
5 12
6 2
15
3274
2
4 12
7 1
15
3275
2
4 12
7 2
16
3666
2
3 12
8 1
16
3667
2
3 12
8 2
17
4058
2
2 12
9 1
17
4059
2
2 12
9 2
18
4450
2
1 12
10 1
18
4451
2
1 12
10 2
19
4842
2
0 12
11 1
19
4843
2
0 12
11 2
12
14
2910
2
5 13
6 1
14
2911
2
5 13
6 2
15
3302
2
4 13
7 1
15
3303
2
4 13
7 2
16
3694
2
3 13
8 1
16
3695
2
3 13
8 2
17
4086
2
2 13
9 1
17
4087
2
2 13
9 2
18
4478
2
1 13
10 1
18
4479
2
1 13
10 2
19
4870
2
0 13
11 1
19
4871
2
0 13
11 2
28
0
195
2
5 0
6 1
0
194
2
5 0
6 0
1
222
2
5 1
6 0
1
223
2
5 1
6 1
2
250
2
5 2
6 0
2
251
2
5 2
6 1
3
278
2
5 3
6 0
3
279
2
5 3
6 1
4
306
2
5 4
6 0
4
307
2
5 4
6 1
5
334
2
5 5
6 0
5
335
2
5 5
6 1
6
362
2
5 6
6 0
6
363
2
5 6
6 1
7
390
2
5 7
6 0
7
391
2
5 7
6 1
8
418
2
5 8
6 0
8
419
2
5 8
6 1
9
446
2
5 9
6 0
9
447
2
5 9
6 1
10
474
2
5 10
6 0
10
475
2
5 10
6 1
11
502
2
5 11
6 0
11
503
2
5 11
6 1
12
530
2
5 12
6 0
12
531
2
5 12
6 1
13
558
2
5 13
6 0
13
559
2
5 13
6 1
28
0
587
2
4 0
7 1
0
586
2
4 0
7 0
1
614
2
4 1
7 0
1
615
2
4 1
7 1
2
642
2
4 2
7 0
2
643
2
4 2
7 1
3
670
2
4 3
7 0
3
671
2
4 3
7 1
4
698
2
4 4
7 0
4
699
2
4 4
7 1
5
726
2
4 5
7 0
5
727
2
4 5
7 1
6
754
2
4 6
7 0
6
755
2
4 6
7 1
7
782
2
4 7
7 0
7
783
2
4 7
7 1
8
810
2
4 8
7 0
8
811
2
4 8
7 1
9
838
2
4 9
7 0
9
839
2
4 9
7 1
10
866
2
4 10
7 0
10
867
2
4 10
7 1
11
894
2
4 11
7 0
11
895
2
4 11
7 1
12
922
2
4 12
7 0
12
923
2
4 12
7 1
13
950
2
4 13
7 0
13
951
2
4 13
7 1
28
0
979
2
3 0
8 1
0
978
2
3 0
8 0
1
1006
2
3 1
8 0
1
1007
2
3 1
8 1
2
1034
2
3 2
8 0
2
1035
2
3 2
8 1
3
1062
2
3 3
8 0
3
1063
2
3 3
8 1
4
1090
2
3 4
8 0
4
1091
2
3 4
8 1
5
1118
2
3 5
8 0
5
1119
2
3 5
8 1
6
1146
2
3 6
8 0
6
1147
2
3 6
8 1
7
1174
2
3 7
8 0
7
1175
2
3 7
8 1
8
1202
2
3 8
8 0
8
1203
2
3 8
8 1
9
1230
2
3 9
8 0
9
1231
2
3 9
8 1
10
1258
2
3 10
8 0
10
1259
2
3 10
8 1
11
1286
2
3 11
8 0
11
1287
2
3 11
8 1
12
1314
2
3 12
8 0
12
1315
2
3 12
8 1
13
1342
2
3 13
8 0
13
1343
2
3 13
8 1
28
0
1371
2
2 0
9 1
0
1370
2
2 0
9 0
1
1398
2
2 1
9 0
1
1399
2
2 1
9 1
2
1426
2
2 2
9 0
2
1427
2
2 2
9 1
3
1454
2
2 3
9 0
3
1455
2
2 3
9 1
4
1482
2
2 4
9 0
4
1483
2
2 4
9 1
5
1510
2
2 5
9 0
5
1511
2
2 5
9 1
6
1538
2
2 6
9 0
6
1539
2
2 6
9 1
7
1566
2
2 7
9 0
7
1567
2
2 7
9 1
8
1594
2
2 8
9 0
8
1595
2
2 8
9 1
9
1622
2
2 9
9 0
9
1623
2
2 9
9 1
10
1650
2
2 10
9 0
10
1651
2
2 10
9 1
11
1678
2
2 11
9 0
11
1679
2
2 11
9 1
12
1706
2
2 12
9 0
12
1707
2
2 12
9 1
13
1734
2
2 13
9 0
13
1735
2
2 13
9 1
28
0
1763
2
1 0
10 1
0
1762
2
1 0
10 0
1
1790
2
1 1
10 0
1
1791
2
1 1
10 1
2
1818
2
1 2
10 0
2
1819
2
1 2
10 1
3
1846
2
1 3
10 0
3
1847
2
1 3
10 1
4
1874
2
1 4
10 0
4
1875
2
1 4
10 1
5
1902
2
1 5
10 0
5
1903
2
1 5
10 1
6
1930
2
1 6
10 0
6
1931
2
1 6
10 1
7
1958
2
1 7
10 0
7
1959
2
1 7
10 1
8
1986
2
1 8
10 0
8
1987
2
1 8
10 1
9
2014
2
1 9
10 0
9
2015
2
1 9
10 1
10
2042
2
1 10
10 0
10
2043
2
1 10
10 1
11
2070
2
1 11
10 0
11
2071
2
1 11
10 1
12
2098
2
1 12
10 0
12
2099
2
1 12
10 1
13
2126
2
1 13
10 0
13
2127
2
1 13
10 1
28
0
2155
2
0 0
11 1
0
2154
2
0 0
11 0
1
2182
2
0 1
11 0
1
2183
2
0 1
11 1
2
2210
2
0 2
11 0
2
2211
2
0 2
11 1
3
2238
2
0 3
11 0
3
2239
2
0 3
11 1
4
2266
2
0 4
11 0
4
2267
2
0 4
11 1
5
2294
2
0 5
11 0
5
2295
2
0 5
11 1
6
2322
2
0 6
11 0
6
2323
2
0 6
11 1
7
2350
2
0 7
11 0
7
2351
2
0 7
11 1
8
2378
2
0 8
11 0
8
2379
2
0 8
11 1
9
2406
2
0 9
11 0
9
2407
2
0 9
11 1
10
2434
2
0 10
11 0
10
2435
2
0 10
11 1
11
2462
2
0 11
11 0
11
2463
2
0 11
11 1
12
2490
2
0 12
11 0
12
2491
2
0 12
11 1
13
2518
2
0 13
11 0
13
2519
2
0 13
11 1
end_DTG
begin_CG
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
11 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
10 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
9 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
8 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
7 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
6 784
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
