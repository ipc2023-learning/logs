begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var19
-1
14
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var18
-1
14
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var17
-1
14
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var16
-1
14
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var15
-1
14
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var14
-1
14
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var20
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var21
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var22
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var23
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var24
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var25
-1
3
Atom capacity(v6, c0)
Atom capacity(v6, c1)
Atom capacity(v6, c2)
end_variable
begin_variable
var0
-1
20
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
end_variable
begin_variable
var1
-1
20
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
end_variable
begin_variable
var2
-1
20
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
end_variable
begin_variable
var3
-1
20
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
end_variable
begin_variable
var4
-1
20
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var5
-1
20
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
end_variable
begin_variable
var6
-1
20
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l13)
Atom at(p2, l14)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
Atom in(p2, v6)
end_variable
begin_variable
var7
-1
20
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l13)
Atom at(p3, l14)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





10 1
18
4903
2
1 11
10 2
19
5294
2
0 11
11 1
19
5295
2
0 11
11 2
12
14
3362
2
5 12
6 1
14
3363
2
5 12
6 2
15
3754
2
4 12
7 1
15
3755
2
4 12
7 2
16
4146
2
3 12
8 1
16
4147
2
3 12
8 2
17
4538
2
2 12
9 1
17
4539
2
2 12
9 2
18
4930
2
1 12
10 1
18
4931
2
1 12
10 2
19
5322
2
0 12
11 1
19
5323
2
0 12
11 2
12
14
3390
2
5 13
6 1
14
3391
2
5 13
6 2
15
3782
2
4 13
7 1
15
3783
2
4 13
7 2
16
4174
2
3 13
8 1
16
4175
2
3 13
8 2
17
4566
2
2 13
9 1
17
4567
2
2 13
9 2
18
4958
2
1 13
10 1
18
4959
2
1 13
10 2
19
5350
2
0 13
11 1
19
5351
2
0 13
11 2
28
0
675
2
5 0
6 1
0
674
2
5 0
6 0
1
702
2
5 1
6 0
1
703
2
5 1
6 1
2
730
2
5 2
6 0
2
731
2
5 2
6 1
3
758
2
5 3
6 0
3
759
2
5 3
6 1
4
786
2
5 4
6 0
4
787
2
5 4
6 1
5
814
2
5 5
6 0
5
815
2
5 5
6 1
6
842
2
5 6
6 0
6
843
2
5 6
6 1
7
870
2
5 7
6 0
7
871
2
5 7
6 1
8
898
2
5 8
6 0
8
899
2
5 8
6 1
9
926
2
5 9
6 0
9
927
2
5 9
6 1
10
954
2
5 10
6 0
10
955
2
5 10
6 1
11
982
2
5 11
6 0
11
983
2
5 11
6 1
12
1010
2
5 12
6 0
12
1011
2
5 12
6 1
13
1038
2
5 13
6 0
13
1039
2
5 13
6 1
28
0
1067
2
4 0
7 1
0
1066
2
4 0
7 0
1
1094
2
4 1
7 0
1
1095
2
4 1
7 1
2
1122
2
4 2
7 0
2
1123
2
4 2
7 1
3
1150
2
4 3
7 0
3
1151
2
4 3
7 1
4
1178
2
4 4
7 0
4
1179
2
4 4
7 1
5
1206
2
4 5
7 0
5
1207
2
4 5
7 1
6
1234
2
4 6
7 0
6
1235
2
4 6
7 1
7
1262
2
4 7
7 0
7
1263
2
4 7
7 1
8
1290
2
4 8
7 0
8
1291
2
4 8
7 1
9
1318
2
4 9
7 0
9
1319
2
4 9
7 1
10
1346
2
4 10
7 0
10
1347
2
4 10
7 1
11
1374
2
4 11
7 0
11
1375
2
4 11
7 1
12
1402
2
4 12
7 0
12
1403
2
4 12
7 1
13
1430
2
4 13
7 0
13
1431
2
4 13
7 1
28
0
1459
2
3 0
8 1
0
1458
2
3 0
8 0
1
1486
2
3 1
8 0
1
1487
2
3 1
8 1
2
1514
2
3 2
8 0
2
1515
2
3 2
8 1
3
1542
2
3 3
8 0
3
1543
2
3 3
8 1
4
1570
2
3 4
8 0
4
1571
2
3 4
8 1
5
1598
2
3 5
8 0
5
1599
2
3 5
8 1
6
1626
2
3 6
8 0
6
1627
2
3 6
8 1
7
1654
2
3 7
8 0
7
1655
2
3 7
8 1
8
1682
2
3 8
8 0
8
1683
2
3 8
8 1
9
1710
2
3 9
8 0
9
1711
2
3 9
8 1
10
1738
2
3 10
8 0
10
1739
2
3 10
8 1
11
1766
2
3 11
8 0
11
1767
2
3 11
8 1
12
1794
2
3 12
8 0
12
1795
2
3 12
8 1
13
1822
2
3 13
8 0
13
1823
2
3 13
8 1
28
0
1851
2
2 0
9 1
0
1850
2
2 0
9 0
1
1878
2
2 1
9 0
1
1879
2
2 1
9 1
2
1906
2
2 2
9 0
2
1907
2
2 2
9 1
3
1934
2
2 3
9 0
3
1935
2
2 3
9 1
4
1962
2
2 4
9 0
4
1963
2
2 4
9 1
5
1990
2
2 5
9 0
5
1991
2
2 5
9 1
6
2018
2
2 6
9 0
6
2019
2
2 6
9 1
7
2046
2
2 7
9 0
7
2047
2
2 7
9 1
8
2074
2
2 8
9 0
8
2075
2
2 8
9 1
9
2102
2
2 9
9 0
9
2103
2
2 9
9 1
10
2130
2
2 10
9 0
10
2131
2
2 10
9 1
11
2158
2
2 11
9 0
11
2159
2
2 11
9 1
12
2186
2
2 12
9 0
12
2187
2
2 12
9 1
13
2214
2
2 13
9 0
13
2215
2
2 13
9 1
28
0
2243
2
1 0
10 1
0
2242
2
1 0
10 0
1
2270
2
1 1
10 0
1
2271
2
1 1
10 1
2
2298
2
1 2
10 0
2
2299
2
1 2
10 1
3
2326
2
1 3
10 0
3
2327
2
1 3
10 1
4
2354
2
1 4
10 0
4
2355
2
1 4
10 1
5
2382
2
1 5
10 0
5
2383
2
1 5
10 1
6
2410
2
1 6
10 0
6
2411
2
1 6
10 1
7
2438
2
1 7
10 0
7
2439
2
1 7
10 1
8
2466
2
1 8
10 0
8
2467
2
1 8
10 1
9
2494
2
1 9
10 0
9
2495
2
1 9
10 1
10
2522
2
1 10
10 0
10
2523
2
1 10
10 1
11
2550
2
1 11
10 0
11
2551
2
1 11
10 1
12
2578
2
1 12
10 0
12
2579
2
1 12
10 1
13
2606
2
1 13
10 0
13
2607
2
1 13
10 1
28
0
2635
2
0 0
11 1
0
2634
2
0 0
11 0
1
2662
2
0 1
11 0
1
2663
2
0 1
11 1
2
2690
2
0 2
11 0
2
2691
2
0 2
11 1
3
2718
2
0 3
11 0
3
2719
2
0 3
11 1
4
2746
2
0 4
11 0
4
2747
2
0 4
11 1
5
2774
2
0 5
11 0
5
2775
2
0 5
11 1
6
2802
2
0 6
11 0
6
2803
2
0 6
11 1
7
2830
2
0 7
11 0
7
2831
2
0 7
11 1
8
2858
2
0 8
11 0
8
2859
2
0 8
11 1
9
2886
2
0 9
11 0
9
2887
2
0 9
11 1
10
2914
2
0 10
11 0
10
2915
2
0 10
11 1
11
2942
2
0 11
11 0
11
2943
2
0 11
11 1
12
2970
2
0 12
11 0
12
2971
2
0 12
11 1
13
2998
2
0 13
11 0
13
2999
2
0 13
11 1
end_DTG
begin_CG
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
11 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
10 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
9 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
8 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
7 784
15
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
6 784
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
14
12 56
13 56
14 56
15 56
16 56
17 56
18 56
19 56
20 56
21 56
22 56
23 56
24 56
25 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
6
6 56
7 56
8 56
9 56
10 56
11 56
end_CG
