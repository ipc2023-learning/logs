begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var15
-1
12
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var14
-1
12
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var13
-1
12
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var12
-1
12
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var11
-1
12
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var16
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var17
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var18
-1
3
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
end_variable
begin_variable
var19
-1
3
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
end_variable
begin_variable
var20
-1
3
Atom capacity(v5, c0)
Atom capacity(v5, c1)
Atom capacity(v5, c2)
end_variable
begin_variable
var0
-1
17
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var1
-1
17
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var2
-1
17
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
end_variable
begin_variable
var3
-1
17
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var4
-1
17
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var5
-1
17
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var6
-1
17
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var7
-1
17
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var8
-1
17
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var9
-1
17
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var10
-1
17
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l12)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





9 2
10
12
1752
2
4 1
5 1
12
1753
2
4 1
5 2
13
2016
2
3 1
6 1
13
2017
2
3 1
6 2
14
2280
2
2 1
7 1
14
2281
2
2 1
7 2
15
2544
2
1 1
8 1
15
2545
2
1 1
8 2
16
2808
2
0 1
9 1
16
2809
2
0 1
9 2
10
12
1774
2
4 2
5 1
12
1775
2
4 2
5 2
13
2038
2
3 2
6 1
13
2039
2
3 2
6 2
14
2302
2
2 2
7 1
14
2303
2
2 2
7 2
15
2566
2
1 2
8 1
15
2567
2
1 2
8 2
16
2830
2
0 2
9 1
16
2831
2
0 2
9 2
10
12
1796
2
4 3
5 1
12
1797
2
4 3
5 2
13
2060
2
3 3
6 1
13
2061
2
3 3
6 2
14
2324
2
2 3
7 1
14
2325
2
2 3
7 2
15
2588
2
1 3
8 1
15
2589
2
1 3
8 2
16
2852
2
0 3
9 1
16
2853
2
0 3
9 2
10
12
1818
2
4 4
5 1
12
1819
2
4 4
5 2
13
2082
2
3 4
6 1
13
2083
2
3 4
6 2
14
2346
2
2 4
7 1
14
2347
2
2 4
7 2
15
2610
2
1 4
8 1
15
2611
2
1 4
8 2
16
2874
2
0 4
9 1
16
2875
2
0 4
9 2
10
12
1840
2
4 5
5 1
12
1841
2
4 5
5 2
13
2104
2
3 5
6 1
13
2105
2
3 5
6 2
14
2368
2
2 5
7 1
14
2369
2
2 5
7 2
15
2632
2
1 5
8 1
15
2633
2
1 5
8 2
16
2896
2
0 5
9 1
16
2897
2
0 5
9 2
10
12
1862
2
4 6
5 1
12
1863
2
4 6
5 2
13
2126
2
3 6
6 1
13
2127
2
3 6
6 2
14
2390
2
2 6
7 1
14
2391
2
2 6
7 2
15
2654
2
1 6
8 1
15
2655
2
1 6
8 2
16
2918
2
0 6
9 1
16
2919
2
0 6
9 2
10
12
1884
2
4 7
5 1
12
1885
2
4 7
5 2
13
2148
2
3 7
6 1
13
2149
2
3 7
6 2
14
2412
2
2 7
7 1
14
2413
2
2 7
7 2
15
2676
2
1 7
8 1
15
2677
2
1 7
8 2
16
2940
2
0 7
9 1
16
2941
2
0 7
9 2
10
12
1906
2
4 8
5 1
12
1907
2
4 8
5 2
13
2170
2
3 8
6 1
13
2171
2
3 8
6 2
14
2434
2
2 8
7 1
14
2435
2
2 8
7 2
15
2698
2
1 8
8 1
15
2699
2
1 8
8 2
16
2962
2
0 8
9 1
16
2963
2
0 8
9 2
10
12
1928
2
4 9
5 1
12
1929
2
4 9
5 2
13
2192
2
3 9
6 1
13
2193
2
3 9
6 2
14
2456
2
2 9
7 1
14
2457
2
2 9
7 2
15
2720
2
1 9
8 1
15
2721
2
1 9
8 2
16
2984
2
0 9
9 1
16
2985
2
0 9
9 2
10
12
1950
2
4 10
5 1
12
1951
2
4 10
5 2
13
2214
2
3 10
6 1
13
2215
2
3 10
6 2
14
2478
2
2 10
7 1
14
2479
2
2 10
7 2
15
2742
2
1 10
8 1
15
2743
2
1 10
8 2
16
3006
2
0 10
9 1
16
3007
2
0 10
9 2
10
12
1972
2
4 11
5 1
12
1973
2
4 11
5 2
13
2236
2
3 11
6 1
13
2237
2
3 11
6 2
14
2500
2
2 11
7 1
14
2501
2
2 11
7 2
15
2764
2
1 11
8 1
15
2765
2
1 11
8 2
16
3028
2
0 11
9 1
16
3029
2
0 11
9 2
24
0
411
2
4 0
5 1
0
410
2
4 0
5 0
1
432
2
4 1
5 0
1
433
2
4 1
5 1
2
454
2
4 2
5 0
2
455
2
4 2
5 1
3
476
2
4 3
5 0
3
477
2
4 3
5 1
4
498
2
4 4
5 0
4
499
2
4 4
5 1
5
520
2
4 5
5 0
5
521
2
4 5
5 1
6
542
2
4 6
5 0
6
543
2
4 6
5 1
7
564
2
4 7
5 0
7
565
2
4 7
5 1
8
586
2
4 8
5 0
8
587
2
4 8
5 1
9
608
2
4 9
5 0
9
609
2
4 9
5 1
10
630
2
4 10
5 0
10
631
2
4 10
5 1
11
652
2
4 11
5 0
11
653
2
4 11
5 1
24
0
675
2
3 0
6 1
0
674
2
3 0
6 0
1
696
2
3 1
6 0
1
697
2
3 1
6 1
2
718
2
3 2
6 0
2
719
2
3 2
6 1
3
740
2
3 3
6 0
3
741
2
3 3
6 1
4
762
2
3 4
6 0
4
763
2
3 4
6 1
5
784
2
3 5
6 0
5
785
2
3 5
6 1
6
806
2
3 6
6 0
6
807
2
3 6
6 1
7
828
2
3 7
6 0
7
829
2
3 7
6 1
8
850
2
3 8
6 0
8
851
2
3 8
6 1
9
872
2
3 9
6 0
9
873
2
3 9
6 1
10
894
2
3 10
6 0
10
895
2
3 10
6 1
11
916
2
3 11
6 0
11
917
2
3 11
6 1
24
0
939
2
2 0
7 1
0
938
2
2 0
7 0
1
960
2
2 1
7 0
1
961
2
2 1
7 1
2
982
2
2 2
7 0
2
983
2
2 2
7 1
3
1004
2
2 3
7 0
3
1005
2
2 3
7 1
4
1026
2
2 4
7 0
4
1027
2
2 4
7 1
5
1048
2
2 5
7 0
5
1049
2
2 5
7 1
6
1070
2
2 6
7 0
6
1071
2
2 6
7 1
7
1092
2
2 7
7 0
7
1093
2
2 7
7 1
8
1114
2
2 8
7 0
8
1115
2
2 8
7 1
9
1136
2
2 9
7 0
9
1137
2
2 9
7 1
10
1158
2
2 10
7 0
10
1159
2
2 10
7 1
11
1180
2
2 11
7 0
11
1181
2
2 11
7 1
24
0
1203
2
1 0
8 1
0
1202
2
1 0
8 0
1
1224
2
1 1
8 0
1
1225
2
1 1
8 1
2
1246
2
1 2
8 0
2
1247
2
1 2
8 1
3
1268
2
1 3
8 0
3
1269
2
1 3
8 1
4
1290
2
1 4
8 0
4
1291
2
1 4
8 1
5
1312
2
1 5
8 0
5
1313
2
1 5
8 1
6
1334
2
1 6
8 0
6
1335
2
1 6
8 1
7
1356
2
1 7
8 0
7
1357
2
1 7
8 1
8
1378
2
1 8
8 0
8
1379
2
1 8
8 1
9
1400
2
1 9
8 0
9
1401
2
1 9
8 1
10
1422
2
1 10
8 0
10
1423
2
1 10
8 1
11
1444
2
1 11
8 0
11
1445
2
1 11
8 1
24
0
1467
2
0 0
9 1
0
1466
2
0 0
9 0
1
1488
2
0 1
9 0
1
1489
2
0 1
9 1
2
1510
2
0 2
9 0
2
1511
2
0 2
9 1
3
1532
2
0 3
9 0
3
1533
2
0 3
9 1
4
1554
2
0 4
9 0
4
1555
2
0 4
9 1
5
1576
2
0 5
9 0
5
1577
2
0 5
9 1
6
1598
2
0 6
9 0
6
1599
2
0 6
9 1
7
1620
2
0 7
9 0
7
1621
2
0 7
9 1
8
1642
2
0 8
9 0
8
1643
2
0 8
9 1
9
1664
2
0 9
9 0
9
1665
2
0 9
9 1
10
1686
2
0 10
9 0
10
1687
2
0 10
9 1
11
1708
2
0 11
9 0
11
1709
2
0 11
9 1
end_DTG
begin_CG
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
9 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
8 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
7 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
6 528
12
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5 528
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
11
10 48
11 48
12 48
13 48
14 48
15 48
16 48
17 48
18 48
19 48
20 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
5
5 48
6 48
7 48
8 48
9 48
end_CG
