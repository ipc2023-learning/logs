begin_version
3
end_version
begin_metric
0
end_metric
56
begin_variable
var68
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var52
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var13
-1
2
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




340
0
5
348
0
6
356
0
7
364
0
8
372
0
8
0
308
0
1
316
0
2
324
0
4
341
0
5
349
0
6
357
0
7
365
0
8
373
0
8
0
309
0
1
317
0
2
325
0
3
333
0
5
350
0
6
358
0
7
366
0
8
374
0
8
0
310
0
1
318
0
2
326
0
3
334
0
4
342
0
6
359
0
7
367
0
8
375
0
8
0
311
0
1
319
0
2
327
0
3
335
0
4
343
0
5
351
0
7
368
0
8
376
0
8
0
312
0
1
320
0
2
328
0
3
336
0
4
344
0
5
352
0
6
360
0
8
377
0
8
0
313
0
1
321
0
2
329
0
3
337
0
4
345
0
5
353
0
6
361
0
7
369
0
end_DTG
begin_DTG
8
1
242
0
2
250
0
3
258
0
4
266
0
5
274
0
6
282
0
7
290
0
8
298
0
8
0
234
0
2
251
0
3
259
0
4
267
0
5
275
0
6
283
0
7
291
0
8
299
0
8
0
235
0
1
243
0
3
260
0
4
268
0
5
276
0
6
284
0
7
292
0
8
300
0
8
0
236
0
1
244
0
2
252
0
4
269
0
5
277
0
6
285
0
7
293
0
8
301
0
8
0
237
0
1
245
0
2
253
0
3
261
0
5
278
0
6
286
0
7
294
0
8
302
0
8
0
238
0
1
246
0
2
254
0
3
262
0
4
270
0
6
287
0
7
295
0
8
303
0
8
0
239
0
1
247
0
2
255
0
3
263
0
4
271
0
5
279
0
7
296
0
8
304
0
8
0
240
0
1
248
0
2
256
0
3
264
0
4
272
0
5
280
0
6
288
0
8
305
0
8
0
241
0
1
249
0
2
257
0
3
265
0
4
273
0
5
281
0
6
289
0
7
297
0
end_DTG
begin_DTG
8
1
170
0
2
178
0
3
186
0
4
194
0
5
202
0
6
210
0
7
218
0
8
226
0
8
0
162
0
2
179
0
3
187
0
4
195
0
5
203
0
6
211
0
7
219
0
8
227
0
8
0
163
0
1
171
0
3
188
0
4
196
0
5
204
0
6
212
0
7
220
0
8
228
0
8
0
164
0
1
172
0
2
180
0
4
197
0
5
205
0
6
213
0
7
221
0
8
229
0
8
0
165
0
1
173
0
2
181
0
3
189
0
5
206
0
6
214
0
7
222
0
8
230
0
8
0
166
0
1
174
0
2
182
0
3
190
0
4
198
0
6
215
0
7
223
0
8
231
0
8
0
167
0
1
175
0
2
183
0
3
191
0
4
199
0
5
207
0
7
224
0
8
232
0
8
0
168
0
1
176
0
2
184
0
3
192
0
4
200
0
5
208
0
6
216
0
8
233
0
8
0
169
0
1
177
0
2
185
0
3
193
0
4
201
0
5
209
0
6
217
0
7
225
0
end_DTG
begin_DTG
8
1
98
0
2
106
0
3
114
0
4
122
0
5
130
0
6
138
0
7
146
0
8
154
0
8
0
90
0
2
107
0
3
115
0
4
123
0
5
131
0
6
139
0
7
147
0
8
155
0
8
0
91
0
1
99
0
3
116
0
4
124
0
5
132
0
6
140
0
7
148
0
8
156
0
8
0
92
0
1
100
0
2
108
0
4
125
0
5
133
0
6
141
0
7
149
0
8
157
0
8
0
93
0
1
101
0
2
109
0
3
117
0
5
134
0
6
142
0
7
150
0
8
158
0
8
0
94
0
1
102
0
2
110
0
3
118
0
4
126
0
6
143
0
7
151
0
8
159
0
8
0
95
0
1
103
0
2
111
0
3
119
0
4
127
0
5
135
0
7
152
0
8
160
0
8
0
96
0
1
104
0
2
112
0
3
120
0
4
128
0
5
136
0
6
144
0
8
161
0
8
0
97
0
1
105
0
2
113
0
3
121
0
4
129
0
5
137
0
6
145
0
7
153
0
end_DTG
begin_DTG
1
1
50
1
5 0
1
0
14
2
27 6
4 0
end_DTG
begin_DTG
1
1
49
1
16 0
1
0
7
2
31 7
15 0
end_DTG
begin_DTG
1
1
48
1
6 0
1
0
12
2
28 1
7 0
end_DTG
begin_DTG
1
1
47
1
20 0
1
0
5
2
32 1
19 0
end_DTG
begin_DTG
1
1
46
1
13 0
1
0
9
2
30 5
12 0
end_DTG
begin_DTG
1
1
45
1
10 0
1
0
11
2
29 5
9 0
end_DTG
begin_DTG
1
1
44
1
2 0
1
0
16
2
26 8
1 0
end_DTG
begin_DTG
1
1
43
1
24 0
1
0
0
2
34 1
25 0
end_DTG
begin_DTG
1
1
42
1
5 0
1
0
13
2
27 3
3 0
end_DTG
begin_DTG
1
1
41
1
16 0
1
0
6
2
31 7
14 0
end_DTG
begin_DTG
1
1
40
1
2 0
1
0
15
2
26 6
0 0
end_DTG
begin_DTG
1
1
39
1
20 0
1
0
4
2
32 8
18 0
end_DTG
begin_DTG
1
1
38
1
10 0
1
0
10
2
29 5
8 0
end_DTG
begin_DTG
1
1
37
1
13 0
1
0
8
2
30 4
11 0
end_DTG
begin_DTG
1
1
36
1
20 0
1
0
3
2
32 8
17 0
end_DTG
begin_DTG
1
1
35
1
23 0
1
0
2
2
33 1
22 0
end_DTG
begin_DTG
1
1
34
1
23 0
1
0
1
2
33 4
21 0
end_DTG
begin_DTG
0
11
0
52
3
42 0
34 6
25 0
0
57
3
51 0
33 6
21 0
0
64
3
49 0
32 6
17 0
0
65
3
38 0
32 6
19 0
0
71
3
44 0
31 6
14 0
0
72
3
36 0
31 6
15 0
0
76
3
48 0
30 6
11 0
0
80
3
40 0
29 6
9 0
0
85
3
35 0
27 6
4 0
0
88
3
45 0
26 6
0 0
0
89
3
41 0
26 6
1 0
end_DTG
begin_DTG
0
11
0
55
3
51 0
33 2
21 0
0
56
3
50 0
33 2
22 0
0
62
3
49 0
32 2
17 0
0
63
3
46 0
32 2
18 0
0
69
3
44 0
31 2
14 0
0
70
3
36 0
31 2
15 0
0
75
3
39 0
30 2
12 0
0
78
3
47 0
29 2
8 0
0
79
3
40 0
29 2
9 0
0
81
3
37 0
28 2
7 0
0
84
3
35 0
27 2
4 0
end_DTG
begin_DTG
0
11
0
51
3
42 0
34 1
25 0
0
54
3
51 0
33 1
21 0
0
59
3
49 0
32 1
17 0
0
61
3
38 0
32 1
19 0
0
67
3
44 0
31 1
14 0
0
68
3
36 0
31 1
15 0
0
73
3
48 0
30 1
11 0
0
77
3
40 0
29 1
9 0
0
83
3
35 0
27 1
4 0
0
86
3
45 0
26 1
0 0
0
87
3
41 0
26 1
1 0
end_DTG
begin_DTG
0
6
0
53
3
51 0
33 1
21 0
0
58
3
49 0
32 1
17 0
0
60
3
46 0
32 1
18 0
0
66
3
44 0
31 1
14 0
0
74
3
39 0
30 1
12 0
0
82
3
43 0
27 1
3 0
end_DTG
begin_CG
4
45 1
54 1
52 1
2 1
4
41 1
54 1
52 1
2 1
4
45 1
41 1
0 1
1 1
3
43 1
55 1
5 1
5
35 1
54 1
53 1
52 1
5 1
4
43 1
35 1
3 1
4 1
2
37 1
7 1
3
37 1
53 1
6 1
3
47 1
53 1
10 1
5
40 1
54 1
53 1
52 1
10 1
4
47 1
40 1
8 1
9 1
4
48 1
54 1
52 1
13 1
4
39 1
55 1
53 1
13 1
4
48 1
39 1
11 1
12 1
6
44 1
55 1
54 1
53 1
52 1
16 1
5
36 1
54 1
53 1
52 1
16 1
4
44 1
36 1
14 1
15 1
6
49 1
55 1
54 1
53 1
52 1
20 1
4
46 1
55 1
53 1
20 1
4
38 1
54 1
52 1
20 1
6
49 1
46 1
38 1
17 1
18 1
19 1
6
51 1
55 1
54 1
53 1
52 1
23 1
3
50 1
53 1
23 1
4
51 1
50 1
21 1
22 1
2
42 1
25 1
4
42 1
54 1
52 1
24 1
4
45 1
41 1
54 2
52 2
6
43 1
35 1
55 1
54 1
53 1
52 1
2
37 1
53 1
5
47 1
40 1
54 1
53 2
52 1
6
48 1
39 1
55 1
54 1
53 1
52 1
6
44 1
36 1
55 1
54 2
53 2
52 2
7
49 1
46 1
38 1
55 2
54 2
53 2
52 2
6
51 1
50 1
55 1
54 1
53 2
52 1
3
42 1
54 1
52 1
3
54 1
53 1
52 1
3
54 1
53 1
52 1
1
53 1
2
54 1
52 1
2
55 1
53 1
3
54 1
53 1
52 1
2
54 1
52 1
2
54 1
52 1
1
55 1
4
55 1
54 1
53 1
52 1
2
54 1
52 1
2
55 1
53 1
1
53 1
2
54 1
52 1
4
55 1
54 1
53 1
52 1
1
53 1
4
55 1
54 1
53 1
52 1
0
0
0
0
end_CG
