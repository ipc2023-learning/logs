begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var45
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var44
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var43
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var56
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var42
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var37
-1
8
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
end_variable
begin_variable
var36
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAt




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





238
0
2
245
0
4
260
0
5
267
0
6
274
0
7
281
0
7
0
232
0
1
239
0
2
246
0
3
253
0
5
268
0
6
275
0
7
282
0
7
0
233
0
1
240
0
2
247
0
3
254
0
4
261
0
6
276
0
7
283
0
7
0
234
0
1
241
0
2
248
0
3
255
0
4
262
0
5
269
0
7
284
0
7
0
235
0
1
242
0
2
249
0
3
256
0
4
263
0
5
270
0
6
277
0
end_DTG
begin_DTG
7
1
180
0
2
187
0
3
194
0
4
201
0
5
208
0
6
215
0
7
222
0
7
0
173
0
2
188
0
3
195
0
4
202
0
5
209
0
6
216
0
7
223
0
7
0
174
0
1
181
0
3
196
0
4
203
0
5
210
0
6
217
0
7
224
0
7
0
175
0
1
182
0
2
189
0
4
204
0
5
211
0
6
218
0
7
225
0
7
0
176
0
1
183
0
2
190
0
3
197
0
5
212
0
6
219
0
7
226
0
7
0
177
0
1
184
0
2
191
0
3
198
0
4
205
0
6
220
0
7
227
0
7
0
178
0
1
185
0
2
192
0
3
199
0
4
206
0
5
213
0
7
228
0
7
0
179
0
1
186
0
2
193
0
3
200
0
4
207
0
5
214
0
6
221
0
end_DTG
begin_DTG
7
1
124
0
2
131
0
3
138
0
4
145
0
5
152
0
6
159
0
7
166
0
7
0
117
0
2
132
0
3
139
0
4
146
0
5
153
0
6
160
0
7
167
0
7
0
118
0
1
125
0
3
140
0
4
147
0
5
154
0
6
161
0
7
168
0
7
0
119
0
1
126
0
2
133
0
4
148
0
5
155
0
6
162
0
7
169
0
7
0
120
0
1
127
0
2
134
0
3
141
0
5
156
0
6
163
0
7
170
0
7
0
121
0
1
128
0
2
135
0
3
142
0
4
149
0
6
164
0
7
171
0
7
0
122
0
1
129
0
2
136
0
3
143
0
4
150
0
5
157
0
7
172
0
7
0
123
0
1
130
0
2
137
0
3
144
0
4
151
0
5
158
0
6
165
0
end_DTG
begin_DTG
1
1
41
1
21 0
1
0
2
2
29 6
20 0
end_DTG
begin_DTG
1
1
40
1
16 0
1
0
3
2
28 5
17 0
end_DTG
begin_DTG
1
1
39
1
7 0
1
0
10
2
24 3
6 0
end_DTG
begin_DTG
1
1
38
1
10 0
1
0
8
2
25 6
9 0
end_DTG
begin_DTG
1
1
37
1
21 0
1
0
1
2
29 3
19 0
end_DTG
begin_DTG
1
1
36
1
13 0
1
0
6
2
26 7
12 0
end_DTG
begin_DTG
1
1
35
1
0 0
1
0
13
2
22 1
1 0
end_DTG
begin_DTG
1
1
34
1
14 0
1
0
4
2
27 6
15 0
end_DTG
begin_DTG
1
1
33
1
7 0
1
0
9
2
24 5
5 0
end_DTG
begin_DTG
1
1
32
1
13 0
1
0
5
2
26 2
11 0
end_DTG
begin_DTG
1
1
31
1
4 0
1
0
12
2
23 7
3 0
end_DTG
begin_DTG
1
1
30
1
21 0
1
0
0
2
29 2
18 0
end_DTG
begin_DTG
1
1
29
1
10 0
1
0
7
2
25 3
8 0
end_DTG
begin_DTG
1
1
28
1
4 0
1
0
11
2
23 4
2 0
end_DTG
begin_DTG
0
13
0
53
3
41 0
29 7
18 0
0
55
3
34 0
29 7
19 0
0
59
3
31 0
28 7
17 0
0
62
3
37 0
27 7
15 0
0
72
3
39 0
26 7
11 0
0
74
3
35 0
26 7
12 0
0
84
3
42 0
25 7
8 0
0
86
3
33 0
25 7
9 0
0
96
3
38 0
24 7
5 0
0
98
3
32 0
24 7
6 0
0
108
3
43 0
23 7
2 0
0
110
3
40 0
23 7
3 0
0
116
3
36 0
22 7
1 0
end_DTG
begin_DTG
0
12
0
52
3
41 0
29 7
18 0
0
54
3
34 0
29 7
19 0
0
56
3
30 0
29 7
20 0
0
71
3
39 0
26 7
11 0
0
73
3
35 0
26 7
12 0
0
83
3
42 0
25 7
8 0
0
85
3
33 0
25 7
9 0
0
95
3
38 0
24 7
5 0
0
97
3
32 0
24 7
6 0
0
107
3
43 0
23 7
2 0
0
109
3
40 0
23 7
3 0
0
115
3
36 0
22 7
1 0
end_DTG
begin_DTG
0
12
0
49
3
41 0
29 6
18 0
0
50
3
34 0
29 6
19 0
0
51
3
30 0
29 6
20 0
0
69
3
39 0
26 6
11 0
0
70
3
35 0
26 6
12 0
0
81
3
42 0
25 6
8 0
0
82
3
33 0
25 6
9 0
0
93
3
38 0
24 6
5 0
0
94
3
32 0
24 6
6 0
0
105
3
43 0
23 6
2 0
0
106
3
40 0
23 6
3 0
0
114
3
36 0
22 6
1 0
end_DTG
begin_DTG
0
12
0
46
3
41 0
29 4
18 0
0
47
3
34 0
29 4
19 0
0
48
3
30 0
29 4
20 0
0
67
3
39 0
26 4
11 0
0
68
3
35 0
26 4
12 0
0
79
3
42 0
25 4
8 0
0
80
3
33 0
25 4
9 0
0
91
3
38 0
24 4
5 0
0
92
3
32 0
24 4
6 0
0
103
3
43 0
23 4
2 0
0
104
3
40 0
23 4
3 0
0
113
3
36 0
22 4
1 0
end_DTG
begin_DTG
0
13
0
44
3
41 0
29 1
18 0
0
45
3
34 0
29 1
19 0
0
58
3
31 0
28 1
17 0
0
61
3
37 0
27 1
15 0
0
65
3
39 0
26 1
11 0
0
66
3
35 0
26 1
12 0
0
77
3
42 0
25 1
8 0
0
78
3
33 0
25 1
9 0
0
89
3
38 0
24 1
5 0
0
90
3
32 0
24 1
6 0
0
101
3
43 0
23 1
2 0
0
102
3
40 0
23 1
3 0
0
112
3
36 0
22 1
1 0
end_DTG
begin_DTG
0
13
0
42
3
41 0
29 0
18 0
0
43
3
34 0
29 0
19 0
0
57
3
31 0
28 0
17 0
0
60
3
37 0
27 0
15 0
0
63
3
39 0
26 0
11 0
0
64
3
35 0
26 0
12 0
0
75
3
42 0
25 0
8 0
0
76
3
33 0
25 0
9 0
0
87
3
38 0
24 0
5 0
0
88
3
32 0
24 0
6 0
0
99
3
43 0
23 0
2 0
0
100
3
40 0
23 0
3 0
0
111
3
36 0
22 0
1 0
end_DTG
begin_CG
2
36 1
1 1
8
36 1
49 1
48 1
47 1
46 1
45 1
44 1
0 1
8
43 1
49 1
48 1
47 1
46 1
45 1
44 1
4 1
8
40 1
49 1
48 1
47 1
46 1
45 1
44 1
4 1
4
43 1
40 1
2 1
3 1
8
38 1
49 1
48 1
47 1
46 1
45 1
44 1
7 1
8
32 1
49 1
48 1
47 1
46 1
45 1
44 1
7 1
4
38 1
32 1
5 1
6 1
8
42 1
49 1
48 1
47 1
46 1
45 1
44 1
10 1
8
33 1
49 1
48 1
47 1
46 1
45 1
44 1
10 1
4
42 1
33 1
8 1
9 1
8
39 1
49 1
48 1
47 1
46 1
45 1
44 1
13 1
8
35 1
49 1
48 1
47 1
46 1
45 1
44 1
13 1
4
39 1
35 1
11 1
12 1
2
37 1
15 1
5
37 1
49 1
48 1
44 1
14 1
2
31 1
17 1
5
31 1
49 1
48 1
44 1
16 1
8
41 1
49 1
48 1
47 1
46 1
45 1
44 1
21 1
8
34 1
49 1
48 1
47 1
46 1
45 1
44 1
21 1
5
30 1
47 1
46 1
45 1
21 1
6
41 1
34 1
30 1
18 1
19 1
20 1
7
36 1
49 1
48 1
47 1
46 1
45 1
44 1
8
43 1
40 1
49 2
48 2
47 2
46 2
45 2
44 2
8
38 1
32 1
49 2
48 2
47 2
46 2
45 2
44 2
8
42 1
33 1
49 2
48 2
47 2
46 2
45 2
44 2
8
39 1
35 1
49 2
48 2
47 2
46 2
45 2
44 2
4
37 1
49 1
48 1
44 1
4
31 1
49 1
48 1
44 1
9
41 1
34 1
30 1
49 2
48 2
47 3
46 3
45 3
44 2
3
47 1
46 1
45 1
3
49 1
48 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
3
49 1
48 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
0
0
0
0
0
0
end_CG
