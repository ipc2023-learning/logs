begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var23
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var26
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var19
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var18
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var20
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var17
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var22
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var21
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var25
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var16
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var15
-1
5
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
end_variable
begin_variable
var14
-1
5
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
end_variable
begin_variable
var13
-1
5
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
end_variable
begin_variable
var12
-1
5
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var10
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
1
1
0
0
1
0
1
1
1
1
0
3
4
0
3
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
11 3
12 0
13 4
22 0
23 0
24 0
25 0
26 0
end_goal
136
begin_operator
calibrate sat1 ins2 dir1
2
14 0
7 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat1 ins5 dir2
2
14 1
8 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat1 ins6 dir2
2
14 1
9 0
1
0 16 -1 0
0
end_operator
begin_operator
calibrate sat2 ins3 dir2
2
13 1
6 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat3 ins1 dir5
2
12 4
4 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat4 ins4 dir3
2
11 2
0 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat4 ins7 dir1
2
11 0
1 0
1
0 15 -1 0
0
end_operator
begin_operator
switch_off ins1 sat3
0
2
0 3 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins2 sat1
0
2
0 10 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins3 sat2
0
2
0 5 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins4 sat4
0
2
0 2 -1 0
0 0 0 1
0
end_operator
begin_operator
switch_off ins5 sat1
0
2
0 10 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins6 sat1
0
2
0 10 -1 0
0 9 0 1
0
end_operator
begin_operator
switch_off ins7 sat4
0
2
0 2 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_on ins1 sat3
0
3
0 21 -1 1
0 3 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins2 sat1
0
3
0 20 -1 1
0 10 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins3 sat2
0
3
0 19 -1 1
0 5 0 1
0 6 -1 0
0
end_operator
begin_operator
switch_on ins4 sat4
0
3
0 18 -1 1
0 2 0 1
0 0 -1 0
0
end_operator
begin_operator
switch_on ins5 sat1
0
3
0 17 -1 1
0 10 0 1
0 8 -1 0
0
end_operator
begin_operator
switch_on ins6 sat1
0
3
0 16 -1 1
0 10 0 1
0 9 -1 0
0
end_operator
begin_operator
switch_on ins7 sat4
0
3
0 15 -1 1
0 2 0 1
0 1 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins2 mod1
3
20 0
14 0
7 0
1
0 26 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins5 mod1
3
17 0
14 0
8 0
1
0 26 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins6 mod1
3
16 0
14 0
9 0
1
0 26 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins2 mod1
3
20 0
14 1
7 0
1
0 25 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins5 mod1
3
17 0
14 1
8 0
1
0 25 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins6 mod1
3
16 0
14 1
9 0
1
0 25 -1 0
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




witch 8
check 0
check 1
34
check 0
check 0
check 0
check 0
switch 16
check 0
switch 14
check 0
switch 9
check 0
check 1
23
check 0
check 0
switch 9
check 0
check 1
26
check 0
check 0
switch 9
check 0
check 1
29
check 0
check 0
switch 9
check 0
check 1
32
check 0
check 0
switch 9
check 0
check 1
35
check 0
check 0
check 0
check 0
switch 15
check 0
switch 11
check 0
switch 1
check 0
check 1
47
check 0
check 0
switch 1
check 0
check 1
49
check 0
check 0
switch 1
check 0
check 1
51
check 0
check 0
switch 1
check 0
check 1
53
check 0
check 0
switch 1
check 0
check 1
55
check 0
check 0
check 0
check 0
switch 14
check 0
switch 13
check 4
60
64
68
72
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
0
check 0
check 0
switch 13
check 4
56
65
69
73
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
1
check 0
switch 9
check 0
check 1
2
check 0
check 0
check 4
57
61
70
74
check 4
58
62
66
75
check 4
59
63
67
71
switch 13
check 0
check 4
80
84
88
92
switch 12
check 4
76
85
89
93
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
3
check 0
check 0
check 4
77
81
90
94
check 4
78
82
86
95
check 4
79
83
87
91
switch 12
check 0
check 4
100
104
108
112
check 4
96
105
109
113
check 4
97
101
110
114
check 4
98
102
106
115
switch 11
check 4
99
103
107
111
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
4
check 0
check 0
switch 11
check 0
switch 10
check 4
120
124
128
132
check 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 4
116
125
129
133
switch 10
check 4
117
121
130
134
check 0
check 0
switch 0
check 0
check 1
5
check 0
check 0
check 4
118
122
126
135
check 4
119
123
127
131
switch 10
check 0
check 3
15
18
19
check 0
switch 5
check 0
check 1
16
check 0
switch 3
check 0
check 1
14
check 0
switch 2
check 0
check 2
17
20
check 0
switch 4
check 0
check 1
7
check 0
switch 7
check 0
check 1
8
check 0
switch 6
check 0
check 1
9
check 0
switch 0
check 0
check 1
10
check 0
switch 8
check 0
check 1
11
check 0
switch 9
check 0
check 1
12
check 0
switch 1
check 0
check 1
13
check 0
check 0
end_SG
begin_DTG
1
1
10
0
1
0
17
1
2 0
end_DTG
begin_DTG
1
1
13
0
1
0
20
1
2 0
end_DTG
begin_DTG
1
1
17
0
2
0
10
1
0 0
0
13
1
1 0
end_DTG
begin_DTG
1
1
14
0
1
0
7
1
4 0
end_DTG
begin_DTG
1
1
7
0
1
0
14
1
3 0
end_DTG
begin_DTG
1
1
16
0
1
0
9
1
6 0
end_DTG
begin_DTG
1
1
9
0
1
0
16
1
5 0
end_DTG
begin_DTG
1
1
8
0
1
0
15
1
10 0
end_DTG
begin_DTG
1
1
11
0
1
0
18
1
10 0
end_DTG
begin_DTG
1
1
12
0
1
0
19
1
10 0
end_DTG
begin_DTG
1
1
15
0
3
0
8
1
7 0
0
11
1
8 0
0
12
1
9 0
end_DTG
begin_DTG
4
1
120
0
2
124
0
3
128
0
4
132
0
4
0
116
0
2
125
0
3
129
0
4
133
0
4
0
117
0
1
121
0
3
130
0
4
134
0
4
0
118
0
1
122
0
2
126
0
4
135
0
4
0
119
0
1
123
0
2
127
0
3
131
0
end_DTG
begin_DTG
4
1
100
0
2
104
0
3
108
0
4
112
0
4
0
96
0
2
105
0
3
109
0
4
113
0
4
0
97
0
1
101
0
3
110
0
4
114
0
4
0
98
0
1
102
0
2
106
0
4
115
0
4
0
99
0
1
103
0
2
107
0
3
111
0
end_DTG
begin_DTG
4
1
80
0
2
84
0
3
88
0
4
92
0
4
0
76
0
2
85
0
3
89
0
4
93
0
4
0
77
0
1
81
0
3
90
0
4
94
0
4
0
78
0
1
82
0
2
86
0
4
95
0
4
0
79
0
1
83
0
2
87
0
3
91
0
end_DTG
begin_DTG
4
1
60
0
2
64
0
3
68
0
4
72
0
4
0
56
0
2
65
0
3
69
0
4
73
0
4
0
57
0
1
61
0
3
70
0
4
74
0
4
0
58
0
1
62
0
2
66
0
4
75
0
4
0
59
0
1
63
0
2
67
0
3
71
0
end_DTG
begin_DTG
1
1
20
1
2 0
1
0
6
2
11 0
1 0
end_DTG
begin_DTG
1
1
19
1
10 0
1
0
2
2
14 1
9 0
end_DTG
begin_DTG
1
1
18
1
10 0
1
0
1
2
14 1
8 0
end_DTG
begin_DTG
1
1
17
1
2 0
1
0
5
2
11 2
0 0
end_DTG
begin_DTG
1
1
16
1
5 0
1
0
3
2
13 1
6 0
end_DTG
begin_DTG
1
1
15
1
10 0
1
0
0
2
14 0
7 0
end_DTG
begin_DTG
1
1
14
1
3 0
1
0
4
2
12 4
4 0
end_DTG
begin_DTG
0
7
0
33
3
20 0
14 4
7 0
0
34
3
17 0
14 4
8 0
0
35
3
16 0
14 4
9 0
0
40
3
19 0
13 4
6 0
0
45
3
21 0
12 4
4 0
0
54
3
18 0
11 4
0 0
0
55
3
15 0
11 4
1 0
end_DTG
begin_DTG
0
7
0
30
3
20 0
14 3
7 0
0
31
3
17 0
14 3
8 0
0
32
3
16 0
14 3
9 0
0
39
3
19 0
13 3
6 0
0
44
3
21 0
12 3
4 0
0
52
3
18 0
11 3
0 0
0
53
3
15 0
11 3
1 0
end_DTG
begin_DTG
0
7
0
27
3
20 0
14 2
7 0
0
28
3
17 0
14 2
8 0
0
29
3
16 0
14 2
9 0
0
38
3
19 0
13 2
6 0
0
43
3
21 0
12 2
4 0
0
50
3
18 0
11 2
0 0
0
51
3
15 0
11 2
1 0
end_DTG
begin_DTG
0
7
0
24
3
20 0
14 1
7 0
0
25
3
17 0
14 1
8 0
0
26
3
16 0
14 1
9 0
0
37
3
19 0
13 1
6 0
0
42
3
21 0
12 1
4 0
0
48
3
18 0
11 1
0 0
0
49
3
15 0
11 1
1 0
end_DTG
begin_DTG
0
7
0
21
3
20 0
14 0
7 0
0
22
3
17 0
14 0
8 0
0
23
3
16 0
14 0
9 0
0
36
3
19 0
13 0
6 0
0
41
3
21 0
12 0
4 0
0
46
3
18 0
11 0
0 0
0
47
3
15 0
11 0
1 0
end_DTG
begin_CG
7
18 1
26 1
25 1
24 1
23 1
22 1
2 1
7
15 1
26 1
25 1
24 1
23 1
22 1
2 1
4
18 1
15 1
0 1
1 1
2
21 1
4 1
7
21 1
26 1
25 1
24 1
23 1
22 1
3 1
2
19 1
6 1
7
19 1
26 1
25 1
24 1
23 1
22 1
5 1
7
20 1
26 1
25 1
24 1
23 1
22 1
10 1
7
17 1
26 1
25 1
24 1
23 1
22 1
10 1
7
16 1
26 1
25 1
24 1
23 1
22 1
10 1
6
20 1
17 1
16 1
7 1
8 1
9 1
7
18 1
15 1
26 2
25 2
24 2
23 2
22 2
6
21 1
26 1
25 1
24 1
23 1
22 1
6
19 1
26 1
25 1
24 1
23 1
22 1
8
20 1
17 1
16 1
26 3
25 3
24 3
23 3
22 3
5
26 1
25 1
24 1
23 1
22 1
5
26 1
25 1
24 1
23 1
22 1
5
26 1
25 1
24 1
23 1
22 1
5
26 1
25 1
24 1
23 1
22 1
5
26 1
25 1
24 1
23 1
22 1
5
26 1
25 1
24 1
23 1
22 1
5
26 1
25 1
24 1
23 1
22 1
0
0
0
0
0
end_CG
