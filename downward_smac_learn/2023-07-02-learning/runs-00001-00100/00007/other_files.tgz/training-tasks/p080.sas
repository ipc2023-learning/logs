begin_version
3
end_version
begin_metric
0
end_metric
73
begin_variable
var61
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var52
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var13
-1
2
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





3
45 0
34 5
23 0
0
99
3
42 0
33 5
21 0
0
124
3
43 0
32 5
17 0
0
126
3
35 0
32 5
18 0
0
166
3
36 0
31 5
15 0
0
201
3
37 0
30 5
11 0
0
217
3
65 0
29 5
9 0
0
235
3
50 0
28 5
5 0
0
264
3
39 0
27 5
3 0
0
287
3
38 0
26 5
1 0
end_DTG
begin_DTG
0
10
0
67
3
45 0
34 3
23 0
0
97
3
42 0
33 3
21 0
0
119
3
43 0
32 3
17 0
0
121
3
35 0
32 3
18 0
0
159
3
36 0
31 3
15 0
0
196
3
37 0
30 3
11 0
0
216
3
65 0
29 3
9 0
0
231
3
50 0
28 3
5 0
0
259
3
39 0
27 3
3 0
0
284
3
38 0
26 3
1 0
end_DTG
begin_DTG
0
10
0
62
3
45 0
34 2
23 0
0
95
3
42 0
33 2
21 0
0
114
3
43 0
32 2
17 0
0
116
3
35 0
32 2
18 0
0
154
3
36 0
31 2
15 0
0
193
3
37 0
30 2
11 0
0
215
3
65 0
29 2
9 0
0
227
3
50 0
28 2
5 0
0
256
3
39 0
27 2
3 0
0
281
3
38 0
26 2
1 0
end_DTG
begin_DTG
0
10
0
56
3
45 0
34 1
23 0
0
93
3
42 0
33 1
21 0
0
109
3
43 0
32 1
17 0
0
111
3
35 0
32 1
18 0
0
148
3
36 0
31 1
15 0
0
189
3
37 0
30 1
11 0
0
214
3
65 0
29 1
9 0
0
223
3
50 0
28 1
5 0
0
252
3
39 0
27 1
3 0
0
278
3
38 0
26 1
1 0
end_DTG
begin_DTG
0
10
0
52
3
45 0
34 0
23 0
0
92
3
42 0
33 0
21 0
0
105
3
43 0
32 0
17 0
0
107
3
35 0
32 0
18 0
0
143
3
36 0
31 0
15 0
0
185
3
37 0
30 0
11 0
0
213
3
65 0
29 0
9 0
0
220
3
50 0
28 0
5 0
0
249
3
39 0
27 0
3 0
0
276
3
38 0
26 0
1 0
end_DTG
begin_CG
2
38 1
1 1
23
38 1
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
0 1
8
44 1
63 1
61 1
58 1
57 1
54 1
52 1
4 1
23
39 1
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
4 1
4
44 1
39 1
2 1
3 1
23
50 1
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
7 1
10
40 1
64 1
62 1
60 1
59 1
56 1
55 1
53 1
51 1
7 1
4
50 1
40 1
5 1
6 1
2
65 1
9 1
9
65 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
8 1
16
49 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
12 1
17
37 1
72 1
64 1
71 1
62 1
70 1
60 1
69 1
59 1
68 1
56 1
67 1
55 1
66 1
53 1
51 1
12 1
4
49 1
37 1
10 1
11 1
16
48 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
16 1
10
47 1
64 1
62 1
60 1
59 1
56 1
55 1
53 1
51 1
16 1
23
36 1
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
16 1
6
48 1
47 1
36 1
13 1
14 1
15 1
17
43 1
72 1
64 1
71 1
62 1
70 1
60 1
69 1
59 1
68 1
56 1
67 1
55 1
66 1
53 1
51 1
19 1
23
35 1
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
19 1
4
43 1
35 1
17 1
18 1
2
42 1
21 1
15
42 1
72 1
71 1
63 1
70 1
61 1
69 1
58 1
68 1
57 1
67 1
66 1
54 1
52 1
20 1
16
46 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
25 1
23
45 1
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
25 1
8
41 1
63 1
61 1
58 1
57 1
54 1
52 1
25 1
6
46 1
45 1
41 1
22 1
23 1
24 1
22
38 1
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
23
44 1
39 1
72 1
64 1
71 1
63 2
62 1
70 1
61 2
60 1
69 1
59 1
58 2
68 1
57 2
56 1
67 1
55 1
66 1
54 2
53 1
52 2
51 1
23
50 1
40 1
72 1
64 2
71 1
63 1
62 2
70 1
61 1
60 2
69 1
59 2
58 1
68 1
57 1
56 2
67 1
55 2
66 1
54 1
53 2
52 1
51 2
8
65 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
23
49 1
37 1
72 1
64 2
71 1
63 1
62 2
70 1
61 1
60 2
69 1
59 2
58 1
68 1
57 1
56 2
67 1
55 2
66 1
54 1
53 2
52 1
51 2
24
48 1
47 1
36 1
72 1
64 3
71 1
63 2
62 3
70 1
61 2
60 3
69 1
59 3
58 2
68 1
57 2
56 3
67 1
55 3
66 1
54 2
53 3
52 2
51 3
23
43 1
35 1
72 2
64 2
71 2
63 1
62 2
70 2
61 1
60 2
69 2
59 2
58 1
68 2
57 1
56 2
67 2
55 2
66 2
54 1
53 2
52 1
51 2
14
42 1
72 1
71 1
63 1
70 1
61 1
69 1
58 1
68 1
57 1
67 1
66 1
54 1
52 1
24
46 1
45 1
41 1
72 1
64 2
71 1
63 3
62 2
70 1
61 3
60 2
69 1
59 2
58 3
68 1
57 3
56 2
67 1
55 2
66 1
54 3
53 2
52 3
51 2
21
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
21
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
15
72 1
64 1
71 1
62 1
70 1
60 1
69 1
59 1
68 1
56 1
67 1
55 1
66 1
53 1
51 1
21
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
21
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
8
64 1
62 1
60 1
59 1
56 1
55 1
53 1
51 1
6
63 1
61 1
58 1
57 1
54 1
52 1
13
72 1
71 1
63 1
70 1
61 1
69 1
58 1
68 1
57 1
67 1
66 1
54 1
52 1
15
72 1
64 1
71 1
62 1
70 1
60 1
69 1
59 1
68 1
56 1
67 1
55 1
66 1
53 1
51 1
6
63 1
61 1
58 1
57 1
54 1
52 1
21
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
14
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
8
64 1
62 1
60 1
59 1
56 1
55 1
53 1
51 1
14
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
14
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
21
72 1
64 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
59 1
58 1
68 1
57 1
56 1
67 1
55 1
66 1
54 1
53 1
52 1
51 1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
7
72 1
71 1
70 1
69 1
68 1
67 1
66 1
0
0
0
0
0
0
0
end_CG
