begin_version
3
end_version
begin_metric
0
end_metric
62
begin_variable
var61
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var60
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var51
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var50
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var49
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var56
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var48
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var47
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var46
-1
8
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
end_variable
begin_variable
var45
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var44
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var43
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var42
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var41
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var40
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var39
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins15)
NegatedAtom calibrated(ins15)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
70
3
31 0
30 6
21 0
0
92
3
42 0
29 6
17 0
0
93
3
35 0
29 6
18 0
0
110
3
41 0
28 6
13 0
0
132
3
32 0
26 6
10 0
0
163
3
45 0
25 6
5 0
0
166
3
43 0
25 6
6 0
0
188
3
39 0
23 6
0 0
end_DTG
begin_DTG
0
6
0
64
3
38 0
30 5
20 0
0
66
3
31 0
30 5
21 0
0
109
3
41 0
28 5
13 0
0
131
3
32 0
26 5
10 0
0
160
3
45 0
25 5
5 0
0
162
3
40 0
25 5
7 0
end_DTG
begin_DTG
0
9
0
63
3
38 0
30 5
20 0
0
65
3
31 0
30 5
21 0
0
89
3
42 0
29 5
17 0
0
90
3
35 0
29 5
18 0
0
108
3
41 0
28 5
13 0
0
130
3
32 0
26 5
10 0
0
159
3
45 0
25 5
5 0
0
161
3
43 0
25 5
6 0
0
187
3
39 0
23 5
0 0
end_DTG
begin_DTG
0
12
0
59
3
38 0
30 4
20 0
0
62
3
31 0
30 4
21 0
0
85
3
44 0
29 4
16 0
0
88
3
35 0
29 4
18 0
0
107
3
33 0
28 4
14 0
0
118
3
37 0
27 4
12 0
0
129
3
32 0
26 4
10 0
0
154
3
45 0
25 4
5 0
0
156
3
43 0
25 4
6 0
0
158
3
40 0
25 4
7 0
0
178
3
34 0
24 4
4 0
0
186
3
36 0
23 4
1 0
end_DTG
begin_DTG
0
6
0
58
3
38 0
30 4
20 0
0
61
3
31 0
30 4
21 0
0
106
3
41 0
28 4
13 0
0
128
3
32 0
26 4
10 0
0
153
3
45 0
25 4
5 0
0
157
3
40 0
25 4
7 0
end_DTG
begin_DTG
0
9
0
57
3
38 0
30 4
20 0
0
60
3
31 0
30 4
21 0
0
86
3
42 0
29 4
17 0
0
87
3
35 0
29 4
18 0
0
105
3
41 0
28 4
13 0
0
127
3
32 0
26 4
10 0
0
152
3
45 0
25 4
5 0
0
155
3
43 0
25 4
6 0
0
185
3
39 0
23 4
0 0
end_DTG
begin_DTG
0
12
0
54
3
38 0
30 3
20 0
0
56
3
31 0
30 3
21 0
0
83
3
44 0
29 3
16 0
0
84
3
35 0
29 3
18 0
0
104
3
33 0
28 3
14 0
0
117
3
37 0
27 3
12 0
0
126
3
32 0
26 3
10 0
0
148
3
45 0
25 3
5 0
0
149
3
43 0
25 3
6 0
0
151
3
40 0
25 3
7 0
0
177
3
34 0
24 3
4 0
0
184
3
36 0
23 3
1 0
end_DTG
begin_DTG
0
6
0
53
3
38 0
30 3
20 0
0
55
3
31 0
30 3
21 0
0
103
3
41 0
28 3
13 0
0
125
3
32 0
26 3
10 0
0
147
3
45 0
25 3
5 0
0
150
3
40 0
25 3
7 0
end_DTG
begin_DTG
0
12
0
51
3
38 0
30 2
20 0
0
52
3
31 0
30 2
21 0
0
81
3
44 0
29 2
16 0
0
82
3
35 0
29 2
18 0
0
102
3
33 0
28 2
14 0
0
116
3
37 0
27 2
12 0
0
124
3
32 0
26 2
10 0
0
144
3
45 0
25 2
5 0
0
145
3
43 0
25 2
6 0
0
146
3
40 0
25 2
7 0
0
176
3
34 0
24 2
4 0
0
183
3
36 0
23 2
1 0
end_DTG
begin_DTG
0
12
0
48
3
38 0
30 1
20 0
0
50
3
31 0
30 1
21 0
0
77
3
44 0
29 1
16 0
0
80
3
35 0
29 1
18 0
0
101
3
33 0
28 1
14 0
0
115
3
37 0
27 1
12 0
0
123
3
32 0
26 1
10 0
0
140
3
45 0
25 1
5 0
0
142
3
43 0
25 1
6 0
0
143
3
40 0
25 1
7 0
0
175
3
34 0
24 1
4 0
0
182
3
36 0
23 1
1 0
end_DTG
begin_DTG
0
9
0
47
3
38 0
30 1
20 0
0
49
3
31 0
30 1
21 0
0
78
3
42 0
29 1
17 0
0
79
3
35 0
29 1
18 0
0
100
3
41 0
28 1
13 0
0
122
3
32 0
26 1
10 0
0
139
3
45 0
25 1
5 0
0
141
3
43 0
25 1
6 0
0
181
3
39 0
23 1
0 0
end_DTG
begin_DTG
0
6
0
45
3
38 0
30 0
20 0
0
46
3
31 0
30 0
21 0
0
99
3
41 0
28 0
13 0
0
121
3
32 0
26 0
10 0
0
137
3
45 0
25 0
5 0
0
138
3
40 0
25 0
7 0
end_DTG
begin_CG
7
39 1
60 1
55 1
52 1
50 1
47 1
2 1
8
36 1
59 1
58 1
56 1
53 1
48 1
46 1
2 1
4
39 1
36 1
0 1
1 1
2
34 1
4 1
8
34 1
59 1
58 1
56 1
53 1
48 1
46 1
3 1
18
45 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
8 1
13
43 1
60 1
59 1
58 1
56 1
55 1
53 1
52 1
50 1
48 1
47 1
46 1
8 1
13
40 1
61 1
59 1
58 1
57 1
56 1
54 1
53 1
51 1
49 1
48 1
46 1
8 1
6
45 1
43 1
40 1
5 1
6 1
7 1
2
32 1
10 1
18
32 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
9 1
2
37 1
12 1
8
37 1
59 1
58 1
56 1
53 1
48 1
46 1
11 1
12
41 1
61 1
60 1
57 1
55 1
54 1
52 1
51 1
50 1
49 1
47 1
15 1
8
33 1
59 1
58 1
56 1
53 1
48 1
46 1
15 1
4
41 1
33 1
13 1
14 1
8
44 1
59 1
58 1
56 1
53 1
48 1
46 1
19 1
7
42 1
60 1
55 1
52 1
50 1
47 1
19 1
13
35 1
60 1
59 1
58 1
56 1
55 1
53 1
52 1
50 1
48 1
47 1
46 1
19 1
6
44 1
42 1
35 1
16 1
17 1
18 1
18
38 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
22 1
18
31 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
22 1
4
38 1
31 1
20 1
21 1
13
39 1
36 1
60 1
59 1
58 1
56 1
55 1
53 1
52 1
50 1
48 1
47 1
46 1
7
34 1
59 1
58 1
56 1
53 1
48 1
46 1
19
45 1
43 1
40 1
61 2
60 2
59 3
58 3
57 2
56 3
55 2
54 2
53 3
52 2
51 2
50 2
49 2
48 3
47 2
46 3
17
32 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
7
37 1
59 1
58 1
56 1
53 1
48 1
46 1
18
41 1
33 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
14
44 1
42 1
35 1
60 2
59 2
58 2
56 2
55 2
53 2
52 2
50 2
48 2
47 2
46 2
18
38 1
31 1
61 2
60 2
59 2
58 2
57 2
56 2
55 2
54 2
53 2
52 2
51 2
50 2
49 2
48 2
47 2
46 2
16
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
16
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
6
59 1
58 1
56 1
53 1
48 1
46 1
6
59 1
58 1
56 1
53 1
48 1
46 1
11
60 1
59 1
58 1
56 1
55 1
53 1
52 1
50 1
48 1
47 1
46 1
6
59 1
58 1
56 1
53 1
48 1
46 1
6
59 1
58 1
56 1
53 1
48 1
46 1
16
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
5
60 1
55 1
52 1
50 1
47 1
11
61 1
59 1
58 1
57 1
56 1
54 1
53 1
51 1
49 1
48 1
46 1
10
61 1
60 1
57 1
55 1
54 1
52 1
51 1
50 1
49 1
47 1
5
60 1
55 1
52 1
50 1
47 1
11
60 1
59 1
58 1
56 1
55 1
53 1
52 1
50 1
48 1
47 1
46 1
6
59 1
58 1
56 1
53 1
48 1
46 1
16
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
