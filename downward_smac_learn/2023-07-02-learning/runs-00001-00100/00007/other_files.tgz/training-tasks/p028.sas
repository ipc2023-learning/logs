begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var19
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var23
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var18
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var22
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var17
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var16
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var20
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var15
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var21
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var14
-1
5
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
end_variable
begin_variable
var13
-1
5
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
end_variable
begin_variable
var12
-1
5
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
end_variable
begin_variable
var11
-1
5
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var10
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var6
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
1
1
0
1
1
0
0
1
0
1
1
4
1
3
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
7
11 1
12 3
13 2
20 0
21 0
22 0
23 0
end_goal
122
begin_operator
calibrate sat1 ins3 dir3
2
13 2
9 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir3
2
12 2
7 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat3 ins4 dir1
2
11 0
3 0
1
0 16 -1 0
0
end_operator
begin_operator
calibrate sat3 ins6 dir3
2
11 2
4 0
1
0 14 -1 0
0
end_operator
begin_operator
calibrate sat4 ins1 dir3
2
10 2
0 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat4 ins5 dir4
2
10 3
1 0
1
0 15 -1 0
0
end_operator
begin_operator
switch_off ins1 sat4
0
2
0 2 -1 0
0 0 0 1
0
end_operator
begin_operator
switch_off ins2 sat2
0
2
0 6 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins3 sat1
0
2
0 8 -1 0
0 9 0 1
0
end_operator
begin_operator
switch_off ins4 sat3
0
2
0 5 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins5 sat4
0
2
0 2 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins6 sat3
0
2
0 5 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_on ins1 sat4
0
3
0 19 -1 1
0 2 0 1
0 0 -1 0
0
end_operator
begin_operator
switch_on ins2 sat2
0
3
0 18 -1 1
0 6 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins3 sat1
0
3
0 17 -1 1
0 8 0 1
0 9 -1 0
0
end_operator
begin_operator
switch_on ins4 sat3
0
3
0 16 -1 1
0 5 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins5 sat4
0
3
0 15 -1 1
0 2 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins6 sat3
0
3
0 14 -1 1
0 5 0 1
0 4 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins3 mod1
3
17 0
13 0
9 0
1
0 23 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins3 mod1
3
17 0
13 1
9 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins3 mod1
3
17 0
13 3
9 0
1
0 21 -1 0
0
end_operator
begin_operator
take_image sat1 dir5 ins3 mod1
3
17 0
13 4
9 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat2 dir1 ins2 mod1
3
18 0
12 0
7 0
1
0 23 -1 0
0
end_operator
begin_operator
take_image sat2 dir2 ins2 mod1
3
18 0
12 1
7 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat2 dir4 ins2 mod1
3
18 0
12 3
7 0
1
0 21 -1 0
0
end_operator
begin_operator
take_image sat2 dir5 ins2 mod1
3
18 0
12 4
7 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat3 dir1 ins4 mod1
3
16 0
11 0
3 0
1
0 23 -1 0
0
end_operator
begin_operator
take_image sat3 dir1 ins6 mod1
3
14 0
11 0
4 0
1
0 23 -1 0
0
end_operator
begin_operator
take_image sat3 dir2 ins4 mod1
3
16 0
11 1
3 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat3 dir2 ins6 mod1
3
14 0
11 1
4 0
1
0 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 0
check 1
40
check 0
check 0
check 0
check 0
switch 18
check 0
switch 12
check 0
switch 7
check 0
check 1
22
check 0
check 0
switch 7
check 0
check 1
23
check 0
check 0
check 0
switch 7
check 0
check 1
24
check 0
check 0
switch 7
check 0
check 1
25
check 0
check 0
check 0
check 0
switch 17
check 0
switch 13
check 0
switch 9
check 0
check 1
18
check 0
check 0
switch 9
check 0
check 1
19
check 0
check 0
check 0
switch 9
check 0
check 1
20
check 0
check 0
switch 9
check 0
check 1
21
check 0
check 0
check 0
check 0
switch 16
check 0
switch 11
check 0
switch 3
check 0
check 1
26
check 0
check 0
switch 3
check 0
check 1
28
check 0
check 0
check 0
switch 3
check 0
check 1
30
check 0
check 0
switch 3
check 0
check 1
32
check 0
check 0
check 0
check 0
switch 15
check 0
switch 10
check 0
switch 1
check 0
check 1
35
check 0
check 0
switch 1
check 0
check 1
37
check 0
check 0
check 0
switch 1
check 0
check 1
39
check 0
check 0
switch 1
check 0
check 1
41
check 0
check 0
check 0
check 0
switch 14
check 0
switch 11
check 0
switch 4
check 0
check 1
27
check 0
check 0
switch 4
check 0
check 1
29
check 0
check 0
check 0
switch 4
check 0
check 1
31
check 0
check 0
switch 4
check 0
check 1
33
check 0
check 0
check 0
check 0
switch 13
check 0
check 4
46
50
54
58
check 4
42
51
55
59
switch 12
check 4
43
47
56
60
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
0
check 0
check 0
check 4
44
48
52
61
check 4
45
49
53
57
switch 12
check 0
check 4
66
70
74
78
check 4
62
71
75
79
switch 11
check 4
63
67
76
80
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
1
check 0
check 0
check 4
64
68
72
81
check 4
65
69
73
77
switch 11
check 0
switch 10
check 4
86
90
94
98
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
2
check 0
check 0
check 4
82
91
95
99
switch 10
check 4
83
87
96
100
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
3
check 0
check 0
check 4
84
88
92
101
check 4
85
89
93
97
switch 10
check 0
check 4
106
110
114
118
check 4
102
111
115
119
switch 8
check 4
103
107
116
120
check 0
check 0
switch 0
check 0
check 1
4
check 0
check 0
switch 8
check 4
104
108
112
121
check 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
check 4
105
109
113
117
switch 8
check 0
check 1
14
check 0
switch 6
check 0
check 1
13
check 0
switch 5
check 0
check 2
15
17
check 0
switch 2
check 0
check 2
12
16
check 0
switch 0
check 0
check 1
6
check 0
switch 7
check 0
check 1
7
check 0
switch 9
check 0
check 1
8
check 0
switch 3
check 0
check 1
9
check 0
switch 1
check 0
check 1
10
check 0
switch 4
check 0
check 1
11
check 0
check 0
end_SG
begin_DTG
1
1
6
0
1
0
12
1
2 0
end_DTG
begin_DTG
1
1
10
0
1
0
16
1
2 0
end_DTG
begin_DTG
1
1
12
0
2
0
6
1
0 0
0
10
1
1 0
end_DTG
begin_DTG
1
1
9
0
1
0
15
1
5 0
end_DTG
begin_DTG
1
1
11
0
1
0
17
1
5 0
end_DTG
begin_DTG
1
1
15
0
2
0
9
1
3 0
0
11
1
4 0
end_DTG
begin_DTG
1
1
13
0
1
0
7
1
7 0
end_DTG
begin_DTG
1
1
7
0
1
0
13
1
6 0
end_DTG
begin_DTG
1
1
14
0
1
0
8
1
9 0
end_DTG
begin_DTG
1
1
8
0
1
0
14
1
8 0
end_DTG
begin_DTG
4
1
106
0
2
110
0
3
114
0
4
118
0
4
0
102
0
2
111
0
3
115
0
4
119
0
4
0
103
0
1
107
0
3
116
0
4
120
0
4
0
104
0
1
108
0
2
112
0
4
121
0
4
0
105
0
1
109
0
2
113
0
3
117
0
end_DTG
begin_DTG
4
1
86
0
2
90
0
3
94
0
4
98
0
4
0
82
0
2
91
0
3
95
0
4
99
0
4
0
83
0
1
87
0
3
96
0
4
100
0
4
0
84
0
1
88
0
2
92
0
4
101
0
4
0
85
0
1
89
0
2
93
0
3
97
0
end_DTG
begin_DTG
4
1
66
0
2
70
0
3
74
0
4
78
0
4
0
62
0
2
71
0
3
75
0
4
79
0
4
0
63
0
1
67
0
3
76
0
4
80
0
4
0
64
0
1
68
0
2
72
0
4
81
0
4
0
65
0
1
69
0
2
73
0
3
77
0
end_DTG
begin_DTG
4
1
46
0
2
50
0
3
54
0
4
58
0
4
0
42
0
2
51
0
3
55
0
4
59
0
4
0
43
0
1
47
0
3
56
0
4
60
0
4
0
44
0
1
48
0
2
52
0
4
61
0
4
0
45
0
1
49
0
2
53
0
3
57
0
end_DTG
begin_DTG
1
1
17
1
5 0
1
0
3
2
11 2
4 0
end_DTG
begin_DTG
1
1
16
1
2 0
1
0
5
2
10 3
1 0
end_DTG
begin_DTG
1
1
15
1
5 0
1
0
2
2
11 0
3 0
end_DTG
begin_DTG
1
1
14
1
8 0
1
0
0
2
13 2
9 0
end_DTG
begin_DTG
1
1
13
1
6 0
1
0
1
2
12 2
7 0
end_DTG
begin_DTG
1
1
12
1
2 0
1
0
4
2
10 2
0 0
end_DTG
begin_DTG
0
6
0
21
3
17 0
13 4
9 0
0
25
3
18 0
12 4
7 0
0
32
3
16 0
11 4
3 0
0
33
3
14 0
11 4
4 0
0
40
3
19 0
10 4
0 0
0
41
3
15 0
10 4
1 0
end_DTG
begin_DTG
0
6
0
20
3
17 0
13 3
9 0
0
24
3
18 0
12 3
7 0
0
30
3
16 0
11 3
3 0
0
31
3
14 0
11 3
4 0
0
38
3
19 0
10 3
0 0
0
39
3
15 0
10 3
1 0
end_DTG
begin_DTG
0
6
0
19
3
17 0
13 1
9 0
0
23
3
18 0
12 1
7 0
0
28
3
16 0
11 1
3 0
0
29
3
14 0
11 1
4 0
0
36
3
19 0
10 1
0 0
0
37
3
15 0
10 1
1 0
end_DTG
begin_DTG
0
6
0
18
3
17 0
13 0
9 0
0
22
3
18 0
12 0
7 0
0
26
3
16 0
11 0
3 0
0
27
3
14 0
11 0
4 0
0
34
3
19 0
10 0
0 0
0
35
3
15 0
10 0
1 0
end_DTG
begin_CG
6
19 1
23 1
22 1
21 1
20 1
2 1
6
15 1
23 1
22 1
21 1
20 1
2 1
4
19 1
15 1
0 1
1 1
6
16 1
23 1
22 1
21 1
20 1
5 1
6
14 1
23 1
22 1
21 1
20 1
5 1
4
16 1
14 1
3 1
4 1
2
18 1
7 1
6
18 1
23 1
22 1
21 1
20 1
6 1
2
17 1
9 1
6
17 1
23 1
22 1
21 1
20 1
8 1
6
19 1
15 1
23 2
22 2
21 2
20 2
6
16 1
14 1
23 2
22 2
21 2
20 2
5
18 1
23 1
22 1
21 1
20 1
5
17 1
23 1
22 1
21 1
20 1
4
23 1
22 1
21 1
20 1
4
23 1
22 1
21 1
20 1
4
23 1
22 1
21 1
20 1
4
23 1
22 1
21 1
20 1
4
23 1
22 1
21 1
20 1
4
23 1
22 1
21 1
20 1
0
0
0
0
end_CG
