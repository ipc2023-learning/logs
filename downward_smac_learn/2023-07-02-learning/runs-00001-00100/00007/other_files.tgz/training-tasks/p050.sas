begin_version
3
end_version
begin_metric
0
end_metric
36
begin_variable
var37
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var25
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var24
-1
2
Atom have_image(dir7, mod2)
NegatedAtom have_image(dir7, mod2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var23
-1
2
Atom have_image(dir7, mod1)
NegatedAtom have_image(dir7, mod1)
end_variable
0
begin_state
1
1
1
0
0
1
1
1
1
0
0
1
1
1
0
0
1
1
0
3
6
6
3
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
5
17 5
19 5
22 0
33 0
35 0
end_goal
305
begin_operator
calibrate sat1 ins2 dir1
2
22 0
16 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat2 ins10 dir7
2
21 6
12 0
1
0 32 -1 0
0
end_operator
begin_operator
calibrate sat2 ins5 dir2
2
21 1
13 0
1
0 27 -1 0
0
end_operator
begin_operator
calibrate sat3 ins4 dir6
2
20 5
11 0
1
0 28 -1 0
0
end_operator
begin_operator
calibrate sat4 ins11 dir1
2
19 0
6 0
1
0 31 -1 0
0
end_operator
begin_operator
calibrate sat4 ins6 dir2
2
19 1
7 0
1
0 26 -1 0
0
end_operator
begin_operator
calibrate sat4 ins7 dir2
2
19 1
8 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat5 ins3 dir1
2
18 0
5 0
1
0 29 -1 0
0
end_operator
begin_operator
calibrate sat6 ins1 dir4
2
17 3
0 0
1
0 34 -1 0
0
end_operator
begin_operator
calibrate sat6 ins8 dir3
2
17 2
1 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat6 ins9 dir1
2
17 0
2 0
1
0 23 -1 0
0
end_operator
begin_operator
switch_off ins1 sat6





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 0
check 2
23
28
check 0
switch 10
check 0
check 1
27
check 0
switch 9
check 0
check 3
24
29
30
check 0
switch 4
check 0
check 1
26
check 0
switch 3
check 0
check 3
22
31
32
check 0
switch 0
check 0
check 1
11
check 0
switch 12
check 0
check 1
12
check 0
switch 6
check 0
check 1
13
check 0
switch 16
check 0
check 1
14
check 0
switch 5
check 0
check 1
15
check 0
switch 11
check 0
check 1
16
check 0
switch 13
check 0
check 1
17
check 0
switch 7
check 0
check 1
18
check 0
switch 8
check 0
check 1
19
check 0
switch 1
check 0
check 1
20
check 0
switch 2
check 0
check 1
21
check 0
check 0
end_SG
begin_DTG
1
1
11
0
1
0
22
1
3 0
end_DTG
begin_DTG
1
1
20
0
1
0
31
1
3 0
end_DTG
begin_DTG
1
1
21
0
1
0
32
1
3 0
end_DTG
begin_DTG
1
1
22
0
3
0
11
1
0 0
0
20
1
1 0
0
21
1
2 0
end_DTG
begin_DTG
1
1
26
0
1
0
15
1
5 0
end_DTG
begin_DTG
1
1
15
0
1
0
26
1
4 0
end_DTG
begin_DTG
1
1
13
0
1
0
24
1
9 0
end_DTG
begin_DTG
1
1
18
0
1
0
29
1
9 0
end_DTG
begin_DTG
1
1
19
0
1
0
30
1
9 0
end_DTG
begin_DTG
1
1
24
0
3
0
13
1
6 0
0
18
1
7 0
0
19
1
8 0
end_DTG
begin_DTG
1
1
27
0
1
0
16
1
11 0
end_DTG
begin_DTG
1
1
16
0
1
0
27
1
10 0
end_DTG
begin_DTG
1
1
12
0
1
0
23
1
14 0
end_DTG
begin_DTG
1
1
17
0
1
0
28
1
14 0
end_DTG
begin_DTG
1
1
23
0
2
0
12
1
12 0
0
17
1
13 0
end_DTG
begin_DTG
1
1
25
0
1
0
14
1
16 0
end_DTG
begin_DTG
1
1
14
0
1
0
25
1
15 0
end_DTG
begin_DTG
6
1
269
0
2
275
0
3
281
0
4
287
0
5
293
0
6
299
0
6
0
263
0
2
276
0
3
282
0
4
288
0
5
294
0
6
300
0
6
0
264
0
1
270
0
3
283
0
4
289
0
5
295
0
6
301
0
6
0
265
0
1
271
0
2
277
0
4
290
0
5
296
0
6
302
0
6
0
266
0
1
272
0
2
278
0
3
284
0
5
297
0
6
303
0
6
0
267
0
1
273
0
2
279
0
3
285
0
4
291
0
6
304
0
6
0
268
0
1
274
0
2
280
0
3
286
0
4
292
0
5
298
0
end_DTG
begin_DTG
6
1
227
0
2
233
0
3
239
0
4
245
0
5
251
0
6
257
0
6
0
221
0
2
234
0
3
240
0
4
246
0
5
252
0
6
258
0
6
0
222
0
1
228
0
3
241
0
4
247
0
5
253
0
6
259
0
6
0
223
0
1
229
0
2
235
0
4
248
0
5
254
0
6
260
0
6
0
224
0
1
230
0
2
236
0
3
242
0
5
255
0
6
261
0
6
0
225
0
1
231
0
2
237
0
3
243
0
4
249
0
6
262
0
6
0
226
0
1
232
0
2
238
0
3
244
0
4
250
0
5
256
0
end_DTG
begin_DTG
6
1
185
0
2
191
0
3
197
0
4
203
0
5
209
0
6
215
0
6
0
179
0
2
192
0
3
198
0
4
204
0
5
210
0
6
216
0
6
0
180
0
1
186
0
3
199
0
4
205
0
5
211
0
6
217
0
6
0
181
0
1
187
0
2
193
0
4
206
0
5
212
0
6
218
0
6
0
182
0
1
188
0
2
194
0
3
200
0
5
213
0
6
219
0
6
0
183
0
1
189
0
2
195
0
3
201
0
4
207
0
6
220
0
6
0
184
0
1
190
0
2
196
0
3
202
0
4
208
0
5
214
0
end_DTG
begin_DTG
6
1
143
0
2
149
0
3
155
0
4
161
0
5
167
0
6
173
0
6
0
137
0
2
150
0
3
156
0
4
162
0
5
168
0
6
174
0
6
0
138
0
1
144
0
3
157
0
4
163
0
5
169
0
6
175
0
6
0
139
0
1
145
0
2
151
0
4
164
0
5
170
0
6
176
0
6
0
140
0
1
146
0
2
152
0
3
158
0
5
171
0
6
177
0
6
0
141
0
1
147
0
2
153
0
3
159
0
4
165
0
6
178
0
6
0
142
0
1
148
0
2
154
0
3
160
0
4
166
0
5
172
0
end_DTG
begin_DTG
6
1
101
0
2
107
0
3
113
0
4
119
0
5
125
0
6
131
0
6
0
95
0
2
108
0
3
114
0
4
120
0
5
126
0
6
132
0
6
0
96
0
1
102
0
3
115
0
4
121
0
5
127
0
6
133
0
6
0
97
0
1
103
0
2
109
0
4
122
0
5
128
0
6
134
0
6
0
98
0
1
104
0
2
110
0
3
116
0
5
129
0
6
135
0
6
0
99
0
1
105
0
2
111
0
3
117
0
4
123
0
6
136
0
6
0
100
0
1
106
0
2
112
0
3
118
0
4
124
0
5
130
0
end_DTG
begin_DTG
6
1
59
0
2
65
0
3
71
0
4
77
0
5
83
0
6
89
0
6
0
53
0
2
66
0
3
72
0
4
78
0
5
84
0
6
90
0
6
0
54
0
1
60
0
3
73
0
4
79
0
5
85
0
6
91
0
6
0
55
0
1
61
0
2
67
0
4
80
0
5
86
0
6
92
0
6
0
56
0
1
62
0
2
68
0
3
74
0
5
87
0
6
93
0
6
0
57
0
1
63
0
2
69
0
3
75
0
4
81
0
6
94
0
6
0
58
0
1
64
0
2
70
0
3
76
0
4
82
0
5
88
0
end_DTG
begin_DTG
1
1
32
1
3 0
1
0
10
2
17 0
2 0
end_DTG
begin_DTG
1
1
31
1
3 0
1
0
9
2
17 2
1 0
end_DTG
begin_DTG
1
1
30
1
9 0
1
0
6
2
19 1
8 0
end_DTG
begin_DTG
1
1
29
1
9 0
1
0
5
2
19 1
7 0
end_DTG
begin_DTG
1
1
28
1
14 0
1
0
2
2
21 1
13 0
end_DTG
begin_DTG
1
1
27
1
10 0
1
0
3
2
20 5
11 0
end_DTG
begin_DTG
1
1
26
1
4 0
1
0
7
2
18 0
5 0
end_DTG
begin_DTG
1
1
25
1
15 0
1
0
0
2
22 0
16 0
end_DTG
begin_DTG
1
1
24
1
9 0
1
0
4
2
19 0
6 0
end_DTG
begin_DTG
1
1
23
1
14 0
1
0
1
2
21 6
12 0
end_DTG
begin_DTG
0
9
0
34
3
30 0
22 6
16 0
0
36
3
32 0
21 6
12 0
0
38
3
27 0
21 6
13 0
0
40
3
28 0
20 6
11 0
0
42
3
31 0
19 6
6 0
0
44
3
26 0
19 6
7 0
0
46
3
25 0
19 6
8 0
0
50
3
24 0
17 6
1 0
0
52
3
23 0
17 6
2 0
end_DTG
begin_DTG
1
1
22
1
3 0
1
0
8
2
17 3
0 0
end_DTG
begin_DTG
0
11
0
33
3
30 0
22 6
16 0
0
35
3
32 0
21 6
12 0
0
37
3
27 0
21 6
13 0
0
39
3
28 0
20 6
11 0
0
41
3
31 0
19 6
6 0
0
43
3
26 0
19 6
7 0
0
45
3
25 0
19 6
8 0
0
47
3
29 0
18 6
5 0
0
48
3
34 0
17 6
0 0
0
49
3
24 0
17 6
1 0
0
51
3
23 0
17 6
2 0
end_DTG
begin_CG
3
34 1
35 1
3 1
4
24 1
35 1
33 1
3 1
4
23 1
35 1
33 1
3 1
6
34 1
24 1
23 1
0 1
1 1
2 1
2
29 1
5 1
3
29 1
35 1
4 1
4
31 1
35 1
33 1
9 1
4
26 1
35 1
33 1
9 1
4
25 1
35 1
33 1
9 1
6
31 1
26 1
25 1
6 1
7 1
8 1
2
28 1
11 1
4
28 1
35 1
33 1
10 1
4
32 1
35 1
33 1
14 1
4
27 1
35 1
33 1
14 1
4
32 1
27 1
12 1
13 1
2
30 1
16 1
4
30 1
35 1
33 1
15 1
5
34 1
24 1
23 1
35 3
33 2
2
29 1
35 1
5
31 1
26 1
25 1
35 3
33 3
3
28 1
35 1
33 1
4
32 1
27 1
35 2
33 2
3
30 1
35 1
33 1
2
35 1
33 1
2
35 1
33 1
2
35 1
33 1
2
35 1
33 1
2
35 1
33 1
2
35 1
33 1
1
35 1
2
35 1
33 1
2
35 1
33 1
2
35 1
33 1
0
1
35 1
0
end_CG
