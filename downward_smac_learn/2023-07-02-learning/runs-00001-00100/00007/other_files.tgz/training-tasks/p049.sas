begin_version
3
end_version
begin_metric
0
end_metric
38
begin_variable
var35
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var36
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var30
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var25
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var24
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir7, mod1)
NegatedAtom have_image(dir7, mod1)
end_variable
begin_variable
var18
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var17
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var16
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
0
begin_state
0
1
1
1
0
1
1
0
0
1
1
1
0
1
1
0
6
2
4
3
6
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
9
16 2
17 5
19 2
32 0
33 0
34 0
35 0
36 0
37 0
end_goal
332
begin_operator
calibrate sat1 ins4 dir2
2
21 1
13 0
1
0 27 -1 0
0
end_operator
begin_operator
calibrate sat1 ins9 dir1
2
21 0
14 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir2
2
20 1
10 0
1
0 29 -1 0
0
end_operator
begin_operator
calibrate sat2 ins8 dir7
2
20 6
11 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat3 ins1 dir7
2
19 6
9 0
1
0 31 -1 0
0
end_operator
begin_operator
calibrate sat4 ins10 dir4
2
18 3
5 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat4 ins6 dir3
2
18 2
6 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat5 ins5 dir6
2
17 5
2 0
1
0 26 -1 0
0
end_operator
begin_operator
cali




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




TG
begin_DTG
1
1
18
0
1
0
28
1
12 0
end_DTG
begin_DTG
1
1
22
0
2
0
12
1
10 0
0
18
1
11 0
end_DTG
begin_DTG
1
1
14
0
1
0
24
1
15 0
end_DTG
begin_DTG
1
1
19
0
1
0
29
1
15 0
end_DTG
begin_DTG
1
1
24
0
2
0
14
1
13 0
0
19
1
14 0
end_DTG
begin_DTG
6
1
296
0
2
302
0
3
308
0
4
314
0
5
320
0
6
326
0
6
0
290
0
2
303
0
3
309
0
4
315
0
5
321
0
6
327
0
6
0
291
0
1
297
0
3
310
0
4
316
0
5
322
0
6
328
0
6
0
292
0
1
298
0
2
304
0
4
317
0
5
323
0
6
329
0
6
0
293
0
1
299
0
2
305
0
3
311
0
5
324
0
6
330
0
6
0
294
0
1
300
0
2
306
0
3
312
0
4
318
0
6
331
0
6
0
295
0
1
301
0
2
307
0
3
313
0
4
319
0
5
325
0
end_DTG
begin_DTG
6
1
254
0
2
260
0
3
266
0
4
272
0
5
278
0
6
284
0
6
0
248
0
2
261
0
3
267
0
4
273
0
5
279
0
6
285
0
6
0
249
0
1
255
0
3
268
0
4
274
0
5
280
0
6
286
0
6
0
250
0
1
256
0
2
262
0
4
275
0
5
281
0
6
287
0
6
0
251
0
1
257
0
2
263
0
3
269
0
5
282
0
6
288
0
6
0
252
0
1
258
0
2
264
0
3
270
0
4
276
0
6
289
0
6
0
253
0
1
259
0
2
265
0
3
271
0
4
277
0
5
283
0
end_DTG
begin_DTG
6
1
212
0
2
218
0
3
224
0
4
230
0
5
236
0
6
242
0
6
0
206
0
2
219
0
3
225
0
4
231
0
5
237
0
6
243
0
6
0
207
0
1
213
0
3
226
0
4
232
0
5
238
0
6
244
0
6
0
208
0
1
214
0
2
220
0
4
233
0
5
239
0
6
245
0
6
0
209
0
1
215
0
2
221
0
3
227
0
5
240
0
6
246
0
6
0
210
0
1
216
0
2
222
0
3
228
0
4
234
0
6
247
0
6
0
211
0
1
217
0
2
223
0
3
229
0
4
235
0
5
241
0
end_DTG
begin_DTG
6
1
170
0
2
176
0
3
182
0
4
188
0
5
194
0
6
200
0
6
0
164
0
2
177
0
3
183
0
4
189
0
5
195
0
6
201
0
6
0
165
0
1
171
0
3
184
0
4
190
0
5
196
0
6
202
0
6
0
166
0
1
172
0
2
178
0
4
191
0
5
197
0
6
203
0
6
0
167
0
1
173
0
2
179
0
3
185
0
5
198
0
6
204
0
6
0
168
0
1
174
0
2
180
0
3
186
0
4
192
0
6
205
0
6
0
169
0
1
175
0
2
181
0
3
187
0
4
193
0
5
199
0
end_DTG
begin_DTG
6
1
128
0
2
134
0
3
140
0
4
146
0
5
152
0
6
158
0
6
0
122
0
2
135
0
3
141
0
4
147
0
5
153
0
6
159
0
6
0
123
0
1
129
0
3
142
0
4
148
0
5
154
0
6
160
0
6
0
124
0
1
130
0
2
136
0
4
149
0
5
155
0
6
161
0
6
0
125
0
1
131
0
2
137
0
3
143
0
5
156
0
6
162
0
6
0
126
0
1
132
0
2
138
0
3
144
0
4
150
0
6
163
0
6
0
127
0
1
133
0
2
139
0
3
145
0
4
151
0
5
157
0
end_DTG
begin_DTG
6
1
86
0
2
92
0
3
98
0
4
104
0
5
110
0
6
116
0
6
0
80
0
2
93
0
3
99
0
4
105
0
5
111
0
6
117
0
6
0
81
0
1
87
0
3
100
0
4
106
0
5
112
0
6
118
0
6
0
82
0
1
88
0
2
94
0
4
107
0
5
113
0
6
119
0
6
0
83
0
1
89
0
2
95
0
3
101
0
5
114
0
6
120
0
6
0
84
0
1
90
0
2
96
0
3
102
0
4
108
0
6
121
0
6
0
85
0
1
91
0
2
97
0
3
103
0
4
109
0
5
115
0
end_DTG
begin_DTG
1
1
29
1
15 0
1
0
1
2
21 0
14 0
end_DTG
begin_DTG
1
1
28
1
12 0
1
0
3
2
20 6
11 0
end_DTG
begin_DTG
1
1
27
1
4 0
1
0
8
2
17 1
3 0
end_DTG
begin_DTG
1
1
26
1
7 0
1
0
6
2
18 2
6 0
end_DTG
begin_DTG
1
1
25
1
4 0
1
0
7
2
17 5
2 0
end_DTG
begin_DTG
1
1
24
1
15 0
1
0
0
2
21 1
13 0
end_DTG
begin_DTG
1
1
23
1
0 0
1
0
9
2
16 6
1 0
end_DTG
begin_DTG
1
1
22
1
12 0
1
0
2
2
20 1
10 0
end_DTG
begin_DTG
1
1
21
1
7 0
1
0
5
2
18 3
5 0
end_DTG
begin_DTG
1
1
20
1
8 0
1
0
4
2
19 6
9 0
end_DTG
begin_DTG
0
8
0
40
3
27 0
21 6
13 0
0
41
3
22 0
21 6
14 0
0
48
3
23 0
20 6
11 0
0
54
3
31 0
19 6
9 0
0
61
3
30 0
18 6
5 0
0
72
3
26 0
17 6
2 0
0
73
3
24 0
17 6
3 0
0
79
3
28 0
16 6
1 0
end_DTG
begin_DTG
0
8
0
38
3
27 0
21 4
13 0
0
39
3
22 0
21 4
14 0
0
47
3
23 0
20 4
11 0
0
53
3
31 0
19 4
9 0
0
60
3
30 0
18 4
5 0
0
70
3
26 0
17 4
2 0
0
71
3
24 0
17 4
3 0
0
78
3
28 0
16 4
1 0
end_DTG
begin_DTG
0
10
0
35
3
27 0
21 3
13 0
0
37
3
22 0
21 3
14 0
0
44
3
29 0
20 3
10 0
0
46
3
23 0
20 3
11 0
0
52
3
31 0
19 3
9 0
0
58
3
30 0
18 3
5 0
0
59
3
25 0
18 3
6 0
0
67
3
26 0
17 3
2 0
0
69
3
24 0
17 3
3 0
0
77
3
28 0
16 3
1 0
end_DTG
begin_DTG
0
8
0
34
3
27 0
21 3
13 0
0
36
3
22 0
21 3
14 0
0
45
3
23 0
20 3
11 0
0
51
3
31 0
19 3
9 0
0
57
3
30 0
18 3
5 0
0
66
3
26 0
17 3
2 0
0
68
3
24 0
17 3
3 0
0
76
3
28 0
16 3
1 0
end_DTG
begin_DTG
0
8
0
32
3
27 0
21 2
13 0
0
33
3
22 0
21 2
14 0
0
43
3
23 0
20 2
11 0
0
50
3
31 0
19 2
9 0
0
56
3
30 0
18 2
5 0
0
64
3
26 0
17 2
2 0
0
65
3
24 0
17 2
3 0
0
75
3
28 0
16 2
1 0
end_DTG
begin_DTG
0
8
0
30
3
27 0
21 1
13 0
0
31
3
22 0
21 1
14 0
0
42
3
23 0
20 1
11 0
0
49
3
31 0
19 1
9 0
0
55
3
30 0
18 1
5 0
0
62
3
26 0
17 1
2 0
0
63
3
24 0
17 1
3 0
0
74
3
28 0
16 1
1 0
end_DTG
begin_CG
2
28 1
1 1
8
28 1
37 1
36 1
35 1
34 1
33 1
32 1
0 1
8
26 1
37 1
36 1
35 1
34 1
33 1
32 1
4 1
8
24 1
37 1
36 1
35 1
34 1
33 1
32 1
4 1
4
26 1
24 1
2 1
3 1
8
30 1
37 1
36 1
35 1
34 1
33 1
32 1
7 1
3
25 1
34 1
7 1
4
30 1
25 1
5 1
6 1
2
31 1
9 1
8
31 1
37 1
36 1
35 1
34 1
33 1
32 1
8 1
3
29 1
34 1
12 1
8
23 1
37 1
36 1
35 1
34 1
33 1
32 1
12 1
4
29 1
23 1
10 1
11 1
8
27 1
37 1
36 1
35 1
34 1
33 1
32 1
15 1
8
22 1
37 1
36 1
35 1
34 1
33 1
32 1
15 1
4
27 1
22 1
13 1
14 1
7
28 1
37 1
36 1
35 1
34 1
33 1
32 1
8
26 1
24 1
37 2
36 2
35 2
34 2
33 2
32 2
8
30 1
25 1
37 1
36 1
35 1
34 2
33 1
32 1
7
31 1
37 1
36 1
35 1
34 1
33 1
32 1
8
29 1
23 1
37 1
36 1
35 1
34 2
33 1
32 1
8
27 1
22 1
37 2
36 2
35 2
34 2
33 2
32 2
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
1
34 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
1
34 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
0
0
0
0
0
0
end_CG
