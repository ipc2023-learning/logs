begin_version
3
end_version
begin_metric
0
end_metric
28
begin_variable
var21
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var23
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var20
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var22
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var27
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var19
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var26
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var28
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var18
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var17
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var25
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var16
-1
5
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
end_variable
begin_variable
var15
-1
5
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
end_variable
begin_variable
var14
-1
5
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
end_variable
begin_variable
var13
-1
5
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
end_variable
begin_variable
var12
-1
5
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var10
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
0
1
0
1
1
1
0
1
1
0
0
1
1
4
2
2
3
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
7
14 2
15 0
16 4
24 0
25 0
26 0
27 0
end_goal
149
begin_operator
calibrate sat1 ins4 dir4
2
16 3
11 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat2 ins5 dir5
2
15 4
7 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat2 ins7 dir4
2
15 3
8 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir5
2
14 4
4 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat3 ins6 dir3
2
14 2
5 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat4 ins1 dir4
2
13 3
3 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat5 ins2 dir4
2
12 3
1 0
1
0 22 -1 0
0
end_operator
begin_operator
switch_off ins1 sat4
0
2
0 2 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins2 sat5
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 6 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins4 sat1
0
2
0 10 -1 0
0 11 0 1
0
end_operator
begin_operator
switch_off ins5 sat2
0
2
0 9 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins6 sat3
0
2
0 6 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_off ins7 sat2
0
2
0 9 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_on ins1 sat4
0
3
0 23 -1 1
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins2 sat5
0
3
0 22 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 21 -1 1
0 6 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins4 sat1
0
3
0 20 -1 1
0 10 0 1
0 11 -1 0
0
end_operator
begin_operator
switch_on ins5 sat2
0
3
0 19 -1 1
0 9 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins6 sat3
0
3
0 18 -1 1
0 6 0 1
0 5 -1 0
0
end_operator
begin_operator
switch_on ins7 sat2
0
3
0 17 -1 1
0 9 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins4 mod1
3
20 0
16 0
11 0
1
0 27 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins4 mod1
3
20 0
16 1
11 0
1
0 26 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins4 mod1
3
20 0
16 2
11 0
1
0 25 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins4 mod1
3
20 0
16 3
11 0
1
0 24 -1 0
0
end_operator
begin




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
check 1
36
check 0
check 0
switch 5
check 0
check 1
38
check 0
check 0
switch 5
check 0
check 1
40
check 0
check 0
check 0
check 0
check 0
switch 17
check 0
switch 15
check 0
switch 8
check 0
check 1
26
check 0
check 0
switch 8
check 0
check 1
28
check 0
check 0
switch 8
check 0
check 1
30
check 0
check 0
switch 8
check 0
check 1
32
check 0
check 0
check 0
check 0
check 0
switch 16
check 0
check 4
53
57
61
65
check 4
49
58
62
66
check 4
50
54
63
67
switch 15
check 4
51
55
59
68
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
check 1
0
check 0
check 0
check 4
52
56
60
64
switch 15
check 0
check 4
73
77
81
85
check 4
69
78
82
86
check 4
70
74
83
87
switch 14
check 4
71
75
79
88
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
2
check 0
check 0
switch 14
check 4
72
76
80
84
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
1
check 0
check 0
switch 14
check 0
check 4
93
97
101
105
check 4
89
98
102
106
switch 13
check 4
90
94
103
107
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
4
check 0
check 0
check 4
91
95
99
108
switch 13
check 4
92
96
100
104
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
3
check 0
check 0
switch 13
check 0
check 4
113
117
121
125
check 4
109
118
122
126
check 4
110
114
123
127
switch 12
check 4
111
115
119
128
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
5
check 0
check 0
check 4
112
116
120
124
switch 12
check 0
check 4
133
137
141
145
check 4
129
138
142
146
check 4
130
134
143
147
switch 10
check 4
131
135
139
148
check 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 4
132
136
140
144
switch 10
check 0
check 1
17
check 0
switch 9
check 0
check 2
18
20
check 0
switch 6
check 0
check 2
16
19
check 0
switch 2
check 0
check 1
14
check 0
switch 0
check 0
check 1
15
check 0
switch 3
check 0
check 1
7
check 0
switch 1
check 0
check 1
8
check 0
switch 4
check 0
check 1
9
check 0
switch 11
check 0
check 1
10
check 0
switch 7
check 0
check 1
11
check 0
switch 5
check 0
check 1
12
check 0
switch 8
check 0
check 1
13
check 0
check 0
end_SG
begin_DTG
1
1
15
0
1
0
8
1
1 0
end_DTG
begin_DTG
1
1
8
0
1
0
15
1
0 0
end_DTG
begin_DTG
1
1
14
0
1
0
7
1
3 0
end_DTG
begin_DTG
1
1
7
0
1
0
14
1
2 0
end_DTG
begin_DTG
1
1
9
0
1
0
16
1
6 0
end_DTG
begin_DTG
1
1
12
0
1
0
19
1
6 0
end_DTG
begin_DTG
1
1
16
0
2
0
9
1
4 0
0
12
1
5 0
end_DTG
begin_DTG
1
1
11
0
1
0
18
1
9 0
end_DTG
begin_DTG
1
1
13
0
1
0
20
1
9 0
end_DTG
begin_DTG
1
1
18
0
2
0
11
1
7 0
0
13
1
8 0
end_DTG
begin_DTG
1
1
17
0
1
0
10
1
11 0
end_DTG
begin_DTG
1
1
10
0
1
0
17
1
10 0
end_DTG
begin_DTG
4
1
133
0
2
137
0
3
141
0
4
145
0
4
0
129
0
2
138
0
3
142
0
4
146
0
4
0
130
0
1
134
0
3
143
0
4
147
0
4
0
131
0
1
135
0
2
139
0
4
148
0
4
0
132
0
1
136
0
2
140
0
3
144
0
end_DTG
begin_DTG
4
1
113
0
2
117
0
3
121
0
4
125
0
4
0
109
0
2
118
0
3
122
0
4
126
0
4
0
110
0
1
114
0
3
123
0
4
127
0
4
0
111
0
1
115
0
2
119
0
4
128
0
4
0
112
0
1
116
0
2
120
0
3
124
0
end_DTG
begin_DTG
4
1
93
0
2
97
0
3
101
0
4
105
0
4
0
89
0
2
98
0
3
102
0
4
106
0
4
0
90
0
1
94
0
3
103
0
4
107
0
4
0
91
0
1
95
0
2
99
0
4
108
0
4
0
92
0
1
96
0
2
100
0
3
104
0
end_DTG
begin_DTG
4
1
73
0
2
77
0
3
81
0
4
85
0
4
0
69
0
2
78
0
3
82
0
4
86
0
4
0
70
0
1
74
0
3
83
0
4
87
0
4
0
71
0
1
75
0
2
79
0
4
88
0
4
0
72
0
1
76
0
2
80
0
3
84
0
end_DTG
begin_DTG
4
1
53
0
2
57
0
3
61
0
4
65
0
4
0
49
0
2
58
0
3
62
0
4
66
0
4
0
50
0
1
54
0
3
63
0
4
67
0
4
0
51
0
1
55
0
2
59
0
4
68
0
4
0
52
0
1
56
0
2
60
0
3
64
0
end_DTG
begin_DTG
1
1
20
1
9 0
1
0
2
2
15 3
8 0
end_DTG
begin_DTG
1
1
19
1
6 0
1
0
4
2
14 2
5 0
end_DTG
begin_DTG
1
1
18
1
9 0
1
0
1
2
15 4
7 0
end_DTG
begin_DTG
1
1
17
1
10 0
1
0
0
2
16 3
11 0
end_DTG
begin_DTG
1
1
16
1
6 0
1
0
3
2
14 4
4 0
end_DTG
begin_DTG
1
1
15
1
0 0
1
0
6
2
12 3
1 0
end_DTG
begin_DTG
1
1
14
1
2 0
1
0
5
2
13 3
3 0
end_DTG
begin_DTG
0
7
0
24
3
20 0
16 3
11 0
0
31
3
19 0
15 3
7 0
0
32
3
17 0
15 3
8 0
0
39
3
21 0
14 3
4 0
0
40
3
18 0
14 3
5 0
0
44
3
23 0
13 3
3 0
0
48
3
22 0
12 3
1 0
end_DTG
begin_DTG
0
7
0
23
3
20 0
16 2
11 0
0
29
3
19 0
15 2
7 0
0
30
3
17 0
15 2
8 0
0
37
3
21 0
14 2
4 0
0
38
3
18 0
14 2
5 0
0
43
3
23 0
13 2
3 0
0
47
3
22 0
12 2
1 0
end_DTG
begin_DTG
0
7
0
22
3
20 0
16 1
11 0
0
27
3
19 0
15 1
7 0
0
28
3
17 0
15 1
8 0
0
35
3
21 0
14 1
4 0
0
36
3
18 0
14 1
5 0
0
42
3
23 0
13 1
3 0
0
46
3
22 0
12 1
1 0
end_DTG
begin_DTG
0
7
0
21
3
20 0
16 0
11 0
0
25
3
19 0
15 0
7 0
0
26
3
17 0
15 0
8 0
0
33
3
21 0
14 0
4 0
0
34
3
18 0
14 0
5 0
0
41
3
23 0
13 0
3 0
0
45
3
22 0
12 0
1 0
end_DTG
begin_CG
2
22 1
1 1
6
22 1
27 1
26 1
25 1
24 1
0 1
2
23 1
3 1
6
23 1
27 1
26 1
25 1
24 1
2 1
6
21 1
27 1
26 1
25 1
24 1
6 1
6
18 1
27 1
26 1
25 1
24 1
6 1
4
21 1
18 1
4 1
5 1
6
19 1
27 1
26 1
25 1
24 1
9 1
6
17 1
27 1
26 1
25 1
24 1
9 1
4
19 1
17 1
7 1
8 1
2
20 1
11 1
6
20 1
27 1
26 1
25 1
24 1
10 1
5
22 1
27 1
26 1
25 1
24 1
5
23 1
27 1
26 1
25 1
24 1
6
21 1
18 1
27 2
26 2
25 2
24 2
6
19 1
17 1
27 2
26 2
25 2
24 2
5
20 1
27 1
26 1
25 1
24 1
4
27 1
26 1
25 1
24 1
4
27 1
26 1
25 1
24 1
4
27 1
26 1
25 1
24 1
4
27 1
26 1
25 1
24 1
4
27 1
26 1
25 1
24 1
4
27 1
26 1
25 1
24 1
4
27 1
26 1
25 1
24 1
0
0
0
0
end_CG
