begin_version
3
end_version
begin_metric
0
end_metric
38
begin_variable
var41
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var37
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var32
-1
7
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
end_variable
begin_variable
var31
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
1
1
1
1
0
0
1
0
1
0
1
0
1
0
1
1
1
1
0
3
1
5
5
1
4
0
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
4
22 0
23 4
25 3
37 0
end_goal
340
begin_operator
calibrate sat1 ins12 dir5
2
25 4
15 0
1
0 33 -1 0
0
end_operator
begin_operator
calibrate sat1 ins3 dir7
2
25 6
16 0
1
0 31 -1 0
0
end_operator
begin_operator
calibrate sat1 ins9 dir3
2
25 2
17 0
1
0 26 -1 0
0
end_operator
begin_operator
calibrate sat2 ins4 dir6
2
24 5
14 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat3 ins6 dir4
2
23 3
12 0
1
0 28 -1 0
0
end_operator
begin_operator
calibrate sat4 ins5 dir4
2
22 3
10 0
1
0 29 -1 0
0
end_operator
begin_operator
calibrate sat5 ins2 dir7
2
21 6
8 0
1
0 32 -1 0
0
end_operator
begin_operator
calibrate sat6 ins1 dir4
2
20 3





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
check 0
switch 6
check 0
check 1
11
check 0
switch 0
check 0
check 1
12
check 0
switch 1
check 0
check 1
13
check 0
switch 15
check 0
check 1
14
check 0
switch 8
check 0
check 1
15
check 0
switch 16
check 0
check 1
16
check 0
switch 14
check 0
check 1
17
check 0
switch 10
check 0
check 1
18
check 0
switch 12
check 0
check 1
19
check 0
switch 2
check 0
check 1
20
check 0
switch 3
check 0
check 1
21
check 0
switch 17
check 0
check 1
22
check 0
check 0
end_SG
begin_DTG
1
1
12
0
1
0
24
1
4 0
end_DTG
begin_DTG
1
1
13
0
1
0
25
1
4 0
end_DTG
begin_DTG
1
1
20
0
1
0
32
1
4 0
end_DTG
begin_DTG
1
1
21
0
1
0
33
1
4 0
end_DTG
begin_DTG
1
1
24
0
4
0
12
1
0 0
0
13
1
1 0
0
20
1
2 0
0
21
1
3 0
end_DTG
begin_DTG
1
1
23
0
1
0
11
1
6 0
end_DTG
begin_DTG
1
1
11
0
1
0
23
1
5 0
end_DTG
begin_DTG
1
1
27
0
1
0
15
1
8 0
end_DTG
begin_DTG
1
1
15
0
1
0
27
1
7 0
end_DTG
begin_DTG
1
1
30
0
1
0
18
1
10 0
end_DTG
begin_DTG
1
1
18
0
1
0
30
1
9 0
end_DTG
begin_DTG
1
1
31
0
1
0
19
1
12 0
end_DTG
begin_DTG
1
1
19
0
1
0
31
1
11 0
end_DTG
begin_DTG
1
1
29
0
1
0
17
1
14 0
end_DTG
begin_DTG
1
1
17
0
1
0
29
1
13 0
end_DTG
begin_DTG
1
1
14
0
1
0
26
1
18 0
end_DTG
begin_DTG
1
1
16
0
1
0
28
1
18 0
end_DTG
begin_DTG
1
1
22
0
1
0
34
1
18 0
end_DTG
begin_DTG
1
1
26
0
3
0
14
1
15 0
0
16
1
16 0
0
22
1
17 0
end_DTG
begin_DTG
6
1
304
0
2
310
0
3
316
0
4
322
0
5
328
0
6
334
0
6
0
298
0
2
311
0
3
317
0
4
323
0
5
329
0
6
335
0
6
0
299
0
1
305
0
3
318
0
4
324
0
5
330
0
6
336
0
6
0
300
0
1
306
0
2
312
0
4
325
0
5
331
0
6
337
0
6
0
301
0
1
307
0
2
313
0
3
319
0
5
332
0
6
338
0
6
0
302
0
1
308
0
2
314
0
3
320
0
4
326
0
6
339
0
6
0
303
0
1
309
0
2
315
0
3
321
0
4
327
0
5
333
0
end_DTG
begin_DTG
6
1
262
0
2
268
0
3
274
0
4
280
0
5
286
0
6
292
0
6
0
256
0
2
269
0
3
275
0
4
281
0
5
287
0
6
293
0
6
0
257
0
1
263
0
3
276
0
4
282
0
5
288
0
6
294
0
6
0
258
0
1
264
0
2
270
0
4
283
0
5
289
0
6
295
0
6
0
259
0
1
265
0
2
271
0
3
277
0
5
290
0
6
296
0
6
0
260
0
1
266
0
2
272
0
3
278
0
4
284
0
6
297
0
6
0
261
0
1
267
0
2
273
0
3
279
0
4
285
0
5
291
0
end_DTG
begin_DTG
6
1
220
0
2
226
0
3
232
0
4
238
0
5
244
0
6
250
0
6
0
214
0
2
227
0
3
233
0
4
239
0
5
245
0
6
251
0
6
0
215
0
1
221
0
3
234
0
4
240
0
5
246
0
6
252
0
6
0
216
0
1
222
0
2
228
0
4
241
0
5
247
0
6
253
0
6
0
217
0
1
223
0
2
229
0
3
235
0
5
248
0
6
254
0
6
0
218
0
1
224
0
2
230
0
3
236
0
4
242
0
6
255
0
6
0
219
0
1
225
0
2
231
0
3
237
0
4
243
0
5
249
0
end_DTG
begin_DTG
6
1
178
0
2
184
0
3
190
0
4
196
0
5
202
0
6
208
0
6
0
172
0
2
185
0
3
191
0
4
197
0
5
203
0
6
209
0
6
0
173
0
1
179
0
3
192
0
4
198
0
5
204
0
6
210
0
6
0
174
0
1
180
0
2
186
0
4
199
0
5
205
0
6
211
0
6
0
175
0
1
181
0
2
187
0
3
193
0
5
206
0
6
212
0
6
0
176
0
1
182
0
2
188
0
3
194
0
4
200
0
6
213
0
6
0
177
0
1
183
0
2
189
0
3
195
0
4
201
0
5
207
0
end_DTG
begin_DTG
6
1
136
0
2
142
0
3
148
0
4
154
0
5
160
0
6
166
0
6
0
130
0
2
143
0
3
149
0
4
155
0
5
161
0
6
167
0
6
0
131
0
1
137
0
3
150
0
4
156
0
5
162
0
6
168
0
6
0
132
0
1
138
0
2
144
0
4
157
0
5
163
0
6
169
0
6
0
133
0
1
139
0
2
145
0
3
151
0
5
164
0
6
170
0
6
0
134
0
1
140
0
2
146
0
3
152
0
4
158
0
6
171
0
6
0
135
0
1
141
0
2
147
0
3
153
0
4
159
0
5
165
0
end_DTG
begin_DTG
6
1
94
0
2
100
0
3
106
0
4
112
0
5
118
0
6
124
0
6
0
88
0
2
101
0
3
107
0
4
113
0
5
119
0
6
125
0
6
0
89
0
1
95
0
3
108
0
4
114
0
5
120
0
6
126
0
6
0
90
0
1
96
0
2
102
0
4
115
0
5
121
0
6
127
0
6
0
91
0
1
97
0
2
103
0
3
109
0
5
122
0
6
128
0
6
0
92
0
1
98
0
2
104
0
3
110
0
4
116
0
6
129
0
6
0
93
0
1
99
0
2
105
0
3
111
0
4
117
0
5
123
0
end_DTG
begin_DTG
6
1
52
0
2
58
0
3
64
0
4
70
0
5
76
0
6
82
0
6
0
46
0
2
59
0
3
65
0
4
71
0
5
77
0
6
83
0
6
0
47
0
1
53
0
3
66
0
4
72
0
5
78
0
6
84
0
6
0
48
0
1
54
0
2
60
0
4
73
0
5
79
0
6
85
0
6
0
49
0
1
55
0
2
61
0
3
67
0
5
80
0
6
86
0
6
0
50
0
1
56
0
2
62
0
3
68
0
4
74
0
6
87
0
6
0
51
0
1
57
0
2
63
0
3
69
0
4
75
0
5
81
0
end_DTG
begin_DTG
1
1
34
1
18 0
1
0
2
2
25 2
17 0
end_DTG
begin_DTG
1
1
32
1
4 0
1
0
10
2
19 3
2 0
end_DTG
begin_DTG
1
1
31
1
11 0
1
0
4
2
23 3
12 0
end_DTG
begin_DTG
1
1
30
1
9 0
1
0
5
2
22 3
10 0
end_DTG
begin_DTG
1
1
29
1
13 0
1
0
3
2
24 5
14 0
end_DTG
begin_DTG
1
1
28
1
18 0
1
0
1
2
25 6
16 0
end_DTG
begin_DTG
1
1
27
1
7 0
1
0
6
2
21 6
8 0
end_DTG
begin_DTG
1
1
26
1
18 0
1
0
0
2
25 4
15 0
end_DTG
begin_DTG
1
1
25
1
4 0
1
0
9
2
19 1
1 0
end_DTG
begin_DTG
1
1
24
1
4 0
1
0
8
2
19 1
0 0
end_DTG
begin_DTG
1
1
23
1
5 0
1
0
7
2
20 3
6 0
end_DTG
begin_DTG
0
11
0
35
3
33 0
25 0
15 0
0
36
3
31 0
25 0
16 0
0
37
3
26 0
25 0
17 0
0
38
3
30 0
24 0
14 0
0
39
3
28 0
23 0
12 0
0
40
3
29 0
22 0
10 0
0
41
3
32 0
21 0
8 0
0
42
3
36 0
20 0
6 0
0
43
3
35 0
19 0
0 0
0
44
3
34 0
19 0
1 0
0
45
3
27 0
19 0
2 0
end_DTG
begin_CG
3
35 1
37 1
4 1
3
34 1
37 1
4 1
3
27 1
37 1
4 1
1
4 1
7
35 1
34 1
27 1
0 1
1 1
2 1
3 1
2
36 1
6 1
3
36 1
37 1
5 1
2
32 1
8 1
3
32 1
37 1
7 1
2
29 1
10 1
3
29 1
37 1
9 1
2
28 1
12 1
3
28 1
37 1
11 1
2
30 1
14 1
3
30 1
37 1
13 1
3
33 1
37 1
18 1
3
31 1
37 1
18 1
3
26 1
37 1
18 1
6
33 1
31 1
26 1
15 1
16 1
17 1
4
35 1
34 1
27 1
37 3
2
36 1
37 1
2
32 1
37 1
2
29 1
37 1
2
28 1
37 1
2
30 1
37 1
4
33 1
31 1
26 1
37 3
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
0
end_CG
