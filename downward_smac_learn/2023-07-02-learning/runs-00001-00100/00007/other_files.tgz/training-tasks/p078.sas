begin_version
3
end_version
begin_metric
0
end_metric
63
begin_variable
var66
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var61
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var43
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var11
-1
2
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8 5
8 0
0
160
3
40 0
28 5
9 0
0
179
3
35 0
27 5
7 0
0
196
3
48 0
26 5
3 0
0
197
3
36 0
26 5
4 0
0
218
3
44 0
25 5
0 0
0
220
3
41 0
25 5
1 0
end_DTG
begin_DTG
0
13
0
61
3
43 0
33 5
21 0
0
63
3
42 0
33 5
22 0
0
65
3
38 0
33 5
23 0
0
85
3
34 0
32 5
20 0
0
95
3
39 0
31 5
18 0
0
115
3
49 0
30 5
13 0
0
117
3
45 0
30 5
15 0
0
139
3
37 0
29 5
12 0
0
157
3
46 0
28 5
8 0
0
159
3
40 0
28 5
9 0
0
178
3
35 0
27 5
7 0
0
195
3
48 0
26 5
3 0
0
219
3
41 0
25 5
1 0
end_DTG
begin_DTG
0
15
0
59
3
42 0
33 4
22 0
0
60
3
38 0
33 4
23 0
0
84
3
34 0
32 4
20 0
0
94
3
39 0
31 4
18 0
0
112
3
49 0
30 4
13 0
0
113
3
47 0
30 4
14 0
0
114
3
45 0
30 4
15 0
0
138
3
37 0
29 4
12 0
0
155
3
46 0
28 4
8 0
0
156
3
40 0
28 4
9 0
0
177
3
35 0
27 4
7 0
0
193
3
48 0
26 4
3 0
0
194
3
36 0
26 4
4 0
0
216
3
44 0
25 4
0 0
0
217
3
41 0
25 4
1 0
end_DTG
begin_DTG
0
14
0
52
3
43 0
33 3
21 0
0
55
3
42 0
33 3
22 0
0
58
3
38 0
33 3
23 0
0
93
3
39 0
31 3
18 0
0
107
3
49 0
30 3
13 0
0
111
3
45 0
30 3
15 0
0
137
3
37 0
29 3
12 0
0
151
3
46 0
28 3
8 0
0
154
3
40 0
28 3
9 0
0
176
3
35 0
27 3
7 0
0
190
3
48 0
26 3
3 0
0
192
3
36 0
26 3
4 0
0
212
3
44 0
25 3
0 0
0
215
3
41 0
25 3
1 0
end_DTG
begin_DTG
0
13
0
51
3
43 0
33 3
21 0
0
54
3
42 0
33 3
22 0
0
57
3
38 0
33 3
23 0
0
83
3
34 0
32 3
20 0
0
92
3
39 0
31 3
18 0
0
106
3
49 0
30 3
13 0
0
110
3
45 0
30 3
15 0
0
136
3
37 0
29 3
12 0
0
150
3
46 0
28 3
8 0
0
153
3
40 0
28 3
9 0
0
175
3
35 0
27 3
7 0
0
189
3
48 0
26 3
3 0
0
214
3
41 0
25 3
1 0
end_DTG
begin_DTG
0
15
0
53
3
42 0
33 3
22 0
0
56
3
38 0
33 3
23 0
0
82
3
34 0
32 3
20 0
0
91
3
39 0
31 3
18 0
0
105
3
49 0
30 3
13 0
0
108
3
47 0
30 3
14 0
0
109
3
45 0
30 3
15 0
0
135
3
37 0
29 3
12 0
0
149
3
46 0
28 3
8 0
0
152
3
40 0
28 3
9 0
0
174
3
35 0
27 3
7 0
0
188
3
48 0
26 3
3 0
0
191
3
36 0
26 3
4 0
0
211
3
44 0
25 3
0 0
0
213
3
41 0
25 3
1 0
end_DTG
begin_DTG
0
14
0
48
3
43 0
33 1
21 0
0
49
3
42 0
33 1
22 0
0
50
3
38 0
33 1
23 0
0
90
3
39 0
31 1
18 0
0
103
3
49 0
30 1
13 0
0
104
3
45 0
30 1
15 0
0
134
3
37 0
29 1
12 0
0
147
3
46 0
28 1
8 0
0
148
3
40 0
28 1
9 0
0
173
3
35 0
27 1
7 0
0
186
3
48 0
26 1
3 0
0
187
3
36 0
26 1
4 0
0
209
3
44 0
25 1
0 0
0
210
3
41 0
25 1
1 0
end_DTG
begin_CG
12
44 1
62 1
61 1
59 1
58 1
56 1
55 1
54 1
53 1
51 1
50 1
2 1
15
41 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
2 1
4
44 1
41 1
0 1
1 1
15
48 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
5 1
12
36 1
62 1
61 1
59 1
58 1
56 1
55 1
54 1
53 1
51 1
50 1
5 1
4
48 1
36 1
3 1
4 1
2
35 1
7 1
15
35 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
6 1
15
46 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
10 1
15
40 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
10 1
4
46 1
40 1
8 1
9 1
2
37 1
12 1
15
37 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
11 1
15
49 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
16 1
7
47 1
61 1
58 1
55 1
53 1
51 1
16 1
15
45 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
16 1
6
49 1
47 1
45 1
13 1
14 1
15 1
2
39 1
18 1
15
39 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
17 1
2
34 1
20 1
10
34 1
61 1
60 1
58 1
57 1
55 1
53 1
52 1
51 1
19 1
10
43 1
62 1
60 1
59 1
57 1
56 1
54 1
52 1
50 1
24 1
15
42 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
24 1
15
38 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
24 1
6
43 1
42 1
38 1
21 1
22 1
23 1
15
44 1
41 1
62 2
61 2
60 1
59 2
58 2
57 1
56 2
55 2
54 2
53 2
52 1
51 2
50 2
15
48 1
36 1
62 2
61 2
60 1
59 2
58 2
57 1
56 2
55 2
54 2
53 2
52 1
51 2
50 2
14
35 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
15
46 1
40 1
62 2
61 2
60 2
59 2
58 2
57 2
56 2
55 2
54 2
53 2
52 2
51 2
50 2
14
37 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
16
49 1
47 1
45 1
62 2
61 3
60 2
59 2
58 3
57 2
56 2
55 3
54 2
53 3
52 2
51 3
50 2
14
39 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
9
34 1
61 1
60 1
58 1
57 1
55 1
53 1
52 1
51 1
16
43 1
42 1
38 1
62 3
61 2
60 3
59 3
58 2
57 3
56 3
55 2
54 3
53 2
52 3
51 2
50 3
8
61 1
60 1
58 1
57 1
55 1
53 1
52 1
51 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
10
62 1
61 1
59 1
58 1
56 1
55 1
54 1
53 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
8
62 1
60 1
59 1
57 1
56 1
54 1
52 1
50 1
10
62 1
61 1
59 1
58 1
56 1
55 1
54 1
53 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
5
61 1
58 1
55 1
53 1
51 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
13
62 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
