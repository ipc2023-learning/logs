begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var23
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var28
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var25
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var30
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var22
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var21
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var26
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var27
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var29
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var31
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var20
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var19
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var18
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var17
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var16
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var15
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var14
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
0
1
1
1
0
0
1
1
1
1
0
0
1
2
1
5
4
0
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
6
14 3
16 4
26 0
27 0
28 0
29 0
end_goal
206
begin_operator
calibrate sat1 ins1 dir6
2
17 5
12 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat2 ins4 dir3
2
16 2
7 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat2 ins6 dir6
2
16 5
8 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat2 ins8 dir6
2
16 5
9 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir5
2
15 4
6 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat4 ins2 dir5
2
14 4
2 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat4 ins7 dir6
2
14 5
3 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat5 ins5 dir3
2
13 2
1 0
1
0 21 -1 0
0
end_operator
begin_operator
switch_off ins1 sat1
0
2
0 11 -1 0
0 12 0 1
0
end_operator
begin_operator
switch_off ins2 sat4
0
2
0 4 -1 0
0 2 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 5 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins4 sat2
0
2
0 10 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins5 sat5
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins6 sat2
0
2
0 10 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins7 sat4
0
2
0 4 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins8 sat2
0
2
0 10 -1 0
0 9 0 1
0
end_operator
begin_operator
switch_on ins1 sat1
0
3
0 25 -1 1
0 11 0 1
0 12 -1 0
0
end_operator
begin_operator
switch_on ins2 sat4
0
3
0 24 -1 1
0 4 0 1
0 2 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 23 -1 1
0 5 0 1
0 6 -1 0
0
end_operator
begin_operator
switch_on ins4 sat2
0
3
0 22 -1 1
0 10 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins5 sat5
0
3
0 21 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins6 sat2
0
3
0 20 -1 1
0 10 0 1
0 8 -1 0
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




witch 15
check 0
check 5
121
126
131
136
141
check 5
116
127
132
137
142
check 5
117
122
133
138
143
check 5
118
123
128
139
144
switch 14
check 5
119
124
129
134
145
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
4
check 0
check 0
check 5
120
125
130
135
140
switch 14
check 0
check 5
151
156
161
166
171
check 5
146
157
162
167
172
check 5
147
152
163
168
173
check 5
148
153
158
169
174
switch 13
check 5
149
154
159
164
175
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
5
check 0
check 0
switch 13
check 5
150
155
160
165
170
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
6
check 0
check 0
switch 13
check 0
check 5
181
186
191
196
201
check 5
176
187
192
197
202
switch 11
check 5
177
182
193
198
203
check 0
check 0
switch 1
check 0
check 1
7
check 0
check 0
check 5
178
183
188
199
204
check 5
179
184
189
194
205
check 5
180
185
190
195
200
switch 11
check 0
check 1
16
check 0
switch 10
check 0
check 3
19
21
23
check 0
switch 5
check 0
check 1
18
check 0
switch 4
check 0
check 2
17
22
check 0
switch 0
check 0
check 1
20
check 0
switch 12
check 0
check 1
8
check 0
switch 2
check 0
check 1
9
check 0
switch 6
check 0
check 1
10
check 0
switch 7
check 0
check 1
11
check 0
switch 1
check 0
check 1
12
check 0
switch 8
check 0
check 1
13
check 0
switch 3
check 0
check 1
14
check 0
switch 9
check 0
check 1
15
check 0
check 0
end_SG
begin_DTG
1
1
20
0
1
0
12
1
1 0
end_DTG
begin_DTG
1
1
12
0
1
0
20
1
0 0
end_DTG
begin_DTG
1
1
9
0
1
0
17
1
4 0
end_DTG
begin_DTG
1
1
14
0
1
0
22
1
4 0
end_DTG
begin_DTG
1
1
17
0
2
0
9
1
2 0
0
14
1
3 0
end_DTG
begin_DTG
1
1
18
0
1
0
10
1
6 0
end_DTG
begin_DTG
1
1
10
0
1
0
18
1
5 0
end_DTG
begin_DTG
1
1
11
0
1
0
19
1
10 0
end_DTG
begin_DTG
1
1
13
0
1
0
21
1
10 0
end_DTG
begin_DTG
1
1
15
0
1
0
23
1
10 0
end_DTG
begin_DTG
1
1
19
0
3
0
11
1
7 0
0
13
1
8 0
0
15
1
9 0
end_DTG
begin_DTG
1
1
16
0
1
0
8
1
12 0
end_DTG
begin_DTG
1
1
8
0
1
0
16
1
11 0
end_DTG
begin_DTG
5
1
181
0
2
186
0
3
191
0
4
196
0
5
201
0
5
0
176
0
2
187
0
3
192
0
4
197
0
5
202
0
5
0
177
0
1
182
0
3
193
0
4
198
0
5
203
0
5
0
178
0
1
183
0
2
188
0
4
199
0
5
204
0
5
0
179
0
1
184
0
2
189
0
3
194
0
5
205
0
5
0
180
0
1
185
0
2
190
0
3
195
0
4
200
0
end_DTG
begin_DTG
5
1
151
0
2
156
0
3
161
0
4
166
0
5
171
0
5
0
146
0
2
157
0
3
162
0
4
167
0
5
172
0
5
0
147
0
1
152
0
3
163
0
4
168
0
5
173
0
5
0
148
0
1
153
0
2
158
0
4
169
0
5
174
0
5
0
149
0
1
154
0
2
159
0
3
164
0
5
175
0
5
0
150
0
1
155
0
2
160
0
3
165
0
4
170
0
end_DTG
begin_DTG
5
1
121
0
2
126
0
3
131
0
4
136
0
5
141
0
5
0
116
0
2
127
0
3
132
0
4
137
0
5
142
0
5
0
117
0
1
122
0
3
133
0
4
138
0
5
143
0
5
0
118
0
1
123
0
2
128
0
4
139
0
5
144
0
5
0
119
0
1
124
0
2
129
0
3
134
0
5
145
0
5
0
120
0
1
125
0
2
130
0
3
135
0
4
140
0
end_DTG
begin_DTG
5
1
91
0
2
96
0
3
101
0
4
106
0
5
111
0
5
0
86
0
2
97
0
3
102
0
4
107
0
5
112
0
5
0
87
0
1
92
0
3
103
0
4
108
0
5
113
0
5
0
88
0
1
93
0
2
98
0
4
109
0
5
114
0
5
0
89
0
1
94
0
2
99
0
3
104
0
5
115
0
5
0
90
0
1
95
0
2
100
0
3
105
0
4
110
0
end_DTG
begin_DTG
5
1
61
0
2
66
0
3
71
0
4
76
0
5
81
0
5
0
56
0
2
67
0
3
72
0
4
77
0
5
82
0
5
0
57
0
1
62
0
3
73
0
4
78
0
5
83
0
5
0
58
0
1
63
0
2
68
0
4
79
0
5
84
0
5
0
59
0
1
64
0
2
69
0
3
74
0
5
85
0
5
0
60
0
1
65
0
2
70
0
3
75
0
4
80
0
end_DTG
begin_DTG
1
1
23
1
10 0
1
0
3
2
16 5
9 0
end_DTG
begin_DTG
1
1
22
1
4 0
1
0
6
2
14 5
3 0
end_DTG
begin_DTG
1
1
21
1
10 0
1
0
2
2
16 5
8 0
end_DTG
begin_DTG
1
1
20
1
0 0
1
0
7
2
13 2
1 0
end_DTG
begin_DTG
1
1
19
1
10 0
1
0
1
2
16 2
7 0
end_DTG
begin_DTG
1
1
18
1
5 0
1
0
4
2
15 4
6 0
end_DTG
begin_DTG
1
1
17
1
4 0
1
0
5
2
14 4
2 0
end_DTG
begin_DTG
1
1
16
1
11 0
1
0
0
2
17 5
12 0
end_DTG
begin_DTG
0
8
0
27
3
25 0
17 4
12 0
0
37
3
22 0
16 4
7 0
0
38
3
20 0
16 4
8 0
0
39
3
18 0
16 4
9 0
0
43
3
23 0
15 4
6 0
0
50
3
24 0
14 4
2 0
0
51
3
19 0
14 4
3 0
0
55
3
21 0
13 4
1 0
end_DTG
begin_DTG
0
8
0
26
3
25 0
17 3
12 0
0
34
3
22 0
16 3
7 0
0
35
3
20 0
16 3
8 0
0
36
3
18 0
16 3
9 0
0
42
3
23 0
15 3
6 0
0
48
3
24 0
14 3
2 0
0
49
3
19 0
14 3
3 0
0
54
3
21 0
13 3
1 0
end_DTG
begin_DTG
0
8
0
25
3
25 0
17 1
12 0
0
31
3
22 0
16 1
7 0
0
32
3
20 0
16 1
8 0
0
33
3
18 0
16 1
9 0
0
41
3
23 0
15 1
6 0
0
46
3
24 0
14 1
2 0
0
47
3
19 0
14 1
3 0
0
53
3
21 0
13 1
1 0
end_DTG
begin_DTG
0
8
0
24
3
25 0
17 0
12 0
0
28
3
22 0
16 0
7 0
0
29
3
20 0
16 0
8 0
0
30
3
18 0
16 0
9 0
0
40
3
23 0
15 0
6 0
0
44
3
24 0
14 0
2 0
0
45
3
19 0
14 0
3 0
0
52
3
21 0
13 0
1 0
end_DTG
begin_CG
2
21 1
1 1
6
21 1
29 1
28 1
27 1
26 1
0 1
6
24 1
29 1
28 1
27 1
26 1
4 1
6
19 1
29 1
28 1
27 1
26 1
4 1
4
24 1
19 1
2 1
3 1
2
23 1
6 1
6
23 1
29 1
28 1
27 1
26 1
5 1
6
22 1
29 1
28 1
27 1
26 1
10 1
6
20 1
29 1
28 1
27 1
26 1
10 1
6
18 1
29 1
28 1
27 1
26 1
10 1
6
22 1
20 1
18 1
7 1
8 1
9 1
2
25 1
12 1
6
25 1
29 1
28 1
27 1
26 1
11 1
5
21 1
29 1
28 1
27 1
26 1
6
24 1
19 1
29 2
28 2
27 2
26 2
5
23 1
29 1
28 1
27 1
26 1
7
22 1
20 1
18 1
29 3
28 3
27 3
26 3
5
25 1
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
4
29 1
28 1
27 1
26 1
0
0
0
0
end_CG
