begin_version
3
end_version
begin_metric
0
end_metric
49
begin_variable
var42
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var37
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var29
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var25
-1
2
Atom have_image(dir7, mod1)
NegatedAtom have_image(dir7, mod1)
end_variable
begin_variable
var24
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var23
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
e




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
6
235
0
7
242
0
7
0
193
0
1
200
0
2
207
0
3
214
0
4
221
0
5
228
0
7
243
0
7
0
194
0
1
201
0
2
208
0
3
215
0
4
222
0
5
229
0
6
236
0
end_DTG
begin_DTG
7
1
139
0
2
146
0
3
153
0
4
160
0
5
167
0
6
174
0
7
181
0
7
0
132
0
2
147
0
3
154
0
4
161
0
5
168
0
6
175
0
7
182
0
7
0
133
0
1
140
0
3
155
0
4
162
0
5
169
0
6
176
0
7
183
0
7
0
134
0
1
141
0
2
148
0
4
163
0
5
170
0
6
177
0
7
184
0
7
0
135
0
1
142
0
2
149
0
3
156
0
5
171
0
6
178
0
7
185
0
7
0
136
0
1
143
0
2
150
0
3
157
0
4
164
0
6
179
0
7
186
0
7
0
137
0
1
144
0
2
151
0
3
158
0
4
165
0
5
172
0
7
187
0
7
0
138
0
1
145
0
2
152
0
3
159
0
4
166
0
5
173
0
6
180
0
end_DTG
begin_DTG
1
1
38
1
14 0
1
0
5
2
25 4
13 0
end_DTG
begin_DTG
1
1
37
1
19 0
1
0
3
2
26 5
18 0
end_DTG
begin_DTG
1
1
36
1
9 0
1
0
8
2
23 5
8 0
end_DTG
begin_DTG
1
1
35
1
10 0
1
0
6
2
24 4
11 0
end_DTG
begin_DTG
1
1
34
1
14 0
1
0
4
2
25 1
12 0
end_DTG
begin_DTG
1
1
33
1
2 0
1
0
11
2
21 5
3 0
end_DTG
begin_DTG
1
1
32
1
0 0
1
0
12
2
20 6
1 0
end_DTG
begin_DTG
1
1
31
1
6 0
1
0
10
2
22 2
5 0
end_DTG
begin_DTG
1
1
30
1
6 0
1
0
9
2
22 7
4 0
end_DTG
begin_DTG
1
1
29
1
9 0
1
0
7
2
23 7
7 0
end_DTG
begin_DTG
1
1
28
1
19 0
1
0
2
2
26 0
17 0
end_DTG
begin_DTG
1
1
27
1
19 0
1
0
1
2
26 2
16 0
end_DTG
begin_DTG
1
1
26
1
19 0
1
0
0
2
26 0
15 0
end_DTG
begin_DTG
0
9
0
67
3
39 0
26 6
15 0
0
68
3
37 0
26 6
17 0
0
69
3
28 0
26 6
18 0
0
86
3
31 0
25 6
12 0
0
87
3
27 0
25 6
13 0
0
92
3
30 0
24 6
11 0
0
109
3
36 0
23 6
7 0
0
110
3
29 0
23 6
8 0
0
123
3
35 0
22 6
4 0
end_DTG
begin_DTG
0
12
0
61
3
39 0
26 5
15 0
0
62
3
38 0
26 5
16 0
0
64
3
37 0
26 5
17 0
0
66
3
28 0
26 5
18 0
0
83
3
31 0
25 5
12 0
0
85
3
27 0
25 5
13 0
0
106
3
36 0
23 5
7 0
0
108
3
29 0
23 5
8 0
0
121
3
35 0
22 5
4 0
0
122
3
34 0
22 5
5 0
0
127
3
32 0
21 5
3 0
0
131
3
33 0
20 5
1 0
end_DTG
begin_DTG
0
9
0
60
3
39 0
26 5
15 0
0
63
3
37 0
26 5
17 0
0
65
3
28 0
26 5
18 0
0
82
3
31 0
25 5
12 0
0
84
3
27 0
25 5
13 0
0
91
3
30 0
24 5
11 0
0
105
3
36 0
23 5
7 0
0
107
3
29 0
23 5
8 0
0
120
3
35 0
22 5
4 0
end_DTG
begin_DTG
0
12
0
54
3
39 0
26 4
15 0
0
55
3
38 0
26 4
16 0
0
57
3
37 0
26 4
17 0
0
59
3
28 0
26 4
18 0
0
79
3
31 0
25 4
12 0
0
81
3
27 0
25 4
13 0
0
102
3
36 0
23 4
7 0
0
104
3
29 0
23 4
8 0
0
118
3
35 0
22 4
4 0
0
119
3
34 0
22 4
5 0
0
126
3
32 0
21 4
3 0
0
130
3
33 0
20 4
1 0
end_DTG
begin_DTG
0
9
0
53
3
39 0
26 4
15 0
0
56
3
37 0
26 4
17 0
0
58
3
28 0
26 4
18 0
0
78
3
31 0
25 4
12 0
0
80
3
27 0
25 4
13 0
0
90
3
30 0
24 4
11 0
0
101
3
36 0
23 4
7 0
0
103
3
29 0
23 4
8 0
0
117
3
35 0
22 4
4 0
end_DTG
begin_DTG
0
9
0
50
3
39 0
26 3
15 0
0
51
3
37 0
26 3
17 0
0
52
3
28 0
26 3
18 0
0
76
3
31 0
25 3
12 0
0
77
3
27 0
25 3
13 0
0
89
3
30 0
24 3
11 0
0
99
3
36 0
23 3
7 0
0
100
3
29 0
23 3
8 0
0
116
3
35 0
22 3
4 0
end_DTG
begin_DTG
0
12
0
44
3
39 0
26 2
15 0
0
45
3
38 0
26 2
16 0
0
47
3
37 0
26 2
17 0
0
49
3
28 0
26 2
18 0
0
73
3
31 0
25 2
12 0
0
75
3
27 0
25 2
13 0
0
96
3
36 0
23 2
7 0
0
98
3
29 0
23 2
8 0
0
114
3
35 0
22 2
4 0
0
115
3
34 0
22 2
5 0
0
125
3
32 0
21 2
3 0
0
129
3
33 0
20 2
1 0
end_DTG
begin_DTG
0
9
0
43
3
39 0
26 2
15 0
0
46
3
37 0
26 2
17 0
0
48
3
28 0
26 2
18 0
0
72
3
31 0
25 2
12 0
0
74
3
27 0
25 2
13 0
0
88
3
30 0
24 2
11 0
0
95
3
36 0
23 2
7 0
0
97
3
29 0
23 2
8 0
0
113
3
35 0
22 2
4 0
end_DTG
begin_DTG
0
12
0
39
3
39 0
26 1
15 0
0
40
3
38 0
26 1
16 0
0
41
3
37 0
26 1
17 0
0
42
3
28 0
26 1
18 0
0
70
3
31 0
25 1
12 0
0
71
3
27 0
25 1
13 0
0
93
3
36 0
23 1
7 0
0
94
3
29 0
23 1
8 0
0
111
3
35 0
22 1
4 0
0
112
3
34 0
22 1
5 0
0
124
3
32 0
21 1
3 0
0
128
3
33 0
20 1
1 0
end_DTG
begin_CG
2
33 1
1 1
6
33 1
48 1
46 1
43 1
41 1
0 1
2
32 1
3 1
6
32 1
48 1
46 1
43 1
41 1
2 1
11
35 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
6 1
6
34 1
48 1
46 1
43 1
41 1
6 1
4
35 1
34 1
4 1
5 1
11
36 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
9 1
11
29 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
9 1
4
36 1
29 1
7 1
8 1
2
30 1
11 1
7
30 1
47 1
45 1
44 1
42 1
40 1
10 1
11
31 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
14 1
11
27 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
14 1
4
31 1
27 1
12 1
13 1
11
39 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
19 1
6
38 1
48 1
46 1
43 1
41 1
19 1
11
37 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
19 1
11
28 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
19 1
8
39 1
38 1
37 1
28 1
15 1
16 1
17 1
18 1
5
33 1
48 1
46 1
43 1
41 1
5
32 1
48 1
46 1
43 1
41 1
11
35 1
34 1
48 2
47 1
46 2
45 1
44 1
43 2
42 1
41 2
40 1
11
36 1
29 1
48 2
47 2
46 2
45 2
44 2
43 2
42 2
41 2
40 2
6
30 1
47 1
45 1
44 1
42 1
40 1
11
31 1
27 1
48 2
47 2
46 2
45 2
44 2
43 2
42 2
41 2
40 2
13
39 1
38 1
37 1
28 1
48 4
47 3
46 4
45 3
44 3
43 4
42 3
41 4
40 3
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
5
47 1
45 1
44 1
42 1
40 1
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
4
48 1
46 1
43 1
41 1
4
48 1
46 1
43 1
41 1
4
48 1
46 1
43 1
41 1
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
4
48 1
46 1
43 1
41 1
9
48 1
47 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
0
0
0
0
0
0
0
0
0
end_CG
