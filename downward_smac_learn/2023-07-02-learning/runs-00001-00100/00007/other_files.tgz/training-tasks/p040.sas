begin_version
3
end_version
begin_metric
0
end_metric
40
begin_variable
var30
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var31
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var34
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var29
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var32
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var36
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var28
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var27
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var35
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var33
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var26
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var25
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var24
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var23
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var22
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var21
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var19
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var17
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var15
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var20
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var18
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
begin_variable
var16
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir3, mod2)
NegatedAtom have_image(dir3, mod2)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
begin_variable
var10
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(dir1, mod2)
end_variable
0
begin_state
0
1
1
1
1
0
1
1
0
0
1
1
1
0
4
3
4
0
2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
15
14 4
15 1
18 1
23 0
24 0
25 0
26 0
27 0
28 0
34 0
35 0
36 0
37 0
38 0
39 0
end_goal
237
begin_operator
calibrate sat1 ins3 dir3
2
18 2
11 0
1
0 31 -1 0
0
end_operator
begin_operator
calibrate sat1 ins8 dir5
2
18 4
12 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat2 ins5 dir1
2
17 0
10 0
1
0 29 -1 0
0
end_operator
begin_operator
calibrate sat3 ins2 dir4
2
16 3
6 0
1
0 32 -1 0
0
end_operator
begin_operator
calibrate sat3 ins6 dir4
2
16 3
7 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat4 ins4 dir5
2
15 4
2 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat4 ins7 dir4
2
15 3
3 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat4 ins9 dir5
2
15 4
4 0
1
0 19 -1 0
0
end_operat




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




4
check 0
check 1
17
check 0
check 0
end_SG
begin_DTG
1
1
18
0
1
0
9
1
1 0
end_DTG
begin_DTG
1
1
9
0
1
0
18
1
0 0
end_DTG
begin_DTG
1
1
12
0
1
0
21
1
5 0
end_DTG
begin_DTG
1
1
15
0
1
0
24
1
5 0
end_DTG
begin_DTG
1
1
17
0
1
0
26
1
5 0
end_DTG
begin_DTG
1
1
21
0
3
0
12
1
2 0
0
15
1
3 0
0
17
1
4 0
end_DTG
begin_DTG
1
1
10
0
1
0
19
1
8 0
end_DTG
begin_DTG
1
1
14
0
1
0
23
1
8 0
end_DTG
begin_DTG
1
1
19
0
2
0
10
1
6 0
0
14
1
7 0
end_DTG
begin_DTG
1
1
22
0
1
0
13
1
10 0
end_DTG
begin_DTG
1
1
13
0
1
0
22
1
9 0
end_DTG
begin_DTG
1
1
11
0
1
0
20
1
13 0
end_DTG
begin_DTG
1
1
16
0
1
0
25
1
13 0
end_DTG
begin_DTG
1
1
20
0
2
0
11
1
11 0
0
16
1
12 0
end_DTG
begin_DTG
5
1
212
0
2
217
0
3
222
0
4
227
0
5
232
0
5
0
207
0
2
218
0
3
223
0
4
228
0
5
233
0
5
0
208
0
1
213
0
3
224
0
4
229
0
5
234
0
5
0
209
0
1
214
0
2
219
0
4
230
0
5
235
0
5
0
210
0
1
215
0
2
220
0
3
225
0
5
236
0
5
0
211
0
1
216
0
2
221
0
3
226
0
4
231
0
end_DTG
begin_DTG
5
1
182
0
2
187
0
3
192
0
4
197
0
5
202
0
5
0
177
0
2
188
0
3
193
0
4
198
0
5
203
0
5
0
178
0
1
183
0
3
194
0
4
199
0
5
204
0
5
0
179
0
1
184
0
2
189
0
4
200
0
5
205
0
5
0
180
0
1
185
0
2
190
0
3
195
0
5
206
0
5
0
181
0
1
186
0
2
191
0
3
196
0
4
201
0
end_DTG
begin_DTG
5
1
152
0
2
157
0
3
162
0
4
167
0
5
172
0
5
0
147
0
2
158
0
3
163
0
4
168
0
5
173
0
5
0
148
0
1
153
0
3
164
0
4
169
0
5
174
0
5
0
149
0
1
154
0
2
159
0
4
170
0
5
175
0
5
0
150
0
1
155
0
2
160
0
3
165
0
5
176
0
5
0
151
0
1
156
0
2
161
0
3
166
0
4
171
0
end_DTG
begin_DTG
5
1
122
0
2
127
0
3
132
0
4
137
0
5
142
0
5
0
117
0
2
128
0
3
133
0
4
138
0
5
143
0
5
0
118
0
1
123
0
3
134
0
4
139
0
5
144
0
5
0
119
0
1
124
0
2
129
0
4
140
0
5
145
0
5
0
120
0
1
125
0
2
130
0
3
135
0
5
146
0
5
0
121
0
1
126
0
2
131
0
3
136
0
4
141
0
end_DTG
begin_DTG
5
1
92
0
2
97
0
3
102
0
4
107
0
5
112
0
5
0
87
0
2
98
0
3
103
0
4
108
0
5
113
0
5
0
88
0
1
93
0
3
104
0
4
109
0
5
114
0
5
0
89
0
1
94
0
2
99
0
4
110
0
5
115
0
5
0
90
0
1
95
0
2
100
0
3
105
0
5
116
0
5
0
91
0
1
96
0
2
101
0
3
106
0
4
111
0
end_DTG
begin_DTG
1
1
26
1
5 0
1
0
7
2
15 4
4 0
end_DTG
begin_DTG
1
1
25
1
13 0
1
0
1
2
18 4
12 0
end_DTG
begin_DTG
1
1
24
1
5 0
1
0
6
2
15 3
3 0
end_DTG
begin_DTG
1
1
23
1
8 0
1
0
4
2
16 3
7 0
end_DTG
begin_DTG
0
4
0
38
3
20 0
18 5
12 0
0
56
3
22 0
16 5
7 0
0
78
3
21 0
15 5
3 0
0
79
3
19 0
15 5
4 0
end_DTG
begin_DTG
0
4
0
36
3
20 0
18 4
12 0
0
54
3
22 0
16 4
7 0
0
74
3
21 0
15 4
3 0
0
75
3
19 0
15 4
4 0
end_DTG
begin_DTG
0
4
0
34
3
20 0
18 3
12 0
0
52
3
22 0
16 3
7 0
0
70
3
21 0
15 3
3 0
0
71
3
19 0
15 3
4 0
end_DTG
begin_DTG
0
4
0
32
3
20 0
18 2
12 0
0
50
3
22 0
16 2
7 0
0
66
3
21 0
15 2
3 0
0
67
3
19 0
15 2
4 0
end_DTG
begin_DTG
0
4
0
30
3
20 0
18 1
12 0
0
48
3
22 0
16 1
7 0
0
62
3
21 0
15 1
3 0
0
63
3
19 0
15 1
4 0
end_DTG
begin_DTG
0
4
0
28
3
20 0
18 0
12 0
0
46
3
22 0
16 0
7 0
0
58
3
21 0
15 0
3 0
0
59
3
19 0
15 0
4 0
end_DTG
begin_DTG
1
1
22
1
9 0
1
0
2
2
17 0
10 0
end_DTG
begin_DTG
1
1
21
1
5 0
1
0
5
2
15 4
2 0
end_DTG
begin_DTG
1
1
20
1
13 0
1
0
0
2
18 2
11 0
end_DTG
begin_DTG
1
1
19
1
8 0
1
0
3
2
16 3
6 0
end_DTG
begin_DTG
1
1
18
1
0 0
1
0
8
2
14 1
1 0
end_DTG
begin_DTG
0
6
0
37
3
31 0
18 5
11 0
0
44
3
29 0
17 5
10 0
0
55
3
32 0
16 5
6 0
0
77
3
30 0
15 5
2 0
0
80
3
19 0
15 5
4 0
0
86
3
33 0
14 5
1 0
end_DTG
begin_DTG
0
6
0
35
3
31 0
18 4
11 0
0
43
3
29 0
17 4
10 0
0
53
3
32 0
16 4
6 0
0
73
3
30 0
15 4
2 0
0
76
3
19 0
15 4
4 0
0
85
3
33 0
14 4
1 0
end_DTG
begin_DTG
0
6
0
33
3
31 0
18 3
11 0
0
42
3
29 0
17 3
10 0
0
51
3
32 0
16 3
6 0
0
69
3
30 0
15 3
2 0
0
72
3
19 0
15 3
4 0
0
84
3
33 0
14 3
1 0
end_DTG
begin_DTG
0
6
0
31
3
31 0
18 2
11 0
0
41
3
29 0
17 2
10 0
0
49
3
32 0
16 2
6 0
0
65
3
30 0
15 2
2 0
0
68
3
19 0
15 2
4 0
0
83
3
33 0
14 2
1 0
end_DTG
begin_DTG
0
6
0
29
3
31 0
18 1
11 0
0
40
3
29 0
17 1
10 0
0
47
3
32 0
16 1
6 0
0
61
3
30 0
15 1
2 0
0
64
3
19 0
15 1
4 0
0
82
3
33 0
14 1
1 0
end_DTG
begin_DTG
0
6
0
27
3
31 0
18 0
11 0
0
39
3
29 0
17 0
10 0
0
45
3
32 0
16 0
6 0
0
57
3
30 0
15 0
2 0
0
60
3
19 0
15 0
4 0
0
81
3
33 0
14 0
1 0
end_DTG
begin_CG
2
33 1
1 1
8
33 1
39 1
38 1
37 1
36 1
35 1
34 1
0 1
8
30 1
39 1
38 1
37 1
36 1
35 1
34 1
5 1
8
21 1
28 1
27 1
26 1
25 1
24 1
23 1
5 1
14
19 1
28 1
39 1
27 1
38 1
26 1
37 1
25 1
36 1
24 1
35 1
23 1
34 1
5 1
6
30 1
21 1
19 1
2 1
3 1
4 1
8
32 1
39 1
38 1
37 1
36 1
35 1
34 1
8 1
8
22 1
28 1
27 1
26 1
25 1
24 1
23 1
8 1
4
32 1
22 1
6 1
7 1
2
29 1
10 1
8
29 1
39 1
38 1
37 1
36 1
35 1
34 1
9 1
8
31 1
39 1
38 1
37 1
36 1
35 1
34 1
13 1
8
20 1
28 1
27 1
26 1
25 1
24 1
23 1
13 1
4
31 1
20 1
11 1
12 1
7
33 1
39 1
38 1
37 1
36 1
35 1
34 1
15
30 1
21 1
19 1
28 2
39 2
27 2
38 2
26 2
37 2
25 2
36 2
24 2
35 2
23 2
34 2
14
32 1
22 1
28 1
39 1
27 1
38 1
26 1
37 1
25 1
36 1
24 1
35 1
23 1
34 1
7
29 1
39 1
38 1
37 1
36 1
35 1
34 1
14
31 1
20 1
28 1
39 1
27 1
38 1
26 1
37 1
25 1
36 1
24 1
35 1
23 1
34 1
12
28 1
39 1
27 1
38 1
26 1
37 1
25 1
36 1
24 1
35 1
23 1
34 1
6
28 1
27 1
26 1
25 1
24 1
23 1
6
28 1
27 1
26 1
25 1
24 1
23 1
6
28 1
27 1
26 1
25 1
24 1
23 1
0
0
0
0
0
0
6
39 1
38 1
37 1
36 1
35 1
34 1
6
39 1
38 1
37 1
36 1
35 1
34 1
6
39 1
38 1
37 1
36 1
35 1
34 1
6
39 1
38 1
37 1
36 1
35 1
34 1
6
39 1
38 1
37 1
36 1
35 1
34 1
0
0
0
0
0
0
end_CG
