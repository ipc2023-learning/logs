begin_version
3
end_version
begin_metric
0
end_metric
58
begin_variable
var64
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var52
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var13
-1
2
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5
0
5
303
0
7
320
0
8
328
0
8
0
264
0
1
272
0
2
280
0
3
288
0
4
296
0
5
304
0
6
312
0
8
329
0
8
0
265
0
1
273
0
2
281
0
3
289
0
4
297
0
5
305
0
6
313
0
7
321
0
end_DTG
begin_DTG
8
1
194
0
2
202
0
3
210
0
4
218
0
5
226
0
6
234
0
7
242
0
8
250
0
8
0
186
0
2
203
0
3
211
0
4
219
0
5
227
0
6
235
0
7
243
0
8
251
0
8
0
187
0
1
195
0
3
212
0
4
220
0
5
228
0
6
236
0
7
244
0
8
252
0
8
0
188
0
1
196
0
2
204
0
4
221
0
5
229
0
6
237
0
7
245
0
8
253
0
8
0
189
0
1
197
0
2
205
0
3
213
0
5
230
0
6
238
0
7
246
0
8
254
0
8
0
190
0
1
198
0
2
206
0
3
214
0
4
222
0
6
239
0
7
247
0
8
255
0
8
0
191
0
1
199
0
2
207
0
3
215
0
4
223
0
5
231
0
7
248
0
8
256
0
8
0
192
0
1
200
0
2
208
0
3
216
0
4
224
0
5
232
0
6
240
0
8
257
0
8
0
193
0
1
201
0
2
209
0
3
217
0
4
225
0
5
233
0
6
241
0
7
249
0
end_DTG
begin_DTG
8
1
122
0
2
130
0
3
138
0
4
146
0
5
154
0
6
162
0
7
170
0
8
178
0
8
0
114
0
2
131
0
3
139
0
4
147
0
5
155
0
6
163
0
7
171
0
8
179
0
8
0
115
0
1
123
0
3
140
0
4
148
0
5
156
0
6
164
0
7
172
0
8
180
0
8
0
116
0
1
124
0
2
132
0
4
149
0
5
157
0
6
165
0
7
173
0
8
181
0
8
0
117
0
1
125
0
2
133
0
3
141
0
5
158
0
6
166
0
7
174
0
8
182
0
8
0
118
0
1
126
0
2
134
0
3
142
0
4
150
0
6
167
0
7
175
0
8
183
0
8
0
119
0
1
127
0
2
135
0
3
143
0
4
151
0
5
159
0
7
176
0
8
184
0
8
0
120
0
1
128
0
2
136
0
3
144
0
4
152
0
5
160
0
6
168
0
8
185
0
8
0
121
0
1
129
0
2
137
0
3
145
0
4
153
0
5
161
0
6
169
0
7
177
0
end_DTG
begin_DTG
1
1
50
1
12 0
1
0
9
2
29 7
11 0
end_DTG
begin_DTG
1
1
49
1
18 0
1
0
4
2
32 5
19 0
end_DTG
begin_DTG
1
1
48
1
16 0
1
0
5
2
31 8
17 0
end_DTG
begin_DTG
1
1
47
1
15 0
1
0
7
2
30 5
14 0
end_DTG
begin_DTG
1
1
46
1
25 0
1
0
2
2
34 1
24 0
end_DTG
begin_DTG
1
1
45
1
9 0
1
0
13
2
28 7
8 0
end_DTG
begin_DTG
1
1
44
1
3 0
1
0
14
2
27 1
4 0
end_DTG
begin_DTG
1
1
43
1
2 0
1
0
16
2
26 6
1 0
end_DTG
begin_DTG
1
1
42
1
25 0
1
0
1
2
34 8
23 0
end_DTG
begin_DTG
1
1
41
1
9 0
1
0
12
2
28 2
7 0
end_DTG
begin_DTG
1
1
40
1
25 0
1
0
0
2
34 7
22 0
end_DTG
begin_DTG
1
1
39
1
9 0
1
0
11
2
28 6
6 0
end_DTG
begin_DTG
1
1
38
1
12 0
1
0
8
2
29 1
10 0
end_DTG
begin_DTG
1
1
37
1
15 0
1
0
6
2
30 8
13 0
end_DTG
begin_DTG
1
1
36
1
2 0
1
0
15
2
26 8
0 0
end_DTG
begin_DTG
1
1
35
1
9 0
1
0
10
2
28 0
5 0
end_DTG
begin_DTG
0
11
0
58
3
39 0
34 7
24 0
0
65
3
37 0
31 7
17 0
0
75
3
48 0
30 7
13 0
0
77
3
38 0
30 7
14 0
0
82
3
47 0
29 7
10 0
0
96
3
50 0
28 7
5 0
0
97
3
44 0
28 7
7 0
0
99
3
40 0
28 7
8 0
0
103
3
41 0
27 7
4 0
0
111
3
49 0
26 7
0 0
0
113
3
42 0
26 7
1 0
end_DTG
begin_DTG
0
11
0
54
3
39 0
34 2
24 0
0
64
3
37 0
31 2
17 0
0
70
3
48 0
30 2
13 0
0
71
3
38 0
30 2
14 0
0
80
3
47 0
29 2
10 0
0
89
3
50 0
28 2
5 0
0
90
3
44 0
28 2
7 0
0
91
3
40 0
28 2
8 0
0
101
3
41 0
27 2
4 0
0
107
3
49 0
26 2
0 0
0
108
3
42 0
26 2
1 0
end_DTG
begin_DTG
0
11
0
53
3
39 0
34 1
24 0
0
63
3
37 0
31 1
17 0
0
67
3
48 0
30 1
13 0
0
69
3
38 0
30 1
14 0
0
78
3
47 0
29 1
10 0
0
85
3
50 0
28 1
5 0
0
86
3
44 0
28 1
7 0
0
88
3
40 0
28 1
8 0
0
100
3
41 0
27 1
4 0
0
104
3
49 0
26 1
0 0
0
106
3
42 0
26 1
1 0
end_DTG
begin_DTG
1
1
34
1
20 0
1
0
3
2
33 6
21 0
end_DTG
begin_DTG
0
9
0
56
3
45 0
34 7
22 0
0
57
3
39 0
34 7
24 0
0
61
3
54 0
33 7
21 0
0
74
3
48 0
30 7
13 0
0
76
3
38 0
30 7
14 0
0
83
3
35 0
29 7
11 0
0
95
3
50 0
28 7
5 0
0
98
3
40 0
28 7
8 0
0
112
3
42 0
26 7
1 0
end_DTG
begin_DTG
0
12
0
55
3
43 0
34 6
23 0
0
60
3
54 0
33 6
21 0
0
62
3
36 0
32 6
19 0
0
72
3
48 0
30 6
13 0
0
73
3
38 0
30 6
14 0
0
81
3
47 0
29 6
10 0
0
92
3
50 0
28 6
5 0
0
93
3
46 0
28 6
6 0
0
94
3
44 0
28 6
7 0
0
102
3
41 0
27 6
4 0
0
109
3
49 0
26 6
0 0
0
110
3
42 0
26 6
1 0
end_DTG
begin_DTG
0
9
0
51
3
45 0
34 1
22 0
0
52
3
39 0
34 1
24 0
0
59
3
54 0
33 1
21 0
0
66
3
48 0
30 1
13 0
0
68
3
38 0
30 1
14 0
0
79
3
35 0
29 1
11 0
0
84
3
50 0
28 1
5 0
0
87
3
40 0
28 1
8 0
0
105
3
42 0
26 1
1 0
end_DTG
begin_CG
6
49 1
53 1
52 1
56 1
51 1
2 1
8
42 1
57 1
53 1
52 1
56 1
55 1
51 1
2 1
4
49 1
42 1
0 1
1 1
2
41 1
4 1
6
41 1
53 1
52 1
56 1
51 1
3 1
8
50 1
57 1
53 1
52 1
56 1
55 1
51 1
9 1
3
46 1
56 1
9 1
6
44 1
53 1
52 1
56 1
51 1
9 1
7
40 1
57 1
53 1
52 1
55 1
51 1
9 1
8
50 1
46 1
44 1
40 1
5 1
6 1
7 1
8 1
6
47 1
53 1
52 1
56 1
51 1
12 1
4
35 1
57 1
55 1
12 1
4
47 1
35 1
10 1
11 1
8
48 1
57 1
53 1
52 1
56 1
55 1
51 1
15 1
8
38 1
57 1
53 1
52 1
56 1
55 1
51 1
15 1
4
48 1
38 1
13 1
14 1
2
37 1
17 1
5
37 1
53 1
52 1
51 1
16 1
2
36 1
19 1
3
36 1
56 1
18 1
2
54 1
21 1
5
54 1
57 1
56 1
55 1
20 1
4
45 1
57 1
55 1
25 1
3
43 1
56 1
25 1
7
39 1
57 1
53 1
52 1
55 1
51 1
25 1
6
45 1
43 1
39 1
22 1
23 1
24 1
8
49 1
42 1
57 1
53 2
52 2
56 2
55 1
51 2
5
41 1
53 1
52 1
56 1
51 1
10
50 1
46 1
44 1
40 1
57 2
53 3
52 3
56 3
55 2
51 3
8
47 1
35 1
57 1
53 1
52 1
56 1
55 1
51 1
8
48 1
38 1
57 2
53 2
52 2
56 2
55 2
51 2
4
37 1
53 1
52 1
51 1
2
36 1
56 1
4
54 1
57 1
56 1
55 1
9
45 1
43 1
39 1
57 2
53 1
52 1
56 1
55 2
51 1
2
57 1
55 1
1
56 1
3
53 1
52 1
51 1
6
57 1
53 1
52 1
56 1
55 1
51 1
5
57 1
53 1
52 1
55 1
51 1
5
57 1
53 1
52 1
55 1
51 1
4
53 1
52 1
56 1
51 1
6
57 1
53 1
52 1
56 1
55 1
51 1
1
56 1
4
53 1
52 1
56 1
51 1
2
57 1
55 1
1
56 1
4
53 1
52 1
56 1
51 1
6
57 1
53 1
52 1
56 1
55 1
51 1
4
53 1
52 1
56 1
51 1
6
57 1
53 1
52 1
56 1
55 1
51 1
0
0
0
3
57 1
56 1
55 1
0
0
0
end_CG
