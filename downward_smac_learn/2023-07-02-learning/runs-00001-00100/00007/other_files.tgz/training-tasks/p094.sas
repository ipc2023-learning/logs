begin_version
3
end_version
begin_metric
0
end_metric
64
begin_variable
var73
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat10, dir1)
Atom pointing(sat10, dir1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5
0
2
244
0
3
253
0
4
262
0
5
271
0
6
280
0
7
289
0
9
308
0
9
0
227
0
1
236
0
2
245
0
3
254
0
4
263
0
5
272
0
6
281
0
7
290
0
8
299
0
end_DTG
begin_DTG
9
1
138
0
2
147
0
3
156
0
4
165
0
5
174
0
6
183
0
7
192
0
8
201
0
9
210
0
9
0
129
0
2
148
0
3
157
0
4
166
0
5
175
0
6
184
0
7
193
0
8
202
0
9
211
0
9
0
130
0
1
139
0
3
158
0
4
167
0
5
176
0
6
185
0
7
194
0
8
203
0
9
212
0
9
0
131
0
1
140
0
2
149
0
4
168
0
5
177
0
6
186
0
7
195
0
8
204
0
9
213
0
9
0
132
0
1
141
0
2
150
0
3
159
0
5
178
0
6
187
0
7
196
0
8
205
0
9
214
0
9
0
133
0
1
142
0
2
151
0
3
160
0
4
169
0
6
188
0
7
197
0
8
206
0
9
215
0
9
0
134
0
1
143
0
2
152
0
3
161
0
4
170
0
5
179
0
7
198
0
8
207
0
9
216
0
9
0
135
0
1
144
0
2
153
0
3
162
0
4
171
0
5
180
0
6
189
0
8
208
0
9
217
0
9
0
136
0
1
145
0
2
154
0
3
163
0
4
172
0
5
181
0
6
190
0
7
199
0
9
218
0
9
0
137
0
1
146
0
2
155
0
3
164
0
4
173
0
5
182
0
6
191
0
7
200
0
8
209
0
end_DTG
begin_DTG
1
1
56
1
8 0
1
0
15
2
31 2
7 0
end_DTG
begin_DTG
1
1
55
1
16 0
1
0
10
2
33 9
15 0
end_DTG
begin_DTG
1
1
54
1
28 0
1
0
1
2
38 5
27 0
end_DTG
begin_DTG
1
1
53
1
3 0
1
0
16
2
30 6
4 0
end_DTG
begin_DTG
1
1
52
1
2 0
1
0
18
2
29 0
1 0
end_DTG
begin_DTG
1
1
51
1
20 0
1
0
4
2
35 7
21 0
end_DTG
begin_DTG
1
1
50
1
19 0
1
0
6
2
34 5
18 0
end_DTG
begin_DTG
1
1
49
1
24 0
1
0
2
2
37 5
25 0
end_DTG
begin_DTG
1
1
48
1
8 0
1
0
14
2
31 1
6 0
end_DTG
begin_DTG
1
1
47
1
16 0
1
0
9
2
33 3
14 0
end_DTG
begin_DTG
1
1
46
1
8 0
1
0
13
2
31 8
5 0
end_DTG
begin_DTG
1
1
45
1
19 0
1
0
5
2
34 0
17 0
end_DTG
begin_DTG
1
1
44
1
16 0
1
0
8
2
33 6
13 0
end_DTG
begin_DTG
1
1
43
1
28 0
1
0
0
2
38 6
26 0
end_DTG
begin_DTG
1
1
42
1
2 0
1
0
17
2
29 1
0 0
end_DTG
begin_DTG
1
1
41
1
11 0
1
0
12
2
32 2
10 0
end_DTG
begin_DTG
1
1
40
1
16 0
1
0
7
2
33 2
12 0
end_DTG
begin_DTG
1
1
39
1
11 0
1
0
11
2
32 7
9 0
end_DTG
begin_DTG
0
11
0
64
3
41 0
38 9
27 0
0
72
3
44 0
35 9
21 0
0
81
3
50 0
34 9
17 0
0
82
3
45 0
34 9
18 0
0
97
3
55 0
33 9
12 0
0
98
3
40 0
33 9
15 0
0
107
3
56 0
32 9
9 0
0
108
3
54 0
32 9
10 0
0
119
3
49 0
31 9
5 0
0
120
3
39 0
31 9
7 0
0
124
3
42 0
30 9
4 0
end_DTG
begin_DTG
0
11
0
63
3
41 0
38 7
27 0
0
71
3
44 0
35 7
21 0
0
79
3
50 0
34 7
17 0
0
80
3
45 0
34 7
18 0
0
95
3
55 0
33 7
12 0
0
96
3
40 0
33 7
15 0
0
105
3
56 0
32 7
9 0
0
106
3
54 0
32 7
10 0
0
117
3
49 0
31 7
5 0
0
118
3
39 0
31 7
7 0
0
123
3
42 0
30 7
4 0
end_DTG
begin_DTG
0
11
0
60
3
41 0
38 5
27 0
0
70
3
44 0
35 5
21 0
0
76
3
50 0
34 5
17 0
0
77
3
45 0
34 5
18 0
0
89
3
55 0
33 5
12 0
0
90
3
40 0
33 5
15 0
0
102
3
56 0
32 5
9 0
0
103
3
54 0
32 5
10 0
0
113
3
49 0
31 5
5 0
0
114
3
39 0
31 5
7 0
0
122
3
42 0
30 5
4 0
end_DTG
begin_DTG
0
11
0
59
3
41 0
38 4
27 0
0
69
3
44 0
35 4
21 0
0
74
3
50 0
34 4
17 0
0
75
3
45 0
34 4
18 0
0
87
3
55 0
33 4
12 0
0
88
3
40 0
33 4
15 0
0
100
3
56 0
32 4
9 0
0
101
3
54 0
32 4
10 0
0
111
3
49 0
31 4
5 0
0
112
3
39 0
31 4
7 0
0
121
3
42 0
30 4
4 0
end_DTG
begin_DTG
1
1
38
1
22 0
1
0
3
2
36 4
23 0
end_DTG
begin_DTG
0
14
0
61
3
52 0
38 6
26 0
0
62
3
41 0
38 6
27 0
0
66
3
46 0
37 6
25 0
0
68
3
61 0
36 6
23 0
0
78
3
45 0
34 6
18 0
0
91
3
55 0
33 6
12 0
0
92
3
51 0
33 6
13 0
0
93
3
48 0
33 6
14 0
0
94
3
40 0
33 6
15 0
0
104
3
54 0
32 6
10 0
0
115
3
49 0
31 6
5 0
0
116
3
47 0
31 6
6 0
0
127
3
53 0
29 6
0 0
0
128
3
43 0
29 6
1 0
end_DTG
begin_DTG
0
14
0
57
3
52 0
38 1
26 0
0
58
3
41 0
38 1
27 0
0
65
3
46 0
37 1
25 0
0
67
3
61 0
36 1
23 0
0
73
3
45 0
34 1
18 0
0
83
3
55 0
33 1
12 0
0
84
3
51 0
33 1
13 0
0
85
3
48 0
33 1
14 0
0
86
3
40 0
33 1
15 0
0
99
3
54 0
32 1
10 0
0
109
3
49 0
31 1
5 0
0
110
3
47 0
31 1
6 0
0
125
3
53 0
29 1
0 0
0
126
3
43 0
29 1
1 0
end_DTG
begin_CG
4
53 1
63 1
62 1
2 1
4
43 1
63 1
62 1
2 1
4
53 1
43 1
0 1
1 1
2
42 1
4 1
6
42 1
60 1
59 1
58 1
57 1
3 1
8
49 1
63 1
60 1
59 1
62 1
58 1
57 1
8 1
4
47 1
63 1
62 1
8 1
6
39 1
60 1
59 1
58 1
57 1
8 1
6
49 1
47 1
39 1
5 1
6 1
7 1
6
56 1
60 1
59 1
58 1
57 1
11 1
8
54 1
63 1
60 1
59 1
62 1
58 1
57 1
11 1
4
56 1
54 1
9 1
10 1
8
55 1
63 1
60 1
59 1
62 1
58 1
57 1
16 1
4
51 1
63 1
62 1
16 1
4
48 1
63 1
62 1
16 1
8
40 1
63 1
60 1
59 1
62 1
58 1
57 1
16 1
8
55 1
51 1
48 1
40 1
12 1
13 1
14 1
15 1
6
50 1
60 1
59 1
58 1
57 1
19 1
8
45 1
63 1
60 1
59 1
62 1
58 1
57 1
19 1
4
50 1
45 1
17 1
18 1
2
44 1
21 1
6
44 1
60 1
59 1
58 1
57 1
20 1
2
61 1
23 1
4
61 1
63 1
62 1
22 1
2
46 1
25 1
4
46 1
63 1
62 1
24 1
4
52 1
63 1
62 1
28 1
8
41 1
63 1
60 1
59 1
62 1
58 1
57 1
28 1
4
52 1
41 1
26 1
27 1
4
53 1
43 1
63 2
62 2
5
42 1
60 1
59 1
58 1
57 1
9
49 1
47 1
39 1
63 2
60 2
59 2
62 2
58 2
57 2
8
56 1
54 1
63 1
60 2
59 2
62 1
58 2
57 2
10
55 1
51 1
48 1
40 1
63 4
60 2
59 2
62 4
58 2
57 2
8
50 1
45 1
63 1
60 2
59 2
62 1
58 2
57 2
5
44 1
60 1
59 1
58 1
57 1
3
61 1
63 1
62 1
3
46 1
63 1
62 1
8
52 1
41 1
63 2
60 1
59 1
62 2
58 1
57 1
4
60 1
59 1
58 1
57 1
6
63 1
60 1
59 1
62 1
58 1
57 1
6
63 1
60 1
59 1
62 1
58 1
57 1
4
60 1
59 1
58 1
57 1
2
63 1
62 1
4
60 1
59 1
58 1
57 1
6
63 1
60 1
59 1
62 1
58 1
57 1
2
63 1
62 1
2
63 1
62 1
2
63 1
62 1
6
63 1
60 1
59 1
62 1
58 1
57 1
4
60 1
59 1
58 1
57 1
2
63 1
62 1
2
63 1
62 1
2
63 1
62 1
6
63 1
60 1
59 1
62 1
58 1
57 1
6
63 1
60 1
59 1
62 1
58 1
57 1
4
60 1
59 1
58 1
57 1
0
0
0
0
2
63 1
62 1
0
0
end_CG
