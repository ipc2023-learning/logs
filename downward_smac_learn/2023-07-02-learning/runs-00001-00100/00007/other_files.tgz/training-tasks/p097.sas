begin_version
3
end_version
begin_metric
0
end_metric
83
begin_variable
var69
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var89
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins20)
NegatedAtom power_on(ins20)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var88
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var59
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
0 1
25
55 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
4 1
11
45 1
81 1
77 1
76 1
73 1
70 1
67 1
65 1
64 1
61 1
4 1
4
55 1
45 1
2 1
3 1
25
59 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
9 1
17
54 1
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
9 1
11
51 1
81 1
77 1
76 1
73 1
70 1
67 1
65 1
64 1
61 1
9 1
25
50 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
9 1
8
59 1
54 1
51 1
50 1
5 1
6 1
7 1
8 1
25
47 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
12 1
16
43 1
82 1
80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
12 1
4
47 1
43 1
10 1
11 1
17
52 1
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
15 1
25
42 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
15 1
4
52 1
42 1
13 1
14 1
2
48 1
17 1
25
48 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
16 1
25
57 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
20 1
17
41 1
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
20 1
4
57 1
41 1
18 1
19 1
11
56 1
81 1
77 1
76 1
73 1
70 1
67 1
65 1
64 1
61 1
25 1
25
53 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
25 1
8
49 1
79 1
75 1
72 1
69 1
63 1
60 1
25 1
25
44 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
25 1
8
56 1
53 1
49 1
44 1
21 1
22 1
23 1
24 1
2
46 1
27 1
16
46 1
82 1
80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
26 1
2
58 1
29 1
17
58 1
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
28 1
15
40 1
82 1
80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
25
55 1
45 1
82 1
81 2
80 1
79 1
78 1
77 2
76 2
75 1
74 1
73 2
72 1
71 1
70 2
69 1
68 1
67 2
66 1
65 2
64 2
63 1
62 1
61 2
60 1
27
59 1
54 1
51 1
50 1
82 2
81 4
80 2
79 3
78 2
77 4
76 4
75 3
74 2
73 4
72 3
71 2
70 4
69 3
68 2
67 4
66 2
65 4
64 4
63 3
62 2
61 4
60 3
25
47 1
43 1
82 2
81 1
80 2
79 2
78 2
77 1
76 1
75 2
74 2
73 1
72 2
71 2
70 1
69 2
68 2
67 1
66 2
65 1
64 1
63 2
62 2
61 1
60 2
25
52 1
42 1
82 1
81 2
80 1
79 2
78 1
77 2
76 2
75 2
74 1
73 2
72 2
71 1
70 2
69 2
68 1
67 2
66 1
65 2
64 2
63 2
62 1
61 2
60 2
24
48 1
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
25
57 1
41 1
82 1
81 2
80 1
79 2
78 1
77 2
76 2
75 2
74 1
73 2
72 2
71 1
70 2
69 2
68 1
67 2
66 1
65 2
64 2
63 2
62 1
61 2
60 2
27
56 1
53 1
49 1
44 1
82 2
81 3
80 2
79 3
78 2
77 3
76 3
75 3
74 2
73 3
72 3
71 2
70 3
69 3
68 2
67 3
66 2
65 3
64 3
63 3
62 2
61 3
60 3
15
46 1
82 1
80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
16
58 1
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
14
82 1
80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
15
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
14
82 1
80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
9
81 1
77 1
76 1
73 1
70 1
67 1
65 1
64 1
61 1
14
82 1
80 1
79 1
78 1
75 1
74 1
72 1
71 1
69 1
68 1
66 1
63 1
62 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
6
79 1
75 1
72 1
69 1
63 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
9
81 1
77 1
76 1
73 1
70 1
67 1
65 1
64 1
61 1
15
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
15
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
9
81 1
77 1
76 1
73 1
70 1
67 1
65 1
64 1
61 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
15
81 1
79 1
77 1
76 1
75 1
73 1
72 1
70 1
69 1
67 1
65 1
64 1
63 1
61 1
60 1
23
82 1
81 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
