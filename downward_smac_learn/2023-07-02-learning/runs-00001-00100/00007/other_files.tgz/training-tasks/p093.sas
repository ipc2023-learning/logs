begin_version
3
end_version
begin_metric
0
end_metric
75
begin_variable
var77
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat10, dir1)
Atom pointing(sat10, dir1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
29 7
1 0
end_DTG
begin_DTG
0
12
0
81
3
54 0
38 6
25 0
0
82
3
50 0
38 6
26 0
0
84
3
46 0
38 6
27 0
0
102
3
41 0
37 6
24 0
0
157
3
53 0
34 6
13 0
0
159
3
51 0
34 6
14 0
0
161
3
44 0
34 6
16 0
0
180
3
39 0
33 6
12 0
0
216
3
43 0
31 6
7 0
0
230
3
67 0
30 6
4 0
0
251
3
49 0
29 6
0 0
0
253
3
45 0
29 6
1 0
end_DTG
begin_DTG
0
12
0
75
3
54 0
38 5
25 0
0
77
3
50 0
38 5
26 0
0
80
3
46 0
38 5
27 0
0
100
3
41 0
37 5
24 0
0
150
3
53 0
34 5
13 0
0
153
3
51 0
34 5
14 0
0
156
3
44 0
34 5
16 0
0
178
3
39 0
33 5
12 0
0
211
3
43 0
31 5
7 0
0
229
3
67 0
30 5
4 0
0
246
3
49 0
29 5
0 0
0
249
3
45 0
29 5
1 0
end_DTG
begin_DTG
0
12
0
70
3
54 0
38 4
25 0
0
72
3
50 0
38 4
26 0
0
74
3
46 0
38 4
27 0
0
98
3
41 0
37 4
24 0
0
145
3
53 0
34 4
13 0
0
147
3
51 0
34 4
14 0
0
149
3
44 0
34 4
16 0
0
176
3
39 0
33 4
12 0
0
205
3
43 0
31 4
7 0
0
228
3
67 0
30 4
4 0
0
242
3
49 0
29 4
0 0
0
244
3
45 0
29 4
1 0
end_DTG
begin_DTG
0
12
0
66
3
54 0
38 3
25 0
0
67
3
50 0
38 3
26 0
0
69
3
46 0
38 3
27 0
0
97
3
41 0
37 3
24 0
0
140
3
53 0
34 3
13 0
0
142
3
51 0
34 3
14 0
0
144
3
44 0
34 3
16 0
0
175
3
39 0
33 3
12 0
0
203
3
43 0
31 3
7 0
0
227
3
67 0
30 3
4 0
0
239
3
49 0
29 3
0 0
0
241
3
45 0
29 3
1 0
end_DTG
begin_DTG
0
12
0
63
3
54 0
38 2
25 0
0
64
3
50 0
38 2
26 0
0
65
3
46 0
38 2
27 0
0
95
3
41 0
37 2
24 0
0
137
3
53 0
34 2
13 0
0
138
3
51 0
34 2
14 0
0
139
3
44 0
34 2
16 0
0
173
3
39 0
33 2
12 0
0
199
3
43 0
31 2
7 0
0
226
3
67 0
30 2
4 0
0
237
3
49 0
29 2
0 0
0
238
3
45 0
29 2
1 0
end_DTG
begin_DTG
0
12
0
57
3
54 0
38 1
25 0
0
59
3
50 0
38 1
26 0
0
62
3
46 0
38 1
27 0
0
94
3
41 0
37 1
24 0
0
130
3
53 0
34 1
13 0
0
133
3
51 0
34 1
14 0
0
136
3
44 0
34 1
16 0
0
172
3
39 0
33 1
12 0
0
197
3
43 0
31 1
7 0
0
225
3
67 0
30 1
4 0
0
232
3
49 0
29 1
0 0
0
235
3
45 0
29 1
1 0
end_DTG
begin_CG
14
49 1
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
2 1
19
45 1
66 1
74 1
65 1
73 1
64 1
72 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
68 1
59 1
58 1
57 1
2 1
4
49 1
45 1
0 1
1 1
2
67 1
4 1
9
67 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
3 1
12
55 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
8 1
7
52 1
66 1
64 1
62 1
60 1
58 1
8 1
19
43 1
66 1
74 1
65 1
73 1
64 1
72 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
68 1
59 1
58 1
57 1
8 1
6
55 1
52 1
43 1
5 1
6 1
7 1
2
42 1
10 1
12
42 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
9 1
2
39 1
12 1
14
39 1
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
11 1
14
53 1
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
17 1
14
51 1
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
17 1
12
47 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
17 1
9
44 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
17 1
8
53 1
51 1
47 1
44 1
13 1
14 1
15 1
16 1
12
48 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
20 1
7
40 1
66 1
64 1
62 1
60 1
58 1
20 1
4
48 1
40 1
18 1
19 1
2
56 1
22 1
12
56 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
21 1
2
41 1
24 1
14
41 1
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
23 1
14
54 1
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
28 1
14
50 1
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
28 1
14
46 1
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
28 1
6
54 1
50 1
46 1
25 1
26 1
27 1
19
49 1
45 1
66 1
74 2
65 2
73 2
64 1
72 2
71 2
63 2
62 1
70 2
61 2
60 1
69 2
68 2
59 2
58 1
57 2
8
67 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
20
55 1
52 1
43 1
66 3
74 1
65 2
73 1
64 3
72 1
71 1
63 2
62 3
70 1
61 2
60 3
69 1
68 1
59 2
58 3
57 2
11
42 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
13
39 1
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
21
53 1
51 1
47 1
44 1
66 2
74 3
65 2
73 3
64 2
72 3
71 3
63 2
62 2
70 3
61 2
60 2
69 3
68 3
59 2
58 2
57 2
12
48 1
40 1
66 2
65 1
64 2
63 1
62 2
61 1
60 2
59 1
58 2
57 1
11
56 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
13
41 1
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
20
54 1
50 1
46 1
66 1
74 3
65 2
73 3
64 1
72 3
71 3
63 2
62 1
70 3
61 2
60 1
69 3
68 3
59 2
58 1
57 2
12
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
5
66 1
64 1
62 1
60 1
58 1
12
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
10
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
17
66 1
74 1
65 1
73 1
64 1
72 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
68 1
59 1
58 1
57 1
7
74 1
73 1
72 1
71 1
70 1
69 1
68 1
17
66 1
74 1
65 1
73 1
64 1
72 1
71 1
63 1
62 1
70 1
61 1
60 1
69 1
68 1
59 1
58 1
57 1
12
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
10
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
10
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
12
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
12
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
12
66 1
74 1
73 1
64 1
72 1
71 1
62 1
70 1
60 1
69 1
68 1
58 1
5
66 1
64 1
62 1
60 1
58 1
12
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
12
74 1
65 1
73 1
72 1
71 1
63 1
70 1
61 1
69 1
68 1
59 1
57 1
10
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
10
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
0
0
0
0
0
0
0
0
0
0
7
74 1
73 1
72 1
71 1
70 1
69 1
68 1
0
0
0
0
0
0
0
end_CG
