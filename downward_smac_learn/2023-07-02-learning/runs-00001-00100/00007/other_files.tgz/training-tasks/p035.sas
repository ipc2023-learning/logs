begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var26
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var30
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var23
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var22
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var27
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var21
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var28
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var25
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var29
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var20
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var31
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var19
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var18
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var17
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var16
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var15
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var14
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var10
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
1
1
0
0
1
0
1
1
1
0
1
1
0
4
5
5
3
5
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
15 0
16 1
17 4
26 0
27 0
28 0
29 0
30 0
end_goal
214
begin_operator
calibrate sat1 ins1 dir1
2
17 0
10 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat1 ins8 dir6
2
17 5
11 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir5
2
16 4
7 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat2 ins6 dir4
2
16 3
8 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat3 ins5 dir4
2
15 3
6 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat4 ins4 dir2
2
14 1
4 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat5 ins3 dir5
2
13 4
0 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat5 ins7 dir3
2
13 2
1 0
1
0 19 -1 0
0
end_operator
begin_operator
switch_off ins1 sat1
0
2
0 12 -1 0
0 10 0 1
0
end_operator
begin_operator
switch_off ins2 sat2
0
2
0 9 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins3 sat5
0
2
0 2 -1 0
0 0 0 1
0
end_operator
begin_operator
switch_off ins4 sat4
0
2
0 3 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins5 sat3
0
2
0 5 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins6 sat2
0
2
0 9 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins7 sat5
0
2
0 2 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins8 sat1
0
2
0 12 -1 0
0 11 0 1
0
end_operator
begin_operator
switch_on ins1 sat1
0
3
0 25 -1 1
0 12 0 1
0 10 -1 0
0
end_operator
begin_operator
switch_on ins2 sat2
0
3
0 24 -1 1
0 9 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins3 sat5
0
3
0 23 -1 1
0 2 0 1
0 0 -1 0
0
end_operator
begin_operator
switch_on ins4 sat4
0
3
0 22 -1 1
0 3 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins5 sat3
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8
143
148
switch 14
check 0
check 5
159
164
169
174
179
switch 13
check 5
154
165
170
175
180
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
5
check 0
check 0
check 5
155
160
171
176
181
check 5
156
161
166
177
182
check 5
157
162
167
172
183
check 5
158
163
168
173
178
switch 13
check 0
check 5
189
194
199
204
209
check 5
184
195
200
205
210
switch 12
check 5
185
190
201
206
211
check 0
check 0
switch 1
check 0
check 1
7
check 0
check 0
check 5
186
191
196
207
212
switch 12
check 5
187
192
197
202
213
check 0
check 0
switch 0
check 0
check 1
6
check 0
check 0
check 5
188
193
198
203
208
switch 12
check 0
check 2
16
23
check 0
switch 9
check 0
check 2
17
21
check 0
switch 5
check 0
check 1
20
check 0
switch 3
check 0
check 1
19
check 0
switch 2
check 0
check 2
18
22
check 0
switch 10
check 0
check 1
8
check 0
switch 7
check 0
check 1
9
check 0
switch 0
check 0
check 1
10
check 0
switch 4
check 0
check 1
11
check 0
switch 6
check 0
check 1
12
check 0
switch 8
check 0
check 1
13
check 0
switch 1
check 0
check 1
14
check 0
switch 11
check 0
check 1
15
check 0
check 0
end_SG
begin_DTG
1
1
10
0
1
0
18
1
2 0
end_DTG
begin_DTG
1
1
14
0
1
0
22
1
2 0
end_DTG
begin_DTG
1
1
18
0
2
0
10
1
0 0
0
14
1
1 0
end_DTG
begin_DTG
1
1
19
0
1
0
11
1
4 0
end_DTG
begin_DTG
1
1
11
0
1
0
19
1
3 0
end_DTG
begin_DTG
1
1
20
0
1
0
12
1
6 0
end_DTG
begin_DTG
1
1
12
0
1
0
20
1
5 0
end_DTG
begin_DTG
1
1
9
0
1
0
17
1
9 0
end_DTG
begin_DTG
1
1
13
0
1
0
21
1
9 0
end_DTG
begin_DTG
1
1
17
0
2
0
9
1
7 0
0
13
1
8 0
end_DTG
begin_DTG
1
1
8
0
1
0
16
1
12 0
end_DTG
begin_DTG
1
1
15
0
1
0
23
1
12 0
end_DTG
begin_DTG
1
1
16
0
2
0
8
1
10 0
0
15
1
11 0
end_DTG
begin_DTG
5
1
189
0
2
194
0
3
199
0
4
204
0
5
209
0
5
0
184
0
2
195
0
3
200
0
4
205
0
5
210
0
5
0
185
0
1
190
0
3
201
0
4
206
0
5
211
0
5
0
186
0
1
191
0
2
196
0
4
207
0
5
212
0
5
0
187
0
1
192
0
2
197
0
3
202
0
5
213
0
5
0
188
0
1
193
0
2
198
0
3
203
0
4
208
0
end_DTG
begin_DTG
5
1
159
0
2
164
0
3
169
0
4
174
0
5
179
0
5
0
154
0
2
165
0
3
170
0
4
175
0
5
180
0
5
0
155
0
1
160
0
3
171
0
4
176
0
5
181
0
5
0
156
0
1
161
0
2
166
0
4
177
0
5
182
0
5
0
157
0
1
162
0
2
167
0
3
172
0
5
183
0
5
0
158
0
1
163
0
2
168
0
3
173
0
4
178
0
end_DTG
begin_DTG
5
1
129
0
2
134
0
3
139
0
4
144
0
5
149
0
5
0
124
0
2
135
0
3
140
0
4
145
0
5
150
0
5
0
125
0
1
130
0
3
141
0
4
146
0
5
151
0
5
0
126
0
1
131
0
2
136
0
4
147
0
5
152
0
5
0
127
0
1
132
0
2
137
0
3
142
0
5
153
0
5
0
128
0
1
133
0
2
138
0
3
143
0
4
148
0
end_DTG
begin_DTG
5
1
99
0
2
104
0
3
109
0
4
114
0
5
119
0
5
0
94
0
2
105
0
3
110
0
4
115
0
5
120
0
5
0
95
0
1
100
0
3
111
0
4
116
0
5
121
0
5
0
96
0
1
101
0
2
106
0
4
117
0
5
122
0
5
0
97
0
1
102
0
2
107
0
3
112
0
5
123
0
5
0
98
0
1
103
0
2
108
0
3
113
0
4
118
0
end_DTG
begin_DTG
5
1
69
0
2
74
0
3
79
0
4
84
0
5
89
0
5
0
64
0
2
75
0
3
80
0
4
85
0
5
90
0
5
0
65
0
1
70
0
3
81
0
4
86
0
5
91
0
5
0
66
0
1
71
0
2
76
0
4
87
0
5
92
0
5
0
67
0
1
72
0
2
77
0
3
82
0
5
93
0
5
0
68
0
1
73
0
2
78
0
3
83
0
4
88
0
end_DTG
begin_DTG
1
1
23
1
12 0
1
0
1
2
17 5
11 0
end_DTG
begin_DTG
1
1
22
1
2 0
1
0
7
2
13 2
1 0
end_DTG
begin_DTG
1
1
21
1
9 0
1
0
3
2
16 3
8 0
end_DTG
begin_DTG
1
1
20
1
5 0
1
0
4
2
15 3
6 0
end_DTG
begin_DTG
1
1
19
1
3 0
1
0
5
2
14 1
4 0
end_DTG
begin_DTG
1
1
18
1
2 0
1
0
6
2
13 4
0 0
end_DTG
begin_DTG
1
1
17
1
9 0
1
0
2
2
16 4
7 0
end_DTG
begin_DTG
1
1
16
1
12 0
1
0
0
2
17 0
10 0
end_DTG
begin_DTG
0
8
0
32
3
25 0
17 5
10 0
0
33
3
18 0
17 5
11 0
0
42
3
24 0
16 5
7 0
0
43
3
20 0
16 5
8 0
0
48
3
21 0
15 5
6 0
0
53
3
22 0
14 5
4 0
0
62
3
23 0
13 5
0 0
0
63
3
19 0
13 5
1 0
end_DTG
begin_DTG
0
8
0
30
3
25 0
17 3
10 0
0
31
3
18 0
17 3
11 0
0
40
3
24 0
16 3
7 0
0
41
3
20 0
16 3
8 0
0
47
3
21 0
15 3
6 0
0
52
3
22 0
14 3
4 0
0
60
3
23 0
13 3
0 0
0
61
3
19 0
13 3
1 0
end_DTG
begin_DTG
0
8
0
28
3
25 0
17 2
10 0
0
29
3
18 0
17 2
11 0
0
38
3
24 0
16 2
7 0
0
39
3
20 0
16 2
8 0
0
46
3
21 0
15 2
6 0
0
51
3
22 0
14 2
4 0
0
58
3
23 0
13 2
0 0
0
59
3
19 0
13 2
1 0
end_DTG
begin_DTG
0
8
0
26
3
25 0
17 1
10 0
0
27
3
18 0
17 1
11 0
0
36
3
24 0
16 1
7 0
0
37
3
20 0
16 1
8 0
0
45
3
21 0
15 1
6 0
0
50
3
22 0
14 1
4 0
0
56
3
23 0
13 1
0 0
0
57
3
19 0
13 1
1 0
end_DTG
begin_DTG
0
8
0
24
3
25 0
17 0
10 0
0
25
3
18 0
17 0
11 0
0
34
3
24 0
16 0
7 0
0
35
3
20 0
16 0
8 0
0
44
3
21 0
15 0
6 0
0
49
3
22 0
14 0
4 0
0
54
3
23 0
13 0
0 0
0
55
3
19 0
13 0
1 0
end_DTG
begin_CG
7
23 1
30 1
29 1
28 1
27 1
26 1
2 1
7
19 1
30 1
29 1
28 1
27 1
26 1
2 1
4
23 1
19 1
0 1
1 1
2
22 1
4 1
7
22 1
30 1
29 1
28 1
27 1
26 1
3 1
2
21 1
6 1
7
21 1
30 1
29 1
28 1
27 1
26 1
5 1
7
24 1
30 1
29 1
28 1
27 1
26 1
9 1
7
20 1
30 1
29 1
28 1
27 1
26 1
9 1
4
24 1
20 1
7 1
8 1
7
25 1
30 1
29 1
28 1
27 1
26 1
12 1
7
18 1
30 1
29 1
28 1
27 1
26 1
12 1
4
25 1
18 1
10 1
11 1
7
23 1
19 1
30 2
29 2
28 2
27 2
26 2
6
22 1
30 1
29 1
28 1
27 1
26 1
6
21 1
30 1
29 1
28 1
27 1
26 1
7
24 1
20 1
30 2
29 2
28 2
27 2
26 2
7
25 1
18 1
30 2
29 2
28 2
27 2
26 2
5
30 1
29 1
28 1
27 1
26 1
5
30 1
29 1
28 1
27 1
26 1
5
30 1
29 1
28 1
27 1
26 1
5
30 1
29 1
28 1
27 1
26 1
5
30 1
29 1
28 1
27 1
26 1
5
30 1
29 1
28 1
27 1
26 1
5
30 1
29 1
28 1
27 1
26 1
5
30 1
29 1
28 1
27 1
26 1
0
0
0
0
0
end_CG
