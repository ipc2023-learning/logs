begin_version
3
end_version
begin_metric
0
end_metric
36
begin_variable
var33
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var36
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var30
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var29
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var35
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var28
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var32
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var27
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var34
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var31
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var26
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var25
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var24
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var23
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var22
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var21
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir3, mod2)
NegatedAtom have_image(dir3, mod2)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
begin_variable
var10
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(dir1, mod2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var19
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var17
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
1
1
1
1
0
0
1
0
1
0
1
1
1
0
0
2
0
4
4
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
12
14 3
15 5
16 0
18 5
27 0
28 0
29 0
31 0
32 0
33 0
34 0
35 0
end_goal
227
begin_operator
calibrate sat1 ins1 dir3
2
18 2
11 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat1 ins8 dir5
2
18 4
12 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat2 ins4 dir3
2
17 2
10 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat3 ins2 dir2
2
16 1
8 0
1
0 26 -1 0
0
end_operator
begin_operator
calibrate sat4 ins5 dir1
2
15 0
6 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat5 ins3 dir2
2
14 1
0 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat5 ins6 dir4
2
14 3
1 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat5 ins7 dir4
2
14 3
2 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat5 ins9 dir3
2
14 2
3 0
1
0 19 -1 0
0
end_operator
begin_operator
switch_off ins1 sat1
0
2
0 13 -1 0
0 11 0 1
0
end_operator
begin_operator
switch_off ins2 sat3
0
2
0 7 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins3 sat5
0
2
0 4 -1 0
0 0 0 1
0
end_operator
begin_operator
switch_off ins4 sat2
0
2
0 9 -1 0
0 10 0 1
0
end_operator
begin_operator
switch_off ins5 sat4
0
2
0 5 -1 0
0 6 0 1
0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




210
215
226
check 5
201
206
211
216
221
switch 13
check 0
check 2
18
25
check 0
switch 9
check 0
check 1
21
check 0
switch 7
check 0
check 1
19
check 0
switch 5
check 0
check 1
22
check 0
switch 4
check 0
check 4
20
23
24
26
check 0
switch 11
check 0
check 1
9
check 0
switch 8
check 0
check 1
10
check 0
switch 0
check 0
check 1
11
check 0
switch 10
check 0
check 1
12
check 0
switch 6
check 0
check 1
13
check 0
switch 1
check 0
check 1
14
check 0
switch 2
check 0
check 1
15
check 0
switch 12
check 0
check 1
16
check 0
switch 3
check 0
check 1
17
check 0
check 0
end_SG
begin_DTG
1
1
11
0
1
0
20
1
4 0
end_DTG
begin_DTG
1
1
14
0
1
0
23
1
4 0
end_DTG
begin_DTG
1
1
15
0
1
0
24
1
4 0
end_DTG
begin_DTG
1
1
17
0
1
0
26
1
4 0
end_DTG
begin_DTG
1
1
20
0
4
0
11
1
0 0
0
14
1
1 0
0
15
1
2 0
0
17
1
3 0
end_DTG
begin_DTG
1
1
22
0
1
0
13
1
6 0
end_DTG
begin_DTG
1
1
13
0
1
0
22
1
5 0
end_DTG
begin_DTG
1
1
19
0
1
0
10
1
8 0
end_DTG
begin_DTG
1
1
10
0
1
0
19
1
7 0
end_DTG
begin_DTG
1
1
21
0
1
0
12
1
10 0
end_DTG
begin_DTG
1
1
12
0
1
0
21
1
9 0
end_DTG
begin_DTG
1
1
9
0
1
0
18
1
13 0
end_DTG
begin_DTG
1
1
16
0
1
0
25
1
13 0
end_DTG
begin_DTG
1
1
18
0
2
0
9
1
11 0
0
16
1
12 0
end_DTG
begin_DTG
5
1
202
0
2
207
0
3
212
0
4
217
0
5
222
0
5
0
197
0
2
208
0
3
213
0
4
218
0
5
223
0
5
0
198
0
1
203
0
3
214
0
4
219
0
5
224
0
5
0
199
0
1
204
0
2
209
0
4
220
0
5
225
0
5
0
200
0
1
205
0
2
210
0
3
215
0
5
226
0
5
0
201
0
1
206
0
2
211
0
3
216
0
4
221
0
end_DTG
begin_DTG
5
1
172
0
2
177
0
3
182
0
4
187
0
5
192
0
5
0
167
0
2
178
0
3
183
0
4
188
0
5
193
0
5
0
168
0
1
173
0
3
184
0
4
189
0
5
194
0
5
0
169
0
1
174
0
2
179
0
4
190
0
5
195
0
5
0
170
0
1
175
0
2
180
0
3
185
0
5
196
0
5
0
171
0
1
176
0
2
181
0
3
186
0
4
191
0
end_DTG
begin_DTG
5
1
142
0
2
147
0
3
152
0
4
157
0
5
162
0
5
0
137
0
2
148
0
3
153
0
4
158
0
5
163
0
5
0
138
0
1
143
0
3
154
0
4
159
0
5
164
0
5
0
139
0
1
144
0
2
149
0
4
160
0
5
165
0
5
0
140
0
1
145
0
2
150
0
3
155
0
5
166
0
5
0
141
0
1
146
0
2
151
0
3
156
0
4
161
0
end_DTG
begin_DTG
5
1
112
0
2
117
0
3
122
0
4
127
0
5
132
0
5
0
107
0
2
118
0
3
123
0
4
128
0
5
133
0
5
0
108
0
1
113
0
3
124
0
4
129
0
5
134
0
5
0
109
0
1
114
0
2
119
0
4
130
0
5
135
0
5
0
110
0
1
115
0
2
120
0
3
125
0
5
136
0
5
0
111
0
1
116
0
2
121
0
3
126
0
4
131
0
end_DTG
begin_DTG
5
1
82
0
2
87
0
3
92
0
4
97
0
5
102
0
5
0
77
0
2
88
0
3
93
0
4
98
0
5
103
0
5
0
78
0
1
83
0
3
94
0
4
99
0
5
104
0
5
0
79
0
1
84
0
2
89
0
4
100
0
5
105
0
5
0
80
0
1
85
0
2
90
0
3
95
0
5
106
0
5
0
81
0
1
86
0
2
91
0
3
96
0
4
101
0
end_DTG
begin_DTG
1
1
26
1
4 0
1
0
8
2
14 2
3 0
end_DTG
begin_DTG
1
1
25
1
13 0
1
0
1
2
18 4
12 0
end_DTG
begin_DTG
1
1
24
1
4 0
1
0
7
2
14 3
2 0
end_DTG
begin_DTG
1
1
23
1
4 0
1
0
6
2
14 3
1 0
end_DTG
begin_DTG
1
1
22
1
5 0
1
0
4
2
15 0
6 0
end_DTG
begin_DTG
1
1
21
1
9 0
1
0
2
2
17 2
10 0
end_DTG
begin_DTG
1
1
20
1
4 0
1
0
5
2
14 1
0 0
end_DTG
begin_DTG
1
1
19
1
7 0
1
0
3
2
16 1
8 0
end_DTG
begin_DTG
0
5
0
44
3
26 0
16 2
8 0
0
64
3
25 0
14 2
0 0
0
66
3
22 0
14 2
1 0
0
68
3
21 0
14 2
2 0
0
70
3
19 0
14 2
3 0
end_DTG
begin_DTG
0
5
0
43
3
26 0
16 1
8 0
0
57
3
25 0
14 1
0 0
0
59
3
22 0
14 1
1 0
0
61
3
21 0
14 1
2 0
0
63
3
19 0
14 1
3 0
end_DTG
begin_DTG
0
5
0
42
3
26 0
16 0
8 0
0
50
3
25 0
14 0
0 0
0
52
3
22 0
14 0
1 0
0
54
3
21 0
14 0
2 0
0
56
3
19 0
14 0
3 0
end_DTG
begin_DTG
1
1
18
1
13 0
1
0
0
2
18 2
11 0
end_DTG
begin_DTG
0
7
0
35
3
30 0
18 5
11 0
0
36
3
20 0
18 5
12 0
0
41
3
24 0
17 5
10 0
0
49
3
23 0
15 5
6 0
0
74
3
22 0
14 5
1 0
0
75
3
21 0
14 5
2 0
0
76
3
19 0
14 5
3 0
end_DTG
begin_DTG
0
7
0
33
3
30 0
18 4
11 0
0
34
3
20 0
18 4
12 0
0
40
3
24 0
17 4
10 0
0
48
3
23 0
15 4
6 0
0
71
3
22 0
14 4
1 0
0
72
3
21 0
14 4
2 0
0
73
3
19 0
14 4
3 0
end_DTG
begin_DTG
0
7
0
31
3
30 0
18 2
11 0
0
32
3
20 0
18 2
12 0
0
39
3
24 0
17 2
10 0
0
47
3
23 0
15 2
6 0
0
65
3
22 0
14 2
1 0
0
67
3
21 0
14 2
2 0
0
69
3
19 0
14 2
3 0
end_DTG
begin_DTG
0
7
0
29
3
30 0
18 1
11 0
0
30
3
20 0
18 1
12 0
0
38
3
24 0
17 1
10 0
0
46
3
23 0
15 1
6 0
0
58
3
22 0
14 1
1 0
0
60
3
21 0
14 1
2 0
0
62
3
19 0
14 1
3 0
end_DTG
begin_DTG
0
7
0
27
3
30 0
18 0
11 0
0
28
3
20 0
18 0
12 0
0
37
3
24 0
17 0
10 0
0
45
3
23 0
15 0
6 0
0
51
3
22 0
14 0
1 0
0
53
3
21 0
14 0
2 0
0
55
3
19 0
14 0
3 0
end_DTG
begin_CG
5
25 1
29 1
28 1
27 1
4 1
10
22 1
35 1
29 1
34 1
28 1
33 1
27 1
32 1
31 1
4 1
10
21 1
35 1
29 1
34 1
28 1
33 1
27 1
32 1
31 1
4 1
10
19 1
35 1
29 1
34 1
28 1
33 1
27 1
32 1
31 1
4 1
8
25 1
22 1
21 1
19 1
0 1
1 1
2 1
3 1
2
23 1
6 1
7
23 1
35 1
34 1
33 1
32 1
31 1
5 1
2
26 1
8 1
5
26 1
29 1
28 1
27 1
7 1
2
24 1
10 1
7
24 1
35 1
34 1
33 1
32 1
31 1
9 1
7
30 1
35 1
34 1
33 1
32 1
31 1
13 1
7
20 1
35 1
34 1
33 1
32 1
31 1
13 1
4
30 1
20 1
11 1
12 1
12
25 1
22 1
21 1
19 1
35 3
29 4
34 3
28 4
33 3
27 4
32 3
31 3
6
23 1
35 1
34 1
33 1
32 1
31 1
4
26 1
29 1
28 1
27 1
6
24 1
35 1
34 1
33 1
32 1
31 1
7
30 1
20 1
35 2
34 2
33 2
32 2
31 2
8
35 1
29 1
34 1
28 1
33 1
27 1
32 1
31 1
5
35 1
34 1
33 1
32 1
31 1
8
35 1
29 1
34 1
28 1
33 1
27 1
32 1
31 1
8
35 1
29 1
34 1
28 1
33 1
27 1
32 1
31 1
5
35 1
34 1
33 1
32 1
31 1
5
35 1
34 1
33 1
32 1
31 1
3
29 1
28 1
27 1
3
29 1
28 1
27 1
0
0
0
5
35 1
34 1
33 1
32 1
31 1
0
0
0
0
0
end_CG
