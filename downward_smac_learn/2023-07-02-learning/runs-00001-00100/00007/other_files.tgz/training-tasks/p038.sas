begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var23
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var25
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var29
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var22
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var26
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var31
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var21
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var28
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var30
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var20
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var19
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var27
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var18
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var17
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var16
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var15
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var14
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var10
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
0
1
1
1
0
1
1
0
1
1
0
0
1
2
0
4
4
2
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
6
13 1
14 5
17 2
26 0
27 0
28 0
end_goal
198
begin_operator
calibrate sat1 ins4 dir1
2
17 0
12 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat2 ins5 dir2
2
16 1
8 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat2 ins7 dir1
2
16 0
9 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir3
2
15 2
5 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat3 ins8 dir5
2
15 4
6 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat4 ins1 dir2
2
14 1
2 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat4 ins6 dir5
2
14 4
3 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat5 ins2 dir2
2
13 1
1 0
1
0 24 -1 0
0
end_operator
begin_operator
switch_off ins1 sat4
0
2
0 4 -1 0
0 2 0 1
0
end_operator
begin_operator
switch_off ins2 sat5
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 7 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_off ins4 sat1
0
2
0 11 -1 0
0 12 0 1
0
end_operator
begin_operator
switch_off ins5 sat2
0
2
0 10 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins6 sat4
0
2
0 4 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins7 sat2
0
2
0 10 -1 0
0 9 0 1
0
end_operator
begin_operator
switch_off ins8 sat3
0
2
0 7 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_on ins1 sat4
0
3
0 25 -1 1
0 4 0 1
0 2 -1 0
0
end_operator
begin_operator
switch_on ins2 sat5
0
3
0 24 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 23 -1 1
0 7 0 1
0 5 -1 0
0
end_operator
begin_operator
switch_on ins4 sat1
0
3
0 22 -1 1
0 11 0 1
0 12 -1 0
0
end_operator
begin_operator
switch_on ins5 sat2
0
3
0 21 -1 1
0 10 0 1
0 8 -1 0
0
end_operator
begin_operator
switch_on ins6 sat4
0
3
0 20 -1 1
0 4 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins7 sat2
0
3
0 19 -1 1
0 10 0 1
0 9 -1 0
0
end_operator
begin_ope




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5
78
89
94
99
104
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
1
check 0
check 0
check 5
79
84
95
100
105
check 5
80
85
90
101
106
check 5
81
86
91
96
107
check 5
82
87
92
97
102
switch 15
check 0
check 5
113
118
123
128
133
check 5
108
119
124
129
134
switch 14
check 5
109
114
125
130
135
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
3
check 0
check 0
check 5
110
115
120
131
136
switch 14
check 5
111
116
121
126
137
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
4
check 0
check 0
check 5
112
117
122
127
132
switch 14
check 0
check 5
143
148
153
158
163
switch 13
check 5
138
149
154
159
164
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
5
check 0
check 0
check 5
139
144
155
160
165
check 5
140
145
150
161
166
switch 13
check 5
141
146
151
156
167
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
6
check 0
check 0
check 5
142
147
152
157
162
switch 13
check 0
check 5
173
178
183
188
193
switch 11
check 5
168
179
184
189
194
check 0
check 0
switch 1
check 0
check 1
7
check 0
check 0
check 5
169
174
185
190
195
check 5
170
175
180
191
196
check 5
171
176
181
186
197
check 5
172
177
182
187
192
switch 11
check 0
check 1
19
check 0
switch 10
check 0
check 2
20
22
check 0
switch 7
check 0
check 2
18
23
check 0
switch 4
check 0
check 2
16
21
check 0
switch 0
check 0
check 1
17
check 0
switch 2
check 0
check 1
8
check 0
switch 1
check 0
check 1
9
check 0
switch 5
check 0
check 1
10
check 0
switch 12
check 0
check 1
11
check 0
switch 8
check 0
check 1
12
check 0
switch 3
check 0
check 1
13
check 0
switch 9
check 0
check 1
14
check 0
switch 6
check 0
check 1
15
check 0
check 0
end_SG
begin_DTG
1
1
17
0
1
0
9
1
1 0
end_DTG
begin_DTG
1
1
9
0
1
0
17
1
0 0
end_DTG
begin_DTG
1
1
8
0
1
0
16
1
4 0
end_DTG
begin_DTG
1
1
13
0
1
0
21
1
4 0
end_DTG
begin_DTG
1
1
16
0
2
0
8
1
2 0
0
13
1
3 0
end_DTG
begin_DTG
1
1
10
0
1
0
18
1
7 0
end_DTG
begin_DTG
1
1
15
0
1
0
23
1
7 0
end_DTG
begin_DTG
1
1
18
0
2
0
10
1
5 0
0
15
1
6 0
end_DTG
begin_DTG
1
1
12
0
1
0
20
1
10 0
end_DTG
begin_DTG
1
1
14
0
1
0
22
1
10 0
end_DTG
begin_DTG
1
1
20
0
2
0
12
1
8 0
0
14
1
9 0
end_DTG
begin_DTG
1
1
19
0
1
0
11
1
12 0
end_DTG
begin_DTG
1
1
11
0
1
0
19
1
11 0
end_DTG
begin_DTG
5
1
173
0
2
178
0
3
183
0
4
188
0
5
193
0
5
0
168
0
2
179
0
3
184
0
4
189
0
5
194
0
5
0
169
0
1
174
0
3
185
0
4
190
0
5
195
0
5
0
170
0
1
175
0
2
180
0
4
191
0
5
196
0
5
0
171
0
1
176
0
2
181
0
3
186
0
5
197
0
5
0
172
0
1
177
0
2
182
0
3
187
0
4
192
0
end_DTG
begin_DTG
5
1
143
0
2
148
0
3
153
0
4
158
0
5
163
0
5
0
138
0
2
149
0
3
154
0
4
159
0
5
164
0
5
0
139
0
1
144
0
3
155
0
4
160
0
5
165
0
5
0
140
0
1
145
0
2
150
0
4
161
0
5
166
0
5
0
141
0
1
146
0
2
151
0
3
156
0
5
167
0
5
0
142
0
1
147
0
2
152
0
3
157
0
4
162
0
end_DTG
begin_DTG
5
1
113
0
2
118
0
3
123
0
4
128
0
5
133
0
5
0
108
0
2
119
0
3
124
0
4
129
0
5
134
0
5
0
109
0
1
114
0
3
125
0
4
130
0
5
135
0
5
0
110
0
1
115
0
2
120
0
4
131
0
5
136
0
5
0
111
0
1
116
0
2
121
0
3
126
0
5
137
0
5
0
112
0
1
117
0
2
122
0
3
127
0
4
132
0
end_DTG
begin_DTG
5
1
83
0
2
88
0
3
93
0
4
98
0
5
103
0
5
0
78
0
2
89
0
3
94
0
4
99
0
5
104
0
5
0
79
0
1
84
0
3
95
0
4
100
0
5
105
0
5
0
80
0
1
85
0
2
90
0
4
101
0
5
106
0
5
0
81
0
1
86
0
2
91
0
3
96
0
5
107
0
5
0
82
0
1
87
0
2
92
0
3
97
0
4
102
0
end_DTG
begin_DTG
5
1
53
0
2
58
0
3
63
0
4
68
0
5
73
0
5
0
48
0
2
59
0
3
64
0
4
69
0
5
74
0
5
0
49
0
1
54
0
3
65
0
4
70
0
5
75
0
5
0
50
0
1
55
0
2
60
0
4
71
0
5
76
0
5
0
51
0
1
56
0
2
61
0
3
66
0
5
77
0
5
0
52
0
1
57
0
2
62
0
3
67
0
4
72
0
end_DTG
begin_DTG
1
1
23
1
7 0
1
0
4
2
15 4
6 0
end_DTG
begin_DTG
1
1
22
1
10 0
1
0
2
2
16 0
9 0
end_DTG
begin_DTG
1
1
21
1
4 0
1
0
6
2
14 4
3 0
end_DTG
begin_DTG
1
1
20
1
10 0
1
0
1
2
16 1
8 0
end_DTG
begin_DTG
1
1
19
1
11 0
1
0
0
2
17 0
12 0
end_DTG
begin_DTG
1
1
18
1
7 0
1
0
3
2
15 2
5 0
end_DTG
begin_DTG
1
1
17
1
0 0
1
0
7
2
13 1
1 0
end_DTG
begin_DTG
1
1
16
1
4 0
1
0
5
2
14 1
2 0
end_DTG
begin_DTG
0
8
0
26
3
22 0
17 3
12 0
0
31
3
21 0
16 3
8 0
0
32
3
19 0
16 3
9 0
0
37
3
23 0
15 3
5 0
0
38
3
18 0
15 3
6 0
0
43
3
25 0
14 3
2 0
0
44
3
20 0
14 3
3 0
0
47
3
24 0
13 3
1 0
end_DTG
begin_DTG
0
8
0
25
3
22 0
17 2
12 0
0
29
3
21 0
16 2
8 0
0
30
3
19 0
16 2
9 0
0
35
3
23 0
15 2
5 0
0
36
3
18 0
15 2
6 0
0
41
3
25 0
14 2
2 0
0
42
3
20 0
14 2
3 0
0
46
3
24 0
13 2
1 0
end_DTG
begin_DTG
0
8
0
24
3
22 0
17 0
12 0
0
27
3
21 0
16 0
8 0
0
28
3
19 0
16 0
9 0
0
33
3
23 0
15 0
5 0
0
34
3
18 0
15 0
6 0
0
39
3
25 0
14 0
2 0
0
40
3
20 0
14 0
3 0
0
45
3
24 0
13 0
1 0
end_DTG
begin_CG
2
24 1
1 1
5
24 1
28 1
27 1
26 1
0 1
5
25 1
28 1
27 1
26 1
4 1
5
20 1
28 1
27 1
26 1
4 1
4
25 1
20 1
2 1
3 1
5
23 1
28 1
27 1
26 1
7 1
5
18 1
28 1
27 1
26 1
7 1
4
23 1
18 1
5 1
6 1
5
21 1
28 1
27 1
26 1
10 1
5
19 1
28 1
27 1
26 1
10 1
4
21 1
19 1
8 1
9 1
2
22 1
12 1
5
22 1
28 1
27 1
26 1
11 1
4
24 1
28 1
27 1
26 1
5
25 1
20 1
28 2
27 2
26 2
5
23 1
18 1
28 2
27 2
26 2
5
21 1
19 1
28 2
27 2
26 2
4
22 1
28 1
27 1
26 1
3
28 1
27 1
26 1
3
28 1
27 1
26 1
3
28 1
27 1
26 1
3
28 1
27 1
26 1
3
28 1
27 1
26 1
3
28 1
27 1
26 1
3
28 1
27 1
26 1
3
28 1
27 1
26 1
0
0
0
end_CG
