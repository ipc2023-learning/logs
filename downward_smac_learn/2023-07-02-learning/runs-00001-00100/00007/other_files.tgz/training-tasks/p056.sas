begin_version
3
end_version
begin_metric
0
end_metric
45
begin_variable
var41
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var37
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var32
-1
7
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
end_variable
begin_variable
var31
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var21
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
begin_variable
var19
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var18
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var17
-1
2
Atom have_image(dir3, mod2)
NegatedAtom have_image(dir3, mod2)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(dir1, mod2)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
1
1
1
0
0
1
1
1
0
1
1
0
0
1
0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




begin_DTG
6
1
272
0
2
278
0
3
284
0
4
290
0
5
296
0
6
302
0
6
0
266
0
2
279
0
3
285
0
4
291
0
5
297
0
6
303
0
6
0
267
0
1
273
0
3
286
0
4
292
0
5
298
0
6
304
0
6
0
268
0
1
274
0
2
280
0
4
293
0
5
299
0
6
305
0
6
0
269
0
1
275
0
2
281
0
3
287
0
5
300
0
6
306
0
6
0
270
0
1
276
0
2
282
0
3
288
0
4
294
0
6
307
0
6
0
271
0
1
277
0
2
283
0
3
289
0
4
295
0
5
301
0
end_DTG
begin_DTG
6
1
230
0
2
236
0
3
242
0
4
248
0
5
254
0
6
260
0
6
0
224
0
2
237
0
3
243
0
4
249
0
5
255
0
6
261
0
6
0
225
0
1
231
0
3
244
0
4
250
0
5
256
0
6
262
0
6
0
226
0
1
232
0
2
238
0
4
251
0
5
257
0
6
263
0
6
0
227
0
1
233
0
2
239
0
3
245
0
5
258
0
6
264
0
6
0
228
0
1
234
0
2
240
0
3
246
0
4
252
0
6
265
0
6
0
229
0
1
235
0
2
241
0
3
247
0
4
253
0
5
259
0
end_DTG
begin_DTG
6
1
188
0
2
194
0
3
200
0
4
206
0
5
212
0
6
218
0
6
0
182
0
2
195
0
3
201
0
4
207
0
5
213
0
6
219
0
6
0
183
0
1
189
0
3
202
0
4
208
0
5
214
0
6
220
0
6
0
184
0
1
190
0
2
196
0
4
209
0
5
215
0
6
221
0
6
0
185
0
1
191
0
2
197
0
3
203
0
5
216
0
6
222
0
6
0
186
0
1
192
0
2
198
0
3
204
0
4
210
0
6
223
0
6
0
187
0
1
193
0
2
199
0
3
205
0
4
211
0
5
217
0
end_DTG
begin_DTG
6
1
146
0
2
152
0
3
158
0
4
164
0
5
170
0
6
176
0
6
0
140
0
2
153
0
3
159
0
4
165
0
5
171
0
6
177
0
6
0
141
0
1
147
0
3
160
0
4
166
0
5
172
0
6
178
0
6
0
142
0
1
148
0
2
154
0
4
167
0
5
173
0
6
179
0
6
0
143
0
1
149
0
2
155
0
3
161
0
5
174
0
6
180
0
6
0
144
0
1
150
0
2
156
0
3
162
0
4
168
0
6
181
0
6
0
145
0
1
151
0
2
157
0
3
163
0
4
169
0
5
175
0
end_DTG
begin_DTG
6
1
104
0
2
110
0
3
116
0
4
122
0
5
128
0
6
134
0
6
0
98
0
2
111
0
3
117
0
4
123
0
5
129
0
6
135
0
6
0
99
0
1
105
0
3
118
0
4
124
0
5
130
0
6
136
0
6
0
100
0
1
106
0
2
112
0
4
125
0
5
131
0
6
137
0
6
0
101
0
1
107
0
2
113
0
3
119
0
5
132
0
6
138
0
6
0
102
0
1
108
0
2
114
0
3
120
0
4
126
0
6
139
0
6
0
103
0
1
109
0
2
115
0
3
121
0
4
127
0
5
133
0
end_DTG
begin_DTG
1
1
35
1
11 0
1
0
5
2
22 5
10 0
end_DTG
begin_DTG
1
1
34
1
8 0
1
0
7
2
21 2
7 0
end_DTG
begin_DTG
1
1
33
1
8 0
1
0
6
2
21 1
6 0
end_DTG
begin_DTG
1
1
32
1
14 0
1
0
2
2
24 2
15 0
end_DTG
begin_DTG
1
1
31
1
11 0
1
0
4
2
22 3
9 0
end_DTG
begin_DTG
1
1
30
1
18 0
1
0
1
2
25 6
17 0
end_DTG
begin_DTG
1
1
29
1
3 0
1
0
11
2
19 1
2 0
end_DTG
begin_DTG
1
1
28
1
12 0
1
0
3
2
23 0
13 0
end_DTG
begin_DTG
1
1
27
1
18 0
1
0
0
2
25 0
16 0
end_DTG
begin_DTG
1
1
26
1
3 0
1
0
10
2
19 2
1 0
end_DTG
begin_DTG
1
1
25
1
3 0
1
0
9
2
19 5
0 0
end_DTG
begin_DTG
1
1
24
1
4 0
1
0
8
2
20 6
5 0
end_DTG
begin_DTG
0
8
0
48
3
34 0
25 4
16 0
0
49
3
31 0
25 4
17 0
0
53
3
29 0
24 4
15 0
0
57
3
33 0
23 4
13 0
0
67
3
30 0
22 4
9 0
0
80
3
37 0
20 4
5 0
0
96
3
36 0
19 4
0 0
0
97
3
32 0
19 4
2 0
end_DTG
begin_DTG
0
8
0
45
3
34 0
25 3
16 0
0
47
3
31 0
25 3
17 0
0
52
3
29 0
24 3
15 0
0
56
3
33 0
23 3
13 0
0
65
3
30 0
22 3
9 0
0
79
3
37 0
20 3
5 0
0
92
3
36 0
19 3
0 0
0
95
3
32 0
19 3
2 0
end_DTG
begin_DTG
0
10
0
44
3
34 0
25 3
16 0
0
46
3
31 0
25 3
17 0
0
64
3
30 0
22 3
9 0
0
66
3
26 0
22 3
10 0
0
72
3
28 0
21 3
6 0
0
73
3
27 0
21 3
7 0
0
78
3
37 0
20 3
5 0
0
91
3
36 0
19 3
0 0
0
93
3
35 0
19 3
1 0
0
94
3
32 0
19 3
2 0
end_DTG
begin_DTG
0
8
0
42
3
34 0
25 2
16 0
0
43
3
31 0
25 2
17 0
0
51
3
29 0
24 2
15 0
0
55
3
33 0
23 2
13 0
0
63
3
30 0
22 2
9 0
0
77
3
37 0
20 2
5 0
0
89
3
36 0
19 2
0 0
0
90
3
32 0
19 2
2 0
end_DTG
begin_DTG
0
10
0
40
3
34 0
25 1
16 0
0
41
3
31 0
25 1
17 0
0
61
3
30 0
22 1
9 0
0
62
3
26 0
22 1
10 0
0
70
3
28 0
21 1
6 0
0
71
3
27 0
21 1
7 0
0
76
3
37 0
20 1
5 0
0
86
3
36 0
19 1
0 0
0
87
3
35 0
19 1
1 0
0
88
3
32 0
19 1
2 0
end_DTG
begin_DTG
0
8
0
37
3
34 0
25 0
16 0
0
39
3
31 0
25 0
17 0
0
50
3
29 0
24 0
15 0
0
54
3
33 0
23 0
13 0
0
59
3
30 0
22 0
9 0
0
75
3
37 0
20 0
5 0
0
82
3
36 0
19 0
0 0
0
85
3
32 0
19 0
2 0
end_DTG
begin_DTG
0
10
0
36
3
34 0
25 0
16 0
0
38
3
31 0
25 0
17 0
0
58
3
30 0
22 0
9 0
0
60
3
26 0
22 0
10 0
0
68
3
28 0
21 0
6 0
0
69
3
27 0
21 0
7 0
0
74
3
37 0
20 0
5 0
0
81
3
36 0
19 0
0 0
0
83
3
35 0
19 0
1 0
0
84
3
32 0
19 0
2 0
end_DTG
begin_CG
9
36 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
3 1
5
35 1
44 1
42 1
40 1
3 1
9
32 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
3 1
6
36 1
35 1
32 1
0 1
1 1
2 1
2
37 1
5 1
9
37 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
4 1
5
28 1
44 1
42 1
40 1
8 1
5
27 1
44 1
42 1
40 1
8 1
4
28 1
27 1
6 1
7 1
9
30 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
11 1
5
26 1
44 1
42 1
40 1
11 1
4
30 1
26 1
9 1
10 1
2
33 1
13 1
6
33 1
43 1
41 1
39 1
38 1
12 1
2
29 1
15 1
6
29 1
43 1
41 1
39 1
38 1
14 1
9
34 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
18 1
9
31 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
18 1
4
34 1
31 1
16 1
17 1
10
36 1
35 1
32 1
44 3
43 2
42 3
41 2
40 3
39 2
38 2
8
37 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
5
28 1
27 1
44 2
42 2
40 2
9
30 1
26 1
44 2
43 1
42 2
41 1
40 2
39 1
38 1
5
33 1
43 1
41 1
39 1
38 1
5
29 1
43 1
41 1
39 1
38 1
9
34 1
31 1
44 2
43 2
42 2
41 2
40 2
39 2
38 2
3
44 1
42 1
40 1
3
44 1
42 1
40 1
3
44 1
42 1
40 1
4
43 1
41 1
39 1
38 1
7
44 1
43 1
42 1
41 1
40 1
39 1
38 1
7
44 1
43 1
42 1
41 1
40 1
39 1
38 1
7
44 1
43 1
42 1
41 1
40 1
39 1
38 1
4
43 1
41 1
39 1
38 1
7
44 1
43 1
42 1
41 1
40 1
39 1
38 1
3
44 1
42 1
40 1
7
44 1
43 1
42 1
41 1
40 1
39 1
38 1
7
44 1
43 1
42 1
41 1
40 1
39 1
38 1
0
0
0
0
0
0
0
end_CG
