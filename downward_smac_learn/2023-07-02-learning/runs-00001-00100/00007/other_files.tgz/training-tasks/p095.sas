begin_version
3
end_version
begin_metric
0
end_metric
66
begin_variable
var78
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var69
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var89
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var88
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins20)
NegatedAtom power_on(ins20)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var59
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





9
216
0
9
0
135
0
2
154
0
3
163
0
4
172
0
5
181
0
6
190
0
7
199
0
8
208
0
9
217
0
9
0
136
0
1
145
0
3
164
0
4
173
0
5
182
0
6
191
0
7
200
0
8
209
0
9
218
0
9
0
137
0
1
146
0
2
155
0
4
174
0
5
183
0
6
192
0
7
201
0
8
210
0
9
219
0
9
0
138
0
1
147
0
2
156
0
3
165
0
5
184
0
6
193
0
7
202
0
8
211
0
9
220
0
9
0
139
0
1
148
0
2
157
0
3
166
0
4
175
0
6
194
0
7
203
0
8
212
0
9
221
0
9
0
140
0
1
149
0
2
158
0
3
167
0
4
176
0
5
185
0
7
204
0
8
213
0
9
222
0
9
0
141
0
1
150
0
2
159
0
3
168
0
4
177
0
5
186
0
6
195
0
8
214
0
9
223
0
9
0
142
0
1
151
0
2
160
0
3
169
0
4
178
0
5
187
0
6
196
0
7
205
0
9
224
0
9
0
143
0
1
152
0
2
161
0
3
170
0
4
179
0
5
188
0
6
197
0
7
206
0
8
215
0
end_DTG
begin_DTG
1
1
59
1
9 0
1
0
14
2
32 6
8 0
end_DTG
begin_DTG
1
1
58
1
15 0
1
0
10
2
34 5
14 0
end_DTG
begin_DTG
1
1
57
1
2 0
1
0
19
2
30 0
1 0
end_DTG
begin_DTG
1
1
56
1
18 0
1
0
7
2
36 2
19 0
end_DTG
begin_DTG
1
1
55
1
23 0
1
0
6
2
37 2
22 0
end_DTG
begin_DTG
1
1
54
1
28 0
1
0
0
2
39 5
29 0
end_DTG
begin_DTG
1
1
53
1
16 0
1
0
8
2
35 9
17 0
end_DTG
begin_DTG
1
1
52
1
27 0
1
0
3
2
38 9
26 0
end_DTG
begin_DTG
1
1
51
1
27 0
1
0
2
2
38 1
25 0
end_DTG
begin_DTG
1
1
50
1
12 0
1
0
12
2
33 6
11 0
end_DTG
begin_DTG
1
1
49
1
9 0
1
0
13
2
32 8
7 0
end_DTG
begin_DTG
1
1
48
1
2 0
1
0
18
2
30 6
0 0
end_DTG
begin_DTG
1
1
47
1
6 0
1
0
17
2
31 8
5 0
end_DTG
begin_DTG
1
1
46
1
15 0
1
0
9
2
34 6
13 0
end_DTG
begin_DTG
1
1
45
1
6 0
1
0
16
2
31 9
4 0
end_DTG
begin_DTG
1
1
44
1
27 0
1
0
1
2
38 7
24 0
end_DTG
begin_DTG
1
1
43
1
23 0
1
0
5
2
37 3
21 0
end_DTG
begin_DTG
1
1
42
1
23 0
1
0
4
2
37 8
20 0
end_DTG
begin_DTG
0
13
0
68
3
55 0
38 3
24 0
0
70
3
48 0
38 3
25 0
0
72
3
47 0
38 3
26 0
0
82
3
57 0
37 3
20 0
0
84
3
44 0
37 3
22 0
0
90
3
43 0
36 3
19 0
0
94
3
46 0
35 3
17 0
0
102
3
53 0
34 3
13 0
0
117
3
40 0
32 3
8 0
0
123
3
54 0
31 3
4 0
0
124
3
52 0
31 3
5 0
0
130
3
51 0
30 3
0 0
0
131
3
42 0
30 3
1 0
end_DTG
begin_DTG
1
1
41
1
12 0
1
0
11
2
33 2
10 0
end_DTG
begin_DTG
0
10
0
61
3
45 0
39 6
29 0
0
76
3
55 0
38 6
24 0
0
77
3
48 0
38 6
25 0
0
87
3
57 0
37 6
20 0
0
97
3
46 0
35 6
17 0
0
107
3
53 0
34 6
13 0
0
108
3
41 0
34 6
14 0
0
113
3
59 0
33 6
10 0
0
127
3
54 0
31 6
4 0
0
134
3
51 0
30 6
0 0
end_DTG
begin_DTG
0
10
0
60
3
45 0
39 4
29 0
0
74
3
55 0
38 4
24 0
0
75
3
48 0
38 4
25 0
0
86
3
57 0
37 4
20 0
0
96
3
46 0
35 4
17 0
0
105
3
53 0
34 4
13 0
0
106
3
41 0
34 4
14 0
0
112
3
59 0
33 4
10 0
0
126
3
54 0
31 4
4 0
0
133
3
51 0
30 4
0 0
end_DTG
begin_DTG
1
1
40
1
6 0
1
0
15
2
31 5
3 0
end_DTG
begin_DTG
0
14
0
69
3
55 0
38 3
24 0
0
71
3
48 0
38 3
25 0
0
73
3
47 0
38 3
26 0
0
83
3
56 0
37 3
21 0
0
85
3
44 0
37 3
22 0
0
91
3
43 0
36 3
19 0
0
95
3
46 0
35 3
17 0
0
103
3
53 0
34 3
13 0
0
104
3
41 0
34 3
14 0
0
111
3
49 0
33 3
11 0
0
116
3
50 0
32 3
7 0
0
122
3
62 0
31 3
3 0
0
125
3
52 0
31 3
5 0
0
132
3
42 0
30 3
1 0
end_DTG
begin_DTG
0
14
0
65
3
55 0
38 2
24 0
0
66
3
48 0
38 2
25 0
0
67
3
47 0
38 2
26 0
0
80
3
56 0
37 2
21 0
0
81
3
44 0
37 2
22 0
0
89
3
43 0
36 2
19 0
0
93
3
46 0
35 2
17 0
0
100
3
53 0
34 2
13 0
0
101
3
41 0
34 2
14 0
0
110
3
49 0
33 2
11 0
0
115
3
50 0
32 2
7 0
0
120
3
62 0
31 2
3 0
0
121
3
52 0
31 2
5 0
0
129
3
42 0
30 2
1 0
end_DTG
begin_DTG
0
14
0
62
3
55 0
38 0
24 0
0
63
3
48 0
38 0
25 0
0
64
3
47 0
38 0
26 0
0
78
3
56 0
37 0
21 0
0
79
3
44 0
37 0
22 0
0
88
3
43 0
36 0
19 0
0
92
3
46 0
35 0
17 0
0
98
3
53 0
34 0
13 0
0
99
3
41 0
34 0
14 0
0
109
3
49 0
33 0
11 0
0
114
3
50 0
32 0
7 0
0
118
3
62 0
31 0
3 0
0
119
3
52 0
31 0
5 0
0
128
3
42 0
30 0
1 0
end_DTG
begin_CG
5
51 1
58 1
61 1
60 1
2 1
6
42 1
65 1
64 1
58 1
63 1
2 1
4
51 1
42 1
0 1
1 1
5
62 1
65 1
64 1
63 1
6 1
5
54 1
58 1
61 1
60 1
6 1
6
52 1
65 1
64 1
58 1
63 1
6 1
6
62 1
54 1
52 1
3 1
4 1
5 1
5
50 1
65 1
64 1
63 1
9 1
3
40 1
58 1
9 1
4
50 1
40 1
7 1
8 1
4
59 1
61 1
60 1
12 1
5
49 1
65 1
64 1
63 1
12 1
4
59 1
49 1
10 1
11 1
8
53 1
65 1
64 1
58 1
63 1
61 1
60 1
15 1
7
41 1
65 1
64 1
63 1
61 1
60 1
15 1
4
53 1
41 1
13 1
14 1
2
46 1
17 1
8
46 1
65 1
64 1
58 1
63 1
61 1
60 1
16 1
2
43 1
19 1
6
43 1
65 1
64 1
58 1
63 1
18 1
5
57 1
58 1
61 1
60 1
23 1
5
56 1
65 1
64 1
63 1
23 1
6
44 1
65 1
64 1
58 1
63 1
23 1
6
57 1
56 1
44 1
20 1
21 1
22 1
8
55 1
65 1
64 1
58 1
63 1
61 1
60 1
27 1
8
48 1
65 1
64 1
58 1
63 1
61 1
60 1
27 1
6
47 1
65 1
64 1
58 1
63 1
27 1
6
55 1
48 1
47 1
24 1
25 1
26 1
2
45 1
29 1
4
45 1
61 1
60 1
28 1
8
51 1
42 1
65 1
64 1
58 2
63 1
61 1
60 1
9
62 1
54 1
52 1
65 2
64 2
58 2
63 2
61 1
60 1
6
50 1
40 1
65 1
64 1
58 1
63 1
7
59 1
49 1
65 1
64 1
63 1
61 1
60 1
8
53 1
41 1
65 2
64 2
58 1
63 2
61 2
60 2
7
46 1
65 1
64 1
58 1
63 1
61 1
60 1
5
43 1
65 1
64 1
58 1
63 1
9
57 1
56 1
44 1
65 2
64 2
58 2
63 2
61 1
60 1
9
55 1
48 1
47 1
65 3
64 3
58 3
63 3
61 2
60 2
3
45 1
61 1
60 1
1
58 1
5
65 1
64 1
63 1
61 1
60 1
4
65 1
64 1
58 1
63 1
4
65 1
64 1
58 1
63 1
4
65 1
64 1
58 1
63 1
2
61 1
60 1
6
65 1
64 1
58 1
63 1
61 1
60 1
4
65 1
64 1
58 1
63 1
6
65 1
64 1
58 1
63 1
61 1
60 1
3
65 1
64 1
63 1
3
65 1
64 1
63 1
3
58 1
61 1
60 1
4
65 1
64 1
58 1
63 1
6
65 1
64 1
58 1
63 1
61 1
60 1
3
58 1
61 1
60 1
6
65 1
64 1
58 1
63 1
61 1
60 1
3
65 1
64 1
63 1
3
58 1
61 1
60 1
0
2
61 1
60 1
0
0
3
65 1
64 1
63 1
0
0
0
end_CG
