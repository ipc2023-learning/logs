begin_version
3
end_version
begin_metric
0
end_metric
38
begin_variable
var40
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var34
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var35
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var30
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var29
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var36
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var28
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var27
-1
6
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
end_variable
begin_variable
var26
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var25
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var24
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var23
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var22
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var21
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var20
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var17
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var16
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
0
begin_state
1
1
0
1
1
0
1
1
0
1
1
0
0
1
0
1
1
1
4
2
3
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
7
19 5
32 0
33 0
34 0
35 0
36 0
37 0
end_goal
264
begin_operator
calibrate sat1 ins3 dir6
2
21 5
15 0
1
0 28 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir6
2
20 5
13 0
1
0 29 -1 0
0
end_operator
begin_operator
calibrate sat3 ins4 dir4
2
19 3
9 0
1
0 27 -1 0
0
end_operator
begin_operator
calibrate sat3 ins9 dir2
2
19 1
10 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat4 ins5 dir2
2
18 1
6 0
1
0 26 -1 0
0
end_operator
begin_operator
calibrate sat4 ins7 dir3
2
18 2
7 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat5 ins1 dir2
2
17 1
3 0
1
0 31 -1 0
0
end_operator
begin_operator
calibrate sat5 ins10 dir1
2
17 0
4 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat6 ins6 dir1
2
16 0
0 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat6 ins8 dir1
2
16 0
1 0
1
0 23 -1 0
0
end_operator
begin_operator
switch_off ins1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 0
check 0
end_SG
begin_DTG
1
1
16
0
1
0
26
1
2 0
end_DTG
begin_DTG
1
1
18
0
1
0
28
1
2 0
end_DTG
begin_DTG
1
1
26
0
2
0
16
1
0 0
0
18
1
1 0
end_DTG
begin_DTG
1
1
10
0
1
0
20
1
5 0
end_DTG
begin_DTG
1
1
11
0
1
0
21
1
5 0
end_DTG
begin_DTG
1
1
20
0
2
0
10
1
3 0
0
11
1
4 0
end_DTG
begin_DTG
1
1
15
0
1
0
25
1
8 0
end_DTG
begin_DTG
1
1
17
0
1
0
27
1
8 0
end_DTG
begin_DTG
1
1
25
0
2
0
15
1
6 0
0
17
1
7 0
end_DTG
begin_DTG
1
1
14
0
1
0
24
1
11 0
end_DTG
begin_DTG
1
1
19
0
1
0
29
1
11 0
end_DTG
begin_DTG
1
1
24
0
2
0
14
1
9 0
0
19
1
10 0
end_DTG
begin_DTG
1
1
22
0
1
0
12
1
13 0
end_DTG
begin_DTG
1
1
12
0
1
0
22
1
12 0
end_DTG
begin_DTG
1
1
23
0
1
0
13
1
15 0
end_DTG
begin_DTG
1
1
13
0
1
0
23
1
14 0
end_DTG
begin_DTG
5
1
239
0
2
244
0
3
249
0
4
254
0
5
259
0
5
0
234
0
2
245
0
3
250
0
4
255
0
5
260
0
5
0
235
0
1
240
0
3
251
0
4
256
0
5
261
0
5
0
236
0
1
241
0
2
246
0
4
257
0
5
262
0
5
0
237
0
1
242
0
2
247
0
3
252
0
5
263
0
5
0
238
0
1
243
0
2
248
0
3
253
0
4
258
0
end_DTG
begin_DTG
5
1
209
0
2
214
0
3
219
0
4
224
0
5
229
0
5
0
204
0
2
215
0
3
220
0
4
225
0
5
230
0
5
0
205
0
1
210
0
3
221
0
4
226
0
5
231
0
5
0
206
0
1
211
0
2
216
0
4
227
0
5
232
0
5
0
207
0
1
212
0
2
217
0
3
222
0
5
233
0
5
0
208
0
1
213
0
2
218
0
3
223
0
4
228
0
end_DTG
begin_DTG
5
1
179
0
2
184
0
3
189
0
4
194
0
5
199
0
5
0
174
0
2
185
0
3
190
0
4
195
0
5
200
0
5
0
175
0
1
180
0
3
191
0
4
196
0
5
201
0
5
0
176
0
1
181
0
2
186
0
4
197
0
5
202
0
5
0
177
0
1
182
0
2
187
0
3
192
0
5
203
0
5
0
178
0
1
183
0
2
188
0
3
193
0
4
198
0
end_DTG
begin_DTG
5
1
149
0
2
154
0
3
159
0
4
164
0
5
169
0
5
0
144
0
2
155
0
3
160
0
4
165
0
5
170
0
5
0
145
0
1
150
0
3
161
0
4
166
0
5
171
0
5
0
146
0
1
151
0
2
156
0
4
167
0
5
172
0
5
0
147
0
1
152
0
2
157
0
3
162
0
5
173
0
5
0
148
0
1
153
0
2
158
0
3
163
0
4
168
0
end_DTG
begin_DTG
5
1
119
0
2
124
0
3
129
0
4
134
0
5
139
0
5
0
114
0
2
125
0
3
130
0
4
135
0
5
140
0
5
0
115
0
1
120
0
3
131
0
4
136
0
5
141
0
5
0
116
0
1
121
0
2
126
0
4
137
0
5
142
0
5
0
117
0
1
122
0
2
127
0
3
132
0
5
143
0
5
0
118
0
1
123
0
2
128
0
3
133
0
4
138
0
end_DTG
begin_DTG
5
1
89
0
2
94
0
3
99
0
4
104
0
5
109
0
5
0
84
0
2
95
0
3
100
0
4
105
0
5
110
0
5
0
85
0
1
90
0
3
101
0
4
106
0
5
111
0
5
0
86
0
1
91
0
2
96
0
4
107
0
5
112
0
5
0
87
0
1
92
0
2
97
0
3
102
0
5
113
0
5
0
88
0
1
93
0
2
98
0
3
103
0
4
108
0
end_DTG
begin_DTG
1
1
29
1
11 0
1
0
3
2
19 1
10 0
end_DTG
begin_DTG
1
1
28
1
2 0
1
0
9
2
16 0
1 0
end_DTG
begin_DTG
1
1
27
1
8 0
1
0
5
2
18 2
7 0
end_DTG
begin_DTG
1
1
26
1
2 0
1
0
8
2
16 0
0 0
end_DTG
begin_DTG
1
1
25
1
8 0
1
0
4
2
18 1
6 0
end_DTG
begin_DTG
1
1
24
1
11 0
1
0
2
2
19 3
9 0
end_DTG
begin_DTG
1
1
23
1
14 0
1
0
0
2
21 5
15 0
end_DTG
begin_DTG
1
1
22
1
12 0
1
0
1
2
20 5
13 0
end_DTG
begin_DTG
1
1
21
1
5 0
1
0
7
2
17 0
4 0
end_DTG
begin_DTG
1
1
20
1
5 0
1
0
6
2
17 1
3 0
end_DTG
begin_DTG
0
10
0
35
3
28 0
21 5
15 0
0
38
3
29 0
20 5
13 0
0
48
3
27 0
19 5
9 0
0
50
3
22 0
19 5
10 0
0
58
3
26 0
18 5
6 0
0
59
3
24 0
18 5
7 0
0
69
3
31 0
17 5
3 0
0
71
3
30 0
17 5
4 0
0
81
3
25 0
16 5
0 0
0
83
3
23 0
16 5
1 0
end_DTG
begin_DTG
0
8
0
34
3
28 0
21 5
15 0
0
47
3
27 0
19 5
9 0
0
49
3
22 0
19 5
10 0
0
57
3
26 0
18 5
6 0
0
68
3
31 0
17 5
3 0
0
70
3
30 0
17 5
4 0
0
80
3
25 0
16 5
0 0
0
82
3
23 0
16 5
1 0
end_DTG
begin_DTG
0
10
0
33
3
28 0
21 3
15 0
0
37
3
29 0
20 3
13 0
0
44
3
27 0
19 3
9 0
0
46
3
22 0
19 3
10 0
0
55
3
26 0
18 3
6 0
0
56
3
24 0
18 3
7 0
0
65
3
31 0
17 3
3 0
0
67
3
30 0
17 3
4 0
0
77
3
25 0
16 3
0 0
0
79
3
23 0
16 3
1 0
end_DTG
begin_DTG
0
8
0
32
3
28 0
21 3
15 0
0
43
3
27 0
19 3
9 0
0
45
3
22 0
19 3
10 0
0
54
3
26 0
18 3
6 0
0
64
3
31 0
17 3
3 0
0
66
3
30 0
17 3
4 0
0
76
3
25 0
16 3
0 0
0
78
3
23 0
16 3
1 0
end_DTG
begin_DTG
0
8
0
31
3
28 0
21 2
15 0
0
41
3
27 0
19 2
9 0
0
42
3
22 0
19 2
10 0
0
53
3
26 0
18 2
6 0
0
62
3
31 0
17 2
3 0
0
63
3
30 0
17 2
4 0
0
74
3
25 0
16 2
0 0
0
75
3
23 0
16 2
1 0
end_DTG
begin_DTG
0
10
0
30
3
28 0
21 1
15 0
0
36
3
29 0
20 1
13 0
0
39
3
27 0
19 1
9 0
0
40
3
22 0
19 1
10 0
0
51
3
26 0
18 1
6 0
0
52
3
24 0
18 1
7 0
0
60
3
31 0
17 1
3 0
0
61
3
30 0
17 1
4 0
0
72
3
25 0
16 1
0 0
0
73
3
23 0
16 1
1 0
end_DTG
begin_CG
8
25 1
37 1
36 1
35 1
34 1
33 1
32 1
2 1
8
23 1
37 1
36 1
35 1
34 1
33 1
32 1
2 1
4
25 1
23 1
0 1
1 1
8
31 1
37 1
36 1
35 1
34 1
33 1
32 1
5 1
8
30 1
37 1
36 1
35 1
34 1
33 1
32 1
5 1
4
31 1
30 1
3 1
4 1
8
26 1
37 1
36 1
35 1
34 1
33 1
32 1
8 1
5
24 1
37 1
34 1
32 1
8 1
4
26 1
24 1
6 1
7 1
8
27 1
37 1
36 1
35 1
34 1
33 1
32 1
11 1
8
22 1
37 1
36 1
35 1
34 1
33 1
32 1
11 1
4
27 1
22 1
9 1
10 1
2
29 1
13 1
5
29 1
37 1
34 1
32 1
12 1
2
28 1
15 1
8
28 1
37 1
36 1
35 1
34 1
33 1
32 1
14 1
8
25 1
23 1
37 2
36 2
35 2
34 2
33 2
32 2
8
31 1
30 1
37 2
36 2
35 2
34 2
33 2
32 2
8
26 1
24 1
37 2
36 1
35 1
34 2
33 1
32 2
8
27 1
22 1
37 2
36 2
35 2
34 2
33 2
32 2
4
29 1
37 1
34 1
32 1
7
28 1
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
3
37 1
34 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
3
37 1
34 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
6
37 1
36 1
35 1
34 1
33 1
32 1
0
0
0
0
0
0
end_CG
