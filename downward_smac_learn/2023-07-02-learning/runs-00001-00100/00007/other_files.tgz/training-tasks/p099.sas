begin_version
3
end_version
begin_metric
0
end_metric
70
begin_variable
var69
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var88
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins20)
NegatedAtom power_on(ins20)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var89
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var59
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





49 0
31 6
3 0
0
208
3
52 0
31 6
2 0
0
193
3
48 0
32 6
7 0
0
185
3
41 0
33 6
9 0
0
184
3
55 0
33 6
8 0
0
165
3
43 0
34 6
13 0
0
164
3
56 0
34 6
12 0
0
163
3
57 0
34 6
11 0
0
68
3
53 0
39 6
27 0
0
138
3
51 0
35 6
15 0
0
116
3
47 0
36 6
20 0
0
115
3
54 0
36 6
19 0
0
114
3
59 0
36 6
18 0
0
93
3
45 0
37 6
23 0
0
92
3
50 0
37 6
22 0
0
80
3
44 0
38 6
26 0
0
69
3
40 0
39 6
28 0
end_DTG
begin_DTG
0
15
0
66
3
53 0
39 5
27 0
0
67
3
40 0
39 5
28 0
0
79
3
44 0
38 5
26 0
0
91
3
45 0
37 5
23 0
0
110
3
59 0
36 5
18 0
0
112
3
54 0
36 5
19 0
0
113
3
47 0
36 5
20 0
0
135
3
51 0
35 5
15 0
0
137
3
46 0
35 5
16 0
0
158
3
57 0
34 5
11 0
0
160
3
56 0
34 5
12 0
0
162
3
43 0
34 5
13 0
0
204
3
52 0
31 5
2 0
0
207
3
42 0
31 5
4 0
0
223
3
58 0
30 5
1 0
end_DTG
begin_DTG
0
16
0
65
3
53 0
39 5
27 0
0
89
3
50 0
37 5
22 0
0
90
3
45 0
37 5
23 0
0
109
3
59 0
36 5
18 0
0
111
3
54 0
36 5
19 0
0
134
3
51 0
35 5
15 0
0
136
3
46 0
35 5
16 0
0
157
3
57 0
34 5
11 0
0
159
3
56 0
34 5
12 0
0
161
3
43 0
34 5
13 0
0
182
3
55 0
33 5
8 0
0
183
3
41 0
33 5
9 0
0
203
3
52 0
31 5
2 0
0
205
3
49 0
31 5
3 0
0
206
3
42 0
31 5
4 0
0
222
3
58 0
30 5
1 0
end_DTG
begin_DTG
0
15
0
63
3
53 0
39 2
27 0
0
64
3
40 0
39 2
28 0
0
78
3
44 0
38 2
26 0
0
88
3
45 0
37 2
23 0
0
106
3
59 0
36 2
18 0
0
107
3
54 0
36 2
19 0
0
108
3
47 0
36 2
20 0
0
132
3
51 0
35 2
15 0
0
133
3
46 0
35 2
16 0
0
154
3
57 0
34 2
11 0
0
155
3
56 0
34 2
12 0
0
156
3
43 0
34 2
13 0
0
201
3
52 0
31 2
2 0
0
202
3
42 0
31 2
4 0
0
221
3
58 0
30 2
1 0
end_DTG
begin_DTG
0
19
0
131
3
46 0
35 0
16 0
0
220
3
58 0
30 0
1 0
0
199
3
49 0
31 0
3 0
0
197
3
52 0
31 0
2 0
0
192
3
48 0
32 0
7 0
0
181
3
41 0
33 0
9 0
0
179
3
55 0
33 0
8 0
0
153
3
43 0
34 0
13 0
0
151
3
56 0
34 0
12 0
0
149
3
57 0
34 0
11 0
0
61
3
53 0
39 0
27 0
0
129
3
51 0
35 0
15 0
0
105
3
47 0
36 0
20 0
0
104
3
54 0
36 0
19 0
0
102
3
59 0
36 0
18 0
0
87
3
45 0
37 0
23 0
0
85
3
50 0
37 0
22 0
0
77
3
44 0
38 0
26 0
0
62
3
40 0
39 0
28 0
end_DTG
begin_DTG
0
16
0
60
3
53 0
39 0
27 0
0
84
3
50 0
37 0
22 0
0
86
3
45 0
37 0
23 0
0
101
3
59 0
36 0
18 0
0
103
3
54 0
36 0
19 0
0
128
3
51 0
35 0
15 0
0
130
3
46 0
35 0
16 0
0
148
3
57 0
34 0
11 0
0
150
3
56 0
34 0
12 0
0
152
3
43 0
34 0
13 0
0
178
3
55 0
33 0
8 0
0
180
3
41 0
33 0
9 0
0
196
3
52 0
31 0
2 0
0
198
3
49 0
31 0
3 0
0
200
3
42 0
31 0
4 0
0
219
3
58 0
30 0
1 0
end_DTG
begin_CG
2
58 1
1 1
12
58 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
0 1
12
52 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
5 1
9
49 1
69 1
68 1
66 1
64 1
62 1
61 1
60 1
5 1
8
42 1
69 1
67 1
66 1
65 1
63 1
61 1
5 1
6
52 1
49 1
42 1
2 1
3 1
4 1
2
48 1
7 1
6
48 1
68 1
64 1
62 1
60 1
6 1
9
55 1
69 1
68 1
66 1
64 1
62 1
61 1
60 1
10 1
9
41 1
69 1
68 1
66 1
64 1
62 1
61 1
60 1
10 1
4
55 1
41 1
8 1
9 1
12
57 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
14 1
12
56 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
14 1
12
43 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
14 1
6
57 1
56 1
43 1
11 1
12 1
13 1
12
51 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
17 1
12
46 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
17 1
4
51 1
46 1
15 1
16 1
12
59 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
21 1
12
54 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
21 1
9
47 1
68 1
67 1
65 1
64 1
63 1
62 1
60 1
21 1
6
59 1
54 1
47 1
18 1
19 1
20 1
9
50 1
69 1
68 1
66 1
64 1
62 1
61 1
60 1
24 1
12
45 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
24 1
4
50 1
45 1
22 1
23 1
2
44 1
26 1
9
44 1
68 1
67 1
65 1
64 1
63 1
62 1
60 1
25 1
12
53 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
29 1
9
40 1
68 1
67 1
65 1
64 1
63 1
62 1
60 1
29 1
4
53 1
40 1
27 1
28 1
11
58 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
13
52 1
49 1
42 1
69 3
68 2
67 2
66 3
65 2
64 2
63 2
62 2
61 3
60 2
5
48 1
68 1
64 1
62 1
60 1
9
55 1
41 1
69 2
68 2
66 2
64 2
62 2
61 2
60 2
13
57 1
56 1
43 1
69 3
68 3
67 3
66 3
65 3
64 3
63 3
62 3
61 3
60 3
12
51 1
46 1
69 2
68 2
67 2
66 2
65 2
64 2
63 2
62 2
61 2
60 2
13
59 1
54 1
47 1
69 2
68 3
67 3
66 2
65 3
64 3
63 3
62 3
61 2
60 3
12
50 1
45 1
69 2
68 2
67 1
66 2
65 1
64 2
63 1
62 2
61 2
60 2
8
44 1
68 1
67 1
65 1
64 1
63 1
62 1
60 1
12
53 1
40 1
69 1
68 2
67 2
66 1
65 2
64 2
63 2
62 2
61 1
60 2
7
68 1
67 1
65 1
64 1
63 1
62 1
60 1
7
69 1
68 1
66 1
64 1
62 1
61 1
60 1
6
69 1
67 1
66 1
65 1
63 1
61 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
7
68 1
67 1
65 1
64 1
63 1
62 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
7
68 1
67 1
65 1
64 1
63 1
62 1
60 1
4
68 1
64 1
62 1
60 1
7
69 1
68 1
66 1
64 1
62 1
61 1
60 1
7
69 1
68 1
66 1
64 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
7
69 1
68 1
66 1
64 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
10
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
0
0
0
0
0
0
0
0
0
0
end_CG
