begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var21
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var22
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var17
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var16
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var20
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var15
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var19
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var14
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var18
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var13
-1
5
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
end_variable
begin_variable
var12
-1
5
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
end_variable
begin_variable
var11
-1
5
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
end_variable
begin_variable
var10
-1
5
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
0
begin_state
1
1
0
0
1
0
1
0
1
2
1
1
0
1
1
1
1
1
1
end_state
begin_goal
4
10 4
11 1
12 2
18 0
end_goal
100
begin_operator
calibrate sat1 ins1 dir1
2
12 0
8 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir2
2
11 1
6 0
1
0 16 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir3
2
10 2
4 0
1
0 15 -1 0
0
end_operator
begin_operator
calibrate sat4 ins4 dir1
2
9 0
0 0
1
0 14 -1 0
0
end_operator
begin_operator
calibrate sat4 ins5 dir3
2
9 2
1 0
1
0 13 -1 0
0
end_operator
begin_operator
switch_off ins1 sat1
0
2
0 7 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins2 sat2
0
2
0 5 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 3 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins4 sat4
0
2
0 2 -1 0
0 0 0 1
0
end_operator
begin_operator
switch_off ins5 sat4
0
2
0 2 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_on ins1 sat1
0
3
0 17 -1 1
0 7 0 1
0 8 -1 0
0
end_operator
begin_operator
switch_on ins2 sat2
0
3
0 16 -1 1
0 5 0 1
0 6 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 15 -1 1
0 3 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins4 sat4
0
3
0 14 -1 1
0 2 0 1
0 0 -1 0
0
end_operator
begin_operator
switch_on ins5 sat4
0
3
0 13 -1 1
0 2 0 1
0 1 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins1 mod1
3
17 0
12 2
8 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat2 dir3 ins2 mod1
3
16 0
11 2
6 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat3 dir3 ins3 mod1
3
15 0
10 2
4 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat4 dir3 ins4 mod1
3
14 0
9 2
0 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat4 dir3 ins5 mod1
3
13 0
9 2
1 0
1
0 18 -1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
1
0 12 1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
1
0 12 2 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
1
0 12 3 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir5
0
1
0 12 4 0
0
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
1
0 12 0 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
1
0 12 2 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
1
0 12 3 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir5
0
1
0 12 4 1
0
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
1
0 12 0 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
1
0 12 1 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
1
0 12 3 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir5
0
1
0 12 4 2
0
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
1
0 12 0 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
1
0 12 1 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
1
0 12 2 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir5
0
1
0 12 4 3
0
end_operator
begin_operator
turn_to sat1 dir5 dir1
0
1
0 12 0 4
0
end_operator
begin_operator
turn_to sat1 dir5 dir2
0
1
0 12 1 4
0
end_operator
begin_operator
turn_to sat1 dir5 dir3
0
1
0 12 2 4
0
end_operator
begin_operator
turn_to sat1 dir5 dir4
0
1
0 12 3 4
0
end_operator
begin_operator
turn




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




urn_to sat3 dir4 dir5
0
1
0 10 4 3
0
end_operator
begin_operator
turn_to sat3 dir5 dir1
0
1
0 10 0 4
0
end_operator
begin_operator
turn_to sat3 dir5 dir2
0
1
0 10 1 4
0
end_operator
begin_operator
turn_to sat3 dir5 dir3
0
1
0 10 2 4
0
end_operator
begin_operator
turn_to sat3 dir5 dir4
0
1
0 10 3 4
0
end_operator
begin_operator
turn_to sat4 dir1 dir2
0
1
0 9 1 0
0
end_operator
begin_operator
turn_to sat4 dir1 dir3
0
1
0 9 2 0
0
end_operator
begin_operator
turn_to sat4 dir1 dir4
0
1
0 9 3 0
0
end_operator
begin_operator
turn_to sat4 dir1 dir5
0
1
0 9 4 0
0
end_operator
begin_operator
turn_to sat4 dir2 dir1
0
1
0 9 0 1
0
end_operator
begin_operator
turn_to sat4 dir2 dir3
0
1
0 9 2 1
0
end_operator
begin_operator
turn_to sat4 dir2 dir4
0
1
0 9 3 1
0
end_operator
begin_operator
turn_to sat4 dir2 dir5
0
1
0 9 4 1
0
end_operator
begin_operator
turn_to sat4 dir3 dir1
0
1
0 9 0 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir2
0
1
0 9 1 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir4
0
1
0 9 3 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir5
0
1
0 9 4 2
0
end_operator
begin_operator
turn_to sat4 dir4 dir1
0
1
0 9 0 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir2
0
1
0 9 1 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir3
0
1
0 9 2 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir5
0
1
0 9 4 3
0
end_operator
begin_operator
turn_to sat4 dir5 dir1
0
1
0 9 0 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir2
0
1
0 9 1 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir3
0
1
0 9 2 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir4
0
1
0 9 3 4
0
end_operator
0
begin_SG
switch 17
check 0
switch 12
check 0
check 0
check 0
switch 8
check 0
check 1
15
check 0
check 0
check 0
check 0
check 0
check 0
switch 16
check 0
switch 11
check 0
check 0
check 0
switch 6
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
check 0
switch 15
check 0
switch 10
check 0
check 0
check 0
switch 4
check 0
check 1
17
check 0
check 0
check 0
check 0
check 0
check 0
switch 14
check 0
switch 9
check 0
check 0
check 0
switch 0
check 0
check 1
18
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
switch 9
check 0
check 0
check 0
switch 1
check 0
check 1
19
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
switch 11
check 4
24
28
32
36
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
0
check 0
check 0
check 4
20
29
33
37
check 4
21
25
34
38
check 4
22
26
30
39
check 4
23
27
31
35
switch 11
check 0
check 4
44
48
52
56
switch 10
check 4
40
49
53
57
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
1
check 0
check 0
check 4
41
45
54
58
check 4
42
46
50
59
check 4
43
47
51
55
switch 10
check 0
check 4
64
68
72
76
check 4
60
69
73
77
switch 9
check 4
61
65
74
78
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
2
check 0
check 0
check 4
62
66
70
79
check 4
63
67
71
75
switch 9
check 0
switch 7
check 4
84
88
92
96
check 0
check 0
switch 0
check 0
check 1
3
check 0
check 0
check 4
80
89
93
97
switch 7
check 4
81
85
94
98
check 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
check 4
82
86
90
99
check 4
83
87
91
95
switch 7
check 0
check 1
10
check 0
switch 5
check 0
check 1
11
check 0
switch 3
check 0
check 1
12
check 0
switch 2
check 0
check 2
13
14
check 0
switch 8
check 0
check 1
5
check 0
switch 6
check 0
check 1
6
check 0
switch 4
check 0
check 1
7
check 0
switch 0
check 0
check 1
8
check 0
switch 1
check 0
check 1
9
check 0
check 0
end_SG
begin_DTG
1
1
8
0
1
0
13
1
2 0
end_DTG
begin_DTG
1
1
9
0
1
0
14
1
2 0
end_DTG
begin_DTG
1
1
13
0
2
0
8
1
0 0
0
9
1
1 0
end_DTG
begin_DTG
1
1
12
0
1
0
7
1
4 0
end_DTG
begin_DTG
1
1
7
0
1
0
12
1
3 0
end_DTG
begin_DTG
1
1
11
0
1
0
6
1
6 0
end_DTG
begin_DTG
1
1
6
0
1
0
11
1
5 0
end_DTG
begin_DTG
1
1
10
0
1
0
5
1
8 0
end_DTG
begin_DTG
1
1
5
0
1
0
10
1
7 0
end_DTG
begin_DTG
4
1
84
0
2
88
0
3
92
0
4
96
0
4
0
80
0
2
89
0
3
93
0
4
97
0
4
0
81
0
1
85
0
3
94
0
4
98
0
4
0
82
0
1
86
0
2
90
0
4
99
0
4
0
83
0
1
87
0
2
91
0
3
95
0
end_DTG
begin_DTG
4
1
64
0
2
68
0
3
72
0
4
76
0
4
0
60
0
2
69
0
3
73
0
4
77
0
4
0
61
0
1
65
0
3
74
0
4
78
0
4
0
62
0
1
66
0
2
70
0
4
79
0
4
0
63
0
1
67
0
2
71
0
3
75
0
end_DTG
begin_DTG
4
1
44
0
2
48
0
3
52
0
4
56
0
4
0
40
0
2
49
0
3
53
0
4
57
0
4
0
41
0
1
45
0
3
54
0
4
58
0
4
0
42
0
1
46
0
2
50
0
4
59
0
4
0
43
0
1
47
0
2
51
0
3
55
0
end_DTG
begin_DTG
4
1
24
0
2
28
0
3
32
0
4
36
0
4
0
20
0
2
29
0
3
33
0
4
37
0
4
0
21
0
1
25
0
3
34
0
4
38
0
4
0
22
0
1
26
0
2
30
0
4
39
0
4
0
23
0
1
27
0
2
31
0
3
35
0
end_DTG
begin_DTG
1
1
14
1
2 0
1
0
4
2
9 2
1 0
end_DTG
begin_DTG
1
1
13
1
2 0
1
0
3
2
9 0
0 0
end_DTG
begin_DTG
1
1
12
1
3 0
1
0
2
2
10 2
4 0
end_DTG
begin_DTG
1
1
11
1
5 0
1
0
1
2
11 1
6 0
end_DTG
begin_DTG
1
1
10
1
7 0
1
0
0
2
12 0
8 0
end_DTG
begin_DTG
0
5
0
15
3
17 0
12 2
8 0
0
16
3
16 0
11 2
6 0
0
17
3
15 0
10 2
4 0
0
18
3
14 0
9 2
0 0
0
19
3
13 0
9 2
1 0
end_DTG
begin_CG
3
14 1
18 1
2 1
3
13 1
18 1
2 1
4
14 1
13 1
0 1
1 1
2
15 1
4 1
3
15 1
18 1
3 1
2
16 1
6 1
3
16 1
18 1
5 1
2
17 1
8 1
3
17 1
18 1
7 1
3
14 1
13 1
18 2
2
15 1
18 1
2
16 1
18 1
2
17 1
18 1
1
18 1
1
18 1
1
18 1
1
18 1
1
18 1
0
end_CG
