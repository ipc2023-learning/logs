begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var19
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var20
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var18
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var22
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var21
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var25
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var26
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var17
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var23
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var16
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var15
-1
5
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
end_variable
begin_variable
var14
-1
5
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
end_variable
begin_variable
var13
-1
5
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
end_variable
begin_variable
var12
-1
5
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
0
begin_state
0
1
0
1
1
1
1
0
1
1
0
2
2
3
3
1
1
1
1
1
1
1
1
end_state
begin_goal
2
14 4
22 0
end_goal
108
begin_operator
calibrate sat1 ins4 dir1
2
14 0
8 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat1 ins5 dir1
2
14 0
9 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir1
2
13 0
4 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat2 ins6 dir2
2
13 1
5 0
1
0 16 -1 0
0
end_operator
begin_operator
calibrate sat2 ins7 dir3
2
13 2
6 0
1
0 15 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir4
2
12 3
3 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat4 ins1 dir4
2
11 3
1 0
1
0 21 -1 0
0
end_operator
begin_operator
switch_off ins1 sat4
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins2 sat2
0
2
0 7 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 2 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins4 sat1
0
2
0 10 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins5 sat1
0
2
0 10 -1 0
0 9 0 1
0
end_operator
begin_operator
switch_off ins6 sat2
0
2
0 7 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_off ins7 sat2
0
2
0 7 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_on ins1 sat4
0
3
0 21 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins2 sat2
0
3
0 20 -1 1
0 7 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 19 -1 1
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins4 sat1
0
3
0 18 -1 1
0 10 0 1
0 8 -1 0
0
end_operator
begin_operator
switch_on ins5 sat1
0
3
0 17 -1 1
0 10 0 1
0 9 -1 0
0
end_operator
begin_operator
switch_on ins6 sat2
0
3
0 16 -1 1
0 7 0 1
0 5 -1 0
0
end_operator
begin_operator
switch_on ins7 sat2
0
3
0 15 -1 1
0 7 0 1
0 6 -1 0
0
end_operator
begin_operator
take_image sat1 dir5 ins4 mod1
3
18 0
14 4
8 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat1 dir5 ins5 mod1
3
17 0
14 4
9 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat2 dir5 ins2 mod1
3
20 0
13 4
4 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat2 dir5 ins6 mod1
3
16 0
13 4
5 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat2 dir5 ins7 mod1
3
15 0
13 4
6 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat3 dir5 ins3 mod1
3
19 0
12 4
3 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat4 dir5 ins1 mod1
3
21 0
11 4
1 0
1
0 22 -1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
1
0 14 1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
1
0 14 2 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
1
0 14 3 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir5
0
1
0 14 4 0
0
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
1
0 14 0 1
0
end_operator
begin_operat




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




rn_to sat4 dir3 dir1
0
1
0 11 0 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir2
0
1
0 11 1 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir4
0
1
0 11 3 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir5
0
1
0 11 4 2
0
end_operator
begin_operator
turn_to sat4 dir4 dir1
0
1
0 11 0 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir2
0
1
0 11 1 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir3
0
1
0 11 2 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir5
0
1
0 11 4 3
0
end_operator
begin_operator
turn_to sat4 dir5 dir1
0
1
0 11 0 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir2
0
1
0 11 1 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir3
0
1
0 11 2 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir4
0
1
0 11 3 4
0
end_operator
0
begin_SG
switch 21
check 0
switch 11
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
27
check 0
check 0
check 0
check 0
switch 20
check 0
switch 13
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
23
check 0
check 0
check 0
check 0
switch 19
check 0
switch 12
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
26
check 0
check 0
check 0
check 0
switch 18
check 0
switch 14
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
21
check 0
check 0
check 0
check 0
switch 17
check 0
switch 14
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
22
check 0
check 0
check 0
check 0
switch 16
check 0
switch 13
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
24
check 0
check 0
check 0
check 0
switch 15
check 0
switch 13
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
25
check 0
check 0
check 0
check 0
switch 14
check 0
switch 13
check 4
32
36
40
44
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
0
check 0
switch 9
check 0
check 1
1
check 0
check 0
check 4
28
37
41
45
check 4
29
33
42
46
check 4
30
34
38
47
check 4
31
35
39
43
switch 13
check 0
switch 12
check 4
52
56
60
64
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
2
check 0
check 0
switch 12
check 4
48
57
61
65
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
3
check 0
check 0
switch 12
check 4
49
53
62
66
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
4
check 0
check 0
check 4
50
54
58
67
check 4
51
55
59
63
switch 12
check 0
check 4
72
76
80
84
check 4
68
77
81
85
check 4
69
73
82
86
switch 11
check 4
70
74
78
87
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
5
check 0
check 0
check 4
71
75
79
83
switch 11
check 0
check 4
92
96
100
104
check 4
88
97
101
105
check 4
89
93
102
106
switch 10
check 4
90
94
98
107
check 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 4
91
95
99
103
switch 10
check 0
check 2
17
18
check 0
switch 7
check 0
check 3
15
19
20
check 0
switch 2
check 0
check 1
16
check 0
switch 0
check 0
check 1
14
check 0
switch 1
check 0
check 1
7
check 0
switch 4
check 0
check 1
8
check 0
switch 3
check 0
check 1
9
check 0
switch 8
check 0
check 1
10
check 0
switch 9
check 0
check 1
11
check 0
switch 5
check 0
check 1
12
check 0
switch 6
check 0
check 1
13
check 0
check 0
end_SG
begin_DTG
1
1
14
0
1
0
7
1
1 0
end_DTG
begin_DTG
1
1
7
0
1
0
14
1
0 0
end_DTG
begin_DTG
1
1
16
0
1
0
9
1
3 0
end_DTG
begin_DTG
1
1
9
0
1
0
16
1
2 0
end_DTG
begin_DTG
1
1
8
0
1
0
15
1
7 0
end_DTG
begin_DTG
1
1
12
0
1
0
19
1
7 0
end_DTG
begin_DTG
1
1
13
0
1
0
20
1
7 0
end_DTG
begin_DTG
1
1
15
0
3
0
8
1
4 0
0
12
1
5 0
0
13
1
6 0
end_DTG
begin_DTG
1
1
10
0
1
0
17
1
10 0
end_DTG
begin_DTG
1
1
11
0
1
0
18
1
10 0
end_DTG
begin_DTG
1
1
17
0
2
0
10
1
8 0
0
11
1
9 0
end_DTG
begin_DTG
4
1
92
0
2
96
0
3
100
0
4
104
0
4
0
88
0
2
97
0
3
101
0
4
105
0
4
0
89
0
1
93
0
3
102
0
4
106
0
4
0
90
0
1
94
0
2
98
0
4
107
0
4
0
91
0
1
95
0
2
99
0
3
103
0
end_DTG
begin_DTG
4
1
72
0
2
76
0
3
80
0
4
84
0
4
0
68
0
2
77
0
3
81
0
4
85
0
4
0
69
0
1
73
0
3
82
0
4
86
0
4
0
70
0
1
74
0
2
78
0
4
87
0
4
0
71
0
1
75
0
2
79
0
3
83
0
end_DTG
begin_DTG
4
1
52
0
2
56
0
3
60
0
4
64
0
4
0
48
0
2
57
0
3
61
0
4
65
0
4
0
49
0
1
53
0
3
62
0
4
66
0
4
0
50
0
1
54
0
2
58
0
4
67
0
4
0
51
0
1
55
0
2
59
0
3
63
0
end_DTG
begin_DTG
4
1
32
0
2
36
0
3
40
0
4
44
0
4
0
28
0
2
37
0
3
41
0
4
45
0
4
0
29
0
1
33
0
3
42
0
4
46
0
4
0
30
0
1
34
0
2
38
0
4
47
0
4
0
31
0
1
35
0
2
39
0
3
43
0
end_DTG
begin_DTG
1
1
20
1
7 0
1
0
4
2
13 2
6 0
end_DTG
begin_DTG
1
1
19
1
7 0
1
0
3
2
13 1
5 0
end_DTG
begin_DTG
1
1
18
1
10 0
1
0
1
2
14 0
9 0
end_DTG
begin_DTG
1
1
17
1
10 0
1
0
0
2
14 0
8 0
end_DTG
begin_DTG
1
1
16
1
2 0
1
0
5
2
12 3
3 0
end_DTG
begin_DTG
1
1
15
1
7 0
1
0
2
2
13 0
4 0
end_DTG
begin_DTG
1
1
14
1
0 0
1
0
6
2
11 3
1 0
end_DTG
begin_DTG
0
7
0
21
3
18 0
14 4
8 0
0
22
3
17 0
14 4
9 0
0
23
3
20 0
13 4
4 0
0
24
3
16 0
13 4
5 0
0
25
3
15 0
13 4
6 0
0
26
3
19 0
12 4
3 0
0
27
3
21 0
11 4
1 0
end_DTG
begin_CG
2
21 1
1 1
3
21 1
22 1
0 1
2
19 1
3 1
3
19 1
22 1
2 1
3
20 1
22 1
7 1
3
16 1
22 1
7 1
3
15 1
22 1
7 1
6
20 1
16 1
15 1
4 1
5 1
6 1
3
18 1
22 1
10 1
3
17 1
22 1
10 1
4
18 1
17 1
8 1
9 1
2
21 1
22 1
2
19 1
22 1
4
20 1
16 1
15 1
22 3
3
18 1
17 1
22 2
1
22 1
1
22 1
1
22 1
1
22 1
1
22 1
1
22 1
1
22 1
0
end_CG
