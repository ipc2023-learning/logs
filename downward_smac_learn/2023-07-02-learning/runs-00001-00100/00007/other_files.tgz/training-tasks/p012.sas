begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var12
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var13
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var11
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var15
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var10
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var14
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var9
-1
4
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
end_variable
begin_variable
var8
-1
4
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
end_variable
begin_variable
var7
-1
4
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var6
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var4
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
0
begin_state
0
1
0
1
0
1
3
3
2
1
1
1
1
1
end_state
begin_goal
4
6 2
8 0
12 0
13 0
end_goal
51
begin_operator
calibrate sat1 ins2 dir1
2
8 0
5 0
1
0 10 -1 0
0
end_operator
begin_operator
calibrate sat2 ins3 dir3
2
7 2
3 0
1
0 9 -1 0
0
end_operator
begin_operator
calibrate sat3 ins1 dir3
2
6 2
1 0
1
0 11 -1 0
0
end_operator
begin_operator
switch_off ins1 sat3
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins2 sat1
0
2
0 4 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_off ins3 sat2
0
2
0 2 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_on ins1 sat3
0
3
0 11 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins2 sat1
0
3
0 10 -1 1
0 4 0 1
0 5 -1 0
0
end_operator
begin_operator
switch_on ins3 sat2
0
3
0 9 -1 1
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins2 mod1
3
10 0
8 1
5 0
1
0 13 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins2 mod1
3
10 0
8 3
5 0
1
0 12 -1 0
0
end_operator
begin_operator
take_image sat2 dir2 ins3 mod1
3
9 0
7 1
3 0
1
0 13 -1 0
0
end_operator
begin_operator
take_image sat2 dir4 ins3 mod1
3
9 0
7 3
3 0
1
0 12 -1 0
0
end_operator
begin_operator
take_image sat3 dir2 ins1 mod1
3
11 0
6 1
1 0
1
0 13 -1 0
0
end_operator
begin_operator
take_image sat3 dir4 ins1 mod1
3
11 0
6 3
1 0
1
0 12 -1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
1
0 8 1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
1
0 8 2 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
1
0 8 3 0
0
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
1
0 8 0 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
1
0 8 2 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
1
0 8 3 1
0
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
1
0 8 0 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
1
0 8 1 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
1
0 8 3 2
0
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
1
0 8 0 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
1
0 8 1 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
1
0 8 2 3
0
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
1
0 7 1 0
0
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
1
0 7 2 0
0
end_operator
begin_operator
turn_to sat2 dir1 dir4
0
1
0 7 3 0
0
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
1
0 7 0 1
0
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
1
0 7 2 1
0
end_operator
begin_operator
turn_to sat2 dir2 dir4
0
1
0 7 3 1
0
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
1
0 7 0 2
0
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
1
0 7 1 2
0
end_operator
begin_operator
turn_to sat2 dir3 dir4
0
1
0 7 3 2
0
end_operator
begin_operator
turn_to sat2 dir4 dir1
0
1
0 7 0 3
0
end_operator
begin_operator
turn_to sat2 dir4 dir2
0
1
0 7 1 3
0
end_operator
begin_operator
turn_to sat2 dir4 dir3
0
1
0 7 2 3
0
end_operator
begin_operator
turn_to sat3 dir1 dir2
0
1
0 6 1 0
0
end_operator
begin_operator
turn_to sat3 dir1 dir3
0
1
0 6 2 0
0
end_operator
begin_operator
turn_to sat3 dir1 dir4
0
1
0 6 3 0
0
end_operator
begin_operator
turn_to sat3 dir2 dir1
0
1
0 6 0 1
0
end_operator
begin_operator
turn_to sat3 dir2 dir3
0
1
0 6 2 1
0
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
1
0 6 3 1
0
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
1
0 6 0 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
1
0 6 1 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
1
0 6 3 2
0
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
1
0 6 0 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
1
0 6 1 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
1
0 6 2 3
0
end_operator
0
begin_SG
switch 11
check 0
switch 6
check 0
check 0
switch 1
check 0
check 1
13
check 0
check 0
check 0
switch 1
check 0
check 1
14
check 0
check 0
check 0
check 0
switch 10
check 0
switch 8
check 0
check 0
switch 5
check 0
check 1
9
check 0
check 0
check 0
switch 5
check 0
check 1
10
check 0
check 0
check 0
check 0
switch 9
check 0
switch 7
check 0
check 0
switch 3
check 0
check 1
11
check 0
check 0
check 0
switch 3
check 0
check 1
12
check 0
check 0
check 0
check 0
switch 8
check 0
switch 7
check 3
18
21
24
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
0
check 0
check 0
check 3
15
22
25
check 3
16
19
26
check 3
17
20
23
switch 7
check 0
check 3
30
33
36
check 3
27
34
37
switch 6
check 3
28
31
38
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
1
check 0
check 0
check 3
29
32
35
switch 6
check 0
check 3
42
45
48
check 3
39
46
49
switch 4
check 3
40
43
50
check 0
check 0
switch 1
check 0
check 1
2
check 0
check 0
check 3
41
44
47
switch 4
check 0
check 1
7
check 0
switch 2
check 0
check 1
8
check 0
switch 0
check 0
check 1
6
check 0
switch 1
check 0
check 1
3
check 0
switch 5
check 0
check 1
4
check 0
switch 3
check 0
check 1
5
check 0
check 0
end_SG
begin_DTG
1
1
6
0
1
0
3
1
1 0
end_DTG
begin_DTG
1
1
3
0
1
0
6
1
0 0
end_DTG
begin_DTG
1
1
8
0
1
0
5
1
3 0
end_DTG
begin_DTG
1
1
5
0
1
0
8
1
2 0
end_DTG
begin_DTG
1
1
7
0
1
0
4
1
5 0
end_DTG
begin_DTG
1
1
4
0
1
0
7
1
4 0
end_DTG
begin_DTG
3
1
42
0
2
45
0
3
48
0
3
0
39
0
2
46
0
3
49
0
3
0
40
0
1
43
0
3
50
0
3
0
41
0
1
44
0
2
47
0
end_DTG
begin_DTG
3
1
30
0
2
33
0
3
36
0
3
0
27
0
2
34
0
3
37
0
3
0
28
0
1
31
0
3
38
0
3
0
29
0
1
32
0
2
35
0
end_DTG
begin_DTG
3
1
18
0
2
21
0
3
24
0
3
0
15
0
2
22
0
3
25
0
3
0
16
0
1
19
0
3
26
0
3
0
17
0
1
20
0
2
23
0
end_DTG
begin_DTG
1
1
8
1
2 0
1
0
1
2
7 2
3 0
end_DTG
begin_DTG
1
1
7
1
4 0
1
0
0
2
8 0
5 0
end_DTG
begin_DTG
1
1
6
1
0 0
1
0
2
2
6 2
1 0
end_DTG
begin_DTG
0
3
0
10
3
10 0
8 3
5 0
0
12
3
9 0
7 3
3 0
0
14
3
11 0
6 3
1 0
end_DTG
begin_DTG
0
3
0
9
3
10 0
8 1
5 0
0
11
3
9 0
7 1
3 0
0
13
3
11 0
6 1
1 0
end_DTG
begin_CG
2
11 1
1 1
4
11 1
13 1
12 1
0 1
2
9 1
3 1
4
9 1
13 1
12 1
2 1
2
10 1
5 1
4
10 1
13 1
12 1
4 1
3
11 1
13 1
12 1
3
9 1
13 1
12 1
3
10 1
13 1
12 1
2
13 1
12 1
2
13 1
12 1
2
13 1
12 1
0
0
end_CG
