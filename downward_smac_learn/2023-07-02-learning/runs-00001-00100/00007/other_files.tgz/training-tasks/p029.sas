begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var18
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var20
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var17
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var19
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var22
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var23
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var16
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var21
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var15
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var14
-1
5
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
end_variable
begin_variable
var13
-1
5
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
end_variable
begin_variable
var12
-1
5
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
end_variable
begin_variable
var11
-1
5
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
0
begin_state
0
1
0
1
1
1
0
1
1
0
1
0
1
4
1
1
1
1
1
1
1
1
1
end_state
begin_goal
5
11 2
12 1
20 0
21 0
22 0
end_goal
116
begin_operator
calibrate sat1 ins3 dir3
2
13 2
7 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat1 ins6 dir2
2
13 1
8 0
1
0 14 -1 0
0
end_operator
begin_operator
calibrate sat2 ins4 dir2
2
12 1
4 0
1
0 16 -1 0
0
end_operator
begin_operator
calibrate sat2 ins5 dir5
2
12 4
5 0
1
0 15 -1 0
0
end_operator
begin_operator
calibrate sat3 ins1 dir4
2
11 3
3 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat4 ins2 dir3
2
10 2
1 0
1
0 18 -1 0
0
end_operator
begin_operator
switch_off ins1 sat3
0
2
0 2 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins2 sat4
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins3 sat1
0
2
0 9 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins4 sat2
0
2
0 6 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins5 sat2
0
2
0 6 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_off ins6 sat1
0
2
0 9 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_on ins1 sat3
0
3
0 19 -1 1
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins2 sat4
0
3
0 18 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins3 sat1
0
3
0 17 -1 1
0 9 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins4 sat2
0
3
0 16 -1 1
0 6 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins5 sat2
0
3
0 15 -1 1
0 6 0 1
0 5 -1 0
0
end_operator
begin_operator
switch_on ins6 sat1
0
3
0 14 -1 1
0 9 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins3 mod1
3
17 0
13 1
7 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins6 mod1
3
14 0
13 1
8 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins3 mod1
3
17 0
13 2
7 0
1
0 21 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins6 mod1
3
14 0
13 2
8 0
1
0 21 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins3 mod1
3
17 0
13 3
7 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins6 mod1
3
14 0
13 3
8 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat2 dir2 ins4 mod1
3
16 0
12 1
4 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat2 dir2 ins5 mod1
3
15 0
12 1
5 0
1
0 22 -1 0
0
end_operator
begin_operator
take_image sat2 dir3 ins4 mod1
3
16 0
12 2
4 0
1
0 21 -1 0
0
end_operator
begin_operator
take_image sat2 dir3 ins5 mod1
3
15 0
12 2
5 0
1
0 21 -1 0
0
end_operator
begin_operator
take_image sat2 dir4 ins4 mod1
3
16 0
12 3
4 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat2 dir4 ins5 mod1
3
15 0
12 3
5 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat3 dir2 ins1 mod1
3
19 0
11 1
3 0
1
0 22 -1 0
0
end_operator
be




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 dir5 dir1
0
1
0 10 0 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir2
0
1
0 10 1 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir3
0
1
0 10 2 4
0
end_operator
begin_operator
turn_to sat4 dir5 dir4
0
1
0 10 3 4
0
end_operator
0
begin_SG
switch 19
check 0
switch 11
check 0
check 0
switch 3
check 0
check 1
30
check 0
check 0
switch 3
check 0
check 1
31
check 0
check 0
switch 3
check 0
check 1
32
check 0
check 0
check 0
check 0
check 0
switch 18
check 0
switch 10
check 0
check 0
switch 1
check 0
check 1
33
check 0
check 0
switch 1
check 0
check 1
34
check 0
check 0
switch 1
check 0
check 1
35
check 0
check 0
check 0
check 0
check 0
switch 17
check 0
switch 13
check 0
check 0
switch 7
check 0
check 1
18
check 0
check 0
switch 7
check 0
check 1
20
check 0
check 0
switch 7
check 0
check 1
22
check 0
check 0
check 0
check 0
check 0
switch 16
check 0
switch 12
check 0
check 0
switch 4
check 0
check 1
24
check 0
check 0
switch 4
check 0
check 1
26
check 0
check 0
switch 4
check 0
check 1
28
check 0
check 0
check 0
check 0
check 0
switch 15
check 0
switch 12
check 0
check 0
switch 5
check 0
check 1
25
check 0
check 0
switch 5
check 0
check 1
27
check 0
check 0
switch 5
check 0
check 1
29
check 0
check 0
check 0
check 0
check 0
switch 14
check 0
switch 13
check 0
check 0
switch 8
check 0
check 1
19
check 0
check 0
switch 8
check 0
check 1
21
check 0
check 0
switch 8
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 4
40
44
48
52
switch 12
check 4
36
45
49
53
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
1
check 0
check 0
switch 12
check 4
37
41
50
54
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
0
check 0
check 0
check 4
38
42
46
55
check 4
39
43
47
51
switch 12
check 0
check 4
60
64
68
72
switch 11
check 4
56
65
69
73
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
2
check 0
check 0
check 4
57
61
70
74
check 4
58
62
66
75
switch 11
check 4
59
63
67
71
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
3
check 0
check 0
switch 11
check 0
check 4
80
84
88
92
check 4
76
85
89
93
check 4
77
81
90
94
switch 10
check 4
78
82
86
95
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
4
check 0
check 0
check 4
79
83
87
91
switch 10
check 0
check 4
100
104
108
112
check 4
96
105
109
113
switch 9
check 4
97
101
110
114
check 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
check 4
98
102
106
115
check 4
99
103
107
111
switch 9
check 0
check 2
14
17
check 0
switch 6
check 0
check 2
15
16
check 0
switch 2
check 0
check 1
12
check 0
switch 0
check 0
check 1
13
check 0
switch 3
check 0
check 1
6
check 0
switch 1
check 0
check 1
7
check 0
switch 7
check 0
check 1
8
check 0
switch 4
check 0
check 1
9
check 0
switch 5
check 0
check 1
10
check 0
switch 8
check 0
check 1
11
check 0
check 0
end_SG
begin_DTG
1
1
13
0
1
0
7
1
1 0
end_DTG
begin_DTG
1
1
7
0
1
0
13
1
0 0
end_DTG
begin_DTG
1
1
12
0
1
0
6
1
3 0
end_DTG
begin_DTG
1
1
6
0
1
0
12
1
2 0
end_DTG
begin_DTG
1
1
9
0
1
0
15
1
6 0
end_DTG
begin_DTG
1
1
10
0
1
0
16
1
6 0
end_DTG
begin_DTG
1
1
15
0
2
0
9
1
4 0
0
10
1
5 0
end_DTG
begin_DTG
1
1
8
0
1
0
14
1
9 0
end_DTG
begin_DTG
1
1
11
0
1
0
17
1
9 0
end_DTG
begin_DTG
1
1
14
0
2
0
8
1
7 0
0
11
1
8 0
end_DTG
begin_DTG
4
1
100
0
2
104
0
3
108
0
4
112
0
4
0
96
0
2
105
0
3
109
0
4
113
0
4
0
97
0
1
101
0
3
110
0
4
114
0
4
0
98
0
1
102
0
2
106
0
4
115
0
4
0
99
0
1
103
0
2
107
0
3
111
0
end_DTG
begin_DTG
4
1
80
0
2
84
0
3
88
0
4
92
0
4
0
76
0
2
85
0
3
89
0
4
93
0
4
0
77
0
1
81
0
3
90
0
4
94
0
4
0
78
0
1
82
0
2
86
0
4
95
0
4
0
79
0
1
83
0
2
87
0
3
91
0
end_DTG
begin_DTG
4
1
60
0
2
64
0
3
68
0
4
72
0
4
0
56
0
2
65
0
3
69
0
4
73
0
4
0
57
0
1
61
0
3
70
0
4
74
0
4
0
58
0
1
62
0
2
66
0
4
75
0
4
0
59
0
1
63
0
2
67
0
3
71
0
end_DTG
begin_DTG
4
1
40
0
2
44
0
3
48
0
4
52
0
4
0
36
0
2
45
0
3
49
0
4
53
0
4
0
37
0
1
41
0
3
50
0
4
54
0
4
0
38
0
1
42
0
2
46
0
4
55
0
4
0
39
0
1
43
0
2
47
0
3
51
0
end_DTG
begin_DTG
1
1
17
1
9 0
1
0
1
2
13 1
8 0
end_DTG
begin_DTG
1
1
16
1
6 0
1
0
3
2
12 4
5 0
end_DTG
begin_DTG
1
1
15
1
6 0
1
0
2
2
12 1
4 0
end_DTG
begin_DTG
1
1
14
1
9 0
1
0
0
2
13 2
7 0
end_DTG
begin_DTG
1
1
13
1
0 0
1
0
5
2
10 2
1 0
end_DTG
begin_DTG
1
1
12
1
2 0
1
0
4
2
11 3
3 0
end_DTG
begin_DTG
0
6
0
22
3
17 0
13 3
7 0
0
23
3
14 0
13 3
8 0
0
28
3
16 0
12 3
4 0
0
29
3
15 0
12 3
5 0
0
32
3
19 0
11 3
3 0
0
35
3
18 0
10 3
1 0
end_DTG
begin_DTG
0
6
0
20
3
17 0
13 2
7 0
0
21
3
14 0
13 2
8 0
0
26
3
16 0
12 2
4 0
0
27
3
15 0
12 2
5 0
0
31
3
19 0
11 2
3 0
0
34
3
18 0
10 2
1 0
end_DTG
begin_DTG
0
6
0
18
3
17 0
13 1
7 0
0
19
3
14 0
13 1
8 0
0
24
3
16 0
12 1
4 0
0
25
3
15 0
12 1
5 0
0
30
3
19 0
11 1
3 0
0
33
3
18 0
10 1
1 0
end_DTG
begin_CG
2
18 1
1 1
5
18 1
22 1
21 1
20 1
0 1
2
19 1
3 1
5
19 1
22 1
21 1
20 1
2 1
5
16 1
22 1
21 1
20 1
6 1
5
15 1
22 1
21 1
20 1
6 1
4
16 1
15 1
4 1
5 1
5
17 1
22 1
21 1
20 1
9 1
5
14 1
22 1
21 1
20 1
9 1
4
17 1
14 1
7 1
8 1
4
18 1
22 1
21 1
20 1
4
19 1
22 1
21 1
20 1
5
16 1
15 1
22 2
21 2
20 2
5
17 1
14 1
22 2
21 2
20 2
3
22 1
21 1
20 1
3
22 1
21 1
20 1
3
22 1
21 1
20 1
3
22 1
21 1
20 1
3
22 1
21 1
20 1
3
22 1
21 1
20 1
0
0
0
end_CG
