begin_version
3
end_version
begin_metric
0
end_metric
43
begin_variable
var65
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var49
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var48
-1
10
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir10)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins18)
NegatedAtom calibrated(ins18)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins17)
NegatedAtom calibrated(ins17)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins16)
NegatedAtom calibrated(in




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8
486
0
9
495
0
9
0
414
0
2
433
0
3
442
0
4
451
0
5
460
0
6
469
0
7
478
0
8
487
0
9
496
0
9
0
415
0
1
424
0
3
443
0
4
452
0
5
461
0
6
470
0
7
479
0
8
488
0
9
497
0
9
0
416
0
1
425
0
2
434
0
4
453
0
5
462
0
6
471
0
7
480
0
8
489
0
9
498
0
9
0
417
0
1
426
0
2
435
0
3
444
0
5
463
0
6
472
0
7
481
0
8
490
0
9
499
0
9
0
418
0
1
427
0
2
436
0
3
445
0
4
454
0
6
473
0
7
482
0
8
491
0
9
500
0
9
0
419
0
1
428
0
2
437
0
3
446
0
4
455
0
5
464
0
7
483
0
8
492
0
9
501
0
9
0
420
0
1
429
0
2
438
0
3
447
0
4
456
0
5
465
0
6
474
0
8
493
0
9
502
0
9
0
421
0
1
430
0
2
439
0
3
448
0
4
457
0
5
466
0
6
475
0
7
484
0
9
503
0
9
0
422
0
1
431
0
2
440
0
3
449
0
4
458
0
5
467
0
6
476
0
7
485
0
8
494
0
end_DTG
begin_DTG
9
1
333
0
2
342
0
3
351
0
4
360
0
5
369
0
6
378
0
7
387
0
8
396
0
9
405
0
9
0
324
0
2
343
0
3
352
0
4
361
0
5
370
0
6
379
0
7
388
0
8
397
0
9
406
0
9
0
325
0
1
334
0
3
353
0
4
362
0
5
371
0
6
380
0
7
389
0
8
398
0
9
407
0
9
0
326
0
1
335
0
2
344
0
4
363
0
5
372
0
6
381
0
7
390
0
8
399
0
9
408
0
9
0
327
0
1
336
0
2
345
0
3
354
0
5
373
0
6
382
0
7
391
0
8
400
0
9
409
0
9
0
328
0
1
337
0
2
346
0
3
355
0
4
364
0
6
383
0
7
392
0
8
401
0
9
410
0
9
0
329
0
1
338
0
2
347
0
3
356
0
4
365
0
5
374
0
7
393
0
8
402
0
9
411
0
9
0
330
0
1
339
0
2
348
0
3
357
0
4
366
0
5
375
0
6
384
0
8
403
0
9
412
0
9
0
331
0
1
340
0
2
349
0
3
358
0
4
367
0
5
376
0
6
385
0
7
394
0
9
413
0
9
0
332
0
1
341
0
2
350
0
3
359
0
4
368
0
5
377
0
6
386
0
7
395
0
8
404
0
end_DTG
begin_DTG
9
1
243
0
2
252
0
3
261
0
4
270
0
5
279
0
6
288
0
7
297
0
8
306
0
9
315
0
9
0
234
0
2
253
0
3
262
0
4
271
0
5
280
0
6
289
0
7
298
0
8
307
0
9
316
0
9
0
235
0
1
244
0
3
263
0
4
272
0
5
281
0
6
290
0
7
299
0
8
308
0
9
317
0
9
0
236
0
1
245
0
2
254
0
4
273
0
5
282
0
6
291
0
7
300
0
8
309
0
9
318
0
9
0
237
0
1
246
0
2
255
0
3
264
0
5
283
0
6
292
0
7
301
0
8
310
0
9
319
0
9
0
238
0
1
247
0
2
256
0
3
265
0
4
274
0
6
293
0
7
302
0
8
311
0
9
320
0
9
0
239
0
1
248
0
2
257
0
3
266
0
4
275
0
5
284
0
7
303
0
8
312
0
9
321
0
9
0
240
0
1
249
0
2
258
0
3
267
0
4
276
0
5
285
0
6
294
0
8
313
0
9
322
0
9
0
241
0
1
250
0
2
259
0
3
268
0
4
277
0
5
286
0
6
295
0
7
304
0
9
323
0
9
0
242
0
1
251
0
2
260
0
3
269
0
4
278
0
5
287
0
6
296
0
7
305
0
8
314
0
end_DTG
begin_DTG
9
1
153
0
2
162
0
3
171
0
4
180
0
5
189
0
6
198
0
7
207
0
8
216
0
9
225
0
9
0
144
0
2
163
0
3
172
0
4
181
0
5
190
0
6
199
0
7
208
0
8
217
0
9
226
0
9
0
145
0
1
154
0
3
173
0
4
182
0
5
191
0
6
200
0
7
209
0
8
218
0
9
227
0
9
0
146
0
1
155
0
2
164
0
4
183
0
5
192
0
6
201
0
7
210
0
8
219
0
9
228
0
9
0
147
0
1
156
0
2
165
0
3
174
0
5
193
0
6
202
0
7
211
0
8
220
0
9
229
0
9
0
148
0
1
157
0
2
166
0
3
175
0
4
184
0
6
203
0
7
212
0
8
221
0
9
230
0
9
0
149
0
1
158
0
2
167
0
3
176
0
4
185
0
5
194
0
7
213
0
8
222
0
9
231
0
9
0
150
0
1
159
0
2
168
0
3
177
0
4
186
0
5
195
0
6
204
0
8
223
0
9
232
0
9
0
151
0
1
160
0
2
169
0
3
178
0
4
187
0
5
196
0
6
205
0
7
214
0
9
233
0
9
0
152
0
1
161
0
2
170
0
3
179
0
4
188
0
5
197
0
6
206
0
7
215
0
8
224
0
end_DTG
begin_DTG
9
1
63
0
2
72
0
3
81
0
4
90
0
5
99
0
6
108
0
7
117
0
8
126
0
9
135
0
9
0
54
0
2
73
0
3
82
0
4
91
0
5
100
0
6
109
0
7
118
0
8
127
0
9
136
0
9
0
55
0
1
64
0
3
83
0
4
92
0
5
101
0
6
110
0
7
119
0
8
128
0
9
137
0
9
0
56
0
1
65
0
2
74
0
4
93
0
5
102
0
6
111
0
7
120
0
8
129
0
9
138
0
9
0
57
0
1
66
0
2
75
0
3
84
0
5
103
0
6
112
0
7
121
0
8
130
0
9
139
0
9
0
58
0
1
67
0
2
76
0
3
85
0
4
94
0
6
113
0
7
122
0
8
131
0
9
140
0
9
0
59
0
1
68
0
2
77
0
3
86
0
4
95
0
5
104
0
7
123
0
8
132
0
9
141
0
9
0
60
0
1
69
0
2
78
0
3
87
0
4
96
0
5
105
0
6
114
0
8
133
0
9
142
0
9
0
61
0
1
70
0
2
79
0
3
88
0
4
97
0
5
106
0
6
115
0
7
124
0
9
143
0
9
0
62
0
1
71
0
2
80
0
3
89
0
4
98
0
5
107
0
6
116
0
7
125
0
8
134
0
end_DTG
begin_DTG
1
1
41
1
17 0
1
0
2
2
28 8
16 0
end_DTG
begin_DTG
1
1
40
1
9 0
1
0
9
2
24 0
8 0
end_DTG
begin_DTG
1
1
39
1
0 0
1
0
11
2
22 3
1 0
end_DTG
begin_DTG
1
1
38
1
10 0
1
0
5
2
25 0
11 0
end_DTG
begin_DTG
1
1
36
1
4 0
1
0
10
2
23 3
3 0
end_DTG
begin_DTG
1
1
35
1
21 0
1
0
0
2
29 7
19 0
end_DTG
begin_DTG
1
1
34
1
9 0
1
0
8
2
24 3
7 0
end_DTG
begin_DTG
1
1
33
1
9 0
1
0
7
2
24 6
6 0
end_DTG
begin_DTG
1
1
32
1
9 0
1
0
6
2
24 4
5 0
end_DTG
begin_DTG
1
1
31
1
14 0
1
0
4
2
27 1
13 0
end_DTG
begin_DTG
1
1
28
1
17 0
1
0
1
2
28 7
15 0
end_DTG
begin_DTG
1
1
27
1
14 0
1
0
3
2
27 5
12 0
end_DTG
begin_DTG
0
12
0
42
3
35 0
29 7
19 0
0
43
3
40 0
28 7
15 0
0
44
3
30 0
28 7
16 0
0
45
3
41 0
27 7
12 0
0
46
3
39 0
27 7
13 0
0
47
3
33 0
25 7
11 0
0
48
3
38 0
24 7
5 0
0
49
3
37 0
24 7
6 0
0
50
3
36 0
24 7
7 0
0
51
3
31 0
24 7
8 0
0
52
3
34 0
23 7
3 0
0
53
3
32 0
22 7
1 0
end_DTG
begin_CG
2
32 1
1 1
3
32 1
42 1
0 1
1
4 1
3
34 1
42 1
4 1
3
34 1
2 1
3 1
3
38 1
42 1
9 1
3
37 1
42 1
9 1
3
36 1
42 1
9 1
3
31 1
42 1
9 1
8
38 1
37 1
36 1
31 1
5 1
6 1
7 1
8 1
2
33 1
11 1
3
33 1
42 1
10 1
3
41 1
42 1
14 1
3
39 1
42 1
14 1
4
41 1
39 1
12 1
13 1
3
40 1
42 1
17 1
3
30 1
42 1
17 1
4
40 1
30 1
15 1
16 1
1
21 1
3
35 1
42 1
21 1
1
21 1
4
35 1
18 1
19 1
20 1
2
32 1
42 1
2
34 1
42 1
5
38 1
37 1
36 1
31 1
42 4
2
33 1
42 1
0
3
41 1
39 1
42 2
3
40 1
30 1
42 2
2
35 1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
1
42 1
0
end_CG
