begin_version
3
end_version
begin_metric
0
end_metric
53
begin_variable
var60
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var61
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var51
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var43
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var7
-1
2
Atom calib




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





8
369
0
8
0
305
0
1
313
0
3
330
0
4
338
0
5
346
0
6
354
0
7
362
0
8
370
0
8
0
306
0
1
314
0
2
322
0
4
339
0
5
347
0
6
355
0
7
363
0
8
371
0
8
0
307
0
1
315
0
2
323
0
3
331
0
5
348
0
6
356
0
7
364
0
8
372
0
8
0
308
0
1
316
0
2
324
0
3
332
0
4
340
0
6
357
0
7
365
0
8
373
0
8
0
309
0
1
317
0
2
325
0
3
333
0
4
341
0
5
349
0
7
366
0
8
374
0
8
0
310
0
1
318
0
2
326
0
3
334
0
4
342
0
5
350
0
6
358
0
8
375
0
8
0
311
0
1
319
0
2
327
0
3
335
0
4
343
0
5
351
0
6
359
0
7
367
0
end_DTG
begin_DTG
8
1
240
0
2
248
0
3
256
0
4
264
0
5
272
0
6
280
0
7
288
0
8
296
0
8
0
232
0
2
249
0
3
257
0
4
265
0
5
273
0
6
281
0
7
289
0
8
297
0
8
0
233
0
1
241
0
3
258
0
4
266
0
5
274
0
6
282
0
7
290
0
8
298
0
8
0
234
0
1
242
0
2
250
0
4
267
0
5
275
0
6
283
0
7
291
0
8
299
0
8
0
235
0
1
243
0
2
251
0
3
259
0
5
276
0
6
284
0
7
292
0
8
300
0
8
0
236
0
1
244
0
2
252
0
3
260
0
4
268
0
6
285
0
7
293
0
8
301
0
8
0
237
0
1
245
0
2
253
0
3
261
0
4
269
0
5
277
0
7
294
0
8
302
0
8
0
238
0
1
246
0
2
254
0
3
262
0
4
270
0
5
278
0
6
286
0
8
303
0
8
0
239
0
1
247
0
2
255
0
3
263
0
4
271
0
5
279
0
6
287
0
7
295
0
end_DTG
begin_DTG
8
1
168
0
2
176
0
3
184
0
4
192
0
5
200
0
6
208
0
7
216
0
8
224
0
8
0
160
0
2
177
0
3
185
0
4
193
0
5
201
0
6
209
0
7
217
0
8
225
0
8
0
161
0
1
169
0
3
186
0
4
194
0
5
202
0
6
210
0
7
218
0
8
226
0
8
0
162
0
1
170
0
2
178
0
4
195
0
5
203
0
6
211
0
7
219
0
8
227
0
8
0
163
0
1
171
0
2
179
0
3
187
0
5
204
0
6
212
0
7
220
0
8
228
0
8
0
164
0
1
172
0
2
180
0
3
188
0
4
196
0
6
213
0
7
221
0
8
229
0
8
0
165
0
1
173
0
2
181
0
3
189
0
4
197
0
5
205
0
7
222
0
8
230
0
8
0
166
0
1
174
0
2
182
0
3
190
0
4
198
0
5
206
0
6
214
0
8
231
0
8
0
167
0
1
175
0
2
183
0
3
191
0
4
199
0
5
207
0
6
215
0
7
223
0
end_DTG
begin_DTG
8
1
96
0
2
104
0
3
112
0
4
120
0
5
128
0
6
136
0
7
144
0
8
152
0
8
0
88
0
2
105
0
3
113
0
4
121
0
5
129
0
6
137
0
7
145
0
8
153
0
8
0
89
0
1
97
0
3
114
0
4
122
0
5
130
0
6
138
0
7
146
0
8
154
0
8
0
90
0
1
98
0
2
106
0
4
123
0
5
131
0
6
139
0
7
147
0
8
155
0
8
0
91
0
1
99
0
2
107
0
3
115
0
5
132
0
6
140
0
7
148
0
8
156
0
8
0
92
0
1
100
0
2
108
0
3
116
0
4
124
0
6
141
0
7
149
0
8
157
0
8
0
93
0
1
101
0
2
109
0
3
117
0
4
125
0
5
133
0
7
150
0
8
158
0
8
0
94
0
1
102
0
2
110
0
3
118
0
4
126
0
5
134
0
6
142
0
8
159
0
8
0
95
0
1
103
0
2
111
0
3
119
0
4
127
0
5
135
0
6
143
0
7
151
0
end_DTG
begin_DTG
1
1
47
1
6 0
1
0
13
2
25 4
5 0
end_DTG
begin_DTG
1
1
46
1
18 0
1
0
6
2
29 8
17 0
end_DTG
begin_DTG
1
1
45
1
9 0
1
0
10
2
26 7
8 0
end_DTG
begin_DTG
1
1
44
1
23 0
1
0
1
2
31 3
22 0
end_DTG
begin_DTG
1
1
43
1
2 0
1
0
15
2
24 1
1 0
end_DTG
begin_DTG
1
1
42
1
19 0
1
0
2
2
30 8
20 0
end_DTG
begin_DTG
1
1
41
1
6 0
1
0
12
2
25 4
4 0
end_DTG
begin_DTG
1
1
40
1
10 0
1
0
8
2
27 7
11 0
end_DTG
begin_DTG
1
1
39
1
23 0
1
0
0
2
31 1
21 0
end_DTG
begin_DTG
1
1
38
1
18 0
1
0
5
2
29 5
16 0
end_DTG
begin_DTG
1
1
37
1
18 0
1
0
4
2
29 8
15 0
end_DTG
begin_DTG
1
1
36
1
9 0
1
0
9
2
26 8
7 0
end_DTG
begin_DTG
1
1
35
1
6 0
1
0
11
2
25 4
3 0
end_DTG
begin_DTG
1
1
34
1
18 0
1
0
3
2
29 2
14 0
end_DTG
begin_DTG
1
1
33
1
2 0
1
0
14
2
24 6
0 0
end_DTG
begin_DTG
0
6
0
56
3
37 0
30 8
20 0
0
63
3
42 0
29 8
15 0
0
64
3
41 0
29 8
16 0
0
80
3
38 0
25 8
4 0
0
86
3
46 0
24 8
0 0
0
87
3
36 0
24 8
1 0
end_DTG
begin_DTG
0
9
0
50
3
40 0
31 3
21 0
0
51
3
35 0
31 3
22 0
0
54
3
37 0
30 3
20 0
0
60
3
45 0
29 3
14 0
0
67
3
39 0
27 3
11 0
0
71
3
43 0
26 3
7 0
0
72
3
34 0
26 3
8 0
0
76
3
44 0
25 3
3 0
0
84
3
46 0
24 3
0 0
end_DTG
begin_DTG
0
6
0
53
3
37 0
30 2
20 0
0
58
3
42 0
29 2
15 0
0
59
3
41 0
29 2
16 0
0
75
3
38 0
25 2
4 0
0
82
3
46 0
24 2
0 0
0
83
3
36 0
24 2
1 0
end_DTG
begin_DTG
0
9
0
48
3
40 0
31 1
21 0
0
49
3
35 0
31 1
22 0
0
52
3
37 0
30 1
20 0
0
57
3
45 0
29 1
14 0
0
66
3
39 0
27 1
11 0
0
69
3
43 0
26 1
7 0
0
70
3
34 0
26 1
8 0
0
74
3
44 0
25 1
3 0
0
81
3
46 0
24 1
0 0
end_DTG
begin_DTG
1
1
32
1
12 0
1
0
7
2
28 8
13 0
end_DTG
begin_DTG
0
10
0
55
3
37 0
30 6
20 0
0
61
3
45 0
29 6
14 0
0
62
3
33 0
29 6
17 0
0
65
3
51 0
28 6
13 0
0
68
3
39 0
27 6
11 0
0
73
3
34 0
26 6
8 0
0
77
3
44 0
25 6
3 0
0
78
3
38 0
25 6
4 0
0
79
3
32 0
25 6
5 0
0
85
3
36 0
24 6
1 0
end_DTG
begin_CG
6
46 1
50 1
49 1
48 1
47 1
2 1
5
36 1
49 1
52 1
47 1
2 1
4
46 1
36 1
0 1
1 1
5
44 1
50 1
48 1
52 1
6 1
5
38 1
49 1
52 1
47 1
6 1
3
32 1
52 1
6 1
6
44 1
38 1
32 1
3 1
4 1
5 1
4
43 1
50 1
48 1
9 1
5
34 1
50 1
48 1
52 1
9 1
4
43 1
34 1
7 1
8 1
2
39 1
11 1
5
39 1
50 1
48 1
52 1
10 1
2
51 1
13 1
3
51 1
52 1
12 1
5
45 1
50 1
48 1
52 1
18 1
4
42 1
49 1
47 1
18 1
4
41 1
49 1
47 1
18 1
3
33 1
52 1
18 1
8
45 1
42 1
41 1
33 1
14 1
15 1
16 1
17 1
2
37 1
20 1
7
37 1
50 1
49 1
48 1
52 1
47 1
19 1
4
40 1
50 1
48 1
23 1
4
35 1
50 1
48 1
23 1
4
40 1
35 1
21 1
22 1
7
46 1
36 1
50 1
49 2
48 1
52 1
47 2
8
44 1
38 1
32 1
50 1
49 1
48 1
52 3
47 1
5
43 1
34 1
50 2
48 2
52 1
4
39 1
50 1
48 1
52 1
2
51 1
52 1
9
45 1
42 1
41 1
33 1
50 1
49 2
48 1
52 2
47 2
6
37 1
50 1
49 1
48 1
52 1
47 1
4
40 1
35 1
50 2
48 2
1
52 1
1
52 1
3
50 1
48 1
52 1
2
50 1
48 1
3
49 1
52 1
47 1
5
50 1
49 1
48 1
52 1
47 1
3
49 1
52 1
47 1
3
50 1
48 1
52 1
2
50 1
48 1
2
49 1
47 1
2
49 1
47 1
2
50 1
48 1
3
50 1
48 1
52 1
3
50 1
48 1
52 1
4
50 1
49 1
48 1
47 1
0
0
0
0
1
52 1
0
end_CG
