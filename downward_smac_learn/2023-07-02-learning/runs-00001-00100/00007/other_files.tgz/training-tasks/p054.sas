begin_version
3
end_version
begin_metric
0
end_metric
47
begin_variable
var39
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var25
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var24
-1
2
Atom have_image(dir7, mod2)
NegatedAtom have_image(dir7, mod2)
end_variable
begin_variable
var23
-1
2
Atom have_image(dir7, mod1)
NegatedAtom have_image(dir7, mod1)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var21
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var20
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
begin_variable
var19
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var17
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var16
-1
2
Atom have_image(dir3, mod2)
NegatedAtom have_image(dir3, mod2)
end_variable
begin_variable
var15
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(dir1, mod2)
end_variable
begin_variable
var11
-1
2
A




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
3
164
0
5
177
0
6
183
0
6
0
147
0
1
153
0
2
159
0
3
165
0
4
171
0
6
184
0
6
0
148
0
1
154
0
2
160
0
3
166
0
4
172
0
5
178
0
end_DTG
begin_DTG
1
1
32
1
3 0
1
0
10
2
17 5
2 0
end_DTG
begin_DTG
1
1
31
1
7 0
1
0
7
2
18 2
6 0
end_DTG
begin_DTG
1
1
30
1
7 0
1
0
6
2
18 5
5 0
end_DTG
begin_DTG
1
1
29
1
16 0
1
0
1
2
22 4
15 0
end_DTG
begin_DTG
1
1
28
1
10 0
1
0
3
2
20 5
11 0
end_DTG
begin_DTG
1
1
27
1
8 0
1
0
4
2
19 2
9 0
end_DTG
begin_DTG
1
1
26
1
3 0
1
0
9
2
17 6
1 0
end_DTG
begin_DTG
1
1
25
1
12 0
1
0
2
2
21 2
13 0
end_DTG
begin_DTG
1
1
24
1
3 0
1
0
8
2
17 2
0 0
end_DTG
begin_DTG
1
1
23
1
16 0
1
0
0
2
22 0
14 0
end_DTG
begin_DTG
1
1
22
1
7 0
1
0
5
2
18 0
4 0
end_DTG
begin_DTG
0
9
0
56
3
32 0
22 6
14 0
0
58
3
26 0
22 6
15 0
0
64
3
30 0
21 6
13 0
0
70
3
27 0
20 6
11 0
0
76
3
28 0
19 6
9 0
0
111
3
33 0
18 6
4 0
0
113
3
25 0
18 6
5 0
0
115
3
24 0
18 6
6 0
0
140
3
31 0
17 6
0 0
end_DTG
begin_DTG
0
8
0
55
3
32 0
22 6
14 0
0
57
3
26 0
22 6
15 0
0
110
3
33 0
18 6
4 0
0
112
3
25 0
18 6
5 0
0
114
3
24 0
18 6
6 0
0
139
3
31 0
17 6
0 0
0
141
3
29 0
17 6
1 0
0
142
3
23 0
17 6
2 0
end_DTG
begin_DTG
0
9
0
52
3
32 0
22 5
14 0
0
54
3
26 0
22 5
15 0
0
63
3
30 0
21 5
13 0
0
69
3
27 0
20 5
11 0
0
75
3
28 0
19 5
9 0
0
105
3
33 0
18 5
4 0
0
107
3
25 0
18 5
5 0
0
109
3
24 0
18 5
6 0
0
136
3
31 0
17 5
0 0
end_DTG
begin_DTG
0
8
0
51
3
32 0
22 5
14 0
0
53
3
26 0
22 5
15 0
0
104
3
33 0
18 5
4 0
0
106
3
25 0
18 5
5 0
0
108
3
24 0
18 5
6 0
0
135
3
31 0
17 5
0 0
0
137
3
29 0
17 5
1 0
0
138
3
23 0
17 5
2 0
end_DTG
begin_DTG
0
9
0
48
3
32 0
22 4
14 0
0
50
3
26 0
22 4
15 0
0
62
3
30 0
21 4
13 0
0
68
3
27 0
20 4
11 0
0
74
3
28 0
19 4
9 0
0
99
3
33 0
18 4
4 0
0
101
3
25 0
18 4
5 0
0
103
3
24 0
18 4
6 0
0
132
3
31 0
17 4
0 0
end_DTG
begin_DTG
0
8
0
47
3
32 0
22 4
14 0
0
49
3
26 0
22 4
15 0
0
98
3
33 0
18 4
4 0
0
100
3
25 0
18 4
5 0
0
102
3
24 0
18 4
6 0
0
131
3
31 0
17 4
0 0
0
133
3
29 0
17 4
1 0
0
134
3
23 0
17 4
2 0
end_DTG
begin_DTG
0
8
0
45
3
32 0
22 3
14 0
0
46
3
26 0
22 3
15 0
0
95
3
33 0
18 3
4 0
0
96
3
25 0
18 3
5 0
0
97
3
24 0
18 3
6 0
0
128
3
31 0
17 3
0 0
0
129
3
29 0
17 3
1 0
0
130
3
23 0
17 3
2 0
end_DTG
begin_DTG
0
9
0
42
3
32 0
22 2
14 0
0
44
3
26 0
22 2
15 0
0
61
3
30 0
21 2
13 0
0
67
3
27 0
20 2
11 0
0
73
3
28 0
19 2
9 0
0
90
3
33 0
18 2
4 0
0
92
3
25 0
18 2
5 0
0
94
3
24 0
18 2
6 0
0
125
3
31 0
17 2
0 0
end_DTG
begin_DTG
0
8
0
41
3
32 0
22 2
14 0
0
43
3
26 0
22 2
15 0
0
89
3
33 0
18 2
4 0
0
91
3
25 0
18 2
5 0
0
93
3
24 0
18 2
6 0
0
124
3
31 0
17 2
0 0
0
126
3
29 0
17 2
1 0
0
127
3
23 0
17 2
2 0
end_DTG
begin_DTG
0
9
0
38
3
32 0
22 1
14 0
0
40
3
26 0
22 1
15 0
0
60
3
30 0
21 1
13 0
0
66
3
27 0
20 1
11 0
0
72
3
28 0
19 1
9 0
0
84
3
33 0
18 1
4 0
0
86
3
25 0
18 1
5 0
0
88
3
24 0
18 1
6 0
0
121
3
31 0
17 1
0 0
end_DTG
begin_DTG
0
8
0
37
3
32 0
22 1
14 0
0
39
3
26 0
22 1
15 0
0
83
3
33 0
18 1
4 0
0
85
3
25 0
18 1
5 0
0
87
3
24 0
18 1
6 0
0
120
3
31 0
17 1
0 0
0
122
3
29 0
17 1
1 0
0
123
3
23 0
17 1
2 0
end_DTG
begin_DTG
0
9
0
34
3
32 0
22 0
14 0
0
36
3
26 0
22 0
15 0
0
59
3
30 0
21 0
13 0
0
65
3
27 0
20 0
11 0
0
71
3
28 0
19 0
9 0
0
78
3
33 0
18 0
4 0
0
80
3
25 0
18 0
5 0
0
82
3
24 0
18 0
6 0
0
117
3
31 0
17 0
0 0
end_DTG
begin_DTG
0
8
0
33
3
32 0
22 0
14 0
0
35
3
26 0
22 0
15 0
0
77
3
33 0
18 0
4 0
0
79
3
25 0
18 0
5 0
0
81
3
24 0
18 0
6 0
0
116
3
31 0
17 0
0 0
0
118
3
29 0
17 0
1 0
0
119
3
23 0
17 0
2 0
end_DTG
begin_CG
15
31 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
3 1
9
29 1
46 1
44 1
42 1
40 1
39 1
37 1
35 1
3 1
9
23 1
46 1
44 1
42 1
40 1
39 1
37 1
35 1
3 1
6
31 1
29 1
23 1
0 1
1 1
2 1
15
33 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
7 1
15
25 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
7 1
15
24 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
7 1
6
33 1
25 1
24 1
4 1
5 1
6 1
2
28 1
9 1
8
28 1
45 1
43 1
41 1
38 1
36 1
34 1
8 1
2
27 1
11 1
8
27 1
45 1
43 1
41 1
38 1
36 1
34 1
10 1
2
30 1
13 1
8
30 1
45 1
43 1
41 1
38 1
36 1
34 1
12 1
15
32 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
16 1
15
26 1
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
16 1
4
32 1
26 1
14 1
15 1
16
31 1
29 1
23 1
46 3
45 1
44 3
43 1
42 3
41 1
40 3
39 3
38 1
37 3
36 1
35 3
34 1
16
33 1
25 1
24 1
46 3
45 3
44 3
43 3
42 3
41 3
40 3
39 3
38 3
37 3
36 3
35 3
34 3
7
28 1
45 1
43 1
41 1
38 1
36 1
34 1
7
27 1
45 1
43 1
41 1
38 1
36 1
34 1
7
30 1
45 1
43 1
41 1
38 1
36 1
34 1
15
32 1
26 1
46 2
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
37 2
36 2
35 2
34 2
7
46 1
44 1
42 1
40 1
39 1
37 1
35 1
13
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
13
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
13
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
6
45 1
43 1
41 1
38 1
36 1
34 1
6
45 1
43 1
41 1
38 1
36 1
34 1
7
46 1
44 1
42 1
40 1
39 1
37 1
35 1
6
45 1
43 1
41 1
38 1
36 1
34 1
13
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
13
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
13
46 1
45 1
44 1
43 1
42 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
