begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var43
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var42
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var37
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var29
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var28
-1
2
Atom have_image(dir8, mod2)
NegatedAtom have_image(dir8, mod2)
end_variable
begin_variable
var24
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
begin_variable
var16
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
e




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





215
0
6
222
0
7
229
0
7
0
180
0
1
187
0
3
202
0
4
209
0
5
216
0
6
223
0
7
230
0
7
0
181
0
1
188
0
2
195
0
4
210
0
5
217
0
6
224
0
7
231
0
7
0
182
0
1
189
0
2
196
0
3
203
0
5
218
0
6
225
0
7
232
0
7
0
183
0
1
190
0
2
197
0
3
204
0
4
211
0
6
226
0
7
233
0
7
0
184
0
1
191
0
2
198
0
3
205
0
4
212
0
5
219
0
7
234
0
7
0
185
0
1
192
0
2
199
0
3
206
0
4
213
0
5
220
0
6
227
0
end_DTG
begin_DTG
7
1
130
0
2
137
0
3
144
0
4
151
0
5
158
0
6
165
0
7
172
0
7
0
123
0
2
138
0
3
145
0
4
152
0
5
159
0
6
166
0
7
173
0
7
0
124
0
1
131
0
3
146
0
4
153
0
5
160
0
6
167
0
7
174
0
7
0
125
0
1
132
0
2
139
0
4
154
0
5
161
0
6
168
0
7
175
0
7
0
126
0
1
133
0
2
140
0
3
147
0
5
162
0
6
169
0
7
176
0
7
0
127
0
1
134
0
2
141
0
3
148
0
4
155
0
6
170
0
7
177
0
7
0
128
0
1
135
0
2
142
0
3
149
0
4
156
0
5
163
0
7
178
0
7
0
129
0
1
136
0
2
143
0
3
150
0
4
157
0
5
164
0
6
171
0
end_DTG
begin_DTG
1
1
38
1
2 0
1
0
12
2
20 3
1 0
end_DTG
begin_DTG
1
1
37
1
19 0
1
0
3
2
26 5
18 0
end_DTG
begin_DTG
1
1
36
1
6 0
1
0
8
2
22 1
7 0
end_DTG
begin_DTG
1
1
35
1
14 0
1
0
5
2
25 7
13 0
end_DTG
begin_DTG
1
1
34
1
5 0
1
0
10
2
21 7
4 0
end_DTG
begin_DTG
1
1
33
1
19 0
1
0
2
2
26 1
17 0
end_DTG
begin_DTG
1
1
32
1
8 0
1
0
7
2
23 0
9 0
end_DTG
begin_DTG
1
1
31
1
10 0
1
0
6
2
24 5
11 0
end_DTG
begin_DTG
1
1
30
1
19 0
1
0
1
2
26 6
16 0
end_DTG
begin_DTG
1
1
29
1
19 0
1
0
0
2
26 4
15 0
end_DTG
begin_DTG
0
6
0
61
3
36 0
26 7
15 0
0
64
3
28 0
26 7
18 0
0
80
3
30 0
25 7
13 0
0
84
3
34 0
24 7
11 0
0
100
3
29 0
22 7
7 0
0
110
3
31 0
21 7
4 0
end_DTG
begin_DTG
0
6
0
56
3
36 0
26 5
15 0
0
59
3
28 0
26 5
18 0
0
77
3
30 0
25 5
13 0
0
83
3
34 0
24 5
11 0
0
98
3
29 0
22 5
7 0
0
108
3
31 0
21 5
4 0
end_DTG
begin_DTG
0
6
0
51
3
36 0
26 4
15 0
0
54
3
28 0
26 4
18 0
0
74
3
30 0
25 4
13 0
0
82
3
34 0
24 4
11 0
0
96
3
29 0
22 4
7 0
0
106
3
31 0
21 4
4 0
end_DTG
begin_DTG
0
6
0
42
3
36 0
26 1
15 0
0
43
3
28 0
26 1
18 0
0
67
3
30 0
25 1
13 0
0
81
3
34 0
24 1
11 0
0
92
3
29 0
22 1
7 0
0
102
3
31 0
21 1
4 0
end_DTG
begin_DTG
1
1
28
1
14 0
1
0
4
2
25 2
12 0
end_DTG
begin_DTG
1
1
27
1
5 0
1
0
9
2
21 4
3 0
end_DTG
begin_DTG
1
1
26
1
2 0
1
0
11
2
20 4
0 0
end_DTG
begin_DTG
0
10
0
60
3
36 0
26 7
15 0
0
62
3
35 0
26 7
16 0
0
63
3
32 0
26 7
17 0
0
78
3
41 0
25 7
12 0
0
79
3
30 0
25 7
13 0
0
90
3
33 0
23 7
9 0
0
99
3
29 0
22 7
7 0
0
109
3
42 0
21 7
3 0
0
121
3
43 0
20 7
0 0
0
122
3
27 0
20 7
1 0
end_DTG
begin_DTG
0
10
0
55
3
36 0
26 5
15 0
0
57
3
35 0
26 5
16 0
0
58
3
32 0
26 5
17 0
0
75
3
41 0
25 5
12 0
0
76
3
30 0
25 5
13 0
0
89
3
33 0
23 5
9 0
0
97
3
29 0
22 5
7 0
0
107
3
42 0
21 5
3 0
0
119
3
43 0
20 5
0 0
0
120
3
27 0
20 5
1 0
end_DTG
begin_DTG
0
10
0
50
3
36 0
26 4
15 0
0
52
3
35 0
26 4
16 0
0
53
3
32 0
26 4
17 0
0
72
3
41 0
25 4
12 0
0
73
3
30 0
25 4
13 0
0
88
3
33 0
23 4
9 0
0
95
3
29 0
22 4
7 0
0
105
3
42 0
21 4
3 0
0
117
3
43 0
20 4
0 0
0
118
3
27 0
20 4
1 0
end_DTG
begin_DTG
0
10
0
47
3
36 0
26 3
15 0
0
48
3
35 0
26 3
16 0
0
49
3
32 0
26 3
17 0
0
70
3
41 0
25 3
12 0
0
71
3
30 0
25 3
13 0
0
87
3
33 0
23 3
9 0
0
94
3
29 0
22 3
7 0
0
104
3
42 0
21 3
3 0
0
115
3
43 0
20 3
0 0
0
116
3
27 0
20 3
1 0
end_DTG
begin_DTG
0
10
0
44
3
36 0
26 2
15 0
0
45
3
35 0
26 2
16 0
0
46
3
32 0
26 2
17 0
0
68
3
41 0
25 2
12 0
0
69
3
30 0
25 2
13 0
0
86
3
33 0
23 2
9 0
0
93
3
29 0
22 2
7 0
0
103
3
42 0
21 2
3 0
0
113
3
43 0
20 2
0 0
0
114
3
27 0
20 2
1 0
end_DTG
begin_DTG
0
10
0
39
3
36 0
26 0
15 0
0
40
3
35 0
26 0
16 0
0
41
3
32 0
26 0
17 0
0
65
3
41 0
25 0
12 0
0
66
3
30 0
25 0
13 0
0
85
3
33 0
23 0
9 0
0
91
3
29 0
22 0
7 0
0
101
3
42 0
21 0
3 0
0
111
3
43 0
20 0
0 0
0
112
3
27 0
20 0
1 0
end_DTG
begin_CG
8
43 1
49 1
48 1
47 1
46 1
45 1
44 1
2 1
8
27 1
49 1
48 1
47 1
46 1
45 1
44 1
2 1
4
43 1
27 1
0 1
1 1
8
42 1
49 1
48 1
47 1
46 1
45 1
44 1
5 1
6
31 1
40 1
39 1
38 1
37 1
5 1
4
42 1
31 1
3 1
4 1
2
29 1
7 1
12
29 1
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
6 1
2
33 1
9 1
8
33 1
49 1
48 1
47 1
46 1
45 1
44 1
8 1
2
34 1
11 1
6
34 1
40 1
39 1
38 1
37 1
10 1
8
41 1
49 1
48 1
47 1
46 1
45 1
44 1
14 1
12
30 1
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
14 1
4
41 1
30 1
12 1
13 1
12
36 1
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
19 1
8
35 1
49 1
48 1
47 1
46 1
45 1
44 1
19 1
8
32 1
49 1
48 1
47 1
46 1
45 1
44 1
19 1
6
28 1
40 1
39 1
38 1
37 1
19 1
8
36 1
35 1
32 1
28 1
15 1
16 1
17 1
18 1
8
43 1
27 1
49 2
48 2
47 2
46 2
45 2
44 2
12
42 1
31 1
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
11
29 1
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
7
33 1
49 1
48 1
47 1
46 1
45 1
44 1
5
34 1
40 1
39 1
38 1
37 1
12
41 1
30 1
49 2
40 1
48 2
47 2
46 2
39 1
45 2
38 1
44 2
37 1
14
36 1
35 1
32 1
28 1
49 3
40 2
48 3
47 3
46 3
39 2
45 3
38 2
44 3
37 2
6
49 1
48 1
47 1
46 1
45 1
44 1
4
40 1
39 1
38 1
37 1
10
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
10
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
4
40 1
39 1
38 1
37 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
4
40 1
39 1
38 1
37 1
6
49 1
48 1
47 1
46 1
45 1
44 1
10
49 1
40 1
48 1
47 1
46 1
39 1
45 1
38 1
44 1
37 1
0
0
0
0
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
6
49 1
48 1
47 1
46 1
45 1
44 1
0
0
0
0
0
0
end_CG
