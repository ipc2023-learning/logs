begin_version
3
end_version
begin_metric
0
end_metric
79
begin_variable
var78
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat10, dir1)
Atom pointing(sat10, dir1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
0
104
3
63 0
36 9
22 0
0
119
3
46 0
35 9
20 0
0
126
3
71 0
34 9
18 0
0
165
3
53 0
33 9
13 0
0
167
3
45 0
33 9
15 0
0
201
3
49 0
32 9
10 0
0
203
3
41 0
32 9
11 0
0
273
3
44 0
29 9
1 0
end_DTG
begin_DTG
0
9
0
90
3
40 0
37 8
24 0
0
102
3
63 0
36 8
22 0
0
118
3
46 0
35 8
20 0
0
125
3
71 0
34 8
18 0
0
159
3
53 0
33 8
13 0
0
163
3
45 0
33 8
15 0
0
197
3
49 0
32 8
10 0
0
200
3
41 0
32 8
11 0
0
272
3
44 0
29 8
1 0
end_DTG
begin_DTG
0
9
0
81
3
40 0
37 4
24 0
0
99
3
63 0
36 4
22 0
0
113
3
46 0
35 4
20 0
0
124
3
71 0
34 4
18 0
0
145
3
53 0
33 4
13 0
0
148
3
45 0
33 4
15 0
0
185
3
49 0
32 4
10 0
0
187
3
41 0
32 4
11 0
0
263
3
44 0
29 4
1 0
end_DTG
begin_DTG
0
9
0
78
3
40 0
37 3
24 0
0
97
3
63 0
36 3
22 0
0
111
3
46 0
35 3
20 0
0
123
3
71 0
34 3
18 0
0
139
3
53 0
33 3
13 0
0
143
3
45 0
33 3
15 0
0
180
3
49 0
32 3
10 0
0
183
3
41 0
32 3
11 0
0
260
3
44 0
29 3
1 0
end_DTG
begin_DTG
0
9
0
75
3
40 0
37 2
24 0
0
95
3
63 0
36 2
22 0
0
109
3
46 0
35 2
20 0
0
122
3
71 0
34 2
18 0
0
135
3
53 0
33 2
13 0
0
137
3
45 0
33 2
15 0
0
176
3
49 0
32 2
10 0
0
178
3
41 0
32 2
11 0
0
257
3
44 0
29 2
1 0
end_DTG
begin_DTG
0
9
0
74
3
40 0
37 1
24 0
0
93
3
63 0
36 1
22 0
0
108
3
46 0
35 1
20 0
0
121
3
71 0
34 1
18 0
0
129
3
53 0
33 1
13 0
0
133
3
45 0
33 1
15 0
0
172
3
49 0
32 1
10 0
0
175
3
41 0
32 1
11 0
0
256
3
44 0
29 1
1 0
end_DTG
begin_DTG
0
9
0
71
3
40 0
37 0
24 0
0
92
3
63 0
36 0
22 0
0
106
3
46 0
35 0
20 0
0
120
3
71 0
34 0
18 0
0
127
3
53 0
33 0
13 0
0
128
3
45 0
33 0
15 0
0
169
3
49 0
32 0
10 0
0
170
3
41 0
32 0
11 0
0
253
3
44 0
29 0
1 0
end_DTG
begin_CG
9
48 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
2 1
16
44 1
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
2 1
4
48 1
44 1
0 1
1 1
9
54 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
7 1
9
52 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
7 1
9
47 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
7 1
16
42 1
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
7 1
8
54 1
52 1
47 1
42 1
3 1
4 1
5 1
6 1
2
43 1
9 1
16
43 1
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
8 1
23
49 1
78 1
62 1
77 1
70 1
76 1
69 1
61 1
75 1
68 1
60 1
74 1
59 1
67 1
58 1
66 1
57 1
56 1
73 1
65 1
72 1
64 1
12 1
16
41 1
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
12 1
4
49 1
41 1
10 1
11 1
9
53 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
16 1
16
50 1
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
16 1
23
45 1
78 1
62 1
77 1
70 1
76 1
69 1
61 1
75 1
68 1
60 1
74 1
59 1
67 1
58 1
66 1
57 1
56 1
73 1
65 1
72 1
64 1
16 1
6
53 1
50 1
45 1
13 1
14 1
15 1
2
71 1
18 1
9
71 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
17 1
2
46 1
20 1
16
46 1
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
19 1
2
63 1
22 1
16
63 1
78 1
77 1
70 1
76 1
69 1
75 1
68 1
74 1
67 1
66 1
73 1
65 1
72 1
64 1
21 1
9
55 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
25 1
16
40 1
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
25 1
4
55 1
40 1
23 1
24 1
9
51 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
28 1
9
39 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
28 1
4
51 1
39 1
26 1
27 1
16
48 1
44 1
78 1
62 2
77 1
76 1
61 2
75 1
60 2
74 1
59 2
58 2
57 2
56 2
73 1
72 1
18
54 1
52 1
47 1
42 1
62 2
70 3
69 3
61 2
68 3
60 2
59 2
67 3
58 2
66 3
57 2
56 2
65 3
64 3
15
43 1
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
23
49 1
41 1
78 2
62 2
77 2
70 1
76 2
69 1
61 2
75 2
68 1
60 2
74 2
59 2
67 1
58 2
66 1
57 2
56 2
73 2
65 1
72 2
64 1
24
53 1
50 1
45 1
78 2
62 2
77 2
70 2
76 2
69 2
61 2
75 2
68 2
60 2
74 2
59 2
67 2
58 2
66 2
57 2
56 2
73 2
65 2
72 2
64 2
8
71 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
15
46 1
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
15
63 1
78 1
77 1
70 1
76 1
69 1
75 1
68 1
74 1
67 1
66 1
73 1
65 1
72 1
64 1
16
55 1
40 1
78 1
62 2
77 1
76 1
61 2
75 1
60 2
74 1
59 2
58 2
57 2
56 2
73 1
72 1
16
51 1
39 1
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
7
62 1
61 1
60 1
59 1
58 1
57 1
56 1
14
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
14
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
14
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
14
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
14
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
21
78 1
62 1
77 1
70 1
76 1
69 1
61 1
75 1
68 1
60 1
74 1
59 1
67 1
58 1
66 1
57 1
56 1
73 1
65 1
72 1
64 1
14
78 1
62 1
77 1
76 1
61 1
75 1
60 1
74 1
59 1
58 1
57 1
56 1
73 1
72 1
7
70 1
69 1
68 1
67 1
66 1
65 1
64 1
7
62 1
61 1
60 1
59 1
58 1
57 1
56 1
21
78 1
62 1
77 1
70 1
76 1
69 1
61 1
75 1
68 1
60 1
74 1
59 1
67 1
58 1
66 1
57 1
56 1
73 1
65 1
72 1
64 1
14
62 1
70 1
69 1
61 1
68 1
60 1
59 1
67 1
58 1
66 1
57 1
56 1
65 1
64 1
7
70 1
69 1
68 1
67 1
66 1
65 1
64 1
7
62 1
61 1
60 1
59 1
58 1
57 1
56 1
7
78 1
77 1
76 1
75 1
74 1
73 1
72 1
7
70 1
69 1
68 1
67 1
66 1
65 1
64 1
7
62 1
61 1
60 1
59 1
58 1
57 1
56 1
0
0
0
0
0
0
0
14
78 1
77 1
70 1
76 1
69 1
75 1
68 1
74 1
67 1
66 1
73 1
65 1
72 1
64 1
0
0
0
0
0
0
0
7
78 1
77 1
76 1
75 1
74 1
73 1
72 1
0
0
0
0
0
0
0
end_CG
