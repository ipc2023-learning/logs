begin_version
3
end_version
begin_metric
0
end_metric
46
begin_variable
var36
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var25
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var24
-1
2
Atom have_image(dir7, mod2)
NegatedAtom have_image(dir7, mod2)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var18
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var16
-1
2
Atom have_image(dir3, mod2)
NegatedAtom have_image(dir3, mod2)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(dir1, mod2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var23
-1
2
Atom have_image(dir7, mod1)
NegatedAtom have_image(dir7, mod1)
end_variable
begin_variable
var21
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var19
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
begin_variable
var15
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
0
1
1
1
0
0
1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
0
6
0
203
0
1
209
0
2
215
0
4
228
0
5
234
0
6
240
0
6
0
204
0
1
210
0
2
216
0
3
222
0
5
235
0
6
241
0
6
0
205
0
1
211
0
2
217
0
3
223
0
4
229
0
6
242
0
6
0
206
0
1
212
0
2
218
0
3
224
0
4
230
0
5
236
0
end_DTG
begin_DTG
6
1
165
0
2
171
0
3
177
0
4
183
0
5
189
0
6
195
0
6
0
159
0
2
172
0
3
178
0
4
184
0
5
190
0
6
196
0
6
0
160
0
1
166
0
3
179
0
4
185
0
5
191
0
6
197
0
6
0
161
0
1
167
0
2
173
0
4
186
0
5
192
0
6
198
0
6
0
162
0
1
168
0
2
174
0
3
180
0
5
193
0
6
199
0
6
0
163
0
1
169
0
2
175
0
3
181
0
4
187
0
6
200
0
6
0
164
0
1
170
0
2
176
0
3
182
0
4
188
0
5
194
0
end_DTG
begin_DTG
6
1
123
0
2
129
0
3
135
0
4
141
0
5
147
0
6
153
0
6
0
117
0
2
130
0
3
136
0
4
142
0
5
148
0
6
154
0
6
0
118
0
1
124
0
3
137
0
4
143
0
5
149
0
6
155
0
6
0
119
0
1
125
0
2
131
0
4
144
0
5
150
0
6
156
0
6
0
120
0
1
126
0
2
132
0
3
138
0
5
151
0
6
157
0
6
0
121
0
1
127
0
2
133
0
3
139
0
4
145
0
6
158
0
6
0
122
0
1
128
0
2
134
0
3
140
0
4
146
0
5
152
0
end_DTG
begin_DTG
1
1
32
1
13 0
1
0
4
2
21 2
12 0
end_DTG
begin_DTG
1
1
31
1
4 0
1
0
9
2
18 5
3 0
end_DTG
begin_DTG
1
1
30
1
16 0
1
0
1
2
22 5
15 0
end_DTG
begin_DTG
1
1
29
1
5 0
1
0
7
2
19 4
6 0
end_DTG
begin_DTG
1
1
28
1
16 0
1
0
0
2
22 5
14 0
end_DTG
begin_DTG
1
1
27
1
4 0
1
0
8
2
18 0
2 0
end_DTG
begin_DTG
1
1
26
1
13 0
1
0
3
2
21 6
11 0
end_DTG
begin_DTG
1
1
25
1
9 0
1
0
6
2
20 0
8 0
end_DTG
begin_DTG
0
5
0
44
3
25 0
22 6
15 0
0
68
3
23 0
21 6
12 0
0
80
3
30 0
20 6
8 0
0
92
3
26 0
19 6
6 0
0
109
3
28 0
18 6
2 0
end_DTG
begin_DTG
0
5
0
42
3
25 0
22 5
15 0
0
64
3
23 0
21 5
12 0
0
78
3
30 0
20 5
8 0
0
90
3
26 0
19 5
6 0
0
106
3
28 0
18 5
2 0
end_DTG
begin_DTG
0
5
0
39
3
25 0
22 3
15 0
0
57
3
23 0
21 3
12 0
0
75
3
30 0
20 3
8 0
0
87
3
26 0
19 3
6 0
0
102
3
28 0
18 3
2 0
end_DTG
begin_DTG
0
5
0
38
3
25 0
22 2
15 0
0
56
3
23 0
21 2
12 0
0
74
3
30 0
20 2
8 0
0
86
3
26 0
19 2
6 0
0
100
3
28 0
18 2
2 0
end_DTG
begin_DTG
0
5
0
36
3
25 0
22 1
15 0
0
52
3
23 0
21 1
12 0
0
72
3
30 0
20 1
8 0
0
84
3
26 0
19 1
6 0
0
97
3
28 0
18 1
2 0
end_DTG
begin_DTG
0
5
0
34
3
25 0
22 0
15 0
0
48
3
23 0
21 0
12 0
0
70
3
30 0
20 0
8 0
0
82
3
26 0
19 0
6 0
0
94
3
28 0
18 0
2 0
end_DTG
begin_DTG
1
1
24
1
9 0
1
0
5
2
20 5
7 0
end_DTG
begin_DTG
1
1
23
1
13 0
1
0
2
2
21 6
10 0
end_DTG
begin_DTG
1
1
22
1
0 0
1
0
10
2
17 5
1 0
end_DTG
begin_DTG
0
9
0
43
3
27 0
22 6
14 0
0
65
3
38 0
21 6
10 0
0
66
3
29 0
21 6
11 0
0
67
3
23 0
21 6
12 0
0
79
3
37 0
20 6
7 0
0
91
3
26 0
19 6
6 0
0
108
3
28 0
18 6
2 0
0
110
3
24 0
18 6
3 0
0
116
3
39 0
17 6
1 0
end_DTG
begin_DTG
0
9
0
41
3
27 0
22 5
14 0
0
61
3
38 0
21 5
10 0
0
62
3
29 0
21 5
11 0
0
63
3
23 0
21 5
12 0
0
77
3
37 0
20 5
7 0
0
89
3
26 0
19 5
6 0
0
105
3
28 0
18 5
2 0
0
107
3
24 0
18 5
3 0
0
115
3
39 0
17 5
1 0
end_DTG
begin_DTG
0
9
0
40
3
27 0
22 4
14 0
0
58
3
38 0
21 4
10 0
0
59
3
29 0
21 4
11 0
0
60
3
23 0
21 4
12 0
0
76
3
37 0
20 4
7 0
0
88
3
26 0
19 4
6 0
0
103
3
28 0
18 4
2 0
0
104
3
24 0
18 4
3 0
0
114
3
39 0
17 4
1 0
end_DTG
begin_DTG
0
9
0
37
3
27 0
22 2
14 0
0
53
3
38 0
21 2
10 0
0
54
3
29 0
21 2
11 0
0
55
3
23 0
21 2
12 0
0
73
3
37 0
20 2
7 0
0
85
3
26 0
19 2
6 0
0
99
3
28 0
18 2
2 0
0
101
3
24 0
18 2
3 0
0
113
3
39 0
17 2
1 0
end_DTG
begin_DTG
0
9
0
35
3
27 0
22 1
14 0
0
49
3
38 0
21 1
10 0
0
50
3
29 0
21 1
11 0
0
51
3
23 0
21 1
12 0
0
71
3
37 0
20 1
7 0
0
83
3
26 0
19 1
6 0
0
96
3
28 0
18 1
2 0
0
98
3
24 0
18 1
3 0
0
112
3
39 0
17 1
1 0
end_DTG
begin_DTG
0
9
0
33
3
27 0
22 0
14 0
0
45
3
38 0
21 0
10 0
0
46
3
29 0
21 0
11 0
0
47
3
23 0
21 0
12 0
0
69
3
37 0
20 0
7 0
0
81
3
26 0
19 0
6 0
0
93
3
28 0
18 0
2 0
0
95
3
24 0
18 0
3 0
0
111
3
39 0
17 0
1 0
end_DTG
begin_CG
2
39 1
1 1
8
39 1
45 1
44 1
43 1
42 1
41 1
40 1
0 1
14
28 1
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
4 1
8
24 1
45 1
44 1
43 1
42 1
41 1
40 1
4 1
4
28 1
24 1
2 1
3 1
2
26 1
6 1
14
26 1
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
5 1
8
37 1
45 1
44 1
43 1
42 1
41 1
40 1
9 1
8
30 1
36 1
35 1
34 1
33 1
32 1
31 1
9 1
4
37 1
30 1
7 1
8 1
8
38 1
45 1
44 1
43 1
42 1
41 1
40 1
13 1
8
29 1
45 1
44 1
43 1
42 1
41 1
40 1
13 1
14
23 1
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
13 1
6
38 1
29 1
23 1
10 1
11 1
12 1
8
27 1
45 1
44 1
43 1
42 1
41 1
40 1
16 1
8
25 1
36 1
35 1
34 1
33 1
32 1
31 1
16 1
4
27 1
25 1
14 1
15 1
7
39 1
45 1
44 1
43 1
42 1
41 1
40 1
14
28 1
24 1
45 2
36 1
44 2
35 1
43 2
34 1
33 1
42 2
41 2
32 1
40 2
31 1
13
26 1
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
14
37 1
30 1
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
15
38 1
29 1
23 1
45 3
36 1
44 3
35 1
43 3
34 1
33 1
42 3
41 3
32 1
40 3
31 1
14
27 1
25 1
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
12
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
6
45 1
44 1
43 1
42 1
41 1
40 1
6
36 1
35 1
34 1
33 1
32 1
31 1
12
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
6
45 1
44 1
43 1
42 1
41 1
40 1
12
45 1
36 1
44 1
35 1
43 1
34 1
33 1
42 1
41 1
32 1
40 1
31 1
6
45 1
44 1
43 1
42 1
41 1
40 1
6
36 1
35 1
34 1
33 1
32 1
31 1
0
0
0
0
0
0
6
45 1
44 1
43 1
42 1
41 1
40 1
6
45 1
44 1
43 1
42 1
41 1
40 1
6
45 1
44 1
43 1
42 1
41 1
40 1
0
0
0
0
0
0
end_CG
