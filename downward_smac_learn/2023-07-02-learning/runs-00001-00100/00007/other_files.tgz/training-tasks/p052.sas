begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var39
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var25
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var21
-1
2
Atom have_image(dir6, mod1)
NegatedAtom have_image(dir6, mod1)
end_variable
begin_variable
var20
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
begin_variable
var18
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var15
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(dir1, mod2)
end_variable
begin_variable
var11
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
1
1
0
1
1
0
1
1
0
0
1
0
1
1
1
1
0
2
0
6
4
5
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
11
17 3
19 0
22 6
34 0
35 0
36 0
37 0
38 0
39 0
40 0
41 0
end_goal
355
begin_operator
calibrate sat1 ins1 dir2
2
22 1
13 0
1
0 33 -1 0
0
end_operator
begin_operator
calibrate sat1 ins10 dir6
2
22 5
14 0
1
0 32 -1 0
0
end_operator
begin_operator
calibrate sat1 ins9 dir2
2
22 1
15 0
1
0 23 -1 0
0
end_operator
begin_o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
6
0
275
0
1
281
0
2
287
0
3
293
0
4
299
0
6
312
0
6
0
276
0
1
282
0
2
288
0
3
294
0
4
300
0
5
306
0
end_DTG
begin_DTG
6
1
235
0
2
241
0
3
247
0
4
253
0
5
259
0
6
265
0
6
0
229
0
2
242
0
3
248
0
4
254
0
5
260
0
6
266
0
6
0
230
0
1
236
0
3
249
0
4
255
0
5
261
0
6
267
0
6
0
231
0
1
237
0
2
243
0
4
256
0
5
262
0
6
268
0
6
0
232
0
1
238
0
2
244
0
3
250
0
5
263
0
6
269
0
6
0
233
0
1
239
0
2
245
0
3
251
0
4
257
0
6
270
0
6
0
234
0
1
240
0
2
246
0
3
252
0
4
258
0
5
264
0
end_DTG
begin_DTG
6
1
193
0
2
199
0
3
205
0
4
211
0
5
217
0
6
223
0
6
0
187
0
2
200
0
3
206
0
4
212
0
5
218
0
6
224
0
6
0
188
0
1
194
0
3
207
0
4
213
0
5
219
0
6
225
0
6
0
189
0
1
195
0
2
201
0
4
214
0
5
220
0
6
226
0
6
0
190
0
1
196
0
2
202
0
3
208
0
5
221
0
6
227
0
6
0
191
0
1
197
0
2
203
0
3
209
0
4
215
0
6
228
0
6
0
192
0
1
198
0
2
204
0
3
210
0
4
216
0
5
222
0
end_DTG
begin_DTG
6
1
151
0
2
157
0
3
163
0
4
169
0
5
175
0
6
181
0
6
0
145
0
2
158
0
3
164
0
4
170
0
5
176
0
6
182
0
6
0
146
0
1
152
0
3
165
0
4
171
0
5
177
0
6
183
0
6
0
147
0
1
153
0
2
159
0
4
172
0
5
178
0
6
184
0
6
0
148
0
1
154
0
2
160
0
3
166
0
5
179
0
6
185
0
6
0
149
0
1
155
0
2
161
0
3
167
0
4
173
0
6
186
0
6
0
150
0
1
156
0
2
162
0
3
168
0
4
174
0
5
180
0
end_DTG
begin_DTG
6
1
109
0
2
115
0
3
121
0
4
127
0
5
133
0
6
139
0
6
0
103
0
2
116
0
3
122
0
4
128
0
5
134
0
6
140
0
6
0
104
0
1
110
0
3
123
0
4
129
0
5
135
0
6
141
0
6
0
105
0
1
111
0
2
117
0
4
130
0
5
136
0
6
142
0
6
0
106
0
1
112
0
2
118
0
3
124
0
5
137
0
6
143
0
6
0
107
0
1
113
0
2
119
0
3
125
0
4
131
0
6
144
0
6
0
108
0
1
114
0
2
120
0
3
126
0
4
132
0
5
138
0
end_DTG
begin_DTG
1
1
32
1
16 0
1
0
2
2
22 1
15 0
end_DTG
begin_DTG
1
1
31
1
8 0
1
0
6
2
19 4
7 0
end_DTG
begin_DTG
1
1
30
1
5 0
1
0
8
2
18 2
4 0
end_DTG
begin_DTG
1
1
29
1
5 0
1
0
7
2
18 6
3 0
end_DTG
begin_DTG
1
1
28
1
2 0
1
0
10
2
17 6
1 0
end_DTG
begin_DTG
1
1
27
1
11 0
1
0
3
2
21 6
12 0
end_DTG
begin_DTG
1
1
26
1
9 0
1
0
4
2
20 3
10 0
end_DTG
begin_DTG
1
1
25
1
8 0
1
0
5
2
19 1
6 0
end_DTG
begin_DTG
1
1
24
1
2 0
1
0
9
2
17 3
0 0
end_DTG
begin_DTG
1
1
23
1
16 0
1
0
1
2
22 5
14 0
end_DTG
begin_DTG
1
1
22
1
16 0
1
0
0
2
22 1
13 0
end_DTG
begin_DTG
0
8
0
48
3
33 0
22 5
13 0
0
50
3
32 0
22 5
14 0
0
59
3
28 0
21 5
12 0
0
67
3
29 0
20 5
10 0
0
74
3
30 0
19 5
6 0
0
85
3
26 0
18 5
3 0
0
100
3
31 0
17 5
0 0
0
102
3
27 0
17 5
1 0
end_DTG
begin_DTG
0
10
0
47
3
33 0
22 5
13 0
0
49
3
32 0
22 5
14 0
0
51
3
23 0
22 5
15 0
0
58
3
28 0
21 5
12 0
0
66
3
29 0
20 5
10 0
0
75
3
24 0
19 5
7 0
0
84
3
26 0
18 5
3 0
0
86
3
25 0
18 5
4 0
0
99
3
31 0
17 5
0 0
0
101
3
27 0
17 5
1 0
end_DTG
begin_DTG
0
8
0
45
3
33 0
22 4
13 0
0
46
3
32 0
22 4
14 0
0
57
3
28 0
21 4
12 0
0
65
3
29 0
20 4
10 0
0
73
3
30 0
19 4
6 0
0
83
3
26 0
18 4
3 0
0
97
3
31 0
17 4
0 0
0
98
3
27 0
17 4
1 0
end_DTG
begin_DTG
0
8
0
43
3
33 0
22 3
13 0
0
44
3
32 0
22 3
14 0
0
56
3
28 0
21 3
12 0
0
64
3
29 0
20 3
10 0
0
72
3
30 0
19 3
6 0
0
82
3
26 0
18 3
3 0
0
95
3
31 0
17 3
0 0
0
96
3
27 0
17 3
1 0
end_DTG
begin_DTG
0
10
0
40
3
33 0
22 2
13 0
0
41
3
32 0
22 2
14 0
0
42
3
23 0
22 2
15 0
0
55
3
28 0
21 2
12 0
0
63
3
29 0
20 2
10 0
0
71
3
24 0
19 2
7 0
0
80
3
26 0
18 2
3 0
0
81
3
25 0
18 2
4 0
0
93
3
31 0
17 2
0 0
0
94
3
27 0
17 2
1 0
end_DTG
begin_DTG
0
8
0
38
3
33 0
22 1
13 0
0
39
3
32 0
22 1
14 0
0
54
3
28 0
21 1
12 0
0
62
3
29 0
20 1
10 0
0
70
3
30 0
19 1
6 0
0
79
3
26 0
18 1
3 0
0
91
3
31 0
17 1
0 0
0
92
3
27 0
17 1
1 0
end_DTG
begin_DTG
0
8
0
34
3
33 0
22 0
13 0
0
36
3
32 0
22 0
14 0
0
53
3
28 0
21 0
12 0
0
61
3
29 0
20 0
10 0
0
68
3
30 0
19 0
6 0
0
77
3
26 0
18 0
3 0
0
88
3
31 0
17 0
0 0
0
90
3
27 0
17 0
1 0
end_DTG
begin_DTG
0
10
0
33
3
33 0
22 0
13 0
0
35
3
32 0
22 0
14 0
0
37
3
23 0
22 0
15 0
0
52
3
28 0
21 0
12 0
0
60
3
29 0
20 0
10 0
0
69
3
24 0
19 0
7 0
0
76
3
26 0
18 0
3 0
0
78
3
25 0
18 0
4 0
0
87
3
31 0
17 0
0 0
0
89
3
27 0
17 0
1 0
end_DTG
begin_CG
10
31 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
2 1
10
27 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
2 1
4
31 1
27 1
0 1
1 1
10
26 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
5 1
5
25 1
41 1
38 1
35 1
5 1
4
26 1
25 1
3 1
4 1
7
30 1
40 1
39 1
37 1
36 1
34 1
8 1
5
24 1
41 1
38 1
35 1
8 1
4
30 1
24 1
6 1
7 1
2
29 1
10 1
10
29 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
9 1
2
28 1
12 1
10
28 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
11 1
10
33 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
16 1
10
32 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
16 1
5
23 1
41 1
38 1
35 1
16 1
6
33 1
32 1
23 1
13 1
14 1
15 1
10
31 1
27 1
41 2
40 2
39 2
38 2
37 2
36 2
35 2
34 2
10
26 1
25 1
41 2
40 1
39 1
38 2
37 1
36 1
35 2
34 1
10
30 1
24 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
9
29 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
9
28 1
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
11
33 1
32 1
23 1
41 3
40 2
39 2
38 3
37 2
36 2
35 3
34 2
3
41 1
38 1
35 1
3
41 1
38 1
35 1
3
41 1
38 1
35 1
8
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
8
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
8
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
8
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
5
40 1
39 1
37 1
36 1
34 1
8
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
8
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
8
41 1
40 1
39 1
38 1
37 1
36 1
35 1
34 1
0
0
0
0
0
0
0
0
end_CG
