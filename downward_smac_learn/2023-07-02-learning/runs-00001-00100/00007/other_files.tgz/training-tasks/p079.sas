begin_version
3
end_version
begin_metric
0
end_metric
72
begin_variable
var66
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var61
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var43
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var11
-1
2
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
97
3
47 0
32 6
18 0
0
128
3
57 0
30 6
13 0
0
129
3
46 0
30 6
14 0
0
150
3
45 0
29 6
10 0
0
175
3
41 0
27 6
7 0
end_DTG
begin_DTG
0
9
0
69
3
34 0
33 6
23 0
0
96
3
47 0
32 6
18 0
0
99
3
35 0
32 6
19 0
0
127
3
57 0
30 6
13 0
0
149
3
45 0
29 6
10 0
0
174
3
41 0
27 6
7 0
0
194
3
43 0
26 6
3 0
0
195
3
38 0
26 6
4 0
0
211
3
44 0
25 6
0 0
end_DTG
begin_DTG
0
7
0
62
3
48 0
33 5
21 0
0
64
3
42 0
33 5
22 0
0
93
3
47 0
32 5
18 0
0
125
3
57 0
30 5
13 0
0
126
3
46 0
30 5
14 0
0
147
3
45 0
29 5
10 0
0
173
3
41 0
27 5
7 0
end_DTG
begin_DTG
0
9
0
65
3
34 0
33 5
23 0
0
92
3
47 0
32 5
18 0
0
95
3
35 0
32 5
19 0
0
124
3
57 0
30 5
13 0
0
146
3
45 0
29 5
10 0
0
172
3
41 0
27 5
7 0
0
191
3
43 0
26 5
3 0
0
192
3
38 0
26 5
4 0
0
209
3
44 0
25 5
0 0
end_DTG
begin_DTG
0
7
0
59
3
48 0
33 4
21 0
0
61
3
42 0
33 4
22 0
0
90
3
47 0
32 4
18 0
0
122
3
57 0
30 4
13 0
0
123
3
46 0
30 4
14 0
0
144
3
45 0
29 4
10 0
0
171
3
41 0
27 4
7 0
end_DTG
begin_DTG
0
9
0
58
3
34 0
33 3
23 0
0
87
3
47 0
32 3
18 0
0
89
3
35 0
32 3
19 0
0
121
3
57 0
30 3
13 0
0
142
3
45 0
29 3
10 0
0
170
3
41 0
27 3
7 0
0
187
3
43 0
26 3
3 0
0
188
3
38 0
26 3
4 0
0
206
3
44 0
25 3
0 0
end_DTG
begin_DTG
0
7
0
53
3
48 0
33 2
21 0
0
55
3
42 0
33 2
22 0
0
84
3
47 0
32 2
18 0
0
119
3
57 0
30 2
13 0
0
120
3
46 0
30 2
14 0
0
140
3
45 0
29 2
10 0
0
169
3
41 0
27 2
7 0
end_DTG
begin_DTG
0
9
0
56
3
34 0
33 2
23 0
0
83
3
47 0
32 2
18 0
0
86
3
35 0
32 2
19 0
0
118
3
57 0
30 2
13 0
0
139
3
45 0
29 2
10 0
0
168
3
41 0
27 2
7 0
0
184
3
43 0
26 2
3 0
0
185
3
38 0
26 2
4 0
0
204
3
44 0
25 2
0 0
end_DTG
begin_DTG
0
9
0
52
3
34 0
33 1
23 0
0
80
3
47 0
32 1
18 0
0
82
3
35 0
32 1
19 0
0
117
3
57 0
30 1
13 0
0
137
3
45 0
29 1
10 0
0
167
3
41 0
27 1
7 0
0
181
3
43 0
26 1
3 0
0
182
3
38 0
26 1
4 0
0
202
3
44 0
25 1
0 0
end_DTG
begin_DTG
0
7
0
48
3
48 0
33 0
21 0
0
49
3
42 0
33 0
22 0
0
78
3
47 0
32 0
18 0
0
115
3
57 0
30 0
13 0
0
116
3
46 0
30 0
14 0
0
136
3
45 0
29 0
10 0
0
166
3
41 0
27 0
7 0
end_DTG
begin_DTG
0
9
0
50
3
34 0
33 0
23 0
0
77
3
47 0
32 0
18 0
0
79
3
35 0
32 0
19 0
0
114
3
57 0
30 0
13 0
0
135
3
45 0
29 0
10 0
0
165
3
41 0
27 0
7 0
0
179
3
43 0
26 0
3 0
0
180
3
38 0
26 0
4 0
0
201
3
44 0
25 0
0 0
end_DTG
begin_CG
9
44 1
71 1
69 1
68 1
66 1
64 1
62 1
60 1
2 1
10
36 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
2 1
4
44 1
36 1
0 1
1 1
9
43 1
71 1
69 1
68 1
66 1
64 1
62 1
60 1
5 1
17
38 1
71 1
69 1
56 1
68 1
55 1
66 1
54 1
53 1
64 1
52 1
62 1
51 1
60 1
50 1
49 1
5 1
4
43 1
38 1
3 1
4 1
2
41 1
7 1
16
41 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
6 1
2
37 1
9 1
10
37 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
8 1
16
45 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
12 1
10
40 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
12 1
4
45 1
40 1
10 1
11 1
16
57 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
15 1
9
46 1
70 1
67 1
65 1
63 1
61 1
59 1
58 1
15 1
4
57 1
46 1
13 1
14 1
2
39 1
17 1
10
39 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
16 1
24
47 1
71 1
70 1
69 1
56 1
68 1
67 1
55 1
66 1
54 1
65 1
53 1
64 1
63 1
52 1
62 1
61 1
51 1
60 1
59 1
50 1
58 1
49 1
20 1
9
35 1
71 1
69 1
68 1
66 1
64 1
62 1
60 1
20 1
4
47 1
35 1
18 1
19 1
17
48 1
70 1
56 1
67 1
55 1
54 1
65 1
53 1
63 1
52 1
61 1
51 1
59 1
50 1
58 1
49 1
24 1
9
42 1
70 1
67 1
65 1
63 1
61 1
59 1
58 1
24 1
9
34 1
71 1
69 1
68 1
66 1
64 1
62 1
60 1
24 1
6
48 1
42 1
34 1
21 1
22 1
23 1
17
44 1
36 1
71 1
69 1
56 1
68 1
55 1
66 1
54 1
53 1
64 1
52 1
62 1
51 1
60 1
50 1
49 1
17
43 1
38 1
71 2
69 2
56 1
68 2
55 1
66 2
54 1
53 1
64 2
52 1
62 2
51 1
60 2
50 1
49 1
15
41 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
9
37 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
24
45 1
40 1
71 1
70 1
69 1
56 1
68 1
67 1
55 1
66 1
54 1
65 1
53 1
64 1
63 1
52 1
62 1
61 1
51 1
60 1
59 1
50 1
58 1
49 1
16
57 1
46 1
71 1
70 2
69 1
68 1
67 2
66 1
65 2
64 1
63 2
62 1
61 2
60 1
59 2
58 2
9
39 1
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
24
47 1
35 1
71 2
70 1
69 2
56 1
68 2
67 1
55 1
66 2
54 1
65 1
53 1
64 2
63 1
52 1
62 2
61 1
51 1
60 2
59 1
50 1
58 1
49 1
25
48 1
42 1
34 1
71 1
70 2
69 1
56 1
68 1
67 2
55 1
66 1
54 1
65 2
53 1
64 1
63 2
52 1
62 1
61 2
51 1
60 1
59 2
50 1
58 2
49 1
7
71 1
69 1
68 1
66 1
64 1
62 1
60 1
7
71 1
69 1
68 1
66 1
64 1
62 1
60 1
8
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
8
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
15
71 1
69 1
56 1
68 1
55 1
66 1
54 1
53 1
64 1
52 1
62 1
51 1
60 1
50 1
49 1
8
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
8
56 1
55 1
54 1
53 1
52 1
51 1
50 1
49 1
14
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
7
70 1
67 1
65 1
63 1
61 1
59 1
58 1
7
71 1
69 1
68 1
66 1
64 1
62 1
60 1
7
71 1
69 1
68 1
66 1
64 1
62 1
60 1
14
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
7
70 1
67 1
65 1
63 1
61 1
59 1
58 1
22
71 1
70 1
69 1
56 1
68 1
67 1
55 1
66 1
54 1
65 1
53 1
64 1
63 1
52 1
62 1
61 1
51 1
60 1
59 1
50 1
58 1
49 1
15
70 1
56 1
67 1
55 1
54 1
65 1
53 1
63 1
52 1
61 1
51 1
59 1
50 1
58 1
49 1
0
0
0
0
0
0
0
0
14
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
