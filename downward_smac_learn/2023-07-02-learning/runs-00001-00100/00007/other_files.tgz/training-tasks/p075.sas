begin_version
3
end_version
begin_metric
0
end_metric
53
begin_variable
var62
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var61
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var60
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var51
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var43
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var7
-1
2
Atom calib




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





377
0
8
0
313
0
1
321
0
2
329
0
3
337
0
4
345
0
6
362
0
7
370
0
8
378
0
8
0
314
0
1
322
0
2
330
0
3
338
0
4
346
0
5
354
0
7
371
0
8
379
0
8
0
315
0
1
323
0
2
331
0
3
339
0
4
347
0
5
355
0
6
363
0
8
380
0
8
0
316
0
1
324
0
2
332
0
3
340
0
4
348
0
5
356
0
6
364
0
7
372
0
end_DTG
begin_DTG
8
1
245
0
2
253
0
3
261
0
4
269
0
5
277
0
6
285
0
7
293
0
8
301
0
8
0
237
0
2
254
0
3
262
0
4
270
0
5
278
0
6
286
0
7
294
0
8
302
0
8
0
238
0
1
246
0
3
263
0
4
271
0
5
279
0
6
287
0
7
295
0
8
303
0
8
0
239
0
1
247
0
2
255
0
4
272
0
5
280
0
6
288
0
7
296
0
8
304
0
8
0
240
0
1
248
0
2
256
0
3
264
0
5
281
0
6
289
0
7
297
0
8
305
0
8
0
241
0
1
249
0
2
257
0
3
265
0
4
273
0
6
290
0
7
298
0
8
306
0
8
0
242
0
1
250
0
2
258
0
3
266
0
4
274
0
5
282
0
7
299
0
8
307
0
8
0
243
0
1
251
0
2
259
0
3
267
0
4
275
0
5
283
0
6
291
0
8
308
0
8
0
244
0
1
252
0
2
260
0
3
268
0
4
276
0
5
284
0
6
292
0
7
300
0
end_DTG
begin_DTG
8
1
173
0
2
181
0
3
189
0
4
197
0
5
205
0
6
213
0
7
221
0
8
229
0
8
0
165
0
2
182
0
3
190
0
4
198
0
5
206
0
6
214
0
7
222
0
8
230
0
8
0
166
0
1
174
0
3
191
0
4
199
0
5
207
0
6
215
0
7
223
0
8
231
0
8
0
167
0
1
175
0
2
183
0
4
200
0
5
208
0
6
216
0
7
224
0
8
232
0
8
0
168
0
1
176
0
2
184
0
3
192
0
5
209
0
6
217
0
7
225
0
8
233
0
8
0
169
0
1
177
0
2
185
0
3
193
0
4
201
0
6
218
0
7
226
0
8
234
0
8
0
170
0
1
178
0
2
186
0
3
194
0
4
202
0
5
210
0
7
227
0
8
235
0
8
0
171
0
1
179
0
2
187
0
3
195
0
4
203
0
5
211
0
6
219
0
8
236
0
8
0
172
0
1
180
0
2
188
0
3
196
0
4
204
0
5
212
0
6
220
0
7
228
0
end_DTG
begin_DTG
8
1
101
0
2
109
0
3
117
0
4
125
0
5
133
0
6
141
0
7
149
0
8
157
0
8
0
93
0
2
110
0
3
118
0
4
126
0
5
134
0
6
142
0
7
150
0
8
158
0
8
0
94
0
1
102
0
3
119
0
4
127
0
5
135
0
6
143
0
7
151
0
8
159
0
8
0
95
0
1
103
0
2
111
0
4
128
0
5
136
0
6
144
0
7
152
0
8
160
0
8
0
96
0
1
104
0
2
112
0
3
120
0
5
137
0
6
145
0
7
153
0
8
161
0
8
0
97
0
1
105
0
2
113
0
3
121
0
4
129
0
6
146
0
7
154
0
8
162
0
8
0
98
0
1
106
0
2
114
0
3
122
0
4
130
0
5
138
0
7
155
0
8
163
0
8
0
99
0
1
107
0
2
115
0
3
123
0
4
131
0
5
139
0
6
147
0
8
164
0
8
0
100
0
1
108
0
2
116
0
3
124
0
4
132
0
5
140
0
6
148
0
7
156
0
end_DTG
begin_DTG
1
1
47
1
13 0
1
0
8
2
28 8
12 0
end_DTG
begin_DTG
1
1
46
1
2 0
1
0
15
2
24 1
1 0
end_DTG
begin_DTG
1
1
45
1
23 0
1
0
1
2
31 3
22 0
end_DTG
begin_DTG
1
1
44
1
16 0
1
0
6
2
29 1
15 0
end_DTG
begin_DTG
1
1
43
1
8 0
1
0
11
2
26 3
7 0
end_DTG
begin_DTG
1
1
42
1
20 0
1
0
4
2
30 5
19 0
end_DTG
begin_DTG
1
1
41
1
5 0
1
0
13
2
25 3
4 0
end_DTG
begin_DTG
1
1
40
1
13 0
1
0
7
2
28 2
11 0
end_DTG
begin_DTG
1
1
39
1
8 0
1
0
10
2
26 0
6 0
end_DTG
begin_DTG
1
1
38
1
16 0
1
0
5
2
29 3
14 0
end_DTG
begin_DTG
1
1
37
1
5 0
1
0
12
2
25 6
3 0
end_DTG
begin_DTG
1
1
36
1
20 0
1
0
3
2
30 5
18 0
end_DTG
begin_DTG
1
1
35
1
2 0
1
0
14
2
24 8
0 0
end_DTG
begin_DTG
0
7
0
54
3
34 0
31 8
22 0
0
61
3
37 0
30 8
19 0
0
66
3
41 0
29 8
14 0
0
73
3
32 0
28 8
12 0
0
80
3
36 0
26 8
7 0
0
87
3
38 0
25 8
4 0
0
91
3
44 0
24 8
0 0
end_DTG
begin_DTG
1
1
34
1
20 0
1
0
2
2
30 1
17 0
end_DTG
begin_DTG
1
1
33
1
23 0
1
0
0
2
31 6
21 0
end_DTG
begin_DTG
0
11
0
52
3
47 0
31 8
21 0
0
53
3
34 0
31 8
22 0
0
59
3
43 0
30 8
18 0
0
60
3
37 0
30 8
19 0
0
65
3
41 0
29 8
14 0
0
72
3
32 0
28 8
12 0
0
79
3
40 0
26 8
6 0
0
85
3
42 0
25 8
3 0
0
86
3
38 0
25 8
4 0
0
90
3
44 0
24 8
0 0
0
92
3
33 0
24 8
1 0
end_DTG
begin_DTG
0
11
0
50
3
47 0
31 5
21 0
0
51
3
34 0
31 5
22 0
0
57
3
43 0
30 5
18 0
0
58
3
37 0
30 5
19 0
0
64
3
41 0
29 5
14 0
0
71
3
32 0
28 5
12 0
0
78
3
40 0
26 5
6 0
0
83
3
42 0
25 5
3 0
0
84
3
38 0
25 5
4 0
0
88
3
44 0
24 5
0 0
0
89
3
33 0
24 5
1 0
end_DTG
begin_DTG
1
1
32
1
9 0
1
0
9
2
27 3
10 0
end_DTG
begin_DTG
0
8
0
49
3
47 0
31 3
21 0
0
56
3
46 0
30 3
17 0
0
63
3
35 0
29 3
15 0
0
69
3
39 0
28 3
11 0
0
70
3
32 0
28 3
12 0
0
75
3
50 0
27 3
10 0
0
77
3
40 0
26 3
6 0
0
82
3
38 0
25 3
4 0
end_DTG
begin_DTG
0
8
0
48
3
47 0
31 2
21 0
0
55
3
46 0
30 2
17 0
0
62
3
35 0
29 2
15 0
0
67
3
39 0
28 2
11 0
0
68
3
32 0
28 2
12 0
0
74
3
50 0
27 2
10 0
0
76
3
40 0
26 2
6 0
0
81
3
38 0
25 2
4 0
end_DTG
begin_CG
5
44 1
49 1
48 1
45 1
2 1
4
33 1
49 1
48 1
2 1
4
44 1
33 1
0 1
1 1
4
42 1
49 1
48 1
5 1
7
38 1
52 1
51 1
49 1
48 1
45 1
5 1
4
42 1
38 1
3 1
4 1
6
40 1
52 1
51 1
49 1
48 1
8 1
3
36 1
45 1
8 1
4
40 1
36 1
6 1
7 1
2
50 1
10 1
4
50 1
52 1
51 1
9 1
4
39 1
52 1
51 1
13 1
7
32 1
52 1
51 1
49 1
48 1
45 1
13 1
4
39 1
32 1
11 1
12 1
5
41 1
49 1
48 1
45 1
16 1
4
35 1
52 1
51 1
16 1
4
41 1
35 1
14 1
15 1
4
46 1
52 1
51 1
20 1
4
43 1
49 1
48 1
20 1
5
37 1
49 1
48 1
45 1
20 1
6
46 1
43 1
37 1
17 1
18 1
19 1
6
47 1
52 1
51 1
49 1
48 1
23 1
5
34 1
49 1
48 1
45 1
23 1
4
47 1
34 1
21 1
22 1
5
44 1
33 1
49 2
48 2
45 1
7
42 1
38 1
52 1
51 1
49 2
48 2
45 1
7
40 1
36 1
52 1
51 1
49 1
48 1
45 1
3
50 1
52 1
51 1
7
39 1
32 1
52 2
51 2
49 1
48 1
45 1
7
41 1
35 1
52 1
51 1
49 1
48 1
45 1
8
46 1
43 1
37 1
52 1
51 1
49 2
48 2
45 1
7
47 1
34 1
52 1
51 1
49 2
48 2
45 1
5
52 1
51 1
49 1
48 1
45 1
2
49 1
48 1
3
49 1
48 1
45 1
2
52 1
51 1
1
45 1
3
49 1
48 1
45 1
5
52 1
51 1
49 1
48 1
45 1
2
52 1
51 1
4
52 1
51 1
49 1
48 1
3
49 1
48 1
45 1
2
49 1
48 1
2
49 1
48 1
3
49 1
48 1
45 1
0
2
52 1
51 1
4
52 1
51 1
49 1
48 1
0
0
2
52 1
51 1
0
0
end_CG
