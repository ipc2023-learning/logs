begin_version
3
end_version
begin_metric
0
end_metric
78
begin_variable
var70
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins20)
NegatedAtom power_on(ins20)
end_variable
begin_variable
var69
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var88
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var89
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var59
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




TG
begin_DTG
0
18
0
223
3
57 0
33 0
10 0
0
293
3
47 0
30 0
3 0
0
291
3
52 0
30 0
2 0
0
289
3
55 0
30 0
1 0
0
287
3
59 0
30 0
0 0
0
265
3
41 0
31 0
6 0
0
264
3
56 0
31 0
5 0
0
258
3
42 0
32 0
9 0
0
225
3
48 0
33 0
11 0
0
61
3
43 0
39 0
29 0
0
211
3
45 0
34 0
14 0
0
183
3
40 0
35 0
16 0
0
181
3
50 0
35 0
15 0
0
144
3
44 0
36 0
20 0
0
142
3
49 0
36 0
19 0
0
141
3
51 0
36 0
18 0
0
111
3
53 0
37 0
23 0
0
80
3
46 0
38 0
26 0
end_DTG
begin_DTG
0
16
0
60
3
43 0
39 0
29 0
0
78
3
54 0
38 0
25 0
0
79
3
46 0
38 0
26 0
0
109
3
58 0
37 0
22 0
0
110
3
53 0
37 0
23 0
0
140
3
51 0
36 0
18 0
0
143
3
44 0
36 0
20 0
0
182
3
40 0
35 0
16 0
0
210
3
45 0
34 0
14 0
0
222
3
57 0
33 0
10 0
0
224
3
48 0
33 0
11 0
0
263
3
56 0
31 0
5 0
0
286
3
59 0
30 0
0 0
0
288
3
55 0
30 0
1 0
0
290
3
52 0
30 0
2 0
0
292
3
47 0
30 0
3 0
end_DTG
begin_CG
20
59 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
4 1
14
55 1
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
4 1
14
52 1
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
4 1
14
47 1
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
4 1
8
59 1
55 1
52 1
47 1
0 1
1 1
2 1
3 1
20
56 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
7 1
7
41 1
76 1
74 1
66 1
64 1
61 1
7 1
4
56 1
41 1
5 1
6 1
2
42 1
9 1
7
42 1
76 1
74 1
66 1
64 1
61 1
8 1
20
57 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
12 1
20
48 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
12 1
4
57 1
48 1
10 1
11 1
2
45 1
14 1
14
45 1
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
13 1
13
50 1
76 1
75 1
74 1
73 1
70 1
68 1
66 1
64 1
62 1
61 1
60 1
17 1
20
40 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
17 1
4
50 1
40 1
15 1
16 1
20
51 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
21 1
7
49 1
76 1
74 1
66 1
64 1
61 1
21 1
20
44 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
21 1
6
51 1
49 1
44 1
18 1
19 1
20 1
15
58 1
77 1
75 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
65 1
63 1
62 1
60 1
24 1
20
53 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
24 1
4
58 1
53 1
22 1
23 1
15
54 1
77 1
75 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
65 1
63 1
62 1
60 1
27 1
20
46 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
27 1
4
54 1
46 1
25 1
26 1
2
43 1
29 1
20
43 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
28 1
22
59 1
55 1
52 1
47 1
77 4
76 4
75 1
74 4
73 1
72 4
71 4
70 1
69 4
68 1
67 4
66 4
65 4
64 4
63 4
62 1
61 4
60 1
20
56 1
41 1
77 1
76 2
75 1
74 2
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 2
65 1
64 2
63 1
62 1
61 2
60 1
6
42 1
76 1
74 1
66 1
64 1
61 1
20
57 1
48 1
77 2
76 2
75 2
74 2
73 2
72 2
71 2
70 2
69 2
68 2
67 2
66 2
65 2
64 2
63 2
62 2
61 2
60 2
13
45 1
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
20
50 1
40 1
77 1
76 2
75 2
74 2
73 2
72 1
71 1
70 2
69 1
68 2
67 1
66 2
65 1
64 2
63 1
62 2
61 2
60 2
21
51 1
49 1
44 1
77 2
76 3
75 2
74 3
73 2
72 2
71 2
70 2
69 2
68 2
67 2
66 3
65 2
64 3
63 2
62 2
61 3
60 2
20
58 1
53 1
77 2
76 1
75 2
74 1
73 2
72 2
71 2
70 2
69 2
68 2
67 2
66 1
65 2
64 1
63 2
62 2
61 1
60 2
20
54 1
46 1
77 2
76 1
75 2
74 1
73 2
72 2
71 2
70 2
69 2
68 2
67 2
66 1
65 2
64 1
63 2
62 2
61 1
60 2
19
43 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
5
76 1
74 1
66 1
64 1
61 1
5
76 1
74 1
66 1
64 1
61 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
12
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
12
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
5
76 1
74 1
66 1
64 1
61 1
11
76 1
75 1
74 1
73 1
70 1
68 1
66 1
64 1
62 1
61 1
60 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
12
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
13
77 1
75 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
65 1
63 1
62 1
60 1
12
77 1
76 1
74 1
72 1
71 1
69 1
67 1
66 1
65 1
64 1
63 1
61 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
13
77 1
75 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
65 1
63 1
62 1
60 1
18
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
