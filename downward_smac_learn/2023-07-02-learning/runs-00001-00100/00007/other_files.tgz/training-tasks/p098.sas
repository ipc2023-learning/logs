begin_version
3
end_version
begin_metric
0
end_metric
81
begin_variable
var73
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var69
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var89
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var88
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins20)
NegatedAtom power_on(ins20)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var59
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




4 3
13 0
0
207
3
49 0
33 3
9 0
0
246
3
43 0
31 3
4 0
0
278
3
42 0
30 3
1 0
end_DTG
begin_DTG
0
11
0
66
3
47 0
39 2
27 0
0
67
3
44 0
39 2
28 0
0
94
3
55 0
38 2
23 0
0
96
3
46 0
38 2
25 0
0
126
3
41 0
37 2
21 0
0
147
3
67 0
36 2
17 0
0
175
3
53 0
35 2
14 0
0
199
3
66 0
34 2
13 0
0
206
3
49 0
33 2
9 0
0
242
3
43 0
31 2
4 0
0
275
3
42 0
30 2
1 0
end_DTG
begin_DTG
0
11
0
64
3
47 0
39 1
27 0
0
65
3
44 0
39 1
28 0
0
91
3
55 0
38 1
23 0
0
93
3
46 0
38 1
25 0
0
124
3
41 0
37 1
21 0
0
145
3
67 0
36 1
17 0
0
173
3
53 0
35 1
14 0
0
198
3
66 0
34 1
13 0
0
205
3
49 0
33 1
9 0
0
239
3
43 0
31 1
4 0
0
273
3
42 0
30 1
1 0
end_DTG
begin_DTG
0
14
0
61
3
47 0
39 0
27 0
0
63
3
44 0
39 0
28 0
0
87
3
55 0
38 0
23 0
0
88
3
51 0
38 0
24 0
0
122
3
41 0
37 0
21 0
0
142
3
67 0
36 0
17 0
0
144
3
52 0
36 0
18 0
0
170
3
53 0
35 0
14 0
0
172
3
48 0
35 0
15 0
0
204
3
45 0
33 0
10 0
0
233
3
50 0
31 0
3 0
0
236
3
43 0
31 0
4 0
0
269
3
56 0
30 0
0 0
0
271
3
42 0
30 0
1 0
end_DTG
begin_DTG
0
11
0
60
3
47 0
39 0
27 0
0
62
3
44 0
39 0
28 0
0
86
3
55 0
38 0
23 0
0
90
3
46 0
38 0
25 0
0
121
3
41 0
37 0
21 0
0
141
3
67 0
36 0
17 0
0
169
3
53 0
35 0
14 0
0
197
3
66 0
34 0
13 0
0
203
3
49 0
33 0
9 0
0
235
3
43 0
31 0
4 0
0
270
3
42 0
30 0
1 0
end_DTG
begin_CG
17
56 1
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
2 1
15
42 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
2 1
4
56 1
42 1
0 1
1 1
17
50 1
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
5 1
23
43 1
65 1
80 1
79 1
64 1
78 1
63 1
77 1
62 1
76 1
75 1
61 1
74 1
60 1
73 1
72 1
59 1
71 1
70 1
69 1
58 1
68 1
5 1
4
50 1
43 1
3 1
4 1
10
54 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
8 1
10
40 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
8 1
4
54 1
40 1
6 1
7 1
8
49 1
80 1
78 1
77 1
76 1
73 1
70 1
11 1
9
45 1
79 1
75 1
74 1
72 1
71 1
69 1
68 1
11 1
4
49 1
45 1
9 1
10 1
2
66 1
13 1
8
66 1
80 1
78 1
77 1
76 1
73 1
70 1
12 1
15
53 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
16 1
17
48 1
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
16 1
4
53 1
48 1
14 1
15 1
15
67 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
19 1
17
52 1
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
19 1
4
67 1
52 1
17 1
18 1
10
57 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
22 1
15
41 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
22 1
4
57 1
41 1
20 1
21 1
15
55 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
26 1
9
51 1
79 1
75 1
74 1
72 1
71 1
69 1
68 1
26 1
16
46 1
65 1
80 1
64 1
78 1
63 1
77 1
62 1
76 1
61 1
60 1
73 1
59 1
70 1
58 1
26 1
6
55 1
51 1
46 1
23 1
24 1
25 1
15
47 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
29 1
15
44 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
29 1
4
47 1
44 1
27 1
28 1
23
56 1
42 1
65 1
80 1
79 2
64 1
78 1
63 1
77 1
62 1
76 1
75 2
61 1
74 2
60 1
73 1
72 2
59 1
71 2
70 1
69 2
58 1
68 2
23
50 1
43 1
65 2
80 1
79 2
64 2
78 1
63 2
77 1
62 2
76 1
75 2
61 2
74 2
60 2
73 1
72 2
59 2
71 2
70 1
69 2
58 2
68 2
10
54 1
40 1
65 2
64 2
63 2
62 2
61 2
60 2
59 2
58 2
15
49 1
45 1
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
7
66 1
80 1
78 1
77 1
76 1
73 1
70 1
23
53 1
48 1
65 1
80 1
79 2
64 1
78 1
63 1
77 1
62 1
76 1
75 2
61 1
74 2
60 1
73 1
72 2
59 1
71 2
70 1
69 2
58 1
68 2
23
67 1
52 1
65 1
80 1
79 2
64 1
78 1
63 1
77 1
62 1
76 1
75 2
61 1
74 2
60 1
73 1
72 2
59 1
71 2
70 1
69 2
58 1
68 2
23
57 1
41 1
65 1
80 1
79 1
64 1
78 1
63 1
77 1
62 1
76 1
75 1
61 1
74 1
60 1
73 1
72 1
59 1
71 1
70 1
69 1
58 1
68 1
24
55 1
51 1
46 1
65 1
80 2
79 2
64 1
78 2
63 1
77 2
62 1
76 2
75 2
61 1
74 2
60 1
73 2
72 2
59 1
71 2
70 2
69 2
58 1
68 2
15
47 1
44 1
80 2
79 2
78 2
77 2
76 2
75 2
74 2
73 2
72 2
71 2
70 2
69 2
68 2
8
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
13
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
13
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
21
65 1
80 1
79 1
64 1
78 1
63 1
77 1
62 1
76 1
75 1
61 1
74 1
60 1
73 1
72 1
59 1
71 1
70 1
69 1
58 1
68 1
13
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
7
79 1
75 1
74 1
72 1
71 1
69 1
68 1
14
65 1
80 1
64 1
78 1
63 1
77 1
62 1
76 1
61 1
60 1
73 1
59 1
70 1
58 1
13
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
15
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
6
80 1
78 1
77 1
76 1
73 1
70 1
15
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
7
79 1
75 1
74 1
72 1
71 1
69 1
68 1
15
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
13
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
8
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
13
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
15
65 1
79 1
64 1
63 1
62 1
75 1
61 1
74 1
60 1
72 1
59 1
71 1
69 1
58 1
68 1
8
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
0
0
0
0
0
0
0
0
6
80 1
78 1
77 1
76 1
73 1
70 1
13
80 1
79 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
