begin_version
3
end_version
begin_metric
0
end_metric
58
begin_variable
var68
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var49
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var48
-1
10
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir10)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
0
9
0
289
0
1
298
0
2
307
0
3
316
0
4
325
0
5
334
0
7
353
0
8
362
0
9
371
0
9
0
290
0
1
299
0
2
308
0
3
317
0
4
326
0
5
335
0
6
344
0
8
363
0
9
372
0
9
0
291
0
1
300
0
2
309
0
3
318
0
4
327
0
5
336
0
6
345
0
7
354
0
9
373
0
9
0
292
0
1
301
0
2
310
0
3
319
0
4
328
0
5
337
0
6
346
0
7
355
0
8
364
0
end_DTG
begin_DTG
9
1
203
0
2
212
0
3
221
0
4
230
0
5
239
0
6
248
0
7
257
0
8
266
0
9
275
0
9
0
194
0
2
213
0
3
222
0
4
231
0
5
240
0
6
249
0
7
258
0
8
267
0
9
276
0
9
0
195
0
1
204
0
3
223
0
4
232
0
5
241
0
6
250
0
7
259
0
8
268
0
9
277
0
9
0
196
0
1
205
0
2
214
0
4
233
0
5
242
0
6
251
0
7
260
0
8
269
0
9
278
0
9
0
197
0
1
206
0
2
215
0
3
224
0
5
243
0
6
252
0
7
261
0
8
270
0
9
279
0
9
0
198
0
1
207
0
2
216
0
3
225
0
4
234
0
6
253
0
7
262
0
8
271
0
9
280
0
9
0
199
0
1
208
0
2
217
0
3
226
0
4
235
0
5
244
0
7
263
0
8
272
0
9
281
0
9
0
200
0
1
209
0
2
218
0
3
227
0
4
236
0
5
245
0
6
254
0
8
273
0
9
282
0
9
0
201
0
1
210
0
2
219
0
3
228
0
4
237
0
5
246
0
6
255
0
7
264
0
9
283
0
9
0
202
0
1
211
0
2
220
0
3
229
0
4
238
0
5
247
0
6
256
0
7
265
0
8
274
0
end_DTG
begin_DTG
9
1
113
0
2
122
0
3
131
0
4
140
0
5
149
0
6
158
0
7
167
0
8
176
0
9
185
0
9
0
104
0
2
123
0
3
132
0
4
141
0
5
150
0
6
159
0
7
168
0
8
177
0
9
186
0
9
0
105
0
1
114
0
3
133
0
4
142
0
5
151
0
6
160
0
7
169
0
8
178
0
9
187
0
9
0
106
0
1
115
0
2
124
0
4
143
0
5
152
0
6
161
0
7
170
0
8
179
0
9
188
0
9
0
107
0
1
116
0
2
125
0
3
134
0
5
153
0
6
162
0
7
171
0
8
180
0
9
189
0
9
0
108
0
1
117
0
2
126
0
3
135
0
4
144
0
6
163
0
7
172
0
8
181
0
9
190
0
9
0
109
0
1
118
0
2
127
0
3
136
0
4
145
0
5
154
0
7
173
0
8
182
0
9
191
0
9
0
110
0
1
119
0
2
128
0
3
137
0
4
146
0
5
155
0
6
164
0
8
183
0
9
192
0
9
0
111
0
1
120
0
2
129
0
3
138
0
4
147
0
5
156
0
6
165
0
7
174
0
9
193
0
9
0
112
0
1
121
0
2
130
0
3
139
0
4
148
0
5
157
0
6
166
0
7
175
0
8
184
0
end_DTG
begin_DTG
1
1
53
1
16 0
1
0
6
2
32 5
17 0
end_DTG
begin_DTG
1
1
52
1
26 0
1
0
2
2
35 3
25 0
end_DTG
begin_DTG
1
1
51
1
3 0
1
0
15
2
28 5
4 0
end_DTG
begin_DTG
1
1
50
1
9 0
1
0
14
2
29 6
8 0
end_DTG
begin_DTG
1
1
49
1
2 0
1
0
17
2
27 2
1 0
end_DTG
begin_DTG
1
1
48
1
15 0
1
0
8
2
31 3
14 0
end_DTG
begin_DTG
1
1
47
1
22 0
1
0
4
2
34 6
21 0
end_DTG
begin_DTG
1
1
46
1
18 0
1
0
5
2
33 6
19 0
end_DTG
begin_DTG
1
1
45
1
15 0
1
0
7
2
31 4
13 0
end_DTG
begin_DTG
1
1
44
1
12 0
1
0
10
2
30 7
11 0
end_DTG
begin_DTG
1
1
43
1
9 0
1
0
13
2
29 2
7 0
end_DTG
begin_DTG
1
1
42
1
26 0
1
0
1
2
35 9
24 0
end_DTG
begin_DTG
1
1
41
1
26 0
1
0
0
2
35 9
23 0
end_DTG
begin_DTG
1
1
40
1
22 0
1
0
3
2
34 4
20 0
end_DTG
begin_DTG
1
1
39
1
9 0
1
0
12
2
29 4
6 0
end_DTG
begin_DTG
1
1
38
1
2 0
1
0
16
2
27 5
0 0
end_DTG
begin_DTG
1
1
37
1
9 0
1
0
11
2
29 5
5 0
end_DTG
begin_DTG
1
1
36
1
12 0
1
0
9
2
30 5
10 0
end_DTG
begin_DTG
0
12
0
61
3
47 0
35 7
24 0
0
62
3
37 0
35 7
25 0
0
66
3
42 0
34 7
21 0
0
70
3
43 0
33 7
19 0
0
78
3
44 0
31 7
13 0
0
79
3
41 0
31 7
14 0
0
85
3
53 0
30 7
10 0
0
86
3
45 0
30 7
11 0
0
94
3
50 0
29 7
6 0
0
95
3
39 0
29 7
8 0
0
98
3
38 0
28 7
4 0
0
103
3
40 0
27 7
1 0
end_DTG
begin_DTG
0
13
0
59
3
48 0
35 5
23 0
0
60
3
47 0
35 5
24 0
0
64
3
49 0
34 5
20 0
0
65
3
42 0
34 5
21 0
0
69
3
43 0
33 5
19 0
0
71
3
36 0
32 5
17 0
0
76
3
44 0
31 5
13 0
0
77
3
41 0
31 5
14 0
0
84
3
53 0
30 5
10 0
0
92
3
52 0
29 5
5 0
0
93
3
50 0
29 5
6 0
0
97
3
38 0
28 5
4 0
0
102
3
51 0
27 5
0 0
end_DTG
begin_DTG
0
12
0
57
3
47 0
35 2
24 0
0
58
3
37 0
35 2
25 0
0
63
3
42 0
34 2
21 0
0
68
3
43 0
33 2
19 0
0
74
3
44 0
31 2
13 0
0
75
3
41 0
31 2
14 0
0
82
3
53 0
30 2
10 0
0
83
3
45 0
30 2
11 0
0
90
3
50 0
29 2
6 0
0
91
3
39 0
29 2
8 0
0
96
3
38 0
28 2
4 0
0
101
3
40 0
27 2
1 0
end_DTG
begin_DTG
0
13
0
54
3
48 0
35 0
23 0
0
55
3
47 0
35 0
24 0
0
56
3
37 0
35 0
25 0
0
67
3
43 0
33 0
19 0
0
72
3
44 0
31 0
13 0
0
73
3
41 0
31 0
14 0
0
80
3
53 0
30 0
10 0
0
81
3
45 0
30 0
11 0
0
87
3
52 0
29 0
5 0
0
88
3
50 0
29 0
6 0
0
89
3
46 0
29 0
7 0
0
99
3
51 0
27 0
0 0
0
100
3
40 0
27 0
1 0
end_DTG
begin_CG
4
51 1
57 1
55 1
2 1
5
40 1
57 1
56 1
54 1
2 1
4
51 1
40 1
0 1
1 1
2
38 1
4 1
5
38 1
56 1
55 1
54 1
3 1
4
52 1
57 1
55 1
9 1
6
50 1
57 1
56 1
55 1
54 1
9 1
3
46 1
57 1
9 1
4
39 1
56 1
54 1
9 1
8
52 1
50 1
46 1
39 1
5 1
6 1
7 1
8 1
6
53 1
57 1
56 1
55 1
54 1
12 1
5
45 1
57 1
56 1
54 1
12 1
4
53 1
45 1
10 1
11 1
6
44 1
57 1
56 1
55 1
54 1
15 1
6
41 1
57 1
56 1
55 1
54 1
15 1
4
44 1
41 1
13 1
14 1
2
36 1
17 1
3
36 1
55 1
16 1
2
43 1
19 1
6
43 1
57 1
56 1
55 1
54 1
18 1
3
49 1
55 1
22 1
5
42 1
56 1
55 1
54 1
22 1
4
49 1
42 1
20 1
21 1
4
48 1
57 1
55 1
26 1
6
47 1
57 1
56 1
55 1
54 1
26 1
5
37 1
57 1
56 1
54 1
26 1
6
48 1
47 1
37 1
23 1
24 1
25 1
6
51 1
40 1
57 2
56 1
55 1
54 1
4
38 1
56 1
55 1
54 1
8
52 1
50 1
46 1
39 1
57 3
56 2
55 2
54 2
6
53 1
45 1
57 2
56 2
55 1
54 2
6
44 1
41 1
57 2
56 2
55 2
54 2
2
36 1
55 1
5
43 1
57 1
56 1
55 1
54 1
5
49 1
42 1
56 1
55 2
54 1
7
48 1
47 1
37 1
57 3
56 2
55 2
54 2
1
55 1
3
57 1
56 1
54 1
3
56 1
55 1
54 1
2
56 1
54 1
3
57 1
56 1
54 1
4
57 1
56 1
55 1
54 1
3
56 1
55 1
54 1
4
57 1
56 1
55 1
54 1
4
57 1
56 1
55 1
54 1
3
57 1
56 1
54 1
1
57 1
4
57 1
56 1
55 1
54 1
2
57 1
55 1
1
55 1
4
57 1
56 1
55 1
54 1
2
57 1
55 1
2
57 1
55 1
4
57 1
56 1
55 1
54 1
0
0
0
0
end_CG
