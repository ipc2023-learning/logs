begin_version
3
end_version
begin_metric
0
end_metric
51
begin_variable
var57
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var61
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var60
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var51
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var50
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var43
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var42
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins15)
NegatedAtom calibrated(ins15)
end_variable
begin_variable
var5
-1
2
Atom cal




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
8
383
0
8
0
319
0
1
327
0
2
335
0
3
343
0
4
351
0
5
359
0
6
367
0
8
384
0
8
0
320
0
1
328
0
2
336
0
3
344
0
4
352
0
5
360
0
6
368
0
7
376
0
end_DTG
begin_DTG
8
1
249
0
2
257
0
3
265
0
4
273
0
5
281
0
6
289
0
7
297
0
8
305
0
8
0
241
0
2
258
0
3
266
0
4
274
0
5
282
0
6
290
0
7
298
0
8
306
0
8
0
242
0
1
250
0
3
267
0
4
275
0
5
283
0
6
291
0
7
299
0
8
307
0
8
0
243
0
1
251
0
2
259
0
4
276
0
5
284
0
6
292
0
7
300
0
8
308
0
8
0
244
0
1
252
0
2
260
0
3
268
0
5
285
0
6
293
0
7
301
0
8
309
0
8
0
245
0
1
253
0
2
261
0
3
269
0
4
277
0
6
294
0
7
302
0
8
310
0
8
0
246
0
1
254
0
2
262
0
3
270
0
4
278
0
5
286
0
7
303
0
8
311
0
8
0
247
0
1
255
0
2
263
0
3
271
0
4
279
0
5
287
0
6
295
0
8
312
0
8
0
248
0
1
256
0
2
264
0
3
272
0
4
280
0
5
288
0
6
296
0
7
304
0
end_DTG
begin_DTG
8
1
177
0
2
185
0
3
193
0
4
201
0
5
209
0
6
217
0
7
225
0
8
233
0
8
0
169
0
2
186
0
3
194
0
4
202
0
5
210
0
6
218
0
7
226
0
8
234
0
8
0
170
0
1
178
0
3
195
0
4
203
0
5
211
0
6
219
0
7
227
0
8
235
0
8
0
171
0
1
179
0
2
187
0
4
204
0
5
212
0
6
220
0
7
228
0
8
236
0
8
0
172
0
1
180
0
2
188
0
3
196
0
5
213
0
6
221
0
7
229
0
8
237
0
8
0
173
0
1
181
0
2
189
0
3
197
0
4
205
0
6
222
0
7
230
0
8
238
0
8
0
174
0
1
182
0
2
190
0
3
198
0
4
206
0
5
214
0
7
231
0
8
239
0
8
0
175
0
1
183
0
2
191
0
3
199
0
4
207
0
5
215
0
6
223
0
8
240
0
8
0
176
0
1
184
0
2
192
0
3
200
0
4
208
0
5
216
0
6
224
0
7
232
0
end_DTG
begin_DTG
8
1
105
0
2
113
0
3
121
0
4
129
0
5
137
0
6
145
0
7
153
0
8
161
0
8
0
97
0
2
114
0
3
122
0
4
130
0
5
138
0
6
146
0
7
154
0
8
162
0
8
0
98
0
1
106
0
3
123
0
4
131
0
5
139
0
6
147
0
7
155
0
8
163
0
8
0
99
0
1
107
0
2
115
0
4
132
0
5
140
0
6
148
0
7
156
0
8
164
0
8
0
100
0
1
108
0
2
116
0
3
124
0
5
141
0
6
149
0
7
157
0
8
165
0
8
0
101
0
1
109
0
2
117
0
3
125
0
4
133
0
6
150
0
7
158
0
8
166
0
8
0
102
0
1
110
0
2
118
0
3
126
0
4
134
0
5
142
0
7
159
0
8
167
0
8
0
103
0
1
111
0
2
119
0
3
127
0
4
135
0
5
143
0
6
151
0
8
168
0
8
0
104
0
1
112
0
2
120
0
3
128
0
4
136
0
5
144
0
6
152
0
7
160
0
end_DTG
begin_DTG
1
1
44
1
20 0
1
0
3
2
29 2
19 0
end_DTG
begin_DTG
1
1
43
1
15 0
1
0
4
2
28 3
16 0
end_DTG
begin_DTG
1
1
42
1
21 0
1
0
0
2
30 2
22 0
end_DTG
begin_DTG
1
1
41
1
14 0
1
0
7
2
27 3
13 0
end_DTG
begin_DTG
1
1
40
1
20 0
1
0
2
2
29 5
18 0
end_DTG
begin_DTG
1
1
39
1
10 0
1
0
9
2
26 4
9 0
end_DTG
begin_DTG
1
1
38
1
6 0
1
0
10
2
25 0
7 0
end_DTG
begin_DTG
1
1
37
1
0 0
1
0
14
2
23 4
1 0
end_DTG
begin_DTG
1
1
36
1
20 0
1
0
1
2
29 1
17 0
end_DTG
begin_DTG
1
1
35
1
14 0
1
0
6
2
27 1
12 0
end_DTG
begin_DTG
1
1
34
1
5 0
1
0
13
2
24 5
4 0
end_DTG
begin_DTG
1
1
33
1
5 0
1
0
12
2
24 3
3 0
end_DTG
begin_DTG
1
1
32
1
10 0
1
0
8
2
26 2
8 0
end_DTG
begin_DTG
1
1
31
1
14 0
1
0
5
2
27 8
11 0
end_DTG
begin_DTG
0
11
0
46
3
33 0
30 3
22 0
0
51
3
39 0
29 3
17 0
0
52
3
31 0
29 3
19 0
0
58
3
32 0
28 3
16 0
0
65
3
44 0
27 3
11 0
0
66
3
40 0
27 3
12 0
0
68
3
34 0
27 3
13 0
0
76
3
43 0
26 3
8 0
0
77
3
36 0
26 3
9 0
0
82
3
37 0
25 3
7 0
0
95
3
38 0
23 3
1 0
end_DTG
begin_DTG
0
11
0
45
3
33 0
30 2
22 0
0
47
3
39 0
29 2
17 0
0
50
3
31 0
29 2
19 0
0
56
3
32 0
28 2
16 0
0
61
3
44 0
27 2
11 0
0
62
3
40 0
27 2
12 0
0
64
3
34 0
27 2
13 0
0
72
3
43 0
26 2
8 0
0
74
3
36 0
26 2
9 0
0
80
3
37 0
25 2
7 0
0
93
3
38 0
23 2
1 0
end_DTG
begin_DTG
1
1
30
1
5 0
1
0
11
2
24 4
2 0
end_DTG
begin_DTG
0
11
0
53
3
35 0
29 8
18 0
0
54
3
31 0
29 8
19 0
0
59
3
32 0
28 8
16 0
0
69
3
44 0
27 8
11 0
0
70
3
34 0
27 8
13 0
0
78
3
43 0
26 8
8 0
0
79
3
36 0
26 8
9 0
0
89
3
47 0
24 8
2 0
0
90
3
42 0
24 8
3 0
0
91
3
41 0
24 8
4 0
0
96
3
38 0
23 8
1 0
end_DTG
begin_DTG
0
8
0
57
3
32 0
28 3
16 0
0
67
3
34 0
27 3
13 0
0
75
3
43 0
26 3
8 0
0
81
3
37 0
25 3
7 0
0
86
3
47 0
24 3
2 0
0
87
3
42 0
24 3
3 0
0
88
3
41 0
24 3
4 0
0
94
3
38 0
23 3
1 0
end_DTG
begin_DTG
0
11
0
48
3
35 0
29 2
18 0
0
49
3
31 0
29 2
19 0
0
55
3
32 0
28 2
16 0
0
60
3
44 0
27 2
11 0
0
63
3
34 0
27 2
13 0
0
71
3
43 0
26 2
8 0
0
73
3
36 0
26 2
9 0
0
83
3
47 0
24 2
2 0
0
84
3
42 0
24 2
3 0
0
85
3
41 0
24 2
4 0
0
92
3
38 0
23 2
1 0
end_DTG
begin_CG
2
38 1
1 1
7
38 1
50 1
46 1
49 1
45 1
48 1
0 1
5
47 1
50 1
49 1
48 1
5 1
5
42 1
50 1
49 1
48 1
5 1
5
41 1
50 1
49 1
48 1
5 1
6
47 1
42 1
41 1
2 1
3 1
4 1
2
37 1
7 1
5
37 1
46 1
49 1
45 1
6 1
7
43 1
50 1
46 1
49 1
45 1
48 1
10 1
6
36 1
50 1
46 1
45 1
48 1
10 1
4
43 1
36 1
8 1
9 1
6
44 1
50 1
46 1
45 1
48 1
14 1
4
40 1
46 1
45 1
14 1
7
34 1
50 1
46 1
49 1
45 1
48 1
14 1
6
44 1
40 1
34 1
11 1
12 1
13 1
2
32 1
16 1
7
32 1
50 1
46 1
49 1
45 1
48 1
15 1
4
39 1
46 1
45 1
20 1
4
35 1
50 1
48 1
20 1
6
31 1
50 1
46 1
45 1
48 1
20 1
6
39 1
35 1
31 1
17 1
18 1
19 1
2
33 1
22 1
4
33 1
46 1
45 1
21 1
6
38 1
50 1
46 1
49 1
45 1
48 1
6
47 1
42 1
41 1
50 3
49 3
48 3
4
37 1
46 1
49 1
45 1
7
43 1
36 1
50 2
46 2
49 1
45 2
48 2
8
44 1
40 1
34 1
50 2
46 3
49 1
45 3
48 2
6
32 1
50 1
46 1
49 1
45 1
48 1
7
39 1
35 1
31 1
50 2
46 2
45 2
48 2
3
33 1
46 1
45 1
4
50 1
46 1
45 1
48 1
5
50 1
46 1
49 1
45 1
48 1
2
46 1
45 1
5
50 1
46 1
49 1
45 1
48 1
2
50 1
48 1
4
50 1
46 1
45 1
48 1
3
46 1
49 1
45 1
5
50 1
46 1
49 1
45 1
48 1
2
46 1
45 1
2
46 1
45 1
3
50 1
49 1
48 1
3
50 1
49 1
48 1
5
50 1
46 1
49 1
45 1
48 1
4
50 1
46 1
45 1
48 1
0
0
3
50 1
49 1
48 1
0
0
0
end_CG
