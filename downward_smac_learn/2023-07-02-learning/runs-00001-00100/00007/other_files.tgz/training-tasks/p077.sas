begin_version
3
end_version
begin_metric
0
end_metric
69
begin_variable
var62
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var61
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var60
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var51
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var43
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var7
-1
2
Atom calib




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




_DTG
0
11
0
80
3
55 0
29 3
17 0
0
82
3
42 0
29 3
18 0
0
123
3
40 0
28 3
13 0
0
124
3
36 0
28 3
14 0
0
126
3
32 0
28 3
15 0
0
177
3
46 0
27 3
9 0
0
179
3
34 0
27 3
10 0
0
205
3
33 0
26 3
8 0
0
221
3
45 0
25 3
4 0
0
253
3
44 0
24 3
0 0
0
255
3
41 0
24 3
1 0
end_DTG
begin_DTG
0
11
0
76
3
55 0
29 2
17 0
0
79
3
42 0
29 2
18 0
0
116
3
40 0
28 2
13 0
0
118
3
36 0
28 2
14 0
0
121
3
32 0
28 2
15 0
0
173
3
46 0
27 2
9 0
0
175
3
34 0
27 2
10 0
0
204
3
33 0
26 2
8 0
0
218
3
45 0
25 2
4 0
0
246
3
44 0
24 2
0 0
0
249
3
41 0
24 2
1 0
end_DTG
begin_DTG
0
13
0
49
3
35 0
31 2
23 0
0
58
3
38 0
30 2
21 0
0
75
3
55 0
29 2
17 0
0
78
3
42 0
29 2
18 0
0
114
3
43 0
28 2
12 0
0
115
3
40 0
28 2
13 0
0
117
3
36 0
28 2
14 0
0
120
3
32 0
28 2
15 0
0
172
3
46 0
27 2
9 0
0
203
3
33 0
26 2
8 0
0
245
3
44 0
24 2
0 0
0
248
3
41 0
24 2
1 0
0
251
3
39 0
24 2
2 0
end_DTG
begin_DTG
0
11
0
73
3
55 0
29 1
17 0
0
74
3
42 0
29 1
18 0
0
110
3
40 0
28 1
13 0
0
111
3
36 0
28 1
14 0
0
112
3
32 0
28 1
15 0
0
169
3
46 0
27 1
9 0
0
170
3
34 0
27 1
10 0
0
202
3
33 0
26 1
8 0
0
216
3
45 0
25 1
4 0
0
242
3
44 0
24 1
0 0
0
243
3
41 0
24 1
1 0
end_DTG
begin_DTG
0
13
0
48
3
35 0
31 0
23 0
0
56
3
38 0
30 0
21 0
0
70
3
55 0
29 0
17 0
0
72
3
42 0
29 0
18 0
0
105
3
43 0
28 0
12 0
0
106
3
40 0
28 0
13 0
0
107
3
36 0
28 0
14 0
0
109
3
32 0
28 0
15 0
0
167
3
46 0
27 0
9 0
0
201
3
33 0
26 0
8 0
0
237
3
44 0
24 0
0 0
0
239
3
41 0
24 0
1 0
0
241
3
39 0
24 0
2 0
end_DTG
begin_CG
23
44 1
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
3 1
23
41 1
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
3 1
17
39 1
54 1
68 1
53 1
66 1
52 1
51 1
63 1
50 1
61 1
49 1
60 1
48 1
58 1
47 1
56 1
3 1
6
44 1
41 1
39 1
0 1
1 1
2 1
16
45 1
54 1
67 1
53 1
65 1
52 1
64 1
51 1
62 1
50 1
49 1
59 1
48 1
57 1
47 1
6 1
10
37 1
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
6 1
4
45 1
37 1
4 1
5 1
2
33 1
8 1
15
33 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
7 1
23
46 1
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
11 1
16
34 1
54 1
67 1
53 1
65 1
52 1
64 1
51 1
62 1
50 1
49 1
59 1
48 1
57 1
47 1
11 1
4
46 1
34 1
9 1
10 1
17
43 1
54 1
68 1
53 1
66 1
52 1
51 1
63 1
50 1
61 1
49 1
60 1
48 1
58 1
47 1
56 1
16 1
15
40 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
16 1
15
36 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
16 1
23
32 1
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
16 1
8
43 1
40 1
36 1
32 1
12 1
13 1
14 1
15 1
15
55 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
19 1
23
42 1
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
19 1
4
55 1
42 1
17 1
18 1
2
38 1
21 1
17
38 1
54 1
68 1
53 1
66 1
52 1
51 1
63 1
50 1
61 1
49 1
60 1
48 1
58 1
47 1
56 1
20 1
2
35 1
23 1
9
35 1
68 1
66 1
63 1
61 1
60 1
58 1
56 1
22 1
24
44 1
41 1
39 1
54 3
68 3
67 2
53 3
66 3
65 2
52 3
64 2
51 3
63 3
62 2
50 3
61 3
49 3
60 3
59 2
48 3
58 3
57 2
47 3
56 3
16
45 1
37 1
54 2
67 1
53 2
65 1
52 2
64 1
51 2
62 1
50 2
49 2
59 1
48 2
57 1
47 2
14
33 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
23
46 1
34 1
54 2
68 1
67 2
53 2
66 1
65 2
52 2
64 2
51 2
63 1
62 2
50 2
61 1
49 2
60 1
59 2
48 2
58 1
57 2
47 2
56 1
25
43 1
40 1
36 1
32 1
54 2
68 4
67 3
53 2
66 4
65 3
52 2
64 3
51 2
63 4
62 3
50 2
61 4
49 2
60 4
59 3
48 2
58 4
57 3
47 2
56 4
23
55 1
42 1
54 1
68 2
67 2
53 1
66 2
65 2
52 1
64 2
51 1
63 2
62 2
50 1
61 2
49 1
60 2
59 2
48 1
58 2
57 2
47 1
56 2
16
38 1
54 1
68 1
53 1
66 1
52 1
51 1
63 1
50 1
61 1
49 1
60 1
48 1
58 1
47 1
56 1
8
35 1
68 1
66 1
63 1
61 1
60 1
58 1
56 1
21
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
13
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
14
54 1
67 1
53 1
65 1
52 1
64 1
51 1
62 1
50 1
49 1
59 1
48 1
57 1
47 1
7
68 1
66 1
63 1
61 1
60 1
58 1
56 1
13
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
8
54 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
15
54 1
68 1
53 1
66 1
52 1
51 1
63 1
50 1
61 1
49 1
60 1
48 1
58 1
47 1
56 1
15
54 1
68 1
53 1
66 1
52 1
51 1
63 1
50 1
61 1
49 1
60 1
48 1
58 1
47 1
56 1
13
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
21
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
21
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
15
54 1
68 1
53 1
66 1
52 1
51 1
63 1
50 1
61 1
49 1
60 1
48 1
58 1
47 1
56 1
21
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
14
54 1
67 1
53 1
65 1
52 1
64 1
51 1
62 1
50 1
49 1
59 1
48 1
57 1
47 1
21
54 1
68 1
67 1
53 1
66 1
65 1
52 1
64 1
51 1
63 1
62 1
50 1
61 1
49 1
60 1
59 1
48 1
58 1
57 1
47 1
56 1
0
0
0
0
0
0
0
0
13
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
58 1
57 1
56 1
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
