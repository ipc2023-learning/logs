begin_version
3
end_version
begin_metric
0
end_metric
59
begin_variable
var62
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var53
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var52
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var15
-1
2
Atom c




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




324
0
8
0
260
0
1
268
0
2
276
0
3
284
0
4
292
0
6
309
0
7
317
0
8
325
0
8
0
261
0
1
269
0
2
277
0
3
285
0
4
293
0
5
301
0
7
318
0
8
326
0
8
0
262
0
1
270
0
2
278
0
3
286
0
4
294
0
5
302
0
6
310
0
8
327
0
8
0
263
0
1
271
0
2
279
0
3
287
0
4
295
0
5
303
0
6
311
0
7
319
0
end_DTG
begin_DTG
8
1
192
0
2
200
0
3
208
0
4
216
0
5
224
0
6
232
0
7
240
0
8
248
0
8
0
184
0
2
201
0
3
209
0
4
217
0
5
225
0
6
233
0
7
241
0
8
249
0
8
0
185
0
1
193
0
3
210
0
4
218
0
5
226
0
6
234
0
7
242
0
8
250
0
8
0
186
0
1
194
0
2
202
0
4
219
0
5
227
0
6
235
0
7
243
0
8
251
0
8
0
187
0
1
195
0
2
203
0
3
211
0
5
228
0
6
236
0
7
244
0
8
252
0
8
0
188
0
1
196
0
2
204
0
3
212
0
4
220
0
6
237
0
7
245
0
8
253
0
8
0
189
0
1
197
0
2
205
0
3
213
0
4
221
0
5
229
0
7
246
0
8
254
0
8
0
190
0
1
198
0
2
206
0
3
214
0
4
222
0
5
230
0
6
238
0
8
255
0
8
0
191
0
1
199
0
2
207
0
3
215
0
4
223
0
5
231
0
6
239
0
7
247
0
end_DTG
begin_DTG
8
1
120
0
2
128
0
3
136
0
4
144
0
5
152
0
6
160
0
7
168
0
8
176
0
8
0
112
0
2
129
0
3
137
0
4
145
0
5
153
0
6
161
0
7
169
0
8
177
0
8
0
113
0
1
121
0
3
138
0
4
146
0
5
154
0
6
162
0
7
170
0
8
178
0
8
0
114
0
1
122
0
2
130
0
4
147
0
5
155
0
6
163
0
7
171
0
8
179
0
8
0
115
0
1
123
0
2
131
0
3
139
0
5
156
0
6
164
0
7
172
0
8
180
0
8
0
116
0
1
124
0
2
132
0
3
140
0
4
148
0
6
165
0
7
173
0
8
181
0
8
0
117
0
1
125
0
2
133
0
3
141
0
4
149
0
5
157
0
7
174
0
8
182
0
8
0
118
0
1
126
0
2
134
0
3
142
0
4
150
0
5
158
0
6
166
0
8
183
0
8
0
119
0
1
127
0
2
135
0
3
143
0
4
151
0
5
159
0
6
167
0
7
175
0
end_DTG
begin_DTG
1
1
53
1
23 0
1
0
3
2
34 2
22 0
end_DTG
begin_DTG
1
1
52
1
2 0
1
0
16
2
28 3
3 0
end_DTG
begin_DTG
1
1
51
1
0 0
1
0
17
2
27 0
1 0
end_DTG
begin_DTG
1
1
50
1
20 0
1
0
7
2
33 8
19 0
end_DTG
begin_DTG
1
1
49
1
26 0
1
0
1
2
35 2
25 0
end_DTG
begin_DTG
1
1
48
1
15 0
1
0
10
2
32 8
14 0
end_DTG
begin_DTG
1
1
47
1
10 0
1
0
11
2
31 5
11 0
end_DTG
begin_DTG
1
1
46
1
6 0
1
0
15
2
29 8
5 0
end_DTG
begin_DTG
1
1
45
1
20 0
1
0
6
2
33 6
18 0
end_DTG
begin_DTG
1
1
44
1
20 0
1
0
5
2
33 7
17 0
end_DTG
begin_DTG
1
1
43
1
15 0
1
0
9
2
32 5
13 0
end_DTG
begin_DTG
1
1
42
1
6 0
1
0
14
2
29 5
4 0
end_DTG
begin_DTG
1
1
41
1
9 0
1
0
13
2
30 8
8 0
end_DTG
begin_DTG
1
1
40
1
15 0
1
0
8
2
32 0
12 0
end_DTG
begin_DTG
1
1
39
1
20 0
1
0
4
2
33 1
16 0
end_DTG
begin_DTG
1
1
38
1
23 0
1
0
2
2
34 4
21 0
end_DTG
begin_DTG
1
1
37
1
26 0
1
0
0
2
35 6
24 0
end_DTG
begin_DTG
1
1
36
1
9 0
1
0
12
2
30 7
7 0
end_DTG
begin_DTG
0
8
0
58
3
40 0
35 6
25 0
0
67
3
36 0
34 6
22 0
0
72
3
50 0
33 6
16 0
0
73
3
44 0
33 6
18 0
0
82
3
46 0
32 6
13 0
0
92
3
53 0
30 6
7 0
0
101
3
47 0
29 6
4 0
0
107
3
37 0
28 6
3 0
end_DTG
begin_DTG
0
10
0
57
3
52 0
35 6
24 0
0
65
3
51 0
34 6
21 0
0
66
3
36 0
34 6
22 0
0
81
3
49 0
32 6
12 0
0
91
3
53 0
30 6
7 0
0
93
3
48 0
30 6
8 0
0
100
3
47 0
29 6
4 0
0
102
3
43 0
29 6
5 0
0
106
3
37 0
28 6
3 0
0
111
3
38 0
27 6
1 0
end_DTG
begin_DTG
0
10
0
56
3
52 0
35 2
24 0
0
63
3
51 0
34 2
21 0
0
64
3
36 0
34 2
22 0
0
80
3
49 0
32 2
12 0
0
89
3
53 0
30 2
7 0
0
90
3
48 0
30 2
8 0
0
98
3
47 0
29 2
4 0
0
99
3
43 0
29 2
5 0
0
105
3
37 0
28 2
3 0
0
110
3
38 0
27 2
1 0
end_DTG
begin_DTG
0
15
0
55
3
52 0
35 1
24 0
0
61
3
51 0
34 1
21 0
0
62
3
36 0
34 1
22 0
0
70
3
45 0
33 1
17 0
0
71
3
39 0
33 1
19 0
0
77
3
49 0
32 1
12 0
0
78
3
46 0
32 1
13 0
0
79
3
41 0
32 1
14 0
0
84
3
42 0
31 1
11 0
0
87
3
53 0
30 1
7 0
0
88
3
48 0
30 1
8 0
0
96
3
47 0
29 1
4 0
0
97
3
43 0
29 1
5 0
0
104
3
37 0
28 1
3 0
0
109
3
38 0
27 1
1 0
end_DTG
begin_DTG
0
15
0
54
3
52 0
35 0
24 0
0
59
3
51 0
34 0
21 0
0
60
3
36 0
34 0
22 0
0
68
3
45 0
33 0
17 0
0
69
3
39 0
33 0
19 0
0
74
3
49 0
32 0
12 0
0
75
3
46 0
32 0
13 0
0
76
3
41 0
32 0
14 0
0
83
3
42 0
31 0
11 0
0
85
3
53 0
30 0
7 0
0
86
3
48 0
30 0
8 0
0
94
3
47 0
29 0
4 0
0
95
3
43 0
29 0
5 0
0
103
3
37 0
28 0
3 0
0
108
3
38 0
27 0
1 0
end_DTG
begin_CG
2
38 1
1 1
6
38 1
58 1
57 1
56 1
55 1
0 1
2
37 1
3 1
7
37 1
58 1
57 1
56 1
55 1
54 1
2 1
7
47 1
58 1
57 1
56 1
55 1
54 1
6 1
6
43 1
58 1
57 1
56 1
55 1
6 1
4
47 1
43 1
4 1
5 1
7
53 1
58 1
57 1
56 1
55 1
54 1
9 1
6
48 1
58 1
57 1
56 1
55 1
9 1
4
53 1
48 1
7 1
8 1
2
42 1
11 1
4
42 1
58 1
57 1
10 1
6
49 1
58 1
57 1
56 1
55 1
15 1
5
46 1
58 1
57 1
54 1
15 1
4
41 1
58 1
57 1
15 1
6
49 1
46 1
41 1
12 1
13 1
14 1
3
50 1
54 1
20 1
4
45 1
58 1
57 1
20 1
3
44 1
54 1
20 1
4
39 1
58 1
57 1
20 1
8
50 1
45 1
44 1
39 1
16 1
17 1
18 1
19 1
6
51 1
58 1
57 1
56 1
55 1
23 1
7
36 1
58 1
57 1
56 1
55 1
54 1
23 1
4
51 1
36 1
21 1
22 1
6
52 1
58 1
57 1
56 1
55 1
26 1
3
40 1
54 1
26 1
4
52 1
40 1
24 1
25 1
5
38 1
58 1
57 1
56 1
55 1
6
37 1
58 1
57 1
56 1
55 1
54 1
7
47 1
43 1
58 2
57 2
56 2
55 2
54 1
7
53 1
48 1
58 2
57 2
56 2
55 2
54 1
3
42 1
58 1
57 1
8
49 1
46 1
41 1
58 3
57 3
56 1
55 1
54 1
7
50 1
45 1
44 1
39 1
58 2
57 2
54 2
7
51 1
36 1
58 2
57 2
56 2
55 2
54 1
7
52 1
40 1
58 1
57 1
56 1
55 1
54 1
5
58 1
57 1
56 1
55 1
54 1
5
58 1
57 1
56 1
55 1
54 1
4
58 1
57 1
56 1
55 1
2
58 1
57 1
1
54 1
2
58 1
57 1
2
58 1
57 1
4
58 1
57 1
56 1
55 1
1
54 1
2
58 1
57 1
3
58 1
57 1
54 1
5
58 1
57 1
56 1
55 1
54 1
4
58 1
57 1
56 1
55 1
4
58 1
57 1
56 1
55 1
1
54 1
4
58 1
57 1
56 1
55 1
4
58 1
57 1
56 1
55 1
5
58 1
57 1
56 1
55 1
54 1
0
0
0
0
0
end_CG
