begin_version
3
end_version
begin_metric
0
end_metric
60
begin_variable
var73
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat10, dir1)
Atom pointing(sat10, dir1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
0
366
0
1
375
0
2
384
0
3
393
0
4
402
0
5
411
0
6
420
0
7
429
0
9
448
0
9
0
367
0
1
376
0
2
385
0
3
394
0
4
403
0
5
412
0
6
421
0
7
430
0
8
439
0
end_DTG
begin_DTG
9
1
278
0
2
287
0
3
296
0
4
305
0
5
314
0
6
323
0
7
332
0
8
341
0
9
350
0
9
0
269
0
2
288
0
3
297
0
4
306
0
5
315
0
6
324
0
7
333
0
8
342
0
9
351
0
9
0
270
0
1
279
0
3
298
0
4
307
0
5
316
0
6
325
0
7
334
0
8
343
0
9
352
0
9
0
271
0
1
280
0
2
289
0
4
308
0
5
317
0
6
326
0
7
335
0
8
344
0
9
353
0
9
0
272
0
1
281
0
2
290
0
3
299
0
5
318
0
6
327
0
7
336
0
8
345
0
9
354
0
9
0
273
0
1
282
0
2
291
0
3
300
0
4
309
0
6
328
0
7
337
0
8
346
0
9
355
0
9
0
274
0
1
283
0
2
292
0
3
301
0
4
310
0
5
319
0
7
338
0
8
347
0
9
356
0
9
0
275
0
1
284
0
2
293
0
3
302
0
4
311
0
5
320
0
6
329
0
8
348
0
9
357
0
9
0
276
0
1
285
0
2
294
0
3
303
0
4
312
0
5
321
0
6
330
0
7
339
0
9
358
0
9
0
277
0
1
286
0
2
295
0
3
304
0
4
313
0
5
322
0
6
331
0
7
340
0
8
349
0
end_DTG
begin_DTG
9
1
188
0
2
197
0
3
206
0
4
215
0
5
224
0
6
233
0
7
242
0
8
251
0
9
260
0
9
0
179
0
2
198
0
3
207
0
4
216
0
5
225
0
6
234
0
7
243
0
8
252
0
9
261
0
9
0
180
0
1
189
0
3
208
0
4
217
0
5
226
0
6
235
0
7
244
0
8
253
0
9
262
0
9
0
181
0
1
190
0
2
199
0
4
218
0
5
227
0
6
236
0
7
245
0
8
254
0
9
263
0
9
0
182
0
1
191
0
2
200
0
3
209
0
5
228
0
6
237
0
7
246
0
8
255
0
9
264
0
9
0
183
0
1
192
0
2
201
0
3
210
0
4
219
0
6
238
0
7
247
0
8
256
0
9
265
0
9
0
184
0
1
193
0
2
202
0
3
211
0
4
220
0
5
229
0
7
248
0
8
257
0
9
266
0
9
0
185
0
1
194
0
2
203
0
3
212
0
4
221
0
5
230
0
6
239
0
8
258
0
9
267
0
9
0
186
0
1
195
0
2
204
0
3
213
0
4
222
0
5
231
0
6
240
0
7
249
0
9
268
0
9
0
187
0
1
196
0
2
205
0
3
214
0
4
223
0
5
232
0
6
241
0
7
250
0
8
259
0
end_DTG
begin_DTG
9
1
98
0
2
107
0
3
116
0
4
125
0
5
134
0
6
143
0
7
152
0
8
161
0
9
170
0
9
0
89
0
2
108
0
3
117
0
4
126
0
5
135
0
6
144
0
7
153
0
8
162
0
9
171
0
9
0
90
0
1
99
0
3
118
0
4
127
0
5
136
0
6
145
0
7
154
0
8
163
0
9
172
0
9
0
91
0
1
100
0
2
109
0
4
128
0
5
137
0
6
146
0
7
155
0
8
164
0
9
173
0
9
0
92
0
1
101
0
2
110
0
3
119
0
5
138
0
6
147
0
7
156
0
8
165
0
9
174
0
9
0
93
0
1
102
0
2
111
0
3
120
0
4
129
0
6
148
0
7
157
0
8
166
0
9
175
0
9
0
94
0
1
103
0
2
112
0
3
121
0
4
130
0
5
139
0
7
158
0
8
167
0
9
176
0
9
0
95
0
1
104
0
2
113
0
3
122
0
4
131
0
5
140
0
6
149
0
8
168
0
9
177
0
9
0
96
0
1
105
0
2
114
0
3
123
0
4
132
0
5
141
0
6
150
0
7
159
0
9
178
0
9
0
97
0
1
106
0
2
115
0
3
124
0
4
133
0
5
142
0
6
151
0
7
160
0
8
169
0
end_DTG
begin_DTG
1
1
56
1
28 0
1
0
1
2
38 5
27 0
end_DTG
begin_DTG
1
1
55
1
18 0
1
0
6
2
35 2
19 0
end_DTG
begin_DTG
1
1
54
1
25 0
1
0
3
2
37 7
24 0
end_DTG
begin_DTG
1
1
53
1
22 0
1
0
5
2
36 9
21 0
end_DTG
begin_DTG
1
1
52
1
2 0
1
0
18
2
29 8
1 0
end_DTG
begin_DTG
1
1
51
1
13 0
1
0
9
2
33 3
14 0
end_DTG
begin_DTG
1
1
50
1
12 0
1
0
11
2
32 2
11 0
end_DTG
begin_DTG
1
1
49
1
17 0
1
0
8
2
34 0
16 0
end_DTG
begin_DTG
1
1
48
1
12 0
1
0
10
2
32 9
10 0
end_DTG
begin_DTG
1
1
47
1
22 0
1
0
4
2
36 1
20 0
end_DTG
begin_DTG
1
1
46
1
25 0
1
0
2
2
37 5
23 0
end_DTG
begin_DTG
1
1
45
1
17 0
1
0
7
2
34 0
15 0
end_DTG
begin_DTG
1
1
44
1
6 0
1
0
16
2
30 3
5 0
end_DTG
begin_DTG
1
1
43
1
28 0
1
0
0
2
38 8
26 0
end_DTG
begin_DTG
1
1
42
1
2 0
1
0
17
2
29 3
0 0
end_DTG
begin_DTG
1
1
41
1
6 0
1
0
15
2
30 8
4 0
end_DTG
begin_DTG
1
1
40
1
9 0
1
0
13
2
31 3
8 0
end_DTG
begin_DTG
1
1
39
1
9 0
1
0
12
2
31 5
7 0
end_DTG
begin_DTG
1
1
38
1
6 0
1
0
14
2
30 1
3 0
end_DTG
begin_DTG
0
16
0
59
3
39 0
38 1
27 0
0
61
3
49 0
37 1
23 0
0
63
3
41 0
37 1
24 0
0
65
3
48 0
36 1
20 0
0
67
3
42 0
36 1
21 0
0
69
3
40 0
35 1
19 0
0
72
3
46 0
34 1
16 0
0
74
3
44 0
33 1
14 0
0
75
3
47 0
32 1
10 0
0
77
3
45 0
32 1
11 0
0
79
3
56 0
31 1
7 0
0
80
3
55 0
31 1
8 0
0
82
3
57 0
30 1
3 0
0
83
3
54 0
30 1
4 0
0
85
3
51 0
30 1
5 0
0
87
3
53 0
29 1
0 0
end_DTG
begin_DTG
0
16
0
57
3
52 0
38 1
26 0
0
58
3
39 0
38 1
27 0
0
60
3
49 0
37 1
23 0
0
62
3
41 0
37 1
24 0
0
64
3
48 0
36 1
20 0
0
66
3
42 0
36 1
21 0
0
68
3
40 0
35 1
19 0
0
70
3
50 0
34 1
15 0
0
71
3
46 0
34 1
16 0
0
73
3
44 0
33 1
14 0
0
76
3
45 0
32 1
11 0
0
78
3
56 0
31 1
7 0
0
81
3
57 0
30 1
3 0
0
84
3
51 0
30 1
5 0
0
86
3
53 0
29 1
0 0
0
88
3
43 0
29 1
1 0
end_DTG
begin_CG
4
53 1
59 1
58 1
2 1
3
43 1
59 1
2 1
4
53 1
43 1
0 1
1 1
4
57 1
59 1
58 1
6 1
3
54 1
58 1
6 1
4
51 1
59 1
58 1
6 1
6
57 1
54 1
51 1
3 1
4 1
5 1
4
56 1
59 1
58 1
9 1
3
55 1
58 1
9 1
4
56 1
55 1
7 1
8 1
3
47 1
58 1
12 1
4
45 1
59 1
58 1
12 1
4
47 1
45 1
10 1
11 1
2
44 1
14 1
4
44 1
59 1
58 1
13 1
3
50 1
59 1
17 1
4
46 1
59 1
58 1
17 1
4
50 1
46 1
15 1
16 1
2
40 1
19 1
4
40 1
59 1
58 1
18 1
4
48 1
59 1
58 1
22 1
4
42 1
59 1
58 1
22 1
4
48 1
42 1
20 1
21 1
4
49 1
59 1
58 1
25 1
4
41 1
59 1
58 1
25 1
4
49 1
41 1
23 1
24 1
3
52 1
59 1
28 1
4
39 1
59 1
58 1
28 1
4
52 1
39 1
26 1
27 1
4
53 1
43 1
59 2
58 1
5
57 1
54 1
51 1
59 2
58 3
4
56 1
55 1
59 1
58 2
4
47 1
45 1
59 1
58 2
3
44 1
59 1
58 1
4
50 1
46 1
59 2
58 1
3
40 1
59 1
58 1
4
48 1
42 1
59 2
58 2
4
49 1
41 1
59 2
58 2
4
52 1
39 1
59 2
58 1
2
59 1
58 1
2
59 1
58 1
2
59 1
58 1
2
59 1
58 1
1
59 1
2
59 1
58 1
2
59 1
58 1
2
59 1
58 1
1
58 1
2
59 1
58 1
2
59 1
58 1
1
59 1
2
59 1
58 1
1
59 1
2
59 1
58 1
1
58 1
1
58 1
2
59 1
58 1
2
59 1
58 1
0
0
end_CG
