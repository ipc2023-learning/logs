begin_version
3
end_version
begin_metric
0
end_metric
45
begin_variable
var45
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var44
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var43
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var42
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var56
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var37
-1
8
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
end_variable
begin_variable
var36
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAt




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





4
480
0
6
495
0
7
502
0
7
0
453
0
1
460
0
2
467
0
3
474
0
4
481
0
5
488
0
7
503
0
7
0
454
0
1
461
0
2
468
0
3
475
0
4
482
0
5
489
0
6
496
0
end_DTG
begin_DTG
7
1
399
0
2
406
0
3
413
0
4
420
0
5
427
0
6
434
0
7
441
0
7
0
392
0
2
407
0
3
414
0
4
421
0
5
428
0
6
435
0
7
442
0
7
0
393
0
1
400
0
3
415
0
4
422
0
5
429
0
6
436
0
7
443
0
7
0
394
0
1
401
0
2
408
0
4
423
0
5
430
0
6
437
0
7
444
0
7
0
395
0
1
402
0
2
409
0
3
416
0
5
431
0
6
438
0
7
445
0
7
0
396
0
1
403
0
2
410
0
3
417
0
4
424
0
6
439
0
7
446
0
7
0
397
0
1
404
0
2
411
0
3
418
0
4
425
0
5
432
0
7
447
0
7
0
398
0
1
405
0
2
412
0
3
419
0
4
426
0
5
433
0
6
440
0
end_DTG
begin_DTG
7
1
343
0
2
350
0
3
357
0
4
364
0
5
371
0
6
378
0
7
385
0
7
0
336
0
2
351
0
3
358
0
4
365
0
5
372
0
6
379
0
7
386
0
7
0
337
0
1
344
0
3
359
0
4
366
0
5
373
0
6
380
0
7
387
0
7
0
338
0
1
345
0
2
352
0
4
367
0
5
374
0
6
381
0
7
388
0
7
0
339
0
1
346
0
2
353
0
3
360
0
5
375
0
6
382
0
7
389
0
7
0
340
0
1
347
0
2
354
0
3
361
0
4
368
0
6
383
0
7
390
0
7
0
341
0
1
348
0
2
355
0
3
362
0
4
369
0
5
376
0
7
391
0
7
0
342
0
1
349
0
2
356
0
3
363
0
4
370
0
5
377
0
6
384
0
end_DTG
begin_DTG
7
1
287
0
2
294
0
3
301
0
4
308
0
5
315
0
6
322
0
7
329
0
7
0
280
0
2
295
0
3
302
0
4
309
0
5
316
0
6
323
0
7
330
0
7
0
281
0
1
288
0
3
303
0
4
310
0
5
317
0
6
324
0
7
331
0
7
0
282
0
1
289
0
2
296
0
4
311
0
5
318
0
6
325
0
7
332
0
7
0
283
0
1
290
0
2
297
0
3
304
0
5
319
0
6
326
0
7
333
0
7
0
284
0
1
291
0
2
298
0
3
305
0
4
312
0
6
327
0
7
334
0
7
0
285
0
1
292
0
2
299
0
3
306
0
4
313
0
5
320
0
7
335
0
7
0
286
0
1
293
0
2
300
0
3
307
0
4
314
0
5
321
0
6
328
0
end_DTG
begin_DTG
7
1
231
0
2
238
0
3
245
0
4
252
0
5
259
0
6
266
0
7
273
0
7
0
224
0
2
239
0
3
246
0
4
253
0
5
260
0
6
267
0
7
274
0
7
0
225
0
1
232
0
3
247
0
4
254
0
5
261
0
6
268
0
7
275
0
7
0
226
0
1
233
0
2
240
0
4
255
0
5
262
0
6
269
0
7
276
0
7
0
227
0
1
234
0
2
241
0
3
248
0
5
263
0
6
270
0
7
277
0
7
0
228
0
1
235
0
2
242
0
3
249
0
4
256
0
6
271
0
7
278
0
7
0
229
0
1
236
0
2
243
0
3
250
0
4
257
0
5
264
0
7
279
0
7
0
230
0
1
237
0
2
244
0
3
251
0
4
258
0
5
265
0
6
272
0
end_DTG
begin_DTG
7
1
175
0
2
182
0
3
189
0
4
196
0
5
203
0
6
210
0
7
217
0
7
0
168
0
2
183
0
3
190
0
4
197
0
5
204
0
6
211
0
7
218
0
7
0
169
0
1
176
0
3
191
0
4
198
0
5
205
0
6
212
0
7
219
0
7
0
170
0
1
177
0
2
184
0
4
199
0
5
206
0
6
213
0
7
220
0
7
0
171
0
1
178
0
2
185
0
3
192
0
5
207
0
6
214
0
7
221
0
7
0
172
0
1
179
0
2
186
0
3
193
0
4
200
0
6
215
0
7
222
0
7
0
173
0
1
180
0
2
187
0
3
194
0
4
201
0
5
208
0
7
223
0
7
0
174
0
1
181
0
2
188
0
3
195
0
4
202
0
5
209
0
6
216
0
end_DTG
begin_DTG
7
1
119
0
2
126
0
3
133
0
4
140
0
5
147
0
6
154
0
7
161
0
7
0
112
0
2
127
0
3
134
0
4
141
0
5
148
0
6
155
0
7
162
0
7
0
113
0
1
120
0
3
135
0
4
142
0
5
149
0
6
156
0
7
163
0
7
0
114
0
1
121
0
2
128
0
4
143
0
5
150
0
6
157
0
7
164
0
7
0
115
0
1
122
0
2
129
0
3
136
0
5
151
0
6
158
0
7
165
0
7
0
116
0
1
123
0
2
130
0
3
137
0
4
144
0
6
159
0
7
166
0
7
0
117
0
1
124
0
2
131
0
3
138
0
4
145
0
5
152
0
7
167
0
7
0
118
0
1
125
0
2
132
0
3
139
0
4
146
0
5
153
0
6
160
0
end_DTG
begin_DTG
7
1
63
0
2
70
0
3
77
0
4
84
0
5
91
0
6
98
0
7
105
0
7
0
56
0
2
71
0
3
78
0
4
85
0
5
92
0
6
99
0
7
106
0
7
0
57
0
1
64
0
3
79
0
4
86
0
5
93
0
6
100
0
7
107
0
7
0
58
0
1
65
0
2
72
0
4
87
0
5
94
0
6
101
0
7
108
0
7
0
59
0
1
66
0
2
73
0
3
80
0
5
95
0
6
102
0
7
109
0
7
0
60
0
1
67
0
2
74
0
3
81
0
4
88
0
6
103
0
7
110
0
7
0
61
0
1
68
0
2
75
0
3
82
0
4
89
0
5
96
0
7
111
0
7
0
62
0
1
69
0
2
76
0
3
83
0
4
90
0
5
97
0
6
104
0
end_DTG
begin_DTG
1
1
41
1
5 0
1
0
12
2
23 4
4 0
end_DTG
begin_DTG
1
1
40
1
6 0
1
0
9
2
24 3
7 0
end_DTG
begin_DTG
1
1
39
1
0 0
1
0
13
2
22 5
1 0
end_DTG
begin_DTG
1
1
38
1
10 0
1
0
7
2
26 3
11 0
end_DTG
begin_DTG
1
1
37
1
18 0
1
0
3
2
28 0
17 0
end_DTG
begin_DTG
1
1
36
1
5 0
1
0
11
2
23 4
3 0
end_DTG
begin_DTG
1
1
35
1
8 0
1
0
8
2
25 7
9 0
end_DTG
begin_DTG
1
1
34
1
15 0
1
0
6
2
27 1
14 0
end_DTG
begin_DTG
1
1
33
1
5 0
1
0
10
2
23 5
2 0
end_DTG
begin_DTG
1
1
32
1
21 0
1
0
1
2
29 3
20 0
end_DTG
begin_DTG
1
1
31
1
15 0
1
0
5
2
27 2
13 0
end_DTG
begin_DTG
1
1
30
1
18 0
1
0
2
2
28 2
16 0
end_DTG
begin_DTG
1
1
29
1
15 0
1
0
4
2
27 3
12 0
end_DTG
begin_DTG
1
1
28
1
21 0
1
0
0
2
29 1
19 0
end_DTG
begin_DTG
0
14
0
42
3
43 0
29 4
19 0
0
43
3
39 0
29 4
20 0
0
44
3
41 0
28 4
16 0
0
45
3
34 0
28 4
17 0
0
46
3
42 0
27 4
12 0
0
47
3
40 0
27 4
13 0
0
48
3
37 0
27 4
14 0
0
49
3
33 0
26 4
11 0
0
50
3
36 0
25 4
9 0
0
51
3
31 0
24 4
7 0
0
52
3
38 0
23 4
2 0
0
53
3
35 0
23 4
3 0
0
54
3
30 0
23 4
4 0
0
55
3
32 0
22 4
1 0
end_DTG
begin_CG
2
32 1
1 1
3
32 1
44 1
0 1
3
38 1
44 1
5 1
3
35 1
44 1
5 1
3
30 1
44 1
5 1
6
38 1
35 1
30 1
2 1
3 1
4 1
2
31 1
7 1
3
31 1
44 1
6 1
2
36 1
9 1
3
36 1
44 1
8 1
2
33 1
11 1
3
33 1
44 1
10 1
3
42 1
44 1
15 1
3
40 1
44 1
15 1
3
37 1
44 1
15 1
6
42 1
40 1
37 1
12 1
13 1
14 1
3
41 1
44 1
18 1
3
34 1
44 1
18 1
4
41 1
34 1
16 1
17 1
3
43 1
44 1
21 1
3
39 1
44 1
21 1
4
43 1
39 1
19 1
20 1
2
32 1
44 1
4
38 1
35 1
30 1
44 3
2
31 1
44 1
2
36 1
44 1
2
33 1
44 1
4
42 1
40 1
37 1
44 3
3
41 1
34 1
44 2
3
43 1
39 1
44 2
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
1
44 1
0
end_CG
