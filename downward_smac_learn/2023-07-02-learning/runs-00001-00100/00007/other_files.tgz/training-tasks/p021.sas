begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var16
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var20
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var15
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var18
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var14
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var17
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var19
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var21
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var13
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var12
-1
4
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
end_variable
begin_variable
var11
-1
4
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
end_variable
begin_variable
var10
-1
4
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
end_variable
begin_variable
var9
-1
4
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var5
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
0
1
0
1
0
1
1
1
0
3
2
3
1
1
1
1
1
1
1
1
1
end_state
begin_goal
3
18 0
19 0
20 0
end_goal
78
begin_operator
calibrate sat1 ins3 dir2
2
12 1
6 0
1
0 15 -1 0
0
end_operator
begin_operator
calibrate sat1 ins5 dir3
2
12 2
7 0
1
0 13 -1 0
0
end_operator
begin_operator
calibrate sat2 ins1 dir4
2
11 3
5 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat3 ins2 dir4
2
10 3
3 0
1
0 16 -1 0
0
end_operator
begin_operator
calibrate sat4 ins4 dir4
2
9 3
1 0
1
0 14 -1 0
0
end_operator
begin_operator
switch_off ins1 sat2
0
2
0 4 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_off ins2 sat3
0
2
0 2 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins3 sat1
0
2
0 8 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins4 sat4
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins5 sat1
0
2
0 8 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_on ins1 sat2
0
3
0 17 -1 1
0 4 0 1
0 5 -1 0
0
end_operator
begin_operator
switch_on ins2 sat3
0
3
0 16 -1 1
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins3 sat1
0
3
0 15 -1 1
0 8 0 1
0 6 -1 0
0
end_operator
begin_operator
switch_on ins4 sat4
0
3
0 14 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins5 sat1
0
3
0 13 -1 1
0 8 0 1
0 7 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins3 mod1
3
15 0
12 0
6 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins5 mod1
3
13 0
12 0
7 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins3 mod1
3
15 0
12 2
6 0
1
0 19 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins5 mod1
3
13 0
12 2
7 0
1
0 19 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins3 mod1
3
15 0
12 3
6 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins5 mod1
3
13 0
12 3
7 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat2 dir1 ins1 mod1
3
17 0
11 0
5 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat2 dir3 ins1 mod1
3
17 0
11 2
5 0
1
0 19 -1 0
0
end_operator
begin_operator
take_image sat2 dir4 ins1 mod1
3
17 0
11 3
5 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat3 dir1 ins2 mod1
3
16 0
10 0
3 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat3 dir3 ins2 mod1
3
16 0
10 2
3 0
1
0 19 -1 0
0
end_operator
begin_operator
take_image sat3 dir4 ins2 mod1
3
16 0
10 3
3 0
1
0 18 -1 0
0
end_operator
begin_operator
take_image sat4 dir1 ins4 mod1
3
14 0
9 0
1 0
1
0 20 -1 0
0
end_operator
begin_operator
take_image sat4 dir3 ins4 mod1
3
14 0
9 2
1 0
1
0 19 -1 0
0
end_operator
begin_operator
take_image sat4 dir4 ins4 mod1
3
14 0
9 3
1 0
1
0 18 -1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
1
0 12 1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
1
0 12 2 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
1
0 12 3 0
0
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
1
0 12 0 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
1
0 12 2 1
0
end_operator
begin_operator
turn_to s




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 2 1
0
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
1
0 10 3 1
0
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
1
0 10 0 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
1
0 10 1 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
1
0 10 3 2
0
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
1
0 10 0 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
1
0 10 1 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
1
0 10 2 3
0
end_operator
begin_operator
turn_to sat4 dir1 dir2
0
1
0 9 1 0
0
end_operator
begin_operator
turn_to sat4 dir1 dir3
0
1
0 9 2 0
0
end_operator
begin_operator
turn_to sat4 dir1 dir4
0
1
0 9 3 0
0
end_operator
begin_operator
turn_to sat4 dir2 dir1
0
1
0 9 0 1
0
end_operator
begin_operator
turn_to sat4 dir2 dir3
0
1
0 9 2 1
0
end_operator
begin_operator
turn_to sat4 dir2 dir4
0
1
0 9 3 1
0
end_operator
begin_operator
turn_to sat4 dir3 dir1
0
1
0 9 0 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir2
0
1
0 9 1 2
0
end_operator
begin_operator
turn_to sat4 dir3 dir4
0
1
0 9 3 2
0
end_operator
begin_operator
turn_to sat4 dir4 dir1
0
1
0 9 0 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir2
0
1
0 9 1 3
0
end_operator
begin_operator
turn_to sat4 dir4 dir3
0
1
0 9 2 3
0
end_operator
0
begin_SG
switch 17
check 0
switch 11
check 0
switch 5
check 0
check 1
21
check 0
check 0
check 0
switch 5
check 0
check 1
22
check 0
check 0
switch 5
check 0
check 1
23
check 0
check 0
check 0
check 0
switch 16
check 0
switch 10
check 0
switch 3
check 0
check 1
24
check 0
check 0
check 0
switch 3
check 0
check 1
25
check 0
check 0
switch 3
check 0
check 1
26
check 0
check 0
check 0
check 0
switch 15
check 0
switch 12
check 0
switch 6
check 0
check 1
15
check 0
check 0
check 0
switch 6
check 0
check 1
17
check 0
check 0
switch 6
check 0
check 1
19
check 0
check 0
check 0
check 0
switch 14
check 0
switch 9
check 0
switch 1
check 0
check 1
27
check 0
check 0
check 0
switch 1
check 0
check 1
28
check 0
check 0
switch 1
check 0
check 1
29
check 0
check 0
check 0
check 0
switch 13
check 0
switch 12
check 0
switch 7
check 0
check 1
16
check 0
check 0
check 0
switch 7
check 0
check 1
18
check 0
check 0
switch 7
check 0
check 1
20
check 0
check 0
check 0
check 0
switch 12
check 0
check 3
33
36
39
switch 11
check 3
30
37
40
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
0
check 0
check 0
switch 11
check 3
31
34
41
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
1
check 0
check 0
check 3
32
35
38
switch 11
check 0
check 3
45
48
51
check 3
42
49
52
check 3
43
46
53
switch 10
check 3
44
47
50
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
2
check 0
check 0
switch 10
check 0
check 3
57
60
63
check 3
54
61
64
check 3
55
58
65
switch 9
check 3
56
59
62
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
3
check 0
check 0
switch 9
check 0
check 3
69
72
75
check 3
66
73
76
check 3
67
70
77
switch 8
check 3
68
71
74
check 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
switch 8
check 0
check 2
12
14
check 0
switch 4
check 0
check 1
10
check 0
switch 2
check 0
check 1
11
check 0
switch 0
check 0
check 1
13
check 0
switch 5
check 0
check 1
5
check 0
switch 3
check 0
check 1
6
check 0
switch 6
check 0
check 1
7
check 0
switch 1
check 0
check 1
8
check 0
switch 7
check 0
check 1
9
check 0
check 0
end_SG
begin_DTG
1
1
13
0
1
0
8
1
1 0
end_DTG
begin_DTG
1
1
8
0
1
0
13
1
0 0
end_DTG
begin_DTG
1
1
11
0
1
0
6
1
3 0
end_DTG
begin_DTG
1
1
6
0
1
0
11
1
2 0
end_DTG
begin_DTG
1
1
10
0
1
0
5
1
5 0
end_DTG
begin_DTG
1
1
5
0
1
0
10
1
4 0
end_DTG
begin_DTG
1
1
7
0
1
0
12
1
8 0
end_DTG
begin_DTG
1
1
9
0
1
0
14
1
8 0
end_DTG
begin_DTG
1
1
12
0
2
0
7
1
6 0
0
9
1
7 0
end_DTG
begin_DTG
3
1
69
0
2
72
0
3
75
0
3
0
66
0
2
73
0
3
76
0
3
0
67
0
1
70
0
3
77
0
3
0
68
0
1
71
0
2
74
0
end_DTG
begin_DTG
3
1
57
0
2
60
0
3
63
0
3
0
54
0
2
61
0
3
64
0
3
0
55
0
1
58
0
3
65
0
3
0
56
0
1
59
0
2
62
0
end_DTG
begin_DTG
3
1
45
0
2
48
0
3
51
0
3
0
42
0
2
49
0
3
52
0
3
0
43
0
1
46
0
3
53
0
3
0
44
0
1
47
0
2
50
0
end_DTG
begin_DTG
3
1
33
0
2
36
0
3
39
0
3
0
30
0
2
37
0
3
40
0
3
0
31
0
1
34
0
3
41
0
3
0
32
0
1
35
0
2
38
0
end_DTG
begin_DTG
1
1
14
1
8 0
1
0
1
2
12 2
7 0
end_DTG
begin_DTG
1
1
13
1
0 0
1
0
4
2
9 3
1 0
end_DTG
begin_DTG
1
1
12
1
8 0
1
0
0
2
12 1
6 0
end_DTG
begin_DTG
1
1
11
1
2 0
1
0
3
2
10 3
3 0
end_DTG
begin_DTG
1
1
10
1
4 0
1
0
2
2
11 3
5 0
end_DTG
begin_DTG
0
5
0
19
3
15 0
12 3
6 0
0
20
3
13 0
12 3
7 0
0
23
3
17 0
11 3
5 0
0
26
3
16 0
10 3
3 0
0
29
3
14 0
9 3
1 0
end_DTG
begin_DTG
0
5
0
17
3
15 0
12 2
6 0
0
18
3
13 0
12 2
7 0
0
22
3
17 0
11 2
5 0
0
25
3
16 0
10 2
3 0
0
28
3
14 0
9 2
1 0
end_DTG
begin_DTG
0
5
0
15
3
15 0
12 0
6 0
0
16
3
13 0
12 0
7 0
0
21
3
17 0
11 0
5 0
0
24
3
16 0
10 0
3 0
0
27
3
14 0
9 0
1 0
end_DTG
begin_CG
2
14 1
1 1
5
14 1
20 1
19 1
18 1
0 1
2
16 1
3 1
5
16 1
20 1
19 1
18 1
2 1
2
17 1
5 1
5
17 1
20 1
19 1
18 1
4 1
5
15 1
20 1
19 1
18 1
8 1
5
13 1
20 1
19 1
18 1
8 1
4
15 1
13 1
6 1
7 1
4
14 1
20 1
19 1
18 1
4
16 1
20 1
19 1
18 1
4
17 1
20 1
19 1
18 1
5
15 1
13 1
20 2
19 2
18 2
3
20 1
19 1
18 1
3
20 1
19 1
18 1
3
20 1
19 1
18 1
3
20 1
19 1
18 1
3
20 1
19 1
18 1
0
0
0
end_CG
