begin_version
3
end_version
begin_metric
0
end_metric
53
begin_variable
var43
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var42
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var56
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var37
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var36
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var27
-1
2
Atom have_image(dir7, mod2)
NegatedAtom have_image(dir7, mod2)
end_variable
begin_variable
var26
-1
2
Atom have_image(dir7, mod1)
NegatedAtom have_image(dir7, mod1)
end_variable
begin_variab




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
end_DTG
begin_DTG
0
10
0
52
3
34 0
27 6
20 0
0
86
3
39 0
26 6
14 0
0
87
3
38 0
26 6
15 0
0
89
3
36 0
26 6
16 0
0
91
3
32 0
26 6
17 0
0
107
3
29 0
25 6
12 0
0
118
3
33 0
24 6
10 0
0
146
3
40 0
23 6
4 0
0
149
3
31 0
23 6
6 0
0
161
3
41 0
22 6
3 0
end_DTG
begin_DTG
0
13
0
51
3
34 0
27 6
20 0
0
85
3
39 0
26 6
14 0
0
88
3
36 0
26 6
16 0
0
90
3
32 0
26 6
17 0
0
105
3
35 0
25 6
11 0
0
106
3
29 0
25 6
12 0
0
117
3
33 0
24 6
10 0
0
145
3
40 0
23 6
4 0
0
147
3
37 0
23 6
5 0
0
148
3
31 0
23 6
6 0
0
150
3
28 0
23 6
7 0
0
160
3
41 0
22 6
3 0
0
166
3
30 0
21 6
1 0
end_DTG
begin_DTG
0
13
0
50
3
34 0
27 5
20 0
0
82
3
39 0
26 5
14 0
0
83
3
36 0
26 5
16 0
0
84
3
32 0
26 5
17 0
0
103
3
35 0
25 5
11 0
0
104
3
29 0
25 5
12 0
0
116
3
33 0
24 5
10 0
0
141
3
40 0
23 5
4 0
0
142
3
37 0
23 5
5 0
0
143
3
31 0
23 5
6 0
0
144
3
28 0
23 5
7 0
0
159
3
41 0
22 5
3 0
0
165
3
30 0
21 5
1 0
end_DTG
begin_DTG
0
10
0
49
3
34 0
27 4
20 0
0
76
3
39 0
26 4
14 0
0
77
3
38 0
26 4
15 0
0
79
3
36 0
26 4
16 0
0
81
3
32 0
26 4
17 0
0
102
3
29 0
25 4
12 0
0
115
3
33 0
24 4
10 0
0
136
3
40 0
23 4
4 0
0
139
3
31 0
23 4
6 0
0
158
3
41 0
22 4
3 0
end_DTG
begin_DTG
0
13
0
48
3
34 0
27 4
20 0
0
75
3
39 0
26 4
14 0
0
78
3
36 0
26 4
16 0
0
80
3
32 0
26 4
17 0
0
100
3
35 0
25 4
11 0
0
101
3
29 0
25 4
12 0
0
114
3
33 0
24 4
10 0
0
135
3
40 0
23 4
4 0
0
137
3
37 0
23 4
5 0
0
138
3
31 0
23 4
6 0
0
140
3
28 0
23 4
7 0
0
157
3
41 0
22 4
3 0
0
164
3
30 0
21 4
1 0
end_DTG
begin_DTG
0
10
0
47
3
34 0
27 3
20 0
0
71
3
39 0
26 3
14 0
0
72
3
38 0
26 3
15 0
0
73
3
36 0
26 3
16 0
0
74
3
32 0
26 3
17 0
0
99
3
29 0
25 3
12 0
0
113
3
33 0
24 3
10 0
0
133
3
40 0
23 3
4 0
0
134
3
31 0
23 3
6 0
0
156
3
41 0
22 3
3 0
end_DTG
begin_DTG
0
10
0
46
3
34 0
27 2
20 0
0
65
3
39 0
26 2
14 0
0
66
3
38 0
26 2
15 0
0
68
3
36 0
26 2
16 0
0
70
3
32 0
26 2
17 0
0
98
3
29 0
25 2
12 0
0
112
3
33 0
24 2
10 0
0
128
3
40 0
23 2
4 0
0
131
3
31 0
23 2
6 0
0
155
3
41 0
22 2
3 0
end_DTG
begin_DTG
0
13
0
45
3
34 0
27 2
20 0
0
64
3
39 0
26 2
14 0
0
67
3
36 0
26 2
16 0
0
69
3
32 0
26 2
17 0
0
96
3
35 0
25 2
11 0
0
97
3
29 0
25 2
12 0
0
111
3
33 0
24 2
10 0
0
127
3
40 0
23 2
4 0
0
129
3
37 0
23 2
5 0
0
130
3
31 0
23 2
6 0
0
132
3
28 0
23 2
7 0
0
154
3
41 0
22 2
3 0
0
163
3
30 0
21 2
1 0
end_DTG
begin_DTG
0
10
0
44
3
34 0
27 1
20 0
0
58
3
39 0
26 1
14 0
0
59
3
38 0
26 1
15 0
0
61
3
36 0
26 1
16 0
0
63
3
32 0
26 1
17 0
0
95
3
29 0
25 1
12 0
0
110
3
33 0
24 1
10 0
0
122
3
40 0
23 1
4 0
0
125
3
31 0
23 1
6 0
0
153
3
41 0
22 1
3 0
end_DTG
begin_DTG
0
13
0
43
3
34 0
27 1
20 0
0
57
3
39 0
26 1
14 0
0
60
3
36 0
26 1
16 0
0
62
3
32 0
26 1
17 0
0
93
3
35 0
25 1
11 0
0
94
3
29 0
25 1
12 0
0
109
3
33 0
24 1
10 0
0
121
3
40 0
23 1
4 0
0
123
3
37 0
23 1
5 0
0
124
3
31 0
23 1
6 0
0
126
3
28 0
23 1
7 0
0
152
3
41 0
22 1
3 0
0
162
3
30 0
21 1
1 0
end_DTG
begin_DTG
0
10
0
42
3
34 0
27 0
20 0
0
53
3
39 0
26 0
14 0
0
54
3
38 0
26 0
15 0
0
55
3
36 0
26 0
16 0
0
56
3
32 0
26 0
17 0
0
92
3
29 0
25 0
12 0
0
108
3
33 0
24 0
10 0
0
119
3
40 0
23 0
4 0
0
120
3
31 0
23 0
6 0
0
151
3
41 0
22 0
3 0
end_DTG
begin_CG
2
30 1
1 1
7
30 1
51 1
49 1
46 1
44 1
43 1
0 1
2
41 1
3 1
13
41 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
2 1
13
40 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
8 1
7
37 1
51 1
49 1
46 1
44 1
43 1
8 1
13
31 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
8 1
7
28 1
51 1
49 1
46 1
44 1
43 1
8 1
8
40 1
37 1
31 1
28 1
4 1
5 1
6 1
7 1
2
33 1
10 1
13
33 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
9 1
7
35 1
51 1
49 1
46 1
44 1
43 1
13 1
13
29 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
13 1
4
35 1
29 1
11 1
12 1
13
39 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
18 1
8
38 1
52 1
50 1
48 1
47 1
45 1
42 1
18 1
13
36 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
18 1
13
32 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
18 1
8
39 1
38 1
36 1
32 1
14 1
15 1
16 1
17 1
2
34 1
20 1
13
34 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
19 1
6
30 1
51 1
49 1
46 1
44 1
43 1
12
41 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
15
40 1
37 1
31 1
28 1
52 2
51 4
50 2
49 4
48 2
47 2
46 4
45 2
44 4
43 4
42 2
12
33 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
13
35 1
29 1
52 1
51 2
50 1
49 2
48 1
47 1
46 2
45 1
44 2
43 2
42 1
15
39 1
38 1
36 1
32 1
52 4
51 3
50 4
49 3
48 4
47 4
46 3
45 4
44 3
43 3
42 4
12
34 1
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
5
51 1
49 1
46 1
44 1
43 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
5
51 1
49 1
46 1
44 1
43 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
5
51 1
49 1
46 1
44 1
43 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
5
51 1
49 1
46 1
44 1
43 1
6
52 1
50 1
48 1
47 1
45 1
42 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
11
52 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
43 1
42 1
0
0
0
0
0
0
0
0
0
0
0
end_CG
