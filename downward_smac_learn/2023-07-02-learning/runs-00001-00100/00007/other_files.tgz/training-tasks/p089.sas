begin_version
3
end_version
begin_metric
0
end_metric
71
begin_variable
var67
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var49
-1
10
Atom pointing(sat10, dir1)
Atom pointing(sat10, dir10)
Atom pointing(sat10, dir2)
Atom pointing(sat10, dir3)
Atom pointing(sat10, dir4)
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




45 0
33 4
14 0
0
169
3
39 0
32 4
12 0
0
187
3
60 0
31 4
8 0
0
189
3
52 0
31 4
9 0
0
214
3
51 0
30 4
5 0
0
216
3
43 0
30 4
6 0
0
240
3
49 0
29 4
2 0
0
242
3
38 0
29 4
3 0
0
260
3
54 0
28 4
1 0
end_DTG
begin_DTG
0
15
0
59
3
42 0
37 3
26 0
0
78
3
47 0
36 3
22 0
0
80
3
41 0
36 3
23 0
0
110
3
50 0
35 3
18 0
0
112
3
48 0
35 3
19 0
0
114
3
44 0
35 3
20 0
0
142
3
53 0
34 3
15 0
0
144
3
40 0
34 3
16 0
0
155
3
45 0
33 3
14 0
0
184
3
60 0
31 3
8 0
0
186
3
52 0
31 3
9 0
0
211
3
51 0
30 3
5 0
0
213
3
43 0
30 3
6 0
0
238
3
49 0
29 3
2 0
0
259
3
54 0
28 3
1 0
end_DTG
begin_DTG
0
15
0
57
3
42 0
37 2
26 0
0
73
3
47 0
36 2
22 0
0
76
3
41 0
36 2
23 0
0
103
3
50 0
35 2
18 0
0
106
3
48 0
35 2
19 0
0
109
3
44 0
35 2
20 0
0
139
3
53 0
34 2
15 0
0
141
3
40 0
34 2
16 0
0
153
3
45 0
33 2
14 0
0
180
3
60 0
31 2
8 0
0
183
3
52 0
31 2
9 0
0
206
3
51 0
30 2
5 0
0
209
3
43 0
30 2
6 0
0
235
3
49 0
29 2
2 0
0
257
3
54 0
28 2
1 0
end_DTG
begin_DTG
0
15
0
56
3
46 0
37 2
25 0
0
72
3
47 0
36 2
22 0
0
75
3
41 0
36 2
23 0
0
102
3
50 0
35 2
18 0
0
105
3
48 0
35 2
19 0
0
108
3
44 0
35 2
20 0
0
152
3
45 0
33 2
14 0
0
167
3
39 0
32 2
12 0
0
179
3
60 0
31 2
8 0
0
182
3
52 0
31 2
9 0
0
205
3
51 0
30 2
5 0
0
208
3
43 0
30 2
6 0
0
234
3
49 0
29 2
2 0
0
237
3
38 0
29 2
3 0
0
256
3
54 0
28 2
1 0
end_DTG
begin_DTG
0
15
0
54
3
46 0
37 0
25 0
0
69
3
47 0
36 0
22 0
0
70
3
41 0
36 0
23 0
0
99
3
50 0
35 0
18 0
0
100
3
48 0
35 0
19 0
0
101
3
44 0
35 0
20 0
0
150
3
45 0
33 0
14 0
0
165
3
39 0
32 0
12 0
0
177
3
60 0
31 0
8 0
0
178
3
52 0
31 0
9 0
0
202
3
51 0
30 0
5 0
0
203
3
43 0
30 0
6 0
0
232
3
49 0
29 0
2 0
0
233
3
38 0
29 0
3 0
0
254
3
54 0
28 0
1 0
end_DTG
begin_CG
2
54 1
1 1
17
54 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
0 1
12
49 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
4 1
14
38 1
70 1
59 1
69 1
58 1
66 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
4 1
4
49 1
38 1
2 1
3 1
17
51 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
7 1
17
43 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
7 1
4
51 1
43 1
5 1
6 1
12
60 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
10 1
17
52 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
10 1
4
60 1
52 1
8 1
9 1
2
39 1
12 1
14
39 1
70 1
59 1
69 1
58 1
66 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
11 1
2
45 1
14 1
17
45 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
13 1
5
53 1
68 1
67 1
65 1
17 1
10
40 1
59 1
68 1
58 1
67 1
65 1
57 1
56 1
55 1
17 1
4
53 1
40 1
15 1
16 1
12
50 1
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
21 1
17
48 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
21 1
17
44 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
21 1
6
50 1
48 1
44 1
18 1
19 1
20 1
17
47 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
24 1
17
41 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
24 1
4
47 1
41 1
22 1
23 1
14
46 1
70 1
59 1
69 1
58 1
66 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
27 1
5
42 1
68 1
67 1
65 1
27 1
4
46 1
42 1
25 1
26 1
16
54 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
17
49 1
38 1
70 2
59 1
69 2
68 1
58 1
67 1
66 2
65 1
57 1
64 2
56 1
55 1
63 2
62 2
61 2
17
51 1
43 1
70 2
59 2
69 2
68 2
58 2
67 2
66 2
65 2
57 2
64 2
56 2
55 2
63 2
62 2
61 2
17
60 1
52 1
70 2
59 1
69 2
68 2
58 1
67 2
66 2
65 2
57 1
64 2
56 1
55 1
63 2
62 2
61 2
13
39 1
70 1
59 1
69 1
58 1
66 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
16
45 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
10
53 1
40 1
59 1
68 2
58 1
67 2
65 2
57 1
56 1
55 1
18
50 1
48 1
44 1
70 3
59 2
69 3
68 3
58 2
67 3
66 3
65 3
57 2
64 3
56 2
55 2
63 3
62 3
61 3
17
47 1
41 1
70 2
59 2
69 2
68 2
58 2
67 2
66 2
65 2
57 2
64 2
56 2
55 2
63 2
62 2
61 2
17
46 1
42 1
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
12
70 1
59 1
69 1
58 1
66 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
12
70 1
59 1
69 1
58 1
66 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
8
59 1
68 1
58 1
67 1
65 1
57 1
56 1
55 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
3
68 1
67 1
65 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
12
70 1
59 1
69 1
58 1
66 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
10
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
10
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
3
68 1
67 1
65 1
15
70 1
59 1
69 1
68 1
58 1
67 1
66 1
65 1
57 1
64 1
56 1
55 1
63 1
62 1
61 1
0
0
0
0
0
10
70 1
69 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
0
0
0
0
0
0
0
0
0
0
end_CG
