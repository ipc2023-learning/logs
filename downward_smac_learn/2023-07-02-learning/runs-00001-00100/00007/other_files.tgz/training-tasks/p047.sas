begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var33
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var34
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var30
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var35
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var29
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var28
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var36
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var27
-1
6
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
end_variable
begin_variable
var26
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var25
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var24
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var23
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var22
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var21
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
0
begin_state
0
1
1
1
0
1
1
0
0
1
1
1
1
0
0
1
2
3
5
4
3
2
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
5
16 3
19 1
21 2
32 0
33 0
end_goal
225
begin_operator
calibrate sat1 ins2 dir5
2
21 4
15 0
1
0 29 -1 0
0
end_operator
begin_operator
calibrate sat2 ins10 dir1
2
20 0
10 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat2 ins5 dir1
2
20 0
11 0
1
0 26 -1 0
0
end_operator
begin_operator
calibrate sat2 ins7 dir4
2
20 3
12 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir4
2
19 3
9 0
1
0 28 -1 0
0
end_operator
begin_operator
calibrate sat4 ins6 dir5
2
18 4
5 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat4 ins8 dir2
2
18 1
6 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat5 ins4 dir3
2
17 2
2 0
1
0 27 -1 0
0
end_operator
begin_operator
calibrate sat5 ins9 dir5
2
17 4
3 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat6 ins1 dir3
2
16 2
1 0
1
0 31 -1 0
0
end_operator
begin_operator
switch_off ins1 sat6
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins10 sat2
0
2
0 13 -1 0
0 10 0 1
0
end_operator
begin_operator
switch_off ins2 sat1
0
2
0 14 -1 0
0 15 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 8 -1 0
0 9 0 1
0
end_operator
begin_operator
switch_off ins4 sat5
0
2
0 4 -1 0
0 2 0 1
0
end_operator
begin_operator
switch_off ins5 sat2
0
2
0 13 -1 0
0 11 0 1
0
end_operator
begin_operator
s




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 1
6
check 0
check 0
check 5
136
141
152
157
162
check 5
137
142
147
158
163
switch 17
check 5
138
143
148
153
164
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
5
check 0
check 0
check 5
139
144
149
154
159
switch 17
check 0
check 5
170
175
180
185
190
check 5
165
176
181
186
191
switch 16
check 5
166
171
182
187
192
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
7
check 0
check 0
check 5
167
172
177
188
193
switch 16
check 5
168
173
178
183
194
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
8
check 0
check 0
check 5
169
174
179
184
189
switch 16
check 0
check 5
200
205
210
215
220
check 5
195
206
211
216
221
switch 14
check 5
196
201
212
217
222
check 0
check 0
switch 1
check 0
check 1
9
check 0
check 0
check 5
197
202
207
218
223
check 5
198
203
208
213
224
check 5
199
204
209
214
219
switch 14
check 0
check 1
22
check 0
switch 13
check 0
check 3
21
25
27
check 0
switch 8
check 0
check 1
23
check 0
switch 7
check 0
check 2
26
28
check 0
switch 4
check 0
check 2
24
29
check 0
switch 0
check 0
check 1
20
check 0
switch 1
check 0
check 1
10
check 0
switch 10
check 0
check 1
11
check 0
switch 15
check 0
check 1
12
check 0
switch 9
check 0
check 1
13
check 0
switch 2
check 0
check 1
14
check 0
switch 11
check 0
check 1
15
check 0
switch 5
check 0
check 1
16
check 0
switch 12
check 0
check 1
17
check 0
switch 6
check 0
check 1
18
check 0
switch 3
check 0
check 1
19
check 0
check 0
end_SG
begin_DTG
1
1
20
0
1
0
10
1
1 0
end_DTG
begin_DTG
1
1
10
0
1
0
20
1
0 0
end_DTG
begin_DTG
1
1
14
0
1
0
24
1
4 0
end_DTG
begin_DTG
1
1
19
0
1
0
29
1
4 0
end_DTG
begin_DTG
1
1
24
0
2
0
14
1
2 0
0
19
1
3 0
end_DTG
begin_DTG
1
1
16
0
1
0
26
1
7 0
end_DTG
begin_DTG
1
1
18
0
1
0
28
1
7 0
end_DTG
begin_DTG
1
1
26
0
2
0
16
1
5 0
0
18
1
6 0
end_DTG
begin_DTG
1
1
23
0
1
0
13
1
9 0
end_DTG
begin_DTG
1
1
13
0
1
0
23
1
8 0
end_DTG
begin_DTG
1
1
11
0
1
0
21
1
13 0
end_DTG
begin_DTG
1
1
15
0
1
0
25
1
13 0
end_DTG
begin_DTG
1
1
17
0
1
0
27
1
13 0
end_DTG
begin_DTG
1
1
21
0
3
0
11
1
10 0
0
15
1
11 0
0
17
1
12 0
end_DTG
begin_DTG
1
1
22
0
1
0
12
1
15 0
end_DTG
begin_DTG
1
1
12
0
1
0
22
1
14 0
end_DTG
begin_DTG
5
1
200
0
2
205
0
3
210
0
4
215
0
5
220
0
5
0
195
0
2
206
0
3
211
0
4
216
0
5
221
0
5
0
196
0
1
201
0
3
212
0
4
217
0
5
222
0
5
0
197
0
1
202
0
2
207
0
4
218
0
5
223
0
5
0
198
0
1
203
0
2
208
0
3
213
0
5
224
0
5
0
199
0
1
204
0
2
209
0
3
214
0
4
219
0
end_DTG
begin_DTG
5
1
170
0
2
175
0
3
180
0
4
185
0
5
190
0
5
0
165
0
2
176
0
3
181
0
4
186
0
5
191
0
5
0
166
0
1
171
0
3
182
0
4
187
0
5
192
0
5
0
167
0
1
172
0
2
177
0
4
188
0
5
193
0
5
0
168
0
1
173
0
2
178
0
3
183
0
5
194
0
5
0
169
0
1
174
0
2
179
0
3
184
0
4
189
0
end_DTG
begin_DTG
5
1
140
0
2
145
0
3
150
0
4
155
0
5
160
0
5
0
135
0
2
146
0
3
151
0
4
156
0
5
161
0
5
0
136
0
1
141
0
3
152
0
4
157
0
5
162
0
5
0
137
0
1
142
0
2
147
0
4
158
0
5
163
0
5
0
138
0
1
143
0
2
148
0
3
153
0
5
164
0
5
0
139
0
1
144
0
2
149
0
3
154
0
4
159
0
end_DTG
begin_DTG
5
1
110
0
2
115
0
3
120
0
4
125
0
5
130
0
5
0
105
0
2
116
0
3
121
0
4
126
0
5
131
0
5
0
106
0
1
111
0
3
122
0
4
127
0
5
132
0
5
0
107
0
1
112
0
2
117
0
4
128
0
5
133
0
5
0
108
0
1
113
0
2
118
0
3
123
0
5
134
0
5
0
109
0
1
114
0
2
119
0
3
124
0
4
129
0
end_DTG
begin_DTG
5
1
80
0
2
85
0
3
90
0
4
95
0
5
100
0
5
0
75
0
2
86
0
3
91
0
4
96
0
5
101
0
5
0
76
0
1
81
0
3
92
0
4
97
0
5
102
0
5
0
77
0
1
82
0
2
87
0
4
98
0
5
103
0
5
0
78
0
1
83
0
2
88
0
3
93
0
5
104
0
5
0
79
0
1
84
0
2
89
0
3
94
0
4
99
0
end_DTG
begin_DTG
5
1
50
0
2
55
0
3
60
0
4
65
0
5
70
0
5
0
45
0
2
56
0
3
61
0
4
66
0
5
71
0
5
0
46
0
1
51
0
3
62
0
4
67
0
5
72
0
5
0
47
0
1
52
0
2
57
0
4
68
0
5
73
0
5
0
48
0
1
53
0
2
58
0
3
63
0
5
74
0
5
0
49
0
1
54
0
2
59
0
3
64
0
4
69
0
end_DTG
begin_DTG
1
1
29
1
4 0
1
0
8
2
17 4
3 0
end_DTG
begin_DTG
1
1
28
1
7 0
1
0
6
2
18 1
6 0
end_DTG
begin_DTG
1
1
27
1
13 0
1
0
3
2
20 3
12 0
end_DTG
begin_DTG
1
1
26
1
7 0
1
0
5
2
18 4
5 0
end_DTG
begin_DTG
1
1
25
1
13 0
1
0
2
2
20 0
11 0
end_DTG
begin_DTG
1
1
24
1
4 0
1
0
7
2
17 2
2 0
end_DTG
begin_DTG
1
1
23
1
8 0
1
0
4
2
19 3
9 0
end_DTG
begin_DTG
1
1
22
1
14 0
1
0
0
2
21 4
15 0
end_DTG
begin_DTG
1
1
21
1
13 0
1
0
1
2
20 0
10 0
end_DTG
begin_DTG
1
1
20
1
0 0
1
0
9
2
16 2
1 0
end_DTG
begin_DTG
0
5
0
31
3
29 0
21 5
15 0
0
35
3
26 0
20 5
11 0
0
36
3
24 0
20 5
12 0
0
40
3
23 0
18 5
6 0
0
44
3
31 0
16 5
1 0
end_DTG
begin_DTG
0
10
0
30
3
29 0
21 1
15 0
0
32
3
30 0
20 1
10 0
0
33
3
26 0
20 1
11 0
0
34
3
24 0
20 1
12 0
0
37
3
28 0
19 1
9 0
0
38
3
25 0
18 1
5 0
0
39
3
23 0
18 1
6 0
0
41
3
27 0
17 1
2 0
0
42
3
22 0
17 1
3 0
0
43
3
31 0
16 1
1 0
end_DTG
begin_CG
2
31 1
1 1
4
31 1
33 1
32 1
0 1
3
27 1
33 1
4 1
3
22 1
33 1
4 1
4
27 1
22 1
2 1
3 1
3
25 1
33 1
7 1
4
23 1
33 1
32 1
7 1
4
25 1
23 1
5 1
6 1
2
28 1
9 1
3
28 1
33 1
8 1
3
30 1
33 1
13 1
4
26 1
33 1
32 1
13 1
4
24 1
33 1
32 1
13 1
6
30 1
26 1
24 1
10 1
11 1
12 1
2
29 1
15 1
4
29 1
33 1
32 1
14 1
3
31 1
33 1
32 1
3
27 1
22 1
33 2
4
25 1
23 1
33 2
32 1
2
28 1
33 1
5
30 1
26 1
24 1
33 3
32 2
3
29 1
33 1
32 1
1
33 1
2
33 1
32 1
2
33 1
32 1
1
33 1
2
33 1
32 1
1
33 1
1
33 1
2
33 1
32 1
1
33 1
2
33 1
32 1
0
0
end_CG
