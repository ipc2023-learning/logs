begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var45
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var44
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var43
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var42
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var56
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var37
-1
8
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
end_variable
begin_variable
var36
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAt




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
7
0
154
0
1
161
0
2
168
0
3
175
0
4
182
0
5
189
0
6
196
0
end_DTG
begin_DTG
1
1
41
1
6 0
1
0
12
2
23 7
5 0
end_DTG
begin_DTG
1
1
40
1
18 0
1
0
1
2
28 2
19 0
end_DTG
begin_DTG
1
1
39
1
0 0
1
0
13
2
22 0
1 0
end_DTG
begin_DTG
1
1
38
1
10 0
1
0
6
2
25 1
11 0
end_DTG
begin_DTG
1
1
37
1
20 0
1
0
0
2
29 2
21 0
end_DTG
begin_DTG
1
1
36
1
17 0
1
0
4
2
27 3
16 0
end_DTG
begin_DTG
1
1
35
1
6 0
1
0
11
2
23 7
4 0
end_DTG
begin_DTG
1
1
34
1
9 0
1
0
8
2
24 6
8 0
end_DTG
begin_DTG
1
1
33
1
9 0
1
0
7
2
24 7
7 0
end_DTG
begin_DTG
1
1
32
1
17 0
1
0
3
2
27 6
15 0
end_DTG
begin_DTG
1
1
31
1
17 0
1
0
2
2
27 7
14 0
end_DTG
begin_DTG
1
1
30
1
6 0
1
0
10
2
23 2
3 0
end_DTG
begin_DTG
1
1
29
1
6 0
1
0
9
2
23 3
2 0
end_DTG
begin_DTG
1
1
28
1
12 0
1
0
5
2
26 2
13 0
end_DTG
begin_DTG
0
14
0
49
3
34 0
29 6
21 0
0
57
3
31 0
28 6
19 0
0
77
3
40 0
27 6
14 0
0
78
3
39 0
27 6
15 0
0
79
3
35 0
27 6
16 0
0
87
3
43 0
26 6
13 0
0
95
3
33 0
25 6
11 0
0
108
3
38 0
24 6
7 0
0
109
3
37 0
24 6
8 0
0
136
3
42 0
23 6
2 0
0
137
3
41 0
23 6
3 0
0
138
3
36 0
23 6
4 0
0
139
3
30 0
23 6
5 0
0
147
3
32 0
22 6
1 0
end_DTG
begin_DTG
0
14
0
48
3
34 0
29 5
21 0
0
56
3
31 0
28 5
19 0
0
74
3
40 0
27 5
14 0
0
75
3
39 0
27 5
15 0
0
76
3
35 0
27 5
16 0
0
86
3
43 0
26 5
13 0
0
94
3
33 0
25 5
11 0
0
106
3
38 0
24 5
7 0
0
107
3
37 0
24 5
8 0
0
132
3
42 0
23 5
2 0
0
133
3
41 0
23 5
3 0
0
134
3
36 0
23 5
4 0
0
135
3
30 0
23 5
5 0
0
146
3
32 0
22 5
1 0
end_DTG
begin_DTG
0
14
0
47
3
34 0
29 4
21 0
0
55
3
31 0
28 4
19 0
0
71
3
40 0
27 4
14 0
0
72
3
39 0
27 4
15 0
0
73
3
35 0
27 4
16 0
0
85
3
43 0
26 4
13 0
0
93
3
33 0
25 4
11 0
0
104
3
38 0
24 4
7 0
0
105
3
37 0
24 4
8 0
0
128
3
42 0
23 4
2 0
0
129
3
41 0
23 4
3 0
0
130
3
36 0
23 4
4 0
0
131
3
30 0
23 4
5 0
0
145
3
32 0
22 4
1 0
end_DTG
begin_DTG
0
14
0
46
3
34 0
29 3
21 0
0
54
3
31 0
28 3
19 0
0
68
3
40 0
27 3
14 0
0
69
3
39 0
27 3
15 0
0
70
3
35 0
27 3
16 0
0
84
3
43 0
26 3
13 0
0
92
3
33 0
25 3
11 0
0
102
3
38 0
24 3
7 0
0
103
3
37 0
24 3
8 0
0
124
3
42 0
23 3
2 0
0
125
3
41 0
23 3
3 0
0
126
3
36 0
23 3
4 0
0
127
3
30 0
23 3
5 0
0
144
3
32 0
22 3
1 0
end_DTG
begin_DTG
0
14
0
45
3
34 0
29 2
21 0
0
53
3
31 0
28 2
19 0
0
64
3
40 0
27 2
14 0
0
66
3
39 0
27 2
15 0
0
67
3
35 0
27 2
16 0
0
83
3
43 0
26 2
13 0
0
91
3
33 0
25 2
11 0
0
100
3
38 0
24 2
7 0
0
101
3
37 0
24 2
8 0
0
117
3
42 0
23 2
2 0
0
119
3
41 0
23 2
3 0
0
121
3
36 0
23 2
4 0
0
123
3
30 0
23 2
5 0
0
143
3
32 0
22 2
1 0
end_DTG
begin_DTG
0
11
0
44
3
34 0
29 2
21 0
0
52
3
31 0
28 2
19 0
0
63
3
40 0
27 2
14 0
0
65
3
39 0
27 2
15 0
0
82
3
43 0
26 2
13 0
0
90
3
33 0
25 2
11 0
0
99
3
38 0
24 2
7 0
0
118
3
41 0
23 2
3 0
0
120
3
36 0
23 2
4 0
0
122
3
30 0
23 2
5 0
0
142
3
32 0
22 2
1 0
end_DTG
begin_DTG
0
14
0
43
3
34 0
29 0
21 0
0
51
3
31 0
28 0
19 0
0
59
3
40 0
27 0
14 0
0
61
3
39 0
27 0
15 0
0
62
3
35 0
27 0
16 0
0
81
3
43 0
26 0
13 0
0
89
3
33 0
25 0
11 0
0
97
3
38 0
24 0
7 0
0
98
3
37 0
24 0
8 0
0
110
3
42 0
23 0
2 0
0
112
3
41 0
23 0
3 0
0
114
3
36 0
23 0
4 0
0
116
3
30 0
23 0
5 0
0
141
3
32 0
22 0
1 0
end_DTG
begin_DTG
0
11
0
42
3
34 0
29 0
21 0
0
50
3
31 0
28 0
19 0
0
58
3
40 0
27 0
14 0
0
60
3
39 0
27 0
15 0
0
80
3
43 0
26 0
13 0
0
88
3
33 0
25 0
11 0
0
96
3
38 0
24 0
7 0
0
111
3
41 0
23 0
3 0
0
113
3
36 0
23 0
4 0
0
115
3
30 0
23 0
5 0
0
140
3
32 0
22 0
1 0
end_DTG
begin_CG
2
32 1
1 1
10
32 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
0 1
8
42 1
50 1
48 1
47 1
46 1
45 1
44 1
6 1
10
41 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
6 1
10
36 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
6 1
10
30 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
6 1
8
42 1
41 1
36 1
30 1
2 1
3 1
4 1
5 1
10
38 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
9 1
8
37 1
50 1
48 1
47 1
46 1
45 1
44 1
9 1
4
38 1
37 1
7 1
8 1
2
33 1
11 1
10
33 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
10 1
2
43 1
13 1
10
43 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
12 1
10
40 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
17 1
10
39 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
17 1
8
35 1
50 1
48 1
47 1
46 1
45 1
44 1
17 1
6
40 1
39 1
35 1
14 1
15 1
16 1
2
31 1
19 1
10
31 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
18 1
2
34 1
21 1
10
34 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
20 1
9
32 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
12
42 1
41 1
36 1
30 1
51 3
50 4
49 3
48 4
47 4
46 4
45 4
44 4
10
38 1
37 1
51 1
50 2
49 1
48 2
47 2
46 2
45 2
44 2
9
33 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
9
43 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
11
40 1
39 1
35 1
51 2
50 3
49 2
48 3
47 3
46 3
45 3
44 3
9
31 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
9
34 1
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
6
50 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
6
50 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
6
50 1
48 1
47 1
46 1
45 1
44 1
8
51 1
50 1
49 1
48 1
47 1
46 1
45 1
44 1
0
0
0
0
0
0
0
0
end_CG
