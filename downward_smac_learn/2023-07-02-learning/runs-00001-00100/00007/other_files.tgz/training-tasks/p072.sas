begin_version
3
end_version
begin_metric
0
end_metric
54
begin_variable
var56
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var60
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var61
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var51
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var50
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var49
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var48
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var47
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var46
-1
8
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
end_variable
begin_variable
var45
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var44
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var43
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var42
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var41
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var40
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var39
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins15)
NegatedAtom calibrated(ins15)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




195
0
3
202
0
4
209
0
5
216
0
6
223
0
7
230
0
7
0
181
0
2
196
0
3
203
0
4
210
0
5
217
0
6
224
0
7
231
0
7
0
182
0
1
189
0
3
204
0
4
211
0
5
218
0
6
225
0
7
232
0
7
0
183
0
1
190
0
2
197
0
4
212
0
5
219
0
6
226
0
7
233
0
7
0
184
0
1
191
0
2
198
0
3
205
0
5
220
0
6
227
0
7
234
0
7
0
185
0
1
192
0
2
199
0
3
206
0
4
213
0
6
228
0
7
235
0
7
0
186
0
1
193
0
2
200
0
3
207
0
4
214
0
5
221
0
7
236
0
7
0
187
0
1
194
0
2
201
0
3
208
0
4
215
0
5
222
0
6
229
0
end_DTG
begin_DTG
7
1
132
0
2
139
0
3
146
0
4
153
0
5
160
0
6
167
0
7
174
0
7
0
125
0
2
140
0
3
147
0
4
154
0
5
161
0
6
168
0
7
175
0
7
0
126
0
1
133
0
3
148
0
4
155
0
5
162
0
6
169
0
7
176
0
7
0
127
0
1
134
0
2
141
0
4
156
0
5
163
0
6
170
0
7
177
0
7
0
128
0
1
135
0
2
142
0
3
149
0
5
164
0
6
171
0
7
178
0
7
0
129
0
1
136
0
2
143
0
3
150
0
4
157
0
6
172
0
7
179
0
7
0
130
0
1
137
0
2
144
0
3
151
0
4
158
0
5
165
0
7
180
0
7
0
131
0
1
138
0
2
145
0
3
152
0
4
159
0
5
166
0
6
173
0
end_DTG
begin_DTG
1
1
44
1
7 0
1
0
12
2
24 7
6 0
end_DTG
begin_DTG
1
1
43
1
10 0
1
0
8
2
25 6
9 0
end_DTG
begin_DTG
1
1
42
1
7 0
1
0
11
2
24 6
5 0
end_DTG
begin_DTG
1
1
41
1
13 0
1
0
6
2
26 2
12 0
end_DTG
begin_DTG
1
1
40
1
21 0
1
0
0
2
30 5
22 0
end_DTG
begin_DTG
1
1
39
1
16 0
1
0
3
2
28 6
17 0
end_DTG
begin_DTG
1
1
38
1
14 0
1
0
4
2
27 1
15 0
end_DTG
begin_DTG
1
1
37
1
2 0
1
0
14
2
23 2
1 0
end_DTG
begin_DTG
1
1
36
1
10 0
1
0
7
2
25 0
8 0
end_DTG
begin_DTG
1
1
35
1
7 0
1
0
10
2
24 4
4 0
end_DTG
begin_DTG
1
1
34
1
20 0
1
0
2
2
29 4
19 0
end_DTG
begin_DTG
1
1
33
1
13 0
1
0
5
2
26 2
11 0
end_DTG
begin_DTG
1
1
32
1
7 0
1
0
9
2
24 3
3 0
end_DTG
begin_DTG
1
1
31
1
2 0
1
0
13
2
23 7
0 0
end_DTG
begin_DTG
0
7
0
64
3
36 0
28 4
17 0
0
65
3
37 0
27 4
15 0
0
68
3
34 0
26 4
12 0
0
76
3
39 0
25 4
8 0
0
78
3
32 0
25 4
9 0
0
92
3
40 0
24 4
4 0
0
114
3
44 0
23 4
0 0
end_DTG
begin_DTG
1
1
30
1
20 0
1
0
1
2
29 2
18 0
end_DTG
begin_DTG
0
11
0
49
3
35 0
30 7
22 0
0
61
3
46 0
29 7
18 0
0
63
3
41 0
29 7
19 0
0
73
3
34 0
26 7
12 0
0
82
3
39 0
25 7
8 0
0
104
3
43 0
24 7
3 0
0
106
3
40 0
24 7
4 0
0
108
3
33 0
24 7
5 0
0
109
3
31 0
24 7
6 0
0
122
3
44 0
23 7
0 0
0
124
3
38 0
23 7
1 0
end_DTG
begin_DTG
0
9
0
60
3
46 0
29 7
18 0
0
62
3
41 0
29 7
19 0
0
72
3
42 0
26 7
11 0
0
81
3
39 0
25 7
8 0
0
103
3
43 0
24 7
3 0
0
105
3
40 0
24 7
4 0
0
107
3
33 0
24 7
5 0
0
121
3
44 0
23 7
0 0
0
123
3
38 0
23 7
1 0
end_DTG
begin_DTG
0
11
0
48
3
35 0
30 6
22 0
0
57
3
46 0
29 6
18 0
0
59
3
41 0
29 6
19 0
0
71
3
34 0
26 6
12 0
0
80
3
39 0
25 6
8 0
0
97
3
43 0
24 6
3 0
0
99
3
40 0
24 6
4 0
0
101
3
33 0
24 6
5 0
0
102
3
31 0
24 6
6 0
0
118
3
44 0
23 6
0 0
0
120
3
38 0
23 6
1 0
end_DTG
begin_DTG
0
9
0
56
3
46 0
29 6
18 0
0
58
3
41 0
29 6
19 0
0
70
3
42 0
26 6
11 0
0
79
3
39 0
25 6
8 0
0
96
3
43 0
24 6
3 0
0
98
3
40 0
24 6
4 0
0
100
3
33 0
24 6
5 0
0
117
3
44 0
23 6
0 0
0
119
3
38 0
23 6
1 0
end_DTG
begin_DTG
0
11
0
47
3
35 0
30 4
22 0
0
54
3
46 0
29 4
18 0
0
55
3
41 0
29 4
19 0
0
69
3
34 0
26 4
12 0
0
77
3
39 0
25 4
8 0
0
91
3
43 0
24 4
3 0
0
93
3
40 0
24 4
4 0
0
94
3
33 0
24 4
5 0
0
95
3
31 0
24 4
6 0
0
115
3
44 0
23 4
0 0
0
116
3
38 0
23 4
1 0
end_DTG
begin_DTG
0
11
0
46
3
35 0
30 2
22 0
0
52
3
46 0
29 2
18 0
0
53
3
41 0
29 2
19 0
0
67
3
34 0
26 2
12 0
0
75
3
39 0
25 2
8 0
0
87
3
43 0
24 2
3 0
0
88
3
40 0
24 2
4 0
0
89
3
33 0
24 2
5 0
0
90
3
31 0
24 2
6 0
0
112
3
44 0
23 2
0 0
0
113
3
38 0
23 2
1 0
end_DTG
begin_DTG
0
11
0
45
3
35 0
30 0
22 0
0
50
3
46 0
29 0
18 0
0
51
3
41 0
29 0
19 0
0
66
3
34 0
26 0
12 0
0
74
3
39 0
25 0
8 0
0
83
3
43 0
24 0
3 0
0
84
3
40 0
24 0
4 0
0
85
3
33 0
24 0
5 0
0
86
3
31 0
24 0
6 0
0
110
3
44 0
23 0
0 0
0
111
3
38 0
23 0
1 0
end_DTG
begin_CG
10
44 1
53 1
52 1
45 1
51 1
50 1
49 1
48 1
47 1
2 1
9
38 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
2 1
4
44 1
38 1
0 1
1 1
9
43 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
7 1
10
40 1
53 1
52 1
45 1
51 1
50 1
49 1
48 1
47 1
7 1
9
33 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
7 1
7
31 1
53 1
52 1
51 1
49 1
47 1
7 1
8
43 1
40 1
33 1
31 1
3 1
4 1
5 1
6 1
10
39 1
53 1
52 1
45 1
51 1
50 1
49 1
48 1
47 1
10 1
3
32 1
45 1
10 1
4
39 1
32 1
8 1
9 1
4
42 1
50 1
48 1
13 1
8
34 1
53 1
52 1
45 1
51 1
49 1
47 1
13 1
4
42 1
34 1
11 1
12 1
2
37 1
15 1
3
37 1
45 1
14 1
2
36 1
17 1
3
36 1
45 1
16 1
9
46 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
20 1
9
41 1
53 1
52 1
51 1
50 1
49 1
48 1
47 1
20 1
4
46 1
41 1
18 1
19 1
2
35 1
22 1
7
35 1
53 1
52 1
51 1
49 1
47 1
21 1
10
44 1
38 1
53 2
52 2
45 1
51 2
50 2
49 2
48 2
47 2
12
43 1
40 1
33 1
31 1
53 4
52 4
45 1
51 4
50 3
49 4
48 3
47 4
10
39 1
32 1
53 1
52 1
45 2
51 1
50 1
49 1
48 1
47 1
10
42 1
34 1
53 1
52 1
45 1
51 1
50 1
49 1
48 1
47 1
2
37 1
45 1
2
36 1
45 1
9
46 1
41 1
53 2
52 2
51 2
50 2
49 2
48 2
47 2
6
35 1
53 1
52 1
51 1
49 1
47 1
5
53 1
52 1
51 1
49 1
47 1
1
45 1
7
53 1
52 1
51 1
50 1
49 1
48 1
47 1
6
53 1
52 1
45 1
51 1
49 1
47 1
5
53 1
52 1
51 1
49 1
47 1
1
45 1
1
45 1
7
53 1
52 1
51 1
50 1
49 1
48 1
47 1
8
53 1
52 1
45 1
51 1
50 1
49 1
48 1
47 1
8
53 1
52 1
45 1
51 1
50 1
49 1
48 1
47 1
7
53 1
52 1
51 1
50 1
49 1
48 1
47 1
2
50 1
48 1
7
53 1
52 1
51 1
50 1
49 1
48 1
47 1
8
53 1
52 1
45 1
51 1
50 1
49 1
48 1
47 1
0
7
53 1
52 1
51 1
50 1
49 1
48 1
47 1
0
0
0
0
0
0
0
end_CG
