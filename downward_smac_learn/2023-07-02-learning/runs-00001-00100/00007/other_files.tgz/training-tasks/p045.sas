begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var35
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var36
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var30
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var29
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var34
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var28
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var27
-1
6
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
end_variable
begin_variable
var25
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var24
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var23
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var22
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var21
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var19
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
0
begin_state
1
1
0
1
1
0
1
1
1
0
0
1
0
1
2
5
2
0
1
1
1
1
1
1
1
1
1
end_state
begin_goal
5
14 3
16 0
17 5
25 0
26 0
end_goal
186
begin_operator
calibrate sat1 ins4 dir6
2
18 5
13 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat2 ins1 dir6
2
17 5
11 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat3 ins9 dir2
2
16 1
8 0
1
0 19 -1 0
0
end_operator
begin_operator
calibrate sat4 ins8 dir6
2
15 5
4 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat6 ins10 dir6
2
14 5
0 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat6 ins5 dir2
2
14 1
1 0
1
0 21 -1 0
0
end_operator
begin_operator
switch_off ins1 sat2
0
2
0 10 -1 0
0 11 0 1
0
end_operator
begin_operator
switch_off ins10 sat6
0
2
0 2 -1 0
0 0 0 1
0
end_operator
begin_operator
switch_off ins2 sat3
0
2
0 9 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins4 sat1
0
2
0 12 -1 0
0 13 0 1
0
end_operator
begin_operator
switch_off ins5 sat6
0
2
0 2 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins6 sat4
0
2
0 5 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins7 sat3
0
2
0 9 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins8 sat4
0
2
0 5 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins9 sat3
0
2
0 9 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_on ins1 sat2
0
3
0 24 -1 1
0 10 0 1
0 11 -1 0
0
end_operator
begin_operator
switch_on ins10 sat6
0
3
0 23 -1 1
0 2 0 1
0 0 -1 0
0
end_operator
begin_operator
switch_on ins2 sat3
0
2
0 9 0 1
0 6 -1 0
0
end_operator
begin_operator
switch_on ins4 sat1
0
3
0 22 -1 1
0 12 0 1
0 13 -1 0
0
end_operator
begin_operator
switch_on ins5 sat6
0
3
0 21 -1 1
0 2 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins6 sat4
0
2
0 5 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins7 sat3
0
2
0 9 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins8 sat4
0
3
0 20 -1 1
0 5 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins9 sat3
0
3
0 19 -1 1
0 9 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image sat1 dir5 ins4 mod2
3
22 0
18 4
13 0
1
0 26 -1 0
0
end_operator
begin_operator
take_image sat1 dir6 ins4 mod2
3
22 0
18 5
13 0
1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
check 0
check 0
switch 4
check 0
check 1
30
check 0
check 0
switch 4
check 0
check 1
31
check 0
check 0
check 0
check 0
switch 19
check 0
switch 16
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
28
check 0
check 0
switch 8
check 0
check 1
29
check 0
check 0
check 0
check 0
switch 18
check 0
check 5
41
46
51
56
61
check 5
36
47
52
57
62
check 5
37
42
53
58
63
check 5
38
43
48
59
64
check 5
39
44
49
54
65
switch 17
check 5
40
45
50
55
60
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 1
0
check 0
check 0
switch 17
check 0
check 5
71
76
81
86
91
check 5
66
77
82
87
92
check 5
67
72
83
88
93
check 5
68
73
78
89
94
check 5
69
74
79
84
95
switch 16
check 5
70
75
80
85
90
check 0
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
check 1
1
check 0
check 0
switch 16
check 0
check 5
101
106
111
116
121
switch 15
check 5
96
107
112
117
122
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
2
check 0
check 0
check 5
97
102
113
118
123
check 5
98
103
108
119
124
check 5
99
104
109
114
125
check 5
100
105
110
115
120
switch 15
check 0
check 5
131
136
141
146
151
check 5
126
137
142
147
152
check 5
127
132
143
148
153
check 5
128
133
138
149
154
check 5
129
134
139
144
155
switch 14
check 5
130
135
140
145
150
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
3
check 0
check 0
switch 14
check 0
check 5
161
166
171
176
181
switch 12
check 5
156
167
172
177
182
check 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
check 5
157
162
173
178
183
check 5
158
163
168
179
184
check 5
159
164
169
174
185
switch 12
check 5
160
165
170
175
180
check 0
check 0
switch 0
check 0
check 1
4
check 0
check 0
switch 12
check 0
check 1
18
check 0
switch 10
check 0
check 1
15
check 0
switch 9
check 0
check 3
17
21
23
check 0
switch 5
check 0
check 2
20
22
check 0
switch 2
check 0
check 2
16
19
check 0
switch 11
check 0
check 1
6
check 0
switch 0
check 0
check 1
7
check 0
switch 6
check 0
check 1
8
check 0
switch 13
check 0
check 1
9
check 0
switch 1
check 0
check 1
10
check 0
switch 3
check 0
check 1
11
check 0
switch 7
check 0
check 1
12
check 0
switch 4
check 0
check 1
13
check 0
switch 8
check 0
check 1
14
check 0
check 0
end_SG
begin_DTG
1
1
7
0
1
0
16
1
2 0
end_DTG
begin_DTG
1
1
10
0
1
0
19
1
2 0
end_DTG
begin_DTG
1
1
16
0
2
0
7
1
0 0
0
10
1
1 0
end_DTG
begin_DTG
1
1
11
0
1
0
20
1
5 0
end_DTG
begin_DTG
1
1
13
0
1
0
22
1
5 0
end_DTG
begin_DTG
1
1
20
0
2
0
11
1
3 0
0
13
1
4 0
end_DTG
begin_DTG
1
1
8
0
1
0
17
1
9 0
end_DTG
begin_DTG
1
1
12
0
1
0
21
1
9 0
end_DTG
begin_DTG
1
1
14
0
1
0
23
1
9 0
end_DTG
begin_DTG
1
1
17
0
3
0
8
1
6 0
0
12
1
7 0
0
14
1
8 0
end_DTG
begin_DTG
1
1
15
0
1
0
6
1
11 0
end_DTG
begin_DTG
1
1
6
0
1
0
15
1
10 0
end_DTG
begin_DTG
1
1
18
0
1
0
9
1
13 0
end_DTG
begin_DTG
1
1
9
0
1
0
18
1
12 0
end_DTG
begin_DTG
5
1
161
0
2
166
0
3
171
0
4
176
0
5
181
0
5
0
156
0
2
167
0
3
172
0
4
177
0
5
182
0
5
0
157
0
1
162
0
3
173
0
4
178
0
5
183
0
5
0
158
0
1
163
0
2
168
0
4
179
0
5
184
0
5
0
159
0
1
164
0
2
169
0
3
174
0
5
185
0
5
0
160
0
1
165
0
2
170
0
3
175
0
4
180
0
end_DTG
begin_DTG
5
1
131
0
2
136
0
3
141
0
4
146
0
5
151
0
5
0
126
0
2
137
0
3
142
0
4
147
0
5
152
0
5
0
127
0
1
132
0
3
143
0
4
148
0
5
153
0
5
0
128
0
1
133
0
2
138
0
4
149
0
5
154
0
5
0
129
0
1
134
0
2
139
0
3
144
0
5
155
0
5
0
130
0
1
135
0
2
140
0
3
145
0
4
150
0
end_DTG
begin_DTG
5
1
101
0
2
106
0
3
111
0
4
116
0
5
121
0
5
0
96
0
2
107
0
3
112
0
4
117
0
5
122
0
5
0
97
0
1
102
0
3
113
0
4
118
0
5
123
0
5
0
98
0
1
103
0
2
108
0
4
119
0
5
124
0
5
0
99
0
1
104
0
2
109
0
3
114
0
5
125
0
5
0
100
0
1
105
0
2
110
0
3
115
0
4
120
0
end_DTG
begin_DTG
5
1
71
0
2
76
0
3
81
0
4
86
0
5
91
0
5
0
66
0
2
77
0
3
82
0
4
87
0
5
92
0
5
0
67
0
1
72
0
3
83
0
4
88
0
5
93
0
5
0
68
0
1
73
0
2
78
0
4
89
0
5
94
0
5
0
69
0
1
74
0
2
79
0
3
84
0
5
95
0
5
0
70
0
1
75
0
2
80
0
3
85
0
4
90
0
end_DTG
begin_DTG
5
1
41
0
2
46
0
3
51
0
4
56
0
5
61
0
5
0
36
0
2
47
0
3
52
0
4
57
0
5
62
0
5
0
37
0
1
42
0
3
53
0
4
58
0
5
63
0
5
0
38
0
1
43
0
2
48
0
4
59
0
5
64
0
5
0
39
0
1
44
0
2
49
0
3
54
0
5
65
0
5
0
40
0
1
45
0
2
50
0
3
55
0
4
60
0
end_DTG
begin_DTG
1
1
23
1
9 0
1
0
2
2
16 1
8 0
end_DTG
begin_DTG
1
1
22
1
5 0
1
0
3
2
15 5
4 0
end_DTG
begin_DTG
1
1
19
1
2 0
1
0
5
2
14 1
1 0
end_DTG
begin_DTG
1
1
18
1
12 0
1
0
0
2
18 5
13 0
end_DTG
begin_DTG
1
1
16
1
2 0
1
0
4
2
14 5
0 0
end_DTG
begin_DTG
1
1
15
1
10 0
1
0
1
2
17 5
11 0
end_DTG
begin_DTG
0
6
0
25
3
22 0
18 5
13 0
0
27
3
24 0
17 5
11 0
0
29
3
19 0
16 5
8 0
0
31
3
20 0
15 5
4 0
0
34
3
23 0
14 5
0 0
0
35
3
21 0
14 5
1 0
end_DTG
begin_DTG
0
6
0
24
3
22 0
18 4
13 0
0
26
3
24 0
17 4
11 0
0
28
3
19 0
16 4
8 0
0
30
3
20 0
15 4
4 0
0
32
3
23 0
14 4
0 0
0
33
3
21 0
14 4
1 0
end_DTG
begin_CG
4
23 1
26 1
25 1
2 1
4
21 1
26 1
25 1
2 1
4
23 1
21 1
0 1
1 1
1
5 1
4
20 1
26 1
25 1
5 1
3
20 1
3 1
4 1
1
9 1
1
9 1
4
19 1
26 1
25 1
9 1
4
19 1
6 1
7 1
8 1
2
24 1
11 1
4
24 1
26 1
25 1
10 1
2
22 1
13 1
4
22 1
26 1
25 1
12 1
4
23 1
21 1
26 2
25 2
3
20 1
26 1
25 1
3
19 1
26 1
25 1
3
24 1
26 1
25 1
3
22 1
26 1
25 1
2
26 1
25 1
2
26 1
25 1
2
26 1
25 1
2
26 1
25 1
2
26 1
25 1
2
26 1
25 1
0
0
end_CG
