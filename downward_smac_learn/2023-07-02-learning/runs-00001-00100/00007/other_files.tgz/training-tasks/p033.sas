begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var21
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var26
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var20
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var22
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var24
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var27
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var19
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var25
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var28
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var18
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var17
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var23
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var16
-1
5
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
end_variable
begin_variable
var15
-1
5
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
end_variable
begin_variable
var14
-1
5
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
end_variable
begin_variable
var13
-1
5
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
end_variable
begin_variable
var12
-1
5
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var9
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var8
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir1, mod1)
NegatedAtom have_image(dir1, mod1)
end_variable
0
begin_state
0
1
0
1
1
1
0
1
1
0
0
1
3
1
3
2
0
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
7
12 2
13 3
14 0
15 2
24 0
25 0
26 0
end_goal
142
begin_operator
calibrate sat1 ins2 dir3
2
16 2
11 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat2 ins4 dir1
2
15 0
7 0
1
0 20 -1 0
0
end_operator
begin_operator
calibrate sat2 ins7 dir4
2
15 3
8 0
1
0 17 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir5
2
14 4
4 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat3 ins6 dir2
2
14 1
5 0
1
0 18 -1 0
0
end_operator
begin_operator
calibrate sat4 ins1 dir3
2
13 2
3 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat5 ins5 dir4
2
12 3
1 0
1
0 19 -1 0
0
end_operator
begin_operator
switch_off ins1 sat4
0
2
0 2 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins2 sat1
0
2
0 10 -1 0
0 11 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 6 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins4 sat2
0
2
0 9 -1 0
0 7 0 1
0
end_operator
begin_operator
switch_off ins5 sat5
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins6 sat3
0
2
0 6 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_off ins7 sat2
0
2
0 9 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_on ins1 sat4
0
3
0 23 -1 1
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins2 sat1
0
3
0 22 -1 1
0 10 0 1
0 11 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 21 -1 1
0 6 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins4 sat2
0
3
0 20 -1 1
0 9 0 1
0 7 -1 0
0
end_operator
begin_operator
switch_on ins5 sat5
0
3
0 19 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins6 sat3
0
3
0 18 -1 1
0 6 0 1
0 5 -1 0
0
end_operator
begin_operator
switch_on ins7 sat2
0
3
0 17 -1 1
0 9 0 1
0 8 -1 0
0
end_operator
begin_operator
take_image sat1 dir1 ins2 mod1
3
22 0
16 0
11 0
1
0 26 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins2 mod1
3
22 0
16 1
11 0
1
0 25 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins2 mod1
3
22 0
16 2
11 0
1
0 24 -1 0
0
end_operator
begin_operator
take_image sat2 dir1 ins4 mod1
3
20 0
15 0
7 0
1
0 26 -1 0
0
end_operator
begin_operator
take_image sat2 dir1 ins7 mod1
3
17 0
15 0
8 0
1
0 26 -1 0
0
end_operator
begin_operator
take_i




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
check 1
28
check 0
check 0
check 0
check 0
check 0
check 0
switch 19
check 0
switch 12
check 0
switch 1
check 0
check 1
39
check 0
check 0
switch 1
check 0
check 1
40
check 0
check 0
switch 1
check 0
check 1
41
check 0
check 0
check 0
check 0
check 0
check 0
switch 18
check 0
switch 14
check 0
switch 5
check 0
check 1
31
check 0
check 0
switch 5
check 0
check 1
33
check 0
check 0
switch 5
check 0
check 1
35
check 0
check 0
check 0
check 0
check 0
check 0
switch 17
check 0
switch 15
check 0
switch 8
check 0
check 1
25
check 0
check 0
switch 8
check 0
check 1
27
check 0
check 0
switch 8
check 0
check 1
29
check 0
check 0
check 0
check 0
check 0
check 0
switch 16
check 0
check 4
46
50
54
58
check 4
42
51
55
59
switch 15
check 4
43
47
56
60
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
check 1
0
check 0
check 0
check 4
44
48
52
61
check 4
45
49
53
57
switch 15
check 0
switch 14
check 4
66
70
74
78
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
1
check 0
check 0
check 4
62
71
75
79
check 4
63
67
76
80
switch 14
check 4
64
68
72
81
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
2
check 0
check 0
check 4
65
69
73
77
switch 14
check 0
check 4
86
90
94
98
switch 13
check 4
82
91
95
99
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
4
check 0
check 0
check 4
83
87
96
100
check 4
84
88
92
101
switch 13
check 4
85
89
93
97
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
3
check 0
check 0
switch 13
check 0
check 4
106
110
114
118
check 4
102
111
115
119
switch 12
check 4
103
107
116
120
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
5
check 0
check 0
check 4
104
108
112
121
check 4
105
109
113
117
switch 12
check 0
check 4
126
130
134
138
check 4
122
131
135
139
check 4
123
127
136
140
switch 10
check 4
124
128
132
141
check 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 4
125
129
133
137
switch 10
check 0
check 1
15
check 0
switch 9
check 0
check 2
17
20
check 0
switch 6
check 0
check 2
16
19
check 0
switch 2
check 0
check 1
14
check 0
switch 0
check 0
check 1
18
check 0
switch 3
check 0
check 1
7
check 0
switch 11
check 0
check 1
8
check 0
switch 4
check 0
check 1
9
check 0
switch 7
check 0
check 1
10
check 0
switch 1
check 0
check 1
11
check 0
switch 5
check 0
check 1
12
check 0
switch 8
check 0
check 1
13
check 0
check 0
end_SG
begin_DTG
1
1
18
0
1
0
11
1
1 0
end_DTG
begin_DTG
1
1
11
0
1
0
18
1
0 0
end_DTG
begin_DTG
1
1
14
0
1
0
7
1
3 0
end_DTG
begin_DTG
1
1
7
0
1
0
14
1
2 0
end_DTG
begin_DTG
1
1
9
0
1
0
16
1
6 0
end_DTG
begin_DTG
1
1
12
0
1
0
19
1
6 0
end_DTG
begin_DTG
1
1
16
0
2
0
9
1
4 0
0
12
1
5 0
end_DTG
begin_DTG
1
1
10
0
1
0
17
1
9 0
end_DTG
begin_DTG
1
1
13
0
1
0
20
1
9 0
end_DTG
begin_DTG
1
1
17
0
2
0
10
1
7 0
0
13
1
8 0
end_DTG
begin_DTG
1
1
15
0
1
0
8
1
11 0
end_DTG
begin_DTG
1
1
8
0
1
0
15
1
10 0
end_DTG
begin_DTG
4
1
126
0
2
130
0
3
134
0
4
138
0
4
0
122
0
2
131
0
3
135
0
4
139
0
4
0
123
0
1
127
0
3
136
0
4
140
0
4
0
124
0
1
128
0
2
132
0
4
141
0
4
0
125
0
1
129
0
2
133
0
3
137
0
end_DTG
begin_DTG
4
1
106
0
2
110
0
3
114
0
4
118
0
4
0
102
0
2
111
0
3
115
0
4
119
0
4
0
103
0
1
107
0
3
116
0
4
120
0
4
0
104
0
1
108
0
2
112
0
4
121
0
4
0
105
0
1
109
0
2
113
0
3
117
0
end_DTG
begin_DTG
4
1
86
0
2
90
0
3
94
0
4
98
0
4
0
82
0
2
91
0
3
95
0
4
99
0
4
0
83
0
1
87
0
3
96
0
4
100
0
4
0
84
0
1
88
0
2
92
0
4
101
0
4
0
85
0
1
89
0
2
93
0
3
97
0
end_DTG
begin_DTG
4
1
66
0
2
70
0
3
74
0
4
78
0
4
0
62
0
2
71
0
3
75
0
4
79
0
4
0
63
0
1
67
0
3
76
0
4
80
0
4
0
64
0
1
68
0
2
72
0
4
81
0
4
0
65
0
1
69
0
2
73
0
3
77
0
end_DTG
begin_DTG
4
1
46
0
2
50
0
3
54
0
4
58
0
4
0
42
0
2
51
0
3
55
0
4
59
0
4
0
43
0
1
47
0
3
56
0
4
60
0
4
0
44
0
1
48
0
2
52
0
4
61
0
4
0
45
0
1
49
0
2
53
0
3
57
0
end_DTG
begin_DTG
1
1
20
1
9 0
1
0
2
2
15 3
8 0
end_DTG
begin_DTG
1
1
19
1
6 0
1
0
4
2
14 1
5 0
end_DTG
begin_DTG
1
1
18
1
0 0
1
0
6
2
12 3
1 0
end_DTG
begin_DTG
1
1
17
1
9 0
1
0
1
2
15 0
7 0
end_DTG
begin_DTG
1
1
16
1
6 0
1
0
3
2
14 4
4 0
end_DTG
begin_DTG
1
1
15
1
10 0
1
0
0
2
16 2
11 0
end_DTG
begin_DTG
1
1
14
1
2 0
1
0
5
2
13 2
3 0
end_DTG
begin_DTG
0
7
0
23
3
22 0
16 2
11 0
0
28
3
20 0
15 2
7 0
0
29
3
17 0
15 2
8 0
0
34
3
21 0
14 2
4 0
0
35
3
18 0
14 2
5 0
0
38
3
23 0
13 2
3 0
0
41
3
19 0
12 2
1 0
end_DTG
begin_DTG
0
7
0
22
3
22 0
16 1
11 0
0
26
3
20 0
15 1
7 0
0
27
3
17 0
15 1
8 0
0
32
3
21 0
14 1
4 0
0
33
3
18 0
14 1
5 0
0
37
3
23 0
13 1
3 0
0
40
3
19 0
12 1
1 0
end_DTG
begin_DTG
0
7
0
21
3
22 0
16 0
11 0
0
24
3
20 0
15 0
7 0
0
25
3
17 0
15 0
8 0
0
30
3
21 0
14 0
4 0
0
31
3
18 0
14 0
5 0
0
36
3
23 0
13 0
3 0
0
39
3
19 0
12 0
1 0
end_DTG
begin_CG
2
19 1
1 1
5
19 1
26 1
25 1
24 1
0 1
2
23 1
3 1
5
23 1
26 1
25 1
24 1
2 1
5
21 1
26 1
25 1
24 1
6 1
5
18 1
26 1
25 1
24 1
6 1
4
21 1
18 1
4 1
5 1
5
20 1
26 1
25 1
24 1
9 1
5
17 1
26 1
25 1
24 1
9 1
4
20 1
17 1
7 1
8 1
2
22 1
11 1
5
22 1
26 1
25 1
24 1
10 1
4
19 1
26 1
25 1
24 1
4
23 1
26 1
25 1
24 1
5
21 1
18 1
26 2
25 2
24 2
5
20 1
17 1
26 2
25 2
24 2
4
22 1
26 1
25 1
24 1
3
26 1
25 1
24 1
3
26 1
25 1
24 1
3
26 1
25 1
24 1
3
26 1
25 1
24 1
3
26 1
25 1
24 1
3
26 1
25 1
24 1
3
26 1
25 1
24 1
0
0
0
end_CG
