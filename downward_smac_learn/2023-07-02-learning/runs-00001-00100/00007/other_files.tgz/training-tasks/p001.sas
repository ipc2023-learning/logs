begin_version
3
end_version
begin_metric
0
end_metric
4
begin_variable
var4
-1
2
Atom power_avail(sat1)
Atom power_on(ins1)
end_variable
begin_variable
var3
-1
2
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var2
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
0
begin_state
0
0
1
1
end_state
begin_goal
1
3 0
end_goal
6
begin_operator
calibrate sat1 ins1 dir1
2
1 0
0 1
1
0 2 -1 0
0
end_operator
begin_operator
switch_off ins1 sat1
0
1
0 0 1 0
0
end_operator
begin_operator
switch_on ins1 sat1
0
2
0 2 -1 1
0 0 0 1
0
end_operator
begin_operator
take_image sat1 dir2 ins1 mod1
3
2 0
1 1
0 1
1
0 3 -1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
1
0 1 1 0
0
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
1
0 1 0 1
0
end_operator
0
begin_SG
switch 2
check 0
switch 1
check 0
check 0
switch 0
check 0
check 0
check 1
3
check 0
check 0
check 0
switch 1
check 0
switch 0
check 1
5
check 0
check 1
0
check 0
check 1
4
switch 0
check 0
check 1
2
check 1
1
check 0
end_SG
begin_DTG
1
1
2
0
1
0
1
0
end_DTG
begin_DTG
1
1
5
0
1
0
4
0
end_DTG
begin_DTG
1
1
2
1
0 0
1
0
0
2
1 0
0 1
end_DTG
begin_DTG
0
1
0
3
3
2 0
1 1
0 1
end_DTG
begin_CG
2
2 2
3 1
2
2 1
3 1
1
3 1
0
end_CG
