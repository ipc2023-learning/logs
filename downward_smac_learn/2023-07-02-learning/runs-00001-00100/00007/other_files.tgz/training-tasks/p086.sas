begin_version
3
end_version
begin_metric
0
end_metric
60
begin_variable
var63
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var53
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var52
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var17
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var15
-1
2
Atom c




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
205
0
3
222
0
4
230
0
5
238
0
6
246
0
7
254
0
8
262
0
8
0
198
0
1
206
0
2
214
0
4
231
0
5
239
0
6
247
0
7
255
0
8
263
0
8
0
199
0
1
207
0
2
215
0
3
223
0
5
240
0
6
248
0
7
256
0
8
264
0
8
0
200
0
1
208
0
2
216
0
3
224
0
4
232
0
6
249
0
7
257
0
8
265
0
8
0
201
0
1
209
0
2
217
0
3
225
0
4
233
0
5
241
0
7
258
0
8
266
0
8
0
202
0
1
210
0
2
218
0
3
226
0
4
234
0
5
242
0
6
250
0
8
267
0
8
0
203
0
1
211
0
2
219
0
3
227
0
4
235
0
5
243
0
6
251
0
7
259
0
end_DTG
begin_DTG
8
1
132
0
2
140
0
3
148
0
4
156
0
5
164
0
6
172
0
7
180
0
8
188
0
8
0
124
0
2
141
0
3
149
0
4
157
0
5
165
0
6
173
0
7
181
0
8
189
0
8
0
125
0
1
133
0
3
150
0
4
158
0
5
166
0
6
174
0
7
182
0
8
190
0
8
0
126
0
1
134
0
2
142
0
4
159
0
5
167
0
6
175
0
7
183
0
8
191
0
8
0
127
0
1
135
0
2
143
0
3
151
0
5
168
0
6
176
0
7
184
0
8
192
0
8
0
128
0
1
136
0
2
144
0
3
152
0
4
160
0
6
177
0
7
185
0
8
193
0
8
0
129
0
1
137
0
2
145
0
3
153
0
4
161
0
5
169
0
7
186
0
8
194
0
8
0
130
0
1
138
0
2
146
0
3
154
0
4
162
0
5
170
0
6
178
0
8
195
0
8
0
131
0
1
139
0
2
147
0
3
155
0
4
163
0
5
171
0
6
179
0
7
187
0
end_DTG
begin_DTG
1
1
53
1
6 0
1
0
13
2
29 6
7 0
end_DTG
begin_DTG
1
1
52
1
23 0
1
0
4
2
34 4
22 0
end_DTG
begin_DTG
1
1
51
1
26 0
1
0
1
2
35 6
25 0
end_DTG
begin_DTG
1
1
50
1
4 0
1
0
14
2
28 0
5 0
end_DTG
begin_DTG
1
1
49
1
8 0
1
0
12
2
30 7
9 0
end_DTG
begin_DTG
1
1
48
1
12 0
1
0
10
2
32 3
13 0
end_DTG
begin_DTG
1
1
47
1
10 0
1
0
11
2
31 4
11 0
end_DTG
begin_DTG
1
1
46
1
19 0
1
0
9
2
33 4
18 0
end_DTG
begin_DTG
1
1
45
1
19 0
1
0
8
2
33 7
17 0
end_DTG
begin_DTG
1
1
44
1
19 0
1
0
7
2
33 8
16 0
end_DTG
begin_DTG
1
1
43
1
23 0
1
0
3
2
34 8
21 0
end_DTG
begin_DTG
1
1
42
1
19 0
1
0
6
2
33 0
15 0
end_DTG
begin_DTG
1
1
41
1
26 0
1
0
0
2
35 7
24 0
end_DTG
begin_DTG
1
1
40
1
23 0
1
0
2
2
34 2
20 0
end_DTG
begin_DTG
1
1
39
1
19 0
1
0
5
2
33 3
14 0
end_DTG
begin_DTG
1
1
38
1
3 0
1
0
17
2
27 5
2 0
end_DTG
begin_DTG
1
1
37
1
3 0
1
0
16
2
27 0
1 0
end_DTG
begin_DTG
1
1
36
1
3 0
1
0
15
2
27 2
0 0
end_DTG
begin_DTG
0
11
0
62
3
48 0
35 7
24 0
0
63
3
38 0
35 7
25 0
0
76
3
49 0
34 7
20 0
0
77
3
46 0
34 7
21 0
0
78
3
37 0
34 7
22 0
0
93
3
47 0
33 7
15 0
0
94
3
43 0
33 7
18 0
0
102
3
42 0
31 7
11 0
0
106
3
40 0
30 7
9 0
0
122
3
53 0
27 7
0 0
0
123
3
52 0
27 7
1 0
end_DTG
begin_DTG
0
11
0
60
3
48 0
35 5
24 0
0
61
3
38 0
35 5
25 0
0
73
3
49 0
34 5
20 0
0
74
3
46 0
34 5
21 0
0
75
3
37 0
34 5
22 0
0
91
3
47 0
33 5
15 0
0
92
3
43 0
33 5
18 0
0
101
3
42 0
31 5
11 0
0
105
3
40 0
30 5
9 0
0
120
3
53 0
27 5
0 0
0
121
3
52 0
27 5
1 0
end_DTG
begin_DTG
0
15
0
58
3
48 0
35 4
24 0
0
69
3
49 0
34 4
20 0
0
71
3
46 0
34 4
21 0
0
84
3
50 0
33 4
14 0
0
86
3
47 0
33 4
15 0
0
87
3
45 0
33 4
16 0
0
88
3
44 0
33 4
17 0
0
90
3
43 0
33 4
18 0
0
96
3
41 0
32 4
13 0
0
100
3
42 0
31 4
11 0
0
107
3
36 0
29 4
7 0
0
109
3
39 0
28 4
5 0
0
116
3
53 0
27 4
0 0
0
118
3
52 0
27 4
1 0
0
119
3
51 0
27 4
2 0
end_DTG
begin_DTG
0
11
0
57
3
48 0
35 4
24 0
0
59
3
38 0
35 4
25 0
0
68
3
49 0
34 4
20 0
0
70
3
46 0
34 4
21 0
0
72
3
37 0
34 4
22 0
0
85
3
47 0
33 4
15 0
0
89
3
43 0
33 4
18 0
0
99
3
42 0
31 4
11 0
0
104
3
40 0
30 4
9 0
0
115
3
53 0
27 4
0 0
0
117
3
52 0
27 4
1 0
end_DTG
begin_DTG
0
11
0
55
3
48 0
35 2
24 0
0
56
3
38 0
35 2
25 0
0
65
3
49 0
34 2
20 0
0
66
3
46 0
34 2
21 0
0
67
3
37 0
34 2
22 0
0
82
3
47 0
33 2
15 0
0
83
3
43 0
33 2
18 0
0
98
3
42 0
31 2
11 0
0
103
3
40 0
30 2
9 0
0
113
3
53 0
27 2
0 0
0
114
3
52 0
27 2
1 0
end_DTG
begin_DTG
0
11
0
54
3
48 0
35 0
24 0
0
64
3
46 0
34 0
21 0
0
79
3
47 0
33 0
15 0
0
80
3
45 0
33 0
16 0
0
81
3
43 0
33 0
18 0
0
95
3
41 0
32 0
13 0
0
97
3
42 0
31 0
11 0
0
108
3
39 0
28 0
5 0
0
110
3
53 0
27 0
0 0
0
111
3
52 0
27 0
1 0
0
112
3
51 0
27 0
2 0
end_DTG
begin_CG
8
53 1
59 1
58 1
57 1
56 1
55 1
54 1
3 1
8
52 1
59 1
58 1
57 1
56 1
55 1
54 1
3 1
4
51 1
59 1
56 1
3 1
6
53 1
52 1
51 1
0 1
1 1
2 1
2
39 1
5 1
4
39 1
59 1
56 1
4 1
2
36 1
7 1
3
36 1
56 1
6 1
2
40 1
9 1
6
40 1
58 1
57 1
55 1
54 1
8 1
2
42 1
11 1
8
42 1
59 1
58 1
57 1
56 1
55 1
54 1
10 1
2
41 1
13 1
4
41 1
59 1
56 1
12 1
3
50 1
56 1
19 1
8
47 1
59 1
58 1
57 1
56 1
55 1
54 1
19 1
4
45 1
59 1
56 1
19 1
3
44 1
56 1
19 1
8
43 1
59 1
58 1
57 1
56 1
55 1
54 1
19 1
10
50 1
47 1
45 1
44 1
43 1
14 1
15 1
16 1
17 1
18 1
7
49 1
58 1
57 1
56 1
55 1
54 1
23 1
8
46 1
59 1
58 1
57 1
56 1
55 1
54 1
23 1
6
37 1
58 1
57 1
55 1
54 1
23 1
6
49 1
46 1
37 1
20 1
21 1
22 1
8
48 1
59 1
58 1
57 1
56 1
55 1
54 1
26 1
6
38 1
58 1
57 1
55 1
54 1
26 1
4
48 1
38 1
24 1
25 1
9
53 1
52 1
51 1
59 3
58 2
57 2
56 3
55 2
54 2
3
39 1
59 1
56 1
2
36 1
56 1
5
40 1
58 1
57 1
55 1
54 1
7
42 1
59 1
58 1
57 1
56 1
55 1
54 1
3
41 1
59 1
56 1
11
50 1
47 1
45 1
44 1
43 1
59 3
58 2
57 2
56 5
55 2
54 2
9
49 1
46 1
37 1
59 1
58 3
57 3
56 2
55 3
54 3
8
48 1
38 1
59 1
58 2
57 2
56 1
55 2
54 2
1
56 1
4
58 1
57 1
55 1
54 1
4
58 1
57 1
55 1
54 1
2
59 1
56 1
4
58 1
57 1
55 1
54 1
2
59 1
56 1
6
59 1
58 1
57 1
56 1
55 1
54 1
6
59 1
58 1
57 1
56 1
55 1
54 1
1
56 1
2
59 1
56 1
6
59 1
58 1
57 1
56 1
55 1
54 1
6
59 1
58 1
57 1
56 1
55 1
54 1
6
59 1
58 1
57 1
56 1
55 1
54 1
5
58 1
57 1
56 1
55 1
54 1
1
56 1
2
59 1
56 1
6
59 1
58 1
57 1
56 1
55 1
54 1
6
59 1
58 1
57 1
56 1
55 1
54 1
0
0
0
0
0
0
end_CG
