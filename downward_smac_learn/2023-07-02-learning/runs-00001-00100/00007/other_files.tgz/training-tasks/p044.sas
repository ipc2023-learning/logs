begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var32
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var35
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var38
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var30
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var33
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var29
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var36
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var34
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var28
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var27
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var26
-1
6
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
end_variable
begin_variable
var25
-1
6
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
end_variable
begin_variable
var24
-1
6
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
end_variable
begin_variable
var23
-1
6
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
end_variable
begin_variable
var22
-1
6
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
end_variable
begin_variable
var21
-1
6
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var18
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir3, mod2)
NegatedAtom have_image(dir3, mod2)
end_variable
begin_variable
var12
-1
2
Atom have_image(dir2, mod2)
NegatedAtom have_image(dir2, mod2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var15
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
0
begin_state
0
1
1
1
0
0
1
0
1
1
1
1
0
0
1
0
1
1
1
2
2
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
15 4
17 0
19 5
20 0
29 0
30 0
31 0
33 0
end_goal
234
begin_operator
calibrate sat1 ins5 dir2
2
20 1
14 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir4
2
19 3
9 0
1
0 28 -1 0
0
end_operator
begin_operator
calibrate sat2 ins7 dir5
2
19 4
10 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat2 ins8 dir6
2
19 5
11 0
1
0 22 -1 0
0
end_operator
begin_operator
calibrate sat3 ins4 dir5
2
18 4
8 0
1
0 26 -1 0
0
end_operator
begin_operator
calibrate sat4 ins1 dir3
2
17 2
6 0
1
0 32 -1 0
0
end_operator
begin_operator
calibrate sat5 ins6 dir2
2
16 1
2 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat5 ins9 dir6
2
16 5
3 0
1
0 21 -1 0
0
end_operator
begin_operator
calibrate sat6 ins3 dir5
2
15 4
1 0
1
0 27 -1 0
0
end_operator
begin_operator
switch_off ins1 sat4
0
2
0 5 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins2 sat2
0
2
0 12 -1 0
0 9 0 1
0
end_operator
begin_operator
switch_off ins3 sat6
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins4 sat3
0
2
0 7 -1 0
0 8 0 1
0
end_operator
begin_operator
switch_off ins5 sat1
0
2
0 13 -1 0
0 14 0 1
0
end_operator
begin_operator
switch_off ins6 sat5
0
2
0 4 -1 0
0 2 0 1
0
end_operator
begin_operator
switch_off ins7 sat2
0
2
0 12 -1 0
0 10 0 1
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 5
174
185
190
195
200
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
6
check 0
check 0
check 5
175
180
191
196
201
check 5
176
181
186
197
202
check 5
177
182
187
192
203
switch 15
check 5
178
183
188
193
198
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
7
check 0
check 0
switch 15
check 0
check 5
209
214
219
224
229
check 5
204
215
220
225
230
check 5
205
210
221
226
231
check 5
206
211
216
227
232
switch 13
check 5
207
212
217
222
233
check 0
check 0
switch 1
check 0
check 1
8
check 0
check 0
check 5
208
213
218
223
228
switch 13
check 0
check 1
22
check 0
switch 12
check 0
check 3
19
24
25
check 0
switch 7
check 0
check 1
21
check 0
switch 5
check 0
check 1
18
check 0
switch 4
check 0
check 2
23
26
check 0
switch 0
check 0
check 1
20
check 0
switch 6
check 0
check 1
9
check 0
switch 9
check 0
check 1
10
check 0
switch 1
check 0
check 1
11
check 0
switch 8
check 0
check 1
12
check 0
switch 14
check 0
check 1
13
check 0
switch 2
check 0
check 1
14
check 0
switch 10
check 0
check 1
15
check 0
switch 11
check 0
check 1
16
check 0
switch 3
check 0
check 1
17
check 0
check 0
end_SG
begin_DTG
1
1
20
0
1
0
11
1
1 0
end_DTG
begin_DTG
1
1
11
0
1
0
20
1
0 0
end_DTG
begin_DTG
1
1
14
0
1
0
23
1
4 0
end_DTG
begin_DTG
1
1
17
0
1
0
26
1
4 0
end_DTG
begin_DTG
1
1
23
0
2
0
14
1
2 0
0
17
1
3 0
end_DTG
begin_DTG
1
1
18
0
1
0
9
1
6 0
end_DTG
begin_DTG
1
1
9
0
1
0
18
1
5 0
end_DTG
begin_DTG
1
1
21
0
1
0
12
1
8 0
end_DTG
begin_DTG
1
1
12
0
1
0
21
1
7 0
end_DTG
begin_DTG
1
1
10
0
1
0
19
1
12 0
end_DTG
begin_DTG
1
1
15
0
1
0
24
1
12 0
end_DTG
begin_DTG
1
1
16
0
1
0
25
1
12 0
end_DTG
begin_DTG
1
1
19
0
3
0
10
1
9 0
0
15
1
10 0
0
16
1
11 0
end_DTG
begin_DTG
1
1
22
0
1
0
13
1
14 0
end_DTG
begin_DTG
1
1
13
0
1
0
22
1
13 0
end_DTG
begin_DTG
5
1
209
0
2
214
0
3
219
0
4
224
0
5
229
0
5
0
204
0
2
215
0
3
220
0
4
225
0
5
230
0
5
0
205
0
1
210
0
3
221
0
4
226
0
5
231
0
5
0
206
0
1
211
0
2
216
0
4
227
0
5
232
0
5
0
207
0
1
212
0
2
217
0
3
222
0
5
233
0
5
0
208
0
1
213
0
2
218
0
3
223
0
4
228
0
end_DTG
begin_DTG
5
1
179
0
2
184
0
3
189
0
4
194
0
5
199
0
5
0
174
0
2
185
0
3
190
0
4
195
0
5
200
0
5
0
175
0
1
180
0
3
191
0
4
196
0
5
201
0
5
0
176
0
1
181
0
2
186
0
4
197
0
5
202
0
5
0
177
0
1
182
0
2
187
0
3
192
0
5
203
0
5
0
178
0
1
183
0
2
188
0
3
193
0
4
198
0
end_DTG
begin_DTG
5
1
149
0
2
154
0
3
159
0
4
164
0
5
169
0
5
0
144
0
2
155
0
3
160
0
4
165
0
5
170
0
5
0
145
0
1
150
0
3
161
0
4
166
0
5
171
0
5
0
146
0
1
151
0
2
156
0
4
167
0
5
172
0
5
0
147
0
1
152
0
2
157
0
3
162
0
5
173
0
5
0
148
0
1
153
0
2
158
0
3
163
0
4
168
0
end_DTG
begin_DTG
5
1
119
0
2
124
0
3
129
0
4
134
0
5
139
0
5
0
114
0
2
125
0
3
130
0
4
135
0
5
140
0
5
0
115
0
1
120
0
3
131
0
4
136
0
5
141
0
5
0
116
0
1
121
0
2
126
0
4
137
0
5
142
0
5
0
117
0
1
122
0
2
127
0
3
132
0
5
143
0
5
0
118
0
1
123
0
2
128
0
3
133
0
4
138
0
end_DTG
begin_DTG
5
1
89
0
2
94
0
3
99
0
4
104
0
5
109
0
5
0
84
0
2
95
0
3
100
0
4
105
0
5
110
0
5
0
85
0
1
90
0
3
101
0
4
106
0
5
111
0
5
0
86
0
1
91
0
2
96
0
4
107
0
5
112
0
5
0
87
0
1
92
0
2
97
0
3
102
0
5
113
0
5
0
88
0
1
93
0
2
98
0
3
103
0
4
108
0
end_DTG
begin_DTG
5
1
59
0
2
64
0
3
69
0
4
74
0
5
79
0
5
0
54
0
2
65
0
3
70
0
4
75
0
5
80
0
5
0
55
0
1
60
0
3
71
0
4
76
0
5
81
0
5
0
56
0
1
61
0
2
66
0
4
77
0
5
82
0
5
0
57
0
1
62
0
2
67
0
3
72
0
5
83
0
5
0
58
0
1
63
0
2
68
0
3
73
0
4
78
0
end_DTG
begin_DTG
1
1
26
1
4 0
1
0
7
2
16 5
3 0
end_DTG
begin_DTG
1
1
25
1
12 0
1
0
3
2
19 5
11 0
end_DTG
begin_DTG
1
1
24
1
12 0
1
0
2
2
19 4
10 0
end_DTG
begin_DTG
1
1
23
1
4 0
1
0
6
2
16 1
2 0
end_DTG
begin_DTG
1
1
22
1
13 0
1
0
0
2
20 1
14 0
end_DTG
begin_DTG
1
1
21
1
7 0
1
0
4
2
18 4
8 0
end_DTG
begin_DTG
1
1
20
1
0 0
1
0
8
2
15 4
1 0
end_DTG
begin_DTG
1
1
19
1
12 0
1
0
1
2
19 3
9 0
end_DTG
begin_DTG
0
7
0
30
3
25 0
20 4
14 0
0
39
3
28 0
19 4
9 0
0
40
3
23 0
19 4
10 0
0
41
3
22 0
19 4
11 0
0
45
3
26 0
18 4
8 0
0
51
3
24 0
16 4
2 0
0
52
3
21 0
16 4
3 0
end_DTG
begin_DTG
0
7
0
28
3
25 0
20 2
14 0
0
34
3
28 0
19 2
9 0
0
35
3
23 0
19 2
10 0
0
36
3
22 0
19 2
11 0
0
43
3
26 0
18 2
8 0
0
49
3
24 0
16 2
2 0
0
50
3
21 0
16 2
3 0
end_DTG
begin_DTG
0
7
0
27
3
25 0
20 1
14 0
0
31
3
28 0
19 1
9 0
0
32
3
23 0
19 1
10 0
0
33
3
22 0
19 1
11 0
0
42
3
26 0
18 1
8 0
0
47
3
24 0
16 1
2 0
0
48
3
21 0
16 1
3 0
end_DTG
begin_DTG
1
1
18
1
5 0
1
0
5
2
17 2
6 0
end_DTG
begin_DTG
0
6
0
29
3
25 0
20 3
14 0
0
37
3
28 0
19 3
9 0
0
38
3
22 0
19 3
11 0
0
44
3
26 0
18 3
8 0
0
46
3
32 0
17 3
6 0
0
53
3
27 0
15 3
1 0
end_DTG
begin_CG
2
27 1
1 1
3
27 1
33 1
0 1
5
24 1
31 1
30 1
29 1
4 1
5
21 1
31 1
30 1
29 1
4 1
4
24 1
21 1
2 1
3 1
2
32 1
6 1
3
32 1
33 1
5 1
2
26 1
8 1
6
26 1
31 1
30 1
33 1
29 1
7 1
6
28 1
31 1
30 1
33 1
29 1
12 1
5
23 1
31 1
30 1
29 1
12 1
6
22 1
31 1
30 1
33 1
29 1
12 1
6
28 1
23 1
22 1
9 1
10 1
11 1
2
25 1
14 1
6
25 1
31 1
30 1
33 1
29 1
13 1
2
27 1
33 1
5
24 1
21 1
31 2
30 2
29 2
2
32 1
33 1
5
26 1
31 1
30 1
33 1
29 1
7
28 1
23 1
22 1
31 3
30 3
33 2
29 3
5
25 1
31 1
30 1
33 1
29 1
3
31 1
30 1
29 1
4
31 1
30 1
33 1
29 1
3
31 1
30 1
29 1
3
31 1
30 1
29 1
4
31 1
30 1
33 1
29 1
4
31 1
30 1
33 1
29 1
1
33 1
4
31 1
30 1
33 1
29 1
0
0
0
1
33 1
0
end_CG
