begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var13
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var16
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var12
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var15
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var14
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var17
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var11
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var10
-1
4
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
end_variable
begin_variable
var9
-1
4
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
end_variable
begin_variable
var8
-1
4
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var7
-1
2
Atom have_image(dir4, mod1)
NegatedAtom have_image(dir4, mod1)
end_variable
0
begin_state
0
1
0
1
1
1
0
2
2
3
1
1
1
1
1
end_state
begin_goal
3
7 1
9 2
14 0
end_goal
52
begin_operator
calibrate sat1 ins1 dir2
2
9 1
4 0
1
0 13 -1 0
0
end_operator
begin_operator
calibrate sat1 ins4 dir1
2
9 0
5 0
1
0 10 -1 0
0
end_operator
begin_operator
calibrate sat2 ins2 dir4
2
8 3
3 0
1
0 12 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir3
2
7 2
1 0
1
0 11 -1 0
0
end_operator
begin_operator
switch_off ins1 sat1
0
2
0 6 -1 0
0 4 0 1
0
end_operator
begin_operator
switch_off ins2 sat2
0
2
0 2 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins4 sat1
0
2
0 6 -1 0
0 5 0 1
0
end_operator
begin_operator
switch_on ins1 sat1
0
3
0 13 -1 1
0 6 0 1
0 4 -1 0
0
end_operator
begin_operator
switch_on ins2 sat2
0
3
0 12 -1 1
0 2 0 1
0 3 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 11 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins4 sat1
0
3
0 10 -1 1
0 6 0 1
0 5 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins1 mod1
3
13 0
9 3
4 0
1
0 14 -1 0
0
end_operator
begin_operator
take_image sat1 dir4 ins4 mod1
3
10 0
9 3
5 0
1
0 14 -1 0
0
end_operator
begin_operator
take_image sat2 dir4 ins2 mod1
3
12 0
8 3
3 0
1
0 14 -1 0
0
end_operator
begin_operator
take_image sat3 dir4 ins3 mod1
3
11 0
7 3
1 0
1
0 14 -1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
1
0 9 1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
1
0 9 2 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
1
0 9 3 0
0
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
1
0 9 0 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
1
0 9 2 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
1
0 9 3 1
0
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
1
0 9 0 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
1
0 9 1 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
1
0 9 3 2
0
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
1
0 9 0 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
1
0 9 1 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
1
0 9 2 3
0
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
1
0 8 1 0
0
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
1
0 8 2 0
0
end_operator
begin_operator
turn_to sat2 dir1 dir4
0
1
0 8 3 0
0
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
1
0 8 0 1
0
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
1
0 8 2 1
0
end_operator
begin_operator
turn_to sat2 dir2 dir4
0
1
0 8 3 1
0
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
1
0 8 0 2
0
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
1
0 8 1 2
0
end_operator
begin_operator
turn_to sat2 dir3 dir4
0
1
0 8 3 2
0
end_operator
begin_operator
turn_to sat2 dir4 dir1
0
1
0 8 0 3
0
end_operator
begin_operator
turn_to sat2 dir4 dir2
0
1
0 8 1 3
0
end_operator
begin_operator
turn_to sat2 dir4 dir3
0
1
0 8 2 3
0
end_operator
begin_operator
turn_to sat3 dir1 dir2
0
1
0 7 1 0
0
end_operator
begin_operator
turn_to sat3 dir1 dir3
0
1
0 7 2 0
0
end_operator
begin_operator
turn_to sat3 dir1 dir4
0
1
0 7 3 0
0
end_operator
begin_operator
turn_to sat3 dir2 dir1
0
1
0 7 0 1
0
end_operator
begin_operator
turn_to sat3 dir2 dir3
0
1
0 7 2 1
0
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
1
0 7 3 1
0
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
1
0 7 0 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
1
0 7 1 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
1
0 7 3 2
0
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
1
0 7 0 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
1
0 7 1 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
1
0 7 2 3
0
end_operator
0
begin_SG
switch 13
check 0
switch 9
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
12
check 0
check 0
check 0
check 0
switch 12
check 0
switch 8
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
14
check 0
check 0
check 0
check 0
switch 11
check 0
switch 7
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
15
check 0
check 0
check 0
check 0
switch 10
check 0
switch 9
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
13
check 0
check 0
check 0
check 0
switch 9
check 0
switch 8
check 3
19
22
25
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
1
check 0
check 0
switch 8
check 3
16
23
26
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
0
check 0
check 0
check 3
17
20
27
check 3
18
21
24
switch 8
check 0
check 3
31
34
37
check 3
28
35
38
check 3
29
32
39
switch 7
check 3
30
33
36
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
2
check 0
check 0
switch 7
check 0
check 3
43
46
49
check 3
40
47
50
switch 6
check 3
41
44
51
check 0
check 0
switch 1
check 0
check 1
3
check 0
check 0
check 3
42
45
48
switch 6
check 0
check 2
8
11
check 0
switch 2
check 0
check 1
9
check 0
switch 0
check 0
check 1
10
check 0
switch 4
check 0
check 1
4
check 0
switch 3
check 0
check 1
5
check 0
switch 1
check 0
check 1
6
check 0
switch 5
check 0
check 1
7
check 0
check 0
end_SG
begin_DTG
1
1
10
0
1
0
6
1
1 0
end_DTG
begin_DTG
1
1
6
0
1
0
10
1
0 0
end_DTG
begin_DTG
1
1
9
0
1
0
5
1
3 0
end_DTG
begin_DTG
1
1
5
0
1
0
9
1
2 0
end_DTG
begin_DTG
1
1
4
0
1
0
8
1
6 0
end_DTG
begin_DTG
1
1
7
0
1
0
11
1
6 0
end_DTG
begin_DTG
1
1
8
0
2
0
4
1
4 0
0
7
1
5 0
end_DTG
begin_DTG
3
1
43
0
2
46
0
3
49
0
3
0
40
0
2
47
0
3
50
0
3
0
41
0
1
44
0
3
51
0
3
0
42
0
1
45
0
2
48
0
end_DTG
begin_DTG
3
1
31
0
2
34
0
3
37
0
3
0
28
0
2
35
0
3
38
0
3
0
29
0
1
32
0
3
39
0
3
0
30
0
1
33
0
2
36
0
end_DTG
begin_DTG
3
1
19
0
2
22
0
3
25
0
3
0
16
0
2
23
0
3
26
0
3
0
17
0
1
20
0
3
27
0
3
0
18
0
1
21
0
2
24
0
end_DTG
begin_DTG
1
1
11
1
6 0
1
0
1
2
9 0
5 0
end_DTG
begin_DTG
1
1
10
1
0 0
1
0
3
2
7 2
1 0
end_DTG
begin_DTG
1
1
9
1
2 0
1
0
2
2
8 3
3 0
end_DTG
begin_DTG
1
1
8
1
6 0
1
0
0
2
9 1
4 0
end_DTG
begin_DTG
0
4
0
12
3
13 0
9 3
4 0
0
13
3
10 0
9 3
5 0
0
14
3
12 0
8 3
3 0
0
15
3
11 0
7 3
1 0
end_DTG
begin_CG
2
11 1
1 1
3
11 1
14 1
0 1
2
12 1
3 1
3
12 1
14 1
2 1
3
13 1
14 1
6 1
3
10 1
14 1
6 1
4
13 1
10 1
4 1
5 1
2
11 1
14 1
2
12 1
14 1
3
13 1
10 1
14 2
1
14 1
1
14 1
1
14 1
1
14 1
0
end_CG
