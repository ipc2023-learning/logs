begin_version
3
end_version
begin_metric
0
end_metric
38
begin_variable
var70
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var52
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins17)
NegatedAtom calibrated(ins17)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir2, mod3)
NegatedAtom have_image(dir2, mod3)
end_variable
0
begi




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
2
492
0
4
509
0
5
517
0
6
525
0
7
533
0
8
541
0
8
0
477
0
1
485
0
2
493
0
3
501
0
5
518
0
6
526
0
7
534
0
8
542
0
8
0
478
0
1
486
0
2
494
0
3
502
0
4
510
0
6
527
0
7
535
0
8
543
0
8
0
479
0
1
487
0
2
495
0
3
503
0
4
511
0
5
519
0
7
536
0
8
544
0
8
0
480
0
1
488
0
2
496
0
3
504
0
4
512
0
5
520
0
6
528
0
8
545
0
8
0
481
0
1
489
0
2
497
0
3
505
0
4
513
0
5
521
0
6
529
0
7
537
0
end_DTG
begin_DTG
8
1
410
0
2
418
0
3
426
0
4
434
0
5
442
0
6
450
0
7
458
0
8
466
0
8
0
402
0
2
419
0
3
427
0
4
435
0
5
443
0
6
451
0
7
459
0
8
467
0
8
0
403
0
1
411
0
3
428
0
4
436
0
5
444
0
6
452
0
7
460
0
8
468
0
8
0
404
0
1
412
0
2
420
0
4
437
0
5
445
0
6
453
0
7
461
0
8
469
0
8
0
405
0
1
413
0
2
421
0
3
429
0
5
446
0
6
454
0
7
462
0
8
470
0
8
0
406
0
1
414
0
2
422
0
3
430
0
4
438
0
6
455
0
7
463
0
8
471
0
8
0
407
0
1
415
0
2
423
0
3
431
0
4
439
0
5
447
0
7
464
0
8
472
0
8
0
408
0
1
416
0
2
424
0
3
432
0
4
440
0
5
448
0
6
456
0
8
473
0
8
0
409
0
1
417
0
2
425
0
3
433
0
4
441
0
5
449
0
6
457
0
7
465
0
end_DTG
begin_DTG
8
1
338
0
2
346
0
3
354
0
4
362
0
5
370
0
6
378
0
7
386
0
8
394
0
8
0
330
0
2
347
0
3
355
0
4
363
0
5
371
0
6
379
0
7
387
0
8
395
0
8
0
331
0
1
339
0
3
356
0
4
364
0
5
372
0
6
380
0
7
388
0
8
396
0
8
0
332
0
1
340
0
2
348
0
4
365
0
5
373
0
6
381
0
7
389
0
8
397
0
8
0
333
0
1
341
0
2
349
0
3
357
0
5
374
0
6
382
0
7
390
0
8
398
0
8
0
334
0
1
342
0
2
350
0
3
358
0
4
366
0
6
383
0
7
391
0
8
399
0
8
0
335
0
1
343
0
2
351
0
3
359
0
4
367
0
5
375
0
7
392
0
8
400
0
8
0
336
0
1
344
0
2
352
0
3
360
0
4
368
0
5
376
0
6
384
0
8
401
0
8
0
337
0
1
345
0
2
353
0
3
361
0
4
369
0
5
377
0
6
385
0
7
393
0
end_DTG
begin_DTG
8
1
266
0
2
274
0
3
282
0
4
290
0
5
298
0
6
306
0
7
314
0
8
322
0
8
0
258
0
2
275
0
3
283
0
4
291
0
5
299
0
6
307
0
7
315
0
8
323
0
8
0
259
0
1
267
0
3
284
0
4
292
0
5
300
0
6
308
0
7
316
0
8
324
0
8
0
260
0
1
268
0
2
276
0
4
293
0
5
301
0
6
309
0
7
317
0
8
325
0
8
0
261
0
1
269
0
2
277
0
3
285
0
5
302
0
6
310
0
7
318
0
8
326
0
8
0
262
0
1
270
0
2
278
0
3
286
0
4
294
0
6
311
0
7
319
0
8
327
0
8
0
263
0
1
271
0
2
279
0
3
287
0
4
295
0
5
303
0
7
320
0
8
328
0
8
0
264
0
1
272
0
2
280
0
3
288
0
4
296
0
5
304
0
6
312
0
8
329
0
8
0
265
0
1
273
0
2
281
0
3
289
0
4
297
0
5
305
0
6
313
0
7
321
0
end_DTG
begin_DTG
8
1
194
0
2
202
0
3
210
0
4
218
0
5
226
0
6
234
0
7
242
0
8
250
0
8
0
186
0
2
203
0
3
211
0
4
219
0
5
227
0
6
235
0
7
243
0
8
251
0
8
0
187
0
1
195
0
3
212
0
4
220
0
5
228
0
6
236
0
7
244
0
8
252
0
8
0
188
0
1
196
0
2
204
0
4
221
0
5
229
0
6
237
0
7
245
0
8
253
0
8
0
189
0
1
197
0
2
205
0
3
213
0
5
230
0
6
238
0
7
246
0
8
254
0
8
0
190
0
1
198
0
2
206
0
3
214
0
4
222
0
6
239
0
7
247
0
8
255
0
8
0
191
0
1
199
0
2
207
0
3
215
0
4
223
0
5
231
0
7
248
0
8
256
0
8
0
192
0
1
200
0
2
208
0
3
216
0
4
224
0
5
232
0
6
240
0
8
257
0
8
0
193
0
1
201
0
2
209
0
3
217
0
4
225
0
5
233
0
6
241
0
7
249
0
end_DTG
begin_DTG
8
1
122
0
2
130
0
3
138
0
4
146
0
5
154
0
6
162
0
7
170
0
8
178
0
8
0
114
0
2
131
0
3
139
0
4
147
0
5
155
0
6
163
0
7
171
0
8
179
0
8
0
115
0
1
123
0
3
140
0
4
148
0
5
156
0
6
164
0
7
172
0
8
180
0
8
0
116
0
1
124
0
2
132
0
4
149
0
5
157
0
6
165
0
7
173
0
8
181
0
8
0
117
0
1
125
0
2
133
0
3
141
0
5
158
0
6
166
0
7
174
0
8
182
0
8
0
118
0
1
126
0
2
134
0
3
142
0
4
150
0
6
167
0
7
175
0
8
183
0
8
0
119
0
1
127
0
2
135
0
3
143
0
4
151
0
5
159
0
7
176
0
8
184
0
8
0
120
0
1
128
0
2
136
0
3
144
0
4
152
0
5
160
0
6
168
0
8
185
0
8
0
121
0
1
129
0
2
137
0
3
145
0
4
153
0
5
161
0
6
169
0
7
177
0
end_DTG
begin_DTG
8
1
50
0
2
58
0
3
66
0
4
74
0
5
82
0
6
90
0
7
98
0
8
106
0
8
0
42
0
2
59
0
3
67
0
4
75
0
5
83
0
6
91
0
7
99
0
8
107
0
8
0
43
0
1
51
0
3
68
0
4
76
0
5
84
0
6
92
0
7
100
0
8
108
0
8
0
44
0
1
52
0
2
60
0
4
77
0
5
85
0
6
93
0
7
101
0
8
109
0
8
0
45
0
1
53
0
2
61
0
3
69
0
5
86
0
6
94
0
7
102
0
8
110
0
8
0
46
0
1
54
0
2
62
0
3
70
0
4
78
0
6
95
0
7
103
0
8
111
0
8
0
47
0
1
55
0
2
63
0
3
71
0
4
79
0
5
87
0
7
104
0
8
112
0
8
0
48
0
1
56
0
2
64
0
3
72
0
4
80
0
5
88
0
6
96
0
8
113
0
8
0
49
0
1
57
0
2
65
0
3
73
0
4
81
0
5
89
0
6
97
0
7
105
0
end_DTG
begin_DTG
1
1
32
1
13 0
1
0
2
2
25 4
14 0
end_DTG
begin_DTG
1
1
31
1
5 0
1
0
7
2
21 0
4 0
end_DTG
begin_DTG
1
1
30
1
17 0
1
0
0
2
27 2
18 0
end_DTG
begin_DTG
1
1
29
1
8 0
1
0
6
2
22 2
7 0
end_DTG
begin_DTG
1
1
28
1
15 0
1
0
1
2
26 8
16 0
end_DTG
begin_DTG
1
1
26
1
2 0
1
0
8
2
20 3
0 0
end_DTG
begin_DTG
1
1
23
1
12 0
1
0
5
2
23 3
11 0
end_DTG
begin_DTG
1
1
22
1
12 0
1
0
4
2
23 2
10 0
end_DTG
begin_DTG
1
1
21
1
12 0
1
0
3
2
23 5
9 0
end_DTG
begin_DTG
0
9
0
33
3
30 0
27 1
18 0
0
34
3
32 0
26 1
16 0
0
35
3
28 0
25 1
14 0
0
36
3
36 0
23 1
9 0
0
37
3
35 0
23 1
10 0
0
38
3
34 0
23 1
11 0
0
39
3
31 0
22 1
7 0
0
40
3
29 0
21 1
4 0
0
41
3
33 0
20 1
0 0
end_DTG
begin_CG
3
33 1
37 1
2 1
1
2 1
3
33 1
0 1
1 1
1
5 1
3
29 1
37 1
5 1
3
29 1
3 1
4 1
1
8 1
3
31 1
37 1
8 1
3
31 1
6 1
7 1
3
36 1
37 1
12 1
3
35 1
37 1
12 1
3
34 1
37 1
12 1
6
36 1
35 1
34 1
9 1
10 1
11 1
2
28 1
14 1
3
28 1
37 1
13 1
2
32 1
16 1
3
32 1
37 1
15 1
2
30 1
18 1
3
30 1
37 1
17 1
0
2
33 1
37 1
2
29 1
37 1
2
31 1
37 1
4
36 1
35 1
34 1
37 3
0
2
28 1
37 1
2
32 1
37 1
2
30 1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
1
37 1
0
end_CG
