begin_version
3
end_version
begin_metric
0
end_metric
79
begin_variable
var73
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var87
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var68
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var81
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var67
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var85
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var66
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var65
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var64
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var86
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var63
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var84
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var79
-1
2
Atom power_on(ins19)
NegatedAtom power_on(ins19)
end_variable
begin_variable
var62
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins18)
NegatedAtom power_on(ins18)
end_variable
begin_variable
var83
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var61
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var80
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat10)
NegatedAtom power_avail(sat10)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var82
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var58
-1
10
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir10)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var57
-1
10
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir10)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var56
-1
10
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir10)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var55
-1
10
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir10)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var54
-1
10
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir10)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var53
-1
10
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir10)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var52
-1
10
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir10)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var51
-1
10
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir10)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var50
-1
10
Atom pointing(sat10, dir1)
Atom pointing(sat10, dir1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9 0
0
99
3
48 0
36 2
20 0
0
101
3
43 0
36 2
21 0
0
139
3
64 0
35 2
16 0
0
141
3
47 0
35 2
17 0
0
170
3
42 0
34 2
15 0
0
209
3
62 0
31 2
7 0
0
211
3
41 0
31 2
8 0
0
246
3
49 0
30 2
4 0
0
248
3
45 0
30 2
5 0
end_DTG
begin_DTG
0
15
0
59
3
44 0
38 2
28 0
0
73
3
50 0
37 2
24 0
0
74
3
46 0
37 2
25 0
0
97
3
51 0
36 2
19 0
0
100
3
43 0
36 2
21 0
0
138
3
64 0
35 2
16 0
0
140
3
47 0
35 2
17 0
0
184
3
40 0
33 2
13 0
0
198
3
63 0
32 2
11 0
0
208
3
62 0
31 2
7 0
0
210
3
41 0
31 2
8 0
0
244
3
52 0
30 2
3 0
0
245
3
49 0
30 2
4 0
0
247
3
45 0
30 2
5 0
0
282
3
53 0
29 2
0 0
end_DTG
begin_DTG
0
11
0
58
3
44 0
38 1
28 0
0
94
3
51 0
36 1
19 0
0
95
3
48 0
36 1
20 0
0
96
3
43 0
36 1
21 0
0
136
3
64 0
35 1
16 0
0
137
3
47 0
35 1
17 0
0
169
3
42 0
34 1
15 0
0
206
3
62 0
31 1
7 0
0
207
3
41 0
31 1
8 0
0
242
3
49 0
30 1
4 0
0
243
3
45 0
30 1
5 0
end_DTG
begin_DTG
0
15
0
57
3
44 0
38 0
28 0
0
71
3
50 0
37 0
24 0
0
72
3
46 0
37 0
25 0
0
92
3
51 0
36 0
19 0
0
93
3
43 0
36 0
21 0
0
134
3
64 0
35 0
16 0
0
135
3
47 0
35 0
17 0
0
183
3
40 0
33 0
13 0
0
197
3
63 0
32 0
11 0
0
204
3
62 0
31 0
7 0
0
205
3
41 0
31 0
8 0
0
239
3
52 0
30 0
3 0
0
240
3
49 0
30 0
4 0
0
241
3
45 0
30 0
5 0
0
281
3
53 0
29 0
0 0
end_DTG
begin_CG
16
53 1
78 1
76 1
61 1
73 1
60 1
71 1
59 1
58 1
69 1
57 1
67 1
56 1
66 1
55 1
2 1
9
39 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
2 1
4
53 1
39 1
0 1
1 1
9
52 1
78 1
76 1
73 1
71 1
69 1
67 1
66 1
6 1
16
49 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
6 1
23
45 1
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
6 1
6
52 1
49 1
45 1
3 1
4 1
5 1
16
62 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
9 1
23
41 1
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
9 1
4
62 1
41 1
7 1
8 1
2
63 1
11 1
9
63 1
78 1
76 1
73 1
71 1
69 1
67 1
66 1
10 1
2
40 1
13 1
16
40 1
78 1
76 1
61 1
73 1
60 1
71 1
59 1
58 1
69 1
57 1
67 1
56 1
66 1
55 1
12 1
2
42 1
15 1
16
42 1
77 1
75 1
74 1
61 1
72 1
60 1
59 1
70 1
58 1
68 1
57 1
56 1
65 1
55 1
14 1
16
64 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
18 1
23
47 1
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
18 1
4
64 1
47 1
16 1
17 1
16
51 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
22 1
9
48 1
77 1
75 1
74 1
72 1
70 1
68 1
65 1
22 1
23
43 1
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
22 1
6
51 1
48 1
43 1
19 1
20 1
21 1
9
54 1
61 1
60 1
59 1
58 1
57 1
56 1
55 1
26 1
9
50 1
78 1
76 1
73 1
71 1
69 1
67 1
66 1
26 1
9
46 1
78 1
76 1
73 1
71 1
69 1
67 1
66 1
26 1
6
54 1
50 1
46 1
23 1
24 1
25 1
2
44 1
28 1
16
44 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
27 1
16
53 1
39 1
78 1
76 1
61 2
73 1
60 2
71 1
59 2
58 2
69 1
57 2
67 1
56 2
66 1
55 2
24
52 1
49 1
45 1
78 3
77 2
76 3
75 2
74 2
61 1
73 3
72 2
60 1
71 3
59 1
70 2
58 1
69 3
68 2
57 1
67 3
56 1
66 3
65 2
55 1
23
62 1
41 1
78 2
77 2
76 2
75 2
74 2
61 1
73 2
72 2
60 1
71 2
59 1
70 2
58 1
69 2
68 2
57 1
67 2
56 1
66 2
65 2
55 1
8
63 1
78 1
76 1
73 1
71 1
69 1
67 1
66 1
15
40 1
78 1
76 1
61 1
73 1
60 1
71 1
59 1
58 1
69 1
57 1
67 1
56 1
66 1
55 1
15
42 1
77 1
75 1
74 1
61 1
72 1
60 1
59 1
70 1
58 1
68 1
57 1
56 1
65 1
55 1
23
64 1
47 1
78 2
77 2
76 2
75 2
74 2
61 1
73 2
72 2
60 1
71 2
59 1
70 2
58 1
69 2
68 2
57 1
67 2
56 1
66 2
65 2
55 1
24
51 1
48 1
43 1
78 2
77 3
76 2
75 3
74 3
61 1
73 2
72 3
60 1
71 2
59 1
70 3
58 1
69 2
68 3
57 1
67 2
56 1
66 2
65 3
55 1
17
54 1
50 1
46 1
78 2
76 2
61 1
73 2
60 1
71 2
59 1
58 1
69 2
57 1
67 2
56 1
66 2
55 1
15
44 1
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
7
61 1
60 1
59 1
58 1
57 1
56 1
55 1
14
78 1
76 1
61 1
73 1
60 1
71 1
59 1
58 1
69 1
57 1
67 1
56 1
66 1
55 1
21
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
14
77 1
75 1
74 1
61 1
72 1
60 1
59 1
70 1
58 1
68 1
57 1
56 1
65 1
55 1
21
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
14
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
21
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
7
78 1
76 1
73 1
71 1
69 1
67 1
66 1
21
78 1
77 1
76 1
75 1
74 1
61 1
73 1
72 1
60 1
71 1
59 1
70 1
58 1
69 1
68 1
57 1
67 1
56 1
66 1
65 1
55 1
7
77 1
75 1
74 1
72 1
70 1
68 1
65 1
14
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
7
78 1
76 1
73 1
71 1
69 1
67 1
66 1
14
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
7
78 1
76 1
73 1
71 1
69 1
67 1
66 1
14
78 1
76 1
61 1
73 1
60 1
71 1
59 1
58 1
69 1
57 1
67 1
56 1
66 1
55 1
7
61 1
60 1
59 1
58 1
57 1
56 1
55 1
0
0
0
0
0
0
0
14
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
7
78 1
76 1
73 1
71 1
69 1
67 1
66 1
14
78 1
77 1
76 1
75 1
74 1
73 1
72 1
71 1
70 1
69 1
68 1
67 1
66 1
65 1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_CG
