begin_version
3
end_version
begin_metric
0
end_metric
49
begin_variable
var45
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var44
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var43
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var42
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var56
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var37
-1
8
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
end_variable
begin_variable
var36
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAt




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
291
0
3
298
0
5
313
0
6
320
0
7
327
0
7
0
278
0
1
285
0
2
292
0
3
299
0
4
306
0
6
321
0
7
328
0
7
0
279
0
1
286
0
2
293
0
3
300
0
4
307
0
5
314
0
7
329
0
7
0
280
0
1
287
0
2
294
0
3
301
0
4
308
0
5
315
0
6
322
0
end_DTG
begin_DTG
7
1
225
0
2
232
0
3
239
0
4
246
0
5
253
0
6
260
0
7
267
0
7
0
218
0
2
233
0
3
240
0
4
247
0
5
254
0
6
261
0
7
268
0
7
0
219
0
1
226
0
3
241
0
4
248
0
5
255
0
6
262
0
7
269
0
7
0
220
0
1
227
0
2
234
0
4
249
0
5
256
0
6
263
0
7
270
0
7
0
221
0
1
228
0
2
235
0
3
242
0
5
257
0
6
264
0
7
271
0
7
0
222
0
1
229
0
2
236
0
3
243
0
4
250
0
6
265
0
7
272
0
7
0
223
0
1
230
0
2
237
0
3
244
0
4
251
0
5
258
0
7
273
0
7
0
224
0
1
231
0
2
238
0
3
245
0
4
252
0
5
259
0
6
266
0
end_DTG
begin_DTG
7
1
169
0
2
176
0
3
183
0
4
190
0
5
197
0
6
204
0
7
211
0
7
0
162
0
2
177
0
3
184
0
4
191
0
5
198
0
6
205
0
7
212
0
7
0
163
0
1
170
0
3
185
0
4
192
0
5
199
0
6
206
0
7
213
0
7
0
164
0
1
171
0
2
178
0
4
193
0
5
200
0
6
207
0
7
214
0
7
0
165
0
1
172
0
2
179
0
3
186
0
5
201
0
6
208
0
7
215
0
7
0
166
0
1
173
0
2
180
0
3
187
0
4
194
0
6
209
0
7
216
0
7
0
167
0
1
174
0
2
181
0
3
188
0
4
195
0
5
202
0
7
217
0
7
0
168
0
1
175
0
2
182
0
3
189
0
4
196
0
5
203
0
6
210
0
end_DTG
begin_DTG
7
1
113
0
2
120
0
3
127
0
4
134
0
5
141
0
6
148
0
7
155
0
7
0
106
0
2
121
0
3
128
0
4
135
0
5
142
0
6
149
0
7
156
0
7
0
107
0
1
114
0
3
129
0
4
136
0
5
143
0
6
150
0
7
157
0
7
0
108
0
1
115
0
2
122
0
4
137
0
5
144
0
6
151
0
7
158
0
7
0
109
0
1
116
0
2
123
0
3
130
0
5
145
0
6
152
0
7
159
0
7
0
110
0
1
117
0
2
124
0
3
131
0
4
138
0
6
153
0
7
160
0
7
0
111
0
1
118
0
2
125
0
3
132
0
4
139
0
5
146
0
7
161
0
7
0
112
0
1
119
0
2
126
0
3
133
0
4
140
0
5
147
0
6
154
0
end_DTG
begin_DTG
1
1
41
1
14 0
1
0
5
2
26 7
13 0
end_DTG
begin_DTG
1
1
40
1
5 0
1
0
12
2
23 1
4 0
end_DTG
begin_DTG
1
1
39
1
14 0
1
0
4
2
26 2
12 0
end_DTG
begin_DTG
1
1
38
1
19 0
1
0
2
2
28 3
18 0
end_DTG
begin_DTG
1
1
37
1
20 0
1
0
0
2
29 4
21 0
end_DTG
begin_DTG
1
1
36
1
0 0
1
0
13
2
22 1
1 0
end_DTG
begin_DTG
1
1
35
1
8 0
1
0
9
2
24 7
7 0
end_DTG
begin_DTG
1
1
34
1
15 0
1
0
3
2
27 5
16 0
end_DTG
begin_DTG
1
1
33
1
5 0
1
0
11
2
23 3
3 0
end_DTG
begin_DTG
1
1
32
1
5 0
1
0
10
2
23 5
2 0
end_DTG
begin_DTG
1
1
31
1
11 0
1
0
7
2
25 7
10 0
end_DTG
begin_DTG
1
1
30
1
8 0
1
0
8
2
24 3
6 0
end_DTG
begin_DTG
1
1
29
1
19 0
1
0
1
2
28 5
17 0
end_DTG
begin_DTG
1
1
28
1
11 0
1
0
6
2
25 3
9 0
end_DTG
begin_DTG
0
13
0
46
3
34 0
29 4
21 0
0
55
3
42 0
28 4
17 0
0
56
3
33 0
28 4
18 0
0
65
3
32 0
26 4
12 0
0
66
3
30 0
26 4
13 0
0
75
3
43 0
25 4
9 0
0
76
3
40 0
25 4
10 0
0
85
3
41 0
24 4
6 0
0
86
3
36 0
24 4
7 0
0
99
3
39 0
23 4
2 0
0
100
3
38 0
23 4
3 0
0
101
3
31 0
23 4
4 0
0
105
3
35 0
22 4
1 0
end_DTG
begin_DTG
0
13
0
45
3
34 0
29 3
21 0
0
53
3
42 0
28 3
17 0
0
54
3
33 0
28 3
18 0
0
63
3
32 0
26 3
12 0
0
64
3
30 0
26 3
13 0
0
73
3
43 0
25 3
9 0
0
74
3
40 0
25 3
10 0
0
83
3
41 0
24 3
6 0
0
84
3
36 0
24 3
7 0
0
96
3
39 0
23 3
2 0
0
97
3
38 0
23 3
3 0
0
98
3
31 0
23 3
4 0
0
104
3
35 0
22 3
1 0
end_DTG
begin_DTG
0
13
0
44
3
34 0
29 2
21 0
0
51
3
42 0
28 2
17 0
0
52
3
33 0
28 2
18 0
0
61
3
32 0
26 2
12 0
0
62
3
30 0
26 2
13 0
0
71
3
43 0
25 2
9 0
0
72
3
40 0
25 2
10 0
0
81
3
41 0
24 2
6 0
0
82
3
36 0
24 2
7 0
0
93
3
39 0
23 2
2 0
0
94
3
38 0
23 2
3 0
0
95
3
31 0
23 2
4 0
0
103
3
35 0
22 2
1 0
end_DTG
begin_DTG
0
12
0
43
3
34 0
29 1
21 0
0
49
3
42 0
28 1
17 0
0
50
3
33 0
28 1
18 0
0
57
3
37 0
27 1
16 0
0
60
3
30 0
26 1
13 0
0
69
3
43 0
25 1
9 0
0
70
3
40 0
25 1
10 0
0
79
3
41 0
24 1
6 0
0
80
3
36 0
24 1
7 0
0
90
3
39 0
23 1
2 0
0
91
3
38 0
23 1
3 0
0
92
3
31 0
23 1
4 0
end_DTG
begin_DTG
0
13
0
42
3
34 0
29 0
21 0
0
47
3
42 0
28 0
17 0
0
48
3
33 0
28 0
18 0
0
58
3
32 0
26 0
12 0
0
59
3
30 0
26 0
13 0
0
67
3
43 0
25 0
9 0
0
68
3
40 0
25 0
10 0
0
77
3
41 0
24 0
6 0
0
78
3
36 0
24 0
7 0
0
87
3
39 0
23 0
2 0
0
88
3
38 0
23 0
3 0
0
89
3
31 0
23 0
4 0
0
102
3
35 0
22 0
1 0
end_DTG
begin_CG
2
35 1
1 1
6
35 1
48 1
46 1
45 1
44 1
0 1
7
39 1
48 1
47 1
46 1
45 1
44 1
5 1
7
38 1
48 1
47 1
46 1
45 1
44 1
5 1
7
31 1
48 1
47 1
46 1
45 1
44 1
5 1
6
39 1
38 1
31 1
2 1
3 1
4 1
7
41 1
48 1
47 1
46 1
45 1
44 1
8 1
7
36 1
48 1
47 1
46 1
45 1
44 1
8 1
4
41 1
36 1
6 1
7 1
7
43 1
48 1
47 1
46 1
45 1
44 1
11 1
7
40 1
48 1
47 1
46 1
45 1
44 1
11 1
4
43 1
40 1
9 1
10 1
6
32 1
48 1
46 1
45 1
44 1
14 1
7
30 1
48 1
47 1
46 1
45 1
44 1
14 1
4
32 1
30 1
12 1
13 1
2
37 1
16 1
3
37 1
47 1
15 1
7
42 1
48 1
47 1
46 1
45 1
44 1
19 1
7
33 1
48 1
47 1
46 1
45 1
44 1
19 1
4
42 1
33 1
17 1
18 1
2
34 1
21 1
7
34 1
48 1
47 1
46 1
45 1
44 1
20 1
5
35 1
48 1
46 1
45 1
44 1
8
39 1
38 1
31 1
48 3
47 3
46 3
45 3
44 3
7
41 1
36 1
48 2
47 2
46 2
45 2
44 2
7
43 1
40 1
48 2
47 2
46 2
45 2
44 2
7
32 1
30 1
48 2
47 1
46 2
45 2
44 2
2
37 1
47 1
7
42 1
33 1
48 2
47 2
46 2
45 2
44 2
6
34 1
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
4
48 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
4
48 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
1
47 1
5
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
5
48 1
47 1
46 1
45 1
44 1
0
0
0
0
0
end_CG
