begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var39
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var37
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var32
-1
7
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
end_variable
begin_variable
var31
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var19
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var13
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(dir1, mod2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var20
-1
2
Atom have_image(dir5, mod1)
NegatedAtom have_image(dir5, mod1)
end_variable
0
begin_state
0
1
0
1
0
1
1
1
0
1
1
0
1
1
1
0
1
1
0
4
0
5
1
2
1
3
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
19 3
20 4
21 1
23 3
24 1
37 0
38 0
40 0
end_goal
359
begin_operator
calibrate sat1 ins1 dir7
2
25 6
16 0
1
0 39 -1 0
0
end_operator
begin_operator
calibrate sat1 ins11 dir6
2
25 5
17 0
1
0 35 -1 0
0
end_operator
begin_operator
calibrate sat2 ins10 dir1
2
24 0
12 0
1
0 36 -1 0
0
end_operator
begin_operator
calibrate sat2 ins6 dir6
2




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





1
0
31
1
8 0
end_DTG
begin_DTG
1
1
27
0
2
0
15
1
6 0
0
19
1
7 0
end_DTG
begin_DTG
1
1
16
0
1
0
28
1
11 0
end_DTG
begin_DTG
1
1
23
0
1
0
35
1
11 0
end_DTG
begin_DTG
1
1
28
0
2
0
16
1
9 0
0
23
1
10 0
end_DTG
begin_DTG
1
1
13
0
1
0
25
1
15 0
end_DTG
begin_DTG
1
1
20
0
1
0
32
1
15 0
end_DTG
begin_DTG
1
1
22
0
1
0
34
1
15 0
end_DTG
begin_DTG
1
1
25
0
3
0
13
1
12 0
0
20
1
13 0
0
22
1
14 0
end_DTG
begin_DTG
1
1
12
0
1
0
24
1
18 0
end_DTG
begin_DTG
1
1
14
0
1
0
26
1
18 0
end_DTG
begin_DTG
1
1
24
0
2
0
12
1
16 0
0
14
1
17 0
end_DTG
begin_DTG
6
1
323
0
2
329
0
3
335
0
4
341
0
5
347
0
6
353
0
6
0
317
0
2
330
0
3
336
0
4
342
0
5
348
0
6
354
0
6
0
318
0
1
324
0
3
337
0
4
343
0
5
349
0
6
355
0
6
0
319
0
1
325
0
2
331
0
4
344
0
5
350
0
6
356
0
6
0
320
0
1
326
0
2
332
0
3
338
0
5
351
0
6
357
0
6
0
321
0
1
327
0
2
333
0
3
339
0
4
345
0
6
358
0
6
0
322
0
1
328
0
2
334
0
3
340
0
4
346
0
5
352
0
end_DTG
begin_DTG
6
1
281
0
2
287
0
3
293
0
4
299
0
5
305
0
6
311
0
6
0
275
0
2
288
0
3
294
0
4
300
0
5
306
0
6
312
0
6
0
276
0
1
282
0
3
295
0
4
301
0
5
307
0
6
313
0
6
0
277
0
1
283
0
2
289
0
4
302
0
5
308
0
6
314
0
6
0
278
0
1
284
0
2
290
0
3
296
0
5
309
0
6
315
0
6
0
279
0
1
285
0
2
291
0
3
297
0
4
303
0
6
316
0
6
0
280
0
1
286
0
2
292
0
3
298
0
4
304
0
5
310
0
end_DTG
begin_DTG
6
1
239
0
2
245
0
3
251
0
4
257
0
5
263
0
6
269
0
6
0
233
0
2
246
0
3
252
0
4
258
0
5
264
0
6
270
0
6
0
234
0
1
240
0
3
253
0
4
259
0
5
265
0
6
271
0
6
0
235
0
1
241
0
2
247
0
4
260
0
5
266
0
6
272
0
6
0
236
0
1
242
0
2
248
0
3
254
0
5
267
0
6
273
0
6
0
237
0
1
243
0
2
249
0
3
255
0
4
261
0
6
274
0
6
0
238
0
1
244
0
2
250
0
3
256
0
4
262
0
5
268
0
end_DTG
begin_DTG
6
1
197
0
2
203
0
3
209
0
4
215
0
5
221
0
6
227
0
6
0
191
0
2
204
0
3
210
0
4
216
0
5
222
0
6
228
0
6
0
192
0
1
198
0
3
211
0
4
217
0
5
223
0
6
229
0
6
0
193
0
1
199
0
2
205
0
4
218
0
5
224
0
6
230
0
6
0
194
0
1
200
0
2
206
0
3
212
0
5
225
0
6
231
0
6
0
195
0
1
201
0
2
207
0
3
213
0
4
219
0
6
232
0
6
0
196
0
1
202
0
2
208
0
3
214
0
4
220
0
5
226
0
end_DTG
begin_DTG
6
1
155
0
2
161
0
3
167
0
4
173
0
5
179
0
6
185
0
6
0
149
0
2
162
0
3
168
0
4
174
0
5
180
0
6
186
0
6
0
150
0
1
156
0
3
169
0
4
175
0
5
181
0
6
187
0
6
0
151
0
1
157
0
2
163
0
4
176
0
5
182
0
6
188
0
6
0
152
0
1
158
0
2
164
0
3
170
0
5
183
0
6
189
0
6
0
153
0
1
159
0
2
165
0
3
171
0
4
177
0
6
190
0
6
0
154
0
1
160
0
2
166
0
3
172
0
4
178
0
5
184
0
end_DTG
begin_DTG
6
1
113
0
2
119
0
3
125
0
4
131
0
5
137
0
6
143
0
6
0
107
0
2
120
0
3
126
0
4
132
0
5
138
0
6
144
0
6
0
108
0
1
114
0
3
127
0
4
133
0
5
139
0
6
145
0
6
0
109
0
1
115
0
2
121
0
4
134
0
5
140
0
6
146
0
6
0
110
0
1
116
0
2
122
0
3
128
0
5
141
0
6
147
0
6
0
111
0
1
117
0
2
123
0
3
129
0
4
135
0
6
148
0
6
0
112
0
1
118
0
2
124
0
3
130
0
4
136
0
5
142
0
end_DTG
begin_DTG
6
1
71
0
2
77
0
3
83
0
4
89
0
5
95
0
6
101
0
6
0
65
0
2
78
0
3
84
0
4
90
0
5
96
0
6
102
0
6
0
66
0
1
72
0
3
85
0
4
91
0
5
97
0
6
103
0
6
0
67
0
1
73
0
2
79
0
4
92
0
5
98
0
6
104
0
6
0
68
0
1
74
0
2
80
0
3
86
0
5
99
0
6
105
0
6
0
69
0
1
75
0
2
81
0
3
87
0
4
93
0
6
106
0
6
0
70
0
1
76
0
2
82
0
3
88
0
4
94
0
5
100
0
end_DTG
begin_DTG
1
1
35
1
11 0
1
0
6
2
23 1
10 0
end_DTG
begin_DTG
1
1
34
1
15 0
1
0
4
2
24 1
14 0
end_DTG
begin_DTG
1
1
33
1
4 0
1
0
9
2
21 3
5 0
end_DTG
begin_DTG
1
1
32
1
15 0
1
0
3
2
24 5
13 0
end_DTG
begin_DTG
1
1
31
1
8 0
1
0
8
2
22 2
7 0
end_DTG
begin_DTG
1
1
30
1
0 0
1
0
11
2
19 6
1 0
end_DTG
begin_DTG
1
1
29
1
2 0
1
0
10
2
20 0
3 0
end_DTG
begin_DTG
1
1
28
1
11 0
1
0
5
2
23 5
9 0
end_DTG
begin_DTG
1
1
27
1
8 0
1
0
7
2
22 1
6 0
end_DTG
begin_DTG
1
1
26
1
18 0
1
0
1
2
25 5
17 0
end_DTG
begin_DTG
1
1
25
1
15 0
1
0
2
2
24 0
12 0
end_DTG
begin_DTG
0
10
0
37
3
35 0
25 3
17 0
0
43
3
36 0
24 3
12 0
0
44
3
29 0
24 3
13 0
0
45
3
27 0
24 3
14 0
0
49
3
33 0
23 3
9 0
0
50
3
26 0
23 3
10 0
0
55
3
34 0
22 3
6 0
0
56
3
30 0
22 3
7 0
0
60
3
28 0
21 3
5 0
0
63
3
32 0
20 3
3 0
end_DTG
begin_DTG
0
10
0
36
3
35 0
25 0
17 0
0
40
3
36 0
24 0
12 0
0
41
3
29 0
24 0
13 0
0
42
3
27 0
24 0
14 0
0
47
3
33 0
23 0
9 0
0
48
3
26 0
23 0
10 0
0
53
3
34 0
22 0
6 0
0
54
3
30 0
22 0
7 0
0
59
3
28 0
21 0
5 0
0
62
3
32 0
20 0
3 0
end_DTG
begin_DTG
1
1
24
1
18 0
1
0
0
2
25 6
16 0
end_DTG
begin_DTG
0
9
0
38
3
39 0
25 4
16 0
0
39
3
35 0
25 4
17 0
0
46
3
36 0
24 4
12 0
0
51
3
33 0
23 4
9 0
0
52
3
26 0
23 4
10 0
0
57
3
34 0
22 4
6 0
0
58
3
30 0
22 4
7 0
0
61
3
28 0
21 4
5 0
0
64
3
31 0
19 4
1 0
end_DTG
begin_CG
2
31 1
1 1
3
31 1
40 1
0 1
2
32 1
3 1
4
32 1
38 1
37 1
2 1
2
28 1
5 1
5
28 1
38 1
37 1
40 1
4 1
5
34 1
38 1
37 1
40 1
8 1
5
30 1
38 1
37 1
40 1
8 1
4
34 1
30 1
6 1
7 1
5
33 1
38 1
37 1
40 1
11 1
5
26 1
38 1
37 1
40 1
11 1
4
33 1
26 1
9 1
10 1
5
36 1
38 1
37 1
40 1
15 1
4
29 1
38 1
37 1
15 1
4
27 1
38 1
37 1
15 1
6
36 1
29 1
27 1
12 1
13 1
14 1
3
39 1
40 1
18 1
5
35 1
38 1
37 1
40 1
18 1
4
39 1
35 1
16 1
17 1
2
31 1
40 1
3
32 1
38 1
37 1
4
28 1
38 1
37 1
40 1
5
34 1
30 1
38 2
37 2
40 2
5
33 1
26 1
38 2
37 2
40 2
6
36 1
29 1
27 1
38 3
37 3
40 1
5
39 1
35 1
38 1
37 1
40 2
3
38 1
37 1
40 1
2
38 1
37 1
3
38 1
37 1
40 1
2
38 1
37 1
3
38 1
37 1
40 1
1
40 1
2
38 1
37 1
3
38 1
37 1
40 1
3
38 1
37 1
40 1
3
38 1
37 1
40 1
3
38 1
37 1
40 1
0
0
1
40 1
0
end_CG
