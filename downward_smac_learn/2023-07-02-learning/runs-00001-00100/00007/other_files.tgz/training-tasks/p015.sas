begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var13
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var16
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var14
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var17
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var12
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var11
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var15
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var10
-1
4
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
end_variable
begin_variable
var9
-1
4
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
end_variable
begin_variable
var8
-1
4
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var6
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
begin_variable
var5
-1
2
Atom have_image(dir2, mod1)
NegatedAtom have_image(dir2, mod1)
end_variable
0
begin_state
0
1
1
1
0
0
1
2
1
2
1
1
1
1
1
1
end_state
begin_goal
4
7 3
8 0
14 0
15 0
end_goal
56
begin_operator
calibrate sat1 ins2 dir4
2
9 3
6 0
1
0 12 -1 0
0
end_operator
begin_operator
calibrate sat2 ins1 dir2
2
8 1
2 0
1
0 13 -1 0
0
end_operator
begin_operator
calibrate sat2 ins4 dir2
2
8 1
3 0
1
0 10 -1 0
0
end_operator
begin_operator
calibrate sat3 ins3 dir2
2
7 1
1 0
1
0 11 -1 0
0
end_operator
begin_operator
switch_off ins1 sat2
0
2
0 4 -1 0
0 2 0 1
0
end_operator
begin_operator
switch_off ins2 sat1
0
2
0 5 -1 0
0 6 0 1
0
end_operator
begin_operator
switch_off ins3 sat3
0
2
0 0 -1 0
0 1 0 1
0
end_operator
begin_operator
switch_off ins4 sat2
0
2
0 4 -1 0
0 3 0 1
0
end_operator
begin_operator
switch_on ins1 sat2
0
3
0 13 -1 1
0 4 0 1
0 2 -1 0
0
end_operator
begin_operator
switch_on ins2 sat1
0
3
0 12 -1 1
0 5 0 1
0 6 -1 0
0
end_operator
begin_operator
switch_on ins3 sat3
0
3
0 11 -1 1
0 0 0 1
0 1 -1 0
0
end_operator
begin_operator
switch_on ins4 sat2
0
3
0 10 -1 1
0 4 0 1
0 3 -1 0
0
end_operator
begin_operator
take_image sat1 dir2 ins2 mod1
3
12 0
9 1
6 0
1
0 15 -1 0
0
end_operator
begin_operator
take_image sat1 dir3 ins2 mod1
3
12 0
9 2
6 0
1
0 14 -1 0
0
end_operator
begin_operator
take_image sat2 dir2 ins1 mod1
3
13 0
8 1
2 0
1
0 15 -1 0
0
end_operator
begin_operator
take_image sat2 dir2 ins4 mod1
3
10 0
8 1
3 0
1
0 15 -1 0
0
end_operator
begin_operator
take_image sat2 dir3 ins1 mod1
3
13 0
8 2
2 0
1
0 14 -1 0
0
end_operator
begin_operator
take_image sat2 dir3 ins4 mod1
3
10 0
8 2
3 0
1
0 14 -1 0
0
end_operator
begin_operator
take_image sat3 dir2 ins3 mod1
3
11 0
7 1
1 0
1
0 15 -1 0
0
end_operator
begin_operator
take_image sat3 dir3 ins3 mod1
3
11 0
7 2
1 0
1
0 14 -1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
1
0 9 1 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
1
0 9 2 0
0
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
1
0 9 3 0
0
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
1
0 9 0 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
1
0 9 2 1
0
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
1
0 9 3 1
0
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
1
0 9 0 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
1
0 9 1 2
0
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
1
0 9 3 2
0
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
1
0 9 0 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
1
0 9 1 3
0
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
1
0 9 2 3
0
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
1
0 8 1 0
0
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
1
0 8 2 0
0
end_operator
begin_operator
turn_to sat2 dir1 dir4
0
1
0 8 3 0
0
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
1
0 8 0 1
0
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
1
0 8 2 1
0
end_operator
begin_operator
turn_to sat2 dir2 dir4
0
1
0 8 3 1
0
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
1
0 8 0 2
0
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
1
0 8 1 2
0
end_operator
begin_operator
turn_to sat2 dir3 dir4
0
1
0 8 3 2
0
end_operator
begin_operator
turn_to sat2 dir4 dir1
0
1
0 8 0 3
0
end_operator
begin_operator
turn_to sat2 dir4 dir2
0
1
0 8 1 3
0
end_operator
begin_operator
turn_to sat2 dir4 dir3
0
1
0 8 2 3
0
end_operator
begin_operator
turn_to sat3 dir1 dir2
0
1
0 7 1 0
0
end_operator
begin_operator
turn_to sat3 dir1 dir3
0
1
0 7 2 0
0
end_operator
begin_operator
turn_to sat3 dir1 dir4
0
1
0 7 3 0
0
end_operator
begin_operator
turn_to sat3 dir2 dir1
0
1
0 7 0 1
0
end_operator
begin_operator
turn_to sat3 dir2 dir3
0
1
0 7 2 1
0
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
1
0 7 3 1
0
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
1
0 7 0 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
1
0 7 1 2
0
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
1
0 7 3 2
0
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
1
0 7 0 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
1
0 7 1 3
0
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
1
0 7 2 3
0
end_operator
0
begin_SG
switch 13
check 0
switch 8
check 0
check 0
switch 2
check 0
check 1
14
check 0
check 0
switch 2
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
switch 9
check 0
check 0
switch 6
check 0
check 1
12
check 0
check 0
switch 6
check 0
check 1
13
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
switch 7
check 0
check 0
switch 1
check 0
check 1
18
check 0
check 0
switch 1
check 0
check 1
19
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
switch 8
check 0
check 0
switch 3
check 0
check 1
15
check 0
check 0
switch 3
check 0
check 1
17
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 3
23
26
29
check 3
20
27
30
check 3
21
24
31
switch 8
check 3
22
25
28
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
0
check 0
check 0
switch 8
check 0
check 3
35
38
41
switch 7
check 3
32
39
42
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
1
check 0
switch 3
check 0
check 1
2
check 0
check 0
check 3
33
36
43
check 3
34
37
40
switch 7
check 0
check 3
47
50
53
switch 5
check 3
44
51
54
check 0
check 0
switch 1
check 0
check 1
3
check 0
check 0
check 3
45
48
55
check 3
46
49
52
switch 5
check 0
check 1
9
check 0
switch 4
check 0
check 2
8
11
check 0
switch 0
check 0
check 1
10
check 0
switch 2
check 0
check 1
4
check 0
switch 6
check 0
check 1
5
check 0
switch 1
check 0
check 1
6
check 0
switch 3
check 0
check 1
7
check 0
check 0
end_SG
begin_DTG
1
1
10
0
1
0
6
1
1 0
end_DTG
begin_DTG
1
1
6
0
1
0
10
1
0 0
end_DTG
begin_DTG
1
1
4
0
1
0
8
1
4 0
end_DTG
begin_DTG
1
1
7
0
1
0
11
1
4 0
end_DTG
begin_DTG
1
1
8
0
2
0
4
1
2 0
0
7
1
3 0
end_DTG
begin_DTG
1
1
9
0
1
0
5
1
6 0
end_DTG
begin_DTG
1
1
5
0
1
0
9
1
5 0
end_DTG
begin_DTG
3
1
47
0
2
50
0
3
53
0
3
0
44
0
2
51
0
3
54
0
3
0
45
0
1
48
0
3
55
0
3
0
46
0
1
49
0
2
52
0
end_DTG
begin_DTG
3
1
35
0
2
38
0
3
41
0
3
0
32
0
2
39
0
3
42
0
3
0
33
0
1
36
0
3
43
0
3
0
34
0
1
37
0
2
40
0
end_DTG
begin_DTG
3
1
23
0
2
26
0
3
29
0
3
0
20
0
2
27
0
3
30
0
3
0
21
0
1
24
0
3
31
0
3
0
22
0
1
25
0
2
28
0
end_DTG
begin_DTG
1
1
11
1
4 0
1
0
2
2
8 1
3 0
end_DTG
begin_DTG
1
1
10
1
0 0
1
0
3
2
7 1
1 0
end_DTG
begin_DTG
1
1
9
1
5 0
1
0
0
2
9 3
6 0
end_DTG
begin_DTG
1
1
8
1
4 0
1
0
1
2
8 1
2 0
end_DTG
begin_DTG
0
4
0
13
3
12 0
9 2
6 0
0
16
3
13 0
8 2
2 0
0
17
3
10 0
8 2
3 0
0
19
3
11 0
7 2
1 0
end_DTG
begin_DTG
0
4
0
12
3
12 0
9 1
6 0
0
14
3
13 0
8 1
2 0
0
15
3
10 0
8 1
3 0
0
18
3
11 0
7 1
1 0
end_DTG
begin_CG
2
11 1
1 1
4
11 1
15 1
14 1
0 1
4
13 1
15 1
14 1
4 1
4
10 1
15 1
14 1
4 1
4
13 1
10 1
2 1
3 1
2
12 1
6 1
4
12 1
15 1
14 1
5 1
3
11 1
15 1
14 1
4
13 1
10 1
15 2
14 2
3
12 1
15 1
14 1
2
15 1
14 1
2
15 1
14 1
2
15 1
14 1
2
15 1
14 1
0
0
end_CG
