begin_version
3
end_version
begin_metric
0
end_metric
51
begin_variable
var47
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var52
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var42
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var48
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var54
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var41
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var40
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var53
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var39
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var50
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var38
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var37
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var51
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var49
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var35
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var34
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var33
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var32
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var31
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var30
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var29
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var11
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins12)
NegatedAtom calibrated(ins12)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var28
-1
2
Atom have_image(dir8, mod2)
NegatedAtom have_image(dir8, mod2)
end_variable
begin_variable
var26
-1
2
Atom have_image(dir7, mod2)
NegatedAtom have_image(dir7, mod2)
end_variable
begin_variable
var24
-1
2
Atom have_image(dir6, mod2)
NegatedAtom have_image(dir6, mod2)
end_variable
begin_variable
var22
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_image(dir5, mod2)
end_variable
begin_variable
var14
-1
2
Atom have_image(dir1, mod2)
NegatedAtom have_image(




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
7
0
150
0
1
157
0
2
164
0
3
171
0
4
178
0
5
185
0
6
192
0
end_DTG
begin_DTG
1
1
38
1
15 0
1
0
4
2
24 5
14 0
end_DTG
begin_DTG
1
1
37
1
6 0
1
0
10
2
21 6
5 0
end_DTG
begin_DTG
1
1
36
1
11 0
1
0
6
2
23 0
10 0
end_DTG
begin_DTG
1
1
35
1
2 0
1
0
12
2
20 6
1 0
end_DTG
begin_DTG
1
1
34
1
16 0
1
0
1
2
25 0
17 0
end_DTG
begin_DTG
1
1
33
1
15 0
1
0
3
2
24 4
13 0
end_DTG
begin_DTG
1
1
32
1
18 0
1
0
0
2
26 6
19 0
end_DTG
begin_DTG
1
1
31
1
6 0
1
0
9
2
21 4
4 0
end_DTG
begin_DTG
1
1
30
1
2 0
1
0
11
2
20 0
0 0
end_DTG
begin_DTG
1
1
29
1
15 0
1
0
2
2
24 3
12 0
end_DTG
begin_DTG
1
1
28
1
6 0
1
0
8
2
21 5
3 0
end_DTG
begin_DTG
1
1
27
1
11 0
1
0
5
2
23 7
9 0
end_DTG
begin_DTG
0
9
0
49
3
33 0
26 7
19 0
0
60
3
31 0
25 7
17 0
0
87
3
36 0
24 7
12 0
0
88
3
32 0
24 7
13 0
0
105
3
38 0
23 7
9 0
0
130
3
37 0
21 7
3 0
0
131
3
34 0
21 7
4 0
0
132
3
28 0
21 7
5 0
0
143
3
35 0
20 7
0 0
end_DTG
begin_DTG
0
9
0
48
3
33 0
26 6
19 0
0
59
3
31 0
25 6
17 0
0
83
3
36 0
24 6
12 0
0
85
3
32 0
24 6
13 0
0
103
3
38 0
23 6
9 0
0
126
3
37 0
21 6
3 0
0
127
3
34 0
21 6
4 0
0
129
3
28 0
21 6
5 0
0
141
3
35 0
20 6
0 0
end_DTG
begin_DTG
0
9
0
46
3
33 0
26 5
19 0
0
57
3
31 0
25 5
17 0
0
80
3
36 0
24 5
12 0
0
81
3
32 0
24 5
13 0
0
101
3
38 0
23 5
9 0
0
123
3
37 0
21 5
3 0
0
124
3
34 0
21 5
4 0
0
125
3
28 0
21 5
5 0
0
140
3
35 0
20 5
0 0
end_DTG
begin_DTG
0
9
0
45
3
33 0
26 4
19 0
0
56
3
31 0
25 4
17 0
0
76
3
36 0
24 4
12 0
0
78
3
32 0
24 4
13 0
0
99
3
38 0
23 4
9 0
0
119
3
37 0
21 4
3 0
0
120
3
34 0
21 4
4 0
0
122
3
28 0
21 4
5 0
0
138
3
35 0
20 4
0 0
end_DTG
begin_DTG
0
9
0
40
3
33 0
26 0
19 0
0
51
3
31 0
25 0
17 0
0
62
3
36 0
24 0
12 0
0
64
3
32 0
24 0
13 0
0
90
3
38 0
23 0
9 0
0
112
3
37 0
21 0
3 0
0
113
3
34 0
21 0
4 0
0
115
3
28 0
21 0
5 0
0
133
3
35 0
20 0
0 0
end_DTG
begin_DTG
1
1
26
1
7 0
1
0
7
2
22 5
8 0
end_DTG
begin_DTG
0
10
0
47
3
33 0
26 6
19 0
0
58
3
31 0
25 6
17 0
0
82
3
36 0
24 6
12 0
0
84
3
32 0
24 6
13 0
0
86
3
27 0
24 6
14 0
0
102
3
38 0
23 6
9 0
0
104
3
29 0
23 6
10 0
0
111
3
44 0
22 6
8 0
0
128
3
28 0
21 6
5 0
0
142
3
30 0
20 6
1 0
end_DTG
begin_DTG
0
10
0
44
3
33 0
26 4
19 0
0
55
3
31 0
25 4
17 0
0
75
3
36 0
24 4
12 0
0
77
3
32 0
24 4
13 0
0
79
3
27 0
24 4
14 0
0
98
3
38 0
23 4
9 0
0
100
3
29 0
23 4
10 0
0
110
3
44 0
22 4
8 0
0
121
3
28 0
21 4
5 0
0
139
3
30 0
20 4
1 0
end_DTG
begin_DTG
0
10
0
43
3
33 0
26 3
19 0
0
54
3
31 0
25 3
17 0
0
72
3
36 0
24 3
12 0
0
73
3
32 0
24 3
13 0
0
74
3
27 0
24 3
14 0
0
96
3
38 0
23 3
9 0
0
97
3
29 0
23 3
10 0
0
109
3
44 0
22 3
8 0
0
118
3
28 0
21 3
5 0
0
137
3
30 0
20 3
1 0
end_DTG
begin_DTG
0
10
0
42
3
33 0
26 2
19 0
0
53
3
31 0
25 2
17 0
0
69
3
36 0
24 2
12 0
0
70
3
32 0
24 2
13 0
0
71
3
27 0
24 2
14 0
0
94
3
38 0
23 2
9 0
0
95
3
29 0
23 2
10 0
0
108
3
44 0
22 2
8 0
0
117
3
28 0
21 2
5 0
0
136
3
30 0
20 2
1 0
end_DTG
begin_DTG
0
10
0
41
3
33 0
26 1
19 0
0
52
3
31 0
25 1
17 0
0
66
3
36 0
24 1
12 0
0
67
3
32 0
24 1
13 0
0
68
3
27 0
24 1
14 0
0
92
3
38 0
23 1
9 0
0
93
3
29 0
23 1
10 0
0
107
3
44 0
22 1
8 0
0
116
3
28 0
21 1
5 0
0
135
3
30 0
20 1
1 0
end_DTG
begin_DTG
0
10
0
39
3
33 0
26 0
19 0
0
50
3
31 0
25 0
17 0
0
61
3
36 0
24 0
12 0
0
63
3
32 0
24 0
13 0
0
65
3
27 0
24 0
14 0
0
89
3
38 0
23 0
9 0
0
91
3
29 0
23 0
10 0
0
106
3
44 0
22 0
8 0
0
114
3
28 0
21 0
5 0
0
134
3
30 0
20 0
1 0
end_DTG
begin_CG
7
35 1
43 1
42 1
41 1
40 1
39 1
2 1
8
30 1
50 1
49 1
48 1
47 1
46 1
45 1
2 1
4
35 1
30 1
0 1
1 1
7
37 1
43 1
42 1
41 1
40 1
39 1
6 1
7
34 1
43 1
42 1
41 1
40 1
39 1
6 1
13
28 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
6 1
6
37 1
34 1
28 1
3 1
4 1
5 1
2
44 1
8 1
8
44 1
50 1
49 1
48 1
47 1
46 1
45 1
7 1
13
38 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
11 1
8
29 1
50 1
49 1
48 1
47 1
46 1
45 1
11 1
4
38 1
29 1
9 1
10 1
13
36 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
15 1
13
32 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
15 1
8
27 1
50 1
49 1
48 1
47 1
46 1
45 1
15 1
6
36 1
32 1
27 1
12 1
13 1
14 1
2
31 1
17 1
13
31 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
16 1
2
33 1
19 1
13
33 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
18 1
13
35 1
30 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
14
37 1
34 1
28 1
50 1
43 3
49 1
48 1
47 1
46 1
42 3
41 3
45 1
40 3
39 3
7
44 1
50 1
49 1
48 1
47 1
46 1
45 1
13
38 1
29 1
50 2
43 1
49 2
48 2
47 2
46 2
42 1
41 1
45 2
40 1
39 1
14
36 1
32 1
27 1
50 3
43 2
49 3
48 3
47 3
46 3
42 2
41 2
45 3
40 2
39 2
12
31 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
12
33 1
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
6
50 1
49 1
48 1
47 1
46 1
45 1
11
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
6
50 1
49 1
48 1
47 1
46 1
45 1
6
50 1
49 1
48 1
47 1
46 1
45 1
11
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
11
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
11
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
5
43 1
42 1
41 1
40 1
39 1
5
43 1
42 1
41 1
40 1
39 1
11
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
5
43 1
42 1
41 1
40 1
39 1
11
50 1
43 1
49 1
48 1
47 1
46 1
42 1
41 1
45 1
40 1
39 1
0
0
0
0
0
6
50 1
49 1
48 1
47 1
46 1
45 1
0
0
0
0
0
0
end_CG
