begin_version
3
end_version
begin_metric
0
end_metric
37
begin_variable
var38
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var41
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var36
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var43
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var45
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var35
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var40
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var46
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var47
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var34
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var39
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var44
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var33
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var32
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var42
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var31
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var37
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var30
-1
7
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
end_variable
begin_variable
var29
-1
7
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
end_variable
begin_variable
var28
-1
7
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
end_variable
begin_variable
var27
-1
7
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
end_variable
begin_variable
var26
-1
7
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
end_variable
begin_variable
var25
-1
7
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var7
-1
2
Atom calibrated(ins6)
NegatedAtom calibrated(ins6)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var3
-1
2
Atom calibrated(ins2)
NegatedAtom calibrated(ins2)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var24
-1
2
Atom have_image(dir7, mod2)
NegatedAtom have_image(dir7, mod2)
end_variable
begin_variable
var18
-1
2
Atom have_image(dir4, mod2)
NegatedAtom have_image(dir4, mod2)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var0
-1
2
Atom calibrated(ins1)
NegatedAtom calibrated(ins1)
end_variable
begin_variable
var15
-1
2
Atom have_image(dir3, mod1)
NegatedAtom have_image(dir3, mod1)
end_variable
0
begin_state
1
1
0
1
1
0
1
1
1
0
1
1
0
0
1
0
1
0
3
0
6
2
5
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
8
18 1
19 3
20 4
21 5
22 2
32 0
33 0
36 0
end_goal
308
begin_operator
calibrate sat1 ins1 dir5
2
22 4
16 0
1
0 35 -1 0
0
end_operator
begin_operator
calibrate sat2 ins4 dir7
2
21 6
14 0
1
0 28 -1 0
0
end_operator
begin_operator
calibrate sat3 ins11 dir6
2
20 5
10 0
1
0 31 -1 0
0
end_operator
begin_operator
calibrate sat3 ins6 dir4
2
20 3
11 0
1
0 26 -1 0
0
end_operator
begin_operator
calibrate sat4 ins2 dir6
2
19 5
6 0
1
0 30 -1 0
0
end_operator
begin_operator
calibrate sat4 ins8 dir7
2
19 6
7 0
1
0 24 -1 0
0
end_operator
begin_operator
calibrate sat4 ins9 dir5
2
19 4
8 0
1
0 23 -1 0
0
end_operator
begin_operator
calibrate sat5 ins5 dir2
2
18 1
3 0
1
0 27 -1 0
0
end_operator
begin_operator
calibrate sat5 ins7 dir4
2
18 3
4 0
1
0 25 -1 0
0
end_operator
begin_operator
calibrate sat6 ins10 dir7
2
17 6
0 0
1
0 34 -1 0
0
end_oper




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




28
30
check 0
switch 2
check 0
check 2
23
26
check 0
switch 16
check 0
check 1
11
check 0
switch 0
check 0
check 1
12
check 0
switch 10
check 0
check 1
13
check 0
switch 6
check 0
check 1
14
check 0
switch 1
check 0
check 1
15
check 0
switch 14
check 0
check 1
16
check 0
switch 3
check 0
check 1
17
check 0
switch 11
check 0
check 1
18
check 0
switch 4
check 0
check 1
19
check 0
switch 7
check 0
check 1
20
check 0
switch 8
check 0
check 1
21
check 0
check 0
end_SG
begin_DTG
1
1
12
0
1
0
23
1
2 0
end_DTG
begin_DTG
1
1
15
0
1
0
26
1
2 0
end_DTG
begin_DTG
1
1
23
0
2
0
12
1
0 0
0
15
1
1 0
end_DTG
begin_DTG
1
1
17
0
1
0
28
1
5 0
end_DTG
begin_DTG
1
1
19
0
1
0
30
1
5 0
end_DTG
begin_DTG
1
1
28
0
2
0
17
1
3 0
0
19
1
4 0
end_DTG
begin_DTG
1
1
14
0
1
0
25
1
9 0
end_DTG
begin_DTG
1
1
20
0
1
0
31
1
9 0
end_DTG
begin_DTG
1
1
21
0
1
0
32
1
9 0
end_DTG
begin_DTG
1
1
25
0
3
0
14
1
6 0
0
20
1
7 0
0
21
1
8 0
end_DTG
begin_DTG
1
1
13
0
1
0
24
1
12 0
end_DTG
begin_DTG
1
1
18
0
1
0
29
1
12 0
end_DTG
begin_DTG
1
1
24
0
2
0
13
1
10 0
0
18
1
11 0
end_DTG
begin_DTG
1
1
27
0
1
0
16
1
14 0
end_DTG
begin_DTG
1
1
16
0
1
0
27
1
13 0
end_DTG
begin_DTG
1
1
22
0
1
0
11
1
16 0
end_DTG
begin_DTG
1
1
11
0
1
0
22
1
15 0
end_DTG
begin_DTG
6
1
272
0
2
278
0
3
284
0
4
290
0
5
296
0
6
302
0
6
0
266
0
2
279
0
3
285
0
4
291
0
5
297
0
6
303
0
6
0
267
0
1
273
0
3
286
0
4
292
0
5
298
0
6
304
0
6
0
268
0
1
274
0
2
280
0
4
293
0
5
299
0
6
305
0
6
0
269
0
1
275
0
2
281
0
3
287
0
5
300
0
6
306
0
6
0
270
0
1
276
0
2
282
0
3
288
0
4
294
0
6
307
0
6
0
271
0
1
277
0
2
283
0
3
289
0
4
295
0
5
301
0
end_DTG
begin_DTG
6
1
230
0
2
236
0
3
242
0
4
248
0
5
254
0
6
260
0
6
0
224
0
2
237
0
3
243
0
4
249
0
5
255
0
6
261
0
6
0
225
0
1
231
0
3
244
0
4
250
0
5
256
0
6
262
0
6
0
226
0
1
232
0
2
238
0
4
251
0
5
257
0
6
263
0
6
0
227
0
1
233
0
2
239
0
3
245
0
5
258
0
6
264
0
6
0
228
0
1
234
0
2
240
0
3
246
0
4
252
0
6
265
0
6
0
229
0
1
235
0
2
241
0
3
247
0
4
253
0
5
259
0
end_DTG
begin_DTG
6
1
188
0
2
194
0
3
200
0
4
206
0
5
212
0
6
218
0
6
0
182
0
2
195
0
3
201
0
4
207
0
5
213
0
6
219
0
6
0
183
0
1
189
0
3
202
0
4
208
0
5
214
0
6
220
0
6
0
184
0
1
190
0
2
196
0
4
209
0
5
215
0
6
221
0
6
0
185
0
1
191
0
2
197
0
3
203
0
5
216
0
6
222
0
6
0
186
0
1
192
0
2
198
0
3
204
0
4
210
0
6
223
0
6
0
187
0
1
193
0
2
199
0
3
205
0
4
211
0
5
217
0
end_DTG
begin_DTG
6
1
146
0
2
152
0
3
158
0
4
164
0
5
170
0
6
176
0
6
0
140
0
2
153
0
3
159
0
4
165
0
5
171
0
6
177
0
6
0
141
0
1
147
0
3
160
0
4
166
0
5
172
0
6
178
0
6
0
142
0
1
148
0
2
154
0
4
167
0
5
173
0
6
179
0
6
0
143
0
1
149
0
2
155
0
3
161
0
5
174
0
6
180
0
6
0
144
0
1
150
0
2
156
0
3
162
0
4
168
0
6
181
0
6
0
145
0
1
151
0
2
157
0
3
163
0
4
169
0
5
175
0
end_DTG
begin_DTG
6
1
104
0
2
110
0
3
116
0
4
122
0
5
128
0
6
134
0
6
0
98
0
2
111
0
3
117
0
4
123
0
5
129
0
6
135
0
6
0
99
0
1
105
0
3
118
0
4
124
0
5
130
0
6
136
0
6
0
100
0
1
106
0
2
112
0
4
125
0
5
131
0
6
137
0
6
0
101
0
1
107
0
2
113
0
3
119
0
5
132
0
6
138
0
6
0
102
0
1
108
0
2
114
0
3
120
0
4
126
0
6
139
0
6
0
103
0
1
109
0
2
115
0
3
121
0
4
127
0
5
133
0
end_DTG
begin_DTG
6
1
62
0
2
68
0
3
74
0
4
80
0
5
86
0
6
92
0
6
0
56
0
2
69
0
3
75
0
4
81
0
5
87
0
6
93
0
6
0
57
0
1
63
0
3
76
0
4
82
0
5
88
0
6
94
0
6
0
58
0
1
64
0
2
70
0
4
83
0
5
89
0
6
95
0
6
0
59
0
1
65
0
2
71
0
3
77
0
5
90
0
6
96
0
6
0
60
0
1
66
0
2
72
0
3
78
0
4
84
0
6
97
0
6
0
61
0
1
67
0
2
73
0
3
79
0
4
85
0
5
91
0
end_DTG
begin_DTG
1
1
32
1
9 0
1
0
6
2
19 4
8 0
end_DTG
begin_DTG
1
1
31
1
9 0
1
0
5
2
19 6
7 0
end_DTG
begin_DTG
1
1
30
1
5 0
1
0
8
2
18 3
4 0
end_DTG
begin_DTG
1
1
29
1
12 0
1
0
3
2
20 3
11 0
end_DTG
begin_DTG
1
1
28
1
5 0
1
0
7
2
18 1
3 0
end_DTG
begin_DTG
1
1
27
1
13 0
1
0
1
2
21 6
14 0
end_DTG
begin_DTG
1
1
26
1
2 0
1
0
10
2
17 2
1 0
end_DTG
begin_DTG
1
1
25
1
9 0
1
0
4
2
19 5
6 0
end_DTG
begin_DTG
1
1
24
1
12 0
1
0
2
2
20 5
10 0
end_DTG
begin_DTG
0
7
0
39
3
31 0
20 6
10 0
0
40
3
26 0
20 6
11 0
0
45
3
30 0
19 6
6 0
0
46
3
23 0
19 6
8 0
0
51
3
27 0
18 6
3 0
0
52
3
25 0
18 6
4 0
0
55
3
29 0
17 6
1 0
end_DTG
begin_DTG
0
7
0
37
3
31 0
20 3
10 0
0
38
3
26 0
20 3
11 0
0
43
3
30 0
19 3
6 0
0
44
3
23 0
19 3
8 0
0
49
3
27 0
18 3
3 0
0
50
3
25 0
18 3
4 0
0
54
3
29 0
17 3
1 0
end_DTG
begin_DTG
1
1
23
1
2 0
1
0
9
2
17 6
0 0
end_DTG
begin_DTG
1
1
22
1
15 0
1
0
0
2
22 4
16 0
end_DTG
begin_DTG
0
9
0
33
3
35 0
22 2
16 0
0
34
3
28 0
21 2
14 0
0
35
3
31 0
20 2
10 0
0
36
3
26 0
20 2
11 0
0
41
3
30 0
19 2
6 0
0
42
3
24 0
19 2
7 0
0
47
3
27 0
18 2
3 0
0
48
3
25 0
18 2
4 0
0
53
3
34 0
17 2
0 0
end_DTG
begin_CG
3
34 1
36 1
2 1
4
29 1
33 1
32 1
2 1
4
34 1
29 1
0 1
1 1
5
27 1
36 1
33 1
32 1
5 1
5
25 1
36 1
33 1
32 1
5 1
4
27 1
25 1
3 1
4 1
5
30 1
36 1
33 1
32 1
9 1
3
24 1
36 1
9 1
4
23 1
33 1
32 1
9 1
6
30 1
24 1
23 1
6 1
7 1
8 1
5
31 1
36 1
33 1
32 1
12 1
5
26 1
36 1
33 1
32 1
12 1
4
31 1
26 1
10 1
11 1
2
28 1
14 1
3
28 1
36 1
13 1
2
35 1
16 1
3
35 1
36 1
15 1
5
34 1
29 1
36 1
33 1
32 1
5
27 1
25 1
36 2
33 2
32 2
6
30 1
24 1
23 1
36 2
33 2
32 2
5
31 1
26 1
36 2
33 2
32 2
2
28 1
36 1
2
35 1
36 1
2
33 1
32 1
1
36 1
3
36 1
33 1
32 1
3
36 1
33 1
32 1
3
36 1
33 1
32 1
1
36 1
2
33 1
32 1
3
36 1
33 1
32 1
3
36 1
33 1
32 1
0
0
1
36 1
1
36 1
0
end_CG
