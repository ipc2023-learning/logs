begin_version
3
end_version
begin_metric
0
end_metric
69
begin_variable
var61
-1
2
Atom power_avail(sat9)
NegatedAtom power_avail(sat9)
end_variable
begin_variable
var77
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var60
-1
2
Atom power_avail(sat8)
NegatedAtom power_avail(sat8)
end_variable
begin_variable
var62
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var59
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var73
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var70
-1
2
Atom power_on(ins17)
NegatedAtom power_on(ins17)
end_variable
begin_variable
var75
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var58
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var57
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var74
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins16)
NegatedAtom power_on(ins16)
end_variable
begin_variable
var76
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var56
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var78
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var55
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var72
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var54
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var71
-1
2
Atom power_on(ins2)
NegatedAtom power_on(ins2)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var52
-1
9
Atom pointing(sat9, dir1)
Atom pointing(sat9, dir2)
Atom pointing(sat9, dir3)
Atom pointing(sat9, dir4)
Atom pointing(sat9, dir5)
Atom pointing(sat9, dir6)
Atom pointing(sat9, dir7)
Atom pointing(sat9, dir8)
Atom pointing(sat9, dir9)
end_variable
begin_variable
var51
-1
9
Atom pointing(sat8, dir1)
Atom pointing(sat8, dir2)
Atom pointing(sat8, dir3)
Atom pointing(sat8, dir4)
Atom pointing(sat8, dir5)
Atom pointing(sat8, dir6)
Atom pointing(sat8, dir7)
Atom pointing(sat8, dir8)
Atom pointing(sat8, dir9)
end_variable
begin_variable
var50
-1
9
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
Atom pointing(sat7, dir9)
end_variable
begin_variable
var49
-1
9
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
Atom pointing(sat6, dir9)
end_variable
begin_variable
var48
-1
9
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
Atom pointing(sat5, dir9)
end_variable
begin_variable
var47
-1
9
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
Atom pointing(sat4, dir9)
end_variable
begin_variable
var46
-1
9
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
Atom pointing(sat3, dir9)
end_variable
begin_variable
var45
-1
9
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
Atom pointing(sat2, dir9)
end_variable
begin_variable
var44
-1
9
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
Atom pointing(sat1, dir9)
end_variable
begin_variable
var16
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var15
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var13
-1
2
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




18 0
0
120
3
47 0
33 4
19 0
0
123
3
41 0
33 4
20 0
0
152
3
50 0
32 4
15 0
0
154
3
35 0
32 4
16 0
0
174
3
44 0
31 4
12 0
0
195
3
39 0
30 4
11 0
0
220
3
49 0
29 4
6 0
0
223
3
43 0
29 4
7 0
0
242
3
40 0
28 4
5 0
0
252
3
58 0
27 4
3 0
0
259
3
36 0
26 4
1 0
end_DTG
begin_DTG
0
11
0
69
3
45 0
34 3
23 0
0
71
3
42 0
34 3
24 0
0
114
3
47 0
33 3
19 0
0
116
3
41 0
33 3
20 0
0
150
3
50 0
32 3
15 0
0
171
3
44 0
31 3
12 0
0
193
3
39 0
30 3
11 0
0
216
3
49 0
29 3
6 0
0
218
3
38 0
29 3
8 0
0
241
3
40 0
28 3
5 0
0
251
3
58 0
27 3
3 0
end_DTG
begin_DTG
0
11
0
61
3
45 0
34 1
23 0
0
63
3
42 0
34 1
24 0
0
106
3
47 0
33 1
19 0
0
108
3
41 0
33 1
20 0
0
146
3
50 0
32 1
15 0
0
167
3
44 0
31 1
12 0
0
190
3
39 0
30 1
11 0
0
210
3
49 0
29 1
6 0
0
212
3
38 0
29 1
8 0
0
240
3
40 0
28 1
5 0
0
250
3
58 0
27 1
3 0
end_DTG
begin_DTG
0
15
0
59
3
46 0
34 1
22 0
0
60
3
45 0
34 1
23 0
0
62
3
42 0
34 1
24 0
0
104
3
48 0
33 1
18 0
0
105
3
47 0
33 1
19 0
0
107
3
41 0
33 1
20 0
0
145
3
50 0
32 1
15 0
0
147
3
35 0
32 1
16 0
0
166
3
44 0
31 1
12 0
0
189
3
39 0
30 1
11 0
0
209
3
49 0
29 1
6 0
0
211
3
43 0
29 1
7 0
0
239
3
40 0
28 1
5 0
0
249
3
58 0
27 1
3 0
0
258
3
36 0
26 1
1 0
end_DTG
begin_DTG
0
11
0
55
3
45 0
34 0
23 0
0
58
3
42 0
34 0
24 0
0
100
3
47 0
33 0
19 0
0
103
3
41 0
33 0
20 0
0
143
3
50 0
32 0
15 0
0
164
3
44 0
31 0
12 0
0
188
3
39 0
30 0
11 0
0
205
3
49 0
29 0
6 0
0
208
3
38 0
29 0
8 0
0
238
3
40 0
28 0
5 0
0
248
3
58 0
27 0
3 0
end_DTG
begin_DTG
0
15
0
52
3
46 0
34 0
22 0
0
54
3
45 0
34 0
23 0
0
57
3
42 0
34 0
24 0
0
97
3
48 0
33 0
18 0
0
99
3
47 0
33 0
19 0
0
102
3
41 0
33 0
20 0
0
142
3
50 0
32 0
15 0
0
144
3
35 0
32 0
16 0
0
163
3
44 0
31 0
12 0
0
187
3
39 0
30 0
11 0
0
204
3
49 0
29 0
6 0
0
207
3
43 0
29 0
7 0
0
237
3
40 0
28 0
5 0
0
247
3
58 0
27 0
3 0
0
257
3
36 0
26 0
1 0
end_DTG
begin_CG
2
36 1
1 1
6
36 1
68 1
66 1
63 1
60 1
0 1
2
58 1
3 1
12
58 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
2 1
2
40 1
5 1
12
40 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
4 1
19
49 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
9 1
13
43 1
57 1
68 1
66 1
56 1
55 1
54 1
63 1
53 1
52 1
51 1
60 1
9 1
8
38 1
67 1
65 1
64 1
62 1
61 1
59 1
9 1
6
49 1
43 1
38 1
6 1
7 1
8 1
2
39 1
11 1
19
39 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
10 1
19
44 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
14 1
9
37 1
57 1
56 1
55 1
54 1
53 1
52 1
51 1
14 1
4
44 1
37 1
12 1
13 1
19
50 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
17 1
6
35 1
68 1
66 1
63 1
60 1
17 1
4
50 1
35 1
15 1
16 1
13
48 1
57 1
68 1
66 1
56 1
55 1
54 1
63 1
53 1
52 1
51 1
60 1
21 1
19
47 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
21 1
19
41 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
21 1
6
48 1
47 1
41 1
18 1
19 1
20 1
13
46 1
57 1
68 1
66 1
56 1
55 1
54 1
63 1
53 1
52 1
51 1
60 1
25 1
19
45 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
25 1
19
42 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
25 1
6
46 1
45 1
42 1
22 1
23 1
24 1
5
36 1
68 1
66 1
63 1
60 1
11
58 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
11
40 1
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
20
49 1
43 1
38 1
57 2
68 2
67 2
66 2
65 2
56 2
55 2
64 2
54 2
63 2
62 2
53 2
61 2
52 2
51 2
60 2
59 2
18
39 1
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
19
44 1
37 1
57 2
68 1
67 1
66 1
65 1
56 2
55 2
64 1
54 2
63 1
62 1
53 2
61 1
52 2
51 2
60 1
59 1
19
50 1
35 1
57 1
68 2
67 1
66 2
65 1
56 1
55 1
64 1
54 1
63 2
62 1
53 1
61 1
52 1
51 1
60 2
59 1
20
48 1
47 1
41 1
57 3
68 3
67 2
66 3
65 2
56 3
55 3
64 2
54 3
63 3
62 2
53 3
61 2
52 3
51 3
60 3
59 2
20
46 1
45 1
42 1
57 3
68 3
67 2
66 3
65 2
56 3
55 3
64 2
54 3
63 3
62 2
53 3
61 2
52 3
51 3
60 3
59 2
4
68 1
66 1
63 1
60 1
4
68 1
66 1
63 1
60 1
7
57 1
56 1
55 1
54 1
53 1
52 1
51 1
6
67 1
65 1
64 1
62 1
61 1
59 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
10
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
11
57 1
68 1
66 1
56 1
55 1
54 1
63 1
53 1
52 1
51 1
60 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
11
57 1
68 1
66 1
56 1
55 1
54 1
63 1
53 1
52 1
51 1
60 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
11
57 1
68 1
66 1
56 1
55 1
54 1
63 1
53 1
52 1
51 1
60 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
17
57 1
68 1
67 1
66 1
65 1
56 1
55 1
64 1
54 1
63 1
62 1
53 1
61 1
52 1
51 1
60 1
59 1
0
0
0
0
0
0
0
10
68 1
67 1
66 1
65 1
64 1
63 1
62 1
61 1
60 1
59 1
0
0
0
0
0
0
0
0
0
0
end_CG
