begin_version
3
end_version
begin_metric
0
end_metric
45
begin_variable
var61
-1
2
Atom power_on(ins15)
NegatedAtom power_on(ins15)
end_variable
begin_variable
var66
-1
2
Atom power_on(ins6)
NegatedAtom power_on(ins6)
end_variable
begin_variable
var53
-1
2
Atom power_avail(sat7)
NegatedAtom power_avail(sat7)
end_variable
begin_variable
var52
-1
2
Atom power_avail(sat6)
NegatedAtom power_avail(sat6)
end_variable
begin_variable
var63
-1
2
Atom power_on(ins3)
NegatedAtom power_on(ins3)
end_variable
begin_variable
var60
-1
2
Atom power_on(ins14)
NegatedAtom power_on(ins14)
end_variable
begin_variable
var65
-1
2
Atom power_on(ins5)
NegatedAtom power_on(ins5)
end_variable
begin_variable
var51
-1
2
Atom power_avail(sat5)
NegatedAtom power_avail(sat5)
end_variable
begin_variable
var50
-1
2
Atom power_avail(sat4)
NegatedAtom power_avail(sat4)
end_variable
begin_variable
var67
-1
2
Atom power_on(ins7)
NegatedAtom power_on(ins7)
end_variable
begin_variable
var55
-1
2
Atom power_on(ins1)
NegatedAtom power_on(ins1)
end_variable
begin_variable
var59
-1
2
Atom power_on(ins13)
NegatedAtom power_on(ins13)
end_variable
begin_variable
var49
-1
2
Atom power_avail(sat3)
NegatedAtom power_avail(sat3)
end_variable
begin_variable
var56
-1
2
Atom power_on(ins10)
NegatedAtom power_on(ins10)
end_variable
begin_variable
var58
-1
2
Atom power_on(ins12)
NegatedAtom power_on(ins12)
end_variable
begin_variable
var64
-1
2
Atom power_on(ins4)
NegatedAtom power_on(ins4)
end_variable
begin_variable
var48
-1
2
Atom power_avail(sat2)
NegatedAtom power_avail(sat2)
end_variable
begin_variable
var57
-1
2
Atom power_on(ins11)
NegatedAtom power_on(ins11)
end_variable
begin_variable
var68
-1
2
Atom power_on(ins8)
NegatedAtom power_on(ins8)
end_variable
begin_variable
var69
-1
2
Atom power_on(ins9)
NegatedAtom power_on(ins9)
end_variable
begin_variable
var47
-1
2
Atom power_avail(sat1)
NegatedAtom power_avail(sat1)
end_variable
begin_variable
var45
-1
8
Atom pointing(sat7, dir1)
Atom pointing(sat7, dir2)
Atom pointing(sat7, dir3)
Atom pointing(sat7, dir4)
Atom pointing(sat7, dir5)
Atom pointing(sat7, dir6)
Atom pointing(sat7, dir7)
Atom pointing(sat7, dir8)
end_variable
begin_variable
var44
-1
8
Atom pointing(sat6, dir1)
Atom pointing(sat6, dir2)
Atom pointing(sat6, dir3)
Atom pointing(sat6, dir4)
Atom pointing(sat6, dir5)
Atom pointing(sat6, dir6)
Atom pointing(sat6, dir7)
Atom pointing(sat6, dir8)
end_variable
begin_variable
var43
-1
8
Atom pointing(sat5, dir1)
Atom pointing(sat5, dir2)
Atom pointing(sat5, dir3)
Atom pointing(sat5, dir4)
Atom pointing(sat5, dir5)
Atom pointing(sat5, dir6)
Atom pointing(sat5, dir7)
Atom pointing(sat5, dir8)
end_variable
begin_variable
var42
-1
8
Atom pointing(sat4, dir1)
Atom pointing(sat4, dir2)
Atom pointing(sat4, dir3)
Atom pointing(sat4, dir4)
Atom pointing(sat4, dir5)
Atom pointing(sat4, dir6)
Atom pointing(sat4, dir7)
Atom pointing(sat4, dir8)
end_variable
begin_variable
var41
-1
8
Atom pointing(sat3, dir1)
Atom pointing(sat3, dir2)
Atom pointing(sat3, dir3)
Atom pointing(sat3, dir4)
Atom pointing(sat3, dir5)
Atom pointing(sat3, dir6)
Atom pointing(sat3, dir7)
Atom pointing(sat3, dir8)
end_variable
begin_variable
var40
-1
8
Atom pointing(sat2, dir1)
Atom pointing(sat2, dir2)
Atom pointing(sat2, dir3)
Atom pointing(sat2, dir4)
Atom pointing(sat2, dir5)
Atom pointing(sat2, dir6)
Atom pointing(sat2, dir7)
Atom pointing(sat2, dir8)
end_variable
begin_variable
var39
-1
8
Atom pointing(sat1, dir1)
Atom pointing(sat1, dir2)
Atom pointing(sat1, dir3)
Atom pointing(sat1, dir4)
Atom pointing(sat1, dir5)
Atom pointing(sat1, dir6)
Atom pointing(sat1, dir7)
Atom pointing(sat1, dir8)
end_variable
begin_variable
var14
-1
2
Atom calibrated(ins9)
NegatedAtom calibrated(ins9)
end_variable
begin_variable
var13
-1
2
Atom calibrated(ins8)
NegatedAtom calibrated(ins8)
end_variable
begin_variable
var12
-1
2
Atom calibrated(ins7)
NegatedAtom calibrated(ins7)
end_variable
begin_variable
var10
-1
2
Atom calibrated(ins5)
NegatedAtom calibrated(ins5)
end_variable
begin_variable
var9
-1
2
Atom calibrated(ins4)
NegatedAtom calibrated(ins4)
end_variable
begin_variable
var8
-1
2
Atom calibrated(ins3)
NegatedAtom calibrated(ins3)
end_variable
begin_variable
var6
-1
2
Atom calibrated(ins15)
NegatedAtom calibrated(ins15)
end_variable
begin_variable
var5
-1
2
Atom calibrated(ins14)
NegatedAtom calibrated(ins14)
end_variable
begin_variable
var4
-1
2
Atom calibrated(ins13)
NegatedAtom calibrated(ins13)
end_variable
begin_variable
var2
-1
2
Atom calibrated(ins11)
NegatedAtom calibrated(ins11)
end_variable
begin_variable
var38
-1
2
Atom have_image(dir8, mod3)
NegatedAtom have_image(dir8, mod3)
end_variable
begin_variable
var23
-1
2
Atom have_image(dir3, mod3)
NegatedAtom have_image(dir3, mod3)
end_variable
begin_variable
var20
-1
2
Atom have_image(dir2, mod3)
NegatedAtom have_image(dir2, mod3)
end_variable
begin_variable
var1
-1
2
Atom calibrated(ins10)
NegatedAtom calibrated(ins10)
end_variable
begin_variable
var34
-1
2
Atom have_image(dir7, mod2)
NegatedAtom have_image(dir7, mod2)
end_variable
begin_variable
var28
-1
2
Atom have_image(dir5, mod2)
NegatedAtom have_im




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
5
351
0
6
358
0
7
365
0
7
0
316
0
1
323
0
2
330
0
4
345
0
5
352
0
6
359
0
7
366
0
7
0
317
0
1
324
0
2
331
0
3
338
0
5
353
0
6
360
0
7
367
0
7
0
318
0
1
325
0
2
332
0
3
339
0
4
346
0
6
361
0
7
368
0
7
0
319
0
1
326
0
2
333
0
3
340
0
4
347
0
5
354
0
7
369
0
7
0
320
0
1
327
0
2
334
0
3
341
0
4
348
0
5
355
0
6
362
0
end_DTG
begin_DTG
7
1
265
0
2
272
0
3
279
0
4
286
0
5
293
0
6
300
0
7
307
0
7
0
258
0
2
273
0
3
280
0
4
287
0
5
294
0
6
301
0
7
308
0
7
0
259
0
1
266
0
3
281
0
4
288
0
5
295
0
6
302
0
7
309
0
7
0
260
0
1
267
0
2
274
0
4
289
0
5
296
0
6
303
0
7
310
0
7
0
261
0
1
268
0
2
275
0
3
282
0
5
297
0
6
304
0
7
311
0
7
0
262
0
1
269
0
2
276
0
3
283
0
4
290
0
6
305
0
7
312
0
7
0
263
0
1
270
0
2
277
0
3
284
0
4
291
0
5
298
0
7
313
0
7
0
264
0
1
271
0
2
278
0
3
285
0
4
292
0
5
299
0
6
306
0
end_DTG
begin_DTG
7
1
209
0
2
216
0
3
223
0
4
230
0
5
237
0
6
244
0
7
251
0
7
0
202
0
2
217
0
3
224
0
4
231
0
5
238
0
6
245
0
7
252
0
7
0
203
0
1
210
0
3
225
0
4
232
0
5
239
0
6
246
0
7
253
0
7
0
204
0
1
211
0
2
218
0
4
233
0
5
240
0
6
247
0
7
254
0
7
0
205
0
1
212
0
2
219
0
3
226
0
5
241
0
6
248
0
7
255
0
7
0
206
0
1
213
0
2
220
0
3
227
0
4
234
0
6
249
0
7
256
0
7
0
207
0
1
214
0
2
221
0
3
228
0
4
235
0
5
242
0
7
257
0
7
0
208
0
1
215
0
2
222
0
3
229
0
4
236
0
5
243
0
6
250
0
end_DTG
begin_DTG
7
1
153
0
2
160
0
3
167
0
4
174
0
5
181
0
6
188
0
7
195
0
7
0
146
0
2
161
0
3
168
0
4
175
0
5
182
0
6
189
0
7
196
0
7
0
147
0
1
154
0
3
169
0
4
176
0
5
183
0
6
190
0
7
197
0
7
0
148
0
1
155
0
2
162
0
4
177
0
5
184
0
6
191
0
7
198
0
7
0
149
0
1
156
0
2
163
0
3
170
0
5
185
0
6
192
0
7
199
0
7
0
150
0
1
157
0
2
164
0
3
171
0
4
178
0
6
193
0
7
200
0
7
0
151
0
1
158
0
2
165
0
3
172
0
4
179
0
5
186
0
7
201
0
7
0
152
0
1
159
0
2
166
0
3
173
0
4
180
0
5
187
0
6
194
0
end_DTG
begin_DTG
7
1
97
0
2
104
0
3
111
0
4
118
0
5
125
0
6
132
0
7
139
0
7
0
90
0
2
105
0
3
112
0
4
119
0
5
126
0
6
133
0
7
140
0
7
0
91
0
1
98
0
3
113
0
4
120
0
5
127
0
6
134
0
7
141
0
7
0
92
0
1
99
0
2
106
0
4
121
0
5
128
0
6
135
0
7
142
0
7
0
93
0
1
100
0
2
107
0
3
114
0
5
129
0
6
136
0
7
143
0
7
0
94
0
1
101
0
2
108
0
3
115
0
4
122
0
6
137
0
7
144
0
7
0
95
0
1
102
0
2
109
0
3
116
0
4
123
0
5
130
0
7
145
0
7
0
96
0
1
103
0
2
110
0
3
117
0
4
124
0
5
131
0
6
138
0
end_DTG
begin_DTG
1
1
38
1
20 0
1
0
2
2
27 3
19 0
end_DTG
begin_DTG
1
1
37
1
20 0
1
0
1
2
27 0
18 0
end_DTG
begin_DTG
1
1
36
1
8 0
1
0
6
2
24 5
9 0
end_DTG
begin_DTG
1
1
34
1
7 0
1
0
8
2
23 1
6 0
end_DTG
begin_DTG
1
1
33
1
16 0
1
0
4
2
26 1
15 0
end_DTG
begin_DTG
1
1
32
1
3 0
1
0
9
2
22 2
4 0
end_DTG
begin_DTG
1
1
31
1
2 0
1
0
10
2
21 6
0 0
end_DTG
begin_DTG
1
1
30
1
7 0
1
0
7
2
23 4
5 0
end_DTG
begin_DTG
1
1
29
1
12 0
1
0
5
2
25 2
11 0
end_DTG
begin_DTG
1
1
27
1
20 0
1
0
0
2
27 6
17 0
end_DTG
begin_DTG
0
8
0
51
3
37 0
27 7
17 0
0
52
3
29 0
27 7
18 0
0
53
3
28 0
27 7
19 0
0
62
3
32 0
26 7
15 0
0
68
3
36 0
25 7
11 0
0
74
3
30 0
24 7
9 0
0
80
3
35 0
23 7
5 0
0
89
3
34 0
21 7
0 0
end_DTG
begin_DTG
0
8
0
44
3
37 0
27 2
17 0
0
45
3
29 0
27 2
18 0
0
46
3
28 0
27 2
19 0
0
57
3
32 0
26 2
15 0
0
65
3
36 0
25 2
11 0
0
71
3
30 0
24 2
9 0
0
77
3
35 0
23 2
5 0
0
86
3
34 0
21 2
0 0
end_DTG
begin_DTG
0
8
0
40
3
37 0
27 1
17 0
0
41
3
29 0
27 1
18 0
0
43
3
28 0
27 1
19 0
0
56
3
32 0
26 1
15 0
0
64
3
36 0
25 1
11 0
0
70
3
30 0
24 1
9 0
0
75
3
35 0
23 1
5 0
0
85
3
34 0
21 1
0 0
end_DTG
begin_DTG
1
1
26
1
16 0
1
0
3
2
26 4
13 0
end_DTG
begin_DTG
0
9
0
49
3
37 0
27 6
17 0
0
50
3
28 0
27 6
19 0
0
60
3
41 0
26 6
13 0
0
61
3
32 0
26 6
15 0
0
67
3
36 0
25 6
11 0
0
73
3
30 0
24 6
9 0
0
79
3
31 0
23 6
6 0
0
83
3
33 0
22 6
4 0
0
88
3
34 0
21 6
0 0
end_DTG
begin_DTG
0
9
0
47
3
37 0
27 4
17 0
0
48
3
28 0
27 4
19 0
0
58
3
41 0
26 4
13 0
0
59
3
32 0
26 4
15 0
0
66
3
36 0
25 4
11 0
0
72
3
30 0
24 4
9 0
0
78
3
31 0
23 4
6 0
0
82
3
33 0
22 4
4 0
0
87
3
34 0
21 4
0 0
end_DTG
begin_DTG
0
9
0
39
3
37 0
27 1
17 0
0
42
3
28 0
27 1
19 0
0
54
3
41 0
26 1
13 0
0
55
3
32 0
26 1
15 0
0
63
3
36 0
25 1
11 0
0
69
3
30 0
24 1
9 0
0
76
3
31 0
23 1
6 0
0
81
3
33 0
22 1
4 0
0
84
3
34 0
21 1
0 0
end_DTG
begin_CG
8
34 1
44 1
40 1
39 1
43 1
42 1
38 1
2 1
1
2 1
3
34 1
0 1
1 1
2
33 1
4 1
5
33 1
44 1
43 1
42 1
3 1
5
35 1
40 1
39 1
38 1
7 1
5
31 1
44 1
43 1
42 1
7 1
4
35 1
31 1
5 1
6 1
2
30 1
9 1
8
30 1
44 1
40 1
39 1
43 1
42 1
38 1
8 1
1
12 1
8
36 1
44 1
40 1
39 1
43 1
42 1
38 1
12 1
3
36 1
10 1
11 1
5
41 1
44 1
43 1
42 1
16 1
1
16 1
8
32 1
44 1
40 1
39 1
43 1
42 1
38 1
16 1
5
41 1
32 1
13 1
14 1
15 1
8
37 1
44 1
40 1
39 1
43 1
42 1
38 1
20 1
5
29 1
40 1
39 1
38 1
20 1
8
28 1
44 1
40 1
39 1
43 1
42 1
38 1
20 1
6
37 1
29 1
28 1
17 1
18 1
19 1
7
34 1
44 1
40 1
39 1
43 1
42 1
38 1
4
33 1
44 1
43 1
42 1
8
35 1
31 1
44 1
40 1
39 1
43 1
42 1
38 1
7
30 1
44 1
40 1
39 1
43 1
42 1
38 1
7
36 1
44 1
40 1
39 1
43 1
42 1
38 1
8
41 1
32 1
44 2
40 1
39 1
43 2
42 2
38 1
9
37 1
29 1
28 1
44 2
40 3
39 3
43 2
42 2
38 3
6
44 1
40 1
39 1
43 1
42 1
38 1
3
40 1
39 1
38 1
6
44 1
40 1
39 1
43 1
42 1
38 1
3
44 1
43 1
42 1
6
44 1
40 1
39 1
43 1
42 1
38 1
3
44 1
43 1
42 1
6
44 1
40 1
39 1
43 1
42 1
38 1
3
40 1
39 1
38 1
6
44 1
40 1
39 1
43 1
42 1
38 1
6
44 1
40 1
39 1
43 1
42 1
38 1
0
0
0
3
44 1
43 1
42 1
0
0
0
end_CG
