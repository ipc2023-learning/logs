begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var0
-1
11
Atom at(bob, gate)
Atom at(bob, location1)
Atom at(bob, location2)
Atom at(bob, location3)
Atom at(bob, location4)
Atom at(bob, location5)
Atom at(bob, location6)
Atom at(bob, location7)
Atom at(bob, location8)
Atom at(bob, location9)
Atom at(bob, shed)
end_variable
begin_variable
var9
-1
2
Atom at(spanner9, location7)
Atom carrying(bob, spanner9)
end_variable
begin_variable
var8
-1
2
Atom at(spanner8, location9)
Atom carrying(bob, spanner8)
end_variable
begin_variable
var7
-1
2
Atom at(spanner7, location2)
Atom carrying(bob, spanner7)
end_variable
begin_variable
var6
-1
2
Atom at(spanner6, location9)
Atom carrying(bob, spanner6)
end_variable
begin_variable
var5
-1
2
Atom at(spanner5, location5)
Atom carrying(bob, spanner5)
end_variable
begin_variable
var4
-1
2
Atom at(spanner4, location8)
Atom carrying(bob, spanner4)
end_variable
begin_variable
var3
-1
2
Atom at(spanner3, location7)
Atom carrying(bob, spanner3)
end_variable
begin_variable
var2
-1
2
Atom at(spanner2, location4)
Atom carrying(bob, spanner2)
end_variable
begin_variable
var1
-1
2
Atom at(spanner1, location7)
Atom carrying(bob, spanner1)
end_variable
begin_variable
var15
-1
2
Atom usable(spanner1)
NegatedAtom usable(spanner1)
end_variable
begin_variable
var16
-1
2
Atom usable(spanner2)
NegatedAtom usable(spanner2)
end_variable
begin_variable
var17
-1
2
Atom usable(spanner3)
NegatedAtom usable(spanner3)
end_variable
begin_variable
var18
-1
2
Atom usable(spanner4)
NegatedAtom usable(spanner4)
end_variable
begin_variable
var19
-1
2
Atom usable(spanner5)
NegatedAtom usable(spanner5)
end_variable
begin_variable
var20
-1
2
Atom usable(spanner6)
NegatedAtom usable(spanner6)
end_variable
begin_variable
var21
-1
2
Atom usable(spanner7)
NegatedAtom usable(spanner7)
end_variable
begin_variable
var22
-1
2
Atom usable(spanner8)
NegatedAtom usable(spanner8)
end_variable
begin_variable
var23
-1
2
Atom usable(spanner9)
NegatedAtom usable(spanner9)
end_variable
begin_variable
var10
-1
2
Atom loose(nut1)
Atom tightened(nut1)
end_variable
begin_variable
var11
-1
2
Atom loose(nut2)
Atom tightened(nut2)
end_variable
begin_variable
var12
-1
2
Atom loose(nut3)
Atom tightened(nut3)
end_variable
begin_variable
var13
-1
2
Atom loose(nut4)
Atom tightened(nut4)
end_variable
begin_variable
var14
-1
2
Atom loose(nut5)
Atom tightened(nut5)
end_variable
0
begin_state
10
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
5
19 1
20 1
21 1
22 1
23 1
end_goal
64
begin_operator
pickup_spanner location2 spanner7 bob
1
0 2
1
0 3 0 1
0
end_operator
begin_operator
pickup_spanner location4 spanner2 bob
1
0 4
1
0 8 0 1
0
end_operator
begin_operator
pickup_spanner location5 spanner5 bob
1
0 5
1
0 5 0 1
0
end_operator
begin_operator
pickup_spanner location7 spanner1 bob
1
0 7
1
0 9 0 1
0
end_operator
begin_operator
pickup_spanner location7 spanner3 bob
1
0 7
1
0 7 0 1
0
end_operator
begin_operator
pickup_spanner location7 spanner9 bob
1
0 7
1
0 1 0 1
0
end_operator
begin_operator
pickup_spanner location8 spanner4 bob
1
0 8
1
0 6 0 1
0
end_operator
begin_operator
pickup_spanner location9 spanner6 bob
1
0 9
1
0 4 0 1
0
end_operator
begin_operator
pickup_spanner location9 spanner8 bob
1
0 9
1
0 2 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
2
0 0
9 1
2
0 19 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
2
0 0
9 1
2
0 20 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
2
0 0
9 1
2
0 21 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
2
0 0
9 1
2
0 22 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
2
0 0
9 1
2
0 23 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
2
0 0
8 1
2
0 19 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
2
0 0
8 1
2
0 20 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
2
0 0
8 1
2
0 21 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
2
0 0
8 1
2
0 22 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
2
0 0
8 1
2
0 23 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
2
0 0
7 1
2
0 19 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
2
0 0
7 1
2
0 20 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
2
0 0
7 1
2
0 21 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
2
0 0
7 1
2
0 22 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
2
0 0
7 1
2
0 23 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
2
0 0
6 1
2
0 19 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
2
0 0
6 1
2
0 20 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
2
0 0
6 1
2
0 21 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
2
0 0
6 1
2
0 22 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 0
check 1
39
check 0
check 0
check 0
switch 20
check 0
switch 16
check 0
check 1
40
check 0
check 0
check 0
switch 21
check 0
switch 16
check 0
check 1
41
check 0
check 0
check 0
switch 22
check 0
switch 16
check 0
check 1
42
check 0
check 0
check 0
switch 23
check 0
switch 16
check 0
check 1
43
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
switch 19
check 0
switch 17
check 0
check 1
44
check 0
check 0
check 0
switch 20
check 0
switch 17
check 0
check 1
45
check 0
check 0
check 0
switch 21
check 0
switch 17
check 0
check 1
46
check 0
check 0
check 0
switch 22
check 0
switch 17
check 0
check 1
47
check 0
check 0
check 0
switch 23
check 0
switch 17
check 0
check 1
48
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
switch 19
check 0
switch 18
check 0
check 1
49
check 0
check 0
check 0
switch 20
check 0
switch 18
check 0
check 1
50
check 0
check 0
check 0
switch 21
check 0
switch 18
check 0
check 1
51
check 0
check 0
check 0
switch 22
check 0
switch 18
check 0
check 1
52
check 0
check 0
check 0
switch 23
check 0
switch 18
check 0
check 1
53
check 0
check 0
check 0
check 0
check 0
check 1
54
switch 9
check 1
55
check 0
check 0
switch 3
check 0
check 1
0
check 0
check 0
check 1
56
switch 9
check 1
57
check 0
check 0
switch 8
check 0
check 1
1
check 0
check 0
switch 9
check 1
58
check 0
check 0
switch 5
check 0
check 1
2
check 0
check 0
check 1
59
switch 9
check 1
60
check 1
3
check 0
switch 7
check 0
check 1
4
check 0
switch 1
check 0
check 1
5
check 0
check 0
switch 9
check 1
61
check 0
check 0
switch 6
check 0
check 1
6
check 0
check 0
switch 9
check 1
62
check 0
check 0
switch 4
check 0
check 1
7
check 0
switch 2
check 0
check 1
8
check 0
check 0
check 1
63
check 0
end_SG
begin_DTG
0
1
2
54
0
1
3
55
0
1
4
56
0
1
5
57
0
1
6
58
0
1
7
59
0
1
8
60
0
1
9
61
0
1
0
62
0
1
1
63
0
end_DTG
begin_DTG
1
1
5
1
0 7
0
end_DTG
begin_DTG
1
1
8
1
0 9
0
end_DTG
begin_DTG
1
1
0
1
0 2
0
end_DTG
begin_DTG
1
1
7
1
0 9
0
end_DTG
begin_DTG
1
1
2
1
0 5
0
end_DTG
begin_DTG
1
1
6
1
0 8
0
end_DTG
begin_DTG
1
1
4
1
0 7
0
end_DTG
begin_DTG
1
1
1
1
0 4
0
end_DTG
begin_DTG
1
1
3
1
0 7
0
end_DTG
begin_DTG
5
1
9
3
0 0
9 1
19 0
1
10
3
0 0
9 1
20 0
1
11
3
0 0
9 1
21 0
1
12
3
0 0
9 1
22 0
1
13
3
0 0
9 1
23 0
0
end_DTG
begin_DTG
5
1
14
3
0 0
8 1
19 0
1
15
3
0 0
8 1
20 0
1
16
3
0 0
8 1
21 0
1
17
3
0 0
8 1
22 0
1
18
3
0 0
8 1
23 0
0
end_DTG
begin_DTG
5
1
19
3
0 0
7 1
19 0
1
20
3
0 0
7 1
20 0
1
21
3
0 0
7 1
21 0
1
22
3
0 0
7 1
22 0
1
23
3
0 0
7 1
23 0
0
end_DTG
begin_DTG
5
1
24
3
0 0
6 1
19 0
1
25
3
0 0
6 1
20 0
1
26
3
0 0
6 1
21 0
1
27
3
0 0
6 1
22 0
1
28
3
0 0
6 1
23 0
0
end_DTG
begin_DTG
5
1
29
3
0 0
5 1
19 0
1
30
3
0 0
5 1
20 0
1
31
3
0 0
5 1
21 0
1
32
3
0 0
5 1
22 0
1
33
3
0 0
5 1
23 0
0
end_DTG
begin_DTG
5
1
34
3
0 0
4 1
19 0
1
35
3
0 0
4 1
20 0
1
36
3
0 0
4 1
21 0
1
37
3
0 0
4 1
22 0
1
38
3
0 0
4 1
23 0
0
end_DTG
begin_DTG
5
1
39
3
0 0
3 1
19 0
1
40
3
0 0
3 1
20 0
1
41
3
0 0
3 1
21 0
1
42
3
0 0
3 1
22 0
1
43
3
0 0
3 1
23 0
0
end_DTG
begin_DTG
5
1
44
3
0 0
2 1
19 0
1
45
3
0 0
2 1
20 0
1
46
3
0 0
2 1
21 0
1
47
3
0 0
2 1
22 0
1
48
3
0 0
2 1
23 0
0
end_DTG
begin_DTG
5
1
49
3
0 0
1 1
19 0
1
50
3
0 0
1 1
20 0
1
51
3
0 0
1 1
21 0
1
52
3
0 0
1 1
22 0
1
53
3
0 0
1 1
23 0
0
end_DTG
begin_DTG
9
1
9
3
0 0
9 1
10 0
1
14
3
0 0
8 1
11 0
1
19
3
0 0
7 1
12 0
1
24
3
0 0
6 1
13 0
1
29
3
0 0
5 1
14 0
1
34
3
0 0
4 1
15 0
1
39
3
0 0
3 1
16 0
1
44
3
0 0
2 1
17 0
1
49
3
0 0
1 1
18 0
0
end_DTG
begin_DTG
9
1
10
3
0 0
9 1
10 0
1
15
3
0 0
8 1
11 0
1
20
3
0 0
7 1
12 0
1
25
3
0 0
6 1
13 0
1
30
3
0 0
5 1
14 0
1
35
3
0 0
4 1
15 0
1
40
3
0 0
3 1
16 0
1
45
3
0 0
2 1
17 0
1
50
3
0 0
1 1
18 0
0
end_DTG
begin_DTG
9
1
11
3
0 0
9 1
10 0
1
16
3
0 0
8 1
11 0
1
21
3
0 0
7 1
12 0
1
26
3
0 0
6 1
13 0
1
31
3
0 0
5 1
14 0
1
36
3
0 0
4 1
15 0
1
41
3
0 0
3 1
16 0
1
46
3
0 0
2 1
17 0
1
51
3
0 0
1 1
18 0
0
end_DTG
begin_DTG
9
1
12
3
0 0
9 1
10 0
1
17
3
0 0
8 1
11 0
1
22
3
0 0
7 1
12 0
1
27
3
0 0
6 1
13 0
1
32
3
0 0
5 1
14 0
1
37
3
0 0
4 1
15 0
1
42
3
0 0
3 1
16 0
1
47
3
0 0
2 1
17 0
1
52
3
0 0
1 1
18 0
0
end_DTG
begin_DTG
9
1
13
3
0 0
9 1
10 0
1
18
3
0 0
8 1
11 0
1
23
3
0 0
7 1
12 0
1
28
3
0 0
6 1
13 0
1
33
3
0 0
5 1
14 0
1
38
3
0 0
4 1
15 0
1
43
3
0 0
3 1
16 0
1
48
3
0 0
2 1
17 0
1
53
3
0 0
1 1
18 0
0
end_DTG
begin_CG
23
9 1
8 1
7 1
6 1
5 1
4 1
3 1
2 1
1 1
19 9
20 9
21 9
22 9
23 9
10 5
11 5
12 5
13 5
14 5
15 5
16 5
17 5
18 5
6
19 1
20 1
21 1
22 1
23 1
18 5
6
19 1
20 1
21 1
22 1
23 1
17 5
6
19 1
20 1
21 1
22 1
23 1
16 5
6
19 1
20 1
21 1
22 1
23 1
15 5
6
19 1
20 1
21 1
22 1
23 1
14 5
6
19 1
20 1
21 1
22 1
23 1
13 5
6
19 1
20 1
21 1
22 1
23 1
12 5
6
19 1
20 1
21 1
22 1
23 1
11 5
6
19 1
20 1
21 1
22 1
23 1
10 5
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
5
19 1
20 1
21 1
22 1
23 1
9
10 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
9
10 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
9
10 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
9
10 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
9
10 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
end_CG
