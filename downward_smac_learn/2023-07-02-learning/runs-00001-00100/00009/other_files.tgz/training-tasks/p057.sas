begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var0
-1
10
Atom at(bob, gate)
Atom at(bob, location1)
Atom at(bob, location2)
Atom at(bob, location3)
Atom at(bob, location4)
Atom at(bob, location5)
Atom at(bob, location6)
Atom at(bob, location7)
Atom at(bob, location8)
Atom at(bob, shed)
end_variable
begin_variable
var7
-1
2
Atom at(spanner7, location8)
Atom carrying(bob, spanner7)
end_variable
begin_variable
var6
-1
2
Atom at(spanner6, location1)
Atom carrying(bob, spanner6)
end_variable
begin_variable
var5
-1
2
Atom at(spanner5, location7)
Atom carrying(bob, spanner5)
end_variable
begin_variable
var4
-1
2
Atom at(spanner4, location5)
Atom carrying(bob, spanner4)
end_variable
begin_variable
var3
-1
2
Atom at(spanner3, location5)
Atom carrying(bob, spanner3)
end_variable
begin_variable
var2
-1
2
Atom at(spanner2, location2)
Atom carrying(bob, spanner2)
end_variable
begin_variable
var1
-1
2
Atom at(spanner1, location3)
Atom carrying(bob, spanner1)
end_variable
begin_variable
var12
-1
2
Atom usable(spanner1)
NegatedAtom usable(spanner1)
end_variable
begin_variable
var13
-1
2
Atom usable(spanner2)
NegatedAtom usable(spanner2)
end_variable
begin_variable
var14
-1
2
Atom usable(spanner3)
NegatedAtom usable(spanner3)
end_variable
begin_variable
var15
-1
2
Atom usable(spanner4)
NegatedAtom usable(spanner4)
end_variable
begin_variable
var16
-1
2
Atom usable(spanner5)
NegatedAtom usable(spanner5)
end_variable
begin_variable
var17
-1
2
Atom usable(spanner6)
NegatedAtom usable(spanner6)
end_variable
begin_variable
var18
-1
2
Atom usable(spanner7)
NegatedAtom usable(spanner7)
end_variable
begin_variable
var8
-1
2
Atom loose(nut1)
Atom tightened(nut1)
end_variable
begin_variable
var9
-1
2
Atom loose(nut2)
Atom tightened(nut2)
end_variable
begin_variable
var10
-1
2
Atom loose(nut3)
Atom tightened(nut3)
end_variable
begin_variable
var11
-1
2
Atom loose(nut4)
Atom tightened(nut4)
end_variable
0
begin_state
9
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
4
15 1
16 1
17 1
18 1
end_goal
44
begin_operator
pickup_spanner location1 spanner6 bob
1
0 1
1
0 2 0 1
0
end_operator
begin_operator
pickup_spanner location2 spanner2 bob
1
0 2
1
0 6 0 1
0
end_operator
begin_operator
pickup_spanner location3 spanner1 bob
1
0 3
1
0 7 0 1
0
end_operator
begin_operator
pickup_spanner location5 spanner3 bob
1
0 5
1
0 5 0 1
0
end_operator
begin_operator
pickup_spanner location5 spanner4 bob
1
0 5
1
0 4 0 1
0
end_operator
begin_operator
pickup_spanner location7 spanner5 bob
1
0 7
1
0 3 0 1
0
end_operator
begin_operator
pickup_spanner location8 spanner7 bob
1
0 8
1
0 1 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
2
0 0
7 1
2
0 15 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
2
0 0
7 1
2
0 16 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
2
0 0
7 1
2
0 17 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
2
0 0
7 1
2
0 18 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
2
0 0
6 1
2
0 15 0 1
0 9 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
2
0 0
6 1
2
0 16 0 1
0 9 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
2
0 0
6 1
2
0 17 0 1
0 9 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
2
0 0
6 1
2
0 18 0 1
0 9 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
2
0 0
5 1
2
0 15 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
2
0 0
5 1
2
0 16 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
2
0 0
5 1
2
0 17 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
2
0 0
5 1
2
0 18 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
2
0 0
4 1
2
0 15 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
2
0 0
4 1
2
0 16 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
2
0 0
4 1
2
0 17 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
2
0 0
4 1
2
0 18 0 1
0 11 0 1
0
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
2
0 0
3 1
2
0 15 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
2
0 0
3 1
2
0 16 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
2
0 0
3 1
2
0 17 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
2
0 0
3 1
2
0 18 0 1
0 12 0 1
0
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
2
0 0
2 1
2
0 15 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
2
0 0
2 1
2
0 16 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
2
0 0
2 1
2
0 17 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
2
0 0
2 1
2
0 18 0 1
0 13 0 1
0
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
2
0 0
1 1
2
0 15 0 1
0 14 0 1
0
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
2
0 0
1 1
2
0 16 0 1
0 14 0 1
0
end_operator
begin_operator
tighten_nut ga




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 bob
0
1
0 0 8 0
0
end_operator
begin_operator
walk shed location1 bob
0
1
0 0 9 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 7
check 0
check 0
switch 15
check 0
switch 8
check 0
check 1
7
check 0
check 0
check 0
switch 16
check 0
switch 8
check 0
check 1
8
check 0
check 0
check 0
switch 17
check 0
switch 8
check 0
check 1
9
check 0
check 0
check 0
switch 18
check 0
switch 8
check 0
check 1
10
check 0
check 0
check 0
check 0
switch 6
check 0
check 0
switch 15
check 0
switch 9
check 0
check 1
11
check 0
check 0
check 0
switch 16
check 0
switch 9
check 0
check 1
12
check 0
check 0
check 0
switch 17
check 0
switch 9
check 0
check 1
13
check 0
check 0
check 0
switch 18
check 0
switch 9
check 0
check 1
14
check 0
check 0
check 0
check 0
switch 5
check 0
check 0
switch 15
check 0
switch 10
check 0
check 1
15
check 0
check 0
check 0
switch 16
check 0
switch 10
check 0
check 1
16
check 0
check 0
check 0
switch 17
check 0
switch 10
check 0
check 1
17
check 0
check 0
check 0
switch 18
check 0
switch 10
check 0
check 1
18
check 0
check 0
check 0
check 0
switch 4
check 0
check 0
switch 15
check 0
switch 11
check 0
check 1
19
check 0
check 0
check 0
switch 16
check 0
switch 11
check 0
check 1
20
check 0
check 0
check 0
switch 17
check 0
switch 11
check 0
check 1
21
check 0
check 0
check 0
switch 18
check 0
switch 11
check 0
check 1
22
check 0
check 0
check 0
check 0
switch 3
check 0
check 0
switch 15
check 0
switch 12
check 0
check 1
23
check 0
check 0
check 0
switch 16
check 0
switch 12
check 0
check 1
24
check 0
check 0
check 0
switch 17
check 0
switch 12
check 0
check 1
25
check 0
check 0
check 0
switch 18
check 0
switch 12
check 0
check 1
26
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
switch 15
check 0
switch 13
check 0
check 1
27
check 0
check 0
check 0
switch 16
check 0
switch 13
check 0
check 1
28
check 0
check 0
check 0
switch 17
check 0
switch 13
check 0
check 1
29
check 0
check 0
check 0
switch 18
check 0
switch 13
check 0
check 1
30
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
switch 15
check 0
switch 14
check 0
check 1
31
check 0
check 0
check 0
switch 16
check 0
switch 14
check 0
check 1
32
check 0
check 0
check 0
switch 17
check 0
switch 14
check 0
check 1
33
check 0
check 0
check 0
switch 18
check 0
switch 14
check 0
check 1
34
check 0
check 0
check 0
check 0
check 0
switch 7
check 1
35
check 0
check 0
switch 2
check 0
check 1
0
check 0
check 0
switch 7
check 1
36
check 0
check 0
switch 6
check 0
check 1
1
check 0
check 0
switch 7
check 1
37
check 1
2
check 0
check 0
check 1
38
switch 7
check 1
39
check 0
check 0
switch 5
check 0
check 1
3
check 0
switch 4
check 0
check 1
4
check 0
check 0
check 1
40
switch 7
check 1
41
check 0
check 0
switch 3
check 0
check 1
5
check 0
check 0
switch 7
check 1
42
check 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 1
43
check 0
end_SG
begin_DTG
0
1
2
35
0
1
3
36
0
1
4
37
0
1
5
38
0
1
6
39
0
1
7
40
0
1
8
41
0
1
0
42
0
1
1
43
0
end_DTG
begin_DTG
1
1
6
1
0 8
0
end_DTG
begin_DTG
1
1
0
1
0 1
0
end_DTG
begin_DTG
1
1
5
1
0 7
0
end_DTG
begin_DTG
1
1
4
1
0 5
0
end_DTG
begin_DTG
1
1
3
1
0 5
0
end_DTG
begin_DTG
1
1
1
1
0 2
0
end_DTG
begin_DTG
1
1
2
1
0 3
0
end_DTG
begin_DTG
4
1
7
3
0 0
7 1
15 0
1
8
3
0 0
7 1
16 0
1
9
3
0 0
7 1
17 0
1
10
3
0 0
7 1
18 0
0
end_DTG
begin_DTG
4
1
11
3
0 0
6 1
15 0
1
12
3
0 0
6 1
16 0
1
13
3
0 0
6 1
17 0
1
14
3
0 0
6 1
18 0
0
end_DTG
begin_DTG
4
1
15
3
0 0
5 1
15 0
1
16
3
0 0
5 1
16 0
1
17
3
0 0
5 1
17 0
1
18
3
0 0
5 1
18 0
0
end_DTG
begin_DTG
4
1
19
3
0 0
4 1
15 0
1
20
3
0 0
4 1
16 0
1
21
3
0 0
4 1
17 0
1
22
3
0 0
4 1
18 0
0
end_DTG
begin_DTG
4
1
23
3
0 0
3 1
15 0
1
24
3
0 0
3 1
16 0
1
25
3
0 0
3 1
17 0
1
26
3
0 0
3 1
18 0
0
end_DTG
begin_DTG
4
1
27
3
0 0
2 1
15 0
1
28
3
0 0
2 1
16 0
1
29
3
0 0
2 1
17 0
1
30
3
0 0
2 1
18 0
0
end_DTG
begin_DTG
4
1
31
3
0 0
1 1
15 0
1
32
3
0 0
1 1
16 0
1
33
3
0 0
1 1
17 0
1
34
3
0 0
1 1
18 0
0
end_DTG
begin_DTG
7
1
7
3
0 0
7 1
8 0
1
11
3
0 0
6 1
9 0
1
15
3
0 0
5 1
10 0
1
19
3
0 0
4 1
11 0
1
23
3
0 0
3 1
12 0
1
27
3
0 0
2 1
13 0
1
31
3
0 0
1 1
14 0
0
end_DTG
begin_DTG
7
1
8
3
0 0
7 1
8 0
1
12
3
0 0
6 1
9 0
1
16
3
0 0
5 1
10 0
1
20
3
0 0
4 1
11 0
1
24
3
0 0
3 1
12 0
1
28
3
0 0
2 1
13 0
1
32
3
0 0
1 1
14 0
0
end_DTG
begin_DTG
7
1
9
3
0 0
7 1
8 0
1
13
3
0 0
6 1
9 0
1
17
3
0 0
5 1
10 0
1
21
3
0 0
4 1
11 0
1
25
3
0 0
3 1
12 0
1
29
3
0 0
2 1
13 0
1
33
3
0 0
1 1
14 0
0
end_DTG
begin_DTG
7
1
10
3
0 0
7 1
8 0
1
14
3
0 0
6 1
9 0
1
18
3
0 0
5 1
10 0
1
22
3
0 0
4 1
11 0
1
26
3
0 0
3 1
12 0
1
30
3
0 0
2 1
13 0
1
34
3
0 0
1 1
14 0
0
end_DTG
begin_CG
18
7 1
6 1
5 1
4 1
3 1
2 1
1 1
15 7
16 7
17 7
18 7
8 4
9 4
10 4
11 4
12 4
13 4
14 4
5
15 1
16 1
17 1
18 1
14 4
5
15 1
16 1
17 1
18 1
13 4
5
15 1
16 1
17 1
18 1
12 4
5
15 1
16 1
17 1
18 1
11 4
5
15 1
16 1
17 1
18 1
10 4
5
15 1
16 1
17 1
18 1
9 4
5
15 1
16 1
17 1
18 1
8 4
4
15 1
16 1
17 1
18 1
4
15 1
16 1
17 1
18 1
4
15 1
16 1
17 1
18 1
4
15 1
16 1
17 1
18 1
4
15 1
16 1
17 1
18 1
4
15 1
16 1
17 1
18 1
4
15 1
16 1
17 1
18 1
7
8 1
9 1
10 1
11 1
12 1
13 1
14 1
7
8 1
9 1
10 1
11 1
12 1
13 1
14 1
7
8 1
9 1
10 1
11 1
12 1
13 1
14 1
7
8 1
9 1
10 1
11 1
12 1
13 1
14 1
end_CG
