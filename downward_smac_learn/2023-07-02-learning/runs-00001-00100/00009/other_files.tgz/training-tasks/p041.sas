begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var0
-1
8
Atom at(bob, gate)
Atom at(bob, location1)
Atom at(bob, location2)
Atom at(bob, location3)
Atom at(bob, location4)
Atom at(bob, location5)
Atom at(bob, location6)
Atom at(bob, shed)
end_variable
begin_variable
var5
-1
2
Atom at(spanner5, location6)
Atom carrying(bob, spanner5)
end_variable
begin_variable
var4
-1
2
Atom at(spanner4, location6)
Atom carrying(bob, spanner4)
end_variable
begin_variable
var3
-1
2
Atom at(spanner3, location3)
Atom carrying(bob, spanner3)
end_variable
begin_variable
var2
-1
2
Atom at(spanner2, location1)
Atom carrying(bob, spanner2)
end_variable
begin_variable
var1
-1
2
Atom at(spanner1, location2)
Atom carrying(bob, spanner1)
end_variable
begin_variable
var9
-1
2
Atom usable(spanner1)
NegatedAtom usable(spanner1)
end_variable
begin_variable
var10
-1
2
Atom usable(spanner2)
NegatedAtom usable(spanner2)
end_variable
begin_variable
var11
-1
2
Atom usable(spanner3)
NegatedAtom usable(spanner3)
end_variable
begin_variable
var12
-1
2
Atom usable(spanner4)
NegatedAtom usable(spanner4)
end_variable
begin_variable
var13
-1
2
Atom usable(spanner5)
NegatedAtom usable(spanner5)
end_variable
begin_variable
var6
-1
2
Atom loose(nut1)
Atom tightened(nut1)
end_variable
begin_variable
var7
-1
2
Atom loose(nut2)
Atom tightened(nut2)
end_variable
begin_variable
var8
-1
2
Atom loose(nut3)
Atom tightened(nut3)
end_variable
0
begin_state
7
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
3
11 1
12 1
13 1
end_goal
27
begin_operator
pickup_spanner location1 spanner2 bob
1
0 1
1
0 4 0 1
0
end_operator
begin_operator
pickup_spanner location2 spanner1 bob
1
0 2
1
0 5 0 1
0
end_operator
begin_operator
pickup_spanner location3 spanner3 bob
1
0 3
1
0 3 0 1
0
end_operator
begin_operator
pickup_spanner location6 spanner4 bob
1
0 6
1
0 2 0 1
0
end_operator
begin_operator
pickup_spanner location6 spanner5 bob
1
0 6
1
0 1 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
2
0 0
5 1
2
0 11 0 1
0 6 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
2
0 0
5 1
2
0 12 0 1
0 6 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
2
0 0
5 1
2
0 13 0 1
0 6 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
2
0 0
4 1
2
0 11 0 1
0 7 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
2
0 0
4 1
2
0 12 0 1
0 7 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
2
0 0
4 1
2
0 13 0 1
0 7 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
2
0 0
3 1
2
0 11 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
2
0 0
3 1
2
0 12 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
2
0 0
3 1
2
0 13 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
2
0 0
2 1
2
0 11 0 1
0 9 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
2
0 0
2 1
2
0 12 0 1
0 9 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
2
0 0
2 1
2
0 13 0 1
0 9 0 1
0
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
2
0 0
1 1
2
0 11 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
2
0 0
1 1
2
0 12 0 1
0 10 0 1
0
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
2
0 0
1 1
2
0 13 0 1
0 10 0 1
0
end_operator
begin_operator
walk location1 location2 bob
0
1
0 0 1 2
0
end_operator
begin_operator
walk location2 location3 bob
0
1
0 0 2 3
0
end_operator
begin_operator
walk location3 location4 bob
0
1
0 0 3 4
0
end_operator
begin_operator
walk location4 location5 bob
0
1
0 0 4 5
0
end_operator
begin_operator
walk location5 location6 bob
0
1
0 0 5 6
0
end_operator
begin_operator
walk location6 gate bob
0
1
0 0 6 0
0
end_operator
begin_operator
walk shed location1 bob
0
1
0 0 7 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 5
check 0
check 0
switch 11
check 0
switch 6
check 0
check 1
5
check 0
check 0
check 0
switch 12
check 0
switch 6
check 0
check 1
6
check 0
check 0
check 0
switch 13
check 0
switch 6
check 0
check 1
7
check 0
check 0
check 0
check 0
switch 4
check 0
check 0
switch 11
check 0
switch 7
check 0
check 1
8
check 0
check 0
check 0
switch 12
check 0
switch 7
check 0
check 1
9
check 0
check 0
check 0
switch 13
check 0
switch 7
check 0
check 1
10
check 0
check 0
check 0
check 0
switch 3
check 0
check 0
switch 11
check 0
switch 8
check 0
check 1
11
check 0
check 0
check 0
switch 12
check 0
switch 8
check 0
check 1
12
check 0
check 0
check 0
switch 13
check 0
switch 8
check 0
check 1
13
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
switch 11
check 0
switch 9
check 0
check 1
14
check 0
check 0
check 0
switch 12
check 0
switch 9
check 0
check 1
15
check 0
check 0
check 0
switch 13
check 0
switch 9
check 0
check 1
16
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
switch 11
check 0
switch 10
check 0
check 1
17
check 0
check 0
check 0
switch 12
check 0
switch 10
check 0
check 1
18
check 0
check 0
check 0
switch 13
check 0
switch 10
check 0
check 1
19
check 0
check 0
check 0
check 0
check 0
switch 5
check 1
20
check 0
check 0
switch 4
check 0
check 1
0
check 0
check 0
switch 5
check 1
21
check 1
1
check 0
check 0
switch 5
check 1
22
check 0
check 0
switch 3
check 0
check 1
2
check 0
check 0
check 1
23
check 1
24
switch 5
check 1
25
check 0
check 0
switch 2
check 0
check 1
3
check 0
switch 1
check 0
check 1
4
check 0
check 0
check 1
26
check 0
end_SG
begin_DTG
0
1
2
20
0
1
3
21
0
1
4
22
0
1
5
23
0
1
6
24
0
1
0
25
0
1
1
26
0
end_DTG
begin_DTG
1
1
4
1
0 6
0
end_DTG
begin_DTG
1
1
3
1
0 6
0
end_DTG
begin_DTG
1
1
2
1
0 3
0
end_DTG
begin_DTG
1
1
0
1
0 1
0
end_DTG
begin_DTG
1
1
1
1
0 2
0
end_DTG
begin_DTG
3
1
5
3
0 0
5 1
11 0
1
6
3
0 0
5 1
12 0
1
7
3
0 0
5 1
13 0
0
end_DTG
begin_DTG
3
1
8
3
0 0
4 1
11 0
1
9
3
0 0
4 1
12 0
1
10
3
0 0
4 1
13 0
0
end_DTG
begin_DTG
3
1
11
3
0 0
3 1
11 0
1
12
3
0 0
3 1
12 0
1
13
3
0 0
3 1
13 0
0
end_DTG
begin_DTG
3
1
14
3
0 0
2 1
11 0
1
15
3
0 0
2 1
12 0
1
16
3
0 0
2 1
13 0
0
end_DTG
begin_DTG
3
1
17
3
0 0
1 1
11 0
1
18
3
0 0
1 1
12 0
1
19
3
0 0
1 1
13 0
0
end_DTG
begin_DTG
5
1
5
3
0 0
5 1
6 0
1
8
3
0 0
4 1
7 0
1
11
3
0 0
3 1
8 0
1
14
3
0 0
2 1
9 0
1
17
3
0 0
1 1
10 0
0
end_DTG
begin_DTG
5
1
6
3
0 0
5 1
6 0
1
9
3
0 0
4 1
7 0
1
12
3
0 0
3 1
8 0
1
15
3
0 0
2 1
9 0
1
18
3
0 0
1 1
10 0
0
end_DTG
begin_DTG
5
1
7
3
0 0
5 1
6 0
1
10
3
0 0
4 1
7 0
1
13
3
0 0
3 1
8 0
1
16
3
0 0
2 1
9 0
1
19
3
0 0
1 1
10 0
0
end_DTG
begin_CG
13
5 1
4 1
3 1
2 1
1 1
11 5
12 5
13 5
6 3
7 3
8 3
9 3
10 3
4
11 1
12 1
13 1
10 3
4
11 1
12 1
13 1
9 3
4
11 1
12 1
13 1
8 3
4
11 1
12 1
13 1
7 3
4
11 1
12 1
13 1
6 3
3
11 1
12 1
13 1
3
11 1
12 1
13 1
3
11 1
12 1
13 1
3
11 1
12 1
13 1
3
11 1
12 1
13 1
5
6 1
7 1
8 1
9 1
10 1
5
6 1
7 1
8 1
9 1
10 1
5
6 1
7 1
8 1
9 1
10 1
end_CG
