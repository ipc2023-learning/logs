begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var0
-1
8
Atom at(bob, gate)
Atom at(bob, location1)
Atom at(bob, location2)
Atom at(bob, location3)
Atom at(bob, location4)
Atom at(bob, location5)
Atom at(bob, location6)
Atom at(bob, shed)
end_variable
begin_variable
var4
-1
2
Atom at(spanner4, location4)
Atom carrying(bob, spanner4)
end_variable
begin_variable
var3
-1
2
Atom at(spanner3, location4)
Atom carrying(bob, spanner3)
end_variable
begin_variable
var2
-1
2
Atom at(spanner2, location5)
Atom carrying(bob, spanner2)
end_variable
begin_variable
var1
-1
2
Atom at(spanner1, location4)
Atom carrying(bob, spanner1)
end_variable
begin_variable
var7
-1
2
Atom usable(spanner1)
NegatedAtom usable(spanner1)
end_variable
begin_variable
var8
-1
2
Atom usable(spanner2)
NegatedAtom usable(spanner2)
end_variable
begin_variable
var9
-1
2
Atom usable(spanner3)
NegatedAtom usable(spanner3)
end_variable
begin_variable
var10
-1
2
Atom usable(spanner4)
NegatedAtom usable(spanner4)
end_variable
begin_variable
var5
-1
2
Atom loose(nut1)
Atom tightened(nut1)
end_variable
begin_variable
var6
-1
2
Atom loose(nut2)
Atom tightened(nut2)
end_variable
0
begin_state
7
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
2
9 1
10 1
end_goal
19
begin_operator
pickup_spanner location4 spanner1 bob
1
0 4
1
0 4 0 1
0
end_operator
begin_operator
pickup_spanner location4 spanner3 bob
1
0 4
1
0 2 0 1
0
end_operator
begin_operator
pickup_spanner location4 spanner4 bob
1
0 4
1
0 1 0 1
0
end_operator
begin_operator
pickup_spanner location5 spanner2 bob
1
0 5
1
0 3 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
2
0 0
4 1
2
0 9 0 1
0 5 0 1
0
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
2
0 0
4 1
2
0 10 0 1
0 5 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
2
0 0
3 1
2
0 9 0 1
0 6 0 1
0
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
2
0 0
3 1
2
0 10 0 1
0 6 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
2
0 0
2 1
2
0 9 0 1
0 7 0 1
0
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
2
0 0
2 1
2
0 10 0 1
0 7 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
2
0 0
1 1
2
0 9 0 1
0 8 0 1
0
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
2
0 0
1 1
2
0 10 0 1
0 8 0 1
0
end_operator
begin_operator
walk location1 location2 bob
0
1
0 0 1 2
0
end_operator
begin_operator
walk location2 location3 bob
0
1
0 0 2 3
0
end_operator
begin_operator
walk location3 location4 bob
0
1
0 0 3 4
0
end_operator
begin_operator
walk location4 location5 bob
0
1
0 0 4 5
0
end_operator
begin_operator
walk location5 location6 bob
0
1
0 0 5 6
0
end_operator
begin_operator
walk location6 gate bob
0
1
0 0 6 0
0
end_operator
begin_operator
walk shed location1 bob
0
1
0 0 7 1
0
end_operator
0
begin_SG
switch 0
check 0
switch 4
check 0
check 0
switch 9
check 0
switch 5
check 0
check 1
4
check 0
check 0
check 0
switch 10
check 0
switch 5
check 0
check 1
5
check 0
check 0
check 0
check 0
switch 3
check 0
check 0
switch 9
check 0
switch 6
check 0
check 1
6
check 0
check 0
check 0
switch 10
check 0
switch 6
check 0
check 1
7
check 0
check 0
check 0
check 0
switch 2
check 0
check 0
switch 9
check 0
switch 7
check 0
check 1
8
check 0
check 0
check 0
switch 10
check 0
switch 7
check 0
check 1
9
check 0
check 0
check 0
check 0
switch 1
check 0
check 0
switch 9
check 0
switch 8
check 0
check 1
10
check 0
check 0
check 0
switch 10
check 0
switch 8
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
check 1
12
check 1
13
check 1
14
switch 4
check 1
15
check 1
0
check 0
switch 2
check 0
check 1
1
check 0
switch 1
check 0
check 1
2
check 0
check 0
switch 4
check 1
16
check 0
check 0
switch 3
check 0
check 1
3
check 0
check 0
check 1
17
check 1
18
check 0
end_SG
begin_DTG
0
1
2
12
0
1
3
13
0
1
4
14
0
1
5
15
0
1
6
16
0
1
0
17
0
1
1
18
0
end_DTG
begin_DTG
1
1
2
1
0 4
0
end_DTG
begin_DTG
1
1
1
1
0 4
0
end_DTG
begin_DTG
1
1
3
1
0 5
0
end_DTG
begin_DTG
1
1
0
1
0 4
0
end_DTG
begin_DTG
2
1
4
3
0 0
4 1
9 0
1
5
3
0 0
4 1
10 0
0
end_DTG
begin_DTG
2
1
6
3
0 0
3 1
9 0
1
7
3
0 0
3 1
10 0
0
end_DTG
begin_DTG
2
1
8
3
0 0
2 1
9 0
1
9
3
0 0
2 1
10 0
0
end_DTG
begin_DTG
2
1
10
3
0 0
1 1
9 0
1
11
3
0 0
1 1
10 0
0
end_DTG
begin_DTG
4
1
4
3
0 0
4 1
5 0
1
6
3
0 0
3 1
6 0
1
8
3
0 0
2 1
7 0
1
10
3
0 0
1 1
8 0
0
end_DTG
begin_DTG
4
1
5
3
0 0
4 1
5 0
1
7
3
0 0
3 1
6 0
1
9
3
0 0
2 1
7 0
1
11
3
0 0
1 1
8 0
0
end_DTG
begin_CG
10
4 1
3 1
2 1
1 1
9 4
10 4
5 2
6 2
7 2
8 2
3
9 1
10 1
8 2
3
9 1
10 1
7 2
3
9 1
10 1
6 2
3
9 1
10 1
5 2
2
9 1
10 1
2
9 1
10 1
2
9 1
10 1
2
9 1
10 1
4
5 1
6 1
7 1
8 1
4
5 1
6 1
7 1
8 1
end_CG
