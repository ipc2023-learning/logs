begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var2
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
25
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_5)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_2_5)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_5)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
end_variable
22
begin_mutex_group
2
23 0
0 0
end_mutex_group
begin_mutex_group
2
23 1
1 0
end_mutex_group
begin_mutex_group
2
23 2
8 0
end_mutex_group
begin_mutex_group
2
23 3
9 0
end_mutex_group
begin_mutex_group
2
23 4
14 0
end_mutex_group
begin_mutex_group
2
23 5
10 0
end_mutex_group
begin_mutex_group
2
23 6
3 0
end_mutex_group
begin_mutex_group
2
23 7
2 0
end_mutex_group
begin_mutex_group
2
23 8
19 0
end_mutex_group
begin_mutex_group
2
23 9
15 0
end_mutex_group
begin_mutex_group
2
23 10
21 0
end_mutex_group
begin_mutex_group
2
23 11
18 0
end_mutex_group
begin_mutex_group
2
23 12
7 0
end_mutex_group
begin_mutex_group
2
23 13
11 0
end_mutex_group
begin_mutex_group
2
23 14
16 0
end_mutex_group
begin_mutex_group
2
23 15
20 0
end_mutex_group
begin_mutex_group
2
23 16
17 0
end_mutex_group
begin_mutex_group
2
23 17
4 0
end_mutex_group
begin_mutex_group
2
23 18
5 0
end_mutex_group
begin_mutex_group
2
23 19
12 0
end_mutex_group
begin_mutex_group
2
23 20
13 0
end_mutex_group
begin_mutex_group
2
23 21
6 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
24
9
end_state
begin_goal
1
23 13
end_goal
112
begin_operator
move loc_2_2 loc_3_2 down
0
1
0 22 0 2
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
8 0
1
0 22 1 4
0
end_operator
begin_operator
move loc_3_2 loc_2_2 up
0
1
0 22 2 0
0
end_operator
begin_operator
move loc_3_2 loc_3_3 right
1
1 0
1
0 22 2 3
0
end_operator
begin_operator
move loc_3_2 loc_4_2 down
0
1
0 22 2 5
0
end_operator
begin_operator
move loc_3_3 loc_3_2 left
0
1
0 22 3 2
0
end_operator
begin_operator
move loc_3_3 loc_4_3 down
1
9 0
1
0 22 3 6
0
end_operator
begin_operator
move loc_3_5 loc_2_5 up
1
0 0
1
0 22 4 1
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
14 0
1
0 22 4 7
0
end_operator
begin_operator
move loc_4_2 loc_3_2 up
0
1
0 22 5 2
0
end_operator
begin_operator
move loc_4_2 loc_4_3 right
1
9 0
1
0 22 5 6
0
end_operator
begin_operator
move loc_4_2 loc_5_2 down
1
2 0
1
0 22 5 10
0
end_operator
begin_operator
move loc_4_3 loc_3_3 up
1
1 0
1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





1
107
2
23 20
22 22
0
end_DTG
begin_DTG
1
1
89
2
23 11
22 13
2
0
79
3
23 12
22 9
4 0
0
102
3
23 12
22 20
3 0
end_DTG
begin_DTG
1
1
87
2
23 4
22 13
2
0
70
3
23 2
22 1
14 0
0
74
3
23 2
22 7
0 0
end_DTG
begin_DTG
1
1
94
2
23 8
22 16
2
0
71
3
23 3
22 3
19 0
0
81
3
23 3
22 11
1 0
end_DTG
begin_DTG
1
1
100
2
23 11
22 19
2
0
75
3
23 5
22 7
3 0
0
78
3
23 5
22 9
14 0
end_DTG
begin_DTG
2
1
73
2
23 8
22 6
1
98
2
23 14
22 18
2
0
83
3
23 13
22 11
5 0
0
104
3
23 13
22 21
19 0
end_DTG
begin_DTG
2
1
86
2
23 14
22 12
1
111
2
23 20
22 24
2
0
105
3
23 19
22 21
13 0
0
109
3
23 19
22 23
5 0
end_DTG
begin_DTG
2
1
90
2
23 15
22 13
1
105
2
23 19
22 21
2
0
107
3
23 20
22 22
6 0
0
111
3
23 20
22 24
12 0
end_DTG
begin_DTG
3
1
70
2
23 2
22 1
1
78
2
23 5
22 9
1
97
2
23 10
22 18
2
0
72
3
23 4
22 4
21 0
0
87
3
23 4
22 13
8 0
end_DTG
begin_DTG
3
1
80
2
23 8
22 10
1
91
2
23 10
22 14
1
106
2
23 14
22 22
2
0
82
3
23 9
22 11
21 0
0
88
3
23 9
22 13
19 0
end_DTG
begin_DTG
1
1
101
2
23 15
22 19
4
0
86
3
23 14
22 12
12 0
0
95
3
23 14
22 16
20 0
0
98
3
23 14
22 18
11 0
0
106
3
23 14
22 22
15 0
end_DTG
begin_DTG
2
1
77
2
23 11
22 8
1
96
2
23 15
22 17
4
0
92
3
23 16
22 14
6 0
0
99
3
23 16
22 18
4 0
0
103
3
23 16
22 20
20 0
0
110
3
23 16
22 24
18 0
end_DTG
begin_DTG
2
1
85
2
23 10
22 12
1
110
2
23 16
22 24
4
0
77
3
23 11
22 8
17 0
0
89
3
23 11
22 13
7 0
0
93
3
23 11
22 15
21 0
0
100
3
23 11
22 19
10 0
end_DTG
begin_DTG
3
1
71
2
23 3
22 3
1
88
2
23 9
22 13
1
104
2
23 13
22 21
4
0
73
3
23 8
22 6
11 0
0
80
3
23 8
22 10
15 0
0
84
3
23 8
22 12
2 0
0
94
3
23 8
22 16
9 0
end_DTG
begin_DTG
3
1
76
2
23 10
22 7
1
95
2
23 14
22 16
1
103
2
23 16
22 20
4
0
90
3
23 15
22 13
13 0
0
96
3
23 15
22 17
17 0
0
101
3
23 15
22 19
16 0
0
108
3
23 15
22 23
21 0
end_DTG
begin_DTG
4
1
72
2
23 4
22 4
1
82
2
23 9
22 11
1
93
2
23 11
22 15
1
108
2
23 15
22 23
4
0
76
3
23 10
22 7
20 0
0
85
3
23 10
22 12
18 0
0
91
3
23 10
22 14
15 0
0
97
3
23 10
22 18
14 0
end_DTG
begin_DTG
1
2
0
0
2
4
1
1
8 0
4
70
2
23 2
14 0
3
0
2
0
3
3
1
1 0
5
4
0
3
2
5
0
6
6
1
9 0
6
71
2
23 3
19 0
3
1
7
1
0 0
7
8
1
14 0
7
72
2
23 4
21 0
3
2
9
0
6
10
1
9 0
10
11
1
2 0
4
3
12
1
1 0
5
13
0
11
14
1
19 0
11
73
2
23 8
11 0
6
4
15
1
8 0
4
74
2
23 2
0 0
8
16
1
10 0
8
75
2
23 5
3 0
13
17
1
21 0
13
76
2
23 10
20 0
4
7
18
1
14 0
9
19
1
3 0
14
20
1
18 0
14
77
2
23 11
17 0
4
8
21
1
10 0
8
78
2
23 5
14 0
15
22
1
7 0
15
79
2
23 12
4 0
3
5
23
0
11
24
1
19 0
11
80
2
23 8
15 0
7
6
25
1
9 0
6
81
2
23 3
1 0
10
26
1
2 0
12
27
1
15 0
12
82
2
23 9
21 0
16
28
1
11 0
16
83
2
23 13
5 0
6
11
29
1
19 0
11
84
2
23 8
2 0
13
30
1
21 0
13
85
2
23 10
18 0
17
31
1
16 0
17
86
2
23 14
12 0
8
7
32
1
14 0
7
87
2
23 4
8 0
12
33
1
15 0
12
88
2
23 9
19 0
14
34
1
18 0
14
89
2
23 11
7 0
18
35
1
20 0
18
90
2
23 15
13 0
6
8
36
1
10 0
13
37
1
21 0
13
91
2
23 10
15 0
15
38
1
7 0
19
39
1
17 0
19
92
2
23 16
6 0
4
9
40
1
3 0
14
41
1
18 0
14
93
2
23 11
21 0
20
42
1
4 0
5
11
43
1
19 0
11
94
2
23 8
9 0
17
44
1
16 0
17
95
2
23 14
20 0
21
45
1
5 0
5
12
46
1
15 0
16
47
1
11 0
18
48
1
20 0
18
96
2
23 15
17 0
22
49
1
12 0
7
13
50
1
21 0
13
97
2
23 10
14 0
17
51
1
16 0
17
98
2
23 14
11 0
19
52
1
17 0
19
99
2
23 16
4 0
23
53
1
13 0
6
14
54
1
18 0
14
100
2
23 11
10 0
18
55
1
20 0
18
101
2
23 15
16 0
20
56
1
4 0
24
57
1
6 0
4
15
58
1
7 0
15
102
2
23 12
3 0
19
59
1
17 0
19
103
2
23 16
20 0
4
16
60
1
11 0
16
104
2
23 13
19 0
22
61
1
12 0
22
105
2
23 19
13 0
5
17
62
1
16 0
17
106
2
23 14
15 0
21
63
1
5 0
23
64
1
13 0
23
107
2
23 20
6 0
5
18
65
1
20 0
18
108
2
23 15
21 0
22
66
1
12 0
22
109
2
23 19
5 0
24
67
1
6 0
4
19
68
1
17 0
19
110
2
23 16
18 0
23
69
1
13 0
23
111
2
23 20
12 0
end_DTG
begin_DTG
0
0
2
0
74
2
22 7
0 0
4
70
2
22 1
14 0
2
1
81
2
22 11
1 0
8
71
2
22 3
19 0
2
2
87
2
22 13
8 0
10
72
2
22 4
21 0
2
4
78
2
22 9
14 0
6
75
2
22 7
3 0
0
0
4
3
94
2
22 16
9 0
7
84
2
22 12
2 0
9
80
2
22 10
15 0
13
73
2
22 6
11 0
2
8
88
2
22 13
19 0
10
82
2
22 11
21 0
4
4
97
2
22 18
14 0
9
91
2
22 14
15 0
11
85
2
22 12
18 0
15
76
2
22 7
20 0
4
5
100
2
22 19
10 0
10
93
2
22 15
21 0
12
89
2
22 13
7 0
16
77
2
22 8
17 0
2
6
102
2
22 20
3 0
17
79
2
22 9
4 0
2
8
104
2
22 21
19 0
18
83
2
22 11
5 0
4
9
106
2
22 22
15 0
13
98
2
22 18
11 0
15
95
2
22 16
20 0
19
86
2
22 12
12 0
4
10
108
2
22 23
21 0
14
101
2
22 19
16 0
16
96
2
22 17
17 0
20
90
2
22 13
13 0
4
11
110
2
22 24
18 0
15
103
2
22 20
20 0
17
99
2
22 18
4 0
21
92
2
22 14
6 0
0
0
2
18
109
2
22 23
5 0
20
105
2
22 21
13 0
2
19
111
2
22 24
12 0
21
107
2
22 22
6 0
0
end_DTG
begin_CG
3
23 1
22 2
8 1
3
23 1
22 3
9 1
3
23 1
22 3
19 1
4
23 2
22 4
10 1
7 1
4
23 2
22 4
7 1
17 1
4
23 2
22 4
11 1
12 1
4
23 2
22 4
17 1
13 1
3
23 1
22 4
18 1
3
23 1
22 3
14 1
3
23 1
22 4
19 1
3
23 1
22 4
18 1
4
23 2
22 5
19 1
16 1
4
23 2
22 5
16 1
13 1
4
23 2
22 5
20 1
12 1
5
23 3
22 6
8 1
10 1
21 1
5
23 3
22 6
19 1
21 1
16 1
3
23 1
22 5
20 1
4
23 2
22 6
18 1
20 1
4
23 2
22 6
21 1
17 1
5
23 3
22 7
9 1
15 1
11 1
5
23 3
22 7
21 1
16 1
17 1
6
23 4
22 8
14 1
15 1
18 1
20 1
23
23 42
0 1
1 1
8 3
9 3
14 5
10 3
3 2
2 1
19 7
15 5
21 8
18 6
7 3
11 4
16 5
20 7
17 6
4 2
5 2
12 4
13 4
6 2
23
22 42
0 1
1 1
8 3
9 3
14 5
10 3
3 2
2 1
19 7
15 5
21 8
18 6
7 3
11 4
16 5
20 7
17 6
4 2
5 2
12 4
13 4
6 2
end_CG
