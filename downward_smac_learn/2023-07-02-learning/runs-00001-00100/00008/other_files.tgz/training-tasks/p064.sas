begin_version
3
end_version
begin_metric
0
end_metric
62
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var3
-1
60
Atom at-robot(loc_10_10)
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




345
2
58 27
20 0
27
240
2
58 12
31 0
0
4
14
354
2
58 28
43 0
21
309
2
58 23
8 0
23
297
2
58 21
50 0
28
249
2
58 14
28 0
4
15
360
2
58 29
37 0
22
321
2
58 24
51 0
24
303
2
58 22
39 0
29
258
2
58 15
25 0
2
23
330
2
58 25
50 0
25
312
2
58 23
52 0
4
17
366
2
58 30
53 0
24
339
2
58 26
39 0
26
324
2
58 24
38 0
30
273
2
58 17
40 0
2
18
375
2
58 31
49 0
31
282
2
58 18
45 0
2
20
387
2
58 33
23 0
33
291
2
58 20
29 0
2
22
396
2
58 35
51 0
35
306
2
58 22
46 0
2
23
405
2
58 36
50 0
36
315
2
58 23
47 0
2
25
423
2
58 38
52 0
38
333
2
58 25
54 0
4
26
432
2
58 39
38 0
30
384
2
58 32
40 0
32
369
2
58 30
17 0
39
342
2
58 26
41 0
2
27
378
2
58 31
31 0
31
348
2
58 27
45 0
2
27
441
2
58 40
31 0
40
351
2
58 27
34 0
0
4
28
450
2
58 41
28 0
34
408
2
58 36
4 0
36
393
2
58 34
47 0
41
357
2
58 28
35 0
4
29
459
2
58 42
25 0
35
414
2
58 37
46 0
37
399
2
58 35
42 0
42
363
2
58 29
24 0
2
36
426
2
58 38
47 0
38
411
2
58 36
54 0
4
30
474
2
58 44
40 0
37
435
2
58 39
42 0
39
417
2
58 37
41 0
44
372
2
58 30
56 0
2
31
483
2
58 45
45 0
45
381
2
58 31
57 0
2
33
501
2
58 47
29 0
47
390
2
58 33
33 0
2
35
510
2
58 49
46 0
48
402
2
58 35
22 0
2
41
465
2
58 43
35 0
43
453
2
58 41
55 0
4
37
516
2
58 50
42 0
42
477
2
58 44
24 0
44
462
2
58 42
56 0
49
420
2
58 37
32 0
4
38
525
2
58 51
54 0
43
486
2
58 45
55 0
45
468
2
58 43
57 0
50
429
2
58 38
27 0
4
39
531
2
58 52
41 0
44
495
2
58 46
56 0
46
480
2
58 44
26 0
51
438
2
58 39
48 0
2
40
489
2
58 45
34 0
45
444
2
58 40
57 0
2
40
543
2
58 54
34 0
53
447
2
58 40
19 0
2
41
549
2
58 55
35 0
54
456
2
58 41
12 0
2
43
552
2
58 57
55 0
55
471
2
58 43
15 0
2
49
534
2
58 52
32 0
51
519
2
58 50
48 0
4
45
555
2
58 58
57 0
50
540
2
58 53
27 0
52
528
2
58 51
36 0
56
492
2
58 45
9 0
4
46
561
2
58 59
26 0
47
537
2
58 52
33 0
51
504
2
58 47
48 0
57
498
2
58 46
14 0
2
0
507
2
58 47
0 0
47
180
2
58 0
33 0
2
1
513
2
58 49
5 0
48
186
2
58 1
22 0
2
3
522
2
58 50
18 0
49
195
2
58 3
32 0
0
2
53
558
2
58 58
19 0
56
546
2
58 54
9 0
end_DTG
begin_CG
5
59 1
60 1
61 1
58 4
19 3
5
59 1
60 1
61 1
58 4
18 3
5
59 1
60 1
61 1
58 5
10 3
5
59 1
60 1
61 1
58 5
43 3
5
59 1
60 1
61 1
58 4
46 3
6
59 2
60 2
61 2
58 8
11 3
12 3
6
59 2
60 2
61 2
58 8
13 3
20 3
6
59 2
60 2
61 2
58 8
21 3
44 3
6
59 2
60 2
61 2
58 8
10 3
51 3
6
59 2
60 2
61 2
58 8
48 3
14 3
5
59 1
60 1
61 1
58 6
43 3
5
59 1
60 1
61 1
58 6
18 3
5
59 1
60 1
61 1
58 6
22 3
5
59 1
60 1
61 1
58 6
30 3
5
59 1
60 1
61 1
58 6
36 3
5
59 1
60 1
61 1
58 6
32 3
5
59 1
60 1
61 1
58 6
49 3
5
59 1
60 1
61 1
58 5
45 3
6
59 2
60 2
61 2
58 9
11 3
15 3
6
59 2
60 2
61 2
58 9
33 3
14 3
6
59 2
60 2
61 2
58 9
16 3
23 3
6
59 2
60 2
61 2
58 9
30 3
53 3
6
59 2
60 2
61 2
58 9
35 3
12 3
6
59 2
60 2
61 2
58 8
20 3
31 3
6
59 2
60 2
61 2
58 9
47 3
55 3
6
59 2
60 2
61 2
58 9
50 3
47 3
6
59 2
60 2
61 2
58 9
57 3
36 3
6
59 2
60 2
61 2
58 9
56 3
48 3
6
59 2
60 2
61 2
58 9
51 3
46 3
6
59 2
60 2
61 2
58 8
31 3
34 3
7
59 3
60 3
61 3
58 12
21 3
13 3
49 3
7
59 3
60 3
61 3
58 12
23 3
17 3
29 3
7
59 3
60 3
61 3
58 12
55 3
27 3
15 3
7
59 3
60 3
61 3
58 12
34 3
36 3
19 3
7
59 3
60 3
61 3
58 12
29 3
26 3
33 3
7
59 3
60 3
61 3
58 12
46 3
24 3
22 3
5
59 1
60 1
61 1
58 7
48 3
7
59 3
60 3
61 3
58 12
43 3
44 3
50 3
7
59 3
60 3
61 3
58 12
49 3
52 3
45 3
7
59 3
60 3
61 3
58 12
44 3
50 3
52 3
7
59 3
60 3
61 3
58 12
52 3
45 3
54 3
7
59 3
60 3
61 3
58 12
45 3
54 3
57 3
7
59 3
60 3
61 3
58 12
47 3
54 3
55 3
6
59 2
60 2
61 2
58 10
37 3
51 3
6
59 2
60 2
61 2
58 10
37 3
53 3
7
59 3
60 3
61 3
58 13
38 3
17 3
41 3
7
59 3
60 3
61 3
58 13
28 3
47 3
35 3
7
59 3
60 3
61 3
58 13
25 3
46 3
42 3
7
59 3
60 3
61 3
58 13
57 3
27 3
36 3
7
59 3
60 3
61 3
58 13
53 3
16 3
38 3
7
59 3
60 3
61 3
58 13
51 3
39 3
25 3
7
59 3
60 3
61 3
58 13
43 3
50 3
28 3
7
59 3
60 3
61 3
58 13
53 3
39 3
40 3
7
59 3
60 3
61 3
58 13
44 3
49 3
52 3
7
59 3
60 3
61 3
58 13
40 3
42 3
56 3
7
59 3
60 3
61 3
58 13
24 3
56 3
32 3
7
59 3
60 3
61 3
58 13
54 3
55 3
57 3
8
59 4
60 4
61 4
58 16
41 3
56 3
26 3
48 3
61
59 128
60 128
61 128
0 3
5 6
11 9
18 12
1 3
6 6
2 3
3 3
7 6
21 12
30 15
13 9
20 12
10 9
43 18
37 15
44 18
53 21
49 21
16 9
23 12
8 6
51 21
50 21
39 15
52 21
38 15
31 15
28 12
25 12
40 15
45 21
17 9
29 12
4 3
46 21
47 21
42 15
54 21
41 15
34 15
35 15
24 12
55 21
56 21
57 24
26 12
33 15
22 12
32 15
27 12
48 21
36 15
19 12
12 9
15 9
9 6
14 9
59
58 128
0 1
5 2
11 3
18 4
1 1
6 2
2 1
3 1
7 2
21 4
30 5
13 3
20 4
10 3
43 6
37 5
44 6
53 7
49 7
16 3
23 4
8 2
51 7
50 7
39 5
52 7
38 5
31 5
28 4
25 4
40 5
45 7
17 3
29 4
4 1
46 7
47 7
42 5
54 7
41 5
34 5
35 5
24 4
55 7
56 7
57 8
26 4
33 5
22 4
32 5
27 4
48 7
36 5
19 4
12 3
15 3
9 2
14 3
59
58 128
0 1
5 2
11 3
18 4
1 1
6 2
2 1
3 1
7 2
21 4
30 5
13 3
20 4
10 3
43 6
37 5
44 6
53 7
49 7
16 3
23 4
8 2
51 7
50 7
39 5
52 7
38 5
31 5
28 4
25 4
40 5
45 7
17 3
29 4
4 1
46 7
47 7
42 5
54 7
41 5
34 5
35 5
24 4
55 7
56 7
57 8
26 4
33 5
22 4
32 5
27 4
48 7
36 5
19 4
12 3
15 3
9 2
14 3
59
58 128
0 1
5 2
11 3
18 4
1 1
6 2
2 1
3 1
7 2
21 4
30 5
13 3
20 4
10 3
43 6
37 5
44 6
53 7
49 7
16 3
23 4
8 2
51 7
50 7
39 5
52 7
38 5
31 5
28 4
25 4
40 5
45 7
17 3
29 4
4 1
46 7
47 7
42 5
54 7
41 5
34 5
35 5
24 4
55 7
56 7
57 8
26 4
33 5
22 4
32 5
27 4
48 7
36 5
19 4
12 3
15 3
9 2
14 3
end_CG
