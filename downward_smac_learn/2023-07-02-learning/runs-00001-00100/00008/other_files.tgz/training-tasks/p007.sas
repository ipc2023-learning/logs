begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var2
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
24
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
end_variable
begin_variable
var0
-1
24
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
end_variable
24
begin_mutex_group
2
25 0
0 0
end_mutex_group
begin_mutex_group
2
25 1
4 0
end_mutex_group
begin_mutex_group
2
25 2
7 0
end_mutex_group
begin_mutex_group
2
25 3
6 0
end_mutex_group
begin_mutex_group
2
25 4
1 0
end_mutex_group
begin_mutex_group
2
25 5
5 0
end_mutex_group
begin_mutex_group
2
25 6
20 0
end_mutex_group
begin_mutex_group
2
25 7
16 0
end_mutex_group
begin_mutex_group
2
25 8
22 0
end_mutex_group
begin_mutex_group
2
25 9
8 0
end_mutex_group
begin_mutex_group
2
25 10
10 0
end_mutex_group
begin_mutex_group
2
25 11
17 0
end_mutex_group
begin_mutex_group
2
25 12
19 0
end_mutex_group
begin_mutex_group
2
25 13
13 0
end_mutex_group
begin_mutex_group
2
25 14
9 0
end_mutex_group
begin_mutex_group
2
25 15
21 0
end_mutex_group
begin_mutex_group
2
25 16
18 0
end_mutex_group
begin_mutex_group
2
25 17
23 0
end_mutex_group
begin_mutex_group
2
25 18
12 0
end_mutex_group
begin_mutex_group
2
25 19
2 0
end_mutex_group
begin_mutex_group
2
25 20
11 0
end_mutex_group
begin_mutex_group
2
25 21
15 0
end_mutex_group
begin_mutex_group
2
25 22
14 0
end_mutex_group
begin_mutex_group
2
25 23
3 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
13
12
end_state
begin_goal
1
25 10
end_goal
120
begin_operator
move loc_2_2 loc_2_3 right
1
4 0
1
0 24 0 1
0
end_operator
begin_operator
move loc_2_2 loc_3_2 down
1
5 0
1
0 24 0 5
0
end_operator
begin_operator
move loc_2_3 loc_2_2 left
1
0 0
1
0 24 1 0
0
end_operator
begin_operator
move loc_2_3 loc_2_4 right
1
7 0
1
0 24 1 2
0
end_operator
begin_operator
move loc_2_3 loc_3_3 down
1
20 0
1
0 24 1 6
0
end_operator
begin_operator
move loc_2_4 loc_2_3 left
1
4 0
1
0 24 2 1
0
end_operator
begin_operator
move loc_2_4 loc_2_5 right
1
6 0
1
0 24 2 3
0
end_operator
begin_operator
move loc_2_4 loc_3_4 down
1
16 0
1
0 24 2 7
0
end_operator
begin_operator
mo




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5 10
24 14
5 0
end_DTG
begin_DTG
2
1
95
2
25 15
24 11
1
117
2
25 21
24 22
2
0
111
3
25 20
24 19
15 0
0
114
3
25 20
24 21
2 0
end_DTG
begin_DTG
2
1
91
2
25 13
24 9
1
105
2
25 17
24 16
2
0
99
3
25 18
24 13
3 0
0
118
3
25 18
24 23
13 0
end_DTG
begin_DTG
2
1
81
2
25 9
24 4
1
118
2
25 18
24 23
2
0
91
3
25 13
24 9
12 0
0
108
3
25 13
24 18
8 0
end_DTG
begin_DTG
2
1
97
2
25 17
24 12
1
113
2
25 21
24 20
2
0
115
3
25 22
24 21
3 0
0
119
3
25 22
24 23
15 0
end_DTG
begin_DTG
2
1
111
2
25 20
24 19
1
119
2
25 22
24 23
2
0
113
3
25 21
24 20
14 0
0
117
3
25 21
24 22
11 0
end_DTG
begin_DTG
2
1
82
2
25 6
24 5
1
90
2
25 8
24 9
2
0
84
3
25 7
24 6
22 0
0
88
3
25 7
24 8
20 0
end_DTG
begin_DTG
2
1
75
2
25 6
24 1
1
112
2
25 15
24 20
2
0
85
3
25 11
24 6
21 0
0
102
3
25 11
24 15
20 0
end_DTG
begin_DTG
2
1
101
2
25 15
24 14
1
109
2
25 17
24 18
2
0
103
3
25 16
24 15
23 0
0
107
3
25 16
24 17
21 0
end_DTG
begin_DTG
2
1
79
2
25 8
24 3
1
116
2
25 17
24 22
2
0
89
3
25 12
24 8
23 0
0
106
3
25 12
24 17
22 0
end_DTG
begin_DTG
2
1
88
2
25 7
24 8
1
102
2
25 11
24 15
4
0
75
3
25 6
24 1
17 0
0
82
3
25 6
24 5
16 0
0
86
3
25 6
24 7
5 0
0
94
3
25 6
24 11
4 0
end_DTG
begin_DTG
2
1
85
2
25 11
24 6
1
107
2
25 16
24 17
4
0
95
3
25 15
24 11
11 0
0
101
3
25 15
24 14
18 0
0
104
3
25 15
24 16
9 0
0
112
3
25 15
24 20
17 0
end_DTG
begin_DTG
2
1
84
2
25 7
24 6
1
106
2
25 12
24 17
4
0
79
3
25 8
24 3
19 0
0
87
3
25 8
24 7
8 0
0
90
3
25 8
24 9
16 0
0
96
3
25 8
24 12
6 0
end_DTG
begin_DTG
2
1
89
2
25 12
24 8
1
103
2
25 16
24 15
4
0
97
3
25 17
24 12
14 0
0
105
3
25 17
24 16
12 0
0
109
3
25 17
24 18
18 0
0
116
3
25 17
24 22
19 0
end_DTG
begin_DTG
4
1
0
1
4 0
1
72
2
25 1
7 0
5
1
1
5 0
5
73
2
25 5
10 0
5
0
2
1
0 0
2
3
1
7 0
2
74
2
25 2
6 0
6
4
1
20 0
6
75
2
25 6
17 0
5
1
5
1
4 0
1
76
2
25 1
0 0
3
6
1
6 0
3
77
2
25 3
1 0
7
7
1
16 0
5
2
8
1
7 0
2
78
2
25 2
4 0
4
9
1
1 0
8
10
1
22 0
8
79
2
25 8
19 0
4
3
11
1
6 0
3
80
2
25 3
7 0
9
12
1
8 0
9
81
2
25 9
13 0
5
0
13
1
0 0
6
14
1
20 0
6
82
2
25 6
16 0
10
15
1
10 0
10
83
2
25 10
9 0
6
1
16
1
4 0
5
17
1
5 0
7
18
1
16 0
7
84
2
25 7
22 0
11
19
1
17 0
11
85
2
25 11
21 0
5
2
20
1
7 0
6
21
1
20 0
6
86
2
25 6
5 0
8
22
1
22 0
8
87
2
25 8
8 0
6
3
23
1
6 0
7
24
1
16 0
7
88
2
25 7
20 0
9
25
1
8 0
12
26
1
19 0
12
89
2
25 12
23 0
5
4
27
1
1 0
8
28
1
22 0
8
90
2
25 8
16 0
13
29
1
13 0
13
91
2
25 13
12 0
5
5
30
1
5 0
5
92
2
25 5
0 0
11
31
1
17 0
14
32
1
9 0
14
93
2
25 14
2 0
5
6
33
1
20 0
6
94
2
25 6
4 0
10
34
1
10 0
15
35
1
21 0
15
95
2
25 15
11 0
5
8
36
1
22 0
8
96
2
25 8
6 0
13
37
1
13 0
17
38
1
23 0
17
97
2
25 17
14 0
5
9
39
1
8 0
9
98
2
25 9
1 0
12
40
1
19 0
18
41
1
12 0
18
99
2
25 18
3 0
5
10
42
1
10 0
10
100
2
25 10
5 0
15
43
1
21 0
15
101
2
25 15
18 0
19
44
1
2 0
6
11
45
1
17 0
11
102
2
25 11
20 0
14
46
1
9 0
16
47
1
18 0
16
103
2
25 16
23 0
20
48
1
11 0
5
15
49
1
21 0
15
104
2
25 15
9 0
17
50
1
23 0
17
105
2
25 17
12 0
21
51
1
15 0
6
12
52
1
19 0
12
106
2
25 12
22 0
16
53
1
18 0
16
107
2
25 16
21 0
18
54
1
12 0
22
55
1
14 0
5
13
56
1
13 0
13
108
2
25 13
8 0
17
57
1
23 0
17
109
2
25 17
18 0
23
58
1
3 0
4
14
59
1
9 0
14
110
2
25 14
10 0
20
60
1
11 0
20
111
2
25 20
15 0
5
15
61
1
21 0
15
112
2
25 15
17 0
19
62
1
2 0
21
63
1
15 0
21
113
2
25 21
14 0
5
16
64
1
18 0
20
65
1
11 0
20
114
2
25 20
2 0
22
66
1
14 0
22
115
2
25 22
3 0
5
17
67
1
23 0
17
116
2
25 17
19 0
21
68
1
15 0
21
117
2
25 21
11 0
23
69
1
3 0
4
18
70
1
12 0
18
118
2
25 18
13 0
22
71
1
14 0
22
119
2
25 22
15 0
end_DTG
begin_DTG
0
2
0
76
2
24 2
0 0
2
72
2
24 0
7 0
2
1
78
2
24 3
4 0
3
74
2
24 1
6 0
2
2
80
2
24 4
7 0
4
77
2
24 2
1 0
0
2
0
92
2
24 10
0 0
10
73
2
24 0
10 0
4
1
94
2
24 11
4 0
5
86
2
24 7
5 0
7
82
2
24 5
16 0
11
75
2
24 1
17 0
2
6
88
2
24 8
20 0
8
84
2
24 6
22 0
4
3
96
2
24 12
6 0
7
90
2
24 9
16 0
9
87
2
24 7
8 0
12
79
2
24 3
19 0
2
4
98
2
24 13
1 0
13
81
2
24 4
13 0
2
5
100
2
24 14
5 0
14
83
2
24 5
9 0
2
6
102
2
24 15
20 0
15
85
2
24 6
21 0
2
8
106
2
24 17
22 0
17
89
2
24 8
23 0
2
9
108
2
24 18
8 0
18
91
2
24 9
12 0
2
10
110
2
24 19
10 0
19
93
2
24 10
2 0
4
11
112
2
24 20
17 0
14
104
2
24 16
9 0
16
101
2
24 14
18 0
20
95
2
24 11
11 0
2
15
107
2
24 17
21 0
17
103
2
24 15
23 0
4
12
116
2
24 22
19 0
16
109
2
24 18
18 0
18
105
2
24 16
12 0
22
97
2
24 12
14 0
2
13
118
2
24 23
13 0
23
99
2
24 13
3 0
0
2
19
114
2
24 21
2 0
21
111
2
24 19
15 0
2
20
117
2
24 22
11 0
22
113
2
24 20
14 0
2
21
119
2
24 23
15 0
23
115
2
24 21
3 0
0
end_DTG
begin_CG
4
25 2
24 4
4 1
5 1
4
25 2
24 4
6 1
8 1
4
25 2
24 4
9 1
11 1
4
25 2
24 4
12 1
14 1
4
25 2
24 5
7 1
20 1
4
25 2
24 5
20 1
10 1
4
25 2
24 5
7 1
22 1
4
25 2
24 5
4 1
6 1
4
25 2
24 5
22 1
13 1
4
25 2
24 5
10 1
21 1
4
25 2
24 5
5 1
9 1
4
25 2
24 5
21 1
15 1
4
25 2
24 5
13 1
23 1
4
25 2
24 5
8 1
12 1
4
25 2
24 5
23 1
15 1
4
25 2
24 5
11 1
14 1
4
25 2
24 5
20 1
22 1
4
25 2
24 5
20 1
21 1
4
25 2
24 5
21 1
23 1
4
25 2
24 5
22 1
23 1
4
25 2
24 6
16 1
17 1
4
25 2
24 6
17 1
18 1
4
25 2
24 6
16 1
19 1
4
25 2
24 6
19 1
18 1
25
25 48
0 2
4 4
7 4
6 4
1 2
5 4
20 6
16 4
22 6
8 4
10 4
17 4
19 4
13 4
9 4
21 6
18 4
23 6
12 4
2 2
11 4
15 4
14 4
3 2
25
24 48
0 2
4 4
7 4
6 4
1 2
5 4
20 6
16 4
22 6
8 4
10 4
17 4
19 4
13 4
9 4
21 6
18 4
23 6
12 4
2 2
11 4
15 4
14 4
3 2
end_CG
