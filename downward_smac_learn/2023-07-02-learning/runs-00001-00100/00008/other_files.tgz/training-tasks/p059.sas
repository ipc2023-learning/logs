begin_version
3
end_version
begin_metric
0
end_metric
58
begin_variable
var8
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var3
-1
58
Atom at-robot(loc_10_2)
Atom at-robot(loc_10_3)
Atom at-robot(loc_10_4)
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_7)
Atom at-robot(loc_10_9)
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_10)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom a




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




54 54
39 0
2
51
460
2
54 57
49 0
53
451
2
54 55
40 0
4
5
406
2
54 48
1 0
44
184
2
54 5
29 0
45
457
2
54 56
13 0
52
412
2
54 49
39 0
end_DTG
begin_DTG
0
2
0
170
2
54 2
10 0
2
158
2
54 0
27 0
2
1
176
2
54 3
26 0
3
164
2
54 1
11 0
0
0
0
0
2
6
194
2
54 8
2 0
8
188
2
54 6
3 0
0
0
2
7
224
2
54 19
14 0
15
191
2
54 7
32 0
2
10
209
2
54 14
28 0
12
200
2
54 12
25 0
2
11
215
2
54 15
18 0
13
206
2
54 13
24 0
2
9
233
2
54 21
4 0
17
197
2
54 9
20 0
0
2
10
242
2
54 24
28 0
20
203
2
54 12
48 0
2
12
257
2
54 26
25 0
22
212
2
54 14
51 0
2
13
269
2
54 27
24 0
23
218
2
54 15
41 0
2
14
284
2
54 29
5 0
25
221
2
54 16
23 0
0
4
15
293
2
54 31
32 0
19
251
2
54 25
6 0
21
239
2
54 23
35 0
27
227
2
54 19
47 0
2
20
260
2
54 26
48 0
22
245
2
54 24
51 0
4
16
305
2
54 33
19 0
21
272
2
54 27
35 0
23
254
2
54 25
41 0
29
230
2
54 20
42 0
2
22
278
2
54 28
51 0
24
263
2
54 26
31 0
2
23
287
2
54 29
41 0
25
275
2
54 27
23 0
2
18
317
2
54 35
17 0
31
236
2
54 22
8 0
0
4
20
323
2
54 37
48 0
26
302
2
54 32
7 0
28
290
2
54 30
22 0
33
248
2
54 24
34 0
2
27
308
2
54 33
47 0
29
296
2
54 31
42 0
2
22
329
2
54 38
51 0
34
266
2
54 26
37 0
2
24
335
2
54 39
31 0
35
281
2
54 28
30 0
0
0
2
27
350
2
54 42
47 0
38
299
2
54 31
46 0
2
29
368
2
54 44
42 0
40
311
2
54 33
53 0
2
30
386
2
54 46
21 0
42
314
2
54 34
52 0
2
32
410
2
54 49
9 0
45
320
2
54 36
13 0
0
4
33
419
2
54 51
34 0
37
359
2
54 43
12 0
39
344
2
54 41
43 0
47
326
2
54 37
44 0
2
38
371
2
54 44
46 0
40
353
2
54 42
53 0
4
34
431
2
54 53
37 0
39
380
2
54 45
43 0
41
362
2
54 43
36 0
49
332
2
54 38
50 0
2
40
389
2
54 46
53 0
42
374
2
54 44
52 0
4
35
446
2
54 55
30 0
41
398
2
54 47
36 0
43
383
2
54 45
33 0
51
338
2
54 39
49 0
2
42
404
2
54 48
52 0
44
392
2
54 46
29 0
2
36
401
2
54 47
16 0
43
341
2
54 40
33 0
0
2
0
347
2
54 41
10 0
37
161
2
54 0
12 0
4
1
356
2
54 42
26 0
38
167
2
54 1
46 0
46
425
2
54 52
15 0
48
416
2
54 50
45 0
4
2
365
2
54 43
27 0
39
173
2
54 2
43 0
47
434
2
54 53
44 0
49
422
2
54 51
50 0
4
3
377
2
54 44
11 0
40
179
2
54 3
53 0
48
440
2
54 54
45 0
50
428
2
54 52
38 0
2
49
449
2
54 55
50 0
51
437
2
54 53
49 0
4
4
395
2
54 46
0 0
42
182
2
54 4
52 0
50
455
2
54 56
38 0
52
443
2
54 54
39 0
2
51
461
2
54 57
49 0
53
452
2
54 55
40 0
4
5
407
2
54 48
1 0
44
185
2
54 5
29 0
45
458
2
54 56
13 0
52
413
2
54 49
39 0
end_DTG
begin_CG
5
55 1
56 1
57 1
54 4
49 3
5
55 1
56 1
57 1
54 4
40 3
5
55 1
56 1
57 1
54 4
14 3
5
55 1
56 1
57 1
54 5
14 3
5
55 1
56 1
57 1
54 4
24 3
5
55 1
56 1
57 1
54 5
17 3
5
55 1
56 1
57 1
54 5
48 3
5
55 1
56 1
57 1
54 5
47 3
5
55 1
56 1
57 1
54 5
23 3
5
55 1
56 1
57 1
54 4
16 3
6
55 2
56 2
57 2
54 8
26 3
15 3
6
55 2
56 2
57 2
54 8
27 3
50 3
6
55 2
56 2
57 2
54 8
46 3
15 3
6
55 2
56 2
57 2
54 8
16 3
40 3
5
55 1
56 1
57 1
54 6
28 3
5
55 1
56 1
57 1
54 6
44 3
5
55 1
56 1
57 1
54 6
29 3
5
55 1
56 1
57 1
54 5
23 3
5
55 1
56 1
57 1
54 6
25 3
5
55 1
56 1
57 1
54 6
51 3
5
55 1
56 1
57 1
54 6
24 3
5
55 1
56 1
57 1
54 6
30 3
5
55 1
56 1
57 1
54 6
47 3
6
55 2
56 2
57 2
54 9
17 3
31 3
6
55 2
56 2
57 2
54 9
25 3
20 3
6
55 2
56 2
57 2
54 9
18 3
19 3
6
55 2
56 2
57 2
54 9
27 3
44 3
6
55 2
56 2
57 2
54 9
26 3
45 3
6
55 2
56 2
57 2
54 9
18 3
32 3
6
55 2
56 2
57 2
54 9
33 3
40 3
6
55 2
56 2
57 2
54 8
21 3
52 3
6
55 2
56 2
57 2
54 9
41 3
21 3
6
55 2
56 2
57 2
54 8
28 3
48 3
6
55 2
56 2
57 2
54 9
52 3
29 3
6
55 2
56 2
57 2
54 8
47 3
46 3
6
55 2
56 2
57 2
54 9
48 3
51 3
6
55 2
56 2
57 2
54 9
53 3
52 3
6
55 2
56 2
57 2
54 8
42 3
53 3
6
55 2
56 2
57 2
54 9
50 3
49 3
6
55 2
56 2
57 2
54 9
49 3
40 3
5
55 1
56 1
57 1
54 7
39 3
7
55 3
56 3
57 3
54 12
20 3
51 3
31 3
7
55 3
56 3
57 3
54 12
51 3
22 3
37 3
7
55 3
56 3
57 3
54 12
46 3
53 3
45 3
6
55 2
56 2
57 2
54 10
46 3
45 3
6
55 2
56 2
57 2
54 10
44 3
50 3
7
55 3
56 3
57 3
54 13
34 3
43 3
44 3
7
55 3
56 3
57 3
54 13
48 3
22 3
34 3
7
55 3
56 3
57 3
54 13
32 3
35 3
47 3
7
55 3
56 3
57 3
54 13
52 3
38 3
39 3
7
55 3
56 3
57 3
54 13
53 3
45 3
38 3
8
55 4
56 4
57 4
54 16
19 3
35 3
41 3
42 3
8
55 4
56 4
57 4
54 16
30 3
36 3
33 3
49 3
8
55 4
56 4
57 4
54 16
37 3
43 3
36 3
50 3
57
55 102
56 102
57 102
10 6
26 12
27 12
11 6
0 3
1 3
2 3
14 9
3 3
4 3
28 12
18 9
25 12
24 12
5 3
32 12
19 9
20 9
17 9
6 3
48 21
35 12
51 24
41 15
31 12
23 12
7 3
47 21
22 9
42 15
21 9
8 3
9 3
34 12
37 12
30 12
16 9
12 6
46 21
43 15
53 24
36 12
52 24
33 12
29 12
13 6
15 9
44 18
45 18
50 21
38 12
49 21
39 12
40 15
55
54 102
10 2
26 4
27 4
11 2
0 1
1 1
2 1
14 3
3 1
4 1
28 4
18 3
25 4
24 4
5 1
32 4
19 3
20 3
17 3
6 1
48 7
35 4
51 8
41 5
31 4
23 4
7 1
47 7
22 3
42 5
21 3
8 1
9 1
34 4
37 4
30 4
16 3
12 2
46 7
43 5
53 8
36 4
52 8
33 4
29 4
13 2
15 3
44 6
45 6
50 7
38 4
49 7
39 4
40 5
55
54 102
10 2
26 4
27 4
11 2
0 1
1 1
2 1
14 3
3 1
4 1
28 4
18 3
25 4
24 4
5 1
32 4
19 3
20 3
17 3
6 1
48 7
35 4
51 8
41 5
31 4
23 4
7 1
47 7
22 3
42 5
21 3
8 1
9 1
34 4
37 4
30 4
16 3
12 2
46 7
43 5
53 8
36 4
52 8
33 4
29 4
13 2
15 3
44 6
45 6
50 7
38 4
49 7
39 4
40 5
55
54 102
10 2
26 4
27 4
11 2
0 1
1 1
2 1
14 3
3 1
4 1
28 4
18 3
25 4
24 4
5 1
32 4
19 3
20 3
17 3
6 1
48 7
35 4
51 8
41 5
31 4
23 4
7 1
47 7
22 3
42 5
21 3
8 1
9 1
34 4
37 4
30 4
16 3
12 2
46 7
43 5
53 8
36 4
52 8
33 4
29 4
13 2
15 3
44 6
45 6
50 7
38 4
49 7
39 4
40 5
end_CG
