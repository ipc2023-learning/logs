begin_version
3
end_version
begin_metric
0
end_metric
60
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var3
-1
59
Atom at-robot(loc_10_10)
Atom at-robot(loc_10_7)
Atom at-robot(loc_10_8)
Atom at-robot(loc_11_7)
Atom at-robot(loc_11_8)
Atom at-robot(loc_11_9)
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




56 22
47 0
30
256
2
56 19
53 0
4
18
364
2
56 33
32 0
21
304
2
56 25
41 0
23
286
2
56 23
29 0
31
265
2
56 20
55 0
2
22
313
2
56 26
47 0
24
298
2
56 24
26 0
2
19
307
2
56 25
22 0
23
268
2
56 21
29 0
4
19
394
2
56 36
22 0
26
385
2
56 35
9 0
33
328
2
56 28
43 0
34
271
2
56 21
39 0
0
0
2
27
343
2
56 31
6 0
29
334
2
56 29
46 0
4
20
418
2
56 41
30 0
28
355
2
56 32
17 0
30
337
2
56 30
53 0
39
280
2
56 22
40 0
4
21
427
2
56 42
41 0
29
367
2
56 33
46 0
31
346
2
56 31
55 0
40
289
2
56 23
52 0
4
22
439
2
56 43
47 0
30
376
2
56 34
53 0
32
358
2
56 32
44 0
41
301
2
56 24
54 0
4
23
451
2
56 44
29 0
31
388
2
56 35
55 0
33
370
2
56 33
43 0
42
310
2
56 25
51 0
4
24
463
2
56 45
26 0
25
379
2
56 34
38 0
32
322
2
56 27
44 0
43
316
2
56 26
48 0
4
25
475
2
56 46
38 0
35
466
2
56 45
14 0
43
403
2
56 37
48 0
44
325
2
56 27
37 0
2
26
484
2
56 47
9 0
45
331
2
56 28
10 0
0
2
36
412
2
56 40
7 0
38
406
2
56 38
24 0
2
37
421
2
56 41
18 0
39
409
2
56 39
40 0
4
29
490
2
56 49
46 0
38
430
2
56 42
24 0
40
415
2
56 40
52 0
46
349
2
56 31
11 0
4
30
496
2
56 50
53 0
39
442
2
56 43
40 0
41
424
2
56 41
54 0
47
361
2
56 32
34 0
4
31
502
2
56 51
55 0
40
454
2
56 44
52 0
42
433
2
56 42
51 0
48
373
2
56 33
49 0
4
32
514
2
56 52
44 0
41
469
2
56 45
54 0
43
445
2
56 43
48 0
49
382
2
56 34
50 0
4
33
526
2
56 53
43 0
34
457
2
56 44
39 0
42
397
2
56 36
51 0
50
391
2
56 35
42 0
4
34
535
2
56 54
39 0
45
529
2
56 53
10 0
50
487
2
56 47
42 0
51
400
2
56 36
21 0
0
0
4
40
541
2
56 55
52 0
46
505
2
56 51
11 0
48
493
2
56 49
49 0
52
436
2
56 42
12 0
4
41
550
2
56 56
54 0
47
517
2
56 52
34 0
49
499
2
56 50
50 0
53
448
2
56 43
36 0
4
42
559
2
56 57
51 0
48
532
2
56 53
49 0
50
508
2
56 51
42 0
54
460
2
56 44
45 0
4
43
568
2
56 58
48 0
44
520
2
56 52
37 0
49
478
2
56 46
50 0
55
472
2
56 45
25 0
2
0
481
2
56 46
0 0
44
178
2
56 0
37 0
0
4
1
511
2
56 51
19 0
48
181
2
56 1
49 0
52
562
2
56 57
12 0
54
544
2
56 55
45 0
4
2
523
2
56 52
20 0
49
184
2
56 2
50 0
53
571
2
56 58
36 0
55
553
2
56 56
25 0
2
51
565
2
56 57
21 0
54
538
2
56 54
45 0
end_DTG
begin_CG
5
57 1
58 1
59 1
56 4
21 3
5
57 1
58 1
59 1
56 4
13 3
5
57 1
58 1
59 1
56 4
35 3
5
57 1
58 1
59 1
56 5
15 3
5
57 1
58 1
59 1
56 4
16 3
5
57 1
58 1
59 1
56 4
22 3
5
57 1
58 1
59 1
56 5
17 3
5
57 1
58 1
59 1
56 5
18 3
6
57 2
58 2
59 2
56 8
19 3
13 3
6
57 2
58 2
59 2
56 8
38 3
14 3
6
57 2
58 2
59 2
56 8
14 3
37 3
6
57 2
58 2
59 2
56 8
40 3
34 3
6
57 2
58 2
59 2
56 8
34 3
36 3
5
57 1
58 1
59 1
56 6
20 3
5
57 1
58 1
59 1
56 6
39 3
5
57 1
58 1
59 1
56 6
23 3
5
57 1
58 1
59 1
56 5
35 3
5
57 1
58 1
59 1
56 6
46 3
5
57 1
58 1
59 1
56 6
24 3
5
57 1
58 1
59 1
56 6
36 3
5
57 1
58 1
59 1
56 6
45 3
6
57 2
58 2
59 2
56 9
37 3
25 3
6
57 2
58 2
59 2
56 9
26 3
38 3
6
57 2
58 2
59 2
56 8
15 3
28 3
6
57 2
58 2
59 2
56 9
18 3
40 3
6
57 2
58 2
59 2
56 9
42 3
45 3
6
57 2
58 2
59 2
56 9
29 3
43 3
6
57 2
58 2
59 2
56 9
33 3
30 3
7
57 3
58 3
59 3
56 12
23 3
31 3
27 3
7
57 3
58 3
59 3
56 12
47 3
26 3
44 3
7
57 3
58 3
59 3
56 12
27 3
41 3
46 3
7
57 3
58 3
59 3
56 12
28 3
35 3
33 3
7
57 3
58 3
59 3
56 12
35 3
33 3
47 3
5
57 1
58 1
59 1
56 7
41 3
6
57 2
58 2
59 2
56 10
52 3
49 3
7
57 3
58 3
59 3
56 13
31 3
16 3
32 3
7
57 3
58 3
59 3
56 13
19 3
49 3
45 3
7
57 3
58 3
59 3
56 13
39 3
42 3
21 3
7
57 3
58 3
59 3
56 13
22 3
43 3
39 3
7
57 3
58 3
59 3
56 13
38 3
48 3
37 3
7
57 3
58 3
59 3
56 13
46 3
24 3
52 3
7
57 3
58 3
59 3
56 13
33 3
47 3
53 3
7
57 3
58 3
59 3
56 13
48 3
37 3
50 3
7
57 3
58 3
59 3
56 13
38 3
44 3
48 3
7
57 3
58 3
59 3
56 13
55 3
43 3
51 3
8
57 4
58 4
59 4
56 16
20 3
50 3
36 3
25 3
8
57 4
58 4
59 4
56 16
30 3
17 3
53 3
40 3
8
57 4
58 4
59 4
56 16
32 3
41 3
29 3
55 3
8
57 4
58 4
59 4
56 16
43 3
39 3
51 3
42 3
8
57 4
58 4
59 4
56 16
54 3
34 3
50 3
36 3
8
57 4
58 4
59 4
56 16
51 3
49 3
42 3
45 3
8
57 4
58 4
59 4
56 16
44 3
54 3
48 3
50 3
8
57 4
58 4
59 4
56 16
53 3
40 3
54 3
34 3
8
57 4
58 4
59 4
56 16
41 3
46 3
55 3
52 3
8
57 4
58 4
59 4
56 16
55 3
52 3
51 3
49 3
8
57 4
58 4
59 4
56 16
47 3
53 3
44 3
54 3
59
57 132
58 132
59 132
0 3
19 9
20 9
8 6
13 9
1 3
2 3
3 3
15 9
23 12
28 15
31 15
35 21
16 9
4 3
5 3
27 12
33 15
32 15
22 12
30 15
41 21
47 24
29 15
26 12
38 21
9 6
6 3
17 9
46 24
53 24
55 24
44 21
43 21
39 21
14 9
7 3
18 9
24 12
40 21
52 24
54 24
51 24
48 24
37 21
10 6
11 6
34 18
49 24
50 24
42 21
21 12
12 6
36 21
45 24
25 12
57
56 132
0 1
19 3
20 3
8 2
13 3
1 1
2 1
3 1
15 3
23 4
28 5
31 5
35 7
16 3
4 1
5 1
27 4
33 5
32 5
22 4
30 5
41 7
47 8
29 5
26 4
38 7
9 2
6 1
17 3
46 8
53 8
55 8
44 7
43 7
39 7
14 3
7 1
18 3
24 4
40 7
52 8
54 8
51 8
48 8
37 7
10 2
11 2
34 6
49 8
50 8
42 7
21 4
12 2
36 7
45 8
25 4
57
56 132
0 1
19 3
20 3
8 2
13 3
1 1
2 1
3 1
15 3
23 4
28 5
31 5
35 7
16 3
4 1
5 1
27 4
33 5
32 5
22 4
30 5
41 7
47 8
29 5
26 4
38 7
9 2
6 1
17 3
46 8
53 8
55 8
44 7
43 7
39 7
14 3
7 1
18 3
24 4
40 7
52 8
54 8
51 8
48 8
37 7
10 2
11 2
34 6
49 8
50 8
42 7
21 4
12 2
36 7
45 8
25 4
57
56 132
0 1
19 3
20 3
8 2
13 3
1 1
2 1
3 1
15 3
23 4
28 5
31 5
35 7
16 3
4 1
5 1
27 4
33 5
32 5
22 4
30 5
41 7
47 8
29 5
26 4
38 7
9 2
6 1
17 3
46 8
53 8
55 8
44 7
43 7
39 7
14 3
7 1
18 3
24 4
40 7
52 8
54 8
51 8
48 8
37 7
10 2
11 2
34 6
49 8
50 8
42 7
21 4
12 2
36 7
45 8
25 4
end_CG
