begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var3
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var2
-1
22
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_9_2)
Atom at-robot(loc_9_3)
Atom at-robot(loc_9_4)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_8_2)
Atom at(box1, loc_8_3)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
Atom at(box1, loc_8_7)
Atom at(box1, loc_9_2)
Atom at(box1, loc_9_3)
Atom at(box1, loc_9_4)
end_variable
begin_variable
var1
-1
22
Atom at(box2, loc_5_5)
Atom at(box2, loc_5_7)
Atom at(box2, loc_6_2)
Atom at(box2, loc_6_3)
Atom at(box2, loc_6_4)
Atom at(box2, loc_6_5)
Atom at(box2, loc_6_7)
Atom at(box2, loc_7_2)
Atom at(box2, loc_7_3)
Atom at(box2, loc_7_4)
Atom at(box2, loc_7_5)
Atom at(box2, loc_7_6)
Atom at(box2, loc_7_7)
Atom at(box2, loc_8_2)
Atom at(box2, loc_8_3)
Atom at(box2, loc_8_4)
Atom at(box2, loc_8_5)
Atom at(box2, loc_8_6)
Atom at(box2, loc_8_7)
Atom at(box2, loc_9_2)
Atom at(box2, loc_9_3)
Atom at(box2, loc_9_4)
end_variable
22
begin_mutex_group
3
23 0
24 0
0 0
end_mutex_group
begin_mutex_group
3
23 1
24 1
1 0
end_mutex_group
begin_mutex_group
3
23 2
24 2
2 0
end_mutex_group
begin_mutex_group
3
23 3
24 3
12 0
end_mutex_group
begin_mutex_group
3
23 4
24 4
13 0
end_mutex_group
begin_mutex_group
3
23 5
24 5
11 0
end_mutex_group
begin_mutex_group
3
23 6
24 6
7 0
end_mutex_group
begin_mutex_group
3
23 7
24 7
14 0
end_mutex_group
begin_mutex_group
3
23 8
24 8
17 0
end_mutex_group
begin_mutex_group
3
23 9
24 9
21 0
end_mutex_group
begin_mutex_group
3
23 10
24 10
19 0
end_mutex_group
begin_mutex_group
3
23 11
24 11
9 0
end_mutex_group
begin_mutex_group
3
23 12
24 12
10 0
end_mutex_group
begin_mutex_group
3
23 13
24 13
15 0
end_mutex_group
begin_mutex_group
3
23 14
24 14
18 0
end_mutex_group
begin_mutex_group
3
23 15
24 15
20 0
end_mutex_group
begin_mutex_group
3
23 16
24 16
16 0
end_mutex_group
begin_mutex_group
3
23 17
24 17
8 0
end_mutex_group
begin_mutex_group
3
23 18
24 18
3 0
end_mutex_group
begin_mutex_group
3
23 19
24 19
4 0
end_mutex_group
begin_mutex_group
3
23 20
24 20
6 0
end_mutex_group
begin_mutex_group
3
23 21
24 21
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
1
19
17
9
end_state
begin_goal
2
23 8
24 3
end_goal
146
begin_operator
move loc_5_5 loc_6_5 down
1
11 0
1
0 22 0 5
0
end_operator
begin_operator
move loc_5_7 loc_6_7 down
1
7 0
1
0 22 1 6
0
end_operator
begin_operator
move loc_6_2 loc_6_3 right
1
12 0
1
0 22 2 3
0
end_operator
begin_operator
move loc_6_2 loc_7_2 down
1
14 0
1
0 22 2 7
0
end_operato




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





24 9
22 4
20 0
0
88
3
23 9
22 8
19 0
0
89
3
24 9
22 8
19 0
0
100
3
23 9
22 10
17 0
0
101
3
24 9
22 10
17 0
0
118
3
23 9
22 15
13 0
0
119
3
24 9
22 15
13 0
end_DTG
begin_DTG
3
5
0
1
11 0
5
62
2
23 5
19 0
5
63
2
24 5
19 0
3
6
1
1
7 0
6
64
2
23 6
10 0
6
65
2
24 6
10 0
6
3
2
1
12 0
3
66
2
23 3
13 0
3
67
2
24 3
13 0
7
3
1
14 0
7
68
2
23 7
15 0
7
69
2
24 7
15 0
7
2
4
1
2 0
4
5
1
13 0
4
70
2
23 4
11 0
4
71
2
24 4
11 0
8
6
1
17 0
8
72
2
23 8
18 0
8
73
2
24 8
18 0
7
3
7
1
12 0
3
74
2
23 3
2 0
3
75
2
24 3
2 0
5
8
1
11 0
9
9
1
21 0
9
76
2
23 9
20 0
9
77
2
24 9
20 0
7
0
10
1
0 0
4
11
1
13 0
4
78
2
23 4
12 0
4
79
2
24 4
12 0
10
12
1
19 0
10
80
2
23 10
16 0
10
81
2
24 10
16 0
4
1
13
1
1 0
12
14
1
10 0
12
82
2
23 12
3 0
12
83
2
24 12
3 0
7
2
15
1
2 0
8
16
1
17 0
8
84
2
23 8
21 0
8
85
2
24 8
21 0
13
17
1
15 0
13
86
2
23 13
4 0
13
87
2
24 13
4 0
8
3
18
1
12 0
7
19
1
14 0
9
20
1
21 0
9
88
2
23 9
19 0
9
89
2
24 9
19 0
14
21
1
18 0
14
90
2
23 14
6 0
14
91
2
24 14
6 0
10
4
22
1
13 0
8
23
1
17 0
8
92
2
23 8
14 0
8
93
2
24 8
14 0
10
24
1
19 0
10
94
2
23 10
9 0
10
95
2
24 10
9 0
15
25
1
20 0
15
96
2
23 15
5 0
15
97
2
24 15
5 0
10
5
26
1
11 0
5
98
2
23 5
0 0
5
99
2
24 5
0 0
9
27
1
21 0
9
100
2
23 9
17 0
9
101
2
24 9
17 0
11
28
1
9 0
11
102
2
23 11
10 0
11
103
2
24 11
10 0
16
29
1
16 0
5
10
30
1
19 0
10
104
2
23 10
21 0
10
105
2
24 10
21 0
12
31
1
10 0
17
32
1
8 0
7
6
33
1
7 0
6
106
2
23 6
1 0
6
107
2
24 6
1 0
11
34
1
9 0
11
108
2
23 11
19 0
11
109
2
24 11
19 0
18
35
1
3 0
7
7
36
1
14 0
7
110
2
23 7
2 0
7
111
2
24 7
2 0
14
37
1
18 0
14
112
2
23 14
20 0
14
113
2
24 14
20 0
19
38
1
4 0
8
8
39
1
17 0
8
114
2
23 8
12 0
8
115
2
24 8
12 0
13
40
1
15 0
15
41
1
20 0
15
116
2
23 15
16 0
15
117
2
24 15
16 0
20
42
1
6 0
10
9
43
1
21 0
9
118
2
23 9
13 0
9
119
2
24 9
13 0
14
44
1
18 0
14
120
2
23 14
15 0
14
121
2
24 14
15 0
16
45
1
16 0
16
122
2
23 16
8 0
16
123
2
24 16
8 0
21
46
1
5 0
9
10
47
1
19 0
10
124
2
23 10
11 0
10
125
2
24 10
11 0
15
48
1
20 0
15
126
2
23 15
18 0
15
127
2
24 15
18 0
17
49
1
8 0
17
128
2
23 17
3 0
17
129
2
24 17
3 0
5
11
50
1
9 0
16
51
1
16 0
16
130
2
23 16
20 0
16
131
2
24 16
20 0
18
52
1
3 0
6
12
53
1
10 0
12
132
2
23 12
7 0
12
133
2
24 12
7 0
17
54
1
8 0
17
134
2
23 17
16 0
17
135
2
24 17
16 0
6
13
55
1
15 0
13
136
2
23 13
14 0
13
137
2
24 13
14 0
20
56
1
6 0
20
138
2
23 20
5 0
20
139
2
24 20
5 0
5
14
57
1
18 0
14
140
2
23 14
17 0
14
141
2
24 14
17 0
19
58
1
4 0
21
59
1
5 0
6
15
60
1
20 0
15
142
2
23 15
21 0
15
143
2
24 15
21 0
20
61
1
6 0
20
144
2
23 20
4 0
20
145
2
24 20
4 0
end_DTG
begin_DTG
0
0
0
2
2
74
2
22 4
2 0
4
66
2
22 2
13 0
2
3
78
2
22 5
12 0
5
70
2
22 3
11 0
2
0
98
2
22 10
0 0
10
62
2
22 0
19 0
2
1
106
2
22 12
1 0
12
64
2
22 1
10 0
2
2
110
2
22 13
2 0
13
68
2
22 2
15 0
4
3
114
2
22 14
12 0
7
92
2
22 9
14 0
9
84
2
22 7
21 0
14
72
2
22 3
18 0
4
4
118
2
22 15
13 0
8
100
2
22 10
17 0
10
88
2
22 8
19 0
15
76
2
22 4
20 0
4
5
124
2
22 16
11 0
9
104
2
22 11
21 0
11
94
2
22 9
9 0
16
80
2
22 5
16 0
2
10
108
2
22 12
19 0
12
102
2
22 10
10 0
2
6
132
2
22 18
7 0
18
82
2
22 6
3 0
2
7
136
2
22 19
14 0
19
86
2
22 7
4 0
4
8
140
2
22 20
17 0
13
120
2
22 15
15 0
15
112
2
22 13
20 0
20
90
2
22 8
6 0
4
9
142
2
22 21
21 0
14
126
2
22 16
18 0
16
116
2
22 14
16 0
21
96
2
22 9
5 0
2
15
130
2
22 17
20 0
17
122
2
22 15
8 0
2
16
134
2
22 18
16 0
18
128
2
22 16
3 0
0
0
2
19
144
2
22 21
4 0
21
138
2
22 19
5 0
0
end_DTG
begin_DTG
0
0
0
2
2
75
2
22 4
2 0
4
67
2
22 2
13 0
2
3
79
2
22 5
12 0
5
71
2
22 3
11 0
2
0
99
2
22 10
0 0
10
63
2
22 0
19 0
2
1
107
2
22 12
1 0
12
65
2
22 1
10 0
2
2
111
2
22 13
2 0
13
69
2
22 2
15 0
4
3
115
2
22 14
12 0
7
93
2
22 9
14 0
9
85
2
22 7
21 0
14
73
2
22 3
18 0
4
4
119
2
22 15
13 0
8
101
2
22 10
17 0
10
89
2
22 8
19 0
15
77
2
22 4
20 0
4
5
125
2
22 16
11 0
9
105
2
22 11
21 0
11
95
2
22 9
9 0
16
81
2
22 5
16 0
2
10
109
2
22 12
19 0
12
103
2
22 10
10 0
2
6
133
2
22 18
7 0
18
83
2
22 6
3 0
2
7
137
2
22 19
14 0
19
87
2
22 7
4 0
4
8
141
2
22 20
17 0
13
121
2
22 15
15 0
15
113
2
22 13
20 0
20
91
2
22 8
6 0
4
9
143
2
22 21
21 0
14
127
2
22 16
18 0
16
117
2
22 14
16 0
21
97
2
22 9
5 0
2
15
131
2
22 17
20 0
17
123
2
22 15
8 0
2
16
135
2
22 18
16 0
18
129
2
22 16
3 0
0
0
2
19
145
2
22 21
4 0
21
139
2
22 19
5 0
0
end_DTG
begin_CG
4
23 1
24 1
22 3
11 2
4
23 1
24 1
22 3
7 2
5
23 2
24 2
22 6
12 2
14 2
5
23 2
24 2
22 6
10 2
8 2
5
23 2
24 2
22 6
15 2
6 2
5
23 2
24 2
22 6
20 2
6 2
4
23 1
24 1
22 5
18 2
4
23 1
24 1
22 4
10 2
4
23 1
24 1
22 5
16 2
4
23 1
24 1
22 5
19 2
5
23 2
24 2
22 7
7 2
9 2
5
23 2
24 2
22 7
13 2
19 2
5
23 2
24 2
22 7
13 2
17 2
5
23 2
24 2
22 7
12 2
21 2
5
23 2
24 2
22 7
17 2
15 2
5
23 2
24 2
22 7
14 2
18 2
6
23 3
24 3
22 9
19 2
20 2
8 2
5
23 2
24 2
22 8
21 2
18 2
5
23 2
24 2
22 8
17 2
20 2
6
23 3
24 3
22 10
11 2
21 2
9 2
6
23 3
24 3
22 10
21 2
18 2
16 2
6
23 3
24 3
22 10
17 2
19 2
20 2
24
23 42
24 42
0 2
1 2
2 4
12 8
13 8
11 8
7 6
14 8
17 12
21 14
19 14
9 6
10 8
15 8
18 12
20 14
16 10
8 6
3 4
4 4
6 6
5 4
23
22 42
0 1
1 1
2 2
12 4
13 4
11 4
7 3
14 4
17 6
21 7
19 7
9 3
10 4
15 4
18 6
20 7
16 5
8 3
3 2
4 2
6 3
5 2
23
22 42
0 1
1 1
2 2
12 4
13 4
11 4
7 3
14 4
17 6
21 7
19 7
9 3
10 4
15 4
18 6
20 7
16 5
8 3
3 2
4 2
6 3
5 2
end_CG
