begin_version
3
end_version
begin_metric
0
end_metric
45
begin_variable
var2
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var1
-1
45
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_9_2)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_7)
Atom at-robot(loc_9_8)
end_variable
begin_variable
var0
-1
43
Atom at(box2, loc_2_4)
Atom at(box2, loc_2_6)
Atom at(box2, loc_3_4)
Atom at(box2, loc_3_5)
Atom at(box2, loc_3_6)
Atom at(box2, loc_3_7)
Atom at(box2, loc_4_3)
Atom at(box2, loc_4_4)
Atom at(box2, loc_4_5)
Atom at(box2, loc_4_6)
Atom at(box2, loc_4_7)
Atom at(box2, loc_4_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




16
188
2
44 16
32 0
22
73
1
33 0
22
189
2
44 22
21 0
24
74
1
41 0
24
190
2
44 24
39 0
31
75
1
26 0
8
17
76
1
42 0
17
191
2
44 17
36 0
23
77
1
34 0
23
192
2
44 23
33 0
25
78
1
39 0
25
193
2
44 25
22 0
32
79
1
29 0
32
194
2
44 32
19 0
8
18
80
1
40 0
18
195
2
44 18
31 0
24
81
1
41 0
24
196
2
44 24
34 0
26
82
1
22 0
26
197
2
44 26
16 0
33
83
1
25 0
33
198
2
44 33
23 0
5
19
84
1
24 0
19
199
2
44 19
18 0
25
85
1
39 0
25
200
2
44 25
41 0
27
86
1
16 0
5
20
87
1
17 0
20
201
2
44 20
10 0
26
88
1
22 0
26
202
2
44 26
39 0
34
89
1
4 0
3
29
90
1
15 0
29
203
2
44 29
35 0
35
91
0
5
21
92
1
21 0
21
204
2
44 21
28 0
28
93
1
3 0
30
94
1
35 0
30
205
2
44 30
26 0
8
22
95
1
33 0
22
206
2
44 22
37 0
29
96
1
15 0
29
207
2
44 29
3 0
31
97
1
26 0
31
208
2
44 31
29 0
36
98
1
13 0
36
209
2
44 35
6 0
6
23
99
1
34 0
23
210
2
44 23
38 0
30
100
1
35 0
30
211
2
44 30
15 0
32
101
1
29 0
32
212
2
44 32
25 0
7
24
102
1
41 0
24
213
2
44 24
42 0
31
103
1
26 0
31
214
2
44 31
35 0
33
104
1
25 0
37
105
1
19 0
37
215
2
44 36
11 0
6
25
106
1
39 0
25
216
2
44 25
40 0
32
107
1
29 0
32
217
2
44 32
26 0
38
108
1
23 0
38
218
2
44 37
12 0
2
27
109
1
16 0
27
219
2
44 27
17 0
2
28
110
1
3 0
40
111
0
3
30
112
1
35 0
30
220
2
44 30
33 0
41
113
1
6 0
5
32
114
1
29 0
32
221
2
44 32
41 0
38
115
1
23 0
38
222
2
44 37
5 0
42
116
1
11 0
5
33
117
1
25 0
33
223
2
44 33
39 0
37
118
1
19 0
39
119
1
5 0
43
120
1
12 0
3
38
121
1
23 0
38
224
2
44 37
19 0
44
122
1
7 0
1
35
123
0
2
36
124
1
13 0
36
225
2
44 35
35 0
4
37
125
1
19 0
37
226
2
44 36
29 0
43
126
1
12 0
43
227
2
44 41
7 0
4
38
127
1
23 0
38
228
2
44 37
25 0
42
128
1
11 0
44
129
1
7 0
3
39
130
1
5 0
43
131
1
12 0
43
229
2
44 41
11 0
end_DTG
begin_DTG
0
0
2
0
144
2
43 7
0 0
7
132
2
43 0
30 0
2
2
138
2
43 4
14 0
4
134
2
43 2
27 0
4
1
150
2
43 9
1 0
3
140
2
43 5
20 0
5
136
2
43 3
8 0
9
133
2
43 1
36 0
0
0
4
2
164
2
43 15
14 0
6
147
2
43 8
9 0
8
142
2
43 6
32 0
15
135
2
43 2
37 0
4
3
168
2
43 16
20 0
7
151
2
43 9
30 0
9
145
2
43 7
36 0
16
137
2
43 3
38 0
4
4
172
2
43 17
27 0
8
154
2
43 10
32 0
10
148
2
43 8
31 0
17
139
2
43 4
42 0
4
5
176
2
43 18
8 0
9
157
2
43 11
36 0
11
152
2
43 9
18 0
18
141
2
43 5
40 0
2
10
159
2
43 12
31 0
12
155
2
43 10
10 0
0
0
4
6
183
2
43 21
9 0
13
165
2
43 15
2 0
15
161
2
43 13
37 0
21
143
2
43 6
21 0
4
7
185
2
43 22
30 0
14
169
2
43 16
28 0
16
162
2
43 14
38 0
22
146
2
43 7
33 0
4
8
188
2
43 23
32 0
15
173
2
43 17
37 0
17
166
2
43 15
42 0
23
149
2
43 8
34 0
4
9
191
2
43 24
36 0
16
177
2
43 18
38 0
18
170
2
43 16
40 0
24
153
2
43 9
41 0
4
10
195
2
43 25
31 0
17
180
2
43 19
42 0
19
174
2
43 17
24 0
25
156
2
43 10
39 0
4
11
199
2
43 26
18 0
18
181
2
43 20
40 0
20
178
2
43 18
17 0
26
158
2
43 11
22 0
2
12
201
2
43 27
10 0
27
160
2
43 12
16 0
2
14
204
2
43 29
28 0
29
163
2
43 14
15 0
4
15
206
2
43 30
37 0
21
189
2
43 23
21 0
23
184
2
43 21
34 0
30
167
2
43 15
35 0
4
16
210
2
43 31
38 0
22
192
2
43 24
33 0
24
186
2
43 22
41 0
31
171
2
43 16
26 0
4
17
213
2
43 32
42 0
23
196
2
43 25
34 0
25
190
2
43 23
39 0
32
175
2
43 17
29 0
4
18
216
2
43 33
40 0
24
200
2
43 26
41 0
26
193
2
43 24
22 0
33
179
2
43 18
25 0
2
25
202
2
43 27
39 0
27
197
2
43 25
16 0
2
20
219
2
43 34
17 0
34
182
2
43 20
4 0
0
2
28
207
2
43 30
3 0
30
203
2
43 28
35 0
4
22
220
2
43 36
33 0
29
211
2
43 31
15 0
31
205
2
43 29
26 0
35
187
2
43 22
13 0
2
30
214
2
43 32
35 0
32
208
2
43 30
29 0
4
24
221
2
43 37
41 0
31
217
2
43 33
26 0
33
212
2
43 31
25 0
36
194
2
43 24
19 0
2
25
223
2
43 38
39 0
37
198
2
43 25
23 0
0
2
30
225
2
43 41
35 0
39
209
2
43 30
6 0
2
32
226
2
43 42
29 0
40
215
2
43 32
11 0
4
33
228
2
43 43
25 0
36
224
2
43 39
19 0
38
222
2
43 37
5 0
41
218
2
43 33
12 0
0
0
0
2
40
229
2
43 44
11 0
42
227
2
43 42
7 0
0
end_DTG
begin_CG
3
44 1
43 2
14 1
3
44 1
43 2
27 1
3
44 1
43 2
28 1
3
44 1
43 3
15 1
3
44 1
43 2
16 1
3
44 1
43 3
23 1
3
44 1
43 2
13 1
3
44 1
43 3
12 1
4
44 2
43 4
27 1
31 1
4
44 2
43 4
30 1
28 1
4
44 2
43 4
18 1
17 1
4
44 2
43 4
19 1
12 1
3
44 1
43 4
23 1
3
44 1
43 3
35 1
4
44 2
43 5
20 1
30 1
4
44 2
43 5
21 1
35 1
4
44 2
43 5
17 1
22 1
4
44 2
43 5
24 1
16 1
4
44 2
43 5
31 1
24 1
4
44 2
43 5
29 1
23 1
4
44 2
43 5
27 1
32 1
4
44 2
43 5
28 1
33 1
4
44 2
43 5
24 1
39 1
3
44 1
43 5
25 1
3
44 1
43 5
40 1
5
44 3
43 6
39 1
29 1
23 1
5
44 3
43 6
34 1
35 1
29 1
4
44 2
43 6
20 1
36 1
4
44 2
43 6
37 1
21 1
5
44 3
43 7
41 1
26 1
19 1
5
44 3
43 7
14 1
32 1
37 1
5
44 3
43 7
36 1
18 1
40 1
5
44 3
43 7
30 1
36 1
38 1
5
44 3
43 7
37 1
34 1
35 1
5
44 3
43 7
38 1
33 1
41 1
6
44 4
43 8
33 1
15 1
26 1
13 1
6
44 4
43 8
27 1
32 1
31 1
42 1
6
44 4
43 8
30 1
28 1
38 1
33 1
6
44 4
43 8
32 1
37 1
42 1
34 1
6
44 4
43 8
40 1
41 1
22 1
25 1
6
44 4
43 8
31 1
42 1
24 1
39 1
6
44 4
43 8
42 1
34 1
39 1
29 1
6
44 4
43 8
36 1
38 1
40 1
41 1
44
44 98
0 1
1 1
14 4
20 4
27 6
8 2
9 2
30 7
32 7
36 8
31 7
18 4
10 2
2 1
28 6
37 8
38 8
42 8
40 8
24 5
17 4
21 4
33 7
34 7
41 8
39 8
22 4
16 4
3 1
15 4
35 8
26 5
29 7
25 5
4 1
13 3
19 4
23 5
5 1
6 1
11 2
12 3
7 1
44
43 98
0 1
1 1
14 4
20 4
27 6
8 2
9 2
30 7
32 7
36 8
31 7
18 4
10 2
2 1
28 6
37 8
38 8
42 8
40 8
24 5
17 4
21 4
33 7
34 7
41 8
39 8
22 4
16 4
3 1
15 4
35 8
26 5
29 7
25 5
4 1
13 3
19 4
23 5
5 1
6 1
11 2
12 3
7 1
end_CG
