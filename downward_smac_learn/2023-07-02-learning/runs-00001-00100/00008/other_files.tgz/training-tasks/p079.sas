begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var5
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var3
-1
47
Atom at-robot(loc_10_10)
Atom at-robot(loc_10_11)
Atom at-robot(loc_10_4)
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_10_8)
Atom at-robot(loc_10_9)
Atom at-robot(loc_11_10)
Atom at-robot(loc_11_5)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_10)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_10)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_10)
Atom at-robot(loc_8_11)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_8_9)
Atom at-robot(loc_9_10)
Atom at-robot(loc_9_3)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_7




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




94
2
46 36
21 0
35
181
2
46 5
42 0
42
469
2
46 45
39 0
44
457
2
46 43
33 0
4
6
403
2
46 37
22 0
36
190
2
46 6
25 0
43
478
2
46 46
37 0
45
466
2
46 44
32 0
4
7
415
2
46 38
23 0
37
199
2
46 7
38 0
38
472
2
46 45
24 0
44
424
2
46 39
33 0
end_DTG
begin_DTG
4
1
194
2
46 7
0 0
7
152
2
46 1
23 0
8
419
2
46 39
1 0
38
203
2
46 8
24 0
0
0
4
2
167
2
46 4
5 0
4
155
2
46 2
20 0
9
440
2
46 42
2 0
41
206
2
46 9
43 0
2
3
176
2
46 5
28 0
5
161
2
46 3
21 0
2
4
185
2
46 6
20 0
6
170
2
46 4
22 0
2
5
197
2
46 7
21 0
7
179
2
46 5
23 0
2
0
188
2
46 6
26 0
6
146
2
46 0
22 0
0
0
0
2
10
218
2
46 12
6 0
12
209
2
46 10
7 0
0
0
2
10
284
2
46 23
6 0
22
212
2
46 10
17 0
4
11
293
2
46 24
10 0
14
242
2
46 17
13 0
16
230
2
46 15
35 0
23
215
2
46 11
36 0
4
12
302
2
46 25
7 0
15
251
2
46 18
30 0
17
236
2
46 16
19 0
24
221
2
46 12
40 0
2
16
260
2
46 19
35 0
18
245
2
46 17
18 0
2
17
269
2
46 20
19 0
19
254
2
46 18
15 0
2
18
275
2
46 21
18 0
20
263
2
46 19
14 0
2
13
272
2
46 20
8 0
19
224
2
46 14
15 0
2
13
329
2
46 29
8 0
28
227
2
46 14
34 0
2
14
344
2
46 32
13 0
31
233
2
46 15
27 0
4
15
350
2
46 33
30 0
22
305
2
46 25
17 0
24
287
2
46 23
40 0
32
239
2
46 16
41 0
4
16
362
2
46 34
35 0
23
314
2
46 26
36 0
25
296
2
46 24
31 0
33
248
2
46 17
45 0
4
17
374
2
46 35
19 0
24
320
2
46 27
40 0
26
308
2
46 25
16 0
34
257
2
46 18
44 0
2
18
386
2
46 36
18 0
35
266
2
46 19
42 0
2
20
407
2
46 38
14 0
37
278
2
46 21
38 0
4
21
422
2
46 39
11 0
29
410
2
46 38
3 0
37
338
2
46 30
38 0
38
281
2
46 22
24 0
0
0
4
22
428
2
46 40
17 0
30
353
2
46 33
4 0
32
341
2
46 31
41 0
39
290
2
46 23
9 0
4
23
434
2
46 41
36 0
31
365
2
46 34
27 0
33
347
2
46 32
45 0
40
299
2
46 24
29 0
4
24
443
2
46 42
40 0
32
377
2
46 35
41 0
34
356
2
46 33
44 0
41
311
2
46 25
43 0
4
25
452
2
46 43
31 0
33
389
2
46 36
45 0
35
368
2
46 34
42 0
42
317
2
46 26
39 0
4
26
461
2
46 44
16 0
34
398
2
46 37
44 0
36
380
2
46 35
25 0
43
323
2
46 27
37 0
2
35
413
2
46 38
42 0
37
392
2
46 36
38 0
4
27
476
2
46 46
12 0
28
401
2
46 37
34 0
36
332
2
46 29
25 0
45
326
2
46 28
32 0
2
0
335
2
46 29
26 0
28
149
2
46 0
34 0
0
4
2
359
2
46 33
5 0
32
158
2
46 2
41 0
39
446
2
46 42
9 0
41
431
2
46 40
43 0
4
3
371
2
46 34
28 0
33
164
2
46 3
45 0
40
455
2
46 43
29 0
42
437
2
46 41
39 0
4
4
383
2
46 35
20 0
34
173
2
46 4
44 0
41
464
2
46 44
43 0
43
449
2
46 42
37 0
4
5
395
2
46 36
21 0
35
182
2
46 5
42 0
42
470
2
46 45
39 0
44
458
2
46 43
33 0
4
6
404
2
46 37
22 0
36
191
2
46 6
25 0
43
479
2
46 46
37 0
45
467
2
46 44
32 0
4
7
416
2
46 38
23 0
37
200
2
46 7
38 0
38
473
2
46 45
24 0
44
425
2
46 39
33 0
end_DTG
begin_CG
5
47 1
48 1
49 1
46 4
26 3
5
47 1
48 1
49 1
46 4
26 3
5
47 1
48 1
49 1
46 4
28 3
5
47 1
48 1
49 1
46 4
34 3
5
47 1
48 1
49 1
46 4
27 3
6
47 2
48 2
49 2
46 8
28 3
29 3
6
47 2
48 2
49 2
46 8
10 3
13 3
6
47 2
48 2
49 2
46 8
10 3
35 3
6
47 2
48 2
49 2
46 8
14 3
11 3
6
47 2
48 2
49 2
46 8
27 3
29 3
5
47 1
48 1
49 1
46 6
30 3
5
47 1
48 1
49 1
46 6
34 3
5
47 1
48 1
49 1
46 6
38 3
6
47 2
48 2
49 2
46 9
30 3
17 3
6
47 2
48 2
49 2
46 9
15 3
12 3
6
47 2
48 2
49 2
46 9
18 3
14 3
6
47 2
48 2
49 2
46 9
31 3
42 3
7
47 3
48 3
49 3
46 12
13 3
36 3
27 3
7
47 3
48 3
49 3
46 12
19 3
15 3
16 3
7
47 3
48 3
49 3
46 12
35 3
18 3
31 3
7
47 3
48 3
49 3
46 12
28 3
21 3
39 3
7
47 3
48 3
49 3
46 12
20 3
22 3
37 3
7
47 3
48 3
49 3
46 12
21 3
23 3
33 3
7
47 3
48 3
49 3
46 12
26 3
22 3
32 3
7
47 3
48 3
49 3
46 12
26 3
34 3
32 3
7
47 3
48 3
49 3
46 12
42 3
38 3
33 3
6
47 2
48 2
49 2
46 10
23 3
24 3
6
47 2
48 2
49 2
46 10
17 3
41 3
6
47 2
48 2
49 2
46 10
20 3
43 3
6
47 2
48 2
49 2
46 10
41 3
43 3
6
47 2
48 2
49 2
46 10
35 3
36 3
6
47 2
48 2
49 2
46 10
40 3
44 3
6
47 2
48 2
49 2
46 10
38 3
33 3
6
47 2
48 2
49 2
46 10
37 3
32 3
7
47 3
48 3
49 3
46 13
11 3
38 3
24 3
7
47 3
48 3
49 3
46 13
30 3
19 3
40 3
7
47 3
48 3
49 3
46 13
30 3
40 3
41 3
7
47 3
48 3
49 3
46 13
42 3
39 3
33 3
8
47 4
48 4
49 4
46 16
12 3
34 3
25 3
32 3
7
47 3
48 3
49 3
46 13
44 3
43 3
37 3
8
47 4
48 4
49 4
46 16
35 3
36 3
31 3
45 3
8
47 4
48 4
49 4
46 16
36 3
27 3
45 3
29 3
8
47 4
48 4
49 4
46 16
16 3
44 3
25 3
37 3
8
47 4
48 4
49 4
46 16
28 3
45 3
29 3
39 3
8
47 4
48 4
49 4
46 16
31 3
45 3
42 3
39 3
8
47 4
48 4
49 4
46 16
40 3
41 3
44 3
43 3
49
47 112
48 112
49 112
26 18
0 3
5 6
28 18
20 15
21 15
22 15
23 15
1 3
2 3
6 6
10 9
7 6
8 6
13 12
30 18
35 21
19 15
18 15
15 12
14 12
11 9
17 15
36 21
40 24
31 18
16 12
12 9
34 21
3 3
4 3
27 18
41 24
45 24
44 24
42 24
25 15
38 24
24 15
9 6
29 18
43 24
39 21
37 21
33 18
32 18
47
46 112
26 6
0 1
5 2
28 6
20 5
21 5
22 5
23 5
1 1
2 1
6 2
10 3
7 2
8 2
13 4
30 6
35 7
19 5
18 5
15 4
14 4
11 3
17 5
36 7
40 8
31 6
16 4
12 3
34 7
3 1
4 1
27 6
41 8
45 8
44 8
42 8
25 5
38 8
24 5
9 2
29 6
43 8
39 7
37 7
33 6
32 6
47
46 112
26 6
0 1
5 2
28 6
20 5
21 5
22 5
23 5
1 1
2 1
6 2
10 3
7 2
8 2
13 4
30 6
35 7
19 5
18 5
15 4
14 4
11 3
17 5
36 7
40 8
31 6
16 4
12 3
34 7
3 1
4 1
27 6
41 8
45 8
44 8
42 8
25 5
38 8
24 5
9 2
29 6
43 8
39 7
37 7
33 6
32 6
47
46 112
26 6
0 1
5 2
28 6
20 5
21 5
22 5
23 5
1 1
2 1
6 2
10 3
7 2
8 2
13 4
30 6
35 7
19 5
18 5
15 4
14 4
11 3
17 5
36 7
40 8
31 6
16 4
12 3
34 7
3 1
4 1
27 6
41 8
45 8
44 8
42 8
25 5
38 8
24 5
9 2
29 6
43 8
39 7
37 7
33 6
32 6
end_CG
