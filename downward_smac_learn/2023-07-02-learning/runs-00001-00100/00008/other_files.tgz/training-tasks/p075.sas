begin_version
3
end_version
begin_metric
0
end_metric
77
begin_variable
var7
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var75
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var76
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var58
-1
2
Atom cl




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5
642
2
73 60
31 0
59
549
2
73 46
36 0
2
46
651
2
73 61
11 0
60
555
2
73 47
12 0
4
47
657
2
73 62
57 0
53
618
2
73 56
16 0
55
603
2
73 54
64 0
61
564
2
73 48
56 0
4
48
666
2
73 63
63 0
54
627
2
73 57
58 0
56
609
2
73 55
42 0
62
573
2
73 49
67 0
2
49
678
2
73 64
43 0
63
582
2
73 50
52 0
2
50
693
2
73 66
29 0
65
588
2
73 51
37 0
2
51
708
2
73 68
34 0
67
594
2
73 52
50 0
2
52
717
2
73 69
32 0
68
600
2
73 53
19 0
0
4
54
723
2
73 70
58 0
60
669
2
73 63
12 0
62
654
2
73 61
67 0
69
612
2
73 55
38 0
4
55
732
2
73 71
64 0
61
681
2
73 64
56 0
63
660
2
73 62
52 0
70
621
2
73 56
46 0
4
56
735
2
73 72
42 0
62
687
2
73 65
67 0
64
672
2
73 63
30 0
71
630
2
73 57
13 0
2
63
696
2
73 66
52 0
65
684
2
73 64
37 0
2
64
702
2
73 67
30 0
66
690
2
73 65
35 0
2
65
711
2
73 68
37 0
67
699
2
73 66
50 0
4
58
741
2
73 73
33 0
59
705
2
73 67
36 0
66
645
2
73 60
35 0
72
639
2
73 59
22 0
2
0
648
2
73 60
3 0
59
231
2
73 0
36 0
2
1
663
2
73 62
20 0
61
234
2
73 1
56 0
4
2
675
2
73 63
23 0
62
237
2
73 2
67 0
69
738
2
73 72
38 0
71
726
2
73 70
13 0
0
2
6
714
2
73 68
25 0
67
255
2
73 6
50 0
end_DTG
begin_CG
5
74 1
75 1
76 1
73 5
17 3
5
74 1
75 1
76 1
73 5
18 3
5
74 1
75 1
76 1
73 4
47 3
6
74 2
75 2
76 2
73 8
25 3
19 3
6
74 2
75 2
76 2
73 8
20 3
24 3
6
74 2
75 2
76 2
73 8
15 3
27 3
6
74 2
75 2
76 2
73 8
14 3
48 3
6
74 2
75 2
76 2
73 8
14 3
59 3
6
74 2
75 2
76 2
73 8
15 3
53 3
6
74 2
75 2
76 2
73 8
48 3
47 3
6
74 2
75 2
76 2
73 8
28 3
54 3
6
74 2
75 2
76 2
73 8
57 3
16 3
6
74 2
75 2
76 2
73 8
16 3
56 3
6
74 2
75 2
76 2
73 8
52 3
46 3
5
74 1
75 1
76 1
73 6
60 3
5
74 1
75 1
76 1
73 6
49 3
5
74 1
75 1
76 1
73 6
58 3
5
74 1
75 1
76 1
73 5
26 3
5
74 1
75 1
76 1
73 5
24 3
5
74 1
75 1
76 1
73 6
36 3
5
74 1
75 1
76 1
73 6
38 3
5
74 1
75 1
76 1
73 5
29 3
5
74 1
75 1
76 1
73 6
50 3
5
74 1
75 1
76 1
73 6
46 3
6
74 2
75 2
76 2
73 9
23 3
18 3
6
74 2
75 2
76 2
73 9
26 3
22 3
6
74 2
75 2
76 2
73 9
17 3
25 3
6
74 2
75 2
76 2
73 9
49 3
28 3
6
74 2
75 2
76 2
73 9
27 3
55 3
6
74 2
75 2
76 2
73 8
65 3
21 3
6
74 2
75 2
76 2
73 8
52 3
37 3
6
74 2
75 2
76 2
73 9
54 3
32 3
6
74 2
75 2
76 2
73 9
31 3
36 3
6
74 2
75 2
76 2
73 9
34 3
50 3
6
74 2
75 2
76 2
73 9
68 3
33 3
6
74 2
75 2
76 2
73 8
37 3
50 3
7
74 3
75 3
76 3
73 12
32 3
50 3
19 3
7
74 3
75 3
76 3
73 12
21 3
30 3
35 3
7
74 3
75 3
76 3
73 12
20 3
56 3
46 3
7
74 3
75 3
76 3
73 12
47 3
66 3
57 3
7
74 3
75 3
76 3
73 12
59 3
41 3
61 3
7
74 3
75 3
76 3
73 12
40 3
53 3
51 3
7
74 3
75 3
76 3
73 12
43 3
64 3
52 3
7
74 3
75 3
76 3
73 12
71 3
63 3
42 3
7
74 3
75 3
76 3
73 12
62 3
71 3
65 3
7
74 3
75 3
76 3
73 12
51 3
65 3
68 3
6
74 2
75 2
76 2
73 10
23 3
67 3
6
74 2
75 2
76 2
73 10
70 3
39 3
6
74 2
75 2
76 2
73 10
60 3
70 3
6
74 2
75 2
76 2
73 10
53 3
55 3
7
74 3
75 3
76 3
73 13
33 3
35 3
22 3
6
74 2
75 2
76 2
73 10
61 3
69 3
7
74 3
75 3
76 3
73 13
42 3
67 3
30 3
7
74 3
75 3
76 3
73 13
49 3
41 3
69 3
7
74 3
75 3
76 3
73 13
55 3
68 3
31 3
7
74 3
75 3
76 3
73 13
49 3
69 3
54 3
7
74 3
75 3
76 3
73 13
58 3
67 3
38 3
7
74 3
75 3
76 3
73 13
39 3
63 3
58 3
7
74 3
75 3
76 3
73 13
57 3
64 3
56 3
7
74 3
75 3
76 3
73 13
60 3
40 3
62 3
7
74 3
75 3
76 3
73 13
48 3
59 3
72 3
7
74 3
75 3
76 3
73 13
62 3
51 3
65 3
7
74 3
75 3
76 3
73 13
59 3
72 3
61 3
7
74 3
75 3
76 3
73 13
66 3
57 3
64 3
7
74 3
75 3
76 3
73 13
63 3
58 3
67 3
8
74 4
75 4
76 4
73 16
61 3
44 3
45 3
29 3
7
74 3
75 3
76 3
73 13
70 3
71 3
63 3
8
74 4
75 4
76 4
73 16
64 3
56 3
52 3
46 3
8
74 4
75 4
76 4
73 16
69 3
54 3
45 3
34 3
8
74 4
75 4
76 4
73 16
53 3
55 3
51 3
68 3
8
74 4
75 4
76 4
73 16
48 3
47 3
72 3
66 3
8
74 4
75 4
76 4
73 16
72 3
66 3
44 3
43 3
8
74 4
75 4
76 4
73 16
60 3
70 3
62 3
71 3
76
74 172
75 172
76 172
3 6
20 9
23 9
0 3
17 9
26 12
25 12
4 6
24 12
18 9
1 3
15 9
5 6
6 6
14 9
7 6
8 6
49 18
27 12
9 6
48 18
60 21
59 21
40 15
41 15
53 21
55 21
28 12
2 3
47 18
70 24
72 24
62 21
61 21
51 18
69 24
54 21
10 6
39 15
66 21
71 24
44 15
65 24
45 15
68 24
31 12
11 6
57 21
63 21
43 15
29 12
34 12
32 12
16 9
58 21
64 21
42 15
21 9
33 12
36 15
12 6
56 21
67 24
52 21
30 12
37 15
35 12
50 21
19 9
38 15
46 18
13 6
22 9
74
73 172
3 2
20 3
23 3
0 1
17 3
26 4
25 4
4 2
24 4
18 3
1 1
15 3
5 2
6 2
14 3
7 2
8 2
49 6
27 4
9 2
48 6
60 7
59 7
40 5
41 5
53 7
55 7
28 4
2 1
47 6
70 8
72 8
62 7
61 7
51 6
69 8
54 7
10 2
39 5
66 7
71 8
44 5
65 8
45 5
68 8
31 4
11 2
57 7
63 7
43 5
29 4
34 4
32 4
16 3
58 7
64 7
42 5
21 3
33 4
36 5
12 2
56 7
67 8
52 7
30 4
37 5
35 4
50 7
19 3
38 5
46 6
13 2
22 3
74
73 172
3 2
20 3
23 3
0 1
17 3
26 4
25 4
4 2
24 4
18 3
1 1
15 3
5 2
6 2
14 3
7 2
8 2
49 6
27 4
9 2
48 6
60 7
59 7
40 5
41 5
53 7
55 7
28 4
2 1
47 6
70 8
72 8
62 7
61 7
51 6
69 8
54 7
10 2
39 5
66 7
71 8
44 5
65 8
45 5
68 8
31 4
11 2
57 7
63 7
43 5
29 4
34 4
32 4
16 3
58 7
64 7
42 5
21 3
33 4
36 5
12 2
56 7
67 8
52 7
30 4
37 5
35 4
50 7
19 3
38 5
46 6
13 2
22 3
74
73 172
3 2
20 3
23 3
0 1
17 3
26 4
25 4
4 2
24 4
18 3
1 1
15 3
5 2
6 2
14 3
7 2
8 2
49 6
27 4
9 2
48 6
60 7
59 7
40 5
41 5
53 7
55 7
28 4
2 1
47 6
70 8
72 8
62 7
61 7
51 6
69 8
54 7
10 2
39 5
66 7
71 8
44 5
65 8
45 5
68 8
31 4
11 2
57 7
63 7
43 5
29 4
34 4
32 4
16 3
58 7
64 7
42 5
21 3
33 4
36 5
12 2
56 7
67 8
52 7
30 4
37 5
35 4
50 7
19 3
38 5
46 6
13 2
22 3
end_CG
