begin_version
3
end_version
begin_metric
0
end_metric
69
begin_variable
var6
-1
2
Atom clear(loc_11_2)
NegatedAtom clear(loc_11_2)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_7_4)
Neg




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7 0
2
26
497
2
65 43
13 0
42
353
2
65 27
26 0
4
27
503
2
65 44
49 0
34
446
2
65 37
25 0
36
428
2
65 35
63 0
43
362
2
65 28
54 0
4
28
512
2
65 45
61 0
35
458
2
65 38
53 0
37
437
2
65 36
64 0
44
374
2
65 29
60 0
4
29
524
2
65 46
62 0
36
470
2
65 39
63 0
38
449
2
65 37
59 0
45
386
2
65 30
45 0
4
30
530
2
65 47
56 0
37
482
2
65 40
64 0
39
461
2
65 38
29 0
46
395
2
65 31
30 0
2
38
488
2
65 41
59 0
40
473
2
65 39
37 0
2
32
536
2
65 48
57 0
47
416
2
65 33
18 0
0
2
34
545
2
65 52
25 0
50
431
2
65 35
14 0
4
35
551
2
65 53
53 0
42
515
2
65 45
26 0
44
500
2
65 43
60 0
51
440
2
65 36
50 0
4
36
560
2
65 54
63 0
43
527
2
65 46
54 0
45
506
2
65 44
45 0
52
452
2
65 37
58 0
4
37
572
2
65 55
64 0
44
533
2
65 47
60 0
46
518
2
65 45
30 0
53
464
2
65 38
41 0
2
38
581
2
65 56
59 0
54
476
2
65 39
40 0
2
40
596
2
65 58
37 0
56
491
2
65 41
36 0
4
41
611
2
65 60
5 0
49
605
2
65 59
6 0
57
542
2
65 51
33 0
58
494
2
65 42
7 0
0
0
4
43
614
2
65 62
54 0
50
563
2
65 54
14 0
52
548
2
65 52
58 0
59
509
2
65 44
31 0
4
44
620
2
65 63
60 0
51
575
2
65 55
50 0
53
554
2
65 53
41 0
60
521
2
65 45
28 0
2
52
584
2
65 56
58 0
54
566
2
65 54
40 0
2
53
590
2
65 57
41 0
55
578
2
65 55
32 0
2
54
599
2
65 58
40 0
56
587
2
65 56
36 0
2
55
608
2
65 59
32 0
57
593
2
65 57
33 0
2
48
602
2
65 58
35 0
56
539
2
65 50
36 0
0
2
51
632
2
65 65
50 0
62
557
2
65 53
47 0
2
52
641
2
65 66
58 0
63
569
2
65 54
46 0
0
4
0
617
2
65 62
16 0
59
206
2
65 0
31 0
61
644
2
65 66
8 0
63
626
2
65 64
46 0
4
1
623
2
65 63
17 0
60
209
2
65 1
28 0
62
647
2
65 67
47 0
64
635
2
65 65
9 0
0
end_DTG
begin_CG
5
66 1
67 1
68 1
65 4
19 3
5
66 1
67 1
68 1
65 5
15 3
5
66 1
67 1
68 1
65 4
20 3
5
66 1
67 1
68 1
65 5
38 3
5
66 1
67 1
68 1
65 5
22 3
5
66 1
67 1
68 1
65 5
35 3
5
66 1
67 1
68 1
65 5
35 3
5
66 1
67 1
68 1
65 5
35 3
5
66 1
67 1
68 1
65 4
47 3
5
66 1
67 1
68 1
65 4
46 3
6
66 2
67 2
68 2
65 8
23 3
38 3
6
66 2
67 2
68 2
65 8
21 3
48 3
6
66 2
67 2
68 2
65 8
24 3
51 3
6
66 2
67 2
68 2
65 8
49 3
25 3
6
66 2
67 2
68 2
65 8
26 3
50 3
5
66 1
67 1
68 1
65 5
34 3
5
66 1
67 1
68 1
65 6
47 3
5
66 1
67 1
68 1
65 6
46 3
5
66 1
67 1
68 1
65 6
37 3
6
66 2
67 2
68 2
65 9
16 3
34 3
6
66 2
67 2
68 2
65 9
21 3
27 3
6
66 2
67 2
68 2
65 9
20 3
44 3
6
66 2
67 2
68 2
65 9
38 3
39 3
6
66 2
67 2
68 2
65 9
24 3
43 3
6
66 2
67 2
68 2
65 9
23 3
52 3
6
66 2
67 2
68 2
65 9
53 3
26 3
6
66 2
67 2
68 2
65 9
25 3
54 3
6
66 2
67 2
68 2
65 9
44 3
49 3
6
66 2
67 2
68 2
65 9
58 3
46 3
6
66 2
67 2
68 2
65 9
55 3
59 3
6
66 2
67 2
68 2
65 9
59 3
45 3
6
66 2
67 2
68 2
65 9
50 3
47 3
6
66 2
67 2
68 2
65 8
40 3
36 3
6
66 2
67 2
68 2
65 9
35 3
36 3
7
66 3
67 3
68 3
65 12
17 3
19 3
15 3
5
66 1
67 1
68 1
65 7
33 3
7
66 3
67 3
68 3
65 12
18 3
32 3
33 3
7
66 3
67 3
68 3
65 12
57 3
29 3
18 3
5
66 1
67 1
68 1
65 7
43 3
7
66 3
67 3
68 3
65 12
43 3
22 3
57 3
7
66 3
67 3
68 3
65 12
30 3
41 3
32 3
7
66 3
67 3
68 3
65 12
45 3
58 3
40 3
7
66 3
67 3
68 3
65 12
48 3
51 3
56 3
6
66 2
67 2
68 2
65 10
38 3
52 3
6
66 2
67 2
68 2
65 10
48 3
61 3
6
66 2
67 2
68 2
65 10
64 3
60 3
7
66 3
67 3
68 3
65 13
17 3
28 3
47 3
7
66 3
67 3
68 3
65 13
16 3
31 3
46 3
7
66 3
67 3
68 3
65 13
44 3
42 3
62 3
7
66 3
67 3
68 3
65 13
27 3
61 3
53 3
7
66 3
67 3
68 3
65 13
54 3
58 3
31 3
7
66 3
67 3
68 3
65 13
42 3
52 3
55 3
7
66 3
67 3
68 3
65 13
51 3
43 3
57 3
7
66 3
67 3
68 3
65 13
49 3
63 3
54 3
7
66 3
67 3
68 3
65 13
53 3
60 3
50 3
7
66 3
67 3
68 3
65 13
51 3
56 3
57 3
7
66 3
67 3
68 3
65 13
62 3
55 3
59 3
8
66 4
67 4
68 4
65 16
52 3
55 3
39 3
37 3
8
66 4
67 4
68 4
65 16
60 3
50 3
41 3
28 3
8
66 4
67 4
68 4
65 16
56 3
64 3
29 3
30 3
8
66 4
67 4
68 4
65 16
63 3
54 3
45 3
58 3
8
66 4
67 4
68 4
65 16
44 3
49 3
62 3
63 3
8
66 4
67 4
68 4
65 16
48 3
61 3
56 3
64 3
8
66 4
67 4
68 4
65 16
61 3
53 3
64 3
60 3
8
66 4
67 4
68 4
65 16
62 3
63 3
59 3
45 3
68
66 148
67 148
68 148
16 9
17 9
0 3
19 12
34 15
15 9
1 3
10 6
2 3
20 12
21 12
11 6
12 6
24 12
23 12
38 15
3 3
27 12
44 18
48 21
42 15
51 21
52 21
43 18
22 12
4 3
13 6
49 21
61 24
62 24
56 21
55 21
57 24
39 15
25 12
53 21
63 24
64 24
59 24
29 12
37 15
5 3
26 12
54 21
60 24
45 18
30 12
18 9
35 15
6 3
14 6
50 21
58 24
41 15
40 15
32 12
36 15
33 12
7 3
31 12
28 12
8 3
47 21
46 21
9 3
66
65 148
16 3
17 3
0 1
19 4
34 5
15 3
1 1
10 2
2 1
20 4
21 4
11 2
12 2
24 4
23 4
38 5
3 1
27 4
44 6
48 7
42 5
51 7
52 7
43 6
22 4
4 1
13 2
49 7
61 8
62 8
56 7
55 7
57 8
39 5
25 4
53 7
63 8
64 8
59 8
29 4
37 5
5 1
26 4
54 7
60 8
45 6
30 4
18 3
35 5
6 1
14 2
50 7
58 8
41 5
40 5
32 4
36 5
33 4
7 1
31 4
28 4
8 1
47 7
46 7
9 1
66
65 148
16 3
17 3
0 1
19 4
34 5
15 3
1 1
10 2
2 1
20 4
21 4
11 2
12 2
24 4
23 4
38 5
3 1
27 4
44 6
48 7
42 5
51 7
52 7
43 6
22 4
4 1
13 2
49 7
61 8
62 8
56 7
55 7
57 8
39 5
25 4
53 7
63 8
64 8
59 8
29 4
37 5
5 1
26 4
54 7
60 8
45 6
30 4
18 3
35 5
6 1
14 2
50 7
58 8
41 5
40 5
32 4
36 5
33 4
7 1
31 4
28 4
8 1
47 7
46 7
9 1
66
65 148
16 3
17 3
0 1
19 4
34 5
15 3
1 1
10 2
2 1
20 4
21 4
11 2
12 2
24 4
23 4
38 5
3 1
27 4
44 6
48 7
42 5
51 7
52 7
43 6
22 4
4 1
13 2
49 7
61 8
62 8
56 7
55 7
57 8
39 5
25 4
53 7
63 8
64 8
59 8
29 4
37 5
5 1
26 4
54 7
60 8
45 6
30 4
18 3
35 5
6 1
14 2
50 7
58 8
41 5
40 5
32 4
36 5
33 4
7 1
31 4
28 4
8 1
47 7
46 7
9 1
end_CG
