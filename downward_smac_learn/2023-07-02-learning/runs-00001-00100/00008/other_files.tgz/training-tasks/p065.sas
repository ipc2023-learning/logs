begin_version
3
end_version
begin_metric
0
end_metric
54
begin_variable
var4
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var3
-1
50
Atom at-robot(loc_10_3)
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_10_8)
Atom at-robot(loc_10_9)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_10)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_10)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_10)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_7)
Ato




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





46
415
2
50 44
47 0
4
2
379
2
50 39
16 0
39
157
2
50 2
48 0
45
436
2
50 47
44 0
47
421
2
50 45
46 0
4
3
391
2
50 40
29 0
40
166
2
50 3
49 0
46
442
2
50 48
47 0
48
430
2
50 46
33 0
4
4
397
2
50 41
17 0
41
172
2
50 4
20 0
47
448
2
50 49
46 0
49
439
2
50 47
15 0
2
5
403
2
50 42
10 0
42
178
2
50 5
14 0
end_DTG
begin_DTG
0
0
2
1
161
2
50 3
9 0
3
149
2
50 1
29 0
2
2
170
2
50 4
16 0
4
155
2
50 2
17 0
2
3
176
2
50 5
29 0
5
164
2
50 3
10 0
0
0
0
0
0
0
0
4
6
251
2
50 20
1 0
11
209
2
50 13
5 0
13
200
2
50 11
37 0
20
182
2
50 6
35 0
2
12
218
2
50 14
40 0
14
203
2
50 12
41 0
4
7
266
2
50 22
2 0
13
224
2
50 15
37 0
15
212
2
50 13
28 0
22
185
2
50 7
34 0
2
14
230
2
50 16
41 0
16
221
2
50 14
36 0
2
15
239
2
50 17
28 0
17
227
2
50 15
39 0
4
8
290
2
50 25
3 0
16
245
2
50 18
36 0
18
233
2
50 16
31 0
25
188
2
50 8
32 0
4
9
299
2
50 26
4 0
10
242
2
50 17
11 0
17
194
2
50 10
39 0
26
191
2
50 9
18 0
2
10
305
2
50 27
11 0
27
197
2
50 10
6 0
2
12
308
2
50 28
40 0
28
206
2
50 12
26 0
4
13
314
2
50 29
37 0
20
269
2
50 22
35 0
22
254
2
50 20
34 0
29
215
2
50 13
24 0
2
21
275
2
50 23
42 0
23
260
2
50 21
23 0
2
22
281
2
50 24
34 0
24
272
2
50 22
45 0
4
16
320
2
50 30
36 0
23
293
2
50 25
23 0
25
278
2
50 23
32 0
30
236
2
50 16
22 0
2
24
302
2
50 26
45 0
26
284
2
50 24
18 0
2
19
296
2
50 25
12 0
25
248
2
50 19
32 0
0
2
20
326
2
50 31
35 0
31
257
2
50 20
27 0
2
21
332
2
50 32
42 0
32
263
2
50 21
25 0
2
24
341
2
50 34
45 0
34
287
2
50 24
21 0
2
28
350
2
50 36
26 0
36
311
2
50 28
30 0
2
29
359
2
50 37
24 0
37
317
2
50 29
43 0
0
2
30
383
2
50 40
22 0
40
323
2
50 30
49 0
0
2
31
407
2
50 43
27 0
43
329
2
50 31
13 0
4
32
413
2
50 44
25 0
36
365
2
50 38
30 0
38
353
2
50 36
38 0
44
335
2
50 32
19 0
2
37
374
2
50 39
43 0
39
362
2
50 37
48 0
4
33
425
2
50 46
7 0
38
386
2
50 40
38 0
40
368
2
50 38
49 0
46
338
2
50 33
47 0
4
34
434
2
50 47
21 0
39
395
2
50 41
48 0
41
377
2
50 39
20 0
47
344
2
50 34
46 0
2
40
401
2
50 42
49 0
42
389
2
50 40
14 0
2
35
446
2
50 49
8 0
49
347
2
50 35
15 0
2
0
356
2
50 36
0 0
36
146
2
50 0
30 0
2
43
419
2
50 45
13 0
45
410
2
50 43
44 0
4
1
371
2
50 38
9 0
38
152
2
50 1
38 0
44
428
2
50 46
19 0
46
416
2
50 44
47 0
4
2
380
2
50 39
16 0
39
158
2
50 2
48 0
45
437
2
50 47
44 0
47
422
2
50 45
46 0
4
3
392
2
50 40
29 0
40
167
2
50 3
49 0
46
443
2
50 48
47 0
48
431
2
50 46
33 0
4
4
398
2
50 41
17 0
41
173
2
50 4
20 0
47
449
2
50 49
46 0
49
440
2
50 47
15 0
2
5
404
2
50 42
10 0
42
179
2
50 5
14 0
end_DTG
begin_CG
5
51 1
52 1
53 1
50 4
13 3
5
51 1
52 1
53 1
50 4
40 3
5
51 1
52 1
53 1
50 4
41 3
5
51 1
52 1
53 1
50 5
39 3
5
51 1
52 1
53 1
50 5
31 3
5
51 1
52 1
53 1
50 4
40 3
5
51 1
52 1
53 1
50 4
12 3
5
51 1
52 1
53 1
50 5
48 3
5
51 1
52 1
53 1
50 4
14 3
6
51 2
52 2
53 2
50 8
16 3
44 3
6
51 2
52 2
53 2
50 8
17 3
15 3
6
51 2
52 2
53 2
50 8
31 3
12 3
5
51 1
52 1
53 1
50 6
18 3
6
51 2
52 2
53 2
50 9
30 3
19 3
6
51 2
52 2
53 2
50 9
20 3
15 3
6
51 2
52 2
53 2
50 9
14 3
33 3
6
51 2
52 2
53 2
50 9
29 3
47 3
6
51 2
52 2
53 2
50 9
29 3
33 3
6
51 2
52 2
53 2
50 9
31 3
32 3
6
51 2
52 2
53 2
50 9
43 3
44 3
6
51 2
52 2
53 2
50 9
49 3
33 3
6
51 2
52 2
53 2
50 9
22 3
49 3
6
51 2
52 2
53 2
50 8
45 3
21 3
6
51 2
52 2
53 2
50 9
34 3
45 3
6
51 2
52 2
53 2
50 9
42 3
25 3
6
51 2
52 2
53 2
50 9
24 3
43 3
6
51 2
52 2
53 2
50 9
35 3
27 3
6
51 2
52 2
53 2
50 9
26 3
30 3
6
51 2
52 2
53 2
50 9
41 3
36 3
7
51 3
52 3
53 3
50 12
16 3
17 3
46 3
7
51 3
52 3
53 3
50 12
27 3
43 3
13 3
5
51 1
52 1
53 1
50 7
39 3
7
51 3
52 3
53 3
50 12
39 3
45 3
18 3
5
51 1
52 1
53 1
50 7
46 3
7
51 3
52 3
53 3
50 12
41 3
42 3
23 3
7
51 3
52 3
53 3
50 12
40 3
42 3
26 3
7
51 3
52 3
53 3
50 12
28 3
39 3
45 3
7
51 3
52 3
53 3
50 12
40 3
41 3
42 3
7
51 3
52 3
53 3
50 12
43 3
48 3
44 3
6
51 2
52 2
53 2
50 10
36 3
31 3
6
51 2
52 2
53 2
50 10
37 3
35 3
6
51 2
52 2
53 2
50 10
37 3
28 3
6
51 2
52 2
53 2
50 10
34 3
24 3
6
51 2
52 2
53 2
50 10
25 3
38 3
6
51 2
52 2
53 2
50 10
19 3
47 3
7
51 3
52 3
53 3
50 13
23 3
32 3
22 3
7
51 3
52 3
53 3
50 13
49 3
47 3
33 3
7
51 3
52 3
53 3
50 13
48 3
44 3
46 3
7
51 3
52 3
53 3
50 13
38 3
49 3
47 3
8
51 4
52 4
53 4
50 16
21 3
48 3
20 3
46 3
53
51 102
52 102
53 102
0 3
9 6
16 12
29 15
17 12
10 6
1 3
2 3
3 3
4 3
11 6
5 3
40 18
37 15
41 18
28 12
36 15
39 18
31 15
12 9
35 15
42 18
34 15
23 12
45 21
32 15
18 12
6 3
26 12
24 12
22 12
27 12
25 12
7 3
21 12
8 3
30 15
43 18
38 15
48 21
49 24
20 12
14 12
13 12
19 12
44 18
47 21
46 21
33 15
15 12
51
50 102
0 1
9 2
16 4
29 5
17 4
10 2
1 1
2 1
3 1
4 1
11 2
5 1
40 6
37 5
41 6
28 4
36 5
39 6
31 5
12 3
35 5
42 6
34 5
23 4
45 7
32 5
18 4
6 1
26 4
24 4
22 4
27 4
25 4
7 1
21 4
8 1
30 5
43 6
38 5
48 7
49 8
20 4
14 4
13 4
19 4
44 6
47 7
46 7
33 5
15 4
51
50 102
0 1
9 2
16 4
29 5
17 4
10 2
1 1
2 1
3 1
4 1
11 2
5 1
40 6
37 5
41 6
28 4
36 5
39 6
31 5
12 3
35 5
42 6
34 5
23 4
45 7
32 5
18 4
6 1
26 4
24 4
22 4
27 4
25 4
7 1
21 4
8 1
30 5
43 6
38 5
48 7
49 8
20 4
14 4
13 4
19 4
44 6
47 7
46 7
33 5
15 4
51
50 102
0 1
9 2
16 4
29 5
17 4
10 2
1 1
2 1
3 1
4 1
11 2
5 1
40 6
37 5
41 6
28 4
36 5
39 6
31 5
12 3
35 5
42 6
34 5
23 4
45 7
32 5
18 4
6 1
26 4
24 4
22 4
27 4
25 4
7 1
21 4
8 1
30 5
43 6
38 5
48 7
49 8
20 4
14 4
13 4
19 4
44 6
47 7
46 7
33 5
15 4
end_CG
