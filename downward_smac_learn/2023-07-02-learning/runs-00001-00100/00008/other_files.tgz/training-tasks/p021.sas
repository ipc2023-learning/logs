begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var2
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
24
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_5)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_5)
end_variable
22
begin_mutex_group
2
23 0
0 0
end_mutex_group
begin_mutex_group
2
23 1
7 0
end_mutex_group
begin_mutex_group
2
23 2
6 0
end_mutex_group
begin_mutex_group
2
23 3
1 0
end_mutex_group
begin_mutex_group
2
23 4
9 0
end_mutex_group
begin_mutex_group
2
23 5
8 0
end_mutex_group
begin_mutex_group
2
23 6
10 0
end_mutex_group
begin_mutex_group
2
23 7
13 0
end_mutex_group
begin_mutex_group
2
23 8
20 0
end_mutex_group
begin_mutex_group
2
23 9
16 0
end_mutex_group
begin_mutex_group
2
23 10
2 0
end_mutex_group
begin_mutex_group
2
23 11
18 0
end_mutex_group
begin_mutex_group
2
23 12
17 0
end_mutex_group
begin_mutex_group
2
23 13
21 0
end_mutex_group
begin_mutex_group
2
23 14
14 0
end_mutex_group
begin_mutex_group
2
23 15
12 0
end_mutex_group
begin_mutex_group
2
23 16
15 0
end_mutex_group
begin_mutex_group
2
23 17
19 0
end_mutex_group
begin_mutex_group
2
23 18
11 0
end_mutex_group
begin_mutex_group
2
23 19
3 0
end_mutex_group
begin_mutex_group
2
23 20
4 0
end_mutex_group
begin_mutex_group
2
23 21
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
11
4
end_state
begin_goal
1
23 6
end_goal
102
begin_operator
move loc_2_2 loc_3_2 down
0
1
0 22 0 4
0
end_operator
begin_operator
move loc_2_4 loc_2_5 right
1
7 0
1
0 22 1 2
0
end_operator
begin_operator
move loc_2_5 loc_2_4 left
1
0 0
1
0 22 2 1
0
end_operator
begin_operator
move loc_2_5 loc_2_6 right
1
6 0
1
0 22 2 3
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
9 0
1
0 22 2 6
0
end_operator
begin_operator
move loc_2_6 loc_2_5 left
1
7 0
1
0 22 3 2
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
8 0
1
0 22 3 7
0
end_operator
begin_operator
move loc_3_2 loc_2_2 up
0
1
0 22 4 0
0
end_operator
begin_operator
move loc_3_2 loc_3_3 right
1
1 0
1
0 22 4 5
0
end_operator
begin_operator
move loc_3_3 loc_3_2 left
0
1
0 22 5 4
0
end_operator
begin_operator
move loc_3_3 loc_4_3 down
1
10 0
1
0 22 5 8
0
end_operator
begin_operator
move loc_3_5 loc_2_5 up
1
7 0
1
0 22 6 2
0
end_operator
begin_operator
move loc_3_5 loc_3_6 right
1
8 0
1
0 22 6 7
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




end_DTG
begin_DTG
1
1
80
2
23 6
22 13
0
end_DTG
begin_DTG
1
1
83
2
23 11
22 14
0
end_DTG
begin_DTG
1
1
96
2
23 18
22 19
0
end_DTG
begin_DTG
1
1
82
2
23 15
22 13
0
end_DTG
begin_DTG
1
1
87
2
23 17
22 15
0
end_DTG
begin_DTG
2
1
62
2
23 1
22 1
1
76
2
23 5
22 11
0
end_DTG
begin_DTG
1
1
73
2
23 4
22 10
2
0
62
3
23 1
22 1
6 0
0
64
3
23 1
22 3
0 0
end_DTG
begin_DTG
1
1
88
2
23 9
22 16
2
0
65
3
23 5
22 3
16 0
0
76
3
23 5
22 11
6 0
end_DTG
begin_DTG
1
1
85
2
23 8
22 15
2
0
63
3
23 4
22 2
20 0
0
73
3
23 4
22 10
7 0
end_DTG
begin_DTG
2
1
74
2
23 7
22 10
1
90
2
23 11
22 17
2
0
66
3
23 6
22 5
18 0
0
80
3
23 6
22 13
1 0
end_DTG
begin_DTG
2
1
78
2
23 14
22 11
1
93
2
23 17
22 18
2
0
96
3
23 18
22 19
3 0
0
99
3
23 18
22 21
19 0
end_DTG
begin_DTG
2
1
70
2
23 11
22 8
1
95
2
23 16
22 19
2
0
82
3
23 15
22 13
4 0
0
100
3
23 15
22 22
18 0
end_DTG
begin_DTG
2
1
77
2
23 8
22 11
1
92
2
23 12
22 18
2
0
69
3
23 7
22 8
20 0
0
74
3
23 7
22 10
10 0
end_DTG
begin_DTG
2
1
68
2
23 9
22 7
1
84
2
23 13
22 14
2
0
78
3
23 14
22 11
11 0
0
97
3
23 14
22 20
16 0
end_DTG
begin_DTG
2
1
72
2
23 12
22 9
1
98
2
23 17
22 20
2
0
91
3
23 16
22 17
19 0
0
95
3
23 16
22 19
12 0
end_DTG
begin_DTG
3
1
65
2
23 5
22 3
1
71
2
23 8
22 9
1
97
2
23 14
22 20
2
0
68
3
23 9
22 7
14 0
0
88
3
23 9
22 16
8 0
end_DTG
begin_DTG
2
1
79
2
23 11
22 12
1
89
2
23 13
22 16
4
0
72
3
23 12
22 9
15 0
0
81
3
23 12
22 13
21 0
0
86
3
23 12
22 15
18 0
0
92
3
23 12
22 18
13 0
end_DTG
begin_DTG
3
1
66
2
23 6
22 5
1
86
2
23 12
22 15
1
100
2
23 15
22 22
4
0
70
3
23 11
22 8
12 0
0
79
3
23 11
22 12
17 0
0
83
3
23 11
22 14
2 0
0
90
3
23 11
22 17
10 0
end_DTG
begin_DTG
3
1
75
2
23 13
22 10
1
91
2
23 16
22 17
1
99
2
23 18
22 21
4
0
87
3
23 17
22 15
5 0
0
93
3
23 17
22 18
11 0
0
98
3
23 17
22 20
15 0
0
101
3
23 17
22 23
21 0
end_DTG
begin_DTG
3
1
63
2
23 4
22 2
1
69
2
23 7
22 8
1
94
2
23 13
22 19
4
0
67
3
23 8
22 6
21 0
0
71
3
23 8
22 9
16 0
0
77
3
23 8
22 11
13 0
0
85
3
23 8
22 15
9 0
end_DTG
begin_DTG
3
1
67
2
23 8
22 6
1
81
2
23 12
22 13
1
101
2
23 17
22 23
4
0
75
3
23 13
22 10
19 0
0
84
3
23 13
22 14
14 0
0
89
3
23 13
22 16
17 0
0
94
3
23 13
22 19
20 0
end_DTG
begin_DTG
1
4
0
0
2
2
1
1
7 0
2
62
2
23 1
6 0
4
1
2
1
0 0
3
3
1
6 0
6
4
1
9 0
6
63
2
23 4
20 0
4
2
5
1
7 0
2
64
2
23 1
0 0
7
6
1
8 0
7
65
2
23 5
16 0
2
0
7
0
5
8
1
1 0
3
4
9
0
8
10
1
10 0
8
66
2
23 6
18 0
4
2
11
1
7 0
7
12
1
8 0
10
13
1
20 0
10
67
2
23 8
21 0
4
3
14
1
6 0
6
15
1
9 0
11
16
1
16 0
11
68
2
23 9
14 0
5
5
17
1
1 0
9
18
1
13 0
9
69
2
23 7
20 0
13
19
1
18 0
13
70
2
23 11
12 0
5
8
20
1
10 0
10
21
1
20 0
10
71
2
23 8
16 0
14
22
1
17 0
14
72
2
23 12
15 0
7
6
23
1
9 0
6
73
2
23 4
7 0
9
24
1
13 0
9
74
2
23 7
10 0
11
25
1
16 0
15
26
1
21 0
15
75
2
23 13
19 0
6
7
27
1
8 0
7
76
2
23 5
6 0
10
28
1
20 0
10
77
2
23 8
13 0
16
29
1
14 0
16
78
2
23 14
11 0
2
13
30
1
18 0
13
79
2
23 11
17 0
7
8
31
1
10 0
8
80
2
23 6
1 0
12
32
1
2 0
14
33
1
17 0
14
81
2
23 12
21 0
17
34
1
12 0
17
82
2
23 15
4 0
6
9
35
1
13 0
13
36
1
18 0
13
83
2
23 11
2 0
15
37
1
21 0
15
84
2
23 13
14 0
18
38
1
15 0
7
10
39
1
20 0
10
85
2
23 8
9 0
14
40
1
17 0
14
86
2
23 12
18 0
16
41
1
14 0
19
42
1
19 0
19
87
2
23 17
5 0
5
11
43
1
16 0
11
88
2
23 9
8 0
15
44
1
21 0
15
89
2
23 13
17 0
20
45
1
11 0
5
13
46
1
18 0
13
90
2
23 11
10 0
18
47
1
15 0
18
91
2
23 16
19 0
22
48
1
4 0
5
14
49
1
17 0
14
92
2
23 12
13 0
17
50
1
12 0
19
51
1
19 0
19
93
2
23 17
11 0
7
15
52
1
21 0
15
94
2
23 13
20 0
18
53
1
15 0
18
95
2
23 16
12 0
20
54
1
11 0
20
96
2
23 18
3 0
23
55
1
5 0
5
16
56
1
14 0
16
97
2
23 14
16 0
19
57
1
19 0
19
98
2
23 17
15 0
21
58
1
3 0
2
20
59
1
11 0
20
99
2
23 18
19 0
2
17
60
1
12 0
17
100
2
23 15
18 0
2
19
61
1
19 0
19
101
2
23 17
21 0
end_DTG
begin_DTG
0
2
0
64
2
22 3
0 0
2
62
2
22 1
6 0
0
0
2
1
73
2
22 10
7 0
8
63
2
22 2
20 0
2
2
76
2
22 11
6 0
9
65
2
22 3
16 0
2
3
80
2
22 13
1 0
11
66
2
22 5
18 0
2
6
74
2
22 10
10 0
8
69
2
22 8
20 0
4
4
85
2
22 15
9 0
7
77
2
22 11
13 0
9
71
2
22 9
16 0
13
67
2
22 6
21 0
2
5
88
2
22 16
8 0
14
68
2
22 7
14 0
0
4
6
90
2
22 17
10 0
10
83
2
22 14
2 0
12
79
2
22 12
17 0
15
70
2
22 8
12 0
4
7
92
2
22 18
13 0
11
86
2
22 15
18 0
13
81
2
22 13
21 0
16
72
2
22 9
15 0
4
8
94
2
22 19
20 0
12
89
2
22 16
17 0
14
84
2
22 14
14 0
17
75
2
22 10
19 0
2
9
97
2
22 20
16 0
18
78
2
22 11
11 0
2
11
100
2
22 22
18 0
20
82
2
22 13
4 0
2
15
95
2
22 19
12 0
17
91
2
22 17
19 0
4
13
101
2
22 23
21 0
16
98
2
22 20
15 0
18
93
2
22 18
11 0
21
87
2
22 15
5 0
2
17
99
2
22 21
19 0
19
96
2
22 19
3 0
0
0
0
end_DTG
begin_CG
3
23 1
22 2
7 1
3
23 1
22 3
10 1
3
23 1
22 2
18 1
3
23 1
22 2
11 1
3
23 1
22 2
12 1
3
23 1
22 2
19 1
4
23 2
22 4
7 1
8 1
3
23 1
22 4
9 1
3
23 1
22 4
16 1
3
23 1
22 4
20 1
4
23 2
22 5
13 1
18 1
4
23 2
22 5
14 1
19 1
4
23 2
22 5
18 1
15 1
4
23 2
22 5
20 1
17 1
4
23 2
22 5
16 1
21 1
4
23 2
22 5
17 1
19 1
5
23 3
22 6
8 1
20 1
14 1
4
23 2
22 6
18 1
21 1
5
23 3
22 7
10 1
17 1
12 1
5
23 3
22 7
21 1
15 1
11 1
5
23 3
22 7
9 1
13 1
21 1
5
23 3
22 7
20 1
17 1
19 1
23
23 40
0 1
7 3
6 2
1 1
9 3
8 3
10 4
13 4
20 7
16 5
2 1
18 7
17 6
21 7
14 4
12 4
15 4
19 7
11 4
3 1
4 1
5 1
23
22 40
0 1
7 3
6 2
1 1
9 3
8 3
10 4
13 4
20 7
16 5
2 1
18 7
17 6
21 7
14 4
12 4
15 4
19 7
11 4
3 1
4 1
5 1
end_CG
