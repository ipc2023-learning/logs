begin_version
3
end_version
begin_metric
0
end_metric
106
begin_variable
var23
-1
2
Atom clear(loc_12_12)
NegatedAtom clear(loc_12_12)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_2_12)
NegatedAtom clear(loc_2_12)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_5_12)
NegatedAtom clear(loc_5_12)
end_variable
begin_variable
var76
-1
2
Atom clear(loc_7_12)
NegatedAtom clear(loc_7_12)
end_variable
begin_variable
var77
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_12_6)
NegatedAtom clear(loc_12_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_4_12)
NegatedAtom clear(loc_4_12)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_3_12)
NegatedAtom clear(loc_3_12)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_12)
NegatedAtom clear(loc_11_12)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var99
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var88
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var87
-1
2
Atom clear(loc_8_12)
NegatedAtom clear(loc_8_12)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var103
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_12)
NegatedAtom clear(loc_10_12)
end_variable
begin_variable
var98
-1
2
Atom clear(loc_9_12)
NegatedAtom clear(loc_9_12)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var104
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var94
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var105
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var100
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variab




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




03 3
104 3
105 3
101 15
61 4
62 4
70 4
8
102 3
103 3
104 3
105 3
101 15
77 4
82 4
86 4
8
102 3
103 3
104 3
105 3
101 15
65 4
86 4
74 4
7
102 2
103 2
104 2
105 2
101 12
35 4
36 4
7
102 2
103 2
104 2
105 2
101 12
63 4
41 4
7
102 2
103 2
104 2
105 2
101 12
69 4
71 4
7
102 2
103 2
104 2
105 2
101 12
66 4
83 4
7
102 2
103 2
104 2
105 2
101 12
67 4
72 4
8
102 3
103 3
104 3
105 3
101 16
45 4
33 4
44 4
7
102 2
103 2
104 2
105 2
101 12
84 4
96 4
8
102 3
103 3
104 3
105 3
101 16
36 4
48 4
51 4
7
102 2
103 2
104 2
105 2
101 12
75 4
89 4
8
102 3
103 3
104 3
105 3
101 16
42 4
16 4
55 4
8
102 3
103 3
104 3
105 3
101 16
25 4
83 4
46 4
8
102 3
103 3
104 3
105 3
101 16
67 4
31 4
53 4
8
102 3
103 3
104 3
105 3
101 16
57 4
45 4
84 4
8
102 3
103 3
104 3
105 3
101 16
58 4
65 4
74 4
8
102 3
103 3
104 3
105 3
101 16
47 4
91 4
69 4
8
102 3
103 3
104 3
105 3
101 16
68 4
90 4
56 4
8
102 3
103 3
104 3
105 3
101 16
51 4
89 4
73 4
8
102 3
103 3
104 3
105 3
101 16
90 4
56 4
81 4
8
102 3
103 3
104 3
105 3
101 16
58 4
73 4
74 4
8
102 3
103 3
104 3
105 3
101 16
70 4
88 4
72 4
8
102 3
103 3
104 3
105 3
101 16
67 4
88 4
72 4
8
102 3
103 3
104 3
105 3
101 16
62 4
76 4
87 4
8
102 3
103 3
104 3
105 3
101 16
94 4
75 4
77 4
8
102 3
103 3
104 3
105 3
101 16
76 4
93 4
87 4
8
102 3
103 3
104 3
105 3
101 16
99 4
92 4
82 4
8
102 3
103 3
104 3
105 3
101 16
83 4
95 4
80 4
8
102 3
103 3
104 3
105 3
101 16
79 4
98 4
91 4
9
102 4
103 4
104 4
105 4
101 20
39 4
92 4
71 4
32 4
9
102 4
103 4
104 4
105 4
101 20
93 4
78 4
52 4
43 4
9
102 4
103 4
104 4
105 4
101 20
57 4
64 4
84 4
79 4
9
102 4
103 4
104 4
105 4
101 20
66 4
83 4
60 4
95 4
9
102 4
103 4
104 4
105 4
101 20
44 4
96 4
50 4
94 4
9
102 4
103 4
104 4
105 4
101 20
87 4
88 4
52 4
53 4
9
102 4
103 4
104 4
105 4
101 20
75 4
89 4
77 4
86 4
9
102 4
103 4
104 4
105 4
101 20
89 4
73 4
86 4
74 4
9
102 4
103 4
104 4
105 4
101 20
62 4
70 4
87 4
88 4
9
102 4
103 4
104 4
105 4
101 20
91 4
69 4
92 4
71 4
9
102 4
103 4
104 4
105 4
101 20
80 4
68 4
97 4
90 4
9
102 4
103 4
104 4
105 4
101 20
97 4
90 4
78 4
81 4
9
102 4
103 4
104 4
105 4
101 20
94 4
99 4
77 4
82 4
9
102 4
103 4
104 4
105 4
101 20
85 4
100 4
76 4
93 4
9
102 4
103 4
104 4
105 4
101 20
84 4
79 4
96 4
98 4
9
102 4
103 4
104 4
105 4
101 20
60 4
95 4
85 4
100 4
9
102 4
103 4
104 4
105 4
101 20
98 4
91 4
99 4
92 4
9
102 4
103 4
104 4
105 4
101 20
95 4
80 4
100 4
97 4
9
102 4
103 4
104 4
105 4
101 20
100 4
97 4
93 4
78 4
9
102 4
103 4
104 4
105 4
101 20
96 4
98 4
94 4
99 4
105
102 272
103 272
104 272
105 272
67 28
58 24
37 20
2 8
20 16
30 16
39 20
42 20
31 16
65 28
40 20
29 16
19 16
23 16
16 12
63 28
55 24
41 20
0 4
3 8
13 12
17 16
4 8
28 16
24 16
5 8
6 8
12 12
7 8
8 8
14 12
27 16
35 16
54 24
18 16
25 16
57 24
66 28
45 20
59 28
33 16
34 16
36 16
15 12
1 4
64 28
83 32
84 32
60 24
44 20
48 20
61 28
9 8
46 20
79 28
95 32
96 32
85 32
50 20
49 20
62 24
51 20
47 20
80 28
98 32
100 32
94 32
76 28
75 28
89 32
70 28
10 8
11 8
68 28
91 32
97 32
99 32
93 32
77 28
87 32
88 32
73 28
26 16
22 16
69 28
90 32
92 32
78 28
82 32
52 20
86 32
74 28
72 28
38 20
21 16
56 24
71 28
81 32
32 16
43 20
53 20
102
101 272
67 7
58 6
37 5
2 2
20 4
30 4
39 5
42 5
31 4
65 7
40 5
29 4
19 4
23 4
16 3
63 7
55 6
41 5
0 1
3 2
13 3
17 4
4 2
28 4
24 4
5 2
6 2
12 3
7 2
8 2
14 3
27 4
35 4
54 6
18 4
25 4
57 6
66 7
45 5
59 7
33 4
34 4
36 4
15 3
1 1
64 7
83 8
84 8
60 6
44 5
48 5
61 7
9 2
46 5
79 7
95 8
96 8
85 8
50 5
49 5
62 6
51 5
47 5
80 7
98 8
100 8
94 8
76 7
75 7
89 8
70 7
10 2
11 2
68 7
91 8
97 8
99 8
93 8
77 7
87 8
88 8
73 7
26 4
22 4
69 7
90 8
92 8
78 7
82 8
52 5
86 8
74 7
72 7
38 5
21 4
56 6
71 7
81 8
32 4
43 5
53 5
102
101 272
67 7
58 6
37 5
2 2
20 4
30 4
39 5
42 5
31 4
65 7
40 5
29 4
19 4
23 4
16 3
63 7
55 6
41 5
0 1
3 2
13 3
17 4
4 2
28 4
24 4
5 2
6 2
12 3
7 2
8 2
14 3
27 4
35 4
54 6
18 4
25 4
57 6
66 7
45 5
59 7
33 4
34 4
36 4
15 3
1 1
64 7
83 8
84 8
60 6
44 5
48 5
61 7
9 2
46 5
79 7
95 8
96 8
85 8
50 5
49 5
62 6
51 5
47 5
80 7
98 8
100 8
94 8
76 7
75 7
89 8
70 7
10 2
11 2
68 7
91 8
97 8
99 8
93 8
77 7
87 8
88 8
73 7
26 4
22 4
69 7
90 8
92 8
78 7
82 8
52 5
86 8
74 7
72 7
38 5
21 4
56 6
71 7
81 8
32 4
43 5
53 5
102
101 272
67 7
58 6
37 5
2 2
20 4
30 4
39 5
42 5
31 4
65 7
40 5
29 4
19 4
23 4
16 3
63 7
55 6
41 5
0 1
3 2
13 3
17 4
4 2
28 4
24 4
5 2
6 2
12 3
7 2
8 2
14 3
27 4
35 4
54 6
18 4
25 4
57 6
66 7
45 5
59 7
33 4
34 4
36 4
15 3
1 1
64 7
83 8
84 8
60 6
44 5
48 5
61 7
9 2
46 5
79 7
95 8
96 8
85 8
50 5
49 5
62 6
51 5
47 5
80 7
98 8
100 8
94 8
76 7
75 7
89 8
70 7
10 2
11 2
68 7
91 8
97 8
99 8
93 8
77 7
87 8
88 8
73 7
26 4
22 4
69 7
90 8
92 8
78 7
82 8
52 5
86 8
74 7
72 7
38 5
21 4
56 6
71 7
81 8
32 4
43 5
53 5
102
101 272
67 7
58 6
37 5
2 2
20 4
30 4
39 5
42 5
31 4
65 7
40 5
29 4
19 4
23 4
16 3
63 7
55 6
41 5
0 1
3 2
13 3
17 4
4 2
28 4
24 4
5 2
6 2
12 3
7 2
8 2
14 3
27 4
35 4
54 6
18 4
25 4
57 6
66 7
45 5
59 7
33 4
34 4
36 4
15 3
1 1
64 7
83 8
84 8
60 6
44 5
48 5
61 7
9 2
46 5
79 7
95 8
96 8
85 8
50 5
49 5
62 6
51 5
47 5
80 7
98 8
100 8
94 8
76 7
75 7
89 8
70 7
10 2
11 2
68 7
91 8
97 8
99 8
93 8
77 7
87 8
88 8
73 7
26 4
22 4
69 7
90 8
92 8
78 7
82 8
52 5
86 8
74 7
72 7
38 5
21 4
56 6
71 7
81 8
32 4
43 5
53 5
end_CG
