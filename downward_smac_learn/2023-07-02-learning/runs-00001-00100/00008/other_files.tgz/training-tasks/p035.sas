begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var2
-1
39
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
39
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
39 5
2 0
0
0
4
3
174
2
39 14
25 0
8
158
2
39 10
6 0
10
150
2
39 8
29 0
14
128
2
39 3
23 0
4
4
180
2
39 15
22 0
9
164
2
39 11
28 0
11
154
2
39 9
27 0
15
134
2
39 4
34 0
4
5
186
2
39 16
20 0
10
168
2
39 12
29 0
12
160
2
39 10
18 0
16
140
2
39 5
36 0
2
6
194
2
39 17
11 0
17
144
2
39 6
30 0
0
2
9
212
2
39 21
28 0
21
156
2
39 9
37 0
4
10
220
2
39 22
29 0
14
188
2
39 16
23 0
16
176
2
39 14
36 0
22
162
2
39 10
38 0
4
11
228
2
39 23
27 0
15
196
2
39 17
34 0
17
182
2
39 15
30 0
23
166
2
39 11
35 0
4
12
234
2
39 24
18 0
16
200
2
39 18
36 0
18
190
2
39 16
7 0
24
170
2
39 12
31 0
0
2
13
244
2
39 26
3 0
26
172
2
39 13
13 0
2
19
214
2
39 21
12 0
21
204
2
39 19
37 0
4
14
250
2
39 28
23 0
20
222
2
39 22
19 0
22
208
2
39 20
38 0
28
178
2
39 14
32 0
4
15
256
2
39 29
34 0
21
230
2
39 23
37 0
23
216
2
39 21
35 0
29
184
2
39 15
33 0
4
16
262
2
39 30
36 0
22
236
2
39 24
38 0
24
224
2
39 22
31 0
30
192
2
39 16
24 0
4
17
268
2
39 31
30 0
23
240
2
39 25
35 0
25
232
2
39 23
15 0
31
198
2
39 17
26 0
2
18
272
2
39 32
7 0
32
202
2
39 18
14 0
2
19
276
2
39 33
12 0
33
206
2
39 19
8 0
4
20
280
2
39 34
19 0
26
252
2
39 28
13 0
28
246
2
39 26
32 0
34
210
2
39 20
16 0
4
21
284
2
39 35
37 0
27
258
2
39 29
21 0
29
248
2
39 27
33 0
35
218
2
39 21
17 0
4
22
288
2
39 36
38 0
28
264
2
39 30
32 0
30
254
2
39 28
24 0
36
226
2
39 22
9 0
2
29
270
2
39 31
33 0
31
260
2
39 29
26 0
4
24
292
2
39 37
31 0
30
274
2
39 32
24 0
32
266
2
39 30
14 0
37
238
2
39 24
4 0
2
25
294
2
39 38
15 0
38
242
2
39 25
5 0
0
2
33
286
2
39 35
8 0
35
278
2
39 33
17 0
2
34
290
2
39 36
16 0
36
282
2
39 34
9 0
0
0
0
end_DTG
begin_DTG
0
0
2
0
149
2
39 8
0 0
8
121
2
39 0
6 0
4
1
153
2
39 9
1 0
2
131
2
39 4
10 0
4
125
2
39 2
22 0
9
123
2
39 1
28 0
2
3
137
2
39 5
25 0
5
127
2
39 3
20 0
2
4
143
2
39 6
22 0
6
133
2
39 4
11 0
2
5
147
2
39 7
20 0
7
139
2
39 5
2 0
0
0
4
3
175
2
39 14
25 0
8
159
2
39 10
6 0
10
151
2
39 8
29 0
14
129
2
39 3
23 0
4
4
181
2
39 15
22 0
9
165
2
39 11
28 0
11
155
2
39 9
27 0
15
135
2
39 4
34 0
4
5
187
2
39 16
20 0
10
169
2
39 12
29 0
12
161
2
39 10
18 0
16
141
2
39 5
36 0
2
6
195
2
39 17
11 0
17
145
2
39 6
30 0
0
2
9
213
2
39 21
28 0
21
157
2
39 9
37 0
4
10
221
2
39 22
29 0
14
189
2
39 16
23 0
16
177
2
39 14
36 0
22
163
2
39 10
38 0
4
11
229
2
39 23
27 0
15
197
2
39 17
34 0
17
183
2
39 15
30 0
23
167
2
39 11
35 0
4
12
235
2
39 24
18 0
16
201
2
39 18
36 0
18
191
2
39 16
7 0
24
171
2
39 12
31 0
0
2
13
245
2
39 26
3 0
26
173
2
39 13
13 0
2
19
215
2
39 21
12 0
21
205
2
39 19
37 0
4
14
251
2
39 28
23 0
20
223
2
39 22
19 0
22
209
2
39 20
38 0
28
179
2
39 14
32 0
4
15
257
2
39 29
34 0
21
231
2
39 23
37 0
23
217
2
39 21
35 0
29
185
2
39 15
33 0
4
16
263
2
39 30
36 0
22
237
2
39 24
38 0
24
225
2
39 22
31 0
30
193
2
39 16
24 0
4
17
269
2
39 31
30 0
23
241
2
39 25
35 0
25
233
2
39 23
15 0
31
199
2
39 17
26 0
2
18
273
2
39 32
7 0
32
203
2
39 18
14 0
2
19
277
2
39 33
12 0
33
207
2
39 19
8 0
4
20
281
2
39 34
19 0
26
253
2
39 28
13 0
28
247
2
39 26
32 0
34
211
2
39 20
16 0
4
21
285
2
39 35
37 0
27
259
2
39 29
21 0
29
249
2
39 27
33 0
35
219
2
39 21
17 0
4
22
289
2
39 36
38 0
28
265
2
39 30
32 0
30
255
2
39 28
24 0
36
227
2
39 22
9 0
2
29
271
2
39 31
33 0
31
261
2
39 29
26 0
4
24
293
2
39 37
31 0
30
275
2
39 32
24 0
32
267
2
39 30
14 0
37
239
2
39 24
4 0
2
25
295
2
39 38
15 0
38
243
2
39 25
5 0
0
2
33
287
2
39 35
8 0
35
279
2
39 33
17 0
2
34
291
2
39 36
16 0
36
283
2
39 34
9 0
0
0
0
end_DTG
begin_CG
4
40 1
41 1
39 4
10 2
4
40 1
41 1
39 4
25 2
4
40 1
41 1
39 3
11 2
4
40 1
41 1
39 3
12 2
4
40 1
41 1
39 4
26 2
4
40 1
41 1
39 4
14 2
5
40 2
41 2
39 6
10 2
28 2
5
40 2
41 2
39 6
30 2
15 2
5
40 2
41 2
39 6
13 2
16 2
5
40 2
41 2
39 6
33 2
17 2
4
40 1
41 1
39 5
25 2
5
40 2
41 2
39 7
20 2
18 2
5
40 2
41 2
39 7
19 2
13 2
5
40 2
41 2
39 7
12 2
21 2
5
40 2
41 2
39 7
15 2
26 2
5
40 2
41 2
39 7
31 2
14 2
5
40 2
41 2
39 7
21 2
17 2
5
40 2
41 2
39 7
32 2
16 2
5
40 2
41 2
39 7
27 2
30 2
5
40 2
41 2
39 7
37 2
21 2
6
40 3
41 3
39 9
22 2
11 2
27 2
4
40 1
41 1
39 6
32 2
6
40 3
41 3
39 9
25 2
20 2
29 2
6
40 3
41 3
39 9
28 2
34 2
37 2
6
40 3
41 3
39 9
35 2
33 2
26 2
5
40 2
41 2
39 8
22 2
28 2
5
40 2
41 2
39 8
31 2
24 2
5
40 2
41 2
39 8
29 2
36 2
6
40 3
41 3
39 10
25 2
29 2
23 2
6
40 3
41 3
39 10
28 2
27 2
34 2
6
40 3
41 3
39 10
18 2
36 2
31 2
6
40 3
41 3
39 10
30 2
35 2
26 2
6
40 3
41 3
39 10
37 2
21 2
33 2
6
40 3
41 3
39 10
38 2
32 2
24 2
6
40 3
41 3
39 10
29 2
36 2
38 2
6
40 3
41 3
39 10
36 2
38 2
31 2
7
40 4
41 4
39 12
27 2
34 2
30 2
35 2
7
40 4
41 4
39 12
23 2
19 2
38 2
32 2
7
40 4
41 4
39 12
34 2
37 2
35 2
33 2
41
40 88
41 88
0 2
1 2
10 6
25 12
22 10
20 10
11 8
2 2
6 4
28 14
29 14
27 12
18 8
3 2
23 10
34 14
36 16
30 14
7 4
12 8
19 8
37 16
38 16
35 14
31 14
15 8
13 8
21 10
32 14
33 14
24 10
26 12
14 8
8 4
16 8
17 8
9 4
4 2
5 2
40
39 88
0 1
1 1
10 3
25 6
22 5
20 5
11 4
2 1
6 2
28 7
29 7
27 6
18 4
3 1
23 5
34 7
36 8
30 7
7 2
12 4
19 4
37 8
38 8
35 7
31 7
15 4
13 4
21 5
32 7
33 7
24 5
26 6
14 4
8 2
16 4
17 4
9 2
4 1
5 1
40
39 88
0 1
1 1
10 3
25 6
22 5
20 5
11 4
2 1
6 2
28 7
29 7
27 6
18 4
3 1
23 5
34 7
36 8
30 7
7 2
12 4
19 4
37 8
38 8
35 7
31 7
15 4
13 4
21 5
32 7
33 7
24 5
26 6
14 4
8 2
16 4
17 4
9 2
4 1
5 1
end_CG
