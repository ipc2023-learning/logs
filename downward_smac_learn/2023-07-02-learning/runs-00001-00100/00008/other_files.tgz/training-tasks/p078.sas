begin_version
3
end_version
begin_metric
0
end_metric
81
begin_variable
var4
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_2)
NegatedAtom clear(loc_11_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var79
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var78
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var76
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var5
-1
2
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




68
32 0
57
622
2
77 61
65 0
59
604
2
77 59
37 0
66
556
2
77 51
31 0
2
58
631
2
77 62
70 0
60
616
2
77 60
68 0
4
50
682
2
77 69
53 0
59
643
2
77 63
37 0
61
625
2
77 61
52 0
67
565
2
77 52
38 0
2
60
652
2
77 64
68 0
62
634
2
77 62
50 0
2
61
664
2
77 65
52 0
63
646
2
77 63
42 0
2
54
655
2
77 64
21 0
62
586
2
77 56
50 0
2
55
691
2
77 71
41 0
69
595
2
77 57
12 0
2
57
700
2
77 72
65 0
70
607
2
77 59
49 0
2
58
709
2
77 73
70 0
71
619
2
77 60
63 0
2
60
727
2
77 75
68 0
73
637
2
77 62
69 0
2
69
748
2
77 78
12 0
76
694
2
77 71
25 0
0
2
1
673
2
77 67
58 0
65
244
2
77 2
40 0
4
2
679
2
77 68
64 0
66
253
2
77 3
31 0
70
718
2
77 74
49 0
72
703
2
77 72
54 0
2
71
730
2
77 75
63 0
73
712
2
77 73
69 0
4
4
685
2
77 69
39 0
67
262
2
77 5
38 0
72
736
2
77 76
54 0
74
721
2
77 74
30 0
2
73
742
2
77 77
69 0
75
733
2
77 75
28 0
2
74
751
2
77 78
30 0
76
739
2
77 76
25 0
2
68
745
2
77 77
18 0
75
688
2
77 70
28 0
end_DTG
begin_CG
5
78 1
79 1
80 1
77 5
58 3
5
78 1
79 1
80 1
77 4
15 3
5
78 1
79 1
80 1
77 5
22 3
5
78 1
79 1
80 1
77 5
13 3
5
78 1
79 1
80 1
77 5
66 3
5
78 1
79 1
80 1
77 5
59 3
5
78 1
79 1
80 1
77 5
14 3
5
78 1
79 1
80 1
77 5
57 3
5
78 1
79 1
80 1
77 5
65 3
6
78 2
79 2
80 2
77 8
13 3
14 3
6
78 2
79 2
80 2
77 8
59 3
67 3
6
78 2
79 2
80 2
77 8
16 3
23 3
6
78 2
79 2
80 2
77 8
17 3
18 3
5
78 1
79 1
80 1
77 6
56 3
5
78 1
79 1
80 1
77 6
56 3
5
78 1
79 1
80 1
77 6
24 3
5
78 1
79 1
80 1
77 6
67 3
5
78 1
79 1
80 1
77 5
41 3
5
78 1
79 1
80 1
77 6
25 3
5
78 1
79 1
80 1
77 6
62 3
5
78 1
79 1
80 1
77 6
72 3
5
78 1
79 1
80 1
77 5
42 3
6
78 2
79 2
80 2
77 9
58 3
43 3
6
78 2
79 2
80 2
77 9
20 3
26 3
6
78 2
79 2
80 2
77 9
15 3
27 3
6
78 2
79 2
80 2
77 9
18 3
28 3
6
78 2
79 2
80 2
77 8
23 3
41 3
6
78 2
79 2
80 2
77 8
29 3
24 3
6
78 2
79 2
80 2
77 8
30 3
25 3
6
78 2
79 2
80 2
77 8
44 3
27 3
6
78 2
79 2
80 2
77 8
69 3
28 3
6
78 2
79 2
80 2
77 9
70 3
63 3
6
78 2
79 2
80 2
77 9
57 3
70 3
6
78 2
79 2
80 2
77 9
56 3
46 3
6
78 2
79 2
80 2
77 9
56 3
47 3
6
78 2
79 2
80 2
77 9
48 3
32 3
6
78 2
79 2
80 2
77 9
72 3
60 3
6
78 2
79 2
80 2
77 8
70 3
68 3
6
78 2
79 2
80 2
77 8
68 3
69 3
6
78 2
79 2
80 2
77 9
55 3
69 3
6
78 2
79 2
80 2
77 9
65 3
49 3
7
78 3
79 3
80 3
77 12
26 3
21 3
17 3
7
78 3
79 3
80 3
77 12
36 3
21 3
50 3
7
78 3
79 3
80 3
77 12
64 3
22 3
45 3
7
78 3
79 3
80 3
77 12
39 3
45 3
29 3
7
78 3
79 3
80 3
77 12
55 3
43 3
44 3
7
78 3
79 3
80 3
77 12
33 3
35 3
57 3
7
78 3
79 3
80 3
77 12
34 3
51 3
19 3
7
78 3
79 3
80 3
77 12
19 3
35 3
71 3
7
78 3
79 3
80 3
77 12
58 3
40 3
63 3
7
78 3
79 3
80 3
77 12
60 3
52 3
42 3
7
78 3
79 3
80 3
77 12
47 3
66 3
62 3
7
78 3
79 3
80 3
77 12
61 3
68 3
50 3
7
78 3
79 3
80 3
77 12
71 3
61 3
68 3
7
78 3
79 3
80 3
77 12
55 3
63 3
69 3
5
78 1
79 1
80 1
77 7
64 3
6
78 2
79 2
80 2
77 10
34 3
33 3
6
78 2
79 2
80 2
77 10
46 3
65 3
6
78 2
79 2
80 2
77 10
64 3
49 3
6
78 2
79 2
80 2
77 10
66 3
74 3
6
78 2
79 2
80 2
77 10
76 3
61 3
6
78 2
79 2
80 2
77 10
75 3
60 3
6
78 2
79 2
80 2
77 10
73 3
71 3
7
78 3
79 3
80 3
77 13
64 3
31 3
54 3
7
78 3
79 3
80 3
77 13
58 3
55 3
63 3
7
78 3
79 3
80 3
77 13
57 3
70 3
40 3
7
78 3
79 3
80 3
77 13
51 3
59 3
73 3
7
78 3
79 3
80 3
77 13
16 3
74 3
72 3
8
78 4
79 4
80 4
77 16
53 3
37 3
52 3
38 3
8
78 4
79 4
80 4
77 16
39 3
38 3
54 3
30 3
8
78 4
79 4
80 4
77 16
32 3
65 3
37 3
31 3
8
78 4
79 4
80 4
77 16
62 3
48 3
75 3
53 3
8
78 4
79 4
80 4
77 16
67 3
20 3
76 3
36 3
8
78 4
79 4
80 4
77 16
66 3
62 3
74 3
75 3
8
78 4
79 4
80 4
77 16
59 3
73 3
67 3
76 3
8
78 4
79 4
80 4
77 16
73 3
71 3
76 3
61 3
8
78 4
79 4
80 4
77 16
74 3
75 3
72 3
60 3
80
78 172
79 172
80 172
0 3
58 18
64 21
55 15
39 12
15 9
1 3
2 3
22 12
43 15
45 15
44 15
29 12
27 12
24 12
9 6
13 9
3 3
4 3
5 3
14 9
56 18
34 12
47 15
51 15
66 21
59 18
10 6
16 9
11 6
6 3
33 12
19 9
62 18
73 24
74 24
67 21
20 9
23 12
46 15
35 12
48 15
71 24
75 24
76 24
72 24
26 12
7 3
57 18
32 12
53 15
61 18
60 18
36 12
21 9
41 15
8 3
65 21
70 24
37 12
68 24
52 15
50 15
42 15
17 9
40 12
31 12
38 12
18 9
12 6
49 15
63 21
54 15
69 24
30 12
28 12
25 12
78
77 172
0 1
58 6
64 7
55 5
39 4
15 3
1 1
2 1
22 4
43 5
45 5
44 5
29 4
27 4
24 4
9 2
13 3
3 1
4 1
5 1
14 3
56 6
34 4
47 5
51 5
66 7
59 6
10 2
16 3
11 2
6 1
33 4
19 3
62 6
73 8
74 8
67 7
20 3
23 4
46 5
35 4
48 5
71 8
75 8
76 8
72 8
26 4
7 1
57 6
32 4
53 5
61 6
60 6
36 4
21 3
41 5
8 1
65 7
70 8
37 4
68 8
52 5
50 5
42 5
17 3
40 4
31 4
38 4
18 3
12 2
49 5
63 7
54 5
69 8
30 4
28 4
25 4
78
77 172
0 1
58 6
64 7
55 5
39 4
15 3
1 1
2 1
22 4
43 5
45 5
44 5
29 4
27 4
24 4
9 2
13 3
3 1
4 1
5 1
14 3
56 6
34 4
47 5
51 5
66 7
59 6
10 2
16 3
11 2
6 1
33 4
19 3
62 6
73 8
74 8
67 7
20 3
23 4
46 5
35 4
48 5
71 8
75 8
76 8
72 8
26 4
7 1
57 6
32 4
53 5
61 6
60 6
36 4
21 3
41 5
8 1
65 7
70 8
37 4
68 8
52 5
50 5
42 5
17 3
40 4
31 4
38 4
18 3
12 2
49 5
63 7
54 5
69 8
30 4
28 4
25 4
78
77 172
0 1
58 6
64 7
55 5
39 4
15 3
1 1
2 1
22 4
43 5
45 5
44 5
29 4
27 4
24 4
9 2
13 3
3 1
4 1
5 1
14 3
56 6
34 4
47 5
51 5
66 7
59 6
10 2
16 3
11 2
6 1
33 4
19 3
62 6
73 8
74 8
67 7
20 3
23 4
46 5
35 4
48 5
71 8
75 8
76 8
72 8
26 4
7 1
57 6
32 4
53 5
61 6
60 6
36 4
21 3
41 5
8 1
65 7
70 8
37 4
68 8
52 5
50 5
42 5
17 3
40 4
31 4
38 4
18 3
12 2
49 5
63 7
54 5
69 8
30 4
28 4
25 4
end_CG
