begin_version
3
end_version
begin_metric
0
end_metric
39
begin_variable
var3
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var2
-1
37
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_9_8)
end_variable
begin_variable
var0
-1
36
Atom at(box1, loc_2_8)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_3)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_7)
Atom at(box1, loc_8_8)
Atom at(box1, loc_9_8)
end_variable
begin_variable
var1
-1
36
Atom at(box2, loc_2_8)
Atom at(box2, loc_3_3)
Atom at(box2, loc_3_4)
Atom at(box2, loc_3_5)
Atom at(box2, loc_3_8)
Atom at(box2, loc_4_2)
Atom at(box2, loc_4_4)
Atom at(box2, loc_4_5)
Atom at




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
34
85
1
5 0
9
23
86
1
24 0
23
220
2
37 22
20 0
23
221
2
38 22
20 0
29
87
1
27 0
29
222
2
37 28
22 0
29
223
2
38 28
22 0
35
88
1
14 0
35
224
2
37 34
6 0
35
225
2
38 34
6 0
6
25
89
1
29 0
25
226
2
37 24
30 0
25
227
2
38 24
30 0
32
90
1
12 0
32
228
2
37 31
10 0
32
229
2
38 31
10 0
5
26
91
1
33 0
26
230
2
37 25
35 0
26
231
2
38 25
35 0
31
92
1
9 0
33
93
1
10 0
6
27
94
1
32 0
27
232
2
37 26
34 0
27
233
2
38 26
34 0
32
95
1
12 0
32
234
2
37 31
9 0
32
235
2
38 31
9 0
4
29
96
1
27 0
29
236
2
37 28
28 0
29
237
2
38 28
28 0
35
97
1
14 0
5
30
98
1
23 0
30
238
2
37 29
24 0
30
239
2
38 29
24 0
34
99
1
5 0
36
100
1
6 0
3
35
101
1
14 0
35
240
2
37 34
23 0
35
241
2
38 34
23 0
end_DTG
begin_DTG
0
0
2
1
108
2
36 3
1 0
3
104
2
36 1
7 0
0
2
0
124
2
36 9
0 0
9
102
2
36 0
18 0
0
2
2
136
2
36 13
11 0
12
106
2
36 2
31 0
4
3
142
2
36 14
7 0
6
122
2
36 8
17 0
8
116
2
36 6
3 0
13
110
2
36 3
26 0
0
2
4
150
2
36 16
13 0
15
112
2
36 4
20 0
2
5
154
2
36 17
2 0
16
114
2
36 5
16 0
2
10
138
2
36 13
15 0
12
128
2
36 11
31 0
4
6
162
2
36 19
17 0
11
144
2
36 14
19 0
13
132
2
36 12
26 0
18
118
2
36 6
35 0
2
7
170
2
36 20
25 0
19
120
2
36 7
34 0
0
2
9
186
2
36 23
18 0
22
126
2
36 9
24 0
2
10
192
2
36 24
15 0
23
130
2
36 11
8 0
4
11
196
2
36 25
19 0
16
164
2
36 19
16 0
18
156
2
36 17
35 0
24
134
2
36 12
29 0
4
12
200
2
36 26
31 0
17
172
2
36 20
30 0
19
158
2
36 18
34 0
25
140
2
36 13
33 0
4
13
206
2
36 27
26 0
18
178
2
36 21
35 0
20
166
2
36 19
21 0
26
146
2
36 14
32 0
2
19
182
2
36 22
34 0
21
174
2
36 20
28 0
4
14
216
2
36 29
4 0
20
188
2
36 23
21 0
22
180
2
36 21
24 0
28
148
2
36 15
27 0
2
15
220
2
36 30
20 0
29
152
2
36 16
23 0
0
4
17
226
2
36 31
30 0
23
202
2
36 26
8 0
25
194
2
36 24
33 0
30
160
2
36 18
9 0
4
18
230
2
36 32
35 0
24
208
2
36 27
29 0
26
198
2
36 25
32 0
31
168
2
36 19
12 0
4
19
232
2
36 33
34 0
25
212
2
36 28
33 0
27
204
2
36 26
22 0
32
176
2
36 20
10 0
2
26
218
2
36 29
32 0
28
210
2
36 27
27 0
4
21
236
2
36 34
28 0
27
222
2
36 30
22 0
29
214
2
36 28
23 0
33
184
2
36 22
5 0
2
22
238
2
36 35
24 0
34
190
2
36 23
14 0
0
2
30
234
2
36 33
9 0
32
228
2
36 31
10 0
0
0
2
29
240
2
36 36
23 0
35
224
2
36 30
6 0
0
end_DTG
begin_DTG
0
0
2
1
109
2
36 3
1 0
3
105
2
36 1
7 0
0
2
0
125
2
36 9
0 0
9
103
2
36 0
18 0
0
2
2
137
2
36 13
11 0
12
107
2
36 2
31 0
4
3
143
2
36 14
7 0
6
123
2
36 8
17 0
8
117
2
36 6
3 0
13
111
2
36 3
26 0
0
2
4
151
2
36 16
13 0
15
113
2
36 4
20 0
2
5
155
2
36 17
2 0
16
115
2
36 5
16 0
2
10
139
2
36 13
15 0
12
129
2
36 11
31 0
4
6
163
2
36 19
17 0
11
145
2
36 14
19 0
13
133
2
36 12
26 0
18
119
2
36 6
35 0
2
7
171
2
36 20
25 0
19
121
2
36 7
34 0
0
2
9
187
2
36 23
18 0
22
127
2
36 9
24 0
2
10
193
2
36 24
15 0
23
131
2
36 11
8 0
4
11
197
2
36 25
19 0
16
165
2
36 19
16 0
18
157
2
36 17
35 0
24
135
2
36 12
29 0
4
12
201
2
36 26
31 0
17
173
2
36 20
30 0
19
159
2
36 18
34 0
25
141
2
36 13
33 0
4
13
207
2
36 27
26 0
18
179
2
36 21
35 0
20
167
2
36 19
21 0
26
147
2
36 14
32 0
2
19
183
2
36 22
34 0
21
175
2
36 20
28 0
4
14
217
2
36 29
4 0
20
189
2
36 23
21 0
22
181
2
36 21
24 0
28
149
2
36 15
27 0
2
15
221
2
36 30
20 0
29
153
2
36 16
23 0
0
4
17
227
2
36 31
30 0
23
203
2
36 26
8 0
25
195
2
36 24
33 0
30
161
2
36 18
9 0
4
18
231
2
36 32
35 0
24
209
2
36 27
29 0
26
199
2
36 25
32 0
31
169
2
36 19
12 0
4
19
233
2
36 33
34 0
25
213
2
36 28
33 0
27
205
2
36 26
22 0
32
177
2
36 20
10 0
2
26
219
2
36 29
32 0
28
211
2
36 27
27 0
4
21
237
2
36 34
28 0
27
223
2
36 30
22 0
29
215
2
36 28
23 0
33
185
2
36 22
5 0
2
22
239
2
36 35
24 0
34
191
2
36 23
14 0
0
2
30
235
2
36 33
9 0
32
229
2
36 31
10 0
0
0
2
29
241
2
36 36
23 0
35
225
2
36 30
6 0
0
end_DTG
begin_CG
4
37 1
38 1
36 3
13 2
4
37 1
38 1
36 3
11 2
4
37 1
38 1
36 3
15 2
4
37 1
38 1
36 3
25 2
4
37 1
38 1
36 4
28 2
4
37 1
38 1
36 4
27 2
4
37 1
38 1
36 3
14 2
5
37 2
38 2
36 6
11 2
25 2
5
37 2
38 2
36 6
16 2
29 2
5
37 2
38 2
36 6
29 2
12 2
5
37 2
38 2
36 6
32 2
12 2
4
37 1
38 1
36 5
17 2
4
37 1
38 1
36 5
33 2
4
37 1
38 1
36 4
18 2
4
37 1
38 1
36 5
23 2
5
37 2
38 2
36 7
19 2
16 2
5
37 2
38 2
36 7
15 2
30 2
5
37 2
38 2
36 7
25 2
31 2
5
37 2
38 2
36 7
13 2
20 2
5
37 2
38 2
36 7
31 2
30 2
5
37 2
38 2
36 7
18 2
24 2
5
37 2
38 2
36 7
34 2
28 2
5
37 2
38 2
36 7
32 2
27 2
6
37 3
38 3
36 9
24 2
27 2
14 2
6
37 3
38 3
36 9
20 2
28 2
23 2
4
37 1
38 1
36 6
26 2
6
37 3
38 3
36 9
25 2
31 2
34 2
5
37 2
38 2
36 8
28 2
22 2
5
37 2
38 2
36 8
21 2
27 2
5
37 2
38 2
36 8
30 2
33 2
5
37 2
38 2
36 8
35 2
29 2
6
37 3
38 3
36 10
17 2
19 2
35 2
6
37 3
38 3
36 10
34 2
33 2
22 2
6
37 3
38 3
36 10
35 2
29 2
32 2
7
37 4
38 4
36 12
26 2
35 2
21 2
32 2
7
37 4
38 4
36 12
31 2
30 2
34 2
33 2
38
37 70
38 70
0 2
1 2
11 6
7 4
13 6
2 2
17 8
25 10
3 2
18 8
15 8
19 8
31 14
26 10
4 2
20 8
16 8
30 12
35 16
34 16
21 8
28 12
24 10
8 4
29 12
33 14
32 14
22 8
27 12
23 10
9 4
12 6
10 4
5 2
14 6
6 2
37
36 70
0 1
1 1
11 3
7 2
13 3
2 1
17 4
25 5
3 1
18 4
15 4
19 4
31 7
26 5
4 1
20 4
16 4
30 6
35 8
34 8
21 4
28 6
24 5
8 2
29 6
33 7
32 7
22 4
27 6
23 5
9 2
12 3
10 2
5 1
14 3
6 1
37
36 70
0 1
1 1
11 3
7 2
13 3
2 1
17 4
25 5
3 1
18 4
15 4
19 4
31 7
26 5
4 1
20 4
16 4
30 6
35 8
34 8
21 4
28 6
24 5
8 2
29 6
33 7
32 7
22 4
27 6
23 5
9 2
12 3
10 2
5 1
14 3
6 1
end_CG
