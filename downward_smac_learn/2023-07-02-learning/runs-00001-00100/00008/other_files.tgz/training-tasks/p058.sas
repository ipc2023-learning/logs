begin_version
3
end_version
begin_metric
0
end_metric
69
begin_variable
var8
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_8)
NegatedAtom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




385
2
65 29
25 0
28
322
2
65 22
62 0
36
316
2
65 21
48 0
0
2
22
442
2
65 38
13 0
37
328
2
65 23
15 0
4
23
448
2
65 39
61 0
31
418
2
65 34
18 0
33
406
2
65 32
41 0
38
337
2
65 24
57 0
2
24
457
2
65 40
64 0
39
349
2
65 25
56 0
2
26
472
2
65 42
63 0
41
370
2
65 27
39 0
2
28
487
2
65 44
62 0
43
388
2
65 29
54 0
4
29
496
2
65 45
59 0
30
430
2
65 36
14 0
35
403
2
65 31
42 0
44
397
2
65 30
43 0
0
4
32
508
2
65 47
53 0
37
460
2
65 40
15 0
39
445
2
65 38
56 0
46
412
2
65 33
32 0
4
33
514
2
65 48
41 0
38
466
2
65 41
57 0
40
451
2
65 39
35 0
47
421
2
65 34
3 0
2
39
475
2
65 42
56 0
41
463
2
65 40
39 0
2
40
481
2
65 43
35 0
42
469
2
65 41
36 0
2
41
490
2
65 44
39 0
43
478
2
65 42
54 0
4
35
517
2
65 49
42 0
42
499
2
65 45
36 0
44
484
2
65 43
43 0
48
433
2
65 36
44 0
2
36
526
2
65 50
48 0
49
439
2
65 37
47 0
0
2
38
535
2
65 52
57 0
51
454
2
65 39
31 0
0
2
43
547
2
65 55
54 0
54
493
2
65 44
49 0
4
44
553
2
65 56
43 0
45
520
2
65 49
2 0
48
505
2
65 46
44 0
55
502
2
65 45
29 0
0
2
46
565
2
65 59
32 0
58
511
2
65 47
45 0
0
0
4
48
595
2
65 64
44 0
53
556
2
65 56
6 0
55
544
2
65 54
29 0
63
523
2
65 49
55 0
2
49
604
2
65 65
47 0
64
529
2
65 50
21 0
0
2
0
532
2
65 51
8 0
50
199
2
65 1
4 0
4
1
538
2
65 52
22 0
51
205
2
65 2
31 0
57
571
2
65 60
16 0
59
562
2
65 58
30 0
2
58
577
2
65 61
45 0
60
568
2
65 59
46 0
4
3
541
2
65 53
20 0
52
217
2
65 4
5 0
59
583
2
65 62
30 0
61
574
2
65 60
38 0
2
60
589
2
65 63
46 0
62
580
2
65 61
37 0
2
61
598
2
65 64
38 0
63
586
2
65 62
55 0
4
5
550
2
65 55
1 0
54
223
2
65 6
49 0
62
607
2
65 65
37 0
64
592
2
65 63
21 0
2
56
601
2
65 64
7 0
63
559
2
65 57
55 0
end_DTG
begin_CG
5
66 1
67 1
68 1
65 5
20 3
5
66 1
67 1
68 1
65 4
55 3
5
66 1
67 1
68 1
65 4
47 3
5
66 1
67 1
68 1
65 5
56 3
5
66 1
67 1
68 1
65 5
16 3
5
66 1
67 1
68 1
65 4
46 3
5
66 1
67 1
68 1
65 5
49 3
5
66 1
67 1
68 1
65 5
21 3
6
66 2
67 2
68 2
65 8
22 3
16 3
6
66 2
67 2
68 2
65 8
17 3
24 3
6
66 2
67 2
68 2
65 8
26 3
28 3
6
66 2
67 2
68 2
65 8
27 3
60 3
6
66 2
67 2
68 2
65 8
17 3
58 3
6
66 2
67 2
68 2
65 8
61 3
18 3
6
66 2
67 2
68 2
65 8
25 3
48 3
6
66 2
67 2
68 2
65 8
18 3
57 3
5
66 1
67 1
68 1
65 6
45 3
5
66 1
67 1
68 1
65 6
50 3
5
66 1
67 1
68 1
65 6
53 3
5
66 1
67 1
68 1
65 5
63 3
6
66 2
67 2
68 2
65 9
23 3
46 3
6
66 2
67 2
68 2
65 9
29 3
55 3
6
66 2
67 2
68 2
65 9
23 3
45 3
6
66 2
67 2
68 2
65 9
22 3
20 3
6
66 2
67 2
68 2
65 9
50 3
25 3
6
66 2
67 2
68 2
65 9
24 3
59 3
6
66 2
67 2
68 2
65 9
27 3
51 3
6
66 2
67 2
68 2
65 9
26 3
52 3
6
66 2
67 2
68 2
65 9
51 3
61 3
6
66 2
67 2
68 2
65 9
47 3
49 3
6
66 2
67 2
68 2
65 9
45 3
46 3
6
66 2
67 2
68 2
65 9
32 3
45 3
6
66 2
67 2
68 2
65 9
57 3
31 3
6
66 2
67 2
68 2
65 9
60 3
58 3
6
66 2
67 2
68 2
65 9
63 3
62 3
6
66 2
67 2
68 2
65 8
56 3
39 3
6
66 2
67 2
68 2
65 8
39 3
54 3
6
66 2
67 2
68 2
65 9
38 3
55 3
6
66 2
67 2
68 2
65 9
46 3
37 3
7
66 3
67 3
68 3
65 12
19 3
35 3
36 3
7
66 3
67 3
68 3
65 12
52 3
64 3
63 3
7
66 3
67 3
68 3
65 12
64 3
53 3
56 3
7
66 3
67 3
68 3
65 12
62 3
48 3
54 3
7
66 3
67 3
68 3
65 12
48 3
54 3
47 3
7
66 3
67 3
68 3
65 12
54 3
47 3
49 3
6
66 2
67 2
68 2
65 10
31 3
30 3
6
66 2
67 2
68 2
65 10
30 3
38 3
6
66 2
67 2
68 2
65 10
43 3
29 3
6
66 2
67 2
68 2
65 10
59 3
43 3
6
66 2
67 2
68 2
65 10
44 3
55 3
6
66 2
67 2
68 2
65 10
58 3
59 3
6
66 2
67 2
68 2
65 10
52 3
64 3
6
66 2
67 2
68 2
65 10
51 3
60 3
6
66 2
67 2
68 2
65 10
61 3
57 3
7
66 3
67 3
68 3
65 13
42 3
36 3
44 3
7
66 3
67 3
68 3
65 13
49 3
37 3
21 3
7
66 3
67 3
68 3
65 13
41 3
57 3
35 3
7
66 3
67 3
68 3
65 13
53 3
56 3
32 3
7
66 3
67 3
68 3
65 13
33 3
50 3
62 3
7
66 3
67 3
68 3
65 13
50 3
62 3
48 3
7
66 3
67 3
68 3
65 13
52 3
33 3
63 3
7
66 3
67 3
68 3
65 13
28 3
64 3
53 3
8
66 4
67 4
68 4
65 16
58 3
34 3
59 3
42 3
8
66 4
67 4
68 4
65 16
60 3
40 3
34 3
19 3
8
66 4
67 4
68 4
65 16
51 3
61 3
40 3
41 3
68
66 138
67 138
68 138
8 6
22 12
23 12
20 12
0 3
1 3
9 6
10 6
26 12
27 12
11 6
12 6
17 9
24 12
28 12
51 18
52 18
60 21
33 12
58 21
50 18
25 12
13 6
61 21
64 24
40 15
63 24
34 12
62 24
59 21
14 6
18 9
53 18
41 15
19 9
42 15
48 18
15 6
57 21
56 21
35 12
39 15
36 12
54 21
43 15
2 3
32 12
3 3
44 15
47 18
4 3
31 12
5 3
6 3
49 18
29 12
7 3
16 9
45 18
30 12
46 18
38 12
37 12
55 21
21 12
66
65 138
8 2
22 4
23 4
20 4
0 1
1 1
9 2
10 2
26 4
27 4
11 2
12 2
17 3
24 4
28 4
51 6
52 6
60 7
33 4
58 7
50 6
25 4
13 2
61 7
64 8
40 5
63 8
34 4
62 8
59 7
14 2
18 3
53 6
41 5
19 3
42 5
48 6
15 2
57 7
56 7
35 4
39 5
36 4
54 7
43 5
2 1
32 4
3 1
44 5
47 6
4 1
31 4
5 1
6 1
49 6
29 4
7 1
16 3
45 6
30 4
46 6
38 4
37 4
55 7
21 4
66
65 138
8 2
22 4
23 4
20 4
0 1
1 1
9 2
10 2
26 4
27 4
11 2
12 2
17 3
24 4
28 4
51 6
52 6
60 7
33 4
58 7
50 6
25 4
13 2
61 7
64 8
40 5
63 8
34 4
62 8
59 7
14 2
18 3
53 6
41 5
19 3
42 5
48 6
15 2
57 7
56 7
35 4
39 5
36 4
54 7
43 5
2 1
32 4
3 1
44 5
47 6
4 1
31 4
5 1
6 1
49 6
29 4
7 1
16 3
45 6
30 4
46 6
38 4
37 4
55 7
21 4
66
65 138
8 2
22 4
23 4
20 4
0 1
1 1
9 2
10 2
26 4
27 4
11 2
12 2
17 3
24 4
28 4
51 6
52 6
60 7
33 4
58 7
50 6
25 4
13 2
61 7
64 8
40 5
63 8
34 4
62 8
59 7
14 2
18 3
53 6
41 5
19 3
42 5
48 6
15 2
57 7
56 7
35 4
39 5
36 4
54 7
43 5
2 1
32 4
3 1
44 5
47 6
4 1
31 4
5 1
6 1
49 6
29 4
7 1
16 3
45 6
30 4
46 6
38 4
37 4
55 7
21 4
end_CG
