begin_version
3
end_version
begin_metric
0
end_metric
70
begin_variable
var16
-1
2
Atom clear(loc_11_2)
NegatedAtom clear(loc_11_2)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_12)
NegatedAtom clear(loc_10_12)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_12_12)
NegatedAtom clear(loc_12_12)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_12_3)
NegatedAtom clear(loc_12_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_12)
NegatedAtom clear(loc_11_12)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_12_11)
NegatedAtom clear(loc_12_11)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_12_4)
NegatedAtom clear(loc_12_4)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_12_6)
NegatedAtom clear(loc_12_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_12_9)
NegatedAtom clear(loc_12_9)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variab




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





65 54
60 0
46
595
2
65 49
63 0
48
575
2
65 47
23 0
53
531
2
65 42
56 0
2
42
655
2
65 55
12 0
54
539
2
65 43
36 0
0
4
43
707
2
65 60
46 0
51
691
2
65 59
39 0
58
623
2
65 52
54 0
59
547
2
65 44
53 0
2
44
715
2
65 61
33 0
60
559
2
65 45
40 0
2
46
731
2
65 63
63 0
62
579
2
65 47
45 0
4
47
739
2
65 64
62 0
52
659
2
65 55
42 0
54
635
2
65 53
36 0
63
591
2
65 48
43 0
2
53
667
2
65 56
56 0
55
647
2
65 54
29 0
2
54
675
2
65 57
36 0
56
663
2
65 55
28 0
2
55
683
2
65 58
29 0
57
671
2
65 56
27 0
2
56
695
2
65 59
28 0
58
679
2
65 57
54 0
4
49
751
2
65 66
14 0
50
687
2
65 58
55 0
57
611
2
65 51
27 0
64
603
2
65 50
41 0
4
0
615
2
65 51
64 0
50
211
2
65 0
55 0
60
755
2
65 66
40 0
64
719
2
65 61
41 0
2
1
627
2
65 52
57 0
51
223
2
65 1
39 0
0
4
3
639
2
65 53
44 0
52
243
2
65 3
42 0
61
743
2
65 64
4 0
63
723
2
65 62
43 0
2
4
651
2
65 54
48 0
53
251
2
65 4
56 0
2
7
699
2
65 59
58 0
58
279
2
65 7
54 0
end_DTG
begin_CG
6
66 1
67 1
68 1
69 1
65 5
49 4
6
66 1
67 1
68 1
69 1
65 6
16 4
6
66 1
67 1
68 1
69 1
65 6
18 4
6
66 1
67 1
68 1
69 1
65 6
19 4
6
66 1
67 1
68 1
69 1
65 5
45 4
7
66 2
67 2
68 2
69 2
65 10
57 4
15 4
7
66 2
67 2
68 2
69 2
65 10
48 4
20 4
7
66 2
67 2
68 2
69 2
65 10
58 4
21 4
7
66 2
67 2
68 2
69 2
65 10
15 4
25 4
7
66 2
67 2
68 2
69 2
65 10
49 4
26 4
7
66 2
67 2
68 2
69 2
65 10
16 4
22 4
7
66 2
67 2
68 2
69 2
65 10
47 4
17 4
7
66 2
67 2
68 2
69 2
65 10
60 4
23 4
7
66 2
67 2
68 2
69 2
65 10
17 4
63 4
7
66 2
67 2
68 2
69 2
65 10
46 4
54 4
6
66 1
67 1
68 1
69 1
65 7
51 4
6
66 1
67 1
68 1
69 1
65 7
24 4
6
66 1
67 1
68 1
69 1
65 7
61 4
6
66 1
67 1
68 1
69 1
65 7
46 4
6
66 1
67 1
68 1
69 1
65 7
33 4
6
66 1
67 1
68 1
69 1
65 7
50 4
6
66 1
67 1
68 1
69 1
65 7
52 4
6
66 1
67 1
68 1
69 1
65 7
47 4
6
66 1
67 1
68 1
69 1
65 7
62 4
6
66 1
67 1
68 1
69 1
65 7
34 4
7
66 2
67 2
68 2
69 2
65 11
51 4
35 4
7
66 2
67 2
68 2
69 2
65 11
50 4
32 4
7
66 2
67 2
68 2
69 2
65 10
28 4
54 4
7
66 2
67 2
68 2
69 2
65 10
29 4
27 4
7
66 2
67 2
68 2
69 2
65 11
36 4
28 4
7
66 2
67 2
68 2
69 2
65 10
31 4
37 4
7
66 2
67 2
68 2
69 2
65 10
32 4
30 4
8
66 3
67 3
68 3
69 3
65 15
20 4
26 4
31 4
8
66 3
67 3
68 3
69 3
65 15
19 4
46 4
39 4
8
66 3
67 3
68 3
69 3
65 15
24 4
47 4
60 4
8
66 3
67 3
68 3
69 3
65 15
59 4
25 4
38 4
8
66 3
67 3
68 3
69 3
65 15
23 4
56 4
29 4
8
66 3
67 3
68 3
69 3
65 15
21 4
30 4
38 4
8
66 3
67 3
68 3
69 3
65 15
52 4
35 4
37 4
8
66 3
67 3
68 3
69 3
65 15
33 4
55 4
40 4
8
66 3
67 3
68 3
69 3
65 15
57 4
39 4
53 4
8
66 3
67 3
68 3
69 3
65 15
58 4
54 4
53 4
8
66 3
67 3
68 3
69 3
65 15
63 4
56 4
45 4
8
66 3
67 3
68 3
69 3
65 15
48 4
56 4
45 4
8
66 3
67 3
68 3
69 3
65 15
48 4
49 4
45 4
7
66 2
67 2
68 2
69 2
65 12
44 4
42 4
7
66 2
67 2
68 2
69 2
65 12
18 4
55 4
7
66 2
67 2
68 2
69 2
65 12
22 4
61 4
7
66 2
67 2
68 2
69 2
65 12
50 4
43 4
7
66 2
67 2
68 2
69 2
65 12
44 4
50 4
7
66 2
67 2
68 2
69 2
65 12
48 4
49 4
7
66 2
67 2
68 2
69 2
65 12
57 4
59 4
7
66 2
67 2
68 2
69 2
65 12
58 4
59 4
7
66 2
67 2
68 2
69 2
65 12
64 4
55 4
8
66 3
67 3
68 3
69 3
65 16
55 4
27 4
41 4
8
66 3
67 3
68 3
69 3
65 16
46 4
54 4
53 4
8
66 3
67 3
68 3
69 3
65 16
62 4
36 4
43 4
8
66 3
67 3
68 3
69 3
65 16
64 4
51 4
40 4
8
66 3
67 3
68 3
69 3
65 16
64 4
52 4
41 4
8
66 3
67 3
68 3
69 3
65 16
64 4
51 4
52 4
8
66 3
67 3
68 3
69 3
65 16
34 4
61 4
62 4
8
66 3
67 3
68 3
69 3
65 16
47 4
60 4
63 4
8
66 3
67 3
68 3
69 3
65 16
60 4
63 4
56 4
8
66 3
67 3
68 3
69 3
65 16
61 4
62 4
42 4
9
66 4
67 4
68 4
69 4
65 20
57 4
58 4
59 4
53 4
69
66 140
67 140
68 140
69 140
64 32
57 28
5 8
44 20
48 24
6 8
7 8
58 28
59 28
51 24
15 12
0 4
49 24
50 24
20 12
21 12
52 24
35 20
25 16
8 8
9 8
26 16
32 20
31 16
30 16
37 20
38 20
10 8
16 12
1 4
22 12
24 12
2 4
3 4
11 8
47 24
34 20
18 12
19 12
17 12
61 28
60 28
12 8
46 24
33 20
13 8
63 28
62 28
23 12
14 8
55 28
39 20
42 20
56 28
36 20
29 16
28 16
27 16
54 28
53 24
40 20
4 4
45 24
43 20
41 20
66
65 140
64 8
57 7
5 2
44 5
48 6
6 2
7 2
58 7
59 7
51 6
15 3
0 1
49 6
50 6
20 3
21 3
52 6
35 5
25 4
8 2
9 2
26 4
32 5
31 4
30 4
37 5
38 5
10 2
16 3
1 1
22 3
24 3
2 1
3 1
11 2
47 6
34 5
18 3
19 3
17 3
61 7
60 7
12 2
46 6
33 5
13 2
63 7
62 7
23 3
14 2
55 7
39 5
42 5
56 7
36 5
29 4
28 4
27 4
54 7
53 6
40 5
4 1
45 6
43 5
41 5
66
65 140
64 8
57 7
5 2
44 5
48 6
6 2
7 2
58 7
59 7
51 6
15 3
0 1
49 6
50 6
20 3
21 3
52 6
35 5
25 4
8 2
9 2
26 4
32 5
31 4
30 4
37 5
38 5
10 2
16 3
1 1
22 3
24 3
2 1
3 1
11 2
47 6
34 5
18 3
19 3
17 3
61 7
60 7
12 2
46 6
33 5
13 2
63 7
62 7
23 3
14 2
55 7
39 5
42 5
56 7
36 5
29 4
28 4
27 4
54 7
53 6
40 5
4 1
45 6
43 5
41 5
66
65 140
64 8
57 7
5 2
44 5
48 6
6 2
7 2
58 7
59 7
51 6
15 3
0 1
49 6
50 6
20 3
21 3
52 6
35 5
25 4
8 2
9 2
26 4
32 5
31 4
30 4
37 5
38 5
10 2
16 3
1 1
22 3
24 3
2 1
3 1
11 2
47 6
34 5
18 3
19 3
17 3
61 7
60 7
12 2
46 6
33 5
13 2
63 7
62 7
23 3
14 2
55 7
39 5
42 5
56 7
36 5
29 4
28 4
27 4
54 7
53 6
40 5
4 1
45 6
43 5
41 5
66
65 140
64 8
57 7
5 2
44 5
48 6
6 2
7 2
58 7
59 7
51 6
15 3
0 1
49 6
50 6
20 3
21 3
52 6
35 5
25 4
8 2
9 2
26 4
32 5
31 4
30 4
37 5
38 5
10 2
16 3
1 1
22 3
24 3
2 1
3 1
11 2
47 6
34 5
18 3
19 3
17 3
61 7
60 7
12 2
46 6
33 5
13 2
63 7
62 7
23 3
14 2
55 7
39 5
42 5
56 7
36 5
29 4
28 4
27 4
54 7
53 6
40 5
4 1
45 6
43 5
41 5
end_CG
