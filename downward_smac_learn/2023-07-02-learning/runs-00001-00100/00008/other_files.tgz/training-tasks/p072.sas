begin_version
3
end_version
begin_metric
0
end_metric
74
begin_variable
var6
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var46
-1
2
Atom cl




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
70 65
58 0
49
572
2
70 56
40 0
51
554
2
70 54
69 0
60
500
2
70 47
60 0
4
43
659
2
70 66
67 0
50
587
2
70 57
57 0
52
563
2
70 55
68 0
61
512
2
70 48
59 0
4
44
668
2
70 67
66 0
45
575
2
70 56
55 0
51
530
2
70 50
69 0
62
524
2
70 49
61 0
4
45
683
2
70 68
55 0
54
671
2
70 67
36 0
62
605
2
70 59
61 0
63
533
2
70 50
53 0
2
46
692
2
70 69
26 0
64
539
2
70 51
35 0
0
4
48
698
2
70 70
30 0
55
626
2
70 62
12 0
57
614
2
70 60
31 0
65
548
2
70 53
14 0
2
56
632
2
70 63
46 0
58
620
2
70 61
32 0
2
57
641
2
70 64
31 0
59
629
2
70 62
49 0
4
49
701
2
70 72
40 0
58
650
2
70 65
32 0
60
635
2
70 63
60 0
66
557
2
70 54
13 0
4
50
710
2
70 73
57 0
59
662
2
70 66
49 0
61
644
2
70 64
59 0
67
566
2
70 55
51 0
4
51
716
2
70 74
69 0
60
674
2
70 67
60 0
62
653
2
70 65
61 0
68
578
2
70 56
42 0
4
52
725
2
70 75
68 0
53
665
2
70 66
56 0
61
596
2
70 58
59 0
69
590
2
70 57
54 0
4
0
599
2
70 58
34 0
53
230
2
70 0
56 0
64
728
2
70 75
35 0
69
695
2
70 69
54 0
2
1
608
2
70 59
23 0
54
236
2
70 1
36 0
2
2
623
2
70 61
0 0
56
239
2
70 2
46 0
0
4
3
656
2
70 65
15 0
60
242
2
70 5
60 0
66
719
2
70 74
13 0
68
704
2
70 72
42 0
2
67
731
2
70 75
51 0
69
713
2
70 73
54 0
4
4
677
2
70 67
5 0
62
248
2
70 6
61 0
63
722
2
70 74
53 0
68
686
2
70 68
42 0
end_DTG
begin_CG
5
71 1
72 1
73 1
70 5
14 3
5
71 1
72 1
73 1
70 5
34 3
5
71 1
72 1
73 1
70 5
23 3
5
71 1
72 1
73 1
70 5
15 3
5
71 1
72 1
73 1
70 5
16 3
6
71 2
72 2
73 2
70 8
34 3
54 3
6
71 2
72 2
73 2
70 8
17 3
18 3
6
71 2
72 2
73 2
70 8
24 3
25 3
6
71 2
72 2
73 2
70 8
47 3
44 3
6
71 2
72 2
73 2
70 8
44 3
22 3
6
71 2
72 2
73 2
70 8
52 3
26 3
6
71 2
72 2
73 2
70 8
48 3
43 3
6
71 2
72 2
73 2
70 8
19 3
46 3
6
71 2
72 2
73 2
70 8
49 3
51 3
5
71 1
72 1
73 1
70 6
46 3
5
71 1
72 1
73 1
70 5
51 3
5
71 1
72 1
73 1
70 5
27 3
5
71 1
72 1
73 1
70 5
28 3
5
71 1
72 1
73 1
70 5
47 3
5
71 1
72 1
73 1
70 6
22 3
5
71 1
72 1
73 1
70 6
62 3
5
71 1
72 1
73 1
70 6
63 3
6
71 2
72 2
73 2
70 9
43 3
19 3
6
71 2
72 2
73 2
70 9
34 3
35 3
6
71 2
72 2
73 2
70 9
62 3
45 3
6
71 2
72 2
73 2
70 9
45 3
52 3
6
71 2
72 2
73 2
70 9
55 3
36 3
6
71 2
72 2
73 2
70 8
16 3
37 3
6
71 2
72 2
73 2
70 8
17 3
38 3
6
71 2
72 2
73 2
70 9
47 3
39 3
6
71 2
72 2
73 2
70 9
43 3
46 3
6
71 2
72 2
73 2
70 9
46 3
32 3
6
71 2
72 2
73 2
70 8
31 3
49 3
6
71 2
72 2
73 2
70 9
48 3
50 3
5
71 1
72 1
73 1
70 7
53 3
7
71 3
72 3
73 3
70 12
23 3
36 3
53 3
7
71 3
72 3
73 3
70 12
26 3
56 3
35 3
7
71 3
72 3
73 3
70 12
38 3
27 3
20 3
7
71 3
72 3
73 3
70 12
28 3
37 3
21 3
7
71 3
72 3
73 3
70 12
29 3
63 3
50 3
7
71 3
72 3
73 3
70 12
41 3
57 3
49 3
7
71 3
72 3
73 3
70 12
50 3
58 3
40 3
7
71 3
72 3
73 3
70 12
59 3
51 3
54 3
6
71 2
72 2
73 2
70 10
44 3
30 3
6
71 2
72 2
73 2
70 10
48 3
43 3
6
71 2
72 2
73 2
70 10
65 3
66 3
7
71 3
72 3
73 3
70 13
30 3
31 3
14 3
7
71 3
72 3
73 3
70 13
18 3
29 3
48 3
7
71 3
72 3
73 3
70 13
47 3
44 3
33 3
7
71 3
72 3
73 3
70 13
40 3
32 3
60 3
7
71 3
72 3
73 3
70 13
33 3
64 3
41 3
7
71 3
72 3
73 3
70 13
15 3
60 3
42 3
7
71 3
72 3
73 3
70 13
25 3
66 3
55 3
7
71 3
72 3
73 3
70 13
34 3
56 3
54 3
7
71 3
72 3
73 3
70 13
61 3
53 3
42 3
7
71 3
72 3
73 3
70 13
52 3
68 3
56 3
7
71 3
72 3
73 3
70 13
55 3
61 3
53 3
7
71 3
72 3
73 3
70 13
58 3
69 3
60 3
7
71 3
72 3
73 3
70 13
64 3
67 3
57 3
7
71 3
72 3
73 3
70 13
69 3
60 3
61 3
8
71 4
72 4
73 4
70 16
57 3
49 3
59 3
51 3
8
71 4
72 4
73 4
70 16
68 3
56 3
59 3
54 3
8
71 4
72 4
73 4
70 16
20 3
63 3
24 3
65 3
8
71 4
72 4
73 4
70 16
21 3
39 3
62 3
64 3
8
71 4
72 4
73 4
70 16
63 3
50 3
65 3
58 3
8
71 4
72 4
73 4
70 16
62 3
64 3
45 3
67 3
8
71 4
72 4
73 4
70 16
45 3
52 3
67 3
68 3
8
71 4
72 4
73 4
70 16
65 3
58 3
66 3
69 3
8
71 4
72 4
73 4
70 16
66 3
55 3
69 3
61 3
8
71 4
72 4
73 4
70 16
67 3
57 3
68 3
59 3
73
71 168
72 168
73 168
34 15
23 12
0 3
15 9
5 6
1 3
2 3
3 3
16 9
4 3
6 6
17 9
28 12
38 15
37 15
27 12
18 9
21 9
20 9
7 6
8 6
47 21
29 12
39 15
63 24
62 24
24 12
25 12
9 6
44 18
48 21
33 12
50 21
64 24
65 24
45 18
52 21
10 6
22 12
43 18
11 6
41 15
58 21
67 24
66 24
55 21
26 12
19 9
30 12
40 15
57 21
69 24
68 24
56 21
36 15
12 6
46 21
31 12
32 12
49 21
60 24
59 21
61 24
53 21
35 15
14 9
13 6
51 21
42 15
54 21
71
70 168
34 5
23 4
0 1
15 3
5 2
1 1
2 1
3 1
16 3
4 1
6 2
17 3
28 4
38 5
37 5
27 4
18 3
21 3
20 3
7 2
8 2
47 7
29 4
39 5
63 8
62 8
24 4
25 4
9 2
44 6
48 7
33 4
50 7
64 8
65 8
45 6
52 7
10 2
22 4
43 6
11 2
41 5
58 7
67 8
66 8
55 7
26 4
19 3
30 4
40 5
57 7
69 8
68 8
56 7
36 5
12 2
46 7
31 4
32 4
49 7
60 8
59 7
61 8
53 7
35 5
14 3
13 2
51 7
42 5
54 7
71
70 168
34 5
23 4
0 1
15 3
5 2
1 1
2 1
3 1
16 3
4 1
6 2
17 3
28 4
38 5
37 5
27 4
18 3
21 3
20 3
7 2
8 2
47 7
29 4
39 5
63 8
62 8
24 4
25 4
9 2
44 6
48 7
33 4
50 7
64 8
65 8
45 6
52 7
10 2
22 4
43 6
11 2
41 5
58 7
67 8
66 8
55 7
26 4
19 3
30 4
40 5
57 7
69 8
68 8
56 7
36 5
12 2
46 7
31 4
32 4
49 7
60 8
59 7
61 8
53 7
35 5
14 3
13 2
51 7
42 5
54 7
71
70 168
34 5
23 4
0 1
15 3
5 2
1 1
2 1
3 1
16 3
4 1
6 2
17 3
28 4
38 5
37 5
27 4
18 3
21 3
20 3
7 2
8 2
47 7
29 4
39 5
63 8
62 8
24 4
25 4
9 2
44 6
48 7
33 4
50 7
64 8
65 8
45 6
52 7
10 2
22 4
43 6
11 2
41 5
58 7
67 8
66 8
55 7
26 4
19 3
30 4
40 5
57 7
69 8
68 8
56 7
36 5
12 2
46 7
31 4
32 4
49 7
60 8
59 7
61 8
53 7
35 5
14 3
13 2
51 7
42 5
54 7
end_CG
