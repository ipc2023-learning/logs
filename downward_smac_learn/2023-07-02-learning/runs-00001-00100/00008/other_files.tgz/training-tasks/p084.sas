begin_version
3
end_version
begin_metric
0
end_metric
88
begin_variable
var12
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var87
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var79
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var86
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var81
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var77
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var78
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var75
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var32
-1
2
Atom c




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





85 1
86 1
87 1
83 6
71 4
7
84 2
85 2
86 2
87 2
83 11
20 4
21 4
7
84 2
85 2
86 2
87 2
83 11
65 4
34 4
7
84 2
85 2
86 2
87 2
83 11
35 4
53 4
7
84 2
85 2
86 2
87 2
83 11
53 4
60 4
7
84 2
85 2
86 2
87 2
83 11
32 4
54 4
7
84 2
85 2
86 2
87 2
83 11
54 4
36 4
7
84 2
85 2
86 2
87 2
83 10
10 4
22 4
7
84 2
85 2
86 2
87 2
83 10
23 4
13 4
7
84 2
85 2
86 2
87 2
83 11
37 4
79 4
7
84 2
85 2
86 2
87 2
83 10
38 4
19 4
7
84 2
85 2
86 2
87 2
83 10
40 4
20 4
7
84 2
85 2
86 2
87 2
83 11
64 4
59 4
7
84 2
85 2
86 2
87 2
83 11
58 4
62 4
7
84 2
85 2
86 2
87 2
83 10
75 4
42 4
7
84 2
85 2
86 2
87 2
83 11
59 4
69 4
7
84 2
85 2
86 2
87 2
83 11
57 4
71 4
7
84 2
85 2
86 2
87 2
83 11
56 4
78 4
7
84 2
85 2
86 2
87 2
83 11
78 4
43 4
7
84 2
85 2
86 2
87 2
83 11
32 4
44 4
8
84 3
85 3
86 3
87 3
83 15
17 4
31 4
58 4
8
84 3
85 3
86 3
87 3
83 15
74 4
46 4
11 4
8
84 3
85 3
86 3
87 3
83 15
66 4
14 4
39 4
8
84 3
85 3
86 3
87 3
83 15
45 4
15 4
67 4
8
84 3
85 3
86 3
87 3
83 15
18 4
55 4
41 4
6
84 1
85 1
86 1
87 1
83 8
65 4
8
84 3
85 3
86 3
87 3
83 15
28 4
39 4
22 4
8
84 3
85 3
86 3
87 3
83 15
57 4
34 4
38 4
8
84 3
85 3
86 3
87 3
83 15
41 4
29 4
23 4
8
84 3
85 3
86 3
87 3
83 15
36 4
56 4
40 4
8
84 3
85 3
86 3
87 3
83 15
26 4
27 4
71 4
8
84 3
85 3
86 3
87 3
83 15
30 4
59 4
79 4
8
84 3
85 3
86 3
87 3
83 15
31 4
45 4
62 4
8
84 3
85 3
86 3
87 3
83 15
44 4
35 4
68 4
6
84 1
85 1
86 1
87 1
83 8
61 4
8
84 3
85 3
86 3
87 3
83 15
58 4
55 4
77 4
8
84 3
85 3
86 3
87 3
83 15
60 4
72 4
61 4
8
84 3
85 3
86 3
87 3
83 15
62 4
70 4
63 4
8
84 3
85 3
86 3
87 3
83 15
77 4
63 4
64 4
8
84 3
85 3
86 3
87 3
83 15
63 4
64 4
75 4
8
84 3
85 3
86 3
87 3
83 15
73 4
75 4
74 4
7
84 2
85 2
86 2
87 2
83 12
67 4
81 4
7
84 2
85 2
86 2
87 2
83 12
58 4
55 4
7
84 2
85 2
86 2
87 2
83 12
54 4
56 4
7
84 2
85 2
86 2
87 2
83 12
55 4
77 4
7
84 2
85 2
86 2
87 2
83 12
66 4
69 4
8
84 3
85 3
86 3
87 3
83 16
54 4
25 4
47 4
8
84 3
85 3
86 3
87 3
83 16
24 4
27 4
80 4
8
84 3
85 3
86 3
87 3
83 16
16 4
81 4
48 4
8
84 3
85 3
86 3
87 3
83 16
48 4
74 4
46 4
8
84 3
85 3
86 3
87 3
83 16
25 4
68 4
49 4
8
84 3
85 3
86 3
87 3
83 16
49 4
50 4
76 4
8
84 3
85 3
86 3
87 3
83 16
78 4
51 4
24 4
8
84 3
85 3
86 3
87 3
83 16
37 4
66 4
79 4
8
84 3
85 3
86 3
87 3
83 16
65 4
57 4
80 4
8
84 3
85 3
86 3
87 3
83 16
68 4
53 4
82 4
8
84 3
85 3
86 3
87 3
83 16
62 4
67 4
70 4
8
84 3
85 3
86 3
87 3
83 16
57 4
80 4
71 4
8
84 3
85 3
86 3
87 3
83 16
68 4
82 4
76 4
9
84 4
85 4
86 4
87 4
83 20
28 4
42 4
69 4
12 4
8
84 3
85 3
86 3
87 3
83 16
81 4
73 4
74 4
8
84 3
85 3
86 3
87 3
83 16
82 4
76 4
72 4
9
84 4
85 4
86 4
87 4
83 20
72 4
61 4
52 4
33 4
9
84 4
85 4
86 4
87 4
83 20
76 4
51 4
52 4
26 4
9
84 4
85 4
86 4
87 4
83 20
70 4
63 4
73 4
75 4
9
84 4
85 4
86 4
87 4
83 20
47 4
56 4
50 4
78 4
9
84 4
85 4
86 4
87 4
83 20
77 4
29 4
64 4
30 4
9
84 4
85 4
86 4
87 4
83 20
65 4
43 4
21 4
80 4
9
84 4
85 4
86 4
87 4
83 20
66 4
59 4
79 4
69 4
9
84 4
85 4
86 4
87 4
83 20
53 4
60 4
82 4
72 4
9
84 4
85 4
86 4
87 4
83 20
67 4
70 4
81 4
73 4
87
84 210
85 210
86 210
87 210
5 8
37 20
65 28
66 28
57 24
28 16
10 12
0 4
6 8
14 16
34 20
39 20
38 20
22 16
19 16
7 8
8 8
17 16
32 20
31 16
44 20
45 20
35 20
15 16
16 16
18 16
54 24
58 28
25 16
62 28
68 28
67 28
53 24
60 28
1 4
36 20
55 24
47 20
49 20
70 28
82 32
81 32
48 20
41 20
56 24
77 32
50 20
63 28
76 32
73 28
72 28
61 28
2 4
40 20
29 16
78 32
64 28
51 20
75 32
52 20
74 32
46 20
3 4
23 16
30 16
24 16
26 16
33 20
4 4
20 16
43 20
59 28
27 16
42 20
11 12
13 16
21 16
79 32
80 32
69 28
71 32
12 12
9 8
84
83 210
5 2
37 5
65 7
66 7
57 6
28 4
10 3
0 1
6 2
14 4
34 5
39 5
38 5
22 4
19 4
7 2
8 2
17 4
32 5
31 4
44 5
45 5
35 5
15 4
16 4
18 4
54 6
58 7
25 4
62 7
68 7
67 7
53 6
60 7
1 1
36 5
55 6
47 5
49 5
70 7
82 8
81 8
48 5
41 5
56 6
77 8
50 5
63 7
76 8
73 7
72 7
61 7
2 1
40 5
29 4
78 8
64 7
51 5
75 8
52 5
74 8
46 5
3 1
23 4
30 4
24 4
26 4
33 5
4 1
20 4
43 5
59 7
27 4
42 5
11 3
13 4
21 4
79 8
80 8
69 7
71 8
12 3
9 2
84
83 210
5 2
37 5
65 7
66 7
57 6
28 4
10 3
0 1
6 2
14 4
34 5
39 5
38 5
22 4
19 4
7 2
8 2
17 4
32 5
31 4
44 5
45 5
35 5
15 4
16 4
18 4
54 6
58 7
25 4
62 7
68 7
67 7
53 6
60 7
1 1
36 5
55 6
47 5
49 5
70 7
82 8
81 8
48 5
41 5
56 6
77 8
50 5
63 7
76 8
73 7
72 7
61 7
2 1
40 5
29 4
78 8
64 7
51 5
75 8
52 5
74 8
46 5
3 1
23 4
30 4
24 4
26 4
33 5
4 1
20 4
43 5
59 7
27 4
42 5
11 3
13 4
21 4
79 8
80 8
69 7
71 8
12 3
9 2
84
83 210
5 2
37 5
65 7
66 7
57 6
28 4
10 3
0 1
6 2
14 4
34 5
39 5
38 5
22 4
19 4
7 2
8 2
17 4
32 5
31 4
44 5
45 5
35 5
15 4
16 4
18 4
54 6
58 7
25 4
62 7
68 7
67 7
53 6
60 7
1 1
36 5
55 6
47 5
49 5
70 7
82 8
81 8
48 5
41 5
56 6
77 8
50 5
63 7
76 8
73 7
72 7
61 7
2 1
40 5
29 4
78 8
64 7
51 5
75 8
52 5
74 8
46 5
3 1
23 4
30 4
24 4
26 4
33 5
4 1
20 4
43 5
59 7
27 4
42 5
11 3
13 4
21 4
79 8
80 8
69 7
71 8
12 3
9 2
84
83 210
5 2
37 5
65 7
66 7
57 6
28 4
10 3
0 1
6 2
14 4
34 5
39 5
38 5
22 4
19 4
7 2
8 2
17 4
32 5
31 4
44 5
45 5
35 5
15 4
16 4
18 4
54 6
58 7
25 4
62 7
68 7
67 7
53 6
60 7
1 1
36 5
55 6
47 5
49 5
70 7
82 8
81 8
48 5
41 5
56 6
77 8
50 5
63 7
76 8
73 7
72 7
61 7
2 1
40 5
29 4
78 8
64 7
51 5
75 8
52 5
74 8
46 5
3 1
23 4
30 4
24 4
26 4
33 5
4 1
20 4
43 5
59 7
27 4
42 5
11 3
13 4
21 4
79 8
80 8
69 7
71 8
12 3
9 2
end_CG
