begin_version
3
end_version
begin_metric
0
end_metric
83
begin_variable
var20
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var75
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var76
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var82
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var77
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var81
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var58
-1
2
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





81 2
82 2
78 10
15 4
16 4
7
79 2
80 2
81 2
82 2
78 10
32 4
17 4
7
79 2
80 2
81 2
82 2
78 10
18 4
31 4
7
79 2
80 2
81 2
82 2
78 10
38 4
12 4
7
79 2
80 2
81 2
82 2
78 10
12 4
33 4
6
79 1
80 1
81 1
82 1
78 7
39 4
7
79 2
80 2
81 2
82 2
78 11
19 4
20 4
7
79 2
80 2
81 2
82 2
78 11
30 4
51 4
7
79 2
80 2
81 2
82 2
78 11
34 4
21 4
7
79 2
80 2
81 2
82 2
78 11
34 4
22 4
7
79 2
80 2
81 2
82 2
78 11
41 4
23 4
7
79 2
80 2
81 2
82 2
78 11
51 4
40 4
7
79 2
80 2
81 2
82 2
78 11
25 4
35 4
8
79 3
80 3
81 3
82 3
78 15
13 4
35 4
26 4
8
79 3
80 3
81 3
82 3
78 15
15 4
36 4
43 4
8
79 3
80 3
81 3
82 3
78 15
42 4
24 4
16 4
8
79 3
80 3
81 3
82 3
78 15
47 4
17 4
24 4
8
79 3
80 3
81 3
82 3
78 15
48 4
23 4
22 4
8
79 3
80 3
81 3
82 3
78 15
19 4
27 4
44 4
8
79 3
80 3
81 3
82 3
78 15
20 4
45 4
28 4
8
79 3
80 3
81 3
82 3
78 15
25 4
30 4
49 4
8
79 3
80 3
81 3
82 3
78 15
26 4
50 4
38 4
8
79 3
80 3
81 3
82 3
78 15
31 4
46 4
37 4
7
79 2
80 2
81 2
82 2
78 12
27 4
52 4
7
79 2
80 2
81 2
82 2
78 12
40 4
29 4
7
79 2
80 2
81 2
82 2
78 12
41 4
53 4
7
79 2
80 2
81 2
82 2
78 12
39 4
53 4
7
79 2
80 2
81 2
82 2
78 12
42 4
43 4
7
79 2
80 2
81 2
82 2
78 12
44 4
45 4
8
79 3
80 3
81 3
82 3
78 16
37 4
54 4
21 4
8
79 3
80 3
81 3
82 3
78 16
29 4
55 4
36 4
8
79 3
80 3
81 3
82 3
78 16
28 4
58 4
39 4
8
79 3
80 3
81 3
82 3
78 16
38 4
59 4
33 4
8
79 3
80 3
81 3
82 3
78 16
31 4
60 4
46 4
8
79 3
80 3
81 3
82 3
78 16
32 4
47 4
61 4
8
79 3
80 3
81 3
82 3
78 16
48 4
34 4
56 4
8
79 3
80 3
81 3
82 3
78 16
34 4
54 4
56 4
8
79 3
80 3
81 3
82 3
78 16
35 4
49 4
57 4
8
79 3
80 3
81 3
82 3
78 16
35 4
57 4
50 4
8
79 3
80 3
81 3
82 3
78 16
40 4
68 4
55 4
8
79 3
80 3
81 3
82 3
78 16
41 4
48 4
64 4
8
79 3
80 3
81 3
82 3
78 16
47 4
42 4
63 4
8
79 3
80 3
81 3
82 3
78 16
44 4
52 4
65 4
8
79 3
80 3
81 3
82 3
78 16
45 4
67 4
58 4
9
79 4
80 4
81 4
82 4
78 20
14 4
52 4
18 4
60 4
9
79 4
80 4
81 4
82 4
78 20
30 4
49 4
51 4
66 4
9
79 4
80 4
81 4
82 4
78 20
32 4
59 4
33 4
61 4
9
79 4
80 4
81 4
82 4
78 20
55 4
36 4
62 4
43 4
9
79 4
80 4
81 4
82 4
78 20
46 4
37 4
69 4
54 4
9
79 4
80 4
81 4
82 4
78 20
42 4
62 4
63 4
43 4
9
79 4
80 4
81 4
82 4
78 20
44 4
45 4
65 4
67 4
9
79 4
80 4
81 4
82 4
78 20
50 4
38 4
71 4
59 4
9
79 4
80 4
81 4
82 4
78 20
58 4
39 4
70 4
53 4
9
79 4
80 4
81 4
82 4
78 20
51 4
66 4
40 4
68 4
9
79 4
80 4
81 4
82 4
78 20
41 4
70 4
53 4
64 4
9
79 4
80 4
81 4
82 4
78 20
69 4
72 4
54 4
56 4
9
79 4
80 4
81 4
82 4
78 20
48 4
72 4
64 4
56 4
9
79 4
80 4
81 4
82 4
78 20
47 4
73 4
61 4
63 4
9
79 4
80 4
81 4
82 4
78 20
49 4
57 4
66 4
74 4
9
79 4
80 4
81 4
82 4
78 20
52 4
65 4
60 4
75 4
9
79 4
80 4
81 4
82 4
78 20
57 4
50 4
74 4
71 4
9
79 4
80 4
81 4
82 4
78 20
60 4
75 4
46 4
69 4
9
79 4
80 4
81 4
82 4
78 20
68 4
77 4
55 4
62 4
9
79 4
80 4
81 4
82 4
78 20
71 4
59 4
73 4
61 4
9
79 4
80 4
81 4
82 4
78 20
67 4
58 4
76 4
70 4
9
79 4
80 4
81 4
82 4
78 20
77 4
73 4
62 4
63 4
9
79 4
80 4
81 4
82 4
78 20
76 4
70 4
72 4
64 4
9
79 4
80 4
81 4
82 4
78 20
65 4
67 4
75 4
76 4
9
79 4
80 4
81 4
82 4
78 20
66 4
74 4
68 4
77 4
9
79 4
80 4
81 4
82 4
78 20
74 4
71 4
77 4
73 4
9
79 4
80 4
81 4
82 4
78 20
75 4
76 4
69 4
72 4
82
79 228
80 228
81 228
82 228
15 16
6 8
32 24
41 28
47 28
48 28
42 28
34 24
7 8
8 8
17 16
23 20
24 20
22 20
16 16
0 4
1 4
2 4
13 16
19 16
25 20
27 20
30 24
14 16
9 8
20 20
35 24
44 28
49 28
52 32
51 32
18 16
31 24
3 4
26 20
45 28
57 32
65 32
66 32
60 32
40 28
29 20
28 20
50 28
67 32
74 32
75 32
68 32
46 28
37 28
4 4
10 8
38 28
58 32
71 32
76 32
77 32
69 32
55 32
36 28
5 4
12 12
39 28
59 32
70 32
73 32
72 32
62 32
54 32
21 20
11 8
33 24
53 32
61 32
64 32
63 32
56 32
43 28
79
78 228
15 4
6 2
32 6
41 7
47 7
48 7
42 7
34 6
7 2
8 2
17 4
23 5
24 5
22 5
16 4
0 1
1 1
2 1
13 4
19 4
25 5
27 5
30 6
14 4
9 2
20 5
35 6
44 7
49 7
52 8
51 8
18 4
31 6
3 1
26 5
45 7
57 8
65 8
66 8
60 8
40 7
29 5
28 5
50 7
67 8
74 8
75 8
68 8
46 7
37 7
4 1
10 2
38 7
58 8
71 8
76 8
77 8
69 8
55 8
36 7
5 1
12 3
39 7
59 8
70 8
73 8
72 8
62 8
54 8
21 5
11 2
33 6
53 8
61 8
64 8
63 8
56 8
43 7
79
78 228
15 4
6 2
32 6
41 7
47 7
48 7
42 7
34 6
7 2
8 2
17 4
23 5
24 5
22 5
16 4
0 1
1 1
2 1
13 4
19 4
25 5
27 5
30 6
14 4
9 2
20 5
35 6
44 7
49 7
52 8
51 8
18 4
31 6
3 1
26 5
45 7
57 8
65 8
66 8
60 8
40 7
29 5
28 5
50 7
67 8
74 8
75 8
68 8
46 7
37 7
4 1
10 2
38 7
58 8
71 8
76 8
77 8
69 8
55 8
36 7
5 1
12 3
39 7
59 8
70 8
73 8
72 8
62 8
54 8
21 5
11 2
33 6
53 8
61 8
64 8
63 8
56 8
43 7
79
78 228
15 4
6 2
32 6
41 7
47 7
48 7
42 7
34 6
7 2
8 2
17 4
23 5
24 5
22 5
16 4
0 1
1 1
2 1
13 4
19 4
25 5
27 5
30 6
14 4
9 2
20 5
35 6
44 7
49 7
52 8
51 8
18 4
31 6
3 1
26 5
45 7
57 8
65 8
66 8
60 8
40 7
29 5
28 5
50 7
67 8
74 8
75 8
68 8
46 7
37 7
4 1
10 2
38 7
58 8
71 8
76 8
77 8
69 8
55 8
36 7
5 1
12 3
39 7
59 8
70 8
73 8
72 8
62 8
54 8
21 5
11 2
33 6
53 8
61 8
64 8
63 8
56 8
43 7
79
78 228
15 4
6 2
32 6
41 7
47 7
48 7
42 7
34 6
7 2
8 2
17 4
23 5
24 5
22 5
16 4
0 1
1 1
2 1
13 4
19 4
25 5
27 5
30 6
14 4
9 2
20 5
35 6
44 7
49 7
52 8
51 8
18 4
31 6
3 1
26 5
45 7
57 8
65 8
66 8
60 8
40 7
29 5
28 5
50 7
67 8
74 8
75 8
68 8
46 7
37 7
4 1
10 2
38 7
58 8
71 8
76 8
77 8
69 8
55 8
36 7
5 1
12 3
39 7
59 8
70 8
73 8
72 8
62 8
54 8
21 5
11 2
33 6
53 8
61 8
64 8
63 8
56 8
43 7
end_CG
