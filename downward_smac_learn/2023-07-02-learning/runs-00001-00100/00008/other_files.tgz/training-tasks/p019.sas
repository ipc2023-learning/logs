begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var2
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var1
-1
19
Atom at-robot(loc_2_5)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
end_variable
begin_variable
var0
-1
19
Atom at(box1, loc_2_5)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
end_variable
19
begin_mutex_group
2
20 0
0 0
end_mutex_group
begin_mutex_group
2
20 1
1 0
end_mutex_group
begin_mutex_group
2
20 2
14 0
end_mutex_group
begin_mutex_group
2
20 3
11 0
end_mutex_group
begin_mutex_group
2
20 4
2 0
end_mutex_group
begin_mutex_group
2
20 5
3 0
end_mutex_group
begin_mutex_group
2
20 6
17 0
end_mutex_group
begin_mutex_group
2
20 7
15 0
end_mutex_group
begin_mutex_group
2
20 8
4 0
end_mutex_group
begin_mutex_group
2
20 9
12 0
end_mutex_group
begin_mutex_group
2
20 10
13 0
end_mutex_group
begin_mutex_group
2
20 11
5 0
end_mutex_group
begin_mutex_group
2
20 12
10 0
end_mutex_group
begin_mutex_group
2
20 13
18 0
end_mutex_group
begin_mutex_group
2
20 14
16 0
end_mutex_group
begin_mutex_group
2
20 15
6 0
end_mutex_group
begin_mutex_group
2
20 16
8 0
end_mutex_group
begin_mutex_group
2
20 17
9 0
end_mutex_group
begin_mutex_group
2
20 18
7 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
14
9
end_state
begin_goal
1
20 1
end_goal
80
begin_operator
move loc_2_5 loc_3_5 down
1
14 0
1
0 19 0 2
0
end_operator
begin_operator
move loc_3_4 loc_3_5 right
1
14 0
1
0 19 1 2
0
end_operator
begin_operator
move loc_3_4 loc_4_4 down
1
3 0
1
0 19 1 5
0
end_operator
begin_operator
move loc_3_5 loc_2_5 up
1
0 0
1
0 19 2 0
0
end_operator
begin_operator
move loc_3_5 loc_3_4 left
1
1 0
1
0 19 2 1
0
end_operator
begin_operator
move loc_3_5 loc_3_6 right
1
11 0
1
0 19 2 3
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
17 0
1
0 19 2 6
0
end_operator
begin_operator
move loc_3_6 loc_3_5 left
1
14 0
1
0 19 3 2
0
end_operator
begin_operator
move loc_3_6 loc_3_7 right
1
2 0
1
0 19 3 4
0
end_operator
begin_operator
move loc_3_6 loc_4_6 down
1
15 0
1
0 19 3 7
0
end_operator
begin_operator
move loc_3_7 loc_3_6 left
1
11 0
1
0 19 4 3
0
end_operator
begin_operator
move loc_3_7 loc_4_7 down
1
4 0
1
0 19 4 8
0
end_operator
begin_operator
move loc_4_4 loc_3_4 up
1
1 0
1
0 19 5 1
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
17 0
1
0 19 5 6
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
14 0
1
0 19 6 2
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
3 0
1
0 19 6 5
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
15 0
1
0 19 6 7
0
end_operator
begin_operator
move loc_4_5 loc_5_5 down
1
12 0
1
0 19 6 9
0
end_operator
begin_operator
move loc_4_6 loc_3_6 up
1
11 0
1
0 19 7 3
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
1
17 0
1
0 19 7 6
0
end_operator
begin_operator
move loc_4_6 loc_4_7 right
1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




21
check 0
check 0
switch 2
check 0
check 1
22
check 0
switch 15
check 0
check 1
23
check 0
check 0
switch 17
check 0
check 1
24
check 0
switch 13
check 0
check 1
25
check 0
switch 18
check 0
check 1
26
check 0
check 0
switch 15
check 0
check 1
27
check 0
switch 12
check 0
check 1
28
check 0
switch 16
check 0
check 1
29
check 0
check 0
switch 10
check 0
check 1
30
check 0
check 0
switch 5
check 0
check 1
31
check 0
switch 18
check 0
check 1
32
check 0
check 0
switch 12
check 0
check 1
33
check 0
switch 10
check 0
check 1
34
check 0
switch 16
check 0
check 1
35
check 0
switch 8
check 0
check 1
36
check 0
check 0
switch 13
check 0
check 1
37
check 0
switch 18
check 0
check 1
38
check 0
switch 6
check 0
check 1
39
check 0
switch 9
check 0
check 1
40
check 0
check 0
switch 16
check 0
check 1
41
check 0
switch 7
check 0
check 1
42
check 0
check 0
switch 18
check 0
check 1
43
check 0
switch 9
check 0
check 1
44
check 0
check 0
switch 16
check 0
check 1
45
check 0
switch 8
check 0
check 1
46
check 0
switch 7
check 0
check 1
47
check 0
check 0
switch 6
check 0
check 1
48
check 0
switch 9
check 0
check 1
49
check 0
check 0
check 0
end_SG
begin_DTG
1
1
58
2
20 2
19 6
0
end_DTG
begin_DTG
1
1
54
2
20 2
19 3
0
end_DTG
begin_DTG
1
1
52
2
20 3
19 2
0
end_DTG
begin_DTG
1
1
61
2
20 6
19 7
0
end_DTG
begin_DTG
1
1
59
2
20 7
19 6
0
end_DTG
begin_DTG
1
1
71
2
20 12
19 13
0
end_DTG
begin_DTG
1
1
72
2
20 14
19 13
0
end_DTG
begin_DTG
1
1
77
2
20 17
19 16
0
end_DTG
begin_DTG
2
1
65
2
20 13
19 9
1
79
2
20 17
19 18
0
end_DTG
begin_DTG
1
1
67
2
20 14
19 10
2
0
77
3
20 17
19 16
7 0
0
79
3
20 17
19 18
8 0
end_DTG
begin_DTG
1
1
74
2
20 13
19 14
2
0
68
3
20 12
19 11
18 0
0
71
3
20 12
19 13
5 0
end_DTG
begin_DTG
2
1
51
2
20 2
19 1
1
66
2
20 7
19 10
2
0
52
3
20 3
19 2
2 0
0
56
3
20 3
19 4
14 0
end_DTG
begin_DTG
2
1
53
2
20 6
19 2
1
76
2
20 13
19 16
2
0
60
3
20 9
19 6
18 0
0
70
3
20 9
19 13
17 0
end_DTG
begin_DTG
2
1
55
2
20 7
19 3
1
78
2
20 14
19 17
2
0
62
3
20 10
19 7
16 0
0
73
3
20 10
19 14
15 0
end_DTG
begin_DTG
2
1
56
2
20 3
19 4
1
64
2
20 6
19 9
4
0
50
3
20 2
19 0
17 0
0
51
3
20 2
19 1
11 0
0
54
3
20 2
19 3
1 0
0
58
3
20 2
19 6
0 0
end_DTG
begin_DTG
2
1
57
2
20 6
19 5
1
73
2
20 10
19 14
4
0
55
3
20 7
19 3
13 0
0
59
3
20 7
19 6
4 0
0
63
3
20 7
19 8
17 0
0
66
3
20 7
19 10
11 0
end_DTG
begin_DTG
2
1
62
2
20 10
19 7
1
69
2
20 13
19 12
4
0
67
3
20 14
19 10
9 0
0
72
3
20 14
19 13
6 0
0
75
3
20 14
19 15
18 0
0
78
3
20 14
19 17
13 0
end_DTG
begin_DTG
3
1
50
2
20 2
19 0
1
63
2
20 7
19 8
1
70
2
20 9
19 13
4
0
53
3
20 6
19 2
12 0
0
57
3
20 6
19 5
15 0
0
61
3
20 6
19 7
3 0
0
64
3
20 6
19 9
14 0
end_DTG
begin_DTG
3
1
60
2
20 9
19 6
1
68
2
20 12
19 11
1
75
2
20 14
19 15
4
0
65
3
20 13
19 9
8 0
0
69
3
20 13
19 12
16 0
0
74
3
20 13
19 14
10 0
0
76
3
20 13
19 16
12 0
end_DTG
begin_DTG
2
2
0
1
14 0
2
50
2
20 2
17 0
3
2
1
1
14 0
2
51
2
20 2
11 0
5
2
1
3 0
6
0
3
1
0 0
1
4
1
1 0
3
5
1
11 0
3
52
2
20 3
2 0
6
6
1
17 0
6
53
2
20 6
12 0
5
2
7
1
14 0
2
54
2
20 2
1 0
4
8
1
2 0
7
9
1
15 0
7
55
2
20 7
13 0
3
3
10
1
11 0
3
56
2
20 3
14 0
8
11
1
4 0
3
1
12
1
1 0
6
13
1
17 0
6
57
2
20 6
15 0
7
2
14
1
14 0
2
58
2
20 2
0 0
5
15
1
3 0
7
16
1
15 0
7
59
2
20 7
4 0
9
17
1
12 0
9
60
2
20 9
18 0
6
3
18
1
11 0
6
19
1
17 0
6
61
2
20 6
3 0
8
20
1
4 0
10
21
1
13 0
10
62
2
20 10
16 0
3
4
22
1
2 0
7
23
1
15 0
7
63
2
20 7
17 0
5
6
24
1
17 0
6
64
2
20 6
14 0
10
25
1
13 0
13
26
1
18 0
13
65
2
20 13
8 0
5
7
27
1
15 0
7
66
2
20 7
11 0
9
28
1
12 0
14
29
1
16 0
14
67
2
20 14
9 0
2
12
30
1
10 0
12
68
2
20 12
18 0
3
11
31
1
5 0
13
32
1
18 0
13
69
2
20 13
16 0
7
9
33
1
12 0
9
70
2
20 9
17 0
12
34
1
10 0
12
71
2
20 12
5 0
14
35
1
16 0
14
72
2
20 14
6 0
16
36
1
8 0
6
10
37
1
13 0
10
73
2
20 10
15 0
13
38
1
18 0
13
74
2
20 13
10 0
15
39
1
6 0
17
40
1
9 0
3
14
41
1
16 0
14
75
2
20 14
18 0
18
42
1
7 0
4
13
43
1
18 0
13
76
2
20 13
12 0
17
44
1
9 0
17
77
2
20 17
7 0
4
14
45
1
16 0
14
78
2
20 14
13 0
16
46
1
8 0
18
47
1
7 0
3
15
48
1
6 0
17
49
1
9 0
17
79
2
20 17
8 0
end_DTG
begin_DTG
0
0
4
0
58
2
19 6
0 0
1
54
2
19 3
1 0
3
51
2
19 1
11 0
6
50
2
19 0
17 0
2
2
56
2
19 4
14 0
4
52
2
19 2
2 0
0
0
4
2
64
2
19 9
14 0
5
61
2
19 7
3 0
7
57
2
19 5
15 0
9
53
2
19 2
12 0
4
3
66
2
19 10
11 0
6
63
2
19 8
17 0
8
59
2
19 6
4 0
10
55
2
19 3
13 0
0
2
6
70
2
19 13
17 0
13
60
2
19 6
18 0
2
7
73
2
19 14
15 0
14
62
2
19 7
16 0
0
2
11
71
2
19 13
5 0
13
68
2
19 11
18 0
4
9
76
2
19 16
12 0
12
74
2
19 14
10 0
14
69
2
19 12
16 0
16
65
2
19 9
8 0
4
10
78
2
19 17
13 0
13
75
2
19 15
18 0
15
72
2
19 13
6 0
17
67
2
19 10
9 0
0
0
2
16
79
2
19 18
8 0
18
77
2
19 16
7 0
0
end_DTG
begin_CG
3
20 1
19 2
14 1
3
20 1
19 3
14 1
3
20 1
19 3
11 1
3
20 1
19 3
17 1
3
20 1
19 3
15 1
3
20 1
19 2
10 1
3
20 1
19 3
16 1
3
20 1
19 3
9 1
4
20 2
19 4
18 1
9 1
3
20 1
19 4
16 1
3
20 1
19 3
18 1
4
20 2
19 5
14 1
15 1
4
20 2
19 5
17 1
18 1
4
20 2
19 5
15 1
16 1
4
20 2
19 6
11 1
17 1
4
20 2
19 6
17 1
13 1
4
20 2
19 6
13 1
18 1
5
20 3
19 7
14 1
15 1
12 1
5
20 3
19 7
12 1
10 1
16 1
20
20 30
0 1
1 1
14 6
11 4
2 1
3 1
17 7
15 6
4 1
12 4
13 4
5 1
10 3
18 7
16 6
6 1
8 2
9 3
7 1
20
19 30
0 1
1 1
14 6
11 4
2 1
3 1
17 7
15 6
4 1
12 4
13 4
5 1
10 3
18 7
16 6
6 1
8 2
9 3
7 1
end_CG
