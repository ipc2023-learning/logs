begin_version
3
end_version
begin_metric
0
end_metric
74
begin_variable
var7
-1
2
Atom clear(loc_10_12)
NegatedAtom clear(loc_10_12)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_12)
NegatedAtom clear(loc_5_12)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_8_12)
NegatedAtom clear(loc_8_12)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_12_2)
NegatedAtom clear(loc_12_2)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_2)
NegatedAtom clear(loc_11_2)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_12_9)
NegatedAtom clear(loc_12_9)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_12_3)
NegatedAtom clear(loc_12_3)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_12_4)
NegatedAtom clear(loc_12_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_12_6)
NegatedAtom clear(loc_12_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_var




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
67 0
4
0
713
2
69 61
28 0
51
249
2
69 0
62 0
62
913
2
69 78
22 0
68
833
2
69 72
67 0
2
1
725
2
69 62
17 0
52
257
2
69 1
45 0
2
5
745
2
69 65
56 0
55
293
2
69 5
50 0
4
6
761
2
69 66
53 0
56
305
2
69 6
59 0
63
869
2
69 75
36 0
65
845
2
69 73
61 0
4
7
773
2
69 67
35 0
57
317
2
69 7
58 0
64
881
2
69 76
57 0
66
857
2
69 74
40 0
2
65
897
2
69 77
61 0
67
873
2
69 75
65 0
4
8
801
2
69 69
39 0
59
329
2
69 8
66 0
66
917
2
69 78
40 0
68
885
2
69 76
67 0
4
9
817
2
69 70
47 0
60
341
2
69 9
68 0
61
901
2
69 77
44 0
67
825
2
69 71
65 0
end_DTG
begin_CG
6
70 1
71 1
72 1
73 1
69 5
17 4
6
70 1
71 1
72 1
73 1
69 5
18 4
6
70 1
71 1
72 1
73 1
69 5
27 4
6
70 1
71 1
72 1
73 1
69 5
27 4
6
70 1
71 1
72 1
73 1
69 6
15 4
6
70 1
71 1
72 1
73 1
69 6
19 4
6
70 1
71 1
72 1
73 1
69 6
43 4
6
70 1
71 1
72 1
73 1
69 6
51 4
6
70 1
71 1
72 1
73 1
69 6
16 4
6
70 1
71 1
72 1
73 1
69 5
45 4
6
70 1
71 1
72 1
73 1
69 6
50 4
7
70 2
71 2
72 2
73 2
69 10
20 4
14 4
7
70 2
71 2
72 2
73 2
69 10
14 4
21 4
7
70 2
71 2
72 2
73 2
69 10
27 4
42 4
6
70 1
71 1
72 1
73 1
69 7
29 4
6
70 1
71 1
72 1
73 1
69 7
54 4
6
70 1
71 1
72 1
73 1
69 7
54 4
7
70 2
71 2
72 2
73 2
69 11
28 4
22 4
7
70 2
71 2
72 2
73 2
69 11
23 4
26 4
7
70 2
71 2
72 2
73 2
69 11
43 4
63 4
7
70 2
71 2
72 2
73 2
69 11
56 4
29 4
7
70 2
71 2
72 2
73 2
69 11
29 4
30 4
7
70 2
71 2
72 2
73 2
69 11
45 4
44 4
7
70 2
71 2
72 2
73 2
69 11
47 4
41 4
7
70 2
71 2
72 2
73 2
69 11
46 4
41 4
7
70 2
71 2
72 2
73 2
69 11
31 4
26 4
8
70 3
71 3
72 3
73 3
69 15
41 4
25 4
18 4
6
70 1
71 1
72 1
73 1
69 8
33 4
8
70 3
71 3
72 3
73 3
69 15
17 4
47 4
44 4
6
70 1
71 1
72 1
73 1
69 8
48 4
8
70 3
71 3
72 3
73 3
69 15
48 4
21 4
32 4
8
70 3
71 3
72 3
73 3
69 15
46 4
32 4
25 4
8
70 3
71 3
72 3
73 3
69 15
49 4
30 4
31 4
8
70 3
71 3
72 3
73 3
69 15
27 4
42 4
34 4
8
70 3
71 3
72 3
73 3
69 15
33 4
52 4
45 4
8
70 3
71 3
72 3
73 3
69 15
53 4
46 4
61 4
8
70 3
71 3
72 3
73 3
69 15
56 4
50 4
57 4
8
70 3
71 3
72 3
73 3
69 15
51 4
63 4
58 4
8
70 3
71 3
72 3
73 3
69 15
42 4
43 4
55 4
8
70 3
71 3
72 3
73 3
69 15
47 4
41 4
65 4
8
70 3
71 3
72 3
73 3
69 15
60 4
61 4
65 4
7
70 2
71 2
72 2
73 2
69 12
39 4
24 4
7
70 2
71 2
72 2
73 2
69 12
38 4
52 4
7
70 2
71 2
72 2
73 2
69 12
38 4
64 4
7
70 2
71 2
72 2
73 2
69 12
62 4
67 4
8
70 3
71 3
72 3
73 3
69 16
34 4
62 4
22 4
8
70 3
71 3
72 3
73 3
69 16
35 4
49 4
24 4
8
70 3
71 3
72 3
73 3
69 16
28 4
23 4
67 4
8
70 3
71 3
72 3
73 3
69 16
56 4
29 4
49 4
8
70 3
71 3
72 3
73 3
69 16
53 4
48 4
46 4
8
70 3
71 3
72 3
73 3
69 16
54 4
59 4
36 4
8
70 3
71 3
72 3
73 3
69 16
54 4
37 4
59 4
8
70 3
71 3
72 3
73 3
69 16
42 4
55 4
62 4
8
70 3
71 3
72 3
73 3
69 16
56 4
49 4
57 4
9
70 4
71 4
72 4
73 4
69 20
15 4
16 4
51 4
50 4
8
70 3
71 3
72 3
73 3
69 16
52 4
64 4
68 4
9
70 4
71 4
72 4
73 4
69 20
20 4
53 4
48 4
36 4
8
70 3
71 3
72 3
73 3
69 16
53 4
59 4
61 4
8
70 3
71 3
72 3
73 3
69 16
59 4
60 4
61 4
9
70 4
71 4
72 4
73 4
69 20
51 4
50 4
58 4
57 4
8
70 3
71 3
72 3
73 3
69 16
63 4
58 4
66 4
9
70 4
71 4
72 4
73 4
69 20
35 4
58 4
57 4
40 4
9
70 4
71 4
72 4
73 4
69 20
52 4
45 4
68 4
44 4
9
70 4
71 4
72 4
73 4
69 20
19 4
37 4
64 4
60 4
9
70 4
71 4
72 4
73 4
69 20
43 4
63 4
55 4
66 4
9
70 4
71 4
72 4
73 4
69 20
39 4
66 4
40 4
67 4
9
70 4
71 4
72 4
73 4
69 20
64 4
60 4
68 4
65 4
9
70 4
71 4
72 4
73 4
69 20
47 4
68 4
44 4
65 4
9
70 4
71 4
72 4
73 4
69 20
55 4
62 4
66 4
67 4
73
70 170
71 170
72 170
73 170
28 20
17 16
0 4
11 8
20 16
56 32
53 28
35 20
39 20
47 28
14 12
29 20
48 28
49 28
46 28
24 16
41 24
23 16
1 4
12 8
21 16
30 20
32 20
31 20
25 16
26 20
18 16
2 4
13 8
27 20
3 4
4 4
5 4
6 4
42 24
33 20
15 12
7 4
19 16
43 24
38 20
52 28
34 20
8 4
16 12
54 32
51 28
37 20
63 32
64 32
55 28
62 32
45 28
9 4
10 4
50 28
59 32
58 28
60 28
66 32
68 32
44 24
22 16
36 20
57 28
61 32
40 20
65 32
67 32
70
69 170
28 5
17 4
0 1
11 2
20 4
56 8
53 7
35 5
39 5
47 7
14 3
29 5
48 7
49 7
46 7
24 4
41 6
23 4
1 1
12 2
21 4
30 5
32 5
31 5
25 4
26 5
18 4
2 1
13 2
27 5
3 1
4 1
5 1
6 1
42 6
33 5
15 3
7 1
19 4
43 6
38 5
52 7
34 5
8 1
16 3
54 8
51 7
37 5
63 8
64 8
55 7
62 8
45 7
9 1
10 1
50 7
59 8
58 7
60 7
66 8
68 8
44 6
22 4
36 5
57 7
61 8
40 5
65 8
67 8
70
69 170
28 5
17 4
0 1
11 2
20 4
56 8
53 7
35 5
39 5
47 7
14 3
29 5
48 7
49 7
46 7
24 4
41 6
23 4
1 1
12 2
21 4
30 5
32 5
31 5
25 4
26 5
18 4
2 1
13 2
27 5
3 1
4 1
5 1
6 1
42 6
33 5
15 3
7 1
19 4
43 6
38 5
52 7
34 5
8 1
16 3
54 8
51 7
37 5
63 8
64 8
55 7
62 8
45 7
9 1
10 1
50 7
59 8
58 7
60 7
66 8
68 8
44 6
22 4
36 5
57 7
61 8
40 5
65 8
67 8
70
69 170
28 5
17 4
0 1
11 2
20 4
56 8
53 7
35 5
39 5
47 7
14 3
29 5
48 7
49 7
46 7
24 4
41 6
23 4
1 1
12 2
21 4
30 5
32 5
31 5
25 4
26 5
18 4
2 1
13 2
27 5
3 1
4 1
5 1
6 1
42 6
33 5
15 3
7 1
19 4
43 6
38 5
52 7
34 5
8 1
16 3
54 8
51 7
37 5
63 8
64 8
55 7
62 8
45 7
9 1
10 1
50 7
59 8
58 7
60 7
66 8
68 8
44 6
22 4
36 5
57 7
61 8
40 5
65 8
67 8
70
69 170
28 5
17 4
0 1
11 2
20 4
56 8
53 7
35 5
39 5
47 7
14 3
29 5
48 7
49 7
46 7
24 4
41 6
23 4
1 1
12 2
21 4
30 5
32 5
31 5
25 4
26 5
18 4
2 1
13 2
27 5
3 1
4 1
5 1
6 1
42 6
33 5
15 3
7 1
19 4
43 6
38 5
52 7
34 5
8 1
16 3
54 8
51 7
37 5
63 8
64 8
55 7
62 8
45 7
9 1
10 1
50 7
59 8
58 7
60 7
66 8
68 8
44 6
22 4
36 5
57 7
61 8
40 5
65 8
67 8
end_CG
