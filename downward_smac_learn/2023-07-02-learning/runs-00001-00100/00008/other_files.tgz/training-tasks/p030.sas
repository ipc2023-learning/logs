begin_version
3
end_version
begin_metric
0
end_metric
17
begin_variable
var2
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var1
-1
15
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
end_variable
begin_variable
var0
-1
15
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
end_variable
15
begin_mutex_group
2
16 0
0 0
end_mutex_group
begin_mutex_group
2
16 1
1 0
end_mutex_group
begin_mutex_group
2
16 2
5 0
end_mutex_group
begin_mutex_group
2
16 3
7 0
end_mutex_group
begin_mutex_group
2
16 4
11 0
end_mutex_group
begin_mutex_group
2
16 5
13 0
end_mutex_group
begin_mutex_group
2
16 6
9 0
end_mutex_group
begin_mutex_group
2
16 7
6 0
end_mutex_group
begin_mutex_group
2
16 8
8 0
end_mutex_group
begin_mutex_group
2
16 9
12 0
end_mutex_group
begin_mutex_group
2
16 10
14 0
end_mutex_group
begin_mutex_group
2
16 11
10 0
end_mutex_group
begin_mutex_group
2
16 12
2 0
end_mutex_group
begin_mutex_group
2
16 13
3 0
end_mutex_group
begin_mutex_group
2
16 14
4 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
9
3
end_state
begin_goal
1
16 14
end_goal
62
begin_operator
move loc_2_6 loc_2_7 right
1
1 0
1
0 15 0 1
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
13 0
1
0 15 0 5
0
end_operator
begin_operator
move loc_2_7 loc_2_6 left
1
0 0
1
0 15 1 0
0
end_operator
begin_operator
move loc_2_7 loc_3_7 down
1
9 0
1
0 15 1 6
0
end_operator
begin_operator
move loc_3_3 loc_3_4 right
1
7 0
1
0 15 2 3
0
end_operator
begin_operator
move loc_3_3 loc_4_3 down
1
6 0
1
0 15 2 7
0
end_operator
begin_operator
move loc_3_4 loc_3_3 left
1
5 0
1
0 15 3 2
0
end_operator
begin_operator
move loc_3_4 loc_3_5 right
1
11 0
1
0 15 3 4
0
end_operator
begin_operator
move loc_3_4 loc_4_4 down
1
8 0
1
0 15 3 8
0
end_operator
begin_operator
move loc_3_5 loc_3_4 left
1
7 0
1
0 15 4 3
0
end_operator
begin_operator
move loc_3_5 loc_3_6 right
1
13 0
1
0 15 4 5
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
12 0
1
0 15 4 9
0
end_operator
begin_operator
move loc_3_6 loc_2_6 up
1
0 0
1
0 15 5 0
0
end_operator
begin_operator
move loc_3_6 loc_3_5 left
1
11 0
1
0 15 5 4
0
end_operator
begin_operator
move loc_3_6 loc_3_7 right
1
9 0
1
0 15 5 6
0
end_operator
begin_operator
move loc_3_6 loc_4_6 down
1
14 0
1
0 15 5 10
0
end_operator
begin_operator
move loc_3_7 loc_2_7 up
1
1 0
1
0 15 6 1
0
end_operator
begin_operator
move loc_3_7 loc_3_6 left
1
13 0
1
0 15 6 5
0
end_operator
begin_operator
move loc_3_7 loc_4_7 down
1
10 0
1
0 15 6 11
0
end_operator
begin_operator
move loc_4_3 loc_3_3 up
1
5 0
1
0 15 7 2
0
end_operator
begin_operator
move loc_4_3 loc_4_4 right
1
8 0
1
0 15 7 8
0
end_operator
begin_operator
move loc_4_3 loc_5_3 down
1
2 0
1
0 15 7 12
0
end_operator
begin_operator
move loc_4_4 loc_3_4 up
1
7 0
1
0 15 8 3
0
end_operator
begin_operator
move loc_4_4 loc_4_3 left
1
6 0
1
0 15 8 7
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
12 0
1
0 15 8 9
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
11 0
1
0 15 9 4
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
8 0
1
0 15 9 8
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
14 0
1
0 15 9 10
0
end_operator
begin_operator
move loc_4_6 loc_3_6 up
1
13 0
1
0 15 10 5
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
1
12 0
1
0 15 10 9
0
end_operator
begin_operator
move loc_4_6 loc_4




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 0
check 0
check 0
check 0
switch 15
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
48
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
check 1
54
check 0
check 0
check 0
switch 12
check 0
check 1
58
check 0
check 0
check 0
switch 13
check 0
check 1
60
check 0
check 0
check 0
check 0
switch 15
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
50
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
61
check 0
check 0
check 0
check 0
check 0
check 0
switch 15
check 0
switch 1
check 0
check 1
0
check 0
switch 13
check 0
check 1
1
check 0
check 0
switch 0
check 0
check 1
2
check 0
switch 9
check 0
check 1
3
check 0
check 0
switch 7
check 0
check 1
4
check 0
switch 6
check 0
check 1
5
check 0
check 0
switch 5
check 0
check 1
6
check 0
switch 11
check 0
check 1
7
check 0
switch 8
check 0
check 1
8
check 0
check 0
switch 7
check 0
check 1
9
check 0
switch 13
check 0
check 1
10
check 0
switch 12
check 0
check 1
11
check 0
check 0
switch 0
check 0
check 1
12
check 0
switch 11
check 0
check 1
13
check 0
switch 9
check 0
check 1
14
check 0
switch 14
check 0
check 1
15
check 0
check 0
switch 1
check 0
check 1
16
check 0
switch 13
check 0
check 1
17
check 0
switch 10
check 0
check 1
18
check 0
check 0
switch 5
check 0
check 1
19
check 0
switch 8
check 0
check 1
20
check 0
switch 2
check 0
check 1
21
check 0
check 0
switch 7
check 0
check 1
22
check 0
switch 6
check 0
check 1
23
check 0
switch 12
check 0
check 1
24
check 0
check 0
switch 11
check 0
check 1
25
check 0
switch 8
check 0
check 1
26
check 0
switch 14
check 0
check 1
27
check 0
check 0
switch 13
check 0
check 1
28
check 0
switch 12
check 0
check 1
29
check 0
switch 10
check 0
check 1
30
check 0
switch 3
check 0
check 1
31
check 0
check 0
switch 9
check 0
check 1
32
check 0
switch 14
check 0
check 1
33
check 0
switch 4
check 0
check 1
34
check 0
check 0
switch 6
check 0
check 1
35
check 0
check 0
switch 14
check 0
check 1
36
check 0
switch 4
check 0
check 1
37
check 0
check 0
switch 10
check 0
check 1
38
check 0
switch 3
check 0
check 1
39
check 0
check 0
check 0
end_SG
begin_DTG
1
1
55
2
16 5
15 10
0
end_DTG
begin_DTG
1
1
57
2
16 6
15 11
0
end_DTG
begin_DTG
1
1
43
2
16 7
15 2
0
end_DTG
begin_DTG
1
1
48
2
16 10
15 5
0
end_DTG
begin_DTG
1
1
50
2
16 11
15 6
0
end_DTG
begin_DTG
2
1
45
2
16 3
15 4
1
59
2
16 7
15 12
0
end_DTG
begin_DTG
1
1
53
2
16 8
15 9
2
0
43
3
16 7
15 2
2 0
0
59
3
16 7
15 12
5 0
end_DTG
begin_DTG
1
1
47
2
16 4
15 5
2
0
42
3
16 3
15 2
11 0
0
45
3
16 3
15 4
5 0
end_DTG
begin_DTG
1
1
56
2
16 9
15 10
2
0
51
3
16 8
15 7
12 0
0
53
3
16 8
15 9
6 0
end_DTG
begin_DTG
2
1
46
2
16 5
15 4
1
61
2
16 11
15 14
2
0
41
3
16 6
15 1
10 0
0
57
3
16 6
15 11
1 0
end_DTG
begin_DTG
2
1
41
2
16 6
15 1
1
54
2
16 10
15 9
2
0
50
3
16 11
15 6
4 0
0
61
3
16 11
15 14
9 0
end_DTG
begin_DTG
2
1
42
2
16 3
15 2
1
49
2
16 5
15 6
2
0
44
3
16 4
15 3
13 0
0
47
3
16 4
15 5
7 0
end_DTG
begin_DTG
2
1
51
2
16 8
15 7
1
58
2
16 10
15 11
2
0
52
3
16 9
15 8
14 0
0
56
3
16 9
15 10
8 0
end_DTG
begin_DTG
2
1
44
2
16 4
15 3
1
60
2
16 10
15 13
4
0
40
3
16 5
15 0
14 0
0
46
3
16 5
15 4
9 0
0
49
3
16 5
15 6
11 0
0
55
3
16 5
15 10
0 0
end_DTG
begin_DTG
2
1
40
2
16 5
15 0
1
52
2
16 9
15 8
4
0
48
3
16 10
15 5
3 0
0
54
3
16 10
15 9
10 0
0
58
3
16 10
15 11
12 0
0
60
3
16 10
15 13
13 0
end_DTG
begin_DTG
3
1
0
1
1 0
5
1
1
13 0
5
40
2
16 5
14 0
3
0
2
1
0 0
6
3
1
9 0
6
41
2
16 6
10 0
4
3
4
1
7 0
3
42
2
16 3
11 0
7
5
1
6 0
7
43
2
16 7
2 0
4
2
6
1
5 0
4
7
1
11 0
4
44
2
16 4
13 0
8
8
1
8 0
5
3
9
1
7 0
3
45
2
16 3
5 0
5
10
1
13 0
5
46
2
16 5
9 0
9
11
1
12 0
6
0
12
1
0 0
4
13
1
11 0
4
47
2
16 4
7 0
6
14
1
9 0
10
15
1
14 0
10
48
2
16 10
3 0
5
1
16
1
1 0
5
17
1
13 0
5
49
2
16 5
11 0
11
18
1
10 0
11
50
2
16 11
4 0
4
2
19
1
5 0
8
20
1
8 0
8
51
2
16 8
12 0
12
21
1
2 0
4
3
22
1
7 0
7
23
1
6 0
9
24
1
12 0
9
52
2
16 9
14 0
5
4
25
1
11 0
8
26
1
8 0
8
53
2
16 8
6 0
10
27
1
14 0
10
54
2
16 10
10 0
6
5
28
1
13 0
5
55
2
16 5
0 0
9
29
1
12 0
9
56
2
16 9
8 0
11
30
1
10 0
13
31
1
3 0
5
6
32
1
9 0
6
57
2
16 6
1 0
10
33
1
14 0
10
58
2
16 10
12 0
14
34
1
4 0
2
7
35
1
6 0
7
59
2
16 7
5 0
3
10
36
1
14 0
10
60
2
16 10
13 0
14
37
1
4 0
3
11
38
1
10 0
11
61
2
16 11
9 0
13
39
1
3 0
end_DTG
begin_DTG
0
0
0
2
2
45
2
15 4
5 0
4
42
2
15 2
11 0
2
3
47
2
15 5
7 0
5
44
2
15 3
13 0
4
0
55
2
15 10
0 0
4
49
2
15 6
11 0
6
46
2
15 4
9 0
10
40
2
15 0
14 0
2
1
57
2
15 11
1 0
11
41
2
15 1
10 0
2
2
59
2
15 12
5 0
12
43
2
15 2
2 0
2
7
53
2
15 9
6 0
9
51
2
15 7
12 0
2
8
56
2
15 10
8 0
10
52
2
15 8
14 0
4
5
60
2
15 13
13 0
9
58
2
15 11
12 0
11
54
2
15 9
10 0
13
48
2
15 5
3 0
2
6
61
2
15 14
9 0
14
50
2
15 6
4 0
0
0
0
end_DTG
begin_CG
3
16 1
15 3
13 1
3
16 1
15 3
9 1
3
16 1
15 2
6 1
3
16 1
15 3
14 1
3
16 1
15 3
10 1
4
16 2
15 4
7 1
6 1
3
16 1
15 4
8 1
3
16 1
15 4
11 1
3
16 1
15 4
12 1
4
16 2
15 5
13 1
10 1
4
16 2
15 5
9 1
14 1
4
16 2
15 5
7 1
13 1
4
16 2
15 5
8 1
14 1
4
16 2
15 6
11 1
14 1
4
16 2
15 6
13 1
12 1
16
16 22
0 1
1 1
5 2
7 3
11 4
13 6
9 4
6 3
8 3
12 4
14 6
10 4
2 1
3 1
4 1
16
15 22
0 1
1 1
5 2
7 3
11 4
13 6
9 4
6 3
8 3
12 4
14 6
10 4
2 1
3 1
4 1
end_CG
