begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var3
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var2
-1
38
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
38
Atom at(box1, loc_2_7)
Atom at(box1, loc_2_8)
Atom at(box1, loc_2_9)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_3_9)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_8)
Atom at(box1, loc_4_9)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_8)
Atom at(box1, loc_5_9)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_6_9)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_2)
Atom at(box1, loc_8_7)
Atom at(box1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




92
1
30 0
32
228
2
39 32
31 0
32
229
2
40 32
31 0
9
24
93
1
35 0
24
230
2
39 24
24 0
24
231
2
40 24
24 0
31
94
1
28 0
31
232
2
39 31
29 0
31
233
2
40 31
29 0
33
95
1
31 0
33
234
2
39 33
17 0
33
235
2
40 33
17 0
6
25
96
1
32 0
32
97
1
30 0
32
236
2
39 32
28 0
32
237
2
40 32
28 0
34
98
1
17 0
36
99
1
4 0
7
26
100
1
36 0
26
238
2
39 26
26 0
26
239
2
40 26
26 0
33
101
1
31 0
33
240
2
39 33
30 0
33
241
2
40 33
30 0
37
102
1
5 0
3
28
103
1
10 0
28
242
2
39 28
7 0
28
243
2
40 28
7 0
4
33
104
1
31 0
33
244
2
39 33
32 0
33
245
2
40 33
32 0
37
105
1
5 0
4
34
106
1
17 0
34
246
2
39 34
36 0
34
247
2
40 34
36 0
36
107
1
4 0
end_DTG
begin_DTG
0
2
0
112
2
38 2
0 0
2
108
2
38 0
6 0
0
0
0
2
4
124
2
38 6
2 0
6
118
2
38 4
22 0
2
5
128
2
38 7
16 0
7
120
2
38 5
33 0
4
1
150
2
38 13
9 0
6
132
2
38 8
22 0
8
126
2
38 6
18 0
13
110
2
38 1
27 0
2
2
154
2
38 14
6 0
14
114
2
38 2
19 0
2
3
158
2
38 15
1 0
15
116
2
38 3
21 0
2
9
144
2
38 11
14 0
11
136
2
38 9
12 0
2
10
146
2
38 12
15 0
12
140
2
38 10
23 0
2
5
164
2
38 17
16 0
17
122
2
38 5
24 0
2
7
168
2
38 18
33 0
18
130
2
38 7
26 0
2
8
172
2
38 19
18 0
19
134
2
38 8
11 0
2
9
178
2
38 21
14 0
21
138
2
38 9
34 0
2
10
182
2
38 22
15 0
22
142
2
38 10
37 0
2
12
192
2
38 24
23 0
24
148
2
38 12
35 0
2
13
204
2
38 26
27 0
26
152
2
38 13
36 0
2
14
210
2
38 27
19 0
27
156
2
38 14
8 0
0
4
15
216
2
38 29
21 0
20
184
2
38 22
7 0
22
174
2
38 20
37 0
29
160
2
38 15
20 0
4
16
220
2
38 30
13 0
21
188
2
38 23
34 0
23
180
2
38 21
25 0
30
162
2
38 16
29 0
2
22
194
2
38 24
37 0
24
186
2
38 22
35 0
4
17
230
2
38 32
24 0
23
198
2
38 25
25 0
25
190
2
38 23
32 0
32
166
2
38 17
30 0
2
24
206
2
38 26
35 0
26
196
2
38 24
36 0
4
18
238
2
38 34
26 0
25
212
2
38 27
32 0
27
200
2
38 25
8 0
34
170
2
38 18
17 0
0
2
20
242
2
38 35
7 0
35
176
2
38 20
3 0
2
28
222
2
38 30
10 0
30
214
2
38 28
29 0
2
29
226
2
38 31
20 0
31
218
2
38 29
28 0
2
30
232
2
38 32
29 0
32
224
2
38 30
30 0
2
31
236
2
38 33
28 0
33
228
2
38 31
31 0
4
25
244
2
38 36
32 0
32
240
2
38 34
30 0
34
234
2
38 32
17 0
36
202
2
38 25
4 0
2
26
246
2
38 37
36 0
37
208
2
38 26
5 0
0
0
0
end_DTG
begin_DTG
0
2
0
113
2
38 2
0 0
2
109
2
38 0
6 0
0
0
0
2
4
125
2
38 6
2 0
6
119
2
38 4
22 0
2
5
129
2
38 7
16 0
7
121
2
38 5
33 0
4
1
151
2
38 13
9 0
6
133
2
38 8
22 0
8
127
2
38 6
18 0
13
111
2
38 1
27 0
2
2
155
2
38 14
6 0
14
115
2
38 2
19 0
2
3
159
2
38 15
1 0
15
117
2
38 3
21 0
2
9
145
2
38 11
14 0
11
137
2
38 9
12 0
2
10
147
2
38 12
15 0
12
141
2
38 10
23 0
2
5
165
2
38 17
16 0
17
123
2
38 5
24 0
2
7
169
2
38 18
33 0
18
131
2
38 7
26 0
2
8
173
2
38 19
18 0
19
135
2
38 8
11 0
2
9
179
2
38 21
14 0
21
139
2
38 9
34 0
2
10
183
2
38 22
15 0
22
143
2
38 10
37 0
2
12
193
2
38 24
23 0
24
149
2
38 12
35 0
2
13
205
2
38 26
27 0
26
153
2
38 13
36 0
2
14
211
2
38 27
19 0
27
157
2
38 14
8 0
0
4
15
217
2
38 29
21 0
20
185
2
38 22
7 0
22
175
2
38 20
37 0
29
161
2
38 15
20 0
4
16
221
2
38 30
13 0
21
189
2
38 23
34 0
23
181
2
38 21
25 0
30
163
2
38 16
29 0
2
22
195
2
38 24
37 0
24
187
2
38 22
35 0
4
17
231
2
38 32
24 0
23
199
2
38 25
25 0
25
191
2
38 23
32 0
32
167
2
38 17
30 0
2
24
207
2
38 26
35 0
26
197
2
38 24
36 0
4
18
239
2
38 34
26 0
25
213
2
38 27
32 0
27
201
2
38 25
8 0
34
171
2
38 18
17 0
0
2
20
243
2
38 35
7 0
35
177
2
38 20
3 0
2
28
223
2
38 30
10 0
30
215
2
38 28
29 0
2
29
227
2
38 31
20 0
31
219
2
38 29
28 0
2
30
233
2
38 32
29 0
32
225
2
38 30
30 0
2
31
237
2
38 33
28 0
33
229
2
38 31
31 0
4
25
245
2
38 36
32 0
32
241
2
38 34
30 0
34
235
2
38 32
17 0
36
203
2
38 25
4 0
2
26
247
2
38 37
36 0
37
209
2
38 26
5 0
0
0
0
end_DTG
begin_CG
4
39 1
40 1
38 4
9 2
4
39 1
40 1
38 3
14 2
4
39 1
40 1
38 4
16 2
4
39 1
40 1
38 3
10 2
4
39 1
40 1
38 4
31 2
4
39 1
40 1
38 4
17 2
5
39 2
40 2
38 6
9 2
18 2
5
39 2
40 2
38 6
34 2
10 2
5
39 2
40 2
38 6
11 2
36 2
4
39 1
40 1
38 5
33 2
4
39 1
40 1
38 5
20 2
4
39 1
40 1
38 5
19 2
4
39 1
40 1
38 5
15 2
4
39 1
40 1
38 5
37 2
5
39 2
40 2
38 7
15 2
21 2
5
39 2
40 2
38 7
12 2
13 2
5
39 2
40 2
38 7
22 2
23 2
5
39 2
40 2
38 7
36 2
31 2
5
39 2
40 2
38 7
33 2
19 2
5
39 2
40 2
38 7
18 2
11 2
5
39 2
40 2
38 7
34 2
29 2
5
39 2
40 2
38 7
14 2
34 2
5
39 2
40 2
38 7
16 2
33 2
5
39 2
40 2
38 7
12 2
24 2
5
39 2
40 2
38 6
23 2
35 2
5
39 2
40 2
38 7
37 2
35 2
5
39 2
40 2
38 7
27 2
36 2
5
39 2
40 2
38 7
33 2
26 2
5
39 2
40 2
38 7
29 2
30 2
6
39 3
40 3
38 9
37 2
20 2
28 2
6
39 3
40 3
38 9
35 2
28 2
31 2
4
39 1
40 1
38 6
30 2
6
39 3
40 3
38 9
35 2
36 2
31 2
5
39 2
40 2
38 8
22 2
27 2
5
39 2
40 2
38 8
21 2
37 2
6
39 3
40 3
38 10
24 2
25 2
32 2
6
39 3
40 3
38 10
26 2
32 2
17 2
6
39 3
40 3
38 10
13 2
34 2
25 2
40
39 70
40 70
0 2
9 6
6 4
1 2
2 2
16 8
22 8
33 12
18 8
14 8
15 8
12 6
23 8
27 8
19 8
21 8
13 6
24 8
26 8
11 6
7 4
34 12
37 14
25 8
35 14
32 10
36 14
8 4
10 6
20 8
29 10
28 8
30 10
31 10
17 8
3 2
4 2
5 2
39
38 70
0 1
9 3
6 2
1 1
2 1
16 4
22 4
33 6
18 4
14 4
15 4
12 3
23 4
27 4
19 4
21 4
13 3
24 4
26 4
11 3
7 2
34 6
37 7
25 4
35 7
32 5
36 7
8 2
10 3
20 4
29 5
28 4
30 5
31 5
17 4
3 1
4 1
5 1
39
38 70
0 1
9 3
6 2
1 1
2 1
16 4
22 4
33 6
18 4
14 4
15 4
12 3
23 4
27 4
19 4
21 4
13 3
24 4
26 4
11 3
7 2
34 6
37 7
25 4
35 7
32 5
36 7
8 2
10 3
20 4
29 5
28 4
30 5
31 5
17 4
3 1
4 1
5 1
end_CG
