begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var10
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var2
-1
51
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
19
290
2
49 32
1 0
32
226
2
49 19
21 0
2
20
294
2
49 33
34 0
33
232
2
49 20
7 0
4
21
298
2
49 34
45 0
28
282
2
49 30
18 0
30
274
2
49 28
35 0
34
238
2
49 21
39 0
2
22
302
2
49 35
47 0
35
246
2
49 22
25 0
2
24
306
2
49 36
43 0
36
258
2
49 24
10 0
2
27
310
2
49 38
13 0
38
270
2
49 27
22 0
0
4
29
314
2
49 39
40 0
33
304
2
49 35
7 0
35
296
2
49 33
25 0
39
278
2
49 29
14 0
2
30
318
2
49 40
35 0
40
284
2
49 30
23 0
2
31
326
2
49 42
20 0
42
288
2
49 31
36 0
0
2
32
338
2
49 45
21 0
45
292
2
49 32
15 0
2
34
342
2
49 47
39 0
46
300
2
49 34
3 0
2
39
322
2
49 41
14 0
41
316
2
49 39
26 0
2
40
328
2
49 42
23 0
42
320
2
49 40
36 0
2
41
332
2
49 43
26 0
43
324
2
49 41
38 0
4
37
344
2
49 49
2 0
42
336
2
49 44
36 0
44
330
2
49 42
12 0
47
308
2
49 37
4 0
2
43
340
2
49 45
38 0
45
334
2
49 43
15 0
2
38
346
2
49 50
22 0
48
312
2
49 38
5 0
0
0
0
end_DTG
begin_DTG
0
2
0
149
2
49 2
6 0
2
141
2
49 0
31 0
2
1
155
2
49 3
16 0
3
145
2
49 1
32 0
2
2
161
2
49 4
31 0
4
151
2
49 2
27 0
2
3
165
2
49 5
32 0
5
157
2
49 3
29 0
2
4
171
2
49 6
27 0
6
163
2
49 4
8 0
2
5
173
2
49 7
29 0
7
167
2
49 5
0 0
0
2
0
193
2
49 13
6 0
13
143
2
49 0
33 0
4
1
199
2
49 14
16 0
8
183
2
49 10
17 0
10
175
2
49 8
42 0
14
147
2
49 1
46 0
4
2
205
2
49 15
31 0
9
187
2
49 11
41 0
11
179
2
49 9
28 0
15
153
2
49 2
48 0
2
3
213
2
49 16
32 0
16
159
2
49 3
44 0
2
5
223
2
49 18
29 0
18
169
2
49 5
19 0
2
8
229
2
49 20
17 0
20
177
2
49 8
34 0
4
9
235
2
49 21
41 0
13
207
2
49 15
33 0
15
195
2
49 13
48 0
21
181
2
49 9
45 0
4
10
241
2
49 22
42 0
14
215
2
49 16
46 0
16
201
2
49 14
44 0
22
185
2
49 10
47 0
4
11
249
2
49 23
28 0
15
219
2
49 17
48 0
17
209
2
49 15
24 0
23
189
2
49 11
37 0
2
16
225
2
49 18
44 0
18
217
2
49 16
19 0
2
12
261
2
49 25
9 0
25
191
2
49 12
30 0
0
2
13
273
2
49 28
33 0
28
197
2
49 13
18 0
4
14
277
2
49 29
46 0
20
243
2
49 22
34 0
22
231
2
49 20
47 0
29
203
2
49 14
40 0
4
15
281
2
49 30
48 0
21
251
2
49 23
45 0
23
237
2
49 21
37 0
30
211
2
49 15
35 0
2
22
255
2
49 24
47 0
24
245
2
49 22
43 0
4
17
287
2
49 31
24 0
23
263
2
49 25
37 0
25
253
2
49 23
30 0
31
221
2
49 17
20 0
2
24
267
2
49 26
43 0
26
257
2
49 24
11 0
2
25
269
2
49 27
30 0
27
265
2
49 25
13 0
2
19
291
2
49 32
1 0
32
227
2
49 19
21 0
2
20
295
2
49 33
34 0
33
233
2
49 20
7 0
4
21
299
2
49 34
45 0
28
283
2
49 30
18 0
30
275
2
49 28
35 0
34
239
2
49 21
39 0
2
22
303
2
49 35
47 0
35
247
2
49 22
25 0
2
24
307
2
49 36
43 0
36
259
2
49 24
10 0
2
27
311
2
49 38
13 0
38
271
2
49 27
22 0
0
4
29
315
2
49 39
40 0
33
305
2
49 35
7 0
35
297
2
49 33
25 0
39
279
2
49 29
14 0
2
30
319
2
49 40
35 0
40
285
2
49 30
23 0
2
31
327
2
49 42
20 0
42
289
2
49 31
36 0
0
2
32
339
2
49 45
21 0
45
293
2
49 32
15 0
2
34
343
2
49 47
39 0
46
301
2
49 34
3 0
2
39
323
2
49 41
14 0
41
317
2
49 39
26 0
2
40
329
2
49 42
23 0
42
321
2
49 40
36 0
2
41
333
2
49 43
26 0
43
325
2
49 41
38 0
4
37
345
2
49 49
2 0
42
337
2
49 44
36 0
44
331
2
49 42
12 0
47
309
2
49 37
4 0
2
43
341
2
49 45
38 0
45
335
2
49 43
15 0
2
38
347
2
49 50
22 0
48
313
2
49 38
5 0
0
0
0
end_DTG
begin_CG
4
50 1
51 1
49 3
8 2
4
50 1
51 1
49 3
13 2
4
50 1
51 1
49 4
38 2
4
50 1
51 1
49 4
14 2
4
50 1
51 1
49 3
38 2
4
50 1
51 1
49 3
15 2
5
50 2
51 2
49 6
16 2
17 2
5
50 2
51 2
49 6
18 2
39 2
4
50 1
51 1
49 4
29 2
4
50 1
51 1
49 4
19 2
4
50 1
51 1
49 5
20 2
4
50 1
51 1
49 4
30 2
4
50 1
51 1
49 4
38 2
5
50 2
51 2
49 7
11 2
21 2
5
50 2
51 2
49 7
39 2
23 2
5
50 2
51 2
49 7
22 2
12 2
5
50 2
51 2
49 7
31 2
41 2
5
50 2
51 2
49 7
41 2
33 2
5
50 2
51 2
49 7
34 2
40 2
5
50 2
51 2
49 7
9 2
24 2
5
50 2
51 2
49 6
43 2
10 2
5
50 2
51 2
49 6
13 2
22 2
5
50 2
51 2
49 6
21 2
15 2
5
50 2
51 2
49 7
25 2
26 2
5
50 2
51 2
49 7
44 2
43 2
5
50 2
51 2
49 7
35 2
39 2
5
50 2
51 2
49 7
23 2
36 2
5
50 2
51 2
49 6
32 2
29 2
5
50 2
51 2
49 7
42 2
44 2
6
50 3
51 3
49 9
27 2
8 2
9 2
6
50 3
51 3
49 9
19 2
43 2
11 2
6
50 3
51 3
49 9
16 2
32 2
42 2
6
50 3
51 3
49 9
31 2
27 2
28 2
6
50 3
51 3
49 9
17 2
46 2
34 2
6
50 3
51 3
49 9
33 2
45 2
18 2
6
50 3
51 3
49 9
47 2
40 2
25 2
6
50 3
51 3
49 9
10 2
26 2
38 2
6
50 3
51 3
49 9
44 2
47 2
43 2
5
50 2
51 2
49 8
36 2
12 2
5
50 2
51 2
49 8
40 2
14 2
5
50 2
51 2
49 8
45 2
39 2
5
50 2
51 2
49 8
42 2
46 2
5
50 2
51 2
49 8
41 2
48 2
6
50 3
51 3
49 10
37 2
30 2
20 2
6
50 3
51 3
49 10
28 2
48 2
24 2
6
50 3
51 3
49 10
46 2
47 2
40 2
6
50 3
51 3
49 10
41 2
48 2
45 2
7
50 4
51 4
49 12
48 2
45 2
37 2
35 2
7
50 4
51 4
49 12
42 2
46 2
44 2
47 2
51
50 104
51 104
6 4
16 8
31 10
32 10
27 8
29 10
8 6
0 2
17 8
41 12
42 12
28 8
9 6
33 10
46 14
48 16
44 14
24 8
19 8
1 2
34 10
45 14
47 16
37 10
43 14
30 10
11 6
13 8
18 8
40 12
35 10
20 8
21 8
7 4
39 12
25 8
10 6
2 2
22 8
14 8
23 8
26 8
36 10
38 12
12 6
15 8
3 2
4 2
5 2
50
49 104
6 2
16 4
31 5
32 5
27 4
29 5
8 3
0 1
17 4
41 6
42 6
28 4
9 3
33 5
46 7
48 8
44 7
24 4
19 4
1 1
34 5
45 7
47 8
37 5
43 7
30 5
11 3
13 4
18 4
40 6
35 5
20 4
21 4
7 2
39 6
25 4
10 3
2 1
22 4
14 4
23 4
26 4
36 5
38 6
12 3
15 4
3 1
4 1
5 1
50
49 104
6 2
16 4
31 5
32 5
27 4
29 5
8 3
0 1
17 4
41 6
42 6
28 4
9 3
33 5
46 7
48 8
44 7
24 4
19 4
1 1
34 5
45 7
47 8
37 5
43 7
30 5
11 3
13 4
18 4
40 6
35 5
20 4
21 4
7 2
39 6
25 4
10 3
2 1
22 4
14 4
23 4
26 4
36 5
38 6
12 3
15 4
3 1
4 1
5 1
end_CG
