begin_version
3
end_version
begin_metric
0
end_metric
101
begin_variable
var7
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_12_11)
NegatedAtom clear(loc_12_11)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_12_2)
NegatedAtom clear(loc_12_2)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_7_12)
NegatedAtom clear(loc_7_12)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var94
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_2_12)
NegatedAtom clear(loc_2_12)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_4_12)
NegatedAtom clear(loc_4_12)
end_variable
begin_variable
var93
-1
2
Atom clear(loc_9_12)
NegatedAtom clear(loc_9_12)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_3_12)
NegatedAtom clear(loc_3_12)
end_variable
begin_variable
var84
-1
2
Atom clear(loc_8_12)
NegatedAtom clear(loc_8_12)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_12_3)
NegatedAtom clear(loc_12_3)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var75
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_12_4)
NegatedAtom clear(loc_12_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var83
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var85
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var92
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var95
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begi




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





6
97 1
98 1
99 1
100 1
96 8
59 4
8
97 3
98 3
99 3
100 3
96 15
35 4
55 4
37 4
8
97 3
98 3
99 3
100 3
96 15
71 4
65 4
54 4
8
97 3
98 3
99 3
100 3
96 15
54 4
66 4
73 4
8
97 3
98 3
99 3
100 3
96 15
55 4
60 4
64 4
8
97 3
98 3
99 3
100 3
96 15
61 4
79 4
53 4
8
97 3
98 3
99 3
100 3
96 15
61 4
53 4
67 4
8
97 3
98 3
99 3
100 3
96 15
67 4
68 4
57 4
8
97 3
98 3
99 3
100 3
96 15
69 4
48 4
50 4
8
97 3
98 3
99 3
100 3
96 15
70 4
51 4
47 4
7
97 2
98 2
99 2
100 2
96 12
38 4
62 4
7
97 2
98 2
99 2
100 2
96 12
76 4
47 4
7
97 2
98 2
99 2
100 2
96 12
77 4
48 4
8
97 3
98 3
99 3
100 3
96 16
24 4
35 4
36 4
7
97 2
98 2
99 2
100 2
96 12
85 4
75 4
8
97 3
98 3
99 3
100 3
96 16
41 4
74 4
42 4
8
97 3
98 3
99 3
100 3
96 16
40 4
43 4
63 4
8
97 3
98 3
99 3
100 3
96 16
77 4
33 4
57 4
8
97 3
98 3
99 3
100 3
96 16
56 4
46 4
78 4
8
97 3
98 3
99 3
100 3
96 16
34 4
76 4
80 4
8
97 3
98 3
99 3
100 3
96 16
39 4
60 4
71 4
8
97 3
98 3
99 3
100 3
96 16
59 4
43 4
72 4
9
97 4
98 4
99 4
100 4
96 20
36 4
25 4
44 4
45 4
8
97 3
98 3
99 3
100 3
96 16
73 4
49 4
80 4
8
97 3
98 3
99 3
100 3
96 16
55 4
64 4
83 4
8
97 3
98 3
99 3
100 3
96 16
63 4
72 4
82 4
8
97 3
98 3
99 3
100 3
96 16
72 4
82 4
74 4
8
97 3
98 3
99 3
100 3
96 16
74 4
93 4
81 4
9
97 4
98 4
99 4
100 4
96 20
45 4
26 4
75 4
46 4
8
97 3
98 3
99 3
100 3
96 16
75 4
90 4
78 4
8
97 3
98 3
99 3
100 3
96 16
70 4
76 4
87 4
8
97 3
98 3
99 3
100 3
96 16
77 4
69 4
84 4
9
97 4
98 4
99 4
100 4
96 20
59 4
31 4
72 4
41 4
9
97 4
98 4
99 4
100 4
96 20
60 4
71 4
64 4
65 4
9
97 4
98 4
99 4
100 4
96 20
42 4
32 4
81 4
62 4
9
97 4
98 4
99 4
100 4
96 20
65 4
54 4
88 4
66 4
9
97 4
98 4
99 4
100 4
96 20
53 4
67 4
91 4
68 4
9
97 4
98 4
99 4
100 4
96 20
69 4
58 4
50 4
86 4
9
97 4
98 4
99 4
100 4
96 20
56 4
70 4
51 4
78 4
9
97 4
98 4
99 4
100 4
96 20
77 4
68 4
57 4
84 4
9
97 4
98 4
99 4
100 4
96 20
37 4
44 4
83 4
85 4
9
97 4
98 4
99 4
100 4
96 20
58 4
81 4
62 4
86 4
9
97 4
98 4
99 4
100 4
96 20
66 4
73 4
92 4
80 4
9
97 4
98 4
99 4
100 4
96 20
64 4
83 4
65 4
88 4
9
97 4
98 4
99 4
100 4
96 20
63 4
79 4
82 4
89 4
9
97 4
98 4
99 4
100 4
96 20
70 4
90 4
78 4
87 4
9
97 4
98 4
99 4
100 4
96 20
79 4
53 4
89 4
91 4
9
97 4
98 4
99 4
100 4
96 20
76 4
92 4
87 4
80 4
9
97 4
98 4
99 4
100 4
96 20
69 4
94 4
84 4
86 4
9
97 4
98 4
99 4
100 4
96 20
82 4
89 4
74 4
93 4
9
97 4
98 4
99 4
100 4
96 20
83 4
85 4
88 4
95 4
9
97 4
98 4
99 4
100 4
96 20
91 4
68 4
94 4
84 4
9
97 4
98 4
99 4
100 4
96 20
85 4
75 4
95 4
90 4
9
97 4
98 4
99 4
100 4
96 20
93 4
94 4
81 4
86 4
9
97 4
98 4
99 4
100 4
96 20
88 4
95 4
66 4
92 4
9
97 4
98 4
99 4
100 4
96 20
95 4
90 4
92 4
87 4
9
97 4
98 4
99 4
100 4
96 20
89 4
91 4
93 4
94 4
100
97 250
98 250
99 250
100 250
34 16
38 20
0 4
56 28
77 32
70 28
69 28
76 32
58 28
21 12
33 16
51 24
48 20
47 20
50 24
13 8
1 4
2 4
22 12
27 16
14 8
3 4
30 16
29 16
15 8
4 4
23 12
28 16
5 4
6 4
16 8
59 28
39 20
19 12
7 4
24 12
52 28
35 16
40 20
55 28
43 20
60 28
71 32
31 16
17 8
36 16
37 16
63 28
64 28
72 32
41 20
8 4
25 12
61 32
44 20
79 32
83 32
82 32
65 28
54 28
9 4
45 20
53 24
85 32
89 32
88 32
74 32
42 20
10 4
11 4
26 12
67 32
75 32
91 32
95 32
93 32
66 28
73 32
32 16
20 12
46 20
68 28
90 32
94 32
92 32
81 32
62 28
49 24
18 8
12 4
57 28
78 32
84 32
87 32
86 32
80 32
97
96 250
34 4
38 5
0 1
56 7
77 8
70 7
69 7
76 8
58 7
21 3
33 4
51 6
48 5
47 5
50 6
13 2
1 1
2 1
22 3
27 4
14 2
3 1
30 4
29 4
15 2
4 1
23 3
28 4
5 1
6 1
16 2
59 7
39 5
19 3
7 1
24 3
52 7
35 4
40 5
55 7
43 5
60 7
71 8
31 4
17 2
36 4
37 4
63 7
64 7
72 8
41 5
8 1
25 3
61 8
44 5
79 8
83 8
82 8
65 7
54 7
9 1
45 5
53 6
85 8
89 8
88 8
74 8
42 5
10 1
11 1
26 3
67 8
75 8
91 8
95 8
93 8
66 7
73 8
32 4
20 3
46 5
68 7
90 8
94 8
92 8
81 8
62 7
49 6
18 2
12 1
57 7
78 8
84 8
87 8
86 8
80 8
97
96 250
34 4
38 5
0 1
56 7
77 8
70 7
69 7
76 8
58 7
21 3
33 4
51 6
48 5
47 5
50 6
13 2
1 1
2 1
22 3
27 4
14 2
3 1
30 4
29 4
15 2
4 1
23 3
28 4
5 1
6 1
16 2
59 7
39 5
19 3
7 1
24 3
52 7
35 4
40 5
55 7
43 5
60 7
71 8
31 4
17 2
36 4
37 4
63 7
64 7
72 8
41 5
8 1
25 3
61 8
44 5
79 8
83 8
82 8
65 7
54 7
9 1
45 5
53 6
85 8
89 8
88 8
74 8
42 5
10 1
11 1
26 3
67 8
75 8
91 8
95 8
93 8
66 7
73 8
32 4
20 3
46 5
68 7
90 8
94 8
92 8
81 8
62 7
49 6
18 2
12 1
57 7
78 8
84 8
87 8
86 8
80 8
97
96 250
34 4
38 5
0 1
56 7
77 8
70 7
69 7
76 8
58 7
21 3
33 4
51 6
48 5
47 5
50 6
13 2
1 1
2 1
22 3
27 4
14 2
3 1
30 4
29 4
15 2
4 1
23 3
28 4
5 1
6 1
16 2
59 7
39 5
19 3
7 1
24 3
52 7
35 4
40 5
55 7
43 5
60 7
71 8
31 4
17 2
36 4
37 4
63 7
64 7
72 8
41 5
8 1
25 3
61 8
44 5
79 8
83 8
82 8
65 7
54 7
9 1
45 5
53 6
85 8
89 8
88 8
74 8
42 5
10 1
11 1
26 3
67 8
75 8
91 8
95 8
93 8
66 7
73 8
32 4
20 3
46 5
68 7
90 8
94 8
92 8
81 8
62 7
49 6
18 2
12 1
57 7
78 8
84 8
87 8
86 8
80 8
97
96 250
34 4
38 5
0 1
56 7
77 8
70 7
69 7
76 8
58 7
21 3
33 4
51 6
48 5
47 5
50 6
13 2
1 1
2 1
22 3
27 4
14 2
3 1
30 4
29 4
15 2
4 1
23 3
28 4
5 1
6 1
16 2
59 7
39 5
19 3
7 1
24 3
52 7
35 4
40 5
55 7
43 5
60 7
71 8
31 4
17 2
36 4
37 4
63 7
64 7
72 8
41 5
8 1
25 3
61 8
44 5
79 8
83 8
82 8
65 7
54 7
9 1
45 5
53 6
85 8
89 8
88 8
74 8
42 5
10 1
11 1
26 3
67 8
75 8
91 8
95 8
93 8
66 7
73 8
32 4
20 3
46 5
68 7
90 8
94 8
92 8
81 8
62 7
49 6
18 2
12 1
57 7
78 8
84 8
87 8
86 8
80 8
end_CG
