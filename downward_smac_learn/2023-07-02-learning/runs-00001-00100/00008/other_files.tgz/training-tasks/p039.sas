begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var3
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var2
-1
24
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
end_variable
begin_variable
var0
-1
24
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
end_variable
begin_variable
var1
-1
24
Atom at(box2, loc_2_6)
Atom at(box2, loc_2_7)
Atom at(box2, loc_3_6)
Atom at(box2, loc_3_7)
Atom at(box2, loc_3_8)
Atom at(box2, loc_4_4)
Atom at(box2, loc_4_5)
Atom at(box2, loc_4_6)
Atom at(box2, loc_4_7)
Atom at(box2, loc_5_3)
Atom at(box2, loc_5_4)
Atom at(box2, loc_5_5)
Atom at(box2, loc_5_6)
Atom at(box2, loc_5_7)
Atom at(box2, loc_6_4)
Atom at(box2, loc_6_5)
Atom at(box2, loc_6_6)
Atom at(box2, loc_6_7)
Atom at(box2, loc_7_3)
Atom at(box2, loc_7_4)
Atom at(box2, loc_7_5)
Atom at(box2, loc_7_6)
Atom at(box2, loc_8_5)
Atom at(box2, loc_8_6)
end_variable
24
begin_mutex_group
3
25 0
26 0
0 0
end_mutex_group
begin_mutex_group
3
25 1
26 1
1 0
end_mutex_group
begin_mutex_group
3
25 2
26 2
9 0
end_mutex_group
begin_mutex_group
3
25 3
26 3
15 0
end_mutex_group
begin_mutex_group
3
25 4
26 4
2 0
end_mutex_group
begin_mutex_group
3
25 5
26 5
7 0
end_mutex_group
begin_mutex_group
3
25 6
26 6
12 0
end_mutex_group
begin_mutex_group
3
25 7
26 7
19 0
end_mutex_group
begin_mutex_group
3
25 8
26 8
16 0
end_mutex_group
begin_mutex_group
3
25 9
26 9
3 0
end_mutex_group
begin_mutex_group
3
25 10
26 10
18 0
end_mutex_group
begin_mutex_group
3
25 11
26 11
23 0
end_mutex_group
begin_mutex_group
3
25 12
26 12
21 0
end_mutex_group
begin_mutex_group
3
25 13
26 13
13 0
end_mutex_group
begin_mutex_group
3
25 14
26 14
14 0
end_mutex_group
begin_mutex_group
3
25 15
26 15
22 0
end_mutex_group
begin_mutex_group
3
25 16
26 16
20 0
end_mutex_group
begin_mutex_group
3
25 17
26 17
8 0
end_mutex_group
begin_mutex_group
3
25 18
26 18
4 0
end_mutex_group
begin_mutex_group
3
25 19
26 19
10 0
end_mutex_group
begin_mutex_group
3
25 20
26 20
17 0
end_mutex_group
begin_mutex_group
3
25 21
26 21
11 0
end_mutex_group
begin_mutex_group
3
25 22
26 22
5 0
end_mutex_group
begin_mutex_group
3
25 23
26 23
6 0
end_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
26 6
19 0
10
13
1
18 0
10
82
2
25 10
14 0
10
83
2
26 10
14 0
7
5
14
1
7 0
7
15
1
19 0
7
84
2
25 7
16 0
7
85
2
26 7
16 0
11
16
1
23 0
11
86
2
25 11
22 0
11
87
2
26 11
22 0
10
2
17
1
9 0
2
88
2
25 2
0 0
2
89
2
26 2
0 0
6
18
1
12 0
6
90
2
25 6
7 0
6
91
2
26 6
7 0
8
19
1
16 0
12
20
1
21 0
12
92
2
25 12
20 0
12
93
2
26 12
20 0
9
3
21
1
15 0
3
94
2
25 3
1 0
3
95
2
26 3
1 0
7
22
1
19 0
7
96
2
25 7
12 0
7
97
2
26 7
12 0
13
23
1
13 0
13
98
2
25 13
8 0
13
99
2
26 13
8 0
3
10
24
1
18 0
10
100
2
25 10
23 0
10
101
2
26 10
23 0
8
5
25
1
7 0
9
26
1
3 0
11
27
1
23 0
11
102
2
25 11
21 0
11
103
2
26 11
21 0
14
28
1
14 0
14
104
2
25 14
10 0
14
105
2
26 14
10 0
10
6
29
1
12 0
10
30
1
18 0
10
106
2
25 10
3 0
10
107
2
26 10
3 0
12
31
1
21 0
12
108
2
25 12
13 0
12
109
2
26 12
13 0
15
32
1
22 0
15
110
2
25 15
17 0
15
111
2
26 15
17 0
10
7
33
1
19 0
7
112
2
25 7
9 0
7
113
2
26 7
9 0
11
34
1
23 0
11
114
2
25 11
18 0
11
115
2
26 11
18 0
13
35
1
13 0
16
36
1
20 0
16
116
2
25 16
11 0
16
117
2
26 16
11 0
7
8
37
1
16 0
8
118
2
25 8
15 0
8
119
2
26 8
15 0
12
38
1
21 0
12
120
2
25 12
23 0
12
121
2
26 12
23 0
17
39
1
8 0
7
10
40
1
18 0
10
122
2
25 10
7 0
10
123
2
26 10
7 0
15
41
1
22 0
15
124
2
25 15
20 0
15
125
2
26 15
20 0
19
42
1
10 0
10
11
43
1
23 0
11
126
2
25 11
12 0
11
127
2
26 11
12 0
14
44
1
14 0
16
45
1
20 0
16
128
2
25 16
8 0
16
129
2
26 16
8 0
20
46
1
17 0
20
130
2
25 20
5 0
20
131
2
26 20
5 0
10
12
47
1
21 0
12
132
2
25 12
19 0
12
133
2
26 12
19 0
15
48
1
22 0
15
134
2
25 15
14 0
15
135
2
26 15
14 0
17
49
1
8 0
21
50
1
11 0
21
136
2
25 21
6 0
21
137
2
26 21
6 0
6
13
51
1
13 0
13
138
2
25 13
16 0
13
139
2
26 13
16 0
16
52
1
20 0
16
140
2
25 16
22 0
16
141
2
26 16
22 0
3
19
53
1
10 0
19
142
2
25 19
17 0
19
143
2
26 19
17 0
7
14
54
1
14 0
14
144
2
25 14
18 0
14
145
2
26 14
18 0
18
55
1
4 0
20
56
1
17 0
20
146
2
25 20
11 0
20
147
2
26 20
11 0
8
15
57
1
22 0
15
148
2
25 15
23 0
15
149
2
26 15
23 0
19
58
1
10 0
19
150
2
25 19
4 0
19
151
2
26 19
4 0
21
59
1
11 0
22
60
1
5 0
7
16
61
1
20 0
16
152
2
25 16
21 0
16
153
2
26 16
21 0
20
62
1
17 0
20
154
2
25 20
10 0
20
155
2
26 20
10 0
23
63
1
6 0
4
20
64
1
17 0
20
156
2
25 20
22 0
20
157
2
26 20
22 0
23
65
1
6 0
4
21
66
1
11 0
21
158
2
25 21
20 0
21
159
2
26 21
20 0
22
67
1
5 0
end_DTG
begin_DTG
0
0
2
0
88
2
24 7
0 0
7
68
2
24 0
19 0
4
1
94
2
24 8
1 0
2
78
2
24 4
9 0
4
72
2
24 2
2 0
8
70
2
24 1
16 0
0
0
2
5
90
2
24 7
7 0
7
80
2
24 5
19 0
4
2
112
2
24 12
9 0
6
96
2
24 8
12 0
8
84
2
24 6
16 0
12
74
2
24 2
21 0
2
3
118
2
24 13
15 0
13
76
2
24 3
13 0
0
4
5
122
2
24 14
7 0
9
106
2
24 11
3 0
11
100
2
24 9
23 0
14
82
2
24 5
14 0
4
6
126
2
24 15
12 0
10
114
2
24 12
18 0
12
102
2
24 10
21 0
15
86
2
24 6
22 0
4
7
132
2
24 16
19 0
11
120
2
24 13
23 0
13
108
2
24 11
13 0
16
92
2
24 7
20 0
2
8
138
2
24 17
16 0
17
98
2
24 8
8 0
2
10
144
2
24 19
18 0
19
104
2
24 10
10 0
4
11
148
2
24 20
23 0
14
134
2
24 16
14 0
16
124
2
24 14
20 0
20
110
2
24 11
17 0
4
12
152
2
24 21
21 0
15
140
2
24 17
22 0
17
128
2
24 15
8 0
21
116
2
24 12
11 0
0
0
2
18
150
2
24 20
4 0
20
142
2
24 18
17 0
4
15
156
2
24 22
22 0
19
154
2
24 21
10 0
21
146
2
24 19
11 0
22
130
2
24 15
5 0
2
16
158
2
24 23
20 0
23
136
2
24 16
6 0
0
0
end_DTG
begin_DTG
0
0
2
0
89
2
24 7
0 0
7
69
2
24 0
19 0
4
1
95
2
24 8
1 0
2
79
2
24 4
9 0
4
73
2
24 2
2 0
8
71
2
24 1
16 0
0
0
2
5
91
2
24 7
7 0
7
81
2
24 5
19 0
4
2
113
2
24 12
9 0
6
97
2
24 8
12 0
8
85
2
24 6
16 0
12
75
2
24 2
21 0
2
3
119
2
24 13
15 0
13
77
2
24 3
13 0
0
4
5
123
2
24 14
7 0
9
107
2
24 11
3 0
11
101
2
24 9
23 0
14
83
2
24 5
14 0
4
6
127
2
24 15
12 0
10
115
2
24 12
18 0
12
103
2
24 10
21 0
15
87
2
24 6
22 0
4
7
133
2
24 16
19 0
11
121
2
24 13
23 0
13
109
2
24 11
13 0
16
93
2
24 7
20 0
2
8
139
2
24 17
16 0
17
99
2
24 8
8 0
2
10
145
2
24 19
18 0
19
105
2
24 10
10 0
4
11
149
2
24 20
23 0
14
135
2
24 16
14 0
16
125
2
24 14
20 0
20
111
2
24 11
17 0
4
12
153
2
24 21
21 0
15
141
2
24 17
22 0
17
129
2
24 15
8 0
21
117
2
24 12
11 0
0
0
2
18
151
2
24 20
4 0
20
143
2
24 18
17 0
4
15
157
2
24 22
22 0
19
155
2
24 21
10 0
21
147
2
24 19
11 0
22
131
2
24 15
5 0
2
16
159
2
24 23
20 0
23
137
2
24 16
6 0
0
0
end_DTG
begin_CG
4
25 1
26 1
24 4
9 2
4
25 1
26 1
24 4
15 2
4
25 1
26 1
24 3
15 2
4
25 1
26 1
24 3
18 2
4
25 1
26 1
24 3
10 2
4
25 1
26 1
24 4
17 2
4
25 1
26 1
24 4
11 2
5
25 2
26 2
24 6
12 2
18 2
5
25 2
26 2
24 6
13 2
20 2
5
25 2
26 2
24 7
15 2
19 2
5
25 2
26 2
24 7
14 2
17 2
5
25 2
26 2
24 7
20 2
17 2
5
25 2
26 2
24 7
19 2
23 2
5
25 2
26 2
24 7
16 2
21 2
5
25 2
26 2
24 7
18 2
22 2
4
25 1
26 1
24 6
16 2
6
25 3
26 3
24 9
15 2
19 2
13 2
5
25 2
26 2
24 8
22 2
10 2
5
25 2
26 2
24 8
23 2
14 2
6
25 3
26 3
24 10
9 2
12 2
21 2
6
25 3
26 3
24 10
21 2
22 2
11 2
6
25 3
26 3
24 10
19 2
23 2
20 2
6
25 3
26 3
24 10
23 2
20 2
17 2
6
25 3
26 3
24 10
18 2
21 2
22 2
26
25 46
26 46
0 2
1 2
9 8
15 10
2 2
7 4
12 8
19 14
16 10
3 2
18 12
23 14
21 14
13 8
14 8
22 14
20 14
8 4
4 2
10 8
17 12
11 8
5 2
6 2
25
24 46
0 1
1 1
9 4
15 5
2 1
7 2
12 4
19 7
16 5
3 1
18 6
23 7
21 7
13 4
14 4
22 7
20 7
8 2
4 1
10 4
17 6
11 4
5 1
6 1
25
24 46
0 1
1 1
9 4
15 5
2 1
7 2
12 4
19 7
16 5
3 1
18 6
23 7
21 7
13 4
14 4
22 7
20 7
8 2
4 1
10 4
17 6
11 4
5 1
6 1
end_CG
