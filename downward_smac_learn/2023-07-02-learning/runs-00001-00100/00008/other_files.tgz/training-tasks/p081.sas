begin_version
3
end_version
begin_metric
0
end_metric
92
begin_variable
var6
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var75
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var83
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var84
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var81
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var90
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var91
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var86
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var85
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var82
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var76
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var77




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




11
31 4
57 4
7
88 2
89 2
90 2
91 2
87 11
68 4
13 4
7
88 2
89 2
90 2
91 2
87 10
14 4
25 4
7
88 2
89 2
90 2
91 2
87 11
38 4
72 4
7
88 2
89 2
90 2
91 2
87 10
33 4
23 4
7
88 2
89 2
90 2
91 2
87 11
38 4
67 4
7
88 2
89 2
90 2
91 2
87 10
67 4
37 4
7
88 2
89 2
90 2
91 2
87 11
29 4
48 4
7
88 2
89 2
90 2
91 2
87 11
50 4
28 4
8
88 3
89 3
90 3
91 3
87 15
16 4
53 4
20 4
8
88 3
89 3
90 3
91 3
87 15
18 4
56 4
21 4
8
88 3
89 3
90 3
91 3
87 15
38 4
15 4
33 4
8
88 3
89 3
90 3
91 3
87 15
26 4
32 4
25 4
8
88 3
89 3
90 3
91 3
87 15
17 4
36 4
55 4
8
88 3
89 3
90 3
91 3
87 15
36 4
19 4
62 4
8
88 3
89 3
90 3
91 3
87 15
34 4
35 4
61 4
8
88 3
89 3
90 3
91 3
87 15
13 4
48 4
27 4
6
88 1
89 1
90 1
91 1
87 8
71 4
8
88 3
89 3
90 3
91 3
87 15
51 4
63 4
49 4
8
88 3
89 3
90 3
91 3
87 15
58 4
45 4
72 4
8
88 3
89 3
90 3
91 3
87 15
46 4
52 4
60 4
8
88 3
89 3
90 3
91 3
87 15
64 4
75 4
68 4
8
88 3
89 3
90 3
91 3
87 15
75 4
65 4
44 4
8
88 3
89 3
90 3
91 3
87 15
43 4
66 4
67 4
7
88 2
89 2
90 2
91 2
87 12
49 4
40 4
7
88 2
89 2
90 2
91 2
87 12
41 4
53 4
7
88 2
89 2
90 2
91 2
87 12
55 4
56 4
8
88 3
89 3
90 3
91 3
87 16
12 4
28 4
37 4
8
88 3
89 3
90 3
91 3
87 16
39 4
58 4
45 4
8
88 3
89 3
90 3
91 3
87 16
54 4
68 4
29 4
8
88 3
89 3
90 3
91 3
87 16
57 4
77 4
39 4
8
88 3
89 3
90 3
91 3
87 16
59 4
41 4
70 4
8
88 3
89 3
90 3
91 3
87 16
46 4
60 4
54 4
8
88 3
89 3
90 3
91 3
87 16
53 4
69 4
50 4
8
88 3
89 3
90 3
91 3
87 16
47 4
61 4
76 4
8
88 3
89 3
90 3
91 3
87 16
47 4
76 4
57 4
8
88 3
89 3
90 3
91 3
87 16
56 4
78 4
51 4
8
88 3
89 3
90 3
91 3
87 16
63 4
49 4
73 4
8
88 3
89 3
90 3
91 3
87 16
62 4
52 4
79 4
8
88 3
89 3
90 3
91 3
87 16
53 4
70 4
69 4
8
88 3
89 3
90 3
91 3
87 16
55 4
62 4
83 4
8
88 3
89 3
90 3
91 3
87 16
61 4
59 4
84 4
8
88 3
89 3
90 3
91 3
87 16
77 4
74 4
58 4
8
88 3
89 3
90 3
91 3
87 16
70 4
80 4
69 4
8
88 3
89 3
90 3
91 3
87 16
81 4
74 4
66 4
8
88 3
89 3
90 3
91 3
87 16
65 4
73 4
71 4
9
88 4
89 4
90 4
91 4
87 20
26 4
44 4
71 4
27 4
9
88 4
89 4
90 4
91 4
87 20
69 4
50 4
42 4
22 4
9
88 4
89 4
90 4
91 4
87 20
60 4
54 4
64 4
68 4
9
88 4
89 4
90 4
91 4
87 20
52 4
79 4
60 4
64 4
9
88 4
89 4
90 4
91 4
87 20
38 4
66 4
72 4
67 4
9
88 4
89 4
90 4
91 4
87 20
24 4
73 4
40 4
71 4
9
88 4
89 4
90 4
91 4
87 20
74 4
58 4
66 4
72 4
9
88 4
89 4
90 4
91 4
87 20
82 4
63 4
65 4
73 4
9
88 4
89 4
90 4
91 4
87 20
80 4
81 4
42 4
43 4
9
88 4
89 4
90 4
91 4
87 20
55 4
56 4
83 4
78 4
9
88 4
89 4
90 4
91 4
87 20
78 4
51 4
82 4
63 4
9
88 4
89 4
90 4
91 4
87 20
76 4
57 4
85 4
77 4
9
88 4
89 4
90 4
91 4
87 20
59 4
84 4
70 4
80 4
9
88 4
89 4
90 4
91 4
87 20
79 4
86 4
64 4
75 4
9
88 4
89 4
90 4
91 4
87 20
86 4
82 4
75 4
65 4
9
88 4
89 4
90 4
91 4
87 20
85 4
77 4
81 4
74 4
9
88 4
89 4
90 4
91 4
87 20
61 4
76 4
84 4
85 4
9
88 4
89 4
90 4
91 4
87 20
62 4
83 4
79 4
86 4
9
88 4
89 4
90 4
91 4
87 20
83 4
78 4
86 4
82 4
9
88 4
89 4
90 4
91 4
87 20
84 4
85 4
80 4
81 4
91
88 236
89 236
90 236
91 236
12 12
0 4
24 16
38 20
26 16
14 16
1 4
2 4
15 16
32 20
33 20
25 16
23 16
3 4
4 4
8 8
17 16
34 20
36 20
35 20
19 16
9 8
46 24
16 16
18 16
47 24
55 28
61 28
62 28
59 28
52 28
41 20
53 28
30 20
31 20
56 28
76 32
83 32
84 32
79 32
70 32
60 28
54 28
20 16
21 16
57 28
78 32
85 32
86 32
80 32
64 28
69 32
50 28
10 8
11 8
51 28
77 32
82 32
81 32
75 32
42 20
68 32
29 16
39 20
63 28
74 32
65 28
43 20
22 16
28 16
5 4
49 28
58 28
73 32
66 28
44 20
13 12
48 28
6 4
7 4
45 24
40 20
72 32
71 32
67 32
27 16
37 20
88
87 236
12 3
0 1
24 4
38 5
26 4
14 4
1 1
2 1
15 4
32 5
33 5
25 4
23 4
3 1
4 1
8 2
17 4
34 5
36 5
35 5
19 4
9 2
46 6
16 4
18 4
47 6
55 7
61 7
62 7
59 7
52 7
41 5
53 7
30 5
31 5
56 7
76 8
83 8
84 8
79 8
70 8
60 7
54 7
20 4
21 4
57 7
78 8
85 8
86 8
80 8
64 7
69 8
50 7
10 2
11 2
51 7
77 8
82 8
81 8
75 8
42 5
68 8
29 4
39 5
63 7
74 8
65 7
43 5
22 4
28 4
5 1
49 7
58 7
73 8
66 7
44 5
13 3
48 7
6 1
7 1
45 6
40 5
72 8
71 8
67 8
27 4
37 5
88
87 236
12 3
0 1
24 4
38 5
26 4
14 4
1 1
2 1
15 4
32 5
33 5
25 4
23 4
3 1
4 1
8 2
17 4
34 5
36 5
35 5
19 4
9 2
46 6
16 4
18 4
47 6
55 7
61 7
62 7
59 7
52 7
41 5
53 7
30 5
31 5
56 7
76 8
83 8
84 8
79 8
70 8
60 7
54 7
20 4
21 4
57 7
78 8
85 8
86 8
80 8
64 7
69 8
50 7
10 2
11 2
51 7
77 8
82 8
81 8
75 8
42 5
68 8
29 4
39 5
63 7
74 8
65 7
43 5
22 4
28 4
5 1
49 7
58 7
73 8
66 7
44 5
13 3
48 7
6 1
7 1
45 6
40 5
72 8
71 8
67 8
27 4
37 5
88
87 236
12 3
0 1
24 4
38 5
26 4
14 4
1 1
2 1
15 4
32 5
33 5
25 4
23 4
3 1
4 1
8 2
17 4
34 5
36 5
35 5
19 4
9 2
46 6
16 4
18 4
47 6
55 7
61 7
62 7
59 7
52 7
41 5
53 7
30 5
31 5
56 7
76 8
83 8
84 8
79 8
70 8
60 7
54 7
20 4
21 4
57 7
78 8
85 8
86 8
80 8
64 7
69 8
50 7
10 2
11 2
51 7
77 8
82 8
81 8
75 8
42 5
68 8
29 4
39 5
63 7
74 8
65 7
43 5
22 4
28 4
5 1
49 7
58 7
73 8
66 7
44 5
13 3
48 7
6 1
7 1
45 6
40 5
72 8
71 8
67 8
27 4
37 5
88
87 236
12 3
0 1
24 4
38 5
26 4
14 4
1 1
2 1
15 4
32 5
33 5
25 4
23 4
3 1
4 1
8 2
17 4
34 5
36 5
35 5
19 4
9 2
46 6
16 4
18 4
47 6
55 7
61 7
62 7
59 7
52 7
41 5
53 7
30 5
31 5
56 7
76 8
83 8
84 8
79 8
70 8
60 7
54 7
20 4
21 4
57 7
78 8
85 8
86 8
80 8
64 7
69 8
50 7
10 2
11 2
51 7
77 8
82 8
81 8
75 8
42 5
68 8
29 4
39 5
63 7
74 8
65 7
43 5
22 4
28 4
5 1
49 7
58 7
73 8
66 7
44 5
13 3
48 7
6 1
7 1
45 6
40 5
72 8
71 8
67 8
27 4
37 5
end_CG
