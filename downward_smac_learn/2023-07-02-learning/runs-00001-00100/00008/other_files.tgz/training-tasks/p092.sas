begin_version
3
end_version
begin_metric
0
end_metric
81
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_2)
NegatedAtom clear(loc_11_2)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_12)
NegatedAtom clear(loc_2_12)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_5_12)
NegatedAtom clear(loc_5_12)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var77
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var78
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var45
-1
2





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




76 71
54 0
66
249
2
76 1
67 0
2
4
853
2
76 74
57 0
69
277
2
76 4
73 0
4
5
869
2
76 75
40 0
70
289
2
76 5
75 0
73
917
2
76 80
48 0
75
901
2
76 78
14 0
0
end_DTG
begin_CG
6
77 1
78 1
79 1
80 1
76 6
54 4
6
77 1
78 1
79 1
80 1
76 5
15 4
6
77 1
78 1
79 1
80 1
76 5
55 4
6
77 1
78 1
79 1
80 1
76 5
20 4
6
77 1
78 1
79 1
80 1
76 6
21 4
6
77 1
78 1
79 1
80 1
76 6
16 4
6
77 1
78 1
79 1
80 1
76 6
22 4
6
77 1
78 1
79 1
80 1
76 6
53 4
6
77 1
78 1
79 1
80 1
76 5
56 4
6
77 1
78 1
79 1
80 1
76 5
23 4
7
77 2
78 2
79 2
80 2
76 10
24 4
25 4
7
77 2
78 2
79 2
80 2
76 10
17 4
63 4
7
77 2
78 2
79 2
80 2
76 10
53 4
60 4
7
77 2
78 2
79 2
80 2
76 10
26 4
27 4
7
77 2
78 2
79 2
80 2
76 10
65 4
59 4
6
77 1
78 1
79 1
80 1
76 7
39 4
6
77 1
78 1
79 1
80 1
76 6
62 4
6
77 1
78 1
79 1
80 1
76 7
42 4
6
77 1
78 1
79 1
80 1
76 7
56 4
6
77 1
78 1
79 1
80 1
76 7
28 4
7
77 2
78 2
79 2
80 2
76 11
40 4
29 4
7
77 2
78 2
79 2
80 2
76 11
30 4
19 4
7
77 2
78 2
79 2
80 2
76 11
41 4
31 4
7
77 2
78 2
79 2
80 2
76 11
18 4
67 4
7
77 2
78 2
79 2
80 2
76 11
38 4
42 4
7
77 2
78 2
79 2
80 2
76 11
42 4
69 4
7
77 2
78 2
79 2
80 2
76 11
43 4
61 4
7
77 2
78 2
79 2
80 2
76 11
61 4
65 4
7
77 2
78 2
79 2
80 2
76 11
19 4
53 4
7
77 2
78 2
79 2
80 2
76 11
57 4
32 4
7
77 2
78 2
79 2
80 2
76 10
21 4
38 4
7
77 2
78 2
79 2
80 2
76 11
58 4
56 4
7
77 2
78 2
79 2
80 2
76 11
55 4
29 4
7
77 2
78 2
79 2
80 2
76 11
44 4
57 4
7
77 2
78 2
79 2
80 2
76 11
45 4
71 4
7
77 2
78 2
79 2
80 2
76 11
46 4
67 4
7
77 2
78 2
79 2
80 2
76 10
67 4
47 4
7
77 2
78 2
79 2
80 2
76 10
54 4
67 4
8
77 3
78 3
79 3
80 3
76 15
30 4
24 4
17 4
8
77 3
78 3
79 3
80 3
76 15
54 4
15 4
55 4
8
77 3
78 3
79 3
80 3
76 15
57 4
20 4
59 4
8
77 3
78 3
79 3
80 3
76 15
22 4
62 4
58 4
6
77 1
78 1
79 1
80 1
76 8
63 4
8
77 3
78 3
79 3
80 3
76 15
53 4
60 4
26 4
8
77 3
78 3
79 3
80 3
76 15
54 4
33 4
55 4
8
77 3
78 3
79 3
80 3
76 15
64 4
70 4
34 4
8
77 3
78 3
79 3
80 3
76 15
58 4
56 4
35 4
8
77 3
78 3
79 3
80 3
76 15
34 4
36 4
73 4
8
77 3
78 3
79 3
80 3
76 15
57 4
73 4
59 4
8
77 3
78 3
79 3
80 3
76 15
63 4
68 4
72 4
8
77 3
78 3
79 3
80 3
76 15
60 4
72 4
66 4
8
77 3
78 3
79 3
80 3
76 15
62 4
69 4
64 4
8
77 3
78 3
79 3
80 3
76 15
62 4
58 4
64 4
7
77 2
78 2
79 2
80 2
76 12
28 4
43 4
7
77 2
78 2
79 2
80 2
76 12
44 4
37 4
7
77 2
78 2
79 2
80 2
76 12
39 4
32 4
7
77 2
78 2
79 2
80 2
76 12
31 4
18 4
7
77 2
78 2
79 2
80 2
76 12
33 4
48 4
7
77 2
78 2
79 2
80 2
76 12
52 4
46 4
7
77 2
78 2
79 2
80 2
76 12
40 4
75 4
7
77 2
78 2
79 2
80 2
76 12
50 4
61 4
7
77 2
78 2
79 2
80 2
76 12
60 4
66 4
8
77 3
78 3
79 3
80 3
76 16
16 4
41 4
51 4
8
77 3
78 3
79 3
80 3
76 16
42 4
69 4
49 4
8
77 3
78 3
79 3
80 3
76 16
52 4
68 4
45 4
8
77 3
78 3
79 3
80 3
76 16
66 4
27 4
75 4
8
77 3
78 3
79 3
80 3
76 16
61 4
74 4
65 4
9
77 4
78 4
79 4
80 4
76 20
35 4
23 4
36 4
37 4
8
77 3
78 3
79 3
80 3
76 16
69 4
64 4
70 4
9
77 4
78 4
79 4
80 4
76 20
25 4
51 4
63 4
68 4
8
77 3
78 3
79 3
80 3
76 16
68 4
72 4
71 4
8
77 3
78 3
79 3
80 3
76 16
70 4
74 4
73 4
9
77 4
78 4
79 4
80 4
76 20
49 4
70 4
50 4
74 4
9
77 4
78 4
79 4
80 4
76 20
71 4
47 4
75 4
48 4
9
77 4
78 4
79 4
80 4
76 20
72 4
71 4
66 4
75 4
9
77 4
78 4
79 4
80 4
76 20
74 4
73 4
65 4
59 4
80
77 170
78 170
79 170
80 170
0 4
54 24
44 20
33 16
57 24
40 20
1 4
15 12
39 20
55 24
32 16
29 16
20 16
2 4
3 4
30 16
21 16
4 4
5 4
10 8
24 16
38 20
19 12
16 12
25 16
42 20
17 12
28 16
6 4
22 16
41 20
62 28
51 20
69 32
63 28
11 8
12 8
53 24
7 4
31 16
58 24
52 20
64 28
68 28
49 20
60 24
43 20
8 4
56 24
46 20
45 20
70 28
72 32
50 20
61 24
26 16
18 12
35 16
34 16
71 28
74 32
66 28
27 16
13 8
9 4
23 16
67 32
36 16
47 20
73 32
75 32
65 28
37 16
48 20
59 24
14 8
77
76 170
0 1
54 6
44 5
33 4
57 6
40 5
1 1
15 3
39 5
55 6
32 4
29 4
20 4
2 1
3 1
30 4
21 4
4 1
5 1
10 2
24 4
38 5
19 3
16 3
25 4
42 5
17 3
28 4
6 1
22 4
41 5
62 7
51 5
69 8
63 7
11 2
12 2
53 6
7 1
31 4
58 6
52 5
64 7
68 7
49 5
60 6
43 5
8 1
56 6
46 5
45 5
70 7
72 8
50 5
61 6
26 4
18 3
35 4
34 4
71 7
74 8
66 7
27 4
13 2
9 1
23 4
67 8
36 4
47 5
73 8
75 8
65 7
37 4
48 5
59 6
14 2
77
76 170
0 1
54 6
44 5
33 4
57 6
40 5
1 1
15 3
39 5
55 6
32 4
29 4
20 4
2 1
3 1
30 4
21 4
4 1
5 1
10 2
24 4
38 5
19 3
16 3
25 4
42 5
17 3
28 4
6 1
22 4
41 5
62 7
51 5
69 8
63 7
11 2
12 2
53 6
7 1
31 4
58 6
52 5
64 7
68 7
49 5
60 6
43 5
8 1
56 6
46 5
45 5
70 7
72 8
50 5
61 6
26 4
18 3
35 4
34 4
71 7
74 8
66 7
27 4
13 2
9 1
23 4
67 8
36 4
47 5
73 8
75 8
65 7
37 4
48 5
59 6
14 2
77
76 170
0 1
54 6
44 5
33 4
57 6
40 5
1 1
15 3
39 5
55 6
32 4
29 4
20 4
2 1
3 1
30 4
21 4
4 1
5 1
10 2
24 4
38 5
19 3
16 3
25 4
42 5
17 3
28 4
6 1
22 4
41 5
62 7
51 5
69 8
63 7
11 2
12 2
53 6
7 1
31 4
58 6
52 5
64 7
68 7
49 5
60 6
43 5
8 1
56 6
46 5
45 5
70 7
72 8
50 5
61 6
26 4
18 3
35 4
34 4
71 7
74 8
66 7
27 4
13 2
9 1
23 4
67 8
36 4
47 5
73 8
75 8
65 7
37 4
48 5
59 6
14 2
77
76 170
0 1
54 6
44 5
33 4
57 6
40 5
1 1
15 3
39 5
55 6
32 4
29 4
20 4
2 1
3 1
30 4
21 4
4 1
5 1
10 2
24 4
38 5
19 3
16 3
25 4
42 5
17 3
28 4
6 1
22 4
41 5
62 7
51 5
69 8
63 7
11 2
12 2
53 6
7 1
31 4
58 6
52 5
64 7
68 7
49 5
60 6
43 5
8 1
56 6
46 5
45 5
70 7
72 8
50 5
61 6
26 4
18 3
35 4
34 4
71 7
74 8
66 7
27 4
13 2
9 1
23 4
67 8
36 4
47 5
73 8
75 8
65 7
37 4
48 5
59 6
14 2
end_CG
