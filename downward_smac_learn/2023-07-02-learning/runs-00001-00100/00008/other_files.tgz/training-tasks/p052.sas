begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var11
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var2
-1
51
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





46 0
31
298
2
49 35
42 0
33
286
2
49 33
47 0
39
252
2
49 26
33 0
4
25
330
2
49 42
48 0
32
304
2
49 36
43 0
34
294
2
49 34
39 0
40
260
2
49 27
41 0
4
26
336
2
49 43
30 0
33
308
2
49 37
47 0
35
300
2
49 35
25 0
41
266
2
49 28
38 0
2
27
340
2
49 44
21 0
42
270
2
49 29
24 0
2
29
344
2
49 45
9 0
43
278
2
49 31
2 0
2
36
320
2
49 40
13 0
38
312
2
49 38
40 0
4
31
346
2
49 46
42 0
37
326
2
49 41
22 0
39
316
2
49 39
33 0
44
288
2
49 33
3 0
2
38
332
2
49 42
40 0
40
322
2
49 40
41 0
4
33
348
2
49 47
47 0
39
338
2
49 43
33 0
41
328
2
49 41
38 0
45
302
2
49 35
10 0
4
34
352
2
49 48
39 0
40
342
2
49 44
41 0
42
334
2
49 42
24 0
46
306
2
49 36
18 0
2
35
356
2
49 49
25 0
47
310
2
49 37
17 0
0
0
0
2
45
358
2
49 49
10 0
47
350
2
49 47
17 0
2
46
360
2
49 50
18 0
48
354
2
49 48
4 0
0
end_DTG
begin_DTG
0
2
0
157
2
49 2
5 0
2
151
2
49 0
6 0
0
0
2
3
169
2
49 6
7 0
5
161
2
49 4
36 0
4
0
189
2
49 13
5 0
4
173
2
49 7
20 0
6
165
2
49 5
37 0
11
153
2
49 0
32 0
4
1
195
2
49 14
11 0
5
177
2
49 8
36 0
7
171
2
49 6
19 0
12
155
2
49 1
45 0
2
2
203
2
49 15
6 0
13
159
2
49 2
44 0
0
2
3
221
2
49 19
7 0
17
163
2
49 4
1 0
4
4
223
2
49 20
20 0
9
191
2
49 13
12 0
11
183
2
49 11
32 0
18
167
2
49 5
29 0
2
10
197
2
49 14
34 0
12
185
2
49 12
45 0
4
6
227
2
49 21
37 0
11
205
2
49 15
32 0
13
193
2
49 13
44 0
19
175
2
49 7
27 0
4
7
231
2
49 22
19 0
12
211
2
49 16
45 0
14
199
2
49 14
23 0
20
179
2
49 8
26 0
2
13
215
2
49 17
44 0
15
207
2
49 15
15 0
2
14
217
2
49 18
23 0
16
213
2
49 16
16 0
2
8
235
2
49 23
0 0
21
181
2
49 10
14 0
0
2
10
237
2
49 24
34 0
22
187
2
49 12
31 0
2
12
247
2
49 26
45 0
24
201
2
49 14
46 0
2
13
255
2
49 27
44 0
25
209
2
49 15
48 0
2
16
273
2
49 30
16 0
28
219
2
49 18
8 0
2
18
281
2
49 32
29 0
30
225
2
49 20
35 0
2
22
249
2
49 26
31 0
24
239
2
49 24
46 0
4
19
291
2
49 34
27 0
23
257
2
49 27
28 0
25
243
2
49 25
48 0
32
229
2
49 21
43 0
4
20
297
2
49 35
26 0
24
263
2
49 28
46 0
26
251
2
49 26
30 0
33
233
2
49 22
47 0
2
25
269
2
49 29
48 0
27
259
2
49 27
21 0
2
26
275
2
49 30
30 0
28
265
2
49 28
8 0
0
0
4
22
315
2
49 39
31 0
29
285
2
49 33
9 0
31
277
2
49 31
42 0
37
241
2
49 24
22 0
4
23
319
2
49 40
28 0
30
293
2
49 34
35 0
32
283
2
49 32
43 0
38
245
2
49 25
40 0
4
24
325
2
49 41
46 0
31
299
2
49 35
42 0
33
287
2
49 33
47 0
39
253
2
49 26
33 0
4
25
331
2
49 42
48 0
32
305
2
49 36
43 0
34
295
2
49 34
39 0
40
261
2
49 27
41 0
4
26
337
2
49 43
30 0
33
309
2
49 37
47 0
35
301
2
49 35
25 0
41
267
2
49 28
38 0
2
27
341
2
49 44
21 0
42
271
2
49 29
24 0
2
29
345
2
49 45
9 0
43
279
2
49 31
2 0
2
36
321
2
49 40
13 0
38
313
2
49 38
40 0
4
31
347
2
49 46
42 0
37
327
2
49 41
22 0
39
317
2
49 39
33 0
44
289
2
49 33
3 0
2
38
333
2
49 42
40 0
40
323
2
49 40
41 0
4
33
349
2
49 47
47 0
39
339
2
49 43
33 0
41
329
2
49 41
38 0
45
303
2
49 35
10 0
4
34
353
2
49 48
39 0
40
343
2
49 44
41 0
42
335
2
49 42
24 0
46
307
2
49 36
18 0
2
35
357
2
49 49
25 0
47
311
2
49 37
17 0
0
0
0
2
45
359
2
49 49
10 0
47
351
2
49 47
17 0
2
46
361
2
49 50
18 0
48
355
2
49 48
4 0
0
end_DTG
begin_CG
4
50 1
51 1
49 4
16 2
4
50 1
51 1
49 4
12 2
4
50 1
51 1
49 3
13 2
4
50 1
51 1
49 3
40 2
4
50 1
51 1
49 3
17 2
5
50 2
51 2
49 6
11 2
36 2
5
50 2
51 2
49 6
11 2
19 2
5
50 2
51 2
49 6
20 2
12 2
5
50 2
51 2
49 6
14 2
21 2
5
50 2
51 2
49 6
35 2
13 2
5
50 2
51 2
49 6
41 2
18 2
4
50 1
51 1
49 5
37 2
4
50 1
51 1
49 5
34 2
4
50 1
51 1
49 5
22 2
4
50 1
51 1
49 4
16 2
4
50 1
51 1
49 5
23 2
5
50 2
51 2
49 7
15 2
14 2
5
50 2
51 2
49 7
24 2
18 2
5
50 2
51 2
49 7
38 2
17 2
5
50 2
51 2
49 7
37 2
44 2
5
50 2
51 2
49 7
36 2
34 2
5
50 2
51 2
49 7
30 2
25 2
5
50 2
51 2
49 7
35 2
40 2
5
50 2
51 2
49 6
44 2
15 2
5
50 2
51 2
49 7
25 2
38 2
5
50 2
51 2
49 7
39 2
24 2
5
50 2
51 2
49 7
44 2
48 2
5
50 2
51 2
49 7
45 2
46 2
5
50 2
51 2
49 7
46 2
42 2
5
50 2
51 2
49 7
34 2
31 2
6
50 3
51 3
49 9
48 2
21 2
39 2
6
50 3
51 3
49 9
29 2
28 2
35 2
6
50 3
51 3
49 9
36 2
34 2
45 2
6
50 3
51 3
49 9
43 2
40 2
41 2
5
50 2
51 2
49 8
32 2
29 2
5
50 2
51 2
49 8
31 2
42 2
5
50 2
51 2
49 8
20 2
37 2
5
50 2
51 2
49 8
36 2
45 2
5
50 2
51 2
49 8
39 2
41 2
5
50 2
51 2
49 8
47 2
38 2
6
50 3
51 3
49 10
42 2
22 2
33 2
6
50 3
51 3
49 10
47 2
33 2
38 2
6
50 3
51 3
49 10
35 2
43 2
40 2
6
50 3
51 3
49 10
46 2
42 2
47 2
7
50 4
51 4
49 12
19 2
45 2
23 2
26 2
7
50 4
51 4
49 12
37 2
32 2
44 2
27 2
7
50 4
51 4
49 12
27 2
28 2
48 2
43 2
7
50 4
51 4
49 12
48 2
43 2
39 2
41 2
7
50 4
51 4
49 12
26 2
46 2
30 2
47 2
51
50 106
51 106
5 4
11 6
6 4
7 4
20 8
36 12
37 12
19 8
0 2
12 6
34 12
32 10
45 16
44 16
23 8
15 6
16 8
1 2
29 8
27 8
26 8
14 6
31 10
28 8
46 16
48 16
30 10
21 8
8 4
9 4
35 12
42 14
43 14
47 16
39 12
25 8
13 6
22 8
40 14
33 10
41 14
38 12
24 8
2 2
3 2
10 4
18 8
17 8
4 2
50
49 106
5 2
11 3
6 2
7 2
20 4
36 6
37 6
19 4
0 1
12 3
34 6
32 5
45 8
44 8
23 4
15 3
16 4
1 1
29 4
27 4
26 4
14 3
31 5
28 4
46 8
48 8
30 5
21 4
8 2
9 2
35 6
42 7
43 7
47 8
39 6
25 4
13 3
22 4
40 7
33 5
41 7
38 6
24 4
2 1
3 1
10 2
18 4
17 4
4 1
50
49 106
5 2
11 3
6 2
7 2
20 4
36 6
37 6
19 4
0 1
12 3
34 6
32 5
45 8
44 8
23 4
15 3
16 4
1 1
29 4
27 4
26 4
14 3
31 5
28 4
46 8
48 8
30 5
21 4
8 2
9 2
35 6
42 7
43 7
47 8
39 6
25 4
13 3
22 4
40 7
33 5
41 7
38 6
24 4
2 1
3 1
10 2
18 4
17 4
4 1
end_CG
