begin_version
3
end_version
begin_metric
0
end_metric
103
begin_variable
var7
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_12)
NegatedAtom clear(loc_11_12)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_2)
NegatedAtom clear(loc_11_2)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_12_12)
NegatedAtom clear(loc_12_12)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_3_12)
NegatedAtom clear(loc_3_12)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_5_12)
NegatedAtom clear(loc_5_12)
end_variable
begin_variable
var85
-1
2
Atom clear(loc_8_12)
NegatedAtom clear(loc_8_12)
end_variable
begin_variable
var95
-1
2
Atom clear(loc_9_12)
NegatedAtom clear(loc_9_12)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_12_4)
NegatedAtom clear(loc_12_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var86
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_12_11)
NegatedAtom clear(loc_12_11)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var96
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var79
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_12_6)
NegatedAtom clear(loc_12_6)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_12_9)
NegatedAtom clear(loc_12_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var78
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var81
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var90
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var88
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var87
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_varia




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1 3
102 3
98 15
55 4
68 4
86 4
8
99 3
100 3
101 3
102 3
98 15
88 4
77 4
90 4
8
99 3
100 3
101 3
102 3
98 15
79 4
90 4
78 4
8
99 3
100 3
101 3
102 3
98 15
56 4
79 4
71 4
7
99 2
100 2
101 2
102 2
98 12
80 4
22 4
7
99 2
100 2
101 2
102 2
98 12
40 4
63 4
7
99 2
100 2
101 2
102 2
98 12
54 4
64 4
7
99 2
100 2
101 2
102 2
98 12
54 4
64 4
8
99 3
100 3
101 3
102 3
98 16
23 4
81 4
41 4
8
99 3
100 3
101 3
102 3
98 16
54 4
24 4
43 4
8
99 3
100 3
101 3
102 3
98 16
50 4
53 4
51 4
8
99 3
100 3
101 3
102 3
98 16
24 4
59 4
44 4
8
99 3
100 3
101 3
102 3
98 16
28 4
47 4
65 4
8
99 3
100 3
101 3
102 3
98 16
80 4
16 4
66 4
8
99 3
100 3
101 3
102 3
98 16
18 4
59 4
67 4
8
99 3
100 3
101 3
102 3
98 16
58 4
55 4
68 4
8
99 3
100 3
101 3
102 3
98 16
40 4
61 4
91 4
8
99 3
100 3
101 3
102 3
98 16
42 4
92 4
60 4
9
99 4
100 4
101 4
102 4
98 20
43 4
25 4
26 4
35 4
8
99 3
100 3
101 3
102 3
98 16
69 4
49 4
70 4
9
99 4
100 4
101 4
102 4
98 20
50 4
14 4
51 4
36 4
8
99 3
100 3
101 3
102 3
98 16
80 4
56 4
71 4
8
99 3
100 3
101 3
102 3
98 16
83 4
57 4
72 4
8
99 3
100 3
101 3
102 3
98 16
58 4
68 4
81 4
8
99 3
100 3
101 3
102 3
98 16
59 4
67 4
87 4
8
99 3
100 3
101 3
102 3
98 16
94 4
63 4
91 4
8
99 3
100 3
101 3
102 3
98 16
94 4
63 4
73 4
8
99 3
100 3
101 3
102 3
98 16
83 4
65 4
82 4
8
99 3
100 3
101 3
102 3
98 16
84 4
66 4
74 4
8
99 3
100 3
101 3
102 3
98 16
95 4
74 4
70 4
8
99 3
100 3
101 3
102 3
98 16
85 4
72 4
73 4
8
99 3
100 3
101 3
102 3
98 16
81 4
89 4
76 4
8
99 3
100 3
101 3
102 3
98 16
75 4
77 4
92 4
8
99 3
100 3
101 3
102 3
98 16
89 4
76 4
93 4
8
99 3
100 3
101 3
102 3
98 16
85 4
82 4
97 4
9
99 4
100 4
101 4
102 4
98 20
27 4
47 4
46 4
82 4
9
99 4
100 4
101 4
102 4
98 20
48 4
83 4
57 4
65 4
9
99 4
100 4
101 4
102 4
98 20
67 4
52 4
87 4
75 4
9
99 4
100 4
101 4
102 4
98 20
84 4
79 4
71 4
78 4
9
99 4
100 4
101 4
102 4
98 20
80 4
84 4
66 4
71 4
9
99 4
100 4
101 4
102 4
98 20
83 4
85 4
72 4
82 4
9
99 4
100 4
101 4
102 4
98 20
84 4
95 4
74 4
78 4
9
99 4
100 4
101 4
102 4
98 20
44 4
26 4
87 4
88 4
9
99 4
100 4
101 4
102 4
98 20
68 4
81 4
86 4
89 4
9
99 4
100 4
101 4
102 4
98 20
86 4
15 4
89 4
45 4
9
99 4
100 4
101 4
102 4
98 20
87 4
75 4
88 4
77 4
9
99 4
100 4
101 4
102 4
98 20
45 4
46 4
93 4
97 4
9
99 4
100 4
101 4
102 4
98 20
69 4
92 4
60 4
96 4
9
99 4
100 4
101 4
102 4
98 20
76 4
61 4
93 4
91 4
9
99 4
100 4
101 4
102 4
98 20
77 4
92 4
90 4
96 4
9
99 4
100 4
101 4
102 4
98 20
69 4
95 4
70 4
96 4
9
99 4
100 4
101 4
102 4
98 20
85 4
94 4
73 4
97 4
9
99 4
100 4
101 4
102 4
98 20
94 4
93 4
91 4
97 4
9
99 4
100 4
101 4
102 4
98 20
95 4
90 4
78 4
96 4
102
99 268
100 268
101 268
102 268
69 28
40 20
0 4
48 24
80 32
83 32
84 32
85 32
95 32
94 32
63 28
49 24
1 4
2 4
16 16
57 28
66 28
72 28
74 28
73 28
70 28
33 20
17 16
3 4
10 8
19 16
34 20
38 20
39 20
37 20
11 8
12 8
21 16
31 20
30 16
32 20
20 16
58 28
18 16
4 4
5 4
50 24
54 28
53 28
24 16
55 28
59 28
67 28
23 16
6 4
14 12
64 32
51 24
43 20
44 20
68 28
81 32
52 28
7 4
36 20
25 16
62 32
26 16
86 32
87 32
75 28
41 20
29 16
35 20
15 12
88 32
89 32
76 28
42 20
28 16
27 16
45 20
77 28
92 32
61 28
8 4
13 8
56 28
47 20
79 32
46 20
90 32
93 32
91 32
60 28
9 4
22 16
65 28
71 28
82 32
78 28
97 32
96 32
99
98 268
69 7
40 5
0 1
48 6
80 8
83 8
84 8
85 8
95 8
94 8
63 7
49 6
1 1
2 1
16 4
57 7
66 7
72 7
74 7
73 7
70 7
33 5
17 4
3 1
10 2
19 4
34 5
38 5
39 5
37 5
11 2
12 2
21 4
31 5
30 4
32 5
20 4
58 7
18 4
4 1
5 1
50 6
54 7
53 7
24 4
55 7
59 7
67 7
23 4
6 1
14 3
64 8
51 6
43 5
44 5
68 7
81 8
52 7
7 1
36 5
25 4
62 8
26 4
86 8
87 8
75 7
41 5
29 4
35 5
15 3
88 8
89 8
76 7
42 5
28 4
27 4
45 5
77 7
92 8
61 7
8 1
13 2
56 7
47 5
79 8
46 5
90 8
93 8
91 8
60 7
9 1
22 4
65 7
71 7
82 8
78 7
97 8
96 8
99
98 268
69 7
40 5
0 1
48 6
80 8
83 8
84 8
85 8
95 8
94 8
63 7
49 6
1 1
2 1
16 4
57 7
66 7
72 7
74 7
73 7
70 7
33 5
17 4
3 1
10 2
19 4
34 5
38 5
39 5
37 5
11 2
12 2
21 4
31 5
30 4
32 5
20 4
58 7
18 4
4 1
5 1
50 6
54 7
53 7
24 4
55 7
59 7
67 7
23 4
6 1
14 3
64 8
51 6
43 5
44 5
68 7
81 8
52 7
7 1
36 5
25 4
62 8
26 4
86 8
87 8
75 7
41 5
29 4
35 5
15 3
88 8
89 8
76 7
42 5
28 4
27 4
45 5
77 7
92 8
61 7
8 1
13 2
56 7
47 5
79 8
46 5
90 8
93 8
91 8
60 7
9 1
22 4
65 7
71 7
82 8
78 7
97 8
96 8
99
98 268
69 7
40 5
0 1
48 6
80 8
83 8
84 8
85 8
95 8
94 8
63 7
49 6
1 1
2 1
16 4
57 7
66 7
72 7
74 7
73 7
70 7
33 5
17 4
3 1
10 2
19 4
34 5
38 5
39 5
37 5
11 2
12 2
21 4
31 5
30 4
32 5
20 4
58 7
18 4
4 1
5 1
50 6
54 7
53 7
24 4
55 7
59 7
67 7
23 4
6 1
14 3
64 8
51 6
43 5
44 5
68 7
81 8
52 7
7 1
36 5
25 4
62 8
26 4
86 8
87 8
75 7
41 5
29 4
35 5
15 3
88 8
89 8
76 7
42 5
28 4
27 4
45 5
77 7
92 8
61 7
8 1
13 2
56 7
47 5
79 8
46 5
90 8
93 8
91 8
60 7
9 1
22 4
65 7
71 7
82 8
78 7
97 8
96 8
99
98 268
69 7
40 5
0 1
48 6
80 8
83 8
84 8
85 8
95 8
94 8
63 7
49 6
1 1
2 1
16 4
57 7
66 7
72 7
74 7
73 7
70 7
33 5
17 4
3 1
10 2
19 4
34 5
38 5
39 5
37 5
11 2
12 2
21 4
31 5
30 4
32 5
20 4
58 7
18 4
4 1
5 1
50 6
54 7
53 7
24 4
55 7
59 7
67 7
23 4
6 1
14 3
64 8
51 6
43 5
44 5
68 7
81 8
52 7
7 1
36 5
25 4
62 8
26 4
86 8
87 8
75 7
41 5
29 4
35 5
15 3
88 8
89 8
76 7
42 5
28 4
27 4
45 5
77 7
92 8
61 7
8 1
13 2
56 7
47 5
79 8
46 5
90 8
93 8
91 8
60 7
9 1
22 4
65 7
71 7
82 8
78 7
97 8
96 8
end_CG
