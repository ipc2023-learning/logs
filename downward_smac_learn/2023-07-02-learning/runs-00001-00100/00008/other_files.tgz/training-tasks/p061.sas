begin_version
3
end_version
begin_metric
0
end_metric
43
begin_variable
var8
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var3
-1
40
Atom at-robot(loc_10_4)
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_9_3)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_7)
end_variable
begin_variable
var0
-1
39
Atom at(box1, loc_10_4)
Atom at(box1, loc_10_5)
Atom at(box1, loc_10_6)
Atom at(box1, loc_10_7)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_3_9)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_4_9)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_3)
A




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9 0
32
117
2
39 1
38 0
2
3
303
2
39 35
10 0
34
126
2
39 3
27 0
end_DTG
begin_DTG
0
2
0
121
2
39 2
9 0
2
109
2
39 0
16 0
2
1
124
2
39 3
19 0
3
115
2
39 1
10 0
0
0
0
2
4
154
2
39 12
0 0
11
130
2
39 4
33 0
2
6
145
2
39 9
20 0
8
136
2
39 7
2 0
0
2
5
169
2
39 15
1 0
14
133
2
39 5
22 0
0
4
6
181
2
39 18
20 0
10
163
2
39 13
3 0
12
151
2
39 11
26 0
17
139
2
39 7
30 0
4
7
187
2
39 19
15 0
11
166
2
39 14
33 0
13
157
2
39 12
4 0
18
142
2
39 8
11 0
0
2
9
196
2
39 21
14 0
20
148
2
39 10
34 0
0
0
4
11
217
2
39 24
33 0
16
190
2
39 19
6 0
18
178
2
39 17
11 0
23
160
2
39 12
25 0
0
0
4
14
223
2
39 25
22 0
19
205
2
39 22
7 0
21
193
2
39 20
31 0
24
172
2
39 15
28 0
4
15
232
2
39 26
5 0
20
211
2
39 23
34 0
22
199
2
39 21
12 0
25
175
2
39 16
36 0
0
2
17
256
2
39 29
30 0
28
184
2
39 18
32 0
2
20
268
2
39 31
34 0
30
202
2
39 21
21 0
4
21
274
2
39 32
31 0
24
241
2
39 27
28 0
26
226
2
39 25
35 0
31
208
2
39 22
37 0
4
22
283
2
39 33
12 0
25
250
2
39 28
36 0
27
235
2
39 26
24 0
32
214
2
39 23
38 0
2
26
259
2
39 29
35 0
28
244
2
39 27
32 0
4
23
298
2
39 35
25 0
27
265
2
39 30
24 0
29
253
2
39 28
8 0
34
220
2
39 24
27 0
0
2
24
307
2
39 36
28 0
35
229
2
39 25
13 0
4
25
313
2
39 37
36 0
30
286
2
39 33
21 0
32
271
2
39 31
38 0
36
238
2
39 26
29 0
4
26
316
2
39 38
35 0
31
295
2
39 34
37 0
33
277
2
39 32
18 0
37
247
2
39 27
23 0
2
32
301
2
39 35
38 0
34
289
2
39 33
27 0
2
28
322
2
39 39
32 0
38
262
2
39 29
17 0
0
4
0
280
2
39 32
9 0
31
112
2
39 0
37 0
35
319
2
39 38
13 0
37
310
2
39 36
23 0
2
1
292
2
39 33
19 0
32
118
2
39 1
38 0
2
3
304
2
39 35
10 0
34
127
2
39 3
27 0
end_DTG
begin_DTG
0
2
0
122
2
39 2
9 0
2
110
2
39 0
16 0
2
1
125
2
39 3
19 0
3
116
2
39 1
10 0
0
0
0
2
4
155
2
39 12
0 0
11
131
2
39 4
33 0
2
6
146
2
39 9
20 0
8
137
2
39 7
2 0
0
2
5
170
2
39 15
1 0
14
134
2
39 5
22 0
0
4
6
182
2
39 18
20 0
10
164
2
39 13
3 0
12
152
2
39 11
26 0
17
140
2
39 7
30 0
4
7
188
2
39 19
15 0
11
167
2
39 14
33 0
13
158
2
39 12
4 0
18
143
2
39 8
11 0
0
2
9
197
2
39 21
14 0
20
149
2
39 10
34 0
0
0
4
11
218
2
39 24
33 0
16
191
2
39 19
6 0
18
179
2
39 17
11 0
23
161
2
39 12
25 0
0
0
4
14
224
2
39 25
22 0
19
206
2
39 22
7 0
21
194
2
39 20
31 0
24
173
2
39 15
28 0
4
15
233
2
39 26
5 0
20
212
2
39 23
34 0
22
200
2
39 21
12 0
25
176
2
39 16
36 0
0
2
17
257
2
39 29
30 0
28
185
2
39 18
32 0
2
20
269
2
39 31
34 0
30
203
2
39 21
21 0
4
21
275
2
39 32
31 0
24
242
2
39 27
28 0
26
227
2
39 25
35 0
31
209
2
39 22
37 0
4
22
284
2
39 33
12 0
25
251
2
39 28
36 0
27
236
2
39 26
24 0
32
215
2
39 23
38 0
2
26
260
2
39 29
35 0
28
245
2
39 27
32 0
4
23
299
2
39 35
25 0
27
266
2
39 30
24 0
29
254
2
39 28
8 0
34
221
2
39 24
27 0
0
2
24
308
2
39 36
28 0
35
230
2
39 25
13 0
4
25
314
2
39 37
36 0
30
287
2
39 33
21 0
32
272
2
39 31
38 0
36
239
2
39 26
29 0
4
26
317
2
39 38
35 0
31
296
2
39 34
37 0
33
278
2
39 32
18 0
37
248
2
39 27
23 0
2
32
302
2
39 35
38 0
34
290
2
39 33
27 0
2
28
323
2
39 39
32 0
38
263
2
39 29
17 0
0
4
0
281
2
39 32
9 0
31
113
2
39 0
37 0
35
320
2
39 38
13 0
37
311
2
39 36
23 0
2
1
293
2
39 33
19 0
32
119
2
39 1
38 0
2
3
305
2
39 35
10 0
34
128
2
39 3
27 0
end_DTG
begin_CG
5
40 1
41 1
42 1
39 4
20 3
5
40 1
41 1
42 1
39 5
14 3
5
40 1
41 1
42 1
39 5
15 3
5
40 1
41 1
42 1
39 5
33 3
5
40 1
41 1
42 1
39 5
26 3
5
40 1
41 1
42 1
39 5
31 3
5
40 1
41 1
42 1
39 5
30 3
5
40 1
41 1
42 1
39 4
34 3
5
40 1
41 1
42 1
39 4
32 3
6
40 2
41 2
42 2
39 8
19 3
29 3
6
40 2
41 2
42 2
39 8
16 3
17 3
6
40 2
41 2
42 2
39 8
26 3
30 3
6
40 2
41 2
42 2
39 8
31 3
35 3
6
40 2
41 2
42 2
39 8
21 3
29 3
5
40 1
41 1
42 1
39 5
22 3
5
40 1
41 1
42 1
39 6
26 3
5
40 1
41 1
42 1
39 5
19 3
5
40 1
41 1
42 1
39 5
27 3
5
40 1
41 1
42 1
39 6
38 3
6
40 2
41 2
42 2
39 9
16 3
23 3
6
40 2
41 2
42 2
39 9
15 3
33 3
6
40 2
41 2
42 2
39 9
28 3
37 3
6
40 2
41 2
42 2
39 9
14 3
34 3
6
40 2
41 2
42 2
39 9
38 3
29 3
6
40 2
41 2
42 2
39 9
35 3
32 3
6
40 2
41 2
42 2
39 8
30 3
32 3
5
40 1
41 1
42 1
39 7
33 3
7
40 3
41 3
42 3
39 12
32 3
18 3
17 3
7
40 3
41 3
42 3
39 12
34 3
36 3
21 3
5
40 1
41 1
42 1
39 7
37 3
6
40 2
41 2
42 2
39 10
33 3
25 3
6
40 2
41 2
42 2
39 10
34 3
36 3
7
40 3
41 3
42 3
39 13
25 3
24 3
27 3
7
40 3
41 3
42 3
39 13
20 3
26 3
30 3
7
40 3
41 3
42 3
39 13
22 3
31 3
28 3
7
40 3
41 3
42 3
39 13
36 3
24 3
38 3
7
40 3
41 3
42 3
39 13
31 3
35 3
37 3
7
40 3
41 3
42 3
39 13
36 3
38 3
29 3
8
40 4
41 4
42 4
39 16
35 3
37 3
18 3
23 3
42
40 72
41 72
42 72
9 6
19 12
16 9
10 6
0 3
1 3
20 12
15 9
2 3
14 9
3 3
33 21
26 15
4 3
22 12
5 3
6 3
30 18
11 6
7 3
34 21
31 18
12 6
25 12
28 15
36 21
35 21
24 12
32 21
8 3
21 12
37 21
38 24
18 9
27 15
13 6
29 15
23 12
17 9
40
39 72
9 2
19 4
16 3
10 2
0 1
1 1
20 4
15 3
2 1
14 3
3 1
33 7
26 5
4 1
22 4
5 1
6 1
30 6
11 2
7 1
34 7
31 6
12 2
25 4
28 5
36 7
35 7
24 4
32 7
8 1
21 4
37 7
38 8
18 3
27 5
13 2
29 5
23 4
17 3
40
39 72
9 2
19 4
16 3
10 2
0 1
1 1
20 4
15 3
2 1
14 3
3 1
33 7
26 5
4 1
22 4
5 1
6 1
30 6
11 2
7 1
34 7
31 6
12 2
25 4
28 5
36 7
35 7
24 4
32 7
8 1
21 4
37 7
38 8
18 3
27 5
13 2
29 5
23 4
17 3
40
39 72
9 2
19 4
16 3
10 2
0 1
1 1
20 4
15 3
2 1
14 3
3 1
33 7
26 5
4 1
22 4
5 1
6 1
30 6
11 2
7 1
34 7
31 6
12 2
25 4
28 5
36 7
35 7
24 4
32 7
8 1
21 4
37 7
38 8
18 3
27 5
13 2
29 5
23 4
17 3
end_CG
