begin_version
3
end_version
begin_metric
0
end_metric
44
begin_variable
var3
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var2
-1
46
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_7)
Atom at-robot(loc_9_8)
Atom at-robot(loc_9_9)
end_variable
begin_variable
var0
-1
41
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_7)
Atom at(box1, loc_2_8)
Atom at(box1, loc_2_9)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
43
118
0
2
40
119
0
44
120
0
3
39
121
1
13 0
39
282
2
42 39
31 0
39
283
2
43 39
31 0
2
40
122
0
44
123
0
3
41
124
0
43
125
0
45
126
0
1
44
127
0
end_DTG
begin_DTG
0
0
0
2
2
140
2
41 4
9 0
4
132
2
41 2
28 0
2
3
146
2
41 5
21 0
5
136
2
41 3
19 0
2
4
150
2
41 6
28 0
6
142
2
41 4
2 0
0
2
0
182
2
41 14
0 0
14
128
2
41 0
18 0
4
1
186
2
41 15
1 0
7
160
2
41 9
17 0
9
152
2
41 7
25 0
15
130
2
41 1
36 0
2
8
164
2
41 10
32 0
10
156
2
41 8
34 0
4
2
196
2
41 17
9 0
9
168
2
41 11
25 0
11
162
2
41 9
38 0
17
134
2
41 2
30 0
4
3
202
2
41 18
21 0
10
174
2
41 12
34 0
12
166
2
41 10
35 0
18
138
2
41 3
40 0
4
4
210
2
41 19
28 0
11
178
2
41 13
38 0
13
170
2
41 11
23 0
19
144
2
41 4
39 0
2
5
216
2
41 20
19 0
20
148
2
41 5
37 0
2
7
226
2
41 22
17 0
22
154
2
41 7
3 0
4
8
228
2
41 23
32 0
14
192
2
41 16
18 0
16
184
2
41 14
26 0
23
158
2
41 8
14 0
2
15
198
2
41 17
36 0
17
188
2
41 15
30 0
2
16
204
2
41 18
26 0
18
194
2
41 16
40 0
4
11
230
2
41 24
38 0
17
212
2
41 19
30 0
19
200
2
41 17
39 0
24
172
2
41 11
29 0
4
12
236
2
41 25
35 0
18
218
2
41 20
40 0
20
206
2
41 18
37 0
25
176
2
41 12
27 0
4
13
240
2
41 26
23 0
19
222
2
41 21
39 0
21
214
2
41 19
10 0
26
180
2
41 13
33 0
0
0
2
15
248
2
41 28
36 0
28
190
2
41 15
11 0
2
18
258
2
41 31
40 0
31
208
2
41 18
24 0
2
24
242
2
41 26
29 0
26
232
2
41 24
33 0
4
20
262
2
41 32
37 0
25
244
2
41 27
27 0
27
238
2
41 25
16 0
32
220
2
41 20
4 0
2
21
264
2
41 33
10 0
33
224
2
41 21
12 0
0
2
28
254
2
41 30
11 0
30
250
2
41 28
22 0
2
29
260
2
41 31
15 0
31
252
2
41 29
24 0
2
24
272
2
41 36
29 0
36
234
2
41 24
20 0
0
2
27
278
2
41 38
16 0
38
246
2
41 27
7 0
0
4
30
280
2
41 39
22 0
34
274
2
41 36
5 0
36
266
2
41 34
20 0
39
256
2
41 30
13 0
2
35
276
2
41 37
31 0
37
268
2
41 35
6 0
0
0
2
35
282
2
41 42
31 0
40
270
2
41 35
8 0
0
end_DTG
begin_DTG
0
0
0
2
2
141
2
41 4
9 0
4
133
2
41 2
28 0
2
3
147
2
41 5
21 0
5
137
2
41 3
19 0
2
4
151
2
41 6
28 0
6
143
2
41 4
2 0
0
2
0
183
2
41 14
0 0
14
129
2
41 0
18 0
4
1
187
2
41 15
1 0
7
161
2
41 9
17 0
9
153
2
41 7
25 0
15
131
2
41 1
36 0
2
8
165
2
41 10
32 0
10
157
2
41 8
34 0
4
2
197
2
41 17
9 0
9
169
2
41 11
25 0
11
163
2
41 9
38 0
17
135
2
41 2
30 0
4
3
203
2
41 18
21 0
10
175
2
41 12
34 0
12
167
2
41 10
35 0
18
139
2
41 3
40 0
4
4
211
2
41 19
28 0
11
179
2
41 13
38 0
13
171
2
41 11
23 0
19
145
2
41 4
39 0
2
5
217
2
41 20
19 0
20
149
2
41 5
37 0
2
7
227
2
41 22
17 0
22
155
2
41 7
3 0
4
8
229
2
41 23
32 0
14
193
2
41 16
18 0
16
185
2
41 14
26 0
23
159
2
41 8
14 0
2
15
199
2
41 17
36 0
17
189
2
41 15
30 0
2
16
205
2
41 18
26 0
18
195
2
41 16
40 0
4
11
231
2
41 24
38 0
17
213
2
41 19
30 0
19
201
2
41 17
39 0
24
173
2
41 11
29 0
4
12
237
2
41 25
35 0
18
219
2
41 20
40 0
20
207
2
41 18
37 0
25
177
2
41 12
27 0
4
13
241
2
41 26
23 0
19
223
2
41 21
39 0
21
215
2
41 19
10 0
26
181
2
41 13
33 0
0
0
2
15
249
2
41 28
36 0
28
191
2
41 15
11 0
2
18
259
2
41 31
40 0
31
209
2
41 18
24 0
2
24
243
2
41 26
29 0
26
233
2
41 24
33 0
4
20
263
2
41 32
37 0
25
245
2
41 27
27 0
27
239
2
41 25
16 0
32
221
2
41 20
4 0
2
21
265
2
41 33
10 0
33
225
2
41 21
12 0
0
2
28
255
2
41 30
11 0
30
251
2
41 28
22 0
2
29
261
2
41 31
15 0
31
253
2
41 29
24 0
2
24
273
2
41 36
29 0
36
235
2
41 24
20 0
0
2
27
279
2
41 38
16 0
38
247
2
41 27
7 0
0
4
30
281
2
41 39
22 0
34
275
2
41 36
5 0
36
267
2
41 34
20 0
39
257
2
41 30
13 0
2
35
277
2
41 37
31 0
37
269
2
41 35
6 0
0
0
2
35
283
2
41 42
31 0
40
271
2
41 35
8 0
0
end_DTG
begin_CG
4
42 1
43 1
41 4
17 2
4
42 1
43 1
41 4
32 2
4
42 1
43 1
41 3
19 2
4
42 1
43 1
41 4
18 2
4
42 1
43 1
41 4
33 2
4
42 1
43 1
41 4
31 2
4
42 1
43 1
41 4
20 2
4
42 1
43 1
41 3
12 2
4
42 1
43 1
41 3
13 2
5
42 2
43 2
41 6
21 2
34 2
5
42 2
43 2
41 6
37 2
16 2
5
42 2
43 2
41 6
14 2
15 2
4
42 1
43 1
41 5
16 2
4
42 1
43 1
41 4
31 2
4
42 1
43 1
41 5
36 2
4
42 1
43 1
41 5
22 2
5
42 2
43 2
41 7
33 2
12 2
5
42 2
43 2
41 7
32 2
18 2
5
42 2
43 2
41 7
17 2
36 2
5
42 2
43 2
41 7
28 2
23 2
5
42 2
43 2
41 7
24 2
31 2
5
42 2
43 2
41 7
28 2
38 2
5
42 2
43 2
41 7
15 2
31 2
5
42 2
43 2
41 7
35 2
37 2
5
42 2
43 2
41 7
29 2
22 2
5
42 2
43 2
41 7
32 2
34 2
5
42 2
43 2
41 7
36 2
30 2
5
42 2
43 2
41 7
39 2
33 2
6
42 3
43 3
41 9
21 2
19 2
35 2
6
42 3
43 3
41 9
40 2
27 2
24 2
6
42 3
43 3
41 9
34 2
26 2
40 2
5
42 2
43 2
41 8
20 2
13 2
5
42 2
43 2
41 8
25 2
36 2
5
42 2
43 2
41 8
37 2
27 2
5
42 2
43 2
41 8
25 2
38 2
5
42 2
43 2
41 8
38 2
39 2
6
42 3
43 3
41 10
32 2
26 2
14 2
6
42 3
43 3
41 10
23 2
39 2
33 2
6
42 3
43 3
41 10
34 2
35 2
40 2
6
42 3
43 3
41 10
35 2
40 2
37 2
7
42 4
43 4
41 12
38 2
30 2
39 2
29 2
43
42 78
43 78
0 2
1 2
9 4
21 8
28 10
19 8
2 2
17 8
32 12
25 8
34 12
38 14
35 12
23 8
18 8
36 14
26 8
30 10
40 16
39 14
37 14
10 4
3 2
14 6
29 10
27 8
33 12
16 8
11 4
15 6
22 8
24 8
4 2
12 6
5 2
31 12
20 8
6 2
7 2
13 6
8 2
42
41 78
0 1
1 1
9 2
21 4
28 5
19 4
2 1
17 4
32 6
25 4
34 6
38 7
35 6
23 4
18 4
36 7
26 4
30 5
40 8
39 7
37 7
10 2
3 1
14 3
29 5
27 4
33 6
16 4
11 2
15 3
22 4
24 4
4 1
12 3
5 1
31 6
20 4
6 1
7 1
13 3
8 1
42
41 78
0 1
1 1
9 2
21 4
28 5
19 4
2 1
17 4
32 6
25 4
34 6
38 7
35 6
23 4
18 4
36 7
26 4
30 5
40 8
39 7
37 7
10 2
3 1
14 3
29 5
27 4
33 6
16 4
11 2
15 3
22 4
24 4
4 1
12 3
5 1
31 6
20 4
6 1
7 1
13 3
8 1
end_CG
