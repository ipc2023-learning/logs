begin_version
3
end_version
begin_metric
0
end_metric
47
begin_variable
var4
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var3
-1
44
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_2_10)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_10)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_8)
end_variable
begin_variable
var1
-1
6
Atom at(box2, loc_3_10)
Atom at(box2, loc_3_8)
Atom at(box2, loc_3_9)
Atom at(box2, loc_4_9)
Atom at(box2, loc_5_9)
Atom at(box2, loc_6_9)
end_variable
begin_variable
var0
-1
43
Atom at(box1, loc_10_5)
Atom at(box1, loc_10_6)
Atom at(box1, loc_10_7)
Atom at(box1, loc_2_5)
Atom at(b




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7 0
20
223
2
43 23
33 0
22
210
2
43 21
25 0
28
183
2
43 16
31 0
2
16
263
2
43 30
26 0
29
187
2
43 17
10 0
0
4
17
268
2
43 31
19 0
23
235
2
43 26
5 0
25
225
2
43 24
38 0
30
192
2
43 18
22 0
4
18
274
2
43 32
34 0
24
243
2
43 27
30 0
26
229
2
43 25
41 0
31
198
2
43 19
28 0
4
19
278
2
43 33
42 0
25
251
2
43 28
38 0
27
237
2
43 26
36 0
32
206
2
43 20
39 0
4
20
286
2
43 34
33 0
26
259
2
43 29
41 0
28
245
2
43 27
31 0
33
212
2
43 21
29 0
4
21
290
2
43 35
32 0
27
266
2
43 30
36 0
29
253
2
43 28
10 0
34
218
2
43 22
23 0
0
2
24
296
2
43 36
30 0
35
231
2
43 25
16 0
4
25
300
2
43 37
38 0
30
280
2
43 33
22 0
32
270
2
43 31
39 0
36
239
2
43 26
20 0
4
26
304
2
43 38
41 0
31
288
2
43 34
28 0
33
276
2
43 32
29 0
37
247
2
43 27
35 0
4
27
312
2
43 39
36 0
32
292
2
43 35
39 0
34
282
2
43 33
23 0
38
255
2
43 28
21 0
2
28
316
2
43 40
31 0
39
261
2
43 29
17 0
2
30
320
2
43 41
22 0
40
272
2
43 31
6 0
2
35
306
2
43 38
16 0
37
298
2
43 36
35 0
4
32
322
2
43 42
39 0
36
314
2
43 39
20 0
38
302
2
43 37
21 0
41
284
2
43 33
14 0
2
37
318
2
43 40
35 0
39
308
2
43 38
17 0
2
34
324
2
43 43
23 0
42
294
2
43 35
7 0
0
2
1
310
2
43 38
11 0
37
130
2
43 1
35 0
0
end_DTG
begin_DTG
0
2
0
133
2
43 2
0 0
2
129
2
43 0
1 0
0
0
0
0
2
3
160
2
43 13
2 0
12
135
2
43 4
37 0
2
4
168
2
43 14
3 0
13
137
2
43 5
40 0
0
2
5
147
2
43 9
8 0
8
140
2
43 6
9 0
0
2
10
162
2
43 13
4 0
12
154
2
43 11
37 0
4
6
195
2
43 19
12 0
11
170
2
43 14
15 0
13
156
2
43 12
40 0
18
142
2
43 7
34 0
4
7
201
2
43 20
13 0
12
176
2
43 15
37 0
14
164
2
43 13
24 0
19
144
2
43 8
42 0
2
13
182
2
43 16
40 0
15
172
2
43 14
27 0
4
8
215
2
43 22
9 0
14
186
2
43 17
24 0
16
178
2
43 15
26 0
21
149
2
43 9
32 0
2
9
222
2
43 23
18 0
22
152
2
43 10
25 0
2
11
228
2
43 25
15 0
24
158
2
43 12
30 0
4
12
234
2
43 26
37 0
17
203
2
43 20
19 0
19
191
2
43 18
42 0
25
166
2
43 13
38 0
4
13
242
2
43 27
40 0
18
209
2
43 21
34 0
20
197
2
43 19
33 0
26
174
2
43 14
41 0
4
14
250
2
43 28
24 0
19
217
2
43 22
42 0
21
205
2
43 20
32 0
27
180
2
43 15
36 0
4
15
258
2
43 29
27 0
20
224
2
43 23
33 0
22
211
2
43 21
25 0
28
184
2
43 16
31 0
2
16
265
2
43 30
26 0
29
189
2
43 17
10 0
0
4
17
269
2
43 31
19 0
23
236
2
43 26
5 0
25
226
2
43 24
38 0
30
193
2
43 18
22 0
4
18
275
2
43 32
34 0
24
244
2
43 27
30 0
26
230
2
43 25
41 0
31
199
2
43 19
28 0
4
19
279
2
43 33
42 0
25
252
2
43 28
38 0
27
238
2
43 26
36 0
32
207
2
43 20
39 0
4
20
287
2
43 34
33 0
26
260
2
43 29
41 0
28
246
2
43 27
31 0
33
213
2
43 21
29 0
4
21
291
2
43 35
32 0
27
267
2
43 30
36 0
29
254
2
43 28
10 0
34
219
2
43 22
23 0
0
2
24
297
2
43 36
30 0
35
232
2
43 25
16 0
4
25
301
2
43 37
38 0
30
281
2
43 33
22 0
32
271
2
43 31
39 0
36
240
2
43 26
20 0
4
26
305
2
43 38
41 0
31
289
2
43 34
28 0
33
277
2
43 32
29 0
37
248
2
43 27
35 0
4
27
313
2
43 39
36 0
32
293
2
43 35
39 0
34
283
2
43 33
23 0
38
256
2
43 28
21 0
2
28
317
2
43 40
31 0
39
262
2
43 29
17 0
2
30
321
2
43 41
22 0
40
273
2
43 31
6 0
2
35
307
2
43 38
16 0
37
299
2
43 36
35 0
4
32
323
2
43 42
39 0
36
315
2
43 39
20 0
38
303
2
43 37
21 0
41
285
2
43 33
14 0
2
37
319
2
43 40
35 0
39
309
2
43 38
17 0
2
34
325
2
43 43
23 0
42
295
2
43 35
7 0
0
2
1
311
2
43 38
11 0
37
131
2
43 1
35 0
0
end_DTG
begin_CG
4
45 1
46 1
43 3
11 2
4
45 1
46 1
43 3
11 2
4
45 1
46 1
43 4
12 2
4
45 1
46 1
43 4
13 2
4
45 1
46 1
43 3
15 2
4
45 1
46 1
43 3
30 2
4
45 1
46 1
43 3
16 2
4
45 1
46 1
43 3
17 2
5
45 1
44 1
46 1
43 5
18 3
6
45 2
44 1
46 2
43 7
18 3
27 2
6
45 2
44 1
46 2
43 7
25 3
31 2
4
45 1
46 1
43 5
14 2
4
45 1
46 1
43 5
37 2
4
45 1
46 1
43 5
40 2
4
45 1
46 1
43 4
35 2
5
45 2
46 2
43 7
37 2
19 2
5
45 2
46 2
43 7
22 2
20 2
5
45 2
46 2
43 7
23 2
21 2
5
45 1
44 1
46 1
43 6
26 3
5
45 2
46 2
43 7
34 2
30 2
5
45 2
46 2
43 7
28 2
35 2
5
45 2
46 2
43 7
29 2
35 2
6
45 3
46 3
43 9
30 2
28 2
16 2
6
45 3
46 3
43 9
31 2
29 2
17 2
6
45 3
46 3
43 9
40 2
27 2
33 2
6
45 2
44 1
46 2
43 8
26 3
32 2
6
45 2
44 1
46 2
43 8
27 2
25 3
5
45 2
46 2
43 8
24 2
32 2
5
45 2
46 2
43 8
38 2
39 2
5
45 2
46 2
43 8
36 2
39 2
6
45 3
46 3
43 10
19 2
38 2
22 2
6
45 3
46 3
43 10
32 2
36 2
23 2
6
45 3
46 3
43 10
27 2
33 2
31 2
6
45 3
46 3
43 10
42 2
32 2
36 2
6
45 3
46 3
43 10
37 2
42 2
38 2
7
45 4
46 4
43 12
39 2
20 2
21 2
14 2
7
45 4
46 4
43 12
33 2
41 2
31 2
29 2
7
45 4
46 4
43 12
12 2
15 2
40 2
34 2
7
45 4
46 4
43 12
34 2
30 2
41 2
28 2
7
45 4
46 4
43 12
41 2
28 2
29 2
35 2
7
45 4
46 4
43 12
13 2
37 2
24 2
42 2
7
45 4
46 4
43 12
42 2
38 2
36 2
39 2
7
45 4
46 4
43 12
40 2
34 2
33 2
41 2
46
45 96
44 6
46 96
0 2
11 6
1 2
2 2
3 2
8 3
12 6
13 6
9 5
18 9
4 2
15 8
37 16
40 16
24 10
27 12
26 11
19 8
34 14
42 16
33 14
32 14
25 11
5 2
30 14
38 16
41 16
36 16
31 14
10 5
22 10
28 12
39 16
29 12
23 10
16 8
20 8
35 16
21 8
17 8
6 2
14 6
7 2
7
43 6
8 1
9 1
18 3
26 3
25 3
10 1
44
43 96
0 1
11 3
1 1
2 1
3 1
8 1
12 3
13 3
9 2
18 3
4 1
15 4
37 8
40 8
24 5
27 6
26 4
19 4
34 7
42 8
33 7
32 7
25 4
5 1
30 7
38 8
41 8
36 8
31 7
10 2
22 5
28 6
39 8
29 6
23 5
16 4
20 4
35 8
21 4
17 4
6 1
14 3
7 1
44
43 96
0 1
11 3
1 1
2 1
3 1
8 1
12 3
13 3
9 2
18 3
4 1
15 4
37 8
40 8
24 5
27 6
26 4
19 4
34 7
42 8
33 7
32 7
25 4
5 1
30 7
38 8
41 8
36 8
31 7
10 2
22 5
28 6
39 8
29 6
23 5
16 4
20 4
35 8
21 4
17 4
6 1
14 3
7 1
end_CG
