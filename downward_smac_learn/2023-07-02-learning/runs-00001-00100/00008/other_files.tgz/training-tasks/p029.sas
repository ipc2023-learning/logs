begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var5
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var2
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var1
-1
31
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
21
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_4)
Atom at(box1, loc_7_4)
Atom at(box1, loc_8_4)
end_variable
21
begin_mutex_group
2
22 0
6 0
end_mutex_group
begin_mutex_group
2
22 1
13 0
end_mutex_group
begin_mutex_group
2
22 2
7 0
end_mutex_group
begin_mutex_group
2
22 3
0 0
end_mutex_group
begin_mutex_group
2
22 4
1 0
end_mutex_group
begin_mutex_group
2
22 5
17 0
end_mutex_group
begin_mutex_group
2
22 6
20 0
end_mutex_group
begin_mutex_group
2
22 7
16 0
end_mutex_group
begin_mutex_group
2
22 8
14 0
end_mutex_group
begin_mutex_group
2
22 9
8 0
end_mutex_group
begin_mutex_group
2
22 10
2 0
end_mutex_group
begin_mutex_group
2
22 11
3 0
end_mutex_group
begin_mutex_group
2
22 12
9 0
end_mutex_group
begin_mutex_group
2
22 13
19 0
end_mutex_group
begin_mutex_group
2
22 14
18 0
end_mutex_group
begin_mutex_group
2
22 15
12 0
end_mutex_group
begin_mutex_group
2
22 16
10 0
end_mutex_group
begin_mutex_group
2
22 17
4 0
end_mutex_group
begin_mutex_group
2
22 18
15 0
end_mutex_group
begin_mutex_group
2
22 19
11 0
end_mutex_group
begin_mutex_group
2
22 20
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
15
15
end_state
begin_goal
1
22 9
end_goal
112
begin_operator
move loc_2_3 loc_2_4 right
1
13 0
1
0 21 0 1
0
end_operator
begin_operator
move loc_2_3 loc_3_3 down
1
17 0
1
0 21 0 6
0
end_operator
begin_operator
move loc_2_4 loc_2_3 left
1
6 0
1
0 21 1 0
0
end_operator
begin_operator
move loc_2_4 loc_2_5 right
1
7 0
1
0 21 1 2
0
end_operator
begin_operator
move loc_2_4 loc_3_4 down
1
20 0
1
0 21 1 7
0
end_operator
begin_operator
move loc_2_5 loc_2_4 left
1
13 0
1
0 21 2 1
0
end_operator
begin_operator
move loc_2_5 loc_2_6 right
1
0 0
1
0 21 2 3
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
16 0
1
0 21 2 8
0
end_operator
begin_operator
move loc_2_6 loc_2_5 left
1
7 0
1
0 21 3 2
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
14 0
1
0 21 3 9
0
end_operator
begin_operator
move loc_2_8 loc_3_8 down
1
2 0
1
0 21 4 11
0
end_operator
begin_operator
move loc_3_2 loc_3_3 right
1
17 0
1
0 21 5 6
0
end_operator
begin_operator
move loc_3_2 loc_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




heck 0
switch 15
check 0
check 1
54
check 0
check 0
switch 6
check 2
58
59
check 0
check 0
switch 10
check 0
check 1
57
check 0
check 0
switch 6
check 2
61
62
check 0
check 0
switch 4
check 0
check 1
60
check 0
check 0
switch 6
check 1
64
check 0
check 0
switch 15
check 0
check 1
63
check 0
switch 5
check 0
check 1
65
check 0
check 0
switch 6
check 1
66
check 0
check 0
switch 11
check 0
check 1
67
check 0
check 0
check 3
68
69
70
check 2
71
72
switch 11
check 0
check 1
73
check 0
check 0
check 1
74
check 3
75
76
77
check 2
78
79
check 0
end_SG
begin_DTG
1
1
82
2
22 2
21 1
0
end_DTG
begin_DTG
1
1
88
2
22 5
21 7
0
end_DTG
begin_DTG
1
1
94
2
22 9
21 9
0
end_DTG
begin_DTG
1
1
100
2
22 12
21 14
0
end_DTG
begin_DTG
1
1
105
2
22 16
21 16
0
end_DTG
begin_DTG
1
1
109
2
22 19
21 19
0
end_DTG
begin_DTG
2
1
84
2
22 1
21 2
1
98
2
22 5
21 13
0
end_DTG
begin_DTG
1
1
80
2
22 1
21 0
2
0
82
3
22 2
21 1
0 0
0
85
3
22 2
21 3
13 0
end_DTG
begin_DTG
1
1
92
2
22 8
21 8
2
0
94
3
22 9
21 9
2 0
0
96
3
22 9
21 11
14 0
end_DTG
begin_DTG
1
1
81
2
22 5
21 0
2
0
97
3
22 12
21 12
19 0
0
100
3
22 12
21 14
3 0
end_DTG
begin_DTG
1
1
103
2
22 15
21 15
2
0
105
3
22 16
21 16
4 0
0
107
3
22 16
21 18
12 0
end_DTG
begin_DTG
1
1
104
2
22 18
21 15
2
0
109
3
22 19
21 19
5 0
0
111
3
22 19
21 27
15 0
end_DTG
begin_DTG
1
1
107
2
22 16
21 18
2
0
103
3
22 15
21 15
10 0
0
106
3
22 15
21 17
18 0
end_DTG
begin_DTG
2
1
85
2
22 2
21 3
1
99
2
22 6
21 14
2
0
80
3
22 1
21 0
7 0
0
84
3
22 1
21 2
6 0
end_DTG
begin_DTG
2
1
89
2
22 7
21 7
1
96
2
22 9
21 11
2
0
92
3
22 8
21 8
8 0
0
95
3
22 8
21 10
16 0
end_DTG
begin_DTG
2
1
101
2
22 14
21 14
1
111
2
22 19
21 27
2
0
104
3
22 18
21 15
11 0
0
110
3
22 18
21 23
18 0
end_DTG
begin_DTG
2
1
87
2
22 6
21 6
1
95
2
22 8
21 10
2
0
89
3
22 7
21 7
14 0
0
93
3
22 7
21 9
20 0
end_DTG
begin_DTG
1
1
91
2
22 6
21 8
4
0
81
3
22 5
21 0
9 0
0
86
3
22 5
21 5
20 0
0
88
3
22 5
21 7
1 0
0
98
3
22 5
21 13
6 0
end_DTG
begin_DTG
3
1
90
2
22 13
21 7
1
106
2
22 15
21 17
1
110
2
22 18
21 23
2
0
101
3
22 14
21 14
15 0
0
108
3
22 14
21 19
19 0
end_DTG
begin_DTG
3
1
83
2
22 6
21 1
1
97
2
22 12
21 12
1
108
2
22 14
21 19
2
0
90
3
22 13
21 7
18 0
0
102
3
22 13
21 15
20 0
end_DTG
begin_DTG
3
1
86
2
22 5
21 5
1
93
2
22 7
21 9
1
102
2
22 13
21 15
4
0
83
3
22 6
21 1
19 0
0
87
3
22 6
21 6
16 0
0
91
3
22 6
21 8
17 0
0
99
3
22 6
21 14
13 0
end_DTG
begin_DTG
4
1
0
1
13 0
1
80
2
22 1
7 0
6
1
1
17 0
6
81
2
22 5
9 0
5
0
2
1
6 0
2
3
1
7 0
2
82
2
22 2
0 0
7
4
1
20 0
7
83
2
22 6
19 0
4
1
5
1
13 0
1
84
2
22 1
6 0
3
6
1
0 0
8
7
1
16 0
3
2
8
1
7 0
2
85
2
22 2
13 0
9
9
1
14 0
1
11
10
1
2 0
3
6
11
1
17 0
6
86
2
22 5
20 0
12
12
1
3 0
5
0
13
1
6 0
5
14
1
1 0
7
15
1
20 0
7
87
2
22 6
16 0
13
16
1
9 0
7
1
17
1
13 0
6
18
1
17 0
6
88
2
22 5
1 0
8
19
1
16 0
8
89
2
22 7
14 0
14
20
1
19 0
14
90
2
22 13
18 0
5
2
21
1
7 0
7
22
1
20 0
7
91
2
22 6
17 0
9
23
1
14 0
9
92
2
22 8
8 0
5
3
24
1
0 0
8
25
1
16 0
8
93
2
22 7
20 0
10
26
1
8 0
10
94
2
22 9
2 0
3
9
27
1
14 0
9
95
2
22 8
16 0
11
28
1
2 0
3
4
29
0
10
30
1
8 0
10
96
2
22 9
14 0
3
5
31
1
1 0
13
32
1
9 0
13
97
2
22 12
19 0
4
6
33
1
17 0
6
98
2
22 5
6 0
12
34
1
3 0
14
35
1
19 0
6
7
36
1
20 0
7
99
2
22 6
13 0
13
37
1
9 0
13
100
2
22 12
3 0
15
38
1
18 0
15
101
2
22 14
15 0
6
14
39
1
19 0
14
102
2
22 13
20 0
16
40
1
12 0
16
103
2
22 15
10 0
19
41
1
15 0
19
104
2
22 18
11 0
4
15
42
1
18 0
17
43
1
10 0
17
105
2
22 16
4 0
20
44
0
4
16
45
1
12 0
16
106
2
22 15
18 0
18
46
1
4 0
21
47
0
3
17
48
1
10 0
17
107
2
22 16
12 0
22
49
0
5
15
50
1
18 0
15
108
2
22 14
19 0
20
51
0
23
52
1
11 0
23
109
2
22 19
5 0
4
16
53
1
12 0
19
54
1
15 0
21
55
0
24
56
0
3
17
57
1
10 0
20
58
0
22
59
0
3
18
60
1
4 0
21
61
0
25
62
0
4
19
63
1
15 0
19
110
2
22 18
18 0
24
64
0
27
65
1
5 0
2
20
66
0
23
67
1
11 0
3
22
68
0
26
69
0
29
70
0
2
25
71
0
30
72
0
2
23
73
1
11 0
23
111
2
22 19
15 0
1
29
74
0
3
25
75
0
28
76
0
30
77
0
2
26
78
0
29
79
0
end_DTG
begin_DTG
0
2
0
84
2
21 2
6 0
2
80
2
21 0
7 0
2
1
85
2
21 3
13 0
3
82
2
21 1
0 0
0
0
4
0
98
2
21 13
6 0
4
88
2
21 7
1 0
6
86
2
21 5
20 0
12
81
2
21 0
9 0
4
1
99
2
21 14
13 0
5
91
2
21 8
17 0
7
87
2
21 6
16 0
13
83
2
21 1
19 0
2
6
93
2
21 9
20 0
8
89
2
21 7
14 0
2
7
95
2
21 10
16 0
9
92
2
21 8
8 0
2
8
96
2
21 11
14 0
10
94
2
21 9
2 0
0
0
2
11
100
2
21 14
3 0
13
97
2
21 12
19 0
2
6
102
2
21 15
20 0
14
90
2
21 7
18 0
2
13
108
2
21 19
19 0
18
101
2
21 14
15 0
2
14
106
2
21 17
18 0
16
103
2
21 15
10 0
2
15
107
2
21 18
12 0
17
105
2
21 16
4 0
0
2
14
110
2
21 23
18 0
19
104
2
21 15
11 0
2
18
111
2
21 27
15 0
20
109
2
21 19
5 0
0
end_DTG
begin_CG
3
22 1
21 3
7 1
3
22 1
21 3
17 1
3
22 1
21 3
8 1
3
22 1
21 3
9 1
3
22 1
21 3
10 1
3
22 1
21 2
11 1
4
22 2
21 4
13 1
17 1
3
22 1
21 4
13 1
3
22 1
21 3
14 1
3
22 1
21 4
17 1
3
22 1
21 4
12 1
3
22 1
21 4
15 1
3
22 1
21 4
10 1
4
22 2
21 5
7 1
20 1
4
22 2
21 5
16 1
8 1
4
22 2
21 5
18 1
11 1
4
22 2
21 5
20 1
14 1
3
22 1
21 5
20 1
5
22 3
21 6
19 1
12 1
15 1
5
22 3
21 6
20 1
9 1
18 1
5
22 3
21 7
17 1
16 1
19 1
22
22 32
6 2
13 4
7 3
0 1
1 1
17 5
20 7
16 4
14 4
8 3
2 1
3 1
9 3
19 5
18 5
12 3
10 3
4 1
15 4
11 3
5 1
22
21 32
6 2
13 4
7 3
0 1
1 1
17 5
20 7
16 4
14 4
8 3
2 1
3 1
9 3
19 5
18 5
12 3
10 3
4 1
15 4
11 3
5 1
end_CG
