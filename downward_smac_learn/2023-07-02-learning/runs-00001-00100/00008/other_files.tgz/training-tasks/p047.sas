begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var3
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var2
-1
41
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_8_9)
Atom at-robot(loc_9_2)
Atom at-robot(loc_9_3)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_8)
end_variable
begin_variable
var0
-1
39
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_9)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_4_9)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_5_9)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




nd_DTG
begin_DTG
0
0
0
0
2
0
140
2
39 12
0 0
11
114
2
39 1
34 0
0
2
1
160
2
39 15
1 0
14
116
2
39 2
35 0
2
6
132
2
39 9
17 0
8
126
2
39 7
12 0
2
2
172
2
39 17
2 0
16
118
2
39 3
9 0
2
3
176
2
39 18
3 0
17
120
2
39 4
10 0
2
9
142
2
39 12
13 0
11
134
2
39 10
34 0
4
4
184
2
39 20
14 0
10
148
2
39 13
18 0
12
136
2
39 11
31 0
19
122
2
39 5
32 0
4
5
190
2
39 21
4 0
11
154
2
39 14
34 0
13
144
2
39 12
21 0
20
124
2
39 6
37 0
2
12
162
2
39 15
31 0
14
150
2
39 13
35 0
4
6
204
2
39 23
17 0
13
168
2
39 16
21 0
15
156
2
39 14
27 0
22
128
2
39 7
33 0
4
7
210
2
39 24
16 0
14
174
2
39 17
35 0
16
164
2
39 15
9 0
23
130
2
39 8
22 0
0
0
4
10
216
2
39 25
18 0
17
186
2
39 20
10 0
19
178
2
39 18
32 0
24
138
2
39 11
20 0
4
11
222
2
39 26
34 0
18
192
2
39 21
26 0
20
180
2
39 19
37 0
25
146
2
39 12
19 0
4
12
226
2
39 27
31 0
19
198
2
39 22
32 0
21
188
2
39 20
36 0
26
152
2
39 13
30 0
4
13
232
2
39 28
21 0
20
206
2
39 23
37 0
22
194
2
39 21
33 0
27
158
2
39 14
38 0
4
14
240
2
39 29
35 0
21
212
2
39 24
36 0
23
200
2
39 22
22 0
28
166
2
39 15
29 0
2
15
244
2
39 30
27 0
29
170
2
39 16
23 0
2
18
250
2
39 31
26 0
30
182
2
39 19
15 0
2
24
228
2
39 27
20 0
26
218
2
39 25
30 0
4
20
252
2
39 32
37 0
25
234
2
39 28
19 0
27
224
2
39 26
38 0
31
196
2
39 21
11 0
4
21
256
2
39 33
36 0
26
242
2
39 29
30 0
28
230
2
39 27
29 0
32
202
2
39 22
28 0
4
22
260
2
39 34
33 0
27
246
2
39 30
38 0
29
236
2
39 28
23 0
33
208
2
39 23
24 0
2
23
266
2
39 35
22 0
34
214
2
39 24
25 0
2
24
272
2
39 38
20 0
36
220
2
39 25
6 0
0
4
27
274
2
39 39
38 0
31
262
2
39 34
11 0
33
254
2
39 32
24 0
37
238
2
39 28
7 0
2
32
268
2
39 35
28 0
34
258
2
39 33
25 0
4
29
276
2
39 40
23 0
33
270
2
39 36
24 0
35
264
2
39 34
5 0
38
248
2
39 30
8 0
0
0
0
0
end_DTG
begin_DTG
0
0
0
0
2
0
141
2
39 12
0 0
11
115
2
39 1
34 0
0
2
1
161
2
39 15
1 0
14
117
2
39 2
35 0
2
6
133
2
39 9
17 0
8
127
2
39 7
12 0
2
2
173
2
39 17
2 0
16
119
2
39 3
9 0
2
3
177
2
39 18
3 0
17
121
2
39 4
10 0
2
9
143
2
39 12
13 0
11
135
2
39 10
34 0
4
4
185
2
39 20
14 0
10
149
2
39 13
18 0
12
137
2
39 11
31 0
19
123
2
39 5
32 0
4
5
191
2
39 21
4 0
11
155
2
39 14
34 0
13
145
2
39 12
21 0
20
125
2
39 6
37 0
2
12
163
2
39 15
31 0
14
151
2
39 13
35 0
4
6
205
2
39 23
17 0
13
169
2
39 16
21 0
15
157
2
39 14
27 0
22
129
2
39 7
33 0
4
7
211
2
39 24
16 0
14
175
2
39 17
35 0
16
165
2
39 15
9 0
23
131
2
39 8
22 0
0
0
4
10
217
2
39 25
18 0
17
187
2
39 20
10 0
19
179
2
39 18
32 0
24
139
2
39 11
20 0
4
11
223
2
39 26
34 0
18
193
2
39 21
26 0
20
181
2
39 19
37 0
25
147
2
39 12
19 0
4
12
227
2
39 27
31 0
19
199
2
39 22
32 0
21
189
2
39 20
36 0
26
153
2
39 13
30 0
4
13
233
2
39 28
21 0
20
207
2
39 23
37 0
22
195
2
39 21
33 0
27
159
2
39 14
38 0
4
14
241
2
39 29
35 0
21
213
2
39 24
36 0
23
201
2
39 22
22 0
28
167
2
39 15
29 0
2
15
245
2
39 30
27 0
29
171
2
39 16
23 0
2
18
251
2
39 31
26 0
30
183
2
39 19
15 0
2
24
229
2
39 27
20 0
26
219
2
39 25
30 0
4
20
253
2
39 32
37 0
25
235
2
39 28
19 0
27
225
2
39 26
38 0
31
197
2
39 21
11 0
4
21
257
2
39 33
36 0
26
243
2
39 29
30 0
28
231
2
39 27
29 0
32
203
2
39 22
28 0
4
22
261
2
39 34
33 0
27
247
2
39 30
38 0
29
237
2
39 28
23 0
33
209
2
39 23
24 0
2
23
267
2
39 35
22 0
34
215
2
39 24
25 0
2
24
273
2
39 38
20 0
36
221
2
39 25
6 0
0
4
27
275
2
39 39
38 0
31
263
2
39 34
11 0
33
255
2
39 32
24 0
37
239
2
39 28
7 0
2
32
269
2
39 35
28 0
34
259
2
39 33
25 0
4
29
277
2
39 40
23 0
33
271
2
39 36
24 0
35
265
2
39 34
5 0
38
249
2
39 30
8 0
0
0
0
0
end_DTG
begin_CG
4
40 1
41 1
39 4
14 2
4
40 1
41 1
39 3
17 2
4
40 1
41 1
39 3
12 2
4
40 1
41 1
39 3
13 2
4
40 1
41 1
39 4
31 2
4
40 1
41 1
39 3
25 2
4
40 1
41 1
39 4
15 2
4
40 1
41 1
39 3
28 2
4
40 1
41 1
39 3
25 2
5
40 2
41 2
39 6
12 2
27 2
5
40 2
41 2
39 6
13 2
26 2
5
40 2
41 2
39 6
30 2
28 2
4
40 1
41 1
39 5
16 2
4
40 1
41 1
39 5
18 2
4
40 1
41 1
39 5
34 2
4
40 1
41 1
39 4
20 2
4
40 1
41 1
39 5
27 2
5
40 2
41 2
39 7
16 2
35 2
5
40 2
41 2
39 7
34 2
26 2
5
40 2
41 2
39 7
32 2
30 2
6
40 3
41 3
39 9
26 2
19 2
15 2
6
40 3
41 3
39 9
31 2
35 2
36 2
6
40 3
41 3
39 9
27 2
33 2
23 2
6
40 3
41 3
39 9
22 2
29 2
25 2
6
40 3
41 3
39 9
29 2
28 2
25 2
5
40 2
41 2
39 8
23 2
24 2
5
40 2
41 2
39 8
32 2
20 2
5
40 2
41 2
39 8
35 2
22 2
5
40 2
41 2
39 8
38 2
24 2
5
40 2
41 2
39 8
33 2
38 2
6
40 3
41 3
39 10
37 2
19 2
38 2
6
40 3
41 3
39 10
34 2
21 2
37 2
6
40 3
41 3
39 10
34 2
26 2
37 2
6
40 3
41 3
39 10
35 2
36 2
29 2
7
40 4
41 4
39 12
14 2
18 2
31 2
32 2
7
40 4
41 4
39 12
17 2
21 2
27 2
33 2
6
40 3
41 3
39 10
37 2
33 2
38 2
7
40 4
41 4
39 12
31 2
32 2
36 2
30 2
7
40 4
41 4
39 12
36 2
30 2
29 2
28 2
41
40 82
41 82
0 2
1 2
2 2
3 2
14 6
4 2
17 8
16 6
12 6
13 6
18 8
34 16
31 14
21 10
35 16
27 12
9 4
10 4
26 12
32 14
37 16
36 14
33 14
22 10
20 10
19 8
30 14
38 16
29 12
23 10
15 6
11 4
28 12
24 10
25 12
5 2
6 2
7 2
8 2
40
39 82
0 1
1 1
2 1
3 1
14 3
4 1
17 4
16 3
12 3
13 3
18 4
34 8
31 7
21 5
35 8
27 6
9 2
10 2
26 6
32 7
37 8
36 7
33 7
22 5
20 5
19 4
30 7
38 8
29 6
23 5
15 3
11 2
28 6
24 5
25 6
5 1
6 1
7 1
8 1
40
39 82
0 1
1 1
2 1
3 1
14 3
4 1
17 4
16 3
12 3
13 3
18 4
34 8
31 7
21 5
35 8
27 6
9 2
10 2
26 6
32 7
37 8
36 7
33 7
22 5
20 5
19 4
30 7
38 8
29 6
23 5
15 3
11 2
28 6
24 5
25 6
5 1
6 1
7 1
8 1
end_CG
