begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var2
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var1
-1
27
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
end_variable
begin_variable
var0
-1
27
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
end_variable
27
begin_mutex_group
2
28 0
0 0
end_mutex_group
begin_mutex_group
2
28 1
14 0
end_mutex_group
begin_mutex_group
2
28 2
18 0
end_mutex_group
begin_mutex_group
2
28 3
15 0
end_mutex_group
begin_mutex_group
2
28 4
1 0
end_mutex_group
begin_mutex_group
2
28 5
2 0
end_mutex_group
begin_mutex_group
2
28 6
22 0
end_mutex_group
begin_mutex_group
2
28 7
24 0
end_mutex_group
begin_mutex_group
2
28 8
20 0
end_mutex_group
begin_mutex_group
2
28 9
3 0
end_mutex_group
begin_mutex_group
2
28 10
4 0
end_mutex_group
begin_mutex_group
2
28 11
19 0
end_mutex_group
begin_mutex_group
2
28 12
23 0
end_mutex_group
begin_mutex_group
2
28 13
16 0
end_mutex_group
begin_mutex_group
2
28 14
9 0
end_mutex_group
begin_mutex_group
2
28 15
12 0
end_mutex_group
begin_mutex_group
2
28 16
26 0
end_mutex_group
begin_mutex_group
2
28 17
25 0
end_mutex_group
begin_mutex_group
2
28 18
6 0
end_mutex_group
begin_mutex_group
2
28 19
7 0
end_mutex_group
begin_mutex_group
2
28 20
11 0
end_mutex_group
begin_mutex_group
2
28 21
21 0
end_mutex_group
begin_mutex_group
2
28 22
17 0
end_mutex_group
begin_mutex_group
2
28 23
8 0
end_mutex_group
begin_mutex_group
2
28 24
13 0
end_mutex_group
begin_mutex_group
2
28 25
10 0
end_mutex_group
begin_mutex_group
2
28 26
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
24
12
end_state
begin_goal
1
28 16
end_goal
126
begin_operator
move loc_2_3 loc_2_4 right
1
14 0
1
0 27 0 1
0
e




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
2
0
77
3
28 2
27 1
15 0
0
82
3
28 2
27 3
14 0
end_DTG
begin_DTG
3
1
78
2
28 6
27 1
1
101
2
28 12
27 13
1
116
2
28 16
27 21
2
0
87
3
28 11
27 6
26 0
0
104
3
28 11
27 16
22 0
end_DTG
begin_DTG
2
1
86
2
28 7
27 6
1
111
2
28 13
27 18
4
0
83
3
28 8
27 3
16 0
0
89
3
28 8
27 7
3 0
0
93
3
28 8
27 9
24 0
0
100
3
28 8
27 13
15 0
end_DTG
begin_DTG
2
1
97
2
28 16
27 11
1
114
2
28 20
27 19
4
0
107
3
28 21
27 16
8 0
0
115
3
28 21
27 20
17 0
0
119
3
28 21
27 22
11 0
0
120
3
28 21
27 23
26 0
end_DTG
begin_DTG
2
1
91
2
28 7
27 8
1
104
2
28 11
27 16
4
0
78
3
28 6
27 1
19 0
0
85
3
28 6
27 5
24 0
0
88
3
28 6
27 7
2 0
0
95
3
28 6
27 11
14 0
end_DTG
begin_DTG
2
1
81
2
28 7
27 2
1
118
2
28 17
27 22
4
0
90
3
28 12
27 7
25 0
0
96
3
28 12
27 11
16 0
0
101
3
28 12
27 13
19 0
0
108
3
28 12
27 17
24 0
end_DTG
begin_DTG
3
1
85
2
28 6
27 5
1
93
2
28 8
27 9
1
108
2
28 12
27 17
4
0
81
3
28 7
27 2
23 0
0
86
3
28 7
27 6
20 0
0
91
3
28 7
27 8
22 0
0
98
3
28 7
27 12
18 0
end_DTG
begin_DTG
3
1
90
2
28 12
27 7
1
103
2
28 16
27 15
1
122
2
28 22
27 24
4
0
99
3
28 17
27 12
17 0
0
106
3
28 17
27 16
6 0
0
112
3
28 17
27 18
26 0
0
118
3
28 17
27 22
23 0
end_DTG
begin_DTG
4
1
87
2
28 11
27 6
1
102
2
28 15
27 14
1
112
2
28 17
27 18
1
120
2
28 21
27 23
4
0
97
3
28 16
27 11
21 0
0
103
3
28 16
27 15
25 0
0
109
3
28 16
27 17
12 0
0
116
3
28 16
27 21
19 0
end_DTG
begin_DTG
3
1
0
1
14 0
1
76
2
28 1
18 0
5
1
1
2 0
5
0
2
1
0 0
2
3
1
18 0
2
77
2
28 2
15 0
6
4
1
22 0
6
78
2
28 6
19 0
6
1
5
1
14 0
1
79
2
28 1
0 0
3
6
1
15 0
3
80
2
28 3
1 0
7
7
1
24 0
7
81
2
28 7
23 0
5
2
8
1
18 0
2
82
2
28 2
14 0
4
9
1
1 0
8
10
1
20 0
8
83
2
28 8
16 0
3
3
11
1
15 0
3
84
2
28 3
18 0
9
12
1
3 0
3
0
13
1
0 0
6
14
1
22 0
6
85
2
28 6
24 0
6
1
15
1
14 0
5
16
1
2 0
7
17
1
24 0
7
86
2
28 7
20 0
11
18
1
19 0
11
87
2
28 11
26 0
7
2
19
1
18 0
6
20
1
22 0
6
88
2
28 6
2 0
8
21
1
20 0
8
89
2
28 8
3 0
12
22
1
23 0
12
90
2
28 12
25 0
6
3
23
1
15 0
7
24
1
24 0
7
91
2
28 7
22 0
9
25
1
3 0
13
26
1
16 0
13
92
2
28 13
6 0
3
4
27
1
1 0
8
28
1
20 0
8
93
2
28 8
24 0
2
14
29
1
9 0
14
94
2
28 14
7 0
6
6
30
1
22 0
6
95
2
28 6
14 0
12
31
1
23 0
12
96
2
28 12
16 0
16
32
1
26 0
16
97
2
28 16
21 0
6
7
33
1
24 0
7
98
2
28 7
18 0
11
34
1
19 0
13
35
1
16 0
17
36
1
25 0
17
99
2
28 17
17 0
5
8
37
1
20 0
8
100
2
28 8
15 0
12
38
1
23 0
12
101
2
28 12
19 0
18
39
1
6 0
4
10
40
1
4 0
15
41
1
12 0
15
102
2
28 15
26 0
19
42
1
7 0
4
14
43
1
9 0
16
44
1
26 0
16
103
2
28 16
25 0
20
45
1
11 0
8
11
46
1
19 0
11
104
2
28 11
22 0
15
47
1
12 0
15
105
2
28 15
9 0
17
48
1
25 0
17
106
2
28 17
6 0
21
49
1
21 0
21
107
2
28 21
8 0
7
12
50
1
23 0
12
108
2
28 12
24 0
16
51
1
26 0
16
109
2
28 16
12 0
18
52
1
6 0
22
53
1
17 0
22
110
2
28 22
13 0
4
13
54
1
16 0
13
111
2
28 13
20 0
17
55
1
25 0
17
112
2
28 17
26 0
4
14
56
1
9 0
14
113
2
28 14
4 0
20
57
1
11 0
20
114
2
28 20
21 0
4
15
58
1
12 0
19
59
1
7 0
21
60
1
21 0
21
115
2
28 21
17 0
6
16
61
1
26 0
16
116
2
28 16
19 0
20
62
1
11 0
20
117
2
28 20
7 0
22
63
1
17 0
23
64
1
8 0
5
17
65
1
25 0
17
118
2
28 17
23 0
21
66
1
21 0
21
119
2
28 21
11 0
24
67
1
13 0
4
21
68
1
21 0
21
120
2
28 21
26 0
24
69
1
13 0
24
121
2
28 24
10 0
5
22
70
1
17 0
22
122
2
28 22
25 0
23
71
1
8 0
25
72
1
10 0
25
123
2
28 25
5 0
3
24
73
1
13 0
24
124
2
28 24
8 0
26
74
1
5 0
2
25
75
1
10 0
25
125
2
28 25
13 0
end_DTG
begin_DTG
0
2
0
79
2
27 2
0 0
2
76
2
27 0
18 0
2
1
82
2
27 3
14 0
3
77
2
27 1
15 0
2
2
84
2
27 4
18 0
4
80
2
27 2
1 0
0
0
4
1
95
2
27 11
14 0
5
88
2
27 7
2 0
7
85
2
27 5
24 0
11
78
2
27 1
19 0
4
2
98
2
27 12
18 0
6
91
2
27 8
22 0
8
86
2
27 6
20 0
12
81
2
27 2
23 0
4
3
100
2
27 13
15 0
7
93
2
27 9
24 0
9
89
2
27 7
3 0
13
83
2
27 3
16 0
0
0
2
6
104
2
27 16
22 0
16
87
2
27 6
26 0
4
7
108
2
27 17
24 0
11
101
2
27 13
19 0
13
96
2
27 11
16 0
17
90
2
27 7
25 0
2
8
111
2
27 18
20 0
18
92
2
27 8
6 0
2
10
113
2
27 19
4 0
19
94
2
27 10
7 0
2
14
105
2
27 16
9 0
16
102
2
27 14
26 0
4
11
116
2
27 21
19 0
15
109
2
27 17
12 0
17
103
2
27 15
25 0
21
97
2
27 11
21 0
4
12
118
2
27 22
23 0
16
112
2
27 18
26 0
18
106
2
27 16
6 0
22
99
2
27 12
17 0
0
0
2
19
117
2
27 21
7 0
21
114
2
27 19
21 0
4
16
120
2
27 23
26 0
20
119
2
27 22
11 0
22
115
2
27 20
17 0
23
107
2
27 16
8 0
2
17
122
2
27 24
25 0
24
110
2
27 17
13 0
0
2
23
124
2
27 25
8 0
25
121
2
27 23
10 0
2
24
125
2
27 26
13 0
26
123
2
27 24
5 0
0
end_DTG
begin_CG
3
28 1
27 3
14 1
3
28 1
27 3
15 1
3
28 1
27 3
22 1
3
28 1
27 3
20 1
3
28 1
27 2
9 1
3
28 1
27 2
10 1
4
28 2
27 4
16 1
25 1
4
28 2
27 4
9 1
11 1
4
28 2
27 4
21 1
13 1
3
28 1
27 4
12 1
3
28 1
27 3
13 1
3
28 1
27 4
21 1
3
28 1
27 4
26 1
4
28 2
27 5
17 1
10 1
4
28 2
27 5
18 1
22 1
4
28 2
27 5
18 1
20 1
4
28 2
27 5
20 1
23 1
4
28 2
27 5
25 1
21 1
5
28 3
27 6
14 1
15 1
24 1
5
28 3
27 6
22 1
23 1
26 1
4
28 2
27 6
24 1
16 1
4
28 2
27 6
26 1
11 1
4
28 2
27 6
24 1
19 1
4
28 2
27 6
24 1
25 1
5
28 3
27 7
22 1
20 1
23 1
5
28 3
27 7
23 1
26 1
17 1
6
28 4
27 8
19 1
12 1
25 1
21 1
28
28 50
0 1
14 4
18 5
15 4
1 1
2 1
22 6
24 7
20 6
3 1
4 1
19 5
23 6
16 4
9 3
12 3
26 8
25 7
6 2
7 2
11 3
21 6
17 4
8 2
13 4
10 3
5 1
28
27 50
0 1
14 4
18 5
15 4
1 1
2 1
22 6
24 7
20 6
3 1
4 1
19 5
23 6
16 4
9 3
12 3
26 8
25 7
6 2
7 2
11 3
21 6
17 4
8 2
13 4
10 3
5 1
end_CG
