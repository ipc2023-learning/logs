begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var4
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var3
-1
50
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_10_8)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_8)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_10)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_10)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
34 0
37
386
2
48 37
9 0
43
353
2
48 32
25 0
0
2
32
431
2
48 46
32 0
44
365
2
48 34
24 0
2
33
440
2
48 47
26 0
45
374
2
48 35
15 0
0
0
2
41
425
2
48 45
12 0
43
416
2
48 43
25 0
2
36
443
2
48 48
37 0
46
395
2
48 38
13 0
2
38
446
2
48 49
23 0
47
404
2
48 40
14 0
2
40
434
2
48 46
10 0
44
410
2
48 42
24 0
2
0
428
2
48 45
0 0
43
143
2
48 0
25 0
2
1
437
2
48 46
1 0
44
146
2
48 3
24 0
end_DTG
begin_DTG
0
0
0
0
0
0
0
2
6
171
2
48 10
6 0
8
162
2
48 8
27 0
2
7
180
2
48 11
18 0
9
165
2
48 9
38 0
4
2
225
2
48 17
2 0
8
189
2
48 12
27 0
10
174
2
48 10
28 0
15
150
2
48 4
41 0
2
9
198
2
48 13
38 0
11
183
2
48 11
40 0
4
3
243
2
48 19
3 0
10
207
2
48 14
28 0
12
192
2
48 12
33 0
17
153
2
48 5
44 0
4
4
252
2
48 20
4 0
5
201
2
48 13
5 0
11
159
2
48 7
40 0
18
156
2
48 6
31 0
2
7
273
2
48 24
18 0
22
168
2
48 9
46 0
4
8
285
2
48 25
27 0
13
228
2
48 17
22 0
15
213
2
48 15
41 0
23
177
2
48 10
47 0
4
9
297
2
48 26
38 0
14
234
2
48 18
36 0
16
219
2
48 16
43 0
24
186
2
48 11
29 0
4
10
306
2
48 27
28 0
15
246
2
48 19
41 0
17
231
2
48 17
44 0
25
195
2
48 12
42 0
4
11
315
2
48 28
40 0
16
255
2
48 20
43 0
18
237
2
48 18
31 0
26
204
2
48 13
45 0
2
12
327
2
48 29
33 0
27
210
2
48 14
39 0
0
0
2
20
276
2
48 24
8 0
22
264
2
48 22
46 0
4
13
342
2
48 31
22 0
21
288
2
48 25
19 0
23
267
2
48 23
47 0
29
216
2
48 15
35 0
4
14
348
2
48 32
36 0
22
300
2
48 26
46 0
24
279
2
48 24
29 0
30
222
2
48 16
30 0
2
23
309
2
48 27
47 0
25
291
2
48 25
42 0
4
16
357
2
48 33
43 0
24
318
2
48 28
29 0
26
303
2
48 26
45 0
31
240
2
48 18
11 0
4
17
363
2
48 34
44 0
25
330
2
48 29
42 0
27
312
2
48 27
39 0
32
249
2
48 19
32 0
4
18
369
2
48 35
31 0
19
321
2
48 28
7 0
26
261
2
48 21
45 0
33
258
2
48 20
26 0
2
21
378
2
48 36
19 0
34
270
2
48 23
20 0
4
22
384
2
48 37
46 0
28
351
2
48 32
21 0
30
336
2
48 30
30 0
35
282
2
48 24
34 0
2
23
390
2
48 38
47 0
36
294
2
48 25
37 0
0
4
26
402
2
48 40
45 0
31
372
2
48 35
11 0
33
360
2
48 33
26 0
38
324
2
48 28
23 0
2
27
408
2
48 41
39 0
39
333
2
48 29
17 0
2
28
414
2
48 43
21 0
41
339
2
48 30
12 0
4
29
420
2
48 44
35 0
34
393
2
48 38
20 0
36
381
2
48 36
37 0
42
345
2
48 31
16 0
4
30
423
2
48 45
30 0
35
399
2
48 39
34 0
37
387
2
48 37
9 0
43
354
2
48 32
25 0
0
2
32
432
2
48 46
32 0
44
366
2
48 34
24 0
2
33
441
2
48 47
26 0
45
375
2
48 35
15 0
0
0
2
41
426
2
48 45
12 0
43
417
2
48 43
25 0
2
36
444
2
48 48
37 0
46
396
2
48 38
13 0
2
38
447
2
48 49
23 0
47
405
2
48 40
14 0
2
40
435
2
48 46
10 0
44
411
2
48 42
24 0
2
0
429
2
48 45
0 0
43
144
2
48 0
25 0
2
1
438
2
48 46
1 0
44
147
2
48 3
24 0
end_DTG
begin_CG
5
49 1
50 1
51 1
48 5
13 3
5
49 1
50 1
51 1
48 5
14 3
5
49 1
50 1
51 1
48 4
38 3
5
49 1
50 1
51 1
48 5
40 3
5
49 1
50 1
51 1
48 5
33 3
5
49 1
50 1
51 1
48 4
33 3
5
49 1
50 1
51 1
48 4
18 3
5
49 1
50 1
51 1
48 4
39 3
5
49 1
50 1
51 1
48 4
19 3
5
49 1
50 1
51 1
48 4
37 3
5
49 1
50 1
51 1
48 4
15 3
6
49 2
50 2
51 2
48 8
42 3
32 3
6
49 2
50 2
51 2
48 8
20 3
16 3
5
49 1
50 1
51 1
48 5
25 3
5
49 1
50 1
51 1
48 5
24 3
5
49 1
50 1
51 1
48 6
17 3
5
49 1
50 1
51 1
48 6
34 3
5
49 1
50 1
51 1
48 6
26 3
6
49 2
50 2
51 2
48 9
27 3
22 3
6
49 2
50 2
51 2
48 9
46 3
21 3
6
49 2
50 2
51 2
48 9
21 3
34 3
6
49 2
50 2
51 2
48 9
35 3
20 3
6
49 2
50 2
51 2
48 9
36 3
46 3
6
49 2
50 2
51 2
48 9
32 3
24 3
7
49 3
50 3
51 3
48 12
23 3
15 3
14 3
7
49 3
50 3
51 3
48 12
37 3
16 3
13 3
7
49 3
50 3
51 3
48 12
39 3
32 3
17 3
7
49 3
50 3
51 3
48 12
18 3
38 3
36 3
7
49 3
50 3
51 3
48 12
38 3
40 3
43 3
7
49 3
50 3
51 3
48 12
41 3
47 3
42 3
7
49 3
50 3
51 3
48 12
47 3
35 3
37 3
7
49 3
50 3
51 3
48 12
33 3
44 3
39 3
6
49 2
50 2
51 2
48 10
45 3
23 3
6
49 2
50 2
51 2
48 10
40 3
31 3
6
49 2
50 2
51 2
48 10
35 3
37 3
6
49 2
50 2
51 2
48 10
46 3
34 3
6
49 2
50 2
51 2
48 10
41 3
47 3
7
49 3
50 3
51 3
48 13
30 3
34 3
25 3
7
49 3
50 3
51 3
48 13
27 3
28 3
41 3
7
49 3
50 3
51 3
48 13
31 3
45 3
26 3
7
49 3
50 3
51 3
48 13
28 3
33 3
44 3
7
49 3
50 3
51 3
48 13
38 3
36 3
43 3
7
49 3
50 3
51 3
48 13
43 3
29 3
45 3
7
49 3
50 3
51 3
48 13
41 3
44 3
42 3
7
49 3
50 3
51 3
48 13
40 3
43 3
45 3
8
49 4
50 4
51 4
48 16
44 3
42 3
39 3
32 3
8
49 4
50 4
51 4
48 16
22 3
19 3
47 3
35 3
8
49 4
50 4
51 4
48 16
36 3
46 3
29 3
30 3
51
49 102
50 102
51 102
0 3
1 3
2 3
3 3
4 3
5 3
6 3
18 12
27 15
38 21
28 15
40 21
33 18
22 12
36 18
41 21
43 21
44 21
31 15
7 3
8 3
19 12
46 24
47 24
29 15
42 21
45 24
39 21
21 12
35 18
30 15
11 6
32 18
26 15
20 12
34 18
37 21
9 3
23 12
17 9
10 3
12 6
16 9
25 15
24 15
15 9
13 9
14 9
49
48 102
0 1
1 1
2 1
3 1
4 1
5 1
6 1
18 4
27 5
38 7
28 5
40 7
33 6
22 4
36 6
41 7
43 7
44 7
31 5
7 1
8 1
19 4
46 8
47 8
29 5
42 7
45 8
39 7
21 4
35 6
30 5
11 2
32 6
26 5
20 4
34 6
37 7
9 1
23 4
17 3
10 1
12 2
16 3
25 5
24 5
15 3
13 3
14 3
49
48 102
0 1
1 1
2 1
3 1
4 1
5 1
6 1
18 4
27 5
38 7
28 5
40 7
33 6
22 4
36 6
41 7
43 7
44 7
31 5
7 1
8 1
19 4
46 8
47 8
29 5
42 7
45 8
39 7
21 4
35 6
30 5
11 2
32 6
26 5
20 4
34 6
37 7
9 1
23 4
17 3
10 1
12 2
16 3
25 5
24 5
15 3
13 3
14 3
49
48 102
0 1
1 1
2 1
3 1
4 1
5 1
6 1
18 4
27 5
38 7
28 5
40 7
33 6
22 4
36 6
41 7
43 7
44 7
31 5
7 1
8 1
19 4
46 8
47 8
29 5
42 7
45 8
39 7
21 4
35 6
30 5
11 2
32 6
26 5
20 4
34 6
37 7
9 1
23 4
17 3
10 1
12 2
16 3
25 5
24 5
15 3
13 3
14 3
end_CG
