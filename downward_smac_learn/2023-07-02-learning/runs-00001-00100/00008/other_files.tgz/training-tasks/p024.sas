begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var2
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var1
-1
28
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
end_variable
begin_variable
var0
-1
27
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
end_variable
27
begin_mutex_group
2
28 0
0 0
end_mutex_group
begin_mutex_group
2
28 1
1 0
end_mutex_group
begin_mutex_group
2
28 2
9 0
end_mutex_group
begin_mutex_group
2
28 3
2 0
end_mutex_group
begin_mutex_group
2
28 4
5 0
end_mutex_group
begin_mutex_group
2
28 5
18 0
end_mutex_group
begin_mutex_group
2
28 6
6 0
end_mutex_group
begin_mutex_group
2
28 7
12 0
end_mutex_group
begin_mutex_group
2
28 8
10 0
end_mutex_group
begin_mutex_group
2
28 9
24 0
end_mutex_group
begin_mutex_group
2
28 10
23 0
end_mutex_group
begin_mutex_group
2
28 11
15 0
end_mutex_group
begin_mutex_group
2
28 12
13 0
end_mutex_group
begin_mutex_group
2
28 13
7 0
end_mutex_group
begin_mutex_group
2
28 14
25 0
end_mutex_group
begin_mutex_group
2
28 15
26 0
end_mutex_group
begin_mutex_group
2
28 16
22 0
end_mutex_group
begin_mutex_group
2
28 17
8 0
end_mutex_group
begin_mutex_group
2
28 18
16 0
end_mutex_group
begin_mutex_group
2
28 19
21 0
end_mutex_group
begin_mutex_group
2
28 20
17 0
end_mutex_group
begin_mutex_group
2
28 21
3 0
end_mutex_group
begin_mutex_group
2
28 22
14 0
end_mutex_group
begin_mutex_group
2
28 23
20 0
end_mutex_group
begin_mutex_group
2
28 24
19 0
end_mutex_group
begin_mutex_group
2
28 25
11 0
end_mutex_group
begin_mutex_group
2
28 26
4 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
18
19
end_state
begin_goal
1
28 9
end_goal
126
begin_operator
move loc_2_3 loc_3_3 down





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





5 0
0
87
3
28 5
27 10
0 0
end_DTG
begin_DTG
3
1
107
2
28 20
27 17
1
117
2
28 23
27 23
1
125
2
28 25
27 27
2
0
120
3
28 24
27 24
11 0
0
124
3
28 24
27 26
20 0
end_DTG
begin_DTG
3
1
105
2
28 19
27 16
1
115
2
28 22
27 22
1
124
2
28 24
27 26
2
0
117
3
28 23
27 23
19 0
0
122
3
28 23
27 25
14 0
end_DTG
begin_DTG
1
1
92
2
28 15
27 11
4
0
105
3
28 19
27 16
20 0
0
111
3
28 19
27 19
17 0
0
114
3
28 19
27 21
16 0
0
118
3
28 19
27 24
26 0
end_DTG
begin_DTG
2
1
100
2
28 15
27 15
1
121
2
28 20
27 25
4
0
94
3
28 16
27 12
17 0
0
104
3
28 16
27 16
8 0
0
109
3
28 16
27 18
26 0
0
113
3
28 16
27 21
15 0
end_DTG
begin_DTG
3
1
86
2
28 9
27 9
1
96
2
28 11
27 13
1
112
2
28 15
27 20
4
0
84
3
28 10
27 6
26 0
0
88
3
28 10
27 10
15 0
0
93
3
28 10
27 12
24 0
0
102
3
28 10
27 16
6 0
end_DTG
begin_DTG
3
1
76
2
28 5
27 0
1
93
2
28 10
27 12
1
110
2
28 14
27 19
4
0
82
3
28 9
27 5
25 0
0
86
3
28 9
27 9
23 0
0
90
3
28 9
27 11
10 0
0
99
3
28 9
27 15
18 0
end_DTG
begin_DTG
3
1
82
2
28 9
27 5
1
106
2
28 15
27 17
1
116
2
28 18
27 23
4
0
89
3
28 14
27 10
16 0
0
98
3
28 14
27 14
26 0
0
103
3
28 14
27 16
7 0
0
110
3
28 14
27 19
24 0
end_DTG
begin_DTG
4
1
84
2
28 10
27 6
1
98
2
28 14
27 14
1
109
2
28 16
27 18
1
118
2
28 19
27 24
4
0
92
3
28 15
27 11
21 0
0
100
3
28 15
27 15
22 0
0
106
3
28 15
27 17
25 0
0
112
3
28 15
27 20
23 0
end_DTG
begin_DTG
2
5
0
1
18 0
5
76
2
28 5
24 0
2
2
1
1
9 0
2
77
2
28 2
2 0
4
1
2
1
1 0
3
3
1
2 0
7
4
1
12 0
7
78
2
28 7
13 0
3
2
5
1
9 0
2
79
2
28 2
1 0
8
6
0
4
5
7
1
18 0
5
80
2
28 5
6 0
9
8
1
10 0
9
81
2
28 8
7 0
5
0
9
1
0 0
4
10
1
5 0
6
11
1
6 0
10
12
1
24 0
10
82
2
28 9
25 0
4
5
13
1
18 0
5
83
2
28 5
5 0
11
14
1
23 0
11
84
2
28 10
26 0
4
2
15
1
9 0
8
16
0
13
17
1
13 0
13
85
2
28 12
8 0
2
3
18
1
2 0
7
19
1
12 0
4
4
20
1
5 0
10
21
1
24 0
10
86
2
28 9
23 0
14
22
1
7 0
7
5
23
1
18 0
5
87
2
28 5
0 0
9
24
1
10 0
11
25
1
23 0
11
88
2
28 10
15 0
15
26
1
25 0
15
89
2
28 14
16 0
7
6
27
1
6 0
10
28
1
24 0
10
90
2
28 9
10 0
12
29
1
15 0
12
91
2
28 11
13 0
16
30
1
26 0
16
92
2
28 15
21 0
5
11
31
1
23 0
11
93
2
28 10
24 0
13
32
1
13 0
17
33
1
22 0
17
94
2
28 16
17 0
5
7
34
1
12 0
7
95
2
28 7
9 0
12
35
1
15 0
12
96
2
28 11
23 0
18
36
1
8 0
4
9
37
1
10 0
9
97
2
28 8
5 0
15
38
1
25 0
15
98
2
28 14
26 0
7
10
39
1
24 0
10
99
2
28 9
18 0
14
40
1
7 0
16
41
1
26 0
16
100
2
28 15
22 0
19
42
1
16 0
19
101
2
28 18
14 0
8
11
43
1
23 0
11
102
2
28 10
6 0
15
44
1
25 0
15
103
2
28 14
7 0
17
45
1
22 0
17
104
2
28 16
8 0
20
46
1
21 0
20
105
2
28 19
20 0
6
12
47
1
15 0
16
48
1
26 0
16
106
2
28 15
25 0
18
49
1
8 0
21
50
1
17 0
21
107
2
28 20
19 0
4
13
51
1
13 0
13
108
2
28 12
12 0
17
52
1
22 0
17
109
2
28 16
26 0
5
15
53
1
25 0
15
110
2
28 14
24 0
20
54
1
21 0
20
111
2
28 19
17 0
23
55
1
14 0
5
16
56
1
26 0
16
112
2
28 15
23 0
19
57
1
16 0
21
58
1
17 0
24
59
1
20 0
5
17
60
1
22 0
17
113
2
28 16
15 0
20
61
1
21 0
20
114
2
28 19
16 0
25
62
1
19 0
2
23
63
1
14 0
23
115
2
28 22
20 0
5
19
64
1
16 0
19
116
2
28 18
25 0
22
65
1
3 0
24
66
1
20 0
24
117
2
28 23
19 0
6
20
67
1
21 0
20
118
2
28 19
26 0
23
68
1
14 0
23
119
2
28 22
3 0
25
69
1
19 0
25
120
2
28 24
11 0
6
21
70
1
17 0
21
121
2
28 20
22 0
24
71
1
20 0
24
122
2
28 23
14 0
26
72
1
11 0
26
123
2
28 25
4 0
3
25
73
1
19 0
25
124
2
28 24
20 0
27
74
1
4 0
2
26
75
1
11 0
26
125
2
28 25
19 0
end_DTG
begin_DTG
0
0
2
1
79
2
27 3
1 0
3
77
2
27 1
2 0
0
0
4
0
87
2
27 10
0 0
4
83
2
27 6
5 0
6
80
2
27 4
6 0
9
76
2
27 0
24 0
0
2
2
95
2
27 13
9 0
12
78
2
27 2
13 0
2
4
97
2
27 14
5 0
13
81
2
27 4
7 0
4
5
99
2
27 15
18 0
8
90
2
27 11
10 0
10
86
2
27 9
23 0
14
82
2
27 5
25 0
4
6
102
2
27 16
6 0
9
93
2
27 12
24 0
11
88
2
27 10
15 0
15
84
2
27 6
26 0
2
10
96
2
27 13
23 0
12
91
2
27 11
13 0
2
7
108
2
27 18
12 0
17
85
2
27 7
8 0
0
4
9
110
2
27 19
24 0
13
103
2
27 16
7 0
15
98
2
27 14
26 0
18
89
2
27 10
16 0
4
10
112
2
27 20
23 0
14
106
2
27 17
25 0
16
100
2
27 15
22 0
19
92
2
27 11
21 0
4
11
113
2
27 21
15 0
15
109
2
27 18
26 0
17
104
2
27 16
8 0
20
94
2
27 12
17 0
0
2
14
116
2
27 23
25 0
22
101
2
27 15
14 0
4
15
118
2
27 24
26 0
18
114
2
27 21
16 0
20
111
2
27 19
17 0
23
105
2
27 16
20 0
2
16
121
2
27 25
22 0
24
107
2
27 17
19 0
0
2
21
119
2
27 24
3 0
23
115
2
27 22
20 0
2
22
122
2
27 25
14 0
24
117
2
27 23
19 0
2
23
124
2
27 26
20 0
25
120
2
27 24
11 0
2
24
125
2
27 27
19 0
26
123
2
27 25
4 0
0
end_DTG
begin_CG
3
28 1
27 2
18 1
3
28 1
27 2
9 1
3
28 1
27 3
9 1
3
28 1
27 2
14 1
3
28 1
27 2
11 1
4
28 2
27 4
18 1
10 1
4
28 2
27 4
18 1
23 1
4
28 2
27 4
10 1
25 1
4
28 2
27 4
13 1
22 1
3
28 1
27 4
12 1
3
28 1
27 4
24 1
3
28 1
27 3
19 1
3
28 1
27 4
13 1
4
28 2
27 5
12 1
15 1
4
28 2
27 5
16 1
20 1
4
28 2
27 5
23 1
22 1
4
28 2
27 5
25 1
21 1
4
28 2
27 5
22 1
21 1
3
28 1
27 5
24 1
5
28 3
27 6
17 1
20 1
11 1
5
28 3
27 6
21 1
14 1
19 1
3
28 1
27 5
26 1
4
28 2
27 6
26 1
17 1
5
28 3
27 7
24 1
15 1
26 1
5
28 3
27 7
18 1
23 1
25 1
5
28 3
27 7
24 1
26 1
16 1
6
28 4
27 8
23 1
25 1
22 1
21 1
28
28 50
0 1
1 1
9 3
2 1
5 2
18 5
6 2
12 3
10 3
24 7
23 7
15 4
13 4
7 2
25 7
26 8
22 6
8 2
16 4
21 5
17 4
3 1
14 4
20 5
19 5
11 3
4 1
28
27 50
0 1
1 1
9 3
2 1
5 2
18 5
6 2
12 3
10 3
24 7
23 7
15 4
13 4
7 2
25 7
26 8
22 6
8 2
16 4
21 5
17 4
3 1
14 4
20 5
19 5
11 3
4 1
end_CG
