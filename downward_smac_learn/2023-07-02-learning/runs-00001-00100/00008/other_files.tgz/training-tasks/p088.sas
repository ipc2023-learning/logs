begin_version
3
end_version
begin_metric
0
end_metric
75
begin_variable
var7
-1
2
Atom clear(loc_10_12)
NegatedAtom clear(loc_10_12)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_12)
NegatedAtom clear(loc_4_12)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_5_12)
NegatedAtom clear(loc_5_12)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_12)
NegatedAtom clear(loc_7_12)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_12_9)
NegatedAtom clear(loc_12_9)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
va




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




35 0
0
0
4
48
741
2
70 65
40 0
56
685
2
70 58
16 0
58
661
2
70 56
66 0
65
589
2
70 48
54 0
4
49
749
2
70 66
39 0
57
697
2
70 59
64 0
59
673
2
70 57
23 0
66
597
2
70 49
53 0
2
58
701
2
70 60
66 0
60
689
2
70 58
27 0
2
50
757
2
70 67
14 0
67
605
2
70 50
25 0
0
4
53
769
2
70 69
67 0
54
713
2
70 61
59 0
61
645
2
70 54
17 0
69
641
2
70 53
32 0
2
0
649
2
70 54
68 0
54
217
2
70 0
59 0
2
3
665
2
70 56
9 0
56
233
2
70 3
16 0
4
4
677
2
70 57
28 0
57
241
2
70 4
64 0
64
753
2
70 66
19 0
66
737
2
70 64
53 0
2
5
693
2
70 58
62 0
58
253
2
70 5
66 0
2
7
705
2
70 60
44 0
60
273
2
70 7
27 0
0
2
10
725
2
70 62
69 0
62
309
2
70 10
65 0
end_DTG
begin_CG
6
71 1
72 1
73 1
74 1
70 5
20 4
6
71 1
72 1
73 1
74 1
70 5
62 4
6
71 1
72 1
73 1
74 1
70 5
21 4
6
71 1
72 1
73 1
74 1
70 6
46 4
6
71 1
72 1
73 1
74 1
70 6
26 4
6
71 1
72 1
73 1
74 1
70 6
46 4
6
71 1
72 1
73 1
74 1
70 6
55 4
6
71 1
72 1
73 1
74 1
70 5
57 4
6
71 1
72 1
73 1
74 1
70 6
56 4
7
71 2
72 2
73 2
74 2
70 10
28 4
19 4
7
71 2
72 2
73 2
74 2
70 10
56 4
49 4
7
71 2
72 2
73 2
74 2
70 10
29 4
18 4
7
71 2
72 2
73 2
74 2
70 10
49 4
18 4
7
71 2
72 2
73 2
74 2
70 10
22 4
61 4
7
71 2
72 2
73 2
74 2
70 10
30 4
27 4
7
71 2
72 2
73 2
74 2
70 10
57 4
59 4
7
71 2
72 2
73 2
74 2
70 10
64 4
19 4
7
71 2
72 2
73 2
74 2
70 10
63 4
65 4
6
71 1
72 1
73 1
74 1
70 7
58 4
6
71 1
72 1
73 1
74 1
70 7
54 4
6
71 1
72 1
73 1
74 1
70 6
68 4
6
71 1
72 1
73 1
74 1
70 7
42 4
6
71 1
72 1
73 1
74 1
70 7
26 4
6
71 1
72 1
73 1
74 1
70 6
66 4
6
71 1
72 1
73 1
74 1
70 7
51 4
6
71 1
72 1
73 1
74 1
70 7
27 4
7
71 2
72 2
73 2
74 2
70 11
22 4
55 4
7
71 2
72 2
73 2
74 2
70 11
23 4
25 4
7
71 2
72 2
73 2
74 2
70 11
62 4
54 4
7
71 2
72 2
73 2
74 2
70 11
68 4
58 4
7
71 2
72 2
73 2
74 2
70 11
24 4
63 4
7
71 2
72 2
73 2
74 2
70 10
62 4
44 4
7
71 2
72 2
73 2
74 2
70 11
69 4
65 4
7
71 2
72 2
73 2
74 2
70 11
55 4
61 4
7
71 2
72 2
73 2
74 2
70 10
55 4
57 4
7
71 2
72 2
73 2
74 2
70 11
68 4
59 4
7
71 2
72 2
73 2
74 2
70 10
37 4
45 4
7
71 2
72 2
73 2
74 2
70 11
60 4
36 4
7
71 2
72 2
73 2
74 2
70 11
60 4
39 4
7
71 2
72 2
73 2
74 2
70 11
38 4
66 4
7
71 2
72 2
73 2
74 2
70 11
41 4
64 4
7
71 2
72 2
73 2
74 2
70 11
43 4
40 4
8
71 3
72 3
73 3
74 3
70 15
21 4
46 4
43 4
8
71 3
72 3
73 3
74 3
70 15
42 4
60 4
41 4
8
71 3
72 3
73 3
74 3
70 15
31 4
56 4
25 4
8
71 3
72 3
73 3
74 3
70 15
36 4
47 4
24 4
6
71 1
72 1
73 1
74 1
70 8
60 4
8
71 3
72 3
73 3
74 3
70 15
45 4
61 4
51 4
8
71 3
72 3
73 3
74 3
70 15
56 4
69 4
49 4
6
71 1
72 1
73 1
74 1
70 8
58 4
8
71 3
72 3
73 3
74 3
70 15
61 4
51 4
67 4
6
71 1
72 1
73 1
74 1
70 8
63 4
8
71 3
72 3
73 3
74 3
70 15
57 4
67 4
59 4
8
71 3
72 3
73 3
74 3
70 15
62 4
66 4
54 4
6
71 1
72 1
73 1
74 1
70 8
64 4
7
71 2
72 2
73 2
74 2
70 12
33 4
34 4
7
71 2
72 2
73 2
74 2
70 12
44 4
48 4
7
71 2
72 2
73 2
74 2
70 12
34 4
52 4
7
71 2
72 2
73 2
74 2
70 12
69 4
49 4
7
71 2
72 2
73 2
74 2
70 12
65 4
35 4
8
71 3
72 3
73 3
74 3
70 16
46 4
37 4
38 4
8
71 3
72 3
73 3
74 3
70 16
33 4
47 4
50 4
8
71 3
72 3
73 3
74 3
70 16
28 4
31 4
53 4
8
71 3
72 3
73 3
74 3
70 16
51 4
30 4
67 4
8
71 3
72 3
73 3
74 3
70 16
40 4
66 4
54 4
8
71 3
72 3
73 3
74 3
70 16
67 4
59 4
32 4
9
71 4
72 4
73 4
74 4
70 20
39 4
64 4
23 4
53 4
9
71 4
72 4
73 4
74 4
70 20
50 4
52 4
63 4
65 4
9
71 4
72 4
73 4
74 4
70 20
20 4
69 4
29 4
35 4
9
71 4
72 4
73 4
74 4
70 20
68 4
48 4
58 4
32 4
74
71 142
72 142
73 142
74 142
68 32
20 12
0 4
9 8
28 16
62 28
31 16
44 20
56 24
48 20
69 32
29 16
1 4
10 8
49 20
58 24
11 8
12 8
18 12
2 4
21 12
3 4
22 12
26 16
4 4
42 20
46 20
5 4
13 8
33 16
55 24
6 4
43 20
60 28
37 16
36 16
45 20
47 20
61 28
34 16
41 16
38 16
24 12
51 20
50 20
52 20
57 24
7 4
40 16
39 16
14 8
30 16
63 28
67 32
59 24
15 8
16 8
64 28
66 32
23 12
27 16
17 8
65 28
35 16
19 12
54 20
53 20
25 12
8 4
32 16
71
70 142
68 8
20 3
0 1
9 2
28 4
62 7
31 4
44 5
56 6
48 5
69 8
29 4
1 1
10 2
49 5
58 6
11 2
12 2
18 3
2 1
21 3
3 1
22 3
26 4
4 1
42 5
46 5
5 1
13 2
33 4
55 6
6 1
43 5
60 7
37 4
36 4
45 5
47 5
61 7
34 4
41 4
38 4
24 3
51 5
50 5
52 5
57 6
7 1
40 4
39 4
14 2
30 4
63 7
67 8
59 6
15 2
16 2
64 7
66 8
23 3
27 4
17 2
65 7
35 4
19 3
54 5
53 5
25 3
8 1
32 4
71
70 142
68 8
20 3
0 1
9 2
28 4
62 7
31 4
44 5
56 6
48 5
69 8
29 4
1 1
10 2
49 5
58 6
11 2
12 2
18 3
2 1
21 3
3 1
22 3
26 4
4 1
42 5
46 5
5 1
13 2
33 4
55 6
6 1
43 5
60 7
37 4
36 4
45 5
47 5
61 7
34 4
41 4
38 4
24 3
51 5
50 5
52 5
57 6
7 1
40 4
39 4
14 2
30 4
63 7
67 8
59 6
15 2
16 2
64 7
66 8
23 3
27 4
17 2
65 7
35 4
19 3
54 5
53 5
25 3
8 1
32 4
71
70 142
68 8
20 3
0 1
9 2
28 4
62 7
31 4
44 5
56 6
48 5
69 8
29 4
1 1
10 2
49 5
58 6
11 2
12 2
18 3
2 1
21 3
3 1
22 3
26 4
4 1
42 5
46 5
5 1
13 2
33 4
55 6
6 1
43 5
60 7
37 4
36 4
45 5
47 5
61 7
34 4
41 4
38 4
24 3
51 5
50 5
52 5
57 6
7 1
40 4
39 4
14 2
30 4
63 7
67 8
59 6
15 2
16 2
64 7
66 8
23 3
27 4
17 2
65 7
35 4
19 3
54 5
53 5
25 3
8 1
32 4
71
70 142
68 8
20 3
0 1
9 2
28 4
62 7
31 4
44 5
56 6
48 5
69 8
29 4
1 1
10 2
49 5
58 6
11 2
12 2
18 3
2 1
21 3
3 1
22 3
26 4
4 1
42 5
46 5
5 1
13 2
33 4
55 6
6 1
43 5
60 7
37 4
36 4
45 5
47 5
61 7
34 4
41 4
38 4
24 3
51 5
50 5
52 5
57 6
7 1
40 4
39 4
14 2
30 4
63 7
67 8
59 6
15 2
16 2
64 7
66 8
23 3
27 4
17 2
65 7
35 4
19 3
54 5
53 5
25 3
8 1
32 4
end_CG
