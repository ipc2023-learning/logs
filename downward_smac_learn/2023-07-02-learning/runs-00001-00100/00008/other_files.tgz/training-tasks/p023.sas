begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var2
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
15
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
end_variable
begin_variable
var0
-1
13
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_7_3)
end_variable
13
begin_mutex_group
2
14 0
0 0
end_mutex_group
begin_mutex_group
2
14 1
8 0
end_mutex_group
begin_mutex_group
2
14 2
9 0
end_mutex_group
begin_mutex_group
2
14 3
1 0
end_mutex_group
begin_mutex_group
2
14 4
2 0
end_mutex_group
begin_mutex_group
2
14 5
10 0
end_mutex_group
begin_mutex_group
2
14 6
11 0
end_mutex_group
begin_mutex_group
2
14 7
12 0
end_mutex_group
begin_mutex_group
2
14 8
7 0
end_mutex_group
begin_mutex_group
2
14 9
6 0
end_mutex_group
begin_mutex_group
2
14 10
3 0
end_mutex_group
begin_mutex_group
2
14 11
4 0
end_mutex_group
begin_mutex_group
2
14 12
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
1
0
0
0
0
0
0
14
9
end_state
begin_goal
1
14 2
end_goal
54
begin_operator
move loc_4_4 loc_4_5 right
1
8 0
1
0 13 0 1
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
1
11 0
1
0 13 0 6
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
0 0
1
0 13 1 0
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
9 0
1
0 13 1 2
0
end_operator
begin_operator
move loc_4_5 loc_5_5 down
1
12 0
1
0 13 1 7
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
1
8 0
1
0 13 2 1
0
end_operator
begin_operator
move loc_4_6 loc_4_7 right
1
1 0
1
0 13 2 3
0
end_operator
begin_operator
move loc_4_6 loc_5_6 down
1
7 0
1
0 13 2 8
0
end_operator
begin_operator
move loc_4_7 loc_4_6 left
1
9 0
1
0 13 3 2
0
end_operator
begin_operator
move loc_5_2 loc_5_3 right
1
10 0
1
0 13 4 5
0
end_operator
begin_operator
move loc_5_2 loc_6_2 down
0
1
0 13 4 9
0
end_operator
begin_operator
move loc_5_3 loc_5_2 left
1
2 0
1
0 13 5 4
0
end_operator
begin_operator
move loc_5_3 loc_5_4 right
1
11 0
1
0 13 5 6
0
end_operator
begin_operator
move loc_5_3 loc_6_3 down
1
6 0
1
0 13 5 10
0
end_operator
begin_operator
move loc_5_4 loc_4_4 up
1
0 0
1
0 13 6 0
0
end_operator
begin_operator
move loc_5_4 loc_5_3 left
1
10 0
1
0 13 6 5
0
end_operator
begin_operator
move loc_5_4 loc_5_5 right
1
12 0
1
0 13 6 7
0
end_operator
begin_operator
move loc_5_5 loc_4_5 up
1
8 0
1
0 13 7 1
0
end_operator
begin_operator
move loc_5_5 loc_5_4 left
1
11 0
1
0 13 7 6
0
end_operator
begin_operator
move loc_5_5 loc_5_6 right
1
7 0
1
0 13 7 8
0
end_operator
begin_operator
move loc_5_5 loc_6_5 down
1
3 0
1
0 13 7 11
0
end_operator
begin_operator
move loc_5_6 loc_4_6 up
1
9 0
1
0 13 8 2
0
end_operator
begin_operator
move loc_5_6 loc_5_5 left
1
12 0
1
0 13 8 7
0
end_operator
begin_operator
move loc_5_6 loc_6_6 down
1
4 0
1
0 13 8 12
0
end_operator
begin_operator
move loc_6_2 loc_5_2 up
1
2 0
1
0 13 9 4
0
end_operator
begin_operator
move loc_6_2 loc_6_3 right
1
6 0
1
0 13 9 10
0
end_operator
begin_operator
move loc_6_2 loc_7_2 down
0
1
0 13 9 13
0
end_operator
begin_operator
move loc_6_3 loc_5_3 up
1
10 0
1
0 13 10 5
0
end_operator
begin_operator
move loc_6_3 loc_6_2 left
0
1
0 13 10 9
0
end_operator
begin_operator
move loc_6_3 loc_7_3 down
1
5 0
1
0 13 10 14
0
end_operator
begin_operator
move loc_6_5 loc_5_5 up
1
12 0
1
0 13 11 7
0
end_operator
begin_operator
move loc_6_5 loc_6_6 right
1
4 0
1
0 13 11 12
0
end_operator
begin_operator
move loc_6_6 loc_5_6 up
1
7 0
1
0 13 12 8
0
end_operator
begin_operator
move loc_6_6 loc_6_5 left
1
3 0
1
0 13 12 11
0
end_operator
begin_operator
move loc_7_2 loc_6_2 up
0
1
0 13 13 9
0
end_opera




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
check 1
44
check 0
check 0
check 0
switch 2
check 0
check 1
47
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
check 1
45
check 0
check 0
check 0
switch 10
check 0
check 1
49
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 0
switch 3
check 0
check 1
40
check 0
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
48
check 0
check 0
check 0
switch 11
check 0
check 1
50
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
51
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 0
check 0
switch 4
check 0
check 1
42
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
52
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
46
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
check 1
53
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
switch 8
check 0
check 1
0
check 0
switch 11
check 0
check 1
1
check 0
check 0
switch 0
check 0
check 1
2
check 0
switch 9
check 0
check 1
3
check 0
switch 12
check 0
check 1
4
check 0
check 0
switch 8
check 0
check 1
5
check 0
switch 1
check 0
check 1
6
check 0
switch 7
check 0
check 1
7
check 0
check 0
switch 9
check 0
check 1
8
check 0
check 0
switch 0
check 1
10
check 0
check 0
switch 10
check 0
check 1
9
check 0
check 0
switch 2
check 0
check 1
11
check 0
switch 11
check 0
check 1
12
check 0
switch 6
check 0
check 1
13
check 0
check 0
switch 0
check 0
check 1
14
check 0
switch 10
check 0
check 1
15
check 0
switch 12
check 0
check 1
16
check 0
check 0
switch 8
check 0
check 1
17
check 0
switch 11
check 0
check 1
18
check 0
switch 7
check 0
check 1
19
check 0
switch 3
check 0
check 1
20
check 0
check 0
switch 9
check 0
check 1
21
check 0
switch 12
check 0
check 1
22
check 0
switch 4
check 0
check 1
23
check 0
check 0
switch 0
check 1
26
check 0
check 0
switch 2
check 0
check 1
24
check 0
switch 6
check 0
check 1
25
check 0
check 0
switch 0
check 1
28
check 0
check 0
switch 10
check 0
check 1
27
check 0
switch 5
check 0
check 1
29
check 0
check 0
switch 12
check 0
check 1
30
check 0
switch 4
check 0
check 1
31
check 0
check 0
switch 7
check 0
check 1
32
check 0
switch 3
check 0
check 1
33
check 0
check 0
switch 0
check 1
34
check 0
check 0
switch 5
check 0
check 1
35
check 0
check 0
switch 0
check 1
37
check 0
check 0
switch 6
check 0
check 1
36
check 0
check 0
check 0
end_SG
begin_DTG
1
1
41
2
14 1
13 2
0
end_DTG
begin_DTG
1
1
39
2
14 2
13 1
0
end_DTG
begin_DTG
1
1
47
2
14 5
13 6
0
end_DTG
begin_DTG
1
1
40
2
14 7
13 1
0
end_DTG
begin_DTG
1
1
42
2
14 8
13 2
0
end_DTG
begin_DTG
1
1
46
2
14 9
13 5
0
end_DTG
begin_DTG
0
2
0
46
3
14 9
13 5
5 0
0
53
3
14 9
13 14
10 0
end_DTG
begin_DTG
1
1
48
2
14 7
13 6
2
0
42
3
14 8
13 2
4 0
0
52
3
14 8
13 12
9 0
end_DTG
begin_DTG
2
1
43
2
14 2
13 3
1
51
2
14 7
13 11
2
0
38
3
14 1
13 0
9 0
0
41
3
14 1
13 2
0 0
end_DTG
begin_DTG
2
1
38
2
14 1
13 0
1
52
2
14 8
13 12
2
0
39
3
14 2
13 1
1 0
0
43
3
14 2
13 3
8 0
end_DTG
begin_DTG
2
1
49
2
14 6
13 7
1
53
2
14 9
13 14
2
0
44
3
14 5
13 4
11 0
0
47
3
14 5
13 6
2 0
end_DTG
begin_DTG
2
1
44
2
14 5
13 4
1
50
2
14 7
13 8
2
0
45
3
14 6
13 5
12 0
0
49
3
14 6
13 7
10 0
end_DTG
begin_DTG
1
1
45
2
14 6
13 5
4
0
40
3
14 7
13 1
3 0
0
48
3
14 7
13 6
7 0
0
50
3
14 7
13 8
11 0
0
51
3
14 7
13 11
8 0
end_DTG
begin_DTG
3
1
0
1
8 0
1
38
2
14 1
9 0
6
1
1
11 0
5
0
2
1
0 0
2
3
1
9 0
2
39
2
14 2
1 0
7
4
1
12 0
7
40
2
14 7
3 0
5
1
5
1
8 0
1
41
2
14 1
0 0
3
6
1
1 0
8
7
1
7 0
8
42
2
14 8
4 0
2
2
8
1
9 0
2
43
2
14 2
8 0
3
5
9
1
10 0
5
44
2
14 5
11 0
9
10
0
5
4
11
1
2 0
6
12
1
11 0
6
45
2
14 6
12 0
10
13
1
6 0
10
46
2
14 9
5 0
5
0
14
1
0 0
5
15
1
10 0
5
47
2
14 5
2 0
7
16
1
12 0
7
48
2
14 7
7 0
5
1
17
1
8 0
6
18
1
11 0
6
49
2
14 6
10 0
8
19
1
7 0
11
20
1
3 0
4
2
21
1
9 0
7
22
1
12 0
7
50
2
14 7
11 0
12
23
1
4 0
3
4
24
1
2 0
10
25
1
6 0
13
26
0
3
5
27
1
10 0
9
28
0
14
29
1
5 0
3
7
30
1
12 0
7
51
2
14 7
8 0
12
31
1
4 0
3
8
32
1
7 0
8
52
2
14 8
9 0
11
33
1
3 0
2
9
34
0
14
35
1
5 0
3
10
36
1
6 0
10
53
2
14 9
10 0
13
37
0
end_DTG
begin_DTG
0
2
0
41
2
13 2
0 0
2
38
2
13 0
9 0
2
1
43
2
13 3
8 0
3
39
2
13 1
1 0
0
0
2
4
47
2
13 6
2 0
6
44
2
13 4
11 0
2
5
49
2
13 7
10 0
7
45
2
13 5
12 0
4
1
51
2
13 11
8 0
6
50
2
13 8
11 0
8
48
2
13 6
7 0
10
40
2
13 1
3 0
2
2
52
2
13 12
9 0
11
42
2
13 2
4 0
2
5
53
2
13 14
10 0
12
46
2
13 5
5 0
0
0
0
end_DTG
begin_CG
3
14 1
13 3
8 1
3
14 1
13 2
9 1
3
14 1
13 3
10 1
3
14 1
13 3
12 1
3
14 1
13 3
7 1
3
14 1
13 3
6 1
1
13 3
3
14 1
13 4
12 1
4
14 2
13 5
9 1
12 1
4
14 2
13 5
8 1
7 1
4
14 2
13 5
11 1
6 1
4
14 2
13 5
10 1
12 1
3
14 1
13 5
11 1
14
14 16
0 1
8 4
9 4
1 1
2 1
10 4
11 4
12 5
7 3
6 2
3 1
4 1
5 1
14
13 16
0 1
8 4
9 4
1 1
2 1
10 4
11 4
12 5
7 3
6 2
3 1
4 1
5 1
end_CG
