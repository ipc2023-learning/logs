begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var2
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var1
-1
22
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
end_variable
begin_variable
var0
-1
19
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
end_variable
19
begin_mutex_group
2
20 0
0 0
end_mutex_group
begin_mutex_group
2
20 1
1 0
end_mutex_group
begin_mutex_group
2
20 2
16 0
end_mutex_group
begin_mutex_group
2
20 3
2 0
end_mutex_group
begin_mutex_group
2
20 4
13 0
end_mutex_group
begin_mutex_group
2
20 5
3 0
end_mutex_group
begin_mutex_group
2
20 6
4 0
end_mutex_group
begin_mutex_group
2
20 7
14 0
end_mutex_group
begin_mutex_group
2
20 8
9 0
end_mutex_group
begin_mutex_group
2
20 9
11 0
end_mutex_group
begin_mutex_group
2
20 10
17 0
end_mutex_group
begin_mutex_group
2
20 11
15 0
end_mutex_group
begin_mutex_group
2
20 12
18 0
end_mutex_group
begin_mutex_group
2
20 13
5 0
end_mutex_group
begin_mutex_group
2
20 14
6 0
end_mutex_group
begin_mutex_group
2
20 15
8 0
end_mutex_group
begin_mutex_group
2
20 16
10 0
end_mutex_group
begin_mutex_group
2
20 17
12 0
end_mutex_group
begin_mutex_group
2
20 18
7 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
17
10
end_state
begin_goal
1
20 2
end_goal
82
begin_operator
move loc_2_6 loc_2_7 right
0
1
0 19 0 1
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
16 0
1
0 19 0 3
0
end_operator
begin_operator
move loc_2_7 loc_2_6 left
1
0 0
1
0 19 1 0
0
end_operator
begin_operator
move loc_2_7 loc_3_7 down
1
2 0
1
0 19 1 4
0
end_operator
begin_operator
move loc_3_5 loc_3_6 right
1
16 0
1
0 19 2 3
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
0
1
0 19 2 5
0
end_operator
begin_operator
move loc_3_6 loc_2_6 up
1
0 0
1
0 19 3 0
0
end_operator
begin_operator
move loc_3_6 loc_3_5 left
1
1 0
1
0 19 3 2
0
end_operator
begin_operator
move loc_3_6 loc_3_7 right
1
2 0
1
0 19 3 4
0
end_operator
begin_operator
move loc_3_6 loc_4_6 down
1
13 0
1
0 19 3 6
0
end_operator
begin_operator
move loc_3_7 loc_2_7 up
0
1
0 19 4 1
0
end_operator
begin_operator
move loc_3_7 loc_3_6 left
1
16 0
1
0 19 4 3
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
1 0
1
0 19 5 2
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
13 0
1
0 19 5 6
0
end_operator
begin_operator
move loc_4_6 loc_3_6 up
1
16 0
1
0 19 6 3
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
0
1
0 19 6 5
0
end_operator
begin_operator
move loc_4_6 loc_5_6 down
1
14 0
1
0 19 6 10
0
end_operator
begin_operator
move loc_5_2 loc_5_3 right
0
1
0 19 7 8
0
end_operator
begin_operator
move loc_5_2 loc_6_2 down
1
9 0
1
0 19 7 11
0
end_operator
begin_operator
move loc_5_3 loc_5_2 left
1
3 0
1
0 19 8 7
0
end_operato




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




heck 1
21
check 0
check 0
switch 0
check 1
22
check 0
check 0
switch 17
check 0
check 1
23
check 0
check 0
switch 13
check 0
check 1
24
check 0
switch 18
check 0
check 1
25
check 0
check 0
switch 3
check 0
check 1
26
check 0
switch 11
check 0
check 1
27
check 0
switch 6
check 0
check 1
28
check 0
check 0
switch 0
check 1
29
check 0
check 0
switch 9
check 0
check 1
30
check 0
switch 17
check 0
check 1
31
check 0
check 0
switch 4
check 0
check 1
32
check 0
switch 11
check 0
check 1
33
check 0
switch 15
check 0
check 1
34
check 0
switch 8
check 0
check 1
35
check 0
check 0
switch 17
check 0
check 1
36
check 0
switch 18
check 0
check 1
37
check 0
switch 10
check 0
check 1
38
check 0
check 0
switch 14
check 0
check 1
39
check 0
switch 15
check 0
check 1
40
check 0
switch 5
check 0
check 1
41
check 0
switch 12
check 0
check 1
42
check 0
check 0
switch 18
check 0
check 1
43
check 0
switch 7
check 0
check 1
44
check 0
check 0
switch 9
check 0
check 1
45
check 0
check 0
switch 17
check 0
check 1
46
check 0
switch 10
check 0
check 1
47
check 0
check 0
switch 15
check 0
check 1
48
check 0
switch 8
check 0
check 1
49
check 0
switch 12
check 0
check 1
50
check 0
check 0
switch 18
check 0
check 1
51
check 0
switch 10
check 0
check 1
52
check 0
switch 7
check 0
check 1
53
check 0
check 0
switch 5
check 0
check 1
54
check 0
switch 12
check 0
check 1
55
check 0
check 0
check 0
end_SG
begin_DTG
1
1
60
2
20 2
19 6
0
end_DTG
begin_DTG
1
1
59
2
20 2
19 4
0
end_DTG
begin_DTG
1
1
57
2
20 2
19 2
0
end_DTG
begin_DTG
1
1
75
2
20 8
19 17
0
end_DTG
begin_DTG
1
1
76
2
20 10
19 18
0
end_DTG
begin_DTG
1
1
71
2
20 12
19 14
0
end_DTG
begin_DTG
1
1
62
2
20 8
19 7
0
end_DTG
begin_DTG
1
1
78
2
20 17
19 19
0
end_DTG
begin_DTG
2
1
63
2
20 10
19 9
1
80
2
20 16
19 20
0
end_DTG
begin_DTG
1
1
68
2
20 9
19 13
2
0
62
3
20 8
19 7
6 0
0
75
3
20 8
19 17
3 0
end_DTG
begin_DTG
1
1
81
2
20 17
19 21
2
0
77
3
20 16
19 18
12 0
0
80
3
20 16
19 20
8 0
end_DTG
begin_DTG
1
1
70
2
20 10
19 14
2
0
66
3
20 9
19 11
17 0
0
68
3
20 9
19 13
9 0
end_DTG
begin_DTG
2
1
65
2
20 12
19 10
1
77
2
20 16
19 18
2
0
78
3
20 17
19 19
7 0
0
81
3
20 17
19 21
10 0
end_DTG
begin_DTG
2
1
56
2
20 2
19 0
1
72
2
20 7
19 15
2
0
58
3
20 4
19 3
14 0
0
64
3
20 4
19 10
16 0
end_DTG
begin_DTG
2
1
58
2
20 4
19 3
1
79
2
20 12
19 20
2
0
61
3
20 7
19 6
18 0
0
72
3
20 7
19 15
13 0
end_DTG
begin_DTG
2
1
67
2
20 10
19 12
1
74
2
20 12
19 16
2
0
69
3
20 11
19 13
18 0
0
73
3
20 11
19 15
17 0
end_DTG
begin_DTG
1
1
64
2
20 4
19 10
4
0
56
3
20 2
19 0
13 0
0
57
3
20 2
19 2
2 0
0
59
3
20 2
19 4
1 0
0
60
3
20 2
19 6
0 0
end_DTG
begin_DTG
2
1
66
2
20 9
19 11
1
73
2
20 11
19 15
4
0
63
3
20 10
19 9
8 0
0
67
3
20 10
19 12
15 0
0
70
3
20 10
19 14
11 0
0
76
3
20 10
19 18
4 0
end_DTG
begin_DTG
2
1
61
2
20 7
19 6
1
69
2
20 11
19 13
4
0
65
3
20 12
19 10
12 0
0
71
3
20 12
19 14
5 0
0
74
3
20 12
19 16
15 0
0
79
3
20 12
19 20
14 0
end_DTG
begin_DTG
3
1
0
0
3
1
1
16 0
3
56
2
20 2
13 0
2
0
2
1
0 0
4
3
1
2 0
3
3
4
1
16 0
3
57
2
20 2
2 0
5
5
0
5
0
6
1
0 0
2
7
1
1 0
4
8
1
2 0
6
9
1
13 0
6
58
2
20 4
14 0
3
1
10
0
3
11
1
16 0
3
59
2
20 2
1 0
2
2
12
1
1 0
6
13
1
13 0
5
3
14
1
16 0
3
60
2
20 2
0 0
5
15
0
10
16
1
14 0
10
61
2
20 7
18 0
3
8
17
0
11
18
1
9 0
11
62
2
20 8
6 0
3
7
19
1
3 0
9
20
1
4 0
12
21
1
11 0
3
8
22
0
13
23
1
17 0
13
63
2
20 10
8 0
4
6
24
1
13 0
6
64
2
20 4
16 0
15
25
1
18 0
15
65
2
20 12
12 0
4
7
26
1
3 0
12
27
1
11 0
12
66
2
20 9
17 0
17
28
1
6 0
4
8
29
0
11
30
1
9 0
13
31
1
17 0
13
67
2
20 10
15 0
6
9
32
1
4 0
12
33
1
11 0
12
68
2
20 9
9 0
14
34
1
15 0
14
69
2
20 11
18 0
18
35
1
8 0
5
13
36
1
17 0
13
70
2
20 10
11 0
15
37
1
18 0
15
71
2
20 12
5 0
19
38
1
10 0
6
10
39
1
14 0
10
72
2
20 7
13 0
14
40
1
15 0
14
73
2
20 11
17 0
16
41
1
5 0
20
42
1
12 0
3
15
43
1
18 0
15
74
2
20 12
15 0
21
44
1
7 0
2
11
45
1
9 0
11
75
2
20 8
3 0
4
13
46
1
17 0
13
76
2
20 10
4 0
19
47
1
10 0
19
77
2
20 16
12 0
4
14
48
1
15 0
18
49
1
8 0
20
50
1
12 0
20
78
2
20 17
7 0
5
15
51
1
18 0
15
79
2
20 12
14 0
19
52
1
10 0
19
80
2
20 16
8 0
21
53
1
7 0
3
16
54
1
5 0
20
55
1
12 0
20
81
2
20 17
10 0
end_DTG
begin_DTG
0
0
4
0
60
2
19 6
0 0
1
59
2
19 4
1 0
3
57
2
19 2
2 0
4
56
2
19 0
13 0
0
2
2
64
2
19 10
16 0
7
58
2
19 3
14 0
0
0
2
4
72
2
19 15
13 0
12
61
2
19 6
18 0
2
5
75
2
19 17
3 0
14
62
2
19 7
6 0
2
8
68
2
19 13
9 0
10
66
2
19 11
17 0
4
6
76
2
19 18
4 0
9
70
2
19 14
11 0
11
67
2
19 12
15 0
15
63
2
19 9
8 0
2
10
73
2
19 15
17 0
12
69
2
19 13
18 0
4
7
79
2
19 20
14 0
11
74
2
19 16
15 0
13
71
2
19 14
5 0
17
65
2
19 10
12 0
0
0
0
2
15
80
2
19 20
8 0
17
77
2
19 18
12 0
2
16
81
2
19 21
10 0
18
78
2
19 19
7 0
0
end_DTG
begin_CG
3
20 1
19 3
16 1
3
20 1
19 3
16 1
3
20 1
19 3
16 1
3
20 1
19 3
9 1
3
20 1
19 3
17 1
3
20 1
19 3
18 1
3
20 1
19 2
9 1
3
20 1
19 3
12 1
4
20 2
19 4
17 1
10 1
3
20 1
19 4
11 1
3
20 1
19 4
12 1
3
20 1
19 4
17 1
4
20 2
19 5
18 1
10 1
4
20 2
19 5
16 1
14 1
4
20 2
19 4
13 1
18 1
4
20 2
19 5
17 1
18 1
3
20 1
19 5
13 1
4
20 2
19 6
11 1
15 1
4
20 2
19 6
14 1
15 1
20
20 26
0 1
1 1
16 5
2 1
13 4
3 1
4 1
14 4
9 3
11 3
17 6
15 4
18 6
5 1
6 1
8 2
10 3
12 4
7 1
20
19 26
0 1
1 1
16 5
2 1
13 4
3 1
4 1
14 4
9 3
11 3
17 6
15 4
18 6
5 1
6 1
8 2
10 3
12 4
7 1
end_CG
