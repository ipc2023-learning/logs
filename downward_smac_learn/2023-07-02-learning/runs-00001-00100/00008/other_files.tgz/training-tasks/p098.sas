begin_version
3
end_version
begin_metric
0
end_metric
77
begin_variable
var10
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_12_2)
NegatedAtom clear(loc_12_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_7_12)
NegatedAtom clear(loc_7_12)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_2_12)
NegatedAtom clear(loc_2_12)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_12)
NegatedAtom clear(loc_4_12)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_12)
NegatedAtom clear(loc_3_12)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_12_3)
NegatedAtom clear(loc_12_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_12_4)
NegatedAtom clear(loc_12_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var76
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var75
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var37
-1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
72 70
62 0
63
853
2
72 66
52 0
65
829
2
72 64
41 0
69
749
2
72 57
49 0
2
57
897
2
72 71
67 0
70
765
2
72 58
42 0
2
59
909
2
72 72
65 0
71
793
2
72 60
27 0
0
2
0
833
2
72 64
32 0
63
233
2
72 0
52 0
4
1
845
2
72 65
55 0
64
245
2
72 1
56 0
68
901
2
72 71
35 0
70
881
2
72 69
42 0
2
2
857
2
72 66
63 0
65
261
2
72 2
41 0
2
4
865
2
72 67
46 0
66
281
2
72 4
28 0
end_DTG
begin_CG
6
73 1
74 1
75 1
76 1
72 5
46 4
6
73 1
74 1
75 1
76 1
72 5
20 4
6
73 1
74 1
75 1
76 1
72 5
22 4
6
73 1
74 1
75 1
76 1
72 5
43 4
6
73 1
74 1
75 1
76 1
72 5
44 4
6
73 1
74 1
75 1
76 1
72 5
51 4
6
73 1
74 1
75 1
76 1
72 6
44 4
6
73 1
74 1
75 1
76 1
72 6
53 4
6
73 1
74 1
75 1
76 1
72 6
18 4
6
73 1
74 1
75 1
76 1
72 5
52 4
6
73 1
74 1
75 1
76 1
72 6
57 4
7
73 2
74 2
75 2
76 2
72 10
54 4
21 4
7
73 2
74 2
75 2
76 2
72 10
16 4
50 4
7
73 2
74 2
75 2
76 2
72 10
16 4
17 4
7
73 2
74 2
75 2
76 2
72 10
43 4
23 4
7
73 2
74 2
75 2
76 2
72 10
17 4
24 4
6
73 1
74 1
75 1
76 1
72 7
31 4
6
73 1
74 1
75 1
76 1
72 7
31 4
6
73 1
74 1
75 1
76 1
72 6
30 4
6
73 1
74 1
75 1
76 1
72 7
54 4
7
73 2
74 2
75 2
76 2
72 11
25 4
21 4
7
73 2
74 2
75 2
76 2
72 11
45 4
20 4
7
73 2
74 2
75 2
76 2
72 11
46 4
19 4
7
73 2
74 2
75 2
76 2
72 11
58 4
68 4
7
73 2
74 2
75 2
76 2
72 11
31 4
64 4
7
73 2
74 2
75 2
76 2
72 11
32 4
45 4
7
73 2
74 2
75 2
76 2
72 11
63 4
46 4
7
73 2
74 2
75 2
76 2
72 10
46 4
28 4
7
73 2
74 2
75 2
76 2
72 11
65 4
27 4
7
73 2
74 2
75 2
76 2
72 11
33 4
47 4
8
73 3
74 3
75 3
76 3
72 15
29 4
18 4
34 4
6
73 1
74 1
75 1
76 1
72 8
50 4
8
73 3
74 3
75 3
76 3
72 15
55 4
25 4
35 4
8
73 3
74 3
75 3
76 3
72 15
64 4
59 4
29 4
8
73 3
74 3
75 3
76 3
72 15
47 4
30 4
57 4
8
73 3
74 3
75 3
76 3
72 15
32 4
52 4
49 4
8
73 3
74 3
75 3
76 3
72 15
50 4
43 4
60 4
8
73 3
74 3
75 3
76 3
72 15
51 4
68 4
48 4
8
73 3
74 3
75 3
76 3
72 15
44 4
51 4
61 4
8
73 3
74 3
75 3
76 3
72 15
53 4
62 4
52 4
8
73 3
74 3
75 3
76 3
72 15
48 4
67 4
65 4
8
73 3
74 3
75 3
76 3
72 15
67 4
56 4
42 4
8
73 3
74 3
75 3
76 3
72 15
63 4
41 4
49 4
7
73 2
74 2
75 2
76 2
72 12
36 4
58 4
7
73 2
74 2
75 2
76 2
72 12
38 4
53 4
7
73 2
74 2
75 2
76 2
72 12
55 4
54 4
8
73 3
74 3
75 3
76 3
72 16
26 4
22 4
27 4
7
73 2
74 2
75 2
76 2
72 12
59 4
71 4
7
73 2
74 2
75 2
76 2
72 12
66 4
70 4
7
73 2
74 2
75 2
76 2
72 12
55 4
56 4
8
73 3
74 3
75 3
76 3
72 16
31 4
36 4
64 4
8
73 3
74 3
75 3
76 3
72 16
38 4
37 4
66 4
8
73 3
74 3
75 3
76 3
72 16
39 4
56 4
35 4
8
73 3
74 3
75 3
76 3
72 16
44 4
61 4
39 4
8
73 3
74 3
75 3
76 3
72 16
63 4
45 4
19 4
8
73 3
74 3
75 3
76 3
72 16
63 4
45 4
49 4
8
73 3
74 3
75 3
76 3
72 16
62 4
52 4
49 4
8
73 3
74 3
75 3
76 3
72 16
71 4
65 4
34 4
8
73 3
74 3
75 3
76 3
72 16
43 4
60 4
69 4
8
73 3
74 3
75 3
76 3
72 16
60 4
69 4
47 4
8
73 3
74 3
75 3
76 3
72 16
64 4
58 4
59 4
8
73 3
74 3
75 3
76 3
72 16
53 4
66 4
62 4
8
73 3
74 3
75 3
76 3
72 16
61 4
67 4
56 4
9
73 4
74 4
75 4
76 4
72 20
55 4
26 4
54 4
42 4
9
73 4
74 4
75 4
76 4
72 20
50 4
24 4
60 4
33 4
9
73 4
74 4
75 4
76 4
72 20
70 4
40 4
57 4
28 4
9
73 4
74 4
75 4
76 4
72 20
51 4
61 4
48 4
67 4
9
73 4
74 4
75 4
76 4
72 20
66 4
62 4
40 4
41 4
9
73 4
74 4
75 4
76 4
72 20
23 4
37 4
69 4
70 4
9
73 4
74 4
75 4
76 4
72 20
58 4
68 4
59 4
71 4
9
73 4
74 4
75 4
76 4
72 20
68 4
48 4
71 4
65 4
9
73 4
74 4
75 4
76 4
72 20
69 4
70 4
47 4
57 4
76
73 172
74 172
75 172
76 172
32 20
55 28
63 32
26 16
46 28
0 4
25 16
45 24
54 28
19 12
22 16
1 4
20 16
21 16
11 8
2 4
12 8
16 12
13 8
3 4
50 28
31 20
17 12
14 8
43 24
36 20
64 32
24 16
15 8
4 4
5 4
23 16
58 28
60 28
33 20
6 4
44 24
38 20
51 28
37 20
68 32
69 32
59 28
29 16
7 4
53 28
61 28
66 32
48 24
70 32
71 32
47 24
30 20
18 12
8 4
39 20
62 28
67 32
40 20
65 32
57 28
34 20
9 4
52 28
56 28
41 20
28 16
10 4
35 20
49 24
42 20
27 16
73
72 172
32 5
55 7
63 8
26 4
46 7
0 1
25 4
45 6
54 7
19 3
22 4
1 1
20 4
21 4
11 2
2 1
12 2
16 3
13 2
3 1
50 7
31 5
17 3
14 2
43 6
36 5
64 8
24 4
15 2
4 1
5 1
23 4
58 7
60 7
33 5
6 1
44 6
38 5
51 7
37 5
68 8
69 8
59 7
29 4
7 1
53 7
61 7
66 8
48 6
70 8
71 8
47 6
30 5
18 3
8 1
39 5
62 7
67 8
40 5
65 8
57 7
34 5
9 1
52 7
56 7
41 5
28 4
10 1
35 5
49 6
42 5
27 4
73
72 172
32 5
55 7
63 8
26 4
46 7
0 1
25 4
45 6
54 7
19 3
22 4
1 1
20 4
21 4
11 2
2 1
12 2
16 3
13 2
3 1
50 7
31 5
17 3
14 2
43 6
36 5
64 8
24 4
15 2
4 1
5 1
23 4
58 7
60 7
33 5
6 1
44 6
38 5
51 7
37 5
68 8
69 8
59 7
29 4
7 1
53 7
61 7
66 8
48 6
70 8
71 8
47 6
30 5
18 3
8 1
39 5
62 7
67 8
40 5
65 8
57 7
34 5
9 1
52 7
56 7
41 5
28 4
10 1
35 5
49 6
42 5
27 4
73
72 172
32 5
55 7
63 8
26 4
46 7
0 1
25 4
45 6
54 7
19 3
22 4
1 1
20 4
21 4
11 2
2 1
12 2
16 3
13 2
3 1
50 7
31 5
17 3
14 2
43 6
36 5
64 8
24 4
15 2
4 1
5 1
23 4
58 7
60 7
33 5
6 1
44 6
38 5
51 7
37 5
68 8
69 8
59 7
29 4
7 1
53 7
61 7
66 8
48 6
70 8
71 8
47 6
30 5
18 3
8 1
39 5
62 7
67 8
40 5
65 8
57 7
34 5
9 1
52 7
56 7
41 5
28 4
10 1
35 5
49 6
42 5
27 4
73
72 172
32 5
55 7
63 8
26 4
46 7
0 1
25 4
45 6
54 7
19 3
22 4
1 1
20 4
21 4
11 2
2 1
12 2
16 3
13 2
3 1
50 7
31 5
17 3
14 2
43 6
36 5
64 8
24 4
15 2
4 1
5 1
23 4
58 7
60 7
33 5
6 1
44 6
38 5
51 7
37 5
68 8
69 8
59 7
29 4
7 1
53 7
61 7
66 8
48 6
70 8
71 8
47 6
30 5
18 3
8 1
39 5
62 7
67 8
40 5
65 8
57 7
34 5
9 1
52 7
56 7
41 5
28 4
10 1
35 5
49 6
42 5
27 4
end_CG
