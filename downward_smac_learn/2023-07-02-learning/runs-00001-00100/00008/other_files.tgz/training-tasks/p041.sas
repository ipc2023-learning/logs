begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var21
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var2
-1
39
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
39
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_6)
Atom at(box1, loc_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





269
2
41 32
20 0
36
110
1
11 0
36
270
2
40 36
4 0
36
271
2
41 36
4 0
38
111
1
5 0
4
33
112
1
2 0
37
113
1
12 0
37
272
2
40 37
11 0
37
273
2
41 37
11 0
end_DTG
begin_DTG
0
2
0
122
2
39 2
6 0
2
114
2
39 0
26 0
2
1
128
2
39 3
13 0
3
118
2
39 1
27 0
2
2
134
2
39 4
26 0
4
124
2
39 2
15 0
2
3
138
2
39 5
27 0
5
130
2
39 3
7 0
0
2
0
168
2
39 12
6 0
12
116
2
39 0
23 0
4
1
174
2
39 13
13 0
6
150
2
39 8
14 0
8
142
2
39 6
32 0
13
120
2
39 1
34 0
4
2
180
2
39 14
26 0
7
154
2
39 9
31 0
9
146
2
39 7
36 0
14
126
2
39 2
29 0
4
3
186
2
39 15
27 0
8
160
2
39 10
32 0
10
152
2
39 8
33 0
15
132
2
39 3
37 0
4
4
192
2
39 16
15 0
9
164
2
39 11
36 0
11
156
2
39 9
16 0
16
136
2
39 4
38 0
2
5
200
2
39 17
7 0
17
140
2
39 5
35 0
2
6
208
2
39 19
14 0
19
144
2
39 6
17 0
4
7
212
2
39 20
31 0
12
182
2
39 14
23 0
14
170
2
39 12
29 0
20
148
2
39 7
21 0
2
13
188
2
39 15
34 0
15
176
2
39 13
37 0
4
9
216
2
39 21
36 0
14
194
2
39 16
29 0
16
184
2
39 14
38 0
21
158
2
39 9
8 0
4
10
220
2
39 22
33 0
15
202
2
39 17
37 0
17
190
2
39 15
35 0
22
162
2
39 10
30 0
4
11
224
2
39 23
16 0
16
206
2
39 18
38 0
18
196
2
39 16
0 0
23
166
2
39 11
28 0
0
2
12
230
2
39 24
23 0
24
172
2
39 12
10 0
2
13
232
2
39 25
34 0
25
178
2
39 13
22 0
0
4
16
236
2
39 26
38 0
21
226
2
39 23
8 0
23
218
2
39 21
28 0
26
198
2
39 16
19 0
2
17
240
2
39 27
35 0
27
204
2
39 17
20 0
2
19
244
2
39 28
17 0
28
210
2
39 19
9 0
2
20
248
2
39 29
21 0
29
214
2
39 20
25 0
2
22
252
2
39 31
30 0
31
222
2
39 22
18 0
2
23
256
2
39 32
28 0
32
228
2
39 23
24 0
0
4
25
260
2
39 34
22 0
28
250
2
39 30
9 0
30
246
2
39 28
1 0
34
234
2
39 25
3 0
0
2
26
264
2
39 36
19 0
36
238
2
39 26
11 0
4
27
268
2
39 37
20 0
31
258
2
39 33
18 0
33
254
2
39 31
2 0
37
242
2
39 27
12 0
0
0
0
2
35
270
2
39 37
4 0
37
262
2
39 35
12 0
2
36
272
2
39 38
11 0
38
266
2
39 36
5 0
0
end_DTG
begin_DTG
0
2
0
123
2
39 2
6 0
2
115
2
39 0
26 0
2
1
129
2
39 3
13 0
3
119
2
39 1
27 0
2
2
135
2
39 4
26 0
4
125
2
39 2
15 0
2
3
139
2
39 5
27 0
5
131
2
39 3
7 0
0
2
0
169
2
39 12
6 0
12
117
2
39 0
23 0
4
1
175
2
39 13
13 0
6
151
2
39 8
14 0
8
143
2
39 6
32 0
13
121
2
39 1
34 0
4
2
181
2
39 14
26 0
7
155
2
39 9
31 0
9
147
2
39 7
36 0
14
127
2
39 2
29 0
4
3
187
2
39 15
27 0
8
161
2
39 10
32 0
10
153
2
39 8
33 0
15
133
2
39 3
37 0
4
4
193
2
39 16
15 0
9
165
2
39 11
36 0
11
157
2
39 9
16 0
16
137
2
39 4
38 0
2
5
201
2
39 17
7 0
17
141
2
39 5
35 0
2
6
209
2
39 19
14 0
19
145
2
39 6
17 0
4
7
213
2
39 20
31 0
12
183
2
39 14
23 0
14
171
2
39 12
29 0
20
149
2
39 7
21 0
2
13
189
2
39 15
34 0
15
177
2
39 13
37 0
4
9
217
2
39 21
36 0
14
195
2
39 16
29 0
16
185
2
39 14
38 0
21
159
2
39 9
8 0
4
10
221
2
39 22
33 0
15
203
2
39 17
37 0
17
191
2
39 15
35 0
22
163
2
39 10
30 0
4
11
225
2
39 23
16 0
16
207
2
39 18
38 0
18
197
2
39 16
0 0
23
167
2
39 11
28 0
0
2
12
231
2
39 24
23 0
24
173
2
39 12
10 0
2
13
233
2
39 25
34 0
25
179
2
39 13
22 0
0
4
16
237
2
39 26
38 0
21
227
2
39 23
8 0
23
219
2
39 21
28 0
26
199
2
39 16
19 0
2
17
241
2
39 27
35 0
27
205
2
39 17
20 0
2
19
245
2
39 28
17 0
28
211
2
39 19
9 0
2
20
249
2
39 29
21 0
29
215
2
39 20
25 0
2
22
253
2
39 31
30 0
31
223
2
39 22
18 0
2
23
257
2
39 32
28 0
32
229
2
39 23
24 0
0
4
25
261
2
39 34
22 0
28
251
2
39 30
9 0
30
247
2
39 28
1 0
34
235
2
39 25
3 0
0
2
26
265
2
39 36
19 0
36
239
2
39 26
11 0
4
27
269
2
39 37
20 0
31
259
2
39 33
18 0
33
255
2
39 31
2 0
37
243
2
39 27
12 0
0
0
0
2
35
271
2
39 37
4 0
37
263
2
39 35
12 0
2
36
273
2
39 38
11 0
38
267
2
39 36
5 0
0
end_DTG
begin_CG
4
40 1
41 1
39 3
35 2
4
40 1
41 1
39 3
25 2
4
40 1
41 1
39 4
24 2
4
40 1
41 1
39 3
25 2
4
40 1
41 1
39 3
11 2
4
40 1
41 1
39 4
12 2
5
40 2
41 2
39 6
13 2
14 2
5
40 2
41 2
39 6
15 2
16 2
5
40 2
41 2
39 6
37 2
30 2
5
40 2
41 2
39 6
10 2
25 2
4
40 1
41 1
39 5
17 2
5
40 2
41 2
39 7
18 2
12 2
5
40 2
41 2
39 7
24 2
11 2
5
40 2
41 2
39 7
26 2
31 2
5
40 2
41 2
39 7
31 2
23 2
5
40 2
41 2
39 7
27 2
33 2
5
40 2
41 2
39 7
33 2
35 2
5
40 2
41 2
39 7
23 2
10 2
5
40 2
41 2
39 7
19 2
24 2
5
40 2
41 2
39 7
30 2
18 2
5
40 2
41 2
39 7
28 2
24 2
5
40 2
41 2
39 7
34 2
22 2
5
40 2
41 2
39 7
21 2
25 2
6
40 3
41 3
39 9
14 2
34 2
17 2
4
40 1
41 1
39 6
20 2
4
40 1
41 1
39 6
22 2
6
40 3
41 3
39 9
13 2
27 2
32 2
6
40 3
41 3
39 9
26 2
15 2
36 2
6
40 3
41 3
39 9
35 2
30 2
20 2
6
40 3
41 3
39 9
32 2
34 2
37 2
5
40 2
41 2
39 8
38 2
19 2
5
40 2
41 2
39 8
32 2
34 2
5
40 2
41 2
39 8
31 2
36 2
5
40 2
41 2
39 8
36 2
38 2
6
40 3
41 3
39 10
31 2
29 2
21 2
6
40 3
41 3
39 10
16 2
38 2
28 2
6
40 3
41 3
39 10
32 2
33 2
37 2
6
40 3
41 3
39 10
36 2
29 2
38 2
7
40 4
41 4
39 12
33 2
37 2
35 2
30 2
41
40 80
41 80
6 4
13 8
26 10
27 10
15 8
7 4
14 8
31 12
32 12
36 14
33 12
16 8
23 10
34 14
29 10
37 14
38 16
35 14
0 2
17 8
21 8
8 4
30 12
28 10
10 6
22 8
19 8
20 8
9 4
25 10
1 2
18 8
24 10
2 2
3 2
4 2
11 8
12 8
5 2
40
39 80
6 2
13 4
26 5
27 5
15 4
7 2
14 4
31 6
32 6
36 7
33 6
16 4
23 5
34 7
29 5
37 7
38 8
35 7
0 1
17 4
21 4
8 2
30 6
28 5
10 3
22 4
19 4
20 4
9 2
25 5
1 1
18 4
24 5
2 1
3 1
4 1
11 4
12 4
5 1
40
39 80
6 2
13 4
26 5
27 5
15 4
7 2
14 4
31 6
32 6
36 7
33 6
16 4
23 5
34 7
29 5
37 7
38 8
35 7
0 1
17 4
21 4
8 2
30 6
28 5
10 3
22 4
19 4
20 4
9 2
25 5
1 1
18 4
24 5
2 1
3 1
4 1
11 4
12 4
5 1
end_CG
