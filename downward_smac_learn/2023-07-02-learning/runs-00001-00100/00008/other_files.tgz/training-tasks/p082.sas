begin_version
3
end_version
begin_metric
0
end_metric
60
begin_variable
var7
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var4
-1
56
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_11_5)
Atom at-robot(loc_11_6)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




4
20
485
2
55 35
48 0
25
409
2
55 28
30 0
27
385
2
55 26
49 0
34
325
2
55 20
46 0
4
21
497
2
55 36
50 0
26
425
2
55 29
45 0
28
397
2
55 27
29 0
35
341
2
55 21
31 0
2
27
437
2
55 30
49 0
29
413
2
55 28
38 0
4
23
509
2
55 37
44 0
28
449
2
55 31
29 0
30
429
2
55 29
11 0
36
369
2
55 23
26 0
0
0
2
31
473
2
55 34
12 0
33
453
2
55 32
47 0
4
25
529
2
55 40
30 0
32
489
2
55 35
23 0
34
461
2
55 33
46 0
39
389
2
55 26
40 0
4
26
541
2
55 41
45 0
33
501
2
55 36
47 0
35
477
2
55 34
31 0
40
401
2
55 27
54 0
2
27
557
2
55 42
49 0
41
417
2
55 28
52 0
2
29
577
2
55 44
38 0
43
441
2
55 30
28 0
2
31
589
2
55 45
12 0
44
457
2
55 32
13 0
4
32
597
2
55 46
23 0
37
533
2
55 40
14 0
39
517
2
55 38
40 0
45
465
2
55 33
35 0
4
33
605
2
55 47
47 0
38
545
2
55 41
36 0
40
521
2
55 39
54 0
46
481
2
55 34
32 0
4
34
617
2
55 48
46 0
39
561
2
55 42
40 0
41
537
2
55 40
52 0
47
493
2
55 35
53 0
4
35
633
2
55 49
31 0
40
573
2
55 43
54 0
42
549
2
55 41
16 0
48
505
2
55 36
51 0
2
41
581
2
55 44
52 0
43
565
2
55 42
28 0
2
36
653
2
55 51
26 0
50
513
2
55 37
20 0
0
4
38
661
2
55 52
36 0
44
609
2
55 47
13 0
46
593
2
55 45
32 0
51
525
2
55 39
6 0
2
45
621
2
55 48
35 0
47
601
2
55 46
53 0
4
40
669
2
55 53
54 0
46
637
2
55 49
32 0
48
613
2
55 47
51 0
52
553
2
55 41
24 0
4
41
677
2
55 54
52 0
47
649
2
55 50
53 0
49
625
2
55 48
17 0
53
569
2
55 42
25 0
2
48
657
2
55 51
51 0
50
641
2
55 49
20 0
2
43
681
2
55 55
28 0
54
585
2
55 44
7 0
0
2
0
629
2
55 48
18 0
47
177
2
55 0
53 0
2
1
645
2
55 49
27 0
48
181
2
55 1
51 0
0
end_DTG
begin_CG
6
56 1
57 1
58 1
59 1
55 5
27 4
6
56 1
57 1
58 1
59 1
55 6
18 4
6
56 1
57 1
58 1
59 1
55 6
27 4
6
56 1
57 1
58 1
59 1
55 6
19 4
6
56 1
57 1
58 1
59 1
55 6
15 4
6
56 1
57 1
58 1
59 1
55 6
34 4
6
56 1
57 1
58 1
59 1
55 5
35 4
6
56 1
57 1
58 1
59 1
55 5
20 4
7
56 2
57 2
58 2
59 2
55 10
21 4
39 4
7
56 2
57 2
58 2
59 2
55 10
22 4
37 4
7
56 2
57 2
58 2
59 2
55 10
37 4
33 4
7
56 2
57 2
58 2
59 2
55 10
33 4
38 4
7
56 2
57 2
58 2
59 2
55 10
23 4
14 4
7
56 2
57 2
58 2
59 2
55 10
14 4
35 4
6
56 1
57 1
58 1
59 1
55 7
36 4
6
56 1
57 1
58 1
59 1
55 6
33 4
6
56 1
57 1
58 1
59 1
55 7
52 4
6
56 1
57 1
58 1
59 1
55 7
51 4
7
56 2
57 2
58 2
59 2
55 11
27 4
24 4
7
56 2
57 2
58 2
59 2
55 11
39 4
34 4
7
56 2
57 2
58 2
59 2
55 11
28 4
17 4
7
56 2
57 2
58 2
59 2
55 11
22 4
42 4
7
56 2
57 2
58 2
59 2
55 11
21 4
41 4
7
56 2
57 2
58 2
59 2
55 11
47 4
36 4
7
56 2
57 2
58 2
59 2
55 11
18 4
53 4
7
56 2
57 2
58 2
59 2
55 11
27 4
51 4
7
56 2
57 2
58 2
59 2
55 10
38 4
28 4
6
56 1
57 1
58 1
59 1
55 8
25 4
8
56 3
57 3
58 3
59 3
55 15
26 4
16 4
20 4
8
56 3
57 3
58 3
59 3
55 15
43 4
49 4
38 4
8
56 3
57 3
58 3
59 3
55 15
34 4
45 4
47 4
8
56 3
57 3
58 3
59 3
55 15
49 4
46 4
52 4
8
56 3
57 3
58 3
59 3
55 15
40 4
35 4
53 4
7
56 2
57 2
58 2
59 2
55 12
15 4
44 4
7
56 2
57 2
58 2
59 2
55 12
48 4
30 4
7
56 2
57 2
58 2
59 2
55 12
36 4
32 4
7
56 2
57 2
58 2
59 2
55 12
40 4
35 4
7
56 2
57 2
58 2
59 2
55 12
41 4
44 4
8
56 3
57 3
58 3
59 3
55 16
44 4
29 4
26 4
8
56 3
57 3
58 3
59 3
55 16
19 4
42 4
48 4
8
56 3
57 3
58 3
59 3
55 16
47 4
36 4
54 4
8
56 3
57 3
58 3
59 3
55 16
42 4
37 4
43 4
8
56 3
57 3
58 3
59 3
55 16
39 4
41 4
50 4
8
56 3
57 3
58 3
59 3
55 16
41 4
50 4
44 4
9
56 4
57 4
58 4
59 4
55 20
37 4
43 4
33 4
38 4
8
56 3
57 3
58 3
59 3
55 16
48 4
49 4
46 4
8
56 3
57 3
58 3
59 3
55 16
45 4
47 4
54 4
9
56 4
57 4
58 4
59 4
55 20
30 4
23 4
46 4
40 4
9
56 4
57 4
58 4
59 4
55 20
39 4
34 4
50 4
45 4
9
56 4
57 4
58 4
59 4
55 20
50 4
45 4
29 4
31 4
9
56 4
57 4
58 4
59 4
55 20
42 4
48 4
43 4
49 4
9
56 4
57 4
58 4
59 4
55 20
52 4
53 4
17 4
25 4
9
56 4
57 4
58 4
59 4
55 20
31 4
54 4
16 4
51 4
9
56 4
57 4
58 4
59 4
55 20
54 4
32 4
51 4
24 4
9
56 4
57 4
58 4
59 4
55 20
46 4
40 4
52 4
53 4
59
56 128
57 128
58 128
59 128
18 16
27 20
0 4
1 4
2 4
8 8
21 16
22 16
9 8
3 4
19 16
39 28
42 28
41 28
37 24
10 8
15 12
4 4
5 4
34 24
48 32
50 32
43 28
44 32
33 24
30 20
45 28
49 32
29 20
38 28
11 8
12 8
23 16
47 32
46 28
31 20
26 16
14 12
36 24
40 28
54 32
52 32
16 12
28 20
13 8
35 24
32 20
53 32
51 32
17 12
20 16
6 4
24 16
25 16
7 4
56
55 128
18 4
27 5
0 1
1 1
2 1
8 2
21 4
22 4
9 2
3 1
19 4
39 7
42 7
41 7
37 6
10 2
15 3
4 1
5 1
34 6
48 8
50 8
43 7
44 8
33 6
30 5
45 7
49 8
29 5
38 7
11 2
12 2
23 4
47 8
46 7
31 5
26 4
14 3
36 6
40 7
54 8
52 8
16 3
28 5
13 2
35 6
32 5
53 8
51 8
17 3
20 4
6 1
24 4
25 4
7 1
56
55 128
18 4
27 5
0 1
1 1
2 1
8 2
21 4
22 4
9 2
3 1
19 4
39 7
42 7
41 7
37 6
10 2
15 3
4 1
5 1
34 6
48 8
50 8
43 7
44 8
33 6
30 5
45 7
49 8
29 5
38 7
11 2
12 2
23 4
47 8
46 7
31 5
26 4
14 3
36 6
40 7
54 8
52 8
16 3
28 5
13 2
35 6
32 5
53 8
51 8
17 3
20 4
6 1
24 4
25 4
7 1
56
55 128
18 4
27 5
0 1
1 1
2 1
8 2
21 4
22 4
9 2
3 1
19 4
39 7
42 7
41 7
37 6
10 2
15 3
4 1
5 1
34 6
48 8
50 8
43 7
44 8
33 6
30 5
45 7
49 8
29 5
38 7
11 2
12 2
23 4
47 8
46 7
31 5
26 4
14 3
36 6
40 7
54 8
52 8
16 3
28 5
13 2
35 6
32 5
53 8
51 8
17 3
20 4
6 1
24 4
25 4
7 1
56
55 128
18 4
27 5
0 1
1 1
2 1
8 2
21 4
22 4
9 2
3 1
19 4
39 7
42 7
41 7
37 6
10 2
15 3
4 1
5 1
34 6
48 8
50 8
43 7
44 8
33 6
30 5
45 7
49 8
29 5
38 7
11 2
12 2
23 4
47 8
46 7
31 5
26 4
14 3
36 6
40 7
54 8
52 8
16 3
28 5
13 2
35 6
32 5
53 8
51 8
17 3
20 4
6 1
24 4
25 4
7 1
end_CG
