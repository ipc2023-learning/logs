begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var6
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var3
-1
42
Atom at-robot(loc_10_3)
Atom at-robot(loc_10_4)
Atom at-robot(loc_10_6)
Atom at-robot(loc_11_4)
Atom at-robot(loc_11_5)
Atom at-robot(loc_11_6)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_10)
Atom at-robot(loc_8_11)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_8)
Atom at-robot(loc_8_9)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_6)
end_variable
begin_variable
var0
-1
37
Atom at(box1, loc_10_4)
Atom at(box1, loc_10_6)
Atom at(box1, loc_11_4)
Atom at(box1, loc_11_6)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
Atom at(box1, loc_8_8)
Atom at(box1, loc_9_4)
Atom at(box1, loc_9_5)
Atom at(




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





323
2
37 39
21 0
2
1
311
2
37 36
12 0
32
119
2
37 2
25 0
end_DTG
begin_DTG
2
2
318
2
37 39
0 0
34
123
2
37 3
20 0
2
3
330
2
37 41
1 0
36
126
2
37 5
21 0
0
0
0
2
4
141
2
37 8
7 0
6
129
2
37 6
16 0
2
5
147
2
37 9
17 0
7
135
2
37 7
2 0
0
0
4
4
171
2
37 15
7 0
8
156
2
37 12
3 0
10
150
2
37 10
29 0
13
132
2
37 6
18 0
4
5
177
2
37 16
17 0
9
162
2
37 13
22 0
11
153
2
37 11
19 0
14
138
2
37 7
31 0
2
6
186
2
37 17
16 0
15
144
2
37 8
23 0
0
2
12
180
2
37 16
4 0
14
168
2
37 14
31 0
4
10
195
2
37 18
29 0
13
189
2
37 17
18 0
15
174
2
37 15
23 0
16
159
2
37 12
27 0
2
11
204
2
37 19
19 0
17
165
2
37 13
30 0
2
14
216
2
37 21
31 0
19
183
2
37 16
28 0
4
15
225
2
37 22
23 0
16
210
2
37 20
27 0
18
198
2
37 18
8 0
20
192
2
37 17
34 0
0
2
16
255
2
37 27
27 0
25
201
2
37 18
32 0
4
17
264
2
37 28
30 0
19
234
2
37 23
28 0
21
219
2
37 21
33 0
26
207
2
37 19
36 0
4
18
276
2
37 29
8 0
20
243
2
37 24
34 0
22
228
2
37 22
13 0
27
213
2
37 20
35 0
2
21
246
2
37 25
33 0
23
237
2
37 23
9 0
0
0
4
19
294
2
37 34
28 0
24
267
2
37 28
5 0
26
252
2
37 26
36 0
30
222
2
37 21
24 0
4
20
303
2
37 35
34 0
25
279
2
37 29
32 0
27
258
2
37 27
35 0
31
231
2
37 22
26 0
4
21
306
2
37 36
33 0
26
288
2
37 30
36 0
28
270
2
37 28
14 0
32
240
2
37 23
25 0
2
27
291
2
37 31
35 0
29
282
2
37 29
10 0
2
23
315
2
37 37
9 0
33
249
2
37 25
6 0
2
25
321
2
37 39
32 0
34
261
2
37 27
20 0
4
26
327
2
37 40
36 0
30
309
2
37 36
24 0
32
297
2
37 34
25 0
35
273
2
37 28
15 0
2
27
333
2
37 41
35 0
36
285
2
37 29
21 0
0
2
0
300
2
37 34
11 0
30
117
2
37 1
24 0
2
34
336
2
37 41
20 0
36
324
2
37 39
21 0
2
1
312
2
37 36
12 0
32
120
2
37 2
25 0
end_DTG
begin_DTG
2
2
319
2
37 39
0 0
34
124
2
37 3
20 0
2
3
331
2
37 41
1 0
36
127
2
37 5
21 0
0
0
0
2
4
142
2
37 8
7 0
6
130
2
37 6
16 0
2
5
148
2
37 9
17 0
7
136
2
37 7
2 0
0
0
4
4
172
2
37 15
7 0
8
157
2
37 12
3 0
10
151
2
37 10
29 0
13
133
2
37 6
18 0
4
5
178
2
37 16
17 0
9
163
2
37 13
22 0
11
154
2
37 11
19 0
14
139
2
37 7
31 0
2
6
187
2
37 17
16 0
15
145
2
37 8
23 0
0
2
12
181
2
37 16
4 0
14
169
2
37 14
31 0
4
10
196
2
37 18
29 0
13
190
2
37 17
18 0
15
175
2
37 15
23 0
16
160
2
37 12
27 0
2
11
205
2
37 19
19 0
17
166
2
37 13
30 0
2
14
217
2
37 21
31 0
19
184
2
37 16
28 0
4
15
226
2
37 22
23 0
16
211
2
37 20
27 0
18
199
2
37 18
8 0
20
193
2
37 17
34 0
0
2
16
256
2
37 27
27 0
25
202
2
37 18
32 0
4
17
265
2
37 28
30 0
19
235
2
37 23
28 0
21
220
2
37 21
33 0
26
208
2
37 19
36 0
4
18
277
2
37 29
8 0
20
244
2
37 24
34 0
22
229
2
37 22
13 0
27
214
2
37 20
35 0
2
21
247
2
37 25
33 0
23
238
2
37 23
9 0
0
0
4
19
295
2
37 34
28 0
24
268
2
37 28
5 0
26
253
2
37 26
36 0
30
223
2
37 21
24 0
4
20
304
2
37 35
34 0
25
280
2
37 29
32 0
27
259
2
37 27
35 0
31
232
2
37 22
26 0
4
21
307
2
37 36
33 0
26
289
2
37 30
36 0
28
271
2
37 28
14 0
32
241
2
37 23
25 0
2
27
292
2
37 31
35 0
29
283
2
37 29
10 0
2
23
316
2
37 37
9 0
33
250
2
37 25
6 0
2
25
322
2
37 39
32 0
34
262
2
37 27
20 0
4
26
328
2
37 40
36 0
30
310
2
37 36
24 0
32
298
2
37 34
25 0
35
274
2
37 28
15 0
2
27
334
2
37 41
35 0
36
286
2
37 29
21 0
0
2
0
301
2
37 34
11 0
30
118
2
37 1
24 0
2
34
337
2
37 41
20 0
36
325
2
37 39
21 0
2
1
313
2
37 36
12 0
32
121
2
37 2
25 0
end_DTG
begin_CG
5
38 1
39 1
40 1
37 5
11 3
5
38 1
39 1
40 1
37 5
12 3
5
38 1
39 1
40 1
37 4
16 3
5
38 1
39 1
40 1
37 5
22 3
5
38 1
39 1
40 1
37 5
18 3
5
38 1
39 1
40 1
37 4
32 3
5
38 1
39 1
40 1
37 5
10 3
6
38 2
39 2
40 2
37 8
17 3
22 3
6
38 2
39 2
40 2
37 8
30 3
33 3
6
38 2
39 2
40 2
37 8
13 3
10 3
5
38 1
39 1
40 1
37 6
14 3
5
38 1
39 1
40 1
37 6
20 3
5
38 1
39 1
40 1
37 5
21 3
5
38 1
39 1
40 1
37 6
33 3
5
38 1
39 1
40 1
37 6
35 3
5
38 1
39 1
40 1
37 6
26 3
6
38 2
39 2
40 2
37 9
17 3
19 3
6
38 2
39 2
40 2
37 9
16 3
29 3
6
38 2
39 2
40 2
37 9
22 3
31 3
6
38 2
39 2
40 2
37 9
29 3
23 3
7
38 3
39 3
40 3
37 12
11 3
24 3
15 3
7
38 3
39 3
40 3
37 12
12 3
25 3
15 3
5
38 1
39 1
40 1
37 7
29 3
7
38 3
39 3
40 3
37 12
19 3
31 3
30 3
7
38 3
39 3
40 3
37 12
32 3
26 3
20 3
7
38 3
39 3
40 3
37 12
35 3
26 3
21 3
5
38 1
39 1
40 1
37 7
36 3
7
38 3
39 3
40 3
37 12
31 3
30 3
28 3
7
38 3
39 3
40 3
37 12
27 3
34 3
32 3
6
38 2
39 2
40 2
37 10
22 3
31 3
6
38 2
39 2
40 2
37 10
23 3
34 3
7
38 3
39 3
40 3
37 13
29 3
18 3
27 3
7
38 3
39 3
40 3
37 13
28 3
36 3
24 3
7
38 3
39 3
40 3
37 13
34 3
13 3
35 3
7
38 3
39 3
40 3
37 13
30 3
33 3
36 3
8
38 4
39 4
40 4
37 16
33 3
36 3
14 3
25 3
8
38 4
39 4
40 4
37 16
34 3
32 3
35 3
26 3
40
38 74
39 74
40 74
11 9
12 9
0 3
1 3
7 6
17 12
16 12
2 3
3 3
22 15
29 18
19 12
4 3
18 12
31 21
23 15
27 15
30 18
8 6
28 15
34 21
33 21
13 9
9 6
5 3
32 21
36 24
35 24
14 9
10 9
24 15
26 15
25 15
6 3
20 15
15 9
21 15
38
37 74
11 3
12 3
0 1
1 1
7 2
17 4
16 4
2 1
3 1
22 5
29 6
19 4
4 1
18 4
31 7
23 5
27 5
30 6
8 2
28 5
34 7
33 7
13 3
9 2
5 1
32 7
36 8
35 8
14 3
10 3
24 5
26 5
25 5
6 1
20 5
15 3
21 5
38
37 74
11 3
12 3
0 1
1 1
7 2
17 4
16 4
2 1
3 1
22 5
29 6
19 4
4 1
18 4
31 7
23 5
27 5
30 6
8 2
28 5
34 7
33 7
13 3
9 2
5 1
32 7
36 8
35 8
14 3
10 3
24 5
26 5
25 5
6 1
20 5
15 3
21 5
38
37 74
11 3
12 3
0 1
1 1
7 2
17 4
16 4
2 1
3 1
22 5
29 6
19 4
4 1
18 4
31 7
23 5
27 5
30 6
8 2
28 5
34 7
33 7
13 3
9 2
5 1
32 7
36 8
35 8
14 3
10 3
24 5
26 5
25 5
6 1
20 5
15 3
21 5
end_CG
