begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var20
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var2
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var1
-1
22
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
end_variable
22
begin_mutex_group
2
23 0
4 0
end_mutex_group
begin_mutex_group
2
23 1
10 0
end_mutex_group
begin_mutex_group
2
23 2
14 0
end_mutex_group
begin_mutex_group
2
23 3
13 0
end_mutex_group
begin_mutex_group
2
23 4
5 0
end_mutex_group
begin_mutex_group
2
23 5
11 0
end_mutex_group
begin_mutex_group
2
23 6
20 0
end_mutex_group
begin_mutex_group
2
23 7
19 0
end_mutex_group
begin_mutex_group
2
23 8
21 0
end_mutex_group
begin_mutex_group
2
23 9
15 0
end_mutex_group
begin_mutex_group
2
23 10
12 0
end_mutex_group
begin_mutex_group
2
23 11
17 0
end_mutex_group
begin_mutex_group
2
23 12
18 0
end_mutex_group
begin_mutex_group
2
23 13
16 0
end_mutex_group
begin_mutex_group
2
23 14
6 0
end_mutex_group
begin_mutex_group
2
23 15
7 0
end_mutex_group
begin_mutex_group
2
23 16
8 0
end_mutex_group
begin_mutex_group
2
23 17
9 0
end_mutex_group
begin_mutex_group
2
23 18
0 0
end_mutex_group
begin_mutex_group
2
23 19
1 0
end_mutex_group
begin_mutex_group
2
23 20
2 0
end_mutex_group
begin_mutex_group
2
23 21
3 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
19
11
end_state
begin_goal
1
23 20
end_goal
98
begin_operator
move loc_2_2 loc_2_3 right
1
10 0
1
0 22 0 1
0
end_operator
begin_operator
move loc_2_2 loc_3_2 down
1
11 0
1
0 22 0 5
0
end_operator
begin_operator
move loc_2_3 loc_2_2 left
1
4 0
1
0 22 1 0
0
end_operator
begin_operator
move loc_2_3 loc_2_4 right
1
14 0
1
0 22 1 2
0
end_operator
begin_operator
move loc_2_3 loc_3_3 down
1
20 0
1
0 22 1 6
0
end_operator
begin_operator
move loc_2_4 loc_2_3 left
1
10 0
1
0 22 2 1
0
end_operator
begin_operator
move loc_2_4 loc_2_5 right
1
13 0
1
0 22 2 3
0
end_operator
begin_operator
move loc_2_4 loc_3_4 down
1
19 0
1
0 22 2 7
0
end_operator
begin_operator
move loc_2_5 loc_2_4 left
1
14 0
1
0 22 3 2
0
end_operator
begin_operator
move loc_2_5 loc_2_6 right
1
5 0
1
0 22 3 4
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
21 0
1
0 22 3 8
0
end_operator
begin_operator
move loc_2_6 loc_2_5 left
1
13 0
1
0 22 4 3
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
15 0
1
0 22 4 9
0
end_operator
begin




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





switch 3
check 0
check 1
53
check 0
check 0
switch 6
check 0
check 1
54
check 0
switch 1
check 0
check 1
55
check 0
check 0
switch 7
check 0
check 1
56
check 0
switch 0
check 0
check 1
57
check 0
check 0
switch 8
check 0
check 1
58
check 0
switch 3
check 0
check 1
59
check 0
check 0
switch 9
check 0
check 1
60
check 0
switch 2
check 0
check 1
61
check 0
check 0
check 0
end_SG
begin_DTG
1
1
83
2
23 14
22 10
0
end_DTG
begin_DTG
1
1
85
2
23 15
22 11
0
end_DTG
begin_DTG
1
1
87
2
23 16
22 12
0
end_DTG
begin_DTG
1
1
89
2
23 17
22 13
0
end_DTG
begin_DTG
2
1
66
2
23 1
22 2
1
82
2
23 5
22 10
0
end_DTG
begin_DTG
2
1
67
2
23 3
22 2
1
88
2
23 9
22 13
0
end_DTG
begin_DTG
1
1
73
2
23 10
22 5
2
0
83
3
23 14
22 10
0 0
0
94
3
23 14
22 18
12 0
end_DTG
begin_DTG
1
1
75
2
23 11
22 6
2
0
85
3
23 15
22 11
1 0
0
95
3
23 15
22 19
17 0
end_DTG
begin_DTG
1
1
79
2
23 12
22 8
2
0
87
3
23 16
22 12
2 0
0
96
3
23 16
22 20
18 0
end_DTG
begin_DTG
1
1
81
2
23 13
22 9
2
0
89
3
23 17
22 13
3 0
0
97
3
23 17
22 21
16 0
end_DTG
begin_DTG
2
1
68
2
23 2
22 3
1
84
2
23 6
22 11
2
0
62
3
23 1
22 0
14 0
0
66
3
23 1
22 2
4 0
end_DTG
begin_DTG
2
1
76
2
23 6
22 7
1
90
2
23 10
22 14
2
0
63
3
23 5
22 0
12 0
0
82
3
23 5
22 10
4 0
end_DTG
begin_DTG
2
1
63
2
23 5
22 0
1
94
2
23 14
22 18
2
0
73
3
23 10
22 5
6 0
0
90
3
23 10
22 14
11 0
end_DTG
begin_DTG
2
1
64
2
23 2
22 1
1
86
2
23 8
22 12
2
0
67
3
23 3
22 2
5 0
0
70
3
23 3
22 4
14 0
end_DTG
begin_DTG
2
1
62
2
23 1
22 0
1
70
2
23 3
22 4
2
0
64
3
23 2
22 1
13 0
0
68
3
23 2
22 3
10 0
end_DTG
begin_DTG
2
1
77
2
23 8
22 7
1
93
2
23 13
22 17
2
0
71
3
23 9
22 4
16 0
0
88
3
23 9
22 13
5 0
end_DTG
begin_DTG
2
1
71
2
23 9
22 4
1
97
2
23 17
22 21
2
0
81
3
23 13
22 9
9 0
0
93
3
23 13
22 17
15 0
end_DTG
begin_DTG
2
1
65
2
23 6
22 1
1
95
2
23 15
22 19
2
0
75
3
23 11
22 6
7 0
0
91
3
23 11
22 15
20 0
end_DTG
begin_DTG
2
1
69
2
23 8
22 3
1
96
2
23 16
22 20
2
0
79
3
23 12
22 8
8 0
0
92
3
23 12
22 16
21 0
end_DTG
begin_DTG
2
1
72
2
23 6
22 5
1
80
2
23 8
22 9
2
0
74
3
23 7
22 6
21 0
0
78
3
23 7
22 8
20 0
end_DTG
begin_DTG
2
1
78
2
23 7
22 8
1
91
2
23 11
22 15
4
0
65
3
23 6
22 1
17 0
0
72
3
23 6
22 5
19 0
0
76
3
23 6
22 7
11 0
0
84
3
23 6
22 11
10 0
end_DTG
begin_DTG
2
1
74
2
23 7
22 6
1
92
2
23 12
22 16
4
0
69
3
23 8
22 3
18 0
0
77
3
23 8
22 7
15 0
0
80
3
23 8
22 9
19 0
0
86
3
23 8
22 12
13 0
end_DTG
begin_DTG
4
1
0
1
10 0
1
62
2
23 1
14 0
5
1
1
11 0
5
63
2
23 5
12 0
5
0
2
1
4 0
2
3
1
14 0
2
64
2
23 2
13 0
6
4
1
20 0
6
65
2
23 6
17 0
5
1
5
1
10 0
1
66
2
23 1
4 0
3
6
1
13 0
3
67
2
23 3
5 0
7
7
1
19 0
5
2
8
1
14 0
2
68
2
23 2
10 0
4
9
1
5 0
8
10
1
21 0
8
69
2
23 8
18 0
4
3
11
1
13 0
3
70
2
23 3
14 0
9
12
1
15 0
9
71
2
23 9
16 0
5
0
13
1
4 0
6
14
1
20 0
6
72
2
23 6
19 0
10
15
1
12 0
10
73
2
23 10
6 0
6
1
16
1
10 0
5
17
1
11 0
7
18
1
19 0
7
74
2
23 7
21 0
11
19
1
17 0
11
75
2
23 11
7 0
5
2
20
1
14 0
6
21
1
20 0
6
76
2
23 6
11 0
8
22
1
21 0
8
77
2
23 8
15 0
6
3
23
1
13 0
7
24
1
19 0
7
78
2
23 7
20 0
9
25
1
15 0
12
26
1
18 0
12
79
2
23 12
8 0
5
4
27
1
5 0
8
28
1
21 0
8
80
2
23 8
19 0
13
29
1
16 0
13
81
2
23 13
9 0
5
5
30
1
11 0
5
82
2
23 5
4 0
11
31
1
17 0
14
32
1
6 0
14
83
2
23 14
0 0
5
6
33
1
20 0
6
84
2
23 6
10 0
10
34
1
12 0
15
35
1
7 0
15
85
2
23 15
1 0
5
8
36
1
21 0
8
86
2
23 8
13 0
13
37
1
16 0
16
38
1
8 0
16
87
2
23 16
2 0
5
9
39
1
15 0
9
88
2
23 9
5 0
12
40
1
18 0
17
41
1
9 0
17
89
2
23 17
3 0
4
10
42
1
12 0
10
90
2
23 10
11 0
15
43
1
7 0
18
44
1
0 0
4
11
45
1
17 0
11
91
2
23 11
20 0
14
46
1
6 0
19
47
1
1 0
4
12
48
1
18 0
12
92
2
23 12
21 0
17
49
1
9 0
20
50
1
2 0
4
13
51
1
16 0
13
93
2
23 13
15 0
16
52
1
8 0
21
53
1
3 0
3
14
54
1
6 0
14
94
2
23 14
12 0
19
55
1
1 0
3
15
56
1
7 0
15
95
2
23 15
17 0
18
57
1
0 0
3
16
58
1
8 0
16
96
2
23 16
18 0
21
59
1
3 0
3
17
60
1
9 0
17
97
2
23 17
16 0
20
61
1
2 0
end_DTG
begin_DTG
0
2
0
66
2
22 2
4 0
2
62
2
22 0
14 0
2
1
68
2
22 3
10 0
3
64
2
22 1
13 0
2
2
70
2
22 4
14 0
4
67
2
22 2
5 0
0
2
0
82
2
22 10
4 0
10
63
2
22 0
12 0
4
1
84
2
22 11
10 0
5
76
2
22 7
11 0
7
72
2
22 5
19 0
11
65
2
22 1
17 0
2
6
78
2
22 8
20 0
8
74
2
22 6
21 0
4
3
86
2
22 12
13 0
7
80
2
22 9
19 0
9
77
2
22 7
15 0
12
69
2
22 3
18 0
2
4
88
2
22 13
5 0
13
71
2
22 4
16 0
2
5
90
2
22 14
11 0
14
73
2
22 5
6 0
2
6
91
2
22 15
20 0
15
75
2
22 6
7 0
2
8
92
2
22 16
21 0
16
79
2
22 8
8 0
2
9
93
2
22 17
15 0
17
81
2
22 9
9 0
2
10
94
2
22 18
12 0
18
83
2
22 10
0 0
2
11
95
2
22 19
17 0
19
85
2
22 11
1 0
2
12
96
2
22 20
18 0
20
87
2
22 12
2 0
2
13
97
2
22 21
16 0
21
89
2
22 13
3 0
0
0
0
0
end_DTG
begin_CG
3
23 1
22 3
6 1
3
23 1
22 3
7 1
3
23 1
22 3
8 1
3
23 1
22 3
9 1
4
23 2
22 4
10 1
11 1
4
23 2
22 4
13 1
15 1
3
23 1
22 4
12 1
3
23 1
22 4
17 1
3
23 1
22 4
18 1
3
23 1
22 4
16 1
4
23 2
22 5
14 1
20 1
4
23 2
22 5
20 1
12 1
4
23 2
22 5
11 1
6 1
4
23 2
22 5
14 1
21 1
4
23 2
22 5
10 1
13 1
4
23 2
22 5
21 1
16 1
4
23 2
22 5
15 1
9 1
4
23 2
22 5
20 1
7 1
4
23 2
22 5
21 1
8 1
4
23 2
22 5
20 1
21 1
4
23 2
22 6
19 1
17 1
4
23 2
22 6
19 1
18 1
23
23 36
4 2
10 4
14 4
13 4
5 2
11 4
20 6
19 4
21 6
15 4
12 4
17 4
18 4
16 4
6 3
7 3
8 3
9 3
0 1
1 1
2 1
3 1
23
22 36
4 2
10 4
14 4
13 4
5 2
11 4
20 6
19 4
21 6
15 4
12 4
17 4
18 4
16 4
6 3
7 3
8 3
9 3
0 1
1 1
2 1
3 1
end_CG
