begin_version
3
end_version
begin_metric
0
end_metric
35
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var2
-1
36
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
32
Atom at(box1, loc_2_3)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_2)
Atom at(box1, loc_8_3)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
Atom at(box1, loc_8_7)
Atom at(box1, loc_8_8)
end_variable
begin_variable
var1
-1
32
Atom at(box2, loc_2_3)
Atom at(box2, loc_3_2)
Atom at(box2, loc_3_3)
Atom at(box2, loc_3_6)
Atom at(box2, loc_4_2)
Atom at(box2, loc_4_3)
Atom at(box2, loc_4_4)
Atom at(box2, loc_4_6)
Atom at(box2, loc_5_2)
Atom at(box2, loc_5_3)
Atom at(box2, loc_5_4)
Atom at(box2, loc_5_5)
Atom at(box2, loc_5_6)
Atom at(box2, loc_5_7)
Atom at(box2, loc_6_3)
Atom at(box2, loc_6_4)
Atom at(box2, loc_6_5)
Atom at(box2, loc_6_6)
Atom at(box2, loc_6_7)
Atom at(box2, loc_6_8)
Atom at(box2, loc_7_3)
Atom at(box2, loc_7_5)
Atom at(box2, loc_7_6)
Atom at(box2, loc_7_7)
Atom at(box2, loc_7_8)
Atom at(box2, loc_8_2)
Atom at(box2, loc_8_3)
Atom at(box2, loc_8_4)
Atom a




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
10 0
27
193
2
34 23
10 0
33
76
1
20 0
8
21
77
1
25 0
21
194
2
33 18
6 0
21
195
2
34 18
6 0
26
78
1
27 0
26
196
2
33 22
18 0
26
197
2
34 22
18 0
28
79
1
10 0
34
80
1
15 0
5
22
81
1
7 0
27
82
1
26 0
27
198
2
33 23
27 0
27
199
2
34 23
27 0
35
83
1
8 0
4
23
84
0
30
85
1
14 0
30
200
2
33 26
16 0
30
201
2
34 26
16 0
7
24
86
1
13 0
24
202
2
33 20
19 0
24
203
2
34 20
19 0
29
87
1
3 0
31
88
1
16 0
31
204
2
33 27
21 0
31
205
2
34 27
21 0
6
30
89
1
14 0
30
206
2
33 26
3 0
30
207
2
34 26
3 0
32
90
1
21 0
32
208
2
33 28
20 0
32
209
2
34 28
20 0
9
25
91
1
18 0
25
210
2
33 21
30 0
25
211
2
34 21
30 0
31
92
1
16 0
31
212
2
33 27
14 0
31
213
2
34 27
14 0
33
93
1
20 0
33
214
2
33 29
15 0
33
215
2
34 29
15 0
9
26
94
1
27 0
26
216
2
33 22
31 0
26
217
2
34 22
31 0
32
95
1
21 0
32
218
2
33 28
16 0
32
219
2
34 28
16 0
34
96
1
15 0
34
220
2
33 30
8 0
34
221
2
34 30
8 0
7
27
97
1
26 0
27
222
2
33 23
25 0
27
223
2
34 23
25 0
33
98
1
20 0
33
224
2
33 29
21 0
33
225
2
34 29
21 0
35
99
1
8 0
6
28
100
1
10 0
28
226
2
33 24
7 0
28
227
2
34 24
7 0
34
101
1
15 0
34
228
2
33 30
20 0
34
229
2
34 30
20 0
end_DTG
begin_DTG
0
0
2
0
112
2
32 8
0 0
5
102
2
32 0
23 0
0
2
1
122
2
32 11
1 0
8
104
2
32 3
5 0
4
2
126
2
32 12
11 0
4
116
2
32 9
9 0
6
110
2
32 7
4 0
9
106
2
32 4
28 0
0
2
3
142
2
32 15
2 0
12
108
2
32 6
29 0
0
4
5
152
2
32 17
23 0
8
132
2
32 13
5 0
10
124
2
32 11
24 0
14
114
2
32 8
19 0
4
6
158
2
32 18
4 0
9
136
2
32 14
28 0
11
128
2
32 12
22 0
15
118
2
32 9
17 0
2
10
144
2
32 15
24 0
12
134
2
32 13
29 0
4
7
168
2
32 20
12 0
11
148
2
32 16
22 0
13
138
2
32 14
6 0
17
120
2
32 10
31 0
0
2
9
184
2
32 24
28 0
20
130
2
32 12
13 0
2
14
162
2
32 19
19 0
16
154
2
32 17
30 0
4
11
186
2
32 25
22 0
15
170
2
32 20
17 0
17
160
2
32 18
31 0
21
140
2
32 14
18 0
4
12
190
2
32 26
29 0
16
176
2
32 21
30 0
18
164
2
32 19
25 0
22
146
2
32 15
27 0
4
13
194
2
32 27
6 0
17
180
2
32 22
31 0
19
172
2
32 20
7 0
23
150
2
32 16
26 0
0
2
14
202
2
32 30
19 0
26
156
2
32 17
14 0
2
16
210
2
32 32
30 0
28
166
2
32 19
21 0
4
17
216
2
32 33
31 0
21
196
2
32 27
18 0
23
188
2
32 25
26 0
29
174
2
32 20
20 0
4
18
222
2
32 34
25 0
22
198
2
32 28
27 0
24
192
2
32 26
10 0
30
178
2
32 21
15 0
2
19
226
2
32 35
7 0
31
182
2
32 22
8 0
0
2
25
206
2
32 31
3 0
27
200
2
32 29
16 0
2
26
212
2
32 32
14 0
28
204
2
32 30
21 0
2
27
218
2
32 33
16 0
29
208
2
32 31
20 0
2
28
224
2
32 34
21 0
30
214
2
32 32
15 0
2
29
228
2
32 35
20 0
31
220
2
32 33
8 0
0
end_DTG
begin_DTG
0
0
2
0
113
2
32 8
0 0
5
103
2
32 0
23 0
0
2
1
123
2
32 11
1 0
8
105
2
32 3
5 0
4
2
127
2
32 12
11 0
4
117
2
32 9
9 0
6
111
2
32 7
4 0
9
107
2
32 4
28 0
0
2
3
143
2
32 15
2 0
12
109
2
32 6
29 0
0
4
5
153
2
32 17
23 0
8
133
2
32 13
5 0
10
125
2
32 11
24 0
14
115
2
32 8
19 0
4
6
159
2
32 18
4 0
9
137
2
32 14
28 0
11
129
2
32 12
22 0
15
119
2
32 9
17 0
2
10
145
2
32 15
24 0
12
135
2
32 13
29 0
4
7
169
2
32 20
12 0
11
149
2
32 16
22 0
13
139
2
32 14
6 0
17
121
2
32 10
31 0
0
2
9
185
2
32 24
28 0
20
131
2
32 12
13 0
2
14
163
2
32 19
19 0
16
155
2
32 17
30 0
4
11
187
2
32 25
22 0
15
171
2
32 20
17 0
17
161
2
32 18
31 0
21
141
2
32 14
18 0
4
12
191
2
32 26
29 0
16
177
2
32 21
30 0
18
165
2
32 19
25 0
22
147
2
32 15
27 0
4
13
195
2
32 27
6 0
17
181
2
32 22
31 0
19
173
2
32 20
7 0
23
151
2
32 16
26 0
0
2
14
203
2
32 30
19 0
26
157
2
32 17
14 0
2
16
211
2
32 32
30 0
28
167
2
32 19
21 0
4
17
217
2
32 33
31 0
21
197
2
32 27
18 0
23
189
2
32 25
26 0
29
175
2
32 20
20 0
4
18
223
2
32 34
25 0
22
199
2
32 28
27 0
24
193
2
32 26
10 0
30
179
2
32 21
15 0
2
19
227
2
32 35
7 0
31
183
2
32 22
8 0
0
2
25
207
2
32 31
3 0
27
201
2
32 29
16 0
2
26
213
2
32 32
14 0
28
205
2
32 30
21 0
2
27
219
2
32 33
16 0
29
209
2
32 31
20 0
2
28
225
2
32 34
21 0
30
215
2
32 32
15 0
2
29
229
2
32 35
20 0
31
221
2
32 33
8 0
0
end_DTG
begin_CG
4
33 1
34 1
32 4
11 2
4
33 1
34 1
32 4
9 2
4
33 1
34 1
32 4
12 2
4
33 1
34 1
32 4
14 2
5
33 2
34 2
32 6
23 2
24 2
5
33 2
34 2
32 6
9 2
28 2
5
33 2
34 2
32 6
29 2
25 2
5
33 2
34 2
32 6
25 2
10 2
5
33 2
34 2
32 6
10 2
15 2
4
33 1
34 1
32 5
23 2
4
33 1
34 1
32 5
26 2
4
33 1
34 1
32 5
23 2
4
33 1
34 1
32 4
29 2
4
33 1
34 1
32 5
19 2
5
33 2
34 2
32 7
13 2
16 2
5
33 2
34 2
32 7
26 2
20 2
5
33 2
34 2
32 6
14 2
21 2
5
33 2
34 2
32 7
24 2
30 2
5
33 2
34 2
32 7
30 2
27 2
6
33 3
34 3
32 9
28 2
17 2
13 2
6
33 3
34 3
32 9
27 2
21 2
15 2
6
33 3
34 3
32 9
18 2
16 2
20 2
6
33 3
34 3
32 9
24 2
29 2
30 2
5
33 2
34 2
32 8
11 2
28 2
5
33 2
34 2
32 8
28 2
22 2
5
33 2
34 2
32 8
31 2
26 2
5
33 2
34 2
32 8
25 2
27 2
5
33 2
34 2
32 8
31 2
26 2
6
33 3
34 3
32 10
23 2
24 2
19 2
6
33 3
34 3
32 10
12 2
22 2
31 2
6
33 3
34 3
32 10
17 2
31 2
18 2
7
33 4
34 4
32 12
29 2
30 2
25 2
27 2
34
33 64
34 64
0 2
1 2
11 6
2 2
9 6
23 12
4 4
12 6
5 4
28 14
24 12
22 10
29 14
6 4
19 10
17 8
30 14
31 16
25 12
7 4
13 6
18 8
27 12
26 12
10 6
3 2
14 8
16 8
21 10
20 10
15 8
8 4
33
32 64
0 1
1 1
11 3
2 1
9 3
23 6
4 2
12 3
5 2
28 7
24 6
22 5
29 7
6 2
19 5
17 4
30 7
31 8
25 6
7 2
13 3
18 4
27 6
26 6
10 3
3 1
14 4
16 4
21 5
20 5
15 4
8 2
33
32 64
0 1
1 1
11 3
2 1
9 3
23 6
4 2
12 3
5 2
28 7
24 6
22 5
29 7
6 2
19 5
17 4
30 7
31 8
25 6
7 2
13 3
18 4
27 6
26 6
10 3
3 1
14 4
16 4
21 5
20 5
15 4
8 2
end_CG
