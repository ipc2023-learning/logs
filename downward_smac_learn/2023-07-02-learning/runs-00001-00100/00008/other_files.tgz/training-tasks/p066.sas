begin_version
3
end_version
begin_metric
0
end_metric
54
begin_variable
var4
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var3
-1
52
Atom at-robot(loc_10_3)
Atom at-robot(loc_10_4)
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_10_8)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_2)
Atom at-




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
42
161
2
50 1
22 0
0
4
5
464
2
50 45
7 0
44
182
2
50 5
30 0
47
482
2
50 51
6 0
49
473
2
50 49
10 0
0
end_DTG
begin_DTG
0
2
0
165
2
50 2
0 0
2
156
2
50 0
21 0
2
1
171
2
50 3
15 0
3
159
2
50 1
20 0
2
2
177
2
50 4
21 0
4
168
2
50 2
13 0
2
3
180
2
50 5
20 0
5
174
2
50 3
7 0
0
0
2
6
195
2
50 8
1 0
8
186
2
50 6
17 0
2
7
201
2
50 9
16 0
9
189
2
50 7
8 0
0
2
7
249
2
50 16
16 0
16
192
2
50 7
28 0
4
8
258
2
50 17
17 0
10
219
2
50 12
23 0
12
207
2
50 10
41 0
17
198
2
50 8
45 0
4
9
267
2
50 18
8 0
11
228
2
50 13
38 0
13
213
2
50 11
26 0
18
204
2
50 9
47 0
2
12
237
2
50 14
41 0
14
222
2
50 12
18 0
2
13
243
2
50 15
26 0
15
231
2
50 13
9 0
0
2
10
306
2
50 24
23 0
24
210
2
50 10
48 0
4
11
318
2
50 25
38 0
16
270
2
50 18
28 0
18
252
2
50 16
47 0
25
216
2
50 11
49 0
4
12
330
2
50 26
41 0
17
279
2
50 19
45 0
19
261
2
50 17
43 0
26
225
2
50 12
46 0
4
13
339
2
50 27
26 0
18
288
2
50 20
47 0
20
273
2
50 18
37 0
27
234
2
50 13
44 0
4
14
348
2
50 28
18 0
19
294
2
50 21
43 0
21
282
2
50 19
19 0
28
240
2
50 14
42 0
2
15
357
2
50 29
9 0
29
246
2
50 15
27 0
0
2
22
309
2
50 24
2 0
24
300
2
50 22
48 0
4
16
366
2
50 31
28 0
23
321
2
50 25
11 0
25
303
2
50 23
49 0
30
255
2
50 16
29 0
4
17
375
2
50 32
45 0
24
333
2
50 26
48 0
26
312
2
50 24
46 0
31
264
2
50 17
40 0
4
18
384
2
50 33
47 0
25
342
2
50 27
49 0
27
324
2
50 25
44 0
32
276
2
50 18
35 0
4
19
393
2
50 34
43 0
26
351
2
50 28
46 0
28
336
2
50 26
42 0
33
285
2
50 19
34 0
4
20
402
2
50 35
37 0
27
360
2
50 29
44 0
29
345
2
50 27
27 0
34
291
2
50 20
39 0
2
21
411
2
50 36
19 0
35
297
2
50 21
31 0
2
24
423
2
50 38
48 0
37
315
2
50 24
24 0
4
25
429
2
50 39
49 0
30
387
2
50 33
29 0
32
369
2
50 31
35 0
38
327
2
50 25
12 0
2
31
396
2
50 34
40 0
33
378
2
50 32
34 0
2
32
405
2
50 35
35 0
34
390
2
50 33
39 0
4
28
432
2
50 40
42 0
33
414
2
50 36
34 0
35
399
2
50 34
31 0
39
354
2
50 28
32 0
2
29
441
2
50 41
27 0
40
363
2
50 29
36 0
0
2
30
450
2
50 43
29 0
42
372
2
50 31
22 0
2
31
456
2
50 44
40 0
43
381
2
50 32
5 0
2
34
459
2
50 45
39 0
44
408
2
50 35
30 0
4
35
468
2
50 46
31 0
36
435
2
50 40
3 0
39
420
2
50 37
32 0
45
417
2
50 36
33 0
0
2
37
471
2
50 48
24 0
46
426
2
50 38
14 0
0
2
39
477
2
50 50
32 0
48
438
2
50 40
25 0
4
40
480
2
50 51
36 0
41
462
2
50 45
4 0
44
447
2
50 42
30 0
49
444
2
50 41
10 0
2
1
453
2
50 43
15 0
42
162
2
50 1
22 0
0
4
5
465
2
50 45
7 0
44
183
2
50 5
30 0
47
483
2
50 51
6 0
49
474
2
50 49
10 0
0
end_DTG
begin_CG
5
51 1
52 1
53 1
50 5
15 3
5
51 1
52 1
53 1
50 4
16 3
5
51 1
52 1
53 1
50 5
11 3
5
51 1
52 1
53 1
50 5
36 3
5
51 1
52 1
53 1
50 5
33 3
5
51 1
52 1
53 1
50 5
12 3
5
51 1
52 1
53 1
50 5
25 3
6
51 2
52 2
53 2
50 8
13 3
25 3
6
51 2
52 2
53 2
50 8
17 3
41 3
6
51 2
52 2
53 2
50 8
18 3
19 3
6
51 2
52 2
53 2
50 8
33 3
25 3
5
51 1
52 1
53 1
50 5
48 3
5
51 1
52 1
53 1
50 6
40 3
5
51 1
52 1
53 1
50 6
20 3
5
51 1
52 1
53 1
50 6
22 3
6
51 2
52 2
53 2
50 9
21 3
14 3
6
51 2
52 2
53 2
50 9
17 3
23 3
6
51 2
52 2
53 2
50 9
16 3
38 3
6
51 2
52 2
53 2
50 9
26 3
37 3
6
51 2
52 2
53 2
50 9
37 3
27 3
6
51 2
52 2
53 2
50 8
21 3
13 3
6
51 2
52 2
53 2
50 8
15 3
20 3
6
51 2
52 2
53 2
50 9
24 3
14 3
6
51 2
52 2
53 2
50 9
38 3
28 3
6
51 2
52 2
53 2
50 9
29 3
22 3
5
51 1
52 1
53 1
50 7
30 3
7
51 3
52 3
53 3
50 12
41 3
18 3
43 3
7
51 3
52 3
53 3
50 12
19 3
42 3
31 3
7
51 3
52 3
53 3
50 12
23 3
45 3
48 3
7
51 3
52 3
53 3
50 12
48 3
40 3
24 3
7
51 3
52 3
53 3
50 12
32 3
33 3
25 3
7
51 3
52 3
53 3
50 12
27 3
39 3
36 3
7
51 3
52 3
53 3
50 12
39 3
36 3
30 3
5
51 1
52 1
53 1
50 7
36 3
7
51 3
52 3
53 3
50 12
44 3
35 3
39 3
7
51 3
52 3
53 3
50 12
46 3
40 3
34 3
6
51 2
52 2
53 2
50 10
31 3
33 3
6
51 2
52 2
53 2
50 10
43 3
42 3
6
51 2
52 2
53 2
50 10
41 3
45 3
7
51 3
52 3
53 3
50 13
42 3
34 3
32 3
7
51 3
52 3
53 3
50 13
49 3
35 3
12 3
7
51 3
52 3
53 3
50 13
38 3
26 3
47 3
7
51 3
52 3
53 3
50 13
37 3
44 3
39 3
7
51 3
52 3
53 3
50 13
47 3
37 3
44 3
7
51 3
52 3
53 3
50 13
43 3
46 3
42 3
7
51 3
52 3
53 3
50 13
38 3
47 3
49 3
7
51 3
52 3
53 3
50 13
47 3
49 3
44 3
8
51 4
52 4
53 4
50 16
41 3
45 3
43 3
46 3
8
51 4
52 4
53 4
50 16
28 3
11 3
49 3
29 3
8
51 4
52 4
53 4
50 16
45 3
48 3
46 3
40 3
53
51 110
52 110
53 110
0 3
15 12
21 12
20 12
13 9
7 6
1 3
16 12
17 12
8 6
23 12
38 18
41 21
26 15
18 12
9 6
28 15
45 21
47 24
43 21
37 18
19 12
2 3
11 9
48 24
49 24
46 21
44 21
42 21
27 15
29 15
40 21
35 15
34 15
39 21
31 15
3 3
24 12
12 9
32 15
36 18
4 3
22 12
5 3
30 15
33 15
14 9
6 3
25 15
10 6
51
50 110
0 1
15 4
21 4
20 4
13 3
7 2
1 1
16 4
17 4
8 2
23 4
38 6
41 7
26 5
18 4
9 2
28 5
45 7
47 8
43 7
37 6
19 4
2 1
11 3
48 8
49 8
46 7
44 7
42 7
27 5
29 5
40 7
35 5
34 5
39 7
31 5
3 1
24 4
12 3
32 5
36 6
4 1
22 4
5 1
30 5
33 5
14 3
6 1
25 5
10 2
51
50 110
0 1
15 4
21 4
20 4
13 3
7 2
1 1
16 4
17 4
8 2
23 4
38 6
41 7
26 5
18 4
9 2
28 5
45 7
47 8
43 7
37 6
19 4
2 1
11 3
48 8
49 8
46 7
44 7
42 7
27 5
29 5
40 7
35 5
34 5
39 7
31 5
3 1
24 4
12 3
32 5
36 6
4 1
22 4
5 1
30 5
33 5
14 3
6 1
25 5
10 2
51
50 110
0 1
15 4
21 4
20 4
13 3
7 2
1 1
16 4
17 4
8 2
23 4
38 6
41 7
26 5
18 4
9 2
28 5
45 7
47 8
43 7
37 6
19 4
2 1
11 3
48 8
49 8
46 7
44 7
42 7
27 5
29 5
40 7
35 5
34 5
39 7
31 5
3 1
24 4
12 3
32 5
36 6
4 1
22 4
5 1
30 5
33 5
14 3
6 1
25 5
10 2
end_CG
