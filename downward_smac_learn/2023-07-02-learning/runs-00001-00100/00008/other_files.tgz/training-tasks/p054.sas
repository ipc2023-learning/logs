begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var4
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var2
-1
29
Atom at-robot(loc_2_8)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_6)
Atom at-robot(loc_9_2)
Atom at-robot(loc_9_3)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
end_variable
begin_variable
var1
-1
6
Atom at(box2, loc_2_8)
Atom at(box2, loc_3_8)
Atom at(box2, loc_4_8)
Atom at(box2, loc_5_8)
Atom at(box2, loc_6_8)
Atom at(box2, loc_7_8)
end_variable
begin_variable
var0
-1
28
Atom at(box1, loc_2_8)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_3)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_6)
Atom at(box1, loc_9_2)
Atom at(box1, loc_9_3)
Atom at(box1, loc_9_4)
Atom at(box1, loc_9_5)
end_variable
28
begin_mutex_group
3
30 0
29 0
6 0
end_mutex_group
begin_mutex_group
2
30 1
0 0
end_mutex_group
begin_mutex_group
3
30 2
29 1
24 0
end_mutex_group
begin_mutex_group
2
30 3
1 0
end_mutex_group
begin_mutex_group
2
30 4
19 0
end_mutex_group
begin_mutex_group
3
30 5
29 2
27 0
end_mutex_group
begin_mutex_group
2
30 6
15 0
end_mutex_group
begin_mutex_group
3
30 7
29 3
26 0
end_mutex_group
begin_mutex_group
2
30 8
2 0
end_mutex_group
begin_mutex_group
2
30 9
10 0
end_mutex_group
begin_mutex_group
2
30 10
18 0
end_mutex_group
begin_mutex_group
2
30 11
16 0
end_mutex_group
begin_mutex_group
2
30 12
20 0
end_mutex_group
begin_mutex_group
2
30 13
23 0
end_mutex_group
begin_mutex_group
3
30 14
29 4
25 0
end_mutex_group
begin_mutex_group
2
30 15
11 0
end_mutex_group
begin_mutex_group
2
30 16
21 0
end_mutex_group
begin_mutex_group
2
30 17
17 0
end_mutex_group
begin_mutex_group
2
30 18
22 0
end_mutex_group
begin_mutex_group
2
30 19
14 0
end_mutex_group
begin_mutex_group
3
30 20
29 5
7 0
end_mutex_group
begin_mutex_group
2
30 21
9 0
end_mutex_group
begin_mutex_group
2
30 22
8 0
end_mutex_group





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8 17
1
122
2
30 19
28 21
4
0
104
3
30 18
28 13
3 0
0
115
3
30 18
28 18
14 0
0
119
3
30 18
28 20
17 0
0
125
3
30 18
28 24
20 0
end_DTG
begin_DTG
2
1
82
2
30 6
28 5
1
101
2
30 12
28 12
4
0
89
3
30 13
28 7
14 0
0
103
3
30 13
28 13
25 0
0
109
3
30 13
28 15
20 0
0
118
3
30 13
28 20
15 0
end_DTG
begin_DTG
2
1
90
2
30 5
28 8
1
91
2
29 2
28 8
4
0
76
3
30 2
28 0
27 0
0
77
3
29 1
28 0
27 0
0
83
3
30 2
28 6
6 0
0
84
3
29 1
28 6
6 0
end_DTG
begin_DTG
3
1
86
2
30 7
28 6
1
87
2
29 3
28 6
1
103
2
30 13
28 13
4
0
92
3
30 14
28 8
7 0
0
93
3
29 4
28 8
7 0
0
120
3
30 14
28 21
26 0
0
121
3
29 4
28 21
26 0
end_DTG
begin_DTG
4
1
79
2
30 5
28 3
1
80
2
29 2
28 3
1
120
2
30 14
28 21
1
121
2
29 4
28 21
4
0
86
3
30 7
28 6
25 0
0
87
3
29 3
28 6
25 0
0
107
3
30 7
28 15
27 0
0
108
3
29 3
28 15
27 0
end_DTG
begin_DTG
5
1
76
2
30 2
28 0
1
77
2
29 1
28 0
1
81
2
30 4
28 4
1
107
2
30 7
28 15
1
108
2
29 3
28 15
4
0
79
3
30 5
28 3
26 0
0
80
3
29 2
28 3
26 0
0
90
3
30 5
28 8
24 0
0
91
3
29 2
28 8
24 0
end_DTG
begin_DTG
4
1
0
0
3
1
1
24 0
3
76
2
30 2
27 0
3
77
2
29 1
27 0
1
0
2
1
6 0
3
3
3
1
24 0
5
4
1
19 0
5
78
2
30 4
15 0
5
0
5
1
6 0
2
6
1
0 0
6
7
1
27 0
6
79
2
30 5
26 0
6
80
2
29 2
26 0
2
5
8
1
19 0
5
81
2
30 4
27 0
5
2
9
1
0 0
4
10
1
1 0
6
11
1
27 0
7
12
1
15 0
7
82
2
30 6
23 0
8
3
13
1
24 0
3
83
2
30 2
6 0
3
84
2
29 1
6 0
5
14
1
19 0
5
85
2
30 4
1 0
8
15
1
26 0
8
86
2
30 7
25 0
8
87
2
29 3
25 0
5
5
16
1
19 0
5
88
2
30 4
0 0
8
17
1
26 0
14
18
1
23 0
14
89
2
30 13
14 0
7
6
19
1
27 0
6
90
2
30 5
24 0
6
91
2
29 2
24 0
7
20
1
15 0
15
21
1
25 0
15
92
2
30 14
7 0
15
93
2
29 4
7 0
2
10
22
1
10 0
10
94
2
30 9
18 0
5
9
23
1
2 0
11
24
1
18 0
11
95
2
30 10
16 0
16
25
1
11 0
16
96
2
30 15
9 0
6
10
26
1
10 0
10
97
2
30 9
2 0
12
27
1
16 0
12
98
2
30 11
20 0
17
28
1
21 0
17
99
2
30 16
8 0
5
11
29
1
18 0
11
100
2
30 10
10 0
13
30
1
20 0
13
101
2
30 12
23 0
18
31
1
17 0
6
12
32
1
16 0
12
102
2
30 11
18 0
14
33
1
23 0
14
103
2
30 13
25 0
19
34
1
22 0
19
104
2
30 18
3 0
6
7
35
1
15 0
7
105
2
30 6
19 0
13
36
1
20 0
13
106
2
30 12
16 0
15
37
1
25 0
20
38
1
14 0
6
8
39
1
26 0
8
107
2
30 7
27 0
8
108
2
29 3
27 0
14
40
1
23 0
14
109
2
30 13
20 0
21
41
1
7 0
5
10
42
1
10 0
17
43
1
21 0
17
110
2
30 16
17 0
22
44
1
9 0
22
111
2
30 21
12 0
6
11
45
1
18 0
16
46
1
11 0
18
47
1
17 0
18
112
2
30 17
22 0
23
48
1
8 0
23
113
2
30 22
13 0
5
12
49
1
16 0
17
50
1
21 0
17
114
2
30 16
11 0
19
51
1
22 0
19
115
2
30 18
14 0
6
13
52
1
20 0
18
53
1
17 0
18
116
2
30 17
21 0
20
54
1
14 0
20
117
2
30 19
7 0
24
55
1
3 0
5
14
56
1
23 0
14
118
2
30 13
15 0
19
57
1
22 0
19
119
2
30 18
17 0
21
58
1
7 0
5
15
59
1
25 0
15
120
2
30 14
26 0
15
121
2
29 4
26 0
20
60
1
14 0
20
122
2
30 19
22 0
4
16
61
1
11 0
16
123
2
30 15
10 0
23
62
1
8 0
26
63
1
12 0
4
17
64
1
21 0
17
124
2
30 16
18 0
22
65
1
9 0
27
66
1
13 0
2
19
67
1
22 0
19
125
2
30 18
20 0
2
26
68
1
12 0
26
126
2
30 25
13 0
5
22
69
1
9 0
22
127
2
30 21
11 0
25
70
1
4 0
27
71
1
13 0
27
128
2
30 26
5 0
5
23
72
1
8 0
23
129
2
30 22
21 0
26
73
1
12 0
26
130
2
30 25
4 0
28
74
1
5 0
2
27
75
1
13 0
27
131
2
30 26
12 0
end_DTG
begin_DTG
0
2
0
84
2
28 6
6 0
2
77
2
28 0
27 0
2
1
91
2
28 8
24 0
3
80
2
28 3
26 0
2
2
108
2
28 15
27 0
4
87
2
28 6
25 0
2
3
121
2
28 21
26 0
5
93
2
28 8
7 0
0
end_DTG
begin_DTG
0
0
2
0
83
2
28 6
6 0
5
76
2
28 0
27 0
0
4
1
88
2
28 7
0 0
3
85
2
28 6
1 0
5
81
2
28 4
27 0
6
78
2
28 2
15 0
2
2
90
2
28 8
24 0
7
79
2
28 3
26 0
2
4
105
2
28 14
19 0
13
82
2
28 5
23 0
2
5
107
2
28 15
27 0
14
86
2
28 6
25 0
0
2
8
97
2
28 11
2 0
10
94
2
28 9
18 0
2
9
100
2
28 12
10 0
11
95
2
28 10
16 0
2
10
102
2
28 13
18 0
12
98
2
28 11
20 0
2
11
106
2
28 14
16 0
13
101
2
28 12
23 0
4
6
118
2
28 20
15 0
12
109
2
28 15
20 0
14
103
2
28 13
25 0
19
89
2
28 7
14 0
2
7
120
2
28 21
26 0
20
92
2
28 8
7 0
2
9
123
2
28 22
10 0
21
96
2
28 10
9 0
4
10
124
2
28 23
18 0
15
114
2
28 18
11 0
17
110
2
28 16
17 0
22
99
2
28 11
8 0
2
16
116
2
28 19
21 0
18
112
2
28 17
22 0
4
12
125
2
28 24
20 0
17
119
2
28 20
17 0
19
115
2
28 18
14 0
23
104
2
28 13
3 0
2
18
122
2
28 21
22 0
20
117
2
28 19
7 0
0
2
15
127
2
28 26
11 0
25
111
2
28 16
12 0
2
16
129
2
28 27
21 0
26
113
2
28 17
13 0
0
0
2
24
130
2
28 27
4 0
26
126
2
28 25
13 0
2
25
131
2
28 28
12 0
27
128
2
28 26
5 0
0
end_DTG
begin_CG
3
30 1
28 3
19 1
3
30 1
28 2
19 1
3
30 1
28 2
10 1
3
30 1
28 2
22 1
3
30 1
28 2
12 1
3
30 1
28 2
13 1
4
30 1
29 1
28 4
24 2
5
30 2
29 1
28 5
25 2
14 1
3
30 1
28 4
21 1
3
30 1
28 4
11 1
4
30 2
28 5
18 1
11 1
4
30 2
28 5
21 1
9 1
4
30 2
28 5
9 1
13 1
4
30 2
28 5
8 1
12 1
4
30 2
28 5
23 1
22 1
4
30 2
28 5
19 1
23 1
4
30 2
28 5
18 1
20 1
4
30 2
28 5
21 1
22 1
5
30 3
28 6
10 1
16 1
21 1
3
30 1
28 5
15 1
5
30 3
28 6
16 1
23 1
22 1
4
30 2
28 6
17 1
8 1
4
30 2
28 6
17 1
14 1
4
30 2
28 6
15 1
20 1
4
30 1
29 1
28 5
27 2
5
30 2
29 1
28 6
26 2
23 1
5
30 2
29 2
28 7
27 2
25 2
6
30 3
29 2
28 8
24 2
19 1
26 2
30
30 48
29 8
6 2
0 1
24 6
1 1
19 5
27 9
15 4
26 8
2 1
10 4
18 5
16 4
20 5
23 6
25 7
11 4
21 6
17 4
22 6
14 4
7 3
9 3
8 3
3 1
4 1
12 4
13 4
5 1
7
28 8
6 1
24 3
27 4
26 4
25 3
7 1
29
28 48
6 1
0 1
24 3
1 1
19 5
27 5
15 4
26 4
2 1
10 4
18 5
16 4
20 5
23 6
25 4
11 4
21 6
17 4
22 6
14 4
7 2
9 3
8 3
3 1
4 1
12 4
13 4
5 1
end_CG
