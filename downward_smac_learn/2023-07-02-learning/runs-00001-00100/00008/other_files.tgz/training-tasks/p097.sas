begin_version
3
end_version
begin_metric
0
end_metric
73
begin_variable
var12
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_9_8)
Nega




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




05
2
68 50
65 0
4
47
813
2
68 70
51 0
56
729
2
68 62
59 0
58
701
2
68 60
45 0
66
617
2
68 51
58 0
4
48
825
2
68 71
25 0
49
717
2
68 61
31 0
57
629
2
68 53
64 0
67
625
2
68 52
26 0
0
0
4
0
653
2
68 56
22 0
52
217
2
68 0
63 0
60
769
2
68 66
16 0
62
745
2
68 64
66 0
4
1
669
2
68 57
23 0
53
221
2
68 1
67 0
61
781
2
68 67
57 0
63
757
2
68 65
43 0
2
62
789
2
68 68
66 0
64
773
2
68 66
47 0
4
2
693
2
68 59
7 0
55
229
2
68 2
37 0
63
805
2
68 69
43 0
65
785
2
68 67
65 0
4
3
705
2
68 60
44 0
56
237
2
68 3
59 0
64
817
2
68 70
47 0
66
793
2
68 68
58 0
4
4
721
2
68 61
8 0
57
245
2
68 4
64 0
65
829
2
68 71
65 0
67
809
2
68 69
26 0
2
59
821
2
68 70
15 0
66
737
2
68 63
58 0
end_DTG
begin_CG
6
69 1
70 1
71 1
72 1
68 5
17 4
6
69 1
70 1
71 1
72 1
68 6
19 4
6
69 1
70 1
71 1
72 1
68 5
18 4
6
69 1
70 1
71 1
72 1
68 6
20 4
6
69 1
70 1
71 1
72 1
68 6
21 4
6
69 1
70 1
71 1
72 1
68 5
30 4
6
69 1
70 1
71 1
72 1
68 5
31 4
7
69 2
70 2
71 2
72 2
68 10
44 4
47 4
7
69 2
70 2
71 2
72 2
68 10
44 4
58 4
7
69 2
70 2
71 2
72 2
68 10
22 4
17 4
7
69 2
70 2
71 2
72 2
68 10
18 4
46 4
7
69 2
70 2
71 2
72 2
68 10
24 4
30 4
7
69 2
70 2
71 2
72 2
68 10
30 4
52 4
7
69 2
70 2
71 2
72 2
68 10
25 4
31 4
7
69 2
70 2
71 2
72 2
68 10
51 4
59 4
7
69 2
70 2
71 2
72 2
68 10
31 4
26 4
7
69 2
70 2
71 2
72 2
68 10
27 4
57 4
6
69 1
70 1
71 1
72 1
68 7
23 4
6
69 1
70 1
71 1
72 1
68 7
28 4
6
69 1
70 1
71 1
72 1
68 6
44 4
6
69 1
70 1
71 1
72 1
68 7
32 4
6
69 1
70 1
71 1
72 1
68 7
54 4
6
69 1
70 1
71 1
72 1
68 7
57 4
6
69 1
70 1
71 1
72 1
68 7
66 4
7
69 2
70 2
71 2
72 2
68 11
33 4
53 4
7
69 2
70 2
71 2
72 2
68 11
51 4
45 4
7
69 2
70 2
71 2
72 2
68 11
45 4
58 4
7
69 2
70 2
71 2
72 2
68 11
34 4
63 4
7
69 2
70 2
71 2
72 2
68 11
46 4
36 4
7
69 2
70 2
71 2
72 2
68 10
52 4
51 4
6
69 1
70 1
71 1
72 1
68 8
53 4
6
69 1
70 1
71 1
72 1
68 8
45 4
8
69 3
70 3
71 3
72 3
68 15
20 4
54 4
35 4
8
69 3
70 3
71 3
72 3
68 15
46 4
24 4
49 4
8
69 3
70 3
71 3
72 3
68 15
35 4
62 4
27 4
8
69 3
70 3
71 3
72 3
68 15
32 4
56 4
34 4
8
69 3
70 3
71 3
72 3
68 15
28 4
48 4
60 4
8
69 3
70 3
71 3
72 3
68 15
55 4
59 4
47 4
8
69 3
70 3
71 3
72 3
68 15
39 4
61 4
55 4
8
69 3
70 3
71 3
72 3
68 15
60 4
50 4
38 4
8
69 3
70 3
71 3
72 3
68 15
49 4
41 4
52 4
8
69 3
70 3
71 3
72 3
68 15
48 4
60 4
40 4
8
69 3
70 3
71 3
72 3
68 15
54 4
60 4
50 4
8
69 3
70 3
71 3
72 3
68 15
55 4
66 4
47 4
7
69 2
70 2
71 2
72 2
68 12
19 4
65 4
7
69 2
70 2
71 2
72 2
68 12
31 4
64 4
7
69 2
70 2
71 2
72 2
68 12
33 4
48 4
7
69 2
70 2
71 2
72 2
68 12
43 4
65 4
7
69 2
70 2
71 2
72 2
68 12
46 4
49 4
7
69 2
70 2
71 2
72 2
68 12
48 4
53 4
7
69 2
70 2
71 2
72 2
68 12
56 4
61 4
8
69 3
70 3
71 3
72 3
68 16
29 4
25 4
64 4
8
69 3
70 3
71 3
72 3
68 16
53 4
40 4
29 4
8
69 3
70 3
71 3
72 3
68 16
49 4
30 4
52 4
8
69 3
70 3
71 3
72 3
68 16
21 4
42 4
56 4
8
69 3
70 3
71 3
72 3
68 16
38 4
67 4
37 4
8
69 3
70 3
71 3
72 3
68 16
54 4
50 4
62 4
8
69 3
70 3
71 3
72 3
68 16
22 4
63 4
66 4
8
69 3
70 3
71 3
72 3
68 16
64 4
65 4
26 4
8
69 3
70 3
71 3
72 3
68 16
37 4
64 4
65 4
9
69 4
70 4
71 4
72 4
68 20
36 4
42 4
41 4
39 4
8
69 3
70 3
71 3
72 3
68 16
50 4
62 4
67 4
8
69 3
70 3
71 3
72 3
68 16
56 4
61 4
63 4
8
69 3
70 3
71 3
72 3
68 16
62 4
67 4
57 4
9
69 4
70 4
71 4
72 4
68 20
51 4
59 4
45 4
58 4
9
69 4
70 4
71 4
72 4
68 20
44 4
59 4
47 4
58 4
9
69 4
70 4
71 4
72 4
68 20
23 4
67 4
57 4
43 4
9
69 4
70 4
71 4
72 4
68 20
61 4
63 4
55 4
66 4
72
69 154
70 154
71 154
72 154
22 12
23 12
7 8
44 24
8 8
9 8
17 12
0 4
19 12
1 4
2 4
18 12
10 8
3 4
4 4
28 16
46 24
33 20
24 16
11 8
5 4
20 12
21 12
36 20
48 24
49 24
53 28
30 20
32 20
54 28
42 20
60 32
41 20
40 20
52 28
12 8
35 20
56 28
50 24
39 20
29 16
13 8
34 20
62 28
61 28
38 20
14 8
51 28
25 16
31 20
6 4
27 16
63 28
67 32
55 28
37 20
59 28
64 32
45 24
15 8
16 8
57 28
66 32
43 20
47 24
65 32
58 28
26 16
69
68 154
22 3
23 3
7 2
44 6
8 2
9 2
17 3
0 1
19 3
1 1
2 1
18 3
10 2
3 1
4 1
28 4
46 6
33 5
24 4
11 2
5 1
20 3
21 3
36 5
48 6
49 6
53 7
30 5
32 5
54 7
42 5
60 8
41 5
40 5
52 7
12 2
35 5
56 7
50 6
39 5
29 4
13 2
34 5
62 7
61 7
38 5
14 2
51 7
25 4
31 5
6 1
27 4
63 7
67 8
55 7
37 5
59 7
64 8
45 6
15 2
16 2
57 7
66 8
43 5
47 6
65 8
58 7
26 4
69
68 154
22 3
23 3
7 2
44 6
8 2
9 2
17 3
0 1
19 3
1 1
2 1
18 3
10 2
3 1
4 1
28 4
46 6
33 5
24 4
11 2
5 1
20 3
21 3
36 5
48 6
49 6
53 7
30 5
32 5
54 7
42 5
60 8
41 5
40 5
52 7
12 2
35 5
56 7
50 6
39 5
29 4
13 2
34 5
62 7
61 7
38 5
14 2
51 7
25 4
31 5
6 1
27 4
63 7
67 8
55 7
37 5
59 7
64 8
45 6
15 2
16 2
57 7
66 8
43 5
47 6
65 8
58 7
26 4
69
68 154
22 3
23 3
7 2
44 6
8 2
9 2
17 3
0 1
19 3
1 1
2 1
18 3
10 2
3 1
4 1
28 4
46 6
33 5
24 4
11 2
5 1
20 3
21 3
36 5
48 6
49 6
53 7
30 5
32 5
54 7
42 5
60 8
41 5
40 5
52 7
12 2
35 5
56 7
50 6
39 5
29 4
13 2
34 5
62 7
61 7
38 5
14 2
51 7
25 4
31 5
6 1
27 4
63 7
67 8
55 7
37 5
59 7
64 8
45 6
15 2
16 2
57 7
66 8
43 5
47 6
65 8
58 7
26 4
69
68 154
22 3
23 3
7 2
44 6
8 2
9 2
17 3
0 1
19 3
1 1
2 1
18 3
10 2
3 1
4 1
28 4
46 6
33 5
24 4
11 2
5 1
20 3
21 3
36 5
48 6
49 6
53 7
30 5
32 5
54 7
42 5
60 8
41 5
40 5
52 7
12 2
35 5
56 7
50 6
39 5
29 4
13 2
34 5
62 7
61 7
38 5
14 2
51 7
25 4
31 5
6 1
27 4
63 7
67 8
55 7
37 5
59 7
64 8
45 6
15 2
16 2
57 7
66 8
43 5
47 6
65 8
58 7
26 4
end_CG
