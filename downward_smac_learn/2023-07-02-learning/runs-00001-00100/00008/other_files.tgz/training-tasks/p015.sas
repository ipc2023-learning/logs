begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var2
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
22
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
end_variable
22
begin_mutex_group
2
23 0
0 0
end_mutex_group
begin_mutex_group
2
23 1
1 0
end_mutex_group
begin_mutex_group
2
23 2
10 0
end_mutex_group
begin_mutex_group
2
23 3
4 0
end_mutex_group
begin_mutex_group
2
23 4
16 0
end_mutex_group
begin_mutex_group
2
23 5
18 0
end_mutex_group
begin_mutex_group
2
23 6
5 0
end_mutex_group
begin_mutex_group
2
23 7
6 0
end_mutex_group
begin_mutex_group
2
23 8
15 0
end_mutex_group
begin_mutex_group
2
23 9
21 0
end_mutex_group
begin_mutex_group
2
23 10
20 0
end_mutex_group
begin_mutex_group
2
23 11
11 0
end_mutex_group
begin_mutex_group
2
23 12
2 0
end_mutex_group
begin_mutex_group
2
23 13
13 0
end_mutex_group
begin_mutex_group
2
23 14
14 0
end_mutex_group
begin_mutex_group
2
23 15
19 0
end_mutex_group
begin_mutex_group
2
23 16
17 0
end_mutex_group
begin_mutex_group
2
23 17
12 0
end_mutex_group
begin_mutex_group
2
23 18
3 0
end_mutex_group
begin_mutex_group
2
23 19
7 0
end_mutex_group
begin_mutex_group
2
23 20
9 0
end_mutex_group
begin_mutex_group
2
23 21
8 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
11
14
end_state
begin_goal
1
23 2
end_goal
104
begin_operator
move loc_2_6 loc_3_6 down
1
10 0
1
0 22 0 2
0
end_operator
begin_operator
move loc_3_5 loc_3_6 right
1
10 0
1
0 22 1 2
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
16 0
1
0 22 1 4
0
end_operator
begin_operator
move loc_3_6 loc_2_6 up
1
0 0
1
0 22 2 0
0
end_operator
begin_operator
move loc_3_6 loc_3_5 left
1
1 0
1
0 22 2 1
0
end_operator
begin_operator
move loc_3_6 loc_4_6 down
1
18 0
1
0 22 2 5
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
16 0
1
0 22 3 4
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
1
15 0
1
0 22 3 8
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
1 0
1
0 22 4 1
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
4 0
1
0 22 4 3
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
18 0
1
0 22 4 5
0
end_operator
begin_operator
move loc_4_5 loc_5_5 down
1
21 0
1
0 22 4 9
0
end_operator
begin_operator
move loc_4_6 loc_3_6 up
1
10 0
1
0 22 5 2
0
end_operator
begin_operator




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
1
70
2
23 4
22 5
1
88
2
23 8
22 14
0
end_DTG
begin_DTG
2
1
67
2
23 5
22 4
1
96
2
23 11
22 17
0
end_DTG
begin_DTG
2
1
78
2
23 8
22 9
1
98
2
23 13
22 18
0
end_DTG
begin_DTG
2
1
80
2
23 15
22 9
1
103
2
23 20
22 21
0
end_DTG
begin_DTG
2
1
85
2
23 17
22 11
1
100
2
23 20
22 19
0
end_DTG
begin_DTG
1
1
83
2
23 16
22 10
2
0
100
3
23 20
22 19
8 0
0
103
3
23 20
22 21
7 0
end_DTG
begin_DTG
1
1
81
2
23 5
22 10
2
0
62
3
23 2
22 0
18 0
0
69
3
23 2
22 5
0 0
end_DTG
begin_DTG
2
1
79
2
23 10
22 9
1
102
2
23 17
22 21
2
0
73
3
23 11
22 6
12 0
0
96
3
23 11
22 17
5 0
end_DTG
begin_DTG
2
1
73
2
23 11
22 6
1
93
2
23 16
22 15
2
0
85
3
23 17
22 11
8 0
0
102
3
23 17
22 21
11 0
end_DTG
begin_DTG
1
1
92
2
23 14
22 15
4
0
75
3
23 13
22 7
3 0
0
86
3
23 13
22 12
14 0
0
89
3
23 13
22 14
2 0
0
98
3
23 13
22 18
6 0
end_DTG
begin_DTG
3
1
66
2
23 8
22 3
1
86
2
23 13
22 12
1
95
2
23 15
22 16
2
0
87
3
23 14
22 13
19 0
0
92
3
23 14
22 15
13 0
end_DTG
begin_DTG
1
1
82
2
23 9
22 10
4
0
66
3
23 8
22 3
14 0
0
74
3
23 8
22 7
21 0
0
78
3
23 8
22 9
6 0
0
88
3
23 8
22 14
4 0
end_DTG
begin_DTG
2
1
72
2
23 5
22 6
1
91
2
23 9
22 15
4
0
63
3
23 4
22 1
21 0
0
65
3
23 4
22 3
18 0
0
70
3
23 4
22 5
4 0
0
77
3
23 4
22 9
1 0
end_DTG
begin_DTG
2
1
71
2
23 10
22 5
1
90
2
23 15
22 14
4
0
83
3
23 16
22 10
9 0
0
93
3
23 16
22 15
12 0
0
97
3
23 16
22 17
19 0
0
101
3
23 16
22 20
20 0
end_DTG
begin_DTG
3
1
62
2
23 2
22 0
1
65
2
23 4
22 3
1
94
2
23 10
22 16
4
0
64
3
23 5
22 2
20 0
0
67
3
23 5
22 4
5 0
0
72
3
23 5
22 6
16 0
0
81
3
23 5
22 10
10 0
end_DTG
begin_DTG
3
1
68
2
23 9
22 4
1
87
2
23 14
22 13
1
97
2
23 16
22 17
4
0
80
3
23 15
22 9
7 0
0
90
3
23 15
22 14
17 0
0
95
3
23 15
22 16
14 0
0
99
3
23 15
22 19
21 0
end_DTG
begin_DTG
3
1
64
2
23 5
22 2
1
76
2
23 9
22 8
1
101
2
23 16
22 20
4
0
71
3
23 10
22 5
17 0
0
79
3
23 10
22 9
11 0
0
84
3
23 10
22 11
21 0
0
94
3
23 10
22 16
18 0
end_DTG
begin_DTG
4
1
63
2
23 4
22 1
1
74
2
23 8
22 7
1
84
2
23 10
22 11
1
99
2
23 15
22 19
4
0
68
3
23 9
22 4
19 0
0
76
3
23 9
22 8
20 0
0
82
3
23 9
22 10
15 0
0
91
3
23 9
22 15
16 0
end_DTG
begin_DTG
2
2
0
1
10 0
2
62
2
23 2
18 0
3
2
1
1
10 0
4
2
1
16 0
4
63
2
23 4
21 0
4
0
3
1
0 0
1
4
1
1 0
5
5
1
18 0
5
64
2
23 5
20 0
4
4
6
1
16 0
4
65
2
23 4
18 0
8
7
1
15 0
8
66
2
23 8
14 0
6
1
8
1
1 0
3
9
1
4 0
5
10
1
18 0
5
67
2
23 5
5 0
9
11
1
21 0
9
68
2
23 9
19 0
7
2
12
1
10 0
2
69
2
23 2
0 0
4
13
1
16 0
4
70
2
23 4
4 0
6
14
1
5 0
10
15
1
20 0
10
71
2
23 10
17 0
4
5
16
1
18 0
5
72
2
23 5
16 0
11
17
1
11 0
11
73
2
23 11
12 0
4
8
18
1
15 0
8
74
2
23 8
21 0
13
19
1
13 0
13
75
2
23 13
3 0
5
3
20
1
4 0
7
21
1
6 0
9
22
1
21 0
9
76
2
23 9
20 0
14
23
1
14 0
8
4
24
1
16 0
4
77
2
23 4
1 0
8
25
1
15 0
8
78
2
23 8
6 0
10
26
1
20 0
10
79
2
23 10
11 0
15
27
1
19 0
15
80
2
23 15
7 0
7
5
28
1
18 0
5
81
2
23 5
10 0
9
29
1
21 0
9
82
2
23 9
15 0
11
30
1
11 0
16
31
1
17 0
16
83
2
23 16
9 0
5
6
32
1
5 0
10
33
1
20 0
10
84
2
23 10
21 0
17
34
1
12 0
17
85
2
23 17
8 0
2
13
35
1
13 0
13
86
2
23 13
14 0
5
7
36
1
6 0
12
37
1
2 0
14
38
1
14 0
14
87
2
23 14
19 0
18
39
1
3 0
6
8
40
1
15 0
8
88
2
23 8
4 0
13
41
1
13 0
13
89
2
23 13
2 0
15
42
1
19 0
15
90
2
23 15
17 0
7
9
43
1
21 0
9
91
2
23 9
16 0
14
44
1
14 0
14
92
2
23 14
13 0
16
45
1
17 0
16
93
2
23 16
12 0
19
46
1
7 0
6
10
47
1
20 0
10
94
2
23 10
18 0
15
48
1
19 0
15
95
2
23 15
14 0
17
49
1
12 0
20
50
1
9 0
5
11
51
1
11 0
11
96
2
23 11
5 0
16
52
1
17 0
16
97
2
23 16
19 0
21
53
1
8 0
2
13
54
1
13 0
13
98
2
23 13
6 0
4
15
55
1
19 0
15
99
2
23 15
21 0
20
56
1
9 0
20
100
2
23 20
8 0
4
16
57
1
17 0
16
101
2
23 16
20 0
19
58
1
7 0
21
59
1
8 0
4
17
60
1
12 0
17
102
2
23 17
11 0
20
61
1
9 0
20
103
2
23 20
7 0
end_DTG
begin_DTG
0
0
2
0
69
2
22 5
0 0
5
62
2
22 0
18 0
0
4
1
77
2
22 9
1 0
3
70
2
22 5
4 0
5
65
2
22 3
18 0
9
63
2
22 1
21 0
4
2
81
2
22 10
10 0
4
72
2
22 6
16 0
6
67
2
22 4
5 0
10
64
2
22 2
20 0
0
0
4
3
88
2
22 14
4 0
7
78
2
22 9
6 0
9
74
2
22 7
21 0
14
66
2
22 3
14 0
4
4
91
2
22 15
16 0
8
82
2
22 10
15 0
10
76
2
22 8
20 0
15
68
2
22 4
19 0
4
5
94
2
22 16
18 0
9
84
2
22 11
21 0
11
79
2
22 9
11 0
16
71
2
22 5
17 0
2
6
96
2
22 17
5 0
17
73
2
22 6
12 0
0
4
7
98
2
22 18
6 0
12
89
2
22 14
2 0
14
86
2
22 12
14 0
18
75
2
22 7
3 0
2
13
92
2
22 15
13 0
15
87
2
22 13
19 0
4
9
99
2
22 19
21 0
14
95
2
22 16
14 0
16
90
2
22 14
17 0
19
80
2
22 9
7 0
4
10
101
2
22 20
20 0
15
97
2
22 17
19 0
17
93
2
22 15
12 0
20
83
2
22 10
9 0
2
11
102
2
22 21
11 0
21
85
2
22 11
8 0
0
0
2
19
103
2
22 21
7 0
21
100
2
22 19
8 0
0
end_DTG
begin_CG
3
23 1
22 2
10 1
3
23 1
22 3
16 1
3
23 1
22 2
13 1
3
23 1
22 2
13 1
4
23 2
22 4
16 1
15 1
4
23 2
22 4
18 1
11 1
4
23 2
22 4
15 1
13 1
4
23 2
22 4
19 1
9 1
4
23 2
22 4
12 1
9 1
3
23 1
22 4
17 1
3
23 1
22 4
18 1
4
23 2
22 5
20 1
12 1
4
23 2
22 5
11 1
17 1
3
23 1
22 5
14 1
5
23 3
22 6
15 1
13 1
19 1
3
23 1
22 5
21 1
4
23 2
22 6
18 1
21 1
4
23 2
22 6
20 1
19 1
5
23 3
22 7
10 1
16 1
20 1
5
23 3
22 7
21 1
14 1
17 1
5
23 3
22 7
18 1
21 1
17 1
6
23 4
22 8
16 1
15 1
20 1
19 1
23
23 42
0 1
1 1
10 3
4 2
16 6
18 7
5 2
6 2
15 5
21 8
20 7
11 4
2 1
13 5
14 5
19 7
17 6
12 4
3 1
7 2
9 3
8 2
23
22 42
0 1
1 1
10 3
4 2
16 6
18 7
5 2
6 2
15 5
21 8
20 7
11 4
2 1
13 5
14 5
19 7
17 6
12 4
3 1
7 2
9 3
8 2
end_CG
