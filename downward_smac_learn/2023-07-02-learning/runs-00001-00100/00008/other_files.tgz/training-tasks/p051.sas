begin_version
3
end_version
begin_metric
0
end_metric
49
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var2
-1
49
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_8_9)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_7)
Atom at




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 4
9 0
2
5
230
2
46 21
8 0
21
160
2
46 5
16 0
4
6
232
2
46 22
41 0
13
202
2
46 15
21 0
15
190
2
46 13
33 0
22
164
2
46 6
27 0
2
14
206
2
46 16
44 0
16
196
2
46 14
26 0
2
15
210
2
46 17
33 0
17
204
2
46 15
43 0
4
9
236
2
46 23
32 0
16
218
2
46 18
26 0
18
208
2
46 16
35 0
23
178
2
46 9
29 0
2
17
224
2
46 19
43 0
19
212
2
46 17
39 0
4
11
240
2
46 24
40 0
18
228
2
46 20
35 0
20
220
2
46 18
9 0
24
186
2
46 11
2 0
0
2
13
242
2
46 25
21 0
25
192
2
46 13
10 0
2
14
246
2
46 26
44 0
26
198
2
46 14
42 0
2
17
260
2
46 29
43 0
29
214
2
46 17
34 0
0
0
4
22
266
2
46 30
27 0
25
252
2
46 27
10 0
27
244
2
46 25
31 0
30
234
2
46 22
22 0
2
26
258
2
46 28
42 0
28
248
2
46 26
19 0
2
27
262
2
46 29
31 0
29
254
2
46 27
34 0
2
23
278
2
46 33
29 0
33
238
2
46 23
45 0
2
26
294
2
46 37
42 0
37
250
2
46 26
4 0
4
27
296
2
46 38
31 0
30
274
2
46 32
22 0
32
268
2
46 30
28 0
38
256
2
46 27
17 0
2
31
280
2
46 33
36 0
33
270
2
46 31
45 0
4
29
298
2
46 39
34 0
32
286
2
46 34
28 0
34
276
2
46 32
23 0
39
264
2
46 29
20 0
2
33
290
2
46 35
45 0
35
282
2
46 33
14 0
2
34
292
2
46 36
23 0
36
288
2
46 34
3 0
0
0
2
31
300
2
46 43
36 0
40
272
2
46 31
11 0
2
33
306
2
46 45
45 0
42
284
2
46 33
30 0
0
2
40
308
2
46 45
11 0
42
302
2
46 43
30 0
2
41
312
2
46 46
18 0
43
304
2
46 44
24 0
2
42
316
2
46 47
30 0
44
310
2
46 45
15 0
2
43
318
2
46 48
24 0
45
314
2
46 46
5 0
0
end_DTG
begin_DTG
0
0
0
2
2
155
2
46 4
6 0
4
149
2
46 2
7 0
0
0
4
0
195
2
46 14
0 0
5
167
2
46 7
8 0
7
159
2
46 5
37 0
14
145
2
46 0
44 0
4
1
201
2
46 15
1 0
6
171
2
46 8
41 0
8
163
2
46 6
25 0
15
147
2
46 1
33 0
2
7
175
2
46 9
37 0
9
169
2
46 7
32 0
2
8
181
2
46 10
25 0
10
173
2
46 8
38 0
4
2
217
2
46 18
6 0
9
185
2
46 11
32 0
11
177
2
46 9
40 0
18
151
2
46 2
35 0
4
3
223
2
46 19
12 0
10
189
2
46 12
38 0
12
183
2
46 10
13 0
19
153
2
46 3
39 0
2
4
227
2
46 20
7 0
20
157
2
46 4
9 0
2
5
231
2
46 21
8 0
21
161
2
46 5
16 0
4
6
233
2
46 22
41 0
13
203
2
46 15
21 0
15
191
2
46 13
33 0
22
165
2
46 6
27 0
2
14
207
2
46 16
44 0
16
197
2
46 14
26 0
2
15
211
2
46 17
33 0
17
205
2
46 15
43 0
4
9
237
2
46 23
32 0
16
219
2
46 18
26 0
18
209
2
46 16
35 0
23
179
2
46 9
29 0
2
17
225
2
46 19
43 0
19
213
2
46 17
39 0
4
11
241
2
46 24
40 0
18
229
2
46 20
35 0
20
221
2
46 18
9 0
24
187
2
46 11
2 0
0
2
13
243
2
46 25
21 0
25
193
2
46 13
10 0
2
14
247
2
46 26
44 0
26
199
2
46 14
42 0
2
17
261
2
46 29
43 0
29
215
2
46 17
34 0
0
0
4
22
267
2
46 30
27 0
25
253
2
46 27
10 0
27
245
2
46 25
31 0
30
235
2
46 22
22 0
2
26
259
2
46 28
42 0
28
249
2
46 26
19 0
2
27
263
2
46 29
31 0
29
255
2
46 27
34 0
2
23
279
2
46 33
29 0
33
239
2
46 23
45 0
2
26
295
2
46 37
42 0
37
251
2
46 26
4 0
4
27
297
2
46 38
31 0
30
275
2
46 32
22 0
32
269
2
46 30
28 0
38
257
2
46 27
17 0
2
31
281
2
46 33
36 0
33
271
2
46 31
45 0
4
29
299
2
46 39
34 0
32
287
2
46 34
28 0
34
277
2
46 32
23 0
39
265
2
46 29
20 0
2
33
291
2
46 35
45 0
35
283
2
46 33
14 0
2
34
293
2
46 36
23 0
36
289
2
46 34
3 0
0
0
2
31
301
2
46 43
36 0
40
273
2
46 31
11 0
2
33
307
2
46 45
45 0
42
285
2
46 33
30 0
0
2
40
309
2
46 45
11 0
42
303
2
46 43
30 0
2
41
313
2
46 46
18 0
43
305
2
46 44
24 0
2
42
317
2
46 47
30 0
44
311
2
46 45
15 0
2
43
319
2
46 48
24 0
45
315
2
46 46
5 0
0
end_DTG
begin_CG
4
47 1
48 1
46 4
41 2
4
47 1
48 1
46 4
37 2
4
47 1
48 1
46 3
39 2
4
47 1
48 1
46 4
14 2
4
47 1
48 1
46 4
22 2
4
47 1
48 1
46 4
15 2
5
47 2
48 2
46 6
12 2
38 2
5
47 2
48 2
46 6
12 2
13 2
5
47 2
48 2
46 6
41 2
21 2
5
47 2
48 2
46 6
13 2
39 2
5
47 2
48 2
46 6
16 2
42 2
5
47 2
48 2
46 6
17 2
18 2
4
47 1
48 1
46 5
40 2
4
47 1
48 1
46 5
40 2
4
47 1
48 1
46 5
23 2
4
47 1
48 1
46 5
24 2
4
47 1
48 1
46 5
21 2
4
47 1
48 1
46 5
36 2
4
47 1
48 1
46 4
30 2
4
47 1
48 1
46 5
31 2
4
47 1
48 1
46 5
45 2
5
47 2
48 2
46 7
44 2
16 2
5
47 2
48 2
46 7
42 2
36 2
5
47 2
48 2
46 7
45 2
14 2
5
47 2
48 2
46 7
30 2
15 2
5
47 2
48 2
46 7
37 2
32 2
5
47 2
48 2
46 7
33 2
43 2
5
47 2
48 2
46 7
44 2
42 2
5
47 2
48 2
46 7
36 2
45 2
5
47 2
48 2
46 6
43 2
34 2
6
47 3
48 3
46 9
20 2
18 2
24 2
6
47 3
48 3
46 9
42 2
19 2
36 2
6
47 3
48 3
46 9
25 2
38 2
43 2
6
47 3
48 3
46 9
37 2
44 2
26 2
6
47 3
48 3
46 9
29 2
19 2
45 2
6
47 3
48 3
46 9
38 2
43 2
39 2
5
47 2
48 2
46 8
28 2
17 2
5
47 2
48 2
46 8
41 2
25 2
5
47 2
48 2
46 8
32 2
40 2
5
47 2
48 2
46 8
40 2
35 2
5
47 2
48 2
46 8
38 2
39 2
5
47 2
48 2
46 8
37 2
44 2
6
47 3
48 3
46 10
27 2
31 2
22 2
6
47 3
48 3
46 10
26 2
35 2
29 2
6
47 3
48 3
46 10
41 2
33 2
27 2
7
47 4
48 4
46 12
34 2
28 2
23 2
20 2
48
47 88
48 88
0 2
1 2
6 4
12 6
7 4
8 4
41 12
37 12
25 8
32 10
38 12
40 12
13 6
21 8
44 14
33 10
26 8
43 14
35 10
39 12
9 4
16 6
27 8
29 8
2 2
10 4
42 14
31 10
19 6
34 10
22 8
36 12
28 8
45 16
23 8
14 6
3 2
4 2
17 6
20 6
11 4
18 6
30 10
24 8
15 6
5 2
47
46 88
0 1
1 1
6 2
12 3
7 2
8 2
41 6
37 6
25 4
32 5
38 6
40 6
13 3
21 4
44 7
33 5
26 4
43 7
35 5
39 6
9 2
16 3
27 4
29 4
2 1
10 2
42 7
31 5
19 3
34 5
22 4
36 6
28 4
45 8
23 4
14 3
3 1
4 1
17 3
20 3
11 2
18 3
30 5
24 4
15 3
5 1
47
46 88
0 1
1 1
6 2
12 3
7 2
8 2
41 6
37 6
25 4
32 5
38 6
40 6
13 3
21 4
44 7
33 5
26 4
43 7
35 5
39 6
9 2
16 3
27 4
29 4
2 1
10 2
42 7
31 5
19 3
34 5
22 4
36 6
28 4
45 8
23 4
14 3
3 1
4 1
17 3
20 3
11 2
18 3
30 5
24 4
15 3
5 1
end_CG
