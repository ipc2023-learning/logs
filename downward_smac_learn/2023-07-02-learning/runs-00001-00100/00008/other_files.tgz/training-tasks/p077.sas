begin_version
3
end_version
begin_metric
0
end_metric
77
begin_variable
var10
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var7
-1
2
Ato




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
48 0
0
4
41
595
2
73 62
25 0
50
523
2
73 54
10 0
52
511
2
73 52
70 0
60
436
2
73 43
19 0
4
42
598
2
73 63
69 0
51
532
2
73 55
55 0
53
514
2
73 53
37 0
61
448
2
73 44
20 0
2
52
541
2
73 56
70 0
54
526
2
73 54
60 0
4
44
601
2
73 64
61 0
53
550
2
73 57
37 0
55
535
2
73 55
52 0
62
463
2
73 46
11 0
2
54
556
2
73 58
60 0
56
544
2
73 56
62 0
4
46
604
2
73 65
51 0
55
571
2
73 59
52 0
57
553
2
73 57
72 0
63
478
2
73 48
53 0
4
47
613
2
73 66
71 0
48
559
2
73 58
65 0
56
496
2
73 50
62 0
64
490
2
73 49
67 0
4
48
625
2
73 67
65 0
59
616
2
73 66
48 0
64
589
2
73 61
67 0
65
499
2
73 50
64 0
2
49
634
2
73 68
50 0
66
508
2
73 51
44 0
2
51
640
2
73 69
55 0
67
517
2
73 53
15 0
2
52
646
2
73 70
70 0
68
529
2
73 54
16 0
0
2
56
658
2
73 73
62 0
71
562
2
73 58
63 0
4
57
667
2
73 74
72 0
58
607
2
73 65
66 0
63
580
2
73 60
53 0
72
574
2
73 59
68 0
4
0
583
2
73 60
57 0
58
217
2
73 0
66 0
66
670
2
73 74
44 0
72
637
2
73 68
68 0
2
1
592
2
73 61
26 0
59
223
2
73 1
48 0
0
2
67
649
2
73 71
15 0
69
643
2
73 69
12 0
0
0
4
2
610
2
73 65
39 0
63
229
2
73 2
53 0
70
673
2
73 74
13 0
72
652
2
73 72
68 0
4
3
619
2
73 66
58 0
64
235
2
73 3
67 0
65
661
2
73 73
64 0
71
628
2
73 67
63 0
end_DTG
begin_CG
5
74 1
75 1
76 1
73 4
17 3
5
74 1
75 1
76 1
73 4
24 3
5
74 1
75 1
76 1
73 4
40 3
5
74 1
75 1
76 1
73 5
54 3
5
74 1
75 1
76 1
73 5
40 3
5
74 1
75 1
76 1
73 5
18 3
5
74 1
75 1
76 1
73 5
54 3
5
74 1
75 1
76 1
73 5
61 3
5
74 1
75 1
76 1
73 5
56 3
5
74 1
75 1
76 1
73 5
25 3
5
74 1
75 1
76 1
73 5
55 3
5
74 1
75 1
76 1
73 4
60 3
5
74 1
75 1
76 1
73 4
16 3
5
74 1
75 1
76 1
73 4
63 3
6
74 2
75 2
76 2
73 8
26 3
27 3
6
74 2
75 2
76 2
73 8
19 3
16 3
5
74 1
75 1
76 1
73 6
20 3
5
74 1
75 1
76 1
73 5
28 3
5
74 1
75 1
76 1
73 6
40 3
5
74 1
75 1
76 1
73 6
55 3
5
74 1
75 1
76 1
73 6
70 3
5
74 1
75 1
76 1
73 5
42 3
5
74 1
75 1
76 1
73 6
43 3
5
74 1
75 1
76 1
73 6
59 3
6
74 2
75 2
76 2
73 9
21 3
29 3
6
74 2
75 2
76 2
73 9
69 3
55 3
6
74 2
75 2
76 2
73 9
57 3
44 3
6
74 2
75 2
76 2
73 9
57 3
45 3
6
74 2
75 2
76 2
73 8
17 3
30 3
6
74 2
75 2
76 2
73 8
24 3
47 3
6
74 2
75 2
76 2
73 8
28 3
31 3
6
74 2
75 2
76 2
73 8
30 3
46 3
6
74 2
75 2
76 2
73 9
33 3
54 3
6
74 2
75 2
76 2
73 8
34 3
32 3
6
74 2
75 2
76 2
73 9
41 3
33 3
6
74 2
75 2
76 2
73 9
18 3
36 3
6
74 2
75 2
76 2
73 8
35 3
69 3
6
74 2
75 2
76 2
73 9
70 3
60 3
6
74 2
75 2
76 2
73 9
69 3
61 3
6
74 2
75 2
76 2
73 9
58 3
63 3
5
74 1
75 1
76 1
73 7
41 3
7
74 3
75 3
76 3
73 12
40 3
34 3
35 3
7
74 3
75 3
76 3
73 12
21 3
54 3
22 3
7
74 3
75 3
76 3
73 12
22 3
23 3
71 3
7
74 3
75 3
76 3
73 12
26 3
48 3
64 3
7
74 3
75 3
76 3
73 12
58 3
27 3
46 3
7
74 3
75 3
76 3
73 12
39 3
31 3
45 3
7
74 3
75 3
76 3
73 12
29 3
23 3
49 3
7
74 3
75 3
76 3
73 12
50 3
66 3
44 3
7
74 3
75 3
76 3
73 12
47 3
59 3
50 3
7
74 3
75 3
76 3
73 12
49 3
65 3
48 3
7
74 3
75 3
76 3
73 12
56 3
71 3
62 3
7
74 3
75 3
76 3
73 12
56 3
60 3
62 3
7
74 3
75 3
76 3
73 12
62 3
67 3
63 3
6
74 2
75 2
76 2
73 10
32 3
42 3
6
74 2
75 2
76 2
73 10
70 3
19 3
6
74 2
75 2
76 2
73 10
61 3
51 3
6
74 2
75 2
76 2
73 10
58 3
64 3
6
74 2
75 2
76 2
73 10
57 3
68 3
6
74 2
75 2
76 2
73 10
71 3
65 3
7
74 3
75 3
76 3
73 13
61 3
37 3
52 3
7
74 3
75 3
76 3
73 13
38 3
56 3
60 3
7
74 3
75 3
76 3
73 13
52 3
72 3
53 3
7
74 3
75 3
76 3
73 13
39 3
53 3
68 3
7
74 3
75 3
76 3
73 13
57 3
66 3
68 3
7
74 3
75 3
76 3
73 13
59 3
72 3
66 3
7
74 3
75 3
76 3
73 13
65 3
67 3
64 3
7
74 3
75 3
76 3
73 13
72 3
66 3
68 3
8
74 4
75 4
76 4
73 16
58 3
67 3
64 3
63 3
8
74 4
75 4
76 4
73 16
36 3
25 3
38 3
70 3
8
74 4
75 4
76 4
73 16
69 3
55 3
37 3
20 3
8
74 4
75 4
76 4
73 16
43 3
59 3
51 3
72 3
8
74 4
75 4
76 4
73 16
71 3
65 3
62 3
67 3
76
74 154
75 154
76 154
57 18
26 12
39 12
58 18
27 12
14 6
0 3
17 9
28 12
30 12
31 12
46 15
45 15
1 3
2 3
3 3
21 9
24 12
4 3
40 15
41 15
34 12
33 12
32 12
54 18
42 15
29 12
5 3
18 9
35 12
6 3
22 9
23 9
47 15
36 12
7 3
8 3
43 15
59 18
49 15
9 3
25 12
69 24
38 12
61 21
56 18
51 15
71 24
65 21
50 15
10 3
55 18
70 24
37 12
60 21
52 15
62 21
72 24
66 21
48 15
19 9
20 9
11 3
53 15
67 21
64 21
44 15
15 6
16 9
12 3
13 3
63 21
68 24
74
73 154
57 6
26 4
39 4
58 6
27 4
14 2
0 1
17 3
28 4
30 4
31 4
46 5
45 5
1 1
2 1
3 1
21 3
24 4
4 1
40 5
41 5
34 4
33 4
32 4
54 6
42 5
29 4
5 1
18 3
35 4
6 1
22 3
23 3
47 5
36 4
7 1
8 1
43 5
59 6
49 5
9 1
25 4
69 8
38 4
61 7
56 6
51 5
71 8
65 7
50 5
10 1
55 6
70 8
37 4
60 7
52 5
62 7
72 8
66 7
48 5
19 3
20 3
11 1
53 5
67 7
64 7
44 5
15 2
16 3
12 1
13 1
63 7
68 8
74
73 154
57 6
26 4
39 4
58 6
27 4
14 2
0 1
17 3
28 4
30 4
31 4
46 5
45 5
1 1
2 1
3 1
21 3
24 4
4 1
40 5
41 5
34 4
33 4
32 4
54 6
42 5
29 4
5 1
18 3
35 4
6 1
22 3
23 3
47 5
36 4
7 1
8 1
43 5
59 6
49 5
9 1
25 4
69 8
38 4
61 7
56 6
51 5
71 8
65 7
50 5
10 1
55 6
70 8
37 4
60 7
52 5
62 7
72 8
66 7
48 5
19 3
20 3
11 1
53 5
67 7
64 7
44 5
15 2
16 3
12 1
13 1
63 7
68 8
74
73 154
57 6
26 4
39 4
58 6
27 4
14 2
0 1
17 3
28 4
30 4
31 4
46 5
45 5
1 1
2 1
3 1
21 3
24 4
4 1
40 5
41 5
34 4
33 4
32 4
54 6
42 5
29 4
5 1
18 3
35 4
6 1
22 3
23 3
47 5
36 4
7 1
8 1
43 5
59 6
49 5
9 1
25 4
69 8
38 4
61 7
56 6
51 5
71 8
65 7
50 5
10 1
55 6
70 8
37 4
60 7
52 5
62 7
72 8
66 7
48 5
19 3
20 3
11 1
53 5
67 7
64 7
44 5
15 2
16 3
12 1
13 1
63 7
68 8
end_CG
