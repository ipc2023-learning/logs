begin_version
3
end_version
begin_metric
0
end_metric
74
begin_variable
var7
-1
2
Atom clear(loc_10_12)
NegatedAtom clear(loc_10_12)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_12_12)
NegatedAtom clear(loc_12_12)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_12_5)
NegatedAtom clear(loc_12_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_12)
NegatedAtom clear(loc_6_12)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_12_11)
NegatedAtom clear(loc_12_11)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_11)
NegatedAtom clear(loc_4_11)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_vari




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




69 62
59 0
4
50
807
2
69 72
30 0
57
739
2
69 65
32 0
59
719
2
69 63
36 0
65
655
2
69 56
28 0
2
58
751
2
69 66
59 0
60
731
2
69 64
61 0
4
51
811
2
69 73
48 0
59
767
2
69 67
36 0
61
743
2
69 65
57 0
66
667
2
69 57
21 0
4
52
819
2
69 74
54 0
60
779
2
69 68
61 0
62
755
2
69 66
41 0
67
675
2
69 58
42 0
2
53
823
2
69 75
44 0
68
687
2
69 59
37 0
2
1
695
2
69 60
53 0
54
239
2
69 1
34 0
2
3
711
2
69 62
15 0
56
247
2
69 3
52 0
2
4
735
2
69 64
24 0
58
255
2
69 5
59 0
2
5
759
2
69 66
11 0
60
263
2
69 6
61 0
4
6
771
2
69 67
20 0
61
271
2
69 7
57 0
66
827
2
69 75
21 0
68
815
2
69 73
37 0
2
7
783
2
69 68
38 0
62
283
2
69 8
41 0
end_DTG
begin_CG
6
70 1
71 1
72 1
73 1
69 5
53 4
6
70 1
71 1
72 1
73 1
69 6
15 4
6
70 1
71 1
72 1
73 1
69 5
14 4
6
70 1
71 1
72 1
73 1
69 5
14 4
6
70 1
71 1
72 1
73 1
69 5
16 4
6
70 1
71 1
72 1
73 1
69 6
51 4
6
70 1
71 1
72 1
73 1
69 6
19 4
6
70 1
71 1
72 1
73 1
69 5
50 4
6
70 1
71 1
72 1
73 1
69 6
17 4
6
70 1
71 1
72 1
73 1
69 6
56 4
6
70 1
71 1
72 1
73 1
69 5
52 4
7
70 2
71 2
72 2
73 2
69 10
20 4
21 4
7
70 2
71 2
72 2
73 2
69 10
50 4
40 4
7
70 2
71 2
72 2
73 2
69 10
40 4
22 4
6
70 1
71 1
72 1
73 1
69 7
18 4
6
70 1
71 1
72 1
73 1
69 7
23 4
6
70 1
71 1
72 1
73 1
69 7
24 4
6
70 1
71 1
72 1
73 1
69 7
25 4
6
70 1
71 1
72 1
73 1
69 6
53 4
7
70 2
71 2
72 2
73 2
69 11
51 4
39 4
7
70 2
71 2
72 2
73 2
69 11
38 4
42 4
7
70 2
71 2
72 2
73 2
69 11
61 4
42 4
7
70 2
71 2
72 2
73 2
69 11
26 4
27 4
7
70 2
71 2
72 2
73 2
69 11
15 4
52 4
7
70 2
71 2
72 2
73 2
69 11
16 4
28 4
7
70 2
71 2
72 2
73 2
69 11
17 4
29 4
7
70 2
71 2
72 2
73 2
69 11
40 4
67 4
7
70 2
71 2
72 2
73 2
69 10
22 4
30 4
7
70 2
71 2
72 2
73 2
69 11
24 4
59 4
7
70 2
71 2
72 2
73 2
69 10
25 4
52 4
7
70 2
71 2
72 2
73 2
69 10
27 4
59 4
7
70 2
71 2
72 2
73 2
69 10
53 4
38 4
7
70 2
71 2
72 2
73 2
69 11
52 4
59 4
7
70 2
71 2
72 2
73 2
69 11
56 4
34 4
7
70 2
71 2
72 2
73 2
69 10
33 4
35 4
7
70 2
71 2
72 2
73 2
69 10
53 4
34 4
7
70 2
71 2
72 2
73 2
69 10
59 4
61 4
7
70 2
71 2
72 2
73 2
69 11
41 4
42 4
8
70 3
71 3
72 3
73 3
69 15
31 4
20 4
37 4
8
70 3
71 3
72 3
73 3
69 15
19 4
58 4
43 4
6
70 1
71 1
72 1
73 1
69 8
65 4
8
70 3
71 3
72 3
73 3
69 15
44 4
57 4
37 4
6
70 1
71 1
72 1
73 1
69 8
57 4
8
70 3
71 3
72 3
73 3
69 15
39 4
55 4
56 4
8
70 3
71 3
72 3
73 3
69 15
64 4
54 4
41 4
8
70 3
71 3
72 3
73 3
69 15
50 4
46 4
63 4
8
70 3
71 3
72 3
73 3
69 15
51 4
45 4
62 4
8
70 3
71 3
72 3
73 3
69 15
67 4
60 4
48 4
8
70 3
71 3
72 3
73 3
69 15
47 4
54 4
61 4
8
70 3
71 3
72 3
73 3
69 15
55 4
56 4
64 4
7
70 2
71 2
72 2
73 2
69 12
45 4
65 4
7
70 2
71 2
72 2
73 2
69 12
46 4
58 4
8
70 3
71 3
72 3
73 3
69 16
29 4
32 4
23 4
8
70 3
71 3
72 3
73 3
69 16
31 4
18 4
35 4
7
70 2
71 2
72 2
73 2
69 12
60 4
57 4
7
70 2
71 2
72 2
73 2
69 12
58 4
66 4
8
70 3
71 3
72 3
73 3
69 16
43 4
49 4
33 4
8
70 3
71 3
72 3
73 3
69 16
54 4
61 4
42 4
8
70 3
71 3
72 3
73 3
69 16
51 4
62 4
55 4
9
70 4
71 4
72 4
73 4
69 20
30 4
32 4
36 4
28 4
8
70 3
71 3
72 3
73 3
69 16
68 4
64 4
54 4
9
70 4
71 4
72 4
73 4
69 20
48 4
36 4
57 4
21 4
8
70 3
71 3
72 3
73 3
69 16
58 4
63 4
66 4
8
70 3
71 3
72 3
73 3
69 16
65 4
62 4
68 4
9
70 4
71 4
72 4
73 4
69 20
66 4
49 4
60 4
44 4
9
70 4
71 4
72 4
73 4
69 20
50 4
40 4
63 4
67 4
9
70 4
71 4
72 4
73 4
69 20
62 4
55 4
68 4
64 4
9
70 4
71 4
72 4
73 4
69 20
65 4
26 4
68 4
47 4
9
70 4
71 4
72 4
73 4
69 20
63 4
67 4
66 4
60 4
73
70 152
71 152
72 152
73 152
31 16
53 28
0 4
15 12
24 16
11 8
20 16
38 20
18 12
1 4
16 12
2 4
14 12
3 4
4 4
5 4
6 4
7 4
51 24
19 16
12 8
50 24
45 20
46 20
58 28
39 20
8 4
13 8
40 20
65 32
63 28
62 28
55 24
43 20
17 12
22 16
26 16
67 32
68 32
66 32
49 20
56 28
9 4
25 16
27 16
47 20
60 28
64 32
33 16
29 16
30 16
48 20
54 24
44 20
34 16
10 4
52 28
32 16
59 32
36 16
61 32
57 28
41 20
35 16
23 16
28 16
21 16
42 20
37 16
70
69 152
31 4
53 7
0 1
15 3
24 4
11 2
20 4
38 5
18 3
1 1
16 3
2 1
14 3
3 1
4 1
5 1
6 1
7 1
51 6
19 4
12 2
50 6
45 5
46 5
58 7
39 5
8 1
13 2
40 5
65 8
63 7
62 7
55 6
43 5
17 3
22 4
26 4
67 8
68 8
66 8
49 5
56 7
9 1
25 4
27 4
47 5
60 7
64 8
33 4
29 4
30 4
48 5
54 6
44 5
34 4
10 1
52 7
32 4
59 8
36 4
61 8
57 7
41 5
35 4
23 4
28 4
21 4
42 5
37 4
70
69 152
31 4
53 7
0 1
15 3
24 4
11 2
20 4
38 5
18 3
1 1
16 3
2 1
14 3
3 1
4 1
5 1
6 1
7 1
51 6
19 4
12 2
50 6
45 5
46 5
58 7
39 5
8 1
13 2
40 5
65 8
63 7
62 7
55 6
43 5
17 3
22 4
26 4
67 8
68 8
66 8
49 5
56 7
9 1
25 4
27 4
47 5
60 7
64 8
33 4
29 4
30 4
48 5
54 6
44 5
34 4
10 1
52 7
32 4
59 8
36 4
61 8
57 7
41 5
35 4
23 4
28 4
21 4
42 5
37 4
70
69 152
31 4
53 7
0 1
15 3
24 4
11 2
20 4
38 5
18 3
1 1
16 3
2 1
14 3
3 1
4 1
5 1
6 1
7 1
51 6
19 4
12 2
50 6
45 5
46 5
58 7
39 5
8 1
13 2
40 5
65 8
63 7
62 7
55 6
43 5
17 3
22 4
26 4
67 8
68 8
66 8
49 5
56 7
9 1
25 4
27 4
47 5
60 7
64 8
33 4
29 4
30 4
48 5
54 6
44 5
34 4
10 1
52 7
32 4
59 8
36 4
61 8
57 7
41 5
35 4
23 4
28 4
21 4
42 5
37 4
70
69 152
31 4
53 7
0 1
15 3
24 4
11 2
20 4
38 5
18 3
1 1
16 3
2 1
14 3
3 1
4 1
5 1
6 1
7 1
51 6
19 4
12 2
50 6
45 5
46 5
58 7
39 5
8 1
13 2
40 5
65 8
63 7
62 7
55 6
43 5
17 3
22 4
26 4
67 8
68 8
66 8
49 5
56 7
9 1
25 4
27 4
47 5
60 7
64 8
33 4
29 4
30 4
48 5
54 6
44 5
34 4
10 1
52 7
32 4
59 8
36 4
61 8
57 7
41 5
35 4
23 4
28 4
21 4
42 5
37 4
end_CG
