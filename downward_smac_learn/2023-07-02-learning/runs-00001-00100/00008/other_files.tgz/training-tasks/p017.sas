begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var6
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var2
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var1
-1
14
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
end_variable
begin_variable
var0
-1
14
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
end_variable
14
begin_mutex_group
2
15 0
6 0
end_mutex_group
begin_mutex_group
2
15 1
7 0
end_mutex_group
begin_mutex_group
2
15 2
10 0
end_mutex_group
begin_mutex_group
2
15 3
8 0
end_mutex_group
begin_mutex_group
2
15 4
0 0
end_mutex_group
begin_mutex_group
2
15 5
1 0
end_mutex_group
begin_mutex_group
2
15 6
11 0
end_mutex_group
begin_mutex_group
2
15 7
9 0
end_mutex_group
begin_mutex_group
2
15 8
13 0
end_mutex_group
begin_mutex_group
2
15 9
12 0
end_mutex_group
begin_mutex_group
2
15 10
2 0
end_mutex_group
begin_mutex_group
2
15 11
3 0
end_mutex_group
begin_mutex_group
2
15 12
4 0
end_mutex_group
begin_mutex_group
2
15 13
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
7
end_state
begin_goal
1
15 0
end_goal
56
begin_operator
move loc_5_3 loc_5_4 right
1
7 0
1
0 14 0 1
0
end_operator
begin_operator
move loc_5_3 loc_6_3 down
1
11 0
1
0 14 0 6
0
end_operator
begin_operator
move loc_5_4 loc_5_3 left
1
6 0
1
0 14 1 0
0
end_operator
begin_operator
move loc_5_4 loc_5_5 right
1
10 0
1
0 14 1 2
0
end_operator
begin_operator
move loc_5_4 loc_6_4 down
1
9 0
1
0 14 1 7
0
end_operator
begin_operator
move loc_5_5 loc_5_4 left
1
7 0
1
0 14 2 1
0
end_operator
begin_operator
move loc_5_5 loc_5_6 right
1
8 0
1
0 14 2 3
0
end_operator
begin_operator
move loc_5_5 loc_6_5 down
1
13 0
1
0 14 2 8
0
end_operator
begin_operator
move loc_5_6 loc_5_5 left
1
10 0
1
0 14 3 2
0
end_operator
begin_operator
move loc_5_6 loc_5_7 right
1
0 0
1
0 14 3 4
0
end_operator
begin_operator
move loc_5_6 loc_6_6 down
1
12 0
1
0 14 3 9
0
end_operator
begin_operator
move loc_5_7 loc_5_6 left
1
8 0
1
0 14 4 3
0
end_operator
begin_operator
move loc_5_7 loc_6_7 down
1
2 0
1
0 14 4 10
0
end_operator
begin_operator
move loc_6_2 loc_6_3 right
1
11 0
1
0 14 5 6
0
end_operator
begin_operator
move loc_6_3 loc_5_3 up
1
6 0
1
0 14 6 0
0
end_operator
begin_operator
move loc_6_3 loc_6_2 left
1
1 0
1
0 14 6 5
0
end_operator
begin_operator
move loc_6_3 loc_6_4 right
1
9 0
1
0 14 6 7
0
end_operator
begin_operator
move loc_6_3 loc_7_3 down
1
3 0
1
0 14 6 11
0
end_operator
begin_operator
move loc_6_4 loc_5_4 up
1
7 0
1
0 14 7 1
0
end_operator
begin_operator
move loc_6_4 loc_6_3 left
1
11 0
1
0 14 7 6
0
end_operator
begin_operator
move loc_6_4 loc_6_5 right
1
13 0
1
0 14 7 8
0
end_operator
begin_operator
move loc_6_5 loc_5_5 up
1
10 0
1
0 14 8 2
0
end_operator
begin_operator
move loc_6_5 loc_6_4 left
1
9 0
1
0 14 8 7
0
end_operator
begin_operator
move loc_6_5 loc_6_6 right
1
12 0
1
0 14 8 9
0
end_operator
begin_operator
move loc_6_5 loc_7_5 down
1
4 0
1
0 14 8 12
0
end_operator
begin_operator
move loc_6_6 loc_5_6 up
1
8 0
1
0 14 9 3
0
end_operator
begin_operator
move loc_6_6 loc_6_5 left
1
13 0
1
0 14 9 8
0
end_operator
begin_operator
move loc_6_6 loc_6_7 right
1
2 0
1
0 14 9 10
0
end_operator
begin_operator
move loc_6_6 loc_7_6 down
1
5 0
1
0 14 9 13
0
end_operator
begin_operator
move loc_6_7 loc_5_7 up
1
0 0
1
0 14 10 4
0
end_operator
begin_operator
move loc_6_7 loc_6_6 left
1
12 0
1
0 14 10 9
0
end_operator
begin_operator
move loc_7_3 loc_6_3 up
1
11 0
1
0 14 11 6
0
end_operator
begin_operator
move loc_7_5 loc_6_5 up
1
13 0
1
0 14 12 8
0
end_op




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
check 0
switch 9
check 0
check 1
45
check 0
check 0
check 0
switch 1
check 0
check 1
47
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
53
check 0
check 0
check 0
check 0
check 0
switch 14
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
check 1
46
check 0
check 0
check 0
switch 11
check 0
check 1
49
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 14
check 0
check 0
check 0
switch 4
check 0
check 1
41
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
check 1
48
check 0
check 0
check 0
switch 9
check 0
check 1
51
check 0
check 0
check 0
check 0
switch 10
check 0
check 1
54
check 0
check 0
check 0
check 0
switch 14
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
43
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
50
check 0
check 0
check 0
switch 13
check 0
check 1
52
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
55
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 14
check 0
switch 7
check 0
check 1
0
check 0
switch 11
check 0
check 1
1
check 0
check 0
switch 6
check 0
check 1
2
check 0
switch 10
check 0
check 1
3
check 0
switch 9
check 0
check 1
4
check 0
check 0
switch 7
check 0
check 1
5
check 0
switch 8
check 0
check 1
6
check 0
switch 13
check 0
check 1
7
check 0
check 0
switch 10
check 0
check 1
8
check 0
switch 0
check 0
check 1
9
check 0
switch 12
check 0
check 1
10
check 0
check 0
switch 8
check 0
check 1
11
check 0
switch 2
check 0
check 1
12
check 0
check 0
switch 11
check 0
check 1
13
check 0
check 0
switch 6
check 0
check 1
14
check 0
switch 1
check 0
check 1
15
check 0
switch 9
check 0
check 1
16
check 0
switch 3
check 0
check 1
17
check 0
check 0
switch 7
check 0
check 1
18
check 0
switch 11
check 0
check 1
19
check 0
switch 13
check 0
check 1
20
check 0
check 0
switch 10
check 0
check 1
21
check 0
switch 9
check 0
check 1
22
check 0
switch 12
check 0
check 1
23
check 0
switch 4
check 0
check 1
24
check 0
check 0
switch 8
check 0
check 1
25
check 0
switch 13
check 0
check 1
26
check 0
switch 2
check 0
check 1
27
check 0
switch 5
check 0
check 1
28
check 0
check 0
switch 0
check 0
check 1
29
check 0
switch 12
check 0
check 1
30
check 0
check 0
switch 11
check 0
check 1
31
check 0
check 0
switch 13
check 0
check 1
32
check 0
switch 5
check 0
check 1
33
check 0
check 0
switch 12
check 0
check 1
34
check 0
switch 4
check 0
check 1
35
check 0
check 0
check 0
end_SG
begin_DTG
1
1
40
2
15 3
14 2
0
end_DTG
begin_DTG
1
1
47
2
15 6
14 7
0
end_DTG
begin_DTG
1
1
50
2
15 9
14 8
0
end_DTG
begin_DTG
1
1
37
2
15 6
14 0
0
end_DTG
begin_DTG
1
1
41
2
15 8
14 2
0
end_DTG
begin_DTG
1
1
43
2
15 9
14 3
0
end_DTG
begin_DTG
2
1
39
2
15 1
14 2
1
53
2
15 6
14 11
0
end_DTG
begin_DTG
1
1
42
2
15 2
14 3
2
0
36
3
15 1
14 0
10 0
0
39
3
15 1
14 2
6 0
end_DTG
begin_DTG
2
1
38
2
15 2
14 1
1
55
2
15 9
14 13
2
0
40
3
15 3
14 2
0 0
0
44
3
15 3
14 4
10 0
end_DTG
begin_DTG
2
1
45
2
15 6
14 5
1
51
2
15 8
14 9
2
0
46
3
15 7
14 6
13 0
0
49
3
15 7
14 8
11 0
end_DTG
begin_DTG
3
1
36
2
15 1
14 0
1
44
2
15 3
14 4
1
54
2
15 8
14 12
2
0
38
3
15 2
14 1
8 0
0
42
3
15 2
14 3
7 0
end_DTG
begin_DTG
1
1
49
2
15 7
14 8
4
0
37
3
15 6
14 0
3 0
0
45
3
15 6
14 5
9 0
0
47
3
15 6
14 7
1 0
0
53
3
15 6
14 11
6 0
end_DTG
begin_DTG
1
1
48
2
15 8
14 7
4
0
43
3
15 9
14 3
5 0
0
50
3
15 9
14 8
2 0
0
52
3
15 9
14 10
13 0
0
55
3
15 9
14 13
8 0
end_DTG
begin_DTG
2
1
46
2
15 7
14 6
1
52
2
15 9
14 10
4
0
41
3
15 8
14 2
4 0
0
48
3
15 8
14 7
12 0
0
51
3
15 8
14 9
9 0
0
54
3
15 8
14 12
10 0
end_DTG
begin_DTG
4
1
0
1
7 0
1
36
2
15 1
10 0
6
1
1
11 0
6
37
2
15 6
3 0
4
0
2
1
6 0
2
3
1
10 0
2
38
2
15 2
8 0
7
4
1
9 0
6
1
5
1
7 0
1
39
2
15 1
6 0
3
6
1
8 0
3
40
2
15 3
0 0
8
7
1
13 0
8
41
2
15 8
4 0
5
2
8
1
10 0
2
42
2
15 2
7 0
4
9
1
0 0
9
10
1
12 0
9
43
2
15 9
5 0
3
3
11
1
8 0
3
44
2
15 3
10 0
10
12
1
2 0
2
6
13
1
11 0
6
45
2
15 6
9 0
5
0
14
1
6 0
5
15
1
1 0
7
16
1
9 0
7
46
2
15 7
13 0
11
17
1
3 0
5
1
18
1
7 0
6
19
1
11 0
6
47
2
15 6
1 0
8
20
1
13 0
8
48
2
15 8
12 0
6
2
21
1
10 0
7
22
1
9 0
7
49
2
15 7
11 0
9
23
1
12 0
9
50
2
15 9
2 0
12
24
1
4 0
5
3
25
1
8 0
8
26
1
13 0
8
51
2
15 8
9 0
10
27
1
2 0
13
28
1
5 0
3
4
29
1
0 0
9
30
1
12 0
9
52
2
15 9
13 0
2
6
31
1
11 0
6
53
2
15 6
6 0
3
8
32
1
13 0
8
54
2
15 8
10 0
13
33
1
5 0
3
9
34
1
12 0
9
55
2
15 9
8 0
12
35
1
4 0
end_DTG
begin_DTG
0
2
0
39
2
14 2
6 0
2
36
2
14 0
10 0
2
1
42
2
14 3
7 0
3
38
2
14 1
8 0
2
2
44
2
14 4
10 0
4
40
2
14 2
0 0
0
0
4
0
53
2
14 11
6 0
5
47
2
14 7
1 0
7
45
2
14 5
9 0
11
37
2
14 0
3 0
2
6
49
2
14 8
11 0
8
46
2
14 6
13 0
4
2
54
2
14 12
10 0
7
51
2
14 9
9 0
9
48
2
14 7
12 0
12
41
2
14 2
4 0
4
3
55
2
14 13
8 0
8
52
2
14 10
13 0
10
50
2
14 8
2 0
13
43
2
14 3
5 0
0
0
0
0
end_DTG
begin_CG
3
15 1
14 3
8 1
3
15 1
14 2
11 1
3
15 1
14 3
12 1
3
15 1
14 2
11 1
3
15 1
14 3
13 1
3
15 1
14 3
12 1
4
15 2
14 4
7 1
11 1
3
15 1
14 4
10 1
4
15 2
14 5
10 1
12 1
4
15 2
14 5
11 1
13 1
5
15 3
14 6
7 1
8 1
13 1
3
15 1
14 5
9 1
3
15 1
14 5
13 1
4
15 2
14 6
9 1
12 1
15
15 20
6 2
7 3
10 5
8 4
0 1
1 1
11 5
9 4
13 6
12 5
2 1
3 1
4 1
5 1
15
14 20
6 2
7 3
10 5
8 4
0 1
1 1
11 5
9 4
13 6
12 5
2 1
3 1
4 1
5 1
end_CG
