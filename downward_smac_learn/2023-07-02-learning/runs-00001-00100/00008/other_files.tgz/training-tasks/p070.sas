begin_version
3
end_version
begin_metric
0
end_metric
57
begin_variable
var4
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var3
-1
54
Atom at-robot(loc_10_2)
Atom at-robot(loc_10_3)
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_10)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(lo




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
8
218
2
53 11
21 0
10
206
2
53 9
39 0
17
170
2
53 3
47 0
4
3
263
2
53 19
3 0
9
224
2
53 12
44 0
11
212
2
53 10
7 0
18
173
2
53 4
52 0
0
0
2
4
284
2
53 22
14 0
21
179
2
53 5
30 0
4
5
293
2
53 23
19 0
13
245
2
53 16
28 0
15
236
2
53 14
24 0
22
185
2
53 6
38 0
2
6
299
2
53 24
27 0
23
194
2
53 7
31 0
0
4
9
308
2
53 25
44 0
16
266
2
53 19
5 0
18
251
2
53 17
52 0
24
215
2
53 10
33 0
4
10
317
2
53 26
39 0
17
275
2
53 20
47 0
19
257
2
53 18
40 0
25
221
2
53 11
49 0
4
11
326
2
53 27
7 0
12
269
2
53 19
4 0
18
230
2
53 13
52 0
26
227
2
53 12
45 0
0
2
13
335
2
53 28
28 0
27
239
2
53 14
29 0
4
14
344
2
53 29
32 0
21
302
2
53 24
30 0
23
287
2
53 22
31 0
28
242
2
53 15
46 0
2
15
353
2
53 30
24 0
29
248
2
53 16
50 0
2
17
377
2
53 33
47 0
32
260
2
53 18
51 0
4
18
389
2
53 34
52 0
24
329
2
53 27
33 0
26
311
2
53 25
45 0
33
272
2
53 19
48 0
4
19
398
2
53 35
40 0
20
320
2
53 26
6 0
25
281
2
53 21
49 0
34
278
2
53 20
15 0
2
21
404
2
53 36
30 0
35
290
2
53 22
16 0
4
22
410
2
53 37
38 0
27
356
2
53 30
29 0
29
338
2
53 28
50 0
36
296
2
53 23
41 0
4
23
416
2
53 38
31 0
28
365
2
53 31
46 0
30
347
2
53 29
23 0
37
305
2
53 24
34 0
2
29
371
2
53 32
50 0
31
359
2
53 30
22 0
2
30
380
2
53 33
23 0
32
368
2
53 31
51 0
4
24
425
2
53 39
33 0
31
392
2
53 34
22 0
33
374
2
53 32
48 0
38
314
2
53 25
35 0
4
25
434
2
53 40
49 0
32
401
2
53 35
51 0
34
383
2
53 33
15 0
39
323
2
53 26
36 0
2
26
437
2
53 41
45 0
40
332
2
53 27
8 0
2
27
443
2
53 42
29 0
41
341
2
53 28
9 0
4
28
449
2
53 43
46 0
35
419
2
53 38
16 0
37
407
2
53 36
34 0
42
350
2
53 29
43 0
2
29
458
2
53 44
50 0
43
362
2
53 30
42 0
2
32
479
2
53 47
51 0
46
386
2
53 33
37 0
4
33
485
2
53 48
48 0
38
440
2
53 41
35 0
40
428
2
53 39
8 0
47
395
2
53 34
10 0
0
0
4
36
491
2
53 49
41 0
41
461
2
53 44
9 0
43
446
2
53 42
42 0
48
413
2
53 37
13 0
4
37
497
2
53 50
34 0
42
467
2
53 45
43 0
44
452
2
53 43
25 0
49
422
2
53 38
18 0
2
43
473
2
53 46
42 0
45
464
2
53 44
26 0
2
44
482
2
53 47
25 0
46
470
2
53 45
37 0
4
38
512
2
53 53
35 0
45
488
2
53 48
26 0
47
476
2
53 46
10 0
52
431
2
53 39
11 0
0
2
0
455
2
53 43
0 0
42
164
2
53 1
43 0
2
48
503
2
53 51
13 0
50
494
2
53 49
17 0
2
49
509
2
53 52
18 0
51
500
2
53 50
12 0
2
50
515
2
53 53
17 0
52
506
2
53 51
11 0
0
end_DTG
begin_CG
5
54 1
55 1
56 1
53 5
13 3
5
54 1
55 1
56 1
53 4
14 3
5
54 1
55 1
56 1
53 5
44 3
5
54 1
55 1
56 1
53 5
39 3
5
54 1
55 1
56 1
53 5
40 3
5
54 1
55 1
56 1
53 5
47 3
5
54 1
55 1
56 1
53 5
45 3
6
54 2
55 2
56 2
53 8
39 3
40 3
6
54 2
55 2
56 2
53 8
15 3
36 3
6
54 2
55 2
56 2
53 8
16 3
43 3
6
54 2
55 2
56 2
53 8
36 3
37 3
6
54 2
55 2
56 2
53 8
37 3
12 3
5
54 1
55 1
56 1
53 6
17 3
6
54 2
55 2
56 2
53 9
43 3
18 3
6
54 2
55 2
56 2
53 9
19 3
28 3
6
54 2
55 2
56 2
53 9
45 3
48 3
6
54 2
55 2
56 2
53 9
29 3
41 3
6
54 2
55 2
56 2
53 9
18 3
12 3
6
54 2
55 2
56 2
53 9
42 3
17 3
6
54 2
55 2
56 2
53 9
27 3
32 3
6
54 2
55 2
56 2
53 8
27 3
21 3
6
54 2
55 2
56 2
53 9
20 3
44 3
6
54 2
55 2
56 2
53 8
23 3
51 3
6
54 2
55 2
56 2
53 8
50 3
22 3
6
54 2
55 2
56 2
53 9
32 3
31 3
6
54 2
55 2
56 2
53 9
42 3
26 3
6
54 2
55 2
56 2
53 9
25 3
37 3
7
54 3
55 3
56 3
53 12
19 3
20 3
24 3
7
54 3
55 3
56 3
53 12
14 3
32 3
30 3
7
54 3
55 3
56 3
53 12
30 3
46 3
16 3
7
54 3
55 3
56 3
53 12
28 3
38 3
29 3
7
54 3
55 3
56 3
53 12
24 3
38 3
50 3
5
54 1
55 1
56 1
53 7
38 3
7
54 3
55 3
56 3
53 12
47 3
49 3
51 3
7
54 3
55 3
56 3
53 12
50 3
41 3
42 3
7
54 3
55 3
56 3
53 12
51 3
36 3
37 3
5
54 1
55 1
56 1
53 7
48 3
6
54 2
55 2
56 2
53 10
35 3
26 3
6
54 2
55 2
56 2
53 10
32 3
46 3
6
54 2
55 2
56 2
53 10
44 3
52 3
6
54 2
55 2
56 2
53 10
52 3
45 3
6
54 2
55 2
56 2
53 10
46 3
43 3
7
54 3
55 3
56 3
53 13
34 3
43 3
25 3
7
54 3
55 3
56 3
53 13
41 3
42 3
13 3
7
54 3
55 3
56 3
53 13
21 3
39 3
47 3
7
54 3
55 3
56 3
53 13
40 3
49 3
15 3
7
54 3
55 3
56 3
53 13
38 3
50 3
41 3
7
54 3
55 3
56 3
53 13
44 3
52 3
33 3
7
54 3
55 3
56 3
53 13
49 3
51 3
36 3
7
54 3
55 3
56 3
53 13
52 3
45 3
48 3
8
54 4
55 4
56 4
53 16
31 3
46 3
23 3
34 3
8
54 4
55 4
56 4
53 16
33 3
22 3
48 3
35 3
8
54 4
55 4
56 4
53 16
39 3
47 3
40 3
49 3
56
54 118
55 118
56 118
0 3
1 3
2 3
3 3
14 12
19 12
27 15
20 12
21 12
44 21
39 18
7 6
4 3
28 15
32 15
24 12
5 3
47 21
52 24
40 18
6 3
30 15
38 18
31 15
33 15
49 21
45 21
29 15
46 21
50 24
23 12
22 12
51 24
48 21
15 12
16 12
41 18
34 15
35 15
36 15
8 6
9 6
43 21
42 21
25 12
26 12
37 18
10 6
13 12
18 12
17 12
12 9
11 6
54
53 118
0 1
1 1
2 1
3 1
14 4
19 4
27 5
20 4
21 4
44 7
39 6
7 2
4 1
28 5
32 5
24 4
5 1
47 7
52 8
40 6
6 1
30 5
38 6
31 5
33 5
49 7
45 7
29 5
46 7
50 8
23 4
22 4
51 8
48 7
15 4
16 4
41 6
34 5
35 5
36 5
8 2
9 2
43 7
42 7
25 4
26 4
37 6
10 2
13 4
18 4
17 4
12 3
11 2
54
53 118
0 1
1 1
2 1
3 1
14 4
19 4
27 5
20 4
21 4
44 7
39 6
7 2
4 1
28 5
32 5
24 4
5 1
47 7
52 8
40 6
6 1
30 5
38 6
31 5
33 5
49 7
45 7
29 5
46 7
50 8
23 4
22 4
51 8
48 7
15 4
16 4
41 6
34 5
35 5
36 5
8 2
9 2
43 7
42 7
25 4
26 4
37 6
10 2
13 4
18 4
17 4
12 3
11 2
54
53 118
0 1
1 1
2 1
3 1
14 4
19 4
27 5
20 4
21 4
44 7
39 6
7 2
4 1
28 5
32 5
24 4
5 1
47 7
52 8
40 6
6 1
30 5
38 6
31 5
33 5
49 7
45 7
29 5
46 7
50 8
23 4
22 4
51 8
48 7
15 4
16 4
41 6
34 5
35 5
36 5
8 2
9 2
43 7
42 7
25 4
26 4
37 6
10 2
13 4
18 4
17 4
12 3
11 2
end_CG
