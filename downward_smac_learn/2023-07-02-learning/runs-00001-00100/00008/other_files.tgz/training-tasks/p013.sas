begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var2
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var1
-1
17
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
end_variable
begin_variable
var0
-1
16
Atom at(box1, loc_2_4)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
end_variable
16
begin_mutex_group
2
17 0
0 0
end_mutex_group
begin_mutex_group
2
17 1
10 0
end_mutex_group
begin_mutex_group
2
17 2
1 0
end_mutex_group
begin_mutex_group
2
17 3
2 0
end_mutex_group
begin_mutex_group
2
17 4
13 0
end_mutex_group
begin_mutex_group
2
17 5
7 0
end_mutex_group
begin_mutex_group
2
17 6
3 0
end_mutex_group
begin_mutex_group
2
17 7
14 0
end_mutex_group
begin_mutex_group
2
17 8
15 0
end_mutex_group
begin_mutex_group
2
17 9
4 0
end_mutex_group
begin_mutex_group
2
17 10
8 0
end_mutex_group
begin_mutex_group
2
17 11
12 0
end_mutex_group
begin_mutex_group
2
17 12
11 0
end_mutex_group
begin_mutex_group
2
17 13
5 0
end_mutex_group
begin_mutex_group
2
17 14
9 0
end_mutex_group
begin_mutex_group
2
17 15
6 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
3
11
end_state
begin_goal
1
17 1
end_goal
72
begin_operator
move loc_2_3 loc_2_4 right
1
0 0
1
0 16 0 1
0
end_operator
begin_operator
move loc_2_4 loc_2_3 left
0
1
0 16 1 0
0
end_operator
begin_operator
move loc_2_4 loc_3_4 down
1
10 0
1
0 16 1 2
0
end_operator
begin_operator
move loc_3_4 loc_2_4 up
1
0 0
1
0 16 2 1
0
end_operator
begin_operator
move loc_3_4 loc_3_5 right
1
1 0
1
0 16 2 3
0
end_operator
begin_operator
move loc_3_4 loc_4_4 down
1
13 0
1
0 16 2 5
0
end_operator
begin_operator
move loc_3_5 loc_3_4 left
1
10 0
1
0 16 3 2
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
7 0
1
0 16 3 6
0
end_operator
begin_operator
move loc_4_3 loc_4_4 right
1
13 0
1
0 16 4 5
0
end_operator
begin_operator
move loc_4_3 loc_5_3 down
1
14 0
1
0 16 4 8
0
end_operator
begin_operator
move loc_4_4 loc_3_4 up
1
10 0
1
0 16 5 2
0
end_operator
begin_operator
move loc_4_4 loc_4_3 left
1
2 0
1
0 16 5 4
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
7 0
1
0 16 5 6
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
1
15 0
1
0 16 5 9
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
1 0
1
0 16 6 3
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
13 0
1
0 16 6 5
0
end_operator
begin_operator
move loc_4_5 loc_5_5 down
1
4 0
1
0 16 6 10
0
end_operator
begin_operator
move loc_5_2 loc_5_3 right
1
14 0
1
0 16 7 8
0
end_operator
begin_operator
move loc_5_2 loc_6_2 down
1
8 0
1
0 16 7 11
0
end_operator
begin_operator
move loc_5_3 loc_4_3 up
1
2 0
1
0 16 8 4
0
end_operator
begin_operator
move loc_5_3 loc_5_2 left
1
3 0
1
0 16 8 7
0
end_operator
begin_operator
move loc_5_3 loc_5_4 right
1
15 0
1
0 16 8 9
0
end_operator
begin_operator
move loc_5_3 loc_6_3 down
1
12 0
1
0 16 8 12
0
end_operator
begin_operator
move loc_5_4 loc_4_4 up
1
13 0
1
0 16 9 5
0
end_operator
begin_operator
move loc_5_4 loc_5_3 left
1
14 0
1
0 16 9 8
0
end_operator
begin_operator
move loc_5_4 loc_5_5 right
1
4 0
1
0 16 9 10
0
end_operator
begin_operator
move loc_5_4 loc_6_4 down
1
11 0
1
0 16 9 13
0
end_operator
begin_operator
move loc_5_5 loc_4_5 up
1
7 0
1
0 16




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
check 0
switch 0
check 0
check 1
3
check 0
switch 1
check 0
check 1
4
check 0
switch 13
check 0
check 1
5
check 0
check 0
switch 10
check 0
check 1
6
check 0
switch 7
check 0
check 1
7
check 0
check 0
switch 13
check 0
check 1
8
check 0
switch 14
check 0
check 1
9
check 0
check 0
switch 10
check 0
check 1
10
check 0
switch 2
check 0
check 1
11
check 0
switch 7
check 0
check 1
12
check 0
switch 15
check 0
check 1
13
check 0
check 0
switch 1
check 0
check 1
14
check 0
switch 13
check 0
check 1
15
check 0
switch 4
check 0
check 1
16
check 0
check 0
switch 14
check 0
check 1
17
check 0
switch 8
check 0
check 1
18
check 0
check 0
switch 2
check 0
check 1
19
check 0
switch 3
check 0
check 1
20
check 0
switch 15
check 0
check 1
21
check 0
switch 12
check 0
check 1
22
check 0
check 0
switch 13
check 0
check 1
23
check 0
switch 14
check 0
check 1
24
check 0
switch 4
check 0
check 1
25
check 0
switch 11
check 0
check 1
26
check 0
check 0
switch 7
check 0
check 1
27
check 0
switch 15
check 0
check 1
28
check 0
check 0
switch 3
check 0
check 1
29
check 0
switch 12
check 0
check 1
30
check 0
switch 5
check 0
check 1
31
check 0
check 0
switch 14
check 0
check 1
32
check 0
switch 8
check 0
check 1
33
check 0
switch 11
check 0
check 1
34
check 0
switch 9
check 0
check 1
35
check 0
check 0
switch 15
check 0
check 1
36
check 0
switch 12
check 0
check 1
37
check 0
switch 6
check 0
check 1
38
check 0
check 0
switch 8
check 0
check 1
39
check 0
switch 9
check 0
check 1
40
check 0
check 0
switch 12
check 0
check 1
41
check 0
switch 5
check 0
check 1
42
check 0
switch 6
check 0
check 1
43
check 0
check 0
switch 11
check 0
check 1
44
check 0
switch 9
check 0
check 1
45
check 0
check 0
check 0
end_SG
begin_DTG
1
1
51
2
17 1
16 5
0
end_DTG
begin_DTG
1
1
61
2
17 5
16 10
0
end_DTG
begin_DTG
2
1
53
2
17 4
16 6
1
64
2
17 7
16 12
0
end_DTG
begin_DTG
2
1
59
2
17 7
16 9
1
67
2
17 10
16 14
0
end_DTG
begin_DTG
2
1
48
2
17 5
16 3
1
56
2
17 8
16 8
0
end_DTG
begin_DTG
2
1
55
2
17 10
16 7
1
71
2
17 14
16 16
0
end_DTG
begin_DTG
2
1
60
2
17 12
16 9
1
68
2
17 14
16 14
0
end_DTG
begin_DTG
1
1
49
2
17 4
16 4
2
0
48
3
17 5
16 3
4 0
0
61
3
17 5
16 10
1 0
end_DTG
begin_DTG
1
1
66
2
17 11
16 13
2
0
55
3
17 10
16 7
5 0
0
67
3
17 10
16 14
3 0
end_DTG
begin_DTG
1
1
57
2
17 11
16 8
2
0
68
3
17 14
16 14
6 0
0
71
3
17 14
16 16
5 0
end_DTG
begin_DTG
1
1
58
2
17 4
16 9
2
0
46
3
17 1
16 1
13 0
0
51
3
17 1
16 5
0 0
end_DTG
begin_DTG
2
1
52
2
17 8
16 5
1
63
2
17 11
16 11
2
0
60
3
17 12
16 9
6 0
0
70
3
17 12
16 16
15 0
end_DTG
begin_DTG
1
1
50
2
17 7
16 4
4
0
57
3
17 11
16 8
9 0
0
63
3
17 11
16 11
11 0
0
66
3
17 11
16 13
8 0
0
69
3
17 11
16 15
14 0
end_DTG
begin_DTG
2
1
46
2
17 1
16 1
1
65
2
17 8
16 13
4
0
47
3
17 4
16 2
15 0
0
49
3
17 4
16 4
7 0
0
53
3
17 4
16 6
2 0
0
58
3
17 4
16 9
10 0
end_DTG
begin_DTG
2
1
62
2
17 8
16 10
1
69
2
17 11
16 15
4
0
50
3
17 7
16 4
12 0
0
54
3
17 7
16 7
15 0
0
59
3
17 7
16 9
3 0
0
64
3
17 7
16 12
2 0
end_DTG
begin_DTG
3
1
47
2
17 4
16 2
1
54
2
17 7
16 7
1
70
2
17 12
16 16
4
0
52
3
17 8
16 5
11 0
0
56
3
17 8
16 8
4 0
0
62
3
17 8
16 10
14 0
0
65
3
17 8
16 13
13 0
end_DTG
begin_DTG
1
1
0
1
0 0
3
0
1
0
2
2
1
10 0
2
46
2
17 1
13 0
4
1
3
1
0 0
3
4
1
1 0
5
5
1
13 0
5
47
2
17 4
15 0
3
2
6
1
10 0
6
7
1
7 0
6
48
2
17 5
4 0
4
5
8
1
13 0
5
49
2
17 4
7 0
8
9
1
14 0
8
50
2
17 7
12 0
6
2
10
1
10 0
2
51
2
17 1
0 0
4
11
1
2 0
6
12
1
7 0
9
13
1
15 0
9
52
2
17 8
11 0
4
3
14
1
1 0
5
15
1
13 0
5
53
2
17 4
2 0
10
16
1
4 0
4
8
17
1
14 0
8
54
2
17 7
15 0
11
18
1
8 0
11
55
2
17 10
5 0
6
4
19
1
2 0
7
20
1
3 0
9
21
1
15 0
9
56
2
17 8
4 0
12
22
1
12 0
12
57
2
17 11
9 0
7
5
23
1
13 0
5
58
2
17 4
10 0
8
24
1
14 0
8
59
2
17 7
3 0
10
25
1
4 0
13
26
1
11 0
13
60
2
17 12
6 0
4
6
27
1
7 0
6
61
2
17 5
1 0
9
28
1
15 0
9
62
2
17 8
14 0
4
7
29
1
3 0
12
30
1
12 0
12
63
2
17 11
11 0
14
31
1
5 0
5
8
32
1
14 0
8
64
2
17 7
2 0
11
33
1
8 0
13
34
1
11 0
15
35
1
9 0
5
9
36
1
15 0
9
65
2
17 8
13 0
12
37
1
12 0
12
66
2
17 11
8 0
16
38
1
6 0
4
11
39
1
8 0
11
67
2
17 10
3 0
15
40
1
9 0
15
68
2
17 14
6 0
4
12
41
1
12 0
12
69
2
17 11
14 0
14
42
1
5 0
16
43
1
6 0
4
13
44
1
11 0
13
70
2
17 12
15 0
15
45
1
9 0
15
71
2
17 14
5 0
end_DTG
begin_DTG
0
2
0
51
2
16 5
0 0
4
46
2
16 1
13 0
0
0
4
1
58
2
16 9
10 0
3
53
2
16 6
2 0
5
49
2
16 4
7 0
8
47
2
16 2
15 0
2
2
61
2
16 10
1 0
9
48
2
16 3
4 0
0
4
3
64
2
16 12
2 0
6
59
2
16 9
3 0
8
54
2
16 7
15 0
11
50
2
16 4
12 0
4
4
65
2
16 13
13 0
7
62
2
16 10
14 0
9
56
2
16 8
4 0
12
52
2
16 5
11 0
0
2
6
67
2
16 14
3 0
13
55
2
16 7
5 0
4
7
69
2
16 15
14 0
10
66
2
16 13
8 0
12
63
2
16 11
11 0
14
57
2
16 8
9 0
2
8
70
2
16 16
15 0
15
60
2
16 9
6 0
0
2
13
71
2
16 16
5 0
15
68
2
16 14
6 0
0
end_DTG
begin_CG
3
17 1
16 3
10 1
3
17 1
16 3
7 1
4
17 2
16 4
13 1
14 1
4
17 2
16 4
14 1
8 1
4
17 2
16 4
7 1
15 1
4
17 2
16 4
8 1
9 1
4
17 2
16 4
11 1
9 1
3
17 1
16 4
13 1
3
17 1
16 4
12 1
3
17 1
16 4
12 1
3
17 1
16 4
13 1
4
17 2
16 5
15 1
12 1
3
17 1
16 5
14 1
4
17 2
16 6
10 1
15 1
4
17 2
16 6
15 1
12 1
5
17 3
16 7
13 1
14 1
11 1
17
17 26
0 1
10 3
1 1
2 2
13 6
7 3
3 2
14 6
15 7
4 2
8 3
12 5
11 4
5 2
9 3
6 2
17
16 26
0 1
10 3
1 1
2 2
13 6
7 3
3 2
14 6
15 7
4 2
8 3
12 5
11 4
5 2
9 3
6 2
end_CG
