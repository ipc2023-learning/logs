begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var2
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
22
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
end_variable
22
begin_mutex_group
2
23 0
0 0
end_mutex_group
begin_mutex_group
2
23 1
6 0
end_mutex_group
begin_mutex_group
2
23 2
11 0
end_mutex_group
begin_mutex_group
2
23 3
10 0
end_mutex_group
begin_mutex_group
2
23 4
4 0
end_mutex_group
begin_mutex_group
2
23 5
1 0
end_mutex_group
begin_mutex_group
2
23 6
7 0
end_mutex_group
begin_mutex_group
2
23 7
17 0
end_mutex_group
begin_mutex_group
2
23 8
20 0
end_mutex_group
begin_mutex_group
2
23 9
12 0
end_mutex_group
begin_mutex_group
2
23 10
19 0
end_mutex_group
begin_mutex_group
2
23 11
14 0
end_mutex_group
begin_mutex_group
2
23 12
2 0
end_mutex_group
begin_mutex_group
2
23 13
8 0
end_mutex_group
begin_mutex_group
2
23 14
18 0
end_mutex_group
begin_mutex_group
2
23 15
21 0
end_mutex_group
begin_mutex_group
2
23 16
13 0
end_mutex_group
begin_mutex_group
2
23 17
3 0
end_mutex_group
begin_mutex_group
2
23 18
9 0
end_mutex_group
begin_mutex_group
2
23 19
16 0
end_mutex_group
begin_mutex_group
2
23 20
15 0
end_mutex_group
begin_mutex_group
2
23 21
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
12
14
end_state
begin_goal
1
23 5
end_goal
98
begin_operator
move loc_2_2 loc_2_3 right
1
6 0
1
0 22 0 1
0
end_operator
begin_operator
move loc_2_2 loc_3_2 down
1
1 0
1
0 22 0 5
0
end_operator
begin_operator
move loc_2_3 loc_2_2 left
1
0 0
1
0 22 1 0
0
end_operator
begin_operator
move loc_2_3 loc_2_4 right
1
11 0
1
0 22 1 2
0
end_operator
begin_operator
move loc_2_3 loc_3_3 down
1
7 0
1
0 22 1 6
0
end_operator
begin_operator
move loc_2_4 loc_2_3 left
1
6 0
1
0 22 2 1
0
end_operator
begin_operator
move loc_2_4 loc_2_5 right
1
10 0
1
0 22 2 3
0
end_operator
begin_operator
move loc_2_4 loc_3_4 down
1
17 0
1
0 22 2 7
0
end_operator
begin_operator
move loc_2_5 loc_2_4 left
1
11 0
1
0 22 3 2
0
end_operator
begin_operator
move loc_2_5 loc_2_6 right
1
4 0
1
0 22 3 4
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
20 0
1
0 22 3 8
0
end_operator
begin_operator
move loc_2_6 loc_2_5 left
1
10 0
1
0 22 4 3
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
12 0
1
0 22 4 9
0
end_operator
begin_oper




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 0
check 0
switch 18
check 0
check 1
54
check 0
switch 9
check 0
check 1
55
check 0
switch 15
check 0
check 1
56
check 0
check 0
switch 21
check 0
check 1
57
check 0
switch 16
check 0
check 1
58
check 0
switch 5
check 0
check 1
59
check 0
check 0
switch 13
check 0
check 1
60
check 0
switch 15
check 0
check 1
61
check 0
check 0
check 0
end_SG
begin_DTG
1
1
64
2
23 1
22 2
0
end_DTG
begin_DTG
1
1
72
2
23 6
22 7
0
end_DTG
begin_DTG
1
1
84
2
23 13
22 14
0
end_DTG
begin_DTG
1
1
92
2
23 18
22 19
0
end_DTG
begin_DTG
2
1
65
2
23 3
22 2
1
80
2
23 9
22 11
0
end_DTG
begin_DTG
2
1
81
2
23 16
22 11
1
93
2
23 20
22 19
0
end_DTG
begin_DTG
1
1
66
2
23 2
22 3
2
0
62
3
23 1
22 0
11 0
0
64
3
23 1
22 2
0 0
end_DTG
begin_DTG
1
1
74
2
23 7
22 8
2
0
70
3
23 6
22 5
17 0
0
72
3
23 6
22 7
1 0
end_DTG
begin_DTG
1
1
87
2
23 14
22 15
2
0
82
3
23 13
22 12
18 0
0
84
3
23 13
22 14
2 0
end_DTG
begin_DTG
1
1
95
2
23 19
22 20
2
0
90
3
23 18
22 17
16 0
0
92
3
23 18
22 19
3 0
end_DTG
begin_DTG
2
1
63
2
23 2
22 1
1
78
2
23 8
22 10
2
0
65
3
23 3
22 2
4 0
0
68
3
23 3
22 4
11 0
end_DTG
begin_DTG
2
1
62
2
23 1
22 0
1
68
2
23 3
22 4
2
0
63
3
23 2
22 1
10 0
0
66
3
23 2
22 3
6 0
end_DTG
begin_DTG
2
1
73
2
23 8
22 7
1
88
2
23 11
22 16
2
0
69
3
23 9
22 4
14 0
0
80
3
23 9
22 11
4 0
end_DTG
begin_DTG
2
1
77
2
23 11
22 9
1
85
2
23 15
22 14
2
0
81
3
23 16
22 11
5 0
0
96
3
23 16
22 21
14 0
end_DTG
begin_DTG
2
1
69
2
23 9
22 4
1
96
2
23 16
22 21
2
0
77
3
23 11
22 9
13 0
0
88
3
23 11
22 16
12 0
end_DTG
begin_DTG
2
1
79
2
23 15
22 10
1
91
2
23 19
22 18
2
0
93
3
23 20
22 19
5 0
0
97
3
23 20
22 21
16 0
end_DTG
begin_DTG
2
1
90
2
23 18
22 17
1
97
2
23 20
22 21
2
0
91
3
23 19
22 18
15 0
0
95
3
23 19
22 20
9 0
end_DTG
begin_DTG
2
1
70
2
23 6
22 5
1
76
2
23 8
22 9
2
0
71
3
23 7
22 6
20 0
0
74
3
23 7
22 8
7 0
end_DTG
begin_DTG
2
1
82
2
23 13
22 12
1
89
2
23 15
22 16
2
0
83
3
23 14
22 13
21 0
0
87
3
23 14
22 15
8 0
end_DTG
begin_DTG
2
1
67
2
23 8
22 3
1
94
2
23 15
22 20
2
0
75
3
23 10
22 8
21 0
0
86
3
23 10
22 15
20 0
end_DTG
begin_DTG
2
1
71
2
23 7
22 6
1
86
2
23 10
22 15
4
0
67
3
23 8
22 3
19 0
0
73
3
23 8
22 7
12 0
0
76
3
23 8
22 9
17 0
0
78
3
23 8
22 10
10 0
end_DTG
begin_DTG
2
1
75
2
23 10
22 8
1
83
2
23 14
22 13
4
0
79
3
23 15
22 10
15 0
0
85
3
23 15
22 14
13 0
0
89
3
23 15
22 16
18 0
0
94
3
23 15
22 20
19 0
end_DTG
begin_DTG
3
1
0
1
6 0
1
62
2
23 1
11 0
5
1
1
1 0
4
0
2
1
0 0
2
3
1
11 0
2
63
2
23 2
10 0
6
4
1
7 0
5
1
5
1
6 0
1
64
2
23 1
0 0
3
6
1
10 0
3
65
2
23 3
4 0
7
7
1
17 0
5
2
8
1
11 0
2
66
2
23 2
6 0
4
9
1
4 0
8
10
1
20 0
8
67
2
23 8
19 0
4
3
11
1
10 0
3
68
2
23 3
11 0
9
12
1
12 0
9
69
2
23 9
14 0
3
0
13
1
0 0
6
14
1
7 0
6
70
2
23 6
17 0
4
1
15
1
6 0
5
16
1
1 0
7
17
1
17 0
7
71
2
23 7
20 0
5
2
18
1
11 0
6
19
1
7 0
6
72
2
23 6
1 0
8
20
1
20 0
8
73
2
23 8
12 0
6
3
21
1
10 0
7
22
1
17 0
7
74
2
23 7
7 0
9
23
1
12 0
10
24
1
19 0
10
75
2
23 10
21 0
5
4
25
1
4 0
8
26
1
20 0
8
76
2
23 8
17 0
11
27
1
14 0
11
77
2
23 11
13 0
5
8
28
1
20 0
8
78
2
23 8
10 0
11
29
1
14 0
15
30
1
21 0
15
79
2
23 15
15 0
5
9
31
1
12 0
9
80
2
23 9
4 0
10
32
1
19 0
16
33
1
13 0
16
81
2
23 16
5 0
3
13
34
1
8 0
13
82
2
23 13
18 0
17
35
1
3 0
4
12
36
1
2 0
14
37
1
18 0
14
83
2
23 14
21 0
18
38
1
9 0
5
13
39
1
8 0
13
84
2
23 13
2 0
15
40
1
21 0
15
85
2
23 15
13 0
19
41
1
16 0
6
10
42
1
19 0
10
86
2
23 10
20 0
14
43
1
18 0
14
87
2
23 14
8 0
16
44
1
13 0
20
45
1
15 0
5
11
46
1
14 0
11
88
2
23 11
12 0
15
47
1
21 0
15
89
2
23 15
18 0
21
48
1
5 0
3
12
49
1
2 0
18
50
1
9 0
18
90
2
23 18
16 0
4
13
51
1
8 0
17
52
1
3 0
19
53
1
16 0
19
91
2
23 19
15 0
5
14
54
1
18 0
18
55
1
9 0
18
92
2
23 18
3 0
20
56
1
15 0
20
93
2
23 20
5 0
5
15
57
1
21 0
15
94
2
23 15
19 0
19
58
1
16 0
19
95
2
23 19
9 0
21
59
1
5 0
4
16
60
1
13 0
16
96
2
23 16
14 0
20
61
1
15 0
20
97
2
23 20
16 0
end_DTG
begin_DTG
0
2
0
64
2
22 2
0 0
2
62
2
22 0
11 0
2
1
66
2
22 3
6 0
3
63
2
22 1
10 0
2
2
68
2
22 4
11 0
4
65
2
22 2
4 0
0
0
2
5
72
2
22 7
1 0
7
70
2
22 5
17 0
2
6
74
2
22 8
7 0
8
71
2
22 6
20 0
4
3
78
2
22 10
10 0
7
76
2
22 9
17 0
9
73
2
22 7
12 0
10
67
2
22 3
19 0
2
4
80
2
22 11
4 0
11
69
2
22 4
14 0
2
8
86
2
22 15
20 0
15
75
2
22 8
21 0
2
9
88
2
22 16
12 0
16
77
2
22 9
13 0
0
2
12
84
2
22 14
2 0
14
82
2
22 12
18 0
2
13
87
2
22 15
8 0
15
83
2
22 13
21 0
4
10
94
2
22 20
19 0
14
89
2
22 16
18 0
16
85
2
22 14
13 0
20
79
2
22 10
15 0
2
11
96
2
22 21
14 0
21
81
2
22 11
5 0
0
2
17
92
2
22 19
3 0
19
90
2
22 17
16 0
2
18
95
2
22 20
9 0
20
91
2
22 18
15 0
2
19
97
2
22 21
16 0
21
93
2
22 19
5 0
0
end_DTG
begin_CG
3
23 1
22 3
6 1
3
23 1
22 3
7 1
3
23 1
22 3
8 1
3
23 1
22 3
9 1
4
23 2
22 4
10 1
12 1
4
23 2
22 4
13 1
15 1
3
23 1
22 4
11 1
3
23 1
22 4
17 1
3
23 1
22 4
18 1
3
23 1
22 4
16 1
4
23 2
22 5
11 1
20 1
4
23 2
22 5
6 1
10 1
4
23 2
22 5
20 1
14 1
4
23 2
22 5
14 1
21 1
4
23 2
22 5
12 1
13 1
4
23 2
22 5
21 1
16 1
4
23 2
22 5
9 1
15 1
4
23 2
22 5
7 1
20 1
4
23 2
22 5
8 1
21 1
4
23 2
22 5
20 1
21 1
4
23 2
22 6
17 1
19 1
4
23 2
22 6
19 1
18 1
23
23 36
0 1
6 3
11 4
10 4
4 2
1 1
7 3
17 4
20 6
12 4
19 4
14 4
2 1
8 3
18 4
21 6
13 4
3 1
9 3
16 4
15 4
5 2
23
22 36
0 1
6 3
11 4
10 4
4 2
1 1
7 3
17 4
20 6
12 4
19 4
14 4
2 1
8 3
18 4
21 6
13 4
3 1
9 3
16 4
15 4
5 2
end_CG
