begin_version
3
end_version
begin_metric
0
end_metric
37
begin_variable
var21
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var2
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var1
-1
40
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
35
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_8)
end_variable
35
begin_mutex_group
2
36 0
3 0
end_mutex_group
begin_mutex_group
2
36 1
12 0
end_mutex_group
begin_mutex_group
2
36 2
18 0
end_mutex_group
begin_mutex_group
2
36 3
13 0
end_mutex_group
begin_mutex_group
2
36 4
4 0
end_mutex_group
begin_mutex_group
2
36 5
9 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





11
33
1
5 0
17
34
1
23 0
17
142
2
36 17
26 0
4
10
35
1
14 0
10
143
2
36 10
28 0
18
36
1
15 0
18
144
2
36 18
21 0
5
5
37
1
9 0
5
145
2
36 5
3 0
13
38
1
16 0
13
146
2
36 13
32 0
19
39
1
0 0
5
6
40
1
22 0
6
147
2
36 6
12 0
12
41
1
8 0
14
42
1
32 0
14
148
2
36 14
34 0
8
7
43
1
29 0
7
149
2
36 7
18 0
13
44
1
16 0
13
150
2
36 13
8 0
15
45
1
34 0
15
151
2
36 15
33 0
20
46
1
17 0
20
152
2
36 20
10 0
8
8
47
1
30 0
8
153
2
36 8
13 0
14
48
1
32 0
14
154
2
36 14
16 0
16
49
1
33 0
16
155
2
36 16
23 0
21
50
1
24 0
21
156
2
36 21
19 0
8
9
51
1
28 0
9
157
2
36 9
4 0
15
52
1
34 0
15
158
2
36 15
32 0
17
53
1
23 0
17
159
2
36 17
15 0
22
54
1
31 0
22
160
2
36 22
27 0
6
10
55
1
14 0
16
56
1
33 0
16
161
2
36 16
34 0
18
57
1
15 0
23
58
1
26 0
23
162
2
36 23
25 0
5
11
59
1
5 0
17
60
1
23 0
17
163
2
36 17
33 0
24
61
1
21 0
24
164
2
36 24
20 0
2
12
62
1
8 0
12
165
2
36 12
9 0
5
14
63
1
32 0
14
166
2
36 14
29 0
21
64
1
24 0
21
167
2
36 21
31 0
26
65
1
10 0
6
15
66
1
34 0
15
168
2
36 15
30 0
20
67
1
17 0
22
68
1
31 0
22
169
2
36 22
26 0
27
69
1
19 0
8
16
70
1
33 0
16
170
2
36 16
28 0
21
71
1
24 0
21
171
2
36 21
17 0
23
72
1
26 0
23
172
2
36 23
21 0
28
73
1
27 0
28
173
2
36 28
6 0
7
17
74
1
23 0
17
174
2
36 17
14 0
22
75
1
31 0
22
175
2
36 22
24 0
24
76
1
21 0
29
77
1
25 0
29
176
2
36 29
7 0
6
18
78
1
15 0
18
177
2
36 18
5 0
23
79
1
26 0
23
178
2
36 23
31 0
30
80
1
20 0
30
179
2
36 30
11 0
3
26
81
1
10 0
26
180
2
36 26
19 0
32
82
0
5
20
83
1
17 0
20
181
2
36 20
32 0
25
84
1
1 0
27
85
1
19 0
27
182
2
36 27
27 0
6
21
86
1
24 0
21
183
2
36 21
34 0
26
87
1
10 0
26
184
2
36 26
1 0
28
88
1
27 0
28
185
2
36 28
25 0
7
22
89
1
31 0
22
186
2
36 22
33 0
27
90
1
19 0
27
187
2
36 27
10 0
29
91
1
25 0
29
188
2
36 29
20 0
33
92
1
6 0
6
23
93
1
26 0
23
189
2
36 23
23 0
28
94
1
27 0
28
190
2
36 28
19 0
30
95
1
20 0
34
96
1
7 0
6
24
97
1
21 0
24
191
2
36 24
15 0
29
98
1
25 0
29
192
2
36 29
27 0
35
99
1
11 0
35
193
2
36 33
2 0
1
32
100
0
3
25
101
1
1 0
31
102
0
36
103
0
4
28
104
1
27 0
28
194
2
36 28
31 0
34
105
1
7 0
34
195
2
36 32
11 0
4
29
106
1
25 0
29
196
2
36 29
26 0
33
107
1
6 0
35
108
1
11 0
5
30
109
1
20 0
30
197
2
36 30
21 0
34
110
1
7 0
34
198
2
36 32
6 0
39
111
1
2 0
2
32
112
0
37
113
0
2
36
114
0
38
115
0
1
37
116
0
2
35
117
1
11 0
35
199
2
36 33
20 0
end_DTG
begin_DTG
0
2
0
122
2
35 2
3 0
2
118
2
35 0
18 0
2
1
125
2
35 3
12 0
3
120
2
35 1
13 0
2
2
127
2
35 4
18 0
4
123
2
35 2
4 0
0
2
0
145
2
35 12
3 0
12
119
2
35 0
8 0
4
1
147
2
35 13
12 0
5
132
2
35 7
9 0
7
129
2
35 5
29 0
13
121
2
35 1
16 0
4
2
149
2
35 14
18 0
6
135
2
35 8
22 0
8
131
2
35 6
30 0
14
124
2
35 2
32 0
4
3
153
2
35 15
13 0
7
138
2
35 9
29 0
9
133
2
35 7
28 0
15
126
2
35 3
34 0
4
4
157
2
35 16
4 0
8
141
2
35 10
30 0
10
136
2
35 8
14 0
16
128
2
35 4
33 0
2
9
143
2
35 11
28 0
11
139
2
35 9
5 0
0
2
5
165
2
35 19
9 0
19
130
2
35 5
0 0
2
12
150
2
35 14
8 0
14
146
2
35 12
32 0
4
7
166
2
35 20
29 0
13
154
2
35 15
16 0
15
148
2
35 13
34 0
20
134
2
35 7
17 0
4
8
168
2
35 21
30 0
14
158
2
35 16
32 0
16
151
2
35 14
33 0
21
137
2
35 8
24 0
4
9
170
2
35 22
28 0
15
161
2
35 17
34 0
17
155
2
35 15
23 0
22
140
2
35 9
31 0
4
10
174
2
35 23
14 0
16
163
2
35 18
33 0
18
159
2
35 16
15 0
23
142
2
35 10
26 0
2
11
177
2
35 24
5 0
24
144
2
35 11
21 0
0
2
14
181
2
35 26
32 0
26
152
2
35 14
10 0
4
15
183
2
35 27
34 0
20
171
2
35 22
17 0
22
167
2
35 20
31 0
27
156
2
35 15
19 0
4
16
186
2
35 28
33 0
21
175
2
35 23
24 0
23
169
2
35 21
26 0
28
160
2
35 16
27 0
4
17
189
2
35 29
23 0
22
178
2
35 24
31 0
24
172
2
35 22
21 0
29
162
2
35 17
25 0
2
18
191
2
35 30
15 0
30
164
2
35 18
20 0
0
2
25
184
2
35 27
1 0
27
180
2
35 25
19 0
2
26
187
2
35 28
10 0
28
182
2
35 26
27 0
4
22
194
2
35 33
31 0
27
190
2
35 29
19 0
29
185
2
35 27
25 0
31
173
2
35 22
6 0
4
23
196
2
35 34
26 0
28
192
2
35 30
27 0
30
188
2
35 28
20 0
32
176
2
35 23
7 0
2
24
197
2
35 35
21 0
33
179
2
35 24
11 0
0
2
31
198
2
35 35
6 0
33
195
2
35 33
11 0
2
30
199
2
35 39
20 0
34
193
2
35 30
2 0
0
end_DTG
begin_CG
3
36 1
35 2
8 1
3
36 1
35 3
10 1
3
36 1
35 2
11 1
4
36 2
35 4
12 1
9 1
4
36 2
35 4
13 1
28 1
4
36 2
35 4
14 1
15 1
4
36 2
35 4
27 1
7 1
3
36 1
35 4
25 1
4
36 2
35 5
9 1
16 1
4
36 2
35 5
22 1
8 1
4
36 2
35 5
17 1
19 1
4
36 2
35 5
20 1
7 1
4
36 2
35 5
18 1
22 1
4
36 2
35 5
18 1
30 1
4
36 2
35 5
28 1
23 1
4
36 2
35 5
23 1
21 1
4
36 2
35 5
22 1
32 1
4
36 2
35 5
32 1
24 1
5
36 3
35 6
12 1
13 1
29 1
5
36 3
35 6
24 1
10 1
27 1
5
36 3
35 6
21 1
25 1
11 1
5
36 3
35 6
15 1
26 1
20 1
3
36 1
35 5
29 1
4
36 2
35 6
33 1
26 1
4
36 2
35 6
34 1
31 1
4
36 2
35 6
26 1
27 1
5
36 3
35 7
23 1
31 1
25 1
5
36 3
35 7
31 1
19 1
25 1
5
36 3
35 7
30 1
14 1
33 1
5
36 3
35 7
22 1
30 1
32 1
5
36 3
35 7
29 1
28 1
34 1
6
36 4
35 8
33 1
24 1
26 1
27 1
6
36 4
35 8
29 1
16 1
34 1
17 1
6
36 4
35 8
28 1
34 1
23 1
31 1
6
36 4
35 8
30 1
32 1
33 1
24 1
36
36 82
3 2
12 4
18 5
13 4
4 2
9 4
22 5
29 7
30 7
28 7
14 4
5 2
8 4
16 4
32 8
34 8
33 8
23 6
15 4
0 1
17 4
24 6
31 8
26 7
21 5
1 1
10 4
19 5
27 7
25 6
20 5
6 2
7 3
11 4
2 1
36
35 82
3 2
12 4
18 5
13 4
4 2
9 4
22 5
29 7
30 7
28 7
14 4
5 2
8 4
16 4
32 8
34 8
33 8
23 6
15 4
0 1
17 4
24 6
31 8
26 7
21 5
1 1
10 4
19 5
27 7
25 6
20 5
6 2
7 3
11 4
2 1
end_CG
