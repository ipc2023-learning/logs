begin_version
3
end_version
begin_metric
0
end_metric
70
begin_variable
var6
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_12_11)
NegatedAtom clear(loc_12_11)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_12_9)
NegatedAtom clear(loc_12_9)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var65
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var42
-1
2
Atom clear




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8
657
2
65 56
38 0
46
585
2
65 49
63 0
48
565
2
65 47
39 0
55
497
2
65 39
40 0
2
47
605
2
65 50
49 0
49
581
2
65 48
59 0
4
39
681
2
65 58
31 0
40
589
2
65 49
26 0
48
509
2
65 41
39 0
57
505
2
65 40
60 0
2
51
685
2
65 58
16 0
57
621
2
65 52
60 0
0
2
44
709
2
65 61
61 0
60
537
2
65 45
54 0
4
45
721
2
65 62
64 0
52
649
2
65 55
41 0
54
629
2
65 53
52 0
61
553
2
65 46
29 0
4
46
729
2
65 63
63 0
53
661
2
65 56
47 0
55
641
2
65 54
40 0
62
569
2
65 47
17 0
2
54
669
2
65 57
52 0
56
653
2
65 55
50 0
4
48
741
2
65 64
39 0
55
689
2
65 58
40 0
57
665
2
65 56
60 0
63
593
2
65 49
33 0
4
49
749
2
65 65
59 0
50
673
2
65 57
25 0
56
613
2
65 51
50 0
64
609
2
65 50
30 0
0
2
58
713
2
65 61
13 0
60
697
2
65 59
54 0
4
0
633
2
65 53
20 0
52
193
2
65 0
41 0
59
725
2
65 62
24 0
61
701
2
65 60
29 0
2
60
733
2
65 63
54 0
62
717
2
65 61
17 0
0
2
2
677
2
65 57
42 0
56
205
2
65 2
50 0
2
3
693
2
65 58
35 0
57
217
2
65 3
60 0
end_DTG
begin_CG
6
66 1
67 1
68 1
69 1
65 6
42 4
6
66 1
67 1
68 1
69 1
65 6
43 4
6
66 1
67 1
68 1
69 1
65 5
20 4
6
66 1
67 1
68 1
69 1
65 6
44 4
6
66 1
67 1
68 1
69 1
65 5
21 4
6
66 1
67 1
68 1
69 1
65 5
22 4
6
66 1
67 1
68 1
69 1
65 6
18 4
6
66 1
67 1
68 1
69 1
65 5
48 4
6
66 1
67 1
68 1
69 1
65 6
45 4
6
66 1
67 1
68 1
69 1
65 5
46 4
6
66 1
67 1
68 1
69 1
65 5
19 4
6
66 1
67 1
68 1
69 1
65 6
53 4
6
66 1
67 1
68 1
69 1
65 5
23 4
6
66 1
67 1
68 1
69 1
65 5
24 4
7
66 2
67 2
68 2
69 2
65 10
44 4
28 4
7
66 2
67 2
68 2
69 2
65 10
18 4
51 4
7
66 2
67 2
68 2
69 2
65 10
19 4
25 4
7
66 2
67 2
68 2
69 2
65 10
52 4
29 4
6
66 1
67 1
68 1
69 1
65 7
45 4
6
66 1
67 1
68 1
69 1
65 7
26 4
6
66 1
67 1
68 1
69 1
65 6
54 4
6
66 1
67 1
68 1
69 1
65 7
28 4
6
66 1
67 1
68 1
69 1
65 7
34 4
6
66 1
67 1
68 1
69 1
65 7
61 4
6
66 1
67 1
68 1
69 1
65 6
54 4
6
66 1
67 1
68 1
69 1
65 7
60 4
6
66 1
67 1
68 1
69 1
65 7
59 4
6
66 1
67 1
68 1
69 1
65 7
48 4
7
66 2
67 2
68 2
69 2
65 11
43 4
21 4
7
66 2
67 2
68 2
69 2
65 11
47 4
54 4
7
66 2
67 2
68 2
69 2
65 11
35 4
60 4
7
66 2
67 2
68 2
69 2
65 10
46 4
59 4
7
66 2
67 2
68 2
69 2
65 11
57 4
46 4
7
66 2
67 2
68 2
69 2
65 11
42 4
50 4
8
66 3
67 3
68 3
69 3
65 15
22 4
27 4
46 4
8
66 3
67 3
68 3
69 3
65 15
42 4
43 4
30 4
8
66 3
67 3
68 3
69 3
65 15
51 4
48 4
56 4
8
66 3
67 3
68 3
69 3
65 15
45 4
55 4
53 4
8
66 3
67 3
68 3
69 3
65 15
57 4
58 4
49 4
8
66 3
67 3
68 3
69 3
65 15
49 4
59 4
50 4
8
66 3
67 3
68 3
69 3
65 15
49 4
52 4
50 4
8
66 3
67 3
68 3
69 3
65 15
61 4
47 4
54 4
7
66 2
67 2
68 2
69 2
65 12
44 4
33 4
7
66 2
67 2
68 2
69 2
65 12
35 4
44 4
7
66 2
67 2
68 2
69 2
65 12
42 4
43 4
7
66 2
67 2
68 2
69 2
65 12
51 4
37 4
8
66 3
67 3
68 3
69 3
65 16
34 4
32 4
31 4
7
66 2
67 2
68 2
69 2
65 12
64 4
52 4
8
66 3
67 3
68 3
69 3
65 16
36 4
27 4
57 4
8
66 3
67 3
68 3
69 3
65 16
38 4
63 4
39 4
8
66 3
67 3
68 3
69 3
65 16
40 4
60 4
33 4
8
66 3
67 3
68 3
69 3
65 16
45 4
36 4
55 4
8
66 3
67 3
68 3
69 3
65 16
63 4
47 4
40 4
8
66 3
67 3
68 3
69 3
65 16
37 4
62 4
61 4
9
66 4
67 4
68 4
69 4
65 20
20 4
41 4
24 4
29 4
8
66 3
67 3
68 3
69 3
65 16
51 4
56 4
62 4
8
66 3
67 3
68 3
69 3
65 16
55 4
57 4
58 4
9
66 4
67 4
68 4
69 4
65 20
48 4
56 4
32 4
38 4
8
66 3
67 3
68 3
69 3
65 16
56 4
62 4
63 4
9
66 4
67 4
68 4
69 4
65 20
31 4
26 4
39 4
60 4
9
66 4
67 4
68 4
69 4
65 20
59 4
25 4
50 4
30 4
9
66 4
67 4
68 4
69 4
65 20
53 4
23 4
64 4
41 4
9
66 4
67 4
68 4
69 4
65 20
55 4
53 4
58 4
64 4
9
66 4
67 4
68 4
69 4
65 20
58 4
64 4
49 4
52 4
9
66 4
67 4
68 4
69 4
65 20
62 4
61 4
63 4
47 4
69
66 140
67 140
68 140
69 140
20 12
0 4
42 24
35 20
1 4
2 4
3 4
44 24
43 24
21 12
4 4
14 8
28 16
5 4
6 4
18 12
15 8
7 4
22 12
8 4
45 24
51 28
36 20
48 28
27 12
34 20
9 4
37 20
55 28
56 28
57 32
32 16
46 28
10 4
11 4
53 28
62 32
58 28
38 20
31 16
26 12
19 12
12 4
23 12
61 32
64 32
63 32
49 28
39 20
59 32
25 12
16 8
41 20
47 24
52 28
40 20
50 28
60 32
13 4
24 12
54 32
29 16
17 8
33 16
30 16
66
65 140
20 3
0 1
42 6
35 5
1 1
2 1
3 1
44 6
43 6
21 3
4 1
14 2
28 4
5 1
6 1
18 3
15 2
7 1
22 3
8 1
45 6
51 7
36 5
48 7
27 3
34 5
9 1
37 5
55 7
56 7
57 8
32 4
46 7
10 1
11 1
53 7
62 8
58 7
38 5
31 4
26 3
19 3
12 1
23 3
61 8
64 8
63 8
49 7
39 5
59 8
25 3
16 2
41 5
47 6
52 7
40 5
50 7
60 8
13 1
24 3
54 8
29 4
17 2
33 4
30 4
66
65 140
20 3
0 1
42 6
35 5
1 1
2 1
3 1
44 6
43 6
21 3
4 1
14 2
28 4
5 1
6 1
18 3
15 2
7 1
22 3
8 1
45 6
51 7
36 5
48 7
27 3
34 5
9 1
37 5
55 7
56 7
57 8
32 4
46 7
10 1
11 1
53 7
62 8
58 7
38 5
31 4
26 3
19 3
12 1
23 3
61 8
64 8
63 8
49 7
39 5
59 8
25 3
16 2
41 5
47 6
52 7
40 5
50 7
60 8
13 1
24 3
54 8
29 4
17 2
33 4
30 4
66
65 140
20 3
0 1
42 6
35 5
1 1
2 1
3 1
44 6
43 6
21 3
4 1
14 2
28 4
5 1
6 1
18 3
15 2
7 1
22 3
8 1
45 6
51 7
36 5
48 7
27 3
34 5
9 1
37 5
55 7
56 7
57 8
32 4
46 7
10 1
11 1
53 7
62 8
58 7
38 5
31 4
26 3
19 3
12 1
23 3
61 8
64 8
63 8
49 7
39 5
59 8
25 3
16 2
41 5
47 6
52 7
40 5
50 7
60 8
13 1
24 3
54 8
29 4
17 2
33 4
30 4
66
65 140
20 3
0 1
42 6
35 5
1 1
2 1
3 1
44 6
43 6
21 3
4 1
14 2
28 4
5 1
6 1
18 3
15 2
7 1
22 3
8 1
45 6
51 7
36 5
48 7
27 3
34 5
9 1
37 5
55 7
56 7
57 8
32 4
46 7
10 1
11 1
53 7
62 8
58 7
38 5
31 4
26 3
19 3
12 1
23 3
61 8
64 8
63 8
49 7
39 5
59 8
25 3
16 2
41 5
47 6
52 7
40 5
50 7
60 8
13 1
24 3
54 8
29 4
17 2
33 4
30 4
end_CG
