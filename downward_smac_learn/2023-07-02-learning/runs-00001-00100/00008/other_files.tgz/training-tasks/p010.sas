begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var6
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var2
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var1
-1
22
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
end_variable
22
begin_mutex_group
2
23 0
4 0
end_mutex_group
begin_mutex_group
2
23 1
10 0
end_mutex_group
begin_mutex_group
2
23 2
11 0
end_mutex_group
begin_mutex_group
2
23 3
6 0
end_mutex_group
begin_mutex_group
2
23 4
0 0
end_mutex_group
begin_mutex_group
2
23 5
12 0
end_mutex_group
begin_mutex_group
2
23 6
20 0
end_mutex_group
begin_mutex_group
2
23 7
17 0
end_mutex_group
begin_mutex_group
2
23 8
7 0
end_mutex_group
begin_mutex_group
2
23 9
1 0
end_mutex_group
begin_mutex_group
2
23 10
14 0
end_mutex_group
begin_mutex_group
2
23 11
19 0
end_mutex_group
begin_mutex_group
2
23 12
13 0
end_mutex_group
begin_mutex_group
2
23 13
21 0
end_mutex_group
begin_mutex_group
2
23 14
18 0
end_mutex_group
begin_mutex_group
2
23 15
8 0
end_mutex_group
begin_mutex_group
2
23 16
2 0
end_mutex_group
begin_mutex_group
2
23 17
5 0
end_mutex_group
begin_mutex_group
2
23 18
15 0
end_mutex_group
begin_mutex_group
2
23 19
16 0
end_mutex_group
begin_mutex_group
2
23 20
9 0
end_mutex_group
begin_mutex_group
2
23 21
3 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
16
14
end_state
begin_goal
1
23 9
end_goal
98
begin_operator
move loc_2_2 loc_2_3 right
1
10 0
1
0 22 0 1
0
end_operator
begin_operator
move loc_2_2 loc_3_2 down
1
12 0
1
0 22 0 5
0
end_operator
begin_operator
move loc_2_3 loc_2_2 left
1
4 0
1
0 22 1 0
0
end_operator
begin_operator
move loc_2_3 loc_2_4 right
1
11 0
1
0 22 1 2
0
end_operator
begin_operator
move loc_2_3 loc_3_3 down
1
20 0
1
0 22 1 6
0
end_operator
begin_operator
move loc_2_4 loc_2_3 left
1
10 0
1
0 22 2 1
0
end_operator
begin_operator
move loc_2_4 loc_2_5 right
1
6 0
1
0 22 2 3
0
end_operator
begin_operator
move loc_2_4 loc_3_4 down
1
17 0
1
0 22 2 7
0
end_operator
begin_operator
move loc_2_5 loc_2_4 left
1
11 0
1
0 22 3 2
0
end_operator
begin_operator
move loc_2_5 loc_2_6 right
1
0 0
1
0 22 3 4
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
7 0
1
0 22 3 8
0
end_operator
begin_operator
move loc_2_6 loc_2_5 left
1
6 0
1
0 22 4 3
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
1 0
1
0 22 4 9
0
end_operator
begin_oper




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 0
check 0
switch 18
check 0
check 1
54
check 0
switch 15
check 0
check 1
55
check 0
switch 9
check 0
check 1
56
check 0
check 0
switch 8
check 0
check 1
57
check 0
switch 16
check 0
check 1
58
check 0
switch 3
check 0
check 1
59
check 0
check 0
switch 2
check 0
check 1
60
check 0
switch 9
check 0
check 1
61
check 0
check 0
check 0
end_SG
begin_DTG
1
1
67
2
23 3
22 2
0
end_DTG
begin_DTG
1
1
75
2
23 8
22 7
0
end_DTG
begin_DTG
1
1
87
2
23 15
22 14
0
end_DTG
begin_DTG
1
1
95
2
23 20
22 19
0
end_DTG
begin_DTG
2
1
66
2
23 1
22 2
1
78
2
23 5
22 10
0
end_DTG
begin_DTG
2
1
79
2
23 12
22 10
1
94
2
23 18
22 19
0
end_DTG
begin_DTG
1
1
64
2
23 2
22 1
2
0
67
3
23 3
22 2
0 0
0
69
3
23 3
22 4
11 0
end_DTG
begin_DTG
1
1
72
2
23 7
22 6
2
0
75
3
23 8
22 7
1 0
0
77
3
23 8
22 9
17 0
end_DTG
begin_DTG
1
1
85
2
23 14
22 13
2
0
87
3
23 15
22 14
2 0
0
89
3
23 15
22 16
18 0
end_DTG
begin_DTG
1
1
93
2
23 19
22 18
2
0
95
3
23 20
22 19
3 0
0
97
3
23 20
22 21
16 0
end_DTG
begin_DTG
2
1
68
2
23 2
22 3
1
80
2
23 6
22 11
2
0
62
3
23 1
22 0
11 0
0
66
3
23 1
22 2
4 0
end_DTG
begin_DTG
2
1
62
2
23 1
22 0
1
69
2
23 3
22 4
2
0
64
3
23 2
22 1
6 0
0
68
3
23 2
22 3
10 0
end_DTG
begin_DTG
2
1
74
2
23 6
22 7
1
82
2
23 10
22 12
2
0
63
3
23 5
22 0
14 0
0
78
3
23 5
22 10
4 0
end_DTG
begin_DTG
2
1
71
2
23 10
22 5
1
86
2
23 13
22 14
2
0
79
3
23 12
22 10
5 0
0
90
3
23 12
22 17
14 0
end_DTG
begin_DTG
2
1
63
2
23 5
22 0
1
90
2
23 12
22 17
2
0
71
3
23 10
22 5
13 0
0
82
3
23 10
22 12
12 0
end_DTG
begin_DTG
2
1
81
2
23 13
22 11
1
96
2
23 19
22 20
2
0
91
3
23 18
22 17
16 0
0
94
3
23 18
22 19
5 0
end_DTG
begin_DTG
2
1
91
2
23 18
22 17
1
97
2
23 20
22 21
2
0
93
3
23 19
22 18
9 0
0
96
3
23 19
22 20
15 0
end_DTG
begin_DTG
2
1
70
2
23 6
22 5
1
77
2
23 8
22 9
2
0
72
3
23 7
22 6
7 0
0
76
3
23 7
22 8
20 0
end_DTG
begin_DTG
2
1
83
2
23 13
22 12
1
89
2
23 15
22 16
2
0
85
3
23 14
22 13
8 0
0
88
3
23 14
22 15
21 0
end_DTG
begin_DTG
2
1
65
2
23 6
22 1
1
92
2
23 13
22 18
2
0
73
3
23 11
22 6
21 0
0
84
3
23 11
22 13
20 0
end_DTG
begin_DTG
2
1
76
2
23 7
22 8
1
84
2
23 11
22 13
4
0
65
3
23 6
22 1
19 0
0
70
3
23 6
22 5
17 0
0
74
3
23 6
22 7
12 0
0
80
3
23 6
22 11
10 0
end_DTG
begin_DTG
2
1
73
2
23 11
22 6
1
88
2
23 14
22 15
4
0
81
3
23 13
22 11
15 0
0
83
3
23 13
22 12
18 0
0
86
3
23 13
22 14
13 0
0
92
3
23 13
22 18
19 0
end_DTG
begin_DTG
4
1
0
1
10 0
1
62
2
23 1
11 0
5
1
1
12 0
5
63
2
23 5
14 0
5
0
2
1
4 0
2
3
1
11 0
2
64
2
23 2
6 0
6
4
1
20 0
6
65
2
23 6
19 0
5
1
5
1
10 0
1
66
2
23 1
4 0
3
6
1
6 0
3
67
2
23 3
0 0
7
7
1
17 0
4
2
8
1
11 0
2
68
2
23 2
10 0
4
9
1
0 0
8
10
1
7 0
3
3
11
1
6 0
3
69
2
23 3
11 0
9
12
1
1 0
5
0
13
1
4 0
6
14
1
20 0
6
70
2
23 6
17 0
10
15
1
14 0
10
71
2
23 10
13 0
6
1
16
1
10 0
5
17
1
12 0
7
18
1
17 0
7
72
2
23 7
7 0
11
19
1
19 0
11
73
2
23 11
21 0
5
2
20
1
11 0
6
21
1
20 0
6
74
2
23 6
12 0
8
22
1
7 0
8
75
2
23 8
1 0
4
3
23
1
6 0
7
24
1
17 0
7
76
2
23 7
20 0
9
25
1
1 0
3
4
26
1
0 0
8
27
1
7 0
8
77
2
23 8
17 0
5
5
28
1
12 0
5
78
2
23 5
4 0
11
29
1
19 0
12
30
1
13 0
12
79
2
23 12
5 0
5
6
31
1
20 0
6
80
2
23 6
10 0
10
32
1
14 0
13
33
1
21 0
13
81
2
23 13
15 0
5
10
34
1
14 0
10
82
2
23 10
12 0
13
35
1
21 0
13
83
2
23 13
18 0
17
36
1
5 0
6
11
37
1
19 0
11
84
2
23 11
20 0
12
38
1
13 0
14
39
1
18 0
14
85
2
23 14
8 0
18
40
1
15 0
5
13
41
1
21 0
13
86
2
23 13
13 0
15
42
1
8 0
15
87
2
23 15
2 0
19
43
1
16 0
4
14
44
1
18 0
14
88
2
23 14
21 0
16
45
1
2 0
20
46
1
9 0
3
15
47
1
8 0
15
89
2
23 15
18 0
21
48
1
3 0
4
12
49
1
13 0
12
90
2
23 12
14 0
18
50
1
15 0
18
91
2
23 18
16 0
5
13
51
1
21 0
13
92
2
23 13
19 0
17
52
1
5 0
19
53
1
16 0
19
93
2
23 19
9 0
5
14
54
1
18 0
18
55
1
15 0
18
94
2
23 18
5 0
20
56
1
9 0
20
95
2
23 20
3 0
4
15
57
1
8 0
19
58
1
16 0
19
96
2
23 19
15 0
21
59
1
3 0
3
16
60
1
2 0
20
61
1
9 0
20
97
2
23 20
16 0
end_DTG
begin_DTG
0
2
0
66
2
22 2
4 0
2
62
2
22 0
11 0
2
1
68
2
22 3
10 0
3
64
2
22 1
6 0
2
2
69
2
22 4
11 0
4
67
2
22 2
0 0
0
2
0
78
2
22 10
4 0
10
63
2
22 0
14 0
4
1
80
2
22 11
10 0
5
74
2
22 7
12 0
7
70
2
22 5
17 0
11
65
2
22 1
19 0
2
6
76
2
22 8
20 0
8
72
2
22 6
7 0
2
7
77
2
22 9
17 0
9
75
2
22 7
1 0
0
2
5
82
2
22 12
12 0
12
71
2
22 5
13 0
2
6
84
2
22 13
20 0
13
73
2
22 6
21 0
2
10
90
2
22 17
14 0
17
79
2
22 10
5 0
4
11
92
2
22 18
19 0
12
86
2
22 14
13 0
14
83
2
22 12
18 0
18
81
2
22 11
15 0
2
13
88
2
22 15
21 0
15
85
2
22 13
8 0
2
14
89
2
22 16
18 0
16
87
2
22 14
2 0
0
0
2
17
94
2
22 19
5 0
19
91
2
22 17
16 0
2
18
96
2
22 20
15 0
20
93
2
22 18
9 0
2
19
97
2
22 21
16 0
21
95
2
22 19
3 0
0
end_DTG
begin_CG
3
23 1
22 3
6 1
3
23 1
22 3
7 1
3
23 1
22 3
8 1
3
23 1
22 3
9 1
4
23 2
22 4
10 1
12 1
4
23 2
22 4
13 1
15 1
3
23 1
22 4
11 1
3
23 1
22 4
17 1
3
23 1
22 4
18 1
3
23 1
22 4
16 1
4
23 2
22 5
11 1
20 1
4
23 2
22 5
10 1
6 1
4
23 2
22 5
20 1
14 1
4
23 2
22 5
14 1
21 1
4
23 2
22 5
12 1
13 1
4
23 2
22 5
21 1
16 1
4
23 2
22 5
15 1
9 1
4
23 2
22 5
20 1
7 1
4
23 2
22 5
21 1
8 1
4
23 2
22 5
20 1
21 1
4
23 2
22 6
17 1
19 1
4
23 2
22 6
19 1
18 1
23
23 36
4 2
10 4
11 4
6 3
0 1
12 4
20 6
17 4
7 3
1 1
14 4
19 4
13 4
21 6
18 4
8 3
2 1
5 2
15 4
16 4
9 3
3 1
23
22 36
4 2
10 4
11 4
6 3
0 1
12 4
20 6
17 4
7 3
1 1
14 4
19 4
13 4
21 6
18 4
8 3
2 1
5 2
15 4
16 4
9 3
3 1
end_CG
