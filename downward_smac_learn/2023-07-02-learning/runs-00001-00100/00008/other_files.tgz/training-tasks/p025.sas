begin_version
3
end_version
begin_metric
0
end_metric
20
begin_variable
var2
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var1
-1
20
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
end_variable
begin_variable
var0
-1
18
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_7_5)
end_variable
18
begin_mutex_group
2
19 0
0 0
end_mutex_group
begin_mutex_group
2
19 1
1 0
end_mutex_group
begin_mutex_group
2
19 2
4 0
end_mutex_group
begin_mutex_group
2
19 3
10 0
end_mutex_group
begin_mutex_group
2
19 4
14 0
end_mutex_group
begin_mutex_group
2
19 5
17 0
end_mutex_group
begin_mutex_group
2
19 6
8 0
end_mutex_group
begin_mutex_group
2
19 7
6 0
end_mutex_group
begin_mutex_group
2
19 8
7 0
end_mutex_group
begin_mutex_group
2
19 9
15 0
end_mutex_group
begin_mutex_group
2
19 10
16 0
end_mutex_group
begin_mutex_group
2
19 11
13 0
end_mutex_group
begin_mutex_group
2
19 12
2 0
end_mutex_group
begin_mutex_group
2
19 13
5 0
end_mutex_group
begin_mutex_group
2
19 14
11 0
end_mutex_group
begin_mutex_group
2
19 15
12 0
end_mutex_group
begin_mutex_group
2
19 16
9 0
end_mutex_group
begin_mutex_group
2
19 17
3 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
11
9
end_state
begin_goal
1
19 14
end_goal
84
begin_operator
move loc_3_5 loc_3_6 right
0
1
0 18 0 1
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
17 0
1
0 18 0 6
0
end_operator
begin_operator
move loc_3_6 loc_3_5 left
1
0 0
1
0 18 1 0
0
end_operator
begin_operator
move loc_3_6 loc_3_7 right
1
1 0
1
0 18 1 2
0
end_operator
begin_operator
move loc_3_6 loc_4_6 down
1
8 0
1
0 18 1 7
0
end_operator
begin_operator
move loc_3_7 loc_3_6 left
0
1
0 18 2 1
0
end_operator
begin_operator
move loc_3_7 loc_4_7 down
1
6 0
1
0 18 2 8
0
end_operator
begin_operator
move loc_4_2 loc_4_3 right
1
10 0
1
0 18 3 4
0
end_operator
begin_operator
move loc_4_2 loc_5_2 down
1
7 0
1
0 18 3 9
0
end_operator
begin_operator
move loc_4_3 loc_4_2 left
1
4 0
1
0 18 4 3
0
end_operator
begin_operator
move loc_4_3 loc_4_4 right
1
14 0
1
0 18 4 5
0
end_operator
begin_operator
move loc_4_3 loc_5_3 down
1
15 0
1
0 18 4 10
0
end_operator
begin_operator
move loc_4_4 loc_4_3 left
1
10 0
1
0 18 5 4
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
17 0
1
0 18 5 6
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
1
16 0
1
0 18 5 11
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
0 0
1
0 18 6 0
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
14 0
1
0 18 6 5
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
8 0
1
0 18 6 7
0
end_operator
begin_operator
move loc_4_5 loc_5_5 down
1
13 0
1
0 18 6 12
0
end_operator
begin_operator
move loc_4_6 loc_3_6 up
0
1
0 18 7 1
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
1
17 0
1
0 18 7 6
0
end_operator
begin_operator
move loc_4_6 loc_4_7 right
1
6 0
1
0 18 7 8
0
end_operator
begin_operator
move loc_4_7 loc_3_7 up




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 0
check 0
switch 4
check 0
check 1
25
check 0
switch 15
check 0
check 1
26
check 0
switch 5
check 0
check 1
27
check 0
check 0
switch 10
check 0
check 1
28
check 0
switch 7
check 0
check 1
29
check 0
switch 16
check 0
check 1
30
check 0
switch 11
check 0
check 1
31
check 0
check 0
switch 14
check 0
check 1
32
check 0
switch 15
check 0
check 1
33
check 0
switch 13
check 0
check 1
34
check 0
switch 12
check 0
check 1
35
check 0
check 0
switch 17
check 0
check 1
36
check 0
switch 16
check 0
check 1
37
check 0
switch 9
check 0
check 1
38
check 0
check 0
switch 6
check 0
check 1
39
check 0
check 0
switch 7
check 0
check 1
40
check 0
switch 11
check 0
check 1
41
check 0
check 0
switch 15
check 0
check 1
42
check 0
switch 5
check 0
check 1
43
check 0
switch 12
check 0
check 1
44
check 0
check 0
switch 16
check 0
check 1
45
check 0
switch 11
check 0
check 1
46
check 0
switch 9
check 0
check 1
47
check 0
check 0
switch 13
check 0
check 1
48
check 0
switch 12
check 0
check 1
49
check 0
switch 3
check 0
check 1
50
check 0
check 0
switch 0
check 1
52
check 0
check 0
switch 9
check 0
check 1
51
check 0
check 0
switch 3
check 0
check 1
53
check 0
check 0
check 0
end_SG
begin_DTG
1
1
71
2
19 5
18 12
0
end_DTG
begin_DTG
1
1
74
2
19 7
18 13
0
end_DTG
begin_DTG
1
1
55
2
19 7
18 2
0
end_DTG
begin_DTG
1
1
73
2
19 16
18 12
0
end_DTG
begin_DTG
2
1
60
2
19 3
18 5
1
75
2
19 8
18 14
0
end_DTG
begin_DTG
2
1
57
2
19 8
18 3
1
80
2
19 14
18 16
0
end_DTG
begin_DTG
1
1
64
2
19 6
18 6
2
0
55
3
19 7
18 2
2 0
0
74
3
19 7
18 13
1 0
end_DTG
begin_DTG
1
1
70
2
19 9
18 11
2
0
57
3
19 8
18 3
5 0
0
75
3
19 8
18 14
4 0
end_DTG
begin_DTG
1
1
61
2
19 5
18 5
2
0
64
3
19 6
18 6
6 0
0
67
3
19 6
18 8
17 0
end_DTG
begin_DTG
2
1
65
2
19 11
18 6
1
78
2
19 15
18 15
2
0
73
3
19 16
18 12
3 0
0
83
3
19 16
18 18
13 0
end_DTG
begin_DTG
2
1
63
2
19 4
18 6
1
77
2
19 9
18 15
2
0
56
3
19 3
18 3
14 0
0
60
3
19 3
18 5
4 0
end_DTG
begin_DTG
2
1
59
2
19 9
18 4
1
82
2
19 15
18 17
2
0
76
3
19 14
18 14
12 0
0
80
3
19 14
18 16
5 0
end_DTG
begin_DTG
2
1
62
2
19 10
18 5
1
76
2
19 14
18 14
2
0
78
3
19 15
18 15
9 0
0
82
3
19 15
18 17
11 0
end_DTG
begin_DTG
3
1
54
2
19 5
18 0
1
69
2
19 10
18 10
1
83
2
19 16
18 18
2
0
65
3
19 11
18 6
9 0
0
81
3
19 11
18 17
17 0
end_DTG
begin_DTG
3
1
56
2
19 3
18 3
1
66
2
19 5
18 7
1
79
2
19 10
18 16
2
0
58
3
19 4
18 4
17 0
0
63
3
19 4
18 6
10 0
end_DTG
begin_DTG
1
1
72
2
19 10
18 12
4
0
59
3
19 9
18 4
11 0
0
68
3
19 9
18 9
16 0
0
70
3
19 9
18 11
7 0
0
77
3
19 9
18 15
10 0
end_DTG
begin_DTG
1
1
68
2
19 9
18 9
4
0
62
3
19 10
18 5
12 0
0
69
3
19 10
18 10
13 0
0
72
3
19 10
18 12
15 0
0
79
3
19 10
18 16
14 0
end_DTG
begin_DTG
3
1
58
2
19 4
18 4
1
67
2
19 6
18 8
1
81
2
19 11
18 17
4
0
54
3
19 5
18 0
13 0
0
61
3
19 5
18 5
8 0
0
66
3
19 5
18 7
14 0
0
71
3
19 5
18 12
0 0
end_DTG
begin_DTG
3
1
0
0
6
1
1
17 0
6
54
2
19 5
13 0
3
0
2
1
0 0
2
3
1
1 0
7
4
1
8 0
3
1
5
0
8
6
1
6 0
8
55
2
19 7
2 0
4
4
7
1
10 0
4
56
2
19 3
14 0
9
8
1
7 0
9
57
2
19 8
5 0
5
3
9
1
4 0
5
10
1
14 0
5
58
2
19 4
17 0
10
11
1
15 0
10
59
2
19 9
11 0
6
4
12
1
10 0
4
60
2
19 3
4 0
6
13
1
17 0
6
61
2
19 5
8 0
11
14
1
16 0
11
62
2
19 10
12 0
7
0
15
1
0 0
5
16
1
14 0
5
63
2
19 4
10 0
7
17
1
8 0
7
64
2
19 6
6 0
12
18
1
13 0
12
65
2
19 11
9 0
4
1
19
0
6
20
1
17 0
6
66
2
19 5
14 0
8
21
1
6 0
4
2
22
1
1 0
7
23
1
8 0
7
67
2
19 6
17 0
13
24
1
2 0
4
3
25
1
4 0
10
26
1
15 0
10
68
2
19 9
16 0
14
27
1
5 0
5
4
28
1
10 0
9
29
1
7 0
11
30
1
16 0
11
69
2
19 10
13 0
15
31
1
11 0
5
5
32
1
14 0
10
33
1
15 0
10
70
2
19 9
7 0
12
34
1
13 0
16
35
1
12 0
6
6
36
1
17 0
6
71
2
19 5
0 0
11
37
1
16 0
11
72
2
19 10
15 0
17
38
1
9 0
17
73
2
19 16
3 0
2
8
39
1
6 0
8
74
2
19 7
1 0
4
9
40
1
7 0
9
75
2
19 8
4 0
15
41
1
11 0
15
76
2
19 14
12 0
5
10
42
1
15 0
10
77
2
19 9
10 0
14
43
1
5 0
16
44
1
12 0
16
78
2
19 15
9 0
5
11
45
1
16 0
11
79
2
19 10
14 0
15
46
1
11 0
15
80
2
19 14
5 0
17
47
1
9 0
5
12
48
1
13 0
12
81
2
19 11
17 0
16
49
1
12 0
16
82
2
19 15
11 0
18
50
1
3 0
3
17
51
1
9 0
17
83
2
19 16
13 0
19
52
0
1
18
53
1
3 0
end_DTG
begin_DTG
0
0
0
2
2
60
2
18 5
4 0
4
56
2
18 3
14 0
2
3
63
2
18 6
10 0
5
58
2
18 4
17 0
4
0
71
2
18 12
0 0
4
66
2
18 7
14 0
6
61
2
18 5
8 0
11
54
2
18 0
13 0
2
5
67
2
18 8
17 0
7
64
2
18 6
6 0
2
1
74
2
18 13
1 0
12
55
2
18 2
2 0
2
2
75
2
18 14
4 0
13
57
2
18 3
5 0
4
3
77
2
18 15
10 0
8
70
2
18 11
7 0
10
68
2
18 9
16 0
14
59
2
18 4
11 0
4
4
79
2
18 16
14 0
9
72
2
18 12
15 0
11
69
2
18 10
13 0
15
62
2
18 5
12 0
2
5
81
2
18 17
17 0
16
65
2
18 6
9 0
0
0
2
13
80
2
18 16
5 0
15
76
2
18 14
12 0
2
14
82
2
18 17
11 0
16
78
2
18 15
9 0
2
11
83
2
18 18
13 0
17
73
2
18 12
3 0
0
end_DTG
begin_CG
3
19 1
18 3
17 1
3
19 1
18 3
6 1
3
19 1
18 2
6 1
3
19 1
18 3
9 1
4
19 2
18 4
10 1
7 1
4
19 2
18 4
7 1
11 1
3
19 1
18 4
8 1
3
19 1
18 4
15 1
3
19 1
18 4
17 1
4
19 2
18 5
13 1
12 1
4
19 2
18 5
14 1
15 1
4
19 2
18 5
15 1
12 1
4
19 2
18 5
16 1
11 1
5
19 3
18 6
17 1
16 1
9 1
5
19 3
18 6
10 1
17 1
16 1
3
19 1
18 5
16 1
3
19 1
18 5
15 1
5
19 3
18 7
14 1
8 1
13 1
19
19 30
0 1
1 1
4 2
10 4
14 5
17 7
8 3
6 3
7 3
15 5
16 5
13 5
2 1
5 2
11 4
12 4
9 4
3 1
19
18 30
0 1
1 1
4 2
10 4
14 5
17 7
8 3
6 3
7 3
15 5
16 5
13 5
2 1
5 2
11 4
12 4
9 4
3 1
end_CG
