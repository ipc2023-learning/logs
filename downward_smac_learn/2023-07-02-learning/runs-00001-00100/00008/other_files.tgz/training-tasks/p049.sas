begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var3
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var2
-1
49
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_7)
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





46 0
40
282
2
49 26
37 0
2
28
350
2
49 42
36 0
42
294
2
49 28
21 0
2
35
332
2
49 37
29 0
37
324
2
49 35
7 0
0
2
32
354
2
49 43
39 0
43
308
2
49 32
8 0
4
33
358
2
49 44
40 0
38
344
2
49 40
16 0
40
336
2
49 38
37 0
44
314
2
49 33
17 0
4
34
362
2
49 45
32 0
39
348
2
49 41
33 0
41
340
2
49 39
10 0
45
320
2
49 34
23 0
2
40
352
2
49 42
37 0
42
346
2
49 40
21 0
2
35
372
2
49 47
29 0
47
326
2
49 35
15 0
0
2
43
364
2
49 45
8 0
45
356
2
49 43
23 0
2
44
368
2
49 46
17 0
46
360
2
49 44
22 0
2
45
374
2
49 47
23 0
47
366
2
49 45
15 0
2
46
376
2
49 48
22 0
48
370
2
49 46
6 0
0
end_DTG
begin_DTG
0
2
0
157
2
49 2
0 0
2
151
2
49 0
24 0
2
1
163
2
49 3
11 0
3
153
2
49 1
25 0
2
2
169
2
49 4
24 0
4
159
2
49 2
12 0
2
3
173
2
49 5
25 0
5
165
2
49 3
1 0
0
2
1
193
2
49 11
11 0
11
155
2
49 1
41 0
4
2
199
2
49 12
24 0
6
183
2
49 8
18 0
8
175
2
49 6
35 0
12
161
2
49 2
45 0
4
3
207
2
49 13
25 0
7
187
2
49 9
34 0
9
179
2
49 7
19 0
13
167
2
49 3
43 0
2
4
213
2
49 14
12 0
14
171
2
49 4
26 0
0
4
6
223
2
49 17
18 0
10
201
2
49 12
2 0
12
191
2
49 10
45 0
17
177
2
49 6
42 0
4
7
229
2
49 18
34 0
11
209
2
49 13
41 0
13
195
2
49 11
43 0
18
181
2
49 7
47 0
4
8
237
2
49 19
35 0
12
215
2
49 14
45 0
14
203
2
49 12
26 0
19
185
2
49 8
48 0
2
9
245
2
49 20
19 0
20
189
2
49 9
38 0
0
0
4
11
265
2
49 24
41 0
16
231
2
49 18
4 0
18
221
2
49 16
47 0
24
197
2
49 11
31 0
4
12
271
2
49 25
45 0
17
239
2
49 19
42 0
19
225
2
49 17
48 0
25
205
2
49 12
44 0
4
13
277
2
49 26
43 0
18
247
2
49 20
47 0
20
233
2
49 18
38 0
26
211
2
49 13
46 0
4
14
285
2
49 27
26 0
19
251
2
49 21
48 0
21
241
2
49 19
27 0
27
217
2
49 14
30 0
2
20
257
2
49 22
38 0
22
249
2
49 20
20 0
2
21
261
2
49 23
27 0
23
253
2
49 21
13 0
2
15
299
2
49 30
3 0
30
219
2
49 15
14 0
2
17
305
2
49 32
42 0
32
227
2
49 17
39 0
4
18
311
2
49 33
47 0
24
279
2
49 26
31 0
26
267
2
49 24
46 0
33
235
2
49 18
40 0
4
19
317
2
49 34
48 0
25
287
2
49 27
44 0
27
273
2
49 25
30 0
34
243
2
49 19
32 0
2
26
291
2
49 28
46 0
28
281
2
49 26
36 0
4
21
323
2
49 35
27 0
27
297
2
49 29
30 0
29
289
2
49 27
28 0
35
255
2
49 21
29 0
4
22
329
2
49 36
20 0
28
301
2
49 30
36 0
30
293
2
49 28
14 0
36
259
2
49 22
9 0
2
23
331
2
49 37
13 0
37
263
2
49 23
7 0
0
4
24
335
2
49 38
31 0
31
313
2
49 33
5 0
33
303
2
49 31
40 0
38
269
2
49 24
16 0
4
25
339
2
49 39
44 0
32
319
2
49 34
39 0
34
307
2
49 32
32 0
39
275
2
49 25
33 0
2
26
343
2
49 40
46 0
40
283
2
49 26
37 0
2
28
351
2
49 42
36 0
42
295
2
49 28
21 0
2
35
333
2
49 37
29 0
37
325
2
49 35
7 0
0
2
32
355
2
49 43
39 0
43
309
2
49 32
8 0
4
33
359
2
49 44
40 0
38
345
2
49 40
16 0
40
337
2
49 38
37 0
44
315
2
49 33
17 0
4
34
363
2
49 45
32 0
39
349
2
49 41
33 0
41
341
2
49 39
10 0
45
321
2
49 34
23 0
2
40
353
2
49 42
37 0
42
347
2
49 40
21 0
2
35
373
2
49 47
29 0
47
327
2
49 35
15 0
0
2
43
365
2
49 45
8 0
45
357
2
49 43
23 0
2
44
369
2
49 46
17 0
46
361
2
49 44
22 0
2
45
375
2
49 47
23 0
47
367
2
49 45
15 0
2
46
377
2
49 48
22 0
48
371
2
49 46
6 0
0
end_DTG
begin_CG
4
50 1
51 1
49 3
11 2
4
50 1
51 1
49 3
12 2
4
50 1
51 1
49 4
41 2
4
50 1
51 1
49 3
13 2
4
50 1
51 1
49 4
42 2
4
50 1
51 1
49 3
39 2
4
50 1
51 1
49 3
15 2
5
50 2
51 2
49 6
14 2
9 2
5
50 2
51 2
49 6
16 2
17 2
4
50 1
51 1
49 5
28 2
4
50 1
51 1
49 5
37 2
5
50 2
51 2
49 7
24 2
18 2
5
50 2
51 2
49 7
25 2
19 2
5
50 2
51 2
49 7
20 2
14 2
5
50 2
51 2
49 7
13 2
28 2
5
50 2
51 2
49 7
21 2
22 2
5
50 2
51 2
49 7
39 2
33 2
5
50 2
51 2
49 7
33 2
23 2
5
50 2
51 2
49 7
34 2
41 2
5
50 2
51 2
49 7
35 2
26 2
5
50 2
51 2
49 7
27 2
28 2
5
50 2
51 2
49 7
29 2
10 2
5
50 2
51 2
49 7
23 2
15 2
6
50 3
51 3
49 9
37 2
17 2
22 2
6
50 3
51 3
49 9
11 2
25 2
34 2
6
50 3
51 3
49 9
24 2
12 2
35 2
6
50 3
51 3
49 9
19 2
43 2
38 2
6
50 3
51 3
49 9
38 2
20 2
36 2
4
50 1
51 1
49 6
36 2
6
50 3
51 3
49 9
36 2
9 2
21 2
6
50 3
51 3
49 9
38 2
46 2
36 2
6
50 3
51 3
49 9
42 2
44 2
39 2
6
50 3
51 3
49 9
46 2
40 2
37 2
5
50 2
51 2
49 8
40 2
37 2
5
50 2
51 2
49 8
35 2
45 2
5
50 2
51 2
49 8
34 2
43 2
6
50 3
51 3
49 10
30 2
28 2
29 2
6
50 3
51 3
49 10
32 2
33 2
10 2
6
50 3
51 3
49 10
26 2
48 2
27 2
6
50 3
51 3
49 10
31 2
40 2
16 2
6
50 3
51 3
49 10
44 2
39 2
33 2
6
50 3
51 3
49 10
18 2
45 2
42 2
6
50 3
51 3
49 10
41 2
47 2
31 2
6
50 3
51 3
49 10
35 2
45 2
48 2
6
50 3
51 3
49 10
47 2
46 2
40 2
7
50 4
51 4
49 12
34 2
41 2
43 2
47 2
7
50 4
51 4
49 12
48 2
44 2
30 2
32 2
7
50 4
51 4
49 12
45 2
42 2
48 2
44 2
7
50 4
51 4
49 12
43 2
47 2
38 2
46 2
51
50 114
51 114
0 2
11 8
24 10
25 10
12 8
1 2
18 8
34 12
35 12
19 8
2 2
41 14
45 16
43 14
26 10
3 2
4 2
42 14
47 16
48 16
38 14
27 10
20 8
13 8
31 10
44 14
46 16
30 10
36 14
28 10
14 8
5 2
39 14
40 14
32 10
29 10
9 6
7 4
16 8
33 12
37 14
10 6
21 8
8 4
17 8
23 10
22 8
15 8
6 2
50
49 114
0 1
11 4
24 5
25 5
12 4
1 1
18 4
34 6
35 6
19 4
2 1
41 7
45 8
43 7
26 5
3 1
4 1
42 7
47 8
48 8
38 7
27 5
20 4
13 4
31 5
44 7
46 8
30 5
36 7
28 5
14 4
5 1
39 7
40 7
32 5
29 5
9 3
7 2
16 4
33 6
37 7
10 3
21 4
8 2
17 4
23 5
22 4
15 4
6 1
50
49 114
0 1
11 4
24 5
25 5
12 4
1 1
18 4
34 6
35 6
19 4
2 1
41 7
45 8
43 7
26 5
3 1
4 1
42 7
47 8
48 8
38 7
27 5
20 4
13 4
31 5
44 7
46 8
30 5
36 7
28 5
14 4
5 1
39 7
40 7
32 5
29 5
9 3
7 2
16 4
33 6
37 7
10 3
21 4
8 2
17 4
23 5
22 4
15 4
6 1
end_CG
