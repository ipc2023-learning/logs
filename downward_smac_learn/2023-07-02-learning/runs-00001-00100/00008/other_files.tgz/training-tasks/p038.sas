begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var14
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var2
-1
40
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
39
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9 2
3 0
2
118
2
39 0
22 0
2
1
132
2
39 3
15 0
3
122
2
39 1
16 0
2
2
136
2
39 4
22 0
4
128
2
39 2
4 0
0
2
0
166
2
39 12
3 0
12
120
2
39 0
5 0
4
1
170
2
39 13
15 0
5
146
2
39 7
9 0
7
140
2
39 5
32 0
13
124
2
39 1
34 0
4
2
176
2
39 14
22 0
6
150
2
39 8
31 0
8
142
2
39 6
33 0
14
130
2
39 2
24 0
4
3
182
2
39 15
16 0
7
154
2
39 9
32 0
9
148
2
39 7
36 0
15
134
2
39 3
25 0
4
4
188
2
39 16
4 0
8
160
2
39 10
33 0
10
152
2
39 8
11 0
16
138
2
39 4
35 0
2
9
164
2
39 11
36 0
11
156
2
39 9
0 0
0
0
4
6
198
2
39 18
31 0
12
178
2
39 14
5 0
14
168
2
39 12
24 0
18
144
2
39 6
20 0
2
13
184
2
39 15
34 0
15
172
2
39 13
25 0
2
14
190
2
39 16
24 0
16
180
2
39 14
35 0
4
9
202
2
39 19
36 0
15
194
2
39 17
25 0
17
186
2
39 15
17 0
19
158
2
39 9
26 0
2
10
208
2
39 20
11 0
20
162
2
39 10
28 0
2
13
216
2
39 22
34 0
22
174
2
39 13
18 0
2
16
230
2
39 25
35 0
25
192
2
39 16
38 0
4
17
238
2
39 26
17 0
19
212
2
39 21
26 0
21
204
2
39 19
6 0
26
196
2
39 17
30 0
0
2
18
248
2
39 29
20 0
29
200
2
39 18
12 0
2
22
224
2
39 24
18 0
24
218
2
39 22
23 0
2
23
232
2
39 25
21 0
25
220
2
39 23
38 0
4
19
260
2
39 32
26 0
24
240
2
39 26
23 0
26
226
2
39 24
30 0
32
206
2
39 19
37 0
4
20
266
2
39 33
28 0
25
242
2
39 27
38 0
27
234
2
39 25
14 0
33
210
2
39 20
19 0
2
21
270
2
39 34
6 0
34
214
2
39 21
13 0
0
2
28
252
2
39 30
1 0
30
246
2
39 28
27 0
4
23
274
2
39 36
21 0
29
256
2
39 31
12 0
31
250
2
39 29
29 0
35
222
2
39 23
7 0
4
24
278
2
39 37
23 0
30
262
2
39 32
27 0
32
254
2
39 30
37 0
36
228
2
39 24
10 0
4
25
280
2
39 38
38 0
31
268
2
39 33
29 0
33
258
2
39 31
19 0
37
236
2
39 25
8 0
2
32
272
2
39 34
37 0
34
264
2
39 32
13 0
2
27
284
2
39 39
14 0
38
244
2
39 27
2 0
0
2
35
282
2
39 38
7 0
37
276
2
39 36
8 0
0
0
end_DTG
begin_DTG
0
2
0
127
2
39 2
3 0
2
119
2
39 0
22 0
2
1
133
2
39 3
15 0
3
123
2
39 1
16 0
2
2
137
2
39 4
22 0
4
129
2
39 2
4 0
0
2
0
167
2
39 12
3 0
12
121
2
39 0
5 0
4
1
171
2
39 13
15 0
5
147
2
39 7
9 0
7
141
2
39 5
32 0
13
125
2
39 1
34 0
4
2
177
2
39 14
22 0
6
151
2
39 8
31 0
8
143
2
39 6
33 0
14
131
2
39 2
24 0
4
3
183
2
39 15
16 0
7
155
2
39 9
32 0
9
149
2
39 7
36 0
15
135
2
39 3
25 0
4
4
189
2
39 16
4 0
8
161
2
39 10
33 0
10
153
2
39 8
11 0
16
139
2
39 4
35 0
2
9
165
2
39 11
36 0
11
157
2
39 9
0 0
0
0
4
6
199
2
39 18
31 0
12
179
2
39 14
5 0
14
169
2
39 12
24 0
18
145
2
39 6
20 0
2
13
185
2
39 15
34 0
15
173
2
39 13
25 0
2
14
191
2
39 16
24 0
16
181
2
39 14
35 0
4
9
203
2
39 19
36 0
15
195
2
39 17
25 0
17
187
2
39 15
17 0
19
159
2
39 9
26 0
2
10
209
2
39 20
11 0
20
163
2
39 10
28 0
2
13
217
2
39 22
34 0
22
175
2
39 13
18 0
2
16
231
2
39 25
35 0
25
193
2
39 16
38 0
4
17
239
2
39 26
17 0
19
213
2
39 21
26 0
21
205
2
39 19
6 0
26
197
2
39 17
30 0
0
2
18
249
2
39 29
20 0
29
201
2
39 18
12 0
2
22
225
2
39 24
18 0
24
219
2
39 22
23 0
2
23
233
2
39 25
21 0
25
221
2
39 23
38 0
4
19
261
2
39 32
26 0
24
241
2
39 26
23 0
26
227
2
39 24
30 0
32
207
2
39 19
37 0
4
20
267
2
39 33
28 0
25
243
2
39 27
38 0
27
235
2
39 25
14 0
33
211
2
39 20
19 0
2
21
271
2
39 34
6 0
34
215
2
39 21
13 0
0
2
28
253
2
39 30
1 0
30
247
2
39 28
27 0
4
23
275
2
39 36
21 0
29
257
2
39 31
12 0
31
251
2
39 29
29 0
35
223
2
39 23
7 0
4
24
279
2
39 37
23 0
30
263
2
39 32
27 0
32
255
2
39 30
37 0
36
229
2
39 24
10 0
4
25
281
2
39 38
38 0
31
269
2
39 33
29 0
33
259
2
39 31
19 0
37
237
2
39 25
8 0
2
32
273
2
39 34
37 0
34
265
2
39 32
13 0
2
27
285
2
39 39
14 0
38
245
2
39 27
2 0
0
2
35
283
2
39 38
7 0
37
277
2
39 36
8 0
0
0
end_DTG
begin_CG
4
40 1
41 1
39 3
11 2
4
40 1
41 1
39 4
12 2
4
40 1
41 1
39 3
13 2
5
40 2
41 2
39 6
15 2
9 2
5
40 2
41 2
39 6
16 2
36 2
5
40 2
41 2
39 6
9 2
34 2
5
40 2
41 2
39 6
28 2
14 2
5
40 2
41 2
39 6
27 2
10 2
5
40 2
41 2
39 6
37 2
10 2
4
40 1
41 1
39 5
31 2
4
40 1
41 1
39 5
29 2
5
40 2
41 2
39 7
36 2
17 2
5
40 2
41 2
39 7
18 2
27 2
5
40 2
41 2
39 7
14 2
19 2
5
40 2
41 2
39 7
30 2
13 2
5
40 2
41 2
39 7
22 2
31 2
5
40 2
41 2
39 7
22 2
33 2
5
40 2
41 2
39 7
35 2
28 2
5
40 2
41 2
39 7
20 2
21 2
5
40 2
41 2
39 7
30 2
37 2
5
40 2
41 2
39 6
34 2
18 2
5
40 2
41 2
39 7
23 2
27 2
6
40 3
41 3
39 9
15 2
16 2
32 2
6
40 3
41 3
39 9
21 2
38 2
29 2
6
40 3
41 3
39 9
32 2
34 2
25 2
6
40 3
41 3
39 9
33 2
24 2
35 2
6
40 3
41 3
39 9
35 2
28 2
38 2
5
40 2
41 2
39 8
12 2
29 2
5
40 2
41 2
39 8
17 2
30 2
5
40 2
41 2
39 8
27 2
37 2
5
40 2
41 2
39 8
28 2
38 2
5
40 2
41 2
39 8
32 2
34 2
5
40 2
41 2
39 8
31 2
33 2
5
40 2
41 2
39 8
32 2
36 2
6
40 3
41 3
39 10
31 2
24 2
20 2
6
40 3
41 3
39 10
36 2
25 2
26 2
6
40 3
41 3
39 10
33 2
11 2
35 2
6
40 3
41 3
39 10
38 2
29 2
19 2
7
40 4
41 4
39 12
26 2
23 2
30 2
37 2
41
40 84
41 84
3 4
15 8
22 10
16 8
4 4
9 6
31 12
32 12
33 12
36 14
11 8
0 2
5 4
34 14
24 10
25 10
35 14
17 8
20 8
26 10
28 12
6 4
18 8
21 8
23 10
38 16
30 12
14 8
1 2
12 8
27 12
29 12
37 14
19 8
13 8
7 4
10 6
8 4
2 2
40
39 84
3 2
15 4
22 5
16 4
4 2
9 3
31 6
32 6
33 6
36 7
11 4
0 1
5 2
34 7
24 5
25 5
35 7
17 4
20 4
26 5
28 6
6 2
18 4
21 4
23 5
38 8
30 6
14 4
1 1
12 4
27 6
29 6
37 7
19 4
13 4
7 2
10 3
8 2
2 1
40
39 84
3 2
15 4
22 5
16 4
4 2
9 3
31 6
32 6
33 6
36 7
11 4
0 1
5 2
34 7
24 5
25 5
35 7
17 4
20 4
26 5
28 6
6 2
18 4
21 4
23 5
38 8
30 6
14 4
1 1
12 4
27 6
29 6
37 7
19 4
13 4
7 2
10 3
8 2
2 1
end_CG
