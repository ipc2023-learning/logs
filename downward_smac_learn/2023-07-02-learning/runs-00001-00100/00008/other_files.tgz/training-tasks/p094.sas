begin_version
3
end_version
begin_metric
0
end_metric
87
begin_variable
var15
-1
2
Atom clear(loc_11_12)
NegatedAtom clear(loc_11_12)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_5_12)
NegatedAtom clear(loc_5_12)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_7_12)
NegatedAtom clear(loc_7_12)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var81
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var82
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_12)
NegatedAtom clear(loc_10_12)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_8_12)
NegatedAtom clear(loc_8_12)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var83
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_9_12)
NegatedAtom clear(loc_9_12)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var79
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var78
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var84
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





52 4
7
83 2
84 2
85 2
86 2
82 10
12 4
47 4
6
83 1
84 1
85 1
86 1
82 7
24 4
6
83 1
84 1
85 1
86 1
82 7
37 4
6
83 1
84 1
85 1
86 1
82 7
47 4
6
83 1
84 1
85 1
86 1
82 7
66 4
6
83 1
84 1
85 1
86 1
82 7
39 4
6
83 1
84 1
85 1
86 1
82 7
62 4
7
83 2
84 2
85 2
86 2
82 11
25 4
35 4
7
83 2
84 2
85 2
86 2
82 11
52 4
26 4
7
83 2
84 2
85 2
86 2
82 11
27 4
28 4
7
83 2
84 2
85 2
86 2
82 11
51 4
35 4
7
83 2
84 2
85 2
86 2
82 11
29 4
17 4
7
83 2
84 2
85 2
86 2
82 11
36 4
48 4
7
83 2
84 2
85 2
86 2
82 11
63 4
47 4
7
83 2
84 2
85 2
86 2
82 11
40 4
49 4
7
83 2
84 2
85 2
86 2
82 11
55 4
41 4
7
83 2
84 2
85 2
86 2
82 11
20 4
65 4
7
83 2
84 2
85 2
86 2
82 11
15 4
30 4
7
83 2
84 2
85 2
86 2
82 10
22 4
42 4
7
83 2
84 2
85 2
86 2
82 11
28 4
51 4
7
83 2
84 2
85 2
86 2
82 11
68 4
60 4
7
83 2
84 2
85 2
86 2
82 11
48 4
68 4
7
83 2
84 2
85 2
86 2
82 11
70 4
56 4
7
83 2
84 2
85 2
86 2
82 10
36 4
37 4
8
83 3
84 3
85 3
86 3
82 15
18 4
21 4
49 4
8
83 3
84 3
85 3
86 3
82 15
23 4
34 4
32 4
8
83 3
84 3
85 3
86 3
82 15
13 4
34 4
16 4
6
83 1
84 1
85 1
86 1
82 8
64 4
8
83 3
84 3
85 3
86 3
82 15
16 4
31 4
65 4
8
83 3
84 3
85 3
86 3
82 15
25 4
53 4
50 4
8
83 3
84 3
85 3
86 3
82 15
26 4
57 4
43 4
8
83 3
84 3
85 3
86 3
82 15
29 4
54 4
33 4
8
83 3
84 3
85 3
86 3
82 15
41 4
58 4
63 4
8
83 3
84 3
85 3
86 3
82 15
59 4
62 4
70 4
8
83 3
84 3
85 3
86 3
82 15
66 4
61 4
71 4
8
83 3
84 3
85 3
86 3
82 15
51 4
71 4
50 4
7
83 2
84 2
85 2
86 2
82 12
62 4
14 4
7
83 2
84 2
85 2
86 2
82 12
52 4
69 4
7
83 2
84 2
85 2
86 2
82 12
51 4
50 4
7
83 2
84 2
85 2
86 2
82 12
49 4
72 4
8
83 3
84 3
85 3
86 3
82 16
30 4
46 4
49 4
8
83 3
84 3
85 3
86 3
82 16
19 4
48 4
55 4
8
83 3
84 3
85 3
86 3
82 16
40 4
64 4
72 4
8
83 3
84 3
85 3
86 3
82 16
42 4
64 4
56 4
8
83 3
84 3
85 3
86 3
82 16
52 4
69 4
57 4
8
83 3
84 3
85 3
86 3
82 16
54 4
75 4
73 4
8
83 3
84 3
85 3
86 3
82 16
55 4
77 4
58 4
8
83 3
84 3
85 3
86 3
82 16
57 4
79 4
59 4
8
83 3
84 3
85 3
86 3
82 16
58 4
63 4
78 4
8
83 3
84 3
85 3
86 3
82 16
76 4
65 4
67 4
8
83 3
84 3
85 3
86 3
82 16
67 4
80 4
74 4
9
83 4
84 4
85 4
86 4
82 20
63 4
47 4
44 4
17 4
9
83 4
84 4
85 4
86 4
82 20
43 4
24 4
59 4
62 4
9
83 4
84 4
85 4
86 4
82 20
54 4
53 4
38 4
73 4
9
83 4
84 4
85 4
86 4
82 20
39 4
27 4
60 4
66 4
9
83 4
84 4
85 4
86 4
82 20
65 4
15 4
67 4
45 4
9
83 4
84 4
85 4
86 4
82 20
60 4
81 4
66 4
61 4
9
83 4
84 4
85 4
86 4
82 20
32 4
69 4
31 4
76 4
9
83 4
84 4
85 4
86 4
82 20
48 4
55 4
68 4
77 4
9
83 4
84 4
85 4
86 4
82 20
78 4
44 4
75 4
33 4
9
83 4
84 4
85 4
86 4
82 20
45 4
46 4
74 4
72 4
9
83 4
84 4
85 4
86 4
82 20
53 4
71 4
50 4
73 4
9
83 4
84 4
85 4
86 4
82 20
64 4
74 4
56 4
72 4
9
83 4
84 4
85 4
86 4
82 20
61 4
75 4
71 4
73 4
9
83 4
84 4
85 4
86 4
82 20
80 4
70 4
74 4
56 4
9
83 4
84 4
85 4
86 4
82 20
68 4
77 4
60 4
81 4
9
83 4
84 4
85 4
86 4
82 20
69 4
57 4
76 4
79 4
9
83 4
84 4
85 4
86 4
82 20
79 4
59 4
80 4
70 4
9
83 4
84 4
85 4
86 4
82 20
77 4
58 4
81 4
78 4
9
83 4
84 4
85 4
86 4
82 20
81 4
78 4
61 4
75 4
9
83 4
84 4
85 4
86 4
82 20
76 4
79 4
67 4
80 4
86
83 212
84 212
85 212
86 212
40 20
25 16
18 16
7 8
22 16
29 16
42 20
54 28
64 32
53 28
0 4
8 8
38 20
9 8
1 4
13 12
2 4
10 8
23 16
36 20
34 16
37 20
3 4
19 16
52 28
48 24
32 16
16 12
26 16
55 28
69 32
68 32
31 16
39 20
27 16
20 16
4 4
41 20
57 28
77 32
76 32
60 28
65 32
15 12
28 16
5 4
43 20
58 28
79 32
81 32
67 32
66 32
30 16
6 4
12 12
24 16
63 32
59 28
78 32
80 32
61 28
45 20
46 20
51 28
21 16
11 8
47 24
62 32
44 20
70 32
75 32
74 32
71 32
50 24
49 24
35 20
14 12
17 12
33 16
56 28
73 32
72 32
83
82 212
40 5
25 4
18 4
7 2
22 4
29 4
42 5
54 7
64 8
53 7
0 1
8 2
38 5
9 2
1 1
13 3
2 1
10 2
23 4
36 5
34 4
37 5
3 1
19 4
52 7
48 6
32 4
16 3
26 4
55 7
69 8
68 8
31 4
39 5
27 4
20 4
4 1
41 5
57 7
77 8
76 8
60 7
65 8
15 3
28 4
5 1
43 5
58 7
79 8
81 8
67 8
66 8
30 4
6 1
12 3
24 4
63 8
59 7
78 8
80 8
61 7
45 5
46 5
51 7
21 4
11 2
47 6
62 8
44 5
70 8
75 8
74 8
71 8
50 6
49 6
35 5
14 3
17 3
33 4
56 7
73 8
72 8
83
82 212
40 5
25 4
18 4
7 2
22 4
29 4
42 5
54 7
64 8
53 7
0 1
8 2
38 5
9 2
1 1
13 3
2 1
10 2
23 4
36 5
34 4
37 5
3 1
19 4
52 7
48 6
32 4
16 3
26 4
55 7
69 8
68 8
31 4
39 5
27 4
20 4
4 1
41 5
57 7
77 8
76 8
60 7
65 8
15 3
28 4
5 1
43 5
58 7
79 8
81 8
67 8
66 8
30 4
6 1
12 3
24 4
63 8
59 7
78 8
80 8
61 7
45 5
46 5
51 7
21 4
11 2
47 6
62 8
44 5
70 8
75 8
74 8
71 8
50 6
49 6
35 5
14 3
17 3
33 4
56 7
73 8
72 8
83
82 212
40 5
25 4
18 4
7 2
22 4
29 4
42 5
54 7
64 8
53 7
0 1
8 2
38 5
9 2
1 1
13 3
2 1
10 2
23 4
36 5
34 4
37 5
3 1
19 4
52 7
48 6
32 4
16 3
26 4
55 7
69 8
68 8
31 4
39 5
27 4
20 4
4 1
41 5
57 7
77 8
76 8
60 7
65 8
15 3
28 4
5 1
43 5
58 7
79 8
81 8
67 8
66 8
30 4
6 1
12 3
24 4
63 8
59 7
78 8
80 8
61 7
45 5
46 5
51 7
21 4
11 2
47 6
62 8
44 5
70 8
75 8
74 8
71 8
50 6
49 6
35 5
14 3
17 3
33 4
56 7
73 8
72 8
83
82 212
40 5
25 4
18 4
7 2
22 4
29 4
42 5
54 7
64 8
53 7
0 1
8 2
38 5
9 2
1 1
13 3
2 1
10 2
23 4
36 5
34 4
37 5
3 1
19 4
52 7
48 6
32 4
16 3
26 4
55 7
69 8
68 8
31 4
39 5
27 4
20 4
4 1
41 5
57 7
77 8
76 8
60 7
65 8
15 3
28 4
5 1
43 5
58 7
79 8
81 8
67 8
66 8
30 4
6 1
12 3
24 4
63 8
59 7
78 8
80 8
61 7
45 5
46 5
51 7
21 4
11 2
47 6
62 8
44 5
70 8
75 8
74 8
71 8
50 6
49 6
35 5
14 3
17 3
33 4
56 7
73 8
72 8
end_CG
