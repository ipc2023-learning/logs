begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var2
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var1
-1
21
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_6)
end_variable
begin_variable
var0
-1
16
Atom at(box1, loc_2_5)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_5)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_5)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
end_variable
16
begin_mutex_group
2
17 0
0 0
end_mutex_group
begin_mutex_group
2
17 1
1 0
end_mutex_group
begin_mutex_group
2
17 2
6 0
end_mutex_group
begin_mutex_group
2
17 3
2 0
end_mutex_group
begin_mutex_group
2
17 4
14 0
end_mutex_group
begin_mutex_group
2
17 5
12 0
end_mutex_group
begin_mutex_group
2
17 6
15 0
end_mutex_group
begin_mutex_group
2
17 7
7 0
end_mutex_group
begin_mutex_group
2
17 8
3 0
end_mutex_group
begin_mutex_group
2
17 9
9 0
end_mutex_group
begin_mutex_group
2
17 10
11 0
end_mutex_group
begin_mutex_group
2
17 11
5 0
end_mutex_group
begin_mutex_group
2
17 12
10 0
end_mutex_group
begin_mutex_group
2
17 13
13 0
end_mutex_group
begin_mutex_group
2
17 14
8 0
end_mutex_group
begin_mutex_group
2
17 15
4 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
19
9
end_state
begin_goal
1
17 4
end_goal
74
begin_operator
move loc_2_5 loc_2_6 right
0
1
0 16 0 1
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
6 0
1
0 16 0 5
0
end_operator
begin_operator
move loc_2_6 loc_2_5 left
1
0 0
1
0 16 1 0
0
end_operator
begin_operator
move loc_2_6 loc_2_7 right
0
1
0 16 1 2
0
end_operator
begin_operator
move loc_2_7 loc_2_6 left
0
1
0 16 2 1
0
end_operator
begin_operator
move loc_3_2 loc_3_3 right
1
1 0
1
0 16 3 4
0
end_operator
begin_operator
move loc_3_2 loc_4_2 down
1
2 0
1
0 16 3 6
0
end_operator
begin_operator
move loc_3_3 loc_3_2 left
0
1
0 16 4 3
0
end_operator
begin_operator
move loc_3_3 loc_4_3 down
1
14 0
1
0 16 4 7
0
end_operator
begin_operator
move loc_3_5 loc_2_5 up
1
0 0
1
0 16 5 0
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
15 0
1
0 16 5 9
0
end_operator
begin_operator
move loc_4_2 loc_3_2 up
0
1
0 16 6 3
0
end_operator
begin_operator
move loc_4_2 loc_4_3 right
1
14 0
1
0 16 6 7
0
end_operator
begin_operator
move loc_4_3 loc_3_3 up
1
1 0
1
0 16 7 4
0
end_operator
begin_operator
move loc_4_3 loc_4_2 left
1
2 0
1
0 16 7 6
0
end_operator
begin_operator
move loc_4_3 loc_4_4 right
1
12 0
1
0 16 7 8
0
end_operator
begin_operator
move loc_4_3 loc_5_3 down
1
9 0
1
0 16 7 12
0
end_operator
begin_operator
move loc_4_4 loc_4_3 left
1
14 0
1
0 16 8 7
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
15 0
1
0 16 8 9
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
0
1
0 16 8 13
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
6 0
1
0 16 9 5
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
12 0
1
0 16 9 8
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
7 0
1
0 16 9 10
0
end_operator
begin_operator
move loc_4_5 loc_5_5 down
1
11 0
1
0 16 9 14
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
1
15 0
1
0 16 10 9
0
end_operator
begin_operator
move loc_4_6 loc_4_7 right
1
3 0
1
0 16 10 11
0
end_operator
begin_operator
move loc_4_7 loc_4_6 left
1
7 0
1
0 1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
3
check 1
2
check 0
check 0
check 1
4
switch 1
check 0
check 1
5
check 0
switch 2
check 0
check 1
6
check 0
check 0
switch 0
check 1
7
check 0
check 0
switch 14
check 0
check 1
8
check 0
check 0
switch 0
check 0
check 1
9
check 0
switch 15
check 0
check 1
10
check 0
check 0
switch 0
check 1
11
check 0
check 0
switch 14
check 0
check 1
12
check 0
check 0
switch 1
check 0
check 1
13
check 0
switch 2
check 0
check 1
14
check 0
switch 12
check 0
check 1
15
check 0
switch 9
check 0
check 1
16
check 0
check 0
switch 0
check 1
19
check 0
check 0
switch 14
check 0
check 1
17
check 0
switch 15
check 0
check 1
18
check 0
check 0
switch 6
check 0
check 1
20
check 0
switch 12
check 0
check 1
21
check 0
switch 7
check 0
check 1
22
check 0
switch 11
check 0
check 1
23
check 0
check 0
switch 15
check 0
check 1
24
check 0
switch 3
check 0
check 1
25
check 0
check 0
switch 7
check 0
check 1
26
check 0
check 0
switch 0
check 1
28
check 0
check 0
switch 14
check 0
check 1
27
check 0
switch 5
check 0
check 1
29
check 0
check 0
switch 12
check 0
check 1
30
check 0
switch 9
check 0
check 1
31
check 0
switch 11
check 0
check 1
32
check 0
switch 10
check 0
check 1
33
check 0
check 0
switch 0
check 1
35
check 0
check 0
switch 15
check 0
check 1
34
check 0
switch 13
check 0
check 1
36
check 0
check 0
switch 9
check 0
check 1
37
check 0
switch 10
check 0
check 1
38
check 0
check 0
switch 0
check 1
39
check 0
check 0
switch 5
check 0
check 1
40
check 0
switch 13
check 0
check 1
41
check 0
check 0
switch 11
check 0
check 1
42
check 0
switch 10
check 0
check 1
43
check 0
switch 8
check 0
check 1
44
check 0
check 0
switch 0
check 1
47
check 0
check 0
switch 13
check 0
check 1
45
check 0
switch 4
check 0
check 1
46
check 0
check 0
switch 8
check 0
check 1
48
check 0
check 0
switch 8
check 0
check 1
49
check 0
check 0
check 0
end_SG
begin_DTG
1
1
58
2
17 2
16 9
0
end_DTG
begin_DTG
1
1
64
2
17 4
16 12
0
end_DTG
begin_DTG
1
1
56
2
17 4
16 8
0
end_DTG
begin_DTG
1
1
60
2
17 7
16 9
0
end_DTG
begin_DTG
1
1
71
2
17 14
16 17
0
end_DTG
begin_DTG
2
1
55
2
17 9
16 7
1
70
2
17 12
16 17
0
end_DTG
begin_DTG
1
1
65
2
17 6
16 14
2
0
50
3
17 2
16 0
15 0
0
58
3
17 2
16 9
0 0
end_DTG
begin_DTG
1
1
57
2
17 6
16 8
2
0
60
3
17 7
16 9
3 0
0
63
3
17 7
16 11
15 0
end_DTG
begin_DTG
1
1
68
2
17 13
16 16
2
0
71
3
17 14
16 17
4 0
0
73
3
17 14
16 19
13 0
end_DTG
begin_DTG
1
1
51
2
17 4
16 4
2
0
55
3
17 9
16 7
5 0
0
66
3
17 9
16 15
14 0
end_DTG
begin_DTG
1
1
72
2
17 13
16 18
2
0
67
3
17 12
16 15
13 0
0
70
3
17 12
16 17
5 0
end_DTG
begin_DTG
1
1
52
2
17 6
16 5
2
0
61
3
17 10
16 9
13 0
0
69
3
17 10
16 17
15 0
end_DTG
begin_DTG
2
1
53
2
17 4
16 6
1
62
2
17 6
16 10
2
0
54
3
17 5
16 7
15 0
0
59
3
17 5
16 9
14 0
end_DTG
begin_DTG
3
1
61
2
17 10
16 9
1
67
2
17 12
16 15
1
73
2
17 14
16 19
2
0
68
3
17 13
16 16
8 0
0
72
3
17 13
16 18
10 0
end_DTG
begin_DTG
2
1
59
2
17 5
16 9
1
66
2
17 9
16 15
4
0
51
3
17 4
16 4
9 0
0
53
3
17 4
16 6
12 0
0
56
3
17 4
16 8
2 0
0
64
3
17 4
16 12
1 0
end_DTG
begin_DTG
4
1
50
2
17 2
16 0
1
54
2
17 5
16 7
1
63
2
17 7
16 11
1
69
2
17 10
16 17
4
0
52
3
17 6
16 5
11 0
0
57
3
17 6
16 8
7 0
0
62
3
17 6
16 10
12 0
0
65
3
17 6
16 14
6 0
end_DTG
begin_DTG
3
1
0
0
5
1
1
6 0
5
50
2
17 2
15 0
2
0
2
1
0 0
2
3
0
1
1
4
0
2
4
5
1
1 0
6
6
1
2 0
3
3
7
0
7
8
1
14 0
7
51
2
17 4
9 0
3
0
9
1
0 0
9
10
1
15 0
9
52
2
17 6
11 0
3
3
11
0
7
12
1
14 0
7
53
2
17 4
12 0
6
4
13
1
1 0
6
14
1
2 0
8
15
1
12 0
8
54
2
17 5
15 0
12
16
1
9 0
12
55
2
17 9
5 0
5
7
17
1
14 0
7
56
2
17 4
2 0
9
18
1
15 0
9
57
2
17 6
7 0
13
19
0
8
5
20
1
6 0
5
58
2
17 2
0 0
8
21
1
12 0
8
59
2
17 5
14 0
10
22
1
7 0
10
60
2
17 7
3 0
14
23
1
11 0
14
61
2
17 10
13 0
3
9
24
1
15 0
9
62
2
17 6
12 0
11
25
1
3 0
2
10
26
1
7 0
10
63
2
17 7
15 0
4
7
27
1
14 0
7
64
2
17 4
1 0
13
28
0
15
29
1
5 0
4
8
30
1
12 0
12
31
1
9 0
14
32
1
11 0
16
33
1
10 0
4
9
34
1
15 0
9
65
2
17 6
6 0
13
35
0
17
36
1
13 0
4
12
37
1
9 0
12
66
2
17 9
14 0
16
38
1
10 0
16
67
2
17 12
13 0
4
13
39
0
15
40
1
5 0
17
41
1
13 0
17
68
2
17 13
8 0
6
14
42
1
11 0
14
69
2
17 10
15 0
16
43
1
10 0
16
70
2
17 12
5 0
18
44
1
8 0
18
71
2
17 14
4 0
4
17
45
1
13 0
17
72
2
17 13
10 0
19
46
1
4 0
20
47
0
2
18
48
1
8 0
18
73
2
17 14
13 0
1
18
49
1
8 0
end_DTG
begin_DTG
0
0
2
0
58
2
16 9
0 0
6
50
2
16 0
15 0
0
4
1
64
2
16 12
1 0
3
56
2
16 8
2 0
5
53
2
16 6
12 0
9
51
2
16 4
9 0
2
4
59
2
16 9
14 0
6
54
2
16 7
15 0
4
2
65
2
16 14
6 0
5
62
2
16 10
12 0
7
57
2
16 8
7 0
10
52
2
16 5
11 0
2
6
63
2
16 11
15 0
8
60
2
16 9
3 0
0
2
4
66
2
16 15
14 0
11
55
2
16 7
5 0
2
6
69
2
16 17
15 0
13
61
2
16 9
13 0
0
2
11
70
2
16 17
5 0
13
67
2
16 15
13 0
2
12
72
2
16 18
10 0
14
68
2
16 16
8 0
2
13
73
2
16 19
13 0
15
71
2
16 17
4 0
0
end_DTG
begin_CG
3
17 1
16 3
6 1
3
17 1
16 3
14 1
3
17 1
16 3
14 1
3
17 1
16 2
7 1
3
17 1
16 2
8 1
4
17 2
16 4
9 1
10 1
3
17 1
16 3
15 1
3
17 1
16 3
15 1
3
17 1
16 4
13 1
3
17 1
16 4
14 1
3
17 1
16 4
13 1
3
17 1
16 4
15 1
4
17 2
16 5
14 1
15 1
5
17 3
16 6
11 1
10 1
8 1
4
17 2
16 6
12 1
9 1
6
17 4
16 8
6 1
12 1
7 1
11 1
17
17 24
0 1
1 1
6 3
2 1
14 6
12 4
15 8
7 3
3 1
9 3
11 3
5 2
10 3
13 5
8 3
4 1
17
16 24
0 1
1 1
6 3
2 1
14 6
12 4
15 8
7 3
3 1
9 3
11 3
5 2
10 3
13 5
8 3
4 1
end_CG
