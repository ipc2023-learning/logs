begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var2
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var1
-1
19
Atom at-robot(loc_3_5)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_8_2)
end_variable
begin_variable
var0
-1
19
Atom at(box1, loc_3_5)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_8_2)
end_variable
19
begin_mutex_group
2
20 0
0 0
end_mutex_group
begin_mutex_group
2
20 1
3 0
end_mutex_group
begin_mutex_group
2
20 2
16 0
end_mutex_group
begin_mutex_group
2
20 3
13 0
end_mutex_group
begin_mutex_group
2
20 4
6 0
end_mutex_group
begin_mutex_group
2
20 5
1 0
end_mutex_group
begin_mutex_group
2
20 6
4 0
end_mutex_group
begin_mutex_group
2
20 7
9 0
end_mutex_group
begin_mutex_group
2
20 8
17 0
end_mutex_group
begin_mutex_group
2
20 9
14 0
end_mutex_group
begin_mutex_group
2
20 10
8 0
end_mutex_group
begin_mutex_group
2
20 11
15 0
end_mutex_group
begin_mutex_group
2
20 12
18 0
end_mutex_group
begin_mutex_group
2
20 13
10 0
end_mutex_group
begin_mutex_group
2
20 14
7 0
end_mutex_group
begin_mutex_group
2
20 15
12 0
end_mutex_group
begin_mutex_group
2
20 16
11 0
end_mutex_group
begin_mutex_group
2
20 17
5 0
end_mutex_group
begin_mutex_group
2
20 18
2 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
18
11
end_state
begin_goal
1
20 13
end_goal
84
begin_operator
move loc_3_5 loc_4_5 down
1
16 0
1
0 19 0 2
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
16 0
1
0 19 1 2
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
1
17 0
1
0 19 1 8
0
end_operator
begin_operator
move loc_4_5 loc_3_5 up
1
0 0
1
0 19 2 0
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
3 0
1
0 19 2 1
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
13 0
1
0 19 2 3
0
end_operator
begin_operator
move loc_4_5 loc_5_5 down
1
14 0
1
0 19 2 9
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
1
16 0
1
0 19 3 2
0
end_operator
begin_operator
move loc_4_6 loc_4_7 right
1
6 0
1
0 19 3 4
0
end_operator
begin_operator
move loc_4_7 loc_4_6 left
1
13 0
1
0 19 4 3
0
end_operator
begin_operator
move loc_4_7 loc_4_8 right
1
1 0
1
0 19 4 5
0
end_operator
begin_operator
move loc_4_8 loc_4_7 left
1
6 0
1
0 19 5 4
0
end_operator
begin_operator
move loc_5_2 loc_5_3 right
1
9 0
1
0 19 6 7
0
end_operator
begin_operator
move loc_5_2 loc_6_2 down
1
8 0
1
0 19 6 10
0
end_operator
begin_operator
move loc_5_3 loc_5_2 left
1
4 0
1
0 19 7 6
0
end_operator
begin_operator
move loc_5_3 loc_5_4 right
1
17 0
1
0 19 7 8
0
end_operator
begin_operator
move loc_5_3 loc_6_3 down
1
15 0
1
0 19 7 11
0
end_operator
begin_operator
move loc_5_4 loc_4_4 up
1
3 0
1
0 19 8 1
0
end_operator
begin_operator
move loc_5_4 loc_5_3 left
1
9 0
1
0 19 8 7
0
end_operator
begin_operator
move loc_5_4 loc_5_5 right
1
14 0
1
0 19 8 9
0
end_operator
begin_operator
move loc_5_4 loc_6_4 d




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 1
29
check 0
switch 12
check 0
check 1
30
check 0
check 0
switch 17
check 0
check 1
31
check 0
switch 15
check 0
check 1
32
check 0
switch 10
check 0
check 1
33
check 0
switch 11
check 0
check 1
34
check 0
check 0
switch 14
check 0
check 1
35
check 0
switch 18
check 0
check 1
36
check 0
switch 5
check 0
check 1
37
check 0
check 0
switch 8
check 0
check 1
38
check 0
switch 12
check 0
check 1
39
check 0
switch 2
check 0
check 1
40
check 0
check 0
switch 15
check 0
check 1
41
check 0
switch 7
check 0
check 1
42
check 0
switch 11
check 0
check 1
43
check 0
check 0
switch 18
check 0
check 1
44
check 0
switch 12
check 0
check 1
45
check 0
switch 5
check 0
check 1
46
check 0
check 0
switch 10
check 0
check 1
47
check 0
switch 11
check 0
check 1
48
check 0
check 0
switch 7
check 0
check 1
49
check 0
check 0
check 0
end_SG
begin_DTG
1
1
65
2
20 2
19 9
0
end_DTG
begin_DTG
1
1
56
2
20 4
19 3
0
end_DTG
begin_DTG
1
1
69
2
20 14
19 10
0
end_DTG
begin_DTG
2
1
55
2
20 2
19 3
1
71
2
20 8
19 12
0
end_DTG
begin_DTG
2
1
63
2
20 7
19 8
1
75
2
20 10
19 14
0
end_DTG
begin_DTG
2
1
67
2
20 13
19 9
1
78
2
20 16
19 15
0
end_DTG
begin_DTG
1
1
53
2
20 3
19 2
2
0
56
3
20 4
19 3
1 0
0
58
3
20 4
19 5
13 0
end_DTG
begin_DTG
2
1
60
2
20 10
19 6
1
80
2
20 15
19 16
2
0
69
3
20 14
19 10
2 0
0
83
3
20 14
19 18
8 0
end_DTG
begin_DTG
2
1
72
2
20 11
19 12
1
83
2
20 14
19 18
2
0
60
3
20 10
19 6
7 0
0
75
3
20 10
19 14
4 0
end_DTG
begin_DTG
2
1
66
2
20 8
19 9
1
77
2
20 11
19 15
2
0
59
3
20 7
19 6
17 0
0
63
3
20 7
19 8
4 0
end_DTG
begin_DTG
2
1
54
2
20 9
19 2
1
70
2
20 12
19 11
2
0
67
3
20 13
19 9
5 0
0
81
3
20 13
19 17
14 0
end_DTG
begin_DTG
2
1
64
2
20 12
19 8
1
76
2
20 15
19 14
2
0
78
3
20 16
19 15
5 0
0
82
3
20 16
19 17
12 0
end_DTG
begin_DTG
2
1
62
2
20 11
19 7
1
82
2
20 16
19 17
2
0
76
3
20 15
19 14
11 0
0
80
3
20 15
19 16
7 0
end_DTG
begin_DTG
2
1
51
2
20 2
19 1
1
58
2
20 4
19 5
2
0
53
3
20 3
19 2
6 0
0
57
3
20 3
19 4
16 0
end_DTG
begin_DTG
3
1
50
2
20 2
19 0
1
61
2
20 8
19 7
1
81
2
20 13
19 17
2
0
54
3
20 9
19 2
10 0
0
73
3
20 9
19 13
16 0
end_DTG
begin_DTG
1
1
74
2
20 12
19 13
4
0
62
3
20 11
19 7
12 0
0
68
3
20 11
19 10
18 0
0
72
3
20 11
19 12
8 0
0
77
3
20 11
19 15
9 0
end_DTG
begin_DTG
2
1
57
2
20 3
19 4
1
73
2
20 9
19 13
4
0
50
3
20 2
19 0
14 0
0
51
3
20 2
19 1
13 0
0
55
3
20 2
19 3
3 0
0
65
3
20 2
19 9
0 0
end_DTG
begin_DTG
2
1
59
2
20 7
19 6
1
79
2
20 12
19 16
4
0
52
3
20 8
19 1
18 0
0
61
3
20 8
19 7
14 0
0
66
3
20 8
19 9
9 0
0
71
3
20 8
19 12
3 0
end_DTG
begin_DTG
2
1
52
2
20 8
19 1
1
68
2
20 11
19 10
4
0
64
3
20 12
19 8
11 0
0
70
3
20 12
19 11
10 0
0
74
3
20 12
19 13
15 0
0
79
3
20 12
19 16
17 0
end_DTG
begin_DTG
2
2
0
1
16 0
2
50
2
20 2
14 0
4
2
1
1
16 0
2
51
2
20 2
13 0
8
2
1
17 0
8
52
2
20 8
18 0
6
0
3
1
0 0
1
4
1
3 0
3
5
1
13 0
3
53
2
20 3
6 0
9
6
1
14 0
9
54
2
20 9
10 0
4
2
7
1
16 0
2
55
2
20 2
3 0
4
8
1
6 0
4
56
2
20 4
1 0
3
3
9
1
13 0
3
57
2
20 3
16 0
5
10
1
1 0
2
4
11
1
6 0
4
58
2
20 4
13 0
4
7
12
1
9 0
7
59
2
20 7
17 0
10
13
1
8 0
10
60
2
20 10
7 0
5
6
14
1
4 0
8
15
1
17 0
8
61
2
20 8
14 0
11
16
1
15 0
11
62
2
20 11
12 0
6
1
17
1
3 0
7
18
1
9 0
7
63
2
20 7
4 0
9
19
1
14 0
12
20
1
18 0
12
64
2
20 12
11 0
6
2
21
1
16 0
2
65
2
20 2
0 0
8
22
1
17 0
8
66
2
20 8
9 0
13
23
1
10 0
13
67
2
20 13
5 0
5
6
24
1
4 0
11
25
1
15 0
11
68
2
20 11
18 0
14
26
1
7 0
14
69
2
20 14
2 0
5
7
27
1
9 0
10
28
1
8 0
12
29
1
18 0
12
70
2
20 12
10 0
15
30
1
12 0
6
8
31
1
17 0
8
71
2
20 8
3 0
11
32
1
15 0
11
72
2
20 11
8 0
13
33
1
10 0
16
34
1
11 0
5
9
35
1
14 0
9
73
2
20 9
16 0
12
36
1
18 0
12
74
2
20 12
15 0
17
37
1
5 0
5
10
38
1
8 0
10
75
2
20 10
4 0
15
39
1
12 0
15
76
2
20 15
11 0
18
40
1
2 0
5
11
41
1
15 0
11
77
2
20 11
9 0
14
42
1
7 0
16
43
1
11 0
16
78
2
20 16
5 0
5
12
44
1
18 0
12
79
2
20 12
17 0
15
45
1
12 0
15
80
2
20 15
7 0
17
46
1
5 0
4
13
47
1
10 0
13
81
2
20 13
14 0
16
48
1
11 0
16
82
2
20 16
12 0
2
14
49
1
7 0
14
83
2
20 14
8 0
end_DTG
begin_DTG
0
0
4
0
65
2
19 9
0 0
1
55
2
19 3
3 0
3
51
2
19 1
13 0
9
50
2
19 0
14 0
2
2
57
2
19 4
16 0
4
53
2
19 2
6 0
2
3
58
2
19 5
13 0
5
56
2
19 3
1 0
0
0
2
6
63
2
19 8
4 0
8
59
2
19 6
17 0
4
1
71
2
19 12
3 0
7
66
2
19 9
9 0
9
61
2
19 7
14 0
12
52
2
19 1
18 0
2
2
73
2
19 13
16 0
13
54
2
19 2
10 0
2
6
75
2
19 14
4 0
14
60
2
19 6
7 0
4
7
77
2
19 15
9 0
10
72
2
19 12
8 0
12
68
2
19 10
18 0
15
62
2
19 7
12 0
4
8
79
2
19 16
17 0
11
74
2
19 13
15 0
13
70
2
19 11
10 0
16
64
2
19 8
11 0
2
9
81
2
19 17
14 0
17
67
2
19 9
5 0
2
10
83
2
19 18
8 0
18
69
2
19 10
2 0
2
14
80
2
19 16
7 0
16
76
2
19 14
11 0
2
15
82
2
19 17
12 0
17
78
2
19 15
5 0
0
0
end_DTG
begin_CG
3
20 1
19 2
16 1
3
20 1
19 2
6 1
3
20 1
19 2
7 1
4
20 2
19 4
16 1
17 1
4
20 2
19 4
9 1
8 1
4
20 2
19 4
10 1
11 1
3
20 1
19 3
13 1
4
20 2
19 5
8 1
12 1
4
20 2
19 5
15 1
7 1
4
20 2
19 5
17 1
15 1
4
20 2
19 5
14 1
18 1
4
20 2
19 5
18 1
12 1
4
20 2
19 5
15 1
11 1
4
20 2
19 4
16 1
6 1
5
20 3
19 6
16 1
17 1
10 1
3
20 1
19 5
18 1
4
20 2
19 6
13 1
14 1
4
20 2
19 6
9 1
18 1
4
20 2
19 6
17 1
15 1
20
20 34
0 1
3 2
16 6
13 4
6 3
1 1
4 2
9 4
17 6
14 5
8 4
15 5
18 6
10 4
7 4
12 4
11 4
5 2
2 1
20
19 34
0 1
3 2
16 6
13 4
6 3
1 1
4 2
9 4
17 6
14 5
8 4
15 5
18 6
10 4
7 4
12 4
11 4
5 2
2 1
end_CG
