begin_version
3
end_version
begin_metric
0
end_metric
76
begin_variable
var21
-1
2
Atom clear(loc_12_4)
NegatedAtom clear(loc_12_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_12_8)
NegatedAtom clear(loc_12_8)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var72
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var75
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_10)
NegatedAtom clear(loc_11_10)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var65
-1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
52
532
2
71 49
15 0
2
47
651
2
71 66
52 0
62
536
2
71 49
54 0
0
4
48
663
2
71 69
33 0
55
607
2
71 61
9 0
57
589
2
71 59
69 0
64
545
2
71 50
66 0
4
49
672
2
71 70
57 0
56
619
2
71 62
65 0
58
598
2
71 60
61 0
65
551
2
71 51
70 0
4
50
681
2
71 71
38 0
57
625
2
71 63
69 0
59
610
2
71 61
19 0
66
560
2
71 52
32 0
2
58
634
2
71 64
61 0
60
622
2
71 62
58 0
4
51
699
2
71 73
31 0
59
640
2
71 65
19 0
61
628
2
71 63
17 0
68
569
2
71 53
67 0
2
52
711
2
71 74
15 0
69
575
2
71 54
68 0
2
0
586
2
71 56
53 0
54
228
2
71 0
51 0
2
1
592
2
71 59
7 0
55
234
2
71 1
9 0
4
2
601
2
71 60
41 0
56
237
2
71 2
65 0
63
675
2
71 70
11 0
65
657
2
71 68
70 0
4
3
613
2
71 61
40 0
57
246
2
71 3
69 0
64
684
2
71 71
66 0
66
666
2
71 69
32 0
2
65
690
2
71 72
70 0
67
678
2
71 70
23 0
2
66
702
2
71 73
32 0
68
687
2
71 71
67 0
4
4
637
2
71 64
39 0
60
255
2
71 4
58 0
67
714
2
71 74
23 0
69
693
2
71 72
68 0
4
5
643
2
71 65
64 0
61
264
2
71 5
17 0
68
723
2
71 75
67 0
70
705
2
71 73
27 0
2
62
717
2
71 74
54 0
69
654
2
71 66
68 0
end_DTG
begin_CG
5
73 1
74 1
75 1
71 4
46 3
5
73 1
74 1
75 1
71 5
62 3
5
73 1
74 1
75 1
71 5
63 3
5
73 1
74 1
75 1
71 4
14 3
6
73 1
72 1
74 1
75 1
71 5
34 4
6
73 1
72 1
74 1
75 1
71 5
29 4
6
73 1
72 1
74 1
75 1
71 6
18 4
6
73 2
74 2
75 2
71 8
41 3
11 3
6
73 2
74 2
75 2
71 8
41 3
46 3
6
73 2
74 2
75 2
71 8
65 3
11 3
7
73 2
72 1
74 2
75 2
71 9
35 4
60 3
5
73 1
74 1
75 1
71 6
66 3
5
73 1
74 1
75 1
71 6
59 3
5
73 1
74 1
75 1
71 5
15 3
6
73 2
74 2
75 2
71 9
60 3
16 3
6
73 2
74 2
75 2
71 9
13 3
17 3
6
73 2
74 2
75 2
71 9
55 3
30 3
6
73 2
74 2
75 2
71 9
58 3
68 3
6
73 1
72 1
74 1
75 1
71 7
29 4
6
73 2
74 2
75 2
71 9
61 3
58 3
6
73 2
74 2
75 2
71 8
21 3
31 3
6
73 2
74 2
75 2
71 8
22 3
20 3
6
73 2
74 2
75 2
71 9
12 3
21 3
6
73 2
74 2
75 2
71 9
32 3
67 3
6
73 2
74 2
75 2
71 8
46 3
25 3
6
73 2
74 2
75 2
71 8
24 3
62 3
6
73 2
74 2
75 2
71 9
42 3
63 3
6
73 2
74 2
75 2
71 9
42 3
68 3
6
73 1
72 1
74 1
75 1
71 7
43 4
7
73 2
72 2
74 2
75 2
71 11
18 4
44 4
7
73 3
74 3
75 3
71 12
16 3
56 3
33 3
7
73 3
74 3
75 3
71 12
20 3
15 3
58 3
7
73 3
74 3
75 3
71 12
61 3
70 3
23 3
7
73 3
74 3
75 3
71 12
30 3
57 3
65 3
7
73 2
72 1
74 2
75 2
71 10
53 4
26 3
7
73 2
72 1
74 2
75 2
71 10
45 4
59 3
7
73 3
74 3
75 3
71 12
59 3
55 3
37 3
7
73 3
74 3
75 3
71 12
36 3
56 3
38 3
7
73 3
74 3
75 3
71 12
37 3
57 3
61 3
7
73 3
74 3
75 3
71 12
64 3
62 3
67 3
7
73 3
74 3
75 3
71 12
41 3
46 3
70 3
5
73 1
74 1
75 1
71 7
66 3
5
73 1
74 1
75 1
71 7
64 3
7
73 2
72 2
74 2
75 2
71 11
50 4
28 4
7
73 2
72 2
74 2
75 2
71 11
28 4
47 4
7
73 2
72 2
74 2
75 2
71 11
35 4
50 4
6
73 2
74 2
75 2
71 10
40 3
24 3
7
73 2
72 2
74 2
75 2
71 10
44 4
48 4
7
73 2
72 2
74 2
75 2
71 10
47 4
49 4
7
73 2
72 2
74 2
75 2
71 11
48 4
52 4
8
73 3
72 2
74 3
75 3
71 14
45 4
43 4
22 3
7
73 2
72 2
74 2
75 2
71 11
52 4
54 4
8
73 3
72 2
74 3
75 3
71 14
49 4
13 3
51 4
8
73 3
72 2
74 3
75 3
71 14
42 3
34 4
54 4
8
73 3
72 2
74 3
75 3
71 14
53 4
51 4
27 3
6
73 2
74 2
75 2
71 10
60 3
56 3
6
73 2
74 2
75 2
71 10
55 3
57 3
6
73 2
74 2
75 2
71 10
56 3
69 3
7
73 3
74 3
75 3
71 13
31 3
19 3
67 3
7
73 3
74 3
75 3
71 13
60 3
12 3
36 3
7
73 3
74 3
75 3
71 13
14 3
59 3
55 3
7
73 3
74 3
75 3
71 13
38 3
69 3
19 3
7
73 3
74 3
75 3
71 13
39 3
25 3
63 3
7
73 3
74 3
75 3
71 13
64 3
62 3
26 3
7
73 3
74 3
75 3
71 13
42 3
63 3
68 3
7
73 3
74 3
75 3
71 13
33 3
69 3
66 3
7
73 3
74 3
75 3
71 13
41 3
65 3
70 3
8
73 4
74 4
75 4
71 16
39 3
58 3
23 3
68 3
8
73 4
74 4
75 4
71 16
64 3
17 3
67 3
27 3
8
73 4
74 4
75 4
71 16
57 3
65 3
61 3
70 3
8
73 4
74 4
75 4
71 16
40 3
69 3
66 3
32 3
75
73 158
72 32
74 158
75 158
53 19
7 6
41 15
40 15
39 15
64 21
42 15
34 15
8 6
46 18
24 12
25 12
62 21
63 21
26 12
4 4
0 3
1 3
2 3
29 16
5 4
6 4
18 12
44 16
10 7
35 15
45 16
50 19
43 16
28 12
47 16
3 3
14 12
60 21
59 21
12 9
22 12
48 16
16 12
55 18
36 15
21 12
49 16
30 15
56 18
37 15
20 12
52 19
33 15
57 18
38 15
31 15
15 12
13 9
51 16
9 6
65 21
69 24
61 21
19 12
58 21
17 12
54 19
11 9
66 21
70 24
32 15
23 12
67 24
68 24
27 12
21
71 32
53 4
34 3
4 1
29 4
5 1
6 1
18 3
44 4
10 1
35 3
45 4
50 4
43 4
28 3
47 4
48 4
49 4
52 4
51 4
54 4
72
71 158
53 5
7 2
41 5
40 5
39 5
64 7
42 5
34 4
8 2
46 6
24 4
25 4
62 7
63 7
26 4
4 1
0 1
1 1
2 1
29 4
5 1
6 1
18 3
44 4
10 2
35 4
45 4
50 5
43 4
28 3
47 4
3 1
14 4
60 7
59 7
12 3
22 4
48 4
16 4
55 6
36 5
21 4
49 4
30 5
56 6
37 5
20 4
52 5
33 5
57 6
38 5
31 5
15 4
13 3
51 4
9 2
65 7
69 8
61 7
19 4
58 7
17 4
54 5
11 3
66 7
70 8
32 5
23 4
67 8
68 8
27 4
72
71 158
53 5
7 2
41 5
40 5
39 5
64 7
42 5
34 4
8 2
46 6
24 4
25 4
62 7
63 7
26 4
4 1
0 1
1 1
2 1
29 4
5 1
6 1
18 3
44 4
10 2
35 4
45 4
50 5
43 4
28 3
47 4
3 1
14 4
60 7
59 7
12 3
22 4
48 4
16 4
55 6
36 5
21 4
49 4
30 5
56 6
37 5
20 4
52 5
33 5
57 6
38 5
31 5
15 4
13 3
51 4
9 2
65 7
69 8
61 7
19 4
58 7
17 4
54 5
11 3
66 7
70 8
32 5
23 4
67 8
68 8
27 4
72
71 158
53 5
7 2
41 5
40 5
39 5
64 7
42 5
34 4
8 2
46 6
24 4
25 4
62 7
63 7
26 4
4 1
0 1
1 1
2 1
29 4
5 1
6 1
18 3
44 4
10 2
35 4
45 4
50 5
43 4
28 3
47 4
3 1
14 4
60 7
59 7
12 3
22 4
48 4
16 4
55 6
36 5
21 4
49 4
30 5
56 6
37 5
20 4
52 5
33 5
57 6
38 5
31 5
15 4
13 3
51 4
9 2
65 7
69 8
61 7
19 4
58 7
17 4
54 5
11 3
66 7
70 8
32 5
23 4
67 8
68 8
27 4
end_CG
