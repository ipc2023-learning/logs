begin_version
3
end_version
begin_metric
0
end_metric
64
begin_variable
var13
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_8_6)
Nega




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5 0
40
537
2
59 41
54 0
48
457
2
59 34
58 0
4
32
669
2
59 52
48 0
39
581
2
59 44
56 0
41
553
2
59 42
49 0
49
469
2
59 35
53 0
4
33
685
2
59 53
35 0
40
593
2
59 45
54 0
42
569
2
59 43
13 0
50
481
2
59 36
44 0
2
34
585
2
59 44
29 0
41
489
2
59 37
49 0
2
34
701
2
59 55
29 0
52
493
2
59 37
3 0
0
4
36
709
2
59 57
26 0
44
625
2
59 49
9 0
46
609
2
59 47
52 0
53
509
2
59 39
30 0
4
37
721
2
59 58
51 0
45
641
2
59 50
37 0
47
613
2
59 48
57 0
54
525
2
59 40
46 0
4
38
733
2
59 59
55 0
46
657
2
59 51
52 0
48
629
2
59 49
58 0
55
541
2
59 41
50 0
4
39
745
2
59 60
56 0
47
673
2
59 52
57 0
49
645
2
59 50
53 0
56
557
2
59 42
45 0
4
40
757
2
59 61
54 0
48
689
2
59 53
58 0
50
661
2
59 51
44 0
57
573
2
59 43
38 0
4
41
765
2
59 62
49 0
49
697
2
59 54
53 0
51
677
2
59 52
14 0
58
589
2
59 44
10 0
2
43
693
2
59 53
16 0
50
601
2
59 46
44 0
0
2
0
617
2
59 48
18 0
45
201
2
59 1
37 0
4
1
633
2
59 49
39 0
46
209
2
59 2
52 0
53
737
2
59 59
30 0
55
713
2
59 57
50 0
4
2
649
2
59 50
43 0
47
221
2
59 3
57 0
54
749
2
59 60
46 0
56
725
2
59 58
45 0
4
3
665
2
59 51
17 0
48
229
2
59 4
58 0
55
761
2
59 61
50 0
57
741
2
59 59
38 0
4
4
681
2
59 52
4 0
49
237
2
59 5
53 0
56
769
2
59 62
45 0
58
753
2
59 60
10 0
0
end_DTG
begin_CG
6
60 1
61 1
62 1
63 1
59 5
28 4
6
60 1
61 1
62 1
63 1
59 6
15 4
6
60 1
61 1
62 1
63 1
59 6
40 4
6
60 1
61 1
62 1
63 1
59 6
16 4
7
60 2
61 2
62 2
63 2
59 10
17 4
38 4
7
60 2
61 2
62 2
63 2
59 10
18 4
11 4
7
60 2
61 2
62 2
63 2
59 10
43 4
11 4
7
60 2
61 2
62 2
63 2
59 10
28 4
19 4
7
60 2
61 2
62 2
63 2
59 10
20 4
21 4
7
60 2
61 2
62 2
63 2
59 10
22 4
37 4
7
60 2
61 2
62 2
63 2
59 10
44 4
38 4
6
60 1
61 1
62 1
63 1
59 7
39 4
6
60 1
61 1
62 1
63 1
59 7
40 4
6
60 1
61 1
62 1
63 1
59 7
49 4
6
60 1
61 1
62 1
63 1
59 7
44 4
7
60 2
61 2
62 2
63 2
59 11
12 4
23 4
7
60 2
61 2
62 2
63 2
59 11
29 4
14 4
7
60 2
61 2
62 2
63 2
59 11
43 4
45 4
7
60 2
61 2
62 2
63 2
59 11
39 4
30 4
7
60 2
61 2
62 2
63 2
59 11
24 4
25 4
7
60 2
61 2
62 2
63 2
59 11
28 4
36 4
7
60 2
61 2
62 2
63 2
59 11
36 4
42 4
7
60 2
61 2
62 2
63 2
59 11
23 4
26 4
7
60 2
61 2
62 2
63 2
59 10
15 4
22 4
7
60 2
61 2
62 2
63 2
59 11
28 4
36 4
7
60 2
61 2
62 2
63 2
59 11
19 4
27 4
7
60 2
61 2
62 2
63 2
59 11
51 4
37 4
7
60 2
61 2
62 2
63 2
59 10
25 4
29 4
6
60 1
61 1
62 1
63 1
59 8
20 4
8
60 3
61 3
62 3
63 3
59 15
27 4
13 4
16 4
8
60 3
61 3
62 3
63 3
59 15
18 4
37 4
46 4
8
60 3
61 3
62 3
63 3
59 15
40 4
41 4
51 4
8
60 3
61 3
62 3
63 3
59 15
40 4
33 4
41 4
8
60 3
61 3
62 3
63 3
59 15
32 4
42 4
47 4
8
60 3
61 3
62 3
63 3
59 15
36 4
42 4
35 4
8
60 3
61 3
62 3
63 3
59 15
34 4
48 4
49 4
7
60 2
61 2
62 2
63 2
59 12
24 4
34 4
7
60 2
61 2
62 2
63 2
59 12
52 4
30 4
7
60 2
61 2
62 2
63 2
59 12
53 4
45 4
7
60 2
61 2
62 2
63 2
59 12
43 4
46 4
8
60 3
61 3
62 3
63 3
59 16
12 4
32 4
31 4
7
60 2
61 2
62 2
63 2
59 12
47 4
55 4
8
60 3
61 3
62 3
63 3
59 16
21 4
33 4
48 4
8
60 3
61 3
62 3
63 3
59 16
39 4
17 4
50 4
8
60 3
61 3
62 3
63 3
59 16
49 4
53 4
14 4
8
60 3
61 3
62 3
63 3
59 16
58 4
50 4
38 4
8
60 3
61 3
62 3
63 3
59 16
39 4
52 4
50 4
8
60 3
61 3
62 3
63 3
59 16
41 4
48 4
56 4
8
60 3
61 3
62 3
63 3
59 16
42 4
47 4
54 4
9
60 4
61 4
62 4
63 4
59 20
35 4
54 4
13 4
44 4
9
60 4
61 4
62 4
63 4
59 20
43 4
57 4
46 4
45 4
9
60 4
61 4
62 4
63 4
59 20
31 4
26 4
55 4
52 4
9
60 4
61 4
62 4
63 4
59 20
51 4
37 4
57 4
46 4
9
60 4
61 4
62 4
63 4
59 20
54 4
58 4
44 4
38 4
9
60 4
61 4
62 4
63 4
59 20
48 4
56 4
49 4
53 4
9
60 4
61 4
62 4
63 4
59 20
41 4
51 4
56 4
57 4
9
60 4
61 4
62 4
63 4
59 20
47 4
55 4
54 4
58 4
9
60 4
61 4
62 4
63 4
59 20
55 4
52 4
58 4
50 4
9
60 4
61 4
62 4
63 4
59 20
56 4
57 4
53 4
45 4
63
60 144
61 144
62 144
63 144
18 16
39 24
43 28
17 16
4 8
5 8
11 12
6 8
0 4
7 8
8 8
20 16
28 20
19 16
1 4
2 4
21 16
36 24
24 16
25 16
15 16
12 12
40 28
32 20
33 20
42 28
34 20
27 16
23 16
31 20
41 24
47 28
48 28
35 20
29 20
22 16
26 16
51 32
55 32
56 32
54 32
49 32
13 12
16 16
9 8
37 24
52 32
57 32
58 32
53 32
44 28
14 12
3 4
30 20
46 28
50 32
45 28
38 24
10 8
60
59 144
18 4
39 6
43 7
17 4
4 2
5 2
11 3
6 2
0 1
7 2
8 2
20 4
28 5
19 4
1 1
2 1
21 4
36 6
24 4
25 4
15 4
12 3
40 7
32 5
33 5
42 7
34 5
27 4
23 4
31 5
41 6
47 7
48 7
35 5
29 5
22 4
26 4
51 8
55 8
56 8
54 8
49 8
13 3
16 4
9 2
37 6
52 8
57 8
58 8
53 8
44 7
14 3
3 1
30 5
46 7
50 8
45 7
38 6
10 2
60
59 144
18 4
39 6
43 7
17 4
4 2
5 2
11 3
6 2
0 1
7 2
8 2
20 4
28 5
19 4
1 1
2 1
21 4
36 6
24 4
25 4
15 4
12 3
40 7
32 5
33 5
42 7
34 5
27 4
23 4
31 5
41 6
47 7
48 7
35 5
29 5
22 4
26 4
51 8
55 8
56 8
54 8
49 8
13 3
16 4
9 2
37 6
52 8
57 8
58 8
53 8
44 7
14 3
3 1
30 5
46 7
50 8
45 7
38 6
10 2
60
59 144
18 4
39 6
43 7
17 4
4 2
5 2
11 3
6 2
0 1
7 2
8 2
20 4
28 5
19 4
1 1
2 1
21 4
36 6
24 4
25 4
15 4
12 3
40 7
32 5
33 5
42 7
34 5
27 4
23 4
31 5
41 6
47 7
48 7
35 5
29 5
22 4
26 4
51 8
55 8
56 8
54 8
49 8
13 3
16 4
9 2
37 6
52 8
57 8
58 8
53 8
44 7
14 3
3 1
30 5
46 7
50 8
45 7
38 6
10 2
60
59 144
18 4
39 6
43 7
17 4
4 2
5 2
11 3
6 2
0 1
7 2
8 2
20 4
28 5
19 4
1 1
2 1
21 4
36 6
24 4
25 4
15 4
12 3
40 7
32 5
33 5
42 7
34 5
27 4
23 4
31 5
41 6
47 7
48 7
35 5
29 5
22 4
26 4
51 8
55 8
56 8
54 8
49 8
13 3
16 4
9 2
37 6
52 8
57 8
58 8
53 8
44 7
14 3
3 1
30 5
46 7
50 8
45 7
38 6
10 2
end_CG
