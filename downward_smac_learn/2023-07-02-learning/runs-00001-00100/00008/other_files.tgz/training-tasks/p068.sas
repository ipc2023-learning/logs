begin_version
3
end_version
begin_metric
0
end_metric
56
begin_variable
var4
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var3
-1
52
Atom at-robot(loc_10_4)
Atom at-robot(loc_10_8)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_10)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_10)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_10)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
0
2
6
282
2
52 21
15 0
21
186
2
52 6
46 0
4
7
294
2
52 22
38 0
13
243
2
52 15
23 0
15
225
2
52 13
45 0
22
195
2
52 7
51 0
4
8
306
2
52 23
39 0
14
252
2
52 16
42 0
16
234
2
52 14
32 0
23
204
2
52 8
49 0
4
9
318
2
52 24
17 0
10
246
2
52 15
18 0
15
213
2
52 10
45 0
24
210
2
52 9
33 0
2
10
324
2
52 25
18 0
25
216
2
52 10
10 0
2
11
330
2
52 26
5 0
26
219
2
52 11
25 0
4
12
339
2
52 27
6 0
18
273
2
52 20
16 0
20
264
2
52 18
29 0
27
222
2
52 12
24 0
2
19
285
2
52 21
27 0
21
270
2
52 19
46 0
4
13
354
2
52 29
23 0
20
297
2
52 22
29 0
22
276
2
52 20
51 0
29
228
2
52 13
47 0
4
14
366
2
52 30
42 0
21
309
2
52 23
46 0
23
288
2
52 21
49 0
30
237
2
52 14
50 0
4
15
378
2
52 31
45 0
22
321
2
52 24
51 0
24
300
2
52 22
33 0
31
249
2
52 15
48 0
4
16
390
2
52 32
32 0
17
312
2
52 23
19 0
23
261
2
52 17
49 0
32
255
2
52 16
20 0
0
2
18
396
2
52 33
16 0
33
267
2
52 18
14 0
2
26
345
2
52 28
25 0
28
333
2
52 26
35 0
4
20
399
2
52 34
29 0
27
357
2
52 29
24 0
29
342
2
52 27
47 0
34
279
2
52 20
31 0
4
21
408
2
52 35
46 0
28
369
2
52 30
35 0
30
348
2
52 28
50 0
35
291
2
52 21
43 0
4
22
417
2
52 36
51 0
29
381
2
52 31
47 0
31
360
2
52 29
48 0
36
303
2
52 22
44 0
4
23
426
2
52 37
49 0
30
393
2
52 32
50 0
32
372
2
52 30
20 0
37
315
2
52 23
30 0
2
25
384
2
52 31
10 0
31
327
2
52 25
48 0
2
26
435
2
52 38
25 0
38
336
2
52 26
11 0
2
28
447
2
52 40
35 0
40
351
2
52 28
36 0
4
29
456
2
52 41
47 0
34
420
2
52 36
31 0
36
402
2
52 34
44 0
41
363
2
52 29
40 0
4
30
465
2
52 42
50 0
35
429
2
52 37
43 0
37
411
2
52 35
30 0
42
375
2
52 30
41 0
2
31
474
2
52 43
48 0
43
387
2
52 31
37 0
0
2
38
450
2
52 40
11 0
40
438
2
52 38
36 0
4
34
492
2
52 47
31 0
39
459
2
52 41
21 0
41
441
2
52 39
40 0
47
405
2
52 34
22 0
4
35
498
2
52 48
43 0
40
468
2
52 42
36 0
42
453
2
52 40
41 0
48
414
2
52 35
26 0
4
36
507
2
52 49
44 0
41
477
2
52 43
40 0
43
462
2
52 41
37 0
49
423
2
52 36
28 0
4
37
516
2
52 50
30 0
42
483
2
52 44
41 0
44
471
2
52 42
7 0
50
432
2
52 37
34 0
0
0
2
0
444
2
52 39
0 0
39
162
2
52 0
21 0
2
46
501
2
52 48
12 0
48
489
2
52 46
26 0
2
47
510
2
52 49
22 0
49
495
2
52 47
28 0
2
48
519
2
52 50
26 0
50
504
2
52 48
34 0
4
1
480
2
52 43
1 0
43
165
2
52 1
37 0
49
525
2
52 51
28 0
51
513
2
52 49
13 0
2
45
522
2
52 50
8 0
50
486
2
52 45
34 0
end_DTG
begin_CG
5
53 1
54 1
55 1
52 4
12 3
5
53 1
54 1
55 1
52 4
34 3
5
53 1
54 1
55 1
52 5
38 3
5
53 1
54 1
55 1
52 5
39 3
5
53 1
54 1
55 1
52 4
15 3
5
53 1
54 1
55 1
52 5
16 3
5
53 1
54 1
55 1
52 5
27 3
5
53 1
54 1
55 1
52 5
37 3
5
53 1
54 1
55 1
52 4
13 3
6
53 2
54 2
55 2
52 8
17 3
18 3
6
53 2
54 2
55 2
52 8
19 3
20 3
6
53 2
54 2
55 2
52 8
14 3
21 3
5
53 1
54 1
55 1
52 6
22 3
5
53 1
54 1
55 1
52 6
34 3
5
53 1
54 1
55 1
52 5
25 3
6
53 2
54 2
55 2
52 9
38 3
23 3
6
53 2
54 2
55 2
52 9
27 3
25 3
6
53 2
54 2
55 2
52 9
39 3
32 3
6
53 2
54 2
55 2
52 9
32 3
19 3
6
53 2
54 2
55 2
52 9
18 3
33 3
6
53 2
54 2
55 2
52 9
33 3
48 3
6
53 2
54 2
55 2
52 9
36 3
12 3
6
53 2
54 2
55 2
52 9
36 3
26 3
6
53 2
54 2
55 2
52 9
42 3
46 3
6
53 2
54 2
55 2
52 9
27 3
35 3
7
53 3
54 3
55 3
52 12
16 3
24 3
14 3
7
53 3
54 3
55 3
52 12
40 3
22 3
28 3
5
53 1
54 1
55 1
52 7
29 3
7
53 3
54 3
55 3
52 12
41 3
26 3
34 3
7
53 3
54 3
55 3
52 12
27 3
46 3
35 3
7
53 3
54 3
55 3
52 12
48 3
44 3
37 3
7
53 3
54 3
55 3
52 12
35 3
43 3
36 3
6
53 2
54 2
55 2
52 10
45 3
33 3
6
53 2
54 2
55 2
52 10
32 3
49 3
7
53 3
54 3
55 3
52 13
37 3
28 3
13 3
7
53 3
54 3
55 3
52 13
24 3
47 3
31 3
7
53 3
54 3
55 3
52 13
31 3
21 3
40 3
7
53 3
54 3
55 3
52 13
30 3
41 3
34 3
7
53 3
54 3
55 3
52 13
15 3
39 3
42 3
7
53 3
54 3
55 3
52 13
38 3
17 3
45 3
7
53 3
54 3
55 3
52 13
43 3
36 3
41 3
7
53 3
54 3
55 3
52 13
44 3
40 3
37 3
7
53 3
54 3
55 3
52 13
38 3
45 3
51 3
7
53 3
54 3
55 3
52 13
47 3
44 3
40 3
7
53 3
54 3
55 3
52 13
50 3
43 3
41 3
8
53 4
54 4
55 4
52 16
39 3
42 3
32 3
49 3
8
53 4
54 4
55 4
52 16
23 3
29 3
51 3
47 3
8
53 4
54 4
55 4
52 16
46 3
35 3
50 3
43 3
8
53 4
54 4
55 4
52 16
49 3
50 3
20 3
30 3
8
53 4
54 4
55 4
52 16
45 3
51 3
33 3
48 3
8
53 4
54 4
55 4
52 16
51 3
47 3
48 3
44 3
8
53 4
54 4
55 4
52 16
42 3
46 3
49 3
50 3
55
53 122
54 122
55 122
0 3
1 3
2 3
3 3
9 6
4 3
15 12
38 21
39 21
17 12
18 12
5 3
6 3
23 12
42 21
45 24
32 18
19 12
16 12
27 15
29 15
46 24
51 24
49 24
33 18
10 6
25 15
24 12
35 21
47 24
50 24
48 24
20 12
14 9
31 15
43 21
44 21
30 15
11 6
21 12
36 21
40 21
41 21
37 21
7 3
8 3
12 9
22 12
26 15
28 15
34 21
13 9
53
52 122
0 1
1 1
2 1
3 1
9 2
4 1
15 4
38 7
39 7
17 4
18 4
5 1
6 1
23 4
42 7
45 8
32 6
19 4
16 4
27 5
29 5
46 8
51 8
49 8
33 6
10 2
25 5
24 4
35 7
47 8
50 8
48 8
20 4
14 3
31 5
43 7
44 7
30 5
11 2
21 4
36 7
40 7
41 7
37 7
7 1
8 1
12 3
22 4
26 5
28 5
34 7
13 3
53
52 122
0 1
1 1
2 1
3 1
9 2
4 1
15 4
38 7
39 7
17 4
18 4
5 1
6 1
23 4
42 7
45 8
32 6
19 4
16 4
27 5
29 5
46 8
51 8
49 8
33 6
10 2
25 5
24 4
35 7
47 8
50 8
48 8
20 4
14 3
31 5
43 7
44 7
30 5
11 2
21 4
36 7
40 7
41 7
37 7
7 1
8 1
12 3
22 4
26 5
28 5
34 7
13 3
53
52 122
0 1
1 1
2 1
3 1
9 2
4 1
15 4
38 7
39 7
17 4
18 4
5 1
6 1
23 4
42 7
45 8
32 6
19 4
16 4
27 5
29 5
46 8
51 8
49 8
33 6
10 2
25 5
24 4
35 7
47 8
50 8
48 8
20 4
14 3
31 5
43 7
44 7
30 5
11 2
21 4
36 7
40 7
41 7
37 7
7 1
8 1
12 3
22 4
26 5
28 5
34 7
13 3
end_CG
