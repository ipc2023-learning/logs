begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var2
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
22
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
end_variable
begin_variable
var0
-1
22
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
end_variable
22
begin_mutex_group
2
23 0
0 0
end_mutex_group
begin_mutex_group
2
23 1
1 0
end_mutex_group
begin_mutex_group
2
23 2
2 0
end_mutex_group
begin_mutex_group
2
23 3
3 0
end_mutex_group
begin_mutex_group
2
23 4
6 0
end_mutex_group
begin_mutex_group
2
23 5
7 0
end_mutex_group
begin_mutex_group
2
23 6
8 0
end_mutex_group
begin_mutex_group
2
23 7
9 0
end_mutex_group
begin_mutex_group
2
23 8
11 0
end_mutex_group
begin_mutex_group
2
23 9
17 0
end_mutex_group
begin_mutex_group
2
23 10
18 0
end_mutex_group
begin_mutex_group
2
23 11
14 0
end_mutex_group
begin_mutex_group
2
23 12
10 0
end_mutex_group
begin_mutex_group
2
23 13
20 0
end_mutex_group
begin_mutex_group
2
23 14
19 0
end_mutex_group
begin_mutex_group
2
23 15
21 0
end_mutex_group
begin_mutex_group
2
23 16
13 0
end_mutex_group
begin_mutex_group
2
23 17
4 0
end_mutex_group
begin_mutex_group
2
23 18
12 0
end_mutex_group
begin_mutex_group
2
23 19
16 0
end_mutex_group
begin_mutex_group
2
23 20
15 0
end_mutex_group
begin_mutex_group
2
23 21
5 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
11
10
end_state
begin_goal
1
23 8
end_goal
98
begin_operator
move loc_2_2 loc_2_3 right
1
1 0
1
0 22 0 1
0
end_operator
begin_operator
move loc_2_2 loc_3_2 down
1
6 0
1
0 22 0 4
0
end_operator
begin_operator
move loc_2_3 loc_2_2 left
1
0 0
1
0 22 1 0
0
end_operator
begin_operator
move loc_2_3 loc_3_3 down
1
7 0
1
0 22 1 5
0
end_operator
begin_operator
move loc_2_5 loc_2_6 right
1
3 0
1
0 22 2 3
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
8 0
1
0 22 2 6
0
end_operator
begin_operator
move loc_2_6 loc_2_5 left
1
2 0
1
0 22 3 2
0
end_operator
begin_operator
move loc_2_6 loc_3_6 down
1
9 0
1
0 22 3 7
0
end_operator
begin_operator
move loc_3_2 loc_2_2 up
1
0 0
1
0 22 4 0
0
end_operator
begin_operator
move loc_3_2 loc_3_3 right
1
7 0
1
0 22 4 5
0
end_operator
begin_operator
move loc_3_2 loc_4_2 down
1
11 0
1
0 22 4 8
0
end_operator
begin_operator
move loc_3_3 loc_2_3 up
1
1 0
1
0 22 5 1
0
end_operator
begin_operator
move loc_3_3 loc_3_2 left
1
6 0
1
0 22 5 4
0
end_operator
begin_operator
move l




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




k 1
54
check 0
switch 12
check 0
check 1
55
check 0
switch 15
check 0
check 1
56
check 0
check 0
switch 21
check 0
check 1
57
check 0
switch 16
check 0
check 1
58
check 0
switch 5
check 0
check 1
59
check 0
check 0
switch 13
check 0
check 1
60
check 0
switch 15
check 0
check 1
61
check 0
check 0
check 0
end_SG
begin_DTG
1
1
70
2
23 4
22 8
0
end_DTG
begin_DTG
1
1
72
2
23 5
22 9
0
end_DTG
begin_DTG
1
1
74
2
23 6
22 10
0
end_DTG
begin_DTG
1
1
76
2
23 7
22 11
0
end_DTG
begin_DTG
2
1
71
2
23 12
22 8
1
92
2
23 18
22 19
0
end_DTG
begin_DTG
2
1
77
2
23 16
22 11
1
93
2
23 20
22 19
0
end_DTG
begin_DTG
1
1
78
2
23 8
22 12
2
0
62
3
23 4
22 0
11 0
0
70
3
23 4
22 8
0 0
end_DTG
begin_DTG
1
1
80
2
23 9
22 13
2
0
63
3
23 5
22 1
17 0
0
72
3
23 5
22 9
1 0
end_DTG
begin_DTG
1
1
84
2
23 10
22 15
2
0
64
3
23 6
22 2
18 0
0
74
3
23 6
22 10
2 0
end_DTG
begin_DTG
1
1
86
2
23 11
22 16
2
0
65
3
23 7
22 3
14 0
0
76
3
23 7
22 11
3 0
end_DTG
begin_DTG
2
1
66
2
23 8
22 4
1
82
2
23 13
22 14
2
0
71
3
23 12
22 8
4 0
0
88
3
23 12
22 17
11 0
end_DTG
begin_DTG
2
1
62
2
23 4
22 0
1
88
2
23 12
22 17
2
0
66
3
23 8
22 4
10 0
0
78
3
23 8
22 12
6 0
end_DTG
begin_DTG
2
1
73
2
23 13
22 9
1
95
2
23 19
22 20
2
0
89
3
23 18
22 17
16 0
0
92
3
23 18
22 19
4 0
end_DTG
begin_DTG
2
1
69
2
23 11
22 7
1
83
2
23 15
22 14
2
0
77
3
23 16
22 11
5 0
0
96
3
23 16
22 21
14 0
end_DTG
begin_DTG
2
1
65
2
23 7
22 3
1
96
2
23 16
22 21
2
0
69
3
23 11
22 7
13 0
0
86
3
23 11
22 16
9 0
end_DTG
begin_DTG
2
1
75
2
23 15
22 10
1
91
2
23 19
22 18
2
0
93
3
23 20
22 19
5 0
0
97
3
23 20
22 21
16 0
end_DTG
begin_DTG
2
1
89
2
23 18
22 17
1
97
2
23 20
22 21
2
0
91
3
23 19
22 18
15 0
0
95
3
23 19
22 20
12 0
end_DTG
begin_DTG
2
1
63
2
23 5
22 1
1
90
2
23 13
22 18
2
0
67
3
23 9
22 5
20 0
0
80
3
23 9
22 13
7 0
end_DTG
begin_DTG
2
1
64
2
23 6
22 2
1
94
2
23 15
22 20
2
0
68
3
23 10
22 6
21 0
0
84
3
23 10
22 15
8 0
end_DTG
begin_DTG
2
1
79
2
23 13
22 12
1
87
2
23 15
22 16
2
0
81
3
23 14
22 13
21 0
0
85
3
23 14
22 15
20 0
end_DTG
begin_DTG
2
1
67
2
23 9
22 5
1
85
2
23 14
22 15
4
0
73
3
23 13
22 9
12 0
0
79
3
23 13
22 12
19 0
0
82
3
23 13
22 14
10 0
0
90
3
23 13
22 18
17 0
end_DTG
begin_DTG
2
1
68
2
23 10
22 6
1
81
2
23 14
22 13
4
0
75
3
23 15
22 10
15 0
0
83
3
23 15
22 14
13 0
0
87
3
23 15
22 16
19 0
0
94
3
23 15
22 20
18 0
end_DTG
begin_DTG
3
1
0
1
1 0
4
1
1
6 0
4
62
2
23 4
11 0
3
0
2
1
0 0
5
3
1
7 0
5
63
2
23 5
17 0
3
3
4
1
3 0
6
5
1
8 0
6
64
2
23 6
18 0
3
2
6
1
2 0
7
7
1
9 0
7
65
2
23 7
14 0
4
0
8
1
0 0
5
9
1
7 0
8
10
1
11 0
8
66
2
23 8
10 0
4
1
11
1
1 0
4
12
1
6 0
9
13
1
17 0
9
67
2
23 9
20 0
4
2
14
1
2 0
7
15
1
9 0
10
16
1
18 0
10
68
2
23 10
21 0
4
3
17
1
3 0
6
18
1
8 0
11
19
1
14 0
11
69
2
23 11
13 0
5
4
20
1
6 0
4
70
2
23 4
0 0
9
21
1
17 0
12
22
1
10 0
12
71
2
23 12
4 0
5
5
23
1
7 0
5
72
2
23 5
1 0
8
24
1
11 0
13
25
1
20 0
13
73
2
23 13
12 0
5
6
26
1
8 0
6
74
2
23 6
2 0
11
27
1
14 0
15
28
1
21 0
15
75
2
23 15
15 0
5
7
29
1
9 0
7
76
2
23 7
3 0
10
30
1
18 0
16
31
1
13 0
16
77
2
23 16
5 0
5
8
32
1
11 0
8
78
2
23 8
6 0
13
33
1
20 0
13
79
2
23 13
19 0
17
34
1
4 0
6
9
35
1
17 0
9
80
2
23 9
7 0
12
36
1
10 0
14
37
1
19 0
14
81
2
23 14
21 0
18
38
1
12 0
5
13
39
1
20 0
13
82
2
23 13
10 0
15
40
1
21 0
15
83
2
23 15
13 0
19
41
1
16 0
6
10
42
1
18 0
10
84
2
23 10
8 0
14
43
1
19 0
14
85
2
23 14
20 0
16
44
1
13 0
20
45
1
15 0
5
11
46
1
14 0
11
86
2
23 11
9 0
15
47
1
21 0
15
87
2
23 15
19 0
21
48
1
5 0
4
12
49
1
10 0
12
88
2
23 12
11 0
18
50
1
12 0
18
89
2
23 18
16 0
5
13
51
1
20 0
13
90
2
23 13
17 0
17
52
1
4 0
19
53
1
16 0
19
91
2
23 19
15 0
5
14
54
1
19 0
18
55
1
12 0
18
92
2
23 18
4 0
20
56
1
15 0
20
93
2
23 20
5 0
5
15
57
1
21 0
15
94
2
23 15
18 0
19
58
1
16 0
19
95
2
23 19
12 0
21
59
1
5 0
4
16
60
1
13 0
16
96
2
23 16
14 0
20
61
1
15 0
20
97
2
23 20
16 0
end_DTG
begin_DTG
0
0
0
0
2
0
70
2
22 8
0 0
8
62
2
22 0
11 0
2
1
72
2
22 9
1 0
9
63
2
22 1
17 0
2
2
74
2
22 10
2 0
10
64
2
22 2
18 0
2
3
76
2
22 11
3 0
11
65
2
22 3
14 0
2
4
78
2
22 12
6 0
12
66
2
22 4
10 0
2
5
80
2
22 13
7 0
13
67
2
22 5
20 0
2
6
84
2
22 15
8 0
15
68
2
22 6
21 0
2
7
86
2
22 16
9 0
16
69
2
22 7
13 0
2
8
88
2
22 17
11 0
17
71
2
22 8
4 0
4
9
90
2
22 18
17 0
12
82
2
22 14
10 0
14
79
2
22 12
19 0
18
73
2
22 9
12 0
2
13
85
2
22 15
20 0
15
81
2
22 13
21 0
4
10
94
2
22 20
18 0
14
87
2
22 16
19 0
16
83
2
22 14
13 0
20
75
2
22 10
15 0
2
11
96
2
22 21
14 0
21
77
2
22 11
5 0
0
2
17
92
2
22 19
4 0
19
89
2
22 17
16 0
2
18
95
2
22 20
12 0
20
91
2
22 18
15 0
2
19
97
2
22 21
16 0
21
93
2
22 19
5 0
0
end_DTG
begin_CG
3
23 1
22 3
6 1
3
23 1
22 3
7 1
3
23 1
22 3
8 1
3
23 1
22 3
9 1
4
23 2
22 4
10 1
12 1
4
23 2
22 4
13 1
15 1
3
23 1
22 4
11 1
3
23 1
22 4
17 1
3
23 1
22 4
18 1
3
23 1
22 4
14 1
4
23 2
22 5
11 1
20 1
4
23 2
22 5
6 1
10 1
4
23 2
22 5
20 1
16 1
4
23 2
22 5
14 1
21 1
4
23 2
22 5
9 1
13 1
4
23 2
22 5
21 1
16 1
4
23 2
22 5
12 1
15 1
4
23 2
22 5
7 1
20 1
4
23 2
22 5
8 1
21 1
4
23 2
22 5
20 1
21 1
4
23 2
22 6
17 1
19 1
4
23 2
22 6
18 1
19 1
23
23 36
0 1
1 1
2 1
3 1
6 3
7 3
8 3
9 3
11 4
17 4
18 4
14 4
10 4
20 6
19 4
21 6
13 4
4 2
12 4
16 4
15 4
5 2
23
22 36
0 1
1 1
2 1
3 1
6 3
7 3
8 3
9 3
11 4
17 4
18 4
14 4
10 4
20 6
19 4
21 6
13 4
4 2
12 4
16 4
15 4
5 2
end_CG
