begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var4
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_9_2)
NegatedAtom clear(loc_9_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var3
-1
49
Atom at-robot(loc_10_2)
Atom at-robot(loc_10_3)
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_10)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
48 48
30 0
38
397
2
48 41
43 0
40
385
2
48 39
12 0
47
340
2
48 33
11 0
2
33
394
2
48 40
8 0
39
343
2
48 34
41 0
0
4
0
349
2
48 35
0 0
34
145
2
48 1
19 0
41
409
2
48 44
9 0
43
400
2
48 42
26 0
2
42
418
2
48 45
34 0
44
406
2
48 43
45 0
4
1
364
2
48 37
1 0
36
148
2
48 2
47 0
43
427
2
48 46
26 0
45
412
2
48 44
44 0
4
2
376
2
48 38
2 0
37
151
2
48 3
46 0
44
436
2
48 47
45 0
46
421
2
48 45
21 0
2
45
442
2
48 48
44 0
47
430
2
48 46
11 0
0
end_DTG
begin_DTG
0
0
0
0
0
2
3
191
2
48 11
3 0
10
155
2
48 4
27 0
4
4
200
2
48 12
4 0
5
173
2
48 8
16 0
7
161
2
48 6
29 0
11
158
2
48 5
36 0
2
6
182
2
48 9
35 0
8
167
2
48 7
17 0
2
7
188
2
48 10
29 0
9
176
2
48 8
5 0
0
2
5
239
2
48 18
16 0
17
164
2
48 6
18 0
4
6
245
2
48 19
35 0
10
206
2
48 13
27 0
12
194
2
48 11
37 0
18
170
2
48 7
22 0
4
7
251
2
48 20
29 0
11
212
2
48 14
36 0
13
203
2
48 12
39 0
19
179
2
48 8
24 0
4
8
257
2
48 21
17 0
12
221
2
48 15
37 0
14
209
2
48 13
23 0
20
185
2
48 9
33 0
2
13
227
2
48 16
39 0
15
215
2
48 14
20 0
2
14
233
2
48 17
23 0
16
224
2
48 15
10 0
0
2
10
272
2
48 24
27 0
23
197
2
48 11
6 0
2
17
254
2
48 20
18 0
19
242
2
48 18
24 0
2
18
260
2
48 21
22 0
20
248
2
48 19
33 0
2
13
275
2
48 25
39 0
24
218
2
48 14
32 0
2
15
290
2
48 27
20 0
26
230
2
48 16
40 0
2
16
299
2
48 28
10 0
27
236
2
48 17
28 0
0
2
20
311
2
48 30
33 0
29
263
2
48 21
31 0
2
24
293
2
48 27
32 0
26
278
2
48 25
40 0
4
21
326
2
48 32
14 0
25
302
2
48 28
25 0
27
284
2
48 26
28 0
31
266
2
48 22
42 0
2
22
335
2
48 33
13 0
32
269
2
48 23
30 0
0
2
24
356
2
48 37
32 0
36
281
2
48 25
47 0
4
25
368
2
48 38
25 0
29
329
2
48 32
31 0
31
314
2
48 30
42 0
37
287
2
48 26
46 0
4
26
380
2
48 39
40 0
30
338
2
48 33
38 0
32
320
2
48 31
30 0
38
296
2
48 27
43 0
2
27
389
2
48 40
28 0
39
305
2
48 28
41 0
0
2
28
404
2
48 43
7 0
42
308
2
48 29
34 0
2
34
359
2
48 37
19 0
36
347
2
48 35
47 0
4
29
416
2
48 45
31 0
35
371
2
48 38
15 0
37
353
2
48 36
46 0
44
317
2
48 30
45 0
4
30
425
2
48 46
38 0
36
383
2
48 39
47 0
38
362
2
48 37
43 0
45
323
2
48 31
44 0
4
31
434
2
48 47
42 0
37
392
2
48 40
46 0
39
374
2
48 38
41 0
46
332
2
48 32
21 0
4
32
440
2
48 48
30 0
38
398
2
48 41
43 0
40
386
2
48 39
12 0
47
341
2
48 33
11 0
2
33
395
2
48 40
8 0
39
344
2
48 34
41 0
0
4
0
350
2
48 35
0 0
34
146
2
48 1
19 0
41
410
2
48 44
9 0
43
401
2
48 42
26 0
2
42
419
2
48 45
34 0
44
407
2
48 43
45 0
4
1
365
2
48 37
1 0
36
149
2
48 2
47 0
43
428
2
48 46
26 0
45
413
2
48 44
44 0
4
2
377
2
48 38
2 0
37
152
2
48 3
46 0
44
437
2
48 47
45 0
46
422
2
48 45
21 0
2
45
443
2
48 48
44 0
47
431
2
48 46
11 0
0
end_DTG
begin_CG
5
49 1
50 1
51 1
48 5
34 3
5
49 1
50 1
51 1
48 5
45 3
5
49 1
50 1
51 1
48 5
44 3
5
49 1
50 1
51 1
48 5
16 3
5
49 1
50 1
51 1
48 5
35 3
5
49 1
50 1
51 1
48 5
17 3
5
49 1
50 1
51 1
48 4
18 3
5
49 1
50 1
51 1
48 4
19 3
5
49 1
50 1
51 1
48 4
12 3
5
49 1
50 1
51 1
48 5
34 3
6
49 2
50 2
51 2
48 8
20 3
13 3
6
49 2
50 2
51 2
48 8
41 3
21 3
5
49 1
50 1
51 1
48 5
41 3
5
49 1
50 1
51 1
48 6
28 3
5
49 1
50 1
51 1
48 6
40 3
5
49 1
50 1
51 1
48 6
47 3
6
49 2
50 2
51 2
48 9
35 3
27 3
6
49 2
50 2
51 2
48 9
29 3
39 3
6
49 2
50 2
51 2
48 9
27 3
22 3
6
49 2
50 2
51 2
48 9
15 3
34 3
6
49 2
50 2
51 2
48 9
23 3
14 3
6
49 2
50 2
51 2
48 9
43 3
44 3
6
49 2
50 2
51 2
48 9
36 3
24 3
6
49 2
50 2
51 2
48 9
39 3
20 3
6
49 2
50 2
51 2
48 9
37 3
22 3
6
49 2
50 2
51 2
48 9
40 3
38 3
6
49 2
50 2
51 2
48 9
34 3
45 3
7
49 3
50 3
51 3
48 12
16 3
36 3
18 3
7
49 3
50 3
51 3
48 12
13 3
40 3
30 3
7
49 3
50 3
51 3
48 12
35 3
17 3
37 3
7
49 3
50 3
51 3
48 12
28 3
42 3
41 3
7
49 3
50 3
51 3
48 12
32 3
38 3
47 3
7
49 3
50 3
51 3
48 12
33 3
25 3
31 3
7
49 3
50 3
51 3
48 12
39 3
24 3
32 3
6
49 2
50 2
51 2
48 10
19 3
26 3
6
49 2
50 2
51 2
48 10
29 3
36 3
6
49 2
50 2
51 2
48 10
35 3
37 3
6
49 2
50 2
51 2
48 10
36 3
39 3
6
49 2
50 2
51 2
48 10
42 3
46 3
7
49 3
50 3
51 3
48 13
37 3
23 3
33 3
7
49 3
50 3
51 3
48 13
14 3
25 3
42 3
7
49 3
50 3
51 3
48 13
30 3
43 3
12 3
7
49 3
50 3
51 3
48 13
40 3
38 3
43 3
7
49 3
50 3
51 3
48 13
42 3
46 3
41 3
7
49 3
50 3
51 3
48 13
46 3
45 3
21 3
7
49 3
50 3
51 3
48 13
47 3
26 3
44 3
8
49 4
50 4
51 4
48 16
38 3
47 3
43 3
44 3
8
49 4
50 4
51 4
48 16
31 3
15 3
46 3
45 3
51
49 100
50 100
51 100
0 3
1 3
2 3
3 3
4 3
16 12
35 18
29 15
17 12
5 3
27 15
36 18
37 18
39 21
23 12
20 12
10 6
18 12
22 12
24 12
33 15
14 9
13 9
6 3
32 15
25 12
40 21
28 15
7 3
31 15
38 18
42 21
30 15
8 3
19 12
15 9
47 24
46 24
43 21
41 21
12 9
9 3
34 18
26 12
45 21
44 21
21 12
11 6
49
48 100
0 1
1 1
2 1
3 1
4 1
16 4
35 6
29 5
17 4
5 1
27 5
36 6
37 6
39 7
23 4
20 4
10 2
18 4
22 4
24 4
33 5
14 3
13 3
6 1
32 5
25 4
40 7
28 5
7 1
31 5
38 6
42 7
30 5
8 1
19 4
15 3
47 8
46 8
43 7
41 7
12 3
9 1
34 6
26 4
45 7
44 7
21 4
11 2
49
48 100
0 1
1 1
2 1
3 1
4 1
16 4
35 6
29 5
17 4
5 1
27 5
36 6
37 6
39 7
23 4
20 4
10 2
18 4
22 4
24 4
33 5
14 3
13 3
6 1
32 5
25 4
40 7
28 5
7 1
31 5
38 6
42 7
30 5
8 1
19 4
15 3
47 8
46 8
43 7
41 7
12 3
9 1
34 6
26 4
45 7
44 7
21 4
11 2
49
48 100
0 1
1 1
2 1
3 1
4 1
16 4
35 6
29 5
17 4
5 1
27 5
36 6
37 6
39 7
23 4
20 4
10 2
18 4
22 4
24 4
33 5
14 3
13 3
6 1
32 5
25 4
40 7
28 5
7 1
31 5
38 6
42 7
30 5
8 1
19 4
15 3
47 8
46 8
43 7
41 7
12 3
9 1
34 6
26 4
45 7
44 7
21 4
11 2
end_CG
