begin_version
3
end_version
begin_metric
0
end_metric
33
begin_variable
var4
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var2
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var1
-1
31
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
end_variable
begin_variable
var0
-1
31
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
end_variable
31
begin_mutex_group
2
32 0
4 0
end_mutex_group
begin_mutex_group
2
32 1
8 0
end_mutex_group
begin_mutex_group
2
32 2
0 0
end_mutex_group
begin_mutex_group
2
32 3
1 0
end_mutex_group
begin_mutex_group
2
32 4
9 0
end_mutex_group
begin_mutex_group
2
32 5
22 0
end_mutex_group
begin_mutex_group
2
32 6
14 0
end_mutex_group
begin_mutex_group
2
32 7
20 0
end_mutex_group
begin_mutex_group
2
32 8
23 0
end_mutex_group
begin_mutex_group
2
32 9
5 0
end_mutex_group
begin_mutex_group
2
32 10
2 0
end_mutex_group
begin_mutex_group
2
32 11
17 0
end_mutex_group
begin_mutex_group
2
32 12
15 0
end_mutex_group
begin_mutex_group
2
32 13
25 0
end_mutex_group
begin_mutex_group
2
32 14
10 0
end_mutex_group
begin_mutex_group
2
32 15
21 0
end_mutex_group
begin_mutex_group
2
32 16
16 0
end_mutex_group
begin_mutex_group
2
32 17
30 0
end_mutex_group
begin_mutex_group
2
32 18
28 0
end_mutex_group
begin_mutex_group
2
32




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7
31 12
1
135
2
32 22
31 21
1
144
2
32 24
31 25
4
0
126
3
32 23
31 17
19 0
0
137
3
32 23
31 22
27 0
0
142
3
32 23
31 24
26 0
0
149
3
32 23
31 28
30 0
end_DTG
begin_DTG
4
1
104
2
32 12
31 7
1
119
2
32 16
31 15
1
131
2
32 18
31 19
1
149
2
32 23
31 28
4
0
113
3
32 17
31 12
29 0
0
121
3
32 17
31 16
28 0
0
128
3
32 17
31 18
16 0
0
138
3
32 17
31 23
15 0
end_DTG
begin_DTG
4
1
0
1
8 0
1
92
2
32 1
0 0
4
1
1
9 0
4
93
2
32 4
2 0
4
0
2
1
4 0
2
3
1
0 0
5
4
1
22 0
5
94
2
32 5
17 0
3
1
5
1
8 0
1
95
2
32 1
4 0
6
6
1
14 0
2
8
7
1
23 0
8
96
2
32 8
25 0
4
0
8
1
4 0
5
9
1
22 0
5
97
2
32 5
14 0
10
10
1
2 0
6
1
11
1
8 0
4
12
1
9 0
6
13
1
14 0
6
98
2
32 6
20 0
11
14
1
17 0
11
99
2
32 11
21 0
5
2
15
1
0 0
5
16
1
22 0
5
100
2
32 5
9 0
7
17
1
20 0
7
101
2
32 7
23 0
6
6
18
1
14 0
6
102
2
32 6
22 0
8
19
1
23 0
8
103
2
32 8
5 0
12
20
1
15 0
12
104
2
32 12
30 0
6
3
21
1
1 0
7
22
1
20 0
7
105
2
32 7
14 0
9
23
1
5 0
13
24
1
25 0
13
106
2
32 13
28 0
4
8
25
1
23 0
8
107
2
32 8
20 0
14
26
1
10 0
14
108
2
32 14
18 0
3
4
27
1
9 0
4
109
2
32 4
4 0
11
28
1
17 0
5
5
29
1
22 0
5
110
2
32 5
8 0
10
30
1
2 0
15
31
1
21 0
15
111
2
32 15
24 0
5
7
32
1
20 0
13
33
1
25 0
13
112
2
32 13
10 0
17
34
1
30 0
17
113
2
32 17
29 0
6
8
35
1
23 0
8
114
2
32 8
1 0
12
36
1
15 0
14
37
1
10 0
18
38
1
28 0
18
115
2
32 18
27 0
5
9
39
1
5 0
13
40
1
25 0
13
116
2
32 13
15 0
19
41
1
18 0
19
117
2
32 19
12 0
6
11
42
1
17 0
11
118
2
32 11
22 0
16
43
1
16 0
16
119
2
32 16
30 0
21
44
1
24 0
21
120
2
32 21
6 0
5
15
45
1
21 0
17
46
1
30 0
17
121
2
32 17
28 0
22
47
1
26 0
22
122
2
32 22
11 0
8
12
48
1
15 0
12
123
2
32 12
20 0
16
49
1
16 0
16
124
2
32 16
21 0
18
50
1
28 0
18
125
2
32 18
18 0
23
51
1
29 0
23
126
2
32 23
19 0
7
13
52
1
25 0
13
127
2
32 13
23 0
17
53
1
30 0
17
128
2
32 17
16 0
19
54
1
18 0
24
55
1
27 0
24
129
2
32 24
13 0
6
14
56
1
10 0
14
130
2
32 14
5 0
18
57
1
28 0
18
131
2
32 18
30 0
25
58
1
12 0
25
132
2
32 25
7 0
2
21
59
1
24 0
21
133
2
32 21
26 0
6
15
60
1
21 0
15
134
2
32 15
17 0
20
61
1
3 0
22
62
1
26 0
22
135
2
32 22
29 0
26
63
1
6 0
6
16
64
1
16 0
21
65
1
24 0
21
136
2
32 21
3 0
23
66
1
29 0
23
137
2
32 23
27 0
27
67
1
11 0
7
17
68
1
30 0
17
138
2
32 17
15 0
22
69
1
26 0
22
139
2
32 22
24 0
24
70
1
27 0
24
140
2
32 24
12 0
28
71
1
19 0
6
18
72
1
28 0
18
141
2
32 18
25 0
23
73
1
29 0
23
142
2
32 23
26 0
25
74
1
12 0
29
75
1
13 0
5
19
76
1
18 0
19
143
2
32 19
10 0
24
77
1
27 0
24
144
2
32 24
29 0
30
78
1
7 0
4
21
79
1
24 0
21
145
2
32 21
21 0
27
80
1
11 0
27
146
2
32 27
19 0
5
22
81
1
26 0
22
147
2
32 22
16 0
26
82
1
6 0
28
83
1
19 0
28
148
2
32 28
13 0
6
23
84
1
29 0
23
149
2
32 23
30 0
27
85
1
11 0
27
150
2
32 27
6 0
29
86
1
13 0
29
151
2
32 29
7 0
5
24
87
1
27 0
24
152
2
32 24
28 0
28
88
1
19 0
28
153
2
32 28
11 0
30
89
1
7 0
4
25
90
1
12 0
25
154
2
32 25
18 0
29
91
1
13 0
29
155
2
32 29
19 0
end_DTG
begin_DTG
0
2
0
95
2
31 2
4 0
2
92
2
31 0
0 0
0
0
2
0
109
2
31 10
4 0
10
93
2
31 0
2 0
4
1
110
2
31 11
8 0
4
100
2
31 6
9 0
6
97
2
31 4
14 0
11
94
2
31 1
17 0
2
5
102
2
31 7
22 0
7
98
2
31 5
20 0
2
6
105
2
31 8
14 0
8
101
2
31 6
23 0
4
3
114
2
31 13
1 0
7
107
2
31 9
20 0
9
103
2
31 7
5 0
13
96
2
31 3
25 0
0
0
2
5
118
2
31 15
22 0
15
99
2
31 5
21 0
2
7
123
2
31 17
20 0
17
104
2
31 7
30 0
4
8
127
2
31 18
23 0
12
116
2
31 14
15 0
14
112
2
31 12
10 0
18
106
2
31 8
28 0
2
9
130
2
31 19
5 0
19
108
2
31 9
18 0
2
11
134
2
31 21
17 0
21
111
2
31 11
24 0
2
15
124
2
31 17
21 0
17
119
2
31 15
30 0
4
12
138
2
31 23
15 0
16
128
2
31 18
16 0
18
121
2
31 16
28 0
23
113
2
31 12
29 0
4
13
141
2
31 24
25 0
17
131
2
31 19
30 0
19
125
2
31 17
18 0
24
115
2
31 13
27 0
2
14
143
2
31 25
10 0
25
117
2
31 14
12 0
0
4
15
145
2
31 26
21 0
20
136
2
31 22
3 0
22
133
2
31 20
26 0
26
120
2
31 15
6 0
4
16
147
2
31 27
16 0
21
139
2
31 23
24 0
23
135
2
31 21
29 0
27
122
2
31 16
11 0
4
17
149
2
31 28
30 0
22
142
2
31 24
26 0
24
137
2
31 22
27 0
28
126
2
31 17
19 0
4
18
152
2
31 29
28 0
23
144
2
31 25
29 0
25
140
2
31 23
12 0
29
129
2
31 18
13 0
2
19
154
2
31 30
18 0
30
132
2
31 19
7 0
0
2
26
150
2
31 28
6 0
28
146
2
31 26
19 0
2
27
153
2
31 29
11 0
29
148
2
31 27
13 0
2
28
155
2
31 30
19 0
30
151
2
31 28
7 0
0
end_DTG
begin_CG
3
32 1
31 3
8 1
3
32 1
31 2
23 1
3
32 1
31 3
9 1
3
32 1
31 2
24 1
4
32 2
31 4
8 1
9 1
4
32 2
31 4
23 1
10 1
4
32 2
31 4
24 1
11 1
4
32 2
31 4
12 1
13 1
3
32 1
31 4
22 1
3
32 1
31 4
22 1
4
32 2
31 5
25 1
18 1
4
32 2
31 5
26 1
19 1
4
32 2
31 5
18 1
27 1
4
32 2
31 5
27 1
19 1
4
32 2
31 5
22 1
20 1
4
32 2
31 5
25 1
30 1
4
32 2
31 5
30 1
26 1
4
32 2
31 5
22 1
21 1
5
32 3
31 6
10 1
28 1
12 1
5
32 3
31 6
29 1
11 1
13 1
5
32 3
31 6
14 1
23 1
15 1
5
32 3
31 6
17 1
16 1
24 1
4
32 2
31 6
14 1
17 1
4
32 2
31 6
20 1
25 1
4
32 2
31 6
21 1
26 1
4
32 2
31 6
23 1
28 1
4
32 2
31 6
24 1
29 1
4
32 2
31 6
28 1
29 1
5
32 3
31 7
25 1
30 1
27 1
5
32 3
31 7
30 1
26 1
27 1
6
32 4
31 8
15 1
16 1
28 1
29 1
32
32 64
4 2
8 3
0 1
1 1
9 3
22 6
14 4
20 5
23 6
5 2
2 1
17 4
15 4
25 6
10 4
21 5
16 4
30 8
28 7
18 5
3 1
24 6
26 6
29 7
27 6
12 4
6 2
11 4
19 5
13 4
7 2
32
31 64
4 2
8 3
0 1
1 1
9 3
22 6
14 4
20 5
23 6
5 2
2 1
17 4
15 4
25 6
10 4
21 5
16 4
30 8
28 7
18 5
3 1
24 6
26 6
29 7
27 6
12 4
6 2
11 4
19 5
13 4
7 2
end_CG
