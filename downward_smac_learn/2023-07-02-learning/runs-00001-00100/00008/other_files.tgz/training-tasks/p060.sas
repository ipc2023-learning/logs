begin_version
3
end_version
begin_metric
0
end_metric
57
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_7)
NegatedAtom clear(loc_10_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var3
-1
56
Atom at-robot(loc_10_10)
Atom at-robot(loc_10_4)
Atom at-robot(loc_10_5)
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_7)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Ato




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




53 14
22 0
13
221
2
53 12
38 0
19
203
2
53 7
50 0
4
8
287
2
53 21
21 0
12
239
2
53 15
37 0
14
227
2
53 13
23 0
20
209
2
53 8
43 0
2
9
296
2
53 22
10 0
21
215
2
53 9
27 0
0
4
10
305
2
53 23
14 0
15
254
2
53 18
4 0
17
245
2
53 16
31 0
22
218
2
53 11
11 0
2
16
266
2
53 19
34 0
18
251
2
53 17
49 0
4
11
317
2
53 25
22 0
17
278
2
53 20
31 0
19
257
2
53 18
50 0
24
224
2
53 12
51 0
4
12
329
2
53 26
37 0
18
290
2
53 21
49 0
20
269
2
53 19
43 0
25
230
2
53 13
52 0
4
13
341
2
53 27
38 0
19
299
2
53 22
50 0
21
281
2
53 20
27 0
26
236
2
53 14
45 0
2
14
353
2
53 28
23 0
27
242
2
53 15
41 0
0
4
17
365
2
53 31
31 0
22
320
2
53 25
11 0
24
308
2
53 23
51 0
29
260
2
53 18
32 0
4
18
374
2
53 32
49 0
23
332
2
53 26
36 0
25
311
2
53 24
52 0
30
272
2
53 19
44 0
4
19
383
2
53 33
50 0
24
344
2
53 27
51 0
26
323
2
53 25
45 0
31
284
2
53 20
48 0
4
20
395
2
53 34
43 0
25
356
2
53 28
52 0
27
335
2
53 26
41 0
32
293
2
53 21
39 0
4
21
401
2
53 35
27 0
26
362
2
53 29
45 0
28
347
2
53 27
5 0
33
302
2
53 22
29 0
0
2
23
416
2
53 38
36 0
36
314
2
53 24
42 0
4
24
425
2
53 39
51 0
29
386
2
53 33
32 0
31
368
2
53 31
48 0
37
326
2
53 25
46 0
4
25
437
2
53 40
52 0
30
398
2
53 34
44 0
32
377
2
53 32
39 0
38
338
2
53 26
47 0
4
26
449
2
53 41
45 0
31
404
2
53 35
48 0
33
389
2
53 33
29 0
39
350
2
53 27
30 0
2
27
458
2
53 42
41 0
40
359
2
53 28
40 0
0
2
34
419
2
53 38
6 0
36
410
2
53 36
42 0
4
29
473
2
53 45
32 0
35
428
2
53 39
15 0
37
413
2
53 37
46 0
43
371
2
53 31
12 0
4
30
479
2
53 46
44 0
36
440
2
53 40
42 0
38
422
2
53 38
47 0
44
380
2
53 32
35 0
4
31
485
2
53 47
48 0
37
452
2
53 41
46 0
39
431
2
53 39
30 0
45
392
2
53 33
28 0
2
38
461
2
53 42
47 0
40
443
2
53 40
40 0
4
33
494
2
53 48
29 0
39
467
2
53 43
30 0
41
455
2
53 41
7 0
46
407
2
53 35
17 0
0
0
0
4
37
500
2
53 51
46 0
43
488
2
53 47
12 0
45
476
2
53 45
28 0
48
434
2
53 39
24 0
2
38
506
2
53 52
47 0
49
446
2
53 40
33 0
2
40
518
2
53 54
40 0
51
464
2
53 42
26 0
2
0
470
2
53 44
0 0
42
170
2
53 0
8 0
2
2
482
2
53 46
18 0
44
179
2
53 2
35 0
4
3
491
2
53 47
19 0
45
185
2
53 3
28 0
48
512
2
53 53
24 0
50
503
2
53 51
25 0
2
49
521
2
53 54
33 0
51
509
2
53 52
26 0
2
50
527
2
53 55
25 0
52
515
2
53 53
16 0
2
47
524
2
53 54
13 0
51
497
2
53 50
26 0
end_DTG
begin_CG
5
54 1
55 1
56 1
53 4
13 3
5
54 1
55 1
56 1
53 4
18 3
5
54 1
55 1
56 1
53 5
19 3
5
54 1
55 1
56 1
53 4
14 3
5
54 1
55 1
56 1
53 5
34 3
5
54 1
55 1
56 1
53 4
41 3
5
54 1
55 1
56 1
53 5
15 3
5
54 1
55 1
56 1
53 5
40 3
5
54 1
55 1
56 1
53 5
13 3
6
54 2
55 2
56 2
53 8
20 3
22 3
6
54 2
55 2
56 2
53 8
21 3
23 3
6
54 2
55 2
56 2
53 8
34 3
36 3
6
54 2
55 2
56 2
53 8
42 3
35 3
5
54 1
55 1
56 1
53 6
16 3
5
54 1
55 1
56 1
53 6
34 3
5
54 1
55 1
56 1
53 5
42 3
5
54 1
55 1
56 1
53 6
26 3
5
54 1
55 1
56 1
53 6
40 3
6
54 2
55 2
56 2
53 9
19 3
24 3
6
54 2
55 2
56 2
53 9
18 3
33 3
6
54 2
55 2
56 2
53 9
21 3
37 3
6
54 2
55 2
56 2
53 9
20 3
38 3
6
54 2
55 2
56 2
53 9
37 3
49 3
6
54 2
55 2
56 2
53 9
38 3
27 3
6
54 2
55 2
56 2
53 9
35 3
33 3
6
54 2
55 2
56 2
53 9
33 3
26 3
7
54 3
55 3
56 3
53 12
17 3
25 3
16 3
7
54 3
55 3
56 3
53 12
23 3
43 3
41 3
7
54 3
55 3
56 3
53 12
47 3
35 3
33 3
7
54 3
55 3
56 3
53 12
41 3
39 3
40 3
7
54 3
55 3
56 3
53 12
39 3
47 3
40 3
7
54 3
55 3
56 3
53 12
34 3
49 3
36 3
7
54 3
55 3
56 3
53 12
36 3
44 3
42 3
6
54 2
55 2
56 2
53 10
28 3
25 3
6
54 2
55 2
56 2
53 10
14 3
31 3
6
54 2
55 2
56 2
53 10
46 3
24 3
6
54 2
55 2
56 2
53 10
51 3
32 3
6
54 2
55 2
56 2
53 10
38 3
50 3
6
54 2
55 2
56 2
53 10
37 3
43 3
6
54 2
55 2
56 2
53 10
45 3
48 3
7
54 3
55 3
56 3
53 13
29 3
30 3
17 3
7
54 3
55 3
56 3
53 13
27 3
45 3
29 3
7
54 3
55 3
56 3
53 13
32 3
15 3
46 3
7
54 3
55 3
56 3
53 13
38 3
50 3
45 3
7
54 3
55 3
56 3
53 13
51 3
48 3
46 3
8
54 4
55 4
56 4
53 16
43 3
52 3
41 3
39 3
8
54 4
55 4
56 4
53 16
44 3
42 3
47 3
35 3
8
54 4
55 4
56 4
53 16
48 3
46 3
30 3
28 3
8
54 4
55 4
56 4
53 16
52 3
44 3
39 3
47 3
8
54 4
55 4
56 4
53 16
22 3
31 3
50 3
51 3
8
54 4
55 4
56 4
53 16
37 3
49 3
43 3
52 3
8
54 4
55 4
56 4
53 16
49 3
36 3
52 3
44 3
8
54 4
55 4
56 4
53 16
50 3
51 3
45 3
48 3
56
54 120
55 120
56 120
0 3
1 3
18 12
19 12
2 3
3 3
9 6
20 12
21 12
10 6
14 9
22 12
37 18
38 18
23 12
4 3
34 18
31 15
49 24
50 24
43 21
27 15
11 6
36 18
51 24
52 24
45 24
41 21
5 3
32 15
44 21
48 24
39 18
29 15
6 3
15 9
42 21
46 24
47 24
30 15
40 21
7 3
8 3
12 6
35 18
28 15
17 9
13 9
24 12
33 18
25 12
26 15
16 9
54
53 120
0 1
1 1
18 4
19 4
2 1
3 1
9 2
20 4
21 4
10 2
14 3
22 4
37 6
38 6
23 4
4 1
34 6
31 5
49 8
50 8
43 7
27 5
11 2
36 6
51 8
52 8
45 8
41 7
5 1
32 5
44 7
48 8
39 6
29 5
6 1
15 3
42 7
46 8
47 8
30 5
40 7
7 1
8 1
12 2
35 6
28 5
17 3
13 3
24 4
33 6
25 4
26 5
16 3
54
53 120
0 1
1 1
18 4
19 4
2 1
3 1
9 2
20 4
21 4
10 2
14 3
22 4
37 6
38 6
23 4
4 1
34 6
31 5
49 8
50 8
43 7
27 5
11 2
36 6
51 8
52 8
45 8
41 7
5 1
32 5
44 7
48 8
39 6
29 5
6 1
15 3
42 7
46 8
47 8
30 5
40 7
7 1
8 1
12 2
35 6
28 5
17 3
13 3
24 4
33 6
25 4
26 5
16 3
54
53 120
0 1
1 1
18 4
19 4
2 1
3 1
9 2
20 4
21 4
10 2
14 3
22 4
37 6
38 6
23 4
4 1
34 6
31 5
49 8
50 8
43 7
27 5
11 2
36 6
51 8
52 8
45 8
41 7
5 1
32 5
44 7
48 8
39 6
29 5
6 1
15 3
42 7
46 8
47 8
30 5
40 7
7 1
8 1
12 2
35 6
28 5
17 3
13 3
24 4
33 6
25 4
26 5
16 3
end_CG
