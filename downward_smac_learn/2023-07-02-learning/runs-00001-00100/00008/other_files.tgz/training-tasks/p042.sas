begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var3
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var2
-1
39
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_8_9)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_7)
end_variable
begin_variable
var0
-1
38
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_5_9)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_6_9)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_7_9)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
Atom at(box1, loc_8_7)
Atom at(box1, loc_8_8)
Atom at(box1, loc_8_9)
Atom at(box1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





134
2
38 6
12 0
6
124
2
38 4
30 0
4
1
162
2
38 12
1 0
5
142
2
38 7
22 0
7
130
2
38 5
34 0
12
118
2
38 1
31 0
4
2
168
2
38 13
9 0
6
148
2
38 8
30 0
8
136
2
38 6
15 0
13
120
2
38 2
36 0
2
7
152
2
38 9
34 0
9
144
2
38 7
6 0
0
2
4
192
2
38 18
12 0
18
126
2
38 4
13 0
4
5
196
2
38 19
22 0
10
164
2
38 12
10 0
12
156
2
38 10
31 0
19
132
2
38 5
33 0
4
6
204
2
38 20
30 0
11
170
2
38 13
26 0
13
158
2
38 11
36 0
20
138
2
38 6
23 0
4
7
210
2
38 21
34 0
12
176
2
38 14
31 0
14
166
2
38 12
32 0
21
146
2
38 7
37 0
4
8
218
2
38 22
15 0
13
182
2
38 15
36 0
15
172
2
38 13
24 0
22
150
2
38 8
35 0
4
9
226
2
38 23
6 0
14
186
2
38 16
32 0
16
178
2
38 14
7 0
23
154
2
38 9
28 0
0
0
2
17
198
2
38 19
3 0
19
190
2
38 17
33 0
4
11
236
2
38 25
26 0
18
206
2
38 20
13 0
20
194
2
38 18
23 0
25
160
2
38 11
19 0
2
19
212
2
38 21
33 0
21
200
2
38 19
37 0
4
13
240
2
38 26
36 0
20
220
2
38 22
23 0
22
208
2
38 20
35 0
26
174
2
38 13
20 0
4
14
244
2
38 27
32 0
21
228
2
38 23
37 0
23
214
2
38 21
28 0
27
180
2
38 14
29 0
4
15
250
2
38 28
24 0
22
232
2
38 24
35 0
24
222
2
38 22
16 0
28
184
2
38 15
25 0
2
16
254
2
38 29
7 0
29
188
2
38 16
17 0
2
19
258
2
38 30
33 0
30
202
2
38 19
14 0
2
21
264
2
38 32
37 0
32
216
2
38 21
21 0
4
22
270
2
38 33
35 0
26
252
2
38 28
20 0
28
242
2
38 26
25 0
33
224
2
38 22
27 0
4
23
276
2
38 34
28 0
27
256
2
38 29
29 0
29
246
2
38 27
17 0
34
230
2
38 23
18 0
2
24
280
2
38 35
16 0
35
234
2
38 24
8 0
2
25
284
2
38 36
19 0
36
238
2
38 25
4 0
2
30
266
2
38 32
14 0
32
260
2
38 30
21 0
2
31
272
2
38 33
11 0
33
262
2
38 31
27 0
4
27
286
2
38 38
29 0
32
278
2
38 34
21 0
34
268
2
38 32
18 0
37
248
2
38 27
5 0
2
33
282
2
38 35
27 0
35
274
2
38 33
8 0
0
0
0
end_DTG
begin_DTG
0
0
2
0
141
2
38 7
0 0
7
117
2
38 0
34 0
0
2
3
129
2
38 5
2 0
5
123
2
38 3
22 0
2
4
135
2
38 6
12 0
6
125
2
38 4
30 0
4
1
163
2
38 12
1 0
5
143
2
38 7
22 0
7
131
2
38 5
34 0
12
119
2
38 1
31 0
4
2
169
2
38 13
9 0
6
149
2
38 8
30 0
8
137
2
38 6
15 0
13
121
2
38 2
36 0
2
7
153
2
38 9
34 0
9
145
2
38 7
6 0
0
2
4
193
2
38 18
12 0
18
127
2
38 4
13 0
4
5
197
2
38 19
22 0
10
165
2
38 12
10 0
12
157
2
38 10
31 0
19
133
2
38 5
33 0
4
6
205
2
38 20
30 0
11
171
2
38 13
26 0
13
159
2
38 11
36 0
20
139
2
38 6
23 0
4
7
211
2
38 21
34 0
12
177
2
38 14
31 0
14
167
2
38 12
32 0
21
147
2
38 7
37 0
4
8
219
2
38 22
15 0
13
183
2
38 15
36 0
15
173
2
38 13
24 0
22
151
2
38 8
35 0
4
9
227
2
38 23
6 0
14
187
2
38 16
32 0
16
179
2
38 14
7 0
23
155
2
38 9
28 0
0
0
2
17
199
2
38 19
3 0
19
191
2
38 17
33 0
4
11
237
2
38 25
26 0
18
207
2
38 20
13 0
20
195
2
38 18
23 0
25
161
2
38 11
19 0
2
19
213
2
38 21
33 0
21
201
2
38 19
37 0
4
13
241
2
38 26
36 0
20
221
2
38 22
23 0
22
209
2
38 20
35 0
26
175
2
38 13
20 0
4
14
245
2
38 27
32 0
21
229
2
38 23
37 0
23
215
2
38 21
28 0
27
181
2
38 14
29 0
4
15
251
2
38 28
24 0
22
233
2
38 24
35 0
24
223
2
38 22
16 0
28
185
2
38 15
25 0
2
16
255
2
38 29
7 0
29
189
2
38 16
17 0
2
19
259
2
38 30
33 0
30
203
2
38 19
14 0
2
21
265
2
38 32
37 0
32
217
2
38 21
21 0
4
22
271
2
38 33
35 0
26
253
2
38 28
20 0
28
243
2
38 26
25 0
33
225
2
38 22
27 0
4
23
277
2
38 34
28 0
27
257
2
38 29
29 0
29
247
2
38 27
17 0
34
231
2
38 23
18 0
2
24
281
2
38 35
16 0
35
235
2
38 24
8 0
2
25
285
2
38 36
19 0
36
239
2
38 25
4 0
2
30
267
2
38 32
14 0
32
261
2
38 30
21 0
2
31
273
2
38 33
11 0
33
263
2
38 31
27 0
4
27
287
2
38 38
29 0
32
279
2
38 34
21 0
34
269
2
38 32
18 0
37
249
2
38 27
5 0
2
33
283
2
38 35
27 0
35
275
2
38 33
8 0
0
0
0
end_DTG
begin_CG
4
39 1
40 1
38 3
9 2
4
39 1
40 1
38 4
30 2
4
39 1
40 1
38 3
12 2
4
39 1
40 1
38 3
13 2
4
39 1
40 1
38 4
14 2
4
39 1
40 1
38 3
27 2
5
39 2
40 2
38 6
15 2
24 2
5
39 2
40 2
38 6
24 2
16 2
5
39 2
40 2
38 6
17 2
18 2
4
39 1
40 1
38 5
34 2
4
39 1
40 1
38 5
26 2
4
39 1
40 1
38 5
21 2
5
39 2
40 2
38 7
22 2
10 2
5
39 2
40 2
38 7
10 2
33 2
5
39 2
40 2
38 7
19 2
11 2
5
39 2
40 2
38 7
34 2
32 2
5
39 2
40 2
38 7
28 2
17 2
5
39 2
40 2
38 7
16 2
25 2
5
39 2
40 2
38 7
25 2
27 2
5
39 2
40 2
38 6
33 2
14 2
5
39 2
40 2
38 7
37 2
29 2
6
39 3
40 3
38 9
20 2
11 2
27 2
6
39 3
40 3
38 9
12 2
30 2
26 2
6
39 3
40 3
38 9
31 2
33 2
37 2
5
39 2
40 2
38 8
32 2
28 2
5
39 2
40 2
38 8
28 2
29 2
5
39 2
40 2
38 8
31 2
33 2
6
39 3
40 3
38 10
29 2
21 2
18 2
6
39 3
40 3
38 10
24 2
35 2
25 2
6
39 3
40 3
38 10
35 2
25 2
27 2
6
39 3
40 3
38 10
22 2
34 2
31 2
6
39 3
40 3
38 10
30 2
26 2
36 2
6
39 3
40 3
38 10
36 2
24 2
35 2
7
39 4
40 4
38 12
26 2
13 2
23 2
19 2
7
39 4
40 4
38 12
9 2
30 2
15 2
36 2
7
39 4
40 4
38 12
32 2
37 2
28 2
29 2
7
39 4
40 4
38 12
34 2
31 2
32 2
37 2
7
39 4
40 4
38 12
36 2
23 2
35 2
20 2
40
39 86
40 86
0 2
1 2
9 6
2 2
12 8
22 10
30 14
34 16
15 8
6 4
10 6
26 12
31 14
36 16
32 14
24 12
7 4
3 2
13 8
33 16
23 10
37 16
35 16
28 14
16 8
19 8
20 8
29 14
25 12
17 8
14 8
11 6
21 10
27 14
18 8
8 4
4 2
5 2
39
38 86
0 1
1 1
9 3
2 1
12 4
22 5
30 7
34 8
15 4
6 2
10 3
26 6
31 7
36 8
32 7
24 6
7 2
3 1
13 4
33 8
23 5
37 8
35 8
28 7
16 4
19 4
20 4
29 7
25 6
17 4
14 4
11 3
21 5
27 7
18 4
8 2
4 1
5 1
39
38 86
0 1
1 1
9 3
2 1
12 4
22 5
30 7
34 8
15 4
6 2
10 3
26 6
31 7
36 8
32 7
24 6
7 2
3 1
13 4
33 8
23 5
37 8
35 8
28 7
16 4
19 4
20 4
29 7
25 6
17 4
14 4
11 3
21 5
27 7
18 4
8 2
4 1
5 1
end_CG
