begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var4
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var3
-1
39
Atom at-robot(loc_10_3)
Atom at-robot(loc_10_4)
Atom at-robot(loc_4_10)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_10)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_10)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_8_9)
Atom at-robot(loc_9_10)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_7)
Atom at-robot(loc_9_8)
Atom at-robot(loc_9_9)
end_variable
begin_variable
var0
-1
37
Atom at(box1, loc_10_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_10)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_5_9)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_6_9)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_7_9)
Atom at(box1, loc_8_10)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
Atom at(box1, loc_8_7)
Atom at(box1, loc_8_8)
Atom at(box1, loc_8_9)
Atom at(box1, loc_9_10)
Atom at(box1, loc_9_4)
Atom at(box1, loc_9_5)
Atom at(box1, loc_9_6)
Atom at(box1, loc_9_7)
Atom at(box1, loc_9_8)
Atom at(box1, loc_9_9)
end_variable
begin_variable
var1
-1
37
Atom at(box2, loc




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




283
2
37 24
9 0
22
175
2
37 11
19 0
0
4
10
295
2
37 26
11 0
16
241
2
37 20
4 0
18
226
2
37 18
33 0
24
181
2
37 12
14 0
4
11
304
2
37 27
29 0
17
253
2
37 21
25 0
19
232
2
37 19
36 0
25
190
2
37 13
23 0
4
12
310
2
37 28
34 0
18
265
2
37 22
33 0
20
244
2
37 20
35 0
26
202
2
37 14
30 0
4
13
319
2
37 29
32 0
19
277
2
37 23
36 0
21
256
2
37 21
28 0
27
211
2
37 15
31 0
4
14
328
2
37 30
24 0
20
286
2
37 24
35 0
22
268
2
37 22
19 0
28
217
2
37 16
27 0
2
15
337
2
37 31
13 0
29
223
2
37 17
21 0
0
2
17
346
2
37 33
25 0
31
235
2
37 19
8 0
4
18
352
2
37 34
33 0
24
313
2
37 28
14 0
26
298
2
37 26
30 0
32
247
2
37 20
12 0
4
19
358
2
37 35
36 0
25
322
2
37 29
23 0
27
307
2
37 27
31 0
33
259
2
37 21
17 0
4
20
367
2
37 36
35 0
26
331
2
37 30
30 0
28
316
2
37 28
27 0
34
271
2
37 22
18 0
4
21
376
2
37 37
28 0
27
340
2
37 31
31 0
29
325
2
37 29
21 0
35
280
2
37 23
16 0
4
22
385
2
37 38
19 0
23
334
2
37 30
5 0
28
292
2
37 25
27 0
36
289
2
37 24
10 0
0
2
0
301
2
37 26
0 0
24
121
2
37 1
14 0
2
31
361
2
37 35
8 0
33
349
2
37 33
17 0
2
32
370
2
37 36
12 0
34
355
2
37 34
18 0
2
33
379
2
37 37
17 0
35
364
2
37 35
16 0
2
34
388
2
37 38
18 0
36
373
2
37 36
10 0
2
30
382
2
37 37
6 0
35
343
2
37 32
16 0
end_DTG
begin_DTG
0
0
0
0
0
4
1
185
2
37 13
1 0
4
146
2
37 8
7 0
6
134
2
37 6
26 0
11
125
2
37 3
29 0
4
2
194
2
37 14
2 0
5
155
2
37 9
22 0
7
140
2
37 7
20 0
12
128
2
37 4
34 0
2
6
164
2
37 10
26 0
8
149
2
37 8
15 0
2
7
173
2
37 11
20 0
9
158
2
37 9
9 0
2
3
167
2
37 10
3 0
8
131
2
37 5
15 0
2
4
230
2
37 19
7 0
17
137
2
37 6
25 0
4
5
239
2
37 20
22 0
10
197
2
37 14
11 0
12
179
2
37 12
34 0
18
143
2
37 7
33 0
4
6
251
2
37 21
26 0
11
206
2
37 15
29 0
13
188
2
37 13
32 0
19
152
2
37 8
36 0
4
7
263
2
37 22
20 0
12
215
2
37 16
34 0
14
200
2
37 14
24 0
20
161
2
37 9
35 0
4
8
275
2
37 23
15 0
13
221
2
37 17
32 0
15
209
2
37 15
13 0
21
170
2
37 10
28 0
2
9
284
2
37 24
9 0
22
176
2
37 11
19 0
0
4
10
296
2
37 26
11 0
16
242
2
37 20
4 0
18
227
2
37 18
33 0
24
182
2
37 12
14 0
4
11
305
2
37 27
29 0
17
254
2
37 21
25 0
19
233
2
37 19
36 0
25
191
2
37 13
23 0
4
12
311
2
37 28
34 0
18
266
2
37 22
33 0
20
245
2
37 20
35 0
26
203
2
37 14
30 0
4
13
320
2
37 29
32 0
19
278
2
37 23
36 0
21
257
2
37 21
28 0
27
212
2
37 15
31 0
4
14
329
2
37 30
24 0
20
287
2
37 24
35 0
22
269
2
37 22
19 0
28
218
2
37 16
27 0
2
15
338
2
37 31
13 0
29
224
2
37 17
21 0
0
2
17
347
2
37 33
25 0
31
236
2
37 19
8 0
4
18
353
2
37 34
33 0
24
314
2
37 28
14 0
26
299
2
37 26
30 0
32
248
2
37 20
12 0
4
19
359
2
37 35
36 0
25
323
2
37 29
23 0
27
308
2
37 27
31 0
33
260
2
37 21
17 0
4
20
368
2
37 36
35 0
26
332
2
37 30
30 0
28
317
2
37 28
27 0
34
272
2
37 22
18 0
4
21
377
2
37 37
28 0
27
341
2
37 31
31 0
29
326
2
37 29
21 0
35
281
2
37 23
16 0
4
22
386
2
37 38
19 0
23
335
2
37 30
5 0
28
293
2
37 25
27 0
36
290
2
37 24
10 0
0
2
0
302
2
37 26
0 0
24
122
2
37 1
14 0
2
31
362
2
37 35
8 0
33
350
2
37 33
17 0
2
32
371
2
37 36
12 0
34
356
2
37 34
18 0
2
33
380
2
37 37
17 0
35
365
2
37 35
16 0
2
34
389
2
37 38
18 0
36
374
2
37 36
10 0
2
30
383
2
37 37
6 0
35
344
2
37 32
16 0
end_DTG
begin_CG
5
38 1
39 1
40 1
37 5
8 3
5
38 1
39 1
40 1
37 5
22 3
5
38 1
39 1
40 1
37 5
26 3
5
38 1
39 1
40 1
37 5
9 3
5
38 1
39 1
40 1
37 4
25 3
5
38 1
39 1
40 1
37 5
21 3
5
38 1
39 1
40 1
37 5
10 3
6
38 2
39 2
40 2
37 8
22 3
11 3
6
38 2
39 2
40 2
37 9
14 3
12 3
6
38 2
39 2
40 2
37 9
15 3
13 3
6
38 2
39 2
40 2
37 9
21 3
16 3
6
38 2
39 2
40 2
37 9
29 3
25 3
6
38 2
39 2
40 2
37 9
23 3
17 3
6
38 2
39 2
40 2
37 9
24 3
19 3
7
38 3
39 3
40 3
37 12
25 3
23 3
8 3
7
38 3
39 3
40 3
37 12
20 3
9 3
24 3
7
38 3
39 3
40 3
37 12
27 3
18 3
10 3
7
38 3
39 3
40 3
37 12
30 3
12 3
18 3
7
38 3
39 3
40 3
37 12
31 3
17 3
16 3
7
38 3
39 3
40 3
37 12
13 3
28 3
21 3
7
38 3
39 3
40 3
37 12
26 3
15 3
32 3
6
38 2
39 2
40 2
37 10
19 3
27 3
6
38 2
39 2
40 2
37 10
26 3
29 3
6
38 2
39 2
40 2
37 10
33 3
30 3
6
38 2
39 2
40 2
37 10
32 3
28 3
7
38 3
39 3
40 3
37 13
11 3
33 3
14 3
7
38 3
39 3
40 3
37 13
22 3
20 3
34 3
7
38 3
39 3
40 3
37 13
28 3
31 3
21 3
7
38 3
39 3
40 3
37 13
24 3
35 3
27 3
7
38 3
39 3
40 3
37 13
22 3
34 3
33 3
7
38 3
39 3
40 3
37 13
36 3
23 3
31 3
7
38 3
39 3
40 3
37 13
35 3
30 3
27 3
7
38 3
39 3
40 3
37 13
34 3
24 3
35 3
8
38 4
39 4
40 4
37 16
29 3
25 3
36 3
23 3
8
38 4
39 4
40 4
37 16
26 3
29 3
32 3
36 3
8
38 4
39 4
40 4
37 16
32 3
36 3
28 3
31 3
8
38 4
39 4
40 4
37 16
34 3
33 3
35 3
30 3
40
38 90
39 90
40 90
0 3
1 3
2 3
3 3
7 6
22 18
26 21
20 15
15 15
9 12
11 12
29 21
34 24
32 21
24 18
13 12
4 3
25 21
33 24
36 24
35 24
28 21
19 15
5 3
14 15
23 18
30 21
31 21
27 21
21 18
6 3
8 12
12 12
17 15
18 15
16 15
10 12
38
37 90
0 1
1 1
2 1
3 1
7 2
22 6
26 7
20 5
15 5
9 4
11 4
29 7
34 8
32 7
24 6
13 4
4 1
25 7
33 8
36 8
35 8
28 7
19 5
5 1
14 5
23 6
30 7
31 7
27 7
21 6
6 1
8 4
12 4
17 5
18 5
16 5
10 4
38
37 90
0 1
1 1
2 1
3 1
7 2
22 6
26 7
20 5
15 5
9 4
11 4
29 7
34 8
32 7
24 6
13 4
4 1
25 7
33 8
36 8
35 8
28 7
19 5
5 1
14 5
23 6
30 7
31 7
27 7
21 6
6 1
8 4
12 4
17 5
18 5
16 5
10 4
38
37 90
0 1
1 1
2 1
3 1
7 2
22 6
26 7
20 5
15 5
9 4
11 4
29 7
34 8
32 7
24 6
13 4
4 1
25 7
33 8
36 8
35 8
28 7
19 5
5 1
14 5
23 6
30 7
31 7
27 7
21 6
6 1
8 4
12 4
17 5
18 5
16 5
10 4
end_CG
