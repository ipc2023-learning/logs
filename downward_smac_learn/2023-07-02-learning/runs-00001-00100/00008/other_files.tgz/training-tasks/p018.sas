begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var2
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var1
-1
20
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_5)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_4)
end_variable
begin_variable
var0
-1
19
Atom at(box1, loc_2_3)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_4)
end_variable
19
begin_mutex_group
2
20 0
0 0
end_mutex_group
begin_mutex_group
2
20 1
13 0
end_mutex_group
begin_mutex_group
2
20 2
9 0
end_mutex_group
begin_mutex_group
2
20 3
1 0
end_mutex_group
begin_mutex_group
2
20 4
15 0
end_mutex_group
begin_mutex_group
2
20 5
12 0
end_mutex_group
begin_mutex_group
2
20 6
2 0
end_mutex_group
begin_mutex_group
2
20 7
5 0
end_mutex_group
begin_mutex_group
2
20 8
16 0
end_mutex_group
begin_mutex_group
2
20 9
18 0
end_mutex_group
begin_mutex_group
2
20 10
11 0
end_mutex_group
begin_mutex_group
2
20 11
8 0
end_mutex_group
begin_mutex_group
2
20 12
7 0
end_mutex_group
begin_mutex_group
2
20 13
14 0
end_mutex_group
begin_mutex_group
2
20 14
17 0
end_mutex_group
begin_mutex_group
2
20 15
10 0
end_mutex_group
begin_mutex_group
2
20 16
6 0
end_mutex_group
begin_mutex_group
2
20 17
3 0
end_mutex_group
begin_mutex_group
2
20 18
4 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
6
15
end_state
begin_goal
1
20 13
end_goal
80
begin_operator
move loc_2_3 loc_3_3 down
1
13 0
1
0 19 0 2
0
end_operator
begin_operator
move loc_2_5 loc_3_5 down
1
1 0
1
0 19 1 4
0
end_operator
begin_operator
move loc_3_3 loc_2_3 up
1
0 0
1
0 19 2 0
0
end_operator
begin_operator
move loc_3_3 loc_3_4 right
1
9 0
1
0 19 2 3
0
end_operator
begin_operator
move loc_3_3 loc_4_3 down
1
15 0
1
0 19 2 5
0
end_operator
begin_operator
move loc_3_4 loc_3_3 left
1
13 0
1
0 19 3 2
0
end_operator
begin_operator
move loc_3_4 loc_3_5 right
1
1 0
1
0 19 3 4
0
end_operator
begin_operator
move loc_3_4 loc_4_4 down
1
12 0
1
0 19 3 6
0
end_operator
begin_operator
move loc_3_5 loc_2_5 up
0
1
0 19 4 1
0
end_operator
begin_operator
move loc_3_5 loc_3_4 left
1
9 0
1
0 19 4 3
0
end_operator
begin_operator
move loc_4_3 loc_3_3 up
1
13 0
1
0 19 5 2
0
end_operator
begin_operator
move loc_4_3 loc_4_4 right
1
12 0
1
0 19 5 6
0
end_operator
begin_operator
move loc_4_3 loc_5_3 down
1
16 0
1
0 19 5 9
0
end_operator
begin_operator
move loc_4_4 loc_3_4 up
1
9 0
1
0 19 6 3
0
end_operator
begin_operator
move loc_4_4 loc_4_3 left
1
15 0
1
0 19 6 5
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
1
18 0
1
0 19 6 10
0
end_operator
begin_operator
move loc_4_6 loc_5_6 down
1
8 0
1
0 19 7 12
0
end_operator
begin_operator
move loc_5_2 loc_5_3 right
1
16 0
1
0 19 8 9
0
end_operator
begin_operator
move loc_5_2 loc_6_2 down
1
7 0
1
0 19 8 13
0
end_operator
begin_operator
move loc_5_3 loc_4_3 up
1
15 0
1
0 19 9 5
0
end_operator
begin_operator
move loc_5_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





21
check 0
switch 14
check 0
check 1
22
check 0
check 0
switch 12
check 0
check 1
23
check 0
switch 16
check 0
check 1
24
check 0
switch 11
check 0
check 1
25
check 0
switch 17
check 0
check 1
26
check 0
check 0
switch 18
check 0
check 1
27
check 0
switch 8
check 0
check 1
28
check 0
switch 10
check 0
check 1
29
check 0
check 0
switch 2
check 0
check 1
30
check 0
switch 11
check 0
check 1
31
check 0
switch 6
check 0
check 1
32
check 0
check 0
switch 5
check 0
check 1
33
check 0
switch 14
check 0
check 1
34
check 0
switch 3
check 0
check 1
35
check 0
check 0
switch 16
check 0
check 1
36
check 0
switch 7
check 0
check 1
37
check 0
switch 17
check 0
check 1
38
check 0
check 0
switch 18
check 0
check 1
39
check 0
switch 14
check 0
check 1
40
check 0
switch 10
check 0
check 1
41
check 0
switch 4
check 0
check 1
42
check 0
check 0
switch 11
check 0
check 1
43
check 0
switch 17
check 0
check 1
44
check 0
switch 6
check 0
check 1
45
check 0
check 0
switch 8
check 0
check 1
46
check 0
switch 10
check 0
check 1
47
check 0
check 0
switch 7
check 0
check 1
48
check 0
check 0
switch 17
check 0
check 1
49
check 0
check 0
check 0
end_SG
begin_DTG
1
1
55
2
20 1
19 5
0
end_DTG
begin_DTG
1
1
51
2
20 2
19 2
0
end_DTG
begin_DTG
1
1
76
2
20 11
19 17
0
end_DTG
begin_DTG
1
1
60
2
20 12
19 8
0
end_DTG
begin_DTG
1
1
66
2
20 14
19 10
0
end_DTG
begin_DTG
2
1
64
2
20 8
19 10
1
78
2
20 12
19 18
0
end_DTG
begin_DTG
2
1
58
2
20 11
19 7
1
74
2
20 15
19 15
0
end_DTG
begin_DTG
1
1
73
2
20 13
19 15
2
0
60
3
20 12
19 8
3 0
0
78
3
20 12
19 18
5 0
end_DTG
begin_DTG
1
1
65
2
20 10
19 10
2
0
58
3
20 11
19 7
6 0
0
76
3
20 11
19 17
2 0
end_DTG
begin_DTG
1
1
63
2
20 5
19 10
2
0
51
3
20 2
19 2
1 0
0
54
3
20 2
19 4
13 0
end_DTG
begin_DTG
1
1
71
2
20 14
19 14
2
0
74
3
20 15
19 15
6 0
0
77
3
20 15
19 17
17 0
end_DTG
begin_DTG
1
1
62
2
20 9
19 9
2
0
65
3
20 10
19 10
8 0
0
68
3
20 10
19 12
18 0
end_DTG
begin_DTG
1
1
72
2
20 9
19 15
2
0
53
3
20 5
19 3
18 0
0
63
3
20 5
19 10
9 0
end_DTG
begin_DTG
2
1
54
2
20 2
19 4
1
61
2
20 4
19 9
2
0
50
3
20 1
19 0
15 0
0
55
3
20 1
19 5
0 0
end_DTG
begin_DTG
2
1
56
2
20 8
19 5
1
75
2
20 14
19 16
2
0
69
3
20 13
19 13
17 0
0
73
3
20 13
19 15
7 0
end_DTG
begin_DTG
2
1
50
2
20 1
19 0
1
70
2
20 8
19 14
2
0
52
3
20 4
19 2
16 0
0
61
3
20 4
19 9
13 0
end_DTG
begin_DTG
2
1
52
2
20 4
19 2
1
67
2
20 9
19 11
4
0
56
3
20 8
19 5
14 0
0
59
3
20 8
19 8
18 0
0
64
3
20 8
19 10
5 0
0
70
3
20 8
19 14
15 0
end_DTG
begin_DTG
3
1
57
2
20 9
19 6
1
69
2
20 13
19 13
1
77
2
20 15
19 17
4
0
66
3
20 14
19 10
4 0
0
71
3
20 14
19 14
10 0
0
75
3
20 14
19 16
14 0
0
79
3
20 14
19 19
18 0
end_DTG
begin_DTG
4
1
53
2
20 5
19 3
1
59
2
20 8
19 8
1
68
2
20 10
19 12
1
79
2
20 14
19 19
4
0
57
3
20 9
19 6
17 0
0
62
3
20 9
19 9
11 0
0
67
3
20 9
19 11
16 0
0
72
3
20 9
19 15
12 0
end_DTG
begin_DTG
2
2
0
1
13 0
2
50
2
20 1
15 0
1
4
1
1
1 0
5
0
2
1
0 0
3
3
1
9 0
3
51
2
20 2
1 0
5
4
1
15 0
5
52
2
20 4
16 0
4
2
5
1
13 0
4
6
1
1 0
6
7
1
12 0
6
53
2
20 5
18 0
3
1
8
0
3
9
1
9 0
3
54
2
20 2
13 0
5
2
10
1
13 0
2
55
2
20 1
0 0
6
11
1
12 0
9
12
1
16 0
9
56
2
20 8
14 0
4
3
13
1
9 0
5
14
1
15 0
10
15
1
18 0
10
57
2
20 9
17 0
2
12
16
1
8 0
12
58
2
20 11
6 0
4
9
17
1
16 0
9
59
2
20 8
18 0
13
18
1
7 0
13
60
2
20 12
3 0
6
5
19
1
15 0
5
61
2
20 4
13 0
8
20
1
5 0
10
21
1
18 0
10
62
2
20 9
11 0
14
22
1
14 0
8
6
23
1
12 0
6
63
2
20 5
9 0
9
24
1
16 0
9
64
2
20 8
5 0
11
25
1
11 0
11
65
2
20 10
8 0
15
26
1
17 0
15
66
2
20 14
4 0
4
10
27
1
18 0
10
67
2
20 9
16 0
12
28
1
8 0
16
29
1
10 0
4
7
30
1
2 0
11
31
1
11 0
11
68
2
20 10
18 0
17
32
1
6 0
4
8
33
1
5 0
14
34
1
14 0
14
69
2
20 13
17 0
18
35
1
3 0
5
9
36
1
16 0
9
70
2
20 8
15 0
13
37
1
7 0
15
38
1
17 0
15
71
2
20 14
10 0
7
10
39
1
18 0
10
72
2
20 9
12 0
14
40
1
14 0
14
73
2
20 13
7 0
16
41
1
10 0
16
74
2
20 15
6 0
19
42
1
4 0
4
11
43
1
11 0
15
44
1
17 0
15
75
2
20 14
14 0
17
45
1
6 0
4
12
46
1
8 0
12
76
2
20 11
2 0
16
47
1
10 0
16
77
2
20 15
17 0
2
13
48
1
7 0
13
78
2
20 12
5 0
2
15
49
1
17 0
15
79
2
20 14
18 0
end_DTG
begin_DTG
0
2
0
55
2
19 5
0 0
4
50
2
19 0
15 0
2
1
54
2
19 4
13 0
3
51
2
19 2
1 0
0
2
1
61
2
19 9
13 0
8
52
2
19 2
16 0
2
2
63
2
19 10
9 0
9
53
2
19 3
18 0
0
0
4
4
70
2
19 14
15 0
7
64
2
19 10
5 0
9
59
2
19 8
18 0
13
56
2
19 5
14 0
4
5
72
2
19 15
12 0
8
67
2
19 11
16 0
10
62
2
19 9
11 0
14
57
2
19 6
17 0
2
9
68
2
19 12
18 0
11
65
2
19 10
8 0
2
6
76
2
19 17
2 0
16
58
2
19 7
6 0
2
7
78
2
19 18
5 0
17
60
2
19 8
3 0
2
12
73
2
19 15
7 0
14
69
2
19 13
17 0
4
9
79
2
19 19
18 0
13
75
2
19 16
14 0
15
71
2
19 14
10 0
18
66
2
19 10
4 0
2
14
77
2
19 17
17 0
16
74
2
19 15
6 0
0
0
0
end_DTG
begin_CG
3
20 1
19 2
13 1
3
20 1
19 3
9 1
3
20 1
19 2
8 1
3
20 1
19 2
7 1
3
20 1
19 2
17 1
4
20 2
19 4
16 1
7 1
4
20 2
19 4
8 1
10 1
3
20 1
19 4
14 1
3
20 1
19 4
11 1
3
20 1
19 4
12 1
3
20 1
19 4
17 1
3
20 1
19 4
18 1
3
20 1
19 4
18 1
4
20 2
19 5
9 1
15 1
4
20 2
19 5
16 1
17 1
4
20 2
19 5
13 1
16 1
4
20 2
19 6
15 1
18 1
5
20 3
19 7
18 1
14 1
10 1
6
20 4
19 8
12 1
16 1
11 1
17 1
20
20 30
0 1
13 4
9 3
1 1
15 4
12 3
2 1
5 2
16 6
18 8
11 3
8 3
7 3
14 4
17 7
10 3
6 2
3 1
4 1
20
19 30
0 1
13 4
9 3
1 1
15 4
12 3
2 1
5 2
16 6
18 8
11 3
8 3
7 3
14 4
17 7
10 3
6 2
3 1
4 1
end_CG
