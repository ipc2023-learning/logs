begin_version
3
end_version
begin_metric
0
end_metric
49
begin_variable
var9
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_9_5)
NegatedAtom clear(loc_9_5)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var2
-1
48
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
Atom at-robot(loc_9_2)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_5)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_7)
Atom at-robot(loc_9_8)
Atom at




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





36
262
2
46 23
29 0
4
24
330
2
46 38
43 0
31
314
2
46 33
44 0
33
300
2
46 31
35 0
37
270
2
46 24
32 0
4
25
336
2
46 39
34 0
32
318
2
46 34
45 0
34
308
2
46 32
17 0
38
276
2
46 25
30 0
2
26
340
2
46 40
12 0
39
280
2
46 26
18 0
2
30
344
2
46 42
42 0
40
294
2
46 30
8 0
4
31
348
2
46 43
44 0
35
332
2
46 38
15 0
37
324
2
46 36
32 0
41
302
2
46 31
16 0
4
32
352
2
46 44
45 0
36
338
2
46 39
29 0
38
328
2
46 37
30 0
42
310
2
46 32
22 0
4
33
358
2
46 45
35 0
37
342
2
46 40
32 0
39
334
2
46 38
18 0
43
316
2
46 33
21 0
2
34
364
2
46 46
17 0
44
320
2
46 34
13 0
0
2
40
354
2
46 44
8 0
42
346
2
46 42
22 0
2
41
360
2
46 45
16 0
43
350
2
46 43
21 0
2
42
366
2
46 46
22 0
44
356
2
46 44
13 0
2
43
368
2
46 47
21 0
45
362
2
46 45
3 0
0
end_DTG
begin_DTG
0
2
0
155
2
46 2
4 0
2
147
2
46 0
23 0
2
1
161
2
46 3
14 0
3
151
2
46 1
24 0
2
2
167
2
46 4
23 0
4
157
2
46 2
20 0
2
3
173
2
46 5
24 0
5
163
2
46 3
10 0
2
4
175
2
46 6
20 0
6
169
2
46 4
0 0
0
2
0
197
2
46 12
4 0
12
149
2
46 0
5 0
4
1
201
2
46 13
14 0
7
183
2
46 9
9 0
9
177
2
46 7
33 0
13
153
2
46 1
27 0
4
2
205
2
46 14
23 0
8
189
2
46 10
28 0
10
179
2
46 8
31 0
14
159
2
46 2
39 0
4
3
213
2
46 15
24 0
9
193
2
46 11
33 0
11
185
2
46 9
19 0
15
165
2
46 3
38 0
2
4
219
2
46 16
20 0
16
171
2
46 4
25 0
0
4
8
225
2
46 17
28 0
12
207
2
46 14
5 0
14
199
2
46 12
39 0
17
181
2
46 8
6 0
4
9
229
2
46 18
33 0
13
215
2
46 15
27 0
15
203
2
46 13
38 0
18
187
2
46 9
37 0
4
10
235
2
46 19
31 0
14
221
2
46 16
39 0
16
209
2
46 14
25 0
19
191
2
46 10
41 0
2
11
243
2
46 20
19 0
20
195
2
46 11
36 0
0
4
14
253
2
46 22
39 0
17
237
2
46 19
6 0
19
227
2
46 17
41 0
22
211
2
46 14
26 0
4
15
259
2
46 23
38 0
18
245
2
46 20
37 0
20
231
2
46 18
36 0
23
217
2
46 15
40 0
4
16
265
2
46 24
25 0
19
249
2
46 21
41 0
21
239
2
46 19
7 0
24
223
2
46 16
43 0
0
2
18
289
2
46 30
37 0
30
233
2
46 18
42 0
4
19
297
2
46 31
41 0
22
267
2
46 24
26 0
24
255
2
46 22
43 0
31
241
2
46 19
44 0
4
20
305
2
46 32
36 0
23
273
2
46 25
40 0
25
261
2
46 23
34 0
32
247
2
46 20
45 0
4
21
313
2
46 33
7 0
24
279
2
46 26
43 0
26
269
2
46 24
12 0
33
251
2
46 21
35 0
2
25
283
2
46 27
34 0
27
275
2
46 25
1 0
0
0
2
28
291
2
46 30
2 0
30
285
2
46 28
42 0
4
22
323
2
46 36
26 0
29
299
2
46 31
11 0
31
287
2
46 29
44 0
35
257
2
46 22
15 0
4
23
327
2
46 37
40 0
30
307
2
46 32
42 0
32
293
2
46 30
45 0
36
263
2
46 23
29 0
4
24
331
2
46 38
43 0
31
315
2
46 33
44 0
33
301
2
46 31
35 0
37
271
2
46 24
32 0
4
25
337
2
46 39
34 0
32
319
2
46 34
45 0
34
309
2
46 32
17 0
38
277
2
46 25
30 0
2
26
341
2
46 40
12 0
39
281
2
46 26
18 0
2
30
345
2
46 42
42 0
40
295
2
46 30
8 0
4
31
349
2
46 43
44 0
35
333
2
46 38
15 0
37
325
2
46 36
32 0
41
303
2
46 31
16 0
4
32
353
2
46 44
45 0
36
339
2
46 39
29 0
38
329
2
46 37
30 0
42
311
2
46 32
22 0
4
33
359
2
46 45
35 0
37
343
2
46 40
32 0
39
335
2
46 38
18 0
43
317
2
46 33
21 0
2
34
365
2
46 46
17 0
44
321
2
46 34
13 0
0
2
40
355
2
46 44
8 0
42
347
2
46 42
22 0
2
41
361
2
46 45
16 0
43
351
2
46 43
21 0
2
42
367
2
46 46
22 0
44
357
2
46 44
13 0
2
43
369
2
46 47
21 0
45
363
2
46 45
3 0
0
end_DTG
begin_CG
4
47 1
48 1
46 3
10 2
4
47 1
48 1
46 3
12 2
4
47 1
48 1
46 4
11 2
4
47 1
48 1
46 3
13 2
5
47 2
48 2
46 6
14 2
9 2
5
47 2
48 2
46 6
9 2
27 2
5
47 2
48 2
46 6
27 2
37 2
5
47 2
48 2
46 6
36 2
34 2
5
47 2
48 2
46 6
15 2
16 2
4
47 1
48 1
46 5
28 2
4
47 1
48 1
46 4
20 2
4
47 1
48 1
46 4
42 2
5
47 2
48 2
46 7
34 2
17 2
5
47 2
48 2
46 7
18 2
21 2
5
47 2
48 2
46 7
23 2
28 2
5
47 2
48 2
46 7
42 2
29 2
5
47 2
48 2
46 7
29 2
22 2
5
47 2
48 2
46 7
35 2
18 2
5
47 2
48 2
46 7
17 2
30 2
5
47 2
48 2
46 7
31 2
25 2
6
47 3
48 3
46 9
24 2
10 2
19 2
6
47 3
48 3
46 9
30 2
22 2
13 2
6
47 3
48 3
46 9
32 2
16 2
21 2
6
47 3
48 3
46 9
14 2
24 2
33 2
6
47 3
48 3
46 9
23 2
20 2
31 2
6
47 3
48 3
46 9
19 2
38 2
36 2
6
47 3
48 3
46 9
37 2
40 2
42 2
5
47 2
48 2
46 8
28 2
39 2
5
47 2
48 2
46 8
33 2
27 2
5
47 2
48 2
46 8
44 2
32 2
5
47 2
48 2
46 8
35 2
32 2
5
47 2
48 2
46 8
33 2
38 2
6
47 3
48 3
46 10
45 2
29 2
30 2
6
47 3
48 3
46 10
28 2
31 2
39 2
6
47 3
48 3
46 10
43 2
12 2
35 2
6
47 3
48 3
46 10
34 2
45 2
30 2
6
47 3
48 3
46 10
25 2
41 2
43 2
6
47 3
48 3
46 10
39 2
41 2
26 2
6
47 3
48 3
46 10
31 2
39 2
41 2
7
47 4
48 4
46 12
33 2
27 2
38 2
37 2
6
47 3
48 3
46 10
41 2
43 2
44 2
7
47 4
48 4
46 12
38 2
37 2
36 2
40 2
7
47 4
48 4
46 12
26 2
11 2
44 2
15 2
7
47 4
48 4
46 12
36 2
40 2
34 2
45 2
7
47 4
48 4
46 12
40 2
42 2
45 2
29 2
7
47 4
48 4
46 12
43 2
44 2
35 2
32 2
48
47 112
48 112
4 4
14 8
23 10
24 10
20 10
10 6
0 2
9 6
28 12
33 14
31 12
19 8
5 4
27 12
39 16
38 14
25 10
6 4
37 14
41 16
36 14
7 4
26 10
40 14
43 16
34 14
12 8
1 2
2 2
11 6
42 16
44 16
45 16
35 14
17 8
15 8
29 12
32 14
30 12
18 8
8 4
16 8
22 10
21 10
13 8
3 2
47
46 112
4 2
14 4
23 5
24 5
20 5
10 3
0 1
9 3
28 6
33 7
31 6
19 4
5 2
27 6
39 8
38 7
25 5
6 2
37 7
41 8
36 7
7 2
26 5
40 7
43 8
34 7
12 4
1 1
2 1
11 3
42 8
44 8
45 8
35 7
17 4
15 4
29 6
32 7
30 6
18 4
8 2
16 4
22 5
21 5
13 4
3 1
47
46 112
4 2
14 4
23 5
24 5
20 5
10 3
0 1
9 3
28 6
33 7
31 6
19 4
5 2
27 6
39 8
38 7
25 5
6 2
37 7
41 8
36 7
7 2
26 5
40 7
43 8
34 7
12 4
1 1
2 1
11 3
42 8
44 8
45 8
35 7
17 4
15 4
29 6
32 7
30 6
18 4
8 2
16 4
22 5
21 5
13 4
3 1
end_CG
