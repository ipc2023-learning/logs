begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var29
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var2
-1
30
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
end_variable
begin_variable
var0
-1
25
Atom at(box1, loc_2_6)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_9)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_5_9)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_9)
Atom at(box1, loc_7_5)
end_variable
begin_variable
var1
-1
27
Atom at(box2, loc_2_6)
Atom at(box2, loc_3_2)
Atom at(box2, loc_3_4)
Atom at(box2, loc_3_5)
Atom at(box2, loc_3_6)
Atom at(box2, loc_3_7)
Atom at(box2, loc_3_8)
Atom at(box2, loc_4_2)
Atom at(box2, loc_4_3)
Atom at(box2, loc_4_4)
Atom at(box2, loc_4_5)
Atom at(box2, loc_4_6)
Atom at(box2, loc_4_9)
Atom at(box2, loc_5_2)
Atom at(box2, loc_5_3)
Atom at(box2, loc_5_4)
Atom at(box2, loc_5_5)
Atom at(box2, loc_5_6)
Atom at(box2, loc_5_7)
Atom at(box2, loc_5_8)
Atom at(box2, loc_5_9)
Atom at(box2, loc_6_4)
Atom at(box2, loc_6_5)
Atom at(box2, loc_6_7)
Atom at(box2, loc_6_9)
Atom at(box2, loc_7_5)
Atom at(box2, loc_7_7)
end_variable
27
begin_mutex_group
3
28 0
29 0
1 0
end_mutex_group
begin_mutex_group
3
28 1
29 1
2 0
end_mutex_group
begin_mutex_group
3
28 2
29 2
9 0
end_mutex_group
begin_mutex_group
3
28 3
29 3
18 0
end_mutex_group
begin_mutex_group
3
28 4
29 4
22 0
end_mutex_group
begin_mutex_group
3
28 5
29 5
13 0
end_mutex_group
begin_mutex_group
3
28 6
29 6
3 0
end_mutex_group
begin_mutex_group
3
28 7
29 7
12 0
end_mutex_group
begin_mutex_group
3
28 8
29 8
17 0
end_mutex_group
begin_mutex_group
3
28 9
29 9
24 0
end_mutex_group
begin_mutex_group
3
28 10
29 10
23 0
end_mutex_group
begin_mutex_group
3
28 11
29 11
19 0
end_mutex_group
begin_mutex_group
3
28 12
29 12
4 0
end_mutex_group
begin_mutex_group
3
28 13
29 13
10 0
end_mutex_group
begin_mutex_group
3
28 14




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
6
12
1
13 0
6
94
2
28 5
3 0
6
95
2
29 5
3 0
12
13
1
19 0
12
96
2
28 11
21 0
12
97
2
29 11
21 0
5
1
14
0
5
15
1
22 0
5
98
2
28 4
18 0
5
99
2
29 4
18 0
7
16
1
3 0
3
6
17
1
13 0
6
100
2
28 5
22 0
6
101
2
29 5
22 0
5
2
18
1
2 0
9
19
1
17 0
9
102
2
28 8
24 0
9
103
2
29 8
24 0
14
20
1
10 0
5
8
21
1
12 0
10
22
1
24 0
10
104
2
28 9
23 0
10
105
2
29 9
23 0
15
23
1
15 0
10
3
24
1
9 0
9
25
1
17 0
9
106
2
28 8
12 0
9
107
2
29 8
12 0
11
26
1
23 0
11
108
2
28 10
19 0
11
109
2
29 10
19 0
16
27
1
25 0
16
110
2
28 15
5 0
16
111
2
29 15
5 0
8
4
28
1
18 0
10
29
1
24 0
10
112
2
28 9
17 0
10
113
2
29 9
17 0
12
30
1
19 0
17
31
1
26 0
17
114
2
28 16
14 0
17
115
2
29 16
14 0
7
5
32
1
22 0
5
116
2
28 4
1 0
5
117
2
29 4
1 0
11
33
1
23 0
11
118
2
28 10
24 0
11
119
2
29 10
24 0
18
34
1
21 0
3
21
35
1
11 0
21
120
2
28 20
6 0
21
121
2
29 20
6 0
6
8
36
1
12 0
8
122
2
28 7
2 0
8
123
2
29 7
2 0
15
37
1
15 0
15
124
2
28 14
25 0
15
125
2
29 14
25 0
5
9
38
1
17 0
14
39
1
10 0
16
40
1
25 0
16
126
2
28 15
26 0
16
127
2
29 15
26 0
10
10
41
1
24 0
10
128
2
28 9
9 0
10
129
2
29 9
9 0
15
42
1
15 0
15
130
2
28 14
10 0
15
131
2
29 14
10 0
17
43
1
26 0
17
132
2
28 16
21 0
17
133
2
29 16
21 0
22
44
1
5 0
12
11
45
1
23 0
11
134
2
28 10
18 0
11
135
2
29 10
18 0
16
46
1
25 0
16
136
2
28 15
15 0
16
137
2
29 15
15 0
18
47
1
21 0
18
138
2
28 17
20 0
18
139
2
29 17
20 0
23
48
1
14 0
23
140
2
28 22
7 0
23
141
2
29 22
7 0
9
12
49
1
19 0
12
142
2
28 11
22 0
12
143
2
29 11
22 0
17
50
1
26 0
17
144
2
28 16
25 0
17
145
2
29 16
25 0
19
51
1
20 0
19
146
2
28 18
16 0
19
147
2
29 18
16 0
8
18
52
1
21 0
18
148
2
28 17
26 0
18
149
2
29 17
26 0
20
53
1
16 0
20
150
2
28 19
11 0
20
151
2
29 19
11 0
24
54
1
8 0
24
152
2
29 23
0 0
5
19
55
1
20 0
19
153
2
28 18
21 0
19
154
2
29 18
21 0
21
56
1
11 0
25
57
0
5
13
58
1
4 0
20
59
1
16 0
20
155
2
28 19
20 0
20
156
2
29 19
20 0
26
60
1
6 0
4
16
61
1
25 0
16
157
2
28 15
24 0
16
158
2
29 15
24 0
23
62
1
14 0
5
17
63
1
26 0
17
159
2
28 16
23 0
17
160
2
29 16
23 0
22
64
1
5 0
27
65
1
7 0
3
19
66
1
20 0
25
67
0
29
68
1
0 0
3
20
69
1
16 0
24
70
1
8 0
26
71
1
6 0
4
21
72
1
11 0
21
161
2
28 20
4 0
21
162
2
29 20
4 0
25
73
0
4
23
74
1
14 0
23
163
2
28 22
26 0
23
164
2
29 22
26 0
28
75
0
2
27
76
1
7 0
29
77
1
0 0
3
24
78
1
8 0
24
165
2
29 23
20 0
28
79
0
end_DTG
begin_DTG
0
0
0
2
2
92
2
27 5
9 0
4
84
2
27 3
22 0
4
0
116
2
27 12
1 0
3
98
2
27 6
18 0
5
88
2
27 4
13 0
11
80
2
27 0
19 0
2
4
100
2
27 7
22 0
6
94
2
27 5
3 0
0
2
1
122
2
27 14
2 0
13
82
2
27 2
10 0
2
7
106
2
27 10
12 0
9
102
2
27 8
24 0
4
2
128
2
27 16
9 0
8
112
2
27 11
17 0
10
104
2
27 9
23 0
15
86
2
27 3
25 0
4
3
134
2
27 17
18 0
9
118
2
27 12
24 0
11
108
2
27 10
19 0
16
90
2
27 4
26 0
2
4
142
2
27 18
22 0
17
96
2
27 5
21 0
0
0
2
13
130
2
27 16
10 0
15
124
2
27 14
25 0
4
9
157
2
27 22
24 0
14
136
2
27 17
15 0
16
126
2
27 15
26 0
21
110
2
27 10
5 0
4
10
159
2
27 23
23 0
15
144
2
27 18
25 0
17
132
2
27 16
21 0
22
114
2
27 11
14 0
2
16
148
2
27 19
26 0
18
138
2
27 17
20 0
2
17
153
2
27 20
21 0
19
146
2
27 18
16 0
2
18
155
2
27 21
20 0
20
150
2
27 19
11 0
2
12
161
2
27 26
4 0
23
120
2
27 13
6 0
0
2
16
163
2
27 27
26 0
24
140
2
27 17
7 0
0
0
end_DTG
begin_DTG
0
0
0
2
2
93
2
27 5
9 0
4
85
2
27 3
22 0
4
0
117
2
27 12
1 0
3
99
2
27 6
18 0
5
89
2
27 4
13 0
11
81
2
27 0
19 0
2
4
101
2
27 7
22 0
6
95
2
27 5
3 0
0
2
1
123
2
27 14
2 0
13
83
2
27 2
10 0
2
7
107
2
27 10
12 0
9
103
2
27 8
24 0
4
2
129
2
27 16
9 0
8
113
2
27 11
17 0
10
105
2
27 9
23 0
15
87
2
27 3
25 0
4
3
135
2
27 17
18 0
9
119
2
27 12
24 0
11
109
2
27 10
19 0
16
91
2
27 4
26 0
2
4
143
2
27 18
22 0
17
97
2
27 5
21 0
0
0
2
13
131
2
27 16
10 0
15
125
2
27 14
25 0
4
9
158
2
27 22
24 0
14
137
2
27 17
15 0
16
127
2
27 15
26 0
21
111
2
27 10
5 0
4
10
160
2
27 23
23 0
15
145
2
27 18
25 0
17
133
2
27 16
21 0
22
115
2
27 11
14 0
2
16
149
2
27 19
26 0
18
139
2
27 17
20 0
2
17
154
2
27 20
21 0
19
147
2
27 18
16 0
2
18
156
2
27 21
20 0
20
151
2
27 19
11 0
2
12
162
2
27 26
4 0
24
121
2
27 13
6 0
0
2
16
164
2
27 27
26 0
25
141
2
27 17
7 0
2
18
165
2
27 29
20 0
26
152
2
27 19
0 0
0
0
0
end_DTG
begin_CG
3
29 1
27 3
8 1
4
28 1
29 1
27 4
22 2
4
28 1
29 1
27 3
12 2
4
28 1
29 1
27 3
13 2
4
28 1
29 1
27 3
11 2
4
28 1
29 1
27 4
25 2
4
28 1
29 1
27 4
11 2
4
28 1
29 1
27 4
14 2
1
27 3
5
28 2
29 2
27 6
18 2
24 2
5
28 2
29 2
27 6
12 2
15 2
4
28 1
29 1
27 5
16 2
4
28 1
29 1
27 5
17 2
4
28 1
29 1
27 5
22 2
4
28 1
29 1
27 5
26 2
4
28 1
29 1
27 5
25 2
4
28 1
29 1
27 5
20 2
4
28 1
29 1
27 5
24 2
5
28 2
29 2
27 7
22 2
23 2
5
28 2
29 2
27 7
22 2
23 2
6
28 2
29 3
27 8
21 2
16 2
8 1
6
28 3
29 3
27 9
19 2
26 2
20 2
6
28 3
29 3
27 10
18 2
13 2
19 2
5
28 2
29 2
27 8
24 2
26 2
6
28 3
29 3
27 10
17 2
23 2
25 2
6
28 3
29 3
27 10
24 2
15 2
26 2
7
28 4
29 4
27 12
23 2
25 2
21 2
14 2
29
28 42
29 44
1 2
2 2
9 4
18 8
22 14
13 6
3 2
12 6
17 6
24 14
23 12
19 8
4 2
10 4
15 6
25 14
26 16
21 10
20 9
16 6
11 6
5 2
14 6
8 2
6 2
7 2
0 1
26
27 42
1 1
2 1
9 2
18 4
22 7
13 3
3 1
12 3
17 3
24 7
23 6
19 4
4 1
10 2
15 3
25 7
26 8
21 5
20 4
16 3
11 3
5 1
14 3
6 1
7 1
28
27 44
1 1
2 1
9 2
18 4
22 7
13 3
3 1
12 3
17 3
24 7
23 6
19 4
4 1
10 2
15 3
25 7
26 8
21 5
20 5
16 3
11 3
5 1
14 3
8 2
6 1
7 1
0 1
end_CG
