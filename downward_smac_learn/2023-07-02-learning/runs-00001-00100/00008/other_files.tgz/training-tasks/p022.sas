begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var2
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var1
-1
21
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_5)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_7_3)
end_variable
begin_variable
var0
-1
19
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_5)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_7_3)
end_variable
19
begin_mutex_group
2
20 0
0 0
end_mutex_group
begin_mutex_group
2
20 1
1 0
end_mutex_group
begin_mutex_group
2
20 2
11 0
end_mutex_group
begin_mutex_group
2
20 3
14 0
end_mutex_group
begin_mutex_group
2
20 4
13 0
end_mutex_group
begin_mutex_group
2
20 5
8 0
end_mutex_group
begin_mutex_group
2
20 6
2 0
end_mutex_group
begin_mutex_group
2
20 7
3 0
end_mutex_group
begin_mutex_group
2
20 8
18 0
end_mutex_group
begin_mutex_group
2
20 9
15 0
end_mutex_group
begin_mutex_group
2
20 10
17 0
end_mutex_group
begin_mutex_group
2
20 11
4 0
end_mutex_group
begin_mutex_group
2
20 12
12 0
end_mutex_group
begin_mutex_group
2
20 13
9 0
end_mutex_group
begin_mutex_group
2
20 14
5 0
end_mutex_group
begin_mutex_group
2
20 15
16 0
end_mutex_group
begin_mutex_group
2
20 16
10 0
end_mutex_group
begin_mutex_group
2
20 17
7 0
end_mutex_group
begin_mutex_group
2
20 18
6 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
3
4
end_state
begin_goal
1
20 17
end_goal
84
begin_operator
move loc_2_3 loc_2_4 right
1
1 0
1
0 19 0 1
0
end_operator
begin_operator
move loc_2_3 loc_3_3 down
1
11 0
1
0 19 0 3
0
end_operator
begin_operator
move loc_2_4 loc_2_3 left
1
0 0
1
0 19 1 0
0
end_operator
begin_operator
move loc_2_4 loc_3_4 down
1
14 0
1
0 19 1 4
0
end_operator
begin_operator
move loc_2_7 loc_3_7 down
1
2 0
1
0 19 2 7
0
end_operator
begin_operator
move loc_3_3 loc_2_3 up
1
0 0
1
0 19 3 0
0
end_operator
begin_operator
move loc_3_3 loc_3_4 right
1
14 0
1
0 19 3 4
0
end_operator
begin_operator
move loc_3_3 loc_4_3 down
1
18 0
1
0 19 3 9
0
end_operator
begin_operator
move loc_3_4 loc_2_4 up
1
1 0
1
0 19 4 1
0
end_operator
begin_operator
move loc_3_4 loc_3_3 left
1
11 0
1
0 19 4 3
0
end_operator
begin_operator
move loc_3_4 loc_3_5 right
1
13 0
1
0 19 4 5
0
end_operator
begin_operator
move loc_3_4 loc_4_4 down
1
15 0
1
0 19 4 10
0
end_operator
begin_operator
move loc_3_5 loc_3_4 left
1
14 0
1
0 19 5 4
0
end_operator
begin_operator
move loc_3_5 loc_3_6 right
1
8 0
1
0 19 5 6
0
end_operator
begin_operator
move loc_3_5 loc_4_5 down
1
17 0
1
0 19 5 11
0
end_operator
begin_operator
move loc_3_6 loc_3_5 left
1
13 0
1
0 19 6 5
0
end_operator
begin_operator
move loc_3_6 loc_3_7 right
1
2 0
1
0 19 6 7
0
end_operator
begin_operator
move loc_3_6 loc_4_6 down
1
4 0
1
0 19 6 12
0
end_operator
begin_operator
move loc_3_7 loc_2_7 up
0
1
0 19 7 2
0
end_operator
begin_operator
move loc_3_7 loc_3_6 left
1
8 0
1
0 19 7 6
0
end_operator





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 1
26
check 0
switch 18
check 0
check 1
27
check 0
switch 17
check 0
check 1
28
check 0
check 0
switch 13
check 0
check 1
29
check 0
switch 15
check 0
check 1
30
check 0
switch 4
check 0
check 1
31
check 0
switch 9
check 0
check 1
32
check 0
check 0
switch 8
check 0
check 1
33
check 0
switch 17
check 0
check 1
34
check 0
check 0
switch 3
check 0
check 1
35
check 0
switch 12
check 0
check 1
36
check 0
switch 5
check 0
check 1
37
check 0
check 0
switch 0
check 1
39
check 0
check 0
switch 18
check 0
check 1
38
check 0
switch 16
check 0
check 1
40
check 0
check 0
switch 17
check 0
check 1
41
check 0
switch 7
check 0
check 1
42
check 0
check 0
switch 0
check 1
43
check 0
check 0
switch 16
check 0
check 1
44
check 0
check 0
switch 12
check 0
check 1
45
check 0
switch 5
check 0
check 1
46
check 0
switch 10
check 0
check 1
47
check 0
switch 6
check 0
check 1
48
check 0
check 0
switch 16
check 0
check 1
49
check 0
switch 7
check 0
check 1
50
check 0
check 0
switch 9
check 0
check 1
51
check 0
switch 10
check 0
check 1
52
check 0
check 0
switch 16
check 0
check 1
53
check 0
check 0
check 0
end_SG
begin_DTG
1
1
65
2
20 2
19 9
0
end_DTG
begin_DTG
1
1
68
2
20 3
19 10
0
end_DTG
begin_DTG
1
1
60
2
20 5
19 5
0
end_DTG
begin_DTG
1
1
69
2
20 8
19 10
0
end_DTG
begin_DTG
1
1
70
2
20 10
19 10
0
end_DTG
begin_DTG
1
1
80
2
20 15
19 18
0
end_DTG
begin_DTG
1
1
75
2
20 15
19 14
0
end_DTG
begin_DTG
2
1
72
2
20 13
19 11
1
79
2
20 16
19 17
0
end_DTG
begin_DTG
1
1
58
2
20 4
19 4
2
0
60
3
20 5
19 5
2 0
0
63
3
20 5
19 7
13 0
end_DTG
begin_DTG
1
1
61
2
20 10
19 5
2
0
72
3
20 13
19 11
7 0
0
81
3
20 13
19 19
17 0
end_DTG
begin_DTG
1
1
77
2
20 15
19 16
2
0
79
3
20 16
19 17
7 0
0
82
3
20 16
19 19
16 0
end_DTG
begin_DTG
2
1
59
2
20 3
19 5
1
74
2
20 8
19 14
2
0
54
3
20 2
19 0
18 0
0
65
3
20 2
19 9
0 0
end_DTG
begin_DTG
2
1
57
2
20 8
19 3
1
83
2
20 15
19 20
2
0
67
3
20 12
19 9
16 0
0
78
3
20 12
19 17
18 0
end_DTG
begin_DTG
3
1
56
2
20 3
19 3
1
63
2
20 5
19 7
1
76
2
20 10
19 15
2
0
58
3
20 4
19 4
8 0
0
62
3
20 4
19 6
14 0
end_DTG
begin_DTG
1
1
62
2
20 4
19 6
4
0
55
3
20 3
19 1
15 0
0
56
3
20 3
19 3
13 0
0
59
3
20 3
19 5
11 0
0
68
3
20 3
19 10
1 0
end_DTG
begin_DTG
3
1
55
2
20 3
19 1
1
64
2
20 8
19 8
1
73
2
20 10
19 12
2
0
66
3
20 9
19 9
17 0
0
71
3
20 9
19 11
18 0
end_DTG
begin_DTG
2
1
67
2
20 12
19 9
1
82
2
20 16
19 19
4
0
75
3
20 15
19 14
6 0
0
77
3
20 15
19 16
10 0
0
80
3
20 15
19 18
5 0
0
83
3
20 15
19 20
12 0
end_DTG
begin_DTG
2
1
66
2
20 9
19 9
1
81
2
20 13
19 19
4
0
61
3
20 10
19 5
9 0
0
70
3
20 10
19 10
4 0
0
73
3
20 10
19 12
15 0
0
76
3
20 10
19 15
13 0
end_DTG
begin_DTG
3
1
54
2
20 2
19 0
1
71
2
20 9
19 11
1
78
2
20 12
19 17
4
0
57
3
20 8
19 3
12 0
0
64
3
20 8
19 8
15 0
0
69
3
20 8
19 10
3 0
0
74
3
20 8
19 14
11 0
end_DTG
begin_DTG
3
1
0
1
1 0
3
1
1
11 0
3
54
2
20 2
18 0
3
0
2
1
0 0
4
3
1
14 0
4
55
2
20 3
15 0
1
7
4
1
2 0
5
0
5
1
0 0
4
6
1
14 0
4
56
2
20 3
13 0
9
7
1
18 0
9
57
2
20 8
12 0
5
1
8
1
1 0
3
9
1
11 0
5
10
1
13 0
5
58
2
20 4
8 0
10
11
1
15 0
6
4
12
1
14 0
4
59
2
20 3
11 0
6
13
1
8 0
6
60
2
20 5
2 0
11
14
1
17 0
11
61
2
20 10
9 0
4
5
15
1
13 0
5
62
2
20 4
14 0
7
16
1
2 0
12
17
1
4 0
3
2
18
0
6
19
1
8 0
6
63
2
20 5
13 0
3
9
20
1
18 0
9
64
2
20 8
15 0
13
21
0
7
3
22
1
11 0
3
65
2
20 2
0 0
8
23
1
3 0
10
24
1
15 0
10
66
2
20 9
17 0
14
25
1
12 0
14
67
2
20 12
16 0
6
4
26
1
14 0
4
68
2
20 3
1 0
9
27
1
18 0
9
69
2
20 8
3 0
11
28
1
17 0
11
70
2
20 10
4 0
6
5
29
1
13 0
10
30
1
15 0
10
71
2
20 9
18 0
12
31
1
4 0
15
32
1
9 0
15
72
2
20 13
7 0
3
6
33
1
8 0
11
34
1
17 0
11
73
2
20 10
15 0
3
8
35
1
3 0
14
36
1
12 0
16
37
1
5 0
5
9
38
1
18 0
9
74
2
20 8
11 0
13
39
0
17
40
1
16 0
17
75
2
20 15
6 0
3
11
41
1
17 0
11
76
2
20 10
13 0
19
42
1
7 0
3
13
43
0
17
44
1
16 0
17
77
2
20 15
10 0
6
14
45
1
12 0
14
78
2
20 12
18 0
16
46
1
5 0
18
47
1
10 0
18
79
2
20 16
7 0
20
48
1
6 0
3
17
49
1
16 0
17
80
2
20 15
5 0
19
50
1
7 0
4
15
51
1
9 0
15
81
2
20 13
17 0
18
52
1
10 0
18
82
2
20 16
16 0
2
17
53
1
16 0
17
83
2
20 15
12 0
end_DTG
begin_DTG
0
0
2
0
65
2
19 9
0 0
8
54
2
19 0
18 0
4
1
68
2
19 10
1 0
2
59
2
19 5
11 0
4
56
2
19 3
13 0
9
55
2
19 1
15 0
2
3
62
2
19 6
14 0
5
58
2
19 4
8 0
2
4
63
2
19 7
13 0
6
60
2
19 5
2 0
0
0
4
2
74
2
19 14
11 0
7
69
2
19 10
3 0
9
64
2
19 8
15 0
12
57
2
19 3
12 0
2
8
71
2
19 11
18 0
10
66
2
19 9
17 0
4
4
76
2
19 15
13 0
9
73
2
19 12
15 0
11
70
2
19 10
4 0
13
61
2
19 5
9 0
0
2
8
78
2
19 17
18 0
15
67
2
19 9
16 0
2
10
81
2
19 19
17 0
17
72
2
19 11
7 0
0
4
12
83
2
19 20
12 0
14
80
2
19 18
5 0
16
77
2
19 16
10 0
18
75
2
19 14
6 0
2
15
82
2
19 19
16 0
17
79
2
19 17
7 0
0
0
end_DTG
begin_CG
3
20 1
19 3
11 1
3
20 1
19 3
14 1
3
20 1
19 3
8 1
3
20 1
19 3
18 1
3
20 1
19 3
17 1
3
20 1
19 3
16 1
3
20 1
19 2
16 1
4
20 2
19 4
9 1
10 1
3
20 1
19 4
13 1
3
20 1
19 3
17 1
3
20 1
19 3
16 1
4
20 2
19 5
14 1
18 1
4
20 2
19 5
18 1
16 1
5
20 3
19 6
14 1
8 1
17 1
3
20 1
19 5
13 1
5
20 3
19 6
14 1
18 1
17 1
4
20 2
19 6
12 1
10 1
4
20 2
19 6
15 1
9 1
5
20 3
19 7
11 1
15 1
12 1
20
20 30
0 1
1 1
11 4
14 5
13 5
8 3
2 1
3 1
18 7
15 5
17 6
4 1
12 4
9 3
5 1
16 6
10 3
7 2
6 1
20
19 30
0 1
1 1
11 4
14 5
13 5
8 3
2 1
3 1
18 7
15 5
17 6
4 1
12 4
9 3
5 1
16 6
10 3
7 2
6 1
end_CG
