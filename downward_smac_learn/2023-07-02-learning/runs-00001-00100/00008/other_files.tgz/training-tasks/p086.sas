begin_version
3
end_version
begin_metric
0
end_metric
84
begin_variable
var7
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_12_10)
NegatedAtom clear(loc_12_10)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_12_11)
NegatedAtom clear(loc_12_11)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_12_4)
NegatedAtom clear(loc_12_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_12_7)
NegatedAtom clear(loc_12_7)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_5_11)
NegatedAtom clear(loc_5_11)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var74
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var79
-1
2
Atom clear(loc_9_12)
NegatedAtom clear(loc_9_12)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_11)
NegatedAtom clear(loc_11_11)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var63
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_10_5)
NegatedAtom clear(loc_10_5)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var83
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var81
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var67
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var82
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var62
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var76
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_11)
NegatedAtom clear(loc_10_11)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var73
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var77
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var55
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var64
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
end_DTG
begin_CG
6
80 1
81 1
82 1
83 1
79 5
61 4
6
80 1
81 1
82 1
83 1
79 6
61 4
6
80 1
81 1
82 1
83 1
79 6
63 4
6
80 1
81 1
82 1
83 1
79 6
62 4
6
80 1
81 1
82 1
83 1
79 6
20 4
6
80 1
81 1
82 1
83 1
79 5
17 4
6
80 1
81 1
82 1
83 1
79 5
63 4
6
80 1
81 1
82 1
83 1
79 6
16 4
6
80 1
81 1
82 1
83 1
79 5
21 4
6
80 1
81 1
82 1
83 1
79 6
22 4
6
80 1
81 1
82 1
83 1
79 6
23 4
6
80 1
81 1
82 1
83 1
79 5
60 4
6
80 1
81 1
82 1
83 1
79 5
58 4
6
80 1
81 1
82 1
83 1
79 5
59 4
7
80 2
81 2
82 2
83 2
79 10
16 4
72 4
7
80 2
81 2
82 2
83 2
79 10
65 4
64 4
6
80 1
81 1
82 1
83 1
79 7
71 4
6
80 1
81 1
82 1
83 1
79 7
75 4
6
80 1
81 1
82 1
83 1
79 7
46 4
6
80 1
81 1
82 1
83 1
79 6
24 4
7
80 2
81 2
82 2
83 2
79 11
47 4
62 4
7
80 2
81 2
82 2
83 2
79 11
25 4
19 4
7
80 2
81 2
82 2
83 2
79 11
26 4
18 4
7
80 2
81 2
82 2
83 2
79 11
67 4
27 4
7
80 2
81 2
82 2
83 2
79 11
19 4
67 4
7
80 2
81 2
82 2
83 2
79 11
21 4
71 4
7
80 2
81 2
82 2
83 2
79 10
22 4
28 4
7
80 2
81 2
82 2
83 2
79 11
23 4
29 4
7
80 2
81 2
82 2
83 2
79 11
26 4
48 4
7
80 2
81 2
82 2
83 2
79 11
27 4
59 4
7
80 2
81 2
82 2
83 2
79 10
75 4
31 4
7
80 2
81 2
82 2
83 2
79 11
30 4
76 4
7
80 2
81 2
82 2
83 2
79 11
69 4
70 4
7
80 2
81 2
82 2
83 2
79 11
70 4
45 4
7
80 2
81 2
82 2
83 2
79 11
77 4
45 4
7
80 2
81 2
82 2
83 2
79 11
49 4
66 4
7
80 2
81 2
82 2
83 2
79 11
68 4
73 4
7
80 2
81 2
82 2
83 2
79 11
61 4
60 4
7
80 2
81 2
82 2
83 2
79 11
75 4
50 4
7
80 2
81 2
82 2
83 2
79 11
78 4
58 4
7
80 2
81 2
82 2
83 2
79 11
76 4
58 4
7
80 2
81 2
82 2
83 2
79 10
67 4
77 4
7
80 2
81 2
82 2
83 2
79 11
67 4
43 4
7
80 2
81 2
82 2
83 2
79 11
42 4
51 4
7
80 2
81 2
82 2
83 2
79 11
62 4
52 4
8
80 3
81 3
82 3
83 3
79 15
34 4
58 4
33 4
8
80 3
81 3
82 3
83 3
79 15
18 4
35 4
53 4
8
80 3
81 3
82 3
83 3
79 15
69 4
20 4
59 4
8
80 3
81 3
82 3
83 3
79 15
28 4
72 4
36 4
8
80 3
81 3
82 3
83 3
79 15
35 4
73 4
65 4
8
80 3
81 3
82 3
83 3
79 15
64 4
60 4
38 4
8
80 3
81 3
82 3
83 3
79 15
69 4
43 4
59 4
8
80 3
81 3
82 3
83 3
79 15
70 4
63 4
44 4
8
80 3
81 3
82 3
83 3
79 15
46 4
66 4
54 4
8
80 3
81 3
82 3
83 3
79 15
53 4
64 4
60 4
8
80 3
81 3
82 3
83 3
79 15
56 4
74 4
77 4
8
80 3
81 3
82 3
83 3
79 15
71 4
68 4
55 4
8
80 3
81 3
82 3
83 3
79 15
73 4
65 4
78 4
7
80 2
81 2
82 2
83 2
79 12
39 4
40 4
7
80 2
81 2
82 2
83 2
79 12
47 4
29 4
7
80 2
81 2
82 2
83 2
79 12
54 4
37 4
7
80 2
81 2
82 2
83 2
79 12
75 4
37 4
7
80 2
81 2
82 2
83 2
79 12
69 4
44 4
7
80 2
81 2
82 2
83 2
79 12
76 4
52 4
7
80 2
81 2
82 2
83 2
79 12
66 4
50 4
7
80 2
81 2
82 2
83 2
79 12
66 4
57 4
7
80 2
81 2
82 2
83 2
79 12
65 4
64 4
8
80 3
81 3
82 3
83 3
79 16
24 4
41 4
42 4
7
80 2
81 2
82 2
83 2
79 12
72 4
74 4
8
80 3
81 3
82 3
83 3
79 16
32 4
62 4
51 4
8
80 3
81 3
82 3
83 3
79 16
76 4
32 4
33 4
8
80 3
81 3
82 3
83 3
79 16
72 4
25 4
56 4
8
80 3
81 3
82 3
83 3
79 16
48 4
71 4
68 4
8
80 3
81 3
82 3
83 3
79 16
36 4
49 4
74 4
8
80 3
81 3
82 3
83 3
79 16
68 4
73 4
78 4
9
80 4
81 4
82 4
83 4
79 20
61 4
30 4
17 4
38 4
9
80 4
81 4
82 4
83 4
79 20
31 4
70 4
63 4
40 4
9
80 4
81 4
82 4
83 4
79 20
55 4
78 4
41 4
34 4
9
80 4
81 4
82 4
83 4
79 20
74 4
57 4
77 4
39 4
83
80 168
81 168
82 168
83 168
69 28
47 20
0 4
61 24
75 32
30 16
31 16
76 32
70 28
32 16
62 24
20 16
1 4
17 12
2 4
63 24
52 20
44 16
3 4
4 4
5 4
6 4
14 8
16 12
7 4
21 16
8 4
9 4
22 16
26 16
28 16
48 20
72 28
71 28
25 16
19 12
18 12
36 16
68 24
56 20
24 16
10 4
46 20
35 16
49 20
73 28
74 28
55 20
67 28
23 16
53 20
66 24
65 24
57 20
78 32
77 32
41 16
42 16
27 16
54 20
64 24
15 8
39 16
34 16
43 16
29 16
11 4
60 24
50 20
12 4
58 24
45 20
51 20
59 24
13 4
37 16
38 16
40 16
33 16
80
79 168
69 7
47 5
0 1
61 6
75 8
30 4
31 4
76 8
70 7
32 4
62 6
20 4
1 1
17 3
2 1
63 6
52 5
44 4
3 1
4 1
5 1
6 1
14 2
16 3
7 1
21 4
8 1
9 1
22 4
26 4
28 4
48 5
72 7
71 7
25 4
19 3
18 3
36 4
68 6
56 5
24 4
10 1
46 5
35 4
49 5
73 7
74 7
55 5
67 7
23 4
53 5
66 6
65 6
57 5
78 8
77 8
41 4
42 4
27 4
54 5
64 6
15 2
39 4
34 4
43 4
29 4
11 1
60 6
50 5
12 1
58 6
45 5
51 5
59 6
13 1
37 4
38 4
40 4
33 4
80
79 168
69 7
47 5
0 1
61 6
75 8
30 4
31 4
76 8
70 7
32 4
62 6
20 4
1 1
17 3
2 1
63 6
52 5
44 4
3 1
4 1
5 1
6 1
14 2
16 3
7 1
21 4
8 1
9 1
22 4
26 4
28 4
48 5
72 7
71 7
25 4
19 3
18 3
36 4
68 6
56 5
24 4
10 1
46 5
35 4
49 5
73 7
74 7
55 5
67 7
23 4
53 5
66 6
65 6
57 5
78 8
77 8
41 4
42 4
27 4
54 5
64 6
15 2
39 4
34 4
43 4
29 4
11 1
60 6
50 5
12 1
58 6
45 5
51 5
59 6
13 1
37 4
38 4
40 4
33 4
80
79 168
69 7
47 5
0 1
61 6
75 8
30 4
31 4
76 8
70 7
32 4
62 6
20 4
1 1
17 3
2 1
63 6
52 5
44 4
3 1
4 1
5 1
6 1
14 2
16 3
7 1
21 4
8 1
9 1
22 4
26 4
28 4
48 5
72 7
71 7
25 4
19 3
18 3
36 4
68 6
56 5
24 4
10 1
46 5
35 4
49 5
73 7
74 7
55 5
67 7
23 4
53 5
66 6
65 6
57 5
78 8
77 8
41 4
42 4
27 4
54 5
64 6
15 2
39 4
34 4
43 4
29 4
11 1
60 6
50 5
12 1
58 6
45 5
51 5
59 6
13 1
37 4
38 4
40 4
33 4
80
79 168
69 7
47 5
0 1
61 6
75 8
30 4
31 4
76 8
70 7
32 4
62 6
20 4
1 1
17 3
2 1
63 6
52 5
44 4
3 1
4 1
5 1
6 1
14 2
16 3
7 1
21 4
8 1
9 1
22 4
26 4
28 4
48 5
72 7
71 7
25 4
19 3
18 3
36 4
68 6
56 5
24 4
10 1
46 5
35 4
49 5
73 7
74 7
55 5
67 7
23 4
53 5
66 6
65 6
57 5
78 8
77 8
41 4
42 4
27 4
54 5
64 6
15 2
39 4
34 4
43 4
29 4
11 1
60 6
50 5
12 1
58 6
45 5
51 5
59 6
13 1
37 4
38 4
40 4
33 4
end_CG
