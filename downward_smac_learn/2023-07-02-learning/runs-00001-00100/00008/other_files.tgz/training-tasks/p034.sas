begin_version
3
end_version
begin_metric
0
end_metric
33
begin_variable
var4
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var2
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var1
-1
33
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_6)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
end_variable
begin_variable
var0
-1
31
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_6)
Atom at(box1, loc_8_3)
Atom at(box1, loc_8_6)
end_variable
31
begin_mutex_group
2
32 0
8 0
end_mutex_group
begin_mutex_group
2
32 1
12 0
end_mutex_group
begin_mutex_group
2
32 2
0 0
end_mutex_group
begin_mutex_group
2
32 3
1 0
end_mutex_group
begin_mutex_group
2
32 4
2 0
end_mutex_group
begin_mutex_group
2
32 5
23 0
end_mutex_group
begin_mutex_group
2
32 6
18 0
end_mutex_group
begin_mutex_group
2
32 7
9 0
end_mutex_group
begin_mutex_group
2
32 8
24 0
end_mutex_group
begin_mutex_group
2
32 9
10 0
end_mutex_group
begin_mutex_group
2
32 10
21 0
end_mutex_group
begin_mutex_group
2
32 11
20 0
end_mutex_group
begin_mutex_group
2
32 12
17 0
end_mutex_group
begin_mutex_group
2
32 13
27 0
end_mutex_group
begin_mutex_group
2
32 14
13 0
end_mutex_group
begin_mutex_group
2
32 15
25 0
end_mutex_group
begin_mutex_group
2
32 16
29 0
end_mutex_group
begin_mutex_group
2
32 17
22 0
end_mutex_group
begin_mutex_group
2
3




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
end_DTG
begin_DTG
3
1
90
2
32 10
31 5
1
113
2
32 16
31 17
1
131
2
32 22
31 26
2
0
99
3
32 15
31 10
26 0
0
124
3
32 15
31 22
21 0
end_DTG
begin_DTG
2
1
99
2
32 15
31 10
1
134
2
32 26
31 30
4
0
109
3
32 22
31 15
14 0
0
123
3
32 22
31 21
16 0
0
127
3
32 22
31 23
3 0
0
131
3
32 22
31 26
25 0
end_DTG
begin_DTG
2
1
88
2
32 8
31 3
1
130
2
32 19
31 25
4
0
95
3
32 13
31 8
28 0
0
102
3
32 13
31 12
13 0
0
106
3
32 13
31 14
17 0
0
119
3
32 13
31 19
24 0
end_DTG
begin_DTG
2
1
95
2
32 13
31 8
1
114
2
32 18
31 17
4
0
105
3
32 19
31 13
4 0
0
117
3
32 19
31 18
11 0
0
122
3
32 19
31 20
30 0
0
130
3
32 19
31 25
27 0
end_DTG
begin_DTG
3
1
92
2
32 11
31 6
1
116
2
32 17
31 18
1
132
2
32 23
31 27
4
0
101
3
32 16
31 11
16 0
0
108
3
32 16
31 15
22 0
0
113
3
32 16
31 17
25 0
0
126
3
32 16
31 23
20 0
end_DTG
begin_DTG
4
1
94
2
32 12
31 7
1
111
2
32 17
31 16
1
122
2
32 19
31 20
1
133
2
32 24
31 28
4
0
103
3
32 18
31 12
19 0
0
114
3
32 18
31 17
28 0
0
120
3
32 18
31 19
22 0
0
128
3
32 18
31 24
17 0
end_DTG
begin_DTG
4
1
0
1
12 0
1
84
2
32 1
0 0
5
1
1
23 0
5
85
2
32 5
21 0
4
0
2
1
8 0
2
3
1
0 0
6
4
1
18 0
6
86
2
32 6
20 0
2
1
5
1
12 0
1
87
2
32 1
8 0
2
8
6
1
24 0
8
88
2
32 8
27 0
2
5
7
1
23 0
5
89
2
32 5
18 0
5
0
8
1
8 0
4
9
1
2 0
6
10
1
18 0
10
11
1
21 0
10
90
2
32 10
25 0
5
1
12
1
12 0
5
13
1
23 0
5
91
2
32 5
2 0
11
14
1
20 0
11
92
2
32 11
29 0
4
8
15
1
24 0
8
93
2
32 8
10 0
12
16
1
17 0
12
94
2
32 12
30 0
5
3
17
1
1 0
7
18
1
9 0
9
19
1
10 0
13
20
1
27 0
13
95
2
32 13
28 0
4
8
21
1
24 0
8
96
2
32 8
9 0
14
22
1
13 0
14
97
2
32 14
11 0
5
5
23
1
23 0
5
98
2
32 5
8 0
11
24
1
20 0
15
25
1
25 0
15
99
2
32 15
26 0
5
6
26
1
18 0
6
100
2
32 6
12 0
10
27
1
21 0
16
28
1
29 0
16
101
2
32 16
16 0
5
7
29
1
9 0
13
30
1
27 0
13
102
2
32 13
13 0
18
31
1
30 0
18
103
2
32 18
19 0
6
8
32
1
24 0
8
104
2
32 8
1 0
12
33
1
17 0
14
34
1
13 0
19
35
1
28 0
19
105
2
32 19
4 0
4
9
36
1
10 0
13
37
1
27 0
13
106
2
32 13
17 0
20
38
1
11 0
6
10
39
1
21 0
10
107
2
32 10
23 0
16
40
1
29 0
16
108
2
32 16
22 0
22
41
1
26 0
22
109
2
32 22
14 0
7
11
42
1
20 0
11
110
2
32 11
18 0
15
43
1
25 0
17
44
1
22 0
17
111
2
32 17
30 0
23
45
1
16 0
23
112
2
32 23
5 0
4
16
46
1
29 0
16
113
2
32 16
25 0
18
47
1
30 0
18
114
2
32 18
28 0
8
12
48
1
17 0
12
115
2
32 12
9 0
17
49
1
22 0
17
116
2
32 17
29 0
19
50
1
28 0
19
117
2
32 19
11 0
24
51
1
19 0
24
118
2
32 24
15 0
6
13
52
1
27 0
13
119
2
32 13
24 0
18
53
1
30 0
18
120
2
32 18
22 0
20
54
1
11 0
25
55
1
4 0
4
14
56
1
13 0
14
121
2
32 14
10 0
19
57
1
28 0
19
122
2
32 19
30 0
2
22
58
1
26 0
22
123
2
32 22
16 0
6
15
59
1
25 0
15
124
2
32 15
21 0
21
60
1
3 0
23
61
1
16 0
26
62
1
14 0
26
125
2
32 26
6 0
5
16
63
1
29 0
16
126
2
32 16
20 0
22
64
1
26 0
22
127
2
32 22
3 0
27
65
1
5 0
5
18
66
1
30 0
18
128
2
32 18
17 0
25
67
1
4 0
28
68
1
15 0
28
129
2
32 28
7 0
3
19
69
1
28 0
19
130
2
32 19
27 0
24
70
1
19 0
4
22
71
1
26 0
22
131
2
32 22
25 0
27
72
1
5 0
30
73
1
6 0
3
23
74
1
16 0
23
132
2
32 23
29 0
26
75
1
14 0
3
24
76
1
19 0
24
133
2
32 24
30 0
32
77
1
7 0
1
30
78
1
6 0
3
26
79
1
14 0
26
134
2
32 26
26 0
29
80
0
1
32
81
1
7 0
3
28
82
1
15 0
28
135
2
32 28
19 0
31
83
0
end_DTG
begin_DTG
0
2
0
87
2
31 2
8 0
2
84
2
31 0
0 0
0
0
0
4
0
98
2
31 10
8 0
4
91
2
31 6
2 0
6
89
2
31 4
18 0
10
85
2
31 0
21 0
2
1
100
2
31 11
12 0
11
86
2
31 1
20 0
0
4
3
104
2
31 13
1 0
7
96
2
31 9
9 0
9
93
2
31 7
10 0
13
88
2
31 3
27 0
0
2
5
107
2
31 15
23 0
15
90
2
31 5
25 0
2
6
110
2
31 16
18 0
16
92
2
31 6
29 0
2
7
115
2
31 18
9 0
18
94
2
31 7
30 0
4
8
119
2
31 19
24 0
12
106
2
31 14
17 0
14
102
2
31 12
13 0
19
95
2
31 8
28 0
2
9
121
2
31 20
10 0
20
97
2
31 9
11 0
2
10
124
2
31 22
21 0
22
99
2
31 10
26 0
4
11
126
2
31 23
20 0
15
113
2
31 17
25 0
17
108
2
31 15
22 0
23
101
2
31 11
16 0
2
16
116
2
31 18
29 0
18
111
2
31 16
30 0
4
12
128
2
31 24
17 0
17
120
2
31 19
22 0
19
114
2
31 17
28 0
24
103
2
31 12
19 0
4
13
130
2
31 25
27 0
18
122
2
31 20
30 0
20
117
2
31 18
11 0
25
105
2
31 13
4 0
0
0
4
15
131
2
31 26
25 0
21
127
2
31 23
3 0
23
123
2
31 21
16 0
26
109
2
31 15
14 0
2
16
132
2
31 27
29 0
27
112
2
31 16
5 0
2
18
133
2
31 28
30 0
28
118
2
31 18
15 0
0
2
22
134
2
31 30
26 0
29
125
2
31 22
6 0
0
2
24
135
2
31 32
19 0
30
129
2
31 24
7 0
0
0
end_DTG
begin_CG
3
32 1
31 2
12 1
3
32 1
31 2
24 1
3
32 1
31 2
23 1
3
32 1
31 2
26 1
3
32 1
31 3
28 1
3
32 1
31 3
16 1
3
32 1
31 3
14 1
3
32 1
31 3
15 1
4
32 2
31 4
12 1
23 1
4
32 2
31 4
24 1
17 1
4
32 2
31 4
24 1
13 1
4
32 2
31 4
13 1
28 1
3
32 1
31 4
18 1
3
32 1
31 4
27 1
3
32 1
31 4
26 1
3
32 1
31 3
19 1
4
32 2
31 5
29 1
26 1
4
32 2
31 5
27 1
30 1
4
32 2
31 5
23 1
20 1
4
32 2
31 5
30 1
15 1
4
32 2
31 5
18 1
29 1
4
32 2
31 5
23 1
25 1
4
32 2
31 4
29 1
30 1
3
32 1
31 5
21 1
3
32 1
31 5
27 1
5
32 3
31 6
21 1
29 1
26 1
4
32 2
31 6
25 1
14 1
4
32 2
31 6
24 1
28 1
4
32 2
31 6
27 1
30 1
5
32 3
31 7
20 1
22 1
16 1
6
32 4
31 8
17 1
22 1
28 1
19 1
32
32 52
8 2
12 3
0 1
1 1
2 1
23 5
18 4
9 2
24 5
10 2
21 4
20 4
17 4
27 6
13 3
25 5
29 7
22 4
30 8
28 6
11 2
3 1
26 6
16 4
19 4
4 1
14 3
5 1
15 3
6 1
7 1
32
31 52
8 2
12 3
0 1
1 1
2 1
23 5
18 4
9 2
24 5
10 2
21 4
20 4
17 4
27 6
13 3
25 5
29 7
22 4
30 8
28 6
11 2
3 1
26 6
16 4
19 4
4 1
14 3
5 1
15 3
6 1
7 1
end_CG
