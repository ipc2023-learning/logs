begin_version
3
end_version
begin_metric
0
end_metric
40
begin_variable
var3
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var2
-1
37
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
37
Atom at(box1, loc_2_2)
Atom at(box1, loc_2_3)
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_8)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_2)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_7)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
Atom at(box1, loc_8_7)
Atom at(box1, loc_8_8)
end_variable
begin_variable
var1
-1
37
Atom at(box2, loc_2_2)
Atom at(box2, loc_2_3)
Atom at(box2, loc_2_4)
Atom at(box2,




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





2
39 33
5 0
35
102
1
15 0
35
254
2
38 35
7 0
35
255
2
39 35
7 0
7
30
103
1
27 0
30
256
2
38 30
22 0
30
257
2
39 30
22 0
34
104
1
16 0
34
258
2
38 34
12 0
34
259
2
39 34
12 0
36
105
1
7 0
6
31
106
1
14 0
31
260
2
38 31
19 0
31
261
2
39 31
19 0
35
107
1
15 0
35
262
2
38 35
16 0
35
263
2
39 35
16 0
end_DTG
begin_DTG
0
2
0
112
2
37 2
0 0
2
108
2
37 0
23 0
2
1
118
2
37 3
8 0
3
110
2
37 1
13 0
2
2
122
2
37 4
23 0
4
114
2
37 2
6 0
0
0
2
2
152
2
37 12
23 0
12
116
2
37 2
34 0
4
3
158
2
37 13
13 0
6
136
2
37 8
21 0
8
128
2
37 6
31 0
13
120
2
37 3
36 0
4
4
166
2
37 14
6 0
7
142
2
37 9
28 0
9
132
2
37 7
17 0
14
124
2
37 4
32 0
2
8
146
2
37 10
31 0
10
138
2
37 8
11 0
2
5
176
2
37 16
1 0
16
126
2
37 5
24 0
0
4
6
186
2
37 19
21 0
11
160
2
37 13
2 0
13
150
2
37 11
36 0
19
130
2
37 6
33 0
4
7
192
2
37 20
28 0
12
168
2
37 14
34 0
14
154
2
37 12
32 0
20
134
2
37 7
35 0
4
8
200
2
37 21
31 0
13
172
2
37 15
36 0
15
162
2
37 13
29 0
21
140
2
37 8
26 0
4
9
206
2
37 22
17 0
14
178
2
37 16
32 0
16
170
2
37 14
24 0
22
144
2
37 9
30 0
2
10
212
2
37 23
11 0
23
148
2
37 10
25 0
0
2
17
188
2
37 19
3 0
19
182
2
37 17
33 0
4
12
218
2
37 24
34 0
18
194
2
37 20
9 0
20
184
2
37 18
35 0
24
156
2
37 12
4 0
4
13
220
2
37 25
36 0
19
202
2
37 21
33 0
21
190
2
37 19
26 0
25
164
2
37 13
20 0
2
20
208
2
37 22
35 0
22
196
2
37 20
30 0
4
15
224
2
37 26
29 0
21
214
2
37 23
26 0
23
204
2
37 21
25 0
26
174
2
37 15
22 0
2
16
228
2
37 27
24 0
27
180
2
37 16
19 0
0
2
20
232
2
37 28
35 0
28
198
2
37 20
18 0
2
22
238
2
37 30
30 0
30
210
2
37 22
27 0
2
23
242
2
37 31
25 0
31
216
2
37 23
14 0
2
25
248
2
37 33
20 0
33
222
2
37 25
12 0
2
28
240
2
37 30
18 0
30
234
2
37 28
27 0
4
26
256
2
37 35
22 0
29
244
2
37 31
10 0
31
236
2
37 29
14 0
35
226
2
37 26
15 0
2
27
260
2
37 36
19 0
36
230
2
37 27
7 0
0
2
32
252
2
37 34
5 0
34
246
2
37 32
16 0
2
33
258
2
37 35
12 0
35
250
2
37 33
15 0
2
34
262
2
37 36
16 0
36
254
2
37 34
7 0
0
end_DTG
begin_DTG
0
2
0
113
2
37 2
0 0
2
109
2
37 0
23 0
2
1
119
2
37 3
8 0
3
111
2
37 1
13 0
2
2
123
2
37 4
23 0
4
115
2
37 2
6 0
0
0
2
2
153
2
37 12
23 0
12
117
2
37 2
34 0
4
3
159
2
37 13
13 0
6
137
2
37 8
21 0
8
129
2
37 6
31 0
13
121
2
37 3
36 0
4
4
167
2
37 14
6 0
7
143
2
37 9
28 0
9
133
2
37 7
17 0
14
125
2
37 4
32 0
2
8
147
2
37 10
31 0
10
139
2
37 8
11 0
2
5
177
2
37 16
1 0
16
127
2
37 5
24 0
0
4
6
187
2
37 19
21 0
11
161
2
37 13
2 0
13
151
2
37 11
36 0
19
131
2
37 6
33 0
4
7
193
2
37 20
28 0
12
169
2
37 14
34 0
14
155
2
37 12
32 0
20
135
2
37 7
35 0
4
8
201
2
37 21
31 0
13
173
2
37 15
36 0
15
163
2
37 13
29 0
21
141
2
37 8
26 0
4
9
207
2
37 22
17 0
14
179
2
37 16
32 0
16
171
2
37 14
24 0
22
145
2
37 9
30 0
2
10
213
2
37 23
11 0
23
149
2
37 10
25 0
0
2
17
189
2
37 19
3 0
19
183
2
37 17
33 0
4
12
219
2
37 24
34 0
18
195
2
37 20
9 0
20
185
2
37 18
35 0
24
157
2
37 12
4 0
4
13
221
2
37 25
36 0
19
203
2
37 21
33 0
21
191
2
37 19
26 0
25
165
2
37 13
20 0
2
20
209
2
37 22
35 0
22
197
2
37 20
30 0
4
15
225
2
37 26
29 0
21
215
2
37 23
26 0
23
205
2
37 21
25 0
26
175
2
37 15
22 0
2
16
229
2
37 27
24 0
27
181
2
37 16
19 0
0
2
20
233
2
37 28
35 0
28
199
2
37 20
18 0
2
22
239
2
37 30
30 0
30
211
2
37 22
27 0
2
23
243
2
37 31
25 0
31
217
2
37 23
14 0
2
25
249
2
37 33
20 0
33
223
2
37 25
12 0
2
28
241
2
37 30
18 0
30
235
2
37 28
27 0
4
26
257
2
37 35
22 0
29
245
2
37 31
10 0
31
237
2
37 29
14 0
35
227
2
37 26
15 0
2
27
261
2
37 36
19 0
36
231
2
37 27
7 0
0
2
32
253
2
37 34
5 0
34
247
2
37 32
16 0
2
33
259
2
37 35
12 0
35
251
2
37 33
15 0
2
34
263
2
37 36
16 0
36
255
2
37 34
7 0
0
end_DTG
begin_CG
4
38 1
39 1
37 3
8 2
4
38 1
39 1
37 3
11 2
4
38 1
39 1
37 4
34 2
4
38 1
39 1
37 3
9 2
4
38 1
39 1
37 4
33 2
4
38 1
39 1
37 3
12 2
5
38 2
39 2
37 6
13 2
31 2
5
38 2
39 2
37 6
14 2
15 2
4
38 1
39 1
37 4
23 2
4
38 1
39 1
37 5
33 2
4
38 1
39 1
37 5
27 2
5
38 2
39 2
37 7
17 2
24 2
5
38 2
39 2
37 7
18 2
16 2
5
38 2
39 2
37 7
23 2
28 2
5
38 2
39 2
37 7
19 2
27 2
5
38 2
39 2
37 7
27 2
16 2
5
38 2
39 2
37 7
12 2
15 2
5
38 2
39 2
37 7
31 2
29 2
5
38 2
39 2
37 7
20 2
10 2
5
38 2
39 2
37 7
25 2
14 2
5
38 2
39 2
37 7
35 2
18 2
5
38 2
39 2
37 7
28 2
34 2
5
38 2
39 2
37 7
30 2
27 2
6
38 3
39 3
37 9
8 2
13 2
21 2
6
38 3
39 3
37 9
11 2
29 2
25 2
6
38 3
39 3
37 9
24 2
30 2
19 2
6
38 3
39 3
37 9
32 2
35 2
30 2
5
38 2
39 2
37 8
22 2
10 2
5
38 2
39 2
37 8
31 2
36 2
5
38 2
39 2
37 8
32 2
30 2
6
38 3
39 3
37 10
29 2
26 2
22 2
6
38 3
39 3
37 10
28 2
17 2
32 2
6
38 3
39 3
37 10
31 2
36 2
29 2
6
38 3
39 3
37 10
34 2
9 2
35 2
6
38 3
39 3
37 10
21 2
36 2
33 2
7
38 4
39 4
37 12
36 2
33 2
26 2
20 2
7
38 4
39 4
37 12
28 2
34 2
32 2
35 2
39
38 78
39 78
0 2
8 6
23 10
13 8
6 4
1 2
21 8
28 12
31 14
17 8
11 8
2 2
34 14
36 16
32 14
29 12
24 10
3 2
9 6
33 14
35 16
26 10
30 14
25 10
4 2
20 8
22 8
19 8
18 8
10 6
27 12
14 8
5 2
12 8
16 8
15 8
7 4
38
37 78
0 1
8 3
23 5
13 4
6 2
1 1
21 4
28 6
31 7
17 4
11 4
2 1
34 7
36 8
32 7
29 6
24 5
3 1
9 3
33 7
35 8
26 5
30 7
25 5
4 1
20 4
22 4
19 4
18 4
10 3
27 6
14 4
5 1
12 4
16 4
15 4
7 2
38
37 78
0 1
8 3
23 5
13 4
6 2
1 1
21 4
28 6
31 7
17 4
11 4
2 1
34 7
36 8
32 7
29 6
24 5
3 1
9 3
33 7
35 8
26 5
30 7
25 5
4 1
20 4
22 4
19 4
18 4
10 3
27 6
14 4
5 1
12 4
16 4
15 4
7 2
end_CG
