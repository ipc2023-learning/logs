begin_version
3
end_version
begin_metric
0
end_metric
55
begin_variable
var4
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_11)
NegatedAtom clear(loc_3_11)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var53
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var54
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_10)
NegatedAtom clear(loc_5_10)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var3
-1
55
Atom at-robot(loc_10_10)
Atom at-robot(loc_10_11)
Atom at-robot(loc_10_2)
Atom at-robot(loc_10_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_10)
Atom at-robot(loc_3_11)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_10)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_10)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
At




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




DTG
begin_DTG
0
0
0
0
2
5
213
2
51 13
4 0
10
180
2
51 8
42 0
0
2
2
234
2
51 16
2 0
13
168
2
51 5
47 0
2
6
195
2
51 11
14 0
8
183
2
51 9
29 0
2
7
204
2
51 12
17 0
9
189
2
51 10
32 0
2
8
216
2
51 13
29 0
10
198
2
51 11
42 0
4
3
264
2
51 20
3 0
4
207
2
51 12
15 0
9
174
2
51 7
32 0
17
171
2
51 6
44 0
2
4
273
2
51 21
15 0
18
177
2
51 7
26 0
0
4
6
294
2
51 24
14 0
12
243
2
51 17
8 0
14
228
2
51 15
48 0
21
186
2
51 9
50 0
4
7
306
2
51 25
17 0
13
252
2
51 18
47 0
15
237
2
51 16
39 0
22
192
2
51 10
49 0
4
8
315
2
51 26
29 0
14
258
2
51 19
48 0
16
246
2
51 17
40 0
23
201
2
51 11
33 0
4
9
324
2
51 27
32 0
15
267
2
51 20
39 0
17
255
2
51 18
44 0
24
210
2
51 12
34 0
4
10
333
2
51 28
42 0
11
261
2
51 19
18 0
16
222
2
51 14
40 0
25
219
2
51 13
43 0
2
11
342
2
51 29
18 0
26
225
2
51 14
20 0
0
4
12
354
2
51 31
8 0
19
297
2
51 24
9 0
21
282
2
51 22
50 0
28
231
2
51 15
45 0
4
13
363
2
51 32
47 0
20
309
2
51 25
36 0
22
288
2
51 23
49 0
29
240
2
51 16
46 0
4
14
372
2
51 33
48 0
21
318
2
51 26
50 0
23
300
2
51 24
33 0
30
249
2
51 17
10 0
2
22
327
2
51 27
49 0
24
312
2
51 25
34 0
2
23
336
2
51 28
33 0
25
321
2
51 26
43 0
4
17
378
2
51 34
44 0
18
330
2
51 27
26 0
24
276
2
51 21
34 0
31
270
2
51 20
19 0
2
18
384
2
51 35
26 0
32
279
2
51 21
30 0
2
19
396
2
51 37
9 0
34
285
2
51 22
41 0
4
20
405
2
51 38
36 0
27
366
2
51 32
16 0
29
348
2
51 30
46 0
35
291
2
51 23
37 0
4
21
411
2
51 39
50 0
28
375
2
51 33
45 0
30
357
2
51 31
10 0
36
303
2
51 24
24 0
0
2
25
423
2
51 42
43 0
39
339
2
51 28
35 0
2
26
429
2
51 43
20 0
40
345
2
51 29
38 0
0
4
27
441
2
51 45
16 0
33
408
2
51 38
5 0
35
393
2
51 36
37 0
42
351
2
51 30
28 0
4
28
450
2
51 46
45 0
34
414
2
51 39
41 0
36
399
2
51 37
24 0
43
360
2
51 31
25 0
2
29
456
2
51 47
46 0
44
369
2
51 32
27 0
0
2
37
426
2
51 42
6 0
39
417
2
51 40
35 0
4
31
483
2
51 51
19 0
32
420
2
51 41
30 0
38
387
2
51 35
13 0
48
381
2
51 34
31 0
4
32
492
2
51 52
30 0
41
486
2
51 51
7 0
48
438
2
51 44
31 0
49
390
2
51 35
11 0
0
2
34
495
2
51 54
41 0
50
402
2
51 37
12 0
2
42
459
2
51 47
28 0
44
444
2
51 45
27 0
2
43
465
2
51 48
25 0
45
453
2
51 46
23 0
2
44
471
2
51 49
27 0
46
462
2
51 47
22 0
2
45
477
2
51 50
23 0
47
468
2
51 48
21 0
2
46
489
2
51 51
22 0
48
474
2
51 49
31 0
2
40
480
2
51 50
38 0
47
432
2
51 43
21 0
2
0
435
2
51 43
0 0
40
162
2
51 0
38 0
2
1
447
2
51 45
1 0
42
165
2
51 3
28 0
end_DTG
begin_CG
5
52 1
53 1
54 1
51 5
11 3
5
52 1
53 1
54 1
51 5
12 3
5
52 1
53 1
54 1
51 5
14 3
5
52 1
53 1
54 1
51 4
42 3
5
52 1
53 1
54 1
51 4
15 3
5
52 1
53 1
54 1
51 4
41 3
5
52 1
53 1
54 1
51 5
13 3
5
52 1
53 1
54 1
51 5
38 3
6
52 2
53 2
54 2
51 8
47 3
36 3
6
52 2
53 2
54 2
51 8
36 3
16 3
6
52 2
53 2
54 2
51 8
49 3
46 3
5
52 1
53 1
54 1
51 6
38 3
5
52 1
53 1
54 1
51 5
28 3
5
52 1
53 1
54 1
51 6
35 3
6
52 2
53 2
54 2
51 9
17 3
47 3
6
52 2
53 2
54 2
51 9
42 3
18 3
6
52 2
53 2
54 2
51 9
45 3
41 3
6
52 2
53 2
54 2
51 9
29 3
48 3
6
52 2
53 2
54 2
51 9
44 3
26 3
6
52 2
53 2
54 2
51 9
43 3
35 3
6
52 2
53 2
54 2
51 9
26 3
30 3
6
52 2
53 2
54 2
51 9
22 3
31 3
6
52 2
53 2
54 2
51 9
23 3
21 3
6
52 2
53 2
54 2
51 8
27 3
22 3
6
52 2
53 2
54 2
51 9
46 3
37 3
6
52 2
53 2
54 2
51 9
37 3
27 3
7
52 3
53 3
54 3
51 12
18 3
43 3
20 3
7
52 3
53 3
54 3
51 12
24 3
25 3
23 3
7
52 3
53 3
54 3
51 12
41 3
25 3
12 3
7
52 3
53 3
54 3
51 12
17 3
32 3
39 3
7
52 3
53 3
54 3
51 12
20 3
35 3
38 3
7
52 3
53 3
54 3
51 12
35 3
38 3
21 3
7
52 3
53 3
54 3
51 12
29 3
42 3
40 3
7
52 3
53 3
54 3
51 12
39 3
49 3
34 3
7
52 3
53 3
54 3
51 12
40 3
33 3
43 3
6
52 2
53 2
54 2
51 10
19 3
13 3
6
52 2
53 2
54 2
51 10
50 3
45 3
6
52 2
53 2
54 2
51 10
45 3
41 3
7
52 3
53 3
54 3
51 13
30 3
31 3
11 3
6
52 2
53 2
54 2
51 10
48 3
40 3
6
52 2
53 2
54 2
51 10
39 3
44 3
7
52 3
53 3
54 3
51 13
16 3
37 3
28 3
7
52 3
53 3
54 3
51 13
15 3
32 3
44 3
7
52 3
53 3
54 3
51 13
44 3
34 3
19 3
7
52 3
53 3
54 3
51 13
42 3
40 3
43 3
7
52 3
53 3
54 3
51 13
36 3
46 3
37 3
7
52 3
53 3
54 3
51 13
50 3
45 3
24 3
7
52 3
53 3
54 3
51 13
14 3
48 3
50 3
7
52 3
53 3
54 3
51 13
47 3
39 3
49 3
7
52 3
53 3
54 3
51 13
48 3
50 3
33 3
8
52 4
53 4
54 4
51 16
47 3
36 3
49 3
46 3
54
52 112
53 112
54 112
0 3
1 3
2 3
3 3
15 12
4 3
14 12
17 12
29 15
32 15
42 21
18 12
8 6
47 21
48 21
39 18
40 18
44 21
26 15
9 6
36 18
50 24
49 21
33 15
34 15
43 21
20 12
16 12
45 21
46 21
10 6
19 12
30 15
5 3
41 21
37 18
24 12
6 3
13 9
35 18
38 21
7 3
28 15
25 12
27 15
23 12
22 12
21 12
31 15
11 9
12 9
52
51 112
0 1
1 1
2 1
3 1
15 4
4 1
14 4
17 4
29 5
32 5
42 7
18 4
8 2
47 7
48 7
39 6
40 6
44 7
26 5
9 2
36 6
50 8
49 7
33 5
34 5
43 7
20 4
16 4
45 7
46 7
10 2
19 4
30 5
5 1
41 7
37 6
24 4
6 1
13 3
35 6
38 7
7 1
28 5
25 4
27 5
23 4
22 4
21 4
31 5
11 3
12 3
52
51 112
0 1
1 1
2 1
3 1
15 4
4 1
14 4
17 4
29 5
32 5
42 7
18 4
8 2
47 7
48 7
39 6
40 6
44 7
26 5
9 2
36 6
50 8
49 7
33 5
34 5
43 7
20 4
16 4
45 7
46 7
10 2
19 4
30 5
5 1
41 7
37 6
24 4
6 1
13 3
35 6
38 7
7 1
28 5
25 4
27 5
23 4
22 4
21 4
31 5
11 3
12 3
52
51 112
0 1
1 1
2 1
3 1
15 4
4 1
14 4
17 4
29 5
32 5
42 7
18 4
8 2
47 7
48 7
39 6
40 6
44 7
26 5
9 2
36 6
50 8
49 7
33 5
34 5
43 7
20 4
16 4
45 7
46 7
10 2
19 4
30 5
5 1
41 7
37 6
24 4
6 1
13 3
35 6
38 7
7 1
28 5
25 4
27 5
23 4
22 4
21 4
31 5
11 3
12 3
end_CG
