begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var3
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var2
-1
49
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_8)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_2)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




47 22
11 0
4
21
306
2
47 38
36 0
27
270
2
47 31
12 0
29
260
2
47 29
46 0
36
232
2
47 23
32 0
4
22
310
2
47 39
45 0
28
278
2
47 32
37 0
30
264
2
47 30
40 0
37
240
2
47 24
35 0
4
23
316
2
47 40
39 0
29
284
2
47 33
46 0
31
272
2
47 31
41 0
38
246
2
47 25
31 0
4
24
322
2
47 41
30 0
30
290
2
47 34
40 0
32
280
2
47 32
23 0
39
252
2
47 26
34 0
2
31
294
2
47 35
41 0
33
286
2
47 33
28 0
4
25
332
2
47 43
5 0
32
298
2
47 36
23 0
34
292
2
47 34
27 0
41
254
2
47 27
21 0
2
26
336
2
47 44
25 0
42
258
2
47 28
18 0
0
4
28
340
2
47 45
37 0
35
312
2
47 39
11 0
37
304
2
47 37
35 0
43
266
2
47 30
6 0
4
29
342
2
47 46
46 0
36
318
2
47 40
32 0
38
308
2
47 38
31 0
44
274
2
47 31
7 0
2
37
324
2
47 41
35 0
39
314
2
47 39
34 0
4
31
344
2
47 47
41 0
38
328
2
47 42
31 0
40
320
2
47 40
22 0
45
288
2
47 33
8 0
2
39
334
2
47 43
34 0
41
326
2
47 41
21 0
2
40
338
2
47 44
22 0
42
330
2
47 42
18 0
2
34
346
2
47 48
27 0
46
300
2
47 36
9 0
0
0
0
0
end_DTG
begin_DTG
0
0
0
2
0
169
2
47 11
0 0
9
145
2
47 0
44 0
2
1
177
2
47 12
1 0
10
147
2
47 1
42 0
2
2
191
2
47 15
2 0
13
149
2
47 2
26 0
0
2
6
163
2
47 10
3 0
8
157
2
47 8
29 0
2
7
171
2
47 11
17 0
9
159
2
47 9
44 0
4
3
205
2
47 18
13 0
8
179
2
47 12
29 0
10
165
2
47 10
42 0
16
151
2
47 4
43 0
4
4
213
2
47 19
14 0
9
185
2
47 13
44 0
11
173
2
47 11
19 0
17
153
2
47 5
38 0
2
10
189
2
47 14
42 0
12
181
2
47 12
16 0
2
11
193
2
47 15
19 0
13
187
2
47 13
26 0
2
5
221
2
47 21
15 0
19
155
2
47 7
24 0
2
7
229
2
47 23
17 0
21
161
2
47 9
36 0
4
8
235
2
47 24
29 0
14
207
2
47 18
20 0
16
197
2
47 16
43 0
22
167
2
47 10
45 0
4
9
243
2
47 25
44 0
15
215
2
47 19
33 0
17
201
2
47 17
38 0
23
175
2
47 11
39 0
4
10
249
2
47 26
42 0
16
219
2
47 20
43 0
18
209
2
47 18
4 0
24
183
2
47 12
30 0
0
2
13
257
2
47 28
26 0
26
195
2
47 15
25 0
0
4
14
263
2
47 30
20 0
20
237
2
47 24
10 0
22
225
2
47 22
45 0
28
199
2
47 16
37 0
4
15
269
2
47 31
33 0
21
245
2
47 25
36 0
23
231
2
47 23
39 0
29
203
2
47 17
46 0
4
16
277
2
47 32
43 0
22
251
2
47 26
45 0
24
239
2
47 24
30 0
30
211
2
47 18
40 0
2
17
283
2
47 33
38 0
31
217
2
47 19
41 0
0
2
19
297
2
47 36
24 0
34
223
2
47 21
27 0
2
20
303
2
47 37
10 0
35
227
2
47 22
11 0
4
21
307
2
47 38
36 0
27
271
2
47 31
12 0
29
261
2
47 29
46 0
36
233
2
47 23
32 0
4
22
311
2
47 39
45 0
28
279
2
47 32
37 0
30
265
2
47 30
40 0
37
241
2
47 24
35 0
4
23
317
2
47 40
39 0
29
285
2
47 33
46 0
31
273
2
47 31
41 0
38
247
2
47 25
31 0
4
24
323
2
47 41
30 0
30
291
2
47 34
40 0
32
281
2
47 32
23 0
39
253
2
47 26
34 0
2
31
295
2
47 35
41 0
33
287
2
47 33
28 0
4
25
333
2
47 43
5 0
32
299
2
47 36
23 0
34
293
2
47 34
27 0
41
255
2
47 27
21 0
2
26
337
2
47 44
25 0
42
259
2
47 28
18 0
0
4
28
341
2
47 45
37 0
35
313
2
47 39
11 0
37
305
2
47 37
35 0
43
267
2
47 30
6 0
4
29
343
2
47 46
46 0
36
319
2
47 40
32 0
38
309
2
47 38
31 0
44
275
2
47 31
7 0
2
37
325
2
47 41
35 0
39
315
2
47 39
34 0
4
31
345
2
47 47
41 0
38
329
2
47 42
31 0
40
321
2
47 40
22 0
45
289
2
47 33
8 0
2
39
335
2
47 43
34 0
41
327
2
47 41
21 0
2
40
339
2
47 44
22 0
42
331
2
47 42
18 0
2
34
347
2
47 48
27 0
46
301
2
47 36
9 0
0
0
0
0
end_DTG
begin_CG
4
48 1
49 1
47 4
13 2
4
48 1
49 1
47 4
14 2
4
48 1
49 1
47 3
15 2
4
48 1
49 1
47 4
17 2
4
48 1
49 1
47 4
38 2
4
48 1
49 1
47 4
28 2
4
48 1
49 1
47 4
32 2
4
48 1
49 1
47 4
35 2
4
48 1
49 1
47 3
34 2
4
48 1
49 1
47 3
18 2
5
48 2
49 2
47 6
36 2
12 2
5
48 2
49 2
47 6
12 2
32 2
4
48 1
49 1
47 5
37 2
4
48 1
49 1
47 5
44 2
4
48 1
49 1
47 5
42 2
4
48 1
49 1
47 5
26 2
4
48 1
49 1
47 5
19 2
5
48 2
49 2
47 7
29 2
20 2
5
48 2
49 2
47 7
27 2
21 2
5
48 2
49 2
47 7
42 2
16 2
5
48 2
49 2
47 7
33 2
36 2
5
48 2
49 2
47 7
28 2
22 2
5
48 2
49 2
47 7
34 2
21 2
5
48 2
49 2
47 7
41 2
28 2
5
48 2
49 2
47 6
26 2
25 2
5
48 2
49 2
47 7
24 2
27 2
6
48 3
49 3
47 9
15 2
16 2
24 2
6
48 3
49 3
47 9
25 2
28 2
18 2
4
48 1
49 1
47 6
23 2
6
48 3
49 3
47 9
17 2
44 2
33 2
6
48 3
49 3
47 9
38 2
39 2
41 2
6
48 3
49 3
47 9
40 2
35 2
34 2
5
48 2
49 2
47 8
37 2
35 2
5
48 2
49 2
47 8
43 2
45 2
6
48 3
49 3
47 10
41 2
31 2
22 2
6
48 3
49 3
47 10
46 2
32 2
31 2
6
48 3
49 3
47 10
20 2
45 2
37 2
6
48 3
49 3
47 10
36 2
46 2
32 2
6
48 3
49 3
47 10
42 2
43 2
30 2
6
48 3
49 3
47 10
43 2
45 2
40 2
6
48 3
49 3
47 10
39 2
46 2
41 2
7
48 4
49 4
47 12
30 2
40 2
23 2
34 2
7
48 4
49 4
47 12
14 2
44 2
19 2
38 2
7
48 4
49 4
47 12
44 2
33 2
38 2
39 2
7
48 4
49 4
47 12
13 2
29 2
42 2
43 2
7
48 4
49 4
47 12
33 2
36 2
39 2
46 2
7
48 4
49 4
47 12
45 2
37 2
40 2
35 2
49
48 102
49 102
0 2
1 2
2 2
13 6
14 6
15 6
3 2
17 8
29 10
44 16
42 16
19 8
16 6
26 10
20 8
33 12
43 16
38 14
4 2
24 8
10 4
36 14
45 16
39 14
30 10
5 2
25 8
12 6
37 14
46 16
40 14
41 16
23 8
28 10
27 10
11 4
32 12
35 14
31 10
34 14
22 8
21 8
18 8
6 2
7 2
8 2
9 2
48
47 102
0 1
1 1
2 1
13 3
14 3
15 3
3 1
17 4
29 5
44 8
42 8
19 4
16 3
26 5
20 4
33 6
43 8
38 7
4 1
24 4
10 2
36 7
45 8
39 7
30 5
5 1
25 4
12 3
37 7
46 8
40 7
41 8
23 4
28 5
27 5
11 2
32 6
35 7
31 5
34 7
22 4
21 4
18 4
6 1
7 1
8 1
9 1
48
47 102
0 1
1 1
2 1
13 3
14 3
15 3
3 1
17 4
29 5
44 8
42 8
19 4
16 3
26 5
20 4
33 6
43 8
38 7
4 1
24 4
10 2
36 7
45 8
39 7
30 5
5 1
25 4
12 3
37 7
46 8
40 7
41 8
23 4
28 5
27 5
11 2
32 6
35 7
31 5
34 7
22 4
21 4
18 4
6 1
7 1
8 1
9 1
end_CG
