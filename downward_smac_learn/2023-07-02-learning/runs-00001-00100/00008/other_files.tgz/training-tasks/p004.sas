begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var2
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var1
-1
9
Atom at-robot(loc_2_4)
Atom at-robot(loc_3_4)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_5_4)
Atom at-robot(loc_6_4)
end_variable
begin_variable
var0
-1
9
Atom at(box1, loc_2_4)
Atom at(box1, loc_3_4)
Atom at(box1, loc_4_2)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_5_4)
Atom at(box1, loc_6_4)
end_variable
9
begin_mutex_group
2
10 0
0 0
end_mutex_group
begin_mutex_group
2
10 1
4 0
end_mutex_group
begin_mutex_group
2
10 2
1 0
end_mutex_group
begin_mutex_group
2
10 3
5 0
end_mutex_group
begin_mutex_group
2
10 4
8 0
end_mutex_group
begin_mutex_group
2
10 5
6 0
end_mutex_group
begin_mutex_group
2
10 6
2 0
end_mutex_group
begin_mutex_group
2
10 7
7 0
end_mutex_group
begin_mutex_group
2
10 8
3 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
1
6
4
end_state
begin_goal
1
10 2
end_goal
28
begin_operator
move loc_2_4 loc_3_4 down
1
4 0
1
0 9 0 1
0
end_operator
begin_operator
move loc_3_4 loc_2_4 up
1
0 0
1
0 9 1 0
0
end_operator
begin_operator
move loc_3_4 loc_4_4 down
1
8 0
1
0 9 1 4
0
end_operator
begin_operator
move loc_4_2 loc_4_3 right
1
5 0
1
0 9 2 3
0
end_operator
begin_operator
move loc_4_3 loc_4_2 left
1
1 0
1
0 9 3 2
0
end_operator
begin_operator
move loc_4_3 loc_4_4 right
1
8 0
1
0 9 3 4
0
end_operator
begin_operator
move loc_4_4 loc_3_4 up
1
4 0
1
0 9 4 1
0
end_operator
begin_operator
move loc_4_4 loc_4_3 left
1
5 0
1
0 9 4 3
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
1
6 0
1
0 9 4 5
0
end_operator
begin_operator
move loc_4_4 loc_5_4 down
1
7 0
1
0 9 4 7
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
1
8 0
1
0 9 5 4
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
1
2 0
1
0 9 5 6
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
1
6 0
1
0 9 6 5
0
end_operator
begin_operator
move loc_5_4 loc_4_4 up
1
8 0
1
0 9 7 4
0
end_operator
begin_operator
move loc_5_4 loc_6_4 down
1
3 0
1
0 9 7 8
0
end_operator
begin_operator
move loc_6_4 loc_5_4 up
1
7 0
1
0 9 8 7
0
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box1
0
4
0 10 1 4
0 9 0 1
0 4 -1 0
0 8 0 1
0
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
0
4
0 10 4 7
0 9 1 4
0 8 -1 0
0 7 0 1
0
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box1
0
4
0 10 3 4
0 9 2 3
0 5 -1 0
0 8 0 1
0
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
0
4
0 10 4 5
0 9 3 4
0 8 -1 0
0 6 0 1
0
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box1
0
4
0 10 1 0
0 9 4 1
0 0 0 1
0 4 -1 0
0
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
0
4
0 10 3 2
0 9 4 3
0 1 0 1
0 5 -1 0
0
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
0
4
0 10 5 6
0 9 4 5
0 6 -1 0
0 2 0 1
0
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
0
4
0 10 7 8
0 9 4 7
0 7 -1 0
0 3 0 1
0
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
0
4
0 10 4 3
0 9 5 4
0 5 0 1
0 8 -1 0
0
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
0
4
0 10 5 4
0 9 6 5
0 8 0 1
0 6 -1 0
0
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
0
4
0 10 4 1
0 9 7 4
0 4 0 1
0 8 -1 0
0
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
0
4
0 10 7 4
0 9 8 7
0 8 0 1
0 7 -1 0
0
end_operator
0
begin_SG
switch 10
check 0
check 0
switch 9
check 0
switch 8
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
20
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 0
check 0
switch 8
check 0
check 1
18
check 0
check 0
check 0
switch 1
check 0
check 1
21
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 0
switch 7
check 0
check 1
17
check 0
check 0
check 0
switch 6
check 0
check 1
19
check 0
check 0
check 0
switch 5
check 0
check 1
24
check 0
check 0
check 0
switch 4
check 0
check 1
26
check 0
check 0
check 0
check 0
switch 9
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
22
check 0
check 0
check 0
switch 8
check 0
check 1
25
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
27
check 0
check 0
check 0
check 0
switch 9
check 0
switch 4
check 0
check 1
0
check 0
check 0
switch 0
check 0
check 1
1
check 0
switch 8
check 0
check 1
2
check 0
check 0
switch 5
check 0
check 1
3
check 0
check 0
switch 1
check 0
check 1
4
check 0
switch 8
check 0
check 1
5
check 0
check 0
switch 4
check 0
check 1
6
check 0
switch 5
check 0
check 1
7
check 0
switch 6
check 0
check 1
8
check 0
switch 7
check 0
check 1
9
check 0
check 0
switch 8
check 0
check 1
10
check 0
switch 2
check 0
check 1
11
check 0
check 0
switch 6
check 0
check 1
12
check 0
check 0
switch 8
check 0
check 1
13
check 0
switch 3
check 0
check 1
14
check 0
check 0
switch 7
check 0
check 1
15
check 0
check 0
check 0
end_SG
begin_DTG
1
1
20
2
10 1
9 4
0
end_DTG
begin_DTG
1
1
21
2
10 3
9 4
0
end_DTG
begin_DTG
1
1
22
2
10 5
9 4
0
end_DTG
begin_DTG
1
1
23
2
10 7
9 4
0
end_DTG
begin_DTG
1
1
26
2
10 4
9 7
2
0
16
3
10 1
9 0
8 0
0
20
3
10 1
9 4
0 0
end_DTG
begin_DTG
1
1
24
2
10 4
9 5
2
0
18
3
10 3
9 2
8 0
0
21
3
10 3
9 4
1 0
end_DTG
begin_DTG
1
1
19
2
10 4
9 3
2
0
22
3
10 5
9 4
2 0
0
25
3
10 5
9 6
8 0
end_DTG
begin_DTG
1
1
17
2
10 4
9 1
2
0
23
3
10 7
9 4
3 0
0
27
3
10 7
9 8
8 0
end_DTG
begin_DTG
4
1
16
2
10 1
9 0
1
18
2
10 3
9 2
1
25
2
10 5
9 6
1
27
2
10 7
9 8
4
0
17
3
10 4
9 1
7 0
0
19
3
10 4
9 3
6 0
0
24
3
10 4
9 5
5 0
0
26
3
10 4
9 7
4 0
end_DTG
begin_DTG
2
1
0
1
4 0
1
16
2
10 1
8 0
3
0
1
1
0 0
4
2
1
8 0
4
17
2
10 4
7 0
2
3
3
1
5 0
3
18
2
10 3
8 0
3
2
4
1
1 0
4
5
1
8 0
4
19
2
10 4
6 0
8
1
6
1
4 0
1
20
2
10 1
0 0
3
7
1
5 0
3
21
2
10 3
1 0
5
8
1
6 0
5
22
2
10 5
2 0
7
9
1
7 0
7
23
2
10 7
3 0
3
4
10
1
8 0
4
24
2
10 4
5 0
6
11
1
2 0
2
5
12
1
6 0
5
25
2
10 5
8 0
3
4
13
1
8 0
4
26
2
10 4
4 0
8
14
1
3 0
2
7
15
1
7 0
7
27
2
10 7
8 0
end_DTG
begin_DTG
0
2
0
20
2
9 4
0 0
4
16
2
9 0
8 0
0
2
2
21
2
9 4
1 0
4
18
2
9 2
8 0
4
1
26
2
9 7
4 0
3
24
2
9 5
5 0
5
19
2
9 3
6 0
7
17
2
9 1
7 0
2
4
25
2
9 6
8 0
6
22
2
9 4
2 0
0
2
4
27
2
9 8
8 0
8
23
2
9 4
3 0
0
end_DTG
begin_CG
3
10 1
9 2
4 1
3
10 1
9 2
5 1
3
10 1
9 2
6 1
3
10 1
9 2
7 1
3
10 1
9 3
8 1
3
10 1
9 3
8 1
3
10 1
9 3
8 1
3
10 1
9 3
8 1
6
10 4
9 8
4 1
5 1
6 1
7 1
10
10 12
0 1
4 3
1 1
5 3
8 8
6 3
2 1
7 3
3 1
10
9 12
0 1
4 3
1 1
5 3
8 8
6 3
2 1
7 3
3 1
end_CG
