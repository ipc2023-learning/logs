begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var14
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_10_6)
NegatedAtom clear(loc_10_6)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_8)
NegatedAtom clear(loc_10_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_9_4)
NegatedAtom clear(loc_9_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_2_3)
NegatedAtom clear(loc_2_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_9_7)
NegatedAtom clear(loc_9_7)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_9_6)
NegatedAtom clear(loc_9_6)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_4_9)
NegatedAtom clear(loc_4_9)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_7_9)
NegatedAtom clear(loc_7_9)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_8_9)
NegatedAtom clear(loc_8_9)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_9_9)
NegatedAtom clear(loc_9_9)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_9_8)
NegatedAtom clear(loc_9_8)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var3
-1
46
Atom at-robot(loc_10_6)
Atom at-robot(loc_10_8)
Atom at-robot(loc_10_9)
Atom at-robot(loc_2_3)
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_9)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_9)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_8)
Atom at-robot(loc_4_9)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_5_9)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_7)
Atom at-robot(loc_6_8)
Atom at-robot(loc_6_9)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_7_9)
Atom at-robot(loc_8_10)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_8)
Atom at-robot(loc_8_9)
Atom at-robot(loc_9_10)
Atom at-robot(loc_9_4)
Atom at-robot(loc_9_6)
Atom at-robot(loc_9_7)
Atom at-robot(loc_9_8)
Atom at-robot(loc_9_9)
end_variable
b




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




18
35 0
4
15
300
2
46 33
36 0
22
261
2
46 28
39 0
24
246
2
46 26
32 0
29
197
2
46 19
41 0
2
16
309
2
46 34
31 0
30
206
2
46 20
33 0
2
19
321
2
46 36
44 0
32
225
2
46 23
18 0
2
25
282
2
46 31
30 0
27
270
2
46 29
45 0
4
21
324
2
46 37
43 0
26
294
2
46 32
21 0
28
276
2
46 30
35 0
33
240
2
46 25
26 0
2
27
303
2
46 33
45 0
29
285
2
46 31
41 0
4
23
330
2
46 38
42 0
28
312
2
46 34
35 0
30
297
2
46 32
33 0
34
255
2
46 27
34 0
2
24
339
2
46 39
32 0
35
264
2
46 28
37 0
0
2
25
348
2
46 41
30 0
37
273
2
46 29
10 0
2
27
351
2
46 42
45 0
38
288
2
46 31
23 0
2
29
360
2
46 44
41 0
40
306
2
46 33
40 0
4
30
369
2
46 45
33 0
31
333
2
46 38
8 0
34
318
2
46 35
34 0
41
315
2
46 34
38 0
0
0
2
0
327
2
46 37
1 0
33
127
2
46 0
26 0
2
38
363
2
46 44
23 0
40
354
2
46 42
40 0
4
1
336
2
46 38
2 0
34
130
2
46 1
34 0
39
372
2
46 45
22 0
41
357
2
46 43
38 0
4
2
342
2
46 39
3 0
35
133
2
46 2
37 0
36
366
2
46 44
9 0
40
345
2
46 40
40 0
end_DTG
begin_DTG
0
0
0
0
2
3
144
2
46 5
13 0
5
137
2
46 3
4 0
0
0
2
3
156
2
46 11
13 0
11
138
2
46 3
15 0
2
4
160
2
46 12
16 0
12
141
2
46 4
27 0
2
6
170
2
46 14
5 0
14
147
2
46 6
25 0
0
4
7
174
2
46 15
11 0
10
161
2
46 12
0 0
12
155
2
46 10
27 0
15
148
2
46 7
12 0
2
8
177
2
46 16
19 0
16
151
2
46 8
28 0
0
2
9
201
2
46 20
17 0
20
154
2
46 9
31 0
2
11
211
2
46 22
15 0
22
157
2
46 11
20 0
2
12
217
2
46 23
27 0
23
164
2
46 12
44 0
0
2
17
195
2
46 19
14 0
19
183
2
46 17
36 0
4
13
250
2
46 27
6 0
18
204
2
46 20
24 0
20
189
2
46 18
31 0
27
167
2
46 13
42 0
2
14
259
2
46 28
25 0
28
173
2
46 14
32 0
0
2
21
220
2
46 23
7 0
23
210
2
46 21
44 0
4
16
268
2
46 29
28 0
22
229
2
46 24
20 0
24
214
2
46 22
29 0
29
180
2
46 16
30 0
2
23
235
2
46 25
44 0
25
223
2
46 23
43 0
4
17
280
2
46 31
14 0
24
244
2
46 26
29 0
26
232
2
46 24
39 0
31
186
2
46 17
45 0
4
18
292
2
46 32
24 0
25
253
2
46 27
43 0
27
238
2
46 25
42 0
32
192
2
46 18
35 0
4
19
301
2
46 33
36 0
26
262
2
46 28
39 0
28
247
2
46 26
32 0
33
198
2
46 19
41 0
2
20
310
2
46 34
31 0
34
207
2
46 20
33 0
2
23
322
2
46 36
44 0
36
226
2
46 23
18 0
2
29
283
2
46 31
30 0
31
271
2
46 29
45 0
4
25
325
2
46 37
43 0
30
295
2
46 32
21 0
32
277
2
46 30
35 0
37
241
2
46 25
26 0
2
31
304
2
46 33
45 0
33
286
2
46 31
41 0
4
27
331
2
46 38
42 0
32
313
2
46 34
35 0
34
298
2
46 32
33 0
38
256
2
46 27
34 0
2
28
340
2
46 39
32 0
39
265
2
46 28
37 0
0
2
29
349
2
46 41
30 0
41
274
2
46 29
10 0
2
31
352
2
46 42
45 0
42
289
2
46 31
23 0
2
33
361
2
46 44
41 0
44
307
2
46 33
40 0
4
34
370
2
46 45
33 0
35
334
2
46 38
8 0
38
319
2
46 35
34 0
45
316
2
46 34
38 0
0
0
2
0
328
2
46 37
1 0
37
128
2
46 0
26 0
2
42
364
2
46 44
23 0
44
355
2
46 42
40 0
4
1
337
2
46 38
2 0
38
131
2
46 1
34 0
43
373
2
46 45
22 0
45
358
2
46 43
38 0
4
2
343
2
46 39
3 0
39
134
2
46 2
37 0
40
367
2
46 44
9 0
44
346
2
46 40
40 0
end_DTG
begin_CG
3
49 1
46 2
15 1
5
47 1
48 1
49 1
46 4
23 3
5
47 1
48 1
49 1
46 5
40 3
5
47 1
48 1
49 1
46 5
38 3
5
47 1
48 1
49 1
46 4
16 3
5
47 1
48 1
49 1
46 4
17 3
5
47 1
48 1
49 1
46 5
36 3
5
47 1
48 1
49 1
46 4
20 3
5
47 1
48 1
49 1
46 5
37 3
5
47 1
48 1
49 1
46 5
38 3
5
47 1
48 1
49 1
46 4
18 3
3
49 1
46 4
15 1
3
49 1
46 4
15 1
6
47 1
48 1
49 2
46 6
16 3
11 1
6
47 2
48 2
49 2
46 8
24 3
43 3
4
49 2
46 6
11 1
12 1
5
47 1
48 1
49 1
46 6
19 3
5
47 1
48 1
49 1
46 5
25 3
5
47 1
48 1
49 1
46 5
30 3
5
47 1
48 1
49 1
46 6
27 3
6
47 1
48 1
49 2
46 7
12 1
44 3
5
47 1
48 1
49 1
46 6
45 3
5
47 1
48 1
49 1
46 5
40 3
6
47 2
48 2
49 2
46 9
26 3
22 3
6
47 2
48 2
49 2
46 9
36 3
39 3
6
47 2
48 2
49 2
46 9
17 3
31 3
6
47 2
48 2
49 2
46 8
45 3
23 3
7
47 2
48 2
49 3
46 10
19 3
15 1
28 3
6
47 2
48 2
49 2
46 9
27 3
44 3
6
47 2
48 2
49 2
46 9
44 3
43 3
7
47 3
48 3
49 3
46 12
44 3
21 3
18 3
7
47 3
48 3
49 3
46 12
25 3
36 3
32 3
7
47 3
48 3
49 3
46 12
31 3
42 3
33 3
7
47 3
48 3
49 3
46 12
32 3
41 3
37 3
7
47 3
48 3
49 3
46 12
41 3
37 3
40 3
7
47 3
48 3
49 3
46 12
39 3
45 3
41 3
6
47 2
48 2
49 2
46 10
24 3
42 3
6
47 2
48 2
49 2
46 10
33 3
38 3
6
47 2
48 2
49 2
46 10
37 3
40 3
6
47 2
48 2
49 2
46 10
43 3
42 3
7
47 3
48 3
49 3
46 13
34 3
22 3
38 3
7
47 3
48 3
49 3
46 13
42 3
35 3
34 3
7
47 3
48 3
49 3
46 13
36 3
39 3
41 3
7
47 3
48 3
49 3
46 13
29 3
39 3
45 3
8
47 4
48 4
49 4
46 16
28 3
20 3
29 3
30 3
8
47 4
48 4
49 4
46 16
43 3
21 3
35 3
26 3
49
47 80
48 80
49 88
1 3
2 3
3 3
13 4
16 9
4 3
5 3
11 3
19 9
17 9
0 1
15 6
27 13
6 3
25 12
12 3
28 12
14 6
24 12
36 18
31 15
7 3
20 10
44 24
29 12
43 21
39 18
42 21
32 15
30 15
21 9
45 24
35 15
41 21
33 15
8 3
18 9
26 12
34 15
37 18
9 3
10 3
23 12
22 9
40 21
38 18
43
46 80
1 1
2 1
3 1
13 1
16 3
4 1
5 1
19 3
17 3
27 4
6 1
25 4
28 4
14 2
24 4
36 6
31 5
7 1
20 3
44 8
29 4
43 7
39 6
42 7
32 5
30 5
21 3
45 8
35 5
41 7
33 5
8 1
18 3
26 4
34 5
37 6
9 1
10 1
23 4
22 3
40 7
38 6
43
46 80
1 1
2 1
3 1
13 1
16 3
4 1
5 1
19 3
17 3
27 4
6 1
25 4
28 4
14 2
24 4
36 6
31 5
7 1
20 3
44 8
29 4
43 7
39 6
42 7
32 5
30 5
21 3
45 8
35 5
41 7
33 5
8 1
18 3
26 4
34 5
37 6
9 1
10 1
23 4
22 3
40 7
38 6
47
46 88
1 1
2 1
3 1
13 2
16 3
4 1
5 1
11 3
19 3
17 3
0 1
15 6
27 5
6 1
25 4
12 3
28 4
14 2
24 4
36 6
31 5
7 1
20 4
44 8
29 4
43 7
39 6
42 7
32 5
30 5
21 3
45 8
35 5
41 7
33 5
8 1
18 3
26 4
34 5
37 6
9 1
10 1
23 4
22 3
40 7
38 6
end_CG
