begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var2
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_8_4)
NegatedAtom clear(loc_8_4)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_8_8)
NegatedAtom clear(loc_8_8)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_2_7)
NegatedAtom clear(loc_2_7)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_8_7)
NegatedAtom clear(loc_8_7)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_2_5)
NegatedAtom clear(loc_2_5)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var1
-1
28
Atom at-robot(loc_2_4)
Atom at-robot(loc_2_5)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_7)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_4)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_7)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_7_8)
Atom at-robot(loc_8_3)
Atom at-robot(loc_8_4)
Atom at-robot(loc_8_6)
Atom at-robot(loc_8_7)
Atom at-robot(loc_8_8)
end_variable
begin_variable
var0
-1
27
Atom at(box1, loc_2_4)
Atom at(box1, loc_2_5)
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_7)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_4)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_7)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_7_8)
Atom at(box1, loc_8_4)
Atom at(box1, loc_8_6)
Atom at(box1, loc_8_7)
Atom at(box1, loc_8_8)
end_variable
27
begin_mutex_group
2
28 0
0 0
end_mutex_group
begin_mutex_group
2
28 1
14 0
end_mutex_group
begin_mutex_group
2
28 2
15 0
end_mutex_group
begin_mutex_group
2
28 3
7 0
end_mutex_group
begin_mutex_group
2
28 4
17 0
end_mutex_group
begin_mutex_group
2
28 5
22 0
end_mutex_group
begin_mutex_group
2
28 6
12 0
end_mutex_group
begin_mutex_group
2
28 7
8 0
end_mutex_group
begin_mutex_group
2
28 8
26 0
end_mutex_group
begin_mutex_group
2
28 9
24 0
end_mutex_group
begin_mutex_group
2
28 10
9 0
end_mutex_group
begin_mutex_group
2
28 11
1 0
end_mutex_group
begin_mutex_group
2
28 12
23 0
end_mutex_group
begin_mutex_group
2
28 13
25 0
end_mutex_group
begin_mutex_group
2
28 14
10 0
end_mutex_group
begin_mutex_group
2
28 15
18 0
end_mutex_group
begin_mutex_group
2
28 16
13 0
end_mutex_group
begin_mutex_group
2
28 17
2 0
end_mutex_group
begin_mutex_group
2
28 18
16 0
end_mutex_group
begin_mutex_group
2
28 19
19 0
end_mutex_group
begin_mutex_group
2
28 20
20 0
end_mutex_group
begin_mutex_group
2
28 21
21 0
end_mutex_group
begin_mutex_group
2
28 22
3 0
end_mutex_group
begin_mutex_group
2
28 23
4 0
end_mutex_group
begin_mutex_group
2
28 24
5 0
end_mutex_group
begin_mutex_group
2
28 25
11 0
end_mutex_group
begin_mutex_group
2
28 26
6 0
end_mutex_group
begin_state
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
15
9
end_state
begin_goal
1
28 10
end_goal
118
begin_operator
move loc_2_4 loc_2_5 right




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





79
2
28 2
27 3
1
87
2
28 4
27 8
2
0
74
3
28 1
27 0
15 0
0
77
3
28 1
27 2
0 0
end_DTG
begin_DTG
2
1
74
2
28 1
27 0
1
90
2
28 5
27 9
2
0
75
3
28 2
27 1
7 0
0
79
3
28 2
27 3
14 0
end_DTG
begin_DTG
2
1
96
2
28 15
27 12
1
110
2
28 19
27 20
2
0
103
3
28 18
27 15
4 0
0
114
3
28 18
27 24
18 0
end_DTG
begin_DTG
2
1
84
2
28 5
27 6
1
97
2
28 8
27 13
2
0
76
3
28 4
27 1
26 0
0
87
3
28 4
27 8
14 0
end_DTG
begin_DTG
2
1
86
2
28 12
27 7
1
114
2
28 18
27 24
2
0
96
3
28 15
27 12
16 0
0
106
3
28 15
27 18
23 0
end_DTG
begin_DTG
2
1
99
2
28 16
27 13
1
112
2
28 20
27 21
2
0
107
3
28 19
27 18
20 0
0
110
3
28 19
27 20
16 0
end_DTG
begin_DTG
2
1
107
2
28 19
27 18
1
113
2
28 21
27 22
2
0
109
3
28 20
27 19
21 0
0
112
3
28 20
27 21
19 0
end_DTG
begin_DTG
1
1
109
2
28 20
27 19
4
0
105
3
28 21
27 17
11 0
0
111
3
28 21
27 20
3 0
0
113
3
28 21
27 22
20 0
0
116
3
28 21
27 26
2 0
end_DTG
begin_DTG
1
1
100
2
28 9
27 14
4
0
78
3
28 5
27 2
24 0
0
81
3
28 5
27 4
12 0
0
84
3
28 5
27 6
17 0
0
90
3
28 5
27 9
15 0
end_DTG
begin_DTG
2
1
101
2
28 13
27 14
1
106
2
28 15
27 18
4
0
86
3
28 12
27 7
18 0
0
94
3
28 12
27 11
25 0
0
98
3
28 12
27 13
1 0
0
102
3
28 12
27 15
8 0
end_DTG
begin_DTG
2
1
78
2
28 5
27 2
1
85
2
28 8
27 7
4
0
83
3
28 9
27 5
10 0
0
88
3
28 9
27 8
9 0
0
93
3
28 9
27 10
26 0
0
100
3
28 9
27 14
22 0
end_DTG
begin_DTG
3
1
82
2
28 8
27 4
1
94
2
28 12
27 11
1
108
2
28 16
27 19
4
0
89
3
28 13
27 8
13 0
0
95
3
28 13
27 12
10 0
0
101
3
28 13
27 14
23 0
0
104
3
28 13
27 16
26 0
end_DTG
begin_DTG
3
1
76
2
28 4
27 1
1
93
2
28 9
27 10
1
104
2
28 13
27 16
4
0
82
3
28 8
27 4
25 0
0
85
3
28 8
27 7
24 0
0
91
3
28 8
27 9
8 0
0
97
3
28 8
27 13
17 0
end_DTG
begin_DTG
2
1
0
1
14 0
1
74
2
28 1
15 0
5
0
1
1
0 0
2
2
1
15 0
2
75
2
28 2
7 0
4
3
1
17 0
4
76
2
28 4
26 0
5
1
4
1
14 0
1
77
2
28 1
0 0
3
5
1
7 0
5
6
1
22 0
5
78
2
28 5
24 0
4
2
7
1
15 0
2
79
2
28 2
14 0
6
8
1
12 0
6
80
2
28 6
9 0
5
1
9
1
14 0
5
10
1
22 0
5
81
2
28 5
12 0
8
11
1
26 0
8
82
2
28 8
25 0
5
2
12
1
15 0
4
13
1
17 0
6
14
1
12 0
9
15
1
24 0
9
83
2
28 9
10 0
4
3
16
1
7 0
5
17
1
22 0
5
84
2
28 5
17 0
10
18
1
9 0
4
8
19
1
26 0
8
85
2
28 8
24 0
12
20
1
23 0
12
86
2
28 12
18 0
7
4
21
1
17 0
4
87
2
28 4
14 0
7
22
1
8 0
9
23
1
24 0
9
88
2
28 9
9 0
13
24
1
25 0
13
89
2
28 13
13 0
6
5
25
1
22 0
5
90
2
28 5
15 0
8
26
1
26 0
8
91
2
28 8
8 0
10
27
1
9 0
14
28
1
10 0
4
6
29
1
12 0
6
92
2
28 6
7 0
9
30
1
24 0
9
93
2
28 9
26 0
2
12
31
1
23 0
12
94
2
28 12
25 0
6
7
32
1
8 0
11
33
1
1 0
13
34
1
25 0
13
95
2
28 13
10 0
15
35
1
18 0
15
96
2
28 15
16 0
7
8
36
1
26 0
8
97
2
28 8
17 0
12
37
1
23 0
12
98
2
28 12
1 0
14
38
1
10 0
16
39
1
13 0
16
99
2
28 16
19 0
4
9
40
1
24 0
9
100
2
28 9
22 0
13
41
1
25 0
13
101
2
28 13
23 0
5
12
42
1
23 0
12
102
2
28 12
8 0
16
43
1
13 0
18
44
1
16 0
18
103
2
28 18
4 0
4
13
45
1
25 0
13
104
2
28 13
26 0
15
46
1
18 0
19
47
1
19 0
2
21
48
1
21 0
21
105
2
28 21
11 0
5
15
49
1
18 0
15
106
2
28 15
23 0
19
50
1
19 0
19
107
2
28 19
20 0
24
51
1
4 0
5
16
52
1
13 0
16
108
2
28 16
25 0
18
53
1
16 0
20
54
1
20 0
20
109
2
28 20
21 0
5
19
55
1
19 0
19
110
2
28 19
16 0
21
56
1
21 0
21
111
2
28 21
3 0
25
57
1
5 0
5
17
58
1
2 0
20
59
1
20 0
20
112
2
28 20
19 0
22
60
1
3 0
26
61
1
11 0
3
21
62
1
21 0
21
113
2
28 21
20 0
27
63
1
6 0
1
24
64
1
4 0
3
18
65
1
16 0
18
114
2
28 18
18 0
23
66
0
3
20
67
1
20 0
26
68
1
11 0
26
115
2
28 25
6 0
4
21
69
1
21 0
21
116
2
28 21
2 0
25
70
1
5 0
27
71
1
6 0
3
22
72
1
3 0
26
73
1
11 0
26
117
2
28 25
5 0
end_DTG
begin_DTG
0
2
0
77
2
27 2
0 0
2
74
2
27 0
15 0
2
1
79
2
27 3
14 0
3
75
2
27 1
7 0
0
2
1
87
2
27 8
14 0
8
76
2
27 1
26 0
4
2
90
2
27 9
15 0
4
84
2
27 6
17 0
6
81
2
27 4
12 0
9
78
2
27 2
24 0
2
3
92
2
27 10
7 0
10
80
2
27 3
9 0
0
4
4
97
2
27 13
17 0
7
91
2
27 9
8 0
9
85
2
27 7
24 0
13
82
2
27 4
25 0
4
5
100
2
27 14
22 0
8
93
2
27 10
26 0
10
88
2
27 8
9 0
14
83
2
27 5
10 0
0
0
4
7
102
2
27 15
8 0
11
98
2
27 13
1 0
13
94
2
27 11
25 0
15
86
2
27 7
18 0
4
8
104
2
27 16
26 0
12
101
2
27 14
23 0
14
95
2
27 12
10 0
16
89
2
27 8
13 0
0
2
12
106
2
27 18
23 0
18
96
2
27 12
16 0
2
13
108
2
27 19
25 0
19
99
2
27 13
19 0
0
2
15
114
2
27 24
18 0
23
103
2
27 15
4 0
2
18
110
2
27 20
16 0
20
107
2
27 18
20 0
2
19
112
2
27 21
19 0
21
109
2
27 19
21 0
4
17
116
2
27 26
2 0
20
113
2
27 22
20 0
22
111
2
27 20
3 0
25
105
2
27 17
11 0
0
0
0
2
24
117
2
27 27
5 0
26
115
2
27 25
6 0
0
end_DTG
begin_CG
3
28 1
27 2
14 1
3
28 1
27 2
23 1
3
28 1
27 2
21 1
3
28 1
27 3
21 1
3
28 1
27 3
16 1
3
28 1
27 3
11 1
3
28 1
27 3
11 1
4
28 2
27 4
15 1
12 1
4
28 2
27 4
26 1
23 1
4
28 2
27 4
12 1
24 1
4
28 2
27 4
24 1
25 1
3
28 1
27 4
21 1
3
28 1
27 4
22 1
3
28 1
27 4
25 1
4
28 2
27 5
15 1
17 1
4
28 2
27 5
14 1
22 1
4
28 2
27 5
18 1
19 1
4
28 2
27 5
22 1
26 1
4
28 2
27 5
23 1
16 1
4
28 2
27 5
13 1
20 1
4
28 2
27 5
19 1
21 1
3
28 1
27 5
20 1
3
28 1
27 5
24 1
4
28 2
27 6
25 1
18 1
4
28 2
27 6
22 1
26 1
5
28 3
27 7
26 1
23 1
13 1
5
28 3
27 7
17 1
24 1
25 1
28
28 44
0 1
14 4
15 4
7 2
17 4
22 5
12 3
8 2
26 7
24 6
9 2
1 1
23 6
25 7
10 2
18 4
13 3
2 1
16 4
19 4
20 4
21 5
3 1
4 1
5 1
11 3
6 1
28
27 44
0 1
14 4
15 4
7 2
17 4
22 5
12 3
8 2
26 7
24 6
9 2
1 1
23 6
25 7
10 2
18 4
13 3
2 1
16 4
19 4
20 4
21 5
3 1
4 1
5 1
11 3
6 1
end_CG
