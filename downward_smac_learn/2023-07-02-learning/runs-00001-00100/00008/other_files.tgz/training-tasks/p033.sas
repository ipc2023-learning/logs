begin_version
3
end_version
begin_metric
0
end_metric
5
begin_variable
var2
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var3
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var1
-1
12
Atom at-robot(loc_2_6)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_4_2)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_5_2)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
end_variable
begin_variable
var0
-1
3
Atom at(box1, loc_3_7)
Atom at(box1, loc_4_7)
Atom at(box1, loc_5_7)
end_variable
3
begin_mutex_group
2
4 0
0 0
end_mutex_group
begin_mutex_group
2
4 1
2 0
end_mutex_group
begin_mutex_group
2
4 2
1 0
end_mutex_group
begin_state
0
0
1
9
1
end_state
begin_goal
1
4 0
end_goal
28
begin_operator
move loc_2_6 loc_3_6 down
0
1
0 3 0 1
0
end_operator
begin_operator
move loc_3_6 loc_2_6 up
0
1
0 3 1 0
0
end_operator
begin_operator
move loc_3_6 loc_3_7 right
1
0 0
1
0 3 1 2
0
end_operator
begin_operator
move loc_3_6 loc_4_6 down
0
1
0 3 1 7
0
end_operator
begin_operator
move loc_3_7 loc_3_6 left
0
1
0 3 2 1
0
end_operator
begin_operator
move loc_3_7 loc_4_7 down
1
2 0
1
0 3 2 8
0
end_operator
begin_operator
move loc_4_2 loc_4_3 right
0
1
0 3 3 4
0
end_operator
begin_operator
move loc_4_2 loc_5_2 down
0
1
0 3 3 9
0
end_operator
begin_operator
move loc_4_3 loc_4_2 left
0
1
0 3 4 3
0
end_operator
begin_operator
move loc_4_3 loc_4_4 right
0
1
0 3 4 5
0
end_operator
begin_operator
move loc_4_4 loc_4_3 left
0
1
0 3 5 4
0
end_operator
begin_operator
move loc_4_4 loc_4_5 right
0
1
0 3 5 6
0
end_operator
begin_operator
move loc_4_5 loc_4_4 left
0
1
0 3 6 5
0
end_operator
begin_operator
move loc_4_5 loc_4_6 right
0
1
0 3 6 7
0
end_operator
begin_operator
move loc_4_6 loc_3_6 up
0
1
0 3 7 1
0
end_operator
begin_operator
move loc_4_6 loc_4_5 left
0
1
0 3 7 6
0
end_operator
begin_operator
move loc_4_6 loc_4_7 right
1
2 0
1
0 3 7 8
0
end_operator
begin_operator
move loc_4_6 loc_5_6 down
0
1
0 3 7 10
0
end_operator
begin_operator
move loc_4_7 loc_3_7 up
1
0 0
1
0 3 8 2
0
end_operator
begin_operator
move loc_4_7 loc_4_6 left
0
1
0 3 8 7
0
end_operator
begin_operator
move loc_4_7 loc_5_7 down
1
1 0
1
0 3 8 11
0
end_operator
begin_operator
move loc_5_2 loc_4_2 up
0
1
0 3 9 3
0
end_operator
begin_operator
move loc_5_6 loc_4_6 up
0
1
0 3 10 7
0
end_operator
begin_operator
move loc_5_6 loc_5_7 right
1
1 0
1
0 3 10 11
0
end_operator
begin_operator
move loc_5_7 loc_4_7 up
1
2 0
1
0 3 11 8
0
end_operator
begin_operator
move loc_5_7 loc_5_6 left
0
1
0 3 11 10
0
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
0
4
0 4 1 2
0 3 2 8
0 2 -1 0
0 1 0 1
0
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
0
4
0 4 1 0
0 3 11 8
0 0 0 1
0 2 -1 0
0
end_operator
0
begin_SG
switch 4
check 0
check 0
switch 3
check 0
check 0
check 0
switch 1
check 0
check 1
26
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
27
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
0
switch 0
check 2
1
3
check 1
2
check 0
check 0
switch 0
check 1
4
check 0
check 0
switch 2
check 0
check 1
5
check 0
check 0
check 2
6
7
check 2
8
9
check 2
10
11
check 2
12
13
switch 0
check 3
14
15
17
check 0
check 0
switch 2
check 0
check 1
16
check 0
check 0
switch 0
check 1
19
check 1
18
check 0
switch 1
check 0
check 1
20
check 0
check 0
check 1
21
switch 0
check 1
22
check 0
check 0
switch 1
check 0
check 1
23
check 0
check 0
switch 0
check 1
25
check 0
check 0
switch 2
check 0
check 1
24
check 0
check 0
check 0
end_SG
begin_DTG
1
1
27
2
4 1
3 11
0
end_DTG
begin_DTG
1
1
26
2
4 1
3 2
0
end_DTG
begin_DTG
0
2
0
26
3
4 1
3 2
1 0
0
27
3
4 1
3 11
0 0
end_DTG
begin_DTG
1
1
0
0
3
0
1
0
2
2
1
0 0
7
3
0
3
1
4
0
8
5
1
2 0
8
26
2
4 1
1 0
2
4
6
0
9
7
0
2
3
8
0
5
9
0
2
4
10
0
6
11
0
2
5
12
0
7
13
0
4
1
14
0
6
15
0
8
16
1
2 0
10
17
0
3
2
18
1
0 0
7
19
0
11
20
1
1 0
1
3
21
0
2
7
22
0
11
23
1
1 0
3
8
24
1
2 0
8
27
2
4 1
0 0
10
25
0
end_DTG
begin_DTG
0
2
0
27
2
3 11
0 0
2
26
2
3 2
1 0
0
end_DTG
begin_CG
3
4 1
3 3
2 1
3
4 1
3 3
2 1
1
3 3
4
4 2
0 1
2 2
1 1
4
3 2
0 1
2 2
1 1
end_CG
