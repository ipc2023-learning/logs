begin_version
3
end_version
begin_metric
0
end_metric
37
begin_variable
var3
-1
2
Atom clear(loc_2_6)
NegatedAtom clear(loc_2_6)
end_variable
begin_variable
var4
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_6_8)
NegatedAtom clear(loc_6_8)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_7_7)
NegatedAtom clear(loc_7_7)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_8_5)
NegatedAtom clear(loc_8_5)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_8_6)
NegatedAtom clear(loc_8_6)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var11
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var6
-1
2
Atom clear(loc_3_3)
NegatedAtom clear(loc_3_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_5_8)
NegatedAtom clear(loc_5_8)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var10
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var12
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_7_4)
NegatedAtom clear(loc_7_4)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_5_3)
NegatedAtom clear(loc_5_3)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_6_4)
NegatedAtom clear(loc_6_4)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_3_5)
NegatedAtom clear(loc_3_5)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_6_6)
NegatedAtom clear(loc_6_6)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_7_6)
NegatedAtom clear(loc_7_6)
end_variable
begin_variable
var9
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_6_5)
NegatedAtom clear(loc_6_5)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_7_5)
NegatedAtom clear(loc_7_5)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var2
-1
35
Atom at-robot(loc_2_2)
Atom at-robot(loc_2_6)
Atom at-robot(loc_2_8)
Atom at-robot(loc_3_2)
Atom at-robot(loc_3_3)
Atom at-robot(loc_3_4)
Atom at-robot(loc_3_5)
Atom at-robot(loc_3_6)
Atom at-robot(loc_3_7)
Atom at-robot(loc_3_8)
Atom at-robot(loc_4_3)
Atom at-robot(loc_4_4)
Atom at-robot(loc_4_5)
Atom at-robot(loc_4_6)
Atom at-robot(loc_4_7)
Atom at-robot(loc_4_8)
Atom at-robot(loc_5_3)
Atom at-robot(loc_5_5)
Atom at-robot(loc_5_6)
Atom at-robot(loc_5_7)
Atom at-robot(loc_5_8)
Atom at-robot(loc_6_2)
Atom at-robot(loc_6_3)
Atom at-robot(loc_6_4)
Atom at-robot(loc_6_5)
Atom at-robot(loc_6_6)
Atom at-robot(loc_6_8)
Atom at-robot(loc_7_2)
Atom at-robot(loc_7_3)
Atom at-robot(loc_7_4)
Atom at-robot(loc_7_5)
Atom at-robot(loc_7_6)
Atom at-robot(loc_7_7)
Atom at-robot(loc_8_5)
Atom at-robot(loc_8_6)
end_variable
begin_variable
var0
-1
34
Atom at(box1, loc_2_6)
Atom at(box1, loc_2_8)
Atom at(box1, loc_3_2)
Atom at(box1, loc_3_3)
Atom at(box1, loc_3_4)
Atom at(box1, loc_3_5)
Atom at(box1, loc_3_6)
Atom at(box1, loc_3_7)
Atom at(box1, loc_3_8)
Atom at(box1, loc_4_3)
Atom at(box1, loc_4_4)
Atom at(box1, loc_4_5)
Atom at(box1, loc_4_6)
Atom at(box1, loc_4_7)
Atom at(box1, loc_4_8)
Atom at(box1, loc_5_3)
Atom at(box1, loc_5_5)
Atom at(box1, loc_5_6)
Atom at(box1, loc_5_7)
Atom at(box1, loc_5_8)
Atom at(box1, loc_6_2)
Atom at(box1, loc_6_3)
Atom at(box1, loc_6_4)
Atom at(box1, loc_6_5)
Atom at(box1, loc_6_6)
Atom at(box1, loc_6_8)
Atom at(box1, loc_7_2)
Atom at(box1, loc_7_3)
Atom at(box1, loc_7_4)
Atom at(box1, loc_7_5)
Atom at(box1, loc_7_6)
Atom at(box1, loc_7_7)
Atom at(box1, loc_8_5)
Atom at(box1, loc_8_6)
end_variable
begin_variable
var1
-1
34
Atom at(box2, loc_2_6)
Atom at(box2, loc_2_8)
Atom at(box2, loc_3_2)
Atom at(box2, loc_3_3)
Atom at(box2, loc_3_4)
Atom at(box2, loc_3_5)
Atom at(box2, loc_3_6)
Atom at(box2, loc_3_7)
Atom at(box2, loc_3_8)
Atom at(box2, loc_4_3)
Atom at(box2, loc_4_4)
Atom at(box2, loc_4_5)
Atom at(box2, loc_4_6)
Atom at(box2, loc_4_7)
Atom at(box2, loc_4_8)
Atom at(box2, loc_5_3)
Atom at(box2, loc_5_5)
Atom at(box2, loc_5_6)
Atom at(box2, loc_5_7)
Atom at(box2, loc_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





76
1
12 0
20
206
2
35 19
21 0
20
207
2
36 19
21 0
4
21
77
1
3 0
28
78
1
13 0
28
208
2
35 27
18 0
28
209
2
36 27
18 0
7
22
79
1
26 0
22
210
2
35 21
19 0
22
211
2
36 21
19 0
27
80
1
5 0
29
81
1
18 0
29
212
2
35 28
32 0
29
213
2
36 28
32 0
7
23
82
1
20 0
28
83
1
13 0
28
214
2
35 27
5 0
28
215
2
36 27
5 0
30
84
1
32 0
30
216
2
35 29
27 0
30
217
2
36 29
27 0
10
24
85
1
31 0
24
218
2
35 23
25 0
24
219
2
36 23
25 0
29
86
1
18 0
29
220
2
35 28
13 0
29
221
2
36 28
13 0
31
87
1
27 0
31
222
2
35 30
6 0
31
223
2
36 30
6 0
33
88
1
7 0
8
25
89
1
24 0
25
224
2
35 24
30 0
25
225
2
36 24
30 0
30
90
1
32 0
30
226
2
35 29
18 0
30
227
2
36 29
18 0
32
91
1
6 0
34
92
1
8 0
3
31
93
1
27 0
31
228
2
35 30
32 0
31
229
2
36 30
32 0
4
30
94
1
32 0
30
230
2
35 29
31 0
30
231
2
36 29
31 0
34
95
1
8 0
4
31
96
1
27 0
31
232
2
35 30
24 0
31
233
2
36 30
24 0
33
97
1
7 0
end_DTG
begin_DTG
0
0
0
2
2
108
2
34 5
2 0
4
102
2
34 3
15 0
2
3
112
2
34 6
11 0
5
104
2
34 4
22 0
2
4
118
2
34 7
15 0
6
110
2
34 5
28 0
4
0
144
2
34 13
0 0
5
124
2
34 8
22 0
7
114
2
34 6
14 0
12
98
2
34 1
33 0
2
6
128
2
34 9
28 0
8
120
2
34 7
10 0
2
1
154
2
34 15
1 0
14
100
2
34 2
21 0
2
3
160
2
34 16
11 0
15
106
2
34 4
19 0
2
9
138
2
34 12
16 0
11
132
2
34 10
29 0
4
5
164
2
34 17
22 0
10
146
2
34 13
9 0
12
136
2
34 11
33 0
16
116
2
34 6
25 0
4
6
170
2
34 18
28 0
11
152
2
34 14
29 0
13
140
2
34 12
23 0
17
122
2
34 7
30 0
4
7
176
2
34 19
14 0
12
156
2
34 15
33 0
14
148
2
34 13
21 0
18
126
2
34 8
17 0
2
8
180
2
34 20
10 0
19
130
2
34 9
12 0
2
9
186
2
34 22
16 0
21
134
2
34 10
26 0
2
11
194
2
34 24
29 0
23
142
2
34 12
31 0
4
12
200
2
34 25
33 0
16
178
2
34 19
25 0
18
166
2
34 17
17 0
24
150
2
34 13
24 0
2
17
182
2
34 20
30 0
19
172
2
34 18
12 0
2
14
206
2
34 26
21 0
25
158
2
34 15
4 0
0
4
15
210
2
34 28
19 0
20
190
2
34 23
3 0
22
184
2
34 21
20 0
27
162
2
34 16
13 0
2
21
196
2
34 24
26 0
23
188
2
34 22
31 0
4
16
218
2
34 30
25 0
22
202
2
34 25
20 0
24
192
2
34 23
24 0
29
168
2
34 17
32 0
2
17
224
2
34 31
30 0
30
174
2
34 18
27 0
0
0
2
26
214
2
34 29
5 0
28
208
2
34 27
18 0
2
27
220
2
34 30
13 0
29
212
2
34 28
32 0
4
23
230
2
34 33
31 0
28
226
2
34 31
18 0
30
216
2
34 29
27 0
32
198
2
34 24
7 0
4
24
232
2
34 34
24 0
29
228
2
34 32
32 0
31
222
2
34 30
6 0
33
204
2
34 25
8 0
0
0
0
end_DTG
begin_DTG
0
0
0
2
2
109
2
34 5
2 0
4
103
2
34 3
15 0
2
3
113
2
34 6
11 0
5
105
2
34 4
22 0
2
4
119
2
34 7
15 0
6
111
2
34 5
28 0
4
0
145
2
34 13
0 0
5
125
2
34 8
22 0
7
115
2
34 6
14 0
12
99
2
34 1
33 0
2
6
129
2
34 9
28 0
8
121
2
34 7
10 0
2
1
155
2
34 15
1 0
14
101
2
34 2
21 0
2
3
161
2
34 16
11 0
15
107
2
34 4
19 0
2
9
139
2
34 12
16 0
11
133
2
34 10
29 0
4
5
165
2
34 17
22 0
10
147
2
34 13
9 0
12
137
2
34 11
33 0
16
117
2
34 6
25 0
4
6
171
2
34 18
28 0
11
153
2
34 14
29 0
13
141
2
34 12
23 0
17
123
2
34 7
30 0
4
7
177
2
34 19
14 0
12
157
2
34 15
33 0
14
149
2
34 13
21 0
18
127
2
34 8
17 0
2
8
181
2
34 20
10 0
19
131
2
34 9
12 0
2
9
187
2
34 22
16 0
21
135
2
34 10
26 0
2
11
195
2
34 24
29 0
23
143
2
34 12
31 0
4
12
201
2
34 25
33 0
16
179
2
34 19
25 0
18
167
2
34 17
17 0
24
151
2
34 13
24 0
2
17
183
2
34 20
30 0
19
173
2
34 18
12 0
2
14
207
2
34 26
21 0
25
159
2
34 15
4 0
0
4
15
211
2
34 28
19 0
20
191
2
34 23
3 0
22
185
2
34 21
20 0
27
163
2
34 16
13 0
2
21
197
2
34 24
26 0
23
189
2
34 22
31 0
4
16
219
2
34 30
25 0
22
203
2
34 25
20 0
24
193
2
34 23
24 0
29
169
2
34 17
32 0
2
17
225
2
34 31
30 0
30
175
2
34 18
27 0
0
0
2
26
215
2
34 29
5 0
28
209
2
34 27
18 0
2
27
221
2
34 30
13 0
29
213
2
34 28
32 0
4
23
231
2
34 33
31 0
28
227
2
34 31
18 0
30
217
2
34 29
27 0
32
199
2
34 24
7 0
4
24
233
2
34 34
24 0
29
229
2
34 32
32 0
31
223
2
34 30
6 0
33
205
2
34 25
8 0
0
0
0
end_DTG
begin_CG
4
35 1
36 1
34 3
28 2
4
35 1
36 1
34 3
10 2
4
35 1
36 1
34 4
11 2
4
35 1
36 1
34 4
26 2
4
35 1
36 1
34 3
12 2
4
35 1
36 1
34 4
13 2
4
35 1
36 1
34 3
27 2
4
35 1
36 1
34 4
32 2
4
35 1
36 1
34 4
27 2
4
35 1
36 1
34 5
29 2
5
35 2
36 2
34 7
14 2
21 2
5
35 2
36 2
34 7
15 2
16 2
5
35 2
36 2
34 7
21 2
17 2
5
35 2
36 2
34 7
26 2
18 2
5
35 2
36 2
34 7
28 2
23 2
5
35 2
36 2
34 7
11 2
22 2
5
35 2
36 2
34 7
9 2
19 2
5
35 2
36 2
34 7
23 2
30 2
5
35 2
36 2
34 7
13 2
32 2
5
35 2
36 2
34 6
16 2
26 2
5
35 2
36 2
34 7
26 2
31 2
6
35 3
36 3
34 9
10 2
23 2
12 2
6
35 3
36 3
34 9
15 2
28 2
29 2
4
35 1
36 1
34 6
33 2
6
35 3
36 3
34 9
30 2
31 2
27 2
6
35 3
36 3
34 9
29 2
30 2
31 2
5
35 2
36 2
34 8
19 2
20 2
5
35 2
36 2
34 8
24 2
32 2
6
35 3
36 3
34 10
22 2
14 2
33 2
6
35 3
36 3
34 10
9 2
33 2
25 2
6
35 3
36 3
34 10
33 2
17 2
24 2
6
35 3
36 3
34 10
25 2
20 2
32 2
6
35 3
36 3
34 10
31 2
18 2
27 2
7
35 4
36 4
34 12
28 2
29 2
23 2
30 2
36
35 68
36 68
0 2
1 2
2 2
11 8
15 8
22 10
28 14
14 8
10 8
16 8
9 6
29 14
33 16
23 10
21 10
19 8
25 10
30 14
17 8
12 8
3 2
26 12
20 8
31 14
24 10
4 2
5 2
13 8
18 8
32 14
27 12
6 2
7 2
8 2
35
34 68
0 1
1 1
2 1
11 4
15 4
22 5
28 7
14 4
10 4
16 4
9 3
29 7
33 8
23 5
21 5
19 4
25 5
30 7
17 4
12 4
3 1
26 6
20 4
31 7
24 5
4 1
5 1
13 4
18 4
32 7
27 6
6 1
7 1
8 1
35
34 68
0 1
1 1
2 1
11 4
15 4
22 5
28 7
14 4
10 4
16 4
9 3
29 7
33 8
23 5
21 5
19 4
25 5
30 7
17 4
12 4
3 1
26 6
20 4
31 7
24 5
4 1
5 1
13 4
18 4
32 7
27 6
6 1
7 1
8 1
end_CG
