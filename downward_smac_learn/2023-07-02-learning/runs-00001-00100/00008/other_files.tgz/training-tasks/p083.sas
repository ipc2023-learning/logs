begin_version
3
end_version
begin_metric
0
end_metric
87
begin_variable
var6
-1
2
Atom clear(loc_10_2)
NegatedAtom clear(loc_10_2)
end_variable
begin_variable
var14
-1
2
Atom clear(loc_11_2)
NegatedAtom clear(loc_11_2)
end_variable
begin_variable
var23
-1
2
Atom clear(loc_2_11)
NegatedAtom clear(loc_2_11)
end_variable
begin_variable
var24
-1
2
Atom clear(loc_2_2)
NegatedAtom clear(loc_2_2)
end_variable
begin_variable
var25
-1
2
Atom clear(loc_2_4)
NegatedAtom clear(loc_2_4)
end_variable
begin_variable
var35
-1
2
Atom clear(loc_4_10)
NegatedAtom clear(loc_4_10)
end_variable
begin_variable
var48
-1
2
Atom clear(loc_5_9)
NegatedAtom clear(loc_5_9)
end_variable
begin_variable
var5
-1
2
Atom clear(loc_10_10)
NegatedAtom clear(loc_10_10)
end_variable
begin_variable
var21
-1
2
Atom clear(loc_11_9)
NegatedAtom clear(loc_11_9)
end_variable
begin_variable
var26
-1
2
Atom clear(loc_2_8)
NegatedAtom clear(loc_2_8)
end_variable
begin_variable
var31
-1
2
Atom clear(loc_3_6)
NegatedAtom clear(loc_3_6)
end_variable
begin_variable
var42
-1
2
Atom clear(loc_4_8)
NegatedAtom clear(loc_4_8)
end_variable
begin_variable
var50
-1
2
Atom clear(loc_6_11)
NegatedAtom clear(loc_6_11)
end_variable
begin_variable
var70
-1
2
Atom clear(loc_8_2)
NegatedAtom clear(loc_8_2)
end_variable
begin_variable
var79
-1
2
Atom clear(loc_9_11)
NegatedAtom clear(loc_9_11)
end_variable
begin_variable
var29
-1
2
Atom clear(loc_3_2)
NegatedAtom clear(loc_3_2)
end_variable
begin_variable
var30
-1
2
Atom clear(loc_3_4)
NegatedAtom clear(loc_3_4)
end_variable
begin_variable
var28
-1
2
Atom clear(loc_3_10)
NegatedAtom clear(loc_3_10)
end_variable
begin_variable
var27
-1
2
Atom clear(loc_2_9)
NegatedAtom clear(loc_2_9)
end_variable
begin_variable
var49
-1
2
Atom clear(loc_6_10)
NegatedAtom clear(loc_6_10)
end_variable
begin_variable
var34
-1
2
Atom clear(loc_3_9)
NegatedAtom clear(loc_3_9)
end_variable
begin_variable
var37
-1
2
Atom clear(loc_4_3)
NegatedAtom clear(loc_4_3)
end_variable
begin_variable
var22
-1
2
Atom clear(loc_2_10)
NegatedAtom clear(loc_2_10)
end_variable
begin_variable
var15
-1
2
Atom clear(loc_11_3)
NegatedAtom clear(loc_11_3)
end_variable
begin_variable
var57
-1
2
Atom clear(loc_6_9)
NegatedAtom clear(loc_6_9)
end_variable
begin_variable
var20
-1
2
Atom clear(loc_11_8)
NegatedAtom clear(loc_11_8)
end_variable
begin_variable
var32
-1
2
Atom clear(loc_3_7)
NegatedAtom clear(loc_3_7)
end_variable
begin_variable
var59
-1
2
Atom clear(loc_7_11)
NegatedAtom clear(loc_7_11)
end_variable
begin_variable
var69
-1
2
Atom clear(loc_8_11)
NegatedAtom clear(loc_8_11)
end_variable
begin_variable
var60
-1
2
Atom clear(loc_7_2)
NegatedAtom clear(loc_7_2)
end_variable
begin_variable
var52
-1
2
Atom clear(loc_6_3)
NegatedAtom clear(loc_6_3)
end_variable
begin_variable
var43
-1
2
Atom clear(loc_5_2)
NegatedAtom clear(loc_5_2)
end_variable
begin_variable
var36
-1
2
Atom clear(loc_4_2)
NegatedAtom clear(loc_4_2)
end_variable
begin_variable
var51
-1
2
Atom clear(loc_6_2)
NegatedAtom clear(loc_6_2)
end_variable
begin_variable
var16
-1
2
Atom clear(loc_11_4)
NegatedAtom clear(loc_11_4)
end_variable
begin_variable
var19
-1
2
Atom clear(loc_11_7)
NegatedAtom clear(loc_11_7)
end_variable
begin_variable
var17
-1
2
Atom clear(loc_11_5)
NegatedAtom clear(loc_11_5)
end_variable
begin_variable
var18
-1
2
Atom clear(loc_11_6)
NegatedAtom clear(loc_11_6)
end_variable
begin_variable
var66
-1
2
Atom clear(loc_7_8)
NegatedAtom clear(loc_7_8)
end_variable
begin_variable
var56
-1
2
Atom clear(loc_6_7)
NegatedAtom clear(loc_6_7)
end_variable
begin_variable
var47
-1
2
Atom clear(loc_5_7)
NegatedAtom clear(loc_5_7)
end_variable
begin_variable
var39
-1
2
Atom clear(loc_4_5)
NegatedAtom clear(loc_4_5)
end_variable
begin_variable
var44
-1
2
Atom clear(loc_5_4)
NegatedAtom clear(loc_5_4)
end_variable
begin_variable
var80
-1
2
Atom clear(loc_9_3)
NegatedAtom clear(loc_9_3)
end_variable
begin_variable
var33
-1
2
Atom clear(loc_3_8)
NegatedAtom clear(loc_3_8)
end_variable
begin_variable
var41
-1
2
Atom clear(loc_4_7)
NegatedAtom clear(loc_4_7)
end_variable
begin_variable
var7
-1
2
Atom clear(loc_10_3)
NegatedAtom clear(loc_10_3)
end_variable
begin_variable
var13
-1
2
Atom clear(loc_10_9)
NegatedAtom clear(loc_10_9)
end_variable
begin_variable
var78
-1
2
Atom clear(loc_9_10)
NegatedAtom clear(loc_9_10)
end_variable
begin_variable
var58
-1
2
Atom clear(loc_7_10)
NegatedAtom clear(loc_7_10)
end_variable
begin_variable
var61
-1
2
Atom clear(loc_7_3)
NegatedAtom clear(loc_7_3)
end_variable
begin_variable
var45
-1
2
Atom clear(loc_5_5)
NegatedAtom clear(loc_5_5)
end_variable
begin_variable
var40
-1
2
Atom clear(loc_4_6)
NegatedAtom clear(loc_4_6)
end_variable
begin_variable
var68
-1
2
Atom clear(loc_8_10)
NegatedAtom clear(loc_8_10)
end_variable
begin_variable
var71
-1
2
Atom clear(loc_8_3)
NegatedAtom clear(loc_8_3)
end_variable
begin_variable
var46
-1
2
Atom clear(loc_5_6)
NegatedAtom clear(loc_5_6)
end_variable
begin_variable
var38
-1
2
Atom clear(loc_4_4)
NegatedAtom clear(loc_4_4)
end_variable
begin_variable
var8
-1
2
Atom clear(loc_10_4)
NegatedAtom clear(loc_10_4)
end_variable
begin_variable
var12
-1
2
A




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 2
82 10
26 4
52 4
7
83 2
84 2
85 2
86 2
82 10
44 4
45 4
7
83 2
84 2
85 2
86 2
82 10
19 4
27 4
7
83 2
84 2
85 2
86 2
82 10
29 4
54 4
7
83 2
84 2
85 2
86 2
82 10
28 4
48 4
6
83 1
84 1
85 1
86 1
82 7
32 4
6
83 1
84 1
85 1
86 1
82 7
56 4
6
83 1
84 1
85 1
86 1
82 7
20 4
6
83 1
84 1
85 1
86 1
82 7
22 4
6
83 1
84 1
85 1
86 1
82 7
49 4
6
83 1
84 1
85 1
86 1
82 7
44 4
6
83 1
84 1
85 1
86 1
82 7
56 4
7
83 2
84 2
85 2
86 2
82 11
18 4
17 4
7
83 2
84 2
85 2
86 2
82 11
46 4
34 4
7
83 2
84 2
85 2
86 2
82 11
19 4
65 4
7
83 2
84 2
85 2
86 2
82 11
58 4
35 4
7
83 2
84 2
85 2
86 2
82 11
44 4
45 4
7
83 2
84 2
85 2
86 2
82 11
49 4
28 4
7
83 2
84 2
85 2
86 2
82 11
27 4
53 4
7
83 2
84 2
85 2
86 2
82 11
33 4
50 4
7
83 2
84 2
85 2
86 2
82 11
70 4
50 4
7
83 2
84 2
85 2
86 2
82 10
32 4
33 4
8
83 3
84 3
85 3
86 3
82 15
15 4
21 4
31 4
8
83 3
84 3
85 3
86 3
82 15
31 4
30 4
29 4
8
83 3
84 3
85 3
86 3
82 15
57 4
23 4
36 4
8
83 3
84 3
85 3
86 3
82 15
62 4
37 4
25 4
8
83 3
84 3
85 3
86 3
82 15
60 4
34 4
37 4
8
83 3
84 3
85 3
86 3
82 15
63 4
36 4
35 4
8
83 3
84 3
85 3
86 3
82 15
69 4
65 4
64 4
8
83 3
84 3
85 3
86 3
82 15
40 4
59 4
69 4
8
83 3
84 3
85 3
86 3
82 15
45 4
55 4
39 4
8
83 3
84 3
85 3
86 3
82 15
56 4
52 4
51 4
8
83 3
84 3
85 3
86 3
82 15
56 4
51 4
70 4
8
83 3
84 3
85 3
86 3
82 15
46 4
54 4
61 4
7
83 2
84 2
85 2
86 2
82 12
26 4
20 4
7
83 2
84 2
85 2
86 2
82 12
52 4
40 4
7
83 2
84 2
85 2
86 2
82 12
57 4
43 4
7
83 2
84 2
85 2
86 2
82 12
58 4
67 4
7
83 2
84 2
85 2
86 2
82 12
53 4
67 4
7
83 2
84 2
85 2
86 2
82 12
65 4
53 4
7
83 2
84 2
85 2
86 2
82 12
73 4
54 4
7
83 2
84 2
85 2
86 2
82 12
55 4
71 4
8
83 3
84 3
85 3
86 3
82 16
41 4
45 4
55 4
8
83 3
84 3
85 3
86 3
82 16
49 4
66 4
48 4
8
83 3
84 3
85 3
86 3
82 16
50 4
72 4
43 4
8
83 3
84 3
85 3
86 3
82 16
52 4
51 4
59 4
9
83 4
84 4
85 4
86 4
82 20
16 4
21 4
41 4
42 4
8
83 3
84 3
85 3
86 3
82 16
46 4
60 4
61 4
8
83 3
84 3
85 3
86 3
82 16
62 4
47 4
68 4
8
83 3
84 3
85 3
86 3
82 16
55 4
71 4
78 4
8
83 3
84 3
85 3
86 3
82 16
57 4
63 4
74 4
8
83 3
84 3
85 3
86 3
82 16
57 4
72 4
74 4
8
83 3
84 3
85 3
86 3
82 16
63 4
58 4
75 4
8
83 3
84 3
85 3
86 3
82 16
60 4
62 4
77 4
8
83 3
84 3
85 3
86 3
82 16
76 4
66 4
68 4
9
83 4
84 4
85 4
86 4
82 20
24 4
49 4
38 4
66 4
9
83 4
84 4
85 4
86 4
82 20
65 4
53 4
64 4
67 4
9
83 4
84 4
85 4
86 4
82 20
47 4
66 4
48 4
68 4
9
83 4
84 4
85 4
86 4
82 20
58 4
64 4
75 4
67 4
9
83 4
84 4
85 4
86 4
82 20
39 4
78 4
38 4
76 4
9
83 4
84 4
85 4
86 4
82 20
42 4
30 4
71 4
73 4
9
83 4
84 4
85 4
86 4
82 20
51 4
70 4
59 4
79 4
9
83 4
84 4
85 4
86 4
82 20
73 4
54 4
81 4
61 4
9
83 4
84 4
85 4
86 4
82 20
70 4
50 4
79 4
72 4
9
83 4
84 4
85 4
86 4
82 20
60 4
81 4
61 4
77 4
9
83 4
84 4
85 4
86 4
82 20
62 4
76 4
77 4
68 4
9
83 4
84 4
85 4
86 4
82 20
69 4
80 4
64 4
75 4
9
83 4
84 4
85 4
86 4
82 20
63 4
80 4
74 4
75 4
9
83 4
84 4
85 4
86 4
82 20
59 4
79 4
69 4
80 4
9
83 4
84 4
85 4
86 4
82 20
71 4
73 4
78 4
81 4
9
83 4
84 4
85 4
86 4
82 20
78 4
81 4
76 4
77 4
9
83 4
84 4
85 4
86 4
82 20
79 4
72 4
80 4
74 4
86
83 210
84 210
85 210
86 210
7 8
0 4
46 24
57 28
60 28
63 28
62 28
58 28
47 24
1 4
23 16
34 20
36 20
37 20
35 20
25 16
8 8
22 16
2 4
3 4
4 4
9 8
18 12
17 12
15 12
16 12
10 8
26 16
44 24
20 12
5 4
32 20
21 12
56 32
41 20
52 28
45 24
11 8
31 16
42 20
51 24
55 28
40 20
6 4
19 12
12 8
33 20
30 16
70 32
71 32
59 28
39 20
24 16
49 24
27 16
29 16
50 24
73 32
79 32
78 32
69 32
38 20
65 32
53 28
28 16
13 8
54 28
72 32
81 32
80 32
76 32
64 28
66 32
48 24
14 8
43 20
61 28
74 32
77 32
75 32
68 32
67 32
83
82 210
7 2
0 1
46 6
57 7
60 7
63 7
62 7
58 7
47 6
1 1
23 4
34 5
36 5
37 5
35 5
25 4
8 2
22 4
2 1
3 1
4 1
9 2
18 3
17 3
15 3
16 3
10 2
26 4
44 6
20 3
5 1
32 5
21 3
56 8
41 5
52 7
45 6
11 2
31 4
42 5
51 6
55 7
40 5
6 1
19 3
12 2
33 5
30 4
70 8
71 8
59 7
39 5
24 4
49 6
27 4
29 4
50 6
73 8
79 8
78 8
69 8
38 5
65 8
53 7
28 4
13 2
54 7
72 8
81 8
80 8
76 8
64 7
66 8
48 6
14 2
43 5
61 7
74 8
77 8
75 8
68 8
67 8
83
82 210
7 2
0 1
46 6
57 7
60 7
63 7
62 7
58 7
47 6
1 1
23 4
34 5
36 5
37 5
35 5
25 4
8 2
22 4
2 1
3 1
4 1
9 2
18 3
17 3
15 3
16 3
10 2
26 4
44 6
20 3
5 1
32 5
21 3
56 8
41 5
52 7
45 6
11 2
31 4
42 5
51 6
55 7
40 5
6 1
19 3
12 2
33 5
30 4
70 8
71 8
59 7
39 5
24 4
49 6
27 4
29 4
50 6
73 8
79 8
78 8
69 8
38 5
65 8
53 7
28 4
13 2
54 7
72 8
81 8
80 8
76 8
64 7
66 8
48 6
14 2
43 5
61 7
74 8
77 8
75 8
68 8
67 8
83
82 210
7 2
0 1
46 6
57 7
60 7
63 7
62 7
58 7
47 6
1 1
23 4
34 5
36 5
37 5
35 5
25 4
8 2
22 4
2 1
3 1
4 1
9 2
18 3
17 3
15 3
16 3
10 2
26 4
44 6
20 3
5 1
32 5
21 3
56 8
41 5
52 7
45 6
11 2
31 4
42 5
51 6
55 7
40 5
6 1
19 3
12 2
33 5
30 4
70 8
71 8
59 7
39 5
24 4
49 6
27 4
29 4
50 6
73 8
79 8
78 8
69 8
38 5
65 8
53 7
28 4
13 2
54 7
72 8
81 8
80 8
76 8
64 7
66 8
48 6
14 2
43 5
61 7
74 8
77 8
75 8
68 8
67 8
83
82 210
7 2
0 1
46 6
57 7
60 7
63 7
62 7
58 7
47 6
1 1
23 4
34 5
36 5
37 5
35 5
25 4
8 2
22 4
2 1
3 1
4 1
9 2
18 3
17 3
15 3
16 3
10 2
26 4
44 6
20 3
5 1
32 5
21 3
56 8
41 5
52 7
45 6
11 2
31 4
42 5
51 6
55 7
40 5
6 1
19 3
12 2
33 5
30 4
70 8
71 8
59 7
39 5
24 4
49 6
27 4
29 4
50 6
73 8
79 8
78 8
69 8
38 5
65 8
53 7
28 4
13 2
54 7
72 8
81 8
80 8
76 8
64 7
66 8
48 6
14 2
43 5
61 7
74 8
77 8
75 8
68 8
67 8
end_CG
