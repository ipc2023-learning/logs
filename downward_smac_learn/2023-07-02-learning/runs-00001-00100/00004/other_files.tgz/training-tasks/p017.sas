begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var13
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var12
-1
12
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
end_variable
begin_variable
var9
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
24
begin_mutex_group
4
1 0
1 1
1 2
4 0
end_mutex_group
begin_mutex_group
2
1 0
4 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
4 1
end_mutex_group
begin_mutex_group
2
3 0
4 1
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
4 2
end_mutex_group
begin_mutex_group
2
2 0
4 2
end_mutex_group
begin_mutex_group
4
8 0
8 1
8 2
4 3
end_mutex_group
begin_mutex_group
2
8 0
4 3
end_mutex_group
begin_mutex_group
4
12 0
12 1
12 2
4 4
end_mutex_group
begin_mutex_group
2
12 0
4 4
end_mutex_group
begin_mutex_group
4
10 0
10 1
10 2
4 5
end_mutex_group
begin_mutex_group
2
10 0
4 5
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
4 6
end_mutex_group
begin_mutex_group
2
9 0
4 6
end_mutex_group
begin_mutex_group
4
13 0
13 1
13 2
4 7
end_mutex_group
begin_mutex_group
2
13 0
4 7
end_mutex_group
begin_mutex_group
4
11 0
11 1
11 2
4 8
end_mutex_group
begin_mutex_group
2
11 0
4 8
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
4 9
end_mutex_group
begin_mutex_group
2
5 0
4 9
end_mutex_group
begin_mutex_group
4
7 0
7 1
7 2
4 10
end_mutex_group
begin_mutex_group
2
7 0
4 10
end_mutex_group
begin_mutex_group
4
6 0
6 1
6 2
4 11
end_mutex_group
begin_mutex_group
2
6 0
4 11
end_mutex_group
begin_state
0
0
0
3
1
0
0
0
0
0
0
0
0
0
end_state
begin_goal
9
5 2
6 2
7 1
8 2
9 1
10 2
11 1
12 1
13 2
end_goal
72
begin_operator
change_color robot1 black white
0
1
0 0 0 1
0
end_operator
begin_operator
change_color robot1 white black
0
1
0 0 1 0
0
end_operator
begin_operator
move_down robot1 tile_1_1 tile_0_1
0
3
0 1 0 3
0 8 -1 0
0 4 3 0
0
end_operator
begin_operator
move_down robot1 tile_1_2 tile_0_2
0
3
0 3 0 3
0 12 -1 0
0 4 4 1
0
end_operator
begin_operator
move_down robot1 tile_1_3 tile_0_3
0
3
0 2 0 3
0 10 -1 0
0 4 5 2
0
end_operator
begin_operator
move_down robot1 tile_2_1 tile_1_1
0
3
0 8 0 3
0 9 -1 0
0 4 6 3
0
end_operator
begin_operator
move_down robot1 tile_2_2 tile_1_2
0
3
0 12 0 3
0 13 -1 0
0 4 7 4
0
end_operator
begin_operator
move_down robot1 tile_2_3 tile_1_3
0
3
0 10 0 3
0 11 -1 0
0 4 8 5
0
end_operator
begin_operator
move_down robot1 tile_3_1 tile_2_1
0
3
0 9 0 3
0 5 -1 0
0 4 9 6
0
end_operator
begin_operator
move_down robot1 tile_3_2 tile_2_2
0
3
0 13 0 3
0 7 -1 0
0 4 10 7
0
end_operator
begin_operator
move_down robot1 tile_3_3 tile_2_3
0
3
0 11 0 3
0 6 -1 0
0 4 11 8
0
end_operator
begin_operator
move_left robot1 tile_0_2 tile_0_1
0
3
0 1 0 3
0 3 -1 0
0 4 1 0
0
end_operator
begin_operator
move_left robot1 tile_0_3 tile_0_2
0
3
0 3 0 3
0 2 -1 0
0 4 2 1
0
end_operator
begin_operator
move_left robot1 tile_1_2 tile_1_1
0
3
0 8 0 3
0 12 -1 0
0 4 4 3
0
end_operator
begin_operator
move_left robot1 tile_1_3 tile_1_2
0
3
0 12 0 3
0 10 -1 0
0 4 5 4
0
end_operator
begin_operator
move_left robot1 tile_2_2 tile_2_1
0
3
0 9 0 3
0 13 -1 0
0 4 7 6
0
end_operator
begin_operator
move_left robot1 tile_2_3 tile_2_2
0
3
0 13 0 3
0 11 -1 0
0 4 8 7
0
end_operator
begin_operator
move_left robot1 tile_3_2 tile_3_1
0
3





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





7
check 1
46
check 1
47
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
switch 4
check 0
check 0
check 0
check 0
switch 0
check 1
30
check 1
60
check 1
61
check 0
check 0
check 0
check 0
check 1
15
check 0
switch 0
check 1
8
check 1
48
check 1
49
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 13
check 0
switch 4
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
31
check 1
62
check 1
63
check 0
check 0
check 1
23
check 0
check 1
16
check 0
switch 0
check 1
9
check 1
50
check 1
51
check 0
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
switch 4
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
32
check 1
64
check 1
65
check 0
check 0
check 1
24
check 0
check 0
check 0
switch 0
check 1
10
check 1
52
check 1
53
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
33
check 1
66
check 1
67
check 0
check 0
check 0
check 0
check 1
17
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
switch 4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
34
check 1
68
check 1
69
check 0
check 0
check 1
25
check 0
check 1
18
check 0
check 0
check 0
check 0
switch 6
check 0
switch 4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
35
check 1
70
check 1
71
check 0
check 0
check 1
26
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 1
1
check 0
end_SG
begin_DTG
1
1
0
0
1
0
1
0
end_DTG
begin_DTG
4
1
36
2
4 3
0 0
2
37
2
4 3
0 1
3
2
1
4 3
3
11
1
4 1
2
0
19
2
3 0
4 0
0
27
2
8 0
4 0
2
0
19
2
3 0
4 0
0
27
2
8 0
4 0
2
0
19
2
3 0
4 0
0
27
2
8 0
4 0
end_DTG
begin_DTG
4
1
40
2
4 5
0 0
2
41
2
4 5
0 1
3
4
1
4 5
3
20
1
4 1
2
0
12
2
3 0
4 2
0
29
2
10 0
4 2
2
0
12
2
3 0
4 2
0
29
2
10 0
4 2
2
0
12
2
3 0
4 2
0
29
2
10 0
4 2
end_DTG
begin_DTG
5
1
38
2
4 4
0 0
2
39
2
4 4
0 1
3
3
1
4 4
3
12
1
4 2
3
19
1
4 0
3
0
11
2
1 0
4 1
0
20
2
2 0
4 1
0
28
2
12 0
4 1
3
0
11
2
1 0
4 1
0
20
2
2 0
4 1
0
28
2
12 0
4 1
3
0
11
2
1 0
4 1
0
20
2
2 0
4 1
0
28
2
12 0
4 1
end_DTG
begin_DTG
2
1
19
1
3 0
3
27
1
8 0
3
0
11
1
1 0
2
20
1
2 0
4
28
1
12 0
2
1
12
1
3 0
5
29
1
10 0
3
0
2
1
1 0
4
21
1
12 0
6
30
1
9 0
4
1
3
1
3 0
3
13
1
8 0
5
22
1
10 0
7
31
1
13 0
3
2
4
1
2 0
4
14
1
12 0
8
32
1
11 0
3
3
5
1
8 0
7
23
1
13 0
9
33
1
5 0
4
4
6
1
12 0
6
15
1
9 0
8
24
1
11 0
10
34
1
7 0
3
5
7
1
10 0
7
16
1
13 0
11
35
1
6 0
2
6
8
1
9 0
10
25
1
7 0
3
7
9
1
13 0
9
17
1
5 0
11
26
1
6 0
2
8
10
1
11 0
10
18
1
7 0
end_DTG
begin_DTG
4
1
66
2
4 6
0 0
2
67
2
4 6
0 1
3
17
1
4 10
3
33
1
4 6
2
0
8
2
9 0
4 9
0
25
2
7 0
4 9
2
0
8
2
9 0
4 9
0
25
2
7 0
4 9
2
0
8
2
9 0
4 9
0
25
2
7 0
4 9
end_DTG
begin_DTG
4
1
70
2
4 8
0 0
2
71
2
4 8
0 1
3
26
1
4 10
3
35
1
4 8
2
0
10
2
11 0
4 11
0
18
2
7 0
4 11
2
0
10
2
11 0
4 11
0
18
2
7 0
4 11
2
0
10
2
11 0
4 11
0
18
2
7 0
4 11
end_DTG
begin_DTG
5
1
68
2
4 7
0 0
2
69
2
4 7
0 1
3
18
1
4 11
3
25
1
4 9
3
34
1
4 7
3
0
9
2
13 0
4 10
0
17
2
5 0
4 10
0
26
2
6 0
4 10
3
0
9
2
13 0
4 10
0
17
2
5 0
4 10
0
26
2
6 0
4 10
3
0
9
2
13 0
4 10
0
17
2
5 0
4 10
0
26
2
6 0
4 10
end_DTG
begin_DTG
7
1
42
2
4 6
0 0
1
54
2
4 0
0 0
2
43
2
4 6
0 1
2
55
2
4 0
0 1
3
5
1
4 6
3
13
1
4 4
3
27
1
4 0
3
0
2
2
1 0
4 3
0
21
2
12 0
4 3
0
30
2
9 0
4 3
3
0
2
2
1 0
4 3
0
21
2
12 0
4 3
0
30
2
9 0
4 3
3
0
2
2
1 0
4 3
0
21
2
12 0
4 3
0
30
2
9 0
4 3
end_DTG
begin_DTG
7
1
48
2
4 9
0 0
1
60
2
4 3
0 0
2
49
2
4 9
0 1
2
61
2
4 3
0 1
3
8
1
4 9
3
15
1
4 7
3
30
1
4 3
3
0
5
2
8 0
4 6
0
23
2
13 0
4 6
0
33
2
5 0
4 6
3
0
5
2
8 0
4 6
0
23
2
13 0
4 6
0
33
2
5 0
4 6
3
0
5
2
8 0
4 6
0
23
2
13 0
4 6
0
33
2
5 0
4 6
end_DTG
begin_DTG
7
1
46
2
4 8
0 0
1
58
2
4 2
0 0
2
47
2
4 8
0 1
2
59
2
4 2
0 1
3
7
1
4 8
3
22
1
4 4
3
29
1
4 2
3
0
4
2
2 0
4 5
0
14
2
12 0
4 5
0
32
2
11 0
4 5
3
0
4
2
2 0
4 5
0
14
2
12 0
4 5
0
32
2
11 0
4 5
3
0
4
2
2 0
4 5
0
14
2
12 0
4 5
0
32
2
11 0
4 5
end_DTG
begin_DTG
7
1
52
2
4 11
0 0
1
64
2
4 5
0 0
2
53
2
4 11
0 1
2
65
2
4 5
0 1
3
10
1
4 11
3
24
1
4 7
3
32
1
4 5
3
0
7
2
10 0
4 8
0
16
2
13 0
4 8
0
35
2
6 0
4 8
3
0
7
2
10 0
4 8
0
16
2
13 0
4 8
0
35
2
6 0
4 8
3
0
7
2
10 0
4 8
0
16
2
13 0
4 8
0
35
2
6 0
4 8
end_DTG
begin_DTG
8
1
44
2
4 7
0 0
1
56
2
4 1
0 0
2
45
2
4 7
0 1
2
57
2
4 1
0 1
3
6
1
4 7
3
14
1
4 5
3
21
1
4 3
3
28
1
4 1
4
0
3
2
3 0
4 4
0
13
2
8 0
4 4
0
22
2
10 0
4 4
0
31
2
13 0
4 4
4
0
3
2
3 0
4 4
0
13
2
8 0
4 4
0
22
2
10 0
4 4
0
31
2
13 0
4 4
4
0
3
2
3 0
4 4
0
13
2
8 0
4 4
0
22
2
10 0
4 4
0
31
2
13 0
4 4
end_DTG
begin_DTG
8
1
50
2
4 10
0 0
1
62
2
4 4
0 0
2
51
2
4 10
0 1
2
63
2
4 4
0 1
3
9
1
4 10
3
16
1
4 8
3
23
1
4 6
3
31
1
4 4
4
0
6
2
12 0
4 7
0
15
2
9 0
4 7
0
24
2
11 0
4 7
0
34
2
7 0
4 7
4
0
6
2
12 0
4 7
0
15
2
9 0
4 7
0
24
2
11 0
4 7
0
34
2
7 0
4 7
4
0
6
2
12 0
4 7
0
15
2
9 0
4 7
0
24
2
11 0
4 7
0
34
2
7 0
4 7
end_DTG
begin_CG
12
1 2
3 2
2 2
8 4
12 4
10 4
9 4
13 4
11 4
5 2
7 2
6 2
3
3 1
8 1
4 2
3
3 1
10 1
4 2
4
1 1
2 1
12 1
4 3
12
1 6
3 8
2 6
8 10
12 12
10 10
9 10
13 12
11 10
5 6
7 8
6 6
3
9 1
7 1
4 2
3
11 1
7 1
4 2
4
13 1
5 1
6 1
4 3
4
1 1
12 1
9 1
4 3
4
8 1
13 1
5 1
4 3
4
2 1
12 1
11 1
4 3
4
10 1
13 1
6 1
4 3
5
3 1
8 1
10 1
13 1
4 4
5
12 1
9 1
11 1
7 1
4 4
end_CG
