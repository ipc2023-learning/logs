begin_version
3
end_version
begin_metric
0
end_metric
22
begin_variable
var21
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var20
-1
20
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
end_variable
begin_variable
var16
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_4_4)
Atom painted(tile_4_4, black)
Atom painted(tile_4_4, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
40
begin_mutex_group
4
1 0
1 1
1 2
5 0
end_mutex_group
begin_mutex_group
2
1 0
5 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
5 1
end_mutex_group
begin_mutex_group
2
3 0
5 1
end_mutex_group
begin_mutex_group
4
4 0
4 1
4 2
5 2
end_mutex_group
begin_mutex_group
2
4 0
5 2
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
5 3
end_mutex_group
begin_mutex_group
2
2 0
5 3
end_mutex_group
begin_mutex_group
4
8 0
8 1
8 2
5 4
end_mutex_group
begin_mutex_group
2
8 0
5 4
end_mutex_group
begin_mutex_group
4
16 0
16 1
16 2
5 5
end_mutex_group
begin_mutex_group
2
16 0
5 5
end_mutex_group
begin_mutex_group
4
17 0
17 1
17 2
5 6
end_mutex_group
begin_mutex_group
2
17 0
5 6
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
5 7
end_mutex_group
begin_mutex_group
2
9 0
5 7
end_mutex_group
begin_mutex_group
4
11 0
11 1
11 2
5 8
end_mutex_group
begin_mutex_group
2
11 0
5 8
end_mutex_group
begin_mutex_group
4
19 0
19 1
19 2
5 9
end_mutex_group
begin_mutex_group
2
19 0
5 9
end_mutex_group
begin_mutex_group
4
21 0
21 1
21 2
5 10
end_mutex_group
begin_mutex_group
2
21 0
5 10
end_mutex_group
begin_mutex_group
4
15 0
15 1
15 2
5 11
end_mutex_group
begin_mutex_group
2
15 0
5 11
end_mutex_group
begin_mutex_group
4
10 0
10 1
10 2
5 12
end_mutex_group
begin_mutex_group
2
10 0
5 12
end_mutex_group
begin_mutex_group
4
18 0
18 1
18 2
5 13
end_mutex_group
begin_mutex_group
2
18 0
5 13
end_mutex_group
begin_mutex_group
4
20 0
20 1
20 2
5 14
end_mutex_group
begin_mutex_group
2
20 0
5 14
end_mutex_group
begin_mutex_group
4
14 0
14 1
14 2
5 15
end_mutex_group
begin_mutex_group
2
14 0
5 15




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




19
47
1
7 0
2
15
17
1
14 0
18
32
1
13 0
end_DTG
begin_DTG
4
1
120
2
5 12
0 0
2
121
2
5 12
0 1
3
30
1
5 17
3
60
1
5 12
2
0
14
2
10 0
5 16
0
45
2
12 0
5 16
2
0
14
2
10 0
5 16
0
45
2
12 0
5 16
2
0
14
2
10 0
5 16
0
45
2
12 0
5 16
end_DTG
begin_DTG
4
1
126
2
5 15
0 0
2
127
2
5 15
0 1
3
47
1
5 18
3
63
1
5 15
2
0
17
2
14 0
5 19
0
32
2
13 0
5 19
2
0
17
2
14 0
5 19
0
32
2
13 0
5 19
2
0
17
2
14 0
5 19
0
32
2
13 0
5 19
end_DTG
begin_DTG
7
1
72
2
5 8
0 0
1
96
2
5 0
0 0
2
73
2
5 8
0 1
2
97
2
5 0
0 1
3
6
1
5 8
3
21
1
5 5
3
48
1
5 0
3
0
2
2
1 0
5 4
0
36
2
16 0
5 4
0
52
2
11 0
5 4
3
0
2
2
1 0
5 4
0
36
2
16 0
5 4
0
52
2
11 0
5 4
3
0
2
2
1 0
5 4
0
36
2
16 0
5 4
0
52
2
11 0
5 4
end_DTG
begin_DTG
7
1
78
2
5 11
0 0
1
102
2
5 3
0 0
2
79
2
5 11
0 1
2
103
2
5 3
0 1
3
9
1
5 11
3
38
1
5 6
3
51
1
5 3
3
0
5
2
2 0
5 7
0
23
2
17 0
5 7
0
55
2
15 0
5 7
3
0
5
2
2 0
5 7
0
23
2
17 0
5 7
0
55
2
15 0
5 7
3
0
5
2
2 0
5 7
0
23
2
17 0
5 7
0
55
2
15 0
5 7
end_DTG
begin_DTG
7
1
88
2
5 16
0 0
1
112
2
5 8
0 0
2
89
2
5 16
0 1
2
113
2
5 8
0 1
3
14
1
5 16
3
27
1
5 13
3
56
1
5 8
3
0
10
2
11 0
5 12
0
42
2
18 0
5 12
0
60
2
6 0
5 12
3
0
10
2
11 0
5 12
0
42
2
18 0
5 12
0
60
2
6 0
5 12
3
0
10
2
11 0
5 12
0
42
2
18 0
5 12
0
60
2
6 0
5 12
end_DTG
begin_DTG
7
1
80
2
5 12
0 0
1
104
2
5 4
0 0
2
81
2
5 12
0 1
2
105
2
5 4
0 1
3
10
1
5 12
3
24
1
5 9
3
52
1
5 4
3
0
6
2
8 0
5 8
0
39
2
19 0
5 8
0
56
2
10 0
5 8
3
0
6
2
8 0
5 8
0
39
2
19 0
5 8
0
56
2
10 0
5 8
3
0
6
2
8 0
5 8
0
39
2
19 0
5 8
0
56
2
10 0
5 8
end_DTG
begin_DTG
5
1
122
2
5 13
0 0
2
123
2
5 13
0 1
3
31
1
5 18
3
45
1
5 16
3
61
1
5 13
3
0
15
2
18 0
5 17
0
30
2
6 0
5 17
0
46
2
13 0
5 17
3
0
15
2
18 0
5 17
0
30
2
6 0
5 17
0
46
2
13 0
5 17
3
0
15
2
18 0
5 17
0
30
2
6 0
5 17
0
46
2
13 0
5 17
end_DTG
begin_DTG
5
1
124
2
5 14
0 0
2
125
2
5 14
0 1
3
32
1
5 19
3
46
1
5 17
3
62
1
5 14
3
0
16
2
20 0
5 18
0
31
2
12 0
5 18
0
47
2
7 0
5 18
3
0
16
2
20 0
5 18
0
31
2
12 0
5 18
0
47
2
7 0
5 18
3
0
16
2
20 0
5 18
0
31
2
12 0
5 18
0
47
2
7 0
5 18
end_DTG
begin_DTG
7
1
94
2
5 19
0 0
1
118
2
5 11
0 0
2
95
2
5 19
0 1
2
119
2
5 11
0 1
3
17
1
5 19
3
44
1
5 14
3
59
1
5 11
3
0
13
2
15 0
5 15
0
29
2
20 0
5 15
0
63
2
7 0
5 15
3
0
13
2
15 0
5 15
0
29
2
20 0
5 15
0
63
2
7 0
5 15
3
0
13
2
15 0
5 15
0
29
2
20 0
5 15
0
63
2
7 0
5 15
end_DTG
begin_DTG
7
1
86
2
5 15
0 0
1
110
2
5 7
0 0
2
87
2
5 15
0 1
2
111
2
5 7
0 1
3
13
1
5 15
3
41
1
5 10
3
55
1
5 7
3
0
9
2
9 0
5 11
0
26
2
21 0
5 11
0
59
2
14 0
5 11
3
0
9
2
9 0
5 11
0
26
2
21 0
5 11
0
59
2
14 0
5 11
3
0
9
2
9 0
5 11
0
26
2
21 0
5 11
0
59
2
14 0
5 11
end_DTG
begin_DTG
8
1
74
2
5 9
0 0
1
98
2
5 1
0 0
2
75
2
5 9
0 1
2
99
2
5 1
0 1
3
7
1
5 9
3
22
1
5 6
3
36
1
5 4
3
49
1
5 1
4
0
3
2
3 0
5 5
0
21
2
8 0
5 5
0
37
2
17 0
5 5
0
53
2
19 0
5 5
4
0
3
2
3 0
5 5
0
21
2
8 0
5 5
0
37
2
17 0
5 5
0
53
2
19 0
5 5
4
0
3
2
3 0
5 5
0
21
2
8 0
5 5
0
37
2
17 0
5 5
0
53
2
19 0
5 5
end_DTG
begin_DTG
8
1
76
2
5 10
0 0
1
100
2
5 2
0 0
2
77
2
5 10
0 1
2
101
2
5 2
0 1
3
8
1
5 10
3
23
1
5 7
3
37
1
5 5
3
50
1
5 2
4
0
4
2
4 0
5 6
0
22
2
16 0
5 6
0
38
2
9 0
5 6
0
54
2
21 0
5 6
4
0
4
2
4 0
5 6
0
22
2
16 0
5 6
0
38
2
9 0
5 6
0
54
2
21 0
5 6
4
0
4
2
4 0
5 6
0
22
2
16 0
5 6
0
38
2
9 0
5 6
0
54
2
21 0
5 6
end_DTG
begin_DTG
8
1
90
2
5 17
0 0
1
114
2
5 9
0 0
2
91
2
5 17
0 1
2
115
2
5 9
0 1
3
15
1
5 17
3
28
1
5 14
3
42
1
5 12
3
57
1
5 9
4
0
11
2
19 0
5 13
0
27
2
10 0
5 13
0
43
2
20 0
5 13
0
61
2
12 0
5 13
4
0
11
2
19 0
5 13
0
27
2
10 0
5 13
0
43
2
20 0
5 13
0
61
2
12 0
5 13
4
0
11
2
19 0
5 13
0
27
2
10 0
5 13
0
43
2
20 0
5 13
0
61
2
12 0
5 13
end_DTG
begin_DTG
8
1
82
2
5 13
0 0
1
106
2
5 5
0 0
2
83
2
5 13
0 1
2
107
2
5 5
0 1
3
11
1
5 13
3
25
1
5 10
3
39
1
5 8
3
53
1
5 5
4
0
7
2
16 0
5 9
0
24
2
11 0
5 9
0
40
2
21 0
5 9
0
57
2
18 0
5 9
4
0
7
2
16 0
5 9
0
24
2
11 0
5 9
0
40
2
21 0
5 9
0
57
2
18 0
5 9
4
0
7
2
16 0
5 9
0
24
2
11 0
5 9
0
40
2
21 0
5 9
0
57
2
18 0
5 9
end_DTG
begin_DTG
8
1
92
2
5 18
0 0
1
116
2
5 10
0 0
2
93
2
5 18
0 1
2
117
2
5 10
0 1
3
16
1
5 18
3
29
1
5 15
3
43
1
5 13
3
58
1
5 10
4
0
12
2
21 0
5 14
0
28
2
18 0
5 14
0
44
2
14 0
5 14
0
62
2
13 0
5 14
4
0
12
2
21 0
5 14
0
28
2
18 0
5 14
0
44
2
14 0
5 14
0
62
2
13 0
5 14
4
0
12
2
21 0
5 14
0
28
2
18 0
5 14
0
44
2
14 0
5 14
0
62
2
13 0
5 14
end_DTG
begin_DTG
8
1
84
2
5 14
0 0
1
108
2
5 6
0 0
2
85
2
5 14
0 1
2
109
2
5 6
0 1
3
12
1
5 14
3
26
1
5 11
3
40
1
5 9
3
54
1
5 6
4
0
8
2
17 0
5 10
0
25
2
19 0
5 10
0
41
2
15 0
5 10
0
58
2
20 0
5 10
4
0
8
2
17 0
5 10
0
25
2
19 0
5 10
0
41
2
15 0
5 10
0
58
2
20 0
5 10
4
0
8
2
17 0
5 10
0
25
2
19 0
5 10
0
41
2
15 0
5 10
0
58
2
20 0
5 10
end_DTG
begin_CG
20
1 2
3 2
4 2
2 2
8 4
16 4
17 4
9 4
11 4
19 4
21 4
15 4
10 4
18 4
20 4
14 4
6 2
12 2
13 2
7 2
3
3 1
8 1
5 2
3
4 1
9 1
5 2
4
1 1
4 1
16 1
5 3
4
3 1
2 1
17 1
5 3
20
1 6
3 8
4 8
2 6
8 10
16 12
17 12
9 10
11 10
19 12
21 12
15 10
10 10
18 12
20 12
14 10
6 6
12 8
13 8
7 6
3
10 1
12 1
5 2
3
14 1
13 1
5 2
4
1 1
16 1
11 1
5 3
4
2 1
17 1
15 1
5 3
4
11 1
18 1
6 1
5 3
4
8 1
19 1
10 1
5 3
4
18 1
6 1
13 1
5 3
4
20 1
12 1
7 1
5 3
4
15 1
20 1
7 1
5 3
4
9 1
21 1
14 1
5 3
5
3 1
8 1
17 1
19 1
5 4
5
4 1
16 1
9 1
21 1
5 4
5
19 1
10 1
20 1
12 1
5 4
5
16 1
11 1
21 1
18 1
5 4
5
21 1
18 1
14 1
13 1
5 4
5
17 1
19 1
15 1
20 1
5 4
end_CG
