begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var25
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var24
-1
24
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
end_variable
begin_variable
var18
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_3_6)
Atom painted(tile_3_6, black)
Atom painted(tile_3_6, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_1_6)
Atom painted(tile_1_6, black)
Atom painted(tile_1_6, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_2_6)
Atom painted(tile_2_6, black)
Atom painted(tile_2_6, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_3_5)
Atom painted(tile_3_5, black)
Atom painted(tile_3_5, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_1_5)
Atom painted(tile_1_5, black)
Atom painted(tile_1_5, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_2_5)
Atom painted(tile_2_5, black)
Atom painted(tile_2_5, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
48
begin_mutex_group
4
1 0
1 1
1 2
7 0
end_mutex_group
begin_mutex_group
2
1 0
7 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
7 1
end_mutex_group
begin_mutex_group
2
3 0
7 1
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
7 2
end_mutex_group
begin_mutex_group
2
5 0
7 2
end_mutex_group
begin_mutex_group
4
6 0
6 1
6 2
7 3
end_mutex_group
begin_mutex_group
2
6 0
7 3
end_mutex_group
begin_mutex_group
4
4 0
4 1
4 2
7 4
end_mutex_group
begin_mutex_group
2
4 0
7 4
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
7 5
end_mutex_group
begin_mutex_group
2
2 0
7 5
end_mutex_group
begin_mutex_group
4
10 0
10 1
10 2
7 6
end_mutex_group
begin_mutex_group
2
10 0
7 6
end_mutex_group
begin_mutex_group
4
18 0
18 1
18 2
7 7
end_mutex_group
begin_mutex_group
2
18 0
7 7
end_mutex_group
begin_mutex_group
4
22 0
22 1
22 2
7 8
end_mutex_group
begin_mutex_group
2
22 0
7 8
end_mutex_group
begin_mutex_group
4
23 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
0
50
2
19 0
7 12
0
72
2
8 0
7 12
3
0
8
2
10 0
7 12
0
50
2
19 0
7 12
0
72
2
8 0
7 12
3
0
8
2
10 0
7 12
0
50
2
19 0
7 12
0
72
2
8 0
7 12
end_DTG
begin_DTG
7
1
100
2
7 17
0 0
1
124
2
7 5
0 0
2
101
2
7 17
0 1
2
125
2
7 5
0 1
3
13
1
7 17
3
49
1
7 10
3
65
1
7 5
3
0
7
2
2 0
7 11
0
29
2
20 0
7 11
0
71
2
13 0
7 11
3
0
7
2
2 0
7 11
0
29
2
20 0
7 11
0
71
2
13 0
7 11
3
0
7
2
2 0
7 11
0
29
2
20 0
7 11
0
71
2
13 0
7 11
end_DTG
begin_DTG
7
1
112
2
7 23
0 0
1
136
2
7 11
0 0
2
113
2
7 23
0 1
2
137
2
7 11
0 1
3
19
1
7 23
3
54
1
7 16
3
71
1
7 11
3
0
13
2
12 0
7 17
0
34
2
21 0
7 17
0
77
2
9 0
7 17
3
0
13
2
12 0
7 17
0
34
2
21 0
7 17
0
77
2
9 0
7 17
3
0
13
2
12 0
7 17
0
34
2
21 0
7 17
0
77
2
9 0
7 17
end_DTG
begin_DTG
5
1
140
2
7 13
0 0
2
141
2
7 13
0 1
3
36
1
7 20
3
55
1
7 18
3
73
1
7 13
3
0
15
2
19 0
7 19
0
35
2
8 0
7 19
0
56
2
16 0
7 19
3
0
15
2
19 0
7 19
0
35
2
8 0
7 19
0
56
2
16 0
7 19
3
0
15
2
19 0
7 19
0
35
2
8 0
7 19
0
56
2
16 0
7 19
end_DTG
begin_DTG
5
1
146
2
7 16
0 0
2
147
2
7 16
0 1
3
39
1
7 23
3
58
1
7 21
3
76
1
7 16
3
0
18
2
21 0
7 22
0
38
2
17 0
7 22
0
59
2
9 0
7 22
3
0
18
2
21 0
7 22
0
38
2
17 0
7 22
0
59
2
9 0
7 22
3
0
18
2
21 0
7 22
0
38
2
17 0
7 22
0
59
2
9 0
7 22
end_DTG
begin_DTG
5
1
142
2
7 14
0 0
2
143
2
7 14
0 1
3
37
1
7 21
3
56
1
7 19
3
74
1
7 14
3
0
16
2
24 0
7 20
0
36
2
14 0
7 20
0
57
2
17 0
7 20
3
0
16
2
24 0
7 20
0
36
2
14 0
7 20
0
57
2
17 0
7 20
3
0
16
2
24 0
7 20
0
36
2
14 0
7 20
0
57
2
17 0
7 20
end_DTG
begin_DTG
5
1
144
2
7 15
0 0
2
145
2
7 15
0 1
3
38
1
7 22
3
57
1
7 20
3
75
1
7 15
3
0
17
2
25 0
7 21
0
37
2
16 0
7 21
0
58
2
15 0
7 21
3
0
17
2
25 0
7 21
0
37
2
16 0
7 21
0
58
2
15 0
7 21
3
0
17
2
25 0
7 21
0
37
2
16 0
7 21
0
58
2
15 0
7 21
end_DTG
begin_DTG
8
1
92
2
7 13
0 0
1
116
2
7 1
0 0
2
93
2
7 13
0 1
2
117
2
7 1
0 1
3
9
1
7 13
3
26
1
7 8
3
45
1
7 6
3
61
1
7 1
4
0
3
2
3 0
7 7
0
25
2
10 0
7 7
0
46
2
22 0
7 7
0
67
2
19 0
7 7
4
0
3
2
3 0
7 7
0
25
2
10 0
7 7
0
46
2
22 0
7 7
0
67
2
19 0
7 7
4
0
3
2
3 0
7 7
0
25
2
10 0
7 7
0
46
2
22 0
7 7
0
67
2
19 0
7 7
end_DTG
begin_DTG
8
1
104
2
7 19
0 0
1
128
2
7 7
0 0
2
105
2
7 19
0 1
2
129
2
7 7
0 1
3
15
1
7 19
3
31
1
7 14
3
50
1
7 12
3
67
1
7 7
4
0
9
2
18 0
7 13
0
30
2
11 0
7 13
0
51
2
24 0
7 13
0
73
2
14 0
7 13
4
0
9
2
18 0
7 13
0
30
2
11 0
7 13
0
51
2
24 0
7 13
0
73
2
14 0
7 13
4
0
9
2
18 0
7 13
0
30
2
11 0
7 13
0
51
2
24 0
7 13
0
73
2
14 0
7 13
end_DTG
begin_DTG
8
1
98
2
7 16
0 0
1
122
2
7 4
0 0
2
99
2
7 16
0 1
2
123
2
7 4
0 1
3
12
1
7 16
3
29
1
7 11
3
48
1
7 9
3
64
1
7 4
4
0
6
2
4 0
7 10
0
28
2
23 0
7 10
0
49
2
12 0
7 10
0
70
2
21 0
7 10
4
0
6
2
4 0
7 10
0
28
2
23 0
7 10
0
49
2
12 0
7 10
0
70
2
21 0
7 10
4
0
6
2
4 0
7 10
0
28
2
23 0
7 10
0
49
2
12 0
7 10
0
70
2
21 0
7 10
end_DTG
begin_DTG
8
1
110
2
7 22
0 0
1
134
2
7 10
0 0
2
111
2
7 22
0 1
2
135
2
7 10
0 1
3
18
1
7 22
3
34
1
7 17
3
53
1
7 15
3
70
1
7 10
4
0
12
2
20 0
7 16
0
33
2
25 0
7 16
0
54
2
13 0
7 16
0
76
2
15 0
7 16
4
0
12
2
20 0
7 16
0
33
2
25 0
7 16
0
54
2
13 0
7 16
0
76
2
15 0
7 16
4
0
12
2
20 0
7 16
0
33
2
25 0
7 16
0
54
2
13 0
7 16
0
76
2
15 0
7 16
end_DTG
begin_DTG
8
1
94
2
7 14
0 0
1
118
2
7 2
0 0
2
95
2
7 14
0 1
2
119
2
7 2
0 1
3
10
1
7 14
3
27
1
7 9
3
46
1
7 7
3
62
1
7 2
4
0
4
2
5 0
7 8
0
26
2
18 0
7 8
0
47
2
23 0
7 8
0
68
2
24 0
7 8
4
0
4
2
5 0
7 8
0
26
2
18 0
7 8
0
47
2
23 0
7 8
0
68
2
24 0
7 8
4
0
4
2
5 0
7 8
0
26
2
18 0
7 8
0
47
2
23 0
7 8
0
68
2
24 0
7 8
end_DTG
begin_DTG
8
1
96
2
7 15
0 0
1
120
2
7 3
0 0
2
97
2
7 15
0 1
2
121
2
7 3
0 1
3
11
1
7 15
3
28
1
7 10
3
47
1
7 8
3
63
1
7 3
4
0
5
2
6 0
7 9
0
27
2
22 0
7 9
0
48
2
20 0
7 9
0
69
2
25 0
7 9
4
0
5
2
6 0
7 9
0
27
2
22 0
7 9
0
48
2
20 0
7 9
0
69
2
25 0
7 9
4
0
5
2
6 0
7 9
0
27
2
22 0
7 9
0
48
2
20 0
7 9
0
69
2
25 0
7 9
end_DTG
begin_DTG
8
1
106
2
7 20
0 0
1
130
2
7 8
0 0
2
107
2
7 20
0 1
2
131
2
7 8
0 1
3
16
1
7 20
3
32
1
7 15
3
51
1
7 13
3
68
1
7 8
4
0
10
2
22 0
7 14
0
31
2
19 0
7 14
0
52
2
25 0
7 14
0
74
2
16 0
7 14
4
0
10
2
22 0
7 14
0
31
2
19 0
7 14
0
52
2
25 0
7 14
0
74
2
16 0
7 14
4
0
10
2
22 0
7 14
0
31
2
19 0
7 14
0
52
2
25 0
7 14
0
74
2
16 0
7 14
end_DTG
begin_DTG
8
1
108
2
7 21
0 0
1
132
2
7 9
0 0
2
109
2
7 21
0 1
2
133
2
7 9
0 1
3
17
1
7 21
3
33
1
7 16
3
52
1
7 14
3
69
1
7 9
4
0
11
2
23 0
7 15
0
32
2
24 0
7 15
0
53
2
21 0
7 15
0
75
2
17 0
7 15
4
0
11
2
23 0
7 15
0
32
2
24 0
7 15
0
53
2
21 0
7 15
0
75
2
17 0
7 15
4
0
11
2
23 0
7 15
0
32
2
24 0
7 15
0
53
2
21 0
7 15
0
75
2
17 0
7 15
end_DTG
begin_CG
24
1 2
3 2
5 2
6 2
4 2
2 2
10 4
18 4
22 4
23 4
20 4
12 4
11 4
19 4
24 4
25 4
21 4
13 4
8 2
14 2
16 2
17 2
15 2
9 2
3
3 1
10 1
7 2
3
4 1
12 1
7 2
4
1 1
5 1
18 1
7 3
4
6 1
2 1
20 1
7 3
4
3 1
6 1
22 1
7 3
4
5 1
4 1
23 1
7 3
24
1 6
3 8
5 8
6 8
4 8
2 6
10 10
18 12
22 12
23 12
20 12
12 10
11 10
19 12
24 12
25 12
21 12
13 10
8 6
14 8
16 8
17 8
15 8
9 6
3
11 1
14 1
7 2
3
13 1
15 1
7 2
4
1 1
18 1
11 1
7 3
4
10 1
19 1
8 1
7 3
4
2 1
20 1
13 1
7 3
4
12 1
21 1
9 1
7 3
4
19 1
8 1
16 1
7 3
4
21 1
17 1
9 1
7 3
4
24 1
14 1
17 1
7 3
4
25 1
16 1
15 1
7 3
5
3 1
10 1
22 1
19 1
7 4
5
18 1
11 1
24 1
14 1
7 4
5
4 1
23 1
12 1
21 1
7 4
5
20 1
25 1
13 1
15 1
7 4
5
5 1
18 1
23 1
24 1
7 4
5
6 1
22 1
20 1
25 1
7 4
5
22 1
19 1
25 1
16 1
7 4
5
23 1
24 1
21 1
17 1
7 4
end_CG
