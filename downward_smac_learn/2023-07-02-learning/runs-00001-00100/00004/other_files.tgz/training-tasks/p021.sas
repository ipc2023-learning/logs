begin_version
3
end_version
begin_metric
0
end_metric
20
begin_variable
var19
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var18
-1
18
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
end_variable
begin_variable
var15
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_5_3)
Atom painted(tile_5_3, black)
Atom painted(tile_5_3, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_5_2)
Atom painted(tile_5_2, black)
Atom painted(tile_5_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
36
begin_mutex_group
4
1 0
1 1
1 2
4 0
end_mutex_group
begin_mutex_group
2
1 0
4 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
4 1
end_mutex_group
begin_mutex_group
2
3 0
4 1
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
4 2
end_mutex_group
begin_mutex_group
2
2 0
4 2
end_mutex_group
begin_mutex_group
4
8 0
8 1
8 2
4 3
end_mutex_group
begin_mutex_group
2
8 0
4 3
end_mutex_group
begin_mutex_group
4
16 0
16 1
16 2
4 4
end_mutex_group
begin_mutex_group
2
16 0
4 4
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
4 5
end_mutex_group
begin_mutex_group
2
9 0
4 5
end_mutex_group
begin_mutex_group
4
12 0
12 1
12 2
4 6
end_mutex_group
begin_mutex_group
2
12 0
4 6
end_mutex_group
begin_mutex_group
4
18 0
18 1
18 2
4 7
end_mutex_group
begin_mutex_group
2
18 0
4 7
end_mutex_group
begin_mutex_group
4
14 0
14 1
14 2
4 8
end_mutex_group
begin_mutex_group
2
14 0
4 8
end_mutex_group
begin_mutex_group
4
13 0
13 1
13 2
4 9
end_mutex_group
begin_mutex_group
2
13 0
4 9
end_mutex_group
begin_mutex_group
4
19 0
19 1
19 2
4 10
end_mutex_group
begin_mutex_group
2
19 0
4 10
end_mutex_group
begin_mutex_group
4
15 0
15 1
15 2
4 11
end_mutex_group
begin_mutex_group
2
15 0
4 11
end_mutex_group
begin_mutex_group
4
10 0
10 1
10 2
4 12
end_mutex_group
begin_mutex_group
2
10 0
4 12
end_mutex_group
begin_mutex_group
4
17 0
17 1
17 2
4 13
end_mutex_group
begin_mutex_group
2
17 0
4 13
end_mutex_group
begin_mutex_group
4
11 0
11 1
11 2
4 14
end_mutex_group
begin_mutex_group
2
11 0
4 14
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
4 15
end_mutex_group
begin_mutex_group
2
5 0
4 15
end_mutex_group
begin_mutex_group
4
7 0
7 1
7 2
4 16
end_mutex_group
begin_mutex_group
2
7 0
4 16
end_mutex_group
begin_mutex_group
4
6 0
6 1
6 2
4 17
end_mutex_group
begin_mutex_group
2
6 0
4 17
end_mutex_group
begin_state
1
0
3
0
2
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
15
5 2
6 2
7 1
8 2
9 2
10 1
11 1
12 1
13 2
14 1
15




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
3
2
4
1
2 0
4
20
1
16 0
8
46
1
14 0
3
3
5
1
8 0
7
33
1
18 0
9
47
1
13 0
4
4
6
1
16 0
6
21
1
12 0
8
34
1
14 0
10
48
1
19 0
3
5
7
1
9 0
7
22
1
18 0
11
49
1
15 0
3
6
8
1
12 0
10
35
1
19 0
12
50
1
10 0
4
7
9
1
18 0
9
23
1
13 0
11
36
1
15 0
13
51
1
17 0
3
8
10
1
14 0
10
24
1
19 0
14
52
1
11 0
3
9
11
1
13 0
13
37
1
17 0
15
53
1
5 0
4
10
12
1
19 0
12
25
1
10 0
14
38
1
11 0
16
54
1
7 0
3
11
13
1
15 0
13
26
1
17 0
17
55
1
6 0
2
12
14
1
10 0
16
39
1
7 0
3
13
15
1
17 0
15
27
1
5 0
17
40
1
6 0
2
14
16
1
11 0
16
28
1
7 0
end_DTG
begin_DTG
4
1
110
2
4 12
0 0
2
111
2
4 12
0 1
3
27
1
4 16
3
53
1
4 12
2
0
14
2
10 0
4 15
0
39
2
7 0
4 15
2
0
14
2
10 0
4 15
0
39
2
7 0
4 15
2
0
14
2
10 0
4 15
0
39
2
7 0
4 15
end_DTG
begin_DTG
4
1
114
2
4 14
0 0
2
115
2
4 14
0 1
3
40
1
4 16
3
55
1
4 14
2
0
16
2
11 0
4 17
0
28
2
7 0
4 17
2
0
16
2
11 0
4 17
0
28
2
7 0
4 17
2
0
16
2
11 0
4 17
0
28
2
7 0
4 17
end_DTG
begin_DTG
5
1
112
2
4 13
0 0
2
113
2
4 13
0 1
3
28
1
4 17
3
39
1
4 15
3
54
1
4 13
3
0
15
2
17 0
4 16
0
27
2
5 0
4 16
0
40
2
6 0
4 16
3
0
15
2
17 0
4 16
0
27
2
5 0
4 16
0
40
2
6 0
4 16
3
0
15
2
17 0
4 16
0
27
2
5 0
4 16
0
40
2
6 0
4 16
end_DTG
begin_DTG
7
1
62
2
4 6
0 0
1
86
2
4 0
0 0
2
63
2
4 6
0 1
2
87
2
4 0
0 1
3
5
1
4 6
3
19
1
4 4
3
41
1
4 0
3
0
2
2
1 0
4 3
0
31
2
16 0
4 3
0
44
2
12 0
4 3
3
0
2
2
1 0
4 3
0
31
2
16 0
4 3
0
44
2
12 0
4 3
3
0
2
2
1 0
4 3
0
31
2
16 0
4 3
0
44
2
12 0
4 3
end_DTG
begin_DTG
7
1
66
2
4 8
0 0
1
90
2
4 2
0 0
2
67
2
4 8
0 1
2
91
2
4 2
0 1
3
7
1
4 8
3
32
1
4 4
3
43
1
4 2
3
0
4
2
2 0
4 5
0
20
2
16 0
4 5
0
46
2
14 0
4 5
3
0
4
2
2 0
4 5
0
20
2
16 0
4 5
0
46
2
14 0
4 5
3
0
4
2
2 0
4 5
0
20
2
16 0
4 5
0
46
2
14 0
4 5
end_DTG
begin_DTG
7
1
80
2
4 15
0 0
1
104
2
4 9
0 0
2
81
2
4 15
0 1
2
105
2
4 9
0 1
3
14
1
4 15
3
25
1
4 13
3
50
1
4 9
3
0
11
2
13 0
4 12
0
37
2
17 0
4 12
0
53
2
5 0
4 12
3
0
11
2
13 0
4 12
0
37
2
17 0
4 12
0
53
2
5 0
4 12
3
0
11
2
13 0
4 12
0
37
2
17 0
4 12
0
53
2
5 0
4 12
end_DTG
begin_DTG
7
1
84
2
4 17
0 0
1
108
2
4 11
0 0
2
85
2
4 17
0 1
2
109
2
4 11
0 1
3
16
1
4 17
3
38
1
4 13
3
52
1
4 11
3
0
13
2
15 0
4 14
0
26
2
17 0
4 14
0
55
2
6 0
4 14
3
0
13
2
15 0
4 14
0
26
2
17 0
4 14
0
55
2
6 0
4 14
3
0
13
2
15 0
4 14
0
26
2
17 0
4 14
0
55
2
6 0
4 14
end_DTG
begin_DTG
7
1
68
2
4 9
0 0
1
92
2
4 3
0 0
2
69
2
4 9
0 1
2
93
2
4 3
0 1
3
8
1
4 9
3
21
1
4 7
3
44
1
4 3
3
0
5
2
8 0
4 6
0
33
2
18 0
4 6
0
47
2
13 0
4 6
3
0
5
2
8 0
4 6
0
33
2
18 0
4 6
0
47
2
13 0
4 6
3
0
5
2
8 0
4 6
0
33
2
18 0
4 6
0
47
2
13 0
4 6
end_DTG
begin_DTG
7
1
74
2
4 12
0 0
1
98
2
4 6
0 0
2
75
2
4 12
0 1
2
99
2
4 6
0 1
3
11
1
4 12
3
23
1
4 10
3
47
1
4 6
3
0
8
2
12 0
4 9
0
35
2
19 0
4 9
0
50
2
10 0
4 9
3
0
8
2
12 0
4 9
0
35
2
19 0
4 9
0
50
2
10 0
4 9
3
0
8
2
12 0
4 9
0
35
2
19 0
4 9
0
50
2
10 0
4 9
end_DTG
begin_DTG
7
1
72
2
4 11
0 0
1
96
2
4 5
0 0
2
73
2
4 11
0 1
2
97
2
4 5
0 1
3
10
1
4 11
3
34
1
4 7
3
46
1
4 5
3
0
7
2
9 0
4 8
0
22
2
18 0
4 8
0
49
2
15 0
4 8
3
0
7
2
9 0
4 8
0
22
2
18 0
4 8
0
49
2
15 0
4 8
3
0
7
2
9 0
4 8
0
22
2
18 0
4 8
0
49
2
15 0
4 8
end_DTG
begin_DTG
7
1
78
2
4 14
0 0
1
102
2
4 8
0 0
2
79
2
4 14
0 1
2
103
2
4 8
0 1
3
13
1
4 14
3
36
1
4 10
3
49
1
4 8
3
0
10
2
14 0
4 11
0
24
2
19 0
4 11
0
52
2
11 0
4 11
3
0
10
2
14 0
4 11
0
24
2
19 0
4 11
0
52
2
11 0
4 11
3
0
10
2
14 0
4 11
0
24
2
19 0
4 11
0
52
2
11 0
4 11
end_DTG
begin_DTG
8
1
64
2
4 7
0 0
1
88
2
4 1
0 0
2
65
2
4 7
0 1
2
89
2
4 1
0 1
3
6
1
4 7
3
20
1
4 5
3
31
1
4 3
3
42
1
4 1
4
0
3
2
3 0
4 4
0
19
2
8 0
4 4
0
32
2
9 0
4 4
0
45
2
18 0
4 4
4
0
3
2
3 0
4 4
0
19
2
8 0
4 4
0
32
2
9 0
4 4
0
45
2
18 0
4 4
4
0
3
2
3 0
4 4
0
19
2
8 0
4 4
0
32
2
9 0
4 4
0
45
2
18 0
4 4
end_DTG
begin_DTG
8
1
82
2
4 16
0 0
1
106
2
4 10
0 0
2
83
2
4 16
0 1
2
107
2
4 10
0 1
3
15
1
4 16
3
26
1
4 14
3
37
1
4 12
3
51
1
4 10
4
0
12
2
19 0
4 13
0
25
2
10 0
4 13
0
38
2
11 0
4 13
0
54
2
7 0
4 13
4
0
12
2
19 0
4 13
0
25
2
10 0
4 13
0
38
2
11 0
4 13
0
54
2
7 0
4 13
4
0
12
2
19 0
4 13
0
25
2
10 0
4 13
0
38
2
11 0
4 13
0
54
2
7 0
4 13
end_DTG
begin_DTG
8
1
70
2
4 10
0 0
1
94
2
4 4
0 0
2
71
2
4 10
0 1
2
95
2
4 4
0 1
3
9
1
4 10
3
22
1
4 8
3
33
1
4 6
3
45
1
4 4
4
0
6
2
16 0
4 7
0
21
2
12 0
4 7
0
34
2
14 0
4 7
0
48
2
19 0
4 7
4
0
6
2
16 0
4 7
0
21
2
12 0
4 7
0
34
2
14 0
4 7
0
48
2
19 0
4 7
4
0
6
2
16 0
4 7
0
21
2
12 0
4 7
0
34
2
14 0
4 7
0
48
2
19 0
4 7
end_DTG
begin_DTG
8
1
76
2
4 13
0 0
1
100
2
4 7
0 0
2
77
2
4 13
0 1
2
101
2
4 7
0 1
3
12
1
4 13
3
24
1
4 11
3
35
1
4 9
3
48
1
4 7
4
0
9
2
18 0
4 10
0
23
2
13 0
4 10
0
36
2
15 0
4 10
0
51
2
17 0
4 10
4
0
9
2
18 0
4 10
0
23
2
13 0
4 10
0
36
2
15 0
4 10
0
51
2
17 0
4 10
4
0
9
2
18 0
4 10
0
23
2
13 0
4 10
0
36
2
15 0
4 10
0
51
2
17 0
4 10
end_DTG
begin_CG
18
1 2
3 2
2 2
8 4
16 4
9 4
12 4
18 4
14 4
13 4
19 4
15 4
10 4
17 4
11 4
5 2
7 2
6 2
3
3 1
8 1
4 2
3
3 1
9 1
4 2
4
1 1
2 1
16 1
4 3
18
1 6
3 8
2 6
8 10
16 12
9 10
12 10
18 12
14 10
13 10
19 12
15 10
10 10
17 12
11 10
5 6
7 8
6 6
3
10 1
7 1
4 2
3
11 1
7 1
4 2
4
17 1
5 1
6 1
4 3
4
1 1
16 1
12 1
4 3
4
2 1
16 1
14 1
4 3
4
13 1
17 1
5 1
4 3
4
15 1
17 1
6 1
4 3
4
8 1
18 1
13 1
4 3
4
12 1
19 1
10 1
4 3
4
9 1
18 1
15 1
4 3
4
14 1
19 1
11 1
4 3
5
3 1
8 1
9 1
18 1
4 4
5
19 1
10 1
11 1
7 1
4 4
5
16 1
12 1
14 1
19 1
4 4
5
18 1
13 1
15 1
17 1
4 4
end_CG
