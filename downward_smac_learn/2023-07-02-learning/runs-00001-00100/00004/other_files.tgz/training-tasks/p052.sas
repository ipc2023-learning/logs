begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var30
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var29
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var27
-1
27
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_6_1)
Atom robot-at(robot1, tile_6_2)
Atom robot-at(robot1, tile_6_3)
Atom robot-at(robot1, tile_7_1)
Atom robot-at(robot1, tile_7_2)
Atom robot-at(robot1, tile_7_3)
Atom robot-at(robot1, tile_8_1)
Atom robot-at(robot1, tile_8_2)
Atom robot-at(robot1, tile_8_3)
end_variable
begin_variable
var28
-1
27
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_5_1)
Atom robot-at(robot2, tile_5_2)
Atom robot-at(robot2, tile_5_3)
Atom robot-at(robot2, tile_6_1)
Atom robot-at(robot2, tile_6_2)
Atom robot-at(robot2, tile_6_3)
Atom robot-at(robot2, tile_7_1)
Atom robot-at(robot2, tile_7_2)
Atom robot-at(robot2, tile_7_3)
Atom robot-at(robot2, tile_8_1)
Atom robot-at(robot2, tile_8_2)
Atom robot-at(robot2, tile_8_3)
end_variable
begin_variable
var24
-1
4
Atom clear(tile_8_1)
Atom painted(tile_8_1, black)
Atom painted(tile_8_1, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_8_3)
Atom painted(tile_8_3, black)
Atom painted(tile_8_3, white)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom clear(tile_8_2)
Atom painted(tile_8_2, black)
Atom painted(tile_8_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_7_1)
Atom painted(tile_7_1, black)
Atom painted(tile_7_1, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_7_3)
Atom painted(tile_7_3, black)
Atom painted(tile_7_3, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_6_1)
Atom painted(tile_6_1, black)
Atom painted(tile_6_1, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_6_3)
Atom painted(tile_6_3, black)
Atom painted(tile_6_3, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_5_3)
Atom painted(tile_5_3, black)
Atom painted(tile_5_3, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_7_2)
Atom painted(tile_7_2, black)
Atom painted(tile_7_2, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
67
1
5 23
3
85
1
6 23
3
102
1
5 21
3
120
1
6 21
3
143
1
5 19
3
167
1
6 19
8
0
23
2
27 0
5 22
0
47
2
27 0
6 22
0
66
2
12 0
5 22
0
84
2
12 0
6 22
0
103
2
13 0
5 22
0
121
2
13 0
6 22
0
146
2
9 0
5 22
0
170
2
9 0
6 22
8
0
23
2
27 0
5 22
0
47
2
27 0
6 22
0
66
2
12 0
5 22
0
84
2
12 0
6 22
0
103
2
13 0
5 22
0
121
2
13 0
6 22
0
146
2
9 0
5 22
0
170
2
9 0
6 22
8
0
23
2
27 0
5 22
0
47
2
27 0
6 22
0
66
2
12 0
5 22
0
84
2
12 0
6 22
0
103
2
13 0
5 22
0
121
2
13 0
6 22
0
146
2
9 0
5 22
0
170
2
9 0
6 22
end_DTG
begin_DTG
16
1
186
2
5 10
1 0
1
234
2
6 10
0 0
1
276
2
5 4
1 0
1
324
2
6 4
0 0
2
187
2
5 10
1 1
2
235
2
6 10
0 1
2
277
2
5 4
1 1
2
325
2
6 4
0 1
3
11
1
5 10
3
35
1
6 10
3
57
1
5 8
3
75
1
6 8
3
92
1
5 6
3
110
1
6 6
3
128
1
5 4
3
152
1
6 4
8
0
8
2
24 0
5 7
0
32
2
24 0
6 7
0
56
2
14 0
5 7
0
74
2
14 0
6 7
0
93
2
15 0
5 7
0
111
2
15 0
6 7
0
131
2
28 0
5 7
0
155
2
28 0
6 7
8
0
8
2
24 0
5 7
0
32
2
24 0
6 7
0
56
2
14 0
5 7
0
74
2
14 0
6 7
0
93
2
15 0
5 7
0
111
2
15 0
6 7
0
131
2
28 0
5 7
0
155
2
28 0
6 7
8
0
8
2
24 0
5 7
0
32
2
24 0
6 7
0
56
2
14 0
5 7
0
74
2
14 0
6 7
0
93
2
15 0
5 7
0
111
2
15 0
6 7
0
131
2
28 0
5 7
0
155
2
28 0
6 7
end_DTG
begin_DTG
16
1
210
2
5 22
1 0
1
258
2
6 22
0 0
1
300
2
5 16
1 0
1
348
2
6 16
0 0
2
211
2
5 22
1 1
2
259
2
6 22
0 1
2
301
2
5 16
1 1
2
349
2
6 16
0 1
3
23
1
5 22
3
47
1
6 22
3
65
1
5 20
3
83
1
6 20
3
100
1
5 18
3
118
1
6 18
3
140
1
5 16
3
164
1
6 16
8
0
20
2
29 0
5 19
0
44
2
29 0
6 19
0
64
2
16 0
5 19
0
82
2
16 0
6 19
0
101
2
17 0
5 19
0
119
2
17 0
6 19
0
143
2
25 0
5 19
0
167
2
25 0
6 19
8
0
20
2
29 0
5 19
0
44
2
29 0
6 19
0
64
2
16 0
5 19
0
82
2
16 0
6 19
0
101
2
17 0
5 19
0
119
2
17 0
6 19
0
143
2
25 0
5 19
0
167
2
25 0
6 19
8
0
20
2
29 0
5 19
0
44
2
29 0
6 19
0
64
2
16 0
5 19
0
82
2
16 0
6 19
0
101
2
17 0
5 19
0
119
2
17 0
6 19
0
143
2
25 0
5 19
0
167
2
25 0
6 19
end_DTG
begin_DTG
16
1
192
2
5 13
1 0
1
240
2
6 13
0 0
1
282
2
5 7
1 0
1
330
2
6 7
0 0
2
193
2
5 13
1 1
2
241
2
6 13
0 1
2
283
2
5 7
1 1
2
331
2
6 7
0 1
3
14
1
5 13
3
38
1
6 13
3
59
1
5 11
3
77
1
6 11
3
94
1
5 9
3
112
1
6 9
3
131
1
5 7
3
155
1
6 7
8
0
11
2
26 0
5 10
0
35
2
26 0
6 10
0
58
2
18 0
5 10
0
76
2
18 0
6 10
0
95
2
19 0
5 10
0
113
2
19 0
6 10
0
134
2
30 0
5 10
0
158
2
30 0
6 10
8
0
11
2
26 0
5 10
0
35
2
26 0
6 10
0
58
2
18 0
5 10
0
76
2
18 0
6 10
0
95
2
19 0
5 10
0
113
2
19 0
6 10
0
134
2
30 0
5 10
0
158
2
30 0
6 10
8
0
11
2
26 0
5 10
0
35
2
26 0
6 10
0
58
2
18 0
5 10
0
76
2
18 0
6 10
0
95
2
19 0
5 10
0
113
2
19 0
6 10
0
134
2
30 0
5 10
0
158
2
30 0
6 10
end_DTG
begin_DTG
16
1
204
2
5 19
1 0
1
252
2
6 19
0 0
1
294
2
5 13
1 0
1
342
2
6 13
0 0
2
205
2
5 19
1 1
2
253
2
6 19
0 1
2
295
2
5 13
1 1
2
343
2
6 13
0 1
3
20
1
5 19
3
44
1
6 19
3
63
1
5 17
3
81
1
6 17
3
98
1
5 15
3
116
1
6 15
3
137
1
5 13
3
161
1
6 13
8
0
17
2
30 0
5 16
0
41
2
30 0
6 16
0
62
2
20 0
5 16
0
80
2
20 0
6 16
0
99
2
22 0
5 16
0
117
2
22 0
6 16
0
140
2
27 0
5 16
0
164
2
27 0
6 16
8
0
17
2
30 0
5 16
0
41
2
30 0
6 16
0
62
2
20 0
5 16
0
80
2
20 0
6 16
0
99
2
22 0
5 16
0
117
2
22 0
6 16
0
140
2
27 0
5 16
0
164
2
27 0
6 16
8
0
17
2
30 0
5 16
0
41
2
30 0
6 16
0
62
2
20 0
5 16
0
80
2
20 0
6 16
0
99
2
22 0
5 16
0
117
2
22 0
6 16
0
140
2
27 0
5 16
0
164
2
27 0
6 16
end_DTG
begin_DTG
16
1
198
2
5 16
1 0
1
246
2
6 16
0 0
1
288
2
5 10
1 0
1
336
2
6 10
0 0
2
199
2
5 16
1 1
2
247
2
6 16
0 1
2
289
2
5 10
1 1
2
337
2
6 10
0 1
3
17
1
5 16
3
41
1
6 16
3
61
1
5 14
3
79
1
6 14
3
96
1
5 12
3
114
1
6 12
3
134
1
5 10
3
158
1
6 10
8
0
14
2
28 0
5 13
0
38
2
28 0
6 13
0
60
2
21 0
5 13
0
78
2
21 0
6 13
0
97
2
23 0
5 13
0
115
2
23 0
6 13
0
137
2
29 0
5 13
0
161
2
29 0
6 13
8
0
14
2
28 0
5 13
0
38
2
28 0
6 13
0
60
2
21 0
5 13
0
78
2
21 0
6 13
0
97
2
23 0
5 13
0
115
2
23 0
6 13
0
137
2
29 0
5 13
0
161
2
29 0
6 13
8
0
14
2
28 0
5 13
0
38
2
28 0
6 13
0
60
2
21 0
5 13
0
78
2
21 0
6 13
0
97
2
23 0
5 13
0
115
2
23 0
6 13
0
137
2
29 0
5 13
0
161
2
29 0
6 13
end_DTG
begin_CG
27
2 2
4 2
3 2
10 4
24 4
11 4
14 4
26 4
15 4
18 4
28 4
19 4
21 4
30 4
23 4
20 4
29 4
22 4
16 4
27 4
17 4
12 4
25 4
13 4
7 2
9 2
8 2
27
2 2
4 2
3 2
10 4
24 4
11 4
14 4
26 4
15 4
18 4
28 4
19 4
21 4
30 4
23 4
20 4
29 4
22 4
16 4
27 4
17 4
12 4
25 4
13 4
7 2
9 2
8 2
4
4 2
10 2
5 2
6 2
4
4 2
11 2
5 2
6 2
5
2 2
3 2
24 2
5 3
6 3
27
2 6
4 8
3 6
10 10
24 12
11 10
14 10
26 12
15 10
18 10
28 12
19 10
21 10
30 12
23 10
20 10
29 12
22 10
16 10
27 12
17 10
12 10
25 12
13 10
7 6
9 8
8 6
27
2 6
4 8
3 6
10 10
24 12
11 10
14 10
26 12
15 10
18 10
28 12
19 10
21 10
30 12
23 10
20 10
29 12
22 10
16 10
27 12
17 10
12 10
25 12
13 10
7 6
9 8
8 6
4
12 2
9 2
5 2
6 2
4
13 2
9 2
5 2
6 2
5
25 2
7 2
8 2
5 3
6 3
5
2 2
24 2
14 2
5 3
6 3
5
3 2
24 2
15 2
5 3
6 3
5
16 2
25 2
7 2
5 3
6 3
5
17 2
25 2
8 2
5 3
6 3
5
10 2
26 2
18 2
5 3
6 3
5
11 2
26 2
19 2
5 3
6 3
5
20 2
27 2
12 2
5 3
6 3
5
22 2
27 2
13 2
5 3
6 3
5
14 2
28 2
21 2
5 3
6 3
5
15 2
28 2
23 2
5 3
6 3
5
21 2
29 2
16 2
5 3
6 3
5
18 2
30 2
20 2
5 3
6 3
5
23 2
29 2
17 2
5 3
6 3
5
19 2
30 2
22 2
5 3
6 3
6
4 2
10 2
11 2
26 2
5 4
6 4
6
27 2
12 2
13 2
9 2
5 4
6 4
6
24 2
14 2
15 2
28 2
5 4
6 4
6
29 2
16 2
17 2
25 2
5 4
6 4
6
26 2
18 2
19 2
30 2
5 4
6 4
6
30 2
20 2
22 2
27 2
5 4
6 4
6
28 2
21 2
23 2
29 2
5 4
6 4
end_CG
