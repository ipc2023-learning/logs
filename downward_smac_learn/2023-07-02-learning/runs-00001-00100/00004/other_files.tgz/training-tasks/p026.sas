begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var22
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var21
-1
21
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_6_1)
Atom robot-at(robot1, tile_6_2)
Atom robot-at(robot1, tile_6_3)
end_variable
begin_variable
var18
-1
4
Atom clear(tile_6_1)
Atom painted(tile_6_1, black)
Atom painted(tile_6_1, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_6_3)
Atom painted(tile_6_3, black)
Atom painted(tile_6_3, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_6_2)
Atom painted(tile_6_2, black)
Atom painted(tile_6_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_5_3)
Atom painted(tile_5_3, black)
Atom painted(tile_5_3, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_5_2)
Atom painted(tile_5_2, black)
Atom painted(tile_5_2, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
42
begin_mutex_group
4
1 0
1 1
1 2
4 0
end_mutex_group
begin_mutex_group
2
1 0
4 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
4 1
end_mutex_group
begin_mutex_group
2
3 0
4 1
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
4 2
end_mutex_group
begin_mutex_group
2
2 0
4 2
end_mutex_group
begin_mutex_group
4
8 0
8 1
8 2
4 3
end_mutex_group
begin_mutex_group
2
8 0
4 3
end_mutex_group
begin_mutex_group
4
18 0
18 1
18 2
4 4
end_mutex_group
begin_mutex_group
2
18 0
4 4
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
4 5
end_mutex_group
begin_mutex_group
2
9 0
4 5
end_mutex_group
begin_mutex_group
4
12 0
12 1
12 2
4 6
end_mutex_group
begin_mutex_group
2
12 0
4 6
end_mutex_group
begin_mutex_group
4
20 0
20 1
20 2
4 7
end_mutex_group
begin_mutex_group
2
20 0
4 7
end_mutex_group
begin_mutex_group
4
13 0
13 1
13 2
4 8
end_mutex_group
begin_mutex_group
2
13 0
4 8
end_mutex_group
begin_mutex_group
4
15 0
15 1
15 2
4 9
end_mutex_group
begin_mutex_group
2
15 0
4 9
end_mutex_group
begin_mutex_group
4
22 0
22 1
22 2
4 10
end_mutex_group
begin_mutex_group
2
22 0
4 10
end_mutex_group
begin_mutex_group
4
17 0
17 1
17 2
4 11
end_mutex_group
begin_mutex_group
2
17 0
4 11
end_mutex_group
begin_mutex_group
4
14 0
14 1
14 2
4 12
end_mutex_group
begin_mutex_group
2
14 0
4 12
end_mutex_group
begin_mutex_group
4
21 0
21 1
21 2
4 13
end_mutex_group
begin_mutex_group
2
21 0
4 13
end_mutex_group
begin_mutex_gro




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
0
18
2
19 0
4 19
0
32
2
5 0
4 19
0
47
2
6 0
4 19
3
0
18
2
19 0
4 19
0
32
2
5 0
4 19
0
47
2
6 0
4 19
end_DTG
begin_DTG
7
1
72
2
4 6
0 0
1
102
2
4 0
0 0
2
73
2
4 6
0 1
2
103
2
4 0
0 1
3
5
1
4 6
3
22
1
4 4
3
48
1
4 0
3
0
2
2
1 0
4 3
0
36
2
18 0
4 3
0
51
2
12 0
4 3
3
0
2
2
1 0
4 3
0
36
2
18 0
4 3
0
51
2
12 0
4 3
3
0
2
2
1 0
4 3
0
36
2
18 0
4 3
0
51
2
12 0
4 3
end_DTG
begin_DTG
7
1
76
2
4 8
0 0
1
106
2
4 2
0 0
2
77
2
4 8
0 1
2
107
2
4 2
0 1
3
7
1
4 8
3
37
1
4 4
3
50
1
4 2
3
0
4
2
2 0
4 5
0
23
2
18 0
4 5
0
53
2
13 0
4 5
3
0
4
2
2 0
4 5
0
23
2
18 0
4 5
0
53
2
13 0
4 5
3
0
4
2
2 0
4 5
0
23
2
18 0
4 5
0
53
2
13 0
4 5
end_DTG
begin_DTG
7
1
96
2
4 18
0 0
1
126
2
4 12
0 0
2
97
2
4 18
0 1
2
127
2
4 12
0 1
3
17
1
4 18
3
30
1
4 16
3
60
1
4 12
3
0
14
2
14 0
4 15
0
44
2
19 0
4 15
0
63
2
5 0
4 15
3
0
14
2
14 0
4 15
0
44
2
19 0
4 15
0
63
2
5 0
4 15
3
0
14
2
14 0
4 15
0
44
2
19 0
4 15
0
63
2
5 0
4 15
end_DTG
begin_DTG
7
1
100
2
4 20
0 0
1
130
2
4 14
0 0
2
101
2
4 20
0 1
2
131
2
4 14
0 1
3
19
1
4 20
3
45
1
4 16
3
62
1
4 14
3
0
16
2
16 0
4 17
0
31
2
19 0
4 17
0
65
2
6 0
4 17
3
0
16
2
16 0
4 17
0
31
2
19 0
4 17
0
65
2
6 0
4 17
3
0
16
2
16 0
4 17
0
31
2
19 0
4 17
0
65
2
6 0
4 17
end_DTG
begin_DTG
7
1
78
2
4 9
0 0
1
108
2
4 3
0 0
2
79
2
4 9
0 1
2
109
2
4 3
0 1
3
8
1
4 9
3
24
1
4 7
3
51
1
4 3
3
0
5
2
8 0
4 6
0
38
2
20 0
4 6
0
54
2
15 0
4 6
3
0
5
2
8 0
4 6
0
38
2
20 0
4 6
0
54
2
15 0
4 6
3
0
5
2
8 0
4 6
0
38
2
20 0
4 6
0
54
2
15 0
4 6
end_DTG
begin_DTG
7
1
82
2
4 11
0 0
1
112
2
4 5
0 0
2
83
2
4 11
0 1
2
113
2
4 5
0 1
3
10
1
4 11
3
39
1
4 7
3
53
1
4 5
3
0
7
2
9 0
4 8
0
25
2
20 0
4 8
0
56
2
17 0
4 8
3
0
7
2
9 0
4 8
0
25
2
20 0
4 8
0
56
2
17 0
4 8
3
0
7
2
9 0
4 8
0
25
2
20 0
4 8
0
56
2
17 0
4 8
end_DTG
begin_DTG
7
1
90
2
4 15
0 0
1
120
2
4 9
0 0
2
91
2
4 15
0 1
2
121
2
4 9
0 1
3
14
1
4 15
3
28
1
4 13
3
57
1
4 9
3
0
11
2
15 0
4 12
0
42
2
21 0
4 12
0
60
2
10 0
4 12
3
0
11
2
15 0
4 12
0
42
2
21 0
4 12
0
60
2
10 0
4 12
3
0
11
2
15 0
4 12
0
42
2
21 0
4 12
0
60
2
10 0
4 12
end_DTG
begin_DTG
7
1
84
2
4 12
0 0
1
114
2
4 6
0 0
2
85
2
4 12
0 1
2
115
2
4 6
0 1
3
11
1
4 12
3
26
1
4 10
3
54
1
4 6
3
0
8
2
12 0
4 9
0
40
2
22 0
4 9
0
57
2
14 0
4 9
3
0
8
2
12 0
4 9
0
40
2
22 0
4 9
0
57
2
14 0
4 9
3
0
8
2
12 0
4 9
0
40
2
22 0
4 9
0
57
2
14 0
4 9
end_DTG
begin_DTG
7
1
94
2
4 17
0 0
1
124
2
4 11
0 0
2
95
2
4 17
0 1
2
125
2
4 11
0 1
3
16
1
4 17
3
43
1
4 13
3
59
1
4 11
3
0
13
2
17 0
4 14
0
29
2
21 0
4 14
0
62
2
11 0
4 14
3
0
13
2
17 0
4 14
0
29
2
21 0
4 14
0
62
2
11 0
4 14
3
0
13
2
17 0
4 14
0
29
2
21 0
4 14
0
62
2
11 0
4 14
end_DTG
begin_DTG
7
1
88
2
4 14
0 0
1
118
2
4 8
0 0
2
89
2
4 14
0 1
2
119
2
4 8
0 1
3
13
1
4 14
3
41
1
4 10
3
56
1
4 8
3
0
10
2
13 0
4 11
0
27
2
22 0
4 11
0
59
2
16 0
4 11
3
0
10
2
13 0
4 11
0
27
2
22 0
4 11
0
59
2
16 0
4 11
3
0
10
2
13 0
4 11
0
27
2
22 0
4 11
0
59
2
16 0
4 11
end_DTG
begin_DTG
8
1
74
2
4 7
0 0
1
104
2
4 1
0 0
2
75
2
4 7
0 1
2
105
2
4 1
0 1
3
6
1
4 7
3
23
1
4 5
3
36
1
4 3
3
49
1
4 1
4
0
3
2
3 0
4 4
0
22
2
8 0
4 4
0
37
2
9 0
4 4
0
52
2
20 0
4 4
4
0
3
2
3 0
4 4
0
22
2
8 0
4 4
0
37
2
9 0
4 4
0
52
2
20 0
4 4
4
0
3
2
3 0
4 4
0
22
2
8 0
4 4
0
37
2
9 0
4 4
0
52
2
20 0
4 4
end_DTG
begin_DTG
8
1
98
2
4 19
0 0
1
128
2
4 13
0 0
2
99
2
4 19
0 1
2
129
2
4 13
0 1
3
18
1
4 19
3
31
1
4 17
3
44
1
4 15
3
61
1
4 13
4
0
15
2
21 0
4 16
0
30
2
10 0
4 16
0
45
2
11 0
4 16
0
64
2
7 0
4 16
4
0
15
2
21 0
4 16
0
30
2
10 0
4 16
0
45
2
11 0
4 16
0
64
2
7 0
4 16
4
0
15
2
21 0
4 16
0
30
2
10 0
4 16
0
45
2
11 0
4 16
0
64
2
7 0
4 16
end_DTG
begin_DTG
8
1
80
2
4 10
0 0
1
110
2
4 4
0 0
2
81
2
4 10
0 1
2
111
2
4 4
0 1
3
9
1
4 10
3
25
1
4 8
3
38
1
4 6
3
52
1
4 4
4
0
6
2
18 0
4 7
0
24
2
12 0
4 7
0
39
2
13 0
4 7
0
55
2
22 0
4 7
4
0
6
2
18 0
4 7
0
24
2
12 0
4 7
0
39
2
13 0
4 7
0
55
2
22 0
4 7
4
0
6
2
18 0
4 7
0
24
2
12 0
4 7
0
39
2
13 0
4 7
0
55
2
22 0
4 7
end_DTG
begin_DTG
8
1
92
2
4 16
0 0
1
122
2
4 10
0 0
2
93
2
4 16
0 1
2
123
2
4 10
0 1
3
15
1
4 16
3
29
1
4 14
3
42
1
4 12
3
58
1
4 10
4
0
12
2
22 0
4 13
0
28
2
14 0
4 13
0
43
2
16 0
4 13
0
61
2
19 0
4 13
4
0
12
2
22 0
4 13
0
28
2
14 0
4 13
0
43
2
16 0
4 13
0
61
2
19 0
4 13
4
0
12
2
22 0
4 13
0
28
2
14 0
4 13
0
43
2
16 0
4 13
0
61
2
19 0
4 13
end_DTG
begin_DTG
8
1
86
2
4 13
0 0
1
116
2
4 7
0 0
2
87
2
4 13
0 1
2
117
2
4 7
0 1
3
12
1
4 13
3
27
1
4 11
3
40
1
4 9
3
55
1
4 7
4
0
9
2
20 0
4 10
0
26
2
15 0
4 10
0
41
2
17 0
4 10
0
58
2
21 0
4 10
4
0
9
2
20 0
4 10
0
26
2
15 0
4 10
0
41
2
17 0
4 10
0
58
2
21 0
4 10
4
0
9
2
20 0
4 10
0
26
2
15 0
4 10
0
41
2
17 0
4 10
0
58
2
21 0
4 10
end_DTG
begin_CG
21
1 2
3 2
2 2
8 4
18 4
9 4
12 4
20 4
13 4
15 4
22 4
17 4
14 4
21 4
16 4
10 4
19 4
11 4
5 2
7 2
6 2
3
3 1
8 1
4 2
3
3 1
9 1
4 2
4
1 1
2 1
18 1
4 3
21
1 6
3 8
2 6
8 10
18 12
9 10
12 10
20 12
13 10
15 10
22 12
17 10
14 10
21 12
16 10
10 10
19 12
11 10
5 6
7 8
6 6
3
10 1
7 1
4 2
3
11 1
7 1
4 2
4
19 1
5 1
6 1
4 3
4
1 1
18 1
12 1
4 3
4
2 1
18 1
13 1
4 3
4
14 1
19 1
5 1
4 3
4
16 1
19 1
6 1
4 3
4
8 1
20 1
15 1
4 3
4
9 1
20 1
17 1
4 3
4
15 1
21 1
10 1
4 3
4
12 1
22 1
14 1
4 3
4
17 1
21 1
11 1
4 3
4
13 1
22 1
16 1
4 3
5
3 1
8 1
9 1
20 1
4 4
5
21 1
10 1
11 1
7 1
4 4
5
18 1
12 1
13 1
22 1
4 4
5
22 1
14 1
16 1
19 1
4 4
5
20 1
15 1
17 1
21 1
4 4
end_CG
