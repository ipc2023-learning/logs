begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var33
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var32
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var30
-1
30
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_6_1)
Atom robot-at(robot1, tile_6_2)
Atom robot-at(robot1, tile_6_3)
Atom robot-at(robot1, tile_7_1)
Atom robot-at(robot1, tile_7_2)
Atom robot-at(robot1, tile_7_3)
Atom robot-at(robot1, tile_8_1)
Atom robot-at(robot1, tile_8_2)
Atom robot-at(robot1, tile_8_3)
Atom robot-at(robot1, tile_9_1)
Atom robot-at(robot1, tile_9_2)
Atom robot-at(robot1, tile_9_3)
end_variable
begin_variable
var31
-1
30
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_5_1)
Atom robot-at(robot2, tile_5_2)
Atom robot-at(robot2, tile_5_3)
Atom robot-at(robot2, tile_6_1)
Atom robot-at(robot2, tile_6_2)
Atom robot-at(robot2, tile_6_3)
Atom robot-at(robot2, tile_7_1)
Atom robot-at(robot2, tile_7_2)
Atom robot-at(robot2, tile_7_3)
Atom robot-at(robot2, tile_8_1)
Atom robot-at(robot2, tile_8_2)
Atom robot-at(robot2, tile_8_3)
Atom robot-at(robot2, tile_9_1)
Atom robot-at(robot2, tile_9_2)
Atom robot-at(robot2, tile_9_3)
end_variable
begin_variable
var27
-1
4
Atom clear(tile_9_1)
Atom painted(tile_9_1, black)
Atom painted(tile_9_1, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_9_3)
Atom painted(tile_9_3, black)
Atom painted(tile_9_3, white)
<none of those>
end_variable
begin_variable
var28
-1
4
Atom clear(tile_9_2)
Atom painted(tile_9_2, black)
Atom painted(tile_9_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom clear(tile_8_1)
Atom painted(tile_8_1, black)
Atom painted(tile_8_1, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_8_3)
Atom painted(tile_8_3, black)
Atom painted(tile_8_3, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_7_1)
Atom painted(tile_7_1, black)
Atom painted(tile_7_1, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_7_3)
Atom painted(tile_7_3, black)
Atom painted(tile_7_3, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_6_1)
Atom painted(tile_6_1, black)
Atom painted(tile_6_1, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_6_3)
Atom painted(tile_6_3, black)
Atom painted(tile_6_3, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
va




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




45
2
30 0
5 7
0
172
2
30 0
6 7
8
0
8
2
26 0
5 7
0
35
2
26 0
6 7
0
62
2
14 0
5 7
0
82
2
14 0
6 7
0
103
2
15 0
5 7
0
123
2
15 0
6 7
0
145
2
30 0
5 7
0
172
2
30 0
6 7
8
0
8
2
26 0
5 7
0
35
2
26 0
6 7
0
62
2
14 0
5 7
0
82
2
14 0
6 7
0
103
2
15 0
5 7
0
123
2
15 0
6 7
0
145
2
30 0
5 7
0
172
2
30 0
6 7
end_DTG
begin_DTG
16
1
236
2
5 25
1 0
1
290
2
6 25
0 0
1
338
2
5 19
1 0
1
392
2
6 19
0 0
2
237
2
5 25
1 1
2
291
2
6 25
0 1
2
339
2
5 19
1 1
2
393
2
6 19
0 1
3
26
1
5 25
3
53
1
6 25
3
73
1
5 23
3
93
1
6 23
3
112
1
5 21
3
132
1
6 21
3
157
1
5 19
3
184
1
6 19
8
0
23
2
31 0
5 22
0
50
2
31 0
6 22
0
72
2
16 0
5 22
0
92
2
16 0
6 22
0
113
2
17 0
5 22
0
133
2
17 0
6 22
0
160
2
27 0
5 22
0
187
2
27 0
6 22
8
0
23
2
31 0
5 22
0
50
2
31 0
6 22
0
72
2
16 0
5 22
0
92
2
16 0
6 22
0
113
2
17 0
5 22
0
133
2
17 0
6 22
0
160
2
27 0
5 22
0
187
2
27 0
6 22
8
0
23
2
31 0
5 22
0
50
2
31 0
6 22
0
72
2
16 0
5 22
0
92
2
16 0
6 22
0
113
2
17 0
5 22
0
133
2
17 0
6 22
0
160
2
27 0
5 22
0
187
2
27 0
6 22
end_DTG
begin_DTG
16
1
212
2
5 13
1 0
1
266
2
6 13
0 0
1
314
2
5 7
1 0
1
368
2
6 7
0 0
2
213
2
5 13
1 1
2
267
2
6 13
0 1
2
315
2
5 7
1 1
2
369
2
6 7
0 1
3
14
1
5 13
3
41
1
6 13
3
65
1
5 11
3
85
1
6 11
3
104
1
5 9
3
124
1
6 9
3
145
1
5 7
3
172
1
6 7
8
0
11
2
28 0
5 10
0
38
2
28 0
6 10
0
64
2
18 0
5 10
0
84
2
18 0
6 10
0
105
2
19 0
5 10
0
125
2
19 0
6 10
0
148
2
32 0
5 10
0
175
2
32 0
6 10
8
0
11
2
28 0
5 10
0
38
2
28 0
6 10
0
64
2
18 0
5 10
0
84
2
18 0
6 10
0
105
2
19 0
5 10
0
125
2
19 0
6 10
0
148
2
32 0
5 10
0
175
2
32 0
6 10
8
0
11
2
28 0
5 10
0
38
2
28 0
6 10
0
64
2
18 0
5 10
0
84
2
18 0
6 10
0
105
2
19 0
5 10
0
125
2
19 0
6 10
0
148
2
32 0
5 10
0
175
2
32 0
6 10
end_DTG
begin_DTG
16
1
230
2
5 22
1 0
1
284
2
6 22
0 0
1
332
2
5 16
1 0
1
386
2
6 16
0 0
2
231
2
5 22
1 1
2
285
2
6 22
0 1
2
333
2
5 16
1 1
2
387
2
6 16
0 1
3
23
1
5 22
3
50
1
6 22
3
71
1
5 20
3
91
1
6 20
3
110
1
5 18
3
130
1
6 18
3
154
1
5 16
3
181
1
6 16
8
0
20
2
33 0
5 19
0
47
2
33 0
6 19
0
70
2
20 0
5 19
0
90
2
20 0
6 19
0
111
2
21 0
5 19
0
131
2
21 0
6 19
0
157
2
29 0
5 19
0
184
2
29 0
6 19
8
0
20
2
33 0
5 19
0
47
2
33 0
6 19
0
70
2
20 0
5 19
0
90
2
20 0
6 19
0
111
2
21 0
5 19
0
131
2
21 0
6 19
0
157
2
29 0
5 19
0
184
2
29 0
6 19
8
0
20
2
33 0
5 19
0
47
2
33 0
6 19
0
70
2
20 0
5 19
0
90
2
20 0
6 19
0
111
2
21 0
5 19
0
131
2
21 0
6 19
0
157
2
29 0
5 19
0
184
2
29 0
6 19
end_DTG
begin_DTG
16
1
218
2
5 16
1 0
1
272
2
6 16
0 0
1
320
2
5 10
1 0
1
374
2
6 10
0 0
2
219
2
5 16
1 1
2
273
2
6 16
0 1
2
321
2
5 10
1 1
2
375
2
6 10
0 1
3
17
1
5 16
3
44
1
6 16
3
67
1
5 14
3
87
1
6 14
3
106
1
5 12
3
126
1
6 12
3
148
1
5 10
3
175
1
6 10
8
0
14
2
30 0
5 13
0
41
2
30 0
6 13
0
66
2
22 0
5 13
0
86
2
22 0
6 13
0
107
2
24 0
5 13
0
127
2
24 0
6 13
0
151
2
33 0
5 13
0
178
2
33 0
6 13
8
0
14
2
30 0
5 13
0
41
2
30 0
6 13
0
66
2
22 0
5 13
0
86
2
22 0
6 13
0
107
2
24 0
5 13
0
127
2
24 0
6 13
0
151
2
33 0
5 13
0
178
2
33 0
6 13
8
0
14
2
30 0
5 13
0
41
2
30 0
6 13
0
66
2
22 0
5 13
0
86
2
22 0
6 13
0
107
2
24 0
5 13
0
127
2
24 0
6 13
0
151
2
33 0
5 13
0
178
2
33 0
6 13
end_DTG
begin_DTG
16
1
224
2
5 19
1 0
1
278
2
6 19
0 0
1
326
2
5 13
1 0
1
380
2
6 13
0 0
2
225
2
5 19
1 1
2
279
2
6 19
0 1
2
327
2
5 13
1 1
2
381
2
6 13
0 1
3
20
1
5 19
3
47
1
6 19
3
69
1
5 17
3
89
1
6 17
3
108
1
5 15
3
128
1
6 15
3
151
1
5 13
3
178
1
6 13
8
0
17
2
32 0
5 16
0
44
2
32 0
6 16
0
68
2
23 0
5 16
0
88
2
23 0
6 16
0
109
2
25 0
5 16
0
129
2
25 0
6 16
0
154
2
31 0
5 16
0
181
2
31 0
6 16
8
0
17
2
32 0
5 16
0
44
2
32 0
6 16
0
68
2
23 0
5 16
0
88
2
23 0
6 16
0
109
2
25 0
5 16
0
129
2
25 0
6 16
0
154
2
31 0
5 16
0
181
2
31 0
6 16
8
0
17
2
32 0
5 16
0
44
2
32 0
6 16
0
68
2
23 0
5 16
0
88
2
23 0
6 16
0
109
2
25 0
5 16
0
129
2
25 0
6 16
0
154
2
31 0
5 16
0
181
2
31 0
6 16
end_DTG
begin_CG
30
2 2
4 2
3 2
10 4
26 4
11 4
14 4
28 4
15 4
18 4
30 4
19 4
22 4
32 4
24 4
23 4
33 4
25 4
20 4
31 4
21 4
16 4
29 4
17 4
12 4
27 4
13 4
7 2
9 2
8 2
30
2 2
4 2
3 2
10 4
26 4
11 4
14 4
28 4
15 4
18 4
30 4
19 4
22 4
32 4
24 4
23 4
33 4
25 4
20 4
31 4
21 4
16 4
29 4
17 4
12 4
27 4
13 4
7 2
9 2
8 2
4
4 2
10 2
5 2
6 2
4
4 2
11 2
5 2
6 2
5
2 2
3 2
26 2
5 3
6 3
30
2 6
4 8
3 6
10 10
26 12
11 10
14 10
28 12
15 10
18 10
30 12
19 10
22 10
32 12
24 10
23 10
33 12
25 10
20 10
31 12
21 10
16 10
29 12
17 10
12 10
27 12
13 10
7 6
9 8
8 6
30
2 6
4 8
3 6
10 10
26 12
11 10
14 10
28 12
15 10
18 10
30 12
19 10
22 10
32 12
24 10
23 10
33 12
25 10
20 10
31 12
21 10
16 10
29 12
17 10
12 10
27 12
13 10
7 6
9 8
8 6
4
12 2
9 2
5 2
6 2
4
13 2
9 2
5 2
6 2
5
27 2
7 2
8 2
5 3
6 3
5
2 2
26 2
14 2
5 3
6 3
5
3 2
26 2
15 2
5 3
6 3
5
16 2
27 2
7 2
5 3
6 3
5
17 2
27 2
8 2
5 3
6 3
5
10 2
28 2
18 2
5 3
6 3
5
11 2
28 2
19 2
5 3
6 3
5
20 2
29 2
12 2
5 3
6 3
5
21 2
29 2
13 2
5 3
6 3
5
14 2
30 2
22 2
5 3
6 3
5
15 2
30 2
24 2
5 3
6 3
5
23 2
31 2
16 2
5 3
6 3
5
25 2
31 2
17 2
5 3
6 3
5
18 2
32 2
23 2
5 3
6 3
5
22 2
33 2
20 2
5 3
6 3
5
19 2
32 2
25 2
5 3
6 3
5
24 2
33 2
21 2
5 3
6 3
6
4 2
10 2
11 2
28 2
5 4
6 4
6
29 2
12 2
13 2
9 2
5 4
6 4
6
26 2
14 2
15 2
30 2
5 4
6 4
6
31 2
16 2
17 2
27 2
5 4
6 4
6
28 2
18 2
19 2
32 2
5 4
6 4
6
33 2
20 2
21 2
29 2
5 4
6 4
6
30 2
22 2
24 2
33 2
5 4
6 4
6
32 2
23 2
25 2
31 2
5 4
6 4
end_CG
