begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var33
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var32
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var30
-1
30
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_4_5)
Atom robot-at(robot1, tile_4_6)
end_variable
begin_variable
var31
-1
30
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_0_5)
Atom robot-at(robot2, tile_0_6)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_1_5)
Atom robot-at(robot2, tile_1_6)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_2_5)
Atom robot-at(robot2, tile_2_6)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_3_5)
Atom robot-at(robot2, tile_3_6)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_4_4)
Atom robot-at(robot2, tile_4_5)
Atom robot-at(robot2, tile_4_6)
end_variable
begin_variable
var24
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_4_6)
Atom painted(tile_4_6, black)
Atom painted(tile_4_6, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_1_6)
Atom painted(tile_1_6, black)
Atom painted(tile_1_6, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_3_6)
Atom painted(tile_3_6, black)
Atom painted(tile_3_6, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_2_6)
Atom painted(tile_2_6, black)
Atom painted(tile_2_6, white)
<none of those>
end_variable
begin_variable
var28
-1
4
Atom clear(tile_4_5)
Atom painted(tile_4_5, black)
Atom painted(tile_4_5, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_4_4)
Atom painted(tile_4_4, black)
Atom painted(tile_4_4, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_1_5)
Atom painted(tile_1_5, black)
Atom painted(tile_1_5, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
va




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
9 8
0
109
2
29 0
8 8
0
134
2
29 0
9 8
0
160
2
31 0
8 8
0
184
2
31 0
9 8
8
0
6
2
6 0
8 8
0
30
2
6 0
9 8
0
58
2
22 0
8 8
0
83
2
22 0
9 8
0
109
2
29 0
8 8
0
134
2
29 0
9 8
0
160
2
31 0
8 8
0
184
2
31 0
9 8
8
0
6
2
6 0
8 8
0
30
2
6 0
9 8
0
58
2
22 0
8 8
0
83
2
22 0
9 8
0
109
2
29 0
8 8
0
134
2
29 0
9 8
0
160
2
31 0
8 8
0
184
2
31 0
9 8
end_DTG
begin_DTG
16
1
218
2
8 15
1 0
1
266
2
9 15
0 0
1
302
2
8 3
1 0
1
350
2
9 3
0 0
2
219
2
8 15
1 1
2
267
2
9 15
0 1
2
303
2
8 3
1 1
2
351
2
9 3
0 1
3
13
1
8 15
3
37
1
9 15
3
60
1
8 10
3
85
1
9 10
3
109
1
8 8
3
134
1
9 8
3
155
1
8 3
3
179
1
9 3
8
0
7
2
7 0
8 9
0
31
2
7 0
9 9
0
59
2
28 0
8 9
0
84
2
28 0
9 9
0
110
2
23 0
8 9
0
135
2
23 0
9 9
0
161
2
33 0
8 9
0
185
2
33 0
9 9
8
0
7
2
7 0
8 9
0
31
2
7 0
9 9
0
59
2
28 0
8 9
0
84
2
28 0
9 9
0
110
2
23 0
8 9
0
135
2
23 0
9 9
0
161
2
33 0
8 9
0
185
2
33 0
9 9
8
0
7
2
7 0
8 9
0
31
2
7 0
9 9
0
59
2
28 0
8 9
0
84
2
28 0
9 9
0
110
2
23 0
8 9
0
135
2
23 0
9 9
0
161
2
33 0
8 9
0
185
2
33 0
9 9
end_DTG
begin_DTG
16
1
240
2
8 26
1 0
1
288
2
9 26
0 0
1
324
2
8 14
1 0
1
372
2
9 14
0 0
2
241
2
8 26
1 1
2
289
2
9 26
0 1
2
325
2
8 14
1 1
2
373
2
9 14
0 1
3
24
1
8 26
3
48
1
9 26
3
69
1
8 21
3
94
1
9 21
3
118
1
8 19
3
143
1
9 19
3
166
1
8 14
3
190
1
9 14
8
0
18
2
31 0
8 20
0
42
2
31 0
9 20
0
68
2
24 0
8 20
0
93
2
24 0
9 20
0
119
2
32 0
8 20
0
144
2
32 0
9 20
0
172
2
20 0
8 20
0
196
2
20 0
9 20
8
0
18
2
31 0
8 20
0
42
2
31 0
9 20
0
68
2
24 0
8 20
0
93
2
24 0
9 20
0
119
2
32 0
8 20
0
144
2
32 0
9 20
0
172
2
20 0
8 20
0
196
2
20 0
9 20
8
0
18
2
31 0
8 20
0
42
2
31 0
9 20
0
68
2
24 0
8 20
0
93
2
24 0
9 20
0
119
2
32 0
8 20
0
144
2
32 0
9 20
0
172
2
20 0
8 20
0
196
2
20 0
9 20
end_DTG
begin_DTG
16
1
228
2
8 20
1 0
1
276
2
9 20
0 0
1
312
2
8 8
1 0
1
360
2
9 8
0 0
2
229
2
8 20
1 1
2
277
2
9 20
0 1
2
313
2
8 8
1 1
2
361
2
9 8
0 1
3
18
1
8 20
3
42
1
9 20
3
64
1
8 15
3
89
1
9 15
3
113
1
8 13
3
138
1
9 13
3
160
1
8 8
3
184
1
9 8
8
0
12
2
28 0
8 14
0
36
2
28 0
9 14
0
63
2
25 0
8 14
0
88
2
25 0
9 14
0
114
2
33 0
8 14
0
139
2
33 0
9 14
0
166
2
30 0
8 14
0
190
2
30 0
9 14
8
0
12
2
28 0
8 14
0
36
2
28 0
9 14
0
63
2
25 0
8 14
0
88
2
25 0
9 14
0
114
2
33 0
8 14
0
139
2
33 0
9 14
0
166
2
30 0
8 14
0
190
2
30 0
9 14
8
0
12
2
28 0
8 14
0
36
2
28 0
9 14
0
63
2
25 0
8 14
0
88
2
25 0
9 14
0
114
2
33 0
8 14
0
139
2
33 0
9 14
0
166
2
30 0
8 14
0
190
2
30 0
9 14
end_DTG
begin_DTG
16
1
242
2
8 27
1 0
1
290
2
9 27
0 0
1
326
2
8 15
1 0
1
374
2
9 15
0 0
2
243
2
8 27
1 1
2
291
2
9 27
0 1
2
327
2
8 15
1 1
2
375
2
9 15
0 1
3
25
1
8 27
3
49
1
9 27
3
70
1
8 22
3
95
1
9 22
3
119
1
8 20
3
144
1
9 20
3
167
1
8 15
3
191
1
9 15
8
0
19
2
33 0
8 21
0
43
2
33 0
9 21
0
69
2
30 0
8 21
0
94
2
30 0
9 21
0
120
2
26 0
8 21
0
145
2
26 0
9 21
0
173
2
21 0
8 21
0
197
2
21 0
9 21
8
0
19
2
33 0
8 21
0
43
2
33 0
9 21
0
69
2
30 0
8 21
0
94
2
30 0
9 21
0
120
2
26 0
8 21
0
145
2
26 0
9 21
0
173
2
21 0
8 21
0
197
2
21 0
9 21
8
0
19
2
33 0
8 21
0
43
2
33 0
9 21
0
69
2
30 0
8 21
0
94
2
30 0
9 21
0
120
2
26 0
8 21
0
145
2
26 0
9 21
0
173
2
21 0
8 21
0
197
2
21 0
9 21
end_DTG
begin_DTG
16
1
230
2
8 21
1 0
1
278
2
9 21
0 0
1
314
2
8 9
1 0
1
362
2
9 9
0 0
2
231
2
8 21
1 1
2
279
2
9 21
0 1
2
315
2
8 9
1 1
2
363
2
9 9
0 1
3
19
1
8 21
3
43
1
9 21
3
65
1
8 16
3
90
1
9 16
3
114
1
8 14
3
139
1
9 14
3
161
1
8 9
3
185
1
9 9
8
0
13
2
29 0
8 15
0
37
2
29 0
9 15
0
64
2
31 0
8 15
0
89
2
31 0
9 15
0
115
2
27 0
8 15
0
140
2
27 0
9 15
0
167
2
32 0
8 15
0
191
2
32 0
9 15
8
0
13
2
29 0
8 15
0
37
2
29 0
9 15
0
64
2
31 0
8 15
0
89
2
31 0
9 15
0
115
2
27 0
8 15
0
140
2
27 0
9 15
0
167
2
32 0
8 15
0
191
2
32 0
9 15
8
0
13
2
29 0
8 15
0
37
2
29 0
9 15
0
64
2
31 0
8 15
0
89
2
31 0
9 15
0
115
2
27 0
8 15
0
140
2
27 0
9 15
0
167
2
32 0
8 15
0
191
2
32 0
9 15
end_DTG
begin_CG
30
2 2
4 2
6 2
7 2
5 2
3 2
12 4
22 4
28 4
29 4
23 4
13 4
15 4
25 4
31 4
33 4
27 4
18 4
14 4
24 4
30 4
32 4
26 4
17 4
10 2
16 2
20 2
21 2
19 2
11 2
30
2 2
4 2
6 2
7 2
5 2
3 2
12 4
22 4
28 4
29 4
23 4
13 4
15 4
25 4
31 4
33 4
27 4
18 4
14 4
24 4
30 4
32 4
26 4
17 4
10 2
16 2
20 2
21 2
19 2
11 2
4
4 2
12 2
8 2
9 2
4
5 2
13 2
8 2
9 2
5
2 2
6 2
22 2
8 3
9 3
5
7 2
3 2
23 2
8 3
9 3
5
4 2
7 2
28 2
8 3
9 3
5
6 2
5 2
29 2
8 3
9 3
30
2 6
4 8
6 8
7 8
5 8
3 6
12 10
22 12
28 12
29 12
23 12
13 10
15 10
25 12
31 12
33 12
27 12
18 10
14 10
24 12
30 12
32 12
26 12
17 10
10 6
16 8
20 8
21 8
19 8
11 6
30
2 6
4 8
6 8
7 8
5 8
3 6
12 10
22 12
28 12
29 12
23 12
13 10
15 10
25 12
31 12
33 12
27 12
18 10
14 10
24 12
30 12
32 12
26 12
17 10
10 6
16 8
20 8
21 8
19 8
11 6
4
14 2
16 2
8 2
9 2
4
17 2
19 2
8 2
9 2
5
2 2
22 2
15 2
8 3
9 3
5
3 2
23 2
18 2
8 3
9 3
5
15 2
24 2
10 2
8 3
9 3
5
12 2
25 2
14 2
8 3
9 3
5
24 2
10 2
20 2
8 3
9 3
5
18 2
26 2
11 2
8 3
9 3
5
13 2
27 2
17 2
8 3
9 3
5
26 2
21 2
11 2
8 3
9 3
5
30 2
16 2
21 2
8 3
9 3
5
32 2
20 2
19 2
8 3
9 3
6
4 2
12 2
28 2
25 2
8 4
9 4
6
5 2
29 2
13 2
27 2
8 4
9 4
6
25 2
14 2
30 2
16 2
8 4
9 4
6
22 2
15 2
31 2
24 2
8 4
9 4
6
27 2
32 2
17 2
19 2
8 4
9 4
6
23 2
33 2
18 2
26 2
8 4
9 4
6
6 2
22 2
29 2
31 2
8 4
9 4
6
7 2
28 2
23 2
33 2
8 4
9 4
6
31 2
24 2
32 2
20 2
8 4
9 4
6
28 2
25 2
33 2
30 2
8 4
9 4
6
33 2
30 2
26 2
21 2
8 4
9 4
6
29 2
31 2
27 2
32 2
8 4
9 4
end_CG
