begin_version
3
end_version
begin_metric
0
end_metric
38
begin_variable
var37
-1
2
Atom robot-has(robot3, black)
Atom robot-has(robot3, white)
end_variable
begin_variable
var36
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var35
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var32
-1
32
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_5_4)
Atom robot-at(robot1, tile_6_1)
Atom robot-at(robot1, tile_6_2)
Atom robot-at(robot1, tile_6_3)
Atom robot-at(robot1, tile_6_4)
Atom robot-at(robot1, tile_7_1)
Atom robot-at(robot1, tile_7_2)
Atom robot-at(robot1, tile_7_3)
Atom robot-at(robot1, tile_7_4)
end_variable
begin_variable
var33
-1
32
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_4_4)
Atom robot-at(robot2, tile_5_1)
Atom robot-at(robot2, tile_5_2)
Atom robot-at(robot2, tile_5_3)
Atom robot-at(robot2, tile_5_4)
Atom robot-at(robot2, tile_6_1)
Atom robot-at(robot2, tile_6_2)
Atom robot-at(robot2, tile_6_3)
Atom robot-at(robot2, tile_6_4)
Atom robot-at(robot2, tile_7_1)
Atom robot-at(robot2, tile_7_2)
Atom robot-at(robot2, tile_7_3)
Atom robot-at(robot2, tile_7_4)
end_variable
begin_variable
var34
-1
32
Atom robot-at(robot3, tile_0_1)
Atom robot-at(robot3, tile_0_2)
Atom robot-at(robot3, tile_0_3)
Atom robot-at(robot3, tile_0_4)
Atom robot-at(robot3, tile_1_1)
Atom robot-at(robot3, tile_1_2)
Atom robot-at(robot3, tile_1_3)
Atom robot-at(robot3, tile_1_4)
Atom robot-at(robot3, tile_2_1)
Atom robot-at(robot3, tile_2_2)
Atom robot-at(robot3, tile_2_3)
Atom robot-at(robot3, tile_2_4)
Atom robot-at(robot3, tile_3_1)
Atom robot-at(robot3, tile_3_2)
Atom robot-at(robot3, tile_3_3)
Atom robot-at(robot3, tile_3_4)
Atom robot-at(robot3, tile_4_1)
Atom robot-at(robot3, tile_4_2)
Atom robot-at(robot3, tile_4_3)
Atom robot-at(robot3, tile_4_4)
Atom robot-at(robot3, tile_5_1)
Atom robot-at(robot3, tile_5_2)
Atom robot-at(robot3, tile_5_3)
Atom robot-at(robot3, tile_5_4)
Atom robot-at(robot3, tile_6_1)
Atom robot-at(robot3, tile_6_2)
Atom robot-at(robot3, tile_6_3)
Atom robot-at(robot3, tile_6_4)
Atom robot-at(robot3, tile_7_1)
Atom robot-at(robot3, tile_7_2)
Atom robot-at(robot3, tile_7_3)
Atom robot-at(robot3, tile_7_4)
end_variable
begin_variable
var28
-1
4
Atom clear(tile_7_1)
Atom painted(tile_7_1, black)
Atom painted(tile_7_1, white)
<none of those>
end_variable
begin_variable
var31
-1
4
Atom clear(tile_7_4)
Atom painted(tile_7_4, black)
Atom painted(tile_7_4, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom clear(tile_6_1)
Atom painted(tile_6_1, black)
Atom painted(tile_6_1, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_7_2)
Atom painted(tile_7_2, black)
Atom painted(tile_7_2, white)
<none of those>
end_variable
begin_variable
var30
-1
4
Atom clear(tile_7_3)
Atom painted(tile_7_3, black)
Atom painted(tile_7_3, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_6_4)
Atom painted(tile_6_4, black)
Atom pa




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




275
2
36 0
8 13
0
303
2
36 0
9 13
end_DTG
begin_DTG
24
1
618
2
9 10
0 0
1
562
2
8 10
1 0
1
506
2
7 10
2 0
1
458
2
9 18
0 0
1
402
2
8 18
1 0
1
346
2
7 18
2 0
2
619
2
9 10
0 1
2
563
2
8 10
1 1
2
507
2
7 10
2 1
2
459
2
9 18
0 1
2
403
2
8 18
1 1
2
347
2
7 18
2 1
3
300
1
9 10
3
272
1
8 10
3
244
1
7 10
3
220
1
9 13
3
196
1
8 13
3
172
1
7 13
3
149
1
9 15
3
125
1
8 15
3
101
1
7 15
3
76
1
9 18
3
48
1
8 18
3
20
1
7 18
12
0
16
2
31 0
7 14
0
44
2
31 0
8 14
0
72
2
31 0
9 14
0
100
2
34 0
7 14
0
124
2
34 0
8 14
0
148
2
34 0
9 14
0
173
2
24 0
7 14
0
197
2
24 0
8 14
0
221
2
24 0
9 14
0
248
2
37 0
7 14
0
276
2
37 0
8 14
0
304
2
37 0
9 14
12
0
16
2
31 0
7 14
0
44
2
31 0
8 14
0
72
2
31 0
9 14
0
100
2
34 0
7 14
0
124
2
34 0
8 14
0
148
2
34 0
9 14
0
173
2
24 0
7 14
0
197
2
24 0
8 14
0
221
2
24 0
9 14
0
248
2
37 0
7 14
0
276
2
37 0
8 14
0
304
2
37 0
9 14
12
0
16
2
31 0
7 14
0
44
2
31 0
8 14
0
72
2
31 0
9 14
0
100
2
34 0
7 14
0
124
2
34 0
8 14
0
148
2
34 0
9 14
0
173
2
24 0
7 14
0
197
2
24 0
8 14
0
221
2
24 0
9 14
0
248
2
37 0
7 14
0
276
2
37 0
8 14
0
304
2
37 0
9 14
end_DTG
begin_DTG
24
1
624
2
9 13
0 0
1
568
2
8 13
1 0
1
512
2
7 13
2 0
1
464
2
9 21
0 0
1
408
2
8 21
1 0
1
352
2
7 21
2 0
2
625
2
9 13
0 1
2
569
2
8 13
1 1
2
513
2
7 13
2 1
2
465
2
9 21
0 1
2
409
2
8 21
1 1
2
353
2
7 21
2 1
3
303
1
9 13
3
275
1
8 13
3
247
1
7 13
3
222
1
9 16
3
198
1
8 16
3
174
1
7 16
3
151
1
9 18
3
127
1
8 18
3
103
1
7 18
3
79
1
9 21
3
51
1
8 21
3
23
1
7 21
12
0
19
2
34 0
7 17
0
47
2
34 0
8 17
0
75
2
34 0
9 17
0
102
2
23 0
7 17
0
126
2
23 0
8 17
0
150
2
23 0
9 17
0
175
2
37 0
7 17
0
199
2
37 0
8 17
0
223
2
37 0
9 17
0
251
2
32 0
7 17
0
279
2
32 0
8 17
0
307
2
32 0
9 17
12
0
19
2
34 0
7 17
0
47
2
34 0
8 17
0
75
2
34 0
9 17
0
102
2
23 0
7 17
0
126
2
23 0
8 17
0
150
2
23 0
9 17
0
175
2
37 0
7 17
0
199
2
37 0
8 17
0
223
2
37 0
9 17
0
251
2
32 0
7 17
0
279
2
32 0
8 17
0
307
2
32 0
9 17
12
0
19
2
34 0
7 17
0
47
2
34 0
8 17
0
75
2
34 0
9 17
0
102
2
23 0
7 17
0
126
2
23 0
8 17
0
150
2
23 0
9 17
0
175
2
37 0
7 17
0
199
2
37 0
8 17
0
223
2
37 0
9 17
0
251
2
32 0
7 17
0
279
2
32 0
8 17
0
307
2
32 0
9 17
end_DTG
begin_DTG
24
1
626
2
9 14
0 0
1
570
2
8 14
1 0
1
514
2
7 14
2 0
1
466
2
9 22
0 0
1
410
2
8 22
1 0
1
354
2
7 22
2 0
2
627
2
9 14
0 1
2
571
2
8 14
1 1
2
515
2
7 14
2 1
2
467
2
9 22
0 1
2
411
2
8 22
1 1
2
355
2
7 22
2 1
3
304
1
9 14
3
276
1
8 14
3
248
1
7 14
3
223
1
9 17
3
199
1
8 17
3
175
1
7 17
3
152
1
9 19
3
128
1
8 19
3
104
1
7 19
3
80
1
9 22
3
52
1
8 22
3
24
1
7 22
12
0
20
2
35 0
7 18
0
48
2
35 0
8 18
0
76
2
35 0
9 18
0
103
2
36 0
7 18
0
127
2
36 0
8 18
0
151
2
36 0
9 18
0
176
2
25 0
7 18
0
200
2
25 0
8 18
0
224
2
25 0
9 18
0
252
2
33 0
7 18
0
280
2
33 0
8 18
0
308
2
33 0
9 18
12
0
20
2
35 0
7 18
0
48
2
35 0
8 18
0
76
2
35 0
9 18
0
103
2
36 0
7 18
0
127
2
36 0
8 18
0
151
2
36 0
9 18
0
176
2
25 0
7 18
0
200
2
25 0
8 18
0
224
2
25 0
9 18
0
252
2
33 0
7 18
0
280
2
33 0
8 18
0
308
2
33 0
9 18
12
0
20
2
35 0
7 18
0
48
2
35 0
8 18
0
76
2
35 0
9 18
0
103
2
36 0
7 18
0
127
2
36 0
8 18
0
151
2
36 0
9 18
0
176
2
25 0
7 18
0
200
2
25 0
8 18
0
224
2
25 0
9 18
0
252
2
33 0
7 18
0
280
2
33 0
8 18
0
308
2
33 0
9 18
end_DTG
begin_CG
32
3 2
5 2
6 2
4 2
12 4
26 4
27 4
13 4
18 4
30 4
31 4
19 4
22 4
34 4
35 4
24 4
23 4
36 4
37 4
25 4
20 4
32 4
33 4
21 4
14 4
28 4
29 4
17 4
10 2
15 2
16 2
11 2
32
3 2
5 2
6 2
4 2
12 4
26 4
27 4
13 4
18 4
30 4
31 4
19 4
22 4
34 4
35 4
24 4
23 4
36 4
37 4
25 4
20 4
32 4
33 4
21 4
14 4
28 4
29 4
17 4
10 2
15 2
16 2
11 2
32
3 2
5 2
6 2
4 2
12 4
26 4
27 4
13 4
18 4
30 4
31 4
19 4
22 4
34 4
35 4
24 4
23 4
36 4
37 4
25 4
20 4
32 4
33 4
21 4
14 4
28 4
29 4
17 4
10 2
15 2
16 2
11 2
5
5 3
12 3
7 2
8 2
9 2
5
6 3
13 3
7 2
8 2
9 2
6
3 3
6 3
26 3
7 3
8 3
9 3
6
5 3
4 3
27 3
7 3
8 3
9 3
32
3 6
5 8
6 8
4 6
12 10
26 12
27 12
13 10
18 10
30 12
31 12
19 10
22 10
34 12
35 12
24 10
23 10
36 12
37 12
25 10
20 10
32 12
33 12
21 10
14 10
28 12
29 12
17 10
10 6
15 8
16 8
11 6
32
3 6
5 8
6 8
4 6
12 10
26 12
27 12
13 10
18 10
30 12
31 12
19 10
22 10
34 12
35 12
24 10
23 10
36 12
37 12
25 10
20 10
32 12
33 12
21 10
14 10
28 12
29 12
17 10
10 6
15 8
16 8
11 6
32
3 6
5 8
6 8
4 6
12 10
26 12
27 12
13 10
18 10
30 12
31 12
19 10
22 10
34 12
35 12
24 10
23 10
36 12
37 12
25 10
20 10
32 12
33 12
21 10
14 10
28 12
29 12
17 10
10 6
15 8
16 8
11 6
5
14 3
15 3
7 2
8 2
9 2
5
17 3
16 3
7 2
8 2
9 2
6
3 3
26 3
18 3
7 3
8 3
9 3
6
4 3
27 3
19 3
7 3
8 3
9 3
6
20 3
28 3
10 3
7 3
8 3
9 3
6
28 3
10 3
16 3
7 3
8 3
9 3
6
29 3
15 3
11 3
7 3
8 3
9 3
6
21 3
29 3
11 3
7 3
8 3
9 3
6
12 3
30 3
22 3
7 3
8 3
9 3
6
13 3
31 3
24 3
7 3
8 3
9 3
6
23 3
32 3
14 3
7 3
8 3
9 3
6
25 3
33 3
17 3
7 3
8 3
9 3
6
18 3
34 3
23 3
7 3
8 3
9 3
6
22 3
36 3
20 3
7 3
8 3
9 3
6
19 3
35 3
25 3
7 3
8 3
9 3
6
24 3
37 3
21 3
7 3
8 3
9 3
7
5 3
12 3
27 3
30 3
7 4
8 4
9 4
7
6 3
26 3
13 3
31 3
7 4
8 4
9 4
7
32 3
14 3
29 3
15 3
7 4
8 4
9 4
7
33 3
28 3
17 3
16 3
7 4
8 4
9 4
7
26 3
18 3
31 3
34 3
7 4
8 4
9 4
7
27 3
30 3
19 3
35 3
7 4
8 4
9 4
7
36 3
20 3
33 3
28 3
7 4
8 4
9 4
7
37 3
32 3
21 3
29 3
7 4
8 4
9 4
7
30 3
22 3
35 3
36 3
7 4
8 4
9 4
7
31 3
34 3
24 3
37 3
7 4
8 4
9 4
7
34 3
23 3
37 3
32 3
7 4
8 4
9 4
7
35 3
36 3
25 3
33 3
7 4
8 4
9 4
end_CG
