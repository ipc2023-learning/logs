begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var25
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var24
-1
24
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_5_4)
end_variable
begin_variable
var20
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_5_4)
Atom painted(tile_5_4, black)
Atom painted(tile_5_4, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_5_2)
Atom painted(tile_5_2, black)
Atom painted(tile_5_2, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_5_3)
Atom painted(tile_5_3, black)
Atom painted(tile_5_3, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_4_4)
Atom painted(tile_4_4, black)
Atom painted(tile_4_4, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
48
begin_mutex_group
4
1 0
1 1
1 2
5 0
end_mutex_group
begin_mutex_group
2
1 0
5 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
5 1
end_mutex_group
begin_mutex_group
2
3 0
5 1
end_mutex_group
begin_mutex_group
4
4 0
4 1
4 2
5 2
end_mutex_group
begin_mutex_group
2
4 0
5 2
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
5 3
end_mutex_group
begin_mutex_group
2
2 0
5 3
end_mutex_group
begin_mutex_group
4
8 0
8 1
8 2
5 4
end_mutex_group
begin_mutex_group
2
8 0
5 4
end_mutex_group
begin_mutex_group
4
18 0
18 1
18 2
5 5
end_mutex_group
begin_mutex_group
2
18 0
5 5
end_mutex_group
begin_mutex_group
4
19 0
19 1
19 2
5 6
end_mutex_group
begin_mutex_group
2
19 0
5 6
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
5 7
end_mutex_group
begin_mutex_group
2
9 0
5 7
end_mutex_group
begin_mutex_group
4
14 0
14 1
14 2
5 8
end_mutex_group
begin_mutex_group
2
14 0
5 8
end_mutex_group
begin_mutex_group
4
22 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




9
2
20 0
5 21
0
37
2
6 0
5 21
0
56
2
12 0
5 21
end_DTG
begin_DTG
5
1
154
2
5 18
0 0
2
155
2
5 18
0 1
3
39
1
5 23
3
56
1
5 21
3
76
1
5 18
3
0
20
2
21 0
5 22
0
38
2
11 0
5 22
0
57
2
7 0
5 22
3
0
20
2
21 0
5 22
0
38
2
11 0
5 22
0
57
2
7 0
5 22
3
0
20
2
21 0
5 22
0
38
2
11 0
5 22
0
57
2
7 0
5 22
end_DTG
begin_DTG
7
1
116
2
5 23
0 0
1
148
2
5 15
0 0
2
117
2
5 23
0 1
2
149
2
5 15
0 1
3
21
1
5 23
3
54
1
5 18
3
73
1
5 15
3
0
17
2
17 0
5 19
0
36
2
21 0
5 19
0
77
2
7 0
5 19
3
0
17
2
17 0
5 19
0
36
2
21 0
5 19
0
77
2
7 0
5 19
3
0
17
2
17 0
5 19
0
36
2
21 0
5 19
0
77
2
7 0
5 19
end_DTG
begin_DTG
7
1
94
2
5 12
0 0
1
126
2
5 4
0 0
2
95
2
5 12
0 1
2
127
2
5 4
0 1
3
10
1
5 12
3
28
1
5 9
3
62
1
5 4
3
0
6
2
8 0
5 8
0
46
2
22 0
5 8
0
66
2
15 0
5 8
3
0
6
2
8 0
5 8
0
46
2
22 0
5 8
0
66
2
15 0
5 8
3
0
6
2
8 0
5 8
0
46
2
22 0
5 8
0
66
2
15 0
5 8
end_DTG
begin_DTG
7
1
102
2
5 16
0 0
1
134
2
5 8
0 0
2
103
2
5 16
0 1
2
135
2
5 8
0 1
3
14
1
5 16
3
31
1
5 13
3
66
1
5 8
3
0
10
2
14 0
5 12
0
49
2
24 0
5 12
0
70
2
10 0
5 12
3
0
10
2
14 0
5 12
0
49
2
24 0
5 12
0
70
2
10 0
5 12
3
0
10
2
14 0
5 12
0
49
2
24 0
5 12
0
70
2
10 0
5 12
end_DTG
begin_DTG
7
1
100
2
5 15
0 0
1
132
2
5 7
0 0
2
101
2
5 15
0 1
2
133
2
5 7
0 1
3
13
1
5 15
3
48
1
5 10
3
65
1
5 7
3
0
9
2
9 0
5 11
0
30
2
23 0
5 11
0
69
2
17 0
5 11
3
0
9
2
9 0
5 11
0
30
2
23 0
5 11
0
69
2
17 0
5 11
3
0
9
2
9 0
5 11
0
30
2
23 0
5 11
0
69
2
17 0
5 11
end_DTG
begin_DTG
7
1
108
2
5 19
0 0
1
140
2
5 11
0 0
2
109
2
5 19
0 1
2
141
2
5 11
0 1
3
17
1
5 19
3
51
1
5 14
3
69
1
5 11
3
0
13
2
16 0
5 15
0
33
2
25 0
5 15
0
73
2
13 0
5 15
3
0
13
2
16 0
5 15
0
33
2
25 0
5 15
0
73
2
13 0
5 15
3
0
13
2
16 0
5 15
0
33
2
25 0
5 15
0
73
2
13 0
5 15
end_DTG
begin_DTG
8
1
88
2
5 9
0 0
1
120
2
5 1
0 0
2
89
2
5 9
0 1
2
121
2
5 1
0 1
3
7
1
5 9
3
26
1
5 6
3
43
1
5 4
3
59
1
5 1
4
0
3
2
3 0
5 5
0
25
2
8 0
5 5
0
44
2
19 0
5 5
0
63
2
22 0
5 5
4
0
3
2
3 0
5 5
0
25
2
8 0
5 5
0
44
2
19 0
5 5
0
63
2
22 0
5 5
4
0
3
2
3 0
5 5
0
25
2
8 0
5 5
0
44
2
19 0
5 5
0
63
2
22 0
5 5
end_DTG
begin_DTG
8
1
90
2
5 10
0 0
1
122
2
5 2
0 0
2
91
2
5 10
0 1
2
123
2
5 2
0 1
3
8
1
5 10
3
27
1
5 7
3
44
1
5 5
3
60
1
5 2
4
0
4
2
4 0
5 6
0
26
2
18 0
5 6
0
45
2
9 0
5 6
0
64
2
23 0
5 6
4
0
4
2
4 0
5 6
0
26
2
18 0
5 6
0
45
2
9 0
5 6
0
64
2
23 0
5 6
4
0
4
2
4 0
5 6
0
26
2
18 0
5 6
0
45
2
9 0
5 6
0
64
2
23 0
5 6
end_DTG
begin_DTG
8
1
112
2
5 21
0 0
1
144
2
5 13
0 0
2
113
2
5 21
0 1
2
145
2
5 13
0 1
3
19
1
5 21
3
35
1
5 18
3
52
1
5 16
3
71
1
5 13
4
0
15
2
24 0
5 17
0
34
2
10 0
5 17
0
53
2
21 0
5 17
0
75
2
11 0
5 17
4
0
15
2
24 0
5 17
0
34
2
10 0
5 17
0
53
2
21 0
5 17
0
75
2
11 0
5 17
4
0
15
2
24 0
5 17
0
34
2
10 0
5 17
0
53
2
21 0
5 17
0
75
2
11 0
5 17
end_DTG
begin_DTG
8
1
114
2
5 22
0 0
1
146
2
5 14
0 0
2
115
2
5 22
0 1
2
147
2
5 14
0 1
3
20
1
5 22
3
36
1
5 19
3
53
1
5 17
3
72
1
5 14
4
0
16
2
25 0
5 18
0
35
2
20 0
5 18
0
54
2
13 0
5 18
0
76
2
12 0
5 18
4
0
16
2
25 0
5 18
0
35
2
20 0
5 18
0
54
2
13 0
5 18
0
76
2
12 0
5 18
4
0
16
2
25 0
5 18
0
35
2
20 0
5 18
0
54
2
13 0
5 18
0
76
2
12 0
5 18
end_DTG
begin_DTG
8
1
96
2
5 13
0 0
1
128
2
5 5
0 0
2
97
2
5 13
0 1
2
129
2
5 5
0 1
3
11
1
5 13
3
29
1
5 10
3
46
1
5 8
3
63
1
5 5
4
0
7
2
18 0
5 9
0
28
2
14 0
5 9
0
47
2
23 0
5 9
0
67
2
24 0
5 9
4
0
7
2
18 0
5 9
0
28
2
14 0
5 9
0
47
2
23 0
5 9
0
67
2
24 0
5 9
4
0
7
2
18 0
5 9
0
28
2
14 0
5 9
0
47
2
23 0
5 9
0
67
2
24 0
5 9
end_DTG
begin_DTG
8
1
98
2
5 14
0 0
1
130
2
5 6
0 0
2
99
2
5 14
0 1
2
131
2
5 6
0 1
3
12
1
5 14
3
30
1
5 11
3
47
1
5 9
3
64
1
5 6
4
0
8
2
19 0
5 10
0
29
2
22 0
5 10
0
48
2
16 0
5 10
0
68
2
25 0
5 10
4
0
8
2
19 0
5 10
0
29
2
22 0
5 10
0
48
2
16 0
5 10
0
68
2
25 0
5 10
4
0
8
2
19 0
5 10
0
29
2
22 0
5 10
0
48
2
16 0
5 10
0
68
2
25 0
5 10
end_DTG
begin_DTG
8
1
104
2
5 17
0 0
1
136
2
5 9
0 0
2
105
2
5 17
0 1
2
137
2
5 9
0 1
3
15
1
5 17
3
32
1
5 14
3
49
1
5 12
3
67
1
5 9
4
0
11
2
22 0
5 13
0
31
2
15 0
5 13
0
50
2
25 0
5 13
0
71
2
20 0
5 13
4
0
11
2
22 0
5 13
0
31
2
15 0
5 13
0
50
2
25 0
5 13
0
71
2
20 0
5 13
4
0
11
2
22 0
5 13
0
31
2
15 0
5 13
0
50
2
25 0
5 13
0
71
2
20 0
5 13
end_DTG
begin_DTG
8
1
106
2
5 18
0 0
1
138
2
5 10
0 0
2
107
2
5 18
0 1
2
139
2
5 10
0 1
3
16
1
5 18
3
33
1
5 15
3
50
1
5 13
3
68
1
5 10
4
0
12
2
23 0
5 14
0
32
2
24 0
5 14
0
51
2
17 0
5 14
0
72
2
21 0
5 14
4
0
12
2
23 0
5 14
0
32
2
24 0
5 14
0
51
2
17 0
5 14
0
72
2
21 0
5 14
4
0
12
2
23 0
5 14
0
32
2
24 0
5 14
0
51
2
17 0
5 14
0
72
2
21 0
5 14
end_DTG
begin_CG
24
1 2
3 2
4 2
2 2
8 4
18 4
19 4
9 4
14 4
22 4
23 4
16 4
15 4
24 4
25 4
17 4
10 4
20 4
21 4
13 4
6 2
11 2
12 2
7 2
3
3 1
8 1
5 2
3
4 1
9 1
5 2
4
1 1
4 1
18 1
5 3
4
3 1
2 1
19 1
5 3
24
1 6
3 8
4 8
2 6
8 10
18 12
19 12
9 10
14 10
22 12
23 12
16 10
15 10
24 12
25 12
17 10
10 10
20 12
21 12
13 10
6 6
11 8
12 8
7 6
3
10 1
11 1
5 2
3
13 1
12 1
5 2
4
1 1
18 1
14 1
5 3
4
2 1
19 1
16 1
5 3
4
15 1
20 1
6 1
5 3
4
20 1
6 1
12 1
5 3
4
21 1
11 1
7 1
5 3
4
17 1
21 1
7 1
5 3
4
8 1
22 1
15 1
5 3
4
14 1
24 1
10 1
5 3
4
9 1
23 1
17 1
5 3
4
16 1
25 1
13 1
5 3
5
3 1
8 1
19 1
22 1
5 4
5
4 1
18 1
9 1
23 1
5 4
5
24 1
10 1
21 1
11 1
5 4
5
25 1
20 1
13 1
12 1
5 4
5
18 1
14 1
23 1
24 1
5 4
5
19 1
22 1
16 1
25 1
5 4
5
22 1
15 1
25 1
20 1
5 4
5
23 1
24 1
17 1
21 1
5 4
end_CG
