begin_version
3
end_version
begin_metric
0
end_metric
22
begin_variable
var21
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var20
-1
20
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
end_variable
begin_variable
var15
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_3_5)
Atom painted(tile_3_5, black)
Atom painted(tile_3_5, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_5)
Atom painted(tile_1_5, black)
Atom painted(tile_1_5, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_2_5)
Atom painted(tile_2_5, black)
Atom painted(tile_2_5, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
40
begin_mutex_group
4
1 0
1 1
1 2
6 0
end_mutex_group
begin_mutex_group
2
1 0
6 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
6 1
end_mutex_group
begin_mutex_group
2
3 0
6 1
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
6 2
end_mutex_group
begin_mutex_group
2
5 0
6 2
end_mutex_group
begin_mutex_group
4
4 0
4 1
4 2
6 3
end_mutex_group
begin_mutex_group
2
4 0
6 3
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
6 4
end_mutex_group
begin_mutex_group
2
2 0
6 4
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
6 5
end_mutex_group
begin_mutex_group
2
9 0
6 5
end_mutex_group
begin_mutex_group
4
16 0
16 1
16 2
6 6
end_mutex_group
begin_mutex_group
2
16 0
6 6
end_mutex_group
begin_mutex_group
4
19 0
19 1
19 2
6 7
end_mutex_group
begin_mutex_group
2
19 0
6 7
end_mutex_group
begin_mutex_group
4
18 0
18 1
18 2
6 8
end_mutex_group
begin_mutex_group
2
18 0
6 8
end_mutex_group
begin_mutex_group
4
11 0
11 1
11 2
6 9
end_mutex_group
begin_mutex_group
2
11 0
6 9
end_mutex_group
begin_mutex_group
4
10 0
10 1
10 2
6 10
end_mutex_group
begin_mutex_group
2
10 0
6 10
end_mutex_group
begin_mutex_group
4
17 0
17 1
17 2
6 11
end_mutex_group
begin_mutex_group
2
17 0
6 11
end_mutex_group
begin_mutex_group
4
21 0
21 1
21 2
6 12
end_mutex_group
begin_mutex_group
2
21 0
6 12
end_mutex_group
begin_mutex_group
4
20 0
20 1
20 2
6 13
end_mutex_group
begin_mutex_group
2
20 0
6 13
end_mutex_group
begin_mutex_group
4
12 0
12 1
12 2
6 14
end_mutex_group
begin_mutex_group
2
12 0
6 14
end_mutex_group
begin_mutex_group
4
7 0
7 1
7 2
6 15
end_mutex_group
begin_mutex_group
2
7 0
6 15
end




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
16
60
1
13 0
4
7
9
1
19 0
11
26
1
17 0
13
43
1
20 0
17
61
1
15 0
4
8
10
1
18 0
12
27
1
21 0
14
44
1
12 0
18
62
1
14 0
3
9
11
1
11 0
13
28
1
20 0
19
63
1
8 0
2
10
12
1
10 0
16
45
1
13 0
3
11
13
1
17 0
15
29
1
7 0
17
46
1
15 0
3
12
14
1
21 0
16
30
1
13 0
18
47
1
14 0
3
13
15
1
20 0
17
31
1
15 0
19
48
1
8 0
2
14
16
1
12 0
18
32
1
14 0
end_DTG
begin_DTG
4
1
114
2
6 10
0 0
2
115
2
6 10
0 1
3
29
1
6 16
3
59
1
6 10
2
0
12
2
10 0
6 15
0
45
2
13 0
6 15
2
0
12
2
10 0
6 15
0
45
2
13 0
6 15
2
0
12
2
10 0
6 15
0
45
2
13 0
6 15
end_DTG
begin_DTG
4
1
122
2
6 14
0 0
2
123
2
6 14
0 1
3
48
1
6 18
3
63
1
6 14
2
0
16
2
12 0
6 19
0
32
2
14 0
6 19
2
0
16
2
12 0
6 19
0
32
2
14 0
6 19
2
0
16
2
12 0
6 19
0
32
2
14 0
6 19
end_DTG
begin_DTG
7
1
74
2
6 10
0 0
1
94
2
6 0
0 0
2
75
2
6 10
0 1
2
95
2
6 0
0 1
3
7
1
6 10
3
21
1
6 6
3
49
1
6 0
3
0
2
2
1 0
6 5
0
37
2
16 0
6 5
0
54
2
10 0
6 5
3
0
2
2
1 0
6 5
0
37
2
16 0
6 5
0
54
2
10 0
6 5
3
0
2
2
1 0
6 5
0
37
2
16 0
6 5
0
54
2
10 0
6 5
end_DTG
begin_DTG
7
1
84
2
6 15
0 0
1
104
2
6 5
0 0
2
85
2
6 15
0 1
2
105
2
6 5
0 1
3
12
1
6 15
3
25
1
6 11
3
54
1
6 5
3
0
7
2
9 0
6 10
0
41
2
17 0
6 10
0
59
2
7 0
6 10
3
0
7
2
9 0
6 10
0
41
2
17 0
6 10
0
59
2
7 0
6 10
3
0
7
2
9 0
6 10
0
41
2
17 0
6 10
0
59
2
7 0
6 10
end_DTG
begin_DTG
7
1
82
2
6 14
0 0
1
102
2
6 4
0 0
2
83
2
6 14
0 1
2
103
2
6 4
0 1
3
11
1
6 14
3
40
1
6 8
3
53
1
6 4
3
0
6
2
2 0
6 9
0
24
2
18 0
6 9
0
58
2
12 0
6 9
3
0
6
2
2 0
6 9
0
24
2
18 0
6 9
0
58
2
12 0
6 9
3
0
6
2
2 0
6 9
0
24
2
18 0
6 9
0
58
2
12 0
6 9
end_DTG
begin_DTG
7
1
92
2
6 19
0 0
1
112
2
6 9
0 0
2
93
2
6 19
0 1
2
113
2
6 9
0 1
3
16
1
6 19
3
44
1
6 13
3
58
1
6 9
3
0
11
2
11 0
6 14
0
28
2
20 0
6 14
0
63
2
8 0
6 14
3
0
11
2
11 0
6 14
0
28
2
20 0
6 14
0
63
2
8 0
6 14
3
0
11
2
11 0
6 14
0
28
2
20 0
6 14
0
63
2
8 0
6 14
end_DTG
begin_DTG
5
1
116
2
6 11
0 0
2
117
2
6 11
0 1
3
30
1
6 17
3
45
1
6 15
3
60
1
6 11
3
0
13
2
17 0
6 16
0
29
2
7 0
6 16
0
46
2
15 0
6 16
3
0
13
2
17 0
6 16
0
29
2
7 0
6 16
0
46
2
15 0
6 16
3
0
13
2
17 0
6 16
0
29
2
7 0
6 16
0
46
2
15 0
6 16
end_DTG
begin_DTG
5
1
120
2
6 13
0 0
2
121
2
6 13
0 1
3
32
1
6 19
3
47
1
6 17
3
62
1
6 13
3
0
15
2
20 0
6 18
0
31
2
15 0
6 18
0
48
2
8 0
6 18
3
0
15
2
20 0
6 18
0
31
2
15 0
6 18
0
48
2
8 0
6 18
3
0
15
2
20 0
6 18
0
31
2
15 0
6 18
0
48
2
8 0
6 18
end_DTG
begin_DTG
5
1
118
2
6 12
0 0
2
119
2
6 12
0 1
3
31
1
6 18
3
46
1
6 16
3
61
1
6 12
3
0
14
2
21 0
6 17
0
30
2
13 0
6 17
0
47
2
14 0
6 17
3
0
14
2
21 0
6 17
0
30
2
13 0
6 17
0
47
2
14 0
6 17
3
0
14
2
21 0
6 17
0
30
2
13 0
6 17
0
47
2
14 0
6 17
end_DTG
begin_DTG
8
1
76
2
6 11
0 0
1
96
2
6 1
0 0
2
77
2
6 11
0 1
2
97
2
6 1
0 1
3
8
1
6 11
3
22
1
6 7
3
37
1
6 5
3
50
1
6 1
4
0
3
2
3 0
6 6
0
21
2
9 0
6 6
0
38
2
19 0
6 6
0
55
2
17 0
6 6
4
0
3
2
3 0
6 6
0
21
2
9 0
6 6
0
38
2
19 0
6 6
0
55
2
17 0
6 6
4
0
3
2
3 0
6 6
0
21
2
9 0
6 6
0
38
2
19 0
6 6
0
55
2
17 0
6 6
end_DTG
begin_DTG
8
1
86
2
6 16
0 0
1
106
2
6 6
0 0
2
87
2
6 16
0 1
2
107
2
6 6
0 1
3
13
1
6 16
3
26
1
6 12
3
41
1
6 10
3
55
1
6 6
4
0
8
2
16 0
6 11
0
25
2
10 0
6 11
0
42
2
21 0
6 11
0
60
2
13 0
6 11
4
0
8
2
16 0
6 11
0
25
2
10 0
6 11
0
42
2
21 0
6 11
0
60
2
13 0
6 11
4
0
8
2
16 0
6 11
0
25
2
10 0
6 11
0
42
2
21 0
6 11
0
60
2
13 0
6 11
end_DTG
begin_DTG
8
1
80
2
6 13
0 0
1
100
2
6 3
0 0
2
81
2
6 13
0 1
2
101
2
6 3
0 1
3
10
1
6 13
3
24
1
6 9
3
39
1
6 7
3
52
1
6 3
4
0
5
2
4 0
6 8
0
23
2
19 0
6 8
0
40
2
11 0
6 8
0
57
2
20 0
6 8
4
0
5
2
4 0
6 8
0
23
2
19 0
6 8
0
40
2
11 0
6 8
0
57
2
20 0
6 8
4
0
5
2
4 0
6 8
0
23
2
19 0
6 8
0
40
2
11 0
6 8
0
57
2
20 0
6 8
end_DTG
begin_DTG
8
1
78
2
6 12
0 0
1
98
2
6 2
0 0
2
79
2
6 12
0 1
2
99
2
6 2
0 1
3
9
1
6 12
3
23
1
6 8
3
38
1
6 6
3
51
1
6 2
4
0
4
2
5 0
6 7
0
22
2
16 0
6 7
0
39
2
18 0
6 7
0
56
2
21 0
6 7
4
0
4
2
5 0
6 7
0
22
2
16 0
6 7
0
39
2
18 0
6 7
0
56
2
21 0
6 7
4
0
4
2
5 0
6 7
0
22
2
16 0
6 7
0
39
2
18 0
6 7
0
56
2
21 0
6 7
end_DTG
begin_DTG
8
1
90
2
6 18
0 0
1
110
2
6 8
0 0
2
91
2
6 18
0 1
2
111
2
6 8
0 1
3
15
1
6 18
3
28
1
6 14
3
43
1
6 12
3
57
1
6 8
4
0
10
2
18 0
6 13
0
27
2
21 0
6 13
0
44
2
12 0
6 13
0
62
2
14 0
6 13
4
0
10
2
18 0
6 13
0
27
2
21 0
6 13
0
44
2
12 0
6 13
0
62
2
14 0
6 13
4
0
10
2
18 0
6 13
0
27
2
21 0
6 13
0
44
2
12 0
6 13
0
62
2
14 0
6 13
end_DTG
begin_DTG
8
1
88
2
6 17
0 0
1
108
2
6 7
0 0
2
89
2
6 17
0 1
2
109
2
6 7
0 1
3
14
1
6 17
3
27
1
6 13
3
42
1
6 11
3
56
1
6 7
4
0
9
2
19 0
6 12
0
26
2
17 0
6 12
0
43
2
20 0
6 12
0
61
2
15 0
6 12
4
0
9
2
19 0
6 12
0
26
2
17 0
6 12
0
43
2
20 0
6 12
0
61
2
15 0
6 12
4
0
9
2
19 0
6 12
0
26
2
17 0
6 12
0
43
2
20 0
6 12
0
61
2
15 0
6 12
end_DTG
begin_CG
20
1 2
3 2
5 2
4 2
2 2
9 4
16 4
19 4
18 4
11 4
10 4
17 4
21 4
20 4
12 4
7 2
13 2
15 2
14 2
8 2
3
3 1
9 1
6 2
3
4 1
11 1
6 2
4
1 1
5 1
16 1
6 3
4
5 1
2 1
18 1
6 3
4
3 1
4 1
19 1
6 3
20
1 6
3 8
5 8
4 8
2 6
9 10
16 12
19 12
18 12
11 10
10 10
17 12
21 12
20 12
12 10
7 6
13 8
15 8
14 8
8 6
3
10 1
13 1
6 2
3
12 1
14 1
6 2
4
1 1
16 1
10 1
6 3
4
9 1
17 1
7 1
6 3
4
2 1
18 1
12 1
6 3
4
11 1
20 1
8 1
6 3
4
17 1
7 1
15 1
6 3
4
20 1
15 1
8 1
6 3
4
21 1
13 1
14 1
6 3
5
3 1
9 1
19 1
17 1
6 4
5
16 1
10 1
21 1
13 1
6 4
5
4 1
19 1
11 1
20 1
6 4
5
5 1
16 1
18 1
21 1
6 4
5
18 1
21 1
12 1
14 1
6 4
5
19 1
17 1
20 1
15 1
6 4
end_CG
