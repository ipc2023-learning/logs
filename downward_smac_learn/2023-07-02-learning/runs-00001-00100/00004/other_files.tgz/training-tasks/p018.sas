begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var17
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var16
-1
16
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
end_variable
begin_variable
var12
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
32
begin_mutex_group
4
1 0
1 1
1 2
5 0
end_mutex_group
begin_mutex_group
2
1 0
5 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
5 1
end_mutex_group
begin_mutex_group
2
3 0
5 1
end_mutex_group
begin_mutex_group
4
4 0
4 1
4 2
5 2
end_mutex_group
begin_mutex_group
2
4 0
5 2
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
5 3
end_mutex_group
begin_mutex_group
2
2 0
5 3
end_mutex_group
begin_mutex_group
4
8 0
8 1
8 2
5 4
end_mutex_group
begin_mutex_group
2
8 0
5 4
end_mutex_group
begin_mutex_group
4
14 0
14 1
14 2
5 5
end_mutex_group
begin_mutex_group
2
14 0
5 5
end_mutex_group
begin_mutex_group
4
15 0
15 1
15 2
5 6
end_mutex_group
begin_mutex_group
2
15 0
5 6
end_mutex_group
begin_mutex_group
4
10 0
10 1
10 2
5 7
end_mutex_group
begin_mutex_group
2
10 0
5 7
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
5 8
end_mutex_group
begin_mutex_group
2
9 0
5 8
end_mutex_group
begin_mutex_group
4
16 0
16 1
16 2
5 9
end_mutex_group
begin_mutex_group
2
16 0
5 9
end_mutex_group
begin_mutex_group
4
17 0
17 1
17 2
5 10
end_mutex_group
begin_mutex_group
2
17 0
5 10
end_mutex_group
begin_mutex_group
4
11 0
11 1
11 2
5 11
end_mutex_group
begin_mutex_group
2
11 0
5 11
end_mutex_group
begin_mutex_group
4
6 0
6 1
6 2
5 12
end_mutex_group
begin_mutex_group
2
6 0
5 12
end_mutex_group
begin_mutex_group
4
12 0
12 1
12 2
5 13
end_mutex_group
begin_mutex_group
2
12 0
5 13
end_mutex_group
begin_mutex_group
4
13 0
13 1
13 2
5 14
end_mutex_group
begin_mutex_group
2
13 0
5 14
end_mutex_group
begin_mutex_group
4
7 0
7 1
7 2
5 15
end_mutex_group
begin_mutex_group
2
7 0
5 15
end_mutex_group
begin_state
0
0
0
0
0
14
0
0
0
0
0
0
0
3
0
0
0
0
end_state
begin_goal
12
6 2
7 1
8 2
9 1
10 1
11 2
12 1
13 2
14 1
15 2
16 2
17 1
end_goal
98
begin_operator
change_color robot1 black white
0
1
0 0 0 1
0
end_operator
begin_operator
change_color robot1 white black
0
1
0 0 1 0
0
end_operator
begin_operator
move_down robot1 tile_1_1 tile_0_1
0
3
0 1 0 3
0 8 -1 0
0 5 4 0
0
end_operator
begin_operator
move_down robot1 tile_1_2 tile_0_2
0
3
0 3 0 3
0 14 -1 0
0 5 5 1
0
end_operator
begin_operator
move_down robot1 tile_1_3 tile_0_3
0
3
0 4 0 3
0 15 -1 0
0 5 6 2
0
end_operator
begin_operator
move_down robot1 tile_1_4 tile_0_4
0
3
0 2 0 3
0 10 -1 0
0 5 7 3
0
end_oper




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




k 1
1
check 0
end_SG
begin_DTG
1
1
0
0
1
0
1
0
end_DTG
begin_DTG
4
1
50
2
5 4
0 0
2
51
2
5 4
0 1
3
2
1
5 4
3
14
1
5 1
2
0
26
2
3 0
5 0
0
38
2
8 0
5 0
2
0
26
2
3 0
5 0
0
38
2
8 0
5 0
2
0
26
2
3 0
5 0
0
38
2
8 0
5 0
end_DTG
begin_DTG
4
1
56
2
5 7
0 0
2
57
2
5 7
0 1
3
5
1
5 7
3
28
1
5 2
2
0
16
2
4 0
5 3
0
41
2
10 0
5 3
2
0
16
2
4 0
5 3
0
41
2
10 0
5 3
2
0
16
2
4 0
5 3
0
41
2
10 0
5 3
end_DTG
begin_DTG
5
1
52
2
5 5
0 0
2
53
2
5 5
0 1
3
3
1
5 5
3
15
1
5 2
3
26
1
5 0
3
0
14
2
1 0
5 1
0
27
2
4 0
5 1
0
39
2
14 0
5 1
3
0
14
2
1 0
5 1
0
27
2
4 0
5 1
0
39
2
14 0
5 1
3
0
14
2
1 0
5 1
0
27
2
4 0
5 1
0
39
2
14 0
5 1
end_DTG
begin_DTG
5
1
54
2
5 6
0 0
2
55
2
5 6
0 1
3
4
1
5 6
3
16
1
5 3
3
27
1
5 1
3
0
15
2
3 0
5 2
0
28
2
2 0
5 2
0
40
2
15 0
5 2
3
0
15
2
3 0
5 2
0
28
2
2 0
5 2
0
40
2
15 0
5 2
3
0
15
2
3 0
5 2
0
28
2
2 0
5 2
0
40
2
15 0
5 2
end_DTG
begin_DTG
2
1
26
1
3 0
4
38
1
8 0
3
0
14
1
1 0
2
27
1
4 0
5
39
1
14 0
3
1
15
1
3 0
3
28
1
2 0
6
40
1
15 0
2
2
16
1
4 0
7
41
1
10 0
3
0
2
1
1 0
5
29
1
14 0
8
42
1
9 0
4
1
3
1
3 0
4
17
1
8 0
6
30
1
15 0
9
43
1
16 0
4
2
4
1
4 0
5
18
1
14 0
7
31
1
10 0
10
44
1
17 0
3
3
5
1
2 0
6
19
1
15 0
11
45
1
11 0
3
4
6
1
8 0
9
32
1
16 0
12
46
1
6 0
4
5
7
1
14 0
8
20
1
9 0
10
33
1
17 0
13
47
1
12 0
4
6
8
1
15 0
9
21
1
16 0
11
34
1
11 0
14
48
1
13 0
3
7
9
1
10 0
10
22
1
17 0
15
49
1
7 0
2
8
10
1
9 0
13
35
1
12 0
3
9
11
1
16 0
12
23
1
6 0
14
36
1
13 0
3
10
12
1
17 0
13
24
1
12 0
15
37
1
7 0
2
11
13
1
11 0
14
25
1
13 0
end_DTG
begin_DTG
4
1
90
2
5 8
0 0
2
91
2
5 8
0 1
3
23
1
5 13
3
46
1
5 8
2
0
10
2
9 0
5 12
0
35
2
12 0
5 12
2
0
10
2
9 0
5 12
0
35
2
12 0
5 12
2
0
10
2
9 0
5 12
0
35
2
12 0
5 12
end_DTG
begin_DTG
4
1
96
2
5 11
0 0
2
97
2
5 11
0 1
3
37
1
5 14
3
49
1
5 11
2
0
13
2
11 0
5 15
0
25
2
13 0
5 15
2
0
13
2
11 0
5 15
0
25
2
13 0
5 15
2
0
13
2
11 0
5 15
0
25
2
13 0
5 15
end_DTG
begin_DTG
7
1
58
2
5 8
0 0
1
74
2
5 0
0 0
2
59
2
5 8
0 1
2
75
2
5 0
0 1
3
6
1
5 8
3
17
1
5 5
3
38
1
5 0
3
0
2
2
1 0
5 4
0
29
2
14 0
5 4
0
42
2
9 0
5 4
3
0
2
2
1 0
5 4
0
29
2
14 0
5 4
0
42
2
9 0
5 4
3
0
2
2
1 0
5 4
0
29
2
14 0
5 4
0
42
2
9 0
5 4
end_DTG
begin_DTG
7
1
66
2
5 12
0 0
1
82
2
5 4
0 0
2
67
2
5 12
0 1
2
83
2
5 4
0 1
3
10
1
5 12
3
20
1
5 9
3
42
1
5 4
3
0
6
2
8 0
5 8
0
32
2
16 0
5 8
0
46
2
6 0
5 8
3
0
6
2
8 0
5 8
0
32
2
16 0
5 8
0
46
2
6 0
5 8
3
0
6
2
8 0
5 8
0
32
2
16 0
5 8
0
46
2
6 0
5 8
end_DTG
begin_DTG
7
1
64
2
5 11
0 0
1
80
2
5 3
0 0
2
65
2
5 11
0 1
2
81
2
5 3
0 1
3
9
1
5 11
3
31
1
5 6
3
41
1
5 3
3
0
5
2
2 0
5 7
0
19
2
15 0
5 7
0
45
2
11 0
5 7
3
0
5
2
2 0
5 7
0
19
2
15 0
5 7
0
45
2
11 0
5 7
3
0
5
2
2 0
5 7
0
19
2
15 0
5 7
0
45
2
11 0
5 7
end_DTG
begin_DTG
7
1
72
2
5 15
0 0
1
88
2
5 7
0 0
2
73
2
5 15
0 1
2
89
2
5 7
0 1
3
13
1
5 15
3
34
1
5 10
3
45
1
5 7
3
0
9
2
10 0
5 11
0
22
2
17 0
5 11
0
49
2
7 0
5 11
3
0
9
2
10 0
5 11
0
22
2
17 0
5 11
0
49
2
7 0
5 11
3
0
9
2
10 0
5 11
0
22
2
17 0
5 11
0
49
2
7 0
5 11
end_DTG
begin_DTG
5
1
92
2
5 9
0 0
2
93
2
5 9
0 1
3
24
1
5 14
3
35
1
5 12
3
47
1
5 9
3
0
11
2
16 0
5 13
0
23
2
6 0
5 13
0
36
2
13 0
5 13
3
0
11
2
16 0
5 13
0
23
2
6 0
5 13
0
36
2
13 0
5 13
3
0
11
2
16 0
5 13
0
23
2
6 0
5 13
0
36
2
13 0
5 13
end_DTG
begin_DTG
5
1
94
2
5 10
0 0
2
95
2
5 10
0 1
3
25
1
5 15
3
36
1
5 13
3
48
1
5 10
3
0
12
2
17 0
5 14
0
24
2
12 0
5 14
0
37
2
7 0
5 14
3
0
12
2
17 0
5 14
0
24
2
12 0
5 14
0
37
2
7 0
5 14
3
0
12
2
17 0
5 14
0
24
2
12 0
5 14
0
37
2
7 0
5 14
end_DTG
begin_DTG
8
1
60
2
5 9
0 0
1
76
2
5 1
0 0
2
61
2
5 9
0 1
2
77
2
5 1
0 1
3
7
1
5 9
3
18
1
5 6
3
29
1
5 4
3
39
1
5 1
4
0
3
2
3 0
5 5
0
17
2
8 0
5 5
0
30
2
15 0
5 5
0
43
2
16 0
5 5
4
0
3
2
3 0
5 5
0
17
2
8 0
5 5
0
30
2
15 0
5 5
0
43
2
16 0
5 5
4
0
3
2
3 0
5 5
0
17
2
8 0
5 5
0
30
2
15 0
5 5
0
43
2
16 0
5 5
end_DTG
begin_DTG
8
1
62
2
5 10
0 0
1
78
2
5 2
0 0
2
63
2
5 10
0 1
2
79
2
5 2
0 1
3
8
1
5 10
3
19
1
5 7
3
30
1
5 5
3
40
1
5 2
4
0
4
2
4 0
5 6
0
18
2
14 0
5 6
0
31
2
10 0
5 6
0
44
2
17 0
5 6
4
0
4
2
4 0
5 6
0
18
2
14 0
5 6
0
31
2
10 0
5 6
0
44
2
17 0
5 6
4
0
4
2
4 0
5 6
0
18
2
14 0
5 6
0
31
2
10 0
5 6
0
44
2
17 0
5 6
end_DTG
begin_DTG
8
1
68
2
5 13
0 0
1
84
2
5 5
0 0
2
69
2
5 13
0 1
2
85
2
5 5
0 1
3
11
1
5 13
3
21
1
5 10
3
32
1
5 8
3
43
1
5 5
4
0
7
2
14 0
5 9
0
20
2
9 0
5 9
0
33
2
17 0
5 9
0
47
2
12 0
5 9
4
0
7
2
14 0
5 9
0
20
2
9 0
5 9
0
33
2
17 0
5 9
0
47
2
12 0
5 9
4
0
7
2
14 0
5 9
0
20
2
9 0
5 9
0
33
2
17 0
5 9
0
47
2
12 0
5 9
end_DTG
begin_DTG
8
1
70
2
5 14
0 0
1
86
2
5 6
0 0
2
71
2
5 14
0 1
2
87
2
5 6
0 1
3
12
1
5 14
3
22
1
5 11
3
33
1
5 9
3
44
1
5 6
4
0
8
2
15 0
5 10
0
21
2
16 0
5 10
0
34
2
11 0
5 10
0
48
2
13 0
5 10
4
0
8
2
15 0
5 10
0
21
2
16 0
5 10
0
34
2
11 0
5 10
0
48
2
13 0
5 10
4
0
8
2
15 0
5 10
0
21
2
16 0
5 10
0
34
2
11 0
5 10
0
48
2
13 0
5 10
end_DTG
begin_CG
16
1 2
3 2
4 2
2 2
8 4
14 4
15 4
10 4
9 4
16 4
17 4
11 4
6 2
12 2
13 2
7 2
3
3 1
8 1
5 2
3
4 1
10 1
5 2
4
1 1
4 1
14 1
5 3
4
3 1
2 1
15 1
5 3
16
1 6
3 8
4 8
2 6
8 10
14 12
15 12
10 10
9 10
16 12
17 12
11 10
6 6
12 8
13 8
7 6
3
9 1
12 1
5 2
3
11 1
13 1
5 2
4
1 1
14 1
9 1
5 3
4
8 1
16 1
6 1
5 3
4
2 1
15 1
11 1
5 3
4
10 1
17 1
7 1
5 3
4
16 1
6 1
13 1
5 3
4
17 1
12 1
7 1
5 3
5
3 1
8 1
15 1
16 1
5 4
5
4 1
14 1
10 1
17 1
5 4
5
14 1
9 1
17 1
12 1
5 4
5
15 1
16 1
11 1
13 1
5 4
end_CG
