begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var7
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var6
-1
6
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
end_variable
begin_variable
var4
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
12
begin_mutex_group
4
1 0
1 1
1 2
3 0
end_mutex_group
begin_mutex_group
2
1 0
3 0
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
3 1
end_mutex_group
begin_mutex_group
2
2 0
3 1
end_mutex_group
begin_mutex_group
4
6 0
6 1
6 2
3 2
end_mutex_group
begin_mutex_group
2
6 0
3 2
end_mutex_group
begin_mutex_group
4
7 0
7 1
7 2
3 3
end_mutex_group
begin_mutex_group
2
7 0
3 3
end_mutex_group
begin_mutex_group
4
4 0
4 1
4 2
3 4
end_mutex_group
begin_mutex_group
2
4 0
3 4
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
3 5
end_mutex_group
begin_mutex_group
2
5 0
3 5
end_mutex_group
begin_state
0
0
0
5
0
3
0
0
end_state
begin_goal
4
4 1
5 2
6 2
7 1
end_goal
32
begin_operator
change_color robot1 black white
0
1
0 0 0 1
0
end_operator
begin_operator
change_color robot1 white black
0
1
0 0 1 0
0
end_operator
begin_operator
move_down robot1 tile_1_1 tile_0_1
0
3
0 1 0 3
0 6 -1 0
0 3 2 0
0
end_operator
begin_operator
move_down robot1 tile_1_2 tile_0_2
0
3
0 2 0 3
0 7 -1 0
0 3 3 1
0
end_operator
begin_operator
move_down robot1 tile_2_1 tile_1_1
0
3
0 6 0 3
0 4 -1 0
0 3 4 2
0
end_operator
begin_operator
move_down robot1 tile_2_2 tile_1_2
0
3
0 7 0 3
0 5 -1 0
0 3 5 3
0
end_operator
begin_operator
move_left robot1 tile_0_2 tile_0_1
0
3
0 1 0 3
0 2 -1 0
0 3 1 0
0
end_operator
begin_operator
move_left robot1 tile_1_2 tile_1_1
0
3
0 6 0 3
0 7 -1 0
0 3 3 2
0
end_operator
begin_operator
move_left robot1 tile_2_2 tile_2_1
0
3
0 4 0 3
0 5 -1 0
0 3 5 4
0
end_operator
begin_operator
move_right robot1 tile_0_1 tile_0_2
0
3
0 1 -1 0
0 2 0 3
0 3 0 1
0
end_operator
begin_operator
move_right robot1 tile_1_1 tile_1_2
0
3
0 6 -1 0
0 7 0 3
0 3 2 3
0
end_operator
begin_operator
move_right robot1 tile_2_1 tile_2_2
0
3
0 4 -1 0
0 5 0 3
0 3 4 5
0
end_operator
begin_operator
move_up robot1 tile_0_1 tile_1_1
0
3
0 1 -1 0
0 6 0 3
0 3 0 2
0
end_operator
begin_operator
move_up robot1 tile_0_2 tile_1_2
0
3
0 2 -1 0
0 7 0 3
0 3 1 3
0
end_operator
begin_operator
move_up robot1 tile_1_1 tile_2_1
0
3
0 6 -1 0
0 4 0 3
0 3 2 4
0
end_operator
begin_operator
move_up robot1 tile_1_2 tile_2_2
0
3
0 7 -1 0
0 5 0 3
0 3 3 5
0
end_operator
begin_operator
paint_down robot1 tile_0_1 tile_1_1 black
2
3 2
0 0
1
0 1 0 1
0
end_operator
begin_operator
paint_down robot1 tile_0_1 tile_1_1 white
2
3 2
0 1
1
0 1 0 2
0
end_operator
begin_operator
paint_down robot1 tile_0_2 tile_1_2 black
2
3 3
0 0
1
0 2 0 1
0
end_operator
begin_operator
paint_down robot1 tile_0_2 tile_1_2 white
2
3 3
0 1
1
0 2 0 2
0
end_operator
begin_operator
paint_down robot1 tile_1_1 tile_2_1 black
2
3 4
0 0
1
0 6 0 1
0
end_operator
begin_operator
paint_down robot1 tile_1_1 tile_2_1 white
2
3 4
0 1
1
0 6 0 2
0
end_operator
begin_operator
paint_down robot1 tile_1_2 tile_2_2 black
2
3 5
0 0
1
0 7 0 1
0
end_operator
begin_operator
paint_down robot1 tile_1_2 tile_2_2 white
2
3 5
0 1
1
0 7 0 2
0
end_operator
begin_operator
paint_up robot1 tile_1_1 tile_0_1 black
2
3 0
0 0
1
0 6 0 1
0
end_operator
begin_operator
paint_up robot1 tile_1_1 tile_0_1 white
2
3 0
0 1
1
0 6 0 2
0
end_operator
begin_operator
paint_up robot1 tile_1_2 tile_0_2 black
2
3 1
0 0
1
0 7 0 1
0
end_operator
begin_operator
paint_up robot1 tile_1_2 tile_0_2 white
2
3 1
0 1
1
0 7 0 2
0
end_operator
begin_operator
paint_up robot1 tile_2_1 tile_1_1 black
2
3 2
0 0
1
0 4 0 1
0
end_operator
begin_operator
paint_up robot1 tile_2_1 tile_1_1 white
2
3 2
0 1
1
0 4 0 2
0
end_operator
begin_operator
paint_up robot1 tile_2_2 tile_1_2 black
2
3 3
0 0
1
0 5 0 1
0
end_operator
begin_operator
paint_up robot1 tile_2_2 tile_1_2 white
2
3 3
0 1
1
0 5 0 2
0
end_operator
0
begin_SG
switch 1
check 0
switch 3
check 0
check 0
check 1
6
switch 0
check 1
2
check 1
16
check 1
17
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 3
check 0
check 1
9
check 0
check 0
switch 0
check 1
3
check 1
18
check 1
19
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 3
check 0
switch 0
check 1
12
check 1
24
check 1
25
check 0
check 0
check 0
check 1
7
switch 0
check 1
4
check 1
20
check 1
21
check 0
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
switch 3
check 0
check 0
switch 0
check 1
13
check 1
26
check 1
27
check 0
check 1
10
check 0
check 0
switch 0
check 1
5
check 1
22
check 1
23
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 3
check 0
check 0
check 0
switch 0
check 1
14
check 1
28
check 1
29
check 0
check 0
check 0
check 1
8
check 0
check 0
check 0
check 0
switch 5
check 0
switch 3
check 0
check 0
check 0
check 0
switch 0
check 1
15
check 1
30
check 1
31
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 1
1
check 0
end_SG
begin_DTG
1
1
0
0
1
0
1
0
end_DTG
begin_DTG
4
1
16
2
3 2
0 0
2
17
2
3 2
0 1
3
2
1
3 2
3
6
1
3 1
2
0
9
2
2 0
3 0
0
12
2
6 0
3 0
2
0
9
2
2 0
3 0
0
12
2
6 0
3 0
2
0
9
2
2 0
3 0
0
12
2
6 0
3 0
end_DTG
begin_DTG
4
1
18
2
3 3
0 0
2
19
2
3 3
0 1
3
3
1
3 3
3
9
1
3 0
2
0
6
2
1 0
3 1
0
13
2
7 0
3 1
2
0
6
2
1 0
3 1
0
13
2
7 0
3 1
2
0
6
2
1 0
3 1
0
13
2
7 0
3 1
end_DTG
begin_DTG
2
1
9
1
2 0
2
12
1
6 0
2
0
6
1
1 0
3
13
1
7 0
3
0
2
1
1 0
3
10
1
7 0
4
14
1
4 0
3
1
3
1
2 0
2
7
1
6 0
5
15
1
5 0
2
2
4
1
6 0
5
11
1
5 0
2
3
5
1
7 0
4
8
1
4 0
end_DTG
begin_DTG
4
1
28
2
3 2
0 0
2
29
2
3 2
0 1
3
8
1
3 5
3
14
1
3 2
2
0
4
2
6 0
3 4
0
11
2
5 0
3 4
2
0
4
2
6 0
3 4
0
11
2
5 0
3 4
2
0
4
2
6 0
3 4
0
11
2
5 0
3 4
end_DTG
begin_DTG
4
1
30
2
3 3
0 0
2
31
2
3 3
0 1
3
11
1
3 4
3
15
1
3 3
2
0
5
2
7 0
3 5
0
8
2
4 0
3 5
2
0
5
2
7 0
3 5
0
8
2
4 0
3 5
2
0
5
2
7 0
3 5
0
8
2
4 0
3 5
end_DTG
begin_DTG
7
1
20
2
3 4
0 0
1
24
2
3 0
0 0
2
21
2
3 4
0 1
2
25
2
3 0
0 1
3
4
1
3 4
3
7
1
3 3
3
12
1
3 0
3
0
2
2
1 0
3 2
0
10
2
7 0
3 2
0
14
2
4 0
3 2
3
0
2
2
1 0
3 2
0
10
2
7 0
3 2
0
14
2
4 0
3 2
3
0
2
2
1 0
3 2
0
10
2
7 0
3 2
0
14
2
4 0
3 2
end_DTG
begin_DTG
7
1
22
2
3 5
0 0
1
26
2
3 1
0 0
2
23
2
3 5
0 1
2
27
2
3 1
0 1
3
5
1
3 5
3
10
1
3 2
3
13
1
3 1
3
0
3
2
2 0
3 3
0
7
2
6 0
3 3
0
15
2
5 0
3 3
3
0
3
2
2 0
3 3
0
7
2
6 0
3 3
0
15
2
5 0
3 3
3
0
3
2
2 0
3 3
0
7
2
6 0
3 3
0
15
2
5 0
3 3
end_DTG
begin_CG
6
1 2
2 2
6 4
7 4
4 2
5 2
3
2 1
6 1
3 2
3
1 1
7 1
3 2
6
1 6
2 6
6 10
7 10
4 6
5 6
3
6 1
5 1
3 2
3
7 1
4 1
3 2
4
1 1
7 1
4 1
3 3
4
2 1
6 1
5 1
3 3
end_CG
