begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var29
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_0_7)
Atom painted(tile_0_7, black)
Atom painted(tile_0_7, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var28
-1
28
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_0_7)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_1_7)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_2_7)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_3_7)
end_variable
begin_variable
var21
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_3_7)
Atom painted(tile_3_7, black)
Atom painted(tile_3_7, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_1_7)
Atom painted(tile_1_7, black)
Atom painted(tile_1_7, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_2_7)
Atom painted(tile_2_7, black)
Atom painted(tile_2_7, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_3_6)
Atom painted(tile_3_6, black)
Atom painted(tile_3_6, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom clear(tile_3_5)
Atom painted(tile_3_5, black)
Atom painted(tile_3_5, white)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_1_6)
Atom painted(tile_1_6, black)
Atom painted(tile_1_6, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_2_6)
Atom painted(tile_2_6, black)
Atom painted(tile_2_6, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_1_5)
Atom painted(tile_1_5, black)
Atom painted(tile_1_5, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_2_5)
Atom painted(tile_2_5, black)
Atom painted(tile_2_5, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
56
begin_mutex_group
4
1 0
1 1
1 2
8 0
end_mutex_group
begin_mutex_group
2
1 0
8 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
8 1
end_mutex_group
begin_mutex_group
2
3 0
8 1
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
8 2




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
45
2
18 0
8 26
0
70
2
10 0
8 26
3
0
21
2
23 0
8 26
0
45
2
18 0
8 26
0
70
2
10 0
8 26
end_DTG
begin_DTG
5
1
166
2
8 16
0 0
2
167
2
8 16
0 1
3
43
1
8 24
3
66
1
8 22
3
87
1
8 16
3
0
18
2
25 0
8 23
0
42
2
15 0
8 23
0
67
2
19 0
8 23
3
0
18
2
25 0
8 23
0
42
2
15 0
8 23
0
67
2
19 0
8 23
3
0
18
2
25 0
8 23
0
42
2
15 0
8 23
0
67
2
19 0
8 23
end_DTG
begin_DTG
5
1
170
2
8 18
0 0
2
171
2
8 18
0 1
3
45
1
8 26
3
68
1
8 24
3
89
1
8 18
3
0
20
2
28 0
8 25
0
44
2
19 0
8 25
0
69
2
16 0
8 25
3
0
20
2
28 0
8 25
0
44
2
19 0
8 25
0
69
2
16 0
8 25
3
0
20
2
28 0
8 25
0
44
2
19 0
8 25
0
69
2
16 0
8 25
end_DTG
begin_DTG
5
1
168
2
8 17
0 0
2
169
2
8 17
0 1
3
44
1
8 25
3
67
1
8 23
3
88
1
8 17
3
0
19
2
29 0
8 24
0
43
2
17 0
8 24
0
68
2
18 0
8 24
3
0
19
2
29 0
8 24
0
43
2
17 0
8 24
0
68
2
18 0
8 24
3
0
19
2
29 0
8 24
0
43
2
17 0
8 24
0
68
2
18 0
8 24
end_DTG
begin_DTG
8
1
108
2
8 15
0 0
1
136
2
8 1
0 0
2
109
2
8 15
0 1
2
137
2
8 1
0 1
3
10
1
8 15
3
30
1
8 9
3
53
1
8 7
3
72
1
8 1
4
0
3
2
3 0
8 8
0
29
2
11 0
8 8
0
54
2
24 0
8 8
0
79
2
21 0
8 8
4
0
3
2
3 0
8 8
0
29
2
11 0
8 8
0
54
2
24 0
8 8
0
79
2
21 0
8 8
4
0
3
2
3 0
8 8
0
29
2
11 0
8 8
0
54
2
24 0
8 8
0
79
2
21 0
8 8
end_DTG
begin_DTG
8
1
122
2
8 22
0 0
1
150
2
8 8
0 0
2
123
2
8 22
0 1
2
151
2
8 8
0 1
3
17
1
8 22
3
36
1
8 16
3
59
1
8 14
3
79
1
8 8
4
0
10
2
20 0
8 15
0
35
2
12 0
8 15
0
60
2
25 0
8 15
0
86
2
15 0
8 15
4
0
10
2
20 0
8 15
0
35
2
12 0
8 15
0
60
2
25 0
8 15
0
86
2
15 0
8 15
4
0
10
2
20 0
8 15
0
35
2
12 0
8 15
0
60
2
25 0
8 15
0
86
2
15 0
8 15
end_DTG
begin_DTG
8
1
116
2
8 19
0 0
1
144
2
8 5
0 0
2
117
2
8 19
0 1
2
145
2
8 5
0 1
3
14
1
8 19
3
34
1
8 13
3
57
1
8 11
3
76
1
8 5
4
0
7
2
4 0
8 12
0
33
2
26 0
8 12
0
58
2
13 0
8 12
0
83
2
23 0
8 12
4
0
7
2
4 0
8 12
0
33
2
26 0
8 12
0
58
2
13 0
8 12
0
83
2
23 0
8 12
4
0
7
2
4 0
8 12
0
33
2
26 0
8 12
0
58
2
13 0
8 12
0
83
2
23 0
8 12
end_DTG
begin_DTG
8
1
130
2
8 26
0 0
1
158
2
8 12
0 0
2
131
2
8 26
0 1
2
159
2
8 12
0 1
3
21
1
8 26
3
40
1
8 20
3
63
1
8 18
3
83
1
8 12
4
0
14
2
22 0
8 19
0
39
2
28 0
8 19
0
64
2
14 0
8 19
0
90
2
16 0
8 19
4
0
14
2
22 0
8 19
0
39
2
28 0
8 19
0
64
2
14 0
8 19
0
90
2
16 0
8 19
4
0
14
2
22 0
8 19
0
39
2
28 0
8 19
0
64
2
14 0
8 19
0
90
2
16 0
8 19
end_DTG
begin_DTG
8
1
110
2
8 16
0 0
1
138
2
8 2
0 0
2
111
2
8 16
0 1
2
139
2
8 2
0 1
3
11
1
8 16
3
31
1
8 10
3
54
1
8 8
3
73
1
8 2
4
0
4
2
5 0
8 9
0
30
2
20 0
8 9
0
55
2
27 0
8 9
0
80
2
25 0
8 9
4
0
4
2
5 0
8 9
0
30
2
20 0
8 9
0
55
2
27 0
8 9
0
80
2
25 0
8 9
4
0
4
2
5 0
8 9
0
30
2
20 0
8 9
0
55
2
27 0
8 9
0
80
2
25 0
8 9
end_DTG
begin_DTG
8
1
124
2
8 23
0 0
1
152
2
8 9
0 0
2
125
2
8 23
0 1
2
153
2
8 9
0 1
3
18
1
8 23
3
37
1
8 17
3
60
1
8 15
3
80
1
8 9
4
0
11
2
24 0
8 16
0
36
2
21 0
8 16
0
61
2
29 0
8 16
0
87
2
17 0
8 16
4
0
11
2
24 0
8 16
0
36
2
21 0
8 16
0
61
2
29 0
8 16
0
87
2
17 0
8 16
4
0
11
2
24 0
8 16
0
36
2
21 0
8 16
0
61
2
29 0
8 16
0
87
2
17 0
8 16
end_DTG
begin_DTG
8
1
114
2
8 18
0 0
1
142
2
8 4
0 0
2
115
2
8 18
0 1
2
143
2
8 4
0 1
3
13
1
8 18
3
33
1
8 12
3
56
1
8 10
3
75
1
8 4
4
0
6
2
6 0
8 11
0
32
2
27 0
8 11
0
57
2
22 0
8 11
0
82
2
28 0
8 11
4
0
6
2
6 0
8 11
0
32
2
27 0
8 11
0
57
2
22 0
8 11
0
82
2
28 0
8 11
4
0
6
2
6 0
8 11
0
32
2
27 0
8 11
0
57
2
22 0
8 11
0
82
2
28 0
8 11
end_DTG
begin_DTG
8
1
112
2
8 17
0 0
1
140
2
8 3
0 0
2
113
2
8 17
0 1
2
141
2
8 3
0 1
3
12
1
8 17
3
32
1
8 11
3
55
1
8 9
3
74
1
8 3
4
0
5
2
7 0
8 10
0
31
2
24 0
8 10
0
56
2
26 0
8 10
0
81
2
29 0
8 10
4
0
5
2
7 0
8 10
0
31
2
24 0
8 10
0
56
2
26 0
8 10
0
81
2
29 0
8 10
4
0
5
2
7 0
8 10
0
31
2
24 0
8 10
0
56
2
26 0
8 10
0
81
2
29 0
8 10
end_DTG
begin_DTG
8
1
128
2
8 25
0 0
1
156
2
8 11
0 0
2
129
2
8 25
0 1
2
157
2
8 11
0 1
3
20
1
8 25
3
39
1
8 19
3
62
1
8 17
3
82
1
8 11
4
0
13
2
26 0
8 18
0
38
2
29 0
8 18
0
63
2
23 0
8 18
0
89
2
18 0
8 18
4
0
13
2
26 0
8 18
0
38
2
29 0
8 18
0
63
2
23 0
8 18
0
89
2
18 0
8 18
4
0
13
2
26 0
8 18
0
38
2
29 0
8 18
0
63
2
23 0
8 18
0
89
2
18 0
8 18
end_DTG
begin_DTG
8
1
126
2
8 24
0 0
1
154
2
8 10
0 0
2
127
2
8 24
0 1
2
155
2
8 10
0 1
3
19
1
8 24
3
38
1
8 18
3
61
1
8 16
3
81
1
8 10
4
0
12
2
27 0
8 17
0
37
2
25 0
8 17
0
62
2
28 0
8 17
0
88
2
19 0
8 17
4
0
12
2
27 0
8 17
0
37
2
25 0
8 17
0
62
2
28 0
8 17
0
88
2
19 0
8 17
4
0
12
2
27 0
8 17
0
37
2
25 0
8 17
0
62
2
28 0
8 17
0
88
2
19 0
8 17
end_DTG
begin_CG
28
1 2
3 2
5 2
7 2
6 2
4 2
2 2
11 4
20 4
24 4
27 4
26 4
22 4
13 4
12 4
21 4
25 4
29 4
28 4
23 4
14 4
9 2
15 2
17 2
19 2
18 2
16 2
10 2
3
3 1
11 1
8 2
3
4 1
13 1
8 2
4
1 1
5 1
20 1
8 3
4
6 1
2 1
22 1
8 3
4
3 1
7 1
24 1
8 3
4
7 1
4 1
26 1
8 3
4
5 1
6 1
27 1
8 3
28
1 6
3 8
5 8
7 8
6 8
4 8
2 6
11 10
20 12
24 12
27 12
26 12
22 12
13 10
12 10
21 12
25 12
29 12
28 12
23 12
14 10
9 6
15 8
17 8
19 8
18 8
16 8
10 6
3
12 1
15 1
8 2
3
14 1
16 1
8 2
4
1 1
20 1
12 1
8 3
4
11 1
21 1
9 1
8 3
4
2 1
22 1
14 1
8 3
4
13 1
23 1
10 1
8 3
4
21 1
9 1
17 1
8 3
4
23 1
18 1
10 1
8 3
4
25 1
15 1
19 1
8 3
4
28 1
19 1
16 1
8 3
4
29 1
17 1
18 1
8 3
5
3 1
11 1
24 1
21 1
8 4
5
20 1
12 1
25 1
15 1
8 4
5
4 1
26 1
13 1
23 1
8 4
5
22 1
28 1
14 1
16 1
8 4
5
5 1
20 1
27 1
25 1
8 4
5
24 1
21 1
29 1
17 1
8 4
5
6 1
27 1
22 1
28 1
8 4
5
7 1
24 1
26 1
29 1
8 4
5
26 1
29 1
23 1
18 1
8 4
5
27 1
25 1
28 1
19 1
8 4
end_CG
