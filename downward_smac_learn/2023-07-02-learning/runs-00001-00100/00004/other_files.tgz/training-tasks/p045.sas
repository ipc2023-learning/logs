begin_version
3
end_version
begin_metric
0
end_metric
32
begin_variable
var31
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var30
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var28
-1
28
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_5_4)
Atom robot-at(robot1, tile_6_1)
Atom robot-at(robot1, tile_6_2)
Atom robot-at(robot1, tile_6_3)
Atom robot-at(robot1, tile_6_4)
end_variable
begin_variable
var29
-1
28
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_4_4)
Atom robot-at(robot2, tile_5_1)
Atom robot-at(robot2, tile_5_2)
Atom robot-at(robot2, tile_5_3)
Atom robot-at(robot2, tile_5_4)
Atom robot-at(robot2, tile_6_1)
Atom robot-at(robot2, tile_6_2)
Atom robot-at(robot2, tile_6_3)
Atom robot-at(robot2, tile_6_4)
end_variable
begin_variable
var24
-1
4
Atom clear(tile_6_1)
Atom painted(tile_6_1, black)
Atom painted(tile_6_1, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_6_4)
Atom painted(tile_6_4, black)
Atom painted(tile_6_4, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom clear(tile_6_2)
Atom painted(tile_6_2, black)
Atom painted(tile_6_2, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_6_3)
Atom painted(tile_6_3, black)
Atom painted(tile_6_3, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_5_4)
Atom painted(tile_5_4, black)
Atom painted(tile_5_4, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_4_4)
Atom painted(tile_4_4, black)
Atom painted(tile_4_4, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_5_2)
Atom painted(tile_5_2, black)
Atom painted(tile_5_2, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_5_3)
Atom painted(tile_5_3, black)
Atom painted(tile_5_3, white)
<none of those>
end_variable
begin_vari




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




22 0
6 9
0
33
2
22 0
7 9
0
58
2
16 0
6 9
0
79
2
16 0
7 9
0
101
2
27 0
6 9
0
122
2
27 0
7 9
0
145
2
29 0
6 9
0
169
2
29 0
7 9
8
0
9
2
22 0
6 9
0
33
2
22 0
7 9
0
58
2
16 0
6 9
0
79
2
16 0
7 9
0
101
2
27 0
6 9
0
122
2
27 0
7 9
0
145
2
29 0
6 9
0
169
2
29 0
7 9
8
0
9
2
22 0
6 9
0
33
2
22 0
7 9
0
58
2
16 0
6 9
0
79
2
16 0
7 9
0
101
2
27 0
6 9
0
122
2
27 0
7 9
0
145
2
29 0
6 9
0
169
2
29 0
7 9
end_DTG
begin_DTG
16
1
204
2
6 14
1 0
1
252
2
7 14
0 0
1
292
2
6 6
1 0
1
340
2
7 6
0 0
2
205
2
6 14
1 1
2
253
2
7 14
0 1
2
293
2
6 6
1 1
2
341
2
7 6
0 1
3
14
1
6 14
3
38
1
7 14
3
60
1
6 11
3
81
1
7 11
3
101
1
6 9
3
122
1
7 9
3
142
1
6 6
3
166
1
7 6
8
0
10
2
23 0
6 10
0
34
2
23 0
7 10
0
59
2
26 0
6 10
0
80
2
26 0
7 10
0
102
2
17 0
6 10
0
123
2
17 0
7 10
0
146
2
31 0
6 10
0
170
2
31 0
7 10
8
0
10
2
23 0
6 10
0
34
2
23 0
7 10
0
59
2
26 0
6 10
0
80
2
26 0
7 10
0
102
2
17 0
6 10
0
123
2
17 0
7 10
0
146
2
31 0
6 10
0
170
2
31 0
7 10
8
0
10
2
23 0
6 10
0
34
2
23 0
7 10
0
59
2
26 0
6 10
0
80
2
26 0
7 10
0
102
2
17 0
6 10
0
123
2
17 0
7 10
0
146
2
31 0
6 10
0
170
2
31 0
7 10
end_DTG
begin_DTG
16
1
218
2
6 21
1 0
1
266
2
7 21
0 0
1
306
2
6 13
1 0
1
354
2
7 13
0 0
2
219
2
6 21
1 1
2
267
2
7 21
0 1
2
307
2
6 13
1 1
2
355
2
7 13
0 1
3
21
1
6 21
3
45
1
7 21
3
65
1
6 18
3
86
1
7 18
3
106
1
6 16
3
127
1
7 16
3
149
1
6 13
3
173
1
7 13
8
0
17
2
29 0
6 17
0
41
2
29 0
7 17
0
64
2
18 0
6 17
0
85
2
18 0
7 17
0
107
2
30 0
6 17
0
128
2
30 0
7 17
0
153
2
24 0
6 17
0
177
2
24 0
7 17
8
0
17
2
29 0
6 17
0
41
2
29 0
7 17
0
64
2
18 0
6 17
0
85
2
18 0
7 17
0
107
2
30 0
6 17
0
128
2
30 0
7 17
0
153
2
24 0
6 17
0
177
2
24 0
7 17
8
0
17
2
29 0
6 17
0
41
2
29 0
7 17
0
64
2
18 0
6 17
0
85
2
18 0
7 17
0
107
2
30 0
6 17
0
128
2
30 0
7 17
0
153
2
24 0
6 17
0
177
2
24 0
7 17
end_DTG
begin_DTG
16
1
210
2
6 17
1 0
1
258
2
7 17
0 0
1
298
2
6 9
1 0
1
346
2
7 9
0 0
2
211
2
6 17
1 1
2
259
2
7 17
0 1
2
299
2
6 9
1 1
2
347
2
7 9
0 1
3
17
1
6 17
3
41
1
7 17
3
62
1
6 14
3
83
1
7 14
3
103
1
6 12
3
124
1
7 12
3
145
1
6 9
3
169
1
7 9
8
0
13
2
26 0
6 13
0
37
2
26 0
7 13
0
61
2
19 0
6 13
0
82
2
19 0
7 13
0
104
2
31 0
6 13
0
125
2
31 0
7 13
0
149
2
28 0
6 13
0
173
2
28 0
7 13
8
0
13
2
26 0
6 13
0
37
2
26 0
7 13
0
61
2
19 0
6 13
0
82
2
19 0
7 13
0
104
2
31 0
6 13
0
125
2
31 0
7 13
0
149
2
28 0
6 13
0
173
2
28 0
7 13
8
0
13
2
26 0
6 13
0
37
2
26 0
7 13
0
61
2
19 0
6 13
0
82
2
19 0
7 13
0
104
2
31 0
6 13
0
125
2
31 0
7 13
0
149
2
28 0
6 13
0
173
2
28 0
7 13
end_DTG
begin_DTG
16
1
220
2
6 22
1 0
1
268
2
7 22
0 0
1
308
2
6 14
1 0
1
356
2
7 14
0 0
2
221
2
6 22
1 1
2
269
2
7 22
0 1
2
309
2
6 14
1 1
2
357
2
7 14
0 1
3
22
1
6 22
3
46
1
7 22
3
66
1
6 19
3
87
1
7 19
3
107
1
6 17
3
128
1
7 17
3
150
1
6 14
3
174
1
7 14
8
0
18
2
31 0
6 18
0
42
2
31 0
7 18
0
65
2
28 0
6 18
0
86
2
28 0
7 18
0
108
2
20 0
6 18
0
129
2
20 0
7 18
0
154
2
25 0
6 18
0
178
2
25 0
7 18
8
0
18
2
31 0
6 18
0
42
2
31 0
7 18
0
65
2
28 0
6 18
0
86
2
28 0
7 18
0
108
2
20 0
6 18
0
129
2
20 0
7 18
0
154
2
25 0
6 18
0
178
2
25 0
7 18
8
0
18
2
31 0
6 18
0
42
2
31 0
7 18
0
65
2
28 0
6 18
0
86
2
28 0
7 18
0
108
2
20 0
6 18
0
129
2
20 0
7 18
0
154
2
25 0
6 18
0
178
2
25 0
7 18
end_DTG
begin_DTG
16
1
212
2
6 18
1 0
1
260
2
7 18
0 0
1
300
2
6 10
1 0
1
348
2
7 10
0 0
2
213
2
6 18
1 1
2
261
2
7 18
0 1
2
301
2
6 10
1 1
2
349
2
7 10
0 1
3
18
1
6 18
3
42
1
7 18
3
63
1
6 15
3
84
1
7 15
3
104
1
6 13
3
125
1
7 13
3
146
1
6 10
3
170
1
7 10
8
0
14
2
27 0
6 14
0
38
2
27 0
7 14
0
62
2
29 0
6 14
0
83
2
29 0
7 14
0
105
2
21 0
6 14
0
126
2
21 0
7 14
0
150
2
30 0
6 14
0
174
2
30 0
7 14
8
0
14
2
27 0
6 14
0
38
2
27 0
7 14
0
62
2
29 0
6 14
0
83
2
29 0
7 14
0
105
2
21 0
6 14
0
126
2
21 0
7 14
0
150
2
30 0
6 14
0
174
2
30 0
7 14
8
0
14
2
27 0
6 14
0
38
2
27 0
7 14
0
62
2
29 0
6 14
0
83
2
29 0
7 14
0
105
2
21 0
6 14
0
126
2
21 0
7 14
0
150
2
30 0
6 14
0
174
2
30 0
7 14
end_DTG
begin_CG
28
2 2
4 2
5 2
3 2
10 4
22 4
23 4
11 4
16 4
26 4
27 4
17 4
19 4
29 4
31 4
21 4
18 4
28 4
30 4
20 4
12 4
24 4
25 4
15 4
8 2
13 2
14 2
9 2
28
2 2
4 2
5 2
3 2
10 4
22 4
23 4
11 4
16 4
26 4
27 4
17 4
19 4
29 4
31 4
21 4
18 4
28 4
30 4
20 4
12 4
24 4
25 4
15 4
8 2
13 2
14 2
9 2
4
4 2
10 2
6 2
7 2
4
5 2
11 2
6 2
7 2
5
2 2
5 2
22 2
6 3
7 3
5
4 2
3 2
23 2
6 3
7 3
28
2 6
4 8
5 8
3 6
10 10
22 12
23 12
11 10
16 10
26 12
27 12
17 10
19 10
29 12
31 12
21 10
18 10
28 12
30 12
20 10
12 10
24 12
25 12
15 10
8 6
13 8
14 8
9 6
28
2 6
4 8
5 8
3 6
10 10
22 12
23 12
11 10
16 10
26 12
27 12
17 10
19 10
29 12
31 12
21 10
18 10
28 12
30 12
20 10
12 10
24 12
25 12
15 10
8 6
13 8
14 8
9 6
4
12 2
13 2
6 2
7 2
4
15 2
14 2
6 2
7 2
5
2 2
22 2
16 2
6 3
7 3
5
3 2
23 2
17 2
6 3
7 3
5
18 2
24 2
8 2
6 3
7 3
5
24 2
8 2
14 2
6 3
7 3
5
25 2
13 2
9 2
6 3
7 3
5
20 2
25 2
9 2
6 3
7 3
5
10 2
26 2
19 2
6 3
7 3
5
11 2
27 2
21 2
6 3
7 3
5
19 2
28 2
12 2
6 3
7 3
5
16 2
29 2
18 2
6 3
7 3
5
21 2
30 2
15 2
6 3
7 3
5
17 2
31 2
20 2
6 3
7 3
6
4 2
10 2
23 2
26 2
6 4
7 4
6
5 2
22 2
11 2
27 2
6 4
7 4
6
28 2
12 2
25 2
13 2
6 4
7 4
6
30 2
24 2
15 2
14 2
6 4
7 4
6
22 2
16 2
27 2
29 2
6 4
7 4
6
23 2
26 2
17 2
31 2
6 4
7 4
6
29 2
18 2
30 2
24 2
6 4
7 4
6
26 2
19 2
31 2
28 2
6 4
7 4
6
31 2
28 2
20 2
25 2
6 4
7 4
6
27 2
29 2
21 2
30 2
6 4
7 4
end_CG
