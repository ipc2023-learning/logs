begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var33
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_0_8)
Atom painted(tile_0_8, black)
Atom painted(tile_0_8, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_0_7)
Atom painted(tile_0_7, black)
Atom painted(tile_0_7, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var32
-1
32
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_0_7)
Atom robot-at(robot1, tile_0_8)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_1_7)
Atom robot-at(robot1, tile_1_8)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_2_7)
Atom robot-at(robot1, tile_2_8)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_3_7)
Atom robot-at(robot1, tile_3_8)
end_variable
begin_variable
var24
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var31
-1
4
Atom clear(tile_3_8)
Atom painted(tile_3_8, black)
Atom painted(tile_3_8, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_1_8)
Atom painted(tile_1_8, black)
Atom painted(tile_1_8, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_2_8)
Atom painted(tile_2_8, black)
Atom painted(tile_2_8, white)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var30
-1
4
Atom clear(tile_3_7)
Atom painted(tile_3_7, black)
Atom painted(tile_3_7, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_3_6)
Atom painted(tile_3_6, black)
Atom painted(tile_3_6, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var28
-1
4
Atom clear(tile_3_5)
Atom painted(tile_3_5, black)
Atom painted(tile_3_5, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_1_7)
Atom painted(tile_1_7, black)
Atom painted(tile_1_7, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_2_7)
Atom painted(tile_2_7, black)
Atom painted(tile_2_7, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_1_6)
Atom painted(tile_1_6, black)
Atom painted(tile_1_6, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_2_6)
Atom painted(tile_2_6, black)
Atom painted(tile_2_6, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, wh




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




G
8
1
124
2
9 17
0 0
1
156
2
9 1
0 0
2
125
2
9 17
0 1
2
157
2
9 1
0 1
3
11
1
9 17
3
34
1
9 10
3
61
1
9 8
3
83
1
9 1
4
0
3
2
3 0
9 9
0
33
2
12 0
9 9
0
62
2
26 0
9 9
0
91
2
23 0
9 9
4
0
3
2
3 0
9 9
0
33
2
12 0
9 9
0
62
2
26 0
9 9
0
91
2
23 0
9 9
4
0
3
2
3 0
9 9
0
33
2
12 0
9 9
0
62
2
26 0
9 9
0
91
2
23 0
9 9
end_DTG
begin_DTG
8
1
140
2
9 25
0 0
1
172
2
9 9
0 0
2
141
2
9 25
0 1
2
173
2
9 9
0 1
3
19
1
9 25
3
41
1
9 18
3
68
1
9 16
3
91
1
9 9
4
0
11
2
22 0
9 17
0
40
2
13 0
9 17
0
69
2
27 0
9 17
0
99
2
16 0
9 17
4
0
11
2
22 0
9 17
0
40
2
13 0
9 17
0
69
2
27 0
9 17
0
99
2
16 0
9 17
4
0
11
2
22 0
9 17
0
40
2
13 0
9 17
0
69
2
27 0
9 17
0
99
2
16 0
9 17
end_DTG
begin_DTG
8
1
134
2
9 22
0 0
1
166
2
9 6
0 0
2
135
2
9 22
0 1
2
167
2
9 6
0 1
3
16
1
9 22
3
39
1
9 15
3
66
1
9 13
3
88
1
9 6
4
0
8
2
4 0
9 14
0
38
2
28 0
9 14
0
67
2
14 0
9 14
0
96
2
25 0
9 14
4
0
8
2
4 0
9 14
0
38
2
28 0
9 14
0
67
2
14 0
9 14
0
96
2
25 0
9 14
4
0
8
2
4 0
9 14
0
38
2
28 0
9 14
0
67
2
14 0
9 14
0
96
2
25 0
9 14
end_DTG
begin_DTG
8
1
150
2
9 30
0 0
1
182
2
9 14
0 0
2
151
2
9 30
0 1
2
183
2
9 14
0 1
3
24
1
9 30
3
46
1
9 23
3
73
1
9 21
3
96
1
9 14
4
0
16
2
24 0
9 22
0
45
2
29 0
9 22
0
74
2
15 0
9 22
0
104
2
17 0
9 22
4
0
16
2
24 0
9 22
0
45
2
29 0
9 22
0
74
2
15 0
9 22
0
104
2
17 0
9 22
4
0
16
2
24 0
9 22
0
45
2
29 0
9 22
0
74
2
15 0
9 22
0
104
2
17 0
9 22
end_DTG
begin_DTG
8
1
126
2
9 18
0 0
1
158
2
9 2
0 0
2
127
2
9 18
0 1
2
159
2
9 2
0 1
3
12
1
9 18
3
35
1
9 11
3
62
1
9 9
3
84
1
9 2
4
0
4
2
5 0
9 10
0
34
2
22 0
9 10
0
63
2
30 0
9 10
0
92
2
27 0
9 10
4
0
4
2
5 0
9 10
0
34
2
22 0
9 10
0
63
2
30 0
9 10
0
92
2
27 0
9 10
4
0
4
2
5 0
9 10
0
34
2
22 0
9 10
0
63
2
30 0
9 10
0
92
2
27 0
9 10
end_DTG
begin_DTG
8
1
142
2
9 26
0 0
1
174
2
9 10
0 0
2
143
2
9 26
0 1
2
175
2
9 10
0 1
3
20
1
9 26
3
42
1
9 19
3
69
1
9 17
3
92
1
9 10
4
0
12
2
26 0
9 18
0
41
2
23 0
9 18
0
70
2
32 0
9 18
0
100
2
18 0
9 18
4
0
12
2
26 0
9 18
0
41
2
23 0
9 18
0
70
2
32 0
9 18
0
100
2
18 0
9 18
4
0
12
2
26 0
9 18
0
41
2
23 0
9 18
0
70
2
32 0
9 18
0
100
2
18 0
9 18
end_DTG
begin_DTG
8
1
132
2
9 21
0 0
1
164
2
9 5
0 0
2
133
2
9 21
0 1
2
165
2
9 5
0 1
3
15
1
9 21
3
38
1
9 14
3
65
1
9 12
3
87
1
9 5
4
0
7
2
6 0
9 13
0
37
2
31 0
9 13
0
66
2
24 0
9 13
0
95
2
29 0
9 13
4
0
7
2
6 0
9 13
0
37
2
31 0
9 13
0
66
2
24 0
9 13
0
95
2
29 0
9 13
4
0
7
2
6 0
9 13
0
37
2
31 0
9 13
0
66
2
24 0
9 13
0
95
2
29 0
9 13
end_DTG
begin_DTG
8
1
148
2
9 29
0 0
1
180
2
9 13
0 0
2
149
2
9 29
0 1
2
181
2
9 13
0 1
3
23
1
9 29
3
45
1
9 22
3
72
1
9 20
3
95
1
9 13
4
0
15
2
28 0
9 21
0
44
2
33 0
9 21
0
73
2
25 0
9 21
0
103
2
19 0
9 21
4
0
15
2
28 0
9 21
0
44
2
33 0
9 21
0
73
2
25 0
9 21
0
103
2
19 0
9 21
4
0
15
2
28 0
9 21
0
44
2
33 0
9 21
0
73
2
25 0
9 21
0
103
2
19 0
9 21
end_DTG
begin_DTG
8
1
128
2
9 19
0 0
1
160
2
9 3
0 0
2
129
2
9 19
0 1
2
161
2
9 3
0 1
3
13
1
9 19
3
36
1
9 12
3
63
1
9 10
3
85
1
9 3
4
0
5
2
7 0
9 11
0
35
2
26 0
9 11
0
64
2
31 0
9 11
0
93
2
32 0
9 11
4
0
5
2
7 0
9 11
0
35
2
26 0
9 11
0
64
2
31 0
9 11
0
93
2
32 0
9 11
4
0
5
2
7 0
9 11
0
35
2
26 0
9 11
0
64
2
31 0
9 11
0
93
2
32 0
9 11
end_DTG
begin_DTG
8
1
130
2
9 20
0 0
1
162
2
9 4
0 0
2
131
2
9 20
0 1
2
163
2
9 4
0 1
3
14
1
9 20
3
37
1
9 13
3
64
1
9 11
3
86
1
9 4
4
0
6
2
8 0
9 12
0
36
2
30 0
9 12
0
65
2
28 0
9 12
0
94
2
33 0
9 12
4
0
6
2
8 0
9 12
0
36
2
30 0
9 12
0
65
2
28 0
9 12
0
94
2
33 0
9 12
4
0
6
2
8 0
9 12
0
36
2
30 0
9 12
0
65
2
28 0
9 12
0
94
2
33 0
9 12
end_DTG
begin_DTG
8
1
144
2
9 27
0 0
1
176
2
9 11
0 0
2
145
2
9 27
0 1
2
177
2
9 11
0 1
3
21
1
9 27
3
43
1
9 20
3
70
1
9 18
3
93
1
9 11
4
0
13
2
30 0
9 19
0
42
2
27 0
9 19
0
71
2
33 0
9 19
0
101
2
20 0
9 19
4
0
13
2
30 0
9 19
0
42
2
27 0
9 19
0
71
2
33 0
9 19
0
101
2
20 0
9 19
4
0
13
2
30 0
9 19
0
42
2
27 0
9 19
0
71
2
33 0
9 19
0
101
2
20 0
9 19
end_DTG
begin_DTG
8
1
146
2
9 28
0 0
1
178
2
9 12
0 0
2
147
2
9 28
0 1
2
179
2
9 12
0 1
3
22
1
9 28
3
44
1
9 21
3
71
1
9 19
3
94
1
9 12
4
0
14
2
31 0
9 20
0
43
2
32 0
9 20
0
72
2
29 0
9 20
0
102
2
21 0
9 20
4
0
14
2
31 0
9 20
0
43
2
32 0
9 20
0
72
2
29 0
9 20
0
102
2
21 0
9 20
4
0
14
2
31 0
9 20
0
43
2
32 0
9 20
0
72
2
29 0
9 20
0
102
2
21 0
9 20
end_DTG
begin_CG
32
1 2
3 2
5 2
7 2
8 2
6 2
4 2
2 2
12 4
22 4
26 4
30 4
31 4
28 4
24 4
14 4
13 4
23 4
27 4
32 4
33 4
29 4
25 4
15 4
10 2
16 2
18 2
20 2
21 2
19 2
17 2
11 2
3
3 1
12 1
9 2
3
4 1
14 1
9 2
4
1 1
5 1
22 1
9 3
4
6 1
2 1
24 1
9 3
4
3 1
7 1
26 1
9 3
4
8 1
4 1
28 1
9 3
4
5 1
8 1
30 1
9 3
4
7 1
6 1
31 1
9 3
32
1 6
3 8
5 8
7 8
8 8
6 8
4 8
2 6
12 10
22 12
26 12
30 12
31 12
28 12
24 12
14 10
13 10
23 12
27 12
32 12
33 12
29 12
25 12
15 10
10 6
16 8
18 8
20 8
21 8
19 8
17 8
11 6
3
13 1
16 1
9 2
3
15 1
17 1
9 2
4
1 1
22 1
13 1
9 3
4
12 1
23 1
10 1
9 3
4
2 1
24 1
15 1
9 3
4
14 1
25 1
11 1
9 3
4
23 1
10 1
18 1
9 3
4
25 1
19 1
11 1
9 3
4
27 1
16 1
20 1
9 3
4
29 1
21 1
17 1
9 3
4
32 1
18 1
21 1
9 3
4
33 1
20 1
19 1
9 3
5
3 1
12 1
26 1
23 1
9 4
5
22 1
13 1
27 1
16 1
9 4
5
4 1
28 1
14 1
25 1
9 4
5
24 1
29 1
15 1
17 1
9 4
5
5 1
22 1
30 1
27 1
9 4
5
26 1
23 1
32 1
18 1
9 4
5
6 1
31 1
24 1
29 1
9 4
5
28 1
33 1
25 1
19 1
9 4
5
7 1
26 1
31 1
32 1
9 4
5
8 1
30 1
28 1
33 1
9 4
5
30 1
27 1
33 1
20 1
9 4
5
31 1
32 1
29 1
21 1
9 4
end_CG
