begin_version
3
end_version
begin_metric
0
end_metric
32
begin_variable
var31
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var30
-1
30
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_4_5)
Atom robot-at(robot1, tile_4_6)
end_variable
begin_variable
var24
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_4_6)
Atom painted(tile_4_6, black)
Atom painted(tile_4_6, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_1_6)
Atom painted(tile_1_6, black)
Atom painted(tile_1_6, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_3_6)
Atom painted(tile_3_6, black)
Atom painted(tile_3_6, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_2_6)
Atom painted(tile_2_6, black)
Atom painted(tile_2_6, white)
<none of those>
end_variable
begin_variable
var28
-1
4
Atom clear(tile_4_5)
Atom painted(tile_4_5, black)
Atom painted(tile_4_5, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_4_4)
Atom painted(tile_4_4, black)
Atom painted(tile_4_4, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_1_5)
Atom painted(tile_1_5, black)
Atom painted(tile_1_5, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_3_5)
Atom painted(tile_3_5, black)
Atom painted(tile_3_5, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_2_5)
Atom painted(tile_2_5, black)
Atom painted(tile_2_5, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
7 27
0
74
2
17 0
7 27
3
0
23
2
30 0
7 27
0
48
2
18 0
7 27
0
74
2
17 0
7 27
end_DTG
begin_DTG
8
1
114
2
7 13
0 0
1
150
2
7 1
0 0
2
115
2
7 13
0 1
2
151
2
7 1
0 1
3
9
1
7 13
3
32
1
7 8
3
56
1
7 6
3
77
1
7 1
4
0
3
2
3 0
7 7
0
31
2
10 0
7 7
0
57
2
26 0
7 7
0
83
2
23 0
7 7
4
0
3
2
3 0
7 7
0
31
2
10 0
7 7
0
57
2
26 0
7 7
0
83
2
23 0
7 7
4
0
3
2
3 0
7 7
0
31
2
10 0
7 7
0
57
2
26 0
7 7
0
83
2
23 0
7 7
end_DTG
begin_DTG
8
1
120
2
7 16
0 0
1
156
2
7 4
0 0
2
121
2
7 16
0 1
2
157
2
7 4
0 1
3
12
1
7 16
3
35
1
7 11
3
59
1
7 9
3
80
1
7 4
4
0
6
2
4 0
7 10
0
34
2
27 0
7 10
0
60
2
11 0
7 10
0
86
2
25 0
7 10
4
0
6
2
4 0
7 10
0
34
2
27 0
7 10
0
60
2
11 0
7 10
0
86
2
25 0
7 10
4
0
6
2
4 0
7 10
0
34
2
27 0
7 10
0
60
2
11 0
7 10
0
86
2
25 0
7 10
end_DTG
begin_DTG
8
1
138
2
7 25
0 0
1
174
2
7 13
0 0
2
139
2
7 25
0 1
2
175
2
7 13
0 1
3
21
1
7 25
3
42
1
7 20
3
66
1
7 18
3
89
1
7 13
4
0
15
2
23 0
7 19
0
41
2
12 0
7 19
0
67
2
28 0
7 19
0
95
2
14 0
7 19
4
0
15
2
23 0
7 19
0
41
2
12 0
7 19
0
67
2
28 0
7 19
0
95
2
14 0
7 19
4
0
15
2
23 0
7 19
0
41
2
12 0
7 19
0
67
2
28 0
7 19
0
95
2
14 0
7 19
end_DTG
begin_DTG
8
1
126
2
7 19
0 0
1
162
2
7 7
0 0
2
127
2
7 19
0 1
2
163
2
7 7
0 1
3
15
1
7 19
3
37
1
7 14
3
61
1
7 12
3
83
1
7 7
4
0
9
2
20 0
7 13
0
36
2
13 0
7 13
0
62
2
29 0
7 13
0
89
2
22 0
7 13
4
0
9
2
20 0
7 13
0
36
2
13 0
7 13
0
62
2
29 0
7 13
0
89
2
22 0
7 13
4
0
9
2
20 0
7 13
0
36
2
13 0
7 13
0
62
2
29 0
7 13
0
89
2
22 0
7 13
end_DTG
begin_DTG
8
1
144
2
7 28
0 0
1
180
2
7 16
0 0
2
145
2
7 28
0 1
2
181
2
7 16
0 1
3
24
1
7 28
3
45
1
7 23
3
69
1
7 21
3
92
1
7 16
4
0
18
2
25 0
7 22
0
44
2
30 0
7 22
0
70
2
15 0
7 22
0
98
2
17 0
7 22
4
0
18
2
25 0
7 22
0
44
2
30 0
7 22
0
70
2
15 0
7 22
0
98
2
17 0
7 22
4
0
18
2
25 0
7 22
0
44
2
30 0
7 22
0
70
2
15 0
7 22
0
98
2
17 0
7 22
end_DTG
begin_DTG
8
1
132
2
7 22
0 0
1
168
2
7 10
0 0
2
133
2
7 22
0 1
2
169
2
7 10
0 1
3
18
1
7 22
3
40
1
7 17
3
64
1
7 15
3
86
1
7 10
4
0
12
2
21 0
7 16
0
39
2
31 0
7 16
0
65
2
16 0
7 16
0
92
2
24 0
7 16
4
0
12
2
21 0
7 16
0
39
2
31 0
7 16
0
65
2
16 0
7 16
0
92
2
24 0
7 16
4
0
12
2
21 0
7 16
0
39
2
31 0
7 16
0
65
2
16 0
7 16
0
92
2
24 0
7 16
end_DTG
begin_DTG
8
1
116
2
7 14
0 0
1
152
2
7 2
0 0
2
117
2
7 14
0 1
2
153
2
7 2
0 1
3
10
1
7 14
3
33
1
7 9
3
57
1
7 7
3
78
1
7 2
4
0
4
2
5 0
7 8
0
32
2
20 0
7 8
0
58
2
27 0
7 8
0
84
2
29 0
7 8
4
0
4
2
5 0
7 8
0
32
2
20 0
7 8
0
58
2
27 0
7 8
0
84
2
29 0
7 8
4
0
4
2
5 0
7 8
0
32
2
20 0
7 8
0
58
2
27 0
7 8
0
84
2
29 0
7 8
end_DTG
begin_DTG
8
1
118
2
7 15
0 0
1
154
2
7 3
0 0
2
119
2
7 15
0 1
2
155
2
7 3
0 1
3
11
1
7 15
3
34
1
7 10
3
58
1
7 8
3
79
1
7 3
4
0
5
2
6 0
7 9
0
33
2
26 0
7 9
0
59
2
21 0
7 9
0
85
2
31 0
7 9
4
0
5
2
6 0
7 9
0
33
2
26 0
7 9
0
59
2
21 0
7 9
0
85
2
31 0
7 9
4
0
5
2
6 0
7 9
0
33
2
26 0
7 9
0
59
2
21 0
7 9
0
85
2
31 0
7 9
end_DTG
begin_DTG
8
1
140
2
7 26
0 0
1
176
2
7 14
0 0
2
141
2
7 26
0 1
2
177
2
7 14
0 1
3
22
1
7 26
3
43
1
7 21
3
67
1
7 19
3
90
1
7 14
4
0
16
2
29 0
7 20
0
42
2
22 0
7 20
0
68
2
30 0
7 20
0
96
2
18 0
7 20
4
0
16
2
29 0
7 20
0
42
2
22 0
7 20
0
68
2
30 0
7 20
0
96
2
18 0
7 20
4
0
16
2
29 0
7 20
0
42
2
22 0
7 20
0
68
2
30 0
7 20
0
96
2
18 0
7 20
end_DTG
begin_DTG
8
1
128
2
7 20
0 0
1
164
2
7 8
0 0
2
129
2
7 20
0 1
2
165
2
7 8
0 1
3
16
1
7 20
3
38
1
7 15
3
62
1
7 13
3
84
1
7 8
4
0
10
2
26 0
7 14
0
37
2
23 0
7 14
0
63
2
31 0
7 14
0
90
2
28 0
7 14
4
0
10
2
26 0
7 14
0
37
2
23 0
7 14
0
63
2
31 0
7 14
0
90
2
28 0
7 14
4
0
10
2
26 0
7 14
0
37
2
23 0
7 14
0
63
2
31 0
7 14
0
90
2
28 0
7 14
end_DTG
begin_DTG
8
1
142
2
7 27
0 0
1
178
2
7 15
0 0
2
143
2
7 27
0 1
2
179
2
7 15
0 1
3
23
1
7 27
3
44
1
7 22
3
68
1
7 20
3
91
1
7 15
4
0
17
2
31 0
7 21
0
43
2
28 0
7 21
0
69
2
24 0
7 21
0
97
2
19 0
7 21
4
0
17
2
31 0
7 21
0
43
2
28 0
7 21
0
69
2
24 0
7 21
0
97
2
19 0
7 21
4
0
17
2
31 0
7 21
0
43
2
28 0
7 21
0
69
2
24 0
7 21
0
97
2
19 0
7 21
end_DTG
begin_DTG
8
1
130
2
7 21
0 0
1
166
2
7 9
0 0
2
131
2
7 21
0 1
2
167
2
7 9
0 1
3
17
1
7 21
3
39
1
7 16
3
63
1
7 14
3
85
1
7 9
4
0
11
2
27 0
7 15
0
38
2
29 0
7 15
0
64
2
25 0
7 15
0
91
2
30 0
7 15
4
0
11
2
27 0
7 15
0
38
2
29 0
7 15
0
64
2
25 0
7 15
0
91
2
30 0
7 15
4
0
11
2
27 0
7 15
0
38
2
29 0
7 15
0
64
2
25 0
7 15
0
91
2
30 0
7 15
end_DTG
begin_CG
30
1 2
3 2
5 2
6 2
4 2
2 2
10 4
20 4
26 4
27 4
21 4
11 4
13 4
23 4
29 4
31 4
25 4
16 4
12 4
22 4
28 4
30 4
24 4
15 4
8 2
14 2
18 2
19 2
17 2
9 2
3
3 1
10 1
7 2
3
4 1
11 1
7 2
4
1 1
5 1
20 1
7 3
4
6 1
2 1
21 1
7 3
4
3 1
6 1
26 1
7 3
4
5 1
4 1
27 1
7 3
30
1 6
3 8
5 8
6 8
4 8
2 6
10 10
20 12
26 12
27 12
21 12
11 10
13 10
23 12
29 12
31 12
25 12
16 10
12 10
22 12
28 12
30 12
24 12
15 10
8 6
14 8
18 8
19 8
17 8
9 6
3
12 1
14 1
7 2
3
15 1
17 1
7 2
4
1 1
20 1
13 1
7 3
4
2 1
21 1
16 1
7 3
4
13 1
22 1
8 1
7 3
4
10 1
23 1
12 1
7 3
4
22 1
8 1
18 1
7 3
4
16 1
24 1
9 1
7 3
4
11 1
25 1
15 1
7 3
4
24 1
19 1
9 1
7 3
4
28 1
14 1
19 1
7 3
4
30 1
18 1
17 1
7 3
5
3 1
10 1
26 1
23 1
7 4
5
4 1
27 1
11 1
25 1
7 4
5
23 1
12 1
28 1
14 1
7 4
5
20 1
13 1
29 1
22 1
7 4
5
25 1
30 1
15 1
17 1
7 4
5
21 1
31 1
16 1
24 1
7 4
5
5 1
20 1
27 1
29 1
7 4
5
6 1
26 1
21 1
31 1
7 4
5
29 1
22 1
30 1
18 1
7 4
5
26 1
23 1
31 1
28 1
7 4
5
31 1
28 1
24 1
19 1
7 4
5
27 1
29 1
25 1
30 1
7 4
end_CG
