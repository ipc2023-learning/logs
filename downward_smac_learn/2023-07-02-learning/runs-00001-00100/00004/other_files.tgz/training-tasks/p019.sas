begin_version
3
end_version
begin_metric
0
end_metric
17
begin_variable
var16
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var15
-1
15
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
end_variable
begin_variable
var12
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
30
begin_mutex_group
4
1 0
1 1
1 2
4 0
end_mutex_group
begin_mutex_group
2
1 0
4 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
4 1
end_mutex_group
begin_mutex_group
2
3 0
4 1
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
4 2
end_mutex_group
begin_mutex_group
2
2 0
4 2
end_mutex_group
begin_mutex_group
4
8 0
8 1
8 2
4 3
end_mutex_group
begin_mutex_group
2
8 0
4 3
end_mutex_group
begin_mutex_group
4
14 0
14 1
14 2
4 4
end_mutex_group
begin_mutex_group
2
14 0
4 4
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
4 5
end_mutex_group
begin_mutex_group
2
9 0
4 5
end_mutex_group
begin_mutex_group
4
11 0
11 1
11 2
4 6
end_mutex_group
begin_mutex_group
2
11 0
4 6
end_mutex_group
begin_mutex_group
4
16 0
16 1
16 2
4 7
end_mutex_group
begin_mutex_group
2
16 0
4 7
end_mutex_group
begin_mutex_group
4
13 0
13 1
13 2
4 8
end_mutex_group
begin_mutex_group
2
13 0
4 8
end_mutex_group
begin_mutex_group
4
10 0
10 1
10 2
4 9
end_mutex_group
begin_mutex_group
2
10 0
4 9
end_mutex_group
begin_mutex_group
4
15 0
15 1
15 2
4 10
end_mutex_group
begin_mutex_group
2
15 0
4 10
end_mutex_group
begin_mutex_group
4
12 0
12 1
12 2
4 11
end_mutex_group
begin_mutex_group
2
12 0
4 11
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
4 12
end_mutex_group
begin_mutex_group
2
5 0
4 12
end_mutex_group
begin_mutex_group
4
7 0
7 1
7 2
4 13
end_mutex_group
begin_mutex_group
2
7 0
4 13
end_mutex_group
begin_mutex_group
4
6 0
6 1
6 2
4 14
end_mutex_group
begin_mutex_group
2
6 0
4 14
end_mutex_group
begin_state
0
0
0
0
5
0
0
0
0
3
0
0
0
0
0
0
0
end_state
begin_goal
12
5 1
6 1
7 2
8 2
9 2
10 2
11 1
12 2
13 1
14 1
15 1
16 2
end_goal
94
begin_operator
change_color robot1 black white
0
1
0 0 0 1
0
end_operator
begin_operator
change_color robot1 white black
0
1
0 0 1 0
0
end_operator
begin_operator
move_down robot1 tile_1_1 tile_0_1
0
3
0 1 0 3
0 8 -1 0
0 4 3 0
0
end_operator
begin_operator
move_down robot1 tile_1_2 tile_0_2
0
3
0 3 0 3
0 14 -1 0
0 4 4 1
0
end_operator
begin_operator
move_down robot1 tile_1_3 tile_0_3
0
3
0 2 0 3
0 9 -1 0
0 4 5 2
0
end_operator
begin_operator
move_down robot1 tile_2_1 tile_1_1
0
3
0 8 0 3
0 11 -1 0
0 4 6 3
0
end_operator
begin_operator
move_down robot1 tile_2_2 tile_1_2
0
3
0 14 0 3
0 16 -1 0
0 4 7 4
0
end_operator
begin_operator
move_down robot1 tile_2_3 tile_1_3
0
3
0 9 0 3
0 13 -1 0
0 4 8 5
0
end_operator
begin_operator
move_down robot1 tile_3_1 tile_2_1
0
3
0 11 0 3
0 10 -1 0
0 4 9 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




4
check 1
90
check 1
91
check 0
check 0
check 1
32
check 0
check 1
23
check 0
check 0
check 0
check 0
switch 6
check 0
switch 4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 1
45
check 1
92
check 1
93
check 0
check 0
check 1
33
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 1
1
check 0
end_SG
begin_DTG
1
1
0
0
1
0
1
0
end_DTG
begin_DTG
4
1
46
2
4 3
0 0
2
47
2
4 3
0 1
3
2
1
4 3
3
14
1
4 1
2
0
24
2
3 0
4 0
0
34
2
8 0
4 0
2
0
24
2
3 0
4 0
0
34
2
8 0
4 0
2
0
24
2
3 0
4 0
0
34
2
8 0
4 0
end_DTG
begin_DTG
4
1
50
2
4 5
0 0
2
51
2
4 5
0 1
3
4
1
4 5
3
25
1
4 1
2
0
15
2
3 0
4 2
0
36
2
9 0
4 2
2
0
15
2
3 0
4 2
0
36
2
9 0
4 2
2
0
15
2
3 0
4 2
0
36
2
9 0
4 2
end_DTG
begin_DTG
5
1
48
2
4 4
0 0
2
49
2
4 4
0 1
3
3
1
4 4
3
15
1
4 2
3
24
1
4 0
3
0
14
2
1 0
4 1
0
25
2
2 0
4 1
0
35
2
14 0
4 1
3
0
14
2
1 0
4 1
0
25
2
2 0
4 1
0
35
2
14 0
4 1
3
0
14
2
1 0
4 1
0
25
2
2 0
4 1
0
35
2
14 0
4 1
end_DTG
begin_DTG
2
1
24
1
3 0
3
34
1
8 0
3
0
14
1
1 0
2
25
1
2 0
4
35
1
14 0
2
1
15
1
3 0
5
36
1
9 0
3
0
2
1
1 0
4
26
1
14 0
6
37
1
11 0
4
1
3
1
3 0
3
16
1
8 0
5
27
1
9 0
7
38
1
16 0
3
2
4
1
2 0
4
17
1
14 0
8
39
1
13 0
3
3
5
1
8 0
7
28
1
16 0
9
40
1
10 0
4
4
6
1
14 0
6
18
1
11 0
8
29
1
13 0
10
41
1
15 0
3
5
7
1
9 0
7
19
1
16 0
11
42
1
12 0
3
6
8
1
11 0
10
30
1
15 0
12
43
1
5 0
4
7
9
1
16 0
9
20
1
10 0
11
31
1
12 0
13
44
1
7 0
3
8
10
1
13 0
10
21
1
15 0
14
45
1
6 0
2
9
11
1
10 0
13
32
1
7 0
3
10
12
1
15 0
12
22
1
5 0
14
33
1
6 0
2
11
13
1
12 0
13
23
1
7 0
end_DTG
begin_DTG
4
1
88
2
4 9
0 0
2
89
2
4 9
0 1
3
22
1
4 13
3
43
1
4 9
2
0
11
2
10 0
4 12
0
32
2
7 0
4 12
2
0
11
2
10 0
4 12
0
32
2
7 0
4 12
2
0
11
2
10 0
4 12
0
32
2
7 0
4 12
end_DTG
begin_DTG
4
1
92
2
4 11
0 0
2
93
2
4 11
0 1
3
33
1
4 13
3
45
1
4 11
2
0
13
2
12 0
4 14
0
23
2
7 0
4 14
2
0
13
2
12 0
4 14
0
23
2
7 0
4 14
2
0
13
2
12 0
4 14
0
23
2
7 0
4 14
end_DTG
begin_DTG
5
1
90
2
4 10
0 0
2
91
2
4 10
0 1
3
23
1
4 14
3
32
1
4 12
3
44
1
4 10
3
0
12
2
15 0
4 13
0
22
2
5 0
4 13
0
33
2
6 0
4 13
3
0
12
2
15 0
4 13
0
22
2
5 0
4 13
0
33
2
6 0
4 13
3
0
12
2
15 0
4 13
0
22
2
5 0
4 13
0
33
2
6 0
4 13
end_DTG
begin_DTG
7
1
52
2
4 6
0 0
1
70
2
4 0
0 0
2
53
2
4 6
0 1
2
71
2
4 0
0 1
3
5
1
4 6
3
16
1
4 4
3
34
1
4 0
3
0
2
2
1 0
4 3
0
26
2
14 0
4 3
0
37
2
11 0
4 3
3
0
2
2
1 0
4 3
0
26
2
14 0
4 3
0
37
2
11 0
4 3
3
0
2
2
1 0
4 3
0
26
2
14 0
4 3
0
37
2
11 0
4 3
end_DTG
begin_DTG
7
1
56
2
4 8
0 0
1
74
2
4 2
0 0
2
57
2
4 8
0 1
2
75
2
4 2
0 1
3
7
1
4 8
3
27
1
4 4
3
36
1
4 2
3
0
4
2
2 0
4 5
0
17
2
14 0
4 5
0
39
2
13 0
4 5
3
0
4
2
2 0
4 5
0
17
2
14 0
4 5
0
39
2
13 0
4 5
3
0
4
2
2 0
4 5
0
17
2
14 0
4 5
0
39
2
13 0
4 5
end_DTG
begin_DTG
7
1
64
2
4 12
0 0
1
82
2
4 6
0 0
2
65
2
4 12
0 1
2
83
2
4 6
0 1
3
11
1
4 12
3
20
1
4 10
3
40
1
4 6
3
0
8
2
11 0
4 9
0
30
2
15 0
4 9
0
43
2
5 0
4 9
3
0
8
2
11 0
4 9
0
30
2
15 0
4 9
0
43
2
5 0
4 9
3
0
8
2
11 0
4 9
0
30
2
15 0
4 9
0
43
2
5 0
4 9
end_DTG
begin_DTG
7
1
58
2
4 9
0 0
1
76
2
4 3
0 0
2
59
2
4 9
0 1
2
77
2
4 3
0 1
3
8
1
4 9
3
18
1
4 7
3
37
1
4 3
3
0
5
2
8 0
4 6
0
28
2
16 0
4 6
0
40
2
10 0
4 6
3
0
5
2
8 0
4 6
0
28
2
16 0
4 6
0
40
2
10 0
4 6
3
0
5
2
8 0
4 6
0
28
2
16 0
4 6
0
40
2
10 0
4 6
end_DTG
begin_DTG
7
1
68
2
4 14
0 0
1
86
2
4 8
0 0
2
69
2
4 14
0 1
2
87
2
4 8
0 1
3
13
1
4 14
3
31
1
4 10
3
42
1
4 8
3
0
10
2
13 0
4 11
0
21
2
15 0
4 11
0
45
2
6 0
4 11
3
0
10
2
13 0
4 11
0
21
2
15 0
4 11
0
45
2
6 0
4 11
3
0
10
2
13 0
4 11
0
21
2
15 0
4 11
0
45
2
6 0
4 11
end_DTG
begin_DTG
7
1
62
2
4 11
0 0
1
80
2
4 5
0 0
2
63
2
4 11
0 1
2
81
2
4 5
0 1
3
10
1
4 11
3
29
1
4 7
3
39
1
4 5
3
0
7
2
9 0
4 8
0
19
2
16 0
4 8
0
42
2
12 0
4 8
3
0
7
2
9 0
4 8
0
19
2
16 0
4 8
0
42
2
12 0
4 8
3
0
7
2
9 0
4 8
0
19
2
16 0
4 8
0
42
2
12 0
4 8
end_DTG
begin_DTG
8
1
54
2
4 7
0 0
1
72
2
4 1
0 0
2
55
2
4 7
0 1
2
73
2
4 1
0 1
3
6
1
4 7
3
17
1
4 5
3
26
1
4 3
3
35
1
4 1
4
0
3
2
3 0
4 4
0
16
2
8 0
4 4
0
27
2
9 0
4 4
0
38
2
16 0
4 4
4
0
3
2
3 0
4 4
0
16
2
8 0
4 4
0
27
2
9 0
4 4
0
38
2
16 0
4 4
4
0
3
2
3 0
4 4
0
16
2
8 0
4 4
0
27
2
9 0
4 4
0
38
2
16 0
4 4
end_DTG
begin_DTG
8
1
66
2
4 13
0 0
1
84
2
4 7
0 0
2
67
2
4 13
0 1
2
85
2
4 7
0 1
3
12
1
4 13
3
21
1
4 11
3
30
1
4 9
3
41
1
4 7
4
0
9
2
16 0
4 10
0
20
2
10 0
4 10
0
31
2
12 0
4 10
0
44
2
7 0
4 10
4
0
9
2
16 0
4 10
0
20
2
10 0
4 10
0
31
2
12 0
4 10
0
44
2
7 0
4 10
4
0
9
2
16 0
4 10
0
20
2
10 0
4 10
0
31
2
12 0
4 10
0
44
2
7 0
4 10
end_DTG
begin_DTG
8
1
60
2
4 10
0 0
1
78
2
4 4
0 0
2
61
2
4 10
0 1
2
79
2
4 4
0 1
3
9
1
4 10
3
19
1
4 8
3
28
1
4 6
3
38
1
4 4
4
0
6
2
14 0
4 7
0
18
2
11 0
4 7
0
29
2
13 0
4 7
0
41
2
15 0
4 7
4
0
6
2
14 0
4 7
0
18
2
11 0
4 7
0
29
2
13 0
4 7
0
41
2
15 0
4 7
4
0
6
2
14 0
4 7
0
18
2
11 0
4 7
0
29
2
13 0
4 7
0
41
2
15 0
4 7
end_DTG
begin_CG
15
1 2
3 2
2 2
8 4
14 4
9 4
11 4
16 4
13 4
10 4
15 4
12 4
5 2
7 2
6 2
3
3 1
8 1
4 2
3
3 1
9 1
4 2
4
1 1
2 1
14 1
4 3
15
1 6
3 8
2 6
8 10
14 12
9 10
11 10
16 12
13 10
10 10
15 12
12 10
5 6
7 8
6 6
3
10 1
7 1
4 2
3
12 1
7 1
4 2
4
15 1
5 1
6 1
4 3
4
1 1
14 1
11 1
4 3
4
2 1
14 1
13 1
4 3
4
11 1
15 1
5 1
4 3
4
8 1
16 1
10 1
4 3
4
13 1
15 1
6 1
4 3
4
9 1
16 1
12 1
4 3
5
3 1
8 1
9 1
16 1
4 4
5
16 1
10 1
12 1
7 1
4 4
5
14 1
11 1
13 1
15 1
4 4
end_CG
