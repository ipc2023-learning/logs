begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var9
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var8
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var6
-1
6
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var7
-1
6
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
end_variable
begin_variable
var4
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
12
begin_mutex_group
5
3 0
3 1
3 2
2 0
5 0
end_mutex_group
begin_mutex_group
3
3 0
2 0
5 0
end_mutex_group
begin_mutex_group
5
4 0
4 1
4 2
2 1
5 1
end_mutex_group
begin_mutex_group
3
4 0
2 1
5 1
end_mutex_group
begin_mutex_group
5
8 0
8 1
8 2
2 2
5 2
end_mutex_group
begin_mutex_group
3
8 0
2 2
5 2
end_mutex_group
begin_mutex_group
5
9 0
9 1
9 2
2 3
5 3
end_mutex_group
begin_mutex_group
3
9 0
2 3
5 3
end_mutex_group
begin_mutex_group
5
6 0
6 1
6 2
2 4
5 4
end_mutex_group
begin_mutex_group
3
6 0
2 4
5 4
end_mutex_group
begin_mutex_group
5
7 0
7 1
7 2
2 5
5 5
end_mutex_group
begin_mutex_group
3
7 0
2 5
5 5
end_mutex_group
begin_state
0
1
4
0
0
3
3
0
0
3
end_state
begin_goal
4
6 1
7 2
8 2
9 1
end_goal
64
begin_operator
change_color robot1 black white
0
1
0 1 0 1
0
end_operator
begin_operator
change_color robot1 white black
0
1
0 1 1 0
0
end_operator
begin_operator
change_color robot2 black white
0
1
0 0 0 1
0
end_operator
begin_operator
change_color robot2 white black
0
1
0 0 1 0
0
end_operator
begin_operator
move_down robot1 tile_1_1 tile_0_1
0
3
0 3 0 3
0 8 -1 0
0 2 2 0
0
end_operator
begin_operator
move_down robot1 tile_1_2 tile_0_2
0
3
0 4 0 3
0 9 -1 0
0 2 3 1
0
end_operator
begin_operator
move_down robot1 tile_2_1 tile_1_1
0
3
0 8 0 3
0 6 -1 0
0 2 4 2
0
end_operator
begin_operator
move_down robot1 tile_2_2 tile_1_2
0
3
0 9 0 3
0 7 -1 0
0 2 5 3
0
end_operator
begin_operator
move_down robot2 tile_1_1 tile_0_1
0
3
0 3 0 3
0 8 -1 0
0 5 2 0
0
end_operator
begin_operator
move_down robot2 tile_1_2 tile_0_2
0
3
0 4 0 3
0 9 -1 0
0 5 3 1
0
end_operator
begin_operator
move_down robot2 tile_2_1 tile_1_1
0
3
0 8 0 3
0 6 -1 0
0 5 4 2
0
end_operator
begin_operator
move_down robot2 tile_2_2 tile_1_2
0
3
0 9 0 3
0 7 -1 0
0 5 5 3
0
end_operator
begin_operator
move_left robot1 tile_0_2 tile_0_1
0
3
0 3 0 3
0 4 -1 0
0 2 1 0
0
end_operator
begin_operator
move_left robot1 tile_1_2 tile_1_1
0
3
0 8 0 3
0 9 -1 0
0 2 3 2
0
end_operator
begin_operator
move_left robot1 tile_2_2 tile_2_1
0
3
0 6 0 3
0 7 -1 0
0 2 5 4
0
end_operator
begin_operator
move_left robot2 tile_0_2 tile_0_1
0
3
0 3 0 3
0 4 -1 0
0 5 1 0
0
end_operator
begin_operator
move_left robot2 tile_1_2 tile_1_1
0
3
0 8 0 3
0 9 -1 0
0 5 3 2
0
end_operator
begin_operator
move_left robot2 tile_2_2 tile_2_1
0
3
0 6 0 3
0 7 -1 0
0 5 5 4
0
end_operator
begin_operator
move_right robot1 tile_0_1 tile_0_2
0
3
0 3 -1 0
0 4 0 3
0 2 0 1
0
end_operator
begin_operator
move_right robot1 tile_1_1 tile_1_2
0
3
0 8 -1 0
0 9 0 3
0 2 2 3
0
end_operator
begin_operator
move_right robot1 tile_2_1 tile_2_2
0
3
0 6 -1 0
0 7 0 3
0 2 4 5
0
end_operator
begin_operator
move_right robot2 tile_0_1 tile_0_2
0
3
0 3 -1 0
0 4 0 3
0 5 0 1
0
end_operator
begin_operator
move_right robot2 tile_1_1 tile_1_2
0
3
0 8 -1 0
0 9 0 3
0 5 2 3
0
end_operator
begin_operator
move_right robot2 tile_2_1 tile_2_2
0
3
0 6 -1 0
0 7 0 3
0 5 4 5
0
end_operator
begin_operator
move_up robot1 tile_0_1 tile_1_1
0
3
0 3 -1 0
0 8 0 3
0 2 0 2
0
end_operator
begin_operator
move_up robot1 tile_0_2 tile_1_2
0
3
0 4 -1 0
0 9 0 3
0 2 1 3
0
end_operator
begin_operator
move_up robot1 tile_1_1 tile_2_1
0
3
0 8 -1 0
0 6 0 3
0 2 2 4
0
end_operator
begin_operator
move_up robot1 tile_1_2 tile_2_2
0
3
0 9 -1 0
0 7 0 3
0 2 3 5
0
end_operator
begin_operator
move_up robot2 tile_0_1 tile_1_1
0
3
0 3 -1 0
0 8 0 3
0 5 0 2
0
end_operator
begin_operator
move_up robot2 tile_0_2 tile_1_2
0
3
0 4 -1 0
0 9 0 3
0 5 1 3
0
end_operator
begin_operator
move_up robot2 tile_1_1 tile_2_1
0
3
0 8 -1 0
0 6 0 3
0 5 2 4
0
end_operator
begin_operator
move_up robot2 tile_1_2 tile_2_2
0
3
0 9 -1 0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





switch 2
check 0
check 1
18
check 0
check 0
switch 5
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
34
check 1
35
check 0
check 0
check 0
switch 5
check 0
check 1
21
check 0
check 0
switch 1
check 1
9
check 0
check 0
switch 0
check 0
check 1
42
check 1
43
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
switch 2
check 0
switch 5
check 1
24
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
48
check 1
49
check 0
check 0
check 0
check 1
13
switch 5
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
36
check 1
37
check 0
check 0
switch 5
check 0
switch 1
check 1
28
check 0
check 0
switch 0
check 0
check 1
56
check 1
57
check 0
check 0
check 0
check 1
16
switch 1
check 1
10
check 0
check 0
switch 0
check 0
check 1
44
check 1
45
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
switch 2
check 0
check 0
switch 5
check 1
25
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
50
check 1
51
check 0
check 1
19
check 0
check 0
switch 5
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
38
check 1
39
check 0
switch 5
check 0
check 0
switch 1
check 1
29
check 0
check 0
switch 0
check 0
check 1
58
check 1
59
check 0
check 1
22
check 0
check 0
switch 1
check 1
11
check 0
check 0
switch 0
check 0
check 1
46
check 1
47
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 2
check 0
check 0
check 0
switch 5
check 1
26
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
52
check 1
53
check 0
check 0
check 0
check 1
14
switch 5
check 0
check 0
check 0
switch 1
check 1
30
check 0
check 0
switch 0
check 0
check 1
60
check 1
61
check 0
check 0
check 0
check 1
17
check 0
check 0
check 0
check 0
switch 7
check 0
switch 2
check 0
check 0
check 0
check 0
switch 5
check 1
27
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
54
check 1
55
check 0
check 1
20
check 0
switch 5
check 0
check 0
check 0
check 0
switch 1
check 1
31
check 0
check 0
switch 0
check 0
check 1
62
check 1
63
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
0
check 1
1
switch 0
check 0
check 1
2
check 1
3
check 0
end_SG
begin_DTG
1
1
2
0
1
0
3
0
end_DTG
begin_DTG
1
1
0
0
1
0
1
0
end_DTG
begin_DTG
2
1
18
1
4 0
2
24
1
8 0
2
0
12
1
3 0
3
25
1
9 0
3
0
4
1
3 0
3
19
1
9 0
4
26
1
6 0
3
1
5
1
4 0
2
13
1
8 0
5
27
1
7 0
2
2
6
1
8 0
5
20
1
7 0
2
3
7
1
9 0
4
14
1
6 0
end_DTG
begin_DTG
8
1
32
2
2 2
1 0
1
40
2
5 2
0 0
2
33
2
2 2
1 1
2
41
2
5 2
0 1
3
4
1
2 2
3
8
1
5 2
3
12
1
2 1
3
15
1
5 1
4
0
18
2
4 0
2 0
0
21
2
4 0
5 0
0
24
2
8 0
2 0
0
28
2
8 0
5 0
4
0
18
2
4 0
2 0
0
21
2
4 0
5 0
0
24
2
8 0
2 0
0
28
2
8 0
5 0
4
0
18
2
4 0
2 0
0
21
2
4 0
5 0
0
24
2
8 0
2 0
0
28
2
8 0
5 0
end_DTG
begin_DTG
8
1
34
2
2 3
1 0
1
42
2
5 3
0 0
2
35
2
2 3
1 1
2
43
2
5 3
0 1
3
5
1
2 3
3
9
1
5 3
3
18
1
2 0
3
21
1
5 0
4
0
12
2
3 0
2 1
0
15
2
3 0
5 1
0
25
2
9 0
2 1
0
29
2
9 0
5 1
4
0
12
2
3 0
2 1
0
15
2
3 0
5 1
0
25
2
9 0
2 1
0
29
2
9 0
5 1
4
0
12
2
3 0
2 1
0
15
2
3 0
5 1
0
25
2
9 0
2 1
0
29
2
9 0
5 1
end_DTG
begin_DTG
2
1
21
1
4 0
2
28
1
8 0
2
0
15
1
3 0
3
29
1
9 0
3
0
8
1
3 0
3
22
1
9 0
4
30
1
6 0
3
1
9
1
4 0
2
16
1
8 0
5
31
1
7 0
2
2
10
1
8 0
5
23
1
7 0
2
3
11
1
9 0
4
17
1
6 0
end_DTG
begin_DTG
8
1
52
2
2 2
1 0
1
60
2
5 2
0 0
2
53
2
2 2
1 1
2
61
2
5 2
0 1
3
14
1
2 5
3
17
1
5 5
3
26
1
2 2
3
30
1
5 2
4
0
6
2
8 0
2 4
0
10
2
8 0
5 4
0
20
2
7 0
2 4
0
23
2
7 0
5 4
4
0
6
2
8 0
2 4
0
10
2
8 0
5 4
0
20
2
7 0
2 4
0
23
2
7 0
5 4
4
0
6
2
8 0
2 4
0
10
2
8 0
5 4
0
20
2
7 0
2 4
0
23
2
7 0
5 4
end_DTG
begin_DTG
8
1
54
2
2 3
1 0
1
62
2
5 3
0 0
2
55
2
2 3
1 1
2
63
2
5 3
0 1
3
20
1
2 4
3
23
1
5 4
3
27
1
2 3
3
31
1
5 3
4
0
7
2
9 0
2 5
0
11
2
9 0
5 5
0
14
2
6 0
2 5
0
17
2
6 0
5 5
4
0
7
2
9 0
2 5
0
11
2
9 0
5 5
0
14
2
6 0
2 5
0
17
2
6 0
5 5
4
0
7
2
9 0
2 5
0
11
2
9 0
5 5
0
14
2
6 0
2 5
0
17
2
6 0
5 5
end_DTG
begin_DTG
14
1
36
2
2 4
1 0
1
44
2
5 4
0 0
1
48
2
2 0
1 0
1
56
2
5 0
0 0
2
37
2
2 4
1 1
2
45
2
5 4
0 1
2
49
2
2 0
1 1
2
57
2
5 0
0 1
3
6
1
2 4
3
10
1
5 4
3
13
1
2 3
3
16
1
5 3
3
24
1
2 0
3
28
1
5 0
6
0
4
2
3 0
2 2
0
8
2
3 0
5 2
0
19
2
9 0
2 2
0
22
2
9 0
5 2
0
26
2
6 0
2 2
0
30
2
6 0
5 2
6
0
4
2
3 0
2 2
0
8
2
3 0
5 2
0
19
2
9 0
2 2
0
22
2
9 0
5 2
0
26
2
6 0
2 2
0
30
2
6 0
5 2
6
0
4
2
3 0
2 2
0
8
2
3 0
5 2
0
19
2
9 0
2 2
0
22
2
9 0
5 2
0
26
2
6 0
2 2
0
30
2
6 0
5 2
end_DTG
begin_DTG
14
1
38
2
2 5
1 0
1
46
2
5 5
0 0
1
50
2
2 1
1 0
1
58
2
5 1
0 0
2
39
2
2 5
1 1
2
47
2
5 5
0 1
2
51
2
2 1
1 1
2
59
2
5 1
0 1
3
7
1
2 5
3
11
1
5 5
3
19
1
2 2
3
22
1
5 2
3
25
1
2 1
3
29
1
5 1
6
0
5
2
4 0
2 3
0
9
2
4 0
5 3
0
13
2
8 0
2 3
0
16
2
8 0
5 3
0
27
2
7 0
2 3
0
31
2
7 0
5 3
6
0
5
2
4 0
2 3
0
9
2
4 0
5 3
0
13
2
8 0
2 3
0
16
2
8 0
5 3
0
27
2
7 0
2 3
0
31
2
7 0
5 3
6
0
5
2
4 0
2 3
0
9
2
4 0
5 3
0
13
2
8 0
2 3
0
16
2
8 0
5 3
0
27
2
7 0
2 3
0
31
2
7 0
5 3
end_DTG
begin_CG
6
3 2
4 2
8 4
9 4
6 2
7 2
6
3 2
4 2
8 4
9 4
6 2
7 2
6
3 6
4 6
8 10
9 10
6 6
7 6
4
4 2
8 2
2 2
5 2
4
3 2
9 2
2 2
5 2
6
3 6
4 6
8 10
9 10
6 6
7 6
4
8 2
7 2
2 2
5 2
4
9 2
6 2
2 2
5 2
5
3 2
9 2
6 2
2 3
5 3
5
4 2
8 2
7 2
2 3
5 3
end_CG
