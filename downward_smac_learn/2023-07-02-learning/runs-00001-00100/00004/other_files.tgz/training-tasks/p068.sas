begin_version
3
end_version
begin_metric
0
end_metric
39
begin_variable
var38
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var37
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_0_7)
Atom painted(tile_0_7, black)
Atom painted(tile_0_7, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var35
-1
35
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_0_7)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_1_7)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_2_7)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_3_7)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_4_5)
Atom robot-at(robot1, tile_4_6)
Atom robot-at(robot1, tile_4_7)
end_variable
begin_variable
var36
-1
35
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_0_5)
Atom robot-at(robot2, tile_0_6)
Atom robot-at(robot2, tile_0_7)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_1_5)
Atom robot-at(robot2, tile_1_6)
Atom robot-at(robot2, tile_1_7)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_2_5)
Atom robot-at(robot2, tile_2_6)
Atom robot-at(robot2, tile_2_7)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_3_5)
Atom robot-at(robot2, tile_3_6)
Atom robot-at(robot2, tile_3_7)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_4_4)
Atom robot-at(robot2, tile_4_5)
Atom robot-at(robot2, tile_4_6)
Atom robot-at(robot2, tile_4_7)
end_variable
begin_variable
var28
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var34
-1
4
Atom clear(tile_4_7)
Atom painted(tile_4_7, black)
Atom painted(tile_4_7, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_1_7)
Atom painted(tile_1_7, black)
Atom painted(tile_1_7, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_3_7)
Atom painted(tile_3_7, black)
Atom painted(tile_3_7, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_2_7)
Atom painted(tile_2_7, black)
Atom painted(tile_2_7, white)
<none of those>
end_variable
begin_variable
var33
-1
4
Atom clear(tile_4_6)
Atom painted(tile_4_6, black)
Atom painted(tile_4_6, white)
<none of those>
end_variable
begin_variable
var30
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var32
-1
4
Atom clear(tile_4_5)
Atom painted(tile_4_5, black)
Atom painted(tile_4_5, white




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





2
325
2
10 23
0 1
2
367
2
9 9
1 1
2
423
2
10 9
0 1
3
20
1
9 23
3
48
1
10 23
3
74
1
9 17
3
104
1
10 17
3
133
1
9 15
3
163
1
10 15
3
189
1
9 9
3
217
1
10 9
8
0
13
2
30 0
9 16
0
41
2
30 0
10 16
0
73
2
27 0
9 16
0
103
2
27 0
10 16
0
134
2
38 0
9 16
0
164
2
38 0
10 16
0
196
2
33 0
9 16
0
224
2
33 0
10 16
8
0
13
2
30 0
9 16
0
41
2
30 0
10 16
0
73
2
27 0
9 16
0
103
2
27 0
10 16
0
134
2
38 0
9 16
0
164
2
38 0
10 16
0
196
2
33 0
9 16
0
224
2
33 0
10 16
8
0
13
2
30 0
9 16
0
41
2
30 0
10 16
0
73
2
27 0
9 16
0
103
2
27 0
10 16
0
134
2
38 0
9 16
0
164
2
38 0
10 16
0
196
2
33 0
9 16
0
224
2
33 0
10 16
end_DTG
begin_DTG
16
1
286
2
9 32
1 0
1
342
2
10 32
0 0
1
384
2
9 18
1 0
1
440
2
10 18
0 0
2
287
2
9 32
1 1
2
343
2
10 32
0 1
2
385
2
9 18
1 1
2
441
2
10 18
0 1
3
29
1
9 32
3
57
1
10 32
3
82
1
9 26
3
112
1
10 26
3
141
1
9 24
3
171
1
10 24
3
198
1
9 18
3
226
1
10 18
8
0
22
2
36 0
9 25
0
50
2
36 0
10 25
0
81
2
37 0
9 25
0
111
2
37 0
10 25
0
142
2
28 0
9 25
0
172
2
28 0
10 25
0
205
2
22 0
9 25
0
233
2
22 0
10 25
8
0
22
2
36 0
9 25
0
50
2
36 0
10 25
0
81
2
37 0
9 25
0
111
2
37 0
10 25
0
142
2
28 0
9 25
0
172
2
28 0
10 25
0
205
2
22 0
9 25
0
233
2
22 0
10 25
8
0
22
2
36 0
9 25
0
50
2
36 0
10 25
0
81
2
37 0
9 25
0
111
2
37 0
10 25
0
142
2
28 0
9 25
0
172
2
28 0
10 25
0
205
2
22 0
9 25
0
233
2
22 0
10 25
end_DTG
begin_DTG
16
1
272
2
9 25
1 0
1
328
2
10 25
0 0
1
370
2
9 11
1 0
1
426
2
10 11
0 0
2
273
2
9 25
1 1
2
329
2
10 25
0 1
2
371
2
9 11
1 1
2
427
2
10 11
0 1
3
22
1
9 25
3
50
1
10 25
3
76
1
9 19
3
106
1
10 19
3
135
1
9 17
3
165
1
10 17
3
191
1
9 11
3
219
1
10 11
8
0
15
2
31 0
9 18
0
43
2
31 0
10 18
0
75
2
38 0
9 18
0
105
2
38 0
10 18
0
136
2
29 0
9 18
0
166
2
29 0
10 18
0
198
2
35 0
9 18
0
226
2
35 0
10 18
8
0
15
2
31 0
9 18
0
43
2
31 0
10 18
0
75
2
38 0
9 18
0
105
2
38 0
10 18
0
136
2
29 0
9 18
0
166
2
29 0
10 18
0
198
2
35 0
9 18
0
226
2
35 0
10 18
8
0
15
2
31 0
9 18
0
43
2
31 0
10 18
0
75
2
38 0
9 18
0
105
2
38 0
10 18
0
136
2
29 0
9 18
0
166
2
29 0
10 18
0
198
2
35 0
9 18
0
226
2
35 0
10 18
end_DTG
begin_DTG
16
1
284
2
9 31
1 0
1
340
2
10 31
0 0
1
382
2
9 17
1 0
1
438
2
10 17
0 0
2
285
2
9 31
1 1
2
341
2
10 31
0 1
2
383
2
9 17
1 1
2
439
2
10 17
0 1
3
28
1
9 31
3
56
1
10 31
3
81
1
9 25
3
111
1
10 25
3
140
1
9 23
3
170
1
10 23
3
197
1
9 17
3
225
1
10 17
8
0
21
2
38 0
9 24
0
49
2
38 0
10 24
0
80
2
33 0
9 24
0
110
2
33 0
10 24
0
141
2
35 0
9 24
0
171
2
35 0
10 24
0
204
2
23 0
9 24
0
232
2
23 0
10 24
8
0
21
2
38 0
9 24
0
49
2
38 0
10 24
0
80
2
33 0
9 24
0
110
2
33 0
10 24
0
141
2
35 0
9 24
0
171
2
35 0
10 24
0
204
2
23 0
9 24
0
232
2
23 0
10 24
8
0
21
2
38 0
9 24
0
49
2
38 0
10 24
0
80
2
33 0
9 24
0
110
2
33 0
10 24
0
141
2
35 0
9 24
0
171
2
35 0
10 24
0
204
2
23 0
9 24
0
232
2
23 0
10 24
end_DTG
begin_DTG
16
1
270
2
9 24
1 0
1
326
2
10 24
0 0
1
368
2
9 10
1 0
1
424
2
10 10
0 0
2
271
2
9 24
1 1
2
327
2
10 24
0 1
2
369
2
9 10
1 1
2
425
2
10 10
0 1
3
21
1
9 24
3
49
1
10 24
3
75
1
9 18
3
105
1
10 18
3
134
1
9 16
3
164
1
10 16
3
190
1
9 10
3
218
1
10 10
8
0
14
2
32 0
9 17
0
42
2
32 0
10 17
0
74
2
34 0
9 17
0
104
2
34 0
10 17
0
135
2
36 0
9 17
0
165
2
36 0
10 17
0
197
2
37 0
9 17
0
225
2
37 0
10 17
8
0
14
2
32 0
9 17
0
42
2
32 0
10 17
0
74
2
34 0
9 17
0
104
2
34 0
10 17
0
135
2
36 0
9 17
0
165
2
36 0
10 17
0
197
2
37 0
9 17
0
225
2
37 0
10 17
8
0
14
2
32 0
9 17
0
42
2
32 0
10 17
0
74
2
34 0
9 17
0
104
2
34 0
10 17
0
135
2
36 0
9 17
0
165
2
36 0
10 17
0
197
2
37 0
9 17
0
225
2
37 0
10 17
end_DTG
begin_CG
35
2 2
4 2
6 2
8 2
7 2
5 2
3 2
13 4
24 4
30 4
32 4
31 4
25 4
14 4
16 4
27 4
34 4
38 4
36 4
29 4
19 4
15 4
26 4
33 4
37 4
35 4
28 4
18 4
11 2
17 2
21 2
23 2
22 2
20 2
12 2
35
2 2
4 2
6 2
8 2
7 2
5 2
3 2
13 4
24 4
30 4
32 4
31 4
25 4
14 4
16 4
27 4
34 4
38 4
36 4
29 4
19 4
15 4
26 4
33 4
37 4
35 4
28 4
18 4
11 2
17 2
21 2
23 2
22 2
20 2
12 2
4
4 2
13 2
9 2
10 2
4
5 2
14 2
9 2
10 2
5
2 2
6 2
24 2
9 3
10 3
5
7 2
3 2
25 2
9 3
10 3
5
4 2
8 2
30 2
9 3
10 3
5
8 2
5 2
31 2
9 3
10 3
5
6 2
7 2
32 2
9 3
10 3
35
2 6
4 8
6 8
8 8
7 8
5 8
3 6
13 10
24 12
30 12
32 12
31 12
25 12
14 10
16 10
27 12
34 12
38 12
36 12
29 12
19 10
15 10
26 12
33 12
37 12
35 12
28 12
18 10
11 6
17 8
21 8
23 8
22 8
20 8
12 6
35
2 6
4 8
6 8
8 8
7 8
5 8
3 6
13 10
24 12
30 12
32 12
31 12
25 12
14 10
16 10
27 12
34 12
38 12
36 12
29 12
19 10
15 10
26 12
33 12
37 12
35 12
28 12
18 10
11 6
17 8
21 8
23 8
22 8
20 8
12 6
4
15 2
17 2
9 2
10 2
4
18 2
20 2
9 2
10 2
5
2 2
24 2
16 2
9 3
10 3
5
3 2
25 2
19 2
9 3
10 3
5
16 2
26 2
11 2
9 3
10 3
5
13 2
27 2
15 2
9 3
10 3
5
26 2
11 2
21 2
9 3
10 3
5
19 2
28 2
12 2
9 3
10 3
5
14 2
29 2
18 2
9 3
10 3
5
28 2
22 2
12 2
9 3
10 3
5
33 2
17 2
23 2
9 3
10 3
5
35 2
23 2
20 2
9 3
10 3
5
37 2
21 2
22 2
9 3
10 3
6
4 2
13 2
30 2
27 2
9 4
10 4
6
5 2
31 2
14 2
29 2
9 4
10 4
6
27 2
15 2
33 2
17 2
9 4
10 4
6
24 2
16 2
34 2
26 2
9 4
10 4
6
29 2
35 2
18 2
20 2
9 4
10 4
6
25 2
36 2
19 2
28 2
9 4
10 4
6
6 2
24 2
32 2
34 2
9 4
10 4
6
7 2
32 2
25 2
36 2
9 4
10 4
6
8 2
30 2
31 2
38 2
9 4
10 4
6
34 2
26 2
37 2
21 2
9 4
10 4
6
30 2
27 2
38 2
33 2
9 4
10 4
6
36 2
37 2
28 2
22 2
9 4
10 4
6
31 2
38 2
29 2
35 2
9 4
10 4
6
38 2
33 2
35 2
23 2
9 4
10 4
6
32 2
34 2
36 2
37 2
9 4
10 4
end_CG
