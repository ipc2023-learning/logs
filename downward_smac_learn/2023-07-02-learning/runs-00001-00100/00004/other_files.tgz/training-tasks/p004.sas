begin_version
3
end_version
begin_metric
0
end_metric
4
begin_variable
var3
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
Atom robot-at(robot1, tile_0_1)
end_variable
begin_variable
var2
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
Atom robot-at(robot1, tile_2_1)
end_variable
begin_variable
var1
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
Atom robot-at(robot1, tile_1_1)
end_variable
1
begin_mutex_group
3
1 3
3 3
2 3
end_mutex_group
begin_state
0
0
0
3
end_state
begin_goal
2
2 1
3 2
end_goal
14
begin_operator
change_color robot1 black white
0
1
0 0 0 1
0
end_operator
begin_operator
change_color robot1 white black
0
1
0 0 1 0
0
end_operator
begin_operator
move_down robot1 tile_1_1 tile_0_1
0
2
0 1 0 3
0 3 3 0
0
end_operator
begin_operator
move_down robot1 tile_2_1 tile_1_1
0
2
0 3 0 3
0 2 3 0
0
end_operator
begin_operator
move_up robot1 tile_0_1 tile_1_1
0
2
0 1 3 0
0 3 0 3
0
end_operator
begin_operator
move_up robot1 tile_1_1 tile_2_1
0
2
0 3 3 0
0 2 0 3
0
end_operator
begin_operator
paint_down robot1 tile_0_1 tile_1_1 black
2
3 3
0 0
1
0 1 0 1
0
end_operator
begin_operator
paint_down robot1 tile_0_1 tile_1_1 white
2
3 3
0 1
1
0 1 0 2
0
end_operator
begin_operator
paint_down robot1 tile_1_1 tile_2_1 black
2
2 3
0 0
1
0 3 0 1
0
end_operator
begin_operator
paint_down robot1 tile_1_1 tile_2_1 white
2
2 3
0 1
1
0 3 0 2
0
end_operator
begin_operator
paint_up robot1 tile_1_1 tile_0_1 black
2
1 3
0 0
1
0 3 0 1
0
end_operator
begin_operator
paint_up robot1 tile_1_1 tile_0_1 white
2
1 3
0 1
1
0 3 0 2
0
end_operator
begin_operator
paint_up robot1 tile_2_1 tile_1_1 black
2
3 3
0 0
1
0 2 0 1
0
end_operator
begin_operator
paint_up robot1 tile_2_1 tile_1_1 white
2
3 3
0 1
1
0 2 0 2
0
end_operator
0
begin_SG
switch 1
check 0
switch 3
check 0
check 0
check 0
check 0
switch 2
check 1
2
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
6
check 1
7
check 0
check 0
check 0
check 0
switch 3
check 0
switch 2
check 1
4
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
10
check 1
11
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 2
check 0
check 0
check 0
check 0
switch 0
check 1
3
check 1
8
check 1
9
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 1
5
check 1
12
check 1
13
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 1
1
check 0
end_SG
begin_DTG
1
1
0
0
1
0
1
0
end_DTG
begin_DTG
3
1
6
2
3 3
0 0
2
7
2
3 3
0 1
3
2
1
3 3
0
0
1
0
4
1
3 0
end_DTG
begin_DTG
3
1
12
2
3 3
0 0
2
13
2
3 3
0 1
3
5
1
3 3
0
0
1
0
3
1
3 0
end_DTG
begin_DTG
6
1
8
2
2 3
0 0
1
10
2
1 3
0 0
2
9
2
2 3
0 1
2
11
2
1 3
0 1
3
3
1
2 3
3
4
1
1 3
0
0
2
0
2
1
1 0
0
5
1
2 0
end_DTG
begin_CG
3
1 2
3 4
2 2
1
3 4
1
3 4
2
1 4
2 4
end_CG
