begin_version
3
end_version
begin_metric
0
end_metric
34
begin_variable
var33
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var32
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var30
-1
30
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_4_5)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_5_4)
Atom robot-at(robot1, tile_5_5)
end_variable
begin_variable
var31
-1
30
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_0_5)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_1_5)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_2_5)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_3_5)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_4_4)
Atom robot-at(robot2, tile_4_5)
Atom robot-at(robot2, tile_5_1)
Atom robot-at(robot2, tile_5_2)
Atom robot-at(robot2, tile_5_3)
Atom robot-at(robot2, tile_5_4)
Atom robot-at(robot2, tile_5_5)
end_variable
begin_variable
var25
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_5_5)
Atom painted(tile_5_5, black)
Atom painted(tile_5_5, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_5)
Atom painted(tile_1_5, black)
Atom painted(tile_1_5, white)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_5_2)
Atom painted(tile_5_2, black)
Atom painted(tile_5_2, white)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom clear(tile_4_5)
Atom painted(tile_4_5, black)
Atom painted(tile_4_5, white)
<none of those>
end_variable
begin_variable
var28
-1
4
Atom clear(tile_5_4)
Atom painted(tile_5_4, black)
Atom painted(tile_5_4, white)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(tile_5_3)
Atom painted(tile_5_3, black)
Atom painted(tile_5_3, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_2_5)
Atom painted(tile_2_5, black)
Atom painted(tile_2_5, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_3_5)
Atom painted(tile_3_5, black)
Atom painted(tile_3_5, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var2




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





8 11
8
0
10
2
22 0
7 11
0
35
2
22 0
8 11
0
62
2
18 0
7 11
0
86
2
18 0
8 11
0
111
2
31 0
7 11
0
135
2
31 0
8 11
0
161
2
29 0
7 11
0
186
2
29 0
8 11
8
0
10
2
22 0
7 11
0
35
2
22 0
8 11
0
62
2
18 0
7 11
0
86
2
18 0
8 11
0
111
2
31 0
7 11
0
135
2
31 0
8 11
0
161
2
29 0
7 11
0
186
2
29 0
8 11
end_DTG
begin_DTG
16
1
232
2
7 21
1 0
1
282
2
8 21
0 0
1
322
2
7 11
1 0
1
372
2
8 11
0 0
2
233
2
7 21
1 1
2
283
2
8 21
0 1
2
323
2
7 11
1 1
2
373
2
8 11
0 1
3
20
1
7 21
3
45
1
8 21
3
67
1
7 17
3
91
1
8 17
3
114
1
7 15
3
138
1
8 15
3
161
1
7 11
3
186
1
8 11
8
0
15
2
28 0
7 16
0
40
2
28 0
8 16
0
66
2
19 0
7 16
0
90
2
19 0
8 16
0
115
2
33 0
7 16
0
139
2
33 0
8 16
0
166
2
25 0
7 16
0
191
2
25 0
8 16
8
0
15
2
28 0
7 16
0
40
2
28 0
8 16
0
66
2
19 0
7 16
0
90
2
19 0
8 16
0
115
2
33 0
7 16
0
139
2
33 0
8 16
0
166
2
25 0
7 16
0
191
2
25 0
8 16
8
0
15
2
28 0
7 16
0
40
2
28 0
8 16
0
66
2
19 0
7 16
0
90
2
19 0
8 16
0
115
2
33 0
7 16
0
139
2
33 0
8 16
0
166
2
25 0
7 16
0
191
2
25 0
8 16
end_DTG
begin_DTG
16
1
226
2
7 18
1 0
1
276
2
8 18
0 0
1
316
2
7 8
1 0
1
366
2
8 8
0 0
2
227
2
7 18
1 1
2
277
2
8 18
0 1
2
317
2
7 8
1 1
2
367
2
8 8
0 1
3
17
1
7 18
3
42
1
8 18
3
65
1
7 14
3
89
1
8 14
3
112
1
7 12
3
136
1
8 12
3
158
1
7 8
3
183
1
8 8
8
0
12
2
23 0
7 13
0
37
2
23 0
8 13
0
64
2
31 0
7 13
0
88
2
31 0
8 13
0
113
2
20 0
7 13
0
137
2
20 0
8 13
0
163
2
32 0
7 13
0
188
2
32 0
8 13
8
0
12
2
23 0
7 13
0
37
2
23 0
8 13
0
64
2
31 0
7 13
0
88
2
31 0
8 13
0
113
2
20 0
7 13
0
137
2
20 0
8 13
0
163
2
32 0
7 13
0
188
2
32 0
8 13
8
0
12
2
23 0
7 13
0
37
2
23 0
8 13
0
64
2
31 0
7 13
0
88
2
31 0
8 13
0
113
2
20 0
7 13
0
137
2
20 0
8 13
0
163
2
32 0
7 13
0
188
2
32 0
8 13
end_DTG
begin_DTG
16
1
224
2
7 17
1 0
1
274
2
8 17
0 0
1
314
2
7 7
1 0
1
364
2
8 7
0 0
2
225
2
7 17
1 1
2
275
2
8 17
0 1
2
315
2
7 7
1 1
2
365
2
8 7
0 1
3
16
1
7 17
3
41
1
8 17
3
64
1
7 13
3
88
1
8 13
3
111
1
7 11
3
135
1
8 11
3
157
1
7 7
3
182
1
8 7
8
0
11
2
24 0
7 12
0
36
2
24 0
8 12
0
63
2
28 0
7 12
0
87
2
28 0
8 12
0
112
2
30 0
7 12
0
136
2
30 0
8 12
0
162
2
33 0
7 12
0
187
2
33 0
8 12
8
0
11
2
24 0
7 12
0
36
2
24 0
8 12
0
63
2
28 0
7 12
0
87
2
28 0
8 12
0
112
2
30 0
7 12
0
136
2
30 0
8 12
0
162
2
33 0
7 12
0
187
2
33 0
8 12
8
0
11
2
24 0
7 12
0
36
2
24 0
8 12
0
63
2
28 0
7 12
0
87
2
28 0
8 12
0
112
2
30 0
7 12
0
136
2
30 0
8 12
0
162
2
33 0
7 12
0
187
2
33 0
8 12
end_DTG
begin_DTG
16
1
236
2
7 23
1 0
1
286
2
8 23
0 0
1
326
2
7 13
1 0
1
376
2
8 13
0 0
2
237
2
7 23
1 1
2
287
2
8 23
0 1
2
327
2
7 13
1 1
2
377
2
8 13
0 1
3
22
1
7 23
3
47
1
8 23
3
69
1
7 19
3
93
1
8 19
3
116
1
7 17
3
140
1
8 17
3
163
1
7 13
3
188
1
8 13
8
0
17
2
30 0
7 18
0
42
2
30 0
8 18
0
68
2
33 0
7 18
0
92
2
33 0
8 18
0
117
2
21 0
7 18
0
141
2
21 0
8 18
0
168
2
26 0
7 18
0
193
2
26 0
8 18
8
0
17
2
30 0
7 18
0
42
2
30 0
8 18
0
68
2
33 0
7 18
0
92
2
33 0
8 18
0
117
2
21 0
7 18
0
141
2
21 0
8 18
0
168
2
26 0
7 18
0
193
2
26 0
8 18
8
0
17
2
30 0
7 18
0
42
2
30 0
8 18
0
68
2
33 0
7 18
0
92
2
33 0
8 18
0
117
2
21 0
7 18
0
141
2
21 0
8 18
0
168
2
26 0
7 18
0
193
2
26 0
8 18
end_DTG
begin_DTG
16
1
234
2
7 22
1 0
1
284
2
8 22
0 0
1
324
2
7 12
1 0
1
374
2
8 12
0 0
2
235
2
7 22
1 1
2
285
2
8 22
0 1
2
325
2
7 12
1 1
2
375
2
8 12
0 1
3
21
1
7 22
3
46
1
8 22
3
68
1
7 18
3
92
1
8 18
3
115
1
7 16
3
139
1
8 16
3
162
1
7 12
3
187
1
8 12
8
0
16
2
31 0
7 17
0
41
2
31 0
8 17
0
67
2
29 0
7 17
0
91
2
29 0
8 17
0
116
2
32 0
7 17
0
140
2
32 0
8 17
0
167
2
27 0
7 17
0
192
2
27 0
8 17
8
0
16
2
31 0
7 17
0
41
2
31 0
8 17
0
67
2
29 0
7 17
0
91
2
29 0
8 17
0
116
2
32 0
7 17
0
140
2
32 0
8 17
0
167
2
27 0
7 17
0
192
2
27 0
8 17
8
0
16
2
31 0
7 17
0
41
2
31 0
8 17
0
67
2
29 0
7 17
0
91
2
29 0
8 17
0
116
2
32 0
7 17
0
140
2
32 0
8 17
0
167
2
27 0
7 17
0
192
2
27 0
8 17
end_DTG
begin_CG
30
2 2
4 2
6 2
5 2
3 2
11 4
22 4
24 4
23 4
12 4
18 4
28 4
31 4
30 4
20 4
19 4
29 4
33 4
32 4
21 4
13 4
25 4
27 4
26 4
15 4
9 2
14 2
17 2
16 2
10 2
30
2 2
4 2
6 2
5 2
3 2
11 4
22 4
24 4
23 4
12 4
18 4
28 4
31 4
30 4
20 4
19 4
29 4
33 4
32 4
21 4
13 4
25 4
27 4
26 4
15 4
9 2
14 2
17 2
16 2
10 2
4
4 2
11 2
7 2
8 2
4
5 2
12 2
7 2
8 2
5
2 2
6 2
22 2
7 3
8 3
5
6 2
3 2
23 2
7 3
8 3
5
4 2
5 2
24 2
7 3
8 3
30
2 6
4 8
6 8
5 8
3 6
11 10
22 12
24 12
23 12
12 10
18 10
28 12
31 12
30 12
20 10
19 10
29 12
33 12
32 12
21 10
13 10
25 12
27 12
26 12
15 10
9 6
14 8
17 8
16 8
10 6
30
2 6
4 8
6 8
5 8
3 6
11 10
22 12
24 12
23 12
12 10
18 10
28 12
31 12
30 12
20 10
19 10
29 12
33 12
32 12
21 10
13 10
25 12
27 12
26 12
15 10
9 6
14 8
17 8
16 8
10 6
4
13 2
14 2
7 2
8 2
4
15 2
16 2
7 2
8 2
5
2 2
22 2
18 2
7 3
8 3
5
3 2
23 2
20 2
7 3
8 3
5
19 2
25 2
9 2
7 3
8 3
5
25 2
9 2
17 2
7 3
8 3
5
21 2
26 2
10 2
7 3
8 3
5
26 2
17 2
10 2
7 3
8 3
5
27 2
14 2
16 2
7 3
8 3
5
11 2
28 2
19 2
7 3
8 3
5
18 2
29 2
13 2
7 3
8 3
5
12 2
30 2
21 2
7 3
8 3
5
20 2
32 2
15 2
7 3
8 3
6
4 2
11 2
24 2
28 2
7 4
8 4
6
5 2
24 2
12 2
30 2
7 4
8 4
6
6 2
22 2
23 2
31 2
7 4
8 4
6
29 2
13 2
27 2
14 2
7 4
8 4
6
32 2
27 2
15 2
16 2
7 4
8 4
6
33 2
25 2
26 2
17 2
7 4
8 4
6
22 2
18 2
31 2
29 2
7 4
8 4
6
28 2
19 2
33 2
25 2
7 4
8 4
6
23 2
31 2
20 2
32 2
7 4
8 4
6
24 2
28 2
30 2
33 2
7 4
8 4
6
30 2
33 2
21 2
26 2
7 4
8 4
6
31 2
29 2
32 2
27 2
7 4
8 4
end_CG
