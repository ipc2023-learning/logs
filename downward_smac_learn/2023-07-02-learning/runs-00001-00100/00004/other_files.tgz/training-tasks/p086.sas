begin_version
3
end_version
begin_metric
0
end_metric
46
begin_variable
var45
-1
2
Atom robot-has(robot3, black)
Atom robot-has(robot3, white)
end_variable
begin_variable
var44
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var43
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_10)
Atom painted(tile_0_10, black)
Atom painted(tile_0_10, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_0_9)
Atom painted(tile_0_9, black)
Atom painted(tile_0_9, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_0_8)
Atom painted(tile_0_8, black)
Atom painted(tile_0_8, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_0_7)
Atom painted(tile_0_7, black)
Atom painted(tile_0_7, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var40
-1
40
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_10)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_0_7)
Atom robot-at(robot1, tile_0_8)
Atom robot-at(robot1, tile_0_9)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_10)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_1_7)
Atom robot-at(robot1, tile_1_8)
Atom robot-at(robot1, tile_1_9)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_10)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_2_7)
Atom robot-at(robot1, tile_2_8)
Atom robot-at(robot1, tile_2_9)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_10)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_3_7)
Atom robot-at(robot1, tile_3_8)
Atom robot-at(robot1, tile_3_9)
end_variable
begin_variable
var41
-1
40
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_10)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_0_5)
Atom robot-at(robot2, tile_0_6)
Atom robot-at(robot2, tile_0_7)
Atom robot-at(robot2, tile_0_8)
Atom robot-at(robot2, tile_0_9)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_10)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_1_5)
Atom robot-at(robot2, tile_1_6)
Atom robot-at(robot2, tile_1_7)
Atom robot-at(robot2, tile_1_8)
Atom robot-at(robot2, tile_1_9)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_10)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_2_5)
Atom robot-at(robot2, tile_2_6)
Atom robot-at(robot2, tile_2_7)
Atom robot-at(robot2, tile_2_8)
Atom robot-at(robot2, tile_2_9)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_10)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_3_5)
Atom robot-at(robot2, tile_3_6)
Atom robot-at(robot2, tile_3_7)
Atom robot-at(robot2, tile_3_8)
Atom robot-at(robot2, tile_3_9)
end_variable
begin_variable
var42
-1
40
Atom robot-at(robot3, tile_0_1)
Atom robot-at(robot3, tile_0_10)
Atom robot-at(robot3, tile_0_2)
Atom robot-at(robot3, tile_0_3)
Atom robot-at(robot3, tile_0_4)
Atom robot-at(robot3, tile_0_5)
Atom robot-at(robot3, tile_0_6)
Atom robot-at(robot3, tile_0_7)
Atom robot-at(robot3, tile_0_8)
Atom robot-at(robot3, tile_0_9)
Atom robot-at(robot3, tile_1_1)
Atom robot-at(robot3, tile_1_10)
Atom robot-at(robot3, tile_1_2)
Atom robot-at(robot3, tile_1_3)
Atom robot-at(robot3, tile_1_4)
Atom robot-at(robot3, tile_1_5)
Atom robot-at(robot3, tile_1_6)
Atom robot-at(robot3, tile_1_7)
Atom robot-at(robot3, tile_1_8)
Atom robot-at(robot3, tile_1_9)
Atom robot-at(robot3, tile_2_1)
Atom robot-at(robot3, tile_2_10)
Atom robot-at(robot3, tile_2_2)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




14 16
0
182
2
42 0
15 16
0
218
2
40 0
13 16
0
254
2
40 0
14 16
0
290
2
40 0
15 16
0
328
2
45 0
13 16
0
358
2
45 0
14 16
0
388
2
45 0
15 16
12
0
12
2
12 0
13 16
0
42
2
12 0
14 16
0
72
2
12 0
15 16
0
110
2
42 0
13 16
0
146
2
42 0
14 16
0
182
2
42 0
15 16
0
218
2
40 0
13 16
0
254
2
40 0
14 16
0
290
2
40 0
15 16
0
328
2
45 0
13 16
0
358
2
45 0
14 16
0
388
2
45 0
15 16
end_DTG
begin_DTG
24
1
732
2
15 15
0 0
1
672
2
14 15
1 0
1
612
2
13 15
2 0
1
572
2
15 35
0 0
1
512
2
14 35
1 0
1
452
2
13 35
2 0
2
733
2
15 15
0 1
2
673
2
14 15
1 1
2
613
2
13 15
2 1
2
573
2
15 35
0 1
2
513
2
14 35
1 1
2
453
2
13 35
2 1
3
387
1
15 15
3
357
1
14 15
3
327
1
13 15
3
297
1
15 24
3
261
1
14 24
3
225
1
13 24
3
191
1
15 26
3
155
1
14 26
3
119
1
13 26
3
91
1
15 35
3
61
1
14 35
3
31
1
13 35
12
0
21
2
42 0
13 25
0
51
2
42 0
14 25
0
81
2
42 0
15 25
0
118
2
39 0
13 25
0
154
2
39 0
14 25
0
190
2
39 0
15 25
0
226
2
45 0
13 25
0
262
2
45 0
14 25
0
298
2
45 0
15 25
0
337
2
28 0
13 25
0
367
2
28 0
14 25
0
397
2
28 0
15 25
12
0
21
2
42 0
13 25
0
51
2
42 0
14 25
0
81
2
42 0
15 25
0
118
2
39 0
13 25
0
154
2
39 0
14 25
0
190
2
39 0
15 25
0
226
2
45 0
13 25
0
262
2
45 0
14 25
0
298
2
45 0
15 25
0
337
2
28 0
13 25
0
367
2
28 0
14 25
0
397
2
28 0
15 25
12
0
21
2
42 0
13 25
0
51
2
42 0
14 25
0
81
2
42 0
15 25
0
118
2
39 0
13 25
0
154
2
39 0
14 25
0
190
2
39 0
15 25
0
226
2
45 0
13 25
0
262
2
45 0
14 25
0
298
2
45 0
15 25
0
337
2
28 0
13 25
0
367
2
28 0
14 25
0
397
2
28 0
15 25
end_DTG
begin_DTG
24
1
734
2
15 16
0 0
1
674
2
14 16
1 0
1
614
2
13 16
2 0
1
574
2
15 36
0 0
1
514
2
14 36
1 0
1
454
2
13 36
2 0
2
735
2
15 16
0 1
2
675
2
14 16
1 1
2
615
2
13 16
2 1
2
575
2
15 36
0 1
2
515
2
14 36
1 1
2
455
2
13 36
2 1
3
388
1
15 16
3
358
1
14 16
3
328
1
13 16
3
298
1
15 25
3
262
1
14 25
3
226
1
13 25
3
192
1
15 27
3
156
1
14 27
3
120
1
13 27
3
92
1
15 36
3
62
1
14 36
3
32
1
13 36
12
0
22
2
43 0
13 26
0
52
2
43 0
14 26
0
82
2
43 0
15 26
0
119
2
44 0
13 26
0
155
2
44 0
14 26
0
191
2
44 0
15 26
0
227
2
41 0
13 26
0
263
2
41 0
14 26
0
299
2
41 0
15 26
0
338
2
29 0
13 26
0
368
2
29 0
14 26
0
398
2
29 0
15 26
12
0
22
2
43 0
13 26
0
52
2
43 0
14 26
0
82
2
43 0
15 26
0
119
2
44 0
13 26
0
155
2
44 0
14 26
0
191
2
44 0
15 26
0
227
2
41 0
13 26
0
263
2
41 0
14 26
0
299
2
41 0
15 26
0
338
2
29 0
13 26
0
368
2
29 0
14 26
0
398
2
29 0
15 26
12
0
22
2
43 0
13 26
0
52
2
43 0
14 26
0
82
2
43 0
15 26
0
119
2
44 0
13 26
0
155
2
44 0
14 26
0
191
2
44 0
15 26
0
227
2
41 0
13 26
0
263
2
41 0
14 26
0
299
2
41 0
15 26
0
338
2
29 0
13 26
0
368
2
29 0
14 26
0
398
2
29 0
15 26
end_DTG
begin_CG
40
3 2
4 2
5 2
7 2
9 2
11 2
12 2
10 2
8 2
6 2
18 4
20 4
30 4
34 4
38 4
42 4
43 4
40 4
36 4
32 4
19 4
21 4
31 4
35 4
39 4
44 4
45 4
41 4
37 4
33 4
16 2
17 2
22 2
24 2
26 2
28 2
29 2
27 2
25 2
23 2
40
3 2
4 2
5 2
7 2
9 2
11 2
12 2
10 2
8 2
6 2
18 4
20 4
30 4
34 4
38 4
42 4
43 4
40 4
36 4
32 4
19 4
21 4
31 4
35 4
39 4
44 4
45 4
41 4
37 4
33 4
16 2
17 2
22 2
24 2
26 2
28 2
29 2
27 2
25 2
23 2
40
3 2
4 2
5 2
7 2
9 2
11 2
12 2
10 2
8 2
6 2
18 4
20 4
30 4
34 4
38 4
42 4
43 4
40 4
36 4
32 4
19 4
21 4
31 4
35 4
39 4
44 4
45 4
41 4
37 4
33 4
16 2
17 2
22 2
24 2
26 2
28 2
29 2
27 2
25 2
23 2
5
5 3
18 3
13 2
14 2
15 2
5
6 3
20 3
13 2
14 2
15 2
6
3 3
7 3
30 3
13 3
14 3
15 3
6
4 3
8 3
32 3
13 3
14 3
15 3
6
5 3
9 3
34 3
13 3
14 3
15 3
6
10 3
6 3
36 3
13 3
14 3
15 3
6
7 3
11 3
38 3
13 3
14 3
15 3
6
12 3
8 3
40 3
13 3
14 3
15 3
6
9 3
12 3
42 3
13 3
14 3
15 3
6
11 3
10 3
43 3
13 3
14 3
15 3
40
3 6
4 6
5 8
7 8
9 8
11 8
12 8
10 8
8 8
6 8
18 10
20 10
30 12
34 12
38 12
42 12
43 12
40 12
36 12
32 12
19 10
21 10
31 12
35 12
39 12
44 12
45 12
41 12
37 12
33 12
16 6
17 6
22 8
24 8
26 8
28 8
29 8
27 8
25 8
23 8
40
3 6
4 6
5 8
7 8
9 8
11 8
12 8
10 8
8 8
6 8
18 10
20 10
30 12
34 12
38 12
42 12
43 12
40 12
36 12
32 12
19 10
21 10
31 12
35 12
39 12
44 12
45 12
41 12
37 12
33 12
16 6
17 6
22 8
24 8
26 8
28 8
29 8
27 8
25 8
23 8
40
3 6
4 6
5 8
7 8
9 8
11 8
12 8
10 8
8 8
6 8
18 10
20 10
30 12
34 12
38 12
42 12
43 12
40 12
36 12
32 12
19 10
21 10
31 12
35 12
39 12
44 12
45 12
41 12
37 12
33 12
16 6
17 6
22 8
24 8
26 8
28 8
29 8
27 8
25 8
23 8
5
19 3
22 3
13 2
14 2
15 2
5
21 3
23 3
13 2
14 2
15 2
6
3 3
30 3
19 3
13 3
14 3
15 3
6
18 3
31 3
16 3
13 3
14 3
15 3
6
4 3
32 3
21 3
13 3
14 3
15 3
6
20 3
33 3
17 3
13 3
14 3
15 3
6
31 3
16 3
24 3
13 3
14 3
15 3
6
33 3
17 3
25 3
13 3
14 3
15 3
6
35 3
22 3
26 3
13 3
14 3
15 3
6
37 3
27 3
23 3
13 3
14 3
15 3
6
39 3
24 3
28 3
13 3
14 3
15 3
6
41 3
29 3
25 3
13 3
14 3
15 3
6
44 3
26 3
29 3
13 3
14 3
15 3
6
45 3
28 3
27 3
13 3
14 3
15 3
7
5 3
18 3
34 3
31 3
13 4
14 4
15 4
7
30 3
19 3
35 3
22 3
13 4
14 4
15 4
7
6 3
20 3
36 3
33 3
13 4
14 4
15 4
7
32 3
21 3
37 3
23 3
13 4
14 4
15 4
7
7 3
30 3
38 3
35 3
13 4
14 4
15 4
7
34 3
31 3
39 3
24 3
13 4
14 4
15 4
7
8 3
40 3
32 3
37 3
13 4
14 4
15 4
7
36 3
41 3
33 3
25 3
13 4
14 4
15 4
7
9 3
34 3
42 3
39 3
13 4
14 4
15 4
7
38 3
35 3
44 3
26 3
13 4
14 4
15 4
7
10 3
43 3
36 3
41 3
13 4
14 4
15 4
7
40 3
45 3
37 3
27 3
13 4
14 4
15 4
7
11 3
38 3
43 3
44 3
13 4
14 4
15 4
7
12 3
42 3
40 3
45 3
13 4
14 4
15 4
7
42 3
39 3
45 3
28 3
13 4
14 4
15 4
7
43 3
44 3
41 3
29 3
13 4
14 4
15 4
end_CG
