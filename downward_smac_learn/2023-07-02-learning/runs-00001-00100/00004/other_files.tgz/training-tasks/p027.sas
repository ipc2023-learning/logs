begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var26
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var25
-1
25
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_4_5)
end_variable
begin_variable
var20
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom clear(tile_4_5)
Atom painted(tile_4_5, black)
Atom painted(tile_4_5, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_5)
Atom painted(tile_1_5, black)
Atom painted(tile_1_5, white)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom clear(tile_4_2)
Atom painted(tile_4_2, black)
Atom painted(tile_4_2, white)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom clear(tile_3_5)
Atom painted(tile_3_5, black)
Atom painted(tile_3_5, white)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom clear(tile_2_5)
Atom painted(tile_2_5, black)
Atom painted(tile_2_5, white)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom clear(tile_4_4)
Atom painted(tile_4_4, black)
Atom painted(tile_4_4, white)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom clear(tile_4_3)
Atom painted(tile_4_3, black)
Atom painted(tile_4_3, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_2)
Atom painted(tile_1_2, black)
Atom painted(tile_1_2, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_1_4)
Atom painted(tile_1_4, black)
Atom painted(tile_1_4, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_3)
Atom painted(tile_1_3, black)
Atom painted(tile_1_3, white)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom clear(tile_2_2)
Atom painted(tile_2_2, black)
Atom painted(tile_2_2, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_3_4)
Atom painted(tile_3_4, black)
Atom painted(tile_3_4, white)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom clear(tile_2_4)
Atom painted(tile_2_4, black)
Atom painted(tile_2_4, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var12
-1
4
Atom clear(tile_2_3)
Atom painted(tile_2_3, black)
Atom painted(tile_2_3, white)
<none of those>
end_variable
50
begin_mutex_group
4
1 0
1 1
1 2
6 0
end_mutex_group
begin_mutex_group
2
1 0
6 0
end_mutex_group
begin_mutex_group
4
3 0
3 1
3 2
6 1
end_mutex_group
begin_mutex_group
2
3 0
6 1
end_mutex_group
begin_mutex_group
4
5 0
5 1
5 2
6 2
end_mutex_group
begin_mutex_group
2
5 0
6 2
end_mutex_group
begin_mutex_group
4
4 0
4 1
4 2
6 3
end_mutex_group
begin_mutex_group
2
4 0
6 3
end_mutex_group
begin_mutex_group
4
2 0
2 1
2 2
6 4
end_mutex_group
begin_mutex_group
2
2 0
6 4
end_mutex_group
begin_mutex_group
4
9 0
9 1
9 2
6 5
end_mutex_group
begin_mutex_group
2
9 0
6 5
end_mutex_group
begin_mutex_group
4
18 0
18 1
18 2
6 6
end_mutex_group
begin_mutex_group
2
18 0
6 6
end_mutex_group
begin_mutex_group
4
20 0
20 1
20 2
6 7
end_mutex_group





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




egin_DTG
5
1
154
2
6 16
0 0
2
155
2
6 16
0 1
3
39
1
6 22
3
58
1
6 20
3
78
1
6 16
3
0
18
2
21 0
6 21
0
38
2
7 0
6 21
0
59
2
17 0
6 21
3
0
18
2
21 0
6 21
0
38
2
7 0
6 21
0
59
2
17 0
6 21
3
0
18
2
21 0
6 21
0
38
2
7 0
6 21
0
59
2
17 0
6 21
end_DTG
begin_DTG
7
1
120
2
6 24
0 0
1
150
2
6 14
0 0
2
121
2
6 24
0 1
2
151
2
6 14
0 1
3
21
1
6 24
3
57
1
6 18
3
76
1
6 14
3
0
16
2
15 0
6 19
0
37
2
23 0
6 19
0
81
2
8 0
6 19
3
0
16
2
15 0
6 19
0
37
2
23 0
6 19
0
81
2
8 0
6 19
3
0
16
2
15 0
6 19
0
37
2
23 0
6 19
0
81
2
8 0
6 19
end_DTG
begin_DTG
7
1
110
2
6 19
0 0
1
140
2
6 9
0 0
2
111
2
6 19
0 1
2
141
2
6 9
0 1
3
16
1
6 19
3
53
1
6 13
3
71
1
6 9
3
0
11
2
10 0
6 14
0
33
2
24 0
6 14
0
76
2
14 0
6 14
3
0
11
2
10 0
6 14
0
33
2
24 0
6 14
0
76
2
14 0
6 14
3
0
11
2
10 0
6 14
0
33
2
24 0
6 14
0
76
2
14 0
6 14
end_DTG
begin_DTG
5
1
158
2
6 18
0 0
2
159
2
6 18
0 1
3
41
1
6 24
3
60
1
6 22
3
80
1
6 18
3
0
20
2
23 0
6 23
0
40
2
17 0
6 23
0
61
2
8 0
6 23
3
0
20
2
23 0
6 23
0
40
2
17 0
6 23
0
61
2
8 0
6 23
3
0
20
2
23 0
6 23
0
40
2
17 0
6 23
0
61
2
8 0
6 23
end_DTG
begin_DTG
5
1
156
2
6 17
0 0
2
157
2
6 17
0 1
3
40
1
6 23
3
59
1
6 21
3
79
1
6 17
3
0
19
2
25 0
6 22
0
39
2
13 0
6 22
0
60
2
16 0
6 22
3
0
19
2
25 0
6 22
0
39
2
13 0
6 22
0
60
2
16 0
6 22
3
0
19
2
25 0
6 22
0
39
2
13 0
6 22
0
60
2
16 0
6 22
end_DTG
begin_DTG
8
1
94
2
6 11
0 0
1
124
2
6 1
0 0
2
95
2
6 11
0 1
2
125
2
6 1
0 1
3
8
1
6 11
3
27
1
6 7
3
46
1
6 5
3
63
1
6 1
4
0
3
2
3 0
6 6
0
26
2
9 0
6 6
0
47
2
20 0
6 6
0
68
2
22 0
6 6
4
0
3
2
3 0
6 6
0
26
2
9 0
6 6
0
47
2
20 0
6 6
0
68
2
22 0
6 6
4
0
3
2
3 0
6 6
0
26
2
9 0
6 6
0
47
2
20 0
6 6
0
68
2
22 0
6 6
end_DTG
begin_DTG
8
1
98
2
6 13
0 0
1
128
2
6 3
0 0
2
99
2
6 13
0 1
2
129
2
6 3
0 1
3
10
1
6 13
3
29
1
6 9
3
48
1
6 7
3
65
1
6 3
4
0
5
2
4 0
6 8
0
28
2
20 0
6 8
0
49
2
10 0
6 8
0
70
2
24 0
6 8
4
0
5
2
4 0
6 8
0
28
2
20 0
6 8
0
49
2
10 0
6 8
0
70
2
24 0
6 8
4
0
5
2
4 0
6 8
0
28
2
20 0
6 8
0
49
2
10 0
6 8
0
70
2
24 0
6 8
end_DTG
begin_DTG
8
1
96
2
6 12
0 0
1
126
2
6 2
0 0
2
97
2
6 12
0 1
2
127
2
6 2
0 1
3
9
1
6 12
3
28
1
6 8
3
47
1
6 6
3
64
1
6 2
4
0
4
2
5 0
6 7
0
27
2
18 0
6 7
0
48
2
19 0
6 7
0
69
2
26 0
6 7
4
0
4
2
5 0
6 7
0
27
2
18 0
6 7
0
48
2
19 0
6 7
0
69
2
26 0
6 7
4
0
4
2
5 0
6 7
0
27
2
18 0
6 7
0
48
2
19 0
6 7
0
69
2
26 0
6 7
end_DTG
begin_DTG
8
1
114
2
6 21
0 0
1
144
2
6 11
0 0
2
115
2
6 21
0 1
2
145
2
6 11
0 1
3
18
1
6 21
3
35
1
6 17
3
54
1
6 15
3
73
1
6 11
4
0
13
2
22 0
6 16
0
34
2
11 0
6 16
0
55
2
25 0
6 16
0
78
2
13 0
6 16
4
0
13
2
22 0
6 16
0
34
2
11 0
6 16
0
55
2
25 0
6 16
0
78
2
13 0
6 16
4
0
13
2
22 0
6 16
0
34
2
11 0
6 16
0
55
2
25 0
6 16
0
78
2
13 0
6 16
end_DTG
begin_DTG
8
1
104
2
6 16
0 0
1
134
2
6 6
0 0
2
105
2
6 16
0 1
2
135
2
6 6
0 1
3
13
1
6 16
3
31
1
6 12
3
50
1
6 10
3
68
1
6 6
4
0
8
2
18 0
6 11
0
30
2
12 0
6 11
0
51
2
26 0
6 11
0
73
2
21 0
6 11
4
0
8
2
18 0
6 11
0
30
2
12 0
6 11
0
51
2
26 0
6 11
0
73
2
21 0
6 11
4
0
8
2
18 0
6 11
0
30
2
12 0
6 11
0
51
2
26 0
6 11
0
73
2
21 0
6 11
end_DTG
begin_DTG
8
1
118
2
6 23
0 0
1
148
2
6 13
0 0
2
119
2
6 23
0 1
2
149
2
6 13
0 1
3
20
1
6 23
3
37
1
6 19
3
56
1
6 17
3
75
1
6 13
4
0
15
2
24 0
6 18
0
36
2
25 0
6 18
0
57
2
14 0
6 18
0
80
2
16 0
6 18
4
0
15
2
24 0
6 18
0
36
2
25 0
6 18
0
57
2
14 0
6 18
0
80
2
16 0
6 18
4
0
15
2
24 0
6 18
0
36
2
25 0
6 18
0
57
2
14 0
6 18
0
80
2
16 0
6 18
end_DTG
begin_DTG
8
1
108
2
6 18
0 0
1
138
2
6 8
0 0
2
109
2
6 18
0 1
2
139
2
6 8
0 1
3
15
1
6 18
3
33
1
6 14
3
52
1
6 12
3
70
1
6 8
4
0
10
2
19 0
6 13
0
32
2
26 0
6 13
0
53
2
15 0
6 13
0
75
2
23 0
6 13
4
0
10
2
19 0
6 13
0
32
2
26 0
6 13
0
53
2
15 0
6 13
0
75
2
23 0
6 13
4
0
10
2
19 0
6 13
0
32
2
26 0
6 13
0
53
2
15 0
6 13
0
75
2
23 0
6 13
end_DTG
begin_DTG
8
1
116
2
6 22
0 0
1
146
2
6 12
0 0
2
117
2
6 22
0 1
2
147
2
6 12
0 1
3
19
1
6 22
3
36
1
6 18
3
55
1
6 16
3
74
1
6 12
4
0
14
2
26 0
6 17
0
35
2
21 0
6 17
0
56
2
23 0
6 17
0
79
2
17 0
6 17
4
0
14
2
26 0
6 17
0
35
2
21 0
6 17
0
56
2
23 0
6 17
0
79
2
17 0
6 17
4
0
14
2
26 0
6 17
0
35
2
21 0
6 17
0
56
2
23 0
6 17
0
79
2
17 0
6 17
end_DTG
begin_DTG
8
1
106
2
6 17
0 0
1
136
2
6 7
0 0
2
107
2
6 17
0 1
2
137
2
6 7
0 1
3
14
1
6 17
3
32
1
6 13
3
51
1
6 11
3
69
1
6 7
4
0
9
2
20 0
6 12
0
31
2
22 0
6 12
0
52
2
24 0
6 12
0
74
2
25 0
6 12
4
0
9
2
20 0
6 12
0
31
2
22 0
6 12
0
52
2
24 0
6 12
0
74
2
25 0
6 12
4
0
9
2
20 0
6 12
0
31
2
22 0
6 12
0
52
2
24 0
6 12
0
74
2
25 0
6 12
end_DTG
begin_CG
25
1 2
3 2
5 2
4 2
2 2
9 4
18 4
20 4
19 4
10 4
12 4
22 4
26 4
24 4
15 4
11 4
21 4
25 4
23 4
14 4
7 2
13 2
17 2
16 2
8 2
3
3 1
9 1
6 2
3
4 1
10 1
6 2
4
1 1
5 1
18 1
6 3
4
5 1
2 1
19 1
6 3
4
3 1
4 1
20 1
6 3
25
1 6
3 8
5 8
4 8
2 6
9 10
18 12
20 12
19 12
10 10
12 10
22 12
26 12
24 12
15 10
11 10
21 12
25 12
23 12
14 10
7 6
13 8
17 8
16 8
8 6
3
11 1
13 1
6 2
3
14 1
16 1
6 2
4
1 1
18 1
12 1
6 3
4
2 1
19 1
15 1
6 3
4
12 1
21 1
7 1
6 3
4
9 1
22 1
11 1
6 3
4
21 1
7 1
17 1
6 3
4
15 1
23 1
8 1
6 3
4
10 1
24 1
14 1
6 3
4
23 1
17 1
8 1
6 3
4
25 1
13 1
16 1
6 3
5
3 1
9 1
20 1
22 1
6 4
5
4 1
20 1
10 1
24 1
6 4
5
5 1
18 1
19 1
26 1
6 4
5
22 1
11 1
25 1
13 1
6 4
5
18 1
12 1
26 1
21 1
6 4
5
24 1
25 1
14 1
16 1
6 4
5
19 1
26 1
15 1
23 1
6 4
5
26 1
21 1
23 1
17 1
6 4
5
20 1
22 1
24 1
25 1
6 4
end_CG
