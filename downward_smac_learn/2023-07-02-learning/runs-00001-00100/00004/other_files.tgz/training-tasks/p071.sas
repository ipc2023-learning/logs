begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var40
-1
2
Atom robot-has(robot3, black)
Atom robot-has(robot3, white)
end_variable
begin_variable
var39
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var38
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_0_7)
Atom painted(tile_0_7, black)
Atom painted(tile_0_7, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var35
-1
35
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_0_7)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_1_7)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_2_7)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_3_7)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_4_5)
Atom robot-at(robot1, tile_4_6)
Atom robot-at(robot1, tile_4_7)
end_variable
begin_variable
var36
-1
35
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_0_5)
Atom robot-at(robot2, tile_0_6)
Atom robot-at(robot2, tile_0_7)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_1_5)
Atom robot-at(robot2, tile_1_6)
Atom robot-at(robot2, tile_1_7)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_2_5)
Atom robot-at(robot2, tile_2_6)
Atom robot-at(robot2, tile_2_7)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_3_5)
Atom robot-at(robot2, tile_3_6)
Atom robot-at(robot2, tile_3_7)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_4_4)
Atom robot-at(robot2, tile_4_5)
Atom robot-at(robot2, tile_4_6)
Atom robot-at(robot2, tile_4_7)
end_variable
begin_variable
var37
-1
35
Atom robot-at(robot3, tile_0_1)
Atom robot-at(robot3, tile_0_2)
Atom robot-at(robot3, tile_0_3)
Atom robot-at(robot3, tile_0_4)
Atom robot-at(robot3, tile_0_5)
Atom robot-at(robot3, tile_0_6)
Atom robot-at(robot3, tile_0_7)
Atom robot-at(robot3, tile_1_1)
Atom robot-at(robot3, tile_1_2)
Atom robot-at(robot3, tile_1_3)
Atom robot-at(robot3, tile_1_4)
Atom robot-at(robot3, tile_1_5)
Atom robot-at(robot3, tile_1_6)
Atom robot-at(robot3, tile_1_7)
Atom robot-at(robot3, tile_2_1)
Atom robot-at(robot3, tile_2_2)
Atom robot-at(robot3, tile_2_3)
Atom robot-at(robot3, tile_2_4)
Atom robot-at(robot3, tile_2_5)
Atom robot-at(robot3, tile_2_6)
Atom robot-at(robot3, tile_2_7)
Atom robot-at(robot3, tile_3_1)
Atom robot-at(robot3, tile_3_2)
Atom robot-at(robot3, tile_3_3)
Atom robot-at(robot3, tile_3_4)
Atom robot-at(robot3, tile_3_5)
Atom robot-at(robot3, tile_3_6)
Atom robot-at(robot3, tile_3_7)
Atom robot-at(robot3, tile_4_1)
Atom robot-at(robot3, tile_4_2)
Atom robot-at(robot3, tile_4_3)
Atom robot-at(robot3, tile_4_4)
Atom robot-at(robot3, tile_4_5)
Atom robot-at(robot3, tile_4_6)
Atom robot-at(robot3, tile_4_7)
end_variable
begin_variable
var28
-1
4
Atom clear(tile_4_1)
Atom painted(tile_4_1, black)
Atom painted(tile_4_1, white)
<none of those>
end_variable
begin_variable
var34
-1
4
Atom clear(tile_4_7)
Atom painted(tile_4_7, black)
Atom painted(tile_4_7, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




17
2
33 0
10 18
0
45
2
33 0
11 18
0
73
2
33 0
12 18
0
105
2
40 0
10 18
0
135
2
40 0
11 18
0
165
2
40 0
12 18
0
196
2
31 0
10 18
0
226
2
31 0
11 18
0
256
2
31 0
12 18
0
288
2
37 0
10 18
0
316
2
37 0
11 18
0
344
2
37 0
12 18
12
0
17
2
33 0
10 18
0
45
2
33 0
11 18
0
73
2
33 0
12 18
0
105
2
40 0
10 18
0
135
2
40 0
11 18
0
165
2
40 0
12 18
0
196
2
31 0
10 18
0
226
2
31 0
11 18
0
256
2
31 0
12 18
0
288
2
37 0
10 18
0
316
2
37 0
11 18
0
344
2
37 0
12 18
12
0
17
2
33 0
10 18
0
45
2
33 0
11 18
0
73
2
33 0
12 18
0
105
2
40 0
10 18
0
135
2
40 0
11 18
0
165
2
40 0
12 18
0
196
2
31 0
10 18
0
226
2
31 0
11 18
0
256
2
31 0
12 18
0
288
2
37 0
10 18
0
316
2
37 0
11 18
0
344
2
37 0
12 18
end_DTG
begin_DTG
24
1
668
2
12 17
0 0
1
612
2
11 17
1 0
1
556
2
10 17
2 0
1
514
2
12 31
0 0
1
458
2
11 31
1 0
1
402
2
10 31
2 0
2
669
2
12 17
0 1
2
613
2
11 17
1 1
2
557
2
10 17
2 1
2
515
2
12 31
0 1
2
459
2
11 31
1 1
2
403
2
10 31
2 1
3
343
1
12 17
3
315
1
11 17
3
287
1
10 17
3
260
1
12 23
3
230
1
11 23
3
200
1
10 23
3
171
1
12 25
3
141
1
11 25
3
111
1
10 25
3
86
1
12 31
3
58
1
11 31
3
30
1
10 31
12
0
23
2
40 0
10 24
0
51
2
40 0
11 24
0
79
2
40 0
12 24
0
110
2
35 0
10 24
0
140
2
35 0
11 24
0
170
2
35 0
12 24
0
201
2
37 0
10 24
0
231
2
37 0
11 24
0
261
2
37 0
12 24
0
294
2
25 0
10 24
0
322
2
25 0
11 24
0
350
2
25 0
12 24
12
0
23
2
40 0
10 24
0
51
2
40 0
11 24
0
79
2
40 0
12 24
0
110
2
35 0
10 24
0
140
2
35 0
11 24
0
170
2
35 0
12 24
0
201
2
37 0
10 24
0
231
2
37 0
11 24
0
261
2
37 0
12 24
0
294
2
25 0
10 24
0
322
2
25 0
11 24
0
350
2
25 0
12 24
12
0
23
2
40 0
10 24
0
51
2
40 0
11 24
0
79
2
40 0
12 24
0
110
2
35 0
10 24
0
140
2
35 0
11 24
0
170
2
35 0
12 24
0
201
2
37 0
10 24
0
231
2
37 0
11 24
0
261
2
37 0
12 24
0
294
2
25 0
10 24
0
322
2
25 0
11 24
0
350
2
25 0
12 24
end_DTG
begin_DTG
24
1
654
2
12 10
0 0
1
598
2
11 10
1 0
1
542
2
10 10
2 0
1
500
2
12 24
0 0
1
444
2
11 24
1 0
1
388
2
10 24
2 0
2
655
2
12 10
0 1
2
599
2
11 10
1 1
2
543
2
10 10
2 1
2
501
2
12 24
0 1
2
445
2
11 24
1 1
2
389
2
10 24
2 1
3
336
1
12 10
3
308
1
11 10
3
280
1
10 10
3
254
1
12 16
3
224
1
11 16
3
194
1
10 16
3
165
1
12 18
3
135
1
11 18
3
105
1
10 18
3
79
1
12 24
3
51
1
11 24
3
23
1
10 24
12
0
16
2
34 0
10 17
0
44
2
34 0
11 17
0
72
2
34 0
12 17
0
104
2
36 0
10 17
0
134
2
36 0
11 17
0
164
2
36 0
12 17
0
195
2
38 0
10 17
0
225
2
38 0
11 17
0
255
2
38 0
12 17
0
287
2
39 0
10 17
0
315
2
39 0
11 17
0
343
2
39 0
12 17
12
0
16
2
34 0
10 17
0
44
2
34 0
11 17
0
72
2
34 0
12 17
0
104
2
36 0
10 17
0
134
2
36 0
11 17
0
164
2
36 0
12 17
0
195
2
38 0
10 17
0
225
2
38 0
11 17
0
255
2
38 0
12 17
0
287
2
39 0
10 17
0
315
2
39 0
11 17
0
343
2
39 0
12 17
12
0
16
2
34 0
10 17
0
44
2
34 0
11 17
0
72
2
34 0
12 17
0
104
2
36 0
10 17
0
134
2
36 0
11 17
0
164
2
36 0
12 17
0
195
2
38 0
10 17
0
225
2
38 0
11 17
0
255
2
38 0
12 17
0
287
2
39 0
10 17
0
315
2
39 0
11 17
0
343
2
39 0
12 17
end_DTG
begin_CG
35
3 2
5 2
7 2
9 2
8 2
6 2
4 2
15 4
26 4
32 4
34 4
33 4
27 4
16 4
18 4
29 4
36 4
40 4
38 4
31 4
21 4
17 4
28 4
35 4
39 4
37 4
30 4
20 4
13 2
19 2
23 2
25 2
24 2
22 2
14 2
35
3 2
5 2
7 2
9 2
8 2
6 2
4 2
15 4
26 4
32 4
34 4
33 4
27 4
16 4
18 4
29 4
36 4
40 4
38 4
31 4
21 4
17 4
28 4
35 4
39 4
37 4
30 4
20 4
13 2
19 2
23 2
25 2
24 2
22 2
14 2
35
3 2
5 2
7 2
9 2
8 2
6 2
4 2
15 4
26 4
32 4
34 4
33 4
27 4
16 4
18 4
29 4
36 4
40 4
38 4
31 4
21 4
17 4
28 4
35 4
39 4
37 4
30 4
20 4
13 2
19 2
23 2
25 2
24 2
22 2
14 2
5
5 3
15 3
10 2
11 2
12 2
5
6 3
16 3
10 2
11 2
12 2
6
3 3
7 3
26 3
10 3
11 3
12 3
6
8 3
4 3
27 3
10 3
11 3
12 3
6
5 3
9 3
32 3
10 3
11 3
12 3
6
9 3
6 3
33 3
10 3
11 3
12 3
6
7 3
8 3
34 3
10 3
11 3
12 3
35
3 6
5 8
7 8
9 8
8 8
6 8
4 6
15 10
26 12
32 12
34 12
33 12
27 12
16 10
18 10
29 12
36 12
40 12
38 12
31 12
21 10
17 10
28 12
35 12
39 12
37 12
30 12
20 10
13 6
19 8
23 8
25 8
24 8
22 8
14 6
35
3 6
5 8
7 8
9 8
8 8
6 8
4 6
15 10
26 12
32 12
34 12
33 12
27 12
16 10
18 10
29 12
36 12
40 12
38 12
31 12
21 10
17 10
28 12
35 12
39 12
37 12
30 12
20 10
13 6
19 8
23 8
25 8
24 8
22 8
14 6
35
3 6
5 8
7 8
9 8
8 8
6 8
4 6
15 10
26 12
32 12
34 12
33 12
27 12
16 10
18 10
29 12
36 12
40 12
38 12
31 12
21 10
17 10
28 12
35 12
39 12
37 12
30 12
20 10
13 6
19 8
23 8
25 8
24 8
22 8
14 6
5
17 3
19 3
10 2
11 2
12 2
5
20 3
22 3
10 2
11 2
12 2
6
3 3
26 3
18 3
10 3
11 3
12 3
6
4 3
27 3
21 3
10 3
11 3
12 3
6
18 3
28 3
13 3
10 3
11 3
12 3
6
15 3
29 3
17 3
10 3
11 3
12 3
6
28 3
13 3
23 3
10 3
11 3
12 3
6
21 3
30 3
14 3
10 3
11 3
12 3
6
16 3
31 3
20 3
10 3
11 3
12 3
6
30 3
24 3
14 3
10 3
11 3
12 3
6
35 3
19 3
25 3
10 3
11 3
12 3
6
37 3
25 3
22 3
10 3
11 3
12 3
6
39 3
23 3
24 3
10 3
11 3
12 3
7
5 3
15 3
32 3
29 3
10 4
11 4
12 4
7
6 3
33 3
16 3
31 3
10 4
11 4
12 4
7
29 3
17 3
35 3
19 3
10 4
11 4
12 4
7
26 3
18 3
36 3
28 3
10 4
11 4
12 4
7
31 3
37 3
20 3
22 3
10 4
11 4
12 4
7
27 3
38 3
21 3
30 3
10 4
11 4
12 4
7
7 3
26 3
34 3
36 3
10 4
11 4
12 4
7
8 3
34 3
27 3
38 3
10 4
11 4
12 4
7
9 3
32 3
33 3
40 3
10 4
11 4
12 4
7
36 3
28 3
39 3
23 3
10 4
11 4
12 4
7
32 3
29 3
40 3
35 3
10 4
11 4
12 4
7
38 3
39 3
30 3
24 3
10 4
11 4
12 4
7
33 3
40 3
31 3
37 3
10 4
11 4
12 4
7
40 3
35 3
37 3
25 3
10 4
11 4
12 4
7
34 3
36 3
38 3
39 3
10 4
11 4
12 4
end_CG
