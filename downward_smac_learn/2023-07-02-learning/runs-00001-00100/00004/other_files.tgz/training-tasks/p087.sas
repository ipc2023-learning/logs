begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var41
-1
2
Atom robot-has(robot3, black)
Atom robot-has(robot3, white)
end_variable
begin_variable
var40
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var39
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var36
-1
36
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_4_1)
Atom robot-at(robot1, tile_4_2)
Atom robot-at(robot1, tile_4_3)
Atom robot-at(robot1, tile_4_4)
Atom robot-at(robot1, tile_4_5)
Atom robot-at(robot1, tile_4_6)
Atom robot-at(robot1, tile_5_1)
Atom robot-at(robot1, tile_5_2)
Atom robot-at(robot1, tile_5_3)
Atom robot-at(robot1, tile_5_4)
Atom robot-at(robot1, tile_5_5)
Atom robot-at(robot1, tile_5_6)
end_variable
begin_variable
var37
-1
36
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_0_5)
Atom robot-at(robot2, tile_0_6)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_1_5)
Atom robot-at(robot2, tile_1_6)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_2_5)
Atom robot-at(robot2, tile_2_6)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_3_5)
Atom robot-at(robot2, tile_3_6)
Atom robot-at(robot2, tile_4_1)
Atom robot-at(robot2, tile_4_2)
Atom robot-at(robot2, tile_4_3)
Atom robot-at(robot2, tile_4_4)
Atom robot-at(robot2, tile_4_5)
Atom robot-at(robot2, tile_4_6)
Atom robot-at(robot2, tile_5_1)
Atom robot-at(robot2, tile_5_2)
Atom robot-at(robot2, tile_5_3)
Atom robot-at(robot2, tile_5_4)
Atom robot-at(robot2, tile_5_5)
Atom robot-at(robot2, tile_5_6)
end_variable
begin_variable
var38
-1
36
Atom robot-at(robot3, tile_0_1)
Atom robot-at(robot3, tile_0_2)
Atom robot-at(robot3, tile_0_3)
Atom robot-at(robot3, tile_0_4)
Atom robot-at(robot3, tile_0_5)
Atom robot-at(robot3, tile_0_6)
Atom robot-at(robot3, tile_1_1)
Atom robot-at(robot3, tile_1_2)
Atom robot-at(robot3, tile_1_3)
Atom robot-at(robot3, tile_1_4)
Atom robot-at(robot3, tile_1_5)
Atom robot-at(robot3, tile_1_6)
Atom robot-at(robot3, tile_2_1)
Atom robot-at(robot3, tile_2_2)
Atom robot-at(robot3, tile_2_3)
Atom robot-at(robot3, tile_2_4)
Atom robot-at(robot3, tile_2_5)
Atom robot-at(robot3, tile_2_6)
Atom robot-at(robot3, tile_3_1)
Atom robot-at(robot3, tile_3_2)
Atom robot-at(robot3, tile_3_3)
Atom robot-at(robot3, tile_3_4)
Atom robot-at(robot3, tile_3_5)
Atom robot-at(robot3, tile_3_6)
Atom robot-at(robot3, tile_4_1)
Atom robot-at(robot3, tile_4_2)
Atom robot-at(robot3, tile_4_3)
Atom robot-at(robot3, tile_4_4)
Atom robot-at(robot3, tile_4_5)
Atom robot-at(robot3, tile_4_6)
Atom robot-at(robot3, tile_5_1)
Atom robot-at(robot3, tile_5_2)
Atom robot-at(robot3, tile_5_3)
Atom robot-at(robot3, tile_5_4)
Atom robot-at(robot3, tile_5_5)
Atom robot-at(robot3, tile_5_6)
end_variable
begin_variable
var30
-1
4
Atom clear(tile_5_1)
Atom painted(tile_5_1, black)
Atom painted(tile_5_1, white)
<none of those>
end_variable
begin_variable
var35
-1
4
Atom clear(tile_5_6)
Atom painted(tile_5_6, black)
Atom painted(tile_5_6, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<n




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
15
2
31 0
9 15
0
45
2
31 0
10 15
0
75
2
31 0
11 15
0
108
2
38 0
9 15
0
138
2
38 0
10 15
0
168
2
38 0
11 15
0
199
2
34 0
9 15
0
229
2
34 0
10 15
0
259
2
34 0
11 15
0
291
2
41 0
9 15
0
321
2
41 0
10 15
0
351
2
41 0
11 15
12
0
15
2
31 0
9 15
0
45
2
31 0
10 15
0
75
2
31 0
11 15
0
108
2
38 0
9 15
0
138
2
38 0
10 15
0
168
2
38 0
11 15
0
199
2
34 0
9 15
0
229
2
34 0
10 15
0
259
2
34 0
11 15
0
291
2
41 0
9 15
0
321
2
41 0
10 15
0
351
2
41 0
11 15
12
0
15
2
31 0
9 15
0
45
2
31 0
10 15
0
75
2
31 0
11 15
0
108
2
38 0
9 15
0
138
2
38 0
10 15
0
168
2
38 0
11 15
0
199
2
34 0
9 15
0
229
2
34 0
10 15
0
259
2
34 0
11 15
0
291
2
41 0
9 15
0
321
2
41 0
10 15
0
351
2
41 0
11 15
end_DTG
begin_DTG
24
1
694
2
11 14
0 0
1
634
2
10 14
1 0
1
574
2
9 14
2 0
1
526
2
11 26
0 0
1
466
2
10 26
1 0
1
406
2
9 26
2 0
2
695
2
11 14
0 1
2
635
2
10 14
1 1
2
575
2
9 14
2 1
2
527
2
11 26
0 1
2
467
2
10 26
1 1
2
407
2
9 26
2 1
3
350
1
11 14
3
320
1
10 14
3
290
1
9 14
3
262
1
11 19
3
232
1
10 19
3
202
1
9 19
3
173
1
11 21
3
143
1
10 21
3
113
1
9 21
3
86
1
11 26
3
56
1
10 26
3
26
1
9 26
12
0
20
2
38 0
9 20
0
50
2
38 0
10 20
0
80
2
38 0
11 20
0
112
2
33 0
9 20
0
142
2
33 0
10 20
0
172
2
33 0
11 20
0
203
2
41 0
9 20
0
233
2
41 0
10 20
0
263
2
41 0
11 20
0
296
2
36 0
9 20
0
326
2
36 0
10 20
0
356
2
36 0
11 20
12
0
20
2
38 0
9 20
0
50
2
38 0
10 20
0
80
2
38 0
11 20
0
112
2
33 0
9 20
0
142
2
33 0
10 20
0
172
2
33 0
11 20
0
203
2
41 0
9 20
0
233
2
41 0
10 20
0
263
2
41 0
11 20
0
296
2
36 0
9 20
0
326
2
36 0
10 20
0
356
2
36 0
11 20
12
0
20
2
38 0
9 20
0
50
2
38 0
10 20
0
80
2
38 0
11 20
0
112
2
33 0
9 20
0
142
2
33 0
10 20
0
172
2
33 0
11 20
0
203
2
41 0
9 20
0
233
2
41 0
10 20
0
263
2
41 0
11 20
0
296
2
36 0
9 20
0
326
2
36 0
10 20
0
356
2
36 0
11 20
end_DTG
begin_DTG
24
1
696
2
11 15
0 0
1
636
2
10 15
1 0
1
576
2
9 15
2 0
1
528
2
11 27
0 0
1
468
2
10 27
1 0
1
408
2
9 27
2 0
2
697
2
11 15
0 1
2
637
2
10 15
1 1
2
577
2
9 15
2 1
2
529
2
11 27
0 1
2
469
2
10 27
1 1
2
409
2
9 27
2 1
3
351
1
11 15
3
321
1
10 15
3
291
1
9 15
3
263
1
11 20
3
233
1
10 20
3
203
1
9 20
3
174
1
11 22
3
144
1
10 22
3
114
1
9 22
3
87
1
11 27
3
57
1
10 27
3
27
1
9 27
12
0
21
2
39 0
9 21
0
51
2
39 0
10 21
0
81
2
39 0
11 21
0
113
2
40 0
9 21
0
143
2
40 0
10 21
0
173
2
40 0
11 21
0
204
2
35 0
9 21
0
234
2
35 0
10 21
0
264
2
35 0
11 21
0
297
2
37 0
9 21
0
327
2
37 0
10 21
0
357
2
37 0
11 21
12
0
21
2
39 0
9 21
0
51
2
39 0
10 21
0
81
2
39 0
11 21
0
113
2
40 0
9 21
0
143
2
40 0
10 21
0
173
2
40 0
11 21
0
204
2
35 0
9 21
0
234
2
35 0
10 21
0
264
2
35 0
11 21
0
297
2
37 0
9 21
0
327
2
37 0
10 21
0
357
2
37 0
11 21
12
0
21
2
39 0
9 21
0
51
2
39 0
10 21
0
81
2
39 0
11 21
0
113
2
40 0
9 21
0
143
2
40 0
10 21
0
173
2
40 0
11 21
0
204
2
35 0
9 21
0
234
2
35 0
10 21
0
264
2
35 0
11 21
0
297
2
37 0
9 21
0
327
2
37 0
10 21
0
357
2
37 0
11 21
end_DTG
begin_CG
36
3 2
5 2
7 2
8 2
6 2
4 2
14 4
26 4
30 4
31 4
27 4
15 4
20 4
32 4
38 4
39 4
34 4
22 4
21 4
33 4
40 4
41 4
35 4
23 4
16 4
28 4
36 4
37 4
29 4
18 4
12 2
17 2
24 2
25 2
19 2
13 2
36
3 2
5 2
7 2
8 2
6 2
4 2
14 4
26 4
30 4
31 4
27 4
15 4
20 4
32 4
38 4
39 4
34 4
22 4
21 4
33 4
40 4
41 4
35 4
23 4
16 4
28 4
36 4
37 4
29 4
18 4
12 2
17 2
24 2
25 2
19 2
13 2
36
3 2
5 2
7 2
8 2
6 2
4 2
14 4
26 4
30 4
31 4
27 4
15 4
20 4
32 4
38 4
39 4
34 4
22 4
21 4
33 4
40 4
41 4
35 4
23 4
16 4
28 4
36 4
37 4
29 4
18 4
12 2
17 2
24 2
25 2
19 2
13 2
5
5 3
14 3
9 2
10 2
11 2
5
6 3
15 3
9 2
10 2
11 2
6
3 3
7 3
26 3
9 3
10 3
11 3
6
8 3
4 3
27 3
9 3
10 3
11 3
6
5 3
8 3
30 3
9 3
10 3
11 3
6
7 3
6 3
31 3
9 3
10 3
11 3
36
3 6
5 8
7 8
8 8
6 8
4 6
14 10
26 12
30 12
31 12
27 12
15 10
20 10
32 12
38 12
39 12
34 12
22 10
21 10
33 12
40 12
41 12
35 12
23 10
16 10
28 12
36 12
37 12
29 12
18 10
12 6
17 8
24 8
25 8
19 8
13 6
36
3 6
5 8
7 8
8 8
6 8
4 6
14 10
26 12
30 12
31 12
27 12
15 10
20 10
32 12
38 12
39 12
34 12
22 10
21 10
33 12
40 12
41 12
35 12
23 10
16 10
28 12
36 12
37 12
29 12
18 10
12 6
17 8
24 8
25 8
19 8
13 6
36
3 6
5 8
7 8
8 8
6 8
4 6
14 10
26 12
30 12
31 12
27 12
15 10
20 10
32 12
38 12
39 12
34 12
22 10
21 10
33 12
40 12
41 12
35 12
23 10
16 10
28 12
36 12
37 12
29 12
18 10
12 6
17 8
24 8
25 8
19 8
13 6
5
16 3
17 3
9 2
10 2
11 2
5
18 3
19 3
9 2
10 2
11 2
6
3 3
26 3
20 3
9 3
10 3
11 3
6
4 3
27 3
22 3
9 3
10 3
11 3
6
21 3
28 3
12 3
9 3
10 3
11 3
6
28 3
12 3
24 3
9 3
10 3
11 3
6
23 3
29 3
13 3
9 3
10 3
11 3
6
29 3
25 3
13 3
9 3
10 3
11 3
6
14 3
32 3
21 3
9 3
10 3
11 3
6
20 3
33 3
16 3
9 3
10 3
11 3
6
15 3
34 3
23 3
9 3
10 3
11 3
6
22 3
35 3
18 3
9 3
10 3
11 3
6
36 3
17 3
25 3
9 3
10 3
11 3
6
37 3
24 3
19 3
9 3
10 3
11 3
7
5 3
14 3
30 3
32 3
9 4
10 4
11 4
7
6 3
31 3
15 3
34 3
9 4
10 4
11 4
7
33 3
16 3
36 3
17 3
9 4
10 4
11 4
7
35 3
37 3
18 3
19 3
9 4
10 4
11 4
7
7 3
26 3
31 3
38 3
9 4
10 4
11 4
7
8 3
30 3
27 3
39 3
9 4
10 4
11 4
7
26 3
20 3
38 3
33 3
9 4
10 4
11 4
7
32 3
21 3
40 3
28 3
9 4
10 4
11 4
7
27 3
39 3
22 3
35 3
9 4
10 4
11 4
7
34 3
41 3
23 3
29 3
9 4
10 4
11 4
7
40 3
28 3
37 3
24 3
9 4
10 4
11 4
7
41 3
36 3
29 3
25 3
9 4
10 4
11 4
7
30 3
32 3
39 3
40 3
9 4
10 4
11 4
7
31 3
38 3
34 3
41 3
9 4
10 4
11 4
7
38 3
33 3
41 3
36 3
9 4
10 4
11 4
7
39 3
40 3
35 3
37 3
9 4
10 4
11 4
end_CG
