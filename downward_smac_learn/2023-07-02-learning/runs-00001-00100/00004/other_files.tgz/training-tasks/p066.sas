begin_version
3
end_version
begin_metric
0
end_metric
40
begin_variable
var39
-1
2
Atom robot-has(robot2, black)
Atom robot-has(robot2, white)
end_variable
begin_variable
var38
-1
2
Atom robot-has(robot1, black)
Atom robot-has(robot1, white)
end_variable
begin_variable
var0
-1
4
Atom clear(tile_0_1)
Atom painted(tile_0_1, black)
Atom painted(tile_0_1, white)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom clear(tile_0_9)
Atom painted(tile_0_9, black)
Atom painted(tile_0_9, white)
<none of those>
end_variable
begin_variable
var1
-1
4
Atom clear(tile_0_2)
Atom painted(tile_0_2, black)
Atom painted(tile_0_2, white)
<none of those>
end_variable
begin_variable
var7
-1
4
Atom clear(tile_0_8)
Atom painted(tile_0_8, black)
Atom painted(tile_0_8, white)
<none of those>
end_variable
begin_variable
var2
-1
4
Atom clear(tile_0_3)
Atom painted(tile_0_3, black)
Atom painted(tile_0_3, white)
<none of those>
end_variable
begin_variable
var6
-1
4
Atom clear(tile_0_7)
Atom painted(tile_0_7, black)
Atom painted(tile_0_7, white)
<none of those>
end_variable
begin_variable
var3
-1
4
Atom clear(tile_0_4)
Atom painted(tile_0_4, black)
Atom painted(tile_0_4, white)
<none of those>
end_variable
begin_variable
var5
-1
4
Atom clear(tile_0_6)
Atom painted(tile_0_6, black)
Atom painted(tile_0_6, white)
<none of those>
end_variable
begin_variable
var4
-1
4
Atom clear(tile_0_5)
Atom painted(tile_0_5, black)
Atom painted(tile_0_5, white)
<none of those>
end_variable
begin_variable
var36
-1
36
Atom robot-at(robot1, tile_0_1)
Atom robot-at(robot1, tile_0_2)
Atom robot-at(robot1, tile_0_3)
Atom robot-at(robot1, tile_0_4)
Atom robot-at(robot1, tile_0_5)
Atom robot-at(robot1, tile_0_6)
Atom robot-at(robot1, tile_0_7)
Atom robot-at(robot1, tile_0_8)
Atom robot-at(robot1, tile_0_9)
Atom robot-at(robot1, tile_1_1)
Atom robot-at(robot1, tile_1_2)
Atom robot-at(robot1, tile_1_3)
Atom robot-at(robot1, tile_1_4)
Atom robot-at(robot1, tile_1_5)
Atom robot-at(robot1, tile_1_6)
Atom robot-at(robot1, tile_1_7)
Atom robot-at(robot1, tile_1_8)
Atom robot-at(robot1, tile_1_9)
Atom robot-at(robot1, tile_2_1)
Atom robot-at(robot1, tile_2_2)
Atom robot-at(robot1, tile_2_3)
Atom robot-at(robot1, tile_2_4)
Atom robot-at(robot1, tile_2_5)
Atom robot-at(robot1, tile_2_6)
Atom robot-at(robot1, tile_2_7)
Atom robot-at(robot1, tile_2_8)
Atom robot-at(robot1, tile_2_9)
Atom robot-at(robot1, tile_3_1)
Atom robot-at(robot1, tile_3_2)
Atom robot-at(robot1, tile_3_3)
Atom robot-at(robot1, tile_3_4)
Atom robot-at(robot1, tile_3_5)
Atom robot-at(robot1, tile_3_6)
Atom robot-at(robot1, tile_3_7)
Atom robot-at(robot1, tile_3_8)
Atom robot-at(robot1, tile_3_9)
end_variable
begin_variable
var37
-1
36
Atom robot-at(robot2, tile_0_1)
Atom robot-at(robot2, tile_0_2)
Atom robot-at(robot2, tile_0_3)
Atom robot-at(robot2, tile_0_4)
Atom robot-at(robot2, tile_0_5)
Atom robot-at(robot2, tile_0_6)
Atom robot-at(robot2, tile_0_7)
Atom robot-at(robot2, tile_0_8)
Atom robot-at(robot2, tile_0_9)
Atom robot-at(robot2, tile_1_1)
Atom robot-at(robot2, tile_1_2)
Atom robot-at(robot2, tile_1_3)
Atom robot-at(robot2, tile_1_4)
Atom robot-at(robot2, tile_1_5)
Atom robot-at(robot2, tile_1_6)
Atom robot-at(robot2, tile_1_7)
Atom robot-at(robot2, tile_1_8)
Atom robot-at(robot2, tile_1_9)
Atom robot-at(robot2, tile_2_1)
Atom robot-at(robot2, tile_2_2)
Atom robot-at(robot2, tile_2_3)
Atom robot-at(robot2, tile_2_4)
Atom robot-at(robot2, tile_2_5)
Atom robot-at(robot2, tile_2_6)
Atom robot-at(robot2, tile_2_7)
Atom robot-at(robot2, tile_2_8)
Atom robot-at(robot2, tile_2_9)
Atom robot-at(robot2, tile_3_1)
Atom robot-at(robot2, tile_3_2)
Atom robot-at(robot2, tile_3_3)
Atom robot-at(robot2, tile_3_4)
Atom robot-at(robot2, tile_3_5)
Atom robot-at(robot2, tile_3_6)
Atom robot-at(robot2, tile_3_7)
Atom robot-at(robot2, tile_3_8)
Atom robot-at(robot2, tile_3_9)
end_variable
begin_variable
var27
-1
4
Atom clear(tile_3_1)
Atom painted(tile_3_1, black)
Atom painted(tile_3_1, white)
<none of those>
end_variable
begin_variable
var35
-1
4
Atom clear(tile_3_9)
Atom painted(tile_3_9, black)
Atom painted(tile_3_9, white)
<none of those>
end_variable
begin_variable
var9
-1
4
Atom clear(tile_1_1)
Atom painted(tile_1_1, black)
Atom painted(tile_1_1, white)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom clear(tile_2_1)
Atom painted(tile_2_1, black)
Atom painted(tile_2_1, white)
<none of those>
end_variable
begin_variable
var17
-1
4
Atom clear(tile_1_9)
Atom painted(tile_1_9, black)
Atom painted(tile_1_9, white)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom clear(tile_2_9)
Atom painted(tile_2_9, black)
Atom painted(tile_2_9, white)
<none of those>
end_variable
begin_variable
var28
-1
4
Atom clear(tile_3_2)
Atom painted(tile_3_2, black)
Atom painted(tile_3_2, white)
<none of those>
end_variable
begin_variable
var34
-1
4
Atom clear(tile_3_8)
Atom painted(tile_3_8, black)
Atom painted(tile_3_8, white)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom clear(tile_3_3)
Atom painted(tile_3_3, black)
Atom painted(tile_3_3, white)
<none of those>
end_variable
begin_variable
var33
-1
4
Atom clear(tile_3




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





1
11 12
3
225
1
12 12
8
0
16
2
34 0
11 21
0
43
2
34 0
12 21
0
76
2
31 0
11 21
0
108
2
31 0
12 21
0
141
2
39 0
11 21
0
173
2
39 0
12 21
0
207
2
23 0
11 21
0
234
2
23 0
12 21
8
0
16
2
34 0
11 21
0
43
2
34 0
12 21
0
76
2
31 0
11 21
0
108
2
31 0
12 21
0
141
2
39 0
11 21
0
173
2
39 0
12 21
0
207
2
23 0
11 21
0
234
2
23 0
12 21
8
0
16
2
34 0
11 21
0
43
2
34 0
12 21
0
76
2
31 0
11 21
0
108
2
31 0
12 21
0
141
2
39 0
11 21
0
173
2
39 0
12 21
0
207
2
23 0
11 21
0
234
2
23 0
12 21
end_DTG
begin_DTG
16
1
268
2
11 23
1 0
1
322
2
12 23
0 0
1
358
2
11 5
1 0
1
412
2
12 5
0 0
2
269
2
11 23
1 1
2
323
2
12 23
0 1
2
359
2
11 5
1 1
2
413
2
12 5
0 1
3
18
1
11 23
3
45
1
12 23
3
71
1
11 15
3
103
1
12 15
3
134
1
11 13
3
166
1
12 13
3
191
1
11 5
3
218
1
12 5
8
0
9
2
9 0
11 14
0
36
2
9 0
12 14
0
70
2
37 0
11 14
0
102
2
37 0
12 14
0
135
2
32 0
11 14
0
167
2
32 0
12 14
0
200
2
38 0
11 14
0
227
2
38 0
12 14
8
0
9
2
9 0
11 14
0
36
2
9 0
12 14
0
70
2
37 0
11 14
0
102
2
37 0
12 14
0
135
2
32 0
11 14
0
167
2
32 0
12 14
0
200
2
38 0
11 14
0
227
2
38 0
12 14
8
0
9
2
9 0
11 14
0
36
2
9 0
12 14
0
70
2
37 0
11 14
0
102
2
37 0
12 14
0
135
2
32 0
11 14
0
167
2
32 0
12 14
0
200
2
38 0
11 14
0
227
2
38 0
12 14
end_DTG
begin_DTG
16
1
266
2
11 22
1 0
1
320
2
12 22
0 0
1
356
2
11 4
1 0
1
410
2
12 4
0 0
2
267
2
11 22
1 1
2
321
2
12 22
0 1
2
357
2
11 4
1 1
2
411
2
12 4
0 1
3
17
1
11 22
3
44
1
12 22
3
70
1
11 14
3
102
1
12 14
3
133
1
11 12
3
165
1
12 12
3
190
1
11 4
3
217
1
12 4
8
0
8
2
10 0
11 13
0
35
2
10 0
12 13
0
69
2
34 0
11 13
0
101
2
34 0
12 13
0
134
2
36 0
11 13
0
166
2
36 0
12 13
0
199
2
39 0
11 13
0
226
2
39 0
12 13
8
0
8
2
10 0
11 13
0
35
2
10 0
12 13
0
69
2
34 0
11 13
0
101
2
34 0
12 13
0
134
2
36 0
11 13
0
166
2
36 0
12 13
0
199
2
39 0
11 13
0
226
2
39 0
12 13
8
0
8
2
10 0
11 13
0
35
2
10 0
12 13
0
69
2
34 0
11 13
0
101
2
34 0
12 13
0
134
2
36 0
11 13
0
166
2
36 0
12 13
0
199
2
39 0
11 13
0
226
2
39 0
12 13
end_DTG
begin_DTG
16
1
286
2
11 32
1 0
1
340
2
12 32
0 0
1
376
2
11 14
1 0
1
430
2
12 14
0 0
2
287
2
11 32
1 1
2
341
2
12 32
0 1
2
377
2
11 14
1 1
2
431
2
12 14
0 1
3
27
1
11 32
3
54
1
12 32
3
79
1
11 24
3
111
1
12 24
3
142
1
11 22
3
174
1
12 22
3
200
1
11 14
3
227
1
12 14
8
0
18
2
36 0
11 23
0
45
2
36 0
12 23
0
78
2
39 0
11 23
0
110
2
39 0
12 23
0
143
2
33 0
11 23
0
175
2
33 0
12 23
0
209
2
24 0
11 23
0
236
2
24 0
12 23
8
0
18
2
36 0
11 23
0
45
2
36 0
12 23
0
78
2
39 0
11 23
0
110
2
39 0
12 23
0
143
2
33 0
11 23
0
175
2
33 0
12 23
0
209
2
24 0
11 23
0
236
2
24 0
12 23
8
0
18
2
36 0
11 23
0
45
2
36 0
12 23
0
78
2
39 0
11 23
0
110
2
39 0
12 23
0
143
2
33 0
11 23
0
175
2
33 0
12 23
0
209
2
24 0
11 23
0
236
2
24 0
12 23
end_DTG
begin_DTG
16
1
284
2
11 31
1 0
1
338
2
12 31
0 0
1
374
2
11 13
1 0
1
428
2
12 13
0 0
2
285
2
11 31
1 1
2
339
2
12 31
0 1
2
375
2
11 13
1 1
2
429
2
12 13
0 1
3
26
1
11 31
3
53
1
12 31
3
78
1
11 23
3
110
1
12 23
3
141
1
11 21
3
173
1
12 21
3
199
1
11 13
3
226
1
12 13
8
0
17
2
37 0
11 22
0
44
2
37 0
12 22
0
77
2
35 0
11 22
0
109
2
35 0
12 22
0
142
2
38 0
11 22
0
174
2
38 0
12 22
0
208
2
25 0
11 22
0
235
2
25 0
12 22
8
0
17
2
37 0
11 22
0
44
2
37 0
12 22
0
77
2
35 0
11 22
0
109
2
35 0
12 22
0
142
2
38 0
11 22
0
174
2
38 0
12 22
0
208
2
25 0
11 22
0
235
2
25 0
12 22
8
0
17
2
37 0
11 22
0
44
2
37 0
12 22
0
77
2
35 0
11 22
0
109
2
35 0
12 22
0
142
2
38 0
11 22
0
174
2
38 0
12 22
0
208
2
25 0
11 22
0
235
2
25 0
12 22
end_DTG
begin_CG
36
2 2
4 2
6 2
8 2
10 2
9 2
7 2
5 2
3 2
15 4
26 4
30 4
34 4
37 4
36 4
32 4
28 4
17 4
16 4
27 4
31 4
35 4
39 4
38 4
33 4
29 4
18 4
13 2
19 2
21 2
23 2
25 2
24 2
22 2
20 2
14 2
36
2 2
4 2
6 2
8 2
10 2
9 2
7 2
5 2
3 2
15 4
26 4
30 4
34 4
37 4
36 4
32 4
28 4
17 4
16 4
27 4
31 4
35 4
39 4
38 4
33 4
29 4
18 4
13 2
19 2
21 2
23 2
25 2
24 2
22 2
20 2
14 2
4
4 2
15 2
11 2
12 2
4
5 2
17 2
11 2
12 2
5
2 2
6 2
26 2
11 3
12 3
5
7 2
3 2
28 2
11 3
12 3
5
4 2
8 2
30 2
11 3
12 3
5
9 2
5 2
32 2
11 3
12 3
5
6 2
10 2
34 2
11 3
12 3
5
10 2
7 2
36 2
11 3
12 3
5
8 2
9 2
37 2
11 3
12 3
36
2 6
4 8
6 8
8 8
10 8
9 8
7 8
5 8
3 6
15 10
26 12
30 12
34 12
37 12
36 12
32 12
28 12
17 10
16 10
27 12
31 12
35 12
39 12
38 12
33 12
29 12
18 10
13 6
19 8
21 8
23 8
25 8
24 8
22 8
20 8
14 6
36
2 6
4 8
6 8
8 8
10 8
9 8
7 8
5 8
3 6
15 10
26 12
30 12
34 12
37 12
36 12
32 12
28 12
17 10
16 10
27 12
31 12
35 12
39 12
38 12
33 12
29 12
18 10
13 6
19 8
21 8
23 8
25 8
24 8
22 8
20 8
14 6
4
16 2
19 2
11 2
12 2
4
18 2
20 2
11 2
12 2
5
2 2
26 2
16 2
11 3
12 3
5
15 2
27 2
13 2
11 3
12 3
5
3 2
28 2
18 2
11 3
12 3
5
17 2
29 2
14 2
11 3
12 3
5
27 2
13 2
21 2
11 3
12 3
5
29 2
22 2
14 2
11 3
12 3
5
31 2
19 2
23 2
11 3
12 3
5
33 2
24 2
20 2
11 3
12 3
5
35 2
21 2
25 2
11 3
12 3
5
38 2
25 2
22 2
11 3
12 3
5
39 2
23 2
24 2
11 3
12 3
6
4 2
15 2
30 2
27 2
11 4
12 4
6
26 2
16 2
31 2
19 2
11 4
12 4
6
5 2
32 2
17 2
29 2
11 4
12 4
6
28 2
33 2
18 2
20 2
11 4
12 4
6
6 2
26 2
34 2
31 2
11 4
12 4
6
30 2
27 2
35 2
21 2
11 4
12 4
6
7 2
36 2
28 2
33 2
11 4
12 4
6
32 2
38 2
29 2
22 2
11 4
12 4
6
8 2
30 2
37 2
35 2
11 4
12 4
6
34 2
31 2
39 2
23 2
11 4
12 4
6
9 2
37 2
32 2
38 2
11 4
12 4
6
10 2
34 2
36 2
39 2
11 4
12 4
6
36 2
39 2
33 2
24 2
11 4
12 4
6
37 2
35 2
38 2
25 2
11 4
12 4
end_CG
