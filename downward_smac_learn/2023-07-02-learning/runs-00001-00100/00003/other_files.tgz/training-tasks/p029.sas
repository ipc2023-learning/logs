begin_version
3
end_version
begin_metric
0
end_metric
6
begin_variable
var4
-1
7
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
end_variable
begin_variable
var5
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
8
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom on(car1)
end_variable
begin_variable
var1
-1
8
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom on(car2)
end_variable
begin_variable
var2
-1
8
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom on(car3)
end_variable
begin_variable
var3
-1
8
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom on(car4)
end_variable
1
begin_mutex_group
5
1 0
2 7
3 7
4 7
5 7
end_mutex_group
begin_state
1
0
0
5
3
0
end_state
begin_goal
4
2 2
3 2
4 6
5 1
end_goal
98
begin_operator
board car1 loc1
1
0 0
2
0 2 0 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc7
1
0 6
2
0 5 6 7
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc4
1
0 3
2
0 2 7 3
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc5
1
0 4
2
0 2 7 4
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc6
1
0 5
2
0 2 7 5
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc7
1
0 6
2
0 2 7 6
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc1
1
0 0
2
0 3 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc2
1
0 1
2
0 3 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc3
1
0 2
2
0 3 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc4
1
0 3
2
0 3 7 3
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc5
1
0 4
2
0 3 7 4
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc6
1
0 5
2
0 3 7 5
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc7
1
0 6
2
0 3 7 6
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc1
1
0 0
2
0 4 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc2
1
0 1
2
0 4 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc3
1
0 2
2
0 4 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc4
1
0 3
2
0 4 7 3
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc5
1
0 4
2
0 4 7 4
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc6
1
0 5
2
0 4 7 5
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc7
1
0 6
2
0 4 7 6
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc1
1
0 0
2
0 5 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc2
1
0 1
2
0 5 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc3
1
0 2
2
0 5 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc4
1
0 3
2
0 5 7 3
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc5
1
0 4
2
0 5 7 4
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc6
1
0 5
2
0 5 7 5
0 1 -1 0
0
end_operato




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




eck 0
switch 1
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
12
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
13
check 0
check 0
check 0
switch 0
check 0
check 1
35
check 1
36
check 1
37
check 1
38
check 1
39
check 1
40
check 1
41
check 0
switch 4
check 0
switch 0
check 0
switch 1
check 0
check 1
14
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
15
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
17
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
18
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
19
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
20
check 0
check 0
check 0
switch 0
check 0
check 1
42
check 1
43
check 1
44
check 1
45
check 1
46
check 1
47
check 1
48
check 0
switch 5
check 0
switch 0
check 0
switch 1
check 0
check 1
21
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
22
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
24
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
25
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
26
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
27
check 0
check 0
check 0
switch 0
check 0
check 1
49
check 1
50
check 1
51
check 1
52
check 1
53
check 1
54
check 1
55
check 0
switch 0
check 0
check 6
56
57
58
59
60
61
check 6
62
63
64
65
66
67
check 6
68
69
70
71
72
73
check 6
74
75
76
77
78
79
check 6
80
81
82
83
84
85
check 6
86
87
88
89
90
91
check 6
92
93
94
95
96
97
check 0
end_SG
begin_DTG
6
1
56
0
2
57
0
3
58
0
4
59
0
5
60
0
6
61
0
6
0
62
0
2
63
0
3
64
0
4
65
0
5
66
0
6
67
0
6
0
68
0
1
69
0
3
70
0
4
71
0
5
72
0
6
73
0
6
0
74
0
1
75
0
2
76
0
4
77
0
5
78
0
6
79
0
6
0
80
0
1
81
0
2
82
0
3
83
0
5
84
0
6
85
0
6
0
86
0
1
87
0
2
88
0
3
89
0
4
90
0
6
91
0
6
0
92
0
1
93
0
2
94
0
3
95
0
4
96
0
5
97
0
end_DTG
begin_DTG
28
1
14
2
4 0
0 0
1
27
2
5 6
0 6
1
26
2
5 5
0 5
1
25
2
5 4
0 4
1
24
2
5 3
0 3
1
23
2
5 2
0 2
1
22
2
5 1
0 1
1
21
2
5 0
0 0
1
20
2
4 6
0 6
1
19
2
4 5
0 5
1
18
2
4 4
0 4
1
17
2
4 3
0 3
1
16
2
4 2
0 2
1
15
2
4 1
0 1
1
0
2
2 0
0 0
1
13
2
3 6
0 6
1
12
2
3 5
0 5
1
11
2
3 4
0 4
1
10
2
3 3
0 3
1
9
2
3 2
0 2
1
8
2
3 1
0 1
1
7
2
3 0
0 0
1
6
2
2 6
0 6
1
5
2
2 5
0 5
1
4
2
2 4
0 4
1
3
2
2 3
0 3
1
2
2
2 2
0 2
1
1
2
2 1
0 1
28
0
42
2
4 7
0 0
0
55
2
5 7
0 6
0
54
2
5 7
0 5
0
53
2
5 7
0 4
0
52
2
5 7
0 3
0
51
2
5 7
0 2
0
50
2
5 7
0 1
0
49
2
5 7
0 0
0
48
2
4 7
0 6
0
47
2
4 7
0 5
0
46
2
4 7
0 4
0
45
2
4 7
0 3
0
44
2
4 7
0 2
0
43
2
4 7
0 1
0
28
2
2 7
0 0
0
41
2
3 7
0 6
0
40
2
3 7
0 5
0
39
2
3 7
0 4
0
38
2
3 7
0 3
0
37
2
3 7
0 2
0
36
2
3 7
0 1
0
35
2
3 7
0 0
0
34
2
2 7
0 6
0
33
2
2 7
0 5
0
32
2
2 7
0 4
0
31
2
2 7
0 3
0
30
2
2 7
0 2
0
29
2
2 7
0 1
end_DTG
begin_DTG
1
7
0
2
0 0
1 0
1
7
1
2
0 1
1 0
1
7
2
2
0 2
1 0
1
7
3
2
0 3
1 0
1
7
4
2
0 4
1 0
1
7
5
2
0 5
1 0
1
7
6
2
0 6
1 0
7
0
28
1
0 0
1
29
1
0 1
2
30
1
0 2
3
31
1
0 3
4
32
1
0 4
5
33
1
0 5
6
34
1
0 6
end_DTG
begin_DTG
1
7
7
2
0 0
1 0
1
7
8
2
0 1
1 0
1
7
9
2
0 2
1 0
1
7
10
2
0 3
1 0
1
7
11
2
0 4
1 0
1
7
12
2
0 5
1 0
1
7
13
2
0 6
1 0
7
0
35
1
0 0
1
36
1
0 1
2
37
1
0 2
3
38
1
0 3
4
39
1
0 4
5
40
1
0 5
6
41
1
0 6
end_DTG
begin_DTG
1
7
14
2
0 0
1 0
1
7
15
2
0 1
1 0
1
7
16
2
0 2
1 0
1
7
17
2
0 3
1 0
1
7
18
2
0 4
1 0
1
7
19
2
0 5
1 0
1
7
20
2
0 6
1 0
7
0
42
1
0 0
1
43
1
0 1
2
44
1
0 2
3
45
1
0 3
4
46
1
0 4
5
47
1
0 5
6
48
1
0 6
end_DTG
begin_DTG
1
7
21
2
0 0
1 0
1
7
22
2
0 1
1 0
1
7
23
2
0 2
1 0
1
7
24
2
0 3
1 0
1
7
25
2
0 4
1 0
1
7
26
2
0 5
1 0
1
7
27
2
0 6
1 0
7
0
49
1
0 0
1
50
1
0 1
2
51
1
0 2
3
52
1
0 3
4
53
1
0 4
5
54
1
0 5
6
55
1
0 6
end_DTG
begin_CG
5
2 14
3 14
4 14
5 14
1 56
4
2 7
3 7
4 7
5 7
1
1 14
1
1 14
1
1 14
1
1 14
end_CG
