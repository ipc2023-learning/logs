begin_version
3
end_version
begin_metric
0
end_metric
7
begin_variable
var5
-1
7
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
end_variable
begin_variable
var6
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
8
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom on(car1)
end_variable
begin_variable
var1
-1
8
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom on(car2)
end_variable
begin_variable
var2
-1
8
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom on(car3)
end_variable
begin_variable
var3
-1
8
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom on(car4)
end_variable
begin_variable
var4
-1
8
Atom at(car5, loc1)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom on(car5)
end_variable
1
begin_mutex_group
6
1 0
2 7
3 7
4 7
5 7
6 7
end_mutex_group
begin_state
4
0
1
0
6
1
3
end_state
begin_goal
5
2 3
3 6
4 2
5 2
6 5
end_goal
112
begin_operator
board car1 loc1
1
0 0
2
0 2 0 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc7
1
0 6
2
0 5 6 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc1
1
0 0
2
0 6 0 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc2
1
0 1
2
0 6 1 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc3
1
0 2
2
0 6 2 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc4
1
0 3
2
0 6 3 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc5
1
0 4
2
0 6 4 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc6
1
0 5
2
0 6 5 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc7
1
0 6
2
0 6 6 7
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc4
1
0 3
2
0 2 7 3
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc5
1
0 4
2
0 2 7 4
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc6
1
0 5
2
0 2 7 5
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc7
1
0 6
2
0 2 7 6
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc1
1
0 0
2
0 3 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc2
1
0 1
2
0 3 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc3
1
0 2
2
0 3 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc4
1
0 3
2
0 3 7 3
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc5
1
0 4
2
0 3 7 4
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc6
1
0 5
2
0 3 7 5
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc7
1
0 6
2
0 3 7 6
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc1
1
0 0
2
0 4 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc2
1
0 1
2
0 4 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc3
1
0 2
2
0 4 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
18
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
19
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
20
check 0
check 0
check 0
switch 0
check 0
check 1
49
check 1
50
check 1
51
check 1
52
check 1
53
check 1
54
check 1
55
check 0
switch 5
check 0
switch 0
check 0
switch 1
check 0
check 1
21
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
22
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
24
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
25
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
26
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
27
check 0
check 0
check 0
switch 0
check 0
check 1
56
check 1
57
check 1
58
check 1
59
check 1
60
check 1
61
check 1
62
check 0
switch 6
check 0
switch 0
check 0
switch 1
check 0
check 1
28
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
29
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
30
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
31
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
32
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
33
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
34
check 0
check 0
check 0
switch 0
check 0
check 1
63
check 1
64
check 1
65
check 1
66
check 1
67
check 1
68
check 1
69
check 0
switch 0
check 0
check 6
70
71
72
73
74
75
check 6
76
77
78
79
80
81
check 6
82
83
84
85
86
87
check 6
88
89
90
91
92
93
check 6
94
95
96
97
98
99
check 6
100
101
102
103
104
105
check 6
106
107
108
109
110
111
check 0
end_SG
begin_DTG
6
1
70
0
2
71
0
3
72
0
4
73
0
5
74
0
6
75
0
6
0
76
0
2
77
0
3
78
0
4
79
0
5
80
0
6
81
0
6
0
82
0
1
83
0
3
84
0
4
85
0
5
86
0
6
87
0
6
0
88
0
1
89
0
2
90
0
4
91
0
5
92
0
6
93
0
6
0
94
0
1
95
0
2
96
0
3
97
0
5
98
0
6
99
0
6
0
100
0
1
101
0
2
102
0
3
103
0
4
104
0
6
105
0
6
0
106
0
1
107
0
2
108
0
3
109
0
4
110
0
5
111
0
end_DTG
begin_DTG
35
1
26
2
5 5
0 5
1
18
2
4 4
0 4
1
19
2
4 5
0 5
1
20
2
4 6
0 6
1
21
2
5 0
0 0
1
22
2
5 1
0 1
1
23
2
5 2
0 2
1
24
2
5 3
0 3
1
25
2
5 4
0 4
1
17
2
4 3
0 3
1
27
2
5 6
0 6
1
28
2
6 0
0 0
1
29
2
6 1
0 1
1
30
2
6 2
0 2
1
31
2
6 3
0 3
1
32
2
6 4
0 4
1
33
2
6 5
0 5
1
34
2
6 6
0 6
1
9
2
3 2
0 2
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
2 3
0 3
1
4
2
2 4
0 4
1
5
2
2 5
0 5
1
6
2
2 6
0 6
1
7
2
3 0
0 0
1
8
2
3 1
0 1
1
0
2
2 0
0 0
1
10
2
3 3
0 3
1
11
2
3 4
0 4
1
12
2
3 5
0 5
1
13
2
3 6
0 6
1
14
2
4 0
0 0
1
15
2
4 1
0 1
1
16
2
4 2
0 2
35
0
61
2
5 7
0 5
0
53
2
4 7
0 4
0
54
2
4 7
0 5
0
55
2
4 7
0 6
0
56
2
5 7
0 0
0
57
2
5 7
0 1
0
58
2
5 7
0 2
0
59
2
5 7
0 3
0
60
2
5 7
0 4
0
52
2
4 7
0 3
0
62
2
5 7
0 6
0
63
2
6 7
0 0
0
64
2
6 7
0 1
0
65
2
6 7
0 2
0
66
2
6 7
0 3
0
67
2
6 7
0 4
0
68
2
6 7
0 5
0
69
2
6 7
0 6
0
44
2
3 7
0 2
0
36
2
2 7
0 1
0
37
2
2 7
0 2
0
38
2
2 7
0 3
0
39
2
2 7
0 4
0
40
2
2 7
0 5
0
41
2
2 7
0 6
0
42
2
3 7
0 0
0
43
2
3 7
0 1
0
35
2
2 7
0 0
0
45
2
3 7
0 3
0
46
2
3 7
0 4
0
47
2
3 7
0 5
0
48
2
3 7
0 6
0
49
2
4 7
0 0
0
50
2
4 7
0 1
0
51
2
4 7
0 2
end_DTG
begin_DTG
1
7
0
2
0 0
1 0
1
7
1
2
0 1
1 0
1
7
2
2
0 2
1 0
1
7
3
2
0 3
1 0
1
7
4
2
0 4
1 0
1
7
5
2
0 5
1 0
1
7
6
2
0 6
1 0
7
0
35
1
0 0
1
36
1
0 1
2
37
1
0 2
3
38
1
0 3
4
39
1
0 4
5
40
1
0 5
6
41
1
0 6
end_DTG
begin_DTG
1
7
7
2
0 0
1 0
1
7
8
2
0 1
1 0
1
7
9
2
0 2
1 0
1
7
10
2
0 3
1 0
1
7
11
2
0 4
1 0
1
7
12
2
0 5
1 0
1
7
13
2
0 6
1 0
7
0
42
1
0 0
1
43
1
0 1
2
44
1
0 2
3
45
1
0 3
4
46
1
0 4
5
47
1
0 5
6
48
1
0 6
end_DTG
begin_DTG
1
7
14
2
0 0
1 0
1
7
15
2
0 1
1 0
1
7
16
2
0 2
1 0
1
7
17
2
0 3
1 0
1
7
18
2
0 4
1 0
1
7
19
2
0 5
1 0
1
7
20
2
0 6
1 0
7
0
49
1
0 0
1
50
1
0 1
2
51
1
0 2
3
52
1
0 3
4
53
1
0 4
5
54
1
0 5
6
55
1
0 6
end_DTG
begin_DTG
1
7
21
2
0 0
1 0
1
7
22
2
0 1
1 0
1
7
23
2
0 2
1 0
1
7
24
2
0 3
1 0
1
7
25
2
0 4
1 0
1
7
26
2
0 5
1 0
1
7
27
2
0 6
1 0
7
0
56
1
0 0
1
57
1
0 1
2
58
1
0 2
3
59
1
0 3
4
60
1
0 4
5
61
1
0 5
6
62
1
0 6
end_DTG
begin_DTG
1
7
28
2
0 0
1 0
1
7
29
2
0 1
1 0
1
7
30
2
0 2
1 0
1
7
31
2
0 3
1 0
1
7
32
2
0 4
1 0
1
7
33
2
0 5
1 0
1
7
34
2
0 6
1 0
7
0
63
1
0 0
1
64
1
0 1
2
65
1
0 2
3
66
1
0 3
4
67
1
0 4
5
68
1
0 5
6
69
1
0 6
end_DTG
begin_CG
6
2 14
3 14
4 14
5 14
6 14
1 70
5
2 7
3 7
4 7
5 7
6 7
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
end_CG
