begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var16
-1
13
Atom at-ferry(loc1)
Atom at-ferry(loc10)
Atom at-ferry(loc11)
Atom at-ferry(loc12)
Atom at-ferry(loc13)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var17
-1
17
Atom empty-ferry()
Atom on(car1)
Atom on(car10)
Atom on(car11)
Atom on(car12)
Atom on(car13)
Atom on(car14)
Atom on(car15)
Atom on(car16)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
Atom on(car9)
end_variable
begin_variable
var0
-1
14
Atom at(car1, loc1)
Atom at(car1, loc10)
Atom at(car1, loc11)
Atom at(car1, loc12)
Atom at(car1, loc13)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
<none of those>
end_variable
begin_variable
var1
-1
14
Atom at(car10, loc1)
Atom at(car10, loc10)
Atom at(car10, loc11)
Atom at(car10, loc12)
Atom at(car10, loc13)
Atom at(car10, loc2)
Atom at(car10, loc3)
Atom at(car10, loc4)
Atom at(car10, loc5)
Atom at(car10, loc6)
Atom at(car10, loc7)
Atom at(car10, loc8)
Atom at(car10, loc9)
<none of those>
end_variable
begin_variable
var2
-1
14
Atom at(car11, loc1)
Atom at(car11, loc10)
Atom at(car11, loc11)
Atom at(car11, loc12)
Atom at(car11, loc13)
Atom at(car11, loc2)
Atom at(car11, loc3)
Atom at(car11, loc4)
Atom at(car11, loc5)
Atom at(car11, loc6)
Atom at(car11, loc7)
Atom at(car11, loc8)
Atom at(car11, loc9)
<none of those>
end_variable
begin_variable
var3
-1
14
Atom at(car12, loc1)
Atom at(car12, loc10)
Atom at(car12, loc11)
Atom at(car12, loc12)
Atom at(car12, loc13)
Atom at(car12, loc2)
Atom at(car12, loc3)
Atom at(car12, loc4)
Atom at(car12, loc5)
Atom at(car12, loc6)
Atom at(car12, loc7)
Atom at(car12, loc8)
Atom at(car12, loc9)
<none of those>
end_variable
begin_variable
var4
-1
14
Atom at(car13, loc1)
Atom at(car13, loc10)
Atom at(car13, loc11)
Atom at(car13, loc12)
Atom at(car13, loc13)
Atom at(car13, loc2)
Atom at(car13, loc3)
Atom at(car13, loc4)
Atom at(car13, loc5)
Atom at(car13, loc6)
Atom at(car13, loc7)
Atom at(car13, loc8)
Atom at(car13, loc9)
<none of those>
end_variable
begin_variable
var5
-1
14
Atom at(car14, loc1)
Atom at(car14, loc10)
Atom at(car14, loc11)
Atom at(car14, loc12)
Atom at(car14, loc13)
Atom at(car14, loc2)
Atom at(car14, loc3)
Atom at(car14, loc4)
Atom at(car14, loc5)
Atom at(car14, loc6)
Atom at(car14, loc7)
Atom at(car14, loc8)
Atom at(car14, loc9)
<none of those>
end_variable
begin_variable
var6
-1
14
Atom at(car15, loc1)
Atom at(car15, loc10)
Atom at(car15, loc11)
Atom at(car15, loc12)
Atom at(car15, loc13)
Atom at(car15, loc2)
Atom at(car15, loc3)
Atom at(car15, loc4)
Atom at(car15, loc5)
Atom at(car15, loc6)
Atom at(car15, loc7)
Atom at(car15, loc8)
Atom at(car15, loc9)
<none of those>
end_variable
begin_variable
var7
-1
14
Atom at(car16, loc1)
Atom at(car16, loc10)
Atom at(car16, loc11)
Atom at(car16, loc12)
Atom at(car16, loc13)
Atom at(car16, loc2)
Atom at(car16, loc3)
Atom at(car16, loc4)
Atom at(car16, loc5)
Atom at(car16, loc6)
Atom at(car16, loc7)
Atom at(car16, loc8)
Atom at(car16, loc9)
<none of those>
end_variable
begin_variable
var8
-1
14
Atom at(car2, loc1)
Atom at(car2, loc10)
Atom at(car2, loc11)
Atom at(car2, loc12)
Atom at(car2, loc13)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
<none of those>
end_variable
begin_variable
var9
-1
14
Atom at(car3, loc1)
Atom at(car3, loc10)
Atom at(car3, loc11)
Atom at(car3, loc12)
Atom at(car3, loc13)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
<none of those>
end_variable
begin_variable
var10
-1
14
Atom at(car4, loc1)
Atom at(car4, loc10)
Atom at(car4, loc11)
Atom at(car4, loc12)
Atom at(car4, loc13)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
<none of those>
end_variable
begin_variable
var11
-1
14
Atom at(car5, loc1)
Atom at(car5, loc10)
Atom at(car5, loc11)
Atom at(car5, loc12)
Atom at(car5, loc13)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom at(car5, loc9)
<none of those>
end_variable
begin_variable
var12
-1
14
Atom at(car6, loc1)
Atom at(car6, loc10)
Atom at(car6, loc11)
Atom at(car6, loc12)
Atom at(car6, loc13)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom at(car6, loc9)
<none of those>
end_variable
begin_variable
var13
-1
14
Atom at(car7, loc1)
Atom at(car7, loc10)
Atom at(car7, loc11)
Atom at(car7, loc12)
Atom at(car7, loc13)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 2
1 15
3
393
2
0 3
1 15
4
394
2
0 4
1 15
5
395
2
0 5
1 15
6
396
2
0 6
1 15
8
398
2
0 8
1 15
9
399
2
0 9
1 15
10
400
2
0 10
1 15
11
401
2
0 11
1 15
12
402
2
0 12
1 15
13
189
2
0 7
1 0
13
0
390
2
0 0
1 15
1
391
2
0 1
1 15
2
392
2
0 2
1 15
3
393
2
0 3
1 15
4
394
2
0 4
1 15
5
395
2
0 5
1 15
6
396
2
0 6
1 15
7
397
2
0 7
1 15
9
399
2
0 9
1 15
10
400
2
0 10
1 15
11
401
2
0 11
1 15
12
402
2
0 12
1 15
13
190
2
0 8
1 0
13
0
390
2
0 0
1 15
1
391
2
0 1
1 15
2
392
2
0 2
1 15
3
393
2
0 3
1 15
4
394
2
0 4
1 15
5
395
2
0 5
1 15
6
396
2
0 6
1 15
7
397
2
0 7
1 15
8
398
2
0 8
1 15
10
400
2
0 10
1 15
11
401
2
0 11
1 15
12
402
2
0 12
1 15
13
191
2
0 9
1 0
13
0
390
2
0 0
1 15
1
391
2
0 1
1 15
2
392
2
0 2
1 15
3
393
2
0 3
1 15
4
394
2
0 4
1 15
5
395
2
0 5
1 15
6
396
2
0 6
1 15
7
397
2
0 7
1 15
8
398
2
0 8
1 15
9
399
2
0 9
1 15
11
401
2
0 11
1 15
12
402
2
0 12
1 15
13
192
2
0 10
1 0
13
0
390
2
0 0
1 15
1
391
2
0 1
1 15
2
392
2
0 2
1 15
3
393
2
0 3
1 15
4
394
2
0 4
1 15
5
395
2
0 5
1 15
6
396
2
0 6
1 15
7
397
2
0 7
1 15
8
398
2
0 8
1 15
9
399
2
0 9
1 15
10
400
2
0 10
1 15
12
402
2
0 12
1 15
13
193
2
0 11
1 0
13
0
390
2
0 0
1 15
1
391
2
0 1
1 15
2
392
2
0 2
1 15
3
393
2
0 3
1 15
4
394
2
0 4
1 15
5
395
2
0 5
1 15
6
396
2
0 6
1 15
7
397
2
0 7
1 15
8
398
2
0 8
1 15
9
399
2
0 9
1 15
10
400
2
0 10
1 15
11
401
2
0 11
1 15
13
194
2
0 12
1 0
13
0
390
2
0 0
1 15
1
391
2
0 1
1 15
2
392
2
0 2
1 15
3
393
2
0 3
1 15
4
394
2
0 4
1 15
5
395
2
0 5
1 15
6
396
2
0 6
1 15
7
397
2
0 7
1 15
8
398
2
0 8
1 15
9
399
2
0 9
1 15
10
400
2
0 10
1 15
11
401
2
0 11
1 15
12
402
2
0 12
1 15
end_DTG
begin_DTG
13
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
195
2
0 0
1 0
13
0
403
2
0 0
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
196
2
0 1
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
197
2
0 2
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
198
2
0 3
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
199
2
0 4
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
200
2
0 5
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
201
2
0 6
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
202
2
0 7
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
203
2
0 8
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
204
2
0 9
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
13
205
2
0 10
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
12
415
2
0 12
1 16
13
206
2
0 11
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
13
207
2
0 12
1 0
13
0
403
2
0 0
1 16
1
404
2
0 1
1 16
2
405
2
0 2
1 16
3
406
2
0 3
1 16
4
407
2
0 4
1 16
5
408
2
0 5
1 16
6
409
2
0 6
1 16
7
410
2
0 7
1 16
8
411
2
0 8
1 16
9
412
2
0 9
1 16
10
413
2
0 10
1 16
11
414
2
0 11
1 16
12
415
2
0 12
1 16
end_DTG
begin_CG
17
2 26
3 26
4 26
5 26
6 26
7 26
8 26
9 26
10 26
11 26
12 26
13 26
14 26
15 26
16 26
17 26
1 416
16
2 26
3 26
4 26
5 26
6 26
7 26
8 26
9 26
10 26
11 26
12 26
13 26
14 26
15 26
16 26
17 26
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
1
1 13
end_CG
