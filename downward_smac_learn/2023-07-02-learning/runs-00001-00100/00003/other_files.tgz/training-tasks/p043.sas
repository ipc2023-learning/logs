begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var8
-1
8
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
end_variable
begin_variable
var9
-1
9
Atom empty-ferry()
Atom on(car1)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
end_variable
begin_variable
var0
-1
9
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
<none of those>
end_variable
begin_variable
var1
-1
9
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
<none of those>
end_variable
begin_variable
var2
-1
9
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
<none of those>
end_variable
begin_variable
var3
-1
9
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
<none of those>
end_variable
begin_variable
var4
-1
9
Atom at(car5, loc1)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
<none of those>
end_variable
begin_variable
var5
-1
9
Atom at(car6, loc1)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
<none of those>
end_variable
begin_variable
var6
-1
9
Atom at(car7, loc1)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
<none of those>
end_variable
begin_variable
var7
-1
9
Atom at(car8, loc1)
Atom at(car8, loc2)
Atom at(car8, loc3)
Atom at(car8, loc4)
Atom at(car8, loc5)
Atom at(car8, loc6)
Atom at(car8, loc7)
Atom at(car8, loc8)
<none of those>
end_variable
8
begin_mutex_group
9
2 0
2 1
2 2
2 3
2 4
2 5
2 6
2 7
1 1
end_mutex_group
begin_mutex_group
9
3 0
3 1
3 2
3 3
3 4
3 5
3 6
3 7
1 2
end_mutex_group
begin_mutex_group
9
4 0
4 1
4 2
4 3
4 4
4 5
4 6
4 7
1 3
end_mutex_group
begin_mutex_group
9
5 0
5 1
5 2
5 3
5 4
5 5
5 6
5 7
1 4
end_mutex_group
begin_mutex_group
9
6 0
6 1
6 2
6 3
6 4
6 5
6 6
6 7
1 5
end_mutex_group
begin_mutex_group
9
7 0
7 1
7 2
7 3
7 4
7 5
7 6
7 7
1 6
end_mutex_group
begin_mutex_group
9
8 0
8 1
8 2
8 3
8 4
8 5
8 6
8 7
1 7
end_mutex_group
begin_mutex_group
9
9 0
9 1
9 2
9 3
9 4
9 5
9 6
9 7
1 8
end_mutex_group
begin_state
4
0
1
7
2
7
4
1
7
6
end_state
begin_goal
8
2 5
3 4
4 1
5 3
6 0
7 0
8 2
9 3
end_goal
184
begin_operator
board car1 loc1
1
0 0
2
0 2 0 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc8
1
0 7
2
0 2 7 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 8
0 1 0 2
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 8
0 1 0 2
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 8
0 1 0 2
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 8
0 1 0 2
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 8
0 1 0 2
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 8
0 1 0 2
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 8
0 1 0 2
0
end_operator
begin_operator
board car2 loc8
1
0 7
2
0 3 7 8
0 1 0 2
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 8
0 1 0 3
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 8
0 1 0 3
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 8
0 1 0 3
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 8
0 1 0 3
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 8
0 1 0 3
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 8
0 1 0 3
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 8
0 1 0 3
0
end_operator
begin_operator
board car3 loc8
1
0 7
2
0 4 7 8
0 1 0 3
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 8
0 1 0 4
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 8
0 1 0 4
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 8
0 1 0 4
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 8
0 1 0 4
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 8
0 1 0 4
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 8
0 1 0 4
0
end_operator
begin_operator
board car4 loc7
1
0 6
2
0 5 6 8
0 1 0 4
0
end_operator
begin_operator
board car4 loc8
1
0 7
2
0 5 7 8
0 1 0 4
0
end_operator
begin_operator
board car5 loc1
1
0 0
2
0 6 0 8
0 1 0 5
0
end_opera




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





2
0 7
1 4
8
30
2
0 6
1 0
8
0
88
2
0 0
1 4
1
89
2
0 1
1 4
2
90
2
0 2
1 4
3
91
2
0 3
1 4
4
92
2
0 4
1 4
5
93
2
0 5
1 4
6
94
2
0 6
1 4
8
31
2
0 7
1 0
8
0
88
2
0 0
1 4
1
89
2
0 1
1 4
2
90
2
0 2
1 4
3
91
2
0 3
1 4
4
92
2
0 4
1 4
5
93
2
0 5
1 4
6
94
2
0 6
1 4
7
95
2
0 7
1 4
end_DTG
begin_DTG
8
1
97
2
0 1
1 5
2
98
2
0 2
1 5
3
99
2
0 3
1 5
4
100
2
0 4
1 5
5
101
2
0 5
1 5
6
102
2
0 6
1 5
7
103
2
0 7
1 5
8
32
2
0 0
1 0
8
0
96
2
0 0
1 5
2
98
2
0 2
1 5
3
99
2
0 3
1 5
4
100
2
0 4
1 5
5
101
2
0 5
1 5
6
102
2
0 6
1 5
7
103
2
0 7
1 5
8
33
2
0 1
1 0
8
0
96
2
0 0
1 5
1
97
2
0 1
1 5
3
99
2
0 3
1 5
4
100
2
0 4
1 5
5
101
2
0 5
1 5
6
102
2
0 6
1 5
7
103
2
0 7
1 5
8
34
2
0 2
1 0
8
0
96
2
0 0
1 5
1
97
2
0 1
1 5
2
98
2
0 2
1 5
4
100
2
0 4
1 5
5
101
2
0 5
1 5
6
102
2
0 6
1 5
7
103
2
0 7
1 5
8
35
2
0 3
1 0
8
0
96
2
0 0
1 5
1
97
2
0 1
1 5
2
98
2
0 2
1 5
3
99
2
0 3
1 5
5
101
2
0 5
1 5
6
102
2
0 6
1 5
7
103
2
0 7
1 5
8
36
2
0 4
1 0
8
0
96
2
0 0
1 5
1
97
2
0 1
1 5
2
98
2
0 2
1 5
3
99
2
0 3
1 5
4
100
2
0 4
1 5
6
102
2
0 6
1 5
7
103
2
0 7
1 5
8
37
2
0 5
1 0
8
0
96
2
0 0
1 5
1
97
2
0 1
1 5
2
98
2
0 2
1 5
3
99
2
0 3
1 5
4
100
2
0 4
1 5
5
101
2
0 5
1 5
7
103
2
0 7
1 5
8
38
2
0 6
1 0
8
0
96
2
0 0
1 5
1
97
2
0 1
1 5
2
98
2
0 2
1 5
3
99
2
0 3
1 5
4
100
2
0 4
1 5
5
101
2
0 5
1 5
6
102
2
0 6
1 5
8
39
2
0 7
1 0
8
0
96
2
0 0
1 5
1
97
2
0 1
1 5
2
98
2
0 2
1 5
3
99
2
0 3
1 5
4
100
2
0 4
1 5
5
101
2
0 5
1 5
6
102
2
0 6
1 5
7
103
2
0 7
1 5
end_DTG
begin_DTG
8
1
105
2
0 1
1 6
2
106
2
0 2
1 6
3
107
2
0 3
1 6
4
108
2
0 4
1 6
5
109
2
0 5
1 6
6
110
2
0 6
1 6
7
111
2
0 7
1 6
8
40
2
0 0
1 0
8
0
104
2
0 0
1 6
2
106
2
0 2
1 6
3
107
2
0 3
1 6
4
108
2
0 4
1 6
5
109
2
0 5
1 6
6
110
2
0 6
1 6
7
111
2
0 7
1 6
8
41
2
0 1
1 0
8
0
104
2
0 0
1 6
1
105
2
0 1
1 6
3
107
2
0 3
1 6
4
108
2
0 4
1 6
5
109
2
0 5
1 6
6
110
2
0 6
1 6
7
111
2
0 7
1 6
8
42
2
0 2
1 0
8
0
104
2
0 0
1 6
1
105
2
0 1
1 6
2
106
2
0 2
1 6
4
108
2
0 4
1 6
5
109
2
0 5
1 6
6
110
2
0 6
1 6
7
111
2
0 7
1 6
8
43
2
0 3
1 0
8
0
104
2
0 0
1 6
1
105
2
0 1
1 6
2
106
2
0 2
1 6
3
107
2
0 3
1 6
5
109
2
0 5
1 6
6
110
2
0 6
1 6
7
111
2
0 7
1 6
8
44
2
0 4
1 0
8
0
104
2
0 0
1 6
1
105
2
0 1
1 6
2
106
2
0 2
1 6
3
107
2
0 3
1 6
4
108
2
0 4
1 6
6
110
2
0 6
1 6
7
111
2
0 7
1 6
8
45
2
0 5
1 0
8
0
104
2
0 0
1 6
1
105
2
0 1
1 6
2
106
2
0 2
1 6
3
107
2
0 3
1 6
4
108
2
0 4
1 6
5
109
2
0 5
1 6
7
111
2
0 7
1 6
8
46
2
0 6
1 0
8
0
104
2
0 0
1 6
1
105
2
0 1
1 6
2
106
2
0 2
1 6
3
107
2
0 3
1 6
4
108
2
0 4
1 6
5
109
2
0 5
1 6
6
110
2
0 6
1 6
8
47
2
0 7
1 0
8
0
104
2
0 0
1 6
1
105
2
0 1
1 6
2
106
2
0 2
1 6
3
107
2
0 3
1 6
4
108
2
0 4
1 6
5
109
2
0 5
1 6
6
110
2
0 6
1 6
7
111
2
0 7
1 6
end_DTG
begin_DTG
8
1
113
2
0 1
1 7
2
114
2
0 2
1 7
3
115
2
0 3
1 7
4
116
2
0 4
1 7
5
117
2
0 5
1 7
6
118
2
0 6
1 7
7
119
2
0 7
1 7
8
48
2
0 0
1 0
8
0
112
2
0 0
1 7
2
114
2
0 2
1 7
3
115
2
0 3
1 7
4
116
2
0 4
1 7
5
117
2
0 5
1 7
6
118
2
0 6
1 7
7
119
2
0 7
1 7
8
49
2
0 1
1 0
8
0
112
2
0 0
1 7
1
113
2
0 1
1 7
3
115
2
0 3
1 7
4
116
2
0 4
1 7
5
117
2
0 5
1 7
6
118
2
0 6
1 7
7
119
2
0 7
1 7
8
50
2
0 2
1 0
8
0
112
2
0 0
1 7
1
113
2
0 1
1 7
2
114
2
0 2
1 7
4
116
2
0 4
1 7
5
117
2
0 5
1 7
6
118
2
0 6
1 7
7
119
2
0 7
1 7
8
51
2
0 3
1 0
8
0
112
2
0 0
1 7
1
113
2
0 1
1 7
2
114
2
0 2
1 7
3
115
2
0 3
1 7
5
117
2
0 5
1 7
6
118
2
0 6
1 7
7
119
2
0 7
1 7
8
52
2
0 4
1 0
8
0
112
2
0 0
1 7
1
113
2
0 1
1 7
2
114
2
0 2
1 7
3
115
2
0 3
1 7
4
116
2
0 4
1 7
6
118
2
0 6
1 7
7
119
2
0 7
1 7
8
53
2
0 5
1 0
8
0
112
2
0 0
1 7
1
113
2
0 1
1 7
2
114
2
0 2
1 7
3
115
2
0 3
1 7
4
116
2
0 4
1 7
5
117
2
0 5
1 7
7
119
2
0 7
1 7
8
54
2
0 6
1 0
8
0
112
2
0 0
1 7
1
113
2
0 1
1 7
2
114
2
0 2
1 7
3
115
2
0 3
1 7
4
116
2
0 4
1 7
5
117
2
0 5
1 7
6
118
2
0 6
1 7
8
55
2
0 7
1 0
8
0
112
2
0 0
1 7
1
113
2
0 1
1 7
2
114
2
0 2
1 7
3
115
2
0 3
1 7
4
116
2
0 4
1 7
5
117
2
0 5
1 7
6
118
2
0 6
1 7
7
119
2
0 7
1 7
end_DTG
begin_DTG
8
1
121
2
0 1
1 8
2
122
2
0 2
1 8
3
123
2
0 3
1 8
4
124
2
0 4
1 8
5
125
2
0 5
1 8
6
126
2
0 6
1 8
7
127
2
0 7
1 8
8
56
2
0 0
1 0
8
0
120
2
0 0
1 8
2
122
2
0 2
1 8
3
123
2
0 3
1 8
4
124
2
0 4
1 8
5
125
2
0 5
1 8
6
126
2
0 6
1 8
7
127
2
0 7
1 8
8
57
2
0 1
1 0
8
0
120
2
0 0
1 8
1
121
2
0 1
1 8
3
123
2
0 3
1 8
4
124
2
0 4
1 8
5
125
2
0 5
1 8
6
126
2
0 6
1 8
7
127
2
0 7
1 8
8
58
2
0 2
1 0
8
0
120
2
0 0
1 8
1
121
2
0 1
1 8
2
122
2
0 2
1 8
4
124
2
0 4
1 8
5
125
2
0 5
1 8
6
126
2
0 6
1 8
7
127
2
0 7
1 8
8
59
2
0 3
1 0
8
0
120
2
0 0
1 8
1
121
2
0 1
1 8
2
122
2
0 2
1 8
3
123
2
0 3
1 8
5
125
2
0 5
1 8
6
126
2
0 6
1 8
7
127
2
0 7
1 8
8
60
2
0 4
1 0
8
0
120
2
0 0
1 8
1
121
2
0 1
1 8
2
122
2
0 2
1 8
3
123
2
0 3
1 8
4
124
2
0 4
1 8
6
126
2
0 6
1 8
7
127
2
0 7
1 8
8
61
2
0 5
1 0
8
0
120
2
0 0
1 8
1
121
2
0 1
1 8
2
122
2
0 2
1 8
3
123
2
0 3
1 8
4
124
2
0 4
1 8
5
125
2
0 5
1 8
7
127
2
0 7
1 8
8
62
2
0 6
1 0
8
0
120
2
0 0
1 8
1
121
2
0 1
1 8
2
122
2
0 2
1 8
3
123
2
0 3
1 8
4
124
2
0 4
1 8
5
125
2
0 5
1 8
6
126
2
0 6
1 8
8
63
2
0 7
1 0
8
0
120
2
0 0
1 8
1
121
2
0 1
1 8
2
122
2
0 2
1 8
3
123
2
0 3
1 8
4
124
2
0 4
1 8
5
125
2
0 5
1 8
6
126
2
0 6
1 8
7
127
2
0 7
1 8
end_DTG
begin_CG
9
2 16
3 16
4 16
5 16
6 16
7 16
8 16
9 16
1 128
8
2 16
3 16
4 16
5 16
6 16
7 16
8 16
9 16
1
1 8
1
1 8
1
1 8
1
1 8
1
1 8
1
1 8
1
1 8
1
1 8
end_CG
