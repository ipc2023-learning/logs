begin_version
3
end_version
begin_metric
0
end_metric
4
begin_variable
var2
-1
3
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
end_variable
begin_variable
var3
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
4
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom on(car1)
end_variable
begin_variable
var1
-1
4
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom on(car2)
end_variable
1
begin_mutex_group
3
1 0
2 3
3 3
end_mutex_group
begin_state
1
0
2
2
end_state
begin_goal
2
2 1
3 0
end_goal
18
begin_operator
board car1 loc1
1
0 0
2
0 2 0 3
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 3
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 3
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 3
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 3
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 3
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 3 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 3 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 3 2
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc1
1
0 0
2
0 3 3 0
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc2
1
0 1
2
0 3 3 1
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc3
1
0 2
2
0 3 3 2
0 1 -1 0
0
end_operator
begin_operator
sail loc1 loc2
0
1
0 0 0 1
0
end_operator
begin_operator
sail loc1 loc3
0
1
0 0 0 2
0
end_operator
begin_operator
sail loc2 loc1
0
1
0 0 1 0
0
end_operator
begin_operator
sail loc2 loc3
0
1
0 0 1 2
0
end_operator
begin_operator
sail loc3 loc1
0
1
0 0 2 0
0
end_operator
begin_operator
sail loc3 loc2
0
1
0 0 2 1
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 1
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
1
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
2
check 0
check 0
check 0
switch 0
check 0
check 1
6
check 1
7
check 1
8
check 0
switch 3
check 0
switch 0
check 0
switch 1
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
check 0
switch 0
check 0
check 1
9
check 1
10
check 1
11
check 0
switch 0
check 0
check 2
12
13
check 2
14
15
check 2
16
17
check 0
end_SG
begin_DTG
2
1
12
0
2
13
0
2
0
14
0
2
15
0
2
0
16
0
1
17
0
end_DTG
begin_DTG
6
1
0
2
2 0
0 0
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
3 0
0 0
1
4
2
3 1
0 1
1
5
2
3 2
0 2
6
0
6
2
2 3
0 0
0
7
2
2 3
0 1
0
8
2
2 3
0 2
0
9
2
3 3
0 0
0
10
2
3 3
0 1
0
11
2
3 3
0 2
end_DTG
begin_DTG
1
3
0
2
0 0
1 0
1
3
1
2
0 1
1 0
1
3
2
2
0 2
1 0
3
0
6
1
0 0
1
7
1
0 1
2
8
1
0 2
end_DTG
begin_DTG
1
3
3
2
0 0
1 0
1
3
4
2
0 1
1 0
1
3
5
2
0 2
1 0
3
0
9
1
0 0
1
10
1
0 1
2
11
1
0 2
end_DTG
begin_CG
3
2 6
3 6
1 12
2
2 3
3 3
1
1 6
1
1 6
end_CG
