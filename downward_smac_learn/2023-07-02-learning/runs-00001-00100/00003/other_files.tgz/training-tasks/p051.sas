begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var9
-1
9
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var10
-1
10
Atom empty-ferry()
Atom on(car1)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
Atom on(car9)
end_variable
begin_variable
var0
-1
10
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
<none of those>
end_variable
begin_variable
var1
-1
10
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
<none of those>
end_variable
begin_variable
var2
-1
10
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
<none of those>
end_variable
begin_variable
var3
-1
10
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
<none of those>
end_variable
begin_variable
var4
-1
10
Atom at(car5, loc1)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom at(car5, loc9)
<none of those>
end_variable
begin_variable
var5
-1
10
Atom at(car6, loc1)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom at(car6, loc9)
<none of those>
end_variable
begin_variable
var6
-1
10
Atom at(car7, loc1)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
Atom at(car7, loc9)
<none of those>
end_variable
begin_variable
var7
-1
10
Atom at(car8, loc1)
Atom at(car8, loc2)
Atom at(car8, loc3)
Atom at(car8, loc4)
Atom at(car8, loc5)
Atom at(car8, loc6)
Atom at(car8, loc7)
Atom at(car8, loc8)
Atom at(car8, loc9)
<none of those>
end_variable
begin_variable
var8
-1
10
Atom at(car9, loc1)
Atom at(car9, loc2)
Atom at(car9, loc3)
Atom at(car9, loc4)
Atom at(car9, loc5)
Atom at(car9, loc6)
Atom at(car9, loc7)
Atom at(car9, loc8)
Atom at(car9, loc9)
<none of those>
end_variable
9
begin_mutex_group
10
2 0
2 1
2 2
2 3
2 4
2 5
2 6
2 7
2 8
1 1
end_mutex_group
begin_mutex_group
10
3 0
3 1
3 2
3 3
3 4
3 5
3 6
3 7
3 8
1 2
end_mutex_group
begin_mutex_group
10
4 0
4 1
4 2
4 3
4 4
4 5
4 6
4 7
4 8
1 3
end_mutex_group
begin_mutex_group
10
5 0
5 1
5 2
5 3
5 4
5 5
5 6
5 7
5 8
1 4
end_mutex_group
begin_mutex_group
10
6 0
6 1
6 2
6 3
6 4
6 5
6 6
6 7
6 8
1 5
end_mutex_group
begin_mutex_group
10
7 0
7 1
7 2
7 3
7 4
7 5
7 6
7 7
7 8
1 6
end_mutex_group
begin_mutex_group
10
8 0
8 1
8 2
8 3
8 4
8 5
8 6
8 7
8 8
1 7
end_mutex_group
begin_mutex_group
10
9 0
9 1
9 2
9 3
9 4
9 5
9 6
9 7
9 8
1 8
end_mutex_group
begin_mutex_group
10
10 0
10 1
10 2
10 3
10 4
10 5
10 6
10 7
10 8
1 9
end_mutex_group
begin_state
8
0
7
5
8
8
6
7
0
2
2
end_state
begin_goal
9
2 8
3 0
4 5
5 4
6 5
7 3
8 5
9 3
10 1
end_goal
234
begin_operator
board car1 loc1
1
0 0
2
0 2 0 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc8
1
0 7
2
0 2 7 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc9
1
0 8
2
0 2 8 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc8
1
0 7
2
0 3 7 9
0 1 0 2
0
end_operator
begin_operator
board car2 loc9
1
0 8
2
0 3 8 9
0 1 0 2
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 9
0 1 0 3
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 9
0 1 0 3
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 9
0 1 0 3
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 9
0 1 0 3
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 9
0 1 0 3
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 9
0 1 0 3
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 9
0 1 0 3




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





3
129
2
0 3
1 6
4
130
2
0 4
1 6
5
131
2
0 5
1 6
7
133
2
0 7
1 6
8
134
2
0 8
1 6
9
51
2
0 6
1 0
9
0
126
2
0 0
1 6
1
127
2
0 1
1 6
2
128
2
0 2
1 6
3
129
2
0 3
1 6
4
130
2
0 4
1 6
5
131
2
0 5
1 6
6
132
2
0 6
1 6
8
134
2
0 8
1 6
9
52
2
0 7
1 0
9
0
126
2
0 0
1 6
1
127
2
0 1
1 6
2
128
2
0 2
1 6
3
129
2
0 3
1 6
4
130
2
0 4
1 6
5
131
2
0 5
1 6
6
132
2
0 6
1 6
7
133
2
0 7
1 6
9
53
2
0 8
1 0
9
0
126
2
0 0
1 6
1
127
2
0 1
1 6
2
128
2
0 2
1 6
3
129
2
0 3
1 6
4
130
2
0 4
1 6
5
131
2
0 5
1 6
6
132
2
0 6
1 6
7
133
2
0 7
1 6
8
134
2
0 8
1 6
end_DTG
begin_DTG
9
1
136
2
0 1
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
9
54
2
0 0
1 0
9
0
135
2
0 0
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
9
55
2
0 1
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
9
56
2
0 2
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
2
137
2
0 2
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
9
57
2
0 3
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
9
58
2
0 4
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
9
59
2
0 5
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
9
60
2
0 6
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
8
143
2
0 8
1 7
9
61
2
0 7
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
9
62
2
0 8
1 0
9
0
135
2
0 0
1 7
1
136
2
0 1
1 7
2
137
2
0 2
1 7
3
138
2
0 3
1 7
4
139
2
0 4
1 7
5
140
2
0 5
1 7
6
141
2
0 6
1 7
7
142
2
0 7
1 7
8
143
2
0 8
1 7
end_DTG
begin_DTG
9
1
145
2
0 1
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
9
63
2
0 0
1 0
9
0
144
2
0 0
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
9
64
2
0 1
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
9
65
2
0 2
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
2
146
2
0 2
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
9
66
2
0 3
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
9
67
2
0 4
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
9
68
2
0 5
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
9
69
2
0 6
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
8
152
2
0 8
1 8
9
70
2
0 7
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
9
71
2
0 8
1 0
9
0
144
2
0 0
1 8
1
145
2
0 1
1 8
2
146
2
0 2
1 8
3
147
2
0 3
1 8
4
148
2
0 4
1 8
5
149
2
0 5
1 8
6
150
2
0 6
1 8
7
151
2
0 7
1 8
8
152
2
0 8
1 8
end_DTG
begin_DTG
9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
9
72
2
0 0
1 0
9
0
153
2
0 0
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
9
73
2
0 1
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
9
74
2
0 2
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
9
75
2
0 3
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
9
76
2
0 4
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
9
77
2
0 5
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
9
78
2
0 6
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
8
161
2
0 8
1 9
9
79
2
0 7
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
9
80
2
0 8
1 0
9
0
153
2
0 0
1 9
1
154
2
0 1
1 9
2
155
2
0 2
1 9
3
156
2
0 3
1 9
4
157
2
0 4
1 9
5
158
2
0 5
1 9
6
159
2
0 6
1 9
7
160
2
0 7
1 9
8
161
2
0 8
1 9
end_DTG
begin_CG
10
2 18
3 18
4 18
5 18
6 18
7 18
8 18
9 18
10 18
1 162
9
2 18
3 18
4 18
5 18
6 18
7 18
8 18
9 18
10 18
1
1 9
1
1 9
1
1 9
1
1 9
1
1 9
1
1 9
1
1 9
1
1 9
1
1 9
end_CG
