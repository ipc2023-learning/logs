begin_version
3
end_version
begin_metric
0
end_metric
4
begin_variable
var2
-1
6
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
end_variable
begin_variable
var3
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
7
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom on(car1)
end_variable
begin_variable
var1
-1
7
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom on(car2)
end_variable
1
begin_mutex_group
3
1 0
2 6
3 6
end_mutex_group
begin_state
3
0
2
2
end_state
begin_goal
2
2 1
3 4
end_goal
54
begin_operator
board car1 loc1
1
0 0
2
0 2 0 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 6
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 6 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 6 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 6 2
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc4
1
0 3
2
0 2 6 3
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc5
1
0 4
2
0 2 6 4
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc6
1
0 5
2
0 2 6 5
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc1
1
0 0
2
0 3 6 0
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc2
1
0 1
2
0 3 6 1
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc3
1
0 2
2
0 3 6 2
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc4
1
0 3
2
0 3 6 3
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc5
1
0 4
2
0 3 6 4
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc6
1
0 5
2
0 3 6 5
0 1 -1 0
0
end_operator
begin_operator
sail loc1 loc2
0
1
0 0 0 1
0
end_operator
begin_operator
sail loc1 loc3
0
1
0 0 0 2
0
end_operator
begin_operator
sail loc1 loc4
0
1
0 0 0 3
0
end_operator
begin_operator
sail loc1 loc5
0
1
0 0 0 4
0
end_operator
begin_operator
sail loc1 loc6
0
1
0 0 0 5
0
end_operator
begin_operator
sail loc2 loc1
0
1
0 0 1 0
0
end_operator
begin_operator
sail loc2 loc3
0
1
0 0 1 2
0
end_operator
begin_operator
sail loc2 loc4
0
1
0 0 1 3
0
end_operator
begin_operator
sail loc2 loc5
0
1
0 0 1 4
0
end_operator
begin_operator
sail loc2 loc6
0
1
0 0 1 5
0
end_operator
begin_operator
sail loc3 loc1
0
1
0 0 2 0
0
end_operator
begin_operator
sail loc3 loc2
0
1
0 0 2 1
0
end_operator
begin_operator
sail loc3 loc4
0
1
0 0 2 3
0
end_operator
begin_operator
sail loc3 loc5
0
1
0 0 2 4
0
end_operator
begin_operator
sail loc3 loc6
0
1
0 0 2 5
0
end_operator
begin_operator
sail loc4 loc1
0
1
0 0 3 0
0
end_operator
begin_operator
sail loc4 loc2
0
1
0 0 3 1
0
end_operator
begin_operator
sail loc4 loc3
0
1
0 0 3 2
0
end_operator
begin_operator
sail loc4 loc5
0
1
0 0 3 4
0
end_operator
begin_operator
sail loc4 loc6
0
1
0 0 3 5
0
end_operator
begin_operator
sail loc5 loc1
0
1
0 0 4 0
0
end_operator
begin_operator
sail loc5 loc2
0
1
0 0 4 1
0
end_operator
begin_operator
sail loc5 loc3
0
1
0 0 4 2
0
end_operator
begin_operator
sail loc5 loc4
0
1
0 0 4 3
0
end_operator
begin_operator
sail loc5 loc6
0
1
0 0 4 5
0
end_operator
begin_operator
sail loc6 loc1
0
1
0 0 5 0
0
end_operator
begin_operator
sail loc6 loc2
0
1
0 0 5 1
0
end_operator
begin_operator
sail loc6 loc3
0
1
0 0 5 2
0
end_operator
begin_operator
sail loc6 loc4
0
1
0 0 5 3
0
end_operator
begin_operator
sail loc6 loc5
0
1
0 0 5 4
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 1
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
check 0
switch 0
check 0
check 1
12
check 1
13
check 1
14
check 1
15
check 1
16
check 1
17
check 0
switch 3
check 0
switch 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
10
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
11
check 0
check 0
check 0
switch 0
check 0
check 1
18
check 1
19
check 1
20
check 1
21
check 1
22
check 1
23
check 0
switch 0
check 0
check 5
24
25
26
27
28
check 5
29
30
31
32
33
check 5
34
35
36
37
38
check 5
39
40
41
42
43
check 5
44
45
46
47
48
check 5
49
50
51
52
53
check 0
end_SG
begin_DTG
5
1
24
0
2
25
0
3
26
0
4
27
0
5
28
0
5
0
29
0
2
30
0
3
31
0
4
32
0
5
33
0
5
0
34
0
1
35
0
3
36
0
4
37
0
5
38
0
5
0
39
0
1
40
0
2
41
0
4
42
0
5
43
0
5
0
44
0
1
45
0
2
46
0
3
47
0
5
48
0
5
0
49
0
1
50
0
2
51
0
3
52
0
4
53
0
end_DTG
begin_DTG
12
1
0
2
2 0
0 0
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
2 3
0 3
1
4
2
2 4
0 4
1
5
2
2 5
0 5
1
6
2
3 0
0 0
1
7
2
3 1
0 1
1
8
2
3 2
0 2
1
9
2
3 3
0 3
1
10
2
3 4
0 4
1
11
2
3 5
0 5
12
0
12
2
2 6
0 0
0
13
2
2 6
0 1
0
14
2
2 6
0 2
0
15
2
2 6
0 3
0
16
2
2 6
0 4
0
17
2
2 6
0 5
0
18
2
3 6
0 0
0
19
2
3 6
0 1
0
20
2
3 6
0 2
0
21
2
3 6
0 3
0
22
2
3 6
0 4
0
23
2
3 6
0 5
end_DTG
begin_DTG
1
6
0
2
0 0
1 0
1
6
1
2
0 1
1 0
1
6
2
2
0 2
1 0
1
6
3
2
0 3
1 0
1
6
4
2
0 4
1 0
1
6
5
2
0 5
1 0
6
0
12
1
0 0
1
13
1
0 1
2
14
1
0 2
3
15
1
0 3
4
16
1
0 4
5
17
1
0 5
end_DTG
begin_DTG
1
6
6
2
0 0
1 0
1
6
7
2
0 1
1 0
1
6
8
2
0 2
1 0
1
6
9
2
0 3
1 0
1
6
10
2
0 4
1 0
1
6
11
2
0 5
1 0
6
0
18
1
0 0
1
19
1
0 1
2
20
1
0 2
3
21
1
0 3
4
22
1
0 4
5
23
1
0 5
end_DTG
begin_CG
3
2 12
3 12
1 24
2
2 6
3 6
1
1 12
1
1 12
end_CG
