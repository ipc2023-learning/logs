begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var17
-1
14
Atom at-ferry(loc1)
Atom at-ferry(loc10)
Atom at-ferry(loc11)
Atom at-ferry(loc12)
Atom at-ferry(loc13)
Atom at-ferry(loc14)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var18
-1
18
Atom empty-ferry()
Atom on(car1)
Atom on(car10)
Atom on(car11)
Atom on(car12)
Atom on(car13)
Atom on(car14)
Atom on(car15)
Atom on(car16)
Atom on(car17)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
Atom on(car9)
end_variable
begin_variable
var0
-1
15
Atom at(car1, loc1)
Atom at(car1, loc10)
Atom at(car1, loc11)
Atom at(car1, loc12)
Atom at(car1, loc13)
Atom at(car1, loc14)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
<none of those>
end_variable
begin_variable
var1
-1
15
Atom at(car10, loc1)
Atom at(car10, loc10)
Atom at(car10, loc11)
Atom at(car10, loc12)
Atom at(car10, loc13)
Atom at(car10, loc14)
Atom at(car10, loc2)
Atom at(car10, loc3)
Atom at(car10, loc4)
Atom at(car10, loc5)
Atom at(car10, loc6)
Atom at(car10, loc7)
Atom at(car10, loc8)
Atom at(car10, loc9)
<none of those>
end_variable
begin_variable
var2
-1
15
Atom at(car11, loc1)
Atom at(car11, loc10)
Atom at(car11, loc11)
Atom at(car11, loc12)
Atom at(car11, loc13)
Atom at(car11, loc14)
Atom at(car11, loc2)
Atom at(car11, loc3)
Atom at(car11, loc4)
Atom at(car11, loc5)
Atom at(car11, loc6)
Atom at(car11, loc7)
Atom at(car11, loc8)
Atom at(car11, loc9)
<none of those>
end_variable
begin_variable
var3
-1
15
Atom at(car12, loc1)
Atom at(car12, loc10)
Atom at(car12, loc11)
Atom at(car12, loc12)
Atom at(car12, loc13)
Atom at(car12, loc14)
Atom at(car12, loc2)
Atom at(car12, loc3)
Atom at(car12, loc4)
Atom at(car12, loc5)
Atom at(car12, loc6)
Atom at(car12, loc7)
Atom at(car12, loc8)
Atom at(car12, loc9)
<none of those>
end_variable
begin_variable
var4
-1
15
Atom at(car13, loc1)
Atom at(car13, loc10)
Atom at(car13, loc11)
Atom at(car13, loc12)
Atom at(car13, loc13)
Atom at(car13, loc14)
Atom at(car13, loc2)
Atom at(car13, loc3)
Atom at(car13, loc4)
Atom at(car13, loc5)
Atom at(car13, loc6)
Atom at(car13, loc7)
Atom at(car13, loc8)
Atom at(car13, loc9)
<none of those>
end_variable
begin_variable
var5
-1
15
Atom at(car14, loc1)
Atom at(car14, loc10)
Atom at(car14, loc11)
Atom at(car14, loc12)
Atom at(car14, loc13)
Atom at(car14, loc14)
Atom at(car14, loc2)
Atom at(car14, loc3)
Atom at(car14, loc4)
Atom at(car14, loc5)
Atom at(car14, loc6)
Atom at(car14, loc7)
Atom at(car14, loc8)
Atom at(car14, loc9)
<none of those>
end_variable
begin_variable
var6
-1
15
Atom at(car15, loc1)
Atom at(car15, loc10)
Atom at(car15, loc11)
Atom at(car15, loc12)
Atom at(car15, loc13)
Atom at(car15, loc14)
Atom at(car15, loc2)
Atom at(car15, loc3)
Atom at(car15, loc4)
Atom at(car15, loc5)
Atom at(car15, loc6)
Atom at(car15, loc7)
Atom at(car15, loc8)
Atom at(car15, loc9)
<none of those>
end_variable
begin_variable
var7
-1
15
Atom at(car16, loc1)
Atom at(car16, loc10)
Atom at(car16, loc11)
Atom at(car16, loc12)
Atom at(car16, loc13)
Atom at(car16, loc14)
Atom at(car16, loc2)
Atom at(car16, loc3)
Atom at(car16, loc4)
Atom at(car16, loc5)
Atom at(car16, loc6)
Atom at(car16, loc7)
Atom at(car16, loc8)
Atom at(car16, loc9)
<none of those>
end_variable
begin_variable
var8
-1
15
Atom at(car17, loc1)
Atom at(car17, loc10)
Atom at(car17, loc11)
Atom at(car17, loc12)
Atom at(car17, loc13)
Atom at(car17, loc14)
Atom at(car17, loc2)
Atom at(car17, loc3)
Atom at(car17, loc4)
Atom at(car17, loc5)
Atom at(car17, loc6)
Atom at(car17, loc7)
Atom at(car17, loc8)
Atom at(car17, loc9)
<none of those>
end_variable
begin_variable
var9
-1
15
Atom at(car2, loc1)
Atom at(car2, loc10)
Atom at(car2, loc11)
Atom at(car2, loc12)
Atom at(car2, loc13)
Atom at(car2, loc14)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
<none of those>
end_variable
begin_variable
var10
-1
15
Atom at(car3, loc1)
Atom at(car3, loc10)
Atom at(car3, loc11)
Atom at(car3, loc12)
Atom at(car3, loc13)
Atom at(car3, loc14)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
<none of those>
end_variable
begin_variable
var11
-1
15
Atom at(car4, loc1)
Atom at(car4, loc10)
Atom at(car4, loc11)
Atom at(car4, loc12)
Atom at(car4, loc13)
Atom at(car4, loc14)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
<none of those>
end_variable
begin_variable
var12
-1
15
Atom at(car5, loc1)
Atom at(car5, loc10)
Atom at(car5, loc11)
Atom at(car5, loc12)
Atom at(car5, loc13)
Atom at(car5, loc14)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





461
2
0 13
1 16
14
220
2
0 10
1 0
14
0
448
2
0 0
1 16
1
449
2
0 1
1 16
2
450
2
0 2
1 16
3
451
2
0 3
1 16
4
452
2
0 4
1 16
5
453
2
0 5
1 16
6
454
2
0 6
1 16
7
455
2
0 7
1 16
8
456
2
0 8
1 16
9
457
2
0 9
1 16
10
458
2
0 10
1 16
12
460
2
0 12
1 16
13
461
2
0 13
1 16
14
221
2
0 11
1 0
14
0
448
2
0 0
1 16
1
449
2
0 1
1 16
2
450
2
0 2
1 16
3
451
2
0 3
1 16
4
452
2
0 4
1 16
5
453
2
0 5
1 16
6
454
2
0 6
1 16
7
455
2
0 7
1 16
8
456
2
0 8
1 16
9
457
2
0 9
1 16
10
458
2
0 10
1 16
11
459
2
0 11
1 16
13
461
2
0 13
1 16
14
222
2
0 12
1 0
14
0
448
2
0 0
1 16
1
449
2
0 1
1 16
2
450
2
0 2
1 16
3
451
2
0 3
1 16
4
452
2
0 4
1 16
5
453
2
0 5
1 16
6
454
2
0 6
1 16
7
455
2
0 7
1 16
8
456
2
0 8
1 16
9
457
2
0 9
1 16
10
458
2
0 10
1 16
11
459
2
0 11
1 16
12
460
2
0 12
1 16
14
223
2
0 13
1 0
14
0
448
2
0 0
1 16
1
449
2
0 1
1 16
2
450
2
0 2
1 16
3
451
2
0 3
1 16
4
452
2
0 4
1 16
5
453
2
0 5
1 16
6
454
2
0 6
1 16
7
455
2
0 7
1 16
8
456
2
0 8
1 16
9
457
2
0 9
1 16
10
458
2
0 10
1 16
11
459
2
0 11
1 16
12
460
2
0 12
1 16
13
461
2
0 13
1 16
end_DTG
begin_DTG
14
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
224
2
0 0
1 0
14
0
462
2
0 0
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
225
2
0 1
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
226
2
0 2
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
227
2
0 3
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
228
2
0 4
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
229
2
0 5
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
230
2
0 6
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
231
2
0 7
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
232
2
0 8
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
233
2
0 9
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
234
2
0 10
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
14
235
2
0 11
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
13
475
2
0 13
1 17
14
236
2
0 12
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
14
237
2
0 13
1 0
14
0
462
2
0 0
1 17
1
463
2
0 1
1 17
2
464
2
0 2
1 17
3
465
2
0 3
1 17
4
466
2
0 4
1 17
5
467
2
0 5
1 17
6
468
2
0 6
1 17
7
469
2
0 7
1 17
8
470
2
0 8
1 17
9
471
2
0 9
1 17
10
472
2
0 10
1 17
11
473
2
0 11
1 17
12
474
2
0 12
1 17
13
475
2
0 13
1 17
end_DTG
begin_CG
18
2 28
3 28
4 28
5 28
6 28
7 28
8 28
9 28
10 28
11 28
12 28
13 28
14 28
15 28
16 28
17 28
18 28
1 476
17
2 28
3 28
4 28
5 28
6 28
7 28
8 28
9 28
10 28
11 28
12 28
13 28
14 28
15 28
16 28
17 28
18 28
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
end_CG
