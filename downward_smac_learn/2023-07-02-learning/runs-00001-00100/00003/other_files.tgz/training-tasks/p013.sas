begin_version
3
end_version
begin_metric
0
end_metric
3
begin_variable
var1
-1
5
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
end_variable
begin_variable
var2
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
6
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom on(car1)
end_variable
1
begin_mutex_group
2
1 0
2 5
end_mutex_group
begin_state
0
0
2
end_state
begin_goal
1
2 1
end_goal
30
begin_operator
board car1 loc1
1
0 0
2
0 2 0 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 5
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 5 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 5 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 5 2
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc4
1
0 3
2
0 2 5 3
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc5
1
0 4
2
0 2 5 4
0 1 -1 0
0
end_operator
begin_operator
sail loc1 loc2
0
1
0 0 0 1
0
end_operator
begin_operator
sail loc1 loc3
0
1
0 0 0 2
0
end_operator
begin_operator
sail loc1 loc4
0
1
0 0 0 3
0
end_operator
begin_operator
sail loc1 loc5
0
1
0 0 0 4
0
end_operator
begin_operator
sail loc2 loc1
0
1
0 0 1 0
0
end_operator
begin_operator
sail loc2 loc3
0
1
0 0 1 2
0
end_operator
begin_operator
sail loc2 loc4
0
1
0 0 1 3
0
end_operator
begin_operator
sail loc2 loc5
0
1
0 0 1 4
0
end_operator
begin_operator
sail loc3 loc1
0
1
0 0 2 0
0
end_operator
begin_operator
sail loc3 loc2
0
1
0 0 2 1
0
end_operator
begin_operator
sail loc3 loc4
0
1
0 0 2 3
0
end_operator
begin_operator
sail loc3 loc5
0
1
0 0 2 4
0
end_operator
begin_operator
sail loc4 loc1
0
1
0 0 3 0
0
end_operator
begin_operator
sail loc4 loc2
0
1
0 0 3 1
0
end_operator
begin_operator
sail loc4 loc3
0
1
0 0 3 2
0
end_operator
begin_operator
sail loc4 loc5
0
1
0 0 3 4
0
end_operator
begin_operator
sail loc5 loc1
0
1
0 0 4 0
0
end_operator
begin_operator
sail loc5 loc2
0
1
0 0 4 1
0
end_operator
begin_operator
sail loc5 loc3
0
1
0 0 4 2
0
end_operator
begin_operator
sail loc5 loc4
0
1
0 0 4 3
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 1
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
3
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
check 0
switch 0
check 0
check 1
5
check 1
6
check 1
7
check 1
8
check 1
9
check 0
switch 0
check 0
check 4
10
11
12
13
check 4
14
15
16
17
check 4
18
19
20
21
check 4
22
23
24
25
check 4
26
27
28
29
check 0
end_SG
begin_DTG
4
1
10
0
2
11
0
3
12
0
4
13
0
4
0
14
0
2
15
0
3
16
0
4
17
0
4
0
18
0
1
19
0
3
20
0
4
21
0
4
0
22
0
1
23
0
2
24
0
4
25
0
4
0
26
0
1
27
0
2
28
0
3
29
0
end_DTG
begin_DTG
5
1
0
2
2 0
0 0
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
2 3
0 3
1
4
2
2 4
0 4
5
0
5
2
2 5
0 0
0
6
2
2 5
0 1
0
7
2
2 5
0 2
0
8
2
2 5
0 3
0
9
2
2 5
0 4
end_DTG
begin_DTG
1
5
0
2
0 0
1 0
1
5
1
2
0 1
1 0
1
5
2
2
0 2
1 0
1
5
3
2
0 3
1 0
1
5
4
2
0 4
1 0
5
0
5
1
0 0
1
6
1
0 1
2
7
1
0 2
3
8
1
0 3
4
9
1
0 4
end_DTG
begin_CG
2
2 10
1 10
1
2 5
1
1 10
end_CG
