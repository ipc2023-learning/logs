begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var7
-1
8
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
end_variable
begin_variable
var8
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
9
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom on(car1)
end_variable
begin_variable
var1
-1
9
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom on(car2)
end_variable
begin_variable
var2
-1
9
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom on(car3)
end_variable
begin_variable
var3
-1
9
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom on(car4)
end_variable
begin_variable
var4
-1
9
Atom at(car5, loc1)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom on(car5)
end_variable
begin_variable
var5
-1
9
Atom at(car6, loc1)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom on(car6)
end_variable
begin_variable
var6
-1
9
Atom at(car7, loc1)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
Atom on(car7)
end_variable
1
begin_mutex_group
8
1 0
2 8
3 8
4 8
5 8
6 8
7 8
8 8
end_mutex_group
begin_state
1
0
2
5
5
4
2
5
3
end_state
begin_goal
7
2 4
3 1
4 6
5 0
6 6
7 7
8 1
end_goal
168
begin_operator
board car1 loc1
1
0 0
2
0 2 0 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc8
1
0 7
2
0 2 7 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc8
1
0 7
2
0 3 7 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc8
1
0 7
2
0 4 7 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc7
1
0 6
2
0 5 6 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc8
1
0 7
2
0 5 7 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc1
1
0 0
2
0 6 0 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc2
1
0 1
2
0 6 1 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc3
1
0 2
2
0 6 2 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc4
1
0 3
2
0 6 3 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc5
1
0 4
2
0 6 4 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc6
1
0 5
2
0 6 5 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc7
1
0 6
2
0 6 6 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc8
1
0 7
2
0 6 7 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc1
1
0 0
2
0 7 0 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc2
1
0 1
2
0 7 1 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc3
1
0 2
2
0 7 2 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc4
1
0 3
2
0 7 3 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc5
1
0 4
2
0 7 4 8
0 1 0 1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
51
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
52
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
53
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
54
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
55
check 0
check 0
check 0
switch 0
check 0
check 1
104
check 1
105
check 1
106
check 1
107
check 1
108
check 1
109
check 1
110
check 1
111
check 0
switch 0
check 0
check 7
112
113
114
115
116
117
118
check 7
119
120
121
122
123
124
125
check 7
126
127
128
129
130
131
132
check 7
133
134
135
136
137
138
139
check 7
140
141
142
143
144
145
146
check 7
147
148
149
150
151
152
153
check 7
154
155
156
157
158
159
160
check 7
161
162
163
164
165
166
167
check 0
end_SG
begin_DTG
7
1
112
0
2
113
0
3
114
0
4
115
0
5
116
0
6
117
0
7
118
0
7
0
119
0
2
120
0
3
121
0
4
122
0
5
123
0
6
124
0
7
125
0
7
0
126
0
1
127
0
3
128
0
4
129
0
5
130
0
6
131
0
7
132
0
7
0
133
0
1
134
0
2
135
0
4
136
0
5
137
0
6
138
0
7
139
0
7
0
140
0
1
141
0
2
142
0
3
143
0
5
144
0
6
145
0
7
146
0
7
0
147
0
1
148
0
2
149
0
3
150
0
4
151
0
6
152
0
7
153
0
7
0
154
0
1
155
0
2
156
0
3
157
0
4
158
0
5
159
0
7
160
0
7
0
161
0
1
162
0
2
163
0
3
164
0
4
165
0
5
166
0
6
167
0
end_DTG
begin_DTG
56
1
42
2
7 2
0 2
1
29
2
5 5
0 5
1
30
2
5 6
0 6
1
31
2
5 7
0 7
1
32
2
6 0
0 0
1
33
2
6 1
0 1
1
34
2
6 2
0 2
1
35
2
6 3
0 3
1
36
2
6 4
0 4
1
37
2
6 5
0 5
1
38
2
6 6
0 6
1
39
2
6 7
0 7
1
40
2
7 0
0 0
1
41
2
7 1
0 1
1
28
2
5 4
0 4
1
43
2
7 3
0 3
1
44
2
7 4
0 4
1
45
2
7 5
0 5
1
46
2
7 6
0 6
1
47
2
7 7
0 7
1
48
2
8 0
0 0
1
49
2
8 1
0 1
1
50
2
8 2
0 2
1
51
2
8 3
0 3
1
52
2
8 4
0 4
1
53
2
8 5
0 5
1
54
2
8 6
0 6
1
55
2
8 7
0 7
1
14
2
3 6
0 6
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
2 3
0 3
1
4
2
2 4
0 4
1
5
2
2 5
0 5
1
6
2
2 6
0 6
1
7
2
2 7
0 7
1
8
2
3 0
0 0
1
9
2
3 1
0 1
1
10
2
3 2
0 2
1
11
2
3 3
0 3
1
12
2
3 4
0 4
1
13
2
3 5
0 5
1
0
2
2 0
0 0
1
15
2
3 7
0 7
1
16
2
4 0
0 0
1
17
2
4 1
0 1
1
18
2
4 2
0 2
1
19
2
4 3
0 3
1
20
2
4 4
0 4
1
21
2
4 5
0 5
1
22
2
4 6
0 6
1
23
2
4 7
0 7
1
24
2
5 0
0 0
1
25
2
5 1
0 1
1
26
2
5 2
0 2
1
27
2
5 3
0 3
56
0
98
2
7 8
0 2
0
85
2
5 8
0 5
0
86
2
5 8
0 6
0
87
2
5 8
0 7
0
88
2
6 8
0 0
0
89
2
6 8
0 1
0
90
2
6 8
0 2
0
91
2
6 8
0 3
0
92
2
6 8
0 4
0
93
2
6 8
0 5
0
94
2
6 8
0 6
0
95
2
6 8
0 7
0
96
2
7 8
0 0
0
97
2
7 8
0 1
0
84
2
5 8
0 4
0
99
2
7 8
0 3
0
100
2
7 8
0 4
0
101
2
7 8
0 5
0
102
2
7 8
0 6
0
103
2
7 8
0 7
0
104
2
8 8
0 0
0
105
2
8 8
0 1
0
106
2
8 8
0 2
0
107
2
8 8
0 3
0
108
2
8 8
0 4
0
109
2
8 8
0 5
0
110
2
8 8
0 6
0
111
2
8 8
0 7
0
70
2
3 8
0 6
0
57
2
2 8
0 1
0
58
2
2 8
0 2
0
59
2
2 8
0 3
0
60
2
2 8
0 4
0
61
2
2 8
0 5
0
62
2
2 8
0 6
0
63
2
2 8
0 7
0
64
2
3 8
0 0
0
65
2
3 8
0 1
0
66
2
3 8
0 2
0
67
2
3 8
0 3
0
68
2
3 8
0 4
0
69
2
3 8
0 5
0
56
2
2 8
0 0
0
71
2
3 8
0 7
0
72
2
4 8
0 0
0
73
2
4 8
0 1
0
74
2
4 8
0 2
0
75
2
4 8
0 3
0
76
2
4 8
0 4
0
77
2
4 8
0 5
0
78
2
4 8
0 6
0
79
2
4 8
0 7
0
80
2
5 8
0 0
0
81
2
5 8
0 1
0
82
2
5 8
0 2
0
83
2
5 8
0 3
end_DTG
begin_DTG
1
8
0
2
0 0
1 0
1
8
1
2
0 1
1 0
1
8
2
2
0 2
1 0
1
8
3
2
0 3
1 0
1
8
4
2
0 4
1 0
1
8
5
2
0 5
1 0
1
8
6
2
0 6
1 0
1
8
7
2
0 7
1 0
8
0
56
1
0 0
1
57
1
0 1
2
58
1
0 2
3
59
1
0 3
4
60
1
0 4
5
61
1
0 5
6
62
1
0 6
7
63
1
0 7
end_DTG
begin_DTG
1
8
8
2
0 0
1 0
1
8
9
2
0 1
1 0
1
8
10
2
0 2
1 0
1
8
11
2
0 3
1 0
1
8
12
2
0 4
1 0
1
8
13
2
0 5
1 0
1
8
14
2
0 6
1 0
1
8
15
2
0 7
1 0
8
0
64
1
0 0
1
65
1
0 1
2
66
1
0 2
3
67
1
0 3
4
68
1
0 4
5
69
1
0 5
6
70
1
0 6
7
71
1
0 7
end_DTG
begin_DTG
1
8
16
2
0 0
1 0
1
8
17
2
0 1
1 0
1
8
18
2
0 2
1 0
1
8
19
2
0 3
1 0
1
8
20
2
0 4
1 0
1
8
21
2
0 5
1 0
1
8
22
2
0 6
1 0
1
8
23
2
0 7
1 0
8
0
72
1
0 0
1
73
1
0 1
2
74
1
0 2
3
75
1
0 3
4
76
1
0 4
5
77
1
0 5
6
78
1
0 6
7
79
1
0 7
end_DTG
begin_DTG
1
8
24
2
0 0
1 0
1
8
25
2
0 1
1 0
1
8
26
2
0 2
1 0
1
8
27
2
0 3
1 0
1
8
28
2
0 4
1 0
1
8
29
2
0 5
1 0
1
8
30
2
0 6
1 0
1
8
31
2
0 7
1 0
8
0
80
1
0 0
1
81
1
0 1
2
82
1
0 2
3
83
1
0 3
4
84
1
0 4
5
85
1
0 5
6
86
1
0 6
7
87
1
0 7
end_DTG
begin_DTG
1
8
32
2
0 0
1 0
1
8
33
2
0 1
1 0
1
8
34
2
0 2
1 0
1
8
35
2
0 3
1 0
1
8
36
2
0 4
1 0
1
8
37
2
0 5
1 0
1
8
38
2
0 6
1 0
1
8
39
2
0 7
1 0
8
0
88
1
0 0
1
89
1
0 1
2
90
1
0 2
3
91
1
0 3
4
92
1
0 4
5
93
1
0 5
6
94
1
0 6
7
95
1
0 7
end_DTG
begin_DTG
1
8
40
2
0 0
1 0
1
8
41
2
0 1
1 0
1
8
42
2
0 2
1 0
1
8
43
2
0 3
1 0
1
8
44
2
0 4
1 0
1
8
45
2
0 5
1 0
1
8
46
2
0 6
1 0
1
8
47
2
0 7
1 0
8
0
96
1
0 0
1
97
1
0 1
2
98
1
0 2
3
99
1
0 3
4
100
1
0 4
5
101
1
0 5
6
102
1
0 6
7
103
1
0 7
end_DTG
begin_DTG
1
8
48
2
0 0
1 0
1
8
49
2
0 1
1 0
1
8
50
2
0 2
1 0
1
8
51
2
0 3
1 0
1
8
52
2
0 4
1 0
1
8
53
2
0 5
1 0
1
8
54
2
0 6
1 0
1
8
55
2
0 7
1 0
8
0
104
1
0 0
1
105
1
0 1
2
106
1
0 2
3
107
1
0 3
4
108
1
0 4
5
109
1
0 5
6
110
1
0 6
7
111
1
0 7
end_DTG
begin_CG
8
2 16
3 16
4 16
5 16
6 16
7 16
8 16
1 112
7
2 8
3 8
4 8
5 8
6 8
7 8
8 8
1
1 16
1
1 16
1
1 16
1
1 16
1
1 16
1
1 16
1
1 16
end_CG
