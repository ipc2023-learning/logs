begin_version
3
end_version
begin_metric
0
end_metric
12
begin_variable
var10
-1
10
Atom at-ferry(loc1)
Atom at-ferry(loc10)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var11
-1
11
Atom empty-ferry()
Atom on(car1)
Atom on(car10)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
Atom on(car9)
end_variable
begin_variable
var0
-1
11
Atom at(car1, loc1)
Atom at(car1, loc10)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
<none of those>
end_variable
begin_variable
var1
-1
11
Atom at(car10, loc1)
Atom at(car10, loc10)
Atom at(car10, loc2)
Atom at(car10, loc3)
Atom at(car10, loc4)
Atom at(car10, loc5)
Atom at(car10, loc6)
Atom at(car10, loc7)
Atom at(car10, loc8)
Atom at(car10, loc9)
<none of those>
end_variable
begin_variable
var2
-1
11
Atom at(car2, loc1)
Atom at(car2, loc10)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
<none of those>
end_variable
begin_variable
var3
-1
11
Atom at(car3, loc1)
Atom at(car3, loc10)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
<none of those>
end_variable
begin_variable
var4
-1
11
Atom at(car4, loc1)
Atom at(car4, loc10)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
<none of those>
end_variable
begin_variable
var5
-1
11
Atom at(car5, loc1)
Atom at(car5, loc10)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom at(car5, loc9)
<none of those>
end_variable
begin_variable
var6
-1
11
Atom at(car6, loc1)
Atom at(car6, loc10)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom at(car6, loc9)
<none of those>
end_variable
begin_variable
var7
-1
11
Atom at(car7, loc1)
Atom at(car7, loc10)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
Atom at(car7, loc9)
<none of those>
end_variable
begin_variable
var8
-1
11
Atom at(car8, loc1)
Atom at(car8, loc10)
Atom at(car8, loc2)
Atom at(car8, loc3)
Atom at(car8, loc4)
Atom at(car8, loc5)
Atom at(car8, loc6)
Atom at(car8, loc7)
Atom at(car8, loc8)
Atom at(car8, loc9)
<none of those>
end_variable
begin_variable
var9
-1
11
Atom at(car9, loc1)
Atom at(car9, loc10)
Atom at(car9, loc2)
Atom at(car9, loc3)
Atom at(car9, loc4)
Atom at(car9, loc5)
Atom at(car9, loc6)
Atom at(car9, loc7)
Atom at(car9, loc8)
Atom at(car9, loc9)
<none of those>
end_variable
10
begin_mutex_group
11
2 0
2 1
2 2
2 3
2 4
2 5
2 6
2 7
2 8
2 9
1 1
end_mutex_group
begin_mutex_group
11
3 0
3 1
3 2
3 3
3 4
3 5
3 6
3 7
3 8
3 9
1 2
end_mutex_group
begin_mutex_group
11
4 0
4 1
4 2
4 3
4 4
4 5
4 6
4 7
4 8
4 9
1 3
end_mutex_group
begin_mutex_group
11
5 0
5 1
5 2
5 3
5 4
5 5
5 6
5 7
5 8
5 9
1 4
end_mutex_group
begin_mutex_group
11
6 0
6 1
6 2
6 3
6 4
6 5
6 6
6 7
6 8
6 9
1 5
end_mutex_group
begin_mutex_group
11
7 0
7 1
7 2
7 3
7 4
7 5
7 6
7 7
7 8
7 9
1 6
end_mutex_group
begin_mutex_group
11
8 0
8 1
8 2
8 3
8 4
8 5
8 6
8 7
8 8
8 9
1 7
end_mutex_group
begin_mutex_group
11
9 0
9 1
9 2
9 3
9 4
9 5
9 6
9 7
9 8
9 9
1 8
end_mutex_group
begin_mutex_group
11
10 0
10 1
10 2
10 3
10 4
10 5
10 6
10 7
10 8
10 9
1 9
end_mutex_group
begin_mutex_group
11
11 0
11 1
11 2
11 3
11 4
11 5
11 6
11 7
11 8
11 9
1 10
end_mutex_group
begin_state
4
0
1
7
2
6
4
4
8
6
1
4
end_state
begin_goal
10
2 9
3 8
4 1
5 4
6 9
7 8
8 2
9 0
10 9
11 2
end_goal
290
begin_operator
board car1 loc1
1
0 0
2
0 2 0 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc10
1
0 1
2
0 2 1 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 2
2
0 2 2 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 3
2
0 2 3 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 4
2
0 2 4 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 5
2
0 2 5 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 6
2
0 2 6 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 7
2
0 2 7 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc8
1
0 8
2
0 2 8 10
0 1 0 1
0
end_operator
begin_operator
board car1 loc9
1
0 9
2
0 2 9 10
0 1 0 1
0
end_operator
begin_operator
board car10 loc1
1
0 0
2
0 3 0 10
0 1 0 2
0
end_operator
begin_operator
board car10 loc10
1
0 1
2
0 3 1 10
0 1 0 2
0
end_operator
begin_operator
board car10 loc2
1
0 2
2
0 3 2 10
0 1 0 2
0
end_operator
begin_operator
board car10 loc3
1
0 3
2
0 3 3 10
0 1 0 2
0
end_operator
begin_operator
board car10 loc4
1
0 4
2
0 3 4 10
0 1 0 2
0
end_operator
begin_operator
board car10 loc5




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





178
2
0 8
1 8
9
179
2
0 9
1 8
10
73
2
0 3
1 0
10
0
170
2
0 0
1 8
1
171
2
0 1
1 8
2
172
2
0 2
1 8
3
173
2
0 3
1 8
5
175
2
0 5
1 8
6
176
2
0 6
1 8
7
177
2
0 7
1 8
8
178
2
0 8
1 8
9
179
2
0 9
1 8
10
74
2
0 4
1 0
10
0
170
2
0 0
1 8
1
171
2
0 1
1 8
2
172
2
0 2
1 8
3
173
2
0 3
1 8
4
174
2
0 4
1 8
6
176
2
0 6
1 8
7
177
2
0 7
1 8
8
178
2
0 8
1 8
9
179
2
0 9
1 8
10
75
2
0 5
1 0
10
0
170
2
0 0
1 8
1
171
2
0 1
1 8
2
172
2
0 2
1 8
3
173
2
0 3
1 8
4
174
2
0 4
1 8
5
175
2
0 5
1 8
7
177
2
0 7
1 8
8
178
2
0 8
1 8
9
179
2
0 9
1 8
10
76
2
0 6
1 0
10
0
170
2
0 0
1 8
1
171
2
0 1
1 8
2
172
2
0 2
1 8
3
173
2
0 3
1 8
4
174
2
0 4
1 8
5
175
2
0 5
1 8
6
176
2
0 6
1 8
8
178
2
0 8
1 8
9
179
2
0 9
1 8
10
77
2
0 7
1 0
10
0
170
2
0 0
1 8
1
171
2
0 1
1 8
2
172
2
0 2
1 8
3
173
2
0 3
1 8
4
174
2
0 4
1 8
5
175
2
0 5
1 8
6
176
2
0 6
1 8
7
177
2
0 7
1 8
9
179
2
0 9
1 8
10
78
2
0 8
1 0
10
0
170
2
0 0
1 8
1
171
2
0 1
1 8
2
172
2
0 2
1 8
3
173
2
0 3
1 8
4
174
2
0 4
1 8
5
175
2
0 5
1 8
6
176
2
0 6
1 8
7
177
2
0 7
1 8
8
178
2
0 8
1 8
10
79
2
0 9
1 0
10
0
170
2
0 0
1 8
1
171
2
0 1
1 8
2
172
2
0 2
1 8
3
173
2
0 3
1 8
4
174
2
0 4
1 8
5
175
2
0 5
1 8
6
176
2
0 6
1 8
7
177
2
0 7
1 8
8
178
2
0 8
1 8
9
179
2
0 9
1 8
end_DTG
begin_DTG
10
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
80
2
0 0
1 0
10
0
180
2
0 0
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
81
2
0 1
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
82
2
0 2
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
83
2
0 3
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
84
2
0 4
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
85
2
0 5
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
86
2
0 6
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
10
87
2
0 7
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
9
189
2
0 9
1 9
10
88
2
0 8
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
10
89
2
0 9
1 0
10
0
180
2
0 0
1 9
1
181
2
0 1
1 9
2
182
2
0 2
1 9
3
183
2
0 3
1 9
4
184
2
0 4
1 9
5
185
2
0 5
1 9
6
186
2
0 6
1 9
7
187
2
0 7
1 9
8
188
2
0 8
1 9
9
189
2
0 9
1 9
end_DTG
begin_DTG
10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
90
2
0 0
1 0
10
0
190
2
0 0
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
91
2
0 1
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
92
2
0 2
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
93
2
0 3
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
94
2
0 4
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
95
2
0 5
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
96
2
0 6
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
10
97
2
0 7
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
9
199
2
0 9
1 10
10
98
2
0 8
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
10
99
2
0 9
1 0
10
0
190
2
0 0
1 10
1
191
2
0 1
1 10
2
192
2
0 2
1 10
3
193
2
0 3
1 10
4
194
2
0 4
1 10
5
195
2
0 5
1 10
6
196
2
0 6
1 10
7
197
2
0 7
1 10
8
198
2
0 8
1 10
9
199
2
0 9
1 10
end_DTG
begin_CG
11
2 20
3 20
4 20
5 20
6 20
7 20
8 20
9 20
10 20
11 20
1 200
10
2 20
3 20
4 20
5 20
6 20
7 20
8 20
9 20
10 20
11 20
1
1 10
1
1 10
1
1 10
1
1 10
1
1 10
1
1 10
1
1 10
1
1 10
1
1 10
1
1 10
end_CG
