begin_version
3
end_version
begin_metric
0
end_metric
17
begin_variable
var15
-1
12
Atom at-ferry(loc1)
Atom at-ferry(loc10)
Atom at-ferry(loc11)
Atom at-ferry(loc12)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var16
-1
16
Atom empty-ferry()
Atom on(car1)
Atom on(car10)
Atom on(car11)
Atom on(car12)
Atom on(car13)
Atom on(car14)
Atom on(car15)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
Atom on(car9)
end_variable
begin_variable
var0
-1
13
Atom at(car1, loc1)
Atom at(car1, loc10)
Atom at(car1, loc11)
Atom at(car1, loc12)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
<none of those>
end_variable
begin_variable
var1
-1
13
Atom at(car10, loc1)
Atom at(car10, loc10)
Atom at(car10, loc11)
Atom at(car10, loc12)
Atom at(car10, loc2)
Atom at(car10, loc3)
Atom at(car10, loc4)
Atom at(car10, loc5)
Atom at(car10, loc6)
Atom at(car10, loc7)
Atom at(car10, loc8)
Atom at(car10, loc9)
<none of those>
end_variable
begin_variable
var2
-1
13
Atom at(car11, loc1)
Atom at(car11, loc10)
Atom at(car11, loc11)
Atom at(car11, loc12)
Atom at(car11, loc2)
Atom at(car11, loc3)
Atom at(car11, loc4)
Atom at(car11, loc5)
Atom at(car11, loc6)
Atom at(car11, loc7)
Atom at(car11, loc8)
Atom at(car11, loc9)
<none of those>
end_variable
begin_variable
var3
-1
13
Atom at(car12, loc1)
Atom at(car12, loc10)
Atom at(car12, loc11)
Atom at(car12, loc12)
Atom at(car12, loc2)
Atom at(car12, loc3)
Atom at(car12, loc4)
Atom at(car12, loc5)
Atom at(car12, loc6)
Atom at(car12, loc7)
Atom at(car12, loc8)
Atom at(car12, loc9)
<none of those>
end_variable
begin_variable
var4
-1
13
Atom at(car13, loc1)
Atom at(car13, loc10)
Atom at(car13, loc11)
Atom at(car13, loc12)
Atom at(car13, loc2)
Atom at(car13, loc3)
Atom at(car13, loc4)
Atom at(car13, loc5)
Atom at(car13, loc6)
Atom at(car13, loc7)
Atom at(car13, loc8)
Atom at(car13, loc9)
<none of those>
end_variable
begin_variable
var5
-1
13
Atom at(car14, loc1)
Atom at(car14, loc10)
Atom at(car14, loc11)
Atom at(car14, loc12)
Atom at(car14, loc2)
Atom at(car14, loc3)
Atom at(car14, loc4)
Atom at(car14, loc5)
Atom at(car14, loc6)
Atom at(car14, loc7)
Atom at(car14, loc8)
Atom at(car14, loc9)
<none of those>
end_variable
begin_variable
var6
-1
13
Atom at(car15, loc1)
Atom at(car15, loc10)
Atom at(car15, loc11)
Atom at(car15, loc12)
Atom at(car15, loc2)
Atom at(car15, loc3)
Atom at(car15, loc4)
Atom at(car15, loc5)
Atom at(car15, loc6)
Atom at(car15, loc7)
Atom at(car15, loc8)
Atom at(car15, loc9)
<none of those>
end_variable
begin_variable
var7
-1
13
Atom at(car2, loc1)
Atom at(car2, loc10)
Atom at(car2, loc11)
Atom at(car2, loc12)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
<none of those>
end_variable
begin_variable
var8
-1
13
Atom at(car3, loc1)
Atom at(car3, loc10)
Atom at(car3, loc11)
Atom at(car3, loc12)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
<none of those>
end_variable
begin_variable
var9
-1
13
Atom at(car4, loc1)
Atom at(car4, loc10)
Atom at(car4, loc11)
Atom at(car4, loc12)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
<none of those>
end_variable
begin_variable
var10
-1
13
Atom at(car5, loc1)
Atom at(car5, loc10)
Atom at(car5, loc11)
Atom at(car5, loc12)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom at(car5, loc9)
<none of those>
end_variable
begin_variable
var11
-1
13
Atom at(car6, loc1)
Atom at(car6, loc10)
Atom at(car6, loc11)
Atom at(car6, loc12)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom at(car6, loc9)
<none of those>
end_variable
begin_variable
var12
-1
13
Atom at(car7, loc1)
Atom at(car7, loc10)
Atom at(car7, loc11)
Atom at(car7, loc12)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
Atom at(car7, loc9)
<none of those>
end_variable
begin_variable
var13
-1
13
Atom at(car8, loc1)
Atom at(car8, loc10)
Atom at(car8, loc11)
Atom at(car8, loc12)
Atom at(car8, loc2)
Atom at(car8, loc3)
Atom at(car8, loc4)
Atom at(car8, loc5)
Atom at(car8, loc6)
Atom at(car8, loc7)
Atom at(car8, loc8)
Atom at(car8, loc9)
<none of those>
end_variable
begin_variable
var14
-1
13
Atom at(car9, loc1)
Atom at(car9, loc10)
Atom at(car9, loc11)
Atom at(car9, loc12)
Atom at(car9, loc2)
Atom at(car9, loc3)
Atom at(car9, loc4)
Atom at(car9, loc5)
Atom at(car9, loc6)
Atom at(car9, loc7)
Atom at(car9, loc8)
Atom at




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




4
4
340
2
0 4
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
12
159
2
0 3
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
12
160
2
0 4
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
12
161
2
0 5
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
5
341
2
0 5
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
12
162
2
0 6
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
12
163
2
0 7
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
12
164
2
0 8
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
12
165
2
0 9
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
11
347
2
0 11
1 14
12
166
2
0 10
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
12
167
2
0 11
1 0
12
0
336
2
0 0
1 14
1
337
2
0 1
1 14
2
338
2
0 2
1 14
3
339
2
0 3
1 14
4
340
2
0 4
1 14
5
341
2
0 5
1 14
6
342
2
0 6
1 14
7
343
2
0 7
1 14
8
344
2
0 8
1 14
9
345
2
0 9
1 14
10
346
2
0 10
1 14
11
347
2
0 11
1 14
end_DTG
begin_DTG
12
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
168
2
0 0
1 0
12
0
348
2
0 0
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
169
2
0 1
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
170
2
0 2
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
171
2
0 3
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
172
2
0 4
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
173
2
0 5
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
174
2
0 6
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
175
2
0 7
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
176
2
0 8
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
12
177
2
0 9
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
11
359
2
0 11
1 15
12
178
2
0 10
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
12
179
2
0 11
1 0
12
0
348
2
0 0
1 15
1
349
2
0 1
1 15
2
350
2
0 2
1 15
3
351
2
0 3
1 15
4
352
2
0 4
1 15
5
353
2
0 5
1 15
6
354
2
0 6
1 15
7
355
2
0 7
1 15
8
356
2
0 8
1 15
9
357
2
0 9
1 15
10
358
2
0 10
1 15
11
359
2
0 11
1 15
end_DTG
begin_CG
16
2 24
3 24
4 24
5 24
6 24
7 24
8 24
9 24
10 24
11 24
12 24
13 24
14 24
15 24
16 24
1 360
15
2 24
3 24
4 24
5 24
6 24
7 24
8 24
9 24
10 24
11 24
12 24
13 24
14 24
15 24
16 24
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
end_CG
