begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var6
-1
7
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
end_variable
begin_variable
var7
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
8
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom on(car1)
end_variable
begin_variable
var1
-1
8
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom on(car2)
end_variable
begin_variable
var2
-1
8
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom on(car3)
end_variable
begin_variable
var3
-1
8
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom on(car4)
end_variable
begin_variable
var4
-1
8
Atom at(car5, loc1)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom on(car5)
end_variable
begin_variable
var5
-1
8
Atom at(car6, loc1)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom on(car6)
end_variable
1
begin_mutex_group
7
1 0
2 7
3 7
4 7
5 7
6 7
7 7
end_mutex_group
begin_state
3
0
2
2
4
6
1
3
end_state
begin_goal
6
2 4
3 5
4 3
5 4
6 3
7 6
end_goal
126
begin_operator
board car1 loc1
1
0 0
2
0 2 0 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 7
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 7
0 1 0 1
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 7
0 1 0 1
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 7
0 1 0 1
0
end_operator
begin_operator
board car4 loc7
1
0 6
2
0 5 6 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc1
1
0 0
2
0 6 0 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc2
1
0 1
2
0 6 1 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc3
1
0 2
2
0 6 2 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc4
1
0 3
2
0 6 3 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc5
1
0 4
2
0 6 4 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc6
1
0 5
2
0 6 5 7
0 1 0 1
0
end_operator
begin_operator
board car5 loc7
1
0 6
2
0 6 6 7
0 1 0 1
0
end_operator
begin_operator
board car6 loc1
1
0 0
2
0 7 0 7
0 1 0 1
0
end_operator
begin_operator
board car6 loc2
1
0 1
2
0 7 1 7
0 1 0 1
0
end_operator
begin_operator
board car6 loc3
1
0 2
2
0 7 2 7
0 1 0 1
0
end_operator
begin_operator
board car6 loc4
1
0 3
2
0 7 3 7
0 1 0 1
0
end_operator
begin_operator
board car6 loc5
1
0 4
2
0 7 4 7
0 1 0 1
0
end_operator
begin_operator
board car6 loc6
1
0 5
2
0 7 5 7
0 1 0 1
0
end_operator
begin_operator
board car6 loc7
1
0 6
2
0 7 6 7
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 7 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 7 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 7 2
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc4
1
0 3
2
0 2 7 3
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc5
1
0 4
2
0 2 7 4
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc6
1
0 5
2
0 2 7 5
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc7
1
0 6
2
0 2 7 6
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc1
1
0 0
2
0 3 7 0
0 1 -




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 0
switch 1
check 0
check 1
28
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
29
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
30
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
31
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
32
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
33
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
34
check 0
check 0
check 0
switch 0
check 0
check 1
70
check 1
71
check 1
72
check 1
73
check 1
74
check 1
75
check 1
76
check 0
switch 7
check 0
switch 0
check 0
switch 1
check 0
check 1
35
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
36
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
37
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
38
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
39
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
40
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
41
check 0
check 0
check 0
switch 0
check 0
check 1
77
check 1
78
check 1
79
check 1
80
check 1
81
check 1
82
check 1
83
check 0
switch 0
check 0
check 6
84
85
86
87
88
89
check 6
90
91
92
93
94
95
check 6
96
97
98
99
100
101
check 6
102
103
104
105
106
107
check 6
108
109
110
111
112
113
check 6
114
115
116
117
118
119
check 6
120
121
122
123
124
125
check 0
end_SG
begin_DTG
6
1
84
0
2
85
0
3
86
0
4
87
0
5
88
0
6
89
0
6
0
90
0
2
91
0
3
92
0
4
93
0
5
94
0
6
95
0
6
0
96
0
1
97
0
3
98
0
4
99
0
5
100
0
6
101
0
6
0
102
0
1
103
0
2
104
0
4
105
0
5
106
0
6
107
0
6
0
108
0
1
109
0
2
110
0
3
111
0
5
112
0
6
113
0
6
0
114
0
1
115
0
2
116
0
3
117
0
4
118
0
6
119
0
6
0
120
0
1
121
0
2
122
0
3
123
0
4
124
0
5
125
0
end_DTG
begin_DTG
42
1
32
2
6 4
0 4
1
22
2
5 1
0 1
1
23
2
5 2
0 2
1
24
2
5 3
0 3
1
25
2
5 4
0 4
1
26
2
5 5
0 5
1
27
2
5 6
0 6
1
28
2
6 0
0 0
1
29
2
6 1
0 1
1
30
2
6 2
0 2
1
31
2
6 3
0 3
1
21
2
5 0
0 0
1
33
2
6 5
0 5
1
34
2
6 6
0 6
1
35
2
7 0
0 0
1
36
2
7 1
0 1
1
37
2
7 2
0 2
1
38
2
7 3
0 3
1
39
2
7 4
0 4
1
40
2
7 5
0 5
1
41
2
7 6
0 6
1
11
2
3 4
0 4
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
2 3
0 3
1
4
2
2 4
0 4
1
5
2
2 5
0 5
1
6
2
2 6
0 6
1
7
2
3 0
0 0
1
8
2
3 1
0 1
1
9
2
3 2
0 2
1
10
2
3 3
0 3
1
0
2
2 0
0 0
1
12
2
3 5
0 5
1
13
2
3 6
0 6
1
14
2
4 0
0 0
1
15
2
4 1
0 1
1
16
2
4 2
0 2
1
17
2
4 3
0 3
1
18
2
4 4
0 4
1
19
2
4 5
0 5
1
20
2
4 6
0 6
42
0
74
2
6 7
0 4
0
64
2
5 7
0 1
0
65
2
5 7
0 2
0
66
2
5 7
0 3
0
67
2
5 7
0 4
0
68
2
5 7
0 5
0
69
2
5 7
0 6
0
70
2
6 7
0 0
0
71
2
6 7
0 1
0
72
2
6 7
0 2
0
73
2
6 7
0 3
0
63
2
5 7
0 0
0
75
2
6 7
0 5
0
76
2
6 7
0 6
0
77
2
7 7
0 0
0
78
2
7 7
0 1
0
79
2
7 7
0 2
0
80
2
7 7
0 3
0
81
2
7 7
0 4
0
82
2
7 7
0 5
0
83
2
7 7
0 6
0
53
2
3 7
0 4
0
43
2
2 7
0 1
0
44
2
2 7
0 2
0
45
2
2 7
0 3
0
46
2
2 7
0 4
0
47
2
2 7
0 5
0
48
2
2 7
0 6
0
49
2
3 7
0 0
0
50
2
3 7
0 1
0
51
2
3 7
0 2
0
52
2
3 7
0 3
0
42
2
2 7
0 0
0
54
2
3 7
0 5
0
55
2
3 7
0 6
0
56
2
4 7
0 0
0
57
2
4 7
0 1
0
58
2
4 7
0 2
0
59
2
4 7
0 3
0
60
2
4 7
0 4
0
61
2
4 7
0 5
0
62
2
4 7
0 6
end_DTG
begin_DTG
1
7
0
2
0 0
1 0
1
7
1
2
0 1
1 0
1
7
2
2
0 2
1 0
1
7
3
2
0 3
1 0
1
7
4
2
0 4
1 0
1
7
5
2
0 5
1 0
1
7
6
2
0 6
1 0
7
0
42
1
0 0
1
43
1
0 1
2
44
1
0 2
3
45
1
0 3
4
46
1
0 4
5
47
1
0 5
6
48
1
0 6
end_DTG
begin_DTG
1
7
7
2
0 0
1 0
1
7
8
2
0 1
1 0
1
7
9
2
0 2
1 0
1
7
10
2
0 3
1 0
1
7
11
2
0 4
1 0
1
7
12
2
0 5
1 0
1
7
13
2
0 6
1 0
7
0
49
1
0 0
1
50
1
0 1
2
51
1
0 2
3
52
1
0 3
4
53
1
0 4
5
54
1
0 5
6
55
1
0 6
end_DTG
begin_DTG
1
7
14
2
0 0
1 0
1
7
15
2
0 1
1 0
1
7
16
2
0 2
1 0
1
7
17
2
0 3
1 0
1
7
18
2
0 4
1 0
1
7
19
2
0 5
1 0
1
7
20
2
0 6
1 0
7
0
56
1
0 0
1
57
1
0 1
2
58
1
0 2
3
59
1
0 3
4
60
1
0 4
5
61
1
0 5
6
62
1
0 6
end_DTG
begin_DTG
1
7
21
2
0 0
1 0
1
7
22
2
0 1
1 0
1
7
23
2
0 2
1 0
1
7
24
2
0 3
1 0
1
7
25
2
0 4
1 0
1
7
26
2
0 5
1 0
1
7
27
2
0 6
1 0
7
0
63
1
0 0
1
64
1
0 1
2
65
1
0 2
3
66
1
0 3
4
67
1
0 4
5
68
1
0 5
6
69
1
0 6
end_DTG
begin_DTG
1
7
28
2
0 0
1 0
1
7
29
2
0 1
1 0
1
7
30
2
0 2
1 0
1
7
31
2
0 3
1 0
1
7
32
2
0 4
1 0
1
7
33
2
0 5
1 0
1
7
34
2
0 6
1 0
7
0
70
1
0 0
1
71
1
0 1
2
72
1
0 2
3
73
1
0 3
4
74
1
0 4
5
75
1
0 5
6
76
1
0 6
end_DTG
begin_DTG
1
7
35
2
0 0
1 0
1
7
36
2
0 1
1 0
1
7
37
2
0 2
1 0
1
7
38
2
0 3
1 0
1
7
39
2
0 4
1 0
1
7
40
2
0 5
1 0
1
7
41
2
0 6
1 0
7
0
77
1
0 0
1
78
1
0 1
2
79
1
0 2
3
80
1
0 3
4
81
1
0 4
5
82
1
0 5
6
83
1
0 6
end_DTG
begin_CG
7
2 14
3 14
4 14
5 14
6 14
7 14
1 84
6
2 7
3 7
4 7
5 7
6 7
7 7
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
1
1 14
end_CG
