begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var6
-1
8
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
end_variable
begin_variable
var7
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
9
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom on(car1)
end_variable
begin_variable
var1
-1
9
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom on(car2)
end_variable
begin_variable
var2
-1
9
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom on(car3)
end_variable
begin_variable
var3
-1
9
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom on(car4)
end_variable
begin_variable
var4
-1
9
Atom at(car5, loc1)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom on(car5)
end_variable
begin_variable
var5
-1
9
Atom at(car6, loc1)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom on(car6)
end_variable
1
begin_mutex_group
7
1 0
2 8
3 8
4 8
5 8
6 8
7 8
end_mutex_group
begin_state
1
0
1
6
7
6
4
6
end_state
begin_goal
6
2 4
3 4
4 2
5 1
6 6
7 0
end_goal
152
begin_operator
board car1 loc1
1
0 0
2
0 2 0 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 8
0 1 0 1
0
end_operator
begin_operator
board car1 loc8
1
0 7
2
0 2 7 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 8
0 1 0 1
0
end_operator
begin_operator
board car2 loc8
1
0 7
2
0 3 7 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 8
0 1 0 1
0
end_operator
begin_operator
board car3 loc8
1
0 7
2
0 4 7 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc7
1
0 6
2
0 5 6 8
0 1 0 1
0
end_operator
begin_operator
board car4 loc8
1
0 7
2
0 5 7 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc1
1
0 0
2
0 6 0 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc2
1
0 1
2
0 6 1 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc3
1
0 2
2
0 6 2 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc4
1
0 3
2
0 6 3 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc5
1
0 4
2
0 6 4 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc6
1
0 5
2
0 6 5 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc7
1
0 6
2
0 6 6 8
0 1 0 1
0
end_operator
begin_operator
board car5 loc8
1
0 7
2
0 6 7 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc1
1
0 0
2
0 7 0 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc2
1
0 1
2
0 7 1 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc3
1
0 2
2
0 7 2 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc4
1
0 3
2
0 7 3 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc5
1
0 4
2
0 7 4 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc6
1
0 5
2
0 7 5 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc7
1
0 6
2
0 7 6 8
0 1 0 1
0
end_operator
begin_operator
board car6 loc8
1
0 7
2
0 7 7 8
0 1 0 1
0
end_operat




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
switch 1
check 0
check 1
39
check 0
check 0
check 0
switch 0
check 0
check 1
80
check 1
81
check 1
82
check 1
83
check 1
84
check 1
85
check 1
86
check 1
87
check 0
switch 7
check 0
switch 0
check 0
switch 1
check 0
check 1
40
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
41
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
42
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
43
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
44
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
45
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
46
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
47
check 0
check 0
check 0
switch 0
check 0
check 1
88
check 1
89
check 1
90
check 1
91
check 1
92
check 1
93
check 1
94
check 1
95
check 0
switch 0
check 0
check 7
96
97
98
99
100
101
102
check 7
103
104
105
106
107
108
109
check 7
110
111
112
113
114
115
116
check 7
117
118
119
120
121
122
123
check 7
124
125
126
127
128
129
130
check 7
131
132
133
134
135
136
137
check 7
138
139
140
141
142
143
144
check 7
145
146
147
148
149
150
151
check 0
end_SG
begin_DTG
7
1
96
0
2
97
0
3
98
0
4
99
0
5
100
0
6
101
0
7
102
0
7
0
103
0
2
104
0
3
105
0
4
106
0
5
107
0
6
108
0
7
109
0
7
0
110
0
1
111
0
3
112
0
4
113
0
5
114
0
6
115
0
7
116
0
7
0
117
0
1
118
0
2
119
0
4
120
0
5
121
0
6
122
0
7
123
0
7
0
124
0
1
125
0
2
126
0
3
127
0
5
128
0
6
129
0
7
130
0
7
0
131
0
1
132
0
2
133
0
3
134
0
4
135
0
6
136
0
7
137
0
7
0
138
0
1
139
0
2
140
0
3
141
0
4
142
0
5
143
0
7
144
0
7
0
145
0
1
146
0
2
147
0
3
148
0
4
149
0
5
150
0
6
151
0
end_DTG
begin_DTG
48
1
36
2
6 4
0 4
1
25
2
5 1
0 1
1
26
2
5 2
0 2
1
27
2
5 3
0 3
1
28
2
5 4
0 4
1
29
2
5 5
0 5
1
30
2
5 6
0 6
1
31
2
5 7
0 7
1
32
2
6 0
0 0
1
33
2
6 1
0 1
1
34
2
6 2
0 2
1
35
2
6 3
0 3
1
24
2
5 0
0 0
1
37
2
6 5
0 5
1
38
2
6 6
0 6
1
39
2
6 7
0 7
1
40
2
7 0
0 0
1
41
2
7 1
0 1
1
42
2
7 2
0 2
1
43
2
7 3
0 3
1
44
2
7 4
0 4
1
45
2
7 5
0 5
1
46
2
7 6
0 6
1
47
2
7 7
0 7
1
12
2
3 4
0 4
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
2 3
0 3
1
4
2
2 4
0 4
1
5
2
2 5
0 5
1
6
2
2 6
0 6
1
7
2
2 7
0 7
1
8
2
3 0
0 0
1
9
2
3 1
0 1
1
10
2
3 2
0 2
1
11
2
3 3
0 3
1
0
2
2 0
0 0
1
13
2
3 5
0 5
1
14
2
3 6
0 6
1
15
2
3 7
0 7
1
16
2
4 0
0 0
1
17
2
4 1
0 1
1
18
2
4 2
0 2
1
19
2
4 3
0 3
1
20
2
4 4
0 4
1
21
2
4 5
0 5
1
22
2
4 6
0 6
1
23
2
4 7
0 7
48
0
84
2
6 8
0 4
0
73
2
5 8
0 1
0
74
2
5 8
0 2
0
75
2
5 8
0 3
0
76
2
5 8
0 4
0
77
2
5 8
0 5
0
78
2
5 8
0 6
0
79
2
5 8
0 7
0
80
2
6 8
0 0
0
81
2
6 8
0 1
0
82
2
6 8
0 2
0
83
2
6 8
0 3
0
72
2
5 8
0 0
0
85
2
6 8
0 5
0
86
2
6 8
0 6
0
87
2
6 8
0 7
0
88
2
7 8
0 0
0
89
2
7 8
0 1
0
90
2
7 8
0 2
0
91
2
7 8
0 3
0
92
2
7 8
0 4
0
93
2
7 8
0 5
0
94
2
7 8
0 6
0
95
2
7 8
0 7
0
60
2
3 8
0 4
0
49
2
2 8
0 1
0
50
2
2 8
0 2
0
51
2
2 8
0 3
0
52
2
2 8
0 4
0
53
2
2 8
0 5
0
54
2
2 8
0 6
0
55
2
2 8
0 7
0
56
2
3 8
0 0
0
57
2
3 8
0 1
0
58
2
3 8
0 2
0
59
2
3 8
0 3
0
48
2
2 8
0 0
0
61
2
3 8
0 5
0
62
2
3 8
0 6
0
63
2
3 8
0 7
0
64
2
4 8
0 0
0
65
2
4 8
0 1
0
66
2
4 8
0 2
0
67
2
4 8
0 3
0
68
2
4 8
0 4
0
69
2
4 8
0 5
0
70
2
4 8
0 6
0
71
2
4 8
0 7
end_DTG
begin_DTG
1
8
0
2
0 0
1 0
1
8
1
2
0 1
1 0
1
8
2
2
0 2
1 0
1
8
3
2
0 3
1 0
1
8
4
2
0 4
1 0
1
8
5
2
0 5
1 0
1
8
6
2
0 6
1 0
1
8
7
2
0 7
1 0
8
0
48
1
0 0
1
49
1
0 1
2
50
1
0 2
3
51
1
0 3
4
52
1
0 4
5
53
1
0 5
6
54
1
0 6
7
55
1
0 7
end_DTG
begin_DTG
1
8
8
2
0 0
1 0
1
8
9
2
0 1
1 0
1
8
10
2
0 2
1 0
1
8
11
2
0 3
1 0
1
8
12
2
0 4
1 0
1
8
13
2
0 5
1 0
1
8
14
2
0 6
1 0
1
8
15
2
0 7
1 0
8
0
56
1
0 0
1
57
1
0 1
2
58
1
0 2
3
59
1
0 3
4
60
1
0 4
5
61
1
0 5
6
62
1
0 6
7
63
1
0 7
end_DTG
begin_DTG
1
8
16
2
0 0
1 0
1
8
17
2
0 1
1 0
1
8
18
2
0 2
1 0
1
8
19
2
0 3
1 0
1
8
20
2
0 4
1 0
1
8
21
2
0 5
1 0
1
8
22
2
0 6
1 0
1
8
23
2
0 7
1 0
8
0
64
1
0 0
1
65
1
0 1
2
66
1
0 2
3
67
1
0 3
4
68
1
0 4
5
69
1
0 5
6
70
1
0 6
7
71
1
0 7
end_DTG
begin_DTG
1
8
24
2
0 0
1 0
1
8
25
2
0 1
1 0
1
8
26
2
0 2
1 0
1
8
27
2
0 3
1 0
1
8
28
2
0 4
1 0
1
8
29
2
0 5
1 0
1
8
30
2
0 6
1 0
1
8
31
2
0 7
1 0
8
0
72
1
0 0
1
73
1
0 1
2
74
1
0 2
3
75
1
0 3
4
76
1
0 4
5
77
1
0 5
6
78
1
0 6
7
79
1
0 7
end_DTG
begin_DTG
1
8
32
2
0 0
1 0
1
8
33
2
0 1
1 0
1
8
34
2
0 2
1 0
1
8
35
2
0 3
1 0
1
8
36
2
0 4
1 0
1
8
37
2
0 5
1 0
1
8
38
2
0 6
1 0
1
8
39
2
0 7
1 0
8
0
80
1
0 0
1
81
1
0 1
2
82
1
0 2
3
83
1
0 3
4
84
1
0 4
5
85
1
0 5
6
86
1
0 6
7
87
1
0 7
end_DTG
begin_DTG
1
8
40
2
0 0
1 0
1
8
41
2
0 1
1 0
1
8
42
2
0 2
1 0
1
8
43
2
0 3
1 0
1
8
44
2
0 4
1 0
1
8
45
2
0 5
1 0
1
8
46
2
0 6
1 0
1
8
47
2
0 7
1 0
8
0
88
1
0 0
1
89
1
0 1
2
90
1
0 2
3
91
1
0 3
4
92
1
0 4
5
93
1
0 5
6
94
1
0 6
7
95
1
0 7
end_DTG
begin_CG
7
2 16
3 16
4 16
5 16
6 16
7 16
1 96
6
2 8
3 8
4 8
5 8
6 8
7 8
1
1 16
1
1 16
1
1 16
1
1 16
1
1 16
1
1 16
end_CG
