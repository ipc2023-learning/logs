begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var13
-1
12
Atom at-ferry(loc1)
Atom at-ferry(loc10)
Atom at-ferry(loc11)
Atom at-ferry(loc12)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var14
-1
14
Atom empty-ferry()
Atom on(car1)
Atom on(car10)
Atom on(car11)
Atom on(car12)
Atom on(car13)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
Atom on(car9)
end_variable
begin_variable
var0
-1
13
Atom at(car1, loc1)
Atom at(car1, loc10)
Atom at(car1, loc11)
Atom at(car1, loc12)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
<none of those>
end_variable
begin_variable
var1
-1
13
Atom at(car10, loc1)
Atom at(car10, loc10)
Atom at(car10, loc11)
Atom at(car10, loc12)
Atom at(car10, loc2)
Atom at(car10, loc3)
Atom at(car10, loc4)
Atom at(car10, loc5)
Atom at(car10, loc6)
Atom at(car10, loc7)
Atom at(car10, loc8)
Atom at(car10, loc9)
<none of those>
end_variable
begin_variable
var2
-1
13
Atom at(car11, loc1)
Atom at(car11, loc10)
Atom at(car11, loc11)
Atom at(car11, loc12)
Atom at(car11, loc2)
Atom at(car11, loc3)
Atom at(car11, loc4)
Atom at(car11, loc5)
Atom at(car11, loc6)
Atom at(car11, loc7)
Atom at(car11, loc8)
Atom at(car11, loc9)
<none of those>
end_variable
begin_variable
var3
-1
13
Atom at(car12, loc1)
Atom at(car12, loc10)
Atom at(car12, loc11)
Atom at(car12, loc12)
Atom at(car12, loc2)
Atom at(car12, loc3)
Atom at(car12, loc4)
Atom at(car12, loc5)
Atom at(car12, loc6)
Atom at(car12, loc7)
Atom at(car12, loc8)
Atom at(car12, loc9)
<none of those>
end_variable
begin_variable
var4
-1
13
Atom at(car13, loc1)
Atom at(car13, loc10)
Atom at(car13, loc11)
Atom at(car13, loc12)
Atom at(car13, loc2)
Atom at(car13, loc3)
Atom at(car13, loc4)
Atom at(car13, loc5)
Atom at(car13, loc6)
Atom at(car13, loc7)
Atom at(car13, loc8)
Atom at(car13, loc9)
<none of those>
end_variable
begin_variable
var5
-1
13
Atom at(car2, loc1)
Atom at(car2, loc10)
Atom at(car2, loc11)
Atom at(car2, loc12)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
<none of those>
end_variable
begin_variable
var6
-1
13
Atom at(car3, loc1)
Atom at(car3, loc10)
Atom at(car3, loc11)
Atom at(car3, loc12)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
<none of those>
end_variable
begin_variable
var7
-1
13
Atom at(car4, loc1)
Atom at(car4, loc10)
Atom at(car4, loc11)
Atom at(car4, loc12)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
<none of those>
end_variable
begin_variable
var8
-1
13
Atom at(car5, loc1)
Atom at(car5, loc10)
Atom at(car5, loc11)
Atom at(car5, loc12)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom at(car5, loc9)
<none of those>
end_variable
begin_variable
var9
-1
13
Atom at(car6, loc1)
Atom at(car6, loc10)
Atom at(car6, loc11)
Atom at(car6, loc12)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom at(car6, loc9)
<none of those>
end_variable
begin_variable
var10
-1
13
Atom at(car7, loc1)
Atom at(car7, loc10)
Atom at(car7, loc11)
Atom at(car7, loc12)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
Atom at(car7, loc9)
<none of those>
end_variable
begin_variable
var11
-1
13
Atom at(car8, loc1)
Atom at(car8, loc10)
Atom at(car8, loc11)
Atom at(car8, loc12)
Atom at(car8, loc2)
Atom at(car8, loc3)
Atom at(car8, loc4)
Atom at(car8, loc5)
Atom at(car8, loc6)
Atom at(car8, loc7)
Atom at(car8, loc8)
Atom at(car8, loc9)
<none of those>
end_variable
begin_variable
var12
-1
13
Atom at(car9, loc1)
Atom at(car9, loc10)
Atom at(car9, loc11)
Atom at(car9, loc12)
Atom at(car9, loc2)
Atom at(car9, loc3)
Atom at(car9, loc4)
Atom at(car9, loc5)
Atom at(car9, loc6)
Atom at(car9, loc7)
Atom at(car9, loc8)
Atom at(car9, loc9)
<none of those>
end_variable
13
begin_mutex_group
13
2 0
2 1
2 2
2 3
2 4
2 5
2 6
2 7
2 8
2 9
2 10
2 11
1 1
end_mutex_group
begin_mutex_group
13
3 0
3 1
3 2
3 3
3 4
3 5
3 6
3 7
3 8
3 9
3 10
3 11
1 2
end_mutex_group
begin_mutex_group
13
4 0
4 1
4 2
4 3
4 4
4 5
4 6
4 7
4 8
4 9
4 10
4 11
1 3
end_mutex_group
begin_mutex_group
13
5 0
5 1
5 2
5 3
5 4
5 5
5 6
5 7
5 8
5 9
5 10
5 11
1 4
end_mutex_group
begin_mutex_group
13
6 0
6 1
6 2
6 3
6 4
6 5
6 6
6 7
6 8
6 9
6 10
6 11
1 5
end_mutex_group
begin_mutex_group
13
7 0
7 1
7 2
7 3
7 4
7 5
7 6
7 7
7 8
7 9
7 10
7 11
1 6
end_mutex_group
begin_mutex_group
13
8 0
8 1
8 2
8 3
8 4
8 5
8 6
8 7
8 8
8 9





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
12
135
2
0 3
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
12
136
2
0 4
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
12
137
2
0 5
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
12
138
2
0 6
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
12
139
2
0 7
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
12
140
2
0 8
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
12
141
2
0 9
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
11
299
2
0 11
1 12
12
142
2
0 10
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
12
143
2
0 11
1 0
12
0
288
2
0 0
1 12
1
289
2
0 1
1 12
2
290
2
0 2
1 12
3
291
2
0 3
1 12
4
292
2
0 4
1 12
5
293
2
0 5
1 12
6
294
2
0 6
1 12
7
295
2
0 7
1 12
8
296
2
0 8
1 12
9
297
2
0 9
1 12
10
298
2
0 10
1 12
11
299
2
0 11
1 12
end_DTG
begin_DTG
12
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
144
2
0 0
1 0
12
0
300
2
0 0
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
145
2
0 1
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
146
2
0 2
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
147
2
0 3
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
148
2
0 4
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
149
2
0 5
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
150
2
0 6
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
151
2
0 7
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
152
2
0 8
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
12
153
2
0 9
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
11
311
2
0 11
1 13
12
154
2
0 10
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
12
155
2
0 11
1 0
12
0
300
2
0 0
1 13
1
301
2
0 1
1 13
2
302
2
0 2
1 13
3
303
2
0 3
1 13
4
304
2
0 4
1 13
5
305
2
0 5
1 13
6
306
2
0 6
1 13
7
307
2
0 7
1 13
8
308
2
0 8
1 13
9
309
2
0 9
1 13
10
310
2
0 10
1 13
11
311
2
0 11
1 13
end_DTG
begin_CG
14
2 24
3 24
4 24
5 24
6 24
7 24
8 24
9 24
10 24
11 24
12 24
13 24
14 24
1 312
13
2 24
3 24
4 24
5 24
6 24
7 24
8 24
9 24
10 24
11 24
12 24
13 24
14 24
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
1
1 12
end_CG
