begin_version
3
end_version
begin_metric
0
end_metric
6
begin_variable
var4
-1
6
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
end_variable
begin_variable
var5
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
7
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom on(car1)
end_variable
begin_variable
var1
-1
7
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom on(car2)
end_variable
begin_variable
var2
-1
7
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom on(car3)
end_variable
begin_variable
var3
-1
7
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom on(car4)
end_variable
1
begin_mutex_group
5
1 0
2 6
3 6
4 6
5 6
end_mutex_group
begin_state
0
0
2
4
4
0
end_state
begin_goal
4
2 1
3 5
4 2
5 4
end_goal
78
begin_operator
board car1 loc1
1
0 0
2
0 2 0 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 6
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 6
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 6
0 1 0 1
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 6
0 1 0 1
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 6
0 1 0 1
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 6
0 1 0 1
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 6
0 1 0 1
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 6
0 1 0 1
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 6
0 1 0 1
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 6
0 1 0 1
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 6
0 1 0 1
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 6
0 1 0 1
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 6
0 1 0 1
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 6
0 1 0 1
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 6
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 6 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 6 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 6 2
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc4
1
0 3
2
0 2 6 3
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc5
1
0 4
2
0 2 6 4
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc6
1
0 5
2
0 2 6 5
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc1
1
0 0
2
0 3 6 0
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc2
1
0 1
2
0 3 6 1
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc3
1
0 2
2
0 3 6 2
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc4
1
0 3
2
0 3 6 3
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc5
1
0 4
2
0 3 6 4
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc6
1
0 5
2
0 3 6 5
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc1
1
0 0
2
0 4 6 0
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc2
1
0 1
2
0 4 6 1
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc3
1
0 2
2
0 4 6 2
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc4
1
0 3
2
0 4 6 3
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc5
1
0 4
2
0 4 6 4
0 1 -1 0
0
end_operator
begin_operator
debark car3 loc6
1
0 5
2
0 4 6 5
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc1
1
0 0
2
0 5 6 0
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc2
1
0 1
2
0 5 6 1
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc3
1
0 2
2
0 5 6 2
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc4
1
0 3
2
0 5 6 3
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc5
1
0 4
2
0 5 6 4
0 1 -1 0
0
end_operator
begin_operator
debark car4 loc6
1
0 5
2
0 5 6 5
0 1 -1 0
0
end_operator
begin_operator
sail loc1 loc2
0
1
0 0 0 1
0
end_operator
begin_operator
sail loc1 loc3
0
1
0 0 0 2
0
end_operator
begin_operator
sail loc1 loc4
0
1
0 0 0 3
0
end_operator
begin_operator
sail loc1 loc5
0
1
0 0 0 4
0
end_operator
begin_operator
sail loc1 loc6
0
1
0 0 0 5
0
end_operator
begin_operator
sail loc2 loc1
0
1
0 0 1 0
0
end_operator
begin_operator
sail loc2 loc3
0
1
0 0 1 2
0
end_operator
begin_operator
sail loc2 loc4
0
1
0 0 1 3
0
end_operator
begin_operator
sail loc2 loc5
0
1
0 0 1 4
0
end_operator
begin_operator
sail loc2 loc6
0
1
0 0 1 5
0
end_operator
begin_operator
sail loc3




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




l loc6 loc4
0
1
0 0 5 3
0
end_operator
begin_operator
sail loc6 loc5
0
1
0 0 5 4
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 1
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
check 0
switch 0
check 0
check 1
24
check 1
25
check 1
26
check 1
27
check 1
28
check 1
29
check 0
switch 3
check 0
switch 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
10
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
11
check 0
check 0
check 0
switch 0
check 0
check 1
30
check 1
31
check 1
32
check 1
33
check 1
34
check 1
35
check 0
switch 4
check 0
switch 0
check 0
switch 1
check 0
check 1
12
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
13
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
14
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
15
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
16
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
17
check 0
check 0
check 0
switch 0
check 0
check 1
36
check 1
37
check 1
38
check 1
39
check 1
40
check 1
41
check 0
switch 5
check 0
switch 0
check 0
switch 1
check 0
check 1
18
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
19
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
20
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
21
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
22
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
23
check 0
check 0
check 0
switch 0
check 0
check 1
42
check 1
43
check 1
44
check 1
45
check 1
46
check 1
47
check 0
switch 0
check 0
check 5
48
49
50
51
52
check 5
53
54
55
56
57
check 5
58
59
60
61
62
check 5
63
64
65
66
67
check 5
68
69
70
71
72
check 5
73
74
75
76
77
check 0
end_SG
begin_DTG
5
1
48
0
2
49
0
3
50
0
4
51
0
5
52
0
5
0
53
0
2
54
0
3
55
0
4
56
0
5
57
0
5
0
58
0
1
59
0
3
60
0
4
61
0
5
62
0
5
0
63
0
1
64
0
2
65
0
4
66
0
5
67
0
5
0
68
0
1
69
0
2
70
0
3
71
0
5
72
0
5
0
73
0
1
74
0
2
75
0
3
76
0
4
77
0
end_DTG
begin_DTG
24
1
12
2
4 0
0 0
1
23
2
5 5
0 5
1
22
2
5 4
0 4
1
21
2
5 3
0 3
1
20
2
5 2
0 2
1
19
2
5 1
0 1
1
18
2
5 0
0 0
1
17
2
4 5
0 5
1
16
2
4 4
0 4
1
15
2
4 3
0 3
1
14
2
4 2
0 2
1
13
2
4 1
0 1
1
0
2
2 0
0 0
1
11
2
3 5
0 5
1
10
2
3 4
0 4
1
9
2
3 3
0 3
1
8
2
3 2
0 2
1
7
2
3 1
0 1
1
6
2
3 0
0 0
1
5
2
2 5
0 5
1
4
2
2 4
0 4
1
3
2
2 3
0 3
1
2
2
2 2
0 2
1
1
2
2 1
0 1
24
0
36
2
4 6
0 0
0
47
2
5 6
0 5
0
46
2
5 6
0 4
0
45
2
5 6
0 3
0
44
2
5 6
0 2
0
43
2
5 6
0 1
0
42
2
5 6
0 0
0
41
2
4 6
0 5
0
40
2
4 6
0 4
0
39
2
4 6
0 3
0
38
2
4 6
0 2
0
37
2
4 6
0 1
0
24
2
2 6
0 0
0
35
2
3 6
0 5
0
34
2
3 6
0 4
0
33
2
3 6
0 3
0
32
2
3 6
0 2
0
31
2
3 6
0 1
0
30
2
3 6
0 0
0
29
2
2 6
0 5
0
28
2
2 6
0 4
0
27
2
2 6
0 3
0
26
2
2 6
0 2
0
25
2
2 6
0 1
end_DTG
begin_DTG
1
6
0
2
0 0
1 0
1
6
1
2
0 1
1 0
1
6
2
2
0 2
1 0
1
6
3
2
0 3
1 0
1
6
4
2
0 4
1 0
1
6
5
2
0 5
1 0
6
0
24
1
0 0
1
25
1
0 1
2
26
1
0 2
3
27
1
0 3
4
28
1
0 4
5
29
1
0 5
end_DTG
begin_DTG
1
6
6
2
0 0
1 0
1
6
7
2
0 1
1 0
1
6
8
2
0 2
1 0
1
6
9
2
0 3
1 0
1
6
10
2
0 4
1 0
1
6
11
2
0 5
1 0
6
0
30
1
0 0
1
31
1
0 1
2
32
1
0 2
3
33
1
0 3
4
34
1
0 4
5
35
1
0 5
end_DTG
begin_DTG
1
6
12
2
0 0
1 0
1
6
13
2
0 1
1 0
1
6
14
2
0 2
1 0
1
6
15
2
0 3
1 0
1
6
16
2
0 4
1 0
1
6
17
2
0 5
1 0
6
0
36
1
0 0
1
37
1
0 1
2
38
1
0 2
3
39
1
0 3
4
40
1
0 4
5
41
1
0 5
end_DTG
begin_DTG
1
6
18
2
0 0
1 0
1
6
19
2
0 1
1 0
1
6
20
2
0 2
1 0
1
6
21
2
0 3
1 0
1
6
22
2
0 4
1 0
1
6
23
2
0 5
1 0
6
0
42
1
0 0
1
43
1
0 1
2
44
1
0 2
3
45
1
0 3
4
46
1
0 4
5
47
1
0 5
end_DTG
begin_CG
5
2 12
3 12
4 12
5 12
1 48
4
2 6
3 6
4 6
5 6
1
1 12
1
1 12
1
1 12
1
1 12
end_CG
