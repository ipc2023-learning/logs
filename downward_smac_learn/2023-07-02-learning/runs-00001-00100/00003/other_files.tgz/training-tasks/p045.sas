begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var8
-1
9
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var9
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
10
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
Atom on(car1)
end_variable
begin_variable
var1
-1
10
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
Atom on(car2)
end_variable
begin_variable
var2
-1
10
Atom at(car3, loc1)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
Atom on(car3)
end_variable
begin_variable
var3
-1
10
Atom at(car4, loc1)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
Atom on(car4)
end_variable
begin_variable
var4
-1
10
Atom at(car5, loc1)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom at(car5, loc9)
Atom on(car5)
end_variable
begin_variable
var5
-1
10
Atom at(car6, loc1)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom at(car6, loc9)
Atom on(car6)
end_variable
begin_variable
var6
-1
10
Atom at(car7, loc1)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
Atom at(car7, loc9)
Atom on(car7)
end_variable
begin_variable
var7
-1
10
Atom at(car8, loc1)
Atom at(car8, loc2)
Atom at(car8, loc3)
Atom at(car8, loc4)
Atom at(car8, loc5)
Atom at(car8, loc6)
Atom at(car8, loc7)
Atom at(car8, loc8)
Atom at(car8, loc9)
Atom on(car8)
end_variable
1
begin_mutex_group
9
1 0
2 9
3 9
4 9
5 9
6 9
7 9
8 9
9 9
end_mutex_group
begin_state
7
0
6
7
0
8
7
5
1
5
end_state
begin_goal
8
2 1
3 4
4 5
5 7
6 5
7 8
8 5
9 7
end_goal
216
begin_operator
board car1 loc1
1
0 0
2
0 2 0 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc6
1
0 5
2
0 2 5 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc7
1
0 6
2
0 2 6 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc8
1
0 7
2
0 2 7 9
0 1 0 1
0
end_operator
begin_operator
board car1 loc9
1
0 8
2
0 2 8 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc6
1
0 5
2
0 3 5 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc7
1
0 6
2
0 3 6 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc8
1
0 7
2
0 3 7 9
0 1 0 1
0
end_operator
begin_operator
board car2 loc9
1
0 8
2
0 3 8 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc1
1
0 0
2
0 4 0 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc2
1
0 1
2
0 4 1 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc3
1
0 2
2
0 4 2 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc4
1
0 3
2
0 4 3 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc5
1
0 4
2
0 4 4 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc6
1
0 5
2
0 4 5 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc7
1
0 6
2
0 4 6 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc8
1
0 7
2
0 4 7 9
0 1 0 1
0
end_operator
begin_operator
board car3 loc9
1
0 8
2
0 4 8 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc1
1
0 0
2
0 5 0 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc2
1
0 1
2
0 5 1 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc3
1
0 2
2
0 5 2 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc4
1
0 3
2
0 5 3 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc5
1
0 4
2
0 5 4 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc6
1
0 5
2
0 5 5 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc7
1
0 6
2
0 5 6 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc8
1
0 7
2
0 5 7 9
0 1 0 1
0
end_operator
begin_operator
board car4 loc9
1
0 8
2
0 5 8 9
0 1 0 1
0
end_operator
begin_operator
board car5 loc1
1
0 0
2
0 6 0 9
0 1 0 1
0
end_operator
begin_operator
board car5 loc2
1
0 1
2
0 6 1 9
0 1 0 1
0
end_operator
begin_operator
board car5 loc3
1
0 2
2
0 6 2 9
0 1 0 1
0
end_ope




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
8
0
152
0
2
153
0
3
154
0
4
155
0
5
156
0
6
157
0
7
158
0
8
159
0
8
0
160
0
1
161
0
3
162
0
4
163
0
5
164
0
6
165
0
7
166
0
8
167
0
8
0
168
0
1
169
0
2
170
0
4
171
0
5
172
0
6
173
0
7
174
0
8
175
0
8
0
176
0
1
177
0
2
178
0
3
179
0
5
180
0
6
181
0
7
182
0
8
183
0
8
0
184
0
1
185
0
2
186
0
3
187
0
4
188
0
6
189
0
7
190
0
8
191
0
8
0
192
0
1
193
0
2
194
0
3
195
0
4
196
0
5
197
0
7
198
0
8
199
0
8
0
200
0
1
201
0
2
202
0
3
203
0
4
204
0
5
205
0
6
206
0
8
207
0
8
0
208
0
1
209
0
2
210
0
3
211
0
4
212
0
5
213
0
6
214
0
7
215
0
end_DTG
begin_DTG
72
1
45
2
7 0
0 0
1
53
2
7 8
0 8
1
52
2
7 7
0 7
1
51
2
7 6
0 6
1
50
2
7 5
0 5
1
49
2
7 4
0 4
1
48
2
7 3
0 3
1
47
2
7 2
0 2
1
46
2
7 1
0 1
1
54
2
8 0
0 0
1
44
2
6 8
0 8
1
43
2
6 7
0 7
1
42
2
6 6
0 6
1
41
2
6 5
0 5
1
40
2
6 4
0 4
1
39
2
6 3
0 3
1
38
2
6 2
0 2
1
37
2
6 1
0 1
1
63
2
9 0
0 0
1
71
2
9 8
0 8
1
70
2
9 7
0 7
1
69
2
9 6
0 6
1
68
2
9 5
0 5
1
67
2
9 4
0 4
1
66
2
9 3
0 3
1
65
2
9 2
0 2
1
64
2
9 1
0 1
1
36
2
6 0
0 0
1
62
2
8 8
0 8
1
61
2
8 7
0 7
1
60
2
8 6
0 6
1
59
2
8 5
0 5
1
58
2
8 4
0 4
1
57
2
8 3
0 3
1
56
2
8 2
0 2
1
55
2
8 1
0 1
1
9
2
3 0
0 0
1
17
2
3 8
0 8
1
16
2
3 7
0 7
1
15
2
3 6
0 6
1
14
2
3 5
0 5
1
13
2
3 4
0 4
1
12
2
3 3
0 3
1
11
2
3 2
0 2
1
10
2
3 1
0 1
1
18
2
4 0
0 0
1
8
2
2 8
0 8
1
7
2
2 7
0 7
1
6
2
2 6
0 6
1
5
2
2 5
0 5
1
4
2
2 4
0 4
1
3
2
2 3
0 3
1
2
2
2 2
0 2
1
1
2
2 1
0 1
1
27
2
5 0
0 0
1
35
2
5 8
0 8
1
34
2
5 7
0 7
1
33
2
5 6
0 6
1
32
2
5 5
0 5
1
31
2
5 4
0 4
1
30
2
5 3
0 3
1
29
2
5 2
0 2
1
28
2
5 1
0 1
1
0
2
2 0
0 0
1
26
2
4 8
0 8
1
25
2
4 7
0 7
1
24
2
4 6
0 6
1
23
2
4 5
0 5
1
22
2
4 4
0 4
1
21
2
4 3
0 3
1
20
2
4 2
0 2
1
19
2
4 1
0 1
72
0
117
2
7 9
0 0
0
125
2
7 9
0 8
0
124
2
7 9
0 7
0
123
2
7 9
0 6
0
122
2
7 9
0 5
0
121
2
7 9
0 4
0
120
2
7 9
0 3
0
119
2
7 9
0 2
0
118
2
7 9
0 1
0
126
2
8 9
0 0
0
116
2
6 9
0 8
0
115
2
6 9
0 7
0
114
2
6 9
0 6
0
113
2
6 9
0 5
0
112
2
6 9
0 4
0
111
2
6 9
0 3
0
110
2
6 9
0 2
0
109
2
6 9
0 1
0
135
2
9 9
0 0
0
143
2
9 9
0 8
0
142
2
9 9
0 7
0
141
2
9 9
0 6
0
140
2
9 9
0 5
0
139
2
9 9
0 4
0
138
2
9 9
0 3
0
137
2
9 9
0 2
0
136
2
9 9
0 1
0
108
2
6 9
0 0
0
134
2
8 9
0 8
0
133
2
8 9
0 7
0
132
2
8 9
0 6
0
131
2
8 9
0 5
0
130
2
8 9
0 4
0
129
2
8 9
0 3
0
128
2
8 9
0 2
0
127
2
8 9
0 1
0
81
2
3 9
0 0
0
89
2
3 9
0 8
0
88
2
3 9
0 7
0
87
2
3 9
0 6
0
86
2
3 9
0 5
0
85
2
3 9
0 4
0
84
2
3 9
0 3
0
83
2
3 9
0 2
0
82
2
3 9
0 1
0
90
2
4 9
0 0
0
80
2
2 9
0 8
0
79
2
2 9
0 7
0
78
2
2 9
0 6
0
77
2
2 9
0 5
0
76
2
2 9
0 4
0
75
2
2 9
0 3
0
74
2
2 9
0 2
0
73
2
2 9
0 1
0
99
2
5 9
0 0
0
107
2
5 9
0 8
0
106
2
5 9
0 7
0
105
2
5 9
0 6
0
104
2
5 9
0 5
0
103
2
5 9
0 4
0
102
2
5 9
0 3
0
101
2
5 9
0 2
0
100
2
5 9
0 1
0
72
2
2 9
0 0
0
98
2
4 9
0 8
0
97
2
4 9
0 7
0
96
2
4 9
0 6
0
95
2
4 9
0 5
0
94
2
4 9
0 4
0
93
2
4 9
0 3
0
92
2
4 9
0 2
0
91
2
4 9
0 1
end_DTG
begin_DTG
1
9
0
2
0 0
1 0
1
9
1
2
0 1
1 0
1
9
2
2
0 2
1 0
1
9
3
2
0 3
1 0
1
9
4
2
0 4
1 0
1
9
5
2
0 5
1 0
1
9
6
2
0 6
1 0
1
9
7
2
0 7
1 0
1
9
8
2
0 8
1 0
9
0
72
1
0 0
1
73
1
0 1
2
74
1
0 2
3
75
1
0 3
4
76
1
0 4
5
77
1
0 5
6
78
1
0 6
7
79
1
0 7
8
80
1
0 8
end_DTG
begin_DTG
1
9
9
2
0 0
1 0
1
9
10
2
0 1
1 0
1
9
11
2
0 2
1 0
1
9
12
2
0 3
1 0
1
9
13
2
0 4
1 0
1
9
14
2
0 5
1 0
1
9
15
2
0 6
1 0
1
9
16
2
0 7
1 0
1
9
17
2
0 8
1 0
9
0
81
1
0 0
1
82
1
0 1
2
83
1
0 2
3
84
1
0 3
4
85
1
0 4
5
86
1
0 5
6
87
1
0 6
7
88
1
0 7
8
89
1
0 8
end_DTG
begin_DTG
1
9
18
2
0 0
1 0
1
9
19
2
0 1
1 0
1
9
20
2
0 2
1 0
1
9
21
2
0 3
1 0
1
9
22
2
0 4
1 0
1
9
23
2
0 5
1 0
1
9
24
2
0 6
1 0
1
9
25
2
0 7
1 0
1
9
26
2
0 8
1 0
9
0
90
1
0 0
1
91
1
0 1
2
92
1
0 2
3
93
1
0 3
4
94
1
0 4
5
95
1
0 5
6
96
1
0 6
7
97
1
0 7
8
98
1
0 8
end_DTG
begin_DTG
1
9
27
2
0 0
1 0
1
9
28
2
0 1
1 0
1
9
29
2
0 2
1 0
1
9
30
2
0 3
1 0
1
9
31
2
0 4
1 0
1
9
32
2
0 5
1 0
1
9
33
2
0 6
1 0
1
9
34
2
0 7
1 0
1
9
35
2
0 8
1 0
9
0
99
1
0 0
1
100
1
0 1
2
101
1
0 2
3
102
1
0 3
4
103
1
0 4
5
104
1
0 5
6
105
1
0 6
7
106
1
0 7
8
107
1
0 8
end_DTG
begin_DTG
1
9
36
2
0 0
1 0
1
9
37
2
0 1
1 0
1
9
38
2
0 2
1 0
1
9
39
2
0 3
1 0
1
9
40
2
0 4
1 0
1
9
41
2
0 5
1 0
1
9
42
2
0 6
1 0
1
9
43
2
0 7
1 0
1
9
44
2
0 8
1 0
9
0
108
1
0 0
1
109
1
0 1
2
110
1
0 2
3
111
1
0 3
4
112
1
0 4
5
113
1
0 5
6
114
1
0 6
7
115
1
0 7
8
116
1
0 8
end_DTG
begin_DTG
1
9
45
2
0 0
1 0
1
9
46
2
0 1
1 0
1
9
47
2
0 2
1 0
1
9
48
2
0 3
1 0
1
9
49
2
0 4
1 0
1
9
50
2
0 5
1 0
1
9
51
2
0 6
1 0
1
9
52
2
0 7
1 0
1
9
53
2
0 8
1 0
9
0
117
1
0 0
1
118
1
0 1
2
119
1
0 2
3
120
1
0 3
4
121
1
0 4
5
122
1
0 5
6
123
1
0 6
7
124
1
0 7
8
125
1
0 8
end_DTG
begin_DTG
1
9
54
2
0 0
1 0
1
9
55
2
0 1
1 0
1
9
56
2
0 2
1 0
1
9
57
2
0 3
1 0
1
9
58
2
0 4
1 0
1
9
59
2
0 5
1 0
1
9
60
2
0 6
1 0
1
9
61
2
0 7
1 0
1
9
62
2
0 8
1 0
9
0
126
1
0 0
1
127
1
0 1
2
128
1
0 2
3
129
1
0 3
4
130
1
0 4
5
131
1
0 5
6
132
1
0 6
7
133
1
0 7
8
134
1
0 8
end_DTG
begin_DTG
1
9
63
2
0 0
1 0
1
9
64
2
0 1
1 0
1
9
65
2
0 2
1 0
1
9
66
2
0 3
1 0
1
9
67
2
0 4
1 0
1
9
68
2
0 5
1 0
1
9
69
2
0 6
1 0
1
9
70
2
0 7
1 0
1
9
71
2
0 8
1 0
9
0
135
1
0 0
1
136
1
0 1
2
137
1
0 2
3
138
1
0 3
4
139
1
0 4
5
140
1
0 5
6
141
1
0 6
7
142
1
0 7
8
143
1
0 8
end_DTG
begin_CG
9
2 18
3 18
4 18
5 18
6 18
7 18
8 18
9 18
1 144
8
2 9
3 9
4 9
5 9
6 9
7 9
8 9
9 9
1
1 18
1
1 18
1
1 18
1
1 18
1
1 18
1
1 18
1
1 18
1
1 18
end_CG
