begin_version
3
end_version
begin_metric
0
end_metric
14
begin_variable
var12
-1
11
Atom at-ferry(loc1)
Atom at-ferry(loc10)
Atom at-ferry(loc11)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
Atom at-ferry(loc6)
Atom at-ferry(loc7)
Atom at-ferry(loc8)
Atom at-ferry(loc9)
end_variable
begin_variable
var13
-1
13
Atom empty-ferry()
Atom on(car1)
Atom on(car10)
Atom on(car11)
Atom on(car12)
Atom on(car2)
Atom on(car3)
Atom on(car4)
Atom on(car5)
Atom on(car6)
Atom on(car7)
Atom on(car8)
Atom on(car9)
end_variable
begin_variable
var0
-1
12
Atom at(car1, loc1)
Atom at(car1, loc10)
Atom at(car1, loc11)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom at(car1, loc6)
Atom at(car1, loc7)
Atom at(car1, loc8)
Atom at(car1, loc9)
<none of those>
end_variable
begin_variable
var1
-1
12
Atom at(car10, loc1)
Atom at(car10, loc10)
Atom at(car10, loc11)
Atom at(car10, loc2)
Atom at(car10, loc3)
Atom at(car10, loc4)
Atom at(car10, loc5)
Atom at(car10, loc6)
Atom at(car10, loc7)
Atom at(car10, loc8)
Atom at(car10, loc9)
<none of those>
end_variable
begin_variable
var2
-1
12
Atom at(car11, loc1)
Atom at(car11, loc10)
Atom at(car11, loc11)
Atom at(car11, loc2)
Atom at(car11, loc3)
Atom at(car11, loc4)
Atom at(car11, loc5)
Atom at(car11, loc6)
Atom at(car11, loc7)
Atom at(car11, loc8)
Atom at(car11, loc9)
<none of those>
end_variable
begin_variable
var3
-1
12
Atom at(car12, loc1)
Atom at(car12, loc10)
Atom at(car12, loc11)
Atom at(car12, loc2)
Atom at(car12, loc3)
Atom at(car12, loc4)
Atom at(car12, loc5)
Atom at(car12, loc6)
Atom at(car12, loc7)
Atom at(car12, loc8)
Atom at(car12, loc9)
<none of those>
end_variable
begin_variable
var4
-1
12
Atom at(car2, loc1)
Atom at(car2, loc10)
Atom at(car2, loc11)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom at(car2, loc6)
Atom at(car2, loc7)
Atom at(car2, loc8)
Atom at(car2, loc9)
<none of those>
end_variable
begin_variable
var5
-1
12
Atom at(car3, loc1)
Atom at(car3, loc10)
Atom at(car3, loc11)
Atom at(car3, loc2)
Atom at(car3, loc3)
Atom at(car3, loc4)
Atom at(car3, loc5)
Atom at(car3, loc6)
Atom at(car3, loc7)
Atom at(car3, loc8)
Atom at(car3, loc9)
<none of those>
end_variable
begin_variable
var6
-1
12
Atom at(car4, loc1)
Atom at(car4, loc10)
Atom at(car4, loc11)
Atom at(car4, loc2)
Atom at(car4, loc3)
Atom at(car4, loc4)
Atom at(car4, loc5)
Atom at(car4, loc6)
Atom at(car4, loc7)
Atom at(car4, loc8)
Atom at(car4, loc9)
<none of those>
end_variable
begin_variable
var7
-1
12
Atom at(car5, loc1)
Atom at(car5, loc10)
Atom at(car5, loc11)
Atom at(car5, loc2)
Atom at(car5, loc3)
Atom at(car5, loc4)
Atom at(car5, loc5)
Atom at(car5, loc6)
Atom at(car5, loc7)
Atom at(car5, loc8)
Atom at(car5, loc9)
<none of those>
end_variable
begin_variable
var8
-1
12
Atom at(car6, loc1)
Atom at(car6, loc10)
Atom at(car6, loc11)
Atom at(car6, loc2)
Atom at(car6, loc3)
Atom at(car6, loc4)
Atom at(car6, loc5)
Atom at(car6, loc6)
Atom at(car6, loc7)
Atom at(car6, loc8)
Atom at(car6, loc9)
<none of those>
end_variable
begin_variable
var9
-1
12
Atom at(car7, loc1)
Atom at(car7, loc10)
Atom at(car7, loc11)
Atom at(car7, loc2)
Atom at(car7, loc3)
Atom at(car7, loc4)
Atom at(car7, loc5)
Atom at(car7, loc6)
Atom at(car7, loc7)
Atom at(car7, loc8)
Atom at(car7, loc9)
<none of those>
end_variable
begin_variable
var10
-1
12
Atom at(car8, loc1)
Atom at(car8, loc10)
Atom at(car8, loc11)
Atom at(car8, loc2)
Atom at(car8, loc3)
Atom at(car8, loc4)
Atom at(car8, loc5)
Atom at(car8, loc6)
Atom at(car8, loc7)
Atom at(car8, loc8)
Atom at(car8, loc9)
<none of those>
end_variable
begin_variable
var11
-1
12
Atom at(car9, loc1)
Atom at(car9, loc10)
Atom at(car9, loc11)
Atom at(car9, loc2)
Atom at(car9, loc3)
Atom at(car9, loc4)
Atom at(car9, loc5)
Atom at(car9, loc6)
Atom at(car9, loc7)
Atom at(car9, loc8)
Atom at(car9, loc9)
<none of those>
end_variable
12
begin_mutex_group
12
2 0
2 1
2 2
2 3
2 4
2 5
2 6
2 7
2 8
2 9
2 10
1 1
end_mutex_group
begin_mutex_group
12
3 0
3 1
3 2
3 3
3 4
3 5
3 6
3 7
3 8
3 9
3 10
1 2
end_mutex_group
begin_mutex_group
12
4 0
4 1
4 2
4 3
4 4
4 5
4 6
4 7
4 8
4 9
4 10
1 3
end_mutex_group
begin_mutex_group
12
5 0
5 1
5 2
5 3
5 4
5 5
5 6
5 7
5 8
5 9
5 10
1 4
end_mutex_group
begin_mutex_group
12
6 0
6 1
6 2
6 3
6 4
6 5
6 6
6 7
6 8
6 9
6 10
1 5
end_mutex_group
begin_mutex_group
12
7 0
7 1
7 2
7 3
7 4
7 5
7 6
7 7
7 8
7 9
7 10
1 6
end_mutex_group
begin_mutex_group
12
8 0
8 1
8 2
8 3
8 4
8 5
8 6
8 7
8 8
8 9
8 10
1 7
end_mutex_group
begin_mutex_group
12
9 0
9 1
9 2
9 3
9 4
9 5
9 6
9 7
9 8
9 9
9 10
1 8
end_mutex_group
begin_mutex_group
12
10 0
10 1
10 2
10 3
10 4
10 5
10 6
10 7
10 8
10 9
10 10
1 9
end_mutex_group
begin_mutex_group
12
11 0
11 1
11 2
11 3
11 4
11 5
11 6
11 7
11 8
11 9
11 10
1 10
end_mutex_group
begin_mutex_group
12
12 0
12 1
12 2
12 3
12 4
12 5
12 6
12 7
12 8
12 9
12 10
1 11
end_mutex_group
begin_mutex_group
12
13 0
13 1
13 2
13 3
13 4
13 5
13 6
13 7
13 8
13 9
13 10
1 12
end_mutex_group
begin_state
3
0
1
9
6
5
4
2
2
4
8
9
9
9
end_state
begin_goal
12
2 5
3 10
4 1
5 7
6 2
7 7
8 9
9 6
10 5
11 8
12 3
13 3
end_goal
374





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




10
9
240
2
0 9
1 10
11
109
2
0 10
1 0
11
0
231
2
0 0
1 10
1
232
2
0 1
1 10
2
233
2
0 2
1 10
3
234
2
0 3
1 10
4
235
2
0 4
1 10
5
236
2
0 5
1 10
6
237
2
0 6
1 10
7
238
2
0 7
1 10
8
239
2
0 8
1 10
9
240
2
0 9
1 10
10
241
2
0 10
1 10
end_DTG
begin_DTG
11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
110
2
0 0
1 0
11
0
242
2
0 0
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
111
2
0 1
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
112
2
0 2
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
113
2
0 3
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
114
2
0 4
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
115
2
0 5
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
116
2
0 6
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
117
2
0 7
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
11
118
2
0 8
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
10
252
2
0 10
1 11
11
119
2
0 9
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
11
120
2
0 10
1 0
11
0
242
2
0 0
1 11
1
243
2
0 1
1 11
2
244
2
0 2
1 11
3
245
2
0 3
1 11
4
246
2
0 4
1 11
5
247
2
0 5
1 11
6
248
2
0 6
1 11
7
249
2
0 7
1 11
8
250
2
0 8
1 11
9
251
2
0 9
1 11
10
252
2
0 10
1 11
end_DTG
begin_DTG
11
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
121
2
0 0
1 0
11
0
253
2
0 0
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
122
2
0 1
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
123
2
0 2
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
124
2
0 3
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
125
2
0 4
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
126
2
0 5
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
127
2
0 6
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
128
2
0 7
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
11
129
2
0 8
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
10
263
2
0 10
1 12
11
130
2
0 9
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
11
131
2
0 10
1 0
11
0
253
2
0 0
1 12
1
254
2
0 1
1 12
2
255
2
0 2
1 12
3
256
2
0 3
1 12
4
257
2
0 4
1 12
5
258
2
0 5
1 12
6
259
2
0 6
1 12
7
260
2
0 7
1 12
8
261
2
0 8
1 12
9
262
2
0 9
1 12
10
263
2
0 10
1 12
end_DTG
begin_CG
13
2 22
3 22
4 22
5 22
6 22
7 22
8 22
9 22
10 22
11 22
12 22
13 22
1 264
12
2 22
3 22
4 22
5 22
6 22
7 22
8 22
9 22
10 22
11 22
12 22
13 22
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
1
1 11
end_CG
