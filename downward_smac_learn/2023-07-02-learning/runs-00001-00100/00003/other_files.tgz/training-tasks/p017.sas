begin_version
3
end_version
begin_metric
0
end_metric
4
begin_variable
var2
-1
5
Atom at-ferry(loc1)
Atom at-ferry(loc2)
Atom at-ferry(loc3)
Atom at-ferry(loc4)
Atom at-ferry(loc5)
end_variable
begin_variable
var3
-1
2
Atom empty-ferry()
NegatedAtom empty-ferry()
end_variable
begin_variable
var0
-1
6
Atom at(car1, loc1)
Atom at(car1, loc2)
Atom at(car1, loc3)
Atom at(car1, loc4)
Atom at(car1, loc5)
Atom on(car1)
end_variable
begin_variable
var1
-1
6
Atom at(car2, loc1)
Atom at(car2, loc2)
Atom at(car2, loc3)
Atom at(car2, loc4)
Atom at(car2, loc5)
Atom on(car2)
end_variable
1
begin_mutex_group
3
1 0
2 5
3 5
end_mutex_group
begin_state
2
0
0
3
end_state
begin_goal
2
2 4
3 2
end_goal
40
begin_operator
board car1 loc1
1
0 0
2
0 2 0 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc2
1
0 1
2
0 2 1 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc3
1
0 2
2
0 2 2 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc4
1
0 3
2
0 2 3 5
0 1 0 1
0
end_operator
begin_operator
board car1 loc5
1
0 4
2
0 2 4 5
0 1 0 1
0
end_operator
begin_operator
board car2 loc1
1
0 0
2
0 3 0 5
0 1 0 1
0
end_operator
begin_operator
board car2 loc2
1
0 1
2
0 3 1 5
0 1 0 1
0
end_operator
begin_operator
board car2 loc3
1
0 2
2
0 3 2 5
0 1 0 1
0
end_operator
begin_operator
board car2 loc4
1
0 3
2
0 3 3 5
0 1 0 1
0
end_operator
begin_operator
board car2 loc5
1
0 4
2
0 3 4 5
0 1 0 1
0
end_operator
begin_operator
debark car1 loc1
1
0 0
2
0 2 5 0
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc2
1
0 1
2
0 2 5 1
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc3
1
0 2
2
0 2 5 2
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc4
1
0 3
2
0 2 5 3
0 1 -1 0
0
end_operator
begin_operator
debark car1 loc5
1
0 4
2
0 2 5 4
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc1
1
0 0
2
0 3 5 0
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc2
1
0 1
2
0 3 5 1
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc3
1
0 2
2
0 3 5 2
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc4
1
0 3
2
0 3 5 3
0 1 -1 0
0
end_operator
begin_operator
debark car2 loc5
1
0 4
2
0 3 5 4
0 1 -1 0
0
end_operator
begin_operator
sail loc1 loc2
0
1
0 0 0 1
0
end_operator
begin_operator
sail loc1 loc3
0
1
0 0 0 2
0
end_operator
begin_operator
sail loc1 loc4
0
1
0 0 0 3
0
end_operator
begin_operator
sail loc1 loc5
0
1
0 0 0 4
0
end_operator
begin_operator
sail loc2 loc1
0
1
0 0 1 0
0
end_operator
begin_operator
sail loc2 loc3
0
1
0 0 1 2
0
end_operator
begin_operator
sail loc2 loc4
0
1
0 0 1 3
0
end_operator
begin_operator
sail loc2 loc5
0
1
0 0 1 4
0
end_operator
begin_operator
sail loc3 loc1
0
1
0 0 2 0
0
end_operator
begin_operator
sail loc3 loc2
0
1
0 0 2 1
0
end_operator
begin_operator
sail loc3 loc4
0
1
0 0 2 3
0
end_operator
begin_operator
sail loc3 loc5
0
1
0 0 2 4
0
end_operator
begin_operator
sail loc4 loc1
0
1
0 0 3 0
0
end_operator
begin_operator
sail loc4 loc2
0
1
0 0 3 1
0
end_operator
begin_operator
sail loc4 loc3
0
1
0 0 3 2
0
end_operator
begin_operator
sail loc4 loc5
0
1
0 0 3 4
0
end_operator
begin_operator
sail loc5 loc1
0
1
0 0 4 0
0
end_operator
begin_operator
sail loc5 loc2
0
1
0 0 4 1
0
end_operator
begin_operator
sail loc5 loc3
0
1
0 0 4 2
0
end_operator
begin_operator
sail loc5 loc4
0
1
0 0 4 3
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 1
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
3
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
4
check 0
check 0
check 0
switch 0
check 0
check 1
10
check 1
11
check 1
12
check 1
13
check 1
14
check 0
switch 3
check 0
switch 0
check 0
switch 1
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
switch 1
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
switch 1
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
8
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
9
check 0
check 0
check 0
switch 0
check 0
check 1
15
check 1
16
check 1
17
check 1
18
check 1
19
check 0
switch 0
check 0
check 4
20
21
22
23
check 4
24
25
26
27
check 4
28
29
30
31
check 4
32
33
34
35
check 4
36
37
38
39
check 0
end_SG
begin_DTG
4
1
20
0
2
21
0
3
22
0
4
23
0
4
0
24
0
2
25
0
3
26
0
4
27
0
4
0
28
0
1
29
0
3
30
0
4
31
0
4
0
32
0
1
33
0
2
34
0
4
35
0
4
0
36
0
1
37
0
2
38
0
3
39
0
end_DTG
begin_DTG
10
1
0
2
2 0
0 0
1
1
2
2 1
0 1
1
2
2
2 2
0 2
1
3
2
2 3
0 3
1
4
2
2 4
0 4
1
5
2
3 0
0 0
1
6
2
3 1
0 1
1
7
2
3 2
0 2
1
8
2
3 3
0 3
1
9
2
3 4
0 4
10
0
10
2
2 5
0 0
0
11
2
2 5
0 1
0
12
2
2 5
0 2
0
13
2
2 5
0 3
0
14
2
2 5
0 4
0
15
2
3 5
0 0
0
16
2
3 5
0 1
0
17
2
3 5
0 2
0
18
2
3 5
0 3
0
19
2
3 5
0 4
end_DTG
begin_DTG
1
5
0
2
0 0
1 0
1
5
1
2
0 1
1 0
1
5
2
2
0 2
1 0
1
5
3
2
0 3
1 0
1
5
4
2
0 4
1 0
5
0
10
1
0 0
1
11
1
0 1
2
12
1
0 2
3
13
1
0 3
4
14
1
0 4
end_DTG
begin_DTG
1
5
5
2
0 0
1 0
1
5
6
2
0 1
1 0
1
5
7
2
0 2
1 0
1
5
8
2
0 3
1 0
1
5
9
2
0 4
1 0
5
0
15
1
0 0
1
16
1
0 1
2
17
1
0 2
3
18
1
0 3
4
19
1
0 4
end_DTG
begin_CG
3
2 10
3 10
1 20
2
2 5
3 5
1
1 10
1
1 10
end_CG
