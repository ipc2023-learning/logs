module DownwardHelper
  # convert paramils parameters to downward parameters
  def self.build_downward_params(parameters)
    landmarks = {}
    heuristics = {}
    heuristic_keys = []
    heuristics_with_pref_ops = []

    # Merge and Shrink
    if (parameters["mas_heuristic_enabled"] == "true")
      shrink_strategy = parameters.fetch("mas_heuristic_shrink_strategy")

      nick = "hMas"
      param_string = ["reduce_labels", "merge_strategy"].collect {|param|
        "#{param}=#{parameters.fetch("mas_heuristic_" + param)}"
      }
      shrink_strategies = {
        "bisimulation" => ["max_states", "max_states_before_merge", "greedy",
                           "threshold", "group_by_h", "at_limit"],
        "fh" => ["max_states", "max_states_before_merge", "shrink_f", "shrink_h"],
        "random" => ["max_states", "max_states_before_merge"]
      }
      shrink_params = shrink_strategies[shrink_strategy].collect {|param|
        "#{param}=#{parameters.fetch("mas_heuristic_shrink_" + shrink_strategy + "_" + param)}"
      }
      if (shrink_strategy == "bisimulation")
        # the following is a hack because we do not use the actual threshold as a parameter anymore,
        # but as a scale-parameter depending on the max_states-parameter in order to ensure that
        # threshold is always less or equal to max_states
        threshold = parameters.fetch("mas_heuristic_shrink_bisimulation_threshold").to_i
        if (threshold == 0)
          # we treat threshold = 0 as a special case which has the meaning "least possible threshold"
          threshold = 1
        else
          # if threshold > 0, then 1% of max_states is the smallest possible value for threshold
          max_states = parameters.fetch("mas_heuristic_shrink_bisimulation_max_states").to_i
          threshold = max_states * threshold / 100.0
          threshold = threshold.round
        end
        shrink_params[3] = "threshold=#{threshold}"
      end
      param_string << "shrink_strategy=shrink_#{shrink_strategy}(#{shrink_params.join(",")})"
      heuristics[nick] = "merge_and_shrink(#{param_string.join(",")})"
      heuristic_keys << nick
    end

    # Cegar
    if (parameters["cegar_heuristic_enabled"] == "true")
      nick = "hCegar"
      param_string = ["max_states", "max_time", "pick", "fact_order", "decomposition", "max_abstractions"].collect {|param|
        "#{param}=#{parameters.fetch("cegar_heuristic_" + param)}"
      }

      # hack: we use max_time as a scale parameter depending on timeout
      # this makes sure that max_time is always smaller or equal the timeout
      max_time = parameters.fetch("cegar_heuristic_max_time").to_i
      timeout = parameters.fetch("timeout").to_i
      max_time = timeout * max_time / 100.0
      max_time = max_time.round
      param_string[1] = "max_time=#{max_time}"

      heuristics[nick] = "cegar(#{param_string.join(",")})"
      heuristic_keys << nick
    end

    # PDBs
    pdb_heuristics = {
      "ipdb" => ["pdb_max_size", "collection_max_size", "num_samples", "min_improvement", "max_time"],
      #"gapdb" => ["pdb_max_size", "num_collections", "num_episodes", "mutation_probability", "disjoint"],
      "pdb" => ["max_states"],
      "zopdbs" => [],
      "cpdbs" => [],
    }
    pdb_heuristics.each {|heur, heur_params|
      if (parameters[heur + "_heuristic_enabled"] == "true")
        nick = "h" + heur
        param_string = heur_params.collect {|param|
          "#{param}=#{parameters.fetch(heur + "_heuristic_" + param)}"
        }
        if (heur == "ipdb")
          # the following is a hack because we do not use the actual pdb_max_size as a parameter anymore,
          # but as a scale-parameter depending on the collection_max_size parameter in order to ensure that
          # pdb_max_size is always less or equal to collection_max_size
          pdb_max_size = parameters.fetch("ipdb_heuristic_pdb_max_size").to_i
          # if pdb_max_size > 0, then 1% of collection_max_size is the smallest possible value for pdb_max_size
          collection_max_size = parameters.fetch("ipdb_heuristic_collection_max_size").to_i
          pdb_max_size = collection_max_size * pdb_max_size / 100.0
          pdb_max_size = pdb_max_size.round
          if (pdb_max_size < 1000)
            pdb_max_size = 1000
          end
          param_string[0] = "pdb_max_size=#{pdb_max_size}"

          # hack: we use max_time as a scale parameter depending on timeout
          # this makes sure that max_time is always smaller or equal the timeout
          max_time = parameters.fetch("ipdb_heuristic_max_time").to_i
          timeout = parameters.fetch("timeout").to_i
          max_time = timeout * max_time / 100.0
          max_time = max_time.round
          param_string[4] = "max_time=#{max_time}"
        end
        heuristics[nick] = "#{heur}(#{param_string.join(",")})"
        heuristic_keys << nick
      end
    }

    if (parameters["blind_heuristic_enabled"] == "true")
      heuristics["hBlind"] = "blind()"
      heuristic_keys << "hBlind"
    end

    if (parameters["hm_heuristic_enabled"] == "true")
      m_value 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




sage = parameters["search_#{search_no}_ehc_preferred_usage"]
          costType = parameters["search_#{search_no}_cost_type"]

          search = "ehc("

          # Find a heuristic with pref_ops set to true, pick the first
          # if there aren't any, use the alternate formulation.
          if (heuristics_with_pref_ops.size > 0)
            heur = heuristics_with_pref_ops[0]
            search = search+heur+",preferred=["+heur+"],"
            search = search+"preferred_usage=#{preferredUsage},"
          else
            heur = heuristic_keys[0]

            search = search+heur+","
          end

          search = search+"cost_type=#{costType},bound=#{bound})"

          searches << search
        elsif (searchType == "eager" || searchType == "lazy")
          searchW = parameters["search_#{search_no}_search_w"]
          searchBoost = parameters["search_#{search_no}_search_boost"]
          searchReopen = parameters["search_#{search_no}_search_reopen"]
          searchOpenListTb = parameters["search_#{search_no}_search_open_list_tb"]
          cost_type = parameters["search_#{search_no}_cost_type"]

          evals = []
          if (searchW == "-1")
            heuristic_keys.each { |key|
              evals << key
            }
          else
            searchNumerator = -1
            searchDenominator = -1
            if (searchW == "1" || searchW == "2" || searchW == "3" ||
                searchW == "5" || searchW == "7" || searchW == "10")
              searchNumerator = searchW.to_i
              searchDenominator = 1
            elsif (searchW == "1.125")
              searchNumerator = 9
              searchDenominator = 8
            elsif (searchW == "1.25")
              searchNumerator = 5
              searchDenominator = 4
            elsif (searchW == "1.5")
              searchNumerator = 3
              searchDenominator = 2
            end

            if (searchDenominator == -1 || searchNumerator == -1)
              $stderr.puts "Unrecognized search_w value: #{searchW}"
              Process.exit 1
            end

            heuristic_keys.each { |key|
              evalStr = "sum(["
              if (searchDenominator == 1)
                evalStr += "g(),"
              else
                evalStr += "weight(g(),#{searchDenominator}),"
              end

              if (searchNumerator == 1)
                evalStr += key
              else
                evalStr += "weight(#{key},#{searchNumerator})"
              end
              evalStr += "])"

              evals << evalStr
            }
          end

          openList1 = []
          if (heuristics_with_pref_ops.size == 0)
            if (searchOpenListTb == "true")
              heuristic_keys.each_index { |i|
                openList = "tiebreaking(["
                openList += evals[i]+","+heuristic_keys[i]
                openList += "])"
                openList1 << openList
              }
            else
              evals.each { |e|
                openList1 << "single("+e+")"
              }
            end
          else
            if (searchOpenListTb == "true")
              heuristic_keys.each_index { |i|
                openList = "tiebreaking(["
                openList = openList+evals[i]+","+heuristic_keys[i]

                openList1 << openList+"])"
                openList1 << openList+"],pref_only=true)"
              }
            else
              evals.each { |e|
                openList1 << "single("+e+")"
                openList1 << "single("+e+",pref_only=true)"
              }
            end
          end

          if (openList1.size == 1)
            finalOpenList = openList1[0]
          else
            finalOpenList = "alt([#{openList1.join(",")}],boost=#{searchBoost})"
          end

          search = "#{searchType}(#{finalOpenList},preferred=[#{heuristics_with_pref_ops.join(",")}],reopen_closed=#{searchReopen},"
          if (searchType == "eager")
            pathmax = parameters.fetch("search_#{search_no}_eager_pathmax")
            search += "pathmax=#{pathmax},"
            lookahead = parameters.fetch("search_#{search_no}_eager_lookahead", "false")
            if (lookahead == "true")
              search += "lookahead=#{lookahead},"
              search += "la_greedy=#{parameters.fetch("search_#{search_no}_eager_lookahead_greedy")},"
              search += "la_repair=#{parameters.fetch("search_#{search_no}_eager_lookahead_repair")},"
            end
          end
          search += "cost_type=#{cost_type},bound=#{bound})"

          searches << search
        end
      }

      if (searches.size > 1 || parameters["repeat_single_search"] == "true")
        search_string += "iterated([#{searches.join(",")}],"
        search_string += "bound=#{bound},repeat_last=true,continue_on_fail=true)"
      elsif (searches.size == 1)
        search_string += searches[0]
      else
        $stderr.puts "Must define at least one search."
        Process.exit 1
      end
    end
    search_string = search_string+"\""
    "#{landmarks_string} #{heuristic_string} #{search_string}"
  end
end
