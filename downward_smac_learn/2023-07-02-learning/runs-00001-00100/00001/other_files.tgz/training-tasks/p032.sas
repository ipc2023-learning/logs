begin_version
3
end_version
begin_metric
0
end_metric
21
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var4
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var7
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var8
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var9
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var10
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var11
-1
11
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var12
-1
11
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var13
-1
11
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var14
-1
11
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var17
-1
11
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var18
-1
11
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var19
-1
11
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var20
-1
11
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var15
-1
11
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var16
-1
11
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var5
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
11
begin_mutex_group
11
8 0
9 0
10 0
11 0
12 0
17 0
18 0
13 0
14 0
15 0
16 0
end_mutex_group
begin_mutex_group
11
0 0
9 0
10 1
11 1
12 1
17 1
18 1
13 1
14 1
15 1
16 1
end_mutex_group
begin_mutex_group
11
1 0
10 0
9 1
11 2
12 2
17 2
18 2
13 2
14 2
15 2
16 2
end_mutex_group
begin_mutex_group
11
2 0
11 0
9 2
10 2
12 3
17 3
18 3
13 3
14 3
15 3
16 3
end_mutex_group
begin_mutex_group
11
3 0
12 0
9 3
10 3
11 3
17 4
18 4
13 4
14 4
15 4
16 4
end_mutex_group
begin_mutex_group
11
19 0
17 0
9 4
10 4
11 4
12 4
18 5
13 5
14 5
15 5
16 5
end_mutex_group
begin_mutex_group
11
20 0
18 0
9 5
10 5
11 5
12 5
17 5
13 6
14 6
15 6
16 6
end_mutex_group
begin_mutex_group
11
4 0
13 0
9 6
10 6
11 6
12 6
17 6
18 6
14 7
15 7
16 7
end_mutex_group
begin_mutex_group
11
5 0
14 0
9 7
10 7
11 7
12 7
17 7
18 7
13 7
15 8
16 8
end_mutex_group
begin_mutex_group
11
6 0
15 0
9 8
10 8
11 8
12 8
17 8
18 8
13 8
14 8
16 9
end_mutex_group
begin_mutex_group
11
7 0
16 0
9 9
10 9
11 9
12 9
17 9
18 9
13 9
14 9
15 9
end_mutex_group
begin_state
1
1
1
1
0
1
1
1
0
8
5
4
9
2
4
3
1
10
7
1
1
end_state
begin_goal
12
9 6
10 2
11 9
12 2
13 4
14 1
15 8
16 10
17 10
18 8
19 0
20 0
end_goal
200
begin_operator
pickup b1
0
3
0 8 0 1
0 0 0 1
0 9 10 0
0
end_operator
begin_operator
pickup b10
0
3
0 8 0 1
0 1 0 1
0 10 10 0
0
end_operator
begin_operator
pickup b2
0
3
0 8 0 1
0 2 0 1
0 11 10 0
0
end_operator
begin_operator
pickup b3
0
3
0 8 0 1
0 3 0 1
0 12 10 0
0
end_operator
begin_operator
pickup b4
0
3
0 8 0 1
0 19 0 1
0 17 10 0
0
end_operator
begin_operator
pickup b5
0
3
0 8 0 1
0 20 0 1
0 18 10 0
0
end_operator
begin_operator
pickup b6
0
3
0 8 0 1
0 4 0 1
0 13 10 0
0
end_operator
begin_operator
pickup b7
0
3
0 8 0 1
0 5 0 1
0 14 10 0
0
end_operator
begin_operator
pickup b8
0
3
0 8 0 1
0 6 0 1
0 15 10 0
0
end_operator
begin_operator
pickup b9
0
3
0 8 0 1
0 7 0 1
0 16 10 0
0
end_operator
begin_operator
putdown b1
0
3
0 8 -1 0
0 0 -1 0
0 9 0 10
0
end_operator
begin_operator
putdown b10
0
3
0 8 -1 0
0 1 -1 0
0 10 0 10
0
end_operator
begin_operator
putdown b2




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
1
0
1
2
8 0
1 0
end_DTG
begin_DTG
10
1
38
1
0 0
2
39
1
1 0
3
40
1
3 0
4
41
1
19 0
5
42
1
20 0
6
43
1
4 0
7
44
1
5 0
8
45
1
6 0
9
46
1
7 0
10
12
0
1
0
128
2
8 0
2 0
1
0
129
2
8 0
2 0
1
0
130
2
8 0
2 0
1
0
131
2
8 0
2 0
1
0
132
2
8 0
2 0
1
0
133
2
8 0
2 0
1
0
134
2
8 0
2 0
1
0
135
2
8 0
2 0
1
0
136
2
8 0
2 0
1
0
2
2
8 0
2 0
end_DTG
begin_DTG
10
1
47
1
0 0
2
48
1
1 0
3
49
1
2 0
4
50
1
19 0
5
51
1
20 0
6
52
1
4 0
7
53
1
5 0
8
54
1
6 0
9
55
1
7 0
10
13
0
1
0
137
2
8 0
3 0
1
0
138
2
8 0
3 0
1
0
139
2
8 0
3 0
1
0
140
2
8 0
3 0
1
0
141
2
8 0
3 0
1
0
142
2
8 0
3 0
1
0
143
2
8 0
3 0
1
0
144
2
8 0
3 0
1
0
145
2
8 0
3 0
1
0
3
2
8 0
3 0
end_DTG
begin_DTG
10
1
74
1
0 0
2
75
1
1 0
3
76
1
2 0
4
77
1
3 0
5
78
1
19 0
6
79
1
20 0
7
80
1
5 0
8
81
1
6 0
9
82
1
7 0
10
16
0
1
0
164
2
8 0
4 0
1
0
165
2
8 0
4 0
1
0
166
2
8 0
4 0
1
0
167
2
8 0
4 0
1
0
168
2
8 0
4 0
1
0
169
2
8 0
4 0
1
0
170
2
8 0
4 0
1
0
171
2
8 0
4 0
1
0
172
2
8 0
4 0
1
0
6
2
8 0
4 0
end_DTG
begin_DTG
10
1
83
1
0 0
2
84
1
1 0
3
85
1
2 0
4
86
1
3 0
5
87
1
19 0
6
88
1
20 0
7
89
1
4 0
8
90
1
6 0
9
91
1
7 0
10
17
0
1
0
173
2
8 0
5 0
1
0
174
2
8 0
5 0
1
0
175
2
8 0
5 0
1
0
176
2
8 0
5 0
1
0
177
2
8 0
5 0
1
0
178
2
8 0
5 0
1
0
179
2
8 0
5 0
1
0
180
2
8 0
5 0
1
0
181
2
8 0
5 0
1
0
7
2
8 0
5 0
end_DTG
begin_DTG
10
1
92
1
0 0
2
93
1
1 0
3
94
1
2 0
4
95
1
3 0
5
96
1
19 0
6
97
1
20 0
7
98
1
4 0
8
99
1
5 0
9
100
1
7 0
10
18
0
1
0
182
2
8 0
6 0
1
0
183
2
8 0
6 0
1
0
184
2
8 0
6 0
1
0
185
2
8 0
6 0
1
0
186
2
8 0
6 0
1
0
187
2
8 0
6 0
1
0
188
2
8 0
6 0
1
0
189
2
8 0
6 0
1
0
190
2
8 0
6 0
1
0
8
2
8 0
6 0
end_DTG
begin_DTG
10
1
101
1
0 0
2
102
1
1 0
3
103
1
2 0
4
104
1
3 0
5
105
1
19 0
6
106
1
20 0
7
107
1
4 0
8
108
1
5 0
9
109
1
6 0
10
19
0
1
0
191
2
8 0
7 0
1
0
192
2
8 0
7 0
1
0
193
2
8 0
7 0
1
0
194
2
8 0
7 0
1
0
195
2
8 0
7 0
1
0
196
2
8 0
7 0
1
0
197
2
8 0
7 0
1
0
198
2
8 0
7 0
1
0
199
2
8 0
7 0
1
0
9
2
8 0
7 0
end_DTG
begin_DTG
10
1
56
1
0 0
2
57
1
1 0
3
58
1
2 0
4
59
1
3 0
5
60
1
20 0
6
61
1
4 0
7
62
1
5 0
8
63
1
6 0
9
64
1
7 0
10
14
0
1
0
146
2
8 0
19 0
1
0
147
2
8 0
19 0
1
0
148
2
8 0
19 0
1
0
149
2
8 0
19 0
1
0
150
2
8 0
19 0
1
0
151
2
8 0
19 0
1
0
152
2
8 0
19 0
1
0
153
2
8 0
19 0
1
0
154
2
8 0
19 0
1
0
4
2
8 0
19 0
end_DTG
begin_DTG
10
1
65
1
0 0
2
66
1
1 0
3
67
1
2 0
4
68
1
3 0
5
69
1
19 0
6
70
1
4 0
7
71
1
5 0
8
72
1
6 0
9
73
1
7 0
10
15
0
1
0
155
2
8 0
20 0
1
0
156
2
8 0
20 0
1
0
157
2
8 0
20 0
1
0
158
2
8 0
20 0
1
0
159
2
8 0
20 0
1
0
160
2
8 0
20 0
1
0
161
2
8 0
20 0
1
0
162
2
8 0
20 0
1
0
163
2
8 0
20 0
1
0
5
2
8 0
20 0
end_DTG
begin_DTG
19
1
23
1
9 0
1
105
1
16 0
1
96
1
15 0
1
87
1
14 0
1
78
1
13 0
1
69
1
18 0
1
50
1
12 0
1
41
1
11 0
1
32
1
10 0
1
4
2
8 0
17 10
1
146
2
8 0
17 1
1
147
2
8 0
17 2
1
148
2
8 0
17 3
1
149
2
8 0
17 4
1
150
2
8 0
17 5
1
151
2
8 0
17 6
1
152
2
8 0
17 7
1
153
2
8 0
17 8
1
154
2
8 0
17 9
10
0
14
1
17 0
0
113
3
8 0
0 0
9 4
0
122
3
8 0
1 0
10 4
0
131
3
8 0
2 0
11 4
0
140
3
8 0
3 0
12 4
0
159
3
8 0
20 0
18 5
0
168
3
8 0
4 0
13 5
0
177
3
8 0
5 0
14 5
0
186
3
8 0
6 0
15 5
0
195
3
8 0
7 0
16 5
end_DTG
begin_DTG
19
1
24
1
9 0
1
106
1
16 0
1
97
1
15 0
1
88
1
14 0
1
79
1
13 0
1
60
1
17 0
1
51
1
12 0
1
42
1
11 0
1
33
1
10 0
1
5
2
8 0
18 10
1
155
2
8 0
18 1
1
156
2
8 0
18 2
1
157
2
8 0
18 3
1
158
2
8 0
18 4
1
159
2
8 0
18 5
1
160
2
8 0
18 6
1
161
2
8 0
18 7
1
162
2
8 0
18 8
1
163
2
8 0
18 9
10
0
15
1
18 0
0
114
3
8 0
0 0
9 5
0
123
3
8 0
1 0
10 5
0
132
3
8 0
2 0
11 5
0
141
3
8 0
3 0
12 5
0
150
3
8 0
19 0
17 5
0
169
3
8 0
4 0
13 6
0
178
3
8 0
5 0
14 6
0
187
3
8 0
6 0
15 6
0
196
3
8 0
7 0
16 6
end_DTG
begin_CG
20
8 19
1 2
2 2
3 2
19 2
20 2
4 2
5 2
6 2
7 2
9 10
10 1
11 1
12 1
17 1
18 1
13 1
14 1
15 1
16 1
20
8 19
0 2
2 2
3 2
19 2
20 2
4 2
5 2
6 2
7 2
9 1
10 10
11 1
12 1
17 1
18 1
13 1
14 1
15 1
16 1
20
8 19
0 2
1 2
3 2
19 2
20 2
4 2
5 2
6 2
7 2
9 1
10 1
11 10
12 1
17 1
18 1
13 1
14 1
15 1
16 1
20
8 19
0 2
1 2
2 2
19 2
20 2
4 2
5 2
6 2
7 2
9 1
10 1
11 1
12 10
17 1
18 1
13 1
14 1
15 1
16 1
20
8 19
0 2
1 2
2 2
3 2
19 2
20 2
5 2
6 2
7 2
9 1
10 1
11 1
12 1
17 1
18 1
13 10
14 1
15 1
16 1
20
8 19
0 2
1 2
2 2
3 2
19 2
20 2
4 2
6 2
7 2
9 1
10 1
11 1
12 1
17 1
18 1
13 1
14 10
15 1
16 1
20
8 19
0 2
1 2
2 2
3 2
19 2
20 2
4 2
5 2
7 2
9 1
10 1
11 1
12 1
17 1
18 1
13 1
14 1
15 10
16 1
20
8 19
0 2
1 2
2 2
3 2
19 2
20 2
4 2
5 2
6 2
9 1
10 1
11 1
12 1
17 1
18 1
13 1
14 1
15 1
16 10
20
0 19
1 19
2 19
3 19
19 19
20 19
4 19
5 19
6 19
7 19
9 10
10 10
11 10
12 10
17 10
18 10
13 10
14 10
15 10
16 10
11
8 20
0 20
1 2
2 2
3 2
19 2
20 2
4 2
5 2
6 2
7 2
11
8 20
0 2
1 20
2 2
3 2
19 2
20 2
4 2
5 2
6 2
7 2
11
8 20
0 2
1 2
2 20
3 2
19 2
20 2
4 2
5 2
6 2
7 2
11
8 20
0 2
1 2
2 2
3 20
19 2
20 2
4 2
5 2
6 2
7 2
11
8 20
0 2
1 2
2 2
3 2
19 2
20 2
4 20
5 2
6 2
7 2
11
8 20
0 2
1 2
2 2
3 2
19 2
20 2
4 2
5 20
6 2
7 2
11
8 20
0 2
1 2
2 2
3 2
19 2
20 2
4 2
5 2
6 20
7 2
11
8 20
0 2
1 2
2 2
3 2
19 2
20 2
4 2
5 2
6 2
7 20
11
8 20
0 2
1 2
2 2
3 2
19 20
20 2
4 2
5 2
6 2
7 2
11
8 20
0 2
1 2
2 2
3 2
19 2
20 20
4 2
5 2
6 2
7 2
20
8 19
0 2
1 2
2 2
3 2
20 2
4 2
5 2
6 2
7 2
9 1
10 1
11 1
12 1
17 10
18 1
13 1
14 1
15 1
16 1
20
8 19
0 2
1 2
2 2
3 2
19 2
4 2
5 2
6 2
7 2
9 1
10 1
11 1
12 1
17 1
18 10
13 1
14 1
15 1
16 1
end_CG
