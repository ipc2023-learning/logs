begin_version
3
end_version
begin_metric
0
end_metric
17
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var6
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var7
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var8
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var9
-1
9
Atom holding(b1)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on-table(b1)
end_variable
begin_variable
var11
-1
9
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on-table(b3)
end_variable
begin_variable
var14
-1
9
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on-table(b6)
end_variable
begin_variable
var15
-1
9
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on-table(b7)
end_variable
begin_variable
var16
-1
9
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on-table(b8)
end_variable
begin_variable
var10
-1
9
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on-table(b2)
end_variable
begin_variable
var12
-1
9
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on-table(b4)
end_variable
begin_variable
var13
-1
9
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on-table(b5)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var5
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
9
begin_mutex_group
9
5 0
6 0
11 0
7 0
12 0
13 0
8 0
9 0
10 0
end_mutex_group
begin_mutex_group
9
0 0
6 0
11 1
7 1
12 1
13 1
8 1
9 1
10 1
end_mutex_group
begin_mutex_group
9
14 0
11 0
6 1
7 2
12 2
13 2
8 2
9 2
10 2
end_mutex_group
begin_mutex_group
9
1 0
7 0
6 2
11 2
12 3
13 3
8 3
9 3
10 3
end_mutex_group
begin_mutex_group
9
15 0
12 0
6 3
11 3
7 3
13 4
8 4
9 4
10 4
end_mutex_group
begin_mutex_group
9
16 0
13 0
6 4
11 4
7 4
12 4
8 5
9 5
10 5
end_mutex_group
begin_mutex_group
9
2 0
8 0
6 5
11 5
7 5
12 5
13 5
9 6
10 6
end_mutex_group
begin_mutex_group
9
3 0
9 0
6 6
11 6
7 6
12 6
13 6
8 6
10 7
end_mutex_group
begin_mutex_group
9
4 0
10 0
6 7
11 7
7 7
12 7
13 7
8 7
9 7
end_mutex_group
begin_state
1
1
0
1
1
0
2
6
4
7
2
8
4
1
1
1
1
end_state
begin_goal
11
6 8
7 6
8 3
9 8
10 1
11 7
12 5
13 8
14 0
15 0
16 0
end_goal
128
begin_operator
pickup b1
0
3
0 5 0 1
0 0 0 1
0 6 8 0
0
end_operator
begin_operator
pickup b2
0
3
0 5 0 1
0 14 0 1
0 11 8 0
0
end_operator
begin_operator
pickup b3
0
3
0 5 0 1
0 1 0 1
0 7 8 0
0
end_operator
begin_operator
pickup b4
0
3
0 5 0 1
0 15 0 1
0 12 8 0
0
end_operator
begin_operator
pickup b5
0
3
0 5 0 1
0 16 0 1
0 13 8 0
0
end_operator
begin_operator
pickup b6
0
3
0 5 0 1
0 2 0 1
0 8 8 0
0
end_operator
begin_operator
pickup b7
0
3
0 5 0 1
0 3 0 1
0 9 8 0
0
end_operator
begin_operator
pickup b8
0
3
0 5 0 1
0 4 0 1
0 10 8 0
0
end_operator
begin_operator
putdown b1
0
3
0 5 -1 0
0 0 -1 0
0 6 0 8
0
end_operator
begin_operator
putdown b2
0
3
0 5 -1 0
0 14 -1 0
0 11 0 8
0
end_operator
begin_operator
putdown b3
0
3
0 5 -1 0
0 1 -1 0
0 7 0 8
0
end_operator
begin_operator
putdown b4
0
3
0 5 -1 0
0 15 -1 0
0 12 0 8
0
end_operator
begin_operator
putdown b5
0
3
0 5 -1 0
0 16 -1 0
0 13 0 8
0
end_operator
begin_operator
putdown b6
0
3
0 5 -1 0
0 2 -1 0
0 8 0 8
0
end_operator
begin_operator
putdown b7
0
3
0 5 -1 0
0 3 -1 0
0 9 0 8
0
end_operator
begin_operator
putdown b8
0
3
0 5 -1 0
0 4 -1 0
0 10 0 8
0
end_operator
begin_operator
stack b1 b2
0
4
0 5 -1 0
0 0 -1 0
0 14 0 1
0 6 0 1
0
end_operator
begin_operator
stack b1 b3
0
4
0 5 -1 0
0 0 -1 0
0 1 0 1
0 6 0 2
0
end_operator
begin_operator
stack b1 b4
0
4
0 5 -1 0
0 0 -1 0
0 15 0 1
0 6 0 3
0
end_operator
begin_operator
stack b1 b5
0
4
0 5 -1 0
0 0 -1 0
0 16 0 1
0 6 0 4
0
end_operator
begin_operator
stack b1 b6
0
4
0 5 -1 0
0 0 -1 0
0 2 0 1
0 6 0 5
0
end_operator
begin_operator
stack b1 b7
0
4
0 5 -1 0
0 0 -1 0
0 3 0 1
0 6 0 6
0
end_operator
begin_operator
stack b1 b8
0
4
0 5 -1 0
0 0 -1 0
0 4 0 1
0 6 0 7
0
end_operator
begin_operator
stack b2 b1
0
4
0 5 -1 0
0 0 0 1
0 14 -1 0
0 11 0 1
0
end_operator
begin_operator
stack b2 b3
0
4
0 5 -1 0
0 14 -1 0
0 1 0 1
0 11 0 2
0
end_operator
begin_operator
stack b2 b4
0
4
0 5 -1 0
0 14 -1 0
0 15 0 1
0 11 0 3
0
end_operator
begin_operator
stack b2 b5
0
4
0 5 -1 0
0 14 -1 0
0 16 0 1
0 11 0 4
0
end_operator
begin_operator
stack b2 b6
0
4
0 5 -1 0
0 14 -1 0
0 2 0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




107
2
2 0
8 1
1
108
2
2 0
8 2
1
109
2
2 0
8 3
1
110
2
2 0
8 4
1
111
2
2 0
8 5
1
96
2
15 0
12 4
1
113
2
2 0
8 7
1
114
2
3 0
9 1
1
115
2
3 0
9 2
1
116
2
3 0
9 3
1
117
2
3 0
9 4
1
118
2
3 0
9 5
1
119
2
3 0
9 6
1
120
2
3 0
9 7
1
121
2
4 0
10 1
1
122
2
4 0
10 2
1
123
2
4 0
10 3
1
124
2
4 0
10 4
1
125
2
4 0
10 5
1
126
2
4 0
10 6
1
127
2
4 0
10 7
1
80
2
14 0
11 2
1
1
2
14 0
11 8
1
2
2
1 0
7 8
1
3
2
15 0
12 8
1
4
2
16 0
13 8
1
5
2
2 0
8 8
1
6
2
3 0
9 8
1
7
2
4 0
10 8
1
72
2
0 0
6 1
1
73
2
0 0
6 2
1
74
2
0 0
6 3
1
75
2
0 0
6 4
1
76
2
0 0
6 5
1
77
2
0 0
6 6
1
78
2
0 0
6 7
1
79
2
14 0
11 1
1
0
2
0 0
6 8
1
81
2
14 0
11 3
1
82
2
14 0
11 4
1
83
2
14 0
11 5
1
84
2
14 0
11 6
1
85
2
14 0
11 7
1
86
2
1 0
7 1
1
87
2
1 0
7 2
1
88
2
1 0
7 3
1
89
2
1 0
7 4
1
90
2
1 0
7 5
1
91
2
1 0
7 6
1
92
2
1 0
7 7
1
93
2
15 0
12 1
1
94
2
15 0
12 2
1
95
2
15 0
12 3
8
0
9
1
11 0
0
10
1
7 0
0
11
1
12 0
0
12
1
13 0
0
13
1
8 0
0
14
1
9 0
0
15
1
10 0
0
8
1
6 0
end_DTG
begin_DTG
8
1
16
1
14 0
2
17
1
1 0
3
18
1
15 0
4
19
1
16 0
5
20
1
2 0
6
21
1
3 0
7
22
1
4 0
8
8
0
1
0
72
2
5 0
0 0
1
0
73
2
5 0
0 0
1
0
74
2
5 0
0 0
1
0
75
2
5 0
0 0
1
0
76
2
5 0
0 0
1
0
77
2
5 0
0 0
1
0
78
2
5 0
0 0
1
0
0
2
5 0
0 0
end_DTG
begin_DTG
8
1
30
1
0 0
2
31
1
14 0
3
32
1
15 0
4
33
1
16 0
5
34
1
2 0
6
35
1
3 0
7
36
1
4 0
8
10
0
1
0
86
2
5 0
1 0
1
0
87
2
5 0
1 0
1
0
88
2
5 0
1 0
1
0
89
2
5 0
1 0
1
0
90
2
5 0
1 0
1
0
91
2
5 0
1 0
1
0
92
2
5 0
1 0
1
0
2
2
5 0
1 0
end_DTG
begin_DTG
8
1
51
1
0 0
2
52
1
14 0
3
53
1
1 0
4
54
1
15 0
5
55
1
16 0
6
56
1
3 0
7
57
1
4 0
8
13
0
1
0
107
2
5 0
2 0
1
0
108
2
5 0
2 0
1
0
109
2
5 0
2 0
1
0
110
2
5 0
2 0
1
0
111
2
5 0
2 0
1
0
112
2
5 0
2 0
1
0
113
2
5 0
2 0
1
0
5
2
5 0
2 0
end_DTG
begin_DTG
8
1
58
1
0 0
2
59
1
14 0
3
60
1
1 0
4
61
1
15 0
5
62
1
16 0
6
63
1
2 0
7
64
1
4 0
8
14
0
1
0
114
2
5 0
3 0
1
0
115
2
5 0
3 0
1
0
116
2
5 0
3 0
1
0
117
2
5 0
3 0
1
0
118
2
5 0
3 0
1
0
119
2
5 0
3 0
1
0
120
2
5 0
3 0
1
0
6
2
5 0
3 0
end_DTG
begin_DTG
8
1
65
1
0 0
2
66
1
14 0
3
67
1
1 0
4
68
1
15 0
5
69
1
16 0
6
70
1
2 0
7
71
1
3 0
8
15
0
1
0
121
2
5 0
4 0
1
0
122
2
5 0
4 0
1
0
123
2
5 0
4 0
1
0
124
2
5 0
4 0
1
0
125
2
5 0
4 0
1
0
126
2
5 0
4 0
1
0
127
2
5 0
4 0
1
0
7
2
5 0
4 0
end_DTG
begin_DTG
8
1
23
1
0 0
2
24
1
1 0
3
25
1
15 0
4
26
1
16 0
5
27
1
2 0
6
28
1
3 0
7
29
1
4 0
8
9
0
1
0
79
2
5 0
14 0
1
0
80
2
5 0
14 0
1
0
81
2
5 0
14 0
1
0
82
2
5 0
14 0
1
0
83
2
5 0
14 0
1
0
84
2
5 0
14 0
1
0
85
2
5 0
14 0
1
0
1
2
5 0
14 0
end_DTG
begin_DTG
8
1
37
1
0 0
2
38
1
14 0
3
39
1
1 0
4
40
1
16 0
5
41
1
2 0
6
42
1
3 0
7
43
1
4 0
8
11
0
1
0
93
2
5 0
15 0
1
0
94
2
5 0
15 0
1
0
95
2
5 0
15 0
1
0
96
2
5 0
15 0
1
0
97
2
5 0
15 0
1
0
98
2
5 0
15 0
1
0
99
2
5 0
15 0
1
0
3
2
5 0
15 0
end_DTG
begin_DTG
8
1
44
1
0 0
2
45
1
14 0
3
46
1
1 0
4
47
1
15 0
5
48
1
2 0
6
49
1
3 0
7
50
1
4 0
8
12
0
1
0
100
2
5 0
16 0
1
0
101
2
5 0
16 0
1
0
102
2
5 0
16 0
1
0
103
2
5 0
16 0
1
0
104
2
5 0
16 0
1
0
105
2
5 0
16 0
1
0
106
2
5 0
16 0
1
0
4
2
5 0
16 0
end_DTG
begin_DTG
15
1
16
1
6 0
1
31
1
7 0
1
38
1
12 0
1
45
1
13 0
1
52
1
8 0
1
59
1
9 0
1
66
1
10 0
1
1
2
5 0
11 8
1
79
2
5 0
11 1
1
80
2
5 0
11 2
1
81
2
5 0
11 3
1
82
2
5 0
11 4
1
83
2
5 0
11 5
1
84
2
5 0
11 6
1
85
2
5 0
11 7
8
0
9
1
11 0
0
72
3
5 0
0 0
6 1
0
87
3
5 0
1 0
7 2
0
94
3
5 0
15 0
12 2
0
101
3
5 0
16 0
13 2
0
108
3
5 0
2 0
8 2
0
115
3
5 0
3 0
9 2
0
122
3
5 0
4 0
10 2
end_DTG
begin_DTG
15
1
18
1
6 0
1
25
1
11 0
1
32
1
7 0
1
47
1
13 0
1
54
1
8 0
1
61
1
9 0
1
68
1
10 0
1
3
2
5 0
12 8
1
93
2
5 0
12 1
1
94
2
5 0
12 2
1
95
2
5 0
12 3
1
96
2
5 0
12 4
1
97
2
5 0
12 5
1
98
2
5 0
12 6
1
99
2
5 0
12 7
8
0
11
1
12 0
0
74
3
5 0
0 0
6 3
0
81
3
5 0
14 0
11 3
0
88
3
5 0
1 0
7 3
0
103
3
5 0
16 0
13 4
0
110
3
5 0
2 0
8 4
0
117
3
5 0
3 0
9 4
0
124
3
5 0
4 0
10 4
end_DTG
begin_DTG
15
1
19
1
6 0
1
26
1
11 0
1
33
1
7 0
1
40
1
12 0
1
55
1
8 0
1
62
1
9 0
1
69
1
10 0
1
4
2
5 0
13 8
1
100
2
5 0
13 1
1
101
2
5 0
13 2
1
102
2
5 0
13 3
1
103
2
5 0
13 4
1
104
2
5 0
13 5
1
105
2
5 0
13 6
1
106
2
5 0
13 7
8
0
12
1
13 0
0
75
3
5 0
0 0
6 4
0
82
3
5 0
14 0
11 4
0
89
3
5 0
1 0
7 4
0
96
3
5 0
15 0
12 4
0
111
3
5 0
2 0
8 5
0
118
3
5 0
3 0
9 5
0
125
3
5 0
4 0
10 5
end_DTG
begin_CG
16
5 15
14 2
1 2
15 2
16 2
2 2
3 2
4 2
6 8
11 1
7 1
12 1
13 1
8 1
9 1
10 1
16
5 15
0 2
14 2
15 2
16 2
2 2
3 2
4 2
6 1
11 1
7 8
12 1
13 1
8 1
9 1
10 1
16
5 15
0 2
14 2
1 2
15 2
16 2
3 2
4 2
6 1
11 1
7 1
12 1
13 1
8 8
9 1
10 1
16
5 15
0 2
14 2
1 2
15 2
16 2
2 2
4 2
6 1
11 1
7 1
12 1
13 1
8 1
9 8
10 1
16
5 15
0 2
14 2
1 2
15 2
16 2
2 2
3 2
6 1
11 1
7 1
12 1
13 1
8 1
9 1
10 8
16
0 15
14 15
1 15
15 15
16 15
2 15
3 15
4 15
6 8
11 8
7 8
12 8
13 8
8 8
9 8
10 8
9
5 16
0 16
14 2
1 2
15 2
16 2
2 2
3 2
4 2
9
5 16
0 2
14 2
1 16
15 2
16 2
2 2
3 2
4 2
9
5 16
0 2
14 2
1 2
15 2
16 2
2 16
3 2
4 2
9
5 16
0 2
14 2
1 2
15 2
16 2
2 2
3 16
4 2
9
5 16
0 2
14 2
1 2
15 2
16 2
2 2
3 2
4 16
9
5 16
0 2
14 16
1 2
15 2
16 2
2 2
3 2
4 2
9
5 16
0 2
14 2
1 2
15 16
16 2
2 2
3 2
4 2
9
5 16
0 2
14 2
1 2
15 2
16 16
2 2
3 2
4 2
16
5 15
0 2
1 2
15 2
16 2
2 2
3 2
4 2
6 1
11 8
7 1
12 1
13 1
8 1
9 1
10 1
16
5 15
0 2
14 2
1 2
16 2
2 2
3 2
4 2
6 1
11 1
7 1
12 8
13 1
8 1
9 1
10 1
16
5 15
0 2
14 2
1 2
15 2
2 2
3 2
4 2
6 1
11 1
7 1
12 1
13 8
8 1
9 1
10 1
end_CG
