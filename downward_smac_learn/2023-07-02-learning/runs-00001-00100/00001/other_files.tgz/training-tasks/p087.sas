begin_version
3
end_version
begin_metric
0
end_metric
53
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var16
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var17
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var18
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var19
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var20
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var21
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var23
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var24
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var25
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var26
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var27
-1
27
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var29
-1
27
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b26)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var33
-1
27
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b21)
Atom on(b15, b22)
Atom on(b15, b23)
Atom on(b15, b24)
Atom on(b15, b25)
Atom on(b15, b26)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var35
-1
27
Atom holding(b17)
Atom on(b17, b1)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b21)
Atom on(b17, b22)
Atom on(b17, b23)
Atom on(b17, b24)
Atom on(b17, b25)
Atom on(b17, b26)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b8)
Atom on(b17, b9)
Atom on-table(b17)
end_variable
begin_variable
var36
-1
27
Atom holding(b18)
Atom on(b18, b1)
Atom on(b18, b10)
Atom on(b18, b11)
Atom on(b18, b12)
Atom on(b18, b13)
Atom on(b18, b14)
Atom on(b18, b15)
Atom on(b18, b16)
Atom on(b18, b17)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b20)
Atom on(b18, b21)
Atom on(b18, b22)
Atom on(b18, b23)
Atom on(b18, b24)
Atom on(b18, b25)
Atom on(b18, b26)
Atom on(b18, b3)
Atom on(b18, b4)
Atom on(b18, b5)
Atom on(b18, b6)
Atom on(b18, b7)
Atom on(b18, b8)
Atom on(b18, b9)
Atom on-table(b18)
end_variable
begin_variable
var37
-1
27
Atom holding(b19)
Atom on(b19, b1)
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b12)
Atom on(b19, b13)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b18)
Atom on(b19, b2)
Atom on(b19, b20)
Atom on(b19, b21)
Atom on(b19, b22)
Atom on(b19, b23)
Atom on(b19, b24)
Atom on(b19, b25)
Atom on(b19, b26)
Atom on(b19, b3)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b8)
Atom on(b19, b9)
Atom on-table(b19)
end_variable
begin_variable
var38
-1
27
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b22)
Atom on(b2, b23)
Atom on(b2, b24)
Atom on(b2, b25)
Atom on(b2, b26)
Atom on(b2, b




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3 51
14 51
15 51
52 51
16 51
17 51
18 51
19 51
21 26
41 26
22 26
42 26
43 26
44 26
23 26
45 26
24 26
25 26
26 26
27 26
28 26
29 26
30 26
31 26
32 26
33 26
34 26
35 26
36 26
46 26
37 26
38 26
39 26
40 26
27
20 52
0 52
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 52
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 52
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 52
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 52
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 52
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 52
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 52
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 52
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 52
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 52
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 52
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 52
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 52
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 52
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 52
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 52
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 52
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 52
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 52
27
20 52
0 2
47 52
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 52
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 52
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 52
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 52
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
27
20 52
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 52
16 2
17 2
18 2
19 2
52
20 51
0 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
21 1
41 26
22 1
42 1
43 1
44 1
23 1
45 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
46 1
37 1
38 1
39 1
40 1
52
20 51
0 2
47 2
1 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
21 1
41 1
22 1
42 26
43 1
44 1
23 1
45 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
46 1
37 1
38 1
39 1
40 1
52
20 51
0 2
47 2
1 2
48 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
21 1
41 1
22 1
42 1
43 26
44 1
23 1
45 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
46 1
37 1
38 1
39 1
40 1
52
20 51
0 2
47 2
1 2
48 2
49 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
21 1
41 1
22 1
42 1
43 1
44 26
23 1
45 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
46 1
37 1
38 1
39 1
40 1
52
20 51
0 2
47 2
1 2
48 2
49 2
50 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
52 2
16 2
17 2
18 2
19 2
21 1
41 1
22 1
42 1
43 1
44 1
23 1
45 26
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
46 1
37 1
38 1
39 1
40 1
52
20 51
0 2
47 2
1 2
48 2
49 2
50 2
2 2
51 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
21 1
41 1
22 1
42 1
43 1
44 1
23 1
45 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
46 26
37 1
38 1
39 1
40 1
end_CG
