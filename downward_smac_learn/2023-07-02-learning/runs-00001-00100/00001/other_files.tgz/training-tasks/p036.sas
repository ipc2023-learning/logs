begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var5
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var6
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var7
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var8
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var9
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var12
-1
12
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var14
-1
12
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var15
-1
12
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var16
-1
12
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var17
-1
12
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var18
-1
12
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var19
-1
12
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var20
-1
12
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var13
-1
12
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var21
-1
12
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var22
-1
12
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var10
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var11
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
12
begin_mutex_group
12
8 0
9 0
17 0
10 0
11 0
12 0
13 0
14 0
15 0
16 0
18 0
19 0
end_mutex_group
begin_mutex_group
12
0 0
9 0
17 1
10 1
11 1
12 1
13 1
14 1
15 1
16 1
18 1
19 1
end_mutex_group
begin_mutex_group
12
20 0
17 0
9 1
10 2
11 2
12 2
13 2
14 2
15 2
16 2
18 2
19 2
end_mutex_group
begin_mutex_group
12
1 0
10 0
9 2
17 2
11 3
12 3
13 3
14 3
15 3
16 3
18 3
19 3
end_mutex_group
begin_mutex_group
12
2 0
11 0
9 3
17 3
10 3
12 4
13 4
14 4
15 4
16 4
18 4
19 4
end_mutex_group
begin_mutex_group
12
3 0
12 0
9 4
17 4
10 4
11 4
13 5
14 5
15 5
16 5
18 5
19 5
end_mutex_group
begin_mutex_group
12
4 0
13 0
9 5
17 5
10 5
11 5
12 5
14 6
15 6
16 6
18 6
19 6
end_mutex_group
begin_mutex_group
12
5 0
14 0
9 6
17 6
10 6
11 6
12 6
13 6
15 7
16 7
18 7
19 7
end_mutex_group
begin_mutex_group
12
6 0
15 0
9 7
17 7
10 7
11 7
12 7
13 7
14 7
16 8
18 8
19 8
end_mutex_group
begin_mutex_group
12
7 0
16 0
9 8
17 8
10 8
11 8
12 8
13 8
14 8
15 8
18 9
19 9
end_mutex_group
begin_mutex_group
12
21 0
18 0
9 9
17 9
10 9
11 9
12 9
13 9
14 9
15 9
16 9
19 10
end_mutex_group
begin_mutex_group
12
22 0
19 0
9 10
17 10
10 10
11 10
12 10
13 10
14 10
15 10
16 10
18 10
end_mutex_group
begin_state
1
1
0
1
1
1
1
1
0
7
9
2
8
11
3
6
1
4
11
7
1
1
0
end_state
begin_goal
14
9 6
10 4
11 7
12 8
13 11
14 6
15 11
16 4
17 11
18 3
19 1
20 0
21 0
22 0
end_goal
242
begin_operator
pickup b1
0
3
0 8 0 1
0 0 0 1
0 9 11 0
0
end_operator
begin_operator
pickup b10
0
3
0 8 0 1
0 20 0 1
0 17 11 0
0
end_operator
begin_operator
pickup b11
0
3
0 8 0 1
0 1 0 1
0 10 11 0
0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
6 0
1
0
208
2
8 0
6 0
1
0
209
2
8 0
6 0
1
0
210
2
8 0
6 0
1
0
211
2
8 0
6 0
1
0
7
2
8 0
6 0
end_DTG
begin_DTG
11
1
102
1
0 0
2
103
1
20 0
3
104
1
1 0
4
105
1
2 0
5
106
1
3 0
6
107
1
4 0
7
108
1
5 0
8
109
1
6 0
9
110
1
21 0
10
111
1
22 0
11
19
0
1
0
212
2
8 0
7 0
1
0
213
2
8 0
7 0
1
0
214
2
8 0
7 0
1
0
215
2
8 0
7 0
1
0
216
2
8 0
7 0
1
0
217
2
8 0
7 0
1
0
218
2
8 0
7 0
1
0
219
2
8 0
7 0
1
0
220
2
8 0
7 0
1
0
221
2
8 0
7 0
1
0
8
2
8 0
7 0
end_DTG
begin_DTG
11
1
32
1
0 0
2
33
1
1 0
3
34
1
2 0
4
35
1
3 0
5
36
1
4 0
6
37
1
5 0
7
38
1
6 0
8
39
1
7 0
9
40
1
21 0
10
41
1
22 0
11
12
0
1
0
142
2
8 0
20 0
1
0
143
2
8 0
20 0
1
0
144
2
8 0
20 0
1
0
145
2
8 0
20 0
1
0
146
2
8 0
20 0
1
0
147
2
8 0
20 0
1
0
148
2
8 0
20 0
1
0
149
2
8 0
20 0
1
0
150
2
8 0
20 0
1
0
151
2
8 0
20 0
1
0
1
2
8 0
20 0
end_DTG
begin_DTG
11
1
112
1
0 0
2
113
1
20 0
3
114
1
1 0
4
115
1
2 0
5
116
1
3 0
6
117
1
4 0
7
118
1
5 0
8
119
1
6 0
9
120
1
7 0
10
121
1
22 0
11
20
0
1
0
222
2
8 0
21 0
1
0
223
2
8 0
21 0
1
0
224
2
8 0
21 0
1
0
225
2
8 0
21 0
1
0
226
2
8 0
21 0
1
0
227
2
8 0
21 0
1
0
228
2
8 0
21 0
1
0
229
2
8 0
21 0
1
0
230
2
8 0
21 0
1
0
231
2
8 0
21 0
1
0
9
2
8 0
21 0
end_DTG
begin_DTG
11
1
122
1
0 0
2
123
1
20 0
3
124
1
1 0
4
125
1
2 0
5
126
1
3 0
6
127
1
4 0
7
128
1
5 0
8
129
1
6 0
9
130
1
7 0
10
131
1
21 0
11
21
0
1
0
232
2
8 0
22 0
1
0
233
2
8 0
22 0
1
0
234
2
8 0
22 0
1
0
235
2
8 0
22 0
1
0
236
2
8 0
22 0
1
0
237
2
8 0
22 0
1
0
238
2
8 0
22 0
1
0
239
2
8 0
22 0
1
0
240
2
8 0
22 0
1
0
241
2
8 0
22 0
1
0
10
2
8 0
22 0
end_DTG
begin_DTG
21
1
22
1
9 0
1
123
1
19 0
1
113
1
18 0
1
103
1
16 0
1
93
1
15 0
1
83
1
14 0
1
73
1
13 0
1
63
1
12 0
1
53
1
11 0
1
43
1
10 0
1
1
2
8 0
17 11
1
142
2
8 0
17 1
1
143
2
8 0
17 2
1
144
2
8 0
17 3
1
145
2
8 0
17 4
1
146
2
8 0
17 5
1
147
2
8 0
17 6
1
148
2
8 0
17 7
1
149
2
8 0
17 8
1
150
2
8 0
17 9
1
151
2
8 0
17 10
11
0
12
1
17 0
0
132
3
8 0
0 0
9 1
0
153
3
8 0
1 0
10 2
0
163
3
8 0
2 0
11 2
0
173
3
8 0
3 0
12 2
0
183
3
8 0
4 0
13 2
0
193
3
8 0
5 0
14 2
0
203
3
8 0
6 0
15 2
0
213
3
8 0
7 0
16 2
0
223
3
8 0
21 0
18 2
0
233
3
8 0
22 0
19 2
end_DTG
begin_DTG
21
1
30
1
9 0
1
131
1
19 0
1
110
1
16 0
1
100
1
15 0
1
90
1
14 0
1
80
1
13 0
1
70
1
12 0
1
60
1
11 0
1
50
1
10 0
1
40
1
17 0
1
9
2
8 0
18 11
1
222
2
8 0
18 1
1
223
2
8 0
18 2
1
224
2
8 0
18 3
1
225
2
8 0
18 4
1
226
2
8 0
18 5
1
227
2
8 0
18 6
1
228
2
8 0
18 7
1
229
2
8 0
18 8
1
230
2
8 0
18 9
1
231
2
8 0
18 10
11
0
20
1
18 0
0
140
3
8 0
0 0
9 9
0
150
3
8 0
20 0
17 9
0
160
3
8 0
1 0
10 9
0
170
3
8 0
2 0
11 9
0
180
3
8 0
3 0
12 9
0
190
3
8 0
4 0
13 9
0
200
3
8 0
5 0
14 9
0
210
3
8 0
6 0
15 9
0
220
3
8 0
7 0
16 9
0
241
3
8 0
22 0
19 10
end_DTG
begin_DTG
21
1
31
1
9 0
1
121
1
18 0
1
111
1
16 0
1
101
1
15 0
1
91
1
14 0
1
81
1
13 0
1
71
1
12 0
1
61
1
11 0
1
51
1
10 0
1
41
1
17 0
1
10
2
8 0
19 11
1
232
2
8 0
19 1
1
233
2
8 0
19 2
1
234
2
8 0
19 3
1
235
2
8 0
19 4
1
236
2
8 0
19 5
1
237
2
8 0
19 6
1
238
2
8 0
19 7
1
239
2
8 0
19 8
1
240
2
8 0
19 9
1
241
2
8 0
19 10
11
0
21
1
19 0
0
141
3
8 0
0 0
9 10
0
151
3
8 0
20 0
17 10
0
161
3
8 0
1 0
10 10
0
171
3
8 0
2 0
11 10
0
181
3
8 0
3 0
12 10
0
191
3
8 0
4 0
13 10
0
201
3
8 0
5 0
14 10
0
211
3
8 0
6 0
15 10
0
221
3
8 0
7 0
16 10
0
231
3
8 0
21 0
18 10
end_DTG
begin_CG
22
8 21
20 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
21 2
22 2
9 11
17 1
10 1
11 1
12 1
13 1
14 1
15 1
16 1
18 1
19 1
22
8 21
0 2
20 2
2 2
3 2
4 2
5 2
6 2
7 2
21 2
22 2
9 1
17 1
10 11
11 1
12 1
13 1
14 1
15 1
16 1
18 1
19 1
22
8 21
0 2
20 2
1 2
3 2
4 2
5 2
6 2
7 2
21 2
22 2
9 1
17 1
10 1
11 11
12 1
13 1
14 1
15 1
16 1
18 1
19 1
22
8 21
0 2
20 2
1 2
2 2
4 2
5 2
6 2
7 2
21 2
22 2
9 1
17 1
10 1
11 1
12 11
13 1
14 1
15 1
16 1
18 1
19 1
22
8 21
0 2
20 2
1 2
2 2
3 2
5 2
6 2
7 2
21 2
22 2
9 1
17 1
10 1
11 1
12 1
13 11
14 1
15 1
16 1
18 1
19 1
22
8 21
0 2
20 2
1 2
2 2
3 2
4 2
6 2
7 2
21 2
22 2
9 1
17 1
10 1
11 1
12 1
13 1
14 11
15 1
16 1
18 1
19 1
22
8 21
0 2
20 2
1 2
2 2
3 2
4 2
5 2
7 2
21 2
22 2
9 1
17 1
10 1
11 1
12 1
13 1
14 1
15 11
16 1
18 1
19 1
22
8 21
0 2
20 2
1 2
2 2
3 2
4 2
5 2
6 2
21 2
22 2
9 1
17 1
10 1
11 1
12 1
13 1
14 1
15 1
16 11
18 1
19 1
22
0 21
20 21
1 21
2 21
3 21
4 21
5 21
6 21
7 21
21 21
22 21
9 11
17 11
10 11
11 11
12 11
13 11
14 11
15 11
16 11
18 11
19 11
12
8 22
0 22
20 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
21 2
22 2
12
8 22
0 2
20 2
1 22
2 2
3 2
4 2
5 2
6 2
7 2
21 2
22 2
12
8 22
0 2
20 2
1 2
2 22
3 2
4 2
5 2
6 2
7 2
21 2
22 2
12
8 22
0 2
20 2
1 2
2 2
3 22
4 2
5 2
6 2
7 2
21 2
22 2
12
8 22
0 2
20 2
1 2
2 2
3 2
4 22
5 2
6 2
7 2
21 2
22 2
12
8 22
0 2
20 2
1 2
2 2
3 2
4 2
5 22
6 2
7 2
21 2
22 2
12
8 22
0 2
20 2
1 2
2 2
3 2
4 2
5 2
6 22
7 2
21 2
22 2
12
8 22
0 2
20 2
1 2
2 2
3 2
4 2
5 2
6 2
7 22
21 2
22 2
12
8 22
0 2
20 22
1 2
2 2
3 2
4 2
5 2
6 2
7 2
21 2
22 2
12
8 22
0 2
20 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
21 22
22 2
12
8 22
0 2
20 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
21 2
22 22
22
8 21
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
21 2
22 2
9 1
17 11
10 1
11 1
12 1
13 1
14 1
15 1
16 1
18 1
19 1
22
8 21
0 2
20 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
22 2
9 1
17 1
10 1
11 1
12 1
13 1
14 1
15 1
16 1
18 11
19 1
22
8 21
0 2
20 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
21 2
9 1
17 1
10 1
11 1
12 1
13 1
14 1
15 1
16 1
18 1
19 11
end_CG
