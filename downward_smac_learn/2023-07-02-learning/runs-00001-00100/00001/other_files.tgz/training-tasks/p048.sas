begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var9
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var10
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var11
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var13
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var15
-1
15
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var16
-1
15
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var17
-1
15
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var18
-1
15
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var19
-1
15
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b2)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var20
-1
15
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b2)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var23
-1
15
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b14)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var24
-1
15
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b14)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var25
-1
15
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var27
-1
15
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b14)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var21
-1
15
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var22
-1
15
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b14)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var26
-1
15
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var28
-1
15
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b14)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var7
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var8
-1
2
Atom clear(b3)
Nega




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





312
2
10 0
22 12
1
311
2
10 0
22 11
1
310
2
10 0
22 10
1
309
2
10 0
22 9
1
308
2
10 0
22 8
1
307
2
10 0
22 7
1
306
2
10 0
22 6
1
305
2
10 0
22 5
1
304
2
10 0
22 4
1
303
2
10 0
22 3
1
302
2
10 0
22 2
1
301
2
10 0
22 1
1
7
2
10 0
22 14
14
0
21
1
22 0
0
386
3
10 0
28 0
24 8
0
373
3
10 0
9 0
20 8
0
360
3
10 0
27 0
23 8
0
347
3
10 0
8 0
19 8
0
334
3
10 0
7 0
18 8
0
321
3
10 0
6 0
17 8
0
294
3
10 0
25 0
21 7
0
281
3
10 0
5 0
16 7
0
268
3
10 0
4 0
15 7
0
255
3
10 0
3 0
14 7
0
242
3
10 0
2 0
13 7
0
229
3
10 0
1 0
12 7
0
216
3
10 0
0 0
11 7
end_DTG
begin_DTG
27
1
38
1
11 0
1
208
1
24 0
1
195
1
20 0
1
168
1
19 0
1
155
1
18 0
1
142
1
17 0
1
129
1
22 0
1
103
1
16 0
1
90
1
15 0
1
77
1
14 0
1
64
1
13 0
1
51
1
12 0
1
116
1
21 0
1
365
2
10 0
23 13
1
364
2
10 0
23 12
1
363
2
10 0
23 11
1
362
2
10 0
23 10
1
361
2
10 0
23 9
1
360
2
10 0
23 8
1
359
2
10 0
23 7
1
358
2
10 0
23 6
1
357
2
10 0
23 5
1
356
2
10 0
23 4
1
355
2
10 0
23 3
1
354
2
10 0
23 2
1
353
2
10 0
23 1
1
11
2
10 0
23 14
14
0
25
1
23 0
0
390
3
10 0
28 0
24 12
0
377
3
10 0
9 0
20 12
0
350
3
10 0
8 0
19 11
0
337
3
10 0
7 0
18 11
0
324
3
10 0
6 0
17 11
0
311
3
10 0
26 0
22 11
0
298
3
10 0
25 0
21 11
0
285
3
10 0
5 0
16 11
0
272
3
10 0
4 0
15 11
0
259
3
10 0
3 0
14 11
0
246
3
10 0
2 0
13 11
0
233
3
10 0
1 0
12 11
0
220
3
10 0
0 0
11 11
end_DTG
begin_DTG
27
1
40
1
11 0
1
196
1
20 0
1
183
1
23 0
1
170
1
19 0
1
157
1
18 0
1
144
1
17 0
1
131
1
22 0
1
105
1
16 0
1
92
1
15 0
1
79
1
14 0
1
66
1
13 0
1
53
1
12 0
1
118
1
21 0
1
391
2
10 0
24 13
1
390
2
10 0
24 12
1
389
2
10 0
24 11
1
388
2
10 0
24 10
1
387
2
10 0
24 9
1
386
2
10 0
24 8
1
385
2
10 0
24 7
1
384
2
10 0
24 6
1
383
2
10 0
24 5
1
382
2
10 0
24 4
1
381
2
10 0
24 3
1
380
2
10 0
24 2
1
379
2
10 0
24 1
1
13
2
10 0
24 14
14
0
27
1
24 0
0
378
3
10 0
9 0
20 13
0
365
3
10 0
27 0
23 13
0
352
3
10 0
8 0
19 13
0
339
3
10 0
7 0
18 13
0
326
3
10 0
6 0
17 13
0
313
3
10 0
26 0
22 13
0
300
3
10 0
25 0
21 13
0
287
3
10 0
5 0
16 13
0
274
3
10 0
4 0
15 13
0
261
3
10 0
3 0
14 13
0
248
3
10 0
2 0
13 13
0
235
3
10 0
1 0
12 13
0
222
3
10 0
0 0
11 13
end_DTG
begin_CG
28
10 27
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
11 14
12 1
13 1
14 1
15 1
16 1
21 1
22 1
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
11 1
12 14
13 1
14 1
15 1
16 1
21 1
22 1
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
11 1
12 1
13 14
14 1
15 1
16 1
21 1
22 1
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
11 1
12 1
13 1
14 14
15 1
16 1
21 1
22 1
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
11 1
12 1
13 1
14 1
15 14
16 1
21 1
22 1
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
11 1
12 1
13 1
14 1
15 1
16 14
21 1
22 1
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
7 2
8 2
27 2
9 2
28 2
11 1
12 1
13 1
14 1
15 1
16 1
21 1
22 1
17 14
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
8 2
27 2
9 2
28 2
11 1
12 1
13 1
14 1
15 1
16 1
21 1
22 1
17 1
18 14
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
27 2
9 2
28 2
11 1
12 1
13 1
14 1
15 1
16 1
21 1
22 1
17 1
18 1
19 14
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
28 2
11 1
12 1
13 1
14 1
15 1
16 1
21 1
22 1
17 1
18 1
19 1
23 1
20 14
24 1
28
0 27
1 27
2 27
3 27
4 27
5 27
25 27
26 27
6 27
7 27
8 27
27 27
9 27
28 27
11 14
12 14
13 14
14 14
15 14
16 14
21 14
22 14
17 14
18 14
19 14
23 14
20 14
24 14
15
10 28
0 28
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 28
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 28
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 28
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 28
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 28
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 28
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 28
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 28
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 28
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 28
26 2
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 28
6 2
7 2
8 2
27 2
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 28
9 2
28 2
15
10 28
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
28 28
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
26 2
6 2
7 2
8 2
27 2
9 2
28 2
11 1
12 1
13 1
14 1
15 1
16 1
21 14
22 1
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
25 2
6 2
7 2
8 2
27 2
9 2
28 2
11 1
12 1
13 1
14 1
15 1
16 1
21 1
22 14
17 1
18 1
19 1
23 1
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
9 2
28 2
11 1
12 1
13 1
14 1
15 1
16 1
21 1
22 1
17 1
18 1
19 1
23 14
20 1
24 1
28
10 27
0 2
1 2
2 2
3 2
4 2
5 2
25 2
26 2
6 2
7 2
8 2
27 2
9 2
11 1
12 1
13 1
14 1
15 1
16 1
21 1
22 1
17 1
18 1
19 1
23 1
20 1
24 14
end_CG
