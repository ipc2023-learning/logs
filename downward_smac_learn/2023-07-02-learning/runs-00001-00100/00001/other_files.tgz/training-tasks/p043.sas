begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var7
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var8
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var9
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var10
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var11
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var12
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var16
-1
14
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var17
-1
14
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var18
-1
14
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b2)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var19
-1
14
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var20
-1
14
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var21
-1
14
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var22
-1
14
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var23
-1
14
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var24
-1
14
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var25
-1
14
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var14
-1
14
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var15
-1
14
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var26
-1
14
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var13
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
14
begin_mutex_group
14
10 0
21 0
22 0
11 0
12 0
13 0
14 0
15 0
16 0
17 0
18 0
19 0
20 0
23 0
end_mutex_group
begin_mutex_group
14
24 0
21 0
22 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
23 1
end_mutex_group
begin_mutex_group
14
25 0
22 0
21 1
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
23 2
end_mutex_group
begin_mutex_group
14
0 0
11 0
21 2
22 2
12 3
13 3
14 3
15 3
16 3
17 3
18 3
19 3
20 3
23 3
end_mute




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
172
1
0 0
4
173
1
1 0
5
174
1
2 0
6
175
1
3 0
7
176
1
4 0
8
177
1
5 0
9
178
1
6 0
10
179
1
7 0
11
180
1
8 0
12
181
1
9 0
13
25
0
1
0
326
2
10 0
26 0
1
0
327
2
10 0
26 0
1
0
328
2
10 0
26 0
1
0
329
2
10 0
26 0
1
0
330
2
10 0
26 0
1
0
331
2
10 0
26 0
1
0
332
2
10 0
26 0
1
0
333
2
10 0
26 0
1
0
334
2
10 0
26 0
1
0
335
2
10 0
26 0
1
0
336
2
10 0
26 0
1
0
337
2
10 0
26 0
1
0
12
2
10 0
26 0
end_DTG
begin_DTG
25
1
38
1
22 0
1
170
1
23 0
1
158
1
20 0
1
146
1
19 0
1
134
1
18 0
1
122
1
17 0
1
110
1
16 0
1
86
1
14 0
1
74
1
13 0
1
62
1
12 0
1
50
1
11 0
1
98
1
15 0
1
193
2
10 0
21 12
1
192
2
10 0
21 11
1
191
2
10 0
21 10
1
190
2
10 0
21 9
1
189
2
10 0
21 8
1
188
2
10 0
21 7
1
187
2
10 0
21 6
1
186
2
10 0
21 5
1
185
2
10 0
21 4
1
184
2
10 0
21 3
1
183
2
10 0
21 2
1
182
2
10 0
21 1
1
0
2
10 0
21 13
13
0
13
1
21 0
0
326
3
10 0
26 0
23 1
0
314
3
10 0
9 0
20 1
0
302
3
10 0
8 0
19 1
0
290
3
10 0
7 0
18 1
0
278
3
10 0
6 0
17 1
0
266
3
10 0
5 0
16 1
0
254
3
10 0
4 0
15 1
0
242
3
10 0
3 0
14 1
0
230
3
10 0
2 0
13 1
0
218
3
10 0
1 0
12 1
0
206
3
10 0
0 0
11 1
0
194
3
10 0
25 0
22 1
end_DTG
begin_DTG
25
1
26
1
21 0
1
171
1
23 0
1
159
1
20 0
1
147
1
19 0
1
135
1
18 0
1
123
1
17 0
1
111
1
16 0
1
87
1
14 0
1
75
1
13 0
1
63
1
12 0
1
51
1
11 0
1
99
1
15 0
1
205
2
10 0
22 12
1
204
2
10 0
22 11
1
203
2
10 0
22 10
1
202
2
10 0
22 9
1
201
2
10 0
22 8
1
200
2
10 0
22 7
1
199
2
10 0
22 6
1
198
2
10 0
22 5
1
197
2
10 0
22 4
1
196
2
10 0
22 3
1
195
2
10 0
22 2
1
194
2
10 0
22 1
1
1
2
10 0
22 13
13
0
14
1
22 0
0
327
3
10 0
26 0
23 2
0
315
3
10 0
9 0
20 2
0
303
3
10 0
8 0
19 2
0
291
3
10 0
7 0
18 2
0
279
3
10 0
6 0
17 2
0
267
3
10 0
5 0
16 2
0
255
3
10 0
4 0
15 2
0
243
3
10 0
3 0
14 2
0
231
3
10 0
2 0
13 2
0
219
3
10 0
1 0
12 2
0
207
3
10 0
0 0
11 2
0
182
3
10 0
24 0
21 1
end_DTG
begin_DTG
25
1
37
1
21 0
1
169
1
20 0
1
157
1
19 0
1
145
1
18 0
1
133
1
17 0
1
121
1
16 0
1
109
1
15 0
1
85
1
13 0
1
73
1
12 0
1
61
1
11 0
1
49
1
22 0
1
97
1
14 0
1
337
2
10 0
23 12
1
336
2
10 0
23 11
1
335
2
10 0
23 10
1
334
2
10 0
23 9
1
333
2
10 0
23 8
1
332
2
10 0
23 7
1
331
2
10 0
23 6
1
330
2
10 0
23 5
1
329
2
10 0
23 4
1
328
2
10 0
23 3
1
327
2
10 0
23 2
1
326
2
10 0
23 1
1
12
2
10 0
23 13
13
0
25
1
23 0
0
325
3
10 0
9 0
20 12
0
313
3
10 0
8 0
19 12
0
301
3
10 0
7 0
18 12
0
289
3
10 0
6 0
17 12
0
277
3
10 0
5 0
16 12
0
265
3
10 0
4 0
15 12
0
253
3
10 0
3 0
14 12
0
241
3
10 0
2 0
13 12
0
229
3
10 0
1 0
12 12
0
217
3
10 0
0 0
11 12
0
205
3
10 0
25 0
22 12
0
193
3
10 0
24 0
21 12
end_DTG
begin_CG
26
10 25
24 2
25 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
21 1
22 1
11 13
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
21 1
22 1
11 1
12 13
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
21 1
22 1
11 1
12 1
13 13
14 1
15 1
16 1
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
21 1
22 1
11 1
12 1
13 1
14 13
15 1
16 1
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
3 2
5 2
6 2
7 2
8 2
9 2
26 2
21 1
22 1
11 1
12 1
13 1
14 1
15 13
16 1
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
3 2
4 2
6 2
7 2
8 2
9 2
26 2
21 1
22 1
11 1
12 1
13 1
14 1
15 1
16 13
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
7 2
8 2
9 2
26 2
21 1
22 1
11 1
12 1
13 1
14 1
15 1
16 1
17 13
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
8 2
9 2
26 2
21 1
22 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 13
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
9 2
26 2
21 1
22 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 13
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
26 2
21 1
22 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 13
23 1
26
24 25
25 25
0 25
1 25
2 25
3 25
4 25
5 25
6 25
7 25
8 25
9 25
26 25
21 13
22 13
11 13
12 13
13 13
14 13
15 13
16 13
17 13
18 13
19 13
20 13
23 13
14
10 26
24 2
25 2
0 26
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 26
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 26
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 26
4 2
5 2
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 2
4 26
5 2
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 26
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 26
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 26
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 26
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 26
26 2
14
10 26
24 26
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 26
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
14
10 26
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 26
26
10 25
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
21 13
22 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
21 1
22 13
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
23 1
26
10 25
24 2
25 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
21 1
22 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
23 13
end_CG
