begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var8
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var9
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var10
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var11
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var12
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var13
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var14
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var15
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var16
-1
16
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var17
-1
16
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var18
-1
16
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var19
-1
16
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var20
-1
16
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b2)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var21
-1
16
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b2)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var23
-1
16
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var24
-1
16
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b14)
Atom on(b3, b15)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var25
-1
16
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b14)
Atom on(b4, b15)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var26
-1
16
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b14)
Atom on(b5, b15)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var27
-1
16
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b15)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var28
-1
16
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b15)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var29
-1
16
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b14)
Atom on(b8, b15)
Atom on(b8, b2)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
15
29
0
1
0
436
2
14 0
13 0
1
0
437
2
14 0
13 0
1
0
438
2
14 0
13 0
1
0
439
2
14 0
13 0
1
0
440
2
14 0
13 0
1
0
441
2
14 0
13 0
1
0
442
2
14 0
13 0
1
0
443
2
14 0
13 0
1
0
444
2
14 0
13 0
1
0
445
2
14 0
13 0
1
0
446
2
14 0
13 0
1
0
447
2
14 0
13 0
1
0
448
2
14 0
13 0
1
0
449
2
14 0
13 0
1
0
14
2
14 0
13 0
end_DTG
begin_DTG
15
1
114
1
0 0
2
115
1
1 0
3
116
1
2 0
4
117
1
3 0
5
118
1
4 0
6
119
1
5 0
7
120
1
6 0
8
121
1
7 0
9
122
1
8 0
10
123
1
9 0
11
124
1
10 0
12
125
1
11 0
13
126
1
12 0
14
127
1
13 0
15
21
0
1
0
324
2
14 0
30 0
1
0
325
2
14 0
30 0
1
0
326
2
14 0
30 0
1
0
327
2
14 0
30 0
1
0
328
2
14 0
30 0
1
0
329
2
14 0
30 0
1
0
330
2
14 0
30 0
1
0
331
2
14 0
30 0
1
0
332
2
14 0
30 0
1
0
333
2
14 0
30 0
1
0
334
2
14 0
30 0
1
0
335
2
14 0
30 0
1
0
336
2
14 0
30 0
1
0
337
2
14 0
30 0
1
0
6
2
14 0
30 0
end_DTG
begin_DTG
29
1
35
1
15 0
1
232
1
28 0
1
218
1
27 0
1
204
1
26 0
1
190
1
25 0
1
176
1
24 0
1
162
1
23 0
1
148
1
22 0
1
105
1
20 0
1
91
1
19 0
1
77
1
18 0
1
63
1
17 0
1
49
1
16 0
1
134
1
21 0
1
337
2
14 0
29 14
1
336
2
14 0
29 13
1
335
2
14 0
29 12
1
334
2
14 0
29 11
1
333
2
14 0
29 10
1
332
2
14 0
29 9
1
331
2
14 0
29 8
1
330
2
14 0
29 7
1
329
2
14 0
29 6
1
328
2
14 0
29 5
1
327
2
14 0
29 4
1
326
2
14 0
29 3
1
325
2
14 0
29 2
1
324
2
14 0
29 1
1
6
2
14 0
29 15
15
0
21
1
29 0
0
442
3
14 0
13 0
28 7
0
428
3
14 0
12 0
27 7
0
414
3
14 0
11 0
26 7
0
400
3
14 0
10 0
25 7
0
386
3
14 0
9 0
24 7
0
372
3
14 0
8 0
23 7
0
358
3
14 0
7 0
22 7
0
344
3
14 0
6 0
21 7
0
315
3
14 0
5 0
20 6
0
301
3
14 0
4 0
19 6
0
287
3
14 0
3 0
18 6
0
273
3
14 0
2 0
17 6
0
259
3
14 0
1 0
16 6
0
245
3
14 0
0 0
15 6
end_DTG
begin_CG
30
14 29
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 15
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 15
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 15
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 15
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 15
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 15
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 15
22 1
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 15
23 1
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 15
24 1
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 15
25 1
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 15
26 1
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 15
27 1
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 15
28 1
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
15 1
16 1
17 1
18 1
19 1
20 1
29 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 15
30
0 29
1 29
2 29
3 29
4 29
5 29
30 29
6 29
7 29
8 29
9 29
10 29
11 29
12 29
13 29
15 15
16 15
17 15
18 15
19 15
20 15
29 15
21 15
22 15
23 15
24 15
25 15
26 15
27 15
28 15
16
14 30
0 30
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 30
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 30
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 30
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 30
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 30
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 30
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 30
8 2
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 30
9 2
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 30
10 2
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 30
11 2
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 30
12 2
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 30
13 2
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 30
16
14 30
0 2
1 2
2 2
3 2
4 2
5 2
30 30
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
30
14 29
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 1
16 1
17 1
18 1
19 1
20 1
29 15
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
end_CG
