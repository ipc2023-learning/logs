begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var5
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var6
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var7
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var8
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var9
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var11
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var12
-1
12
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var13
-1
12
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var14
-1
12
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var15
-1
12
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var16
-1
12
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var17
-1
12
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var18
-1
12
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var19
-1
12
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var20
-1
12
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var22
-1
12
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var21
-1
12
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var10
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
12
begin_mutex_group
12
10 0
11 0
12 0
13 0
14 0
15 0
16 0
17 0
18 0
19 0
21 0
20 0
end_mutex_group
begin_mutex_group
12
0 0
11 0
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
21 1
20 1
end_mutex_group
begin_mutex_group
12
1 0
12 0
11 1
13 2
14 2
15 2
16 2
17 2
18 2
19 2
21 2
20 2
end_mutex_group
begin_mutex_group
12
2 0
13 0
11 2
12 2
14 3
15 3
16 3
17 3
18 3
19 3
21 3
20 3
end_mutex_group
begin_mutex_group
12
3 0
14 0
11 3
12 3
13 3
15 4
16 4
17 4
18 4
19 4
21 4
20 4
end_mutex_group
begin_mutex_group
12
4 0
15 0
11 4
12 4
13 4
14 4
16 5
17 5
18 5
19 5
21 5
20 5
end_mutex_group
begin_mutex_group
12
5 0
16 0
11 5
12 5
13 5
14 5
15 5
17 6
18 6
19 6
21 6
20 6
end_mutex_group
begin_mutex_group
12
6 0
17 0
11 6
12 6
13 6
14 6
15 6
16 6
18 7
19 7
21 7
20 7
end_mutex_group
begin_mutex_group
12
7 0
18 0
11 7
12 7
13 7
14 7
15 7
16 7
17 7
19 8
21 8
20 8
end_mutex_group
begin_mutex_group
12
8 0
19 0
11 8
12 8
13 8
14 8
15 8
16 8
17 8
18 8
21 9
20 9
end_mutex_group
begin_mutex_group
12
22 0
21 0
11 9
12 9
13 9
14 9
15 9
16 9
17 9
18 9
19 9
20 10
end_mutex_group
begin_mutex_group
12
9 0
20 0
11 10
12 10
13 10
14 10
15 10
16 10
17 10
18 10
19 10
21 10
end_mutex_group
begin_state
1
0
1
1
1
1
0
0
1
1
0
8
1
11
9
11
3
10
6
4
5
11
1
end_state
begin_goal
12
11 11
12 1
13 3
14 10
15 7
16 6
17 2
18 8
19 3
20 6
21 5
22 0
end_goal
242
begin_operator
pickup b1
0
3
0 10 0 1
0 0 0 1
0 11 11 0
0
end_operator
begin_operator
pickup b10
0
3
0 10 0 1
0 1 0 1
0 12 11 0
0
end_operator
begin_operator
pickup b11
0
3
0 10 0 1
0 2 0 1
0 13 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




5
2
10 0
3 0
1
0
166
2
10 0
3 0
1
0
167
2
10 0
3 0
1
0
168
2
10 0
3 0
1
0
169
2
10 0
3 0
1
0
170
2
10 0
3 0
1
0
171
2
10 0
3 0
1
0
3
2
10 0
3 0
end_DTG
begin_DTG
11
1
62
1
0 0
2
63
1
1 0
3
64
1
2 0
4
65
1
3 0
5
66
1
5 0
6
67
1
6 0
7
68
1
7 0
8
69
1
8 0
9
70
1
22 0
10
71
1
9 0
11
15
0
1
0
172
2
10 0
4 0
1
0
173
2
10 0
4 0
1
0
174
2
10 0
4 0
1
0
175
2
10 0
4 0
1
0
176
2
10 0
4 0
1
0
177
2
10 0
4 0
1
0
178
2
10 0
4 0
1
0
179
2
10 0
4 0
1
0
180
2
10 0
4 0
1
0
181
2
10 0
4 0
1
0
4
2
10 0
4 0
end_DTG
begin_DTG
11
1
72
1
0 0
2
73
1
1 0
3
74
1
2 0
4
75
1
3 0
5
76
1
4 0
6
77
1
6 0
7
78
1
7 0
8
79
1
8 0
9
80
1
22 0
10
81
1
9 0
11
16
0
1
0
182
2
10 0
5 0
1
0
183
2
10 0
5 0
1
0
184
2
10 0
5 0
1
0
185
2
10 0
5 0
1
0
186
2
10 0
5 0
1
0
187
2
10 0
5 0
1
0
188
2
10 0
5 0
1
0
189
2
10 0
5 0
1
0
190
2
10 0
5 0
1
0
191
2
10 0
5 0
1
0
5
2
10 0
5 0
end_DTG
begin_DTG
11
1
82
1
0 0
2
83
1
1 0
3
84
1
2 0
4
85
1
3 0
5
86
1
4 0
6
87
1
5 0
7
88
1
7 0
8
89
1
8 0
9
90
1
22 0
10
91
1
9 0
11
17
0
1
0
192
2
10 0
6 0
1
0
193
2
10 0
6 0
1
0
194
2
10 0
6 0
1
0
195
2
10 0
6 0
1
0
196
2
10 0
6 0
1
0
197
2
10 0
6 0
1
0
198
2
10 0
6 0
1
0
199
2
10 0
6 0
1
0
200
2
10 0
6 0
1
0
201
2
10 0
6 0
1
0
6
2
10 0
6 0
end_DTG
begin_DTG
11
1
92
1
0 0
2
93
1
1 0
3
94
1
2 0
4
95
1
3 0
5
96
1
4 0
6
97
1
5 0
7
98
1
6 0
8
99
1
8 0
9
100
1
22 0
10
101
1
9 0
11
18
0
1
0
202
2
10 0
7 0
1
0
203
2
10 0
7 0
1
0
204
2
10 0
7 0
1
0
205
2
10 0
7 0
1
0
206
2
10 0
7 0
1
0
207
2
10 0
7 0
1
0
208
2
10 0
7 0
1
0
209
2
10 0
7 0
1
0
210
2
10 0
7 0
1
0
211
2
10 0
7 0
1
0
7
2
10 0
7 0
end_DTG
begin_DTG
11
1
102
1
0 0
2
103
1
1 0
3
104
1
2 0
4
105
1
3 0
5
106
1
4 0
6
107
1
5 0
7
108
1
6 0
8
109
1
7 0
9
110
1
22 0
10
111
1
9 0
11
19
0
1
0
212
2
10 0
8 0
1
0
213
2
10 0
8 0
1
0
214
2
10 0
8 0
1
0
215
2
10 0
8 0
1
0
216
2
10 0
8 0
1
0
217
2
10 0
8 0
1
0
218
2
10 0
8 0
1
0
219
2
10 0
8 0
1
0
220
2
10 0
8 0
1
0
221
2
10 0
8 0
1
0
8
2
10 0
8 0
end_DTG
begin_DTG
11
1
122
1
0 0
2
123
1
1 0
3
124
1
2 0
4
125
1
3 0
5
126
1
4 0
6
127
1
5 0
7
128
1
6 0
8
129
1
7 0
9
130
1
8 0
10
131
1
22 0
11
21
0
1
0
232
2
10 0
9 0
1
0
233
2
10 0
9 0
1
0
234
2
10 0
9 0
1
0
235
2
10 0
9 0
1
0
236
2
10 0
9 0
1
0
237
2
10 0
9 0
1
0
238
2
10 0
9 0
1
0
239
2
10 0
9 0
1
0
240
2
10 0
9 0
1
0
241
2
10 0
9 0
1
0
10
2
10 0
9 0
end_DTG
begin_DTG
11
1
112
1
0 0
2
113
1
1 0
3
114
1
2 0
4
115
1
3 0
5
116
1
4 0
6
117
1
5 0
7
118
1
6 0
8
119
1
7 0
9
120
1
8 0
10
121
1
9 0
11
20
0
1
0
222
2
10 0
22 0
1
0
223
2
10 0
22 0
1
0
224
2
10 0
22 0
1
0
225
2
10 0
22 0
1
0
226
2
10 0
22 0
1
0
227
2
10 0
22 0
1
0
228
2
10 0
22 0
1
0
229
2
10 0
22 0
1
0
230
2
10 0
22 0
1
0
231
2
10 0
22 0
1
0
9
2
10 0
22 0
end_DTG
begin_DTG
21
1
30
1
11 0
1
131
1
20 0
1
110
1
19 0
1
100
1
18 0
1
90
1
17 0
1
80
1
16 0
1
70
1
15 0
1
60
1
14 0
1
50
1
13 0
1
40
1
12 0
1
9
2
10 0
21 11
1
222
2
10 0
21 1
1
223
2
10 0
21 2
1
224
2
10 0
21 3
1
225
2
10 0
21 4
1
226
2
10 0
21 5
1
227
2
10 0
21 6
1
228
2
10 0
21 7
1
229
2
10 0
21 8
1
230
2
10 0
21 9
1
231
2
10 0
21 10
11
0
20
1
21 0
0
140
3
10 0
0 0
11 9
0
150
3
10 0
1 0
12 9
0
160
3
10 0
2 0
13 9
0
170
3
10 0
3 0
14 9
0
180
3
10 0
4 0
15 9
0
190
3
10 0
5 0
16 9
0
200
3
10 0
6 0
17 9
0
210
3
10 0
7 0
18 9
0
220
3
10 0
8 0
19 9
0
241
3
10 0
9 0
20 10
end_DTG
begin_CG
22
10 21
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22 2
9 2
11 11
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
21 1
20 1
22
10 21
0 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22 2
9 2
11 1
12 11
13 1
14 1
15 1
16 1
17 1
18 1
19 1
21 1
20 1
22
10 21
0 2
1 2
3 2
4 2
5 2
6 2
7 2
8 2
22 2
9 2
11 1
12 1
13 11
14 1
15 1
16 1
17 1
18 1
19 1
21 1
20 1
22
10 21
0 2
1 2
2 2
4 2
5 2
6 2
7 2
8 2
22 2
9 2
11 1
12 1
13 1
14 11
15 1
16 1
17 1
18 1
19 1
21 1
20 1
22
10 21
0 2
1 2
2 2
3 2
5 2
6 2
7 2
8 2
22 2
9 2
11 1
12 1
13 1
14 1
15 11
16 1
17 1
18 1
19 1
21 1
20 1
22
10 21
0 2
1 2
2 2
3 2
4 2
6 2
7 2
8 2
22 2
9 2
11 1
12 1
13 1
14 1
15 1
16 11
17 1
18 1
19 1
21 1
20 1
22
10 21
0 2
1 2
2 2
3 2
4 2
5 2
7 2
8 2
22 2
9 2
11 1
12 1
13 1
14 1
15 1
16 1
17 11
18 1
19 1
21 1
20 1
22
10 21
0 2
1 2
2 2
3 2
4 2
5 2
6 2
8 2
22 2
9 2
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 11
19 1
21 1
20 1
22
10 21
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
22 2
9 2
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 11
21 1
20 1
22
10 21
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22 2
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
21 1
20 11
22
0 21
1 21
2 21
3 21
4 21
5 21
6 21
7 21
8 21
22 21
9 21
11 11
12 11
13 11
14 11
15 11
16 11
17 11
18 11
19 11
21 11
20 11
12
10 22
0 22
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22 2
9 2
12
10 22
0 2
1 22
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22 2
9 2
12
10 22
0 2
1 2
2 22
3 2
4 2
5 2
6 2
7 2
8 2
22 2
9 2
12
10 22
0 2
1 2
2 2
3 22
4 2
5 2
6 2
7 2
8 2
22 2
9 2
12
10 22
0 2
1 2
2 2
3 2
4 22
5 2
6 2
7 2
8 2
22 2
9 2
12
10 22
0 2
1 2
2 2
3 2
4 2
5 22
6 2
7 2
8 2
22 2
9 2
12
10 22
0 2
1 2
2 2
3 2
4 2
5 2
6 22
7 2
8 2
22 2
9 2
12
10 22
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 22
8 2
22 2
9 2
12
10 22
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 22
22 2
9 2
12
10 22
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22 2
9 22
12
10 22
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22 22
9 2
22
10 21
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
21 11
20 1
end_CG
