begin_version
3
end_version
begin_metric
0
end_metric
47
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var16
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var17
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var18
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var19
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var20
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var21
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var22
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var23
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var25
-1
24
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var26
-1
24
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var27
-1
24
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var28
-1
24
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b21)
Atom on(b13, b22)
Atom on(b13, b23)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var29
-1
24
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var31
-1
24
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
end_variable
begin_variable
var32
-1
24
Atom holding(b17)
Atom on(b17, b1)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b21)
Atom on(b17, b22)
Atom on(b17, b23)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b8)
Atom on(b17, b9)
Atom on-table(b17)
end_variable
begin_variable
var33
-1
24
Atom holding(b18)
Atom on(b18, b1)
Atom on(b18, b10)
Atom on(b18, b11)
Atom on(b18, b12)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8 2
9 2
10 2
11 2
12 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 23
36 1
37 1
38 1
39 1
40 1
41 1
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 2
16 2
17 2
18 2
19 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 23
37 1
38 1
39 1
40 1
41 1
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 2
17 2
18 2
19 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 23
38 1
39 1
40 1
41 1
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
17 2
18 2
19 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 23
39 1
40 1
41 1
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
18 2
19 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 23
40 1
41 1
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
19 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 23
41 1
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 23
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
43 1
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 23
46
45 45
0 45
1 45
2 45
3 45
4 45
46 45
5 45
6 45
7 45
8 45
9 45
10 45
11 45
12 45
13 45
14 45
15 45
16 45
17 45
18 45
19 45
20 45
43 23
22 23
23 23
24 23
25 23
26 23
44 23
27 23
28 23
29 23
30 23
31 23
32 23
33 23
34 23
35 23
36 23
37 23
38 23
39 23
40 23
41 23
42 23
24
21 46
45 2
0 46
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 46
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 46
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 46
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 46
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 46
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 46
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 46
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 46
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 46
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 46
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 46
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 46
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 46
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 46
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 46
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 46
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 46
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 46
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 46
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 46
24
21 46
45 46
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
24
21 46
45 2
0 2
1 2
2 2
3 2
4 2
46 46
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
46
21 45
0 2
1 2
2 2
3 2
4 2
46 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
43 23
22 1
23 1
24 1
25 1
26 1
44 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
46
21 45
45 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
43 1
22 1
23 1
24 1
25 1
26 1
44 23
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
end_CG
