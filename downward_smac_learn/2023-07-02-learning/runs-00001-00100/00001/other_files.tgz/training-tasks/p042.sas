begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var6
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var7
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var8
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var9
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var11
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var13
-1
13
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var15
-1
13
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var16
-1
13
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var17
-1
13
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var18
-1
13
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var19
-1
13
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var20
-1
13
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var21
-1
13
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var23
-1
13
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var14
-1
13
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var22
-1
13
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var24
-1
13
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var10
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var12
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
13
begin_mutex_group
13
9 0
10 0
19 0
11 0
12 0
13 0
14 0
15 0
16 0
17 0
20 0
18 0
21 0
end_mutex_group
begin_mutex_group
13
0 0
10 0
19 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
18 1
21 1
end_mutex_group
begin_mutex_group
13
22 0
19 0
10 1
11 2
12 2
13 2
14 2
15 2
16 2
17 2
20 2
18 2
21 2
end_mutex_group
begin_mutex_group
13
1 0
11 0
10 2
19 2
12 3
13 3
14 3
15 3
16 3
17 3
20 3
18 3
21 3
end_mutex_group
begin_mutex_group
13
2 0
12 0
10 3
19 3
11 3
13 4
14 4
15 4
16 4
17 4
20 4
18 4
21 4
end_mutex_group
begin_mutex_group
13
3 0
13 0
10 4
19 4
11 4
12 4
14 5
15 5
16 5
17 5
20 5
18 5
21 5
end_mutex_group
begin_mutex_group
13
4 0
14 0
10 5
19 5
11 5
12 5
13 5
15 6
16 6
17 6
20 6
18 6
21 6
end_mutex_group
begin_mutex_group
13
5 0
15 0
10 6
19 6
11 6
12 6
13 6
14 6
16 7
17 7
20 7
18 7
21 7
end_mutex_group
begin_mutex_group
13
6 0
16 0
10 7
19 7
11 7
12 7
13 7
14 7
15 7
17 8
20 8
18 8
21 8
end_mutex_group
begin_mutex_group
13
7 0
17 0
10 8
19 8
11 8
12 8
13 8
14 8
15 8
16 8
20 9
18 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7
2
9 0
22 0
1
0
168
2
9 0
22 0
1
0
169
2
9 0
22 0
1
0
170
2
9 0
22 0
1
0
171
2
9 0
22 0
1
0
172
2
9 0
22 0
1
0
173
2
9 0
22 0
1
0
174
2
9 0
22 0
1
0
175
2
9 0
22 0
1
0
176
2
9 0
22 0
1
0
177
2
9 0
22 0
1
0
1
2
9 0
22 0
end_DTG
begin_DTG
12
1
123
1
0 0
2
124
1
22 0
3
125
1
1 0
4
126
1
2 0
5
127
1
3 0
6
128
1
4 0
7
129
1
5 0
8
130
1
6 0
9
131
1
7 0
10
132
1
8 0
11
133
1
24 0
12
21
0
1
0
255
2
9 0
23 0
1
0
256
2
9 0
23 0
1
0
257
2
9 0
23 0
1
0
258
2
9 0
23 0
1
0
259
2
9 0
23 0
1
0
260
2
9 0
23 0
1
0
261
2
9 0
23 0
1
0
262
2
9 0
23 0
1
0
263
2
9 0
23 0
1
0
264
2
9 0
23 0
1
0
265
2
9 0
23 0
1
0
9
2
9 0
23 0
end_DTG
begin_DTG
12
1
145
1
0 0
2
146
1
22 0
3
147
1
1 0
4
148
1
2 0
5
149
1
3 0
6
150
1
4 0
7
151
1
5 0
8
152
1
6 0
9
153
1
7 0
10
154
1
23 0
11
155
1
8 0
12
23
0
1
0
277
2
9 0
24 0
1
0
278
2
9 0
24 0
1
0
279
2
9 0
24 0
1
0
280
2
9 0
24 0
1
0
281
2
9 0
24 0
1
0
282
2
9 0
24 0
1
0
283
2
9 0
24 0
1
0
284
2
9 0
24 0
1
0
285
2
9 0
24 0
1
0
286
2
9 0
24 0
1
0
287
2
9 0
24 0
1
0
11
2
9 0
24 0
end_DTG
begin_DTG
23
1
24
1
10 0
1
146
1
21 0
1
135
1
18 0
1
124
1
20 0
1
113
1
17 0
1
102
1
16 0
1
80
1
14 0
1
69
1
13 0
1
58
1
12 0
1
47
1
11 0
1
91
1
15 0
1
177
2
9 0
19 11
1
176
2
9 0
19 10
1
175
2
9 0
19 9
1
174
2
9 0
19 8
1
173
2
9 0
19 7
1
172
2
9 0
19 6
1
171
2
9 0
19 5
1
170
2
9 0
19 4
1
169
2
9 0
19 3
1
168
2
9 0
19 2
1
167
2
9 0
19 1
1
1
2
9 0
19 12
12
0
13
1
19 0
0
156
3
9 0
0 0
10 1
0
179
3
9 0
1 0
11 2
0
190
3
9 0
2 0
12 2
0
201
3
9 0
3 0
13 2
0
212
3
9 0
4 0
14 2
0
223
3
9 0
5 0
15 2
0
234
3
9 0
6 0
16 2
0
245
3
9 0
7 0
17 2
0
256
3
9 0
23 0
20 2
0
267
3
9 0
8 0
18 2
0
278
3
9 0
24 0
21 2
end_DTG
begin_DTG
23
1
32
1
10 0
1
154
1
21 0
1
143
1
18 0
1
120
1
17 0
1
109
1
16 0
1
98
1
15 0
1
76
1
13 0
1
65
1
12 0
1
54
1
11 0
1
43
1
19 0
1
87
1
14 0
1
265
2
9 0
20 11
1
264
2
9 0
20 10
1
263
2
9 0
20 9
1
262
2
9 0
20 8
1
261
2
9 0
20 7
1
260
2
9 0
20 6
1
259
2
9 0
20 5
1
258
2
9 0
20 4
1
257
2
9 0
20 3
1
256
2
9 0
20 2
1
255
2
9 0
20 1
1
9
2
9 0
20 12
12
0
21
1
20 0
0
164
3
9 0
0 0
10 9
0
175
3
9 0
22 0
19 9
0
186
3
9 0
1 0
11 9
0
197
3
9 0
2 0
12 9
0
208
3
9 0
3 0
13 9
0
219
3
9 0
4 0
14 9
0
230
3
9 0
5 0
15 9
0
241
3
9 0
6 0
16 9
0
252
3
9 0
7 0
17 9
0
275
3
9 0
8 0
18 10
0
286
3
9 0
24 0
21 10
end_DTG
begin_DTG
23
1
34
1
10 0
1
144
1
18 0
1
133
1
20 0
1
122
1
17 0
1
111
1
16 0
1
100
1
15 0
1
78
1
13 0
1
67
1
12 0
1
56
1
11 0
1
45
1
19 0
1
89
1
14 0
1
287
2
9 0
21 11
1
286
2
9 0
21 10
1
285
2
9 0
21 9
1
284
2
9 0
21 8
1
283
2
9 0
21 7
1
282
2
9 0
21 6
1
281
2
9 0
21 5
1
280
2
9 0
21 4
1
279
2
9 0
21 3
1
278
2
9 0
21 2
1
277
2
9 0
21 1
1
11
2
9 0
21 12
12
0
23
1
21 0
0
166
3
9 0
0 0
10 11
0
177
3
9 0
22 0
19 11
0
188
3
9 0
1 0
11 11
0
199
3
9 0
2 0
12 11
0
210
3
9 0
3 0
13 11
0
221
3
9 0
4 0
14 11
0
232
3
9 0
5 0
15 11
0
243
3
9 0
6 0
16 11
0
254
3
9 0
7 0
17 11
0
265
3
9 0
23 0
20 11
0
276
3
9 0
8 0
18 11
end_DTG
begin_CG
24
9 23
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
10 12
19 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
10 1
19 1
11 12
12 1
13 1
14 1
15 1
16 1
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
10 1
19 1
11 1
12 12
13 1
14 1
15 1
16 1
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
10 1
19 1
11 1
12 1
13 12
14 1
15 1
16 1
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
3 2
5 2
6 2
7 2
23 2
8 2
24 2
10 1
19 1
11 1
12 1
13 1
14 12
15 1
16 1
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
3 2
4 2
6 2
7 2
23 2
8 2
24 2
10 1
19 1
11 1
12 1
13 1
14 1
15 12
16 1
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
3 2
4 2
5 2
7 2
23 2
8 2
24 2
10 1
19 1
11 1
12 1
13 1
14 1
15 1
16 12
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
23 2
8 2
24 2
10 1
19 1
11 1
12 1
13 1
14 1
15 1
16 1
17 12
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
24 2
10 1
19 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
18 12
21 1
24
0 23
22 23
1 23
2 23
3 23
4 23
5 23
6 23
7 23
23 23
8 23
24 23
10 12
19 12
11 12
12 12
13 12
14 12
15 12
16 12
17 12
20 12
18 12
21 12
13
9 24
0 24
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 24
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 24
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 24
4 2
5 2
6 2
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 2
4 24
5 2
6 2
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 2
4 2
5 24
6 2
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 24
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 24
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 24
24 2
13
9 24
0 2
22 24
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 24
8 2
24 2
13
9 24
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 24
24
9 23
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
24 2
10 1
19 12
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
24 2
10 1
19 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 12
18 1
21 1
24
9 23
0 2
22 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
23 2
8 2
10 1
19 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
20 1
18 1
21 12
end_CG
