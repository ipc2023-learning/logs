begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var5
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var6
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var7
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var8
-1
8
Atom holding(b1)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on-table(b1)
end_variable
begin_variable
var9
-1
8
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on-table(b2)
end_variable
begin_variable
var10
-1
8
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on-table(b3)
end_variable
begin_variable
var12
-1
8
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on-table(b5)
end_variable
begin_variable
var13
-1
8
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on-table(b6)
end_variable
begin_variable
var14
-1
8
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on-table(b7)
end_variable
begin_variable
var11
-1
8
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on-table(b4)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
8
begin_mutex_group
8
6 0
7 0
8 0
9 0
13 0
10 0
11 0
12 0
end_mutex_group
begin_mutex_group
8
0 0
7 0
8 1
9 1
13 1
10 1
11 1
12 1
end_mutex_group
begin_mutex_group
8
1 0
8 0
7 1
9 2
13 2
10 2
11 2
12 2
end_mutex_group
begin_mutex_group
8
2 0
9 0
7 2
8 2
13 3
10 3
11 3
12 3
end_mutex_group
begin_mutex_group
8
14 0
13 0
7 3
8 3
9 3
10 4
11 4
12 4
end_mutex_group
begin_mutex_group
8
3 0
10 0
7 4
8 4
9 4
13 4
11 5
12 5
end_mutex_group
begin_mutex_group
8
4 0
11 0
7 5
8 5
9 5
13 5
10 5
12 6
end_mutex_group
begin_mutex_group
8
5 0
12 0
7 6
8 6
9 6
13 6
10 6
11 6
end_mutex_group
begin_state
0
1
1
1
1
1
0
6
5
3
2
3
5
7
1
end_state
begin_goal
8
7 7
8 1
9 2
10 5
11 6
12 3
13 4
14 0
end_goal
98
begin_operator
pickup b1
0
3
0 6 0 1
0 0 0 1
0 7 7 0
0
end_operator
begin_operator
pickup b2
0
3
0 6 0 1
0 1 0 1
0 8 7 0
0
end_operator
begin_operator
pickup b3
0
3
0 6 0 1
0 2 0 1
0 9 7 0
0
end_operator
begin_operator
pickup b4
0
3
0 6 0 1
0 14 0 1
0 13 7 0
0
end_operator
begin_operator
pickup b5
0
3
0 6 0 1
0 3 0 1
0 10 7 0
0
end_operator
begin_operator
pickup b6
0
3
0 6 0 1
0 4 0 1
0 11 7 0
0
end_operator
begin_operator
pickup b7
0
3
0 6 0 1
0 5 0 1
0 12 7 0
0
end_operator
begin_operator
putdown b1
0
3
0 6 -1 0
0 0 -1 0
0 7 0 7
0
end_operator
begin_operator
putdown b2
0
3
0 6 -1 0
0 1 -1 0
0 8 0 7
0
end_operator
begin_operator
putdown b3
0
3
0 6 -1 0
0 2 -1 0
0 9 0 7
0
end_operator
begin_operator
putdown b4
0
3
0 6 -1 0
0 14 -1 0
0 13 0 7
0
end_operator
begin_operator
putdown b5
0
3
0 6 -1 0
0 3 -1 0
0 10 0 7
0
end_operator
begin_operator
putdown b6
0
3
0 6 -1 0
0 4 -1 0
0 11 0 7
0
end_operator
begin_operator
putdown b7
0
3
0 6 -1 0
0 5 -1 0
0 12 0 7
0
end_operator
begin_operator
stack b1 b2
0
4
0 6 -1 0
0 0 -1 0
0 1 0 1
0 7 0 1
0
end_operator
begin_operator
stack b1 b3
0
4
0 6 -1 0
0 0 -1 0
0 2 0 1
0 7 0 2
0
end_operator
begin_operator
stack b1 b4
0
4
0 6 -1 0
0 0 -1 0
0 14 0 1
0 7 0 3
0
end_operator
begin_operator
stack b1 b5
0
4
0 6 -1 0
0 0 -1 0
0 3 0 1
0 7 0 4
0
end_operator
begin_operator
stack b1 b6
0
4
0 6 -1 0
0 0 -1 0
0 4 0 1
0 7 0 5
0
end_operator
begin_operator
stack b1 b7
0
4
0 6 -1 0
0 0 -1 0
0 5 0 1
0 7 0 6
0
end_operator
begin_operator
stack b2 b1
0
4
0 6 -1 0
0 0 0 1
0 1 -1 0
0 8 0 1
0
end_operator
begin_operator
stack b2 b3
0
4
0 6 -1 0
0 1 -1 0
0 2 0 1
0 8 0 2
0
end_operator
begin_operator
stack b2 b4
0
4
0 6 -1 0
0 1 -1 0
0 14 0 1
0 8 0 3
0
end_operator
begin_operator
stack b2 b5
0
4
0 6 -1 0
0 1 -1 0
0 3 0 1
0 8 0 4
0
end_operator
begin_operator
stack b2 b6
0
4
0 6 -1 0
0 1 -1 0
0 4 0 1
0 8 0 5
0
end_operator
begin_operator
stack b2 b7
0
4
0 6 -1 0
0 1 -1 0
0 5 0 1
0 8 0 6
0
end_operator
begin_operator
stack b3 b1
0
4
0 6 -1 0
0 0 0 1
0 2 -1 0
0 9 0 1
0
end_operator
begin_operator
stack b3 b2
0
4
0 6 -1 0
0 1 0 1
0 2 -1 0
0 9 0 2
0
end_operator
begin_operator
stack b3 b4
0
4
0 6 -1 0
0 2 -1 0
0 14 0 1
0 9 0 3
0
end_operator
begin_operator
stack b3 b5
0
4
0 6 -1 0
0 2 -1 0
0 3 0 1
0 9 0 4
0
end_operator
begin_operator
stack b3 b6
0
4
0 6 -1 0
0 2 -1 0
0 4 0 1
0 9 0 5
0
end_operator
begin_operator
stack b3 b7
0
4
0 6 -1 0
0 2 -1 0
0 5 0 1
0 9 0 6
0
end_operator
begin_operator
stack b4 b1
0
4
0 6 -1 0
0 0 0 1
0 14 -1 0
0 13 0 1
0
end_operator
begin_operator
stack b4 b2
0
4
0 6 -1 0
0 1 0 1
0 14 -1 0
0 13 0 2
0
e




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





14
1
7 0
1
27
1
9 0
1
33
1
13 0
1
39
1
10 0
1
45
1
11 0
1
51
1
12 0
1
1
2
6 0
8 7
1
62
2
6 0
8 1
1
63
2
6 0
8 2
1
64
2
6 0
8 3
1
65
2
6 0
8 4
1
66
2
6 0
8 5
1
67
2
6 0
8 6
7
0
8
1
8 0
0
56
3
6 0
0 0
7 1
0
69
3
6 0
2 0
9 2
0
75
3
6 0
14 0
13 2
0
81
3
6 0
3 0
10 2
0
87
3
6 0
4 0
11 2
0
93
3
6 0
5 0
12 2
end_DTG
begin_DTG
13
1
15
1
7 0
1
21
1
8 0
1
34
1
13 0
1
40
1
10 0
1
46
1
11 0
1
52
1
12 0
1
2
2
6 0
9 7
1
68
2
6 0
9 1
1
69
2
6 0
9 2
1
70
2
6 0
9 3
1
71
2
6 0
9 4
1
72
2
6 0
9 5
1
73
2
6 0
9 6
7
0
9
1
9 0
0
57
3
6 0
0 0
7 2
0
63
3
6 0
1 0
8 2
0
76
3
6 0
14 0
13 3
0
82
3
6 0
3 0
10 3
0
88
3
6 0
4 0
11 3
0
94
3
6 0
5 0
12 3
end_DTG
begin_DTG
13
1
17
1
7 0
1
23
1
8 0
1
29
1
9 0
1
35
1
13 0
1
48
1
11 0
1
54
1
12 0
1
4
2
6 0
10 7
1
80
2
6 0
10 1
1
81
2
6 0
10 2
1
82
2
6 0
10 3
1
83
2
6 0
10 4
1
84
2
6 0
10 5
1
85
2
6 0
10 6
7
0
11
1
10 0
0
59
3
6 0
0 0
7 4
0
65
3
6 0
1 0
8 4
0
71
3
6 0
2 0
9 4
0
77
3
6 0
14 0
13 4
0
90
3
6 0
4 0
11 5
0
96
3
6 0
5 0
12 5
end_DTG
begin_DTG
13
1
18
1
7 0
1
24
1
8 0
1
30
1
9 0
1
36
1
13 0
1
42
1
10 0
1
55
1
12 0
1
5
2
6 0
11 7
1
86
2
6 0
11 1
1
87
2
6 0
11 2
1
88
2
6 0
11 3
1
89
2
6 0
11 4
1
90
2
6 0
11 5
1
91
2
6 0
11 6
7
0
12
1
11 0
0
60
3
6 0
0 0
7 5
0
66
3
6 0
1 0
8 5
0
72
3
6 0
2 0
9 5
0
78
3
6 0
14 0
13 5
0
84
3
6 0
3 0
10 5
0
97
3
6 0
5 0
12 6
end_DTG
begin_DTG
13
1
19
1
7 0
1
25
1
8 0
1
31
1
9 0
1
37
1
13 0
1
43
1
10 0
1
49
1
11 0
1
6
2
6 0
12 7
1
92
2
6 0
12 1
1
93
2
6 0
12 2
1
94
2
6 0
12 3
1
95
2
6 0
12 4
1
96
2
6 0
12 5
1
97
2
6 0
12 6
7
0
13
1
12 0
0
61
3
6 0
0 0
7 6
0
67
3
6 0
1 0
8 6
0
73
3
6 0
2 0
9 6
0
79
3
6 0
14 0
13 6
0
85
3
6 0
3 0
10 6
0
91
3
6 0
4 0
11 6
end_DTG
begin_DTG
49
1
86
2
4 0
11 1
1
74
2
14 0
13 1
1
75
2
14 0
13 2
1
76
2
14 0
13 3
1
77
2
14 0
13 4
1
78
2
14 0
13 5
1
79
2
14 0
13 6
1
80
2
3 0
10 1
1
81
2
3 0
10 2
1
82
2
3 0
10 3
1
83
2
3 0
10 4
1
84
2
3 0
10 5
1
85
2
3 0
10 6
1
73
2
2 0
9 6
1
87
2
4 0
11 2
1
88
2
4 0
11 3
1
89
2
4 0
11 4
1
90
2
4 0
11 5
1
91
2
4 0
11 6
1
92
2
5 0
12 1
1
93
2
5 0
12 2
1
94
2
5 0
12 3
1
95
2
5 0
12 4
1
96
2
5 0
12 5
1
97
2
5 0
12 6
1
61
2
0 0
7 6
1
1
2
1 0
8 7
1
2
2
2 0
9 7
1
3
2
14 0
13 7
1
4
2
3 0
10 7
1
5
2
4 0
11 7
1
6
2
5 0
12 7
1
56
2
0 0
7 1
1
57
2
0 0
7 2
1
58
2
0 0
7 3
1
59
2
0 0
7 4
1
60
2
0 0
7 5
1
0
2
0 0
7 7
1
62
2
1 0
8 1
1
63
2
1 0
8 2
1
64
2
1 0
8 3
1
65
2
1 0
8 4
1
66
2
1 0
8 5
1
67
2
1 0
8 6
1
68
2
2 0
9 1
1
69
2
2 0
9 2
1
70
2
2 0
9 3
1
71
2
2 0
9 4
1
72
2
2 0
9 5
7
0
8
1
8 0
0
9
1
9 0
0
10
1
13 0
0
11
1
10 0
0
12
1
11 0
0
13
1
12 0
0
7
1
7 0
end_DTG
begin_DTG
7
1
14
1
1 0
2
15
1
2 0
3
16
1
14 0
4
17
1
3 0
5
18
1
4 0
6
19
1
5 0
7
7
0
1
0
56
2
6 0
0 0
1
0
57
2
6 0
0 0
1
0
58
2
6 0
0 0
1
0
59
2
6 0
0 0
1
0
60
2
6 0
0 0
1
0
61
2
6 0
0 0
1
0
0
2
6 0
0 0
end_DTG
begin_DTG
7
1
20
1
0 0
2
21
1
2 0
3
22
1
14 0
4
23
1
3 0
5
24
1
4 0
6
25
1
5 0
7
8
0
1
0
62
2
6 0
1 0
1
0
63
2
6 0
1 0
1
0
64
2
6 0
1 0
1
0
65
2
6 0
1 0
1
0
66
2
6 0
1 0
1
0
67
2
6 0
1 0
1
0
1
2
6 0
1 0
end_DTG
begin_DTG
7
1
26
1
0 0
2
27
1
1 0
3
28
1
14 0
4
29
1
3 0
5
30
1
4 0
6
31
1
5 0
7
9
0
1
0
68
2
6 0
2 0
1
0
69
2
6 0
2 0
1
0
70
2
6 0
2 0
1
0
71
2
6 0
2 0
1
0
72
2
6 0
2 0
1
0
73
2
6 0
2 0
1
0
2
2
6 0
2 0
end_DTG
begin_DTG
7
1
38
1
0 0
2
39
1
1 0
3
40
1
2 0
4
41
1
14 0
5
42
1
4 0
6
43
1
5 0
7
11
0
1
0
80
2
6 0
3 0
1
0
81
2
6 0
3 0
1
0
82
2
6 0
3 0
1
0
83
2
6 0
3 0
1
0
84
2
6 0
3 0
1
0
85
2
6 0
3 0
1
0
4
2
6 0
3 0
end_DTG
begin_DTG
7
1
44
1
0 0
2
45
1
1 0
3
46
1
2 0
4
47
1
14 0
5
48
1
3 0
6
49
1
5 0
7
12
0
1
0
86
2
6 0
4 0
1
0
87
2
6 0
4 0
1
0
88
2
6 0
4 0
1
0
89
2
6 0
4 0
1
0
90
2
6 0
4 0
1
0
91
2
6 0
4 0
1
0
5
2
6 0
4 0
end_DTG
begin_DTG
7
1
50
1
0 0
2
51
1
1 0
3
52
1
2 0
4
53
1
14 0
5
54
1
3 0
6
55
1
4 0
7
13
0
1
0
92
2
6 0
5 0
1
0
93
2
6 0
5 0
1
0
94
2
6 0
5 0
1
0
95
2
6 0
5 0
1
0
96
2
6 0
5 0
1
0
97
2
6 0
5 0
1
0
6
2
6 0
5 0
end_DTG
begin_DTG
7
1
32
1
0 0
2
33
1
1 0
3
34
1
2 0
4
35
1
3 0
5
36
1
4 0
6
37
1
5 0
7
10
0
1
0
74
2
6 0
14 0
1
0
75
2
6 0
14 0
1
0
76
2
6 0
14 0
1
0
77
2
6 0
14 0
1
0
78
2
6 0
14 0
1
0
79
2
6 0
14 0
1
0
3
2
6 0
14 0
end_DTG
begin_DTG
13
1
16
1
7 0
1
22
1
8 0
1
28
1
9 0
1
41
1
10 0
1
47
1
11 0
1
53
1
12 0
1
3
2
6 0
13 7
1
74
2
6 0
13 1
1
75
2
6 0
13 2
1
76
2
6 0
13 3
1
77
2
6 0
13 4
1
78
2
6 0
13 5
1
79
2
6 0
13 6
7
0
10
1
13 0
0
58
3
6 0
0 0
7 3
0
64
3
6 0
1 0
8 3
0
70
3
6 0
2 0
9 3
0
83
3
6 0
3 0
10 4
0
89
3
6 0
4 0
11 4
0
95
3
6 0
5 0
12 4
end_DTG
begin_CG
14
6 13
1 2
2 2
14 2
3 2
4 2
5 2
7 7
8 1
9 1
13 1
10 1
11 1
12 1
14
6 13
0 2
2 2
14 2
3 2
4 2
5 2
7 1
8 7
9 1
13 1
10 1
11 1
12 1
14
6 13
0 2
1 2
14 2
3 2
4 2
5 2
7 1
8 1
9 7
13 1
10 1
11 1
12 1
14
6 13
0 2
1 2
2 2
14 2
4 2
5 2
7 1
8 1
9 1
13 1
10 7
11 1
12 1
14
6 13
0 2
1 2
2 2
14 2
3 2
5 2
7 1
8 1
9 1
13 1
10 1
11 7
12 1
14
6 13
0 2
1 2
2 2
14 2
3 2
4 2
7 1
8 1
9 1
13 1
10 1
11 1
12 7
14
0 13
1 13
2 13
14 13
3 13
4 13
5 13
7 7
8 7
9 7
13 7
10 7
11 7
12 7
8
6 14
0 14
1 2
2 2
14 2
3 2
4 2
5 2
8
6 14
0 2
1 14
2 2
14 2
3 2
4 2
5 2
8
6 14
0 2
1 2
2 14
14 2
3 2
4 2
5 2
8
6 14
0 2
1 2
2 2
14 2
3 14
4 2
5 2
8
6 14
0 2
1 2
2 2
14 2
3 2
4 14
5 2
8
6 14
0 2
1 2
2 2
14 2
3 2
4 2
5 14
8
6 14
0 2
1 2
2 2
14 14
3 2
4 2
5 2
14
6 13
0 2
1 2
2 2
3 2
4 2
5 2
7 1
8 1
9 1
13 7
10 1
11 1
12 1
end_CG
