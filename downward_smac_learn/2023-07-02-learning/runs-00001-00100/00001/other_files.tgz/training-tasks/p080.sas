begin_version
3
end_version
begin_metric
0
end_metric
49
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var16
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var17
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var19
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var20
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var21
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var22
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var23
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var24
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var25
-1
25
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var26
-1
25
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var27
-1
25
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var28
-1
25
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var29
-1
25
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b21)
Atom on(b13, b22)
Atom on(b13, b23)
Atom on(b13, b24)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var30
-1
25
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b24)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var31
-1
25
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b21)
Atom on(b15, b22)
Atom on(b15, b23)
Atom on(b15, b24)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var32





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 1
37 24
38 1
39 1
40 1
41 1
42 1
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
17 2
18 2
19 2
20 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 1
37 1
38 24
39 1
40 1
41 1
42 1
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
18 2
19 2
20 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 1
37 1
38 1
39 24
40 1
41 1
42 1
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
19 2
20 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 1
37 1
38 1
39 1
40 24
41 1
42 1
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
20 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 1
37 1
38 1
39 1
40 1
41 24
42 1
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 1
37 1
38 1
39 1
40 1
41 1
42 24
48
0 47
1 47
2 47
3 47
4 47
5 47
6 47
7 47
8 47
46 47
9 47
10 47
11 47
47 47
12 47
13 47
14 47
48 47
15 47
16 47
17 47
18 47
19 47
20 47
22 24
23 24
24 24
25 24
26 24
27 24
28 24
29 24
30 24
43 24
31 24
32 24
33 24
44 24
34 24
35 24
36 24
45 24
37 24
38 24
39 24
40 24
41 24
42 24
25
21 48
0 48
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 48
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 48
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 48
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 48
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 48
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 48
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 48
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 48
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 48
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 48
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 48
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 48
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 48
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 48
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 48
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 48
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 48
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 48
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 48
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 48
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 48
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 48
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
25
21 48
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 48
15 2
16 2
17 2
18 2
19 2
20 2
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 24
31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 1
37 1
38 1
39 1
40 1
41 1
42 1
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
12 2
13 2
14 2
48 2
15 2
16 2
17 2
18 2
19 2
20 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
33 1
44 24
34 1
35 1
36 1
45 1
37 1
38 1
39 1
40 1
41 1
42 1
48
21 47
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
46 2
9 2
10 2
11 2
47 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
33 1
44 1
34 1
35 1
36 1
45 24
37 1
38 1
39 1
40 1
41 1
42 1
end_CG
