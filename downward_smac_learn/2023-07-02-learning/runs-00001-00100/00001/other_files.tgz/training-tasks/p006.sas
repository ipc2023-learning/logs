begin_version
3
end_version
begin_metric
0
end_metric
7
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var4
-1
4
Atom holding(b1)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on-table(b1)
end_variable
begin_variable
var5
-1
4
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b3)
Atom on-table(b2)
end_variable
begin_variable
var6
-1
4
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b2)
Atom on-table(b3)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
4
begin_mutex_group
4
2 0
3 0
4 0
5 0
end_mutex_group
begin_mutex_group
4
0 0
3 0
4 1
5 1
end_mutex_group
begin_mutex_group
4
1 0
4 0
3 1
5 2
end_mutex_group
begin_mutex_group
4
6 0
5 0
3 2
4 2
end_mutex_group
begin_state
0
0
0
3
3
3
0
end_state
begin_goal
4
3 3
4 1
5 2
6 0
end_goal
18
begin_operator
pickup b1
0
3
0 2 0 1
0 0 0 1
0 3 3 0
0
end_operator
begin_operator
pickup b2
0
3
0 2 0 1
0 1 0 1
0 4 3 0
0
end_operator
begin_operator
pickup b3
0
3
0 2 0 1
0 6 0 1
0 5 3 0
0
end_operator
begin_operator
putdown b1
0
3
0 2 -1 0
0 0 -1 0
0 3 0 3
0
end_operator
begin_operator
putdown b2
0
3
0 2 -1 0
0 1 -1 0
0 4 0 3
0
end_operator
begin_operator
putdown b3
0
3
0 2 -1 0
0 6 -1 0
0 5 0 3
0
end_operator
begin_operator
stack b1 b2
0
4
0 2 -1 0
0 0 -1 0
0 1 0 1
0 3 0 1
0
end_operator
begin_operator
stack b1 b3
0
4
0 2 -1 0
0 0 -1 0
0 6 0 1
0 3 0 2
0
end_operator
begin_operator
stack b2 b1
0
4
0 2 -1 0
0 0 0 1
0 1 -1 0
0 4 0 1
0
end_operator
begin_operator
stack b2 b3
0
4
0 2 -1 0
0 1 -1 0
0 6 0 1
0 4 0 2
0
end_operator
begin_operator
stack b3 b1
0
4
0 2 -1 0
0 0 0 1
0 6 -1 0
0 5 0 1
0
end_operator
begin_operator
stack b3 b2
0
4
0 2 -1 0
0 1 0 1
0 6 -1 0
0 5 0 2
0
end_operator
begin_operator
unstack b1 b2
0
4
0 2 0 1
0 0 0 1
0 1 -1 0
0 3 1 0
0
end_operator
begin_operator
unstack b1 b3
0
4
0 2 0 1
0 0 0 1
0 6 -1 0
0 3 2 0
0
end_operator
begin_operator
unstack b2 b1
0
4
0 2 0 1
0 0 -1 0
0 1 0 1
0 4 1 0
0
end_operator
begin_operator
unstack b2 b3
0
4
0 2 0 1
0 1 0 1
0 6 -1 0
0 4 2 0
0
end_operator
begin_operator
unstack b3 b1
0
4
0 2 0 1
0 0 -1 0
0 6 0 1
0 5 1 0
0
end_operator
begin_operator
unstack b3 b2
0
4
0 2 0 1
0 1 -1 0
0 6 0 1
0 5 2 0
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
switch 3
check 0
check 0
check 1
12
check 1
13
check 1
0
check 0
check 0
switch 1
check 0
switch 4
check 0
check 0
check 1
14
check 1
15
check 1
1
check 0
check 0
switch 6
check 0
switch 5
check 0
check 0
check 1
16
check 1
17
check 1
2
check 0
check 0
check 0
check 0
switch 0
check 0
switch 4
check 0
check 1
8
check 0
check 0
check 0
switch 5
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 3
check 0
check 1
6
check 0
check 0
check 0
switch 5
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 3
check 0
check 1
7
check 0
check 0
check 0
switch 4
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
3
check 0
check 0
check 0
switch 4
check 0
check 1
4
check 0
check 0
check 0
switch 5
check 0
check 1
5
check 0
check 0
check 0
check 0
end_SG
begin_DTG
5
1
8
1
4 0
1
10
1
5 0
1
0
2
2 0
3 3
1
12
2
2 0
3 1
1
13
2
2 0
3 2
3
0
3
1
3 0
0
14
3
2 0
1 0
4 1
0
16
3
2 0
6 0
5 1
end_DTG
begin_DTG
5
1
6
1
3 0
1
11
1
5 0
1
1
2
2 0
4 3
1
14
2
2 0
4 1
1
15
2
2 0
4 2
3
0
4
1
4 0
0
12
3
2 0
0 0
3 1
0
17
3
2 0
6 0
5 2
end_DTG
begin_DTG
9
1
0
2
0 0
3 3
1
1
2
1 0
4 3
1
2
2
6 0
5 3
1
12
2
0 0
3 1
1
13
2
0 0
3 2
1
14
2
1 0
4 1
1
15
2
1 0
4 2
1
16
2
6 0
5 1
1
17
2
6 0
5 2
3
0
3
1
3 0
0
4
1
4 0
0
5
1
5 0
end_DTG
begin_DTG
3
1
6
1
1 0
2
7
1
6 0
3
3
0
1
0
12
2
2 0
0 0
1
0
13
2
2 0
0 0
1
0
0
2
2 0
0 0
end_DTG
begin_DTG
3
1
8
1
0 0
2
9
1
6 0
3
4
0
1
0
14
2
2 0
1 0
1
0
15
2
2 0
1 0
1
0
1
2
2 0
1 0
end_DTG
begin_DTG
3
1
10
1
0 0
2
11
1
1 0
3
5
0
1
0
16
2
2 0
6 0
1
0
17
2
2 0
6 0
1
0
2
2
2 0
6 0
end_DTG
begin_DTG
5
1
7
1
3 0
1
9
1
4 0
1
2
2
2 0
5 3
1
16
2
2 0
5 1
1
17
2
2 0
5 2
3
0
5
1
5 0
0
13
3
2 0
0 0
3 2
0
15
3
2 0
1 0
4 2
end_DTG
begin_CG
6
2 5
1 2
6 2
3 3
4 1
5 1
6
2 5
0 2
6 2
3 1
4 3
5 1
6
0 5
1 5
6 5
3 3
4 3
5 3
4
2 6
0 6
1 2
6 2
4
2 6
0 2
1 6
6 2
4
2 6
0 2
1 2
6 6
6
2 5
0 2
1 2
3 1
4 1
5 3
end_CG
