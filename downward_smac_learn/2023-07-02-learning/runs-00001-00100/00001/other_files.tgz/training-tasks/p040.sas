begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var7
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var8
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var9
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var11
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var12
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var13
-1
13
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var14
-1
13
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var15
-1
13
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var16
-1
13
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var19
-1
13
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var20
-1
13
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var21
-1
13
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var23
-1
13
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var24
-1
13
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var17
-1
13
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var18
-1
13
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var22
-1
13
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var5
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var6
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var10
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
13
begin_mutex_group
13
9 0
10 0
11 0
12 0
13 0
19 0
20 0
14 0
15 0
16 0
21 0
17 0
18 0
end_mutex_group
begin_mutex_group
13
0 0
10 0
11 1
12 1
13 1
19 1
20 1
14 1
15 1
16 1
21 1
17 1
18 1
end_mutex_group
begin_mutex_group
13
1 0
11 0
10 1
12 2
13 2
19 2
20 2
14 2
15 2
16 2
21 2
17 2
18 2
end_mutex_group
begin_mutex_group
13
2 0
12 0
10 2
11 2
13 3
19 3
20 3
14 3
15 3
16 3
21 3
17 3
18 3
end_mutex_group
begin_mutex_group
13
3 0
13 0
10 3
11 3
12 3
19 4
20 4
14 4
15 4
16 4
21 4
17 4
18 4
end_mutex_group
begin_mutex_group
13
22 0
19 0
10 4
11 4
12 4
13 4
20 5
14 5
15 5
16 5
21 5
17 5
18 5
end_mutex_group
begin_mutex_group
13
23 0
20 0
10 5
11 5
12 5
13 5
19 5
14 6
15 6
16 6
21 6
17 6
18 6
end_mutex_group
begin_mutex_group
13
4 0
14 0
10 6
11 6
12 6
13 6
19 6
20 6
15 7
16 7
21 7
17 7
18 7
end_mutex_group
begin_mutex_group
13
5 0
15 0
10 7
11 7
12 7
13 7
19 7
20 7
14 7
16 8
21 8
17 8
18 8
end_mutex_group
begin_mutex_group
13
6 0
16 0
10 8
11 8
12 8
13 8
19 8
20 8
14 8
15 8
21 9
17




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





78
1
8 0
12
16
0
1
0
200
2
9 0
22 0
1
0
201
2
9 0
22 0
1
0
202
2
9 0
22 0
1
0
203
2
9 0
22 0
1
0
204
2
9 0
22 0
1
0
205
2
9 0
22 0
1
0
206
2
9 0
22 0
1
0
207
2
9 0
22 0
1
0
208
2
9 0
22 0
1
0
209
2
9 0
22 0
1
0
210
2
9 0
22 0
1
0
4
2
9 0
22 0
end_DTG
begin_DTG
12
1
79
1
0 0
2
80
1
1 0
3
81
1
2 0
4
82
1
3 0
5
83
1
22 0
6
84
1
4 0
7
85
1
5 0
8
86
1
6 0
9
87
1
24 0
10
88
1
7 0
11
89
1
8 0
12
17
0
1
0
211
2
9 0
23 0
1
0
212
2
9 0
23 0
1
0
213
2
9 0
23 0
1
0
214
2
9 0
23 0
1
0
215
2
9 0
23 0
1
0
216
2
9 0
23 0
1
0
217
2
9 0
23 0
1
0
218
2
9 0
23 0
1
0
219
2
9 0
23 0
1
0
220
2
9 0
23 0
1
0
221
2
9 0
23 0
1
0
5
2
9 0
23 0
end_DTG
begin_DTG
12
1
123
1
0 0
2
124
1
1 0
3
125
1
2 0
4
126
1
3 0
5
127
1
22 0
6
128
1
23 0
7
129
1
4 0
8
130
1
5 0
9
131
1
6 0
10
132
1
7 0
11
133
1
8 0
12
21
0
1
0
255
2
9 0
24 0
1
0
256
2
9 0
24 0
1
0
257
2
9 0
24 0
1
0
258
2
9 0
24 0
1
0
259
2
9 0
24 0
1
0
260
2
9 0
24 0
1
0
261
2
9 0
24 0
1
0
262
2
9 0
24 0
1
0
263
2
9 0
24 0
1
0
264
2
9 0
24 0
1
0
265
2
9 0
24 0
1
0
9
2
9 0
24 0
end_DTG
begin_DTG
23
1
27
1
10 0
1
149
1
18 0
1
138
1
17 0
1
127
1
21 0
1
116
1
16 0
1
105
1
15 0
1
83
1
20 0
1
60
1
13 0
1
49
1
12 0
1
38
1
11 0
1
94
1
14 0
1
210
2
9 0
19 11
1
209
2
9 0
19 10
1
208
2
9 0
19 9
1
207
2
9 0
19 8
1
206
2
9 0
19 7
1
205
2
9 0
19 6
1
204
2
9 0
19 5
1
203
2
9 0
19 4
1
202
2
9 0
19 3
1
201
2
9 0
19 2
1
200
2
9 0
19 1
1
4
2
9 0
19 12
12
0
16
1
19 0
0
159
3
9 0
0 0
10 4
0
170
3
9 0
1 0
11 4
0
181
3
9 0
2 0
12 4
0
192
3
9 0
3 0
13 4
0
215
3
9 0
23 0
20 5
0
226
3
9 0
4 0
14 5
0
237
3
9 0
5 0
15 5
0
248
3
9 0
6 0
16 5
0
259
3
9 0
24 0
21 5
0
270
3
9 0
7 0
17 5
0
281
3
9 0
8 0
18 5
end_DTG
begin_DTG
23
1
28
1
10 0
1
150
1
18 0
1
139
1
17 0
1
128
1
21 0
1
117
1
16 0
1
106
1
15 0
1
72
1
19 0
1
61
1
13 0
1
50
1
12 0
1
39
1
11 0
1
95
1
14 0
1
221
2
9 0
20 11
1
220
2
9 0
20 10
1
219
2
9 0
20 9
1
218
2
9 0
20 8
1
217
2
9 0
20 7
1
216
2
9 0
20 6
1
215
2
9 0
20 5
1
214
2
9 0
20 4
1
213
2
9 0
20 3
1
212
2
9 0
20 2
1
211
2
9 0
20 1
1
5
2
9 0
20 12
12
0
17
1
20 0
0
160
3
9 0
0 0
10 5
0
171
3
9 0
1 0
11 5
0
182
3
9 0
2 0
12 5
0
193
3
9 0
3 0
13 5
0
204
3
9 0
22 0
19 5
0
227
3
9 0
4 0
14 6
0
238
3
9 0
5 0
15 6
0
249
3
9 0
6 0
16 6
0
260
3
9 0
24 0
21 6
0
271
3
9 0
7 0
17 6
0
282
3
9 0
8 0
18 6
end_DTG
begin_DTG
23
1
32
1
10 0
1
154
1
18 0
1
143
1
17 0
1
120
1
16 0
1
109
1
15 0
1
98
1
14 0
1
76
1
19 0
1
65
1
13 0
1
54
1
12 0
1
43
1
11 0
1
87
1
20 0
1
265
2
9 0
21 11
1
264
2
9 0
21 10
1
263
2
9 0
21 9
1
262
2
9 0
21 8
1
261
2
9 0
21 7
1
260
2
9 0
21 6
1
259
2
9 0
21 5
1
258
2
9 0
21 4
1
257
2
9 0
21 3
1
256
2
9 0
21 2
1
255
2
9 0
21 1
1
9
2
9 0
21 12
12
0
21
1
21 0
0
164
3
9 0
0 0
10 9
0
175
3
9 0
1 0
11 9
0
186
3
9 0
2 0
12 9
0
197
3
9 0
3 0
13 9
0
208
3
9 0
22 0
19 9
0
219
3
9 0
23 0
20 9
0
230
3
9 0
4 0
14 9
0
241
3
9 0
5 0
15 9
0
252
3
9 0
6 0
16 9
0
275
3
9 0
7 0
17 10
0
286
3
9 0
8 0
18 10
end_DTG
begin_CG
24
9 23
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
10 12
11 1
12 1
13 1
19 1
20 1
14 1
15 1
16 1
21 1
17 1
18 1
24
9 23
0 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
10 1
11 12
12 1
13 1
19 1
20 1
14 1
15 1
16 1
21 1
17 1
18 1
24
9 23
0 2
1 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
10 1
11 1
12 12
13 1
19 1
20 1
14 1
15 1
16 1
21 1
17 1
18 1
24
9 23
0 2
1 2
2 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
10 1
11 1
12 1
13 12
19 1
20 1
14 1
15 1
16 1
21 1
17 1
18 1
24
9 23
0 2
1 2
2 2
3 2
22 2
23 2
5 2
6 2
24 2
7 2
8 2
10 1
11 1
12 1
13 1
19 1
20 1
14 12
15 1
16 1
21 1
17 1
18 1
24
9 23
0 2
1 2
2 2
3 2
22 2
23 2
4 2
6 2
24 2
7 2
8 2
10 1
11 1
12 1
13 1
19 1
20 1
14 1
15 12
16 1
21 1
17 1
18 1
24
9 23
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
24 2
7 2
8 2
10 1
11 1
12 1
13 1
19 1
20 1
14 1
15 1
16 12
21 1
17 1
18 1
24
9 23
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
8 2
10 1
11 1
12 1
13 1
19 1
20 1
14 1
15 1
16 1
21 1
17 12
18 1
24
9 23
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
10 1
11 1
12 1
13 1
19 1
20 1
14 1
15 1
16 1
21 1
17 1
18 12
24
0 23
1 23
2 23
3 23
22 23
23 23
4 23
5 23
6 23
24 23
7 23
8 23
10 12
11 12
12 12
13 12
19 12
20 12
14 12
15 12
16 12
21 12
17 12
18 12
13
9 24
0 24
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
13
9 24
0 2
1 24
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
13
9 24
0 2
1 2
2 24
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
13
9 24
0 2
1 2
2 2
3 24
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
13
9 24
0 2
1 2
2 2
3 2
22 2
23 2
4 24
5 2
6 2
24 2
7 2
8 2
13
9 24
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 24
6 2
24 2
7 2
8 2
13
9 24
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 24
24 2
7 2
8 2
13
9 24
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 24
8 2
13
9 24
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 2
7 2
8 24
13
9 24
0 2
1 2
2 2
3 2
22 24
23 2
4 2
5 2
6 2
24 2
7 2
8 2
13
9 24
0 2
1 2
2 2
3 2
22 2
23 24
4 2
5 2
6 2
24 2
7 2
8 2
13
9 24
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
24 24
7 2
8 2
24
9 23
0 2
1 2
2 2
3 2
23 2
4 2
5 2
6 2
24 2
7 2
8 2
10 1
11 1
12 1
13 1
19 12
20 1
14 1
15 1
16 1
21 1
17 1
18 1
24
9 23
0 2
1 2
2 2
3 2
22 2
4 2
5 2
6 2
24 2
7 2
8 2
10 1
11 1
12 1
13 1
19 1
20 12
14 1
15 1
16 1
21 1
17 1
18 1
24
9 23
0 2
1 2
2 2
3 2
22 2
23 2
4 2
5 2
6 2
7 2
8 2
10 1
11 1
12 1
13 1
19 1
20 1
14 1
15 1
16 1
21 12
17 1
18 1
end_CG
