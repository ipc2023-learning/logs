begin_version
3
end_version
begin_metric
0
end_metric
45
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var16
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var17
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var19
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var20
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var21
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var22
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var24
-1
23
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var25
-1
23
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var26
-1
23
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var27
-1
23
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b21)
Atom on(b13, b22)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var28
-1
23
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var29
-1
23
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b21)
Atom on(b15, b22)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var30
-1
23
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
end_variable
begin_variable
var31
-1
23
Atom holding(b17)
Atom on(b17, b1)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b21)
Atom on(b17, b22)
Atom on(b17, b3)
Atom on(b17,




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




28 1
29 1
30 1
31 22
32 1
33 1
34 1
35 1
36 1
42 1
37 1
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 22
33 1
34 1
35 1
36 1
42 1
37 1
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 22
34 1
35 1
36 1
42 1
37 1
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 22
35 1
36 1
42 1
37 1
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
15 2
44 2
16 2
17 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 22
36 1
42 1
37 1
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
44 2
16 2
17 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 22
42 1
37 1
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
17 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
42 1
37 22
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
42 1
37 1
38 22
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
42 1
37 1
38 1
39 22
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
42 1
37 1
38 1
39 1
40 22
44
43 43
0 43
1 43
2 43
3 43
4 43
5 43
6 43
7 43
8 43
9 43
10 43
11 43
12 43
13 43
14 43
15 43
44 43
16 43
17 43
18 43
19 43
41 22
21 22
22 22
23 22
24 22
25 22
26 22
27 22
28 22
29 22
30 22
31 22
32 22
33 22
34 22
35 22
36 22
42 22
37 22
38 22
39 22
40 22
23
20 44
43 2
0 44
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 44
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 44
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 44
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 44
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 44
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 44
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 44
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 44
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 44
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 44
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 44
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 44
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 44
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 44
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 44
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 44
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 44
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 44
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 44
23
20 44
43 44
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
23
20 44
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 44
16 2
17 2
18 2
19 2
44
20 43
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
44 2
16 2
17 2
18 2
19 2
41 22
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
42 1
37 1
38 1
39 1
40 1
44
20 43
43 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
41 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
42 22
37 1
38 1
39 1
40 1
end_CG
