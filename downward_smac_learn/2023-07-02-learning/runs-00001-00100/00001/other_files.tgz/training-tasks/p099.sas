begin_version
3
end_version
begin_metric
0
end_metric
59
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var16
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var17
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var18
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var19
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var20
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var23
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var24
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var25
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var26
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var27
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var28
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var29
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var30
-1
30
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b27)
Atom on(b1, b28)
Atom on(b1, b29)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var31
-1
30
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b25)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b28)
Atom on(b10, b29)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var32
-1
30
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b26)
Atom on(b11, b27)
Atom on(b11, b28)
Atom on(b11, b29)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var33
-1
30
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b25)
Atom on(b12, b26)
Atom on(b12, b27)
Atom on(b12, b28)
Atom on(b12, b29)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var34
-1
30
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b21)
Atom on(b13, b22)
Atom on(b13, b23)
Atom on(b13, b24)
Atom on(b13, b25)
Atom on(b13, b26)
Atom on(b13, b27)
Atom on(b13, b28)
Atom on(b13, b29)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var35
-1
30
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14,




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 57
1 57
2 57
3 57
4 57
5 57
6 57
7 57
8 57
9 57
10 57
11 57
12 57
13 57
14 57
15 57
16 57
17 57
18 57
19 57
57 57
58 57
20 57
21 57
22 57
23 57
24 57
25 57
26 57
28 29
29 29
30 29
31 29
32 29
33 29
34 29
35 29
36 29
37 29
38 29
39 29
40 29
41 29
42 29
43 29
44 29
45 29
46 29
47 29
55 29
56 29
48 29
49 29
50 29
51 29
52 29
53 29
54 29
30
27 58
0 58
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 58
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 58
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 58
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 58
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 58
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 58
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 58
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 58
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 58
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 58
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 58
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 58
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 58
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 58
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 58
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 58
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 58
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 58
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 58
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 58
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 58
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 58
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 58
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 58
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 58
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 58
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 58
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
30
27 58
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
58 58
20 2
21 2
22 2
23 2
24 2
25 2
26 2
58
27 57
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
58 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
45 1
46 1
47 1
55 29
56 1
48 1
49 1
50 1
51 1
52 1
53 1
54 1
58
27 57
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
57 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
45 1
46 1
47 1
55 1
56 29
48 1
49 1
50 1
51 1
52 1
53 1
54 1
end_CG
