begin_version
3
end_version
begin_metric
0
end_metric
55
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var17
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var18
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var19
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var21
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var23
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var24
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var25
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var26
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var28
-1
28
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b27)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var29
-1
28
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b25)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var31
-1
28
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b25)
Atom on(b12, b26)
Atom on(b12, b27)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var33
-1
28
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b26)
Atom on(b14, b27)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var34
-1
28
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b21)
Atom on(b15, b22)
Atom on(b15, b23)
Atom on(b15, b24)
Atom on(b15, b25)
Atom on(b15, b26)
Atom on(b15, b27)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var35
-1
28
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b24)
Atom on(b16, b25)
Atom on(b16, b26)
Atom on(b16, b27)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
end_variable
begin_variable
var36
-1
28
Atom holding(b17)
Atom on(b17, b1)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b2




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 54
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 54
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 54
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 54
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 54
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 54
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 54
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 54
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 54
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 54
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 54
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 54
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 54
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 54
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 54
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 54
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 54
54 2
28
20 54
0 2
1 2
48 54
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 54
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 54
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 54
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 54
15 2
53 2
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 54
16 2
17 2
18 2
19 2
54 2
28
20 54
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 54
54
20 53
0 2
1 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
21 1
22 1
41 27
23 1
42 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
44 1
33 1
34 1
35 1
45 1
36 1
46 1
37 1
38 1
39 1
40 1
47 1
54
20 53
0 2
1 2
48 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
21 1
22 1
41 1
23 1
42 27
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
44 1
33 1
34 1
35 1
45 1
36 1
46 1
37 1
38 1
39 1
40 1
47 1
54
20 53
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
21 1
22 1
41 1
23 1
42 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 27
31 1
32 1
44 1
33 1
34 1
35 1
45 1
36 1
46 1
37 1
38 1
39 1
40 1
47 1
54
20 53
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
21 1
22 1
41 1
23 1
42 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
44 27
33 1
34 1
35 1
45 1
36 1
46 1
37 1
38 1
39 1
40 1
47 1
54
20 53
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
15 2
53 2
16 2
17 2
18 2
19 2
54 2
21 1
22 1
41 1
23 1
42 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
44 1
33 1
34 1
35 1
45 27
36 1
46 1
37 1
38 1
39 1
40 1
47 1
54
20 53
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
54 2
21 1
22 1
41 1
23 1
42 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
44 1
33 1
34 1
35 1
45 1
36 1
46 27
37 1
38 1
39 1
40 1
47 1
54
20 53
0 2
1 2
48 2
2 2
49 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
50 2
10 2
11 2
51 2
12 2
13 2
14 2
52 2
15 2
53 2
16 2
17 2
18 2
19 2
21 1
22 1
41 1
23 1
42 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
43 1
31 1
32 1
44 1
33 1
34 1
35 1
45 1
36 1
46 1
37 1
38 1
39 1
40 1
47 27
end_CG
