begin_version
3
end_version
begin_metric
0
end_metric
27
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var7
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var8
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var9
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var10
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var12
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var13
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var14
-1
14
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var15
-1
14
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var16
-1
14
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var17
-1
14
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var18
-1
14
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b2)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var20
-1
14
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var21
-1
14
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var22
-1
14
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var23
-1
14
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var25
-1
14
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var26
-1
14
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var19
-1
14
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var24
-1
14
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var6
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var11
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
14
begin_mutex_group
14
11 0
12 0
13 0
14 0
15 0
16 0
23 0
17 0
18 0
19 0
20 0
24 0
21 0
22 0
end_mutex_group
begin_mutex_group
14
0 0
12 0
13 1
14 1
15 1
16 1
23 1
17 1
18 1
19 1
20 1
24 1
21 1
22 1
end_mutex_group
begin_mutex_group
14
1 0
13 0
12 1
14 2
15 2
16 2
23 2
17 2
18 2
19 2
20 2
24 2
21 2
22 2
end_mutex_group
begin_mutex_group
14
2 0
14 0
12 2
13 2
15 3
16 3
23 3
17 3
18 3
19 3
20 3
24 3
21 3
22 3
end_mutex_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





328
2
11 0
10 0
1
0
329
2
11 0
10 0
1
0
330
2
11 0
10 0
1
0
331
2
11 0
10 0
1
0
332
2
11 0
10 0
1
0
333
2
11 0
10 0
1
0
334
2
11 0
10 0
1
0
335
2
11 0
10 0
1
0
336
2
11 0
10 0
1
0
337
2
11 0
10 0
1
0
12
2
11 0
10 0
end_DTG
begin_DTG
13
1
86
1
0 0
2
87
1
1 0
3
88
1
2 0
4
89
1
3 0
5
90
1
4 0
6
91
1
5 0
7
92
1
6 0
8
93
1
7 0
9
94
1
8 0
10
95
1
26 0
11
96
1
9 0
12
97
1
10 0
13
18
0
1
0
242
2
11 0
25 0
1
0
243
2
11 0
25 0
1
0
244
2
11 0
25 0
1
0
245
2
11 0
25 0
1
0
246
2
11 0
25 0
1
0
247
2
11 0
25 0
1
0
248
2
11 0
25 0
1
0
249
2
11 0
25 0
1
0
250
2
11 0
25 0
1
0
251
2
11 0
25 0
1
0
252
2
11 0
25 0
1
0
253
2
11 0
25 0
1
0
5
2
11 0
25 0
end_DTG
begin_DTG
13
1
146
1
0 0
2
147
1
1 0
3
148
1
2 0
4
149
1
3 0
5
150
1
4 0
6
151
1
25 0
7
152
1
5 0
8
153
1
6 0
9
154
1
7 0
10
155
1
8 0
11
156
1
9 0
12
157
1
10 0
13
23
0
1
0
302
2
11 0
26 0
1
0
303
2
11 0
26 0
1
0
304
2
11 0
26 0
1
0
305
2
11 0
26 0
1
0
306
2
11 0
26 0
1
0
307
2
11 0
26 0
1
0
308
2
11 0
26 0
1
0
309
2
11 0
26 0
1
0
310
2
11 0
26 0
1
0
311
2
11 0
26 0
1
0
312
2
11 0
26 0
1
0
313
2
11 0
26 0
1
0
10
2
11 0
26 0
end_DTG
begin_DTG
25
1
30
1
12 0
1
175
1
22 0
1
163
1
21 0
1
151
1
24 0
1
139
1
20 0
1
127
1
19 0
1
115
1
18 0
1
78
1
16 0
1
66
1
15 0
1
54
1
14 0
1
42
1
13 0
1
103
1
17 0
1
253
2
11 0
23 12
1
252
2
11 0
23 11
1
251
2
11 0
23 10
1
250
2
11 0
23 9
1
249
2
11 0
23 8
1
248
2
11 0
23 7
1
247
2
11 0
23 6
1
246
2
11 0
23 5
1
245
2
11 0
23 4
1
244
2
11 0
23 3
1
243
2
11 0
23 2
1
242
2
11 0
23 1
1
5
2
11 0
23 13
13
0
18
1
23 0
0
331
3
11 0
10 0
22 6
0
319
3
11 0
9 0
21 6
0
307
3
11 0
26 0
24 6
0
295
3
11 0
8 0
20 6
0
283
3
11 0
7 0
19 6
0
271
3
11 0
6 0
18 6
0
259
3
11 0
5 0
17 6
0
234
3
11 0
4 0
16 5
0
222
3
11 0
3 0
15 5
0
210
3
11 0
2 0
14 5
0
198
3
11 0
1 0
13 5
0
186
3
11 0
0 0
12 5
end_DTG
begin_DTG
25
1
35
1
12 0
1
180
1
22 0
1
168
1
21 0
1
143
1
20 0
1
131
1
19 0
1
119
1
18 0
1
107
1
17 0
1
83
1
16 0
1
71
1
15 0
1
59
1
14 0
1
47
1
13 0
1
95
1
23 0
1
313
2
11 0
24 12
1
312
2
11 0
24 11
1
311
2
11 0
24 10
1
310
2
11 0
24 9
1
309
2
11 0
24 8
1
308
2
11 0
24 7
1
307
2
11 0
24 6
1
306
2
11 0
24 5
1
305
2
11 0
24 4
1
304
2
11 0
24 3
1
303
2
11 0
24 2
1
302
2
11 0
24 1
1
10
2
11 0
24 13
13
0
23
1
24 0
0
336
3
11 0
10 0
22 11
0
324
3
11 0
9 0
21 11
0
299
3
11 0
8 0
20 10
0
287
3
11 0
7 0
19 10
0
275
3
11 0
6 0
18 10
0
263
3
11 0
5 0
17 10
0
251
3
11 0
25 0
23 10
0
239
3
11 0
4 0
16 10
0
227
3
11 0
3 0
15 10
0
215
3
11 0
2 0
14 10
0
203
3
11 0
1 0
13 10
0
191
3
11 0
0 0
12 10
end_DTG
begin_CG
26
11 25
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
12 13
13 1
14 1
15 1
16 1
23 1
17 1
18 1
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
12 1
13 13
14 1
15 1
16 1
23 1
17 1
18 1
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
12 1
13 1
14 13
15 1
16 1
23 1
17 1
18 1
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
12 1
13 1
14 1
15 13
16 1
23 1
17 1
18 1
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
3 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
12 1
13 1
14 1
15 1
16 13
23 1
17 1
18 1
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
3 2
4 2
25 2
6 2
7 2
8 2
26 2
9 2
10 2
12 1
13 1
14 1
15 1
16 1
23 1
17 13
18 1
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
3 2
4 2
25 2
5 2
7 2
8 2
26 2
9 2
10 2
12 1
13 1
14 1
15 1
16 1
23 1
17 1
18 13
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
8 2
26 2
9 2
10 2
12 1
13 1
14 1
15 1
16 1
23 1
17 1
18 1
19 13
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
26 2
9 2
10 2
12 1
13 1
14 1
15 1
16 1
23 1
17 1
18 1
19 1
20 13
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
10 2
12 1
13 1
14 1
15 1
16 1
23 1
17 1
18 1
19 1
20 1
24 1
21 13
22 1
26
11 25
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
12 1
13 1
14 1
15 1
16 1
23 1
17 1
18 1
19 1
20 1
24 1
21 1
22 13
26
0 25
1 25
2 25
3 25
4 25
25 25
5 25
6 25
7 25
8 25
26 25
9 25
10 25
12 13
13 13
14 13
15 13
16 13
23 13
17 13
18 13
19 13
20 13
24 13
21 13
22 13
14
11 26
0 26
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 26
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 26
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 26
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 2
4 26
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 2
4 2
25 2
5 26
6 2
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 26
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 26
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 26
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 26
10 2
14
11 26
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 2
9 2
10 26
14
11 26
0 2
1 2
2 2
3 2
4 2
25 26
5 2
6 2
7 2
8 2
26 2
9 2
10 2
14
11 26
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
26 26
9 2
10 2
26
11 25
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
26 2
9 2
10 2
12 1
13 1
14 1
15 1
16 1
23 13
17 1
18 1
19 1
20 1
24 1
21 1
22 1
26
11 25
0 2
1 2
2 2
3 2
4 2
25 2
5 2
6 2
7 2
8 2
9 2
10 2
12 1
13 1
14 1
15 1
16 1
23 1
17 1
18 1
19 1
20 1
24 13
21 1
22 1
end_CG
