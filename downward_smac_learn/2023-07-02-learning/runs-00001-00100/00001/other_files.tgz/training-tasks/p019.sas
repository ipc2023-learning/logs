begin_version
3
end_version
begin_metric
0
end_metric
13
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var7
-1
7
Atom holding(b1)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on-table(b1)
end_variable
begin_variable
var9
-1
7
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on-table(b3)
end_variable
begin_variable
var10
-1
7
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on-table(b4)
end_variable
begin_variable
var12
-1
7
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on-table(b6)
end_variable
begin_variable
var8
-1
7
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on-table(b2)
end_variable
begin_variable
var11
-1
7
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on-table(b5)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var5
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
7
begin_mutex_group
7
4 0
5 0
9 0
6 0
7 0
10 0
8 0
end_mutex_group
begin_mutex_group
7
0 0
5 0
9 1
6 1
7 1
10 1
8 1
end_mutex_group
begin_mutex_group
7
11 0
9 0
5 1
6 2
7 2
10 2
8 2
end_mutex_group
begin_mutex_group
7
1 0
6 0
5 2
9 2
7 3
10 3
8 3
end_mutex_group
begin_mutex_group
7
2 0
7 0
5 3
9 3
6 3
10 4
8 4
end_mutex_group
begin_mutex_group
7
12 0
10 0
5 4
9 4
6 4
7 4
8 5
end_mutex_group
begin_mutex_group
7
3 0
8 0
5 5
9 5
6 5
7 5
10 5
end_mutex_group
begin_state
0
1
1
1
0
6
5
6
4
4
3
0
1
end_state
begin_goal
8
5 6
6 5
7 3
8 1
9 6
10 4
11 0
12 0
end_goal
72
begin_operator
pickup b1
0
3
0 4 0 1
0 0 0 1
0 5 6 0
0
end_operator
begin_operator
pickup b2
0
3
0 4 0 1
0 11 0 1
0 9 6 0
0
end_operator
begin_operator
pickup b3
0
3
0 4 0 1
0 1 0 1
0 6 6 0
0
end_operator
begin_operator
pickup b4
0
3
0 4 0 1
0 2 0 1
0 7 6 0
0
end_operator
begin_operator
pickup b5
0
3
0 4 0 1
0 12 0 1
0 10 6 0
0
end_operator
begin_operator
pickup b6
0
3
0 4 0 1
0 3 0 1
0 8 6 0
0
end_operator
begin_operator
putdown b1
0
3
0 4 -1 0
0 0 -1 0
0 5 0 6
0
end_operator
begin_operator
putdown b2
0
3
0 4 -1 0
0 11 -1 0
0 9 0 6
0
end_operator
begin_operator
putdown b3
0
3
0 4 -1 0
0 1 -1 0
0 6 0 6
0
end_operator
begin_operator
putdown b4
0
3
0 4 -1 0
0 2 -1 0
0 7 0 6
0
end_operator
begin_operator
putdown b5
0
3
0 4 -1 0
0 12 -1 0
0 10 0 6
0
end_operator
begin_operator
putdown b6
0
3
0 4 -1 0
0 3 -1 0
0 8 0 6
0
end_operator
begin_operator
stack b1 b2
0
4
0 4 -1 0
0 0 -1 0
0 11 0 1
0 5 0 1
0
end_operator
begin_operator
stack b1 b3
0
4
0 4 -1 0
0 0 -1 0
0 1 0 1
0 5 0 2
0
end_operator
begin_operator
stack b1 b4
0
4
0 4 -1 0
0 0 -1 0
0 2 0 1
0 5 0 3
0
end_operator
begin_operator
stack b1 b5
0
4
0 4 -1 0
0 0 -1 0
0 12 0 1
0 5 0 4
0
end_operator
begin_operator
stack b1 b6
0
4
0 4 -1 0
0 0 -1 0
0 3 0 1
0 5 0 5
0
end_operator
begin_operator
stack b2 b1
0
4
0 4 -1 0
0 0 0 1
0 11 -1 0
0 9 0 1
0
end_operator
begin_operator
stack b2 b3
0
4
0 4 -1 0
0 11 -1 0
0 1 0 1
0 9 0 2
0
end_operator
begin_operator
stack b2 b4
0
4
0 4 -1 0
0 11 -1 0
0 2 0 1
0 9 0 3
0
end_operator
begin_operator
stack b2 b5
0
4
0 4 -1 0
0 11 -1 0
0 12 0 1
0 9 0 4
0
end_operator
begin_operator
stack b2 b6
0
4
0 4 -1 0
0 11 -1 0
0 3 0 1
0 9 0 5
0
end_operator
begin_operator
stack b3 b1
0
4
0 4 -1 0
0 0 0 1
0 1 -1 0
0 6 0 1
0
end_operator
begin_operator
stack b3 b2
0
4
0 4 -1 0
0 11 0 1
0 1 -1 0
0 6 0 2
0
end_operator
begin_operator
stack b3 b4
0
4
0 4 -1 0
0 1 -1 0
0 2 0 1
0 6 0 3
0
end_operator
begin_operator
stack b3 b5
0
4
0 4 -1 0
0 1 -1 0
0 12 0 1
0 6 0 4
0
end_operator
begin_operator
stack b3 b6
0
4
0 4 -1 0
0 1 -1 0
0 3 0 1
0 6 0 5
0
end_operator
begin_operator
stack b4 b1
0
4
0 4 -1 0
0 0 0 1
0 2 -1 0
0 7 0 1
0
end_operator
begin_operator
stack b4 b2
0
4
0 4 -1 0
0 11 0 1
0 2 -1 0
0 7 0 2
0
end_operator
begin_operator
stack b4 b3
0
4
0 4 -1 0
0 1 0 1
0 2 -1 0
0 7 0 3
0
end_operator
begin_operator
stack b4 b5
0
4
0 4 -1 0
0 2 -1 0
0 12 0 1
0 7 0 4
0
end_operator
begin_operator
stack b4 b6
0
4
0 4 -1 0
0 2 -1 0
0 3 0 1
0 7 0 5
0
end_operator
begin_operator
stack b5 b1
0
4
0 4 -1 0
0 0 0 1
0 12 -1 0
0 10 0 1
0
end_operator
begin_operator
stack b5 b2
0
4
0 4 -1 0
0 11 0 1
0 12 -1 0
0 10 0 2
0
end_operator
begin_operator
stack b5 b3
0
4
0 4 -1 0
0 1 0 1
0 12 -1 0
0 10 0 3
0
end_operator
begin_operator
stack b5 b4
0
4
0 4 -1 0
0 2 0 1
0 12 -1 0
0 10 0 4
0
end_operator
begin_operator
stack b5 b6
0
4
0 4 -1 0
0 12 -1 0
0 3 0 1
0 10 0 5
0
end_operator
begin_operator
stack b6 b1
0
4
0 4 -1 0
0 0 0 1
0 3 -1 0
0 8 0 1
0
end_operator
begin_operator
stack b6 b2
0
4
0 4 -1 0
0 11 0 1
0 3 -1 0
0 8 0 2
0
end_operator
begin_operator
stack b




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




heck 0
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
30
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
41
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 5
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
21
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
26
check 0
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
31
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
check 1
36
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
check 0
check 0
end_SG
begin_DTG
11
1
17
1
9 0
1
22
1
6 0
1
27
1
7 0
1
32
1
10 0
1
37
1
8 0
1
0
2
4 0
5 6
1
42
2
4 0
5 1
1
43
2
4 0
5 2
1
44
2
4 0
5 3
1
45
2
4 0
5 4
1
46
2
4 0
5 5
6
0
6
1
5 0
0
47
3
4 0
11 0
9 1
0
52
3
4 0
1 0
6 1
0
57
3
4 0
2 0
7 1
0
62
3
4 0
12 0
10 1
0
67
3
4 0
3 0
8 1
end_DTG
begin_DTG
11
1
13
1
5 0
1
18
1
9 0
1
29
1
7 0
1
34
1
10 0
1
39
1
8 0
1
2
2
4 0
6 6
1
52
2
4 0
6 1
1
53
2
4 0
6 2
1
54
2
4 0
6 3
1
55
2
4 0
6 4
1
56
2
4 0
6 5
6
0
8
1
6 0
0
43
3
4 0
0 0
5 2
0
48
3
4 0
11 0
9 2
0
59
3
4 0
2 0
7 3
0
64
3
4 0
12 0
10 3
0
69
3
4 0
3 0
8 3
end_DTG
begin_DTG
11
1
14
1
5 0
1
19
1
9 0
1
24
1
6 0
1
35
1
10 0
1
40
1
8 0
1
3
2
4 0
7 6
1
57
2
4 0
7 1
1
58
2
4 0
7 2
1
59
2
4 0
7 3
1
60
2
4 0
7 4
1
61
2
4 0
7 5
6
0
9
1
7 0
0
44
3
4 0
0 0
5 3
0
49
3
4 0
11 0
9 3
0
54
3
4 0
1 0
6 3
0
65
3
4 0
12 0
10 4
0
70
3
4 0
3 0
8 4
end_DTG
begin_DTG
11
1
16
1
5 0
1
21
1
9 0
1
26
1
6 0
1
31
1
7 0
1
36
1
10 0
1
5
2
4 0
8 6
1
67
2
4 0
8 1
1
68
2
4 0
8 2
1
69
2
4 0
8 3
1
70
2
4 0
8 4
1
71
2
4 0
8 5
6
0
11
1
8 0
0
46
3
4 0
0 0
5 5
0
51
3
4 0
11 0
9 5
0
56
3
4 0
1 0
6 5
0
61
3
4 0
2 0
7 5
0
66
3
4 0
12 0
10 5
end_DTG
begin_DTG
36
1
63
2
12 0
10 2
1
55
2
1 0
6 4
1
56
2
1 0
6 5
1
57
2
2 0
7 1
1
58
2
2 0
7 2
1
59
2
2 0
7 3
1
60
2
2 0
7 4
1
61
2
2 0
7 5
1
62
2
12 0
10 1
1
54
2
1 0
6 3
1
64
2
12 0
10 3
1
65
2
12 0
10 4
1
66
2
12 0
10 5
1
67
2
3 0
8 1
1
68
2
3 0
8 2
1
69
2
3 0
8 3
1
70
2
3 0
8 4
1
71
2
3 0
8 5
1
45
2
0 0
5 4
1
1
2
11 0
9 6
1
2
2
1 0
6 6
1
3
2
2 0
7 6
1
4
2
12 0
10 6
1
5
2
3 0
8 6
1
42
2
0 0
5 1
1
43
2
0 0
5 2
1
44
2
0 0
5 3
1
0
2
0 0
5 6
1
46
2
0 0
5 5
1
47
2
11 0
9 1
1
48
2
11 0
9 2
1
49
2
11 0
9 3
1
50
2
11 0
9 4
1
51
2
11 0
9 5
1
52
2
1 0
6 1
1
53
2
1 0
6 2
6
0
7
1
9 0
0
8
1
6 0
0
9
1
7 0
0
10
1
10 0
0
11
1
8 0
0
6
1
5 0
end_DTG
begin_DTG
6
1
12
1
11 0
2
13
1
1 0
3
14
1
2 0
4
15
1
12 0
5
16
1
3 0
6
6
0
1
0
42
2
4 0
0 0
1
0
43
2
4 0
0 0
1
0
44
2
4 0
0 0
1
0
45
2
4 0
0 0
1
0
46
2
4 0
0 0
1
0
0
2
4 0
0 0
end_DTG
begin_DTG
6
1
22
1
0 0
2
23
1
11 0
3
24
1
2 0
4
25
1
12 0
5
26
1
3 0
6
8
0
1
0
52
2
4 0
1 0
1
0
53
2
4 0
1 0
1
0
54
2
4 0
1 0
1
0
55
2
4 0
1 0
1
0
56
2
4 0
1 0
1
0
2
2
4 0
1 0
end_DTG
begin_DTG
6
1
27
1
0 0
2
28
1
11 0
3
29
1
1 0
4
30
1
12 0
5
31
1
3 0
6
9
0
1
0
57
2
4 0
2 0
1
0
58
2
4 0
2 0
1
0
59
2
4 0
2 0
1
0
60
2
4 0
2 0
1
0
61
2
4 0
2 0
1
0
3
2
4 0
2 0
end_DTG
begin_DTG
6
1
37
1
0 0
2
38
1
11 0
3
39
1
1 0
4
40
1
2 0
5
41
1
12 0
6
11
0
1
0
67
2
4 0
3 0
1
0
68
2
4 0
3 0
1
0
69
2
4 0
3 0
1
0
70
2
4 0
3 0
1
0
71
2
4 0
3 0
1
0
5
2
4 0
3 0
end_DTG
begin_DTG
6
1
17
1
0 0
2
18
1
1 0
3
19
1
2 0
4
20
1
12 0
5
21
1
3 0
6
7
0
1
0
47
2
4 0
11 0
1
0
48
2
4 0
11 0
1
0
49
2
4 0
11 0
1
0
50
2
4 0
11 0
1
0
51
2
4 0
11 0
1
0
1
2
4 0
11 0
end_DTG
begin_DTG
6
1
32
1
0 0
2
33
1
11 0
3
34
1
1 0
4
35
1
2 0
5
36
1
3 0
6
10
0
1
0
62
2
4 0
12 0
1
0
63
2
4 0
12 0
1
0
64
2
4 0
12 0
1
0
65
2
4 0
12 0
1
0
66
2
4 0
12 0
1
0
4
2
4 0
12 0
end_DTG
begin_DTG
11
1
12
1
5 0
1
23
1
6 0
1
28
1
7 0
1
33
1
10 0
1
38
1
8 0
1
1
2
4 0
9 6
1
47
2
4 0
9 1
1
48
2
4 0
9 2
1
49
2
4 0
9 3
1
50
2
4 0
9 4
1
51
2
4 0
9 5
6
0
7
1
9 0
0
42
3
4 0
0 0
5 1
0
53
3
4 0
1 0
6 2
0
58
3
4 0
2 0
7 2
0
63
3
4 0
12 0
10 2
0
68
3
4 0
3 0
8 2
end_DTG
begin_DTG
11
1
15
1
5 0
1
20
1
9 0
1
25
1
6 0
1
30
1
7 0
1
41
1
8 0
1
4
2
4 0
10 6
1
62
2
4 0
10 1
1
63
2
4 0
10 2
1
64
2
4 0
10 3
1
65
2
4 0
10 4
1
66
2
4 0
10 5
6
0
10
1
10 0
0
45
3
4 0
0 0
5 4
0
50
3
4 0
11 0
9 4
0
55
3
4 0
1 0
6 4
0
60
3
4 0
2 0
7 4
0
71
3
4 0
3 0
8 5
end_DTG
begin_CG
12
4 11
11 2
1 2
2 2
12 2
3 2
5 6
9 1
6 1
7 1
10 1
8 1
12
4 11
0 2
11 2
2 2
12 2
3 2
5 1
9 1
6 6
7 1
10 1
8 1
12
4 11
0 2
11 2
1 2
12 2
3 2
5 1
9 1
6 1
7 6
10 1
8 1
12
4 11
0 2
11 2
1 2
2 2
12 2
5 1
9 1
6 1
7 1
10 1
8 6
12
0 11
11 11
1 11
2 11
12 11
3 11
5 6
9 6
6 6
7 6
10 6
8 6
7
4 12
0 12
11 2
1 2
2 2
12 2
3 2
7
4 12
0 2
11 2
1 12
2 2
12 2
3 2
7
4 12
0 2
11 2
1 2
2 12
12 2
3 2
7
4 12
0 2
11 2
1 2
2 2
12 2
3 12
7
4 12
0 2
11 12
1 2
2 2
12 2
3 2
7
4 12
0 2
11 2
1 2
2 2
12 12
3 2
12
4 11
0 2
1 2
2 2
12 2
3 2
5 1
9 6
6 1
7 1
10 1
8 1
12
4 11
0 2
11 2
1 2
2 2
3 2
5 1
9 1
6 1
7 1
10 6
8 1
end_CG
