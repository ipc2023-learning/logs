begin_version
3
end_version
begin_metric
0
end_metric
25
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var6
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var7
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var8
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var10
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var11
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var12
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var14
-1
13
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var15
-1
13
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var16
-1
13
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var17
-1
13
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var18
-1
13
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var19
-1
13
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var20
-1
13
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var22
-1
13
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var23
-1
13
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var24
-1
13
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var13
-1
13
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var21
-1
13
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var9
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
13
begin_mutex_group
13
10 0
21 0
11 0
12 0
13 0
14 0
15 0
16 0
17 0
22 0
18 0
19 0
20 0
end_mutex_group
begin_mutex_group
13
23 0
21 0
11 1
12 1
13 1
14 1
15 1
16 1
17 1
22 1
18 1
19 1
20 1
end_mutex_group
begin_mutex_group
13
0 0
11 0
21 1
12 2
13 2
14 2
15 2
16 2
17 2
22 2
18 2
19 2
20 2
end_mutex_group
begin_mutex_group
13
1 0
12 0
21 2
11 2
13 3
14 3
15 3
16 3
17 3
22 3
18 3
19 3
20 3
end_mutex_group
begin_mutex_group
13
2 0
13 0
21 3
11 3
12 3
14 4
15 4
16 4
17 4
22 4
18 4
19 4
20 4
end_mutex_group
begin_mutex_group
13
3 0
14 0
21 4
11 4
12 4
13 4
15 5
16 5
17 5
22 5
18 5
19 5
20 5
end_mutex_group
begin_mutex_group
13
4 0
15 0
21 5
11 5
12 5
13 5
14 5
16 6
17 6
22 6
18 6
19 6
20 6
end_mutex_group
begin_mutex_group
13
5 0
16 0
21 6
11 6
12 6
13 6
14 6
15 6
17 7
22 7
18 7
19 7
20 7
end_mutex_group
begin_mutex_group
13
6 0
17 0
21 7
11 7
12 7
13 7
14 7
15 7
16 7
22 8
18 8
19 8
20 8
end_mutex_group
begin_mutex_group
13
24 0
22 0
21 8
11 8
12 8
13 8
14 8
15 8
16 8
17 8
18 9
1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
7 0
end_DTG
begin_DTG
12
1
134
1
23 0
2
135
1
0 0
3
136
1
1 0
4
137
1
2 0
5
138
1
3 0
6
139
1
4 0
7
140
1
5 0
8
141
1
6 0
9
142
1
24 0
10
143
1
7 0
11
144
1
9 0
12
22
0
1
0
266
2
10 0
8 0
1
0
267
2
10 0
8 0
1
0
268
2
10 0
8 0
1
0
269
2
10 0
8 0
1
0
270
2
10 0
8 0
1
0
271
2
10 0
8 0
1
0
272
2
10 0
8 0
1
0
273
2
10 0
8 0
1
0
274
2
10 0
8 0
1
0
275
2
10 0
8 0
1
0
276
2
10 0
8 0
1
0
10
2
10 0
8 0
end_DTG
begin_DTG
12
1
145
1
23 0
2
146
1
0 0
3
147
1
1 0
4
148
1
2 0
5
149
1
3 0
6
150
1
4 0
7
151
1
5 0
8
152
1
6 0
9
153
1
24 0
10
154
1
7 0
11
155
1
8 0
12
23
0
1
0
277
2
10 0
9 0
1
0
278
2
10 0
9 0
1
0
279
2
10 0
9 0
1
0
280
2
10 0
9 0
1
0
281
2
10 0
9 0
1
0
282
2
10 0
9 0
1
0
283
2
10 0
9 0
1
0
284
2
10 0
9 0
1
0
285
2
10 0
9 0
1
0
286
2
10 0
9 0
1
0
287
2
10 0
9 0
1
0
11
2
10 0
9 0
end_DTG
begin_DTG
12
1
24
1
0 0
2
25
1
1 0
3
26
1
2 0
4
27
1
3 0
5
28
1
4 0
6
29
1
5 0
7
30
1
6 0
8
31
1
24 0
9
32
1
7 0
10
33
1
8 0
11
34
1
9 0
12
12
0
1
0
156
2
10 0
23 0
1
0
157
2
10 0
23 0
1
0
158
2
10 0
23 0
1
0
159
2
10 0
23 0
1
0
160
2
10 0
23 0
1
0
161
2
10 0
23 0
1
0
162
2
10 0
23 0
1
0
163
2
10 0
23 0
1
0
164
2
10 0
23 0
1
0
165
2
10 0
23 0
1
0
166
2
10 0
23 0
1
0
0
2
10 0
23 0
end_DTG
begin_DTG
12
1
112
1
23 0
2
113
1
0 0
3
114
1
1 0
4
115
1
2 0
5
116
1
3 0
6
117
1
4 0
7
118
1
5 0
8
119
1
6 0
9
120
1
7 0
10
121
1
8 0
11
122
1
9 0
12
20
0
1
0
244
2
10 0
24 0
1
0
245
2
10 0
24 0
1
0
246
2
10 0
24 0
1
0
247
2
10 0
24 0
1
0
248
2
10 0
24 0
1
0
249
2
10 0
24 0
1
0
250
2
10 0
24 0
1
0
251
2
10 0
24 0
1
0
252
2
10 0
24 0
1
0
253
2
10 0
24 0
1
0
254
2
10 0
24 0
1
0
8
2
10 0
24 0
end_DTG
begin_DTG
23
1
35
1
11 0
1
145
1
20 0
1
134
1
19 0
1
123
1
18 0
1
112
1
22 0
1
101
1
17 0
1
79
1
15 0
1
68
1
14 0
1
57
1
13 0
1
46
1
12 0
1
90
1
16 0
1
166
2
10 0
21 11
1
165
2
10 0
21 10
1
164
2
10 0
21 9
1
163
2
10 0
21 8
1
162
2
10 0
21 7
1
161
2
10 0
21 6
1
160
2
10 0
21 5
1
159
2
10 0
21 4
1
158
2
10 0
21 3
1
157
2
10 0
21 2
1
156
2
10 0
21 1
1
0
2
10 0
21 12
12
0
12
1
21 0
0
167
3
10 0
0 0
11 1
0
178
3
10 0
1 0
12 1
0
189
3
10 0
2 0
13 1
0
200
3
10 0
3 0
14 1
0
211
3
10 0
4 0
15 1
0
222
3
10 0
5 0
16 1
0
233
3
10 0
6 0
17 1
0
244
3
10 0
24 0
22 1
0
255
3
10 0
7 0
18 1
0
266
3
10 0
8 0
19 1
0
277
3
10 0
9 0
20 1
end_DTG
begin_DTG
23
1
31
1
21 0
1
153
1
20 0
1
142
1
19 0
1
131
1
18 0
1
108
1
17 0
1
97
1
16 0
1
75
1
14 0
1
64
1
13 0
1
53
1
12 0
1
42
1
11 0
1
86
1
15 0
1
254
2
10 0
22 11
1
253
2
10 0
22 10
1
252
2
10 0
22 9
1
251
2
10 0
22 8
1
250
2
10 0
22 7
1
249
2
10 0
22 6
1
248
2
10 0
22 5
1
247
2
10 0
22 4
1
246
2
10 0
22 3
1
245
2
10 0
22 2
1
244
2
10 0
22 1
1
8
2
10 0
22 12
12
0
20
1
22 0
0
163
3
10 0
23 0
21 8
0
174
3
10 0
0 0
11 8
0
185
3
10 0
1 0
12 8
0
196
3
10 0
2 0
13 8
0
207
3
10 0
3 0
14 8
0
218
3
10 0
4 0
15 8
0
229
3
10 0
5 0
16 8
0
240
3
10 0
6 0
17 8
0
263
3
10 0
7 0
18 9
0
274
3
10 0
8 0
19 9
0
285
3
10 0
9 0
20 9
end_DTG
begin_CG
24
10 23
23 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
21 1
11 12
12 1
13 1
14 1
15 1
16 1
17 1
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
21 1
11 1
12 12
13 1
14 1
15 1
16 1
17 1
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
1 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
21 1
11 1
12 1
13 12
14 1
15 1
16 1
17 1
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
1 2
2 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
21 1
11 1
12 1
13 1
14 12
15 1
16 1
17 1
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
1 2
2 2
3 2
5 2
6 2
24 2
7 2
8 2
9 2
21 1
11 1
12 1
13 1
14 1
15 12
16 1
17 1
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
1 2
2 2
3 2
4 2
6 2
24 2
7 2
8 2
9 2
21 1
11 1
12 1
13 1
14 1
15 1
16 12
17 1
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
1 2
2 2
3 2
4 2
5 2
24 2
7 2
8 2
9 2
21 1
11 1
12 1
13 1
14 1
15 1
16 1
17 12
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
8 2
9 2
21 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
22 1
18 12
19 1
20 1
24
10 23
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
9 2
21 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
22 1
18 1
19 12
20 1
24
10 23
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
21 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
22 1
18 1
19 1
20 12
24
23 23
0 23
1 23
2 23
3 23
4 23
5 23
6 23
24 23
7 23
8 23
9 23
21 12
11 12
12 12
13 12
14 12
15 12
16 12
17 12
22 12
18 12
19 12
20 12
13
10 24
23 2
0 24
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 24
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 2
2 24
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 2
2 2
3 24
4 2
5 2
6 2
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 2
2 2
3 2
4 24
5 2
6 2
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 2
2 2
3 2
4 2
5 24
6 2
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 24
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 24
8 2
9 2
13
10 24
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 24
9 2
13
10 24
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 24
13
10 24
23 24
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
13
10 24
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 24
7 2
8 2
9 2
24
10 23
0 2
1 2
2 2
3 2
4 2
5 2
6 2
24 2
7 2
8 2
9 2
21 12
11 1
12 1
13 1
14 1
15 1
16 1
17 1
22 1
18 1
19 1
20 1
24
10 23
23 2
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
21 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
22 12
18 1
19 1
20 1
end_CG
