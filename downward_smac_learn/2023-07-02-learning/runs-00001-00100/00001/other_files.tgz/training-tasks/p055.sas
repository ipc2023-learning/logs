begin_version
3
end_version
begin_metric
0
end_metric
33
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var11
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var13
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var15
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var16
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var17
-1
17
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var18
-1
17
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var19
-1
17
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var20
-1
17
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var21
-1
17
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b2)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var23
-1
17
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b2)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var24
-1
17
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b2)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
end_variable
begin_variable
var25
-1
17
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var27
-1
17
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b14)
Atom on(b4, b15)
Atom on(b4, b16)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var29
-1
17
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b15)
Atom on(b6, b16)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var31
-1
17
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b14)
Atom on(b8, b15)
Atom on(b8, b16)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var32
-1
17
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b14)
Atom on(b9, b15)
Atom on(b9, b16)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var22
-1
17
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




12 0
9 0
22 12
0
432
3
12 0
8 0
21 11
0
417
3
12 0
30 0
26 11
0
402
3
12 0
7 0
20 11
0
387
3
12 0
6 0
19 11
0
372
3
12 0
5 0
18 11
0
357
3
12 0
29 0
25 11
0
342
3
12 0
4 0
17 11
0
327
3
12 0
3 0
16 11
0
312
3
12 0
2 0
15 11
0
297
3
12 0
1 0
14 11
0
282
3
12 0
0 0
13 11
end_DTG
begin_DTG
31
1
44
1
13 0
1
270
1
24 0
1
255
1
23 0
1
224
1
22 0
1
209
1
27 0
1
194
1
21 0
1
179
1
26 0
1
164
1
20 0
1
134
1
18 0
1
119
1
25 0
1
104
1
17 0
1
89
1
16 0
1
74
1
15 0
1
59
1
14 0
1
149
1
19 0
1
481
2
12 0
28 15
1
480
2
12 0
28 14
1
479
2
12 0
28 13
1
478
2
12 0
28 12
1
477
2
12 0
28 11
1
476
2
12 0
28 10
1
475
2
12 0
28 9
1
474
2
12 0
28 8
1
473
2
12 0
28 7
1
472
2
12 0
28 6
1
471
2
12 0
28 5
1
470
2
12 0
28 4
1
469
2
12 0
28 3
1
468
2
12 0
28 2
1
467
2
12 0
28 1
1
13
2
12 0
28 16
16
0
29
1
28 0
0
510
3
12 0
11 0
24 14
0
495
3
12 0
10 0
23 14
0
464
3
12 0
9 0
22 13
0
449
3
12 0
31 0
27 13
0
434
3
12 0
8 0
21 13
0
419
3
12 0
30 0
26 13
0
404
3
12 0
7 0
20 13
0
389
3
12 0
6 0
19 13
0
374
3
12 0
5 0
18 13
0
359
3
12 0
29 0
25 13
0
344
3
12 0
4 0
17 13
0
329
3
12 0
3 0
16 13
0
314
3
12 0
2 0
15 13
0
299
3
12 0
1 0
14 13
0
284
3
12 0
0 0
13 13
end_DTG
begin_CG
32
12 31
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 16
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 16
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 16
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 16
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 16
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 16
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 16
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 16
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 16
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 16
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 16
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 16
32
0 31
1 31
2 31
3 31
4 31
29 31
5 31
6 31
7 31
30 31
8 31
31 31
9 31
32 31
10 31
11 31
13 16
14 16
15 16
16 16
17 16
25 16
18 16
19 16
20 16
26 16
21 16
27 16
22 16
28 16
23 16
24 16
17
12 32
0 32
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 32
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 32
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 32
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 32
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 32
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 32
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 32
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 32
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 32
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 32
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 32
17
12 32
0 2
1 2
2 2
3 2
4 2
29 32
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 32
8 2
31 2
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 32
9 2
32 2
10 2
11 2
17
12 32
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 32
10 2
11 2
32
12 31
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 16
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
8 2
31 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 16
21 1
27 1
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
9 2
32 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 16
22 1
28 1
23 1
24 1
32
12 31
0 2
1 2
2 2
3 2
4 2
29 2
5 2
6 2
7 2
30 2
8 2
31 2
9 2
10 2
11 2
13 1
14 1
15 1
16 1
17 1
25 1
18 1
19 1
20 1
26 1
21 1
27 1
22 1
28 16
23 1
24 1
end_CG
