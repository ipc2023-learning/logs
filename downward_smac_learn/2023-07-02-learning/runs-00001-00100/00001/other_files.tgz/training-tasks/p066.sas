begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var14
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var16
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var20
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var21
-1
21
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var22
-1
21
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var23
-1
21
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var24
-1
21
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var25
-1
21
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var27
-1
21
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var29
-1
21
Atom holding(b17)
Atom on(b17, b1)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b8)
Atom on(b17, b9)
Atom on-table(b17)
end_variable
begin_variable
var31
-1
21
Atom holding(b19)
Atom on(b19, b1)
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b12)
Atom on(b19, b13)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b18)
Atom on(b19, b2)
Atom on(b19, b20)
Atom on(b19, b3)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b8)
Atom on(b19, b9)
Atom on-table(b19)
end_variable
begin_variable
var32
-1
21
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var33
-1
21
Atom holding(b20)
Atom on(b20, b1)
Atom on(b20, b10)
Atom on(b20, b11)
Atom on(b20, b12)
Atom on(b20, b13)
Atom on(b20, b14)
Atom on(b20, b15)
Atom on(b20, b16)
Atom on(b20, b17)
Atom on(b20, b18)
Atom on(b20, b19)
Atom on(b20, b2)
Atom on(b20, b3)
Atom on(b20, b4)
Atom on(b20, b5)
Atom on(b20, b6)
Atom on(b2




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 20
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 20
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 20
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 20
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 20
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 20
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 20
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 20
40
0 39
1 39
2 39
3 39
4 39
34 39
5 39
35 39
6 39
36 39
7 39
8 39
9 39
10 39
37 39
11 39
38 39
39 39
40 39
12 39
14 20
15 20
16 20
17 20
18 20
27 20
19 20
28 20
20 20
29 20
21 20
22 20
23 20
24 20
30 20
25 20
31 20
32 20
33 20
26 20
21
13 40
0 40
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 40
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 40
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 40
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 40
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 40
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 40
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 40
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 40
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 40
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 40
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 40
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 40
21
13 40
0 2
1 2
2 2
3 2
4 2
34 40
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 40
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 40
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 40
11 2
38 2
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 40
39 2
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 40
40 2
12 2
21
13 40
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 40
12 2
40
13 39
0 2
1 2
2 2
3 2
4 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 20
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 20
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 20
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
11 2
38 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 20
25 1
31 1
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
39 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 20
32 1
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
40 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 20
33 1
26 1
40
13 39
0 2
1 2
2 2
3 2
4 2
34 2
5 2
35 2
6 2
36 2
7 2
8 2
9 2
10 2
37 2
11 2
38 2
39 2
12 2
14 1
15 1
16 1
17 1
18 1
27 1
19 1
28 1
20 1
29 1
21 1
22 1
23 1
24 1
30 1
25 1
31 1
32 1
33 20
26 1
end_CG
