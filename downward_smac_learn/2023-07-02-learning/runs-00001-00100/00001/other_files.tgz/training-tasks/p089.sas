begin_version
3
end_version
begin_metric
0
end_metric
53
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var17
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var18
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var20
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var21
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var22
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var23
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var24
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var25
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var26
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var27
-1
27
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var28
-1
27
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b25)
Atom on(b10, b26)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var29
-1
27
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b26)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var30
-1
27
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b25)
Atom on(b12, b26)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var31
-1
27
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b21)
Atom on(b13, b22)
Atom on(b13, b23)
Atom on(b13, b24)
Atom on(b13, b25)
Atom on(b13, b26)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var32
-1
27
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b26)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var33
-1
27
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
17 2
18 2
19 2
21 2
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
45 1
35 1
46 1
47 1
36 1
37 1
48 1
38 1
39 1
40 1
41 1
42 1
43 26
44 1
52
22 51
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
45 1
35 1
46 1
47 1
36 1
37 1
48 1
38 1
39 1
40 1
41 1
42 1
43 1
44 26
52
0 51
1 51
2 51
3 51
4 51
5 51
6 51
7 51
8 51
9 51
10 51
11 51
49 51
12 51
50 51
51 51
13 51
14 51
52 51
15 51
16 51
17 51
18 51
19 51
20 51
21 51
23 26
24 26
25 26
26 26
27 26
28 26
29 26
30 26
31 26
32 26
33 26
34 26
45 26
35 26
46 26
47 26
36 26
37 26
48 26
38 26
39 26
40 26
41 26
42 26
43 26
44 26
27
22 52
0 52
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 52
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 52
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 52
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 52
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 52
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 52
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 52
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 52
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 52
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 52
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 52
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 52
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 52
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 52
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 52
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 52
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 52
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 52
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 52
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 52
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 52
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 52
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 52
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 52
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
27
22 52
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
52 52
15 2
16 2
17 2
18 2
19 2
20 2
21 2
52
22 51
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
50 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
45 26
35 1
46 1
47 1
36 1
37 1
48 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
52
22 51
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
51 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
45 1
35 1
46 26
47 1
36 1
37 1
48 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
52
22 51
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
13 2
14 2
52 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
45 1
35 1
46 1
47 26
36 1
37 1
48 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
52
22 51
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
49 2
12 2
50 2
51 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
45 1
35 1
46 1
47 1
36 1
37 1
48 26
38 1
39 1
40 1
41 1
42 1
43 1
44 1
end_CG
