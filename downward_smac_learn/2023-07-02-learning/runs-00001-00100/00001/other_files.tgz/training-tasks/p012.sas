begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var6
-1
5
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on-table(b2)
end_variable
begin_variable
var8
-1
5
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on-table(b4)
end_variable
begin_variable
var5
-1
5
Atom holding(b1)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on-table(b1)
end_variable
begin_variable
var7
-1
5
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on-table(b3)
end_variable
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
5
begin_mutex_group
5
2 0
5 0
3 0
6 0
4 0
end_mutex_group
begin_mutex_group
5
7 0
5 0
3 1
6 1
4 1
end_mutex_group
begin_mutex_group
5
0 0
3 0
5 1
6 2
4 2
end_mutex_group
begin_mutex_group
5
8 0
6 0
5 2
3 2
4 3
end_mutex_group
begin_mutex_group
5
1 0
4 0
5 3
3 3
6 3
end_mutex_group
begin_state
0
1
0
1
4
2
3
1
1
end_state
begin_goal
6
3 4
4 4
5 1
6 3
7 0
8 0
end_goal
32
begin_operator
pickup b1
0
3
0 2 0 1
0 7 0 1
0 5 4 0
0
end_operator
begin_operator
pickup b2
0
3
0 2 0 1
0 0 0 1
0 3 4 0
0
end_operator
begin_operator
pickup b3
0
3
0 2 0 1
0 8 0 1
0 6 4 0
0
end_operator
begin_operator
pickup b4
0
3
0 2 0 1
0 1 0 1
0 4 4 0
0
end_operator
begin_operator
putdown b1
0
3
0 2 -1 0
0 7 -1 0
0 5 0 4
0
end_operator
begin_operator
putdown b2
0
3
0 2 -1 0
0 0 -1 0
0 3 0 4
0
end_operator
begin_operator
putdown b3
0
3
0 2 -1 0
0 8 -1 0
0 6 0 4
0
end_operator
begin_operator
putdown b4
0
3
0 2 -1 0
0 1 -1 0
0 4 0 4
0
end_operator
begin_operator
stack b1 b2
0
4
0 2 -1 0
0 7 -1 0
0 0 0 1
0 5 0 1
0
end_operator
begin_operator
stack b1 b3
0
4
0 2 -1 0
0 7 -1 0
0 8 0 1
0 5 0 2
0
end_operator
begin_operator
stack b1 b4
0
4
0 2 -1 0
0 7 -1 0
0 1 0 1
0 5 0 3
0
end_operator
begin_operator
stack b2 b1
0
4
0 2 -1 0
0 7 0 1
0 0 -1 0
0 3 0 1
0
end_operator
begin_operator
stack b2 b3
0
4
0 2 -1 0
0 0 -1 0
0 8 0 1
0 3 0 2
0
end_operator
begin_operator
stack b2 b4
0
4
0 2 -1 0
0 0 -1 0
0 1 0 1
0 3 0 3
0
end_operator
begin_operator
stack b3 b1
0
4
0 2 -1 0
0 7 0 1
0 8 -1 0
0 6 0 1
0
end_operator
begin_operator
stack b3 b2
0
4
0 2 -1 0
0 0 0 1
0 8 -1 0
0 6 0 2
0
end_operator
begin_operator
stack b3 b4
0
4
0 2 -1 0
0 8 -1 0
0 1 0 1
0 6 0 3
0
end_operator
begin_operator
stack b4 b1
0
4
0 2 -1 0
0 7 0 1
0 1 -1 0
0 4 0 1
0
end_operator
begin_operator
stack b4 b2
0
4
0 2 -1 0
0 0 0 1
0 1 -1 0
0 4 0 2
0
end_operator
begin_operator
stack b4 b3
0
4
0 2 -1 0
0 8 0 1
0 1 -1 0
0 4 0 3
0
end_operator
begin_operator
unstack b1 b2
0
4
0 2 0 1
0 7 0 1
0 0 -1 0
0 5 1 0
0
end_operator
begin_operator
unstack b1 b3
0
4
0 2 0 1
0 7 0 1
0 8 -1 0
0 5 2 0
0
end_operator
begin_operator
unstack b1 b4
0
4
0 2 0 1
0 7 0 1
0 1 -1 0
0 5 3 0
0
end_operator
begin_operator
unstack b2 b1
0
4
0 2 0 1
0 7 -1 0
0 0 0 1
0 3 1 0
0
end_operator
begin_operator
unstack b2 b3
0
4
0 2 0 1
0 0 0 1
0 8 -1 0
0 3 2 0
0
end_operator
begin_operator
unstack b2 b4
0
4
0 2 0 1
0 0 0 1
0 1 -1 0
0 3 3 0
0
end_operator
begin_operator
unstack b3 b1
0
4
0 2 0 1
0 7 -1 0
0 8 0 1
0 6 1 0
0
end_operator
begin_operator
unstack b3 b2
0
4
0 2 0 1
0 0 -1 0
0 8 0 1
0 6 2 0
0
end_operator
begin_operator
unstack b3 b4
0
4
0 2 0 1
0 8 0 1
0 1 -1 0
0 6 3 0
0
end_operator
begin_operator
unstack b4 b1
0
4
0 2 0 1
0 7 -1 0
0 1 0 1
0 4 1 0
0
end_operator
begin_operator
unstack b4 b2
0
4
0 2 0 1
0 0 -1 0
0 1 0 1
0 4 2 0
0
end_operator
begin_operator
unstack b4 b3
0
4
0 2 0 1
0 8 -1 0
0 1 0 1
0 4 3 0
0
end_operator
0
begin_SG
switch 2
check 0
switch 7
check 0
switch 5
check 0
check 0
check 1
20
check 1
21
check 1
22
check 1
0
check 0
check 0
switch 0
check 0
switch 3
check 0
check 0
check 1
23
check 1
24
check 1
25
check 1
1
check 0
check 0
switch 8
check 0
switch 6
check 0
check 0
check 1
26
check 1
27
check 1
28
check 1
2
check 0
check 0
switch 1
check 0
switch 4
check 0
check 0
check 1
29
check 1
30
check 1
31
check 1
3
check 0
check 0
check 0
check 0
switch 7
check 0
switch 3
check 0
check 1
11
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
14
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
17
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
switch 5
check 0
check 1
8
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
15
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
18
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
switch 5
check 0
check 1
9
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
12
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
19
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 5
check 0
check 1
10
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
13
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
4
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
5
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
6
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
end_SG
begin_DTG
7
1
8
1
5 0
1
15
1
6 0
1
18
1
4 0
1
1
2
2 0
3 4
1
23
2
2 0
3 1
1
24
2
2 0
3 2
1
25
2
2 0
3 3
4
0
5
1
3 0
0
20
3
2 0
7 0
5 1
0
27
3
2 0
8 0
6 2
0
30
3
2 0
1 0
4 2
end_DTG
begin_DTG
7
1
10
1
5 0
1
13
1
3 0
1
16
1
6 0
1
3
2
2 0
4 4
1
29
2
2 0
4 1
1
30
2
2 0
4 2
1
31
2
2 0
4 3
4
0
7
1
4 0
0
22
3
2 0
7 0
5 3
0
25
3
2 0
0 0
3 3
0
28
3
2 0
8 0
6 3
end_DTG
begin_DTG
16
1
0
2
7 0
5 4
1
1
2
0 0
3 4
1
2
2
8 0
6 4
1
3
2
1 0
4 4
1
20
2
7 0
5 1
1
21
2
7 0
5 2
1
22
2
7 0
5 3
1
23
2
0 0
3 1
1
24
2
0 0
3 2
1
25
2
0 0
3 3
1
26
2
8 0
6 1
1
27
2
8 0
6 2
1
28
2
8 0
6 3
1
29
2
1 0
4 1
1
30
2
1 0
4 2
1
31
2
1 0
4 3
4
0
4
1
5 0
0
5
1
3 0
0
6
1
6 0
0
7
1
4 0
end_DTG
begin_DTG
4
1
11
1
7 0
2
12
1
8 0
3
13
1
1 0
4
5
0
1
0
23
2
2 0
0 0
1
0
24
2
2 0
0 0
1
0
25
2
2 0
0 0
1
0
1
2
2 0
0 0
end_DTG
begin_DTG
4
1
17
1
7 0
2
18
1
0 0
3
19
1
8 0
4
7
0
1
0
29
2
2 0
1 0
1
0
30
2
2 0
1 0
1
0
31
2
2 0
1 0
1
0
3
2
2 0
1 0
end_DTG
begin_DTG
4
1
8
1
0 0
2
9
1
8 0
3
10
1
1 0
4
4
0
1
0
20
2
2 0
7 0
1
0
21
2
2 0
7 0
1
0
22
2
2 0
7 0
1
0
0
2
2 0
7 0
end_DTG
begin_DTG
4
1
14
1
7 0
2
15
1
0 0
3
16
1
1 0
4
6
0
1
0
26
2
2 0
8 0
1
0
27
2
2 0
8 0
1
0
28
2
2 0
8 0
1
0
2
2
2 0
8 0
end_DTG
begin_DTG
7
1
11
1
3 0
1
14
1
6 0
1
17
1
4 0
1
0
2
2 0
5 4
1
20
2
2 0
5 1
1
21
2
2 0
5 2
1
22
2
2 0
5 3
4
0
4
1
5 0
0
23
3
2 0
0 0
3 1
0
26
3
2 0
8 0
6 1
0
29
3
2 0
1 0
4 1
end_DTG
begin_DTG
7
1
9
1
5 0
1
12
1
3 0
1
19
1
4 0
1
2
2
2 0
6 4
1
26
2
2 0
6 1
1
27
2
2 0
6 2
1
28
2
2 0
6 3
4
0
6
1
6 0
0
21
3
2 0
7 0
5 2
0
24
3
2 0
0 0
3 2
0
31
3
2 0
1 0
4 3
end_DTG
begin_CG
8
2 7
7 2
8 2
1 2
5 1
3 4
6 1
4 1
8
2 7
7 2
0 2
8 2
5 1
3 1
6 1
4 4
8
7 7
0 7
8 7
1 7
5 4
3 4
6 4
4 4
5
2 8
7 2
0 8
8 2
1 2
5
2 8
7 2
0 2
8 2
1 8
5
2 8
7 8
0 2
8 2
1 2
5
2 8
7 2
0 2
8 8
1 2
8
2 7
0 2
8 2
1 2
5 4
3 1
6 1
4 1
8
2 7
7 2
0 2
1 2
5 1
3 1
6 4
4 1
end_CG
