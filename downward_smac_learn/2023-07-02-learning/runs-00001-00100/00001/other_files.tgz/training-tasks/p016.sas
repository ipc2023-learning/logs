begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var5
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var6
-1
6
Atom holding(b1)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on-table(b1)
end_variable
begin_variable
var8
-1
6
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on-table(b3)
end_variable
begin_variable
var9
-1
6
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on-table(b4)
end_variable
begin_variable
var10
-1
6
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on-table(b5)
end_variable
begin_variable
var7
-1
6
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on-table(b2)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
6
begin_mutex_group
6
4 0
5 0
9 0
6 0
7 0
8 0
end_mutex_group
begin_mutex_group
6
0 0
5 0
9 1
6 1
7 1
8 1
end_mutex_group
begin_mutex_group
6
10 0
9 0
5 1
6 2
7 2
8 2
end_mutex_group
begin_mutex_group
6
1 0
6 0
5 2
9 2
7 3
8 3
end_mutex_group
begin_mutex_group
6
2 0
7 0
5 3
9 3
6 3
8 4
end_mutex_group
begin_mutex_group
6
3 0
8 0
5 4
9 4
6 4
7 4
end_mutex_group
begin_state
1
1
1
1
0
5
1
3
4
4
0
end_state
begin_goal
6
5 2
6 3
7 4
8 5
9 1
10 0
end_goal
50
begin_operator
pickup b1
0
3
0 4 0 1
0 0 0 1
0 5 5 0
0
end_operator
begin_operator
pickup b2
0
3
0 4 0 1
0 10 0 1
0 9 5 0
0
end_operator
begin_operator
pickup b3
0
3
0 4 0 1
0 1 0 1
0 6 5 0
0
end_operator
begin_operator
pickup b4
0
3
0 4 0 1
0 2 0 1
0 7 5 0
0
end_operator
begin_operator
pickup b5
0
3
0 4 0 1
0 3 0 1
0 8 5 0
0
end_operator
begin_operator
putdown b1
0
3
0 4 -1 0
0 0 -1 0
0 5 0 5
0
end_operator
begin_operator
putdown b2
0
3
0 4 -1 0
0 10 -1 0
0 9 0 5
0
end_operator
begin_operator
putdown b3
0
3
0 4 -1 0
0 1 -1 0
0 6 0 5
0
end_operator
begin_operator
putdown b4
0
3
0 4 -1 0
0 2 -1 0
0 7 0 5
0
end_operator
begin_operator
putdown b5
0
3
0 4 -1 0
0 3 -1 0
0 8 0 5
0
end_operator
begin_operator
stack b1 b2
0
4
0 4 -1 0
0 0 -1 0
0 10 0 1
0 5 0 1
0
end_operator
begin_operator
stack b1 b3
0
4
0 4 -1 0
0 0 -1 0
0 1 0 1
0 5 0 2
0
end_operator
begin_operator
stack b1 b4
0
4
0 4 -1 0
0 0 -1 0
0 2 0 1
0 5 0 3
0
end_operator
begin_operator
stack b1 b5
0
4
0 4 -1 0
0 0 -1 0
0 3 0 1
0 5 0 4
0
end_operator
begin_operator
stack b2 b1
0
4
0 4 -1 0
0 0 0 1
0 10 -1 0
0 9 0 1
0
end_operator
begin_operator
stack b2 b3
0
4
0 4 -1 0
0 10 -1 0
0 1 0 1
0 9 0 2
0
end_operator
begin_operator
stack b2 b4
0
4
0 4 -1 0
0 10 -1 0
0 2 0 1
0 9 0 3
0
end_operator
begin_operator
stack b2 b5
0
4
0 4 -1 0
0 10 -1 0
0 3 0 1
0 9 0 4
0
end_operator
begin_operator
stack b3 b1
0
4
0 4 -1 0
0 0 0 1
0 1 -1 0
0 6 0 1
0
end_operator
begin_operator
stack b3 b2
0
4
0 4 -1 0
0 10 0 1
0 1 -1 0
0 6 0 2
0
end_operator
begin_operator
stack b3 b4
0
4
0 4 -1 0
0 1 -1 0
0 2 0 1
0 6 0 3
0
end_operator
begin_operator
stack b3 b5
0
4
0 4 -1 0
0 1 -1 0
0 3 0 1
0 6 0 4
0
end_operator
begin_operator
stack b4 b1
0
4
0 4 -1 0
0 0 0 1
0 2 -1 0
0 7 0 1
0
end_operator
begin_operator
stack b4 b2
0
4
0 4 -1 0
0 10 0 1
0 2 -1 0
0 7 0 2
0
end_operator
begin_operator
stack b4 b3
0
4
0 4 -1 0
0 1 0 1
0 2 -1 0
0 7 0 3
0
end_operator
begin_operator
stack b4 b5
0
4
0 4 -1 0
0 2 -1 0
0 3 0 1
0 7 0 4
0
end_operator
begin_operator
stack b5 b1
0
4
0 4 -1 0
0 0 0 1
0 3 -1 0
0 8 0 1
0
end_operator
begin_operator
stack b5 b2
0
4
0 4 -1 0
0 10 0 1
0 3 -1 0
0 8 0 2
0
end_operator
begin_operator
stack b5 b3
0
4
0 4 -1 0
0 1 0 1
0 3 -1 0
0 8 0 3
0
end_operator
begin_operator
stack b5 b4
0
4
0 4 -1 0
0 2 0 1
0 3 -1 0
0 8 0 4
0
end_operator
begin_operator
unstack b1 b2
0
4
0 4 0 1
0 0 0 1
0 10 -1 0
0 5 1 0
0
end_operator
begin_operator
unstack b1 b3
0
4
0 4 0 1
0 0 0 1
0 1 -1 0
0 5 2 0
0
end_operator
begin_operator
unstack b1 b4
0
4
0 4 0 1
0 0 0 1
0 2 -1 0
0 5 3 0
0
end_operator
begin_operator
unstack b1 b5
0
4
0 4 0 1
0 0 0 1
0 3 -1 0
0 5 4 0
0
end_operator
begin_operator
unstack b2 b1
0
4
0 4 0 1
0 0 -1 0
0 10 0 1
0 9 1 0
0
end_operator
begin_operator
unstack b2 b3
0
4
0 4 0 1
0 10 0 1
0 1 -1 0
0 9 2 0
0
end_operator
begin_operator
unstack b2 b4
0
4
0 4 0 1
0 10 0 1
0 2 -1 0
0 9 3 0
0
end_operator
begin_operator
unstack b2 b5
0
4
0 4 0 1
0 10 0 1
0 3 -1 0
0 9 4 0
0
end_operator
begin_operator
unstack b3 b1
0
4
0 4 0 1
0 0 -1 0
0 1 0 1
0 6 1 0
0
end_operator
begin_operator
unstack b3 b2
0
4
0 4 0 1
0 10 -1 0
0 1 0 1
0 6 2 0
0
end_operator
begin_operator
unstack b3 b4
0
4
0 4 0 1
0 1 0 1
0 2 -1 0
0 6 3 0
0
end_operator
begin_operator
unstack b3 b5
0
4
0 4 0 1
0 1 0 1
0 3 -1 0
0 6 4 0
0
end_operator
begin_operator
unstack b4 b1
0
4
0 4 0 1
0 0 -1 0
0 2 0 1
0 7 1 0
0
end_operator
begin_operator
unstack b4 b2
0
4
0 4 0 1
0 10 -1 0
0 2 0 1
0 7 2 0
0
end_operator
begin_operator
unsta




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 10
check 0
switch 9
check 0
check 0
check 1
34
check 1
35
check 1
36
check 1
37
check 1
1
check 0
check 0
switch 1
check 0
switch 6
check 0
check 0
check 1
38
check 1
39
check 1
40
check 1
41
check 1
2
check 0
check 0
switch 2
check 0
switch 7
check 0
check 0
check 1
42
check 1
43
check 1
44
check 1
45
check 1
3
check 0
check 0
switch 3
check 0
switch 8
check 0
check 0
check 1
46
check 1
47
check 1
48
check 1
49
check 1
4
check 0
check 0
check 0
check 0
switch 0
check 0
switch 9
check 0
check 1
14
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
18
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
22
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
26
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 10
check 0
switch 5
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
19
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
27
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 5
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
15
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
24
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
28
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 5
check 0
check 1
12
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
20
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
29
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 5
check 0
check 1
13
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
17
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
21
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
25
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
switch 7
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
check 0
end_SG
begin_DTG
9
1
14
1
9 0
1
18
1
6 0
1
22
1
7 0
1
26
1
8 0
1
0
2
4 0
5 5
1
30
2
4 0
5 1
1
31
2
4 0
5 2
1
32
2
4 0
5 3
1
33
2
4 0
5 4
5
0
5
1
5 0
0
34
3
4 0
10 0
9 1
0
38
3
4 0
1 0
6 1
0
42
3
4 0
2 0
7 1
0
46
3
4 0
3 0
8 1
end_DTG
begin_DTG
9
1
11
1
5 0
1
15
1
9 0
1
24
1
7 0
1
28
1
8 0
1
2
2
4 0
6 5
1
38
2
4 0
6 1
1
39
2
4 0
6 2
1
40
2
4 0
6 3
1
41
2
4 0
6 4
5
0
7
1
6 0
0
31
3
4 0
0 0
5 2
0
35
3
4 0
10 0
9 2
0
44
3
4 0
2 0
7 3
0
48
3
4 0
3 0
8 3
end_DTG
begin_DTG
9
1
12
1
5 0
1
16
1
9 0
1
20
1
6 0
1
29
1
8 0
1
3
2
4 0
7 5
1
42
2
4 0
7 1
1
43
2
4 0
7 2
1
44
2
4 0
7 3
1
45
2
4 0
7 4
5
0
8
1
7 0
0
32
3
4 0
0 0
5 3
0
36
3
4 0
10 0
9 3
0
40
3
4 0
1 0
6 3
0
49
3
4 0
3 0
8 4
end_DTG
begin_DTG
9
1
13
1
5 0
1
17
1
9 0
1
21
1
6 0
1
25
1
7 0
1
4
2
4 0
8 5
1
46
2
4 0
8 1
1
47
2
4 0
8 2
1
48
2
4 0
8 3
1
49
2
4 0
8 4
5
0
9
1
8 0
0
33
3
4 0
0 0
5 4
0
37
3
4 0
10 0
9 4
0
41
3
4 0
1 0
6 4
0
45
3
4 0
2 0
7 4
end_DTG
begin_DTG
25
1
37
2
10 0
9 4
1
49
2
3 0
8 4
1
48
2
3 0
8 3
1
47
2
3 0
8 2
1
46
2
3 0
8 1
1
45
2
2 0
7 4
1
44
2
2 0
7 3
1
43
2
2 0
7 2
1
42
2
2 0
7 1
1
41
2
1 0
6 4
1
40
2
1 0
6 3
1
39
2
1 0
6 2
1
38
2
1 0
6 1
1
0
2
0 0
5 5
1
36
2
10 0
9 3
1
35
2
10 0
9 2
1
34
2
10 0
9 1
1
33
2
0 0
5 4
1
32
2
0 0
5 3
1
31
2
0 0
5 2
1
30
2
0 0
5 1
1
4
2
3 0
8 5
1
3
2
2 0
7 5
1
2
2
1 0
6 5
1
1
2
10 0
9 5
5
0
6
1
9 0
0
7
1
6 0
0
8
1
7 0
0
9
1
8 0
0
5
1
5 0
end_DTG
begin_DTG
5
1
10
1
10 0
2
11
1
1 0
3
12
1
2 0
4
13
1
3 0
5
5
0
1
0
30
2
4 0
0 0
1
0
31
2
4 0
0 0
1
0
32
2
4 0
0 0
1
0
33
2
4 0
0 0
1
0
0
2
4 0
0 0
end_DTG
begin_DTG
5
1
18
1
0 0
2
19
1
10 0
3
20
1
2 0
4
21
1
3 0
5
7
0
1
0
38
2
4 0
1 0
1
0
39
2
4 0
1 0
1
0
40
2
4 0
1 0
1
0
41
2
4 0
1 0
1
0
2
2
4 0
1 0
end_DTG
begin_DTG
5
1
22
1
0 0
2
23
1
10 0
3
24
1
1 0
4
25
1
3 0
5
8
0
1
0
42
2
4 0
2 0
1
0
43
2
4 0
2 0
1
0
44
2
4 0
2 0
1
0
45
2
4 0
2 0
1
0
3
2
4 0
2 0
end_DTG
begin_DTG
5
1
26
1
0 0
2
27
1
10 0
3
28
1
1 0
4
29
1
2 0
5
9
0
1
0
46
2
4 0
3 0
1
0
47
2
4 0
3 0
1
0
48
2
4 0
3 0
1
0
49
2
4 0
3 0
1
0
4
2
4 0
3 0
end_DTG
begin_DTG
5
1
14
1
0 0
2
15
1
1 0
3
16
1
2 0
4
17
1
3 0
5
6
0
1
0
34
2
4 0
10 0
1
0
35
2
4 0
10 0
1
0
36
2
4 0
10 0
1
0
37
2
4 0
10 0
1
0
1
2
4 0
10 0
end_DTG
begin_DTG
9
1
10
1
5 0
1
19
1
6 0
1
23
1
7 0
1
27
1
8 0
1
1
2
4 0
9 5
1
34
2
4 0
9 1
1
35
2
4 0
9 2
1
36
2
4 0
9 3
1
37
2
4 0
9 4
5
0
6
1
9 0
0
30
3
4 0
0 0
5 1
0
39
3
4 0
1 0
6 2
0
43
3
4 0
2 0
7 2
0
47
3
4 0
3 0
8 2
end_DTG
begin_CG
10
4 9
10 2
1 2
2 2
3 2
5 5
9 1
6 1
7 1
8 1
10
4 9
0 2
10 2
2 2
3 2
5 1
9 1
6 5
7 1
8 1
10
4 9
0 2
10 2
1 2
3 2
5 1
9 1
6 1
7 5
8 1
10
4 9
0 2
10 2
1 2
2 2
5 1
9 1
6 1
7 1
8 5
10
0 9
10 9
1 9
2 9
3 9
5 5
9 5
6 5
7 5
8 5
6
4 10
0 10
10 2
1 2
2 2
3 2
6
4 10
0 2
10 2
1 10
2 2
3 2
6
4 10
0 2
10 2
1 2
2 10
3 2
6
4 10
0 2
10 2
1 2
2 2
3 10
6
4 10
0 2
10 10
1 2
2 2
3 2
10
4 9
0 2
1 2
2 2
3 2
5 1
9 5
6 1
7 1
8 1
end_CG
