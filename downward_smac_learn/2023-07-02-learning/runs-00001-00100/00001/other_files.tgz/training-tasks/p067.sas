begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var15
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var16
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var17
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var18
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var19
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var20
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var21
-1
21
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var22
-1
21
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var23
-1
21
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var24
-1
21
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var25
-1
21
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var26
-1
21
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var27
-1
21
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var28
-1
21
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
end_variable
begin_variable
var30
-1
21
Atom holding(b18)
Atom on(b18, b1)
Atom on(b18, b10)
Atom on(b18, b11)
Atom on(b18, b12)
Atom on(b18, b13)
Atom on(b18, b14)
Atom on(b18, b15)
Atom on(b18, b16)
Atom on(b18, b17)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b20)
Atom on(b18, b3)
Atom on(b18, b4)
Atom on(b18, b5)
Atom on(b18, b6)
Atom on(b18, b7)
Atom on(b18, b8)
Atom on(b18, b9)
Atom on-table(b18)
end_variable
begin_variab




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 20
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 20
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 20
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 20
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 20
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 20
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 20
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 20
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 20
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 20
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 20
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 20
40
0 39
1 39
2 39
3 39
4 39
5 39
6 39
7 39
38 39
8 39
39 39
9 39
10 39
40 39
11 39
12 39
13 39
14 39
15 39
16 39
18 20
19 20
20 20
21 20
22 20
23 20
24 20
25 20
35 20
26 20
36 20
27 20
28 20
37 20
29 20
30 20
31 20
32 20
33 20
34 20
21
17 40
0 40
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 40
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 40
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 40
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 40
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 40
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 40
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 40
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 40
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 40
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 40
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 40
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 40
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 40
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 40
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 40
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 40
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 40
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 40
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
21
17 40
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
40 40
11 2
12 2
13 2
14 2
15 2
16 2
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
39 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 20
26 1
36 1
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
9 2
10 2
40 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 20
27 1
28 1
37 1
29 1
30 1
31 1
32 1
33 1
34 1
40
17 39
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
38 2
8 2
39 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
35 1
26 1
36 1
27 1
28 1
37 20
29 1
30 1
31 1
32 1
33 1
34 1
end_CG
