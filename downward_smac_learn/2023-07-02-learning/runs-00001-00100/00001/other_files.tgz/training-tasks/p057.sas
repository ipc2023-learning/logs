begin_version
3
end_version
begin_metric
0
end_metric
35
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var11
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var12
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var13
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var14
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var15
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var16
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var17
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var18
-1
18
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var19
-1
18
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var20
-1
18
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var23
-1
18
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b2)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var24
-1
18
Atom holding(b15)
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b2)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
end_variable
begin_variable
var25
-1
18
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b2)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
end_variable
begin_variable
var26
-1
18
Atom holding(b17)
Atom on(b17, b1)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b2)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b8)
Atom on(b17, b9)
Atom on-table(b17)
end_variable
begin_variable
var27
-1
18
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var28
-1
18
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b14)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b17)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var29
-1
18
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b14)
Atom on(b4, b15)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var30
-1
18
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b14)
Atom on(b5, b15)
Atom on(b5, b16)
Atom on(b5, b17)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_va




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




15 0
32 14
1
382
2
15 0
32 13
1
381
2
15 0
32 12
1
380
2
15 0
32 11
1
379
2
15 0
32 10
1
378
2
15 0
32 9
1
377
2
15 0
32 8
1
376
2
15 0
32 7
1
375
2
15 0
32 6
1
374
2
15 0
32 5
1
373
2
15 0
32 4
1
372
2
15 0
32 3
1
371
2
15 0
32 2
1
370
2
15 0
32 1
1
4
2
15 0
32 17
17
0
21
1
32 0
0
566
3
15 0
14 0
30 5
0
550
3
15 0
13 0
29 5
0
534
3
15 0
12 0
28 5
0
518
3
15 0
11 0
27 5
0
502
3
15 0
10 0
26 5
0
486
3
15 0
9 0
25 5
0
470
3
15 0
8 0
24 5
0
454
3
15 0
7 0
23 5
0
438
3
15 0
6 0
22 5
0
422
3
15 0
5 0
21 5
0
406
3
15 0
4 0
20 5
0
390
3
15 0
3 0
19 5
0
357
3
15 0
33 0
31 4
0
341
3
15 0
2 0
18 4
0
325
3
15 0
1 0
17 4
0
309
3
15 0
0 0
16 4
end_DTG
begin_CG
34
15 33
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 17
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 17
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 17
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 17
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 17
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 17
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 17
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 17
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 17
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 17
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 17
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 17
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
13 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 17
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
14 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 17
30 1
34
15 33
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
16 1
17 1
18 1
31 1
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 17
34
0 33
1 33
2 33
33 33
34 33
3 33
4 33
5 33
6 33
7 33
8 33
9 33
10 33
11 33
12 33
13 33
14 33
16 17
17 17
18 17
31 17
32 17
19 17
20 17
21 17
22 17
23 17
24 17
25 17
26 17
27 17
28 17
29 17
30 17
18
15 34
0 34
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 34
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 34
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 34
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 34
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 34
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 34
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 34
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 34
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 34
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 34
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 34
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 34
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 34
14 2
18
15 34
0 2
1 2
2 2
33 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 34
18
15 34
0 2
1 2
2 2
33 34
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
18
15 34
0 2
1 2
2 2
33 2
34 34
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
34
15 33
0 2
1 2
2 2
34 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 17
32 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
34
15 33
0 2
1 2
2 2
33 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
16 1
17 1
18 1
31 1
32 17
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
end_CG
