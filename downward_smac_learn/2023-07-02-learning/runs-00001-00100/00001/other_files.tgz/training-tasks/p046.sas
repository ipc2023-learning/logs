begin_version
3
end_version
begin_metric
0
end_metric
29
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var7
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var8
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var9
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var10
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var14
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var15
-1
15
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var16
-1
15
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var17
-1
15
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var18
-1
15
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b2)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var19
-1
15
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b2)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var20
-1
15
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b2)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var21
-1
15
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var22
-1
15
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b14)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var23
-1
15
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b14)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var24
-1
15
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b14)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var28
-1
15
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b14)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var25
-1
15
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var26
-1
15
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var27
-1
15
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b14)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var11
-1
2
Atom clear(b6)
Nega




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 12
1
350
2
11 0
23 11
1
349
2
11 0
23 10
1
348
2
11 0
23 9
1
347
2
11 0
23 8
1
346
2
11 0
23 7
1
345
2
11 0
23 6
1
344
2
11 0
23 5
1
343
2
11 0
23 4
1
342
2
11 0
23 3
1
341
2
11 0
23 2
1
340
2
11 0
23 1
1
10
2
11 0
23 14
14
0
24
1
23 0
0
389
3
11 0
10 0
22 11
0
376
3
11 0
28 0
25 11
0
363
3
11 0
27 0
24 11
0
336
3
11 0
9 0
21 10
0
323
3
11 0
8 0
20 10
0
310
3
11 0
7 0
19 10
0
297
3
11 0
6 0
18 10
0
284
3
11 0
5 0
17 10
0
271
3
11 0
4 0
16 10
0
258
3
11 0
3 0
15 10
0
245
3
11 0
2 0
14 10
0
232
3
11 0
1 0
13 10
0
219
3
11 0
0 0
12 10
end_DTG
begin_DTG
27
1
38
1
12 0
1
208
1
22 0
1
195
1
25 0
1
168
1
23 0
1
155
1
21 0
1
142
1
20 0
1
129
1
19 0
1
103
1
17 0
1
90
1
16 0
1
77
1
15 0
1
64
1
14 0
1
51
1
13 0
1
116
1
18 0
1
365
2
11 0
24 13
1
364
2
11 0
24 12
1
363
2
11 0
24 11
1
362
2
11 0
24 10
1
361
2
11 0
24 9
1
360
2
11 0
24 8
1
359
2
11 0
24 7
1
358
2
11 0
24 6
1
357
2
11 0
24 5
1
356
2
11 0
24 4
1
355
2
11 0
24 3
1
354
2
11 0
24 2
1
353
2
11 0
24 1
1
11
2
11 0
24 14
14
0
25
1
24 0
0
390
3
11 0
10 0
22 12
0
377
3
11 0
28 0
25 12
0
350
3
11 0
26 0
23 11
0
337
3
11 0
9 0
21 11
0
324
3
11 0
8 0
20 11
0
311
3
11 0
7 0
19 11
0
298
3
11 0
6 0
18 11
0
285
3
11 0
5 0
17 11
0
272
3
11 0
4 0
16 11
0
259
3
11 0
3 0
15 11
0
246
3
11 0
2 0
14 11
0
233
3
11 0
1 0
13 11
0
220
3
11 0
0 0
12 11
end_DTG
begin_DTG
27
1
39
1
12 0
1
209
1
22 0
1
182
1
24 0
1
169
1
23 0
1
156
1
21 0
1
143
1
20 0
1
130
1
19 0
1
104
1
17 0
1
91
1
16 0
1
78
1
15 0
1
65
1
14 0
1
52
1
13 0
1
117
1
18 0
1
378
2
11 0
25 13
1
377
2
11 0
25 12
1
376
2
11 0
25 11
1
375
2
11 0
25 10
1
374
2
11 0
25 9
1
373
2
11 0
25 8
1
372
2
11 0
25 7
1
371
2
11 0
25 6
1
370
2
11 0
25 5
1
369
2
11 0
25 4
1
368
2
11 0
25 3
1
367
2
11 0
25 2
1
366
2
11 0
25 1
1
12
2
11 0
25 14
14
0
26
1
25 0
0
391
3
11 0
10 0
22 13
0
364
3
11 0
27 0
24 12
0
351
3
11 0
26 0
23 12
0
338
3
11 0
9 0
21 12
0
325
3
11 0
8 0
20 12
0
312
3
11 0
7 0
19 12
0
299
3
11 0
6 0
18 12
0
286
3
11 0
5 0
17 12
0
273
3
11 0
4 0
16 12
0
260
3
11 0
3 0
15 12
0
247
3
11 0
2 0
14 12
0
234
3
11 0
1 0
13 12
0
221
3
11 0
0 0
12 12
end_DTG
begin_CG
28
11 27
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
12 14
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
12 1
13 14
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
12 1
13 1
14 14
15 1
16 1
17 1
18 1
19 1
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
12 1
13 1
14 1
15 14
16 1
17 1
18 1
19 1
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
12 1
13 1
14 1
15 1
16 14
17 1
18 1
19 1
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
12 1
13 1
14 1
15 1
16 1
17 14
18 1
19 1
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
12 1
13 1
14 1
15 1
16 1
17 1
18 14
19 1
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
6 2
8 2
9 2
26 2
27 2
28 2
10 2
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 14
20 1
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
9 2
26 2
27 2
28 2
10 2
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 14
21 1
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
26 2
27 2
28 2
10 2
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 14
23 1
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
23 1
24 1
25 1
22 14
28
0 27
1 27
2 27
3 27
4 27
5 27
6 27
7 27
8 27
9 27
26 27
27 27
28 27
10 27
12 14
13 14
14 14
15 14
16 14
17 14
18 14
19 14
20 14
21 14
23 14
24 14
25 14
22 14
15
11 28
0 28
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 28
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 28
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 28
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 28
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 28
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 28
7 2
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 28
8 2
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 28
9 2
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 28
26 2
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 2
10 28
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 28
27 2
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 28
28 2
10 2
15
11 28
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
28 28
10 2
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
27 2
28 2
10 2
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
23 14
24 1
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
28 2
10 2
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
23 1
24 14
25 1
22 1
28
11 27
0 2
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
26 2
27 2
10 2
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
23 1
24 1
25 14
22 1
end_CG
