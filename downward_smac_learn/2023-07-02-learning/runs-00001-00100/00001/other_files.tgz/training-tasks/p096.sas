begin_version
3
end_version
begin_metric
0
end_metric
57
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var6
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var13
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var16
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var17
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var18
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var19
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var20
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var21
-1
2
Atom clear(b28)
NegatedAtom clear(b28)
end_variable
begin_variable
var22
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var23
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var24
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var26
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var27
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var28
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var29
-1
29
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b27)
Atom on(b1, b28)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var30
-1
29
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b25)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b28)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var31
-1
29
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b26)
Atom on(b11, b27)
Atom on(b11, b28)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var34
-1
29
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b26)
Atom on(b14, b27)
Atom on(b14, b28)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
end_variable
begin_variable
var36
-1
29
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b24)
Atom on(b16, b25)
Atom on(b16, b26)
Atom on(b16, b27)
Atom on(b16, b28)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
end_variable
begin_variable
var37
-1
29
Atom holding(b17)
Atom on(b17, b1)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b21)
Atom on(b17, b22)
Atom on(b17, b23)
Atom on(b17, b24)
Atom on(b17, b25)
Atom on(b17, b26)
Atom on(b17, b27)
Atom on(b17, b28)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 56
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 56
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 56
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 56
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 56
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 56
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 56
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 56
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 56
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 56
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 56
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 56
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 56
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 56
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 56
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 56
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 56
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 56
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 56
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 56
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 56
29
23 56
0 2
1 2
2 2
52 56
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 56
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 56
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 56
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
29
23 56
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 56
20 2
21 2
22 2
56
23 55
0 2
1 2
2 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
24 1
25 1
26 1
47 28
48 1
27 1
49 1
28 1
29 1
30 1
31 1
50 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
51 1
44 1
45 1
46 1
56
23 55
0 2
1 2
2 2
52 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
24 1
25 1
26 1
47 1
48 28
27 1
49 1
28 1
29 1
30 1
31 1
50 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
51 1
44 1
45 1
46 1
56
23 55
0 2
1 2
2 2
52 2
53 2
3 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
24 1
25 1
26 1
47 1
48 1
27 1
49 28
28 1
29 1
30 1
31 1
50 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
51 1
44 1
45 1
46 1
56
23 55
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
56 2
20 2
21 2
22 2
24 1
25 1
26 1
47 1
48 1
27 1
49 1
28 1
29 1
30 1
31 1
50 28
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
51 1
44 1
45 1
46 1
56
23 55
0 2
1 2
2 2
52 2
53 2
3 2
54 2
4 2
5 2
6 2
7 2
55 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
22 2
24 1
25 1
26 1
47 1
48 1
27 1
49 1
28 1
29 1
30 1
31 1
50 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
51 28
44 1
45 1
46 1
end_CG
