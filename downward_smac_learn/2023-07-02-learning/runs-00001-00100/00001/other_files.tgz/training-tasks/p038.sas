begin_version
3
end_version
begin_metric
0
end_metric
23
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var4
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var5
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var6
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var8
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var9
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var10
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var11
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var12
-1
12
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var13
-1
12
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b2)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var15
-1
12
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var16
-1
12
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var17
-1
12
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var19
-1
12
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var20
-1
12
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var21
-1
12
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var22
-1
12
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var14
-1
12
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b2)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var18
-1
12
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var3
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var7
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
12
begin_mutex_group
12
9 0
10 0
11 0
19 0
12 0
13 0
14 0
20 0
15 0
16 0
17 0
18 0
end_mutex_group
begin_mutex_group
12
0 0
10 0
11 1
19 1
12 1
13 1
14 1
20 1
15 1
16 1
17 1
18 1
end_mutex_group
begin_mutex_group
12
1 0
11 0
10 1
19 2
12 2
13 2
14 2
20 2
15 2
16 2
17 2
18 2
end_mutex_group
begin_mutex_group
12
21 0
19 0
10 2
11 2
12 3
13 3
14 3
20 3
15 3
16 3
17 3
18 3
end_mutex_group
begin_mutex_group
12
2 0
12 0
10 3
11 3
19 3
13 4
14 4
20 4
15 4
16 4
17 4
18 4
end_mutex_group
begin_mutex_group
12
3 0
13 0
10 4
11 4
19 4
12 4
14 5
20 5
15 5
16 5
17 5
18 5
end_mutex_group
begin_mutex_group
12
4 0
14 0
10 5
11 5
19 5
12 5
13 5
20 6
15 6
16 6
17 6
18 6
end_mutex_group
begin_mutex_group
12
22 0
20 0
10 6
11 6
19 6
12 6
13 6
14 6
15 7
16 7
17 7
18 7
end_mutex_group
begin_mutex_group
12
5 0
15 0
10 7
11 7
19 7
12 7
13 7
14 7
20 7
16 8
17 8
18 8
end_mutex_group
begin_mutex_group
12
6 0
16 0
10 8
11 8
19 8
12 8
13 8
14 8
20 8
15 8
17 9
18 9
end_mutex_group
begin_mutex_group
12
7 0
17 0
10 9
11 9
19 9
12 9
13 9
14 9
20 9
15 9
16 9
18 10
end_mutex_group
begin_mutex_group
12
8 0
18 0
10 10
11 10
19 10
12 10
13 10
14 10
20 10
15 10
16 10
17 10
end_mutex_group
begin_state
0
1
1
1
1
1
0
1
1
0
3
6
4
7
2
10
11
6
3
9
11
1
1
end_state
begin_goal
13
10 7
11 1
12 11
13 4
14 9
15 8
16 10
17 2
18 5
19 5
20 11
21 0
22 0
end_goal
242
begin_operator
pickup b1
0
3
0 9 0 1
0 0 0 1
0 10 11 0
0
end_operator
begin_operator
pickup b10
0
3
0 9 0 1
0 1 0 1
0 11 11 0
0
end_operator
begin_operator
pickup b11
0
3
0 9 0 1
0 21 0 1
0 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
4 0
end_DTG
begin_DTG
11
1
92
1
0 0
2
93
1
1 0
3
94
1
21 0
4
95
1
2 0
5
96
1
3 0
6
97
1
4 0
7
98
1
22 0
8
99
1
6 0
9
100
1
7 0
10
101
1
8 0
11
18
0
1
0
202
2
9 0
5 0
1
0
203
2
9 0
5 0
1
0
204
2
9 0
5 0
1
0
205
2
9 0
5 0
1
0
206
2
9 0
5 0
1
0
207
2
9 0
5 0
1
0
208
2
9 0
5 0
1
0
209
2
9 0
5 0
1
0
210
2
9 0
5 0
1
0
211
2
9 0
5 0
1
0
7
2
9 0
5 0
end_DTG
begin_DTG
11
1
102
1
0 0
2
103
1
1 0
3
104
1
21 0
4
105
1
2 0
5
106
1
3 0
6
107
1
4 0
7
108
1
22 0
8
109
1
5 0
9
110
1
7 0
10
111
1
8 0
11
19
0
1
0
212
2
9 0
6 0
1
0
213
2
9 0
6 0
1
0
214
2
9 0
6 0
1
0
215
2
9 0
6 0
1
0
216
2
9 0
6 0
1
0
217
2
9 0
6 0
1
0
218
2
9 0
6 0
1
0
219
2
9 0
6 0
1
0
220
2
9 0
6 0
1
0
221
2
9 0
6 0
1
0
8
2
9 0
6 0
end_DTG
begin_DTG
11
1
112
1
0 0
2
113
1
1 0
3
114
1
21 0
4
115
1
2 0
5
116
1
3 0
6
117
1
4 0
7
118
1
22 0
8
119
1
5 0
9
120
1
6 0
10
121
1
8 0
11
20
0
1
0
222
2
9 0
7 0
1
0
223
2
9 0
7 0
1
0
224
2
9 0
7 0
1
0
225
2
9 0
7 0
1
0
226
2
9 0
7 0
1
0
227
2
9 0
7 0
1
0
228
2
9 0
7 0
1
0
229
2
9 0
7 0
1
0
230
2
9 0
7 0
1
0
231
2
9 0
7 0
1
0
9
2
9 0
7 0
end_DTG
begin_DTG
11
1
122
1
0 0
2
123
1
1 0
3
124
1
21 0
4
125
1
2 0
5
126
1
3 0
6
127
1
4 0
7
128
1
22 0
8
129
1
5 0
9
130
1
6 0
10
131
1
7 0
11
21
0
1
0
232
2
9 0
8 0
1
0
233
2
9 0
8 0
1
0
234
2
9 0
8 0
1
0
235
2
9 0
8 0
1
0
236
2
9 0
8 0
1
0
237
2
9 0
8 0
1
0
238
2
9 0
8 0
1
0
239
2
9 0
8 0
1
0
240
2
9 0
8 0
1
0
241
2
9 0
8 0
1
0
10
2
9 0
8 0
end_DTG
begin_DTG
11
1
42
1
0 0
2
43
1
1 0
3
44
1
2 0
4
45
1
3 0
5
46
1
4 0
6
47
1
22 0
7
48
1
5 0
8
49
1
6 0
9
50
1
7 0
10
51
1
8 0
11
13
0
1
0
152
2
9 0
21 0
1
0
153
2
9 0
21 0
1
0
154
2
9 0
21 0
1
0
155
2
9 0
21 0
1
0
156
2
9 0
21 0
1
0
157
2
9 0
21 0
1
0
158
2
9 0
21 0
1
0
159
2
9 0
21 0
1
0
160
2
9 0
21 0
1
0
161
2
9 0
21 0
1
0
2
2
9 0
21 0
end_DTG
begin_DTG
11
1
82
1
0 0
2
83
1
1 0
3
84
1
21 0
4
85
1
2 0
5
86
1
3 0
6
87
1
4 0
7
88
1
5 0
8
89
1
6 0
9
90
1
7 0
10
91
1
8 0
11
17
0
1
0
192
2
9 0
22 0
1
0
193
2
9 0
22 0
1
0
194
2
9 0
22 0
1
0
195
2
9 0
22 0
1
0
196
2
9 0
22 0
1
0
197
2
9 0
22 0
1
0
198
2
9 0
22 0
1
0
199
2
9 0
22 0
1
0
200
2
9 0
22 0
1
0
201
2
9 0
22 0
1
0
6
2
9 0
22 0
end_DTG
begin_DTG
21
1
23
1
10 0
1
124
1
18 0
1
114
1
17 0
1
104
1
16 0
1
94
1
15 0
1
84
1
20 0
1
74
1
14 0
1
64
1
13 0
1
54
1
12 0
1
33
1
11 0
1
2
2
9 0
19 11
1
152
2
9 0
19 1
1
153
2
9 0
19 2
1
154
2
9 0
19 3
1
155
2
9 0
19 4
1
156
2
9 0
19 5
1
157
2
9 0
19 6
1
158
2
9 0
19 7
1
159
2
9 0
19 8
1
160
2
9 0
19 9
1
161
2
9 0
19 10
11
0
13
1
19 0
0
133
3
9 0
0 0
10 2
0
143
3
9 0
1 0
11 2
0
164
3
9 0
2 0
12 3
0
174
3
9 0
3 0
13 3
0
184
3
9 0
4 0
14 3
0
194
3
9 0
22 0
20 3
0
204
3
9 0
5 0
15 3
0
214
3
9 0
6 0
16 3
0
224
3
9 0
7 0
17 3
0
234
3
9 0
8 0
18 3
end_DTG
begin_DTG
21
1
27
1
10 0
1
128
1
18 0
1
118
1
17 0
1
108
1
16 0
1
98
1
15 0
1
77
1
14 0
1
67
1
13 0
1
57
1
12 0
1
47
1
19 0
1
37
1
11 0
1
6
2
9 0
20 11
1
192
2
9 0
20 1
1
193
2
9 0
20 2
1
194
2
9 0
20 3
1
195
2
9 0
20 4
1
196
2
9 0
20 5
1
197
2
9 0
20 6
1
198
2
9 0
20 7
1
199
2
9 0
20 8
1
200
2
9 0
20 9
1
201
2
9 0
20 10
11
0
17
1
20 0
0
137
3
9 0
0 0
10 6
0
147
3
9 0
1 0
11 6
0
157
3
9 0
21 0
19 6
0
167
3
9 0
2 0
12 6
0
177
3
9 0
3 0
13 6
0
187
3
9 0
4 0
14 6
0
208
3
9 0
5 0
15 7
0
218
3
9 0
6 0
16 7
0
228
3
9 0
7 0
17 7
0
238
3
9 0
8 0
18 7
end_DTG
begin_CG
22
9 21
1 2
21 2
2 2
3 2
4 2
22 2
5 2
6 2
7 2
8 2
10 11
11 1
19 1
12 1
13 1
14 1
20 1
15 1
16 1
17 1
18 1
22
9 21
0 2
21 2
2 2
3 2
4 2
22 2
5 2
6 2
7 2
8 2
10 1
11 11
19 1
12 1
13 1
14 1
20 1
15 1
16 1
17 1
18 1
22
9 21
0 2
1 2
21 2
3 2
4 2
22 2
5 2
6 2
7 2
8 2
10 1
11 1
19 1
12 11
13 1
14 1
20 1
15 1
16 1
17 1
18 1
22
9 21
0 2
1 2
21 2
2 2
4 2
22 2
5 2
6 2
7 2
8 2
10 1
11 1
19 1
12 1
13 11
14 1
20 1
15 1
16 1
17 1
18 1
22
9 21
0 2
1 2
21 2
2 2
3 2
22 2
5 2
6 2
7 2
8 2
10 1
11 1
19 1
12 1
13 1
14 11
20 1
15 1
16 1
17 1
18 1
22
9 21
0 2
1 2
21 2
2 2
3 2
4 2
22 2
6 2
7 2
8 2
10 1
11 1
19 1
12 1
13 1
14 1
20 1
15 11
16 1
17 1
18 1
22
9 21
0 2
1 2
21 2
2 2
3 2
4 2
22 2
5 2
7 2
8 2
10 1
11 1
19 1
12 1
13 1
14 1
20 1
15 1
16 11
17 1
18 1
22
9 21
0 2
1 2
21 2
2 2
3 2
4 2
22 2
5 2
6 2
8 2
10 1
11 1
19 1
12 1
13 1
14 1
20 1
15 1
16 1
17 11
18 1
22
9 21
0 2
1 2
21 2
2 2
3 2
4 2
22 2
5 2
6 2
7 2
10 1
11 1
19 1
12 1
13 1
14 1
20 1
15 1
16 1
17 1
18 11
22
0 21
1 21
21 21
2 21
3 21
4 21
22 21
5 21
6 21
7 21
8 21
10 11
11 11
19 11
12 11
13 11
14 11
20 11
15 11
16 11
17 11
18 11
12
9 22
0 22
1 2
21 2
2 2
3 2
4 2
22 2
5 2
6 2
7 2
8 2
12
9 22
0 2
1 22
21 2
2 2
3 2
4 2
22 2
5 2
6 2
7 2
8 2
12
9 22
0 2
1 2
21 2
2 22
3 2
4 2
22 2
5 2
6 2
7 2
8 2
12
9 22
0 2
1 2
21 2
2 2
3 22
4 2
22 2
5 2
6 2
7 2
8 2
12
9 22
0 2
1 2
21 2
2 2
3 2
4 22
22 2
5 2
6 2
7 2
8 2
12
9 22
0 2
1 2
21 2
2 2
3 2
4 2
22 2
5 22
6 2
7 2
8 2
12
9 22
0 2
1 2
21 2
2 2
3 2
4 2
22 2
5 2
6 22
7 2
8 2
12
9 22
0 2
1 2
21 2
2 2
3 2
4 2
22 2
5 2
6 2
7 22
8 2
12
9 22
0 2
1 2
21 2
2 2
3 2
4 2
22 2
5 2
6 2
7 2
8 22
12
9 22
0 2
1 2
21 22
2 2
3 2
4 2
22 2
5 2
6 2
7 2
8 2
12
9 22
0 2
1 2
21 2
2 2
3 2
4 2
22 22
5 2
6 2
7 2
8 2
22
9 21
0 2
1 2
2 2
3 2
4 2
22 2
5 2
6 2
7 2
8 2
10 1
11 1
19 11
12 1
13 1
14 1
20 1
15 1
16 1
17 1
18 1
22
9 21
0 2
1 2
21 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
10 1
11 1
19 1
12 1
13 1
14 1
20 11
15 1
16 1
17 1
18 1
end_CG
