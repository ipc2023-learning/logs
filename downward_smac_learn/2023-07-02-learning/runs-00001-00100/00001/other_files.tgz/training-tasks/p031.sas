begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var7
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var8
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var9
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var0
-1
2
Atom arm-empty()
NegatedAtom arm-empty()
end_variable
begin_variable
var10
-1
10
Atom holding(b1)
Atom on(b1, b2)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var11
-1
10
Atom holding(b2)
Atom on(b2, b1)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var12
-1
10
Atom holding(b3)
Atom on(b3, b1)
Atom on(b3, b2)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var16
-1
10
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b2)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var17
-1
10
Atom holding(b8)
Atom on(b8, b1)
Atom on(b8, b2)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var18
-1
10
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b2)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var13
-1
10
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b2)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var14
-1
10
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b2)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var15
-1
10
Atom holding(b6)
Atom on(b6, b1)
Atom on(b6, b2)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var5
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var6
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
10
begin_mutex_group
10
6 0
7 0
8 0
9 0
13 0
14 0
15 0
10 0
11 0
12 0
end_mutex_group
begin_mutex_group
10
0 0
7 0
8 1
9 1
13 1
14 1
15 1
10 1
11 1
12 1
end_mutex_group
begin_mutex_group
10
1 0
8 0
7 1
9 2
13 2
14 2
15 2
10 2
11 2
12 2
end_mutex_group
begin_mutex_group
10
2 0
9 0
7 2
8 2
13 3
14 3
15 3
10 3
11 3
12 3
end_mutex_group
begin_mutex_group
10
16 0
13 0
7 3
8 3
9 3
14 4
15 4
10 4
11 4
12 4
end_mutex_group
begin_mutex_group
10
17 0
14 0
7 4
8 4
9 4
13 4
15 5
10 5
11 5
12 5
end_mutex_group
begin_mutex_group
10
18 0
15 0
7 5
8 5
9 5
13 5
14 5
10 6
11 6
12 6
end_mutex_group
begin_mutex_group
10
3 0
10 0
7 6
8 6
9 6
13 6
14 6
15 6
11 7
12 7
end_mutex_group
begin_mutex_group
10
4 0
11 0
7 7
8 7
9 7
13 7
14 7
15 7
10 7
12 8
end_mutex_group
begin_mutex_group
10
5 0
12 0
7 8
8 8
9 8
13 8
14 8
15 8
10 8
11 8
end_mutex_group
begin_state
1
1
0
1
1
1
0
1
6
4
6
1
4
9
7
8
1
1
1
end_state
begin_goal
12
7 1
8 9
9 9
10 8
11 7
12 9
13 1
14 3
15 7
16 0
17 0
18 0
end_goal
162
begin_operator
pickup b1
0
3
0 6 0 1
0 0 0 1
0 7 9 0
0
end_operator
begin_operator
pickup b2
0
3
0 6 0 1
0 1 0 1
0 8 9 0
0
end_operator
begin_operator
pickup b3
0
3
0 6 0 1
0 2 0 1
0 9 9 0
0
end_operator
begin_operator
pickup b4
0
3
0 6 0 1
0 16 0 1
0 13 9 0
0
end_operator
begin_operator
pickup b5
0
3
0 6 0 1
0 17 0 1
0 14 9 0
0
end_operator
begin_operator
pickup b6
0
3
0 6 0 1
0 18 0 1
0 15 9 0
0
end_operator
begin_operator
pickup b7
0
3
0 6 0 1
0 3 0 1
0 10 9 0
0
end_operator
begin_operator
pickup b8
0
3
0 6 0 1
0 4 0 1
0 11 9 0
0
end_operator
begin_operator
pickup b9
0
3
0 6 0 1
0 5 0 1
0 12 9 0
0
end_operator
begin_operator
putdown b1
0
3
0 6 -1 0
0 0 -1 0
0 7 0 9
0
end_operator
begin_operator
putdown b2
0
3
0 6 -1 0
0 1 -1 0
0 8 0 9
0
end_operator
begin_operator
putdown b3
0
3
0 6 -1 0
0 2 -1 0
0 9 0 9
0
end_operator
begin_operator
putdown b4
0
3
0 6 -1 0
0 16 -1 0
0 13 0 9
0
end_operator
begin_operator
putdown b5
0
3
0 6 -1 0
0 17 -1 0
0 14 0 9
0
end_operator
begin_operator
putdown b6
0
3
0 6 -1 0
0 18 -1 0
0 15 0 9
0
end_operator
begin_operator
putdown b7
0
3
0 6 -1 0
0 3 -1 0
0 10 0 9
0
end_operator
begin_operator
putdown b8
0
3
0 6 -1 0
0 4 -1 0
0 11 0 9
0
end_operator
begin_operator
putdown b9
0
3
0 6 -1 0
0 5 -1 0
0 12 0 9
0
end_operator
begin_operator
stack b1 b2
0
4
0 6 -1 0
0 0 -1 0
0 1 0 1
0 7 0 1
0
end_operator
begin_operator
stack b1 b3
0
4
0 6 -1 0
0 0 -1 0
0 2 0 1
0 7 0 2
0
end_operator
begin_operator
stack b1 b4
0
4
0 6 -1 0
0 0 -1 0
0 16 0 1
0 7 0 3
0
end_o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





3
20
1
16 0
4
21
1
17 0
5
22
1
18 0
6
23
1
3 0
7
24
1
4 0
8
25
1
5 0
9
9
0
1
0
90
2
6 0
0 0
1
0
91
2
6 0
0 0
1
0
92
2
6 0
0 0
1
0
93
2
6 0
0 0
1
0
94
2
6 0
0 0
1
0
95
2
6 0
0 0
1
0
96
2
6 0
0 0
1
0
97
2
6 0
0 0
1
0
0
2
6 0
0 0
end_DTG
begin_DTG
9
1
26
1
0 0
2
27
1
2 0
3
28
1
16 0
4
29
1
17 0
5
30
1
18 0
6
31
1
3 0
7
32
1
4 0
8
33
1
5 0
9
10
0
1
0
98
2
6 0
1 0
1
0
99
2
6 0
1 0
1
0
100
2
6 0
1 0
1
0
101
2
6 0
1 0
1
0
102
2
6 0
1 0
1
0
103
2
6 0
1 0
1
0
104
2
6 0
1 0
1
0
105
2
6 0
1 0
1
0
1
2
6 0
1 0
end_DTG
begin_DTG
9
1
34
1
0 0
2
35
1
1 0
3
36
1
16 0
4
37
1
17 0
5
38
1
18 0
6
39
1
3 0
7
40
1
4 0
8
41
1
5 0
9
11
0
1
0
106
2
6 0
2 0
1
0
107
2
6 0
2 0
1
0
108
2
6 0
2 0
1
0
109
2
6 0
2 0
1
0
110
2
6 0
2 0
1
0
111
2
6 0
2 0
1
0
112
2
6 0
2 0
1
0
113
2
6 0
2 0
1
0
2
2
6 0
2 0
end_DTG
begin_DTG
9
1
66
1
0 0
2
67
1
1 0
3
68
1
2 0
4
69
1
16 0
5
70
1
17 0
6
71
1
18 0
7
72
1
4 0
8
73
1
5 0
9
15
0
1
0
138
2
6 0
3 0
1
0
139
2
6 0
3 0
1
0
140
2
6 0
3 0
1
0
141
2
6 0
3 0
1
0
142
2
6 0
3 0
1
0
143
2
6 0
3 0
1
0
144
2
6 0
3 0
1
0
145
2
6 0
3 0
1
0
6
2
6 0
3 0
end_DTG
begin_DTG
9
1
74
1
0 0
2
75
1
1 0
3
76
1
2 0
4
77
1
16 0
5
78
1
17 0
6
79
1
18 0
7
80
1
3 0
8
81
1
5 0
9
16
0
1
0
146
2
6 0
4 0
1
0
147
2
6 0
4 0
1
0
148
2
6 0
4 0
1
0
149
2
6 0
4 0
1
0
150
2
6 0
4 0
1
0
151
2
6 0
4 0
1
0
152
2
6 0
4 0
1
0
153
2
6 0
4 0
1
0
7
2
6 0
4 0
end_DTG
begin_DTG
9
1
82
1
0 0
2
83
1
1 0
3
84
1
2 0
4
85
1
16 0
5
86
1
17 0
6
87
1
18 0
7
88
1
3 0
8
89
1
4 0
9
17
0
1
0
154
2
6 0
5 0
1
0
155
2
6 0
5 0
1
0
156
2
6 0
5 0
1
0
157
2
6 0
5 0
1
0
158
2
6 0
5 0
1
0
159
2
6 0
5 0
1
0
160
2
6 0
5 0
1
0
161
2
6 0
5 0
1
0
8
2
6 0
5 0
end_DTG
begin_DTG
9
1
42
1
0 0
2
43
1
1 0
3
44
1
2 0
4
45
1
17 0
5
46
1
18 0
6
47
1
3 0
7
48
1
4 0
8
49
1
5 0
9
12
0
1
0
114
2
6 0
16 0
1
0
115
2
6 0
16 0
1
0
116
2
6 0
16 0
1
0
117
2
6 0
16 0
1
0
118
2
6 0
16 0
1
0
119
2
6 0
16 0
1
0
120
2
6 0
16 0
1
0
121
2
6 0
16 0
1
0
3
2
6 0
16 0
end_DTG
begin_DTG
9
1
50
1
0 0
2
51
1
1 0
3
52
1
2 0
4
53
1
16 0
5
54
1
18 0
6
55
1
3 0
7
56
1
4 0
8
57
1
5 0
9
13
0
1
0
122
2
6 0
17 0
1
0
123
2
6 0
17 0
1
0
124
2
6 0
17 0
1
0
125
2
6 0
17 0
1
0
126
2
6 0
17 0
1
0
127
2
6 0
17 0
1
0
128
2
6 0
17 0
1
0
129
2
6 0
17 0
1
0
4
2
6 0
17 0
end_DTG
begin_DTG
9
1
58
1
0 0
2
59
1
1 0
3
60
1
2 0
4
61
1
16 0
5
62
1
17 0
6
63
1
3 0
7
64
1
4 0
8
65
1
5 0
9
14
0
1
0
130
2
6 0
18 0
1
0
131
2
6 0
18 0
1
0
132
2
6 0
18 0
1
0
133
2
6 0
18 0
1
0
134
2
6 0
18 0
1
0
135
2
6 0
18 0
1
0
136
2
6 0
18 0
1
0
137
2
6 0
18 0
1
0
5
2
6 0
18 0
end_DTG
begin_DTG
17
1
20
1
7 0
1
85
1
12 0
1
77
1
11 0
1
69
1
10 0
1
61
1
15 0
1
53
1
14 0
1
36
1
9 0
1
28
1
8 0
1
3
2
6 0
13 9
1
114
2
6 0
13 1
1
115
2
6 0
13 2
1
116
2
6 0
13 3
1
117
2
6 0
13 4
1
118
2
6 0
13 5
1
119
2
6 0
13 6
1
120
2
6 0
13 7
1
121
2
6 0
13 8
9
0
12
1
13 0
0
92
3
6 0
0 0
7 3
0
100
3
6 0
1 0
8 3
0
108
3
6 0
2 0
9 3
0
125
3
6 0
17 0
14 4
0
133
3
6 0
18 0
15 4
0
141
3
6 0
3 0
10 4
0
149
3
6 0
4 0
11 4
0
157
3
6 0
5 0
12 4
end_DTG
begin_DTG
17
1
21
1
7 0
1
86
1
12 0
1
78
1
11 0
1
70
1
10 0
1
62
1
15 0
1
45
1
13 0
1
37
1
9 0
1
29
1
8 0
1
4
2
6 0
14 9
1
122
2
6 0
14 1
1
123
2
6 0
14 2
1
124
2
6 0
14 3
1
125
2
6 0
14 4
1
126
2
6 0
14 5
1
127
2
6 0
14 6
1
128
2
6 0
14 7
1
129
2
6 0
14 8
9
0
13
1
14 0
0
93
3
6 0
0 0
7 4
0
101
3
6 0
1 0
8 4
0
109
3
6 0
2 0
9 4
0
117
3
6 0
16 0
13 4
0
134
3
6 0
18 0
15 5
0
142
3
6 0
3 0
10 5
0
150
3
6 0
4 0
11 5
0
158
3
6 0
5 0
12 5
end_DTG
begin_DTG
17
1
22
1
7 0
1
87
1
12 0
1
79
1
11 0
1
71
1
10 0
1
54
1
14 0
1
46
1
13 0
1
38
1
9 0
1
30
1
8 0
1
5
2
6 0
15 9
1
130
2
6 0
15 1
1
131
2
6 0
15 2
1
132
2
6 0
15 3
1
133
2
6 0
15 4
1
134
2
6 0
15 5
1
135
2
6 0
15 6
1
136
2
6 0
15 7
1
137
2
6 0
15 8
9
0
14
1
15 0
0
94
3
6 0
0 0
7 5
0
102
3
6 0
1 0
8 5
0
110
3
6 0
2 0
9 5
0
118
3
6 0
16 0
13 5
0
126
3
6 0
17 0
14 5
0
143
3
6 0
3 0
10 6
0
151
3
6 0
4 0
11 6
0
159
3
6 0
5 0
12 6
end_DTG
begin_CG
18
6 17
1 2
2 2
16 2
17 2
18 2
3 2
4 2
5 2
7 9
8 1
9 1
13 1
14 1
15 1
10 1
11 1
12 1
18
6 17
0 2
2 2
16 2
17 2
18 2
3 2
4 2
5 2
7 1
8 9
9 1
13 1
14 1
15 1
10 1
11 1
12 1
18
6 17
0 2
1 2
16 2
17 2
18 2
3 2
4 2
5 2
7 1
8 1
9 9
13 1
14 1
15 1
10 1
11 1
12 1
18
6 17
0 2
1 2
2 2
16 2
17 2
18 2
4 2
5 2
7 1
8 1
9 1
13 1
14 1
15 1
10 9
11 1
12 1
18
6 17
0 2
1 2
2 2
16 2
17 2
18 2
3 2
5 2
7 1
8 1
9 1
13 1
14 1
15 1
10 1
11 9
12 1
18
6 17
0 2
1 2
2 2
16 2
17 2
18 2
3 2
4 2
7 1
8 1
9 1
13 1
14 1
15 1
10 1
11 1
12 9
18
0 17
1 17
2 17
16 17
17 17
18 17
3 17
4 17
5 17
7 9
8 9
9 9
13 9
14 9
15 9
10 9
11 9
12 9
10
6 18
0 18
1 2
2 2
16 2
17 2
18 2
3 2
4 2
5 2
10
6 18
0 2
1 18
2 2
16 2
17 2
18 2
3 2
4 2
5 2
10
6 18
0 2
1 2
2 18
16 2
17 2
18 2
3 2
4 2
5 2
10
6 18
0 2
1 2
2 2
16 2
17 2
18 2
3 18
4 2
5 2
10
6 18
0 2
1 2
2 2
16 2
17 2
18 2
3 2
4 18
5 2
10
6 18
0 2
1 2
2 2
16 2
17 2
18 2
3 2
4 2
5 18
10
6 18
0 2
1 2
2 2
16 18
17 2
18 2
3 2
4 2
5 2
10
6 18
0 2
1 2
2 2
16 2
17 18
18 2
3 2
4 2
5 2
10
6 18
0 2
1 2
2 2
16 2
17 2
18 18
3 2
4 2
5 2
18
6 17
0 2
1 2
2 2
17 2
18 2
3 2
4 2
5 2
7 1
8 1
9 1
13 9
14 1
15 1
10 1
11 1
12 1
18
6 17
0 2
1 2
2 2
16 2
18 2
3 2
4 2
5 2
7 1
8 1
9 1
13 1
14 9
15 1
10 1
11 1
12 1
18
6 17
0 2
1 2
2 2
16 2
17 2
3 2
4 2
5 2
7 1
8 1
9 1
13 1
14 1
15 9
10 1
11 1
12 1
end_CG
