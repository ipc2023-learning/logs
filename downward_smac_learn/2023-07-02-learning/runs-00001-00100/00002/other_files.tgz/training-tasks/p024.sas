begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var9
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var10
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var12
-1
4
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var13
-1
4
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var17
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_variable
var16
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var15
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var14
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
0
begin_state
0
1
1
1
0
0
0
0
1
0
0
1
0
0
1
1
1
1
end_state
begin_goal
4
14 0
15 0
16 0
17 0
end_goal
117
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 4 0 1
0 5 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 4 0 1
0 6 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 4 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content4
0
3
0 4 0 1
0 13 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 7 0 1
0 5 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 7 0 1
0 6 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 7 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content4
0
3
0 7 0 1
0 13 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 9 0 1
0 5 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 9 0 1
0 6 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 9 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content4
0
3
0 9 0 1
0 13 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content1
0
3
0 12 0 1
0 5 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content2
0
3
0 12 0 1
0 6 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content3
0
3
0 12 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content4
0
3
0 12 0 1
0 13 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content1
0
3
0 4 0 1
0 5 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content2
0
3
0 4 0 1
0 6 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content3
0
3
0 4 0 1
0 10 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content4
0
3
0 4 0 1
0 13 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content1
0
3
0 7 0 1
0 5 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content2
0
3
0 7 0 1
0 6 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content3
0
3
0 7 0 1
0 10 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content4
0
3
0 7 0 1
0 13 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content1
0
3
0 9 0 1
0 5 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content2
0
3
0 9 0 1
0 6 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content3
0
3
0 9 0 1
0 10 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content4
0
3
0 9 0 1
0 13 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread4 content1
0
3
0 12 0 1
0 5 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread4 content2
0
3
0 12 0 1
0 6 0 1
0 2 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread4 content3
0
3





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
10 0
0
15
2
12 0
13 0
3
3
97
1
0 2
3
99
1
0 3
3
100
1
0 1
0
end_DTG
begin_DTG
1
2
93
1
0 0
16
0
16
2
4 0
5 0
0
17
2
4 0
6 0
0
18
2
4 0
10 0
0
19
2
4 0
13 0
0
20
2
7 0
5 0
0
21
2
7 0
6 0
0
22
2
7 0
10 0
0
23
2
7 0
13 0
0
24
2
9 0
5 0
0
25
2
9 0
6 0
0
26
2
9 0
10 0
0
27
2
9 0
13 0
0
28
2
12 0
5 0
0
29
2
12 0
6 0
0
30
2
12 0
10 0
0
31
2
12 0
13 0
3
3
101
1
0 2
3
103
1
0 3
3
104
1
0 1
0
end_DTG
begin_DTG
1
2
94
1
0 0
16
0
32
2
4 0
5 0
0
33
2
4 0
6 0
0
34
2
4 0
10 0
0
35
2
4 0
13 0
0
36
2
7 0
5 0
0
37
2
7 0
6 0
0
38
2
7 0
10 0
0
39
2
7 0
13 0
0
40
2
9 0
5 0
0
41
2
9 0
6 0
0
42
2
9 0
10 0
0
43
2
9 0
13 0
0
44
2
12 0
5 0
0
45
2
12 0
6 0
0
46
2
12 0
10 0
0
47
2
12 0
13 0
3
3
105
1
0 2
3
107
1
0 3
3
108
1
0 1
0
end_DTG
begin_DTG
20
1
34
2
10 0
3 1
1
67
2
13 0
11 1
1
66
2
10 0
11 1
1
65
2
6 0
11 1
1
64
2
5 0
11 1
1
51
2
13 0
8 1
1
50
2
10 0
8 1
1
49
2
6 0
8 1
1
48
2
5 0
8 1
1
35
2
13 0
3 1
1
0
2
5 0
1 1
1
33
2
6 0
3 1
1
32
2
5 0
3 1
1
19
2
13 0
2 1
1
18
2
10 0
2 1
1
17
2
6 0
2 1
1
16
2
5 0
2 1
1
3
2
13 0
1 1
1
2
2
10 0
1 1
1
1
2
6 0
1 1
0
end_DTG
begin_DTG
20
1
40
2
9 0
3 1
1
76
2
12 0
11 1
1
72
2
9 0
11 1
1
68
2
7 0
11 1
1
64
2
4 0
11 1
1
60
2
12 0
8 1
1
56
2
9 0
8 1
1
52
2
7 0
8 1
1
48
2
4 0
8 1
1
44
2
12 0
3 1
1
0
2
4 0
1 1
1
36
2
7 0
3 1
1
32
2
4 0
3 1
1
28
2
12 0
2 1
1
24
2
9 0
2 1
1
20
2
7 0
2 1
1
16
2
4 0
2 1
1
12
2
12 0
1 1
1
8
2
9 0
1 1
1
4
2
7 0
1 1
0
end_DTG
begin_DTG
20
1
41
2
9 0
3 1
1
77
2
12 0
11 1
1
73
2
9 0
11 1
1
69
2
7 0
11 1
1
65
2
4 0
11 1
1
61
2
12 0
8 1
1
57
2
9 0
8 1
1
53
2
7 0
8 1
1
49
2
4 0
8 1
1
45
2
12 0
3 1
1
1
2
4 0
1 1
1
37
2
7 0
3 1
1
33
2
4 0
3 1
1
29
2
12 0
2 1
1
25
2
9 0
2 1
1
21
2
7 0
2 1
1
17
2
4 0
2 1
1
13
2
12 0
1 1
1
9
2
9 0
1 1
1
5
2
7 0
1 1
0
end_DTG
begin_DTG
20
1
38
2
10 0
3 1
1
71
2
13 0
11 1
1
70
2
10 0
11 1
1
69
2
6 0
11 1
1
68
2
5 0
11 1
1
55
2
13 0
8 1
1
54
2
10 0
8 1
1
53
2
6 0
8 1
1
52
2
5 0
8 1
1
39
2
13 0
3 1
1
4
2
5 0
1 1
1
37
2
6 0
3 1
1
36
2
5 0
3 1
1
23
2
13 0
2 1
1
22
2
10 0
2 1
1
21
2
6 0
2 1
1
20
2
5 0
2 1
1
7
2
13 0
1 1
1
6
2
10 0
1 1
1
5
2
6 0
1 1
0
end_DTG
begin_DTG
1
2
95
1
0 0
16
0
48
2
4 0
5 0
0
49
2
4 0
6 0
0
50
2
4 0
10 0
0
51
2
4 0
13 0
0
52
2
7 0
5 0
0
53
2
7 0
6 0
0
54
2
7 0
10 0
0
55
2
7 0
13 0
0
56
2
9 0
5 0
0
57
2
9 0
6 0
0
58
2
9 0
10 0
0
59
2
9 0
13 0
0
60
2
12 0
5 0
0
61
2
12 0
6 0
0
62
2
12 0
10 0
0
63
2
12 0
13 0
3
3
109
1
0 2
3
111
1
0 3
3
112
1
0 1
0
end_DTG
begin_DTG
20
1
42
2
10 0
3 1
1
75
2
13 0
11 1
1
74
2
10 0
11 1
1
73
2
6 0
11 1
1
72
2
5 0
11 1
1
59
2
13 0
8 1
1
58
2
10 0
8 1
1
57
2
6 0
8 1
1
56
2
5 0
8 1
1
43
2
13 0
3 1
1
8
2
5 0
1 1
1
41
2
6 0
3 1
1
40
2
5 0
3 1
1
27
2
13 0
2 1
1
26
2
10 0
2 1
1
25
2
6 0
2 1
1
24
2
5 0
2 1
1
11
2
13 0
1 1
1
10
2
10 0
1 1
1
9
2
6 0
1 1
0
end_DTG
begin_DTG
20
1
42
2
9 0
3 1
1
78
2
12 0
11 1
1
74
2
9 0
11 1
1
70
2
7 0
11 1
1
66
2
4 0
11 1
1
62
2
12 0
8 1
1
58
2
9 0
8 1
1
54
2
7 0
8 1
1
50
2
4 0
8 1
1
46
2
12 0
3 1
1
2
2
4 0
1 1
1
38
2
7 0
3 1
1
34
2
4 0
3 1
1
30
2
12 0
2 1
1
26
2
9 0
2 1
1
22
2
7 0
2 1
1
18
2
4 0
2 1
1
14
2
12 0
1 1
1
10
2
9 0
1 1
1
6
2
7 0
1 1
0
end_DTG
begin_DTG
1
2
96
1
0 0
16
0
64
2
4 0
5 0
0
65
2
4 0
6 0
0
66
2
4 0
10 0
0
67
2
4 0
13 0
0
68
2
7 0
5 0
0
69
2
7 0
6 0
0
70
2
7 0
10 0
0
71
2
7 0
13 0
0
72
2
9 0
5 0
0
73
2
9 0
6 0
0
74
2
9 0
10 0
0
75
2
9 0
13 0
0
76
2
12 0
5 0
0
77
2
12 0
6 0
0
78
2
12 0
10 0
0
79
2
12 0
13 0
3
3
113
1
0 2
3
115
1
0 3
3
116
1
0 1
0
end_DTG
begin_DTG
20
1
46
2
10 0
3 1
1
79
2
13 0
11 1
1
78
2
10 0
11 1
1
77
2
6 0
11 1
1
76
2
5 0
11 1
1
63
2
13 0
8 1
1
62
2
10 0
8 1
1
61
2
6 0
8 1
1
60
2
5 0
8 1
1
47
2
13 0
3 1
1
12
2
5 0
1 1
1
45
2
6 0
3 1
1
44
2
5 0
3 1
1
31
2
13 0
2 1
1
30
2
10 0
2 1
1
29
2
6 0
2 1
1
28
2
5 0
2 1
1
15
2
13 0
1 1
1
14
2
10 0
1 1
1
13
2
6 0
1 1
0
end_DTG
begin_DTG
20
1
43
2
9 0
3 1
1
79
2
12 0
11 1
1
75
2
9 0
11 1
1
71
2
7 0
11 1
1
67
2
4 0
11 1
1
63
2
12 0
8 1
1
59
2
9 0
8 1
1
55
2
7 0
8 1
1
51
2
4 0
8 1
1
47
2
12 0
3 1
1
3
2
4 0
1 1
1
39
2
7 0
3 1
1
35
2
4 0
3 1
1
31
2
12 0
2 1
1
27
2
9 0
2 1
1
23
2
7 0
2 1
1
19
2
4 0
2 1
1
15
2
12 0
1 1
1
11
2
9 0
1 1
1
7
2
7 0
1 1
0
end_DTG
begin_DTG
0
5
0
100
2
0 1
1 2
0
104
2
0 1
2 2
0
108
2
0 1
3 2
0
112
2
0 1
8 2
0
116
2
0 1
11 2
end_DTG
begin_DTG
0
5
0
99
2
0 3
1 2
0
103
2
0 3
2 2
0
107
2
0 3
3 2
0
111
2
0 3
8 2
0
115
2
0 3
11 2
end_DTG
begin_DTG
0
5
0
98
2
0 2
1 2
0
102
2
0 2
2 2
0
106
2
0 2
3 2
0
110
2
0 2
8 2
0
114
2
0 2
11 2
end_DTG
begin_DTG
0
5
0
97
2
0 2
1 2
0
101
2
0 2
2 2
0
105
2
0 2
3 2
0
109
2
0 2
8 2
0
113
2
0 2
11 2
end_DTG
begin_CG
9
1 5
2 5
3 5
8 5
11 5
17 5
16 5
15 5
14 5
12
4 4
7 4
9 4
12 4
5 4
6 4
10 4
13 4
17 1
16 1
15 1
14 1
12
4 4
7 4
9 4
12 4
5 4
6 4
10 4
13 4
17 1
16 1
15 1
14 1
12
4 4
7 4
9 4
12 4
5 4
6 4
10 4
13 4
17 1
16 1
15 1
14 1
9
5 5
6 5
10 5
13 5
1 4
2 4
3 4
8 4
11 4
9
4 5
7 5
9 5
12 5
1 4
2 4
3 4
8 4
11 4
9
4 5
7 5
9 5
12 5
1 4
2 4
3 4
8 4
11 4
9
5 5
6 5
10 5
13 5
1 4
2 4
3 4
8 4
11 4
12
4 4
7 4
9 4
12 4
5 4
6 4
10 4
13 4
17 1
16 1
15 1
14 1
9
5 5
6 5
10 5
13 5
1 4
2 4
3 4
8 4
11 4
9
4 5
7 5
9 5
12 5
1 4
2 4
3 4
8 4
11 4
12
4 4
7 4
9 4
12 4
5 4
6 4
10 4
13 4
17 1
16 1
15 1
14 1
9
5 5
6 5
10 5
13 5
1 4
2 4
3 4
8 4
11 4
9
4 5
7 5
9 5
12 5
1 4
2 4
3 4
8 4
11 4
0
0
0
0
end_CG
