begin_version
3
end_version
begin_metric
0
end_metric
17
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var9
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var10
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var11
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var12
-1
4
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
<none of those>
end_variable
begin_variable
var16
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_variable
var15
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var14
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var13
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
0
begin_state
0
1
0
0
0
0
1
1
0
0
0
0
1
1
1
1
1
end_state
begin_goal
4
13 0
14 0
15 0
16 0
end_goal
96
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 2 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 2 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 2 0 1
0 9 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content4
0
3
0 2 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 5 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 5 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 5 0 1
0 9 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content4
0
3
0 5 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 8 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 8 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 8 0 1
0 9 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content4
0
3
0 8 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content1
0
3
0 11 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content2
0
3
0 11 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content3
0
3
0 11 0 1
0 9 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content4
0
3
0 11 0 1
0 10 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content1
0
3
0 2 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content2
0
3
0 2 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content3
0
3
0 2 0 1
0 9 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content4
0
3
0 2 0 1
0 10 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content1
0
3
0 5 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content2
0
3
0 5 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content3
0
3
0 5 0 1
0 9 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content4
0
3
0 5 0 1
0 10 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content1
0
3
0 8 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content2
0
3
0 8 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content3
0
3
0 8 0 1
0 9 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content4
0
3
0 8 0 1
0 10 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread4 content1
0
3
0 11 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread4 content2
0
3
0 11 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread4 content3
0
3
0 11 0 1
0 9 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread4 content4
0
3
0 11 0 1
0 10 0 1
0 6 1 0
0
end_operator
begin_oper




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ch 6
check 0
check 0
check 1
29
check 0
check 0
switch 7
check 0
check 0
check 1
45
check 0
check 0
switch 12
check 0
check 0
check 1
61
check 0
check 0
check 0
check 0
switch 9
check 0
switch 1
check 0
check 0
check 1
14
check 0
check 0
switch 6
check 0
check 0
check 1
30
check 0
check 0
switch 7
check 0
check 0
check 1
46
check 0
check 0
switch 12
check 0
check 0
check 1
62
check 0
check 0
check 0
check 0
switch 10
check 0
switch 1
check 0
check 0
check 1
15
check 0
check 0
switch 6
check 0
check 0
check 1
31
check 0
check 0
switch 7
check 0
check 0
check 1
47
check 0
check 0
switch 12
check 0
check 0
check 1
63
check 0
check 0
check 0
check 0
check 0
check 0
check 0
end_SG
begin_DTG
3
1
64
0
2
65
0
3
66
0
3
0
67
0
2
68
0
3
69
0
3
0
70
0
1
71
0
3
72
0
3
0
73
0
1
74
0
2
75
0
end_DTG
begin_DTG
1
2
76
1
0 0
16
0
0
2
2 0
3 0
0
1
2
2 0
4 0
0
2
2
2 0
9 0
0
3
2
2 0
10 0
0
4
2
5 0
3 0
0
5
2
5 0
4 0
0
6
2
5 0
9 0
0
7
2
5 0
10 0
0
8
2
8 0
3 0
0
9
2
8 0
4 0
0
10
2
8 0
9 0
0
11
2
8 0
10 0
0
12
2
11 0
3 0
0
13
2
11 0
4 0
0
14
2
11 0
9 0
0
15
2
11 0
10 0
3
3
80
1
0 1
3
82
1
0 2
3
83
1
0 3
0
end_DTG
begin_DTG
16
1
0
2
3 0
1 1
1
1
2
4 0
1 1
1
2
2
9 0
1 1
1
3
2
10 0
1 1
1
16
2
3 0
6 1
1
17
2
4 0
6 1
1
18
2
9 0
6 1
1
19
2
10 0
6 1
1
32
2
3 0
7 1
1
33
2
4 0
7 1
1
34
2
9 0
7 1
1
35
2
10 0
7 1
1
48
2
3 0
12 1
1
49
2
4 0
12 1
1
50
2
9 0
12 1
1
51
2
10 0
12 1
0
end_DTG
begin_DTG
16
1
0
2
2 0
1 1
1
4
2
5 0
1 1
1
8
2
8 0
1 1
1
12
2
11 0
1 1
1
16
2
2 0
6 1
1
20
2
5 0
6 1
1
24
2
8 0
6 1
1
28
2
11 0
6 1
1
32
2
2 0
7 1
1
36
2
5 0
7 1
1
40
2
8 0
7 1
1
44
2
11 0
7 1
1
48
2
2 0
12 1
1
52
2
5 0
12 1
1
56
2
8 0
12 1
1
60
2
11 0
12 1
0
end_DTG
begin_DTG
16
1
1
2
2 0
1 1
1
5
2
5 0
1 1
1
9
2
8 0
1 1
1
13
2
11 0
1 1
1
17
2
2 0
6 1
1
21
2
5 0
6 1
1
25
2
8 0
6 1
1
29
2
11 0
6 1
1
33
2
2 0
7 1
1
37
2
5 0
7 1
1
41
2
8 0
7 1
1
45
2
11 0
7 1
1
49
2
2 0
12 1
1
53
2
5 0
12 1
1
57
2
8 0
12 1
1
61
2
11 0
12 1
0
end_DTG
begin_DTG
16
1
4
2
3 0
1 1
1
5
2
4 0
1 1
1
6
2
9 0
1 1
1
7
2
10 0
1 1
1
20
2
3 0
6 1
1
21
2
4 0
6 1
1
22
2
9 0
6 1
1
23
2
10 0
6 1
1
36
2
3 0
7 1
1
37
2
4 0
7 1
1
38
2
9 0
7 1
1
39
2
10 0
7 1
1
52
2
3 0
12 1
1
53
2
4 0
12 1
1
54
2
9 0
12 1
1
55
2
10 0
12 1
0
end_DTG
begin_DTG
1
2
77
1
0 0
16
0
16
2
2 0
3 0
0
17
2
2 0
4 0
0
18
2
2 0
9 0
0
19
2
2 0
10 0
0
20
2
5 0
3 0
0
21
2
5 0
4 0
0
22
2
5 0
9 0
0
23
2
5 0
10 0
0
24
2
8 0
3 0
0
25
2
8 0
4 0
0
26
2
8 0
9 0
0
27
2
8 0
10 0
0
28
2
11 0
3 0
0
29
2
11 0
4 0
0
30
2
11 0
9 0
0
31
2
11 0
10 0
3
3
84
1
0 1
3
86
1
0 2
3
87
1
0 3
0
end_DTG
begin_DTG
1
2
78
1
0 0
16
0
32
2
2 0
3 0
0
33
2
2 0
4 0
0
34
2
2 0
9 0
0
35
2
2 0
10 0
0
36
2
5 0
3 0
0
37
2
5 0
4 0
0
38
2
5 0
9 0
0
39
2
5 0
10 0
0
40
2
8 0
3 0
0
41
2
8 0
4 0
0
42
2
8 0
9 0
0
43
2
8 0
10 0
0
44
2
11 0
3 0
0
45
2
11 0
4 0
0
46
2
11 0
9 0
0
47
2
11 0
10 0
3
3
88
1
0 1
3
90
1
0 2
3
91
1
0 3
0
end_DTG
begin_DTG
16
1
8
2
3 0
1 1
1
9
2
4 0
1 1
1
10
2
9 0
1 1
1
11
2
10 0
1 1
1
24
2
3 0
6 1
1
25
2
4 0
6 1
1
26
2
9 0
6 1
1
27
2
10 0
6 1
1
40
2
3 0
7 1
1
41
2
4 0
7 1
1
42
2
9 0
7 1
1
43
2
10 0
7 1
1
56
2
3 0
12 1
1
57
2
4 0
12 1
1
58
2
9 0
12 1
1
59
2
10 0
12 1
0
end_DTG
begin_DTG
16
1
2
2
2 0
1 1
1
6
2
5 0
1 1
1
10
2
8 0
1 1
1
14
2
11 0
1 1
1
18
2
2 0
6 1
1
22
2
5 0
6 1
1
26
2
8 0
6 1
1
30
2
11 0
6 1
1
34
2
2 0
7 1
1
38
2
5 0
7 1
1
42
2
8 0
7 1
1
46
2
11 0
7 1
1
50
2
2 0
12 1
1
54
2
5 0
12 1
1
58
2
8 0
12 1
1
62
2
11 0
12 1
0
end_DTG
begin_DTG
16
1
3
2
2 0
1 1
1
7
2
5 0
1 1
1
11
2
8 0
1 1
1
15
2
11 0
1 1
1
19
2
2 0
6 1
1
23
2
5 0
6 1
1
27
2
8 0
6 1
1
31
2
11 0
6 1
1
35
2
2 0
7 1
1
39
2
5 0
7 1
1
43
2
8 0
7 1
1
47
2
11 0
7 1
1
51
2
2 0
12 1
1
55
2
5 0
12 1
1
59
2
8 0
12 1
1
63
2
11 0
12 1
0
end_DTG
begin_DTG
16
1
12
2
3 0
1 1
1
13
2
4 0
1 1
1
14
2
9 0
1 1
1
15
2
10 0
1 1
1
28
2
3 0
6 1
1
29
2
4 0
6 1
1
30
2
9 0
6 1
1
31
2
10 0
6 1
1
44
2
3 0
7 1
1
45
2
4 0
7 1
1
46
2
9 0
7 1
1
47
2
10 0
7 1
1
60
2
3 0
12 1
1
61
2
4 0
12 1
1
62
2
9 0
12 1
1
63
2
10 0
12 1
0
end_DTG
begin_DTG
1
2
79
1
0 0
16
0
48
2
2 0
3 0
0
49
2
2 0
4 0
0
50
2
2 0
9 0
0
51
2
2 0
10 0
0
52
2
5 0
3 0
0
53
2
5 0
4 0
0
54
2
5 0
9 0
0
55
2
5 0
10 0
0
56
2
8 0
3 0
0
57
2
8 0
4 0
0
58
2
8 0
9 0
0
59
2
8 0
10 0
0
60
2
11 0
3 0
0
61
2
11 0
4 0
0
62
2
11 0
9 0
0
63
2
11 0
10 0
3
3
92
1
0 1
3
94
1
0 2
3
95
1
0 3
0
end_DTG
begin_DTG
0
4
0
83
2
0 3
1 2
0
87
2
0 3
6 2
0
91
2
0 3
7 2
0
95
2
0 3
12 2
end_DTG
begin_DTG
0
4
0
82
2
0 2
1 2
0
86
2
0 2
6 2
0
90
2
0 2
7 2
0
94
2
0 2
12 2
end_DTG
begin_DTG
0
4
0
81
2
0 1
1 2
0
85
2
0 1
6 2
0
89
2
0 1
7 2
0
93
2
0 1
12 2
end_DTG
begin_DTG
0
4
0
80
2
0 1
1 2
0
84
2
0 1
6 2
0
88
2
0 1
7 2
0
92
2
0 1
12 2
end_DTG
begin_CG
8
1 5
6 5
7 5
12 5
16 4
15 4
14 4
13 4
12
2 4
5 4
8 4
11 4
3 4
4 4
9 4
10 4
16 1
15 1
14 1
13 1
8
3 4
4 4
9 4
10 4
1 4
6 4
7 4
12 4
8
2 4
5 4
8 4
11 4
1 4
6 4
7 4
12 4
8
2 4
5 4
8 4
11 4
1 4
6 4
7 4
12 4
8
3 4
4 4
9 4
10 4
1 4
6 4
7 4
12 4
12
2 4
5 4
8 4
11 4
3 4
4 4
9 4
10 4
16 1
15 1
14 1
13 1
12
2 4
5 4
8 4
11 4
3 4
4 4
9 4
10 4
16 1
15 1
14 1
13 1
8
3 4
4 4
9 4
10 4
1 4
6 4
7 4
12 4
8
2 4
5 4
8 4
11 4
1 4
6 4
7 4
12 4
8
2 4
5 4
8 4
11 4
1 4
6 4
7 4
12 4
8
3 4
4 4
9 4
10 4
1 4
6 4
7 4
12 4
12
2 4
5 4
8 4
11 4
3 4
4 4
9 4
10 4
16 1
15 1
14 1
13 1
0
0
0
0
end_CG
