begin_version
3
end_version
begin_metric
0
end_metric
38
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var24
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var25
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var26
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var27
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var28
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var29
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var30
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var31
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var23
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var15
-1
5
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
<none of those>
end_variable
begin_variable
var16
-1
5
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
<none of those>
end_variable
begin_variable
var17
-1
5
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
<none of those>
end_variable
begin_variable
var18
-1
5
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
<none of those>
end_variable
begin_variable
var19
-1
5
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var14
-1
5
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var20
-1
5
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var21
-1
5
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
<none of those>
end_variable
begin_variable
var22
-1
5
Atom at_kitchen_sandwich(sandw9)
Atom notexist(sandw9)
Atom ontray(sandw9, tray1)
Atom ontray(sandw9, tray2)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var35
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_variable
var34
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var33
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var32
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var37
-1
2
Atom served(child6)
NegatedAtom served(child6)
end_variable
begin_variable
var36
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
9
begin_mutex_group
2
10 0
18 1
end_mutex_group
begin_mutex_group
2
2 0
11 1
end_mutex_group
begin_mutex_group
2
3 0
12 1
end_mutex_group
begin_mutex_group
2
4 0
13 1
end_mutex_group
begin_mutex_group
2
5 0
14 1
end_mutex_group
begin_mutex_group
2
6 0
15 1
end_mutex_group
begin_mutex_group
2
7 0
23 1
end_mutex_group
begin_mutex_group
2
8 0
26 1
end_mutex_group
begin_mutex_group
2
9 0
27 1
end_mutex_group
begin_state
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
1
0
0
0
0
1
0
0
1
1
0
0
0
0
1
1
1
1
1
1
end_state
b




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
21 0
23 1
1
242
2
20 0
23 1
1
241
2
17 0
23 1
1
343
2
30 0
14 1
1
350
2
29 0
23 1
1
347
2
30 0
15 1
1
346
2
29 0
15 1
1
342
2
29 0
14 1
1
339
2
30 0
13 1
1
338
2
29 0
13 1
1
335
2
30 0
12 1
1
334
2
29 0
12 1
1
331
2
30 0
11 1
1
330
2
29 0
11 1
1
327
2
30 0
18 1
1
63
2
21 0
11 1
1
101
2
25 0
12 1
1
99
2
21 0
12 1
1
98
2
20 0
12 1
1
97
2
17 0
12 1
1
65
2
25 0
11 1
1
62
2
20 0
11 1
1
61
2
17 0
11 1
1
29
2
25 0
18 1
1
27
2
21 0
18 1
1
26
2
20 0
18 1
1
25
2
17 0
18 1
1
171
2
21 0
14 1
1
209
2
25 0
15 1
1
207
2
21 0
15 1
1
206
2
20 0
15 1
1
205
2
17 0
15 1
1
173
2
25 0
14 1
1
170
2
20 0
14 1
1
169
2
17 0
14 1
1
137
2
25 0
13 1
1
135
2
21 0
13 1
1
134
2
20 0
13 1
1
133
2
17 0
13 1
0
end_DTG
begin_DTG
0
18
0
441
2
0 1
14 3
0
473
2
0 1
27 3
0
472
2
1 1
27 2
0
465
2
0 1
26 3
0
464
2
1 1
26 2
0
457
2
0 1
23 3
0
456
2
1 1
23 2
0
449
2
0 1
15 3
0
448
2
1 1
15 2
0
408
2
1 1
18 2
0
440
2
1 1
14 2
0
433
2
0 1
13 3
0
432
2
1 1
13 2
0
425
2
0 1
12 3
0
424
2
1 1
12 2
0
417
2
0 1
11 3
0
416
2
1 1
11 2
0
409
2
0 1
18 3
end_DTG
begin_DTG
0
18
0
439
2
0 1
14 3
0
471
2
0 1
27 3
0
470
2
1 1
27 2
0
463
2
0 1
26 3
0
462
2
1 1
26 2
0
455
2
0 1
23 3
0
454
2
1 1
23 2
0
447
2
0 1
15 3
0
446
2
1 1
15 2
0
406
2
1 1
18 2
0
438
2
1 1
14 2
0
431
2
0 1
13 3
0
430
2
1 1
13 2
0
423
2
0 1
12 3
0
422
2
1 1
12 2
0
415
2
0 1
11 3
0
414
2
1 1
11 2
0
407
2
0 1
18 3
end_DTG
begin_DTG
0
18
0
437
2
0 1
14 3
0
469
2
0 1
27 3
0
468
2
1 1
27 2
0
461
2
0 1
26 3
0
460
2
1 1
26 2
0
453
2
0 1
23 3
0
452
2
1 1
23 2
0
445
2
0 1
15 3
0
444
2
1 1
15 2
0
404
2
1 1
18 2
0
436
2
1 1
14 2
0
429
2
0 1
13 3
0
428
2
1 1
13 2
0
421
2
0 1
12 3
0
420
2
1 1
12 2
0
413
2
0 1
11 3
0
412
2
1 1
11 2
0
405
2
0 1
18 3
end_DTG
begin_DTG
0
18
0
435
2
0 3
14 3
0
467
2
0 3
27 3
0
466
2
1 3
27 2
0
459
2
0 3
26 3
0
458
2
1 3
26 2
0
451
2
0 3
23 3
0
450
2
1 3
23 2
0
443
2
0 3
15 3
0
442
2
1 3
15 2
0
402
2
1 3
18 2
0
434
2
1 3
14 2
0
427
2
0 3
13 3
0
426
2
1 3
13 2
0
419
2
0 3
12 3
0
418
2
1 3
12 2
0
411
2
0 3
11 3
0
410
2
1 3
11 2
0
403
2
0 3
18 3
end_DTG
begin_DTG
0
18
0
493
3
0 3
14 3
5 0
0
509
3
0 3
27 3
9 0
0
508
3
1 3
27 2
9 0
0
505
3
0 3
26 3
8 0
0
504
3
1 3
26 2
8 0
0
501
3
0 3
23 3
7 0
0
500
3
1 3
23 2
7 0
0
497
3
0 3
15 3
6 0
0
496
3
1 3
15 2
6 0
0
476
3
1 3
18 2
10 0
0
492
3
1 3
14 2
5 0
0
489
3
0 3
13 3
4 0
0
488
3
1 3
13 2
4 0
0
485
3
0 3
12 3
3 0
0
484
3
1 3
12 2
3 0
0
481
3
0 3
11 3
2 0
0
480
3
1 3
11 2
2 0
0
477
3
0 3
18 3
10 0
end_DTG
begin_DTG
0
18
0
491
3
0 2
14 3
5 0
0
507
3
0 2
27 3
9 0
0
506
3
1 2
27 2
9 0
0
503
3
0 2
26 3
8 0
0
502
3
1 2
26 2
8 0
0
499
3
0 2
23 3
7 0
0
498
3
1 2
23 2
7 0
0
495
3
0 2
15 3
6 0
0
494
3
1 2
15 2
6 0
0
474
3
1 2
18 2
10 0
0
490
3
1 2
14 2
5 0
0
487
3
0 2
13 3
4 0
0
486
3
1 2
13 2
4 0
0
483
3
0 2
12 3
3 0
0
482
3
1 2
12 2
3 0
0
479
3
0 2
11 3
2 0
0
478
3
1 2
11 2
2 0
0
475
3
0 2
18 3
10 0
end_DTG
begin_CG
15
18 7
11 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
35 9
34 9
33 9
32 9
37 9
36 9
15
18 7
11 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
35 9
34 9
33 9
32 9
37 9
36 9
3
11 4
37 2
36 2
3
12 4
37 2
36 2
3
13 4
37 2
36 2
3
14 4
37 2
36 2
3
15 4
37 2
36 2
3
23 4
37 2
36 2
3
26 4
37 2
36 2
3
27 4
37 2
36 2
3
18 4
37 2
36 2
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
2 4
35 2
34 2
33 2
32 2
37 2
36 2
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
3 4
35 2
34 2
33 2
32 2
37 2
36 2
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
4 4
35 2
34 2
33 2
32 2
37 2
36 2
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
5 4
35 2
34 2
33 2
32 2
37 2
36 2
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
6 4
35 2
34 2
33 2
32 2
37 2
36 2
15
29 9
17 9
20 9
21 9
30 9
25 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
15
16 9
28 9
19 9
22 9
31 9
24 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
10 4
35 2
34 2
33 2
32 2
37 2
36 2
15
29 9
17 9
20 9
21 9
30 9
25 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
15
16 9
28 9
19 9
22 9
31 9
24 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
15
16 9
28 9
19 9
22 9
31 9
24 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
15
29 9
17 9
20 9
21 9
30 9
25 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
7 4
35 2
34 2
33 2
32 2
37 2
36 2
15
29 9
17 9
20 9
21 9
30 9
25 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
15
16 9
28 9
19 9
22 9
31 9
24 9
18 6
11 6
12 6
13 6
14 6
15 6
23 6
26 6
27 6
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
8 4
35 2
34 2
33 2
32 2
37 2
36 2
19
16 6
28 8
19 6
22 6
31 8
24 6
29 8
17 6
20 6
21 6
30 8
25 6
9 4
35 2
34 2
33 2
32 2
37 2
36 2
24
29 18
17 9
20 9
21 9
30 18
25 9
18 8
11 8
12 8
13 8
14 8
15 8
23 8
26 8
27 8
10 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
24
16 9
28 18
19 9
22 9
31 18
24 9
18 8
11 8
12 8
13 8
14 8
15 8
23 8
26 8
27 8
10 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
24
16 9
28 18
19 9
22 9
31 18
24 9
18 8
11 8
12 8
13 8
14 8
15 8
23 8
26 8
27 8
10 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
24
29 18
17 9
20 9
21 9
30 18
25 9
18 8
11 8
12 8
13 8
14 8
15 8
23 8
26 8
27 8
10 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
0
0
0
0
0
0
end_CG
