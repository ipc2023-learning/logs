begin_version
3
end_version
begin_metric
0
end_metric
46
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var29
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var30
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var31
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var32
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var33
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var34
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var35
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var36
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var37
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var28
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var18
-1
5
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var19
-1
5
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
<none of those>
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var15
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var20
-1
5
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
<none of those>
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_bread(bread8)
NegatedAtom at_kitchen_bread(bread8)
end_variable
begin_variable
var16
-1
2
Atom at_kitchen_content(content7)
NegatedAtom at_kitchen_content(content7)
end_variable
begin_variable
var21
-1
5
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
<none of those>
end_variable
begin_variable
var22
-1
5
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
<none of those>
end_variable
begin_variable
var23
-1
5
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
<none of those>
end_variable
begin_variable
var24
-1
5
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
<none of those>
end_variable
begin_variable
var25
-1
5
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
<none of those>
end_variable
begin_variable
var26
-1
5
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var27
-1
5
Atom at_kitchen_sandwich(sandw9)
Atom notexist(sandw9)
Atom ontray(sandw9, tray1)
Atom ontray(sandw9, tray2)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var14
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var17
-1
2
Atom at_kitchen_content(content8)
NegatedAtom at_kitchen_content(content8)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_bread(bread7)
NegatedAtom at_kitchen_bread(bread7)
end_variable
begin_variable
var45
-1
2
Atom served(child8)
NegatedAtom served(child8)
end_variable
begin_variable
var44
-1
2
Atom served(child7)
NegatedAtom served(child7)
end_variable
begin_variable
var43
-1
2
Atom served(child6)
NegatedAtom served(child6)
end_variable
begin_variable
var42
-1
2
Atom served(child5)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
0
985
3
0 3
27 3
8 0
0
984
3
1 3
27 2
8 0
0
977
3
0 3
26 3
7 0
0
976
3
1 3
26 2
7 0
0
969
3
0 3
25 3
6 0
0
928
3
1 3
14 2
11 0
0
961
3
0 3
24 3
5 0
0
960
3
1 3
24 2
5 0
0
953
3
0 3
23 3
4 0
0
952
3
1 3
23 2
4 0
0
945
3
0 3
20 3
3 0
0
944
3
1 3
20 2
3 0
0
937
3
0 3
17 3
2 0
0
936
3
1 3
17 2
2 0
0
929
3
0 3
14 3
11 0
end_DTG
begin_DTG
0
20
0
966
3
1 3
25 2
6 0
0
999
3
0 3
33 3
10 0
0
998
3
1 3
33 2
10 0
0
991
3
0 3
28 3
9 0
0
990
3
1 3
28 2
9 0
0
983
3
0 3
27 3
8 0
0
982
3
1 3
27 2
8 0
0
975
3
0 3
26 3
7 0
0
974
3
1 3
26 2
7 0
0
967
3
0 3
25 3
6 0
0
926
3
1 3
14 2
11 0
0
959
3
0 3
24 3
5 0
0
958
3
1 3
24 2
5 0
0
951
3
0 3
23 3
4 0
0
950
3
1 3
23 2
4 0
0
943
3
0 3
20 3
3 0
0
942
3
1 3
20 2
3 0
0
935
3
0 3
17 3
2 0
0
934
3
1 3
17 2
2 0
0
927
3
0 3
14 3
11 0
end_DTG
begin_DTG
0
20
0
964
3
1 2
25 2
6 0
0
997
3
0 2
33 3
10 0
0
996
3
1 2
33 2
10 0
0
989
3
0 2
28 3
9 0
0
988
3
1 2
28 2
9 0
0
981
3
0 2
27 3
8 0
0
980
3
1 2
27 2
8 0
0
973
3
0 2
26 3
7 0
0
972
3
1 2
26 2
7 0
0
965
3
0 2
25 3
6 0
0
924
3
1 2
14 2
11 0
0
957
3
0 2
24 3
5 0
0
956
3
1 2
24 2
5 0
0
949
3
0 2
23 3
4 0
0
948
3
1 2
23 2
4 0
0
941
3
0 2
20 3
3 0
0
940
3
1 2
20 2
3 0
0
933
3
0 2
17 3
2 0
0
932
3
1 2
17 2
2 0
0
925
3
0 2
14 3
11 0
end_DTG
begin_CG
18
14 9
17 9
20 9
23 9
24 9
25 9
26 9
27 9
28 9
33 9
45 10
44 10
43 10
42 10
41 10
40 10
39 10
38 10
18
14 9
17 9
20 9
23 9
24 9
25 9
26 9
27 9
28 9
33 9
45 10
44 10
43 10
42 10
41 10
40 10
39 10
38 10
5
17 8
45 2
44 2
43 2
42 2
5
20 8
45 2
44 2
43 2
42 2
5
23 8
45 2
44 2
43 2
42 2
5
24 8
45 2
44 2
43 2
42 2
5
25 8
45 2
44 2
43 2
42 2
5
26 8
45 2
44 2
43 2
42 2
5
27 8
45 2
44 2
43 2
42 2
5
28 8
45 2
44 2
43 2
42 2
5
33 8
45 2
44 2
43 2
42 2
5
14 8
45 2
44 2
43 2
42 2
18
13 10
16 10
30 10
31 10
35 10
19 10
22 10
36 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
18
12 10
15 10
29 10
32 10
18 10
34 10
37 10
21 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
11 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
18
13 10
16 10
30 10
31 10
35 10
19 10
22 10
36 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
18
12 10
15 10
29 10
32 10
18 10
34 10
37 10
21 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
2 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
18
13 10
16 10
30 10
31 10
35 10
19 10
22 10
36 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
18
12 10
15 10
29 10
32 10
18 10
34 10
37 10
21 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
3 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
18
13 10
16 10
30 10
31 10
35 10
19 10
22 10
36 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
18
12 10
15 10
29 10
32 10
18 10
34 10
37 10
21 10
14 8
17 8
20 8
23 8
24 8
25 8
26 8
27 8
28 8
33 8
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
4 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
5 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
6 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
7 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
8 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
9 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
28
13 10
16 10
30 20
31 20
35 20
19 10
22 10
36 20
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
28
12 10
15 10
29 20
32 20
18 10
34 20
37 20
21 10
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
28
12 10
15 10
29 20
32 20
18 10
34 20
37 20
21 10
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
28
13 10
16 10
30 20
31 20
35 20
19 10
22 10
36 20
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
25
12 8
15 8
29 12
32 12
18 8
34 12
37 12
21 8
13 8
16 8
30 12
31 12
35 12
19 8
22 8
36 12
10 16
45 2
44 2
43 2
42 2
41 2
40 2
39 2
38 2
28
13 10
16 10
30 20
31 20
35 20
19 10
22 10
36 20
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
28
12 10
15 10
29 20
32 20
18 10
34 20
37 20
21 10
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
28
12 10
15 10
29 20
32 20
18 10
34 20
37 20
21 10
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
28
13 10
16 10
30 20
31 20
35 20
19 10
22 10
36 20
14 12
17 12
20 12
23 12
24 12
25 12
26 12
27 12
28 12
33 12
11 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
0
0
0
0
0
0
0
0
end_CG
