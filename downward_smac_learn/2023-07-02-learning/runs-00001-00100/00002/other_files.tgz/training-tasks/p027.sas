begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var17
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var18
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var19
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var20
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var16
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var11
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var12
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var13
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var14
-1
4
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var25
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
begin_variable
var23
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var22
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var21
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var24
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
5
begin_mutex_group
2
5 0
8 1
end_mutex_group
begin_mutex_group
2
1 0
11 1
end_mutex_group
begin_mutex_group
2
2 0
14 1
end_mutex_group
begin_mutex_group
2
3 0
17 1
end_mutex_group
begin_mutex_group
2
4 0
18 1
end_mutex_group
begin_state
0
1
1
1
1
1
0
0
1
0
0
1
0
0
1
0
0
1
1
0
0
1
1
1
1
1
end_state
begin_goal
5
21 0
22 0
23 0
24 0
25 0
end_goal
172
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 6 0 1
0 7 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 6 0 1
0 20 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 6 0 1
0 10 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content4
0
3
0 6 0 1
0 13 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content5
0
3
0 6 0 1
0 16 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 19 0 1
0 7 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 19 0 1
0 20 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 19 0 1
0 10 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content4
0
3
0 19 0 1
0 13 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content5
0
3
0 19 0 1
0 16 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 9 0 1
0 7 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 9 0 1
0 20 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 9 0 1
0 10 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content4
0
3
0 9 0 1
0 13 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content5
0
3
0 9 0 1
0 16 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content1
0
3
0 12 0 1
0 7 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content2
0
3
0 12 0 1
0 20 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content3
0
3
0 12 0 1
0 10 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content4
0
3
0 12 0 1
0 13 0 1
0 8 1 0
0
end_opera




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





6 0
17 1
1
73
2
15 0
14 1
1
68
2
12 0
14 1
1
3
2
6 0
8 1
1
58
2
19 0
14 1
1
53
2
6 0
14 1
1
48
2
15 0
11 1
1
43
2
12 0
11 1
1
38
2
9 0
11 1
1
33
2
19 0
11 1
1
28
2
6 0
11 1
1
23
2
15 0
8 1
1
18
2
12 0
8 1
1
13
2
9 0
8 1
1
8
2
19 0
8 1
0
end_DTG
begin_DTG
1
2
144
1
0 0
25
0
63
2
9 0
13 0
0
127
2
19 0
20 0
0
74
2
15 0
16 0
0
73
2
15 0
13 0
0
72
2
15 0
10 0
0
71
2
15 0
20 0
0
70
2
15 0
7 0
0
69
2
12 0
16 0
0
68
2
12 0
13 0
0
67
2
12 0
10 0
0
66
2
12 0
20 0
0
65
2
12 0
7 0
0
64
2
9 0
16 0
0
50
2
6 0
7 0
0
62
2
9 0
10 0
0
61
2
9 0
20 0
0
60
2
9 0
7 0
0
59
2
19 0
16 0
0
58
2
19 0
13 0
0
57
2
19 0
10 0
0
55
2
19 0
7 0
0
54
2
6 0
16 0
0
53
2
6 0
13 0
0
52
2
6 0
10 0
0
51
2
6 0
20 0
3
3
155
1
0 3
3
156
1
0 2
3
158
1
0 1
0
end_DTG
begin_DTG
25
1
72
2
10 0
14 1
1
124
2
16 0
18 1
1
123
2
13 0
18 1
1
122
2
10 0
18 1
1
121
2
20 0
18 1
1
120
2
7 0
18 1
1
99
2
16 0
17 1
1
98
2
13 0
17 1
1
97
2
10 0
17 1
1
96
2
20 0
17 1
1
95
2
7 0
17 1
1
74
2
16 0
14 1
1
73
2
13 0
14 1
1
20
2
7 0
8 1
1
71
2
20 0
14 1
1
70
2
7 0
14 1
1
49
2
16 0
11 1
1
48
2
13 0
11 1
1
47
2
10 0
11 1
1
46
2
20 0
11 1
1
45
2
7 0
11 1
1
24
2
16 0
8 1
1
23
2
13 0
8 1
1
22
2
10 0
8 1
1
21
2
20 0
8 1
0
end_DTG
begin_DTG
25
1
64
2
9 0
14 1
1
124
2
15 0
18 1
1
119
2
12 0
18 1
1
114
2
9 0
18 1
1
109
2
19 0
18 1
1
104
2
6 0
18 1
1
99
2
15 0
17 1
1
94
2
12 0
17 1
1
89
2
9 0
17 1
1
84
2
19 0
17 1
1
79
2
6 0
17 1
1
74
2
15 0
14 1
1
69
2
12 0
14 1
1
4
2
6 0
8 1
1
59
2
19 0
14 1
1
54
2
6 0
14 1
1
49
2
15 0
11 1
1
44
2
12 0
11 1
1
39
2
9 0
11 1
1
34
2
19 0
11 1
1
29
2
6 0
11 1
1
24
2
15 0
8 1
1
19
2
12 0
8 1
1
14
2
9 0
8 1
1
9
2
19 0
8 1
0
end_DTG
begin_DTG
1
2
145
1
0 0
25
0
88
2
9 0
13 0
0
128
2
19 0
20 0
0
99
2
15 0
16 0
0
98
2
15 0
13 0
0
97
2
15 0
10 0
0
96
2
15 0
20 0
0
95
2
15 0
7 0
0
94
2
12 0
16 0
0
93
2
12 0
13 0
0
92
2
12 0
10 0
0
91
2
12 0
20 0
0
90
2
12 0
7 0
0
89
2
9 0
16 0
0
75
2
6 0
7 0
0
87
2
9 0
10 0
0
86
2
9 0
20 0
0
85
2
9 0
7 0
0
84
2
19 0
16 0
0
83
2
19 0
13 0
0
82
2
19 0
10 0
0
80
2
19 0
7 0
0
79
2
6 0
16 0
0
78
2
6 0
13 0
0
77
2
6 0
10 0
0
76
2
6 0
20 0
3
3
159
1
0 3
3
160
1
0 2
3
162
1
0 1
0
end_DTG
begin_DTG
1
2
146
1
0 0
25
0
113
2
9 0
13 0
0
129
2
19 0
20 0
0
124
2
15 0
16 0
0
123
2
15 0
13 0
0
122
2
15 0
10 0
0
121
2
15 0
20 0
0
120
2
15 0
7 0
0
119
2
12 0
16 0
0
118
2
12 0
13 0
0
117
2
12 0
10 0
0
116
2
12 0
20 0
0
115
2
12 0
7 0
0
114
2
9 0
16 0
0
100
2
6 0
7 0
0
112
2
9 0
10 0
0
111
2
9 0
20 0
0
110
2
9 0
7 0
0
109
2
19 0
16 0
0
108
2
19 0
13 0
0
107
2
19 0
10 0
0
105
2
19 0
7 0
0
104
2
6 0
16 0
0
103
2
6 0
13 0
0
102
2
6 0
10 0
0
101
2
6 0
20 0
3
3
163
1
0 3
3
164
1
0 2
3
166
1
0 1
0
end_DTG
begin_DTG
25
1
80
2
7 0
17 1
1
129
2
20 0
18 1
1
128
2
20 0
17 1
1
127
2
20 0
14 1
1
126
2
20 0
11 1
1
125
2
20 0
8 1
1
109
2
16 0
18 1
1
108
2
13 0
18 1
1
107
2
10 0
18 1
1
105
2
7 0
18 1
1
84
2
16 0
17 1
1
83
2
13 0
17 1
1
82
2
10 0
17 1
1
5
2
7 0
8 1
1
59
2
16 0
14 1
1
58
2
13 0
14 1
1
57
2
10 0
14 1
1
55
2
7 0
14 1
1
34
2
16 0
11 1
1
33
2
13 0
11 1
1
32
2
10 0
11 1
1
30
2
7 0
11 1
1
9
2
16 0
8 1
1
8
2
13 0
8 1
1
7
2
10 0
8 1
0
end_DTG
begin_DTG
25
1
76
2
6 0
17 1
1
129
2
19 0
18 1
1
128
2
19 0
17 1
1
127
2
19 0
14 1
1
126
2
19 0
11 1
1
125
2
19 0
8 1
1
121
2
15 0
18 1
1
116
2
12 0
18 1
1
111
2
9 0
18 1
1
101
2
6 0
18 1
1
96
2
15 0
17 1
1
91
2
12 0
17 1
1
86
2
9 0
17 1
1
1
2
6 0
8 1
1
71
2
15 0
14 1
1
66
2
12 0
14 1
1
61
2
9 0
14 1
1
51
2
6 0
14 1
1
46
2
15 0
11 1
1
41
2
12 0
11 1
1
36
2
9 0
11 1
1
26
2
6 0
11 1
1
21
2
15 0
8 1
1
16
2
12 0
8 1
1
11
2
9 0
8 1
0
end_DTG
begin_DTG
0
5
0
150
2
0 1
8 2
0
154
2
0 1
11 2
0
158
2
0 1
14 2
0
162
2
0 1
17 2
0
166
2
0 1
18 2
end_DTG
begin_DTG
0
5
0
149
2
0 3
8 2
0
153
2
0 3
11 2
0
157
2
0 3
14 2
0
161
2
0 3
17 2
0
165
2
0 3
18 2
end_DTG
begin_DTG
0
5
0
148
2
0 2
8 2
0
152
2
0 2
11 2
0
156
2
0 2
14 2
0
160
2
0 2
17 2
0
164
2
0 2
18 2
end_DTG
begin_DTG
0
5
0
147
2
0 3
8 2
0
151
2
0 3
11 2
0
155
2
0 3
14 2
0
159
2
0 3
17 2
0
163
2
0 3
18 2
end_DTG
begin_DTG
0
5
0
167
3
0 2
8 2
5 0
0
168
3
0 2
11 2
1 0
0
169
3
0 2
14 2
2 0
0
170
3
0 2
17 2
3 0
0
171
3
0 2
18 2
4 0
end_DTG
begin_CG
10
8 6
11 6
14 6
17 6
18 6
24 5
23 5
22 5
25 5
21 5
2
11 1
25 1
2
14 1
25 1
2
17 1
25 1
2
18 1
25 1
2
8 1
25 1
10
7 5
20 5
10 5
13 5
16 5
8 5
11 5
14 5
17 5
18 5
10
6 5
19 5
9 5
12 5
15 5
8 5
11 5
14 5
17 5
18 5
16
6 5
19 6
9 5
12 5
15 5
7 5
20 6
10 5
13 5
16 5
5 1
24 1
23 1
22 1
25 1
21 1
10
7 5
20 5
10 5
13 5
16 5
8 5
11 5
14 5
17 5
18 5
10
6 5
19 5
9 5
12 5
15 5
8 5
11 5
14 5
17 5
18 5
16
6 5
19 6
9 5
12 5
15 5
7 5
20 6
10 5
13 5
16 5
1 1
24 1
23 1
22 1
25 1
21 1
10
7 5
20 5
10 5
13 5
16 5
8 5
11 5
14 5
17 5
18 5
10
6 5
19 5
9 5
12 5
15 5
8 5
11 5
14 5
17 5
18 5
16
6 5
19 6
9 5
12 5
15 5
7 5
20 6
10 5
13 5
16 5
2 1
24 1
23 1
22 1
25 1
21 1
10
7 5
20 5
10 5
13 5
16 5
8 5
11 5
14 5
17 5
18 5
10
6 5
19 5
9 5
12 5
15 5
8 5
11 5
14 5
17 5
18 5
16
6 5
19 6
9 5
12 5
15 5
7 5
20 6
10 5
13 5
16 5
3 1
24 1
23 1
22 1
25 1
21 1
16
6 5
19 6
9 5
12 5
15 5
7 5
20 6
10 5
13 5
16 5
4 1
24 1
23 1
22 1
25 1
21 1
15
7 5
20 10
10 5
13 5
16 5
8 6
11 6
14 6
17 6
18 6
5 1
1 1
2 1
3 1
4 1
15
6 5
19 10
9 5
12 5
15 5
8 6
11 6
14 6
17 6
18 6
5 1
1 1
2 1
3 1
4 1
0
0
0
0
0
end_CG
