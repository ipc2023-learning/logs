begin_version
3
end_version
begin_metric
0
end_metric
54
begin_variable
var2
-1
4
Atom at(tray3, kitchen)
Atom at(tray3, table1)
Atom at(tray3, table2)
Atom at(tray3, table3)
end_variable
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var34
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var35
-1
2
Atom no_gluten_sandwich(sandw11)
NegatedAtom no_gluten_sandwich(sandw11)
end_variable
begin_variable
var36
-1
2
Atom no_gluten_sandwich(sandw12)
NegatedAtom no_gluten_sandwich(sandw12)
end_variable
begin_variable
var37
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var38
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var39
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var40
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var41
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var42
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var43
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var44
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var33
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var22
-1
6
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
Atom ontray(sandw10, tray3)
<none of those>
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var15
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var21
-1
6
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
Atom ontray(sandw1, tray3)
<none of those>
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var16
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var17
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_bread(bread8)
NegatedAtom at_kitchen_bread(bread8)
end_variable
begin_variable
var23
-1
6
Atom at_kitchen_sandwich(sandw11)
Atom notexist(sandw11)
Atom ontray(sandw11, tray1)
Atom ontray(sandw11, tray2)
Atom ontray(sandw11, tray3)
<none of those>
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_bread(bread9)
NegatedAtom at_kitchen_bread(bread9)
end_variable
begin_variable
var19
-1
2
Atom at_kitchen_content(content8)
NegatedAtom at_kitchen_content(content8)
end_variable
begin_variable
var24
-1
6
Atom at_kitchen_sandwich(sandw12)
Atom notexist(sandw12)
Atom ontray(sandw12, tray1)
Atom ontray(sandw12, tray2)
Atom ontray(sandw12, tray3)
<none of those>
end_variable
begin_variable
var25
-1
6
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
Atom ontray(sandw2, tray3)
<none of those>
end_variable
begin_variable
var26
-1
6
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
Atom ontray(sandw3, tray3)
<none of those>
end_variable
begin_variable
var27
-1
6
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
Atom ontray(sandw4, tray3)
<none of those>
end_variable
begin_variable
var28
-1
6
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
Atom ontray(sandw5, tray3)
<none of those>
end_variable
begin_variable
var29
-1
6
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
Atom ontray(sandw6, tray3)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
Atom ontray(sandw7, tray3)
<none of those>
end_variable
begin_variable
var31
-1
6
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
Atom ontray(sandw8, tray3)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
va




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




27 10
28 10
29 10
30 10
31 10
32 10
33 10
38 10
48 12
53 12
52 12
51 12
47 12
50 12
46 12
45 12
49 12
6
15 15
53 3
52 3
51 3
50 3
49 3
6
23 15
53 3
52 3
51 3
50 3
49 3
6
26 15
53 3
52 3
51 3
50 3
49 3
6
27 15
53 3
52 3
51 3
50 3
49 3
6
28 15
53 3
52 3
51 3
50 3
49 3
6
29 15
53 3
52 3
51 3
50 3
49 3
6
30 15
53 3
52 3
51 3
50 3
49 3
6
31 15
53 3
52 3
51 3
50 3
49 3
6
32 15
53 3
52 3
51 3
50 3
49 3
6
33 15
53 3
52 3
51 3
50 3
49 3
6
38 15
53 3
52 3
51 3
50 3
49 3
6
18 15
53 3
52 3
51 3
50 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
3 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
21
35 12
36 12
40 12
17 12
20 12
21 12
41 12
25 12
44 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
21
34 12
37 12
16 12
19 12
39 12
42 12
43 12
22 12
24 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
14 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
21
35 12
36 12
40 12
17 12
20 12
21 12
41 12
25 12
44 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
21
34 12
37 12
16 12
19 12
39 12
42 12
43 12
22 12
24 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
21
34 12
37 12
16 12
19 12
39 12
42 12
43 12
22 12
24 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
21
35 12
36 12
40 12
17 12
20 12
21 12
41 12
25 12
44 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
4 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
21
35 12
36 12
40 12
17 12
20 12
21 12
41 12
25 12
44 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
21
34 12
37 12
16 12
19 12
39 12
42 12
43 12
22 12
24 12
18 9
15 9
23 9
26 9
27 9
28 9
29 9
30 9
31 9
32 9
33 9
38 9
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
5 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
6 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
7 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
8 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
9 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
10 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
11 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
12 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
33
35 24
36 24
40 24
17 12
20 12
21 12
41 24
25 12
44 24
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
34 24
37 24
16 12
19 12
39 24
42 24
43 24
22 12
24 12
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
34 24
37 24
16 12
19 12
39 24
42 24
43 24
22 12
24 12
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
35 24
36 24
40 24
17 12
20 12
21 12
41 24
25 12
44 24
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
28
34 14
37 14
16 9
19 9
39 14
42 14
43 14
22 9
24 9
35 14
36 14
40 14
17 9
20 9
21 9
41 14
25 9
44 14
13 25
48 3
53 3
52 3
51 3
47 3
50 3
46 3
45 3
49 3
33
35 24
36 24
40 24
17 12
20 12
21 12
41 24
25 12
44 24
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
34 24
37 24
16 12
19 12
39 24
42 24
43 24
22 12
24 12
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
34 24
37 24
16 12
19 12
39 24
42 24
43 24
22 12
24 12
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
35 24
36 24
40 24
17 12
20 12
21 12
41 24
25 12
44 24
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
35 24
36 24
40 24
17 12
20 12
21 12
41 24
25 12
44 24
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
33
34 24
37 24
16 12
19 12
39 24
42 24
43 24
22 12
24 12
18 14
15 14
23 14
26 14
27 14
28 14
29 14
30 14
31 14
32 14
33 14
38 14
14 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
0
0
0
0
0
0
0
0
0
end_CG
