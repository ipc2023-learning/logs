begin_version
3
end_version
begin_metric
0
end_metric
51
begin_variable
var2
-1
4
Atom at(tray3, kitchen)
Atom at(tray3, table1)
Atom at(tray3, table2)
Atom at(tray3, table3)
end_variable
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var32
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var33
-1
2
Atom no_gluten_sandwich(sandw11)
NegatedAtom no_gluten_sandwich(sandw11)
end_variable
begin_variable
var34
-1
2
Atom no_gluten_sandwich(sandw12)
NegatedAtom no_gluten_sandwich(sandw12)
end_variable
begin_variable
var35
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var36
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var37
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var38
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var39
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var40
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var41
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var42
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var31
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var20
-1
6
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
Atom ontray(sandw10, tray3)
<none of those>
end_variable
begin_variable
var21
-1
6
Atom at_kitchen_sandwich(sandw11)
Atom notexist(sandw11)
Atom ontray(sandw11, tray1)
Atom ontray(sandw11, tray2)
Atom ontray(sandw11, tray3)
<none of those>
end_variable
begin_variable
var22
-1
6
Atom at_kitchen_sandwich(sandw12)
Atom notexist(sandw12)
Atom ontray(sandw12, tray1)
Atom ontray(sandw12, tray2)
Atom ontray(sandw12, tray3)
<none of those>
end_variable
begin_variable
var23
-1
6
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
Atom ontray(sandw2, tray3)
<none of those>
end_variable
begin_variable
var24
-1
6
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
Atom ontray(sandw3, tray3)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_bread(bread7)
NegatedAtom at_kitchen_bread(bread7)
end_variable
begin_variable
var15
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var19
-1
6
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
Atom ontray(sandw1, tray3)
<none of those>
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_bread(bread8)
NegatedAtom at_kitchen_bread(bread8)
end_variable
begin_variable
var16
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var25
-1
6
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
Atom ontray(sandw4, tray3)
<none of those>
end_variable
begin_variable
var26
-1
6
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
Atom ontray(sandw5, tray3)
<none of those>
end_variable
begin_variable
var27
-1
6
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
Atom ontray(sandw6, tray3)
<none of those>
end_variable
begin_variable
var28
-1
6
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
Atom ontray(sandw7, tray3)
<none of those>
end_variable
begin_variable
var29
-1
6
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
Atom ontray(sandw8, tray3)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom at_kitchen_sandwich(sandw9)
Atom notexist(sandw9)
Atom ontray(sandw9, tray1)
Atom ontray(sandw9, tray2)
Atom ontray(sandw9, tray3)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(conte




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




33 4
12 0
0
1308
3
2 1
34 2
13 0
0
1309
3
1 1
34 3
13 0
0
1310
3
0 1
34 4
13 0
0
1212
3
2 1
17 2
5 0
0
1177
3
1 1
26 3
14 0
0
1178
3
0 1
26 4
14 0
0
1188
3
2 1
15 2
3 0
0
1189
3
1 1
15 3
3 0
0
1190
3
0 1
15 4
3 0
0
1200
3
2 1
16 2
4 0
0
1201
3
1 1
16 3
4 0
0
1202
3
0 1
16 4
4 0
0
1176
3
2 1
26 2
14 0
0
1213
3
1 1
17 3
5 0
0
1214
3
0 1
17 4
5 0
0
1224
3
2 1
18 2
6 0
0
1225
3
1 1
18 3
6 0
0
1226
3
0 1
18 4
6 0
0
1236
3
2 1
19 2
7 0
0
1237
3
1 1
19 3
7 0
0
1238
3
0 1
19 4
7 0
end_DTG
begin_CG
20
26 9
15 9
16 9
17 9
18 9
19 9
29 9
30 9
31 9
32 9
33 9
34 9
50 12
46 12
45 12
44 12
49 12
48 12
43 12
47 12
20
26 9
15 9
16 9
17 9
18 9
19 9
29 9
30 9
31 9
32 9
33 9
34 9
50 12
46 12
45 12
44 12
49 12
48 12
43 12
47 12
20
26 9
15 9
16 9
17 9
18 9
19 9
29 9
30 9
31 9
32 9
33 9
34 9
50 12
46 12
45 12
44 12
49 12
48 12
43 12
47 12
5
15 12
50 3
49 3
48 3
47 3
5
16 12
50 3
49 3
48 3
47 3
5
17 12
50 3
49 3
48 3
47 3
5
18 12
50 3
49 3
48 3
47 3
5
19 12
50 3
49 3
48 3
47 3
5
29 12
50 3
49 3
48 3
47 3
5
30 12
50 3
49 3
48 3
47 3
5
31 12
50 3
49 3
48 3
47 3
5
32 12
50 3
49 3
48 3
47 3
5
33 12
50 3
49 3
48 3
47 3
5
34 12
50 3
49 3
48 3
47 3
5
26 12
50 3
49 3
48 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
3 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
4 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
5 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
6 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
7 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
20
21 12
22 12
36 12
37 12
25 12
28 12
40 12
41 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
20
20 12
35 12
38 12
39 12
23 12
42 12
24 12
27 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
20
20 12
35 12
38 12
39 12
23 12
42 12
24 12
27 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
20
21 12
22 12
36 12
37 12
25 12
28 12
40 12
41 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
20
21 12
22 12
36 12
37 12
25 12
28 12
40 12
41 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
20
20 12
35 12
38 12
39 12
23 12
42 12
24 12
27 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
14 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
20
21 12
22 12
36 12
37 12
25 12
28 12
40 12
41 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
20
20 12
35 12
38 12
39 12
23 12
42 12
24 12
27 12
26 8
15 8
16 8
17 8
18 8
19 8
29 8
30 8
31 8
32 8
33 8
34 8
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
8 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
9 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
10 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
11 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
12 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
25
20 8
35 12
38 12
39 12
23 8
42 12
24 8
27 8
21 8
22 8
36 12
37 12
25 8
28 8
40 12
41 12
13 16
50 3
46 3
45 3
44 3
49 3
48 3
43 3
47 3
32
21 12
22 12
36 24
37 24
25 12
28 12
40 24
41 24
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
32
20 12
35 24
38 24
39 24
23 12
42 24
24 12
27 12
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
32
20 12
35 24
38 24
39 24
23 12
42 24
24 12
27 12
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
32
21 12
22 12
36 24
37 24
25 12
28 12
40 24
41 24
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
32
21 12
22 12
36 24
37 24
25 12
28 12
40 24
41 24
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
32
20 12
35 24
38 24
39 24
23 12
42 24
24 12
27 12
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
32
20 12
35 24
38 24
39 24
23 12
42 24
24 12
27 12
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
32
21 12
22 12
36 24
37 24
25 12
28 12
40 24
41 24
26 12
15 12
16 12
17 12
18 12
19 12
29 12
30 12
31 12
32 12
33 12
34 12
14 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
12 4
13 4
0
0
0
0
0
0
0
0
end_CG
