begin_version
3
end_version
begin_metric
0
end_metric
56
begin_variable
var2
-1
4
Atom at(tray3, kitchen)
Atom at(tray3, table1)
Atom at(tray3, table2)
Atom at(tray3, table3)
end_variable
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var35
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var36
-1
2
Atom no_gluten_sandwich(sandw11)
NegatedAtom no_gluten_sandwich(sandw11)
end_variable
begin_variable
var37
-1
2
Atom no_gluten_sandwich(sandw12)
NegatedAtom no_gluten_sandwich(sandw12)
end_variable
begin_variable
var38
-1
2
Atom no_gluten_sandwich(sandw13)
NegatedAtom no_gluten_sandwich(sandw13)
end_variable
begin_variable
var39
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var40
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var41
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var42
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var43
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var44
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var45
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var46
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var34
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var22
-1
6
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
Atom ontray(sandw10, tray3)
<none of those>
end_variable
begin_variable
var23
-1
6
Atom at_kitchen_sandwich(sandw11)
Atom notexist(sandw11)
Atom ontray(sandw11, tray1)
Atom ontray(sandw11, tray2)
Atom ontray(sandw11, tray3)
<none of those>
end_variable
begin_variable
var24
-1
6
Atom at_kitchen_sandwich(sandw12)
Atom notexist(sandw12)
Atom ontray(sandw12, tray1)
Atom ontray(sandw12, tray2)
Atom ontray(sandw12, tray3)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var21
-1
6
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
Atom ontray(sandw1, tray3)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var16
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var25
-1
6
Atom at_kitchen_sandwich(sandw13)
Atom notexist(sandw13)
Atom ontray(sandw13, tray1)
Atom ontray(sandw13, tray2)
Atom ontray(sandw13, tray3)
<none of those>
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_bread(bread7)
NegatedAtom at_kitchen_bread(bread7)
end_variable
begin_variable
var18
-1
2
Atom at_kitchen_content(content7)
NegatedAtom at_kitchen_content(content7)
end_variable
begin_variable
var26
-1
6
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
Atom ontray(sandw2, tray3)
<none of those>
end_variable
begin_variable
var27
-1
6
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
Atom ontray(sandw3, tray3)
<none of those>
end_variable
begin_variable
var28
-1
6
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
Atom ontray(sandw4, tray3)
<none of those>
end_variable
begin_variable
var29
-1
6
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
Atom ontray(sandw5, tray3)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
Atom ontray(sandw6, tray3)
<none of those>
end_variable
begin_variable
var31
-1
6
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
Atom ontray(sandw7, tray3)
<none of those>
end_variable
begin_variable
var32
-1
6
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
Atom ontray(sandw8, tray3)
<none of those>
end_variable
begin_variable
var33
-1
6
Atom at_kitchen_sa




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 15
55 3
54 3
53 3
52 3
51 3
6
33 15
55 3
54 3
53 3
52 3
51 3
6
34 15
55 3
54 3
53 3
52 3
51 3
6
35 15
55 3
54 3
53 3
52 3
51 3
6
36 15
55 3
54 3
53 3
52 3
51 3
6
23 15
55 3
54 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
3 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
4 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
5 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
22
20 13
21 13
38 13
39 13
25 13
42 13
28 13
43 13
46 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
22
37 13
19 13
40 13
22 13
24 13
41 13
27 13
44 13
45 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
22
37 13
19 13
40 13
22 13
24 13
41 13
27 13
44 13
45 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
22
20 13
21 13
38 13
39 13
25 13
42 13
28 13
43 13
46 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
15 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
22
20 13
21 13
38 13
39 13
25 13
42 13
28 13
43 13
46 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
22
37 13
19 13
40 13
22 13
24 13
41 13
27 13
44 13
45 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
6 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
22
20 13
21 13
38 13
39 13
25 13
42 13
28 13
43 13
46 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
22
37 13
19 13
40 13
22 13
24 13
41 13
27 13
44 13
45 13
23 9
16 9
17 9
18 9
26 9
29 9
30 9
31 9
32 9
33 9
34 9
35 9
36 9
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
7 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
8 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
9 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
10 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
11 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
12 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
13 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
28
37 14
19 9
40 14
22 9
24 9
41 14
27 9
44 14
45 14
20 9
21 9
38 14
39 14
25 9
42 14
28 9
43 14
46 14
14 25
55 3
50 3
49 3
48 3
54 3
47 3
53 3
52 3
51 3
35
20 13
21 13
38 26
39 26
25 13
42 26
28 13
43 26
46 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
37 26
19 13
40 26
22 13
24 13
41 26
27 13
44 26
45 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
37 26
19 13
40 26
22 13
24 13
41 26
27 13
44 26
45 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
20 13
21 13
38 26
39 26
25 13
42 26
28 13
43 26
46 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
20 13
21 13
38 26
39 26
25 13
42 26
28 13
43 26
46 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
37 26
19 13
40 26
22 13
24 13
41 26
27 13
44 26
45 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
37 26
19 13
40 26
22 13
24 13
41 26
27 13
44 26
45 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
20 13
21 13
38 26
39 26
25 13
42 26
28 13
43 26
46 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
20 13
21 13
38 26
39 26
25 13
42 26
28 13
43 26
46 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
35
37 26
19 13
40 26
22 13
24 13
41 26
27 13
44 26
45 26
23 14
16 14
17 14
18 14
26 14
29 14
30 14
31 14
32 14
33 14
34 14
35 14
36 14
15 5
3 5
4 5
5 5
6 5
7 5
8 5
9 5
10 5
11 5
12 5
13 5
14 5
0
0
0
0
0
0
0
0
0
end_CG
