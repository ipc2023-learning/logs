begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var0
-1
3
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
end_variable
begin_variable
var5
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var6
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var10
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var9
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
0
begin_state
0
1
0
0
0
0
1
1
1
end_state
begin_goal
2
7 0
8 0
end_goal
28
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 2 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 2 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 5 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 5 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content1
0
3
0 2 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content2
0
3
0 2 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content1
0
3
0 5 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content2
0
3
0 5 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw1 bread1 content1
0
3
0 2 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw1 bread1 content2
0
3
0 2 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw1 bread2 content1
0
3
0 5 0 1
0 3 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw1 bread2 content2
0
3
0 5 0 1
0 4 0 1
0 1 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw2 bread1 content1
0
3
0 2 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw2 bread1 content2
0
3
0 2 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw2 bread2 content1
0
3
0 5 0 1
0 3 0 1
0 6 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw2 bread2 content2
0
3
0 5 0 1
0 4 0 1
0 6 1 0
0
end_operator
begin_operator
move_tray tray1 kitchen table1
0
1
0 0 0 1
0
end_operator
begin_operator
move_tray tray1 kitchen table2
0
1
0 0 0 2
0
end_operator
begin_operator
move_tray tray1 table1 kitchen
0
1
0 0 1 0
0
end_operator
begin_operator
move_tray tray1 table1 table2
0
1
0 0 1 2
0
end_operator
begin_operator
move_tray tray1 table2 kitchen
0
1
0 0 2 0
0
end_operator
begin_operator
move_tray tray1 table2 table1
0
1
0 0 2 1
0
end_operator
begin_operator
put_on_tray sandw1 tray1
1
0 0
1
0 1 0 2
0
end_operator
begin_operator
put_on_tray sandw2 tray1
1
0 0
1
0 6 0 2
0
end_operator
begin_operator
serve_sandwich sandw1 child1 tray1 table2
1
0 2
2
0 1 2 3
0 8 -1 0
0
end_operator
begin_operator
serve_sandwich sandw1 child2 tray1 table1
1
0 1
2
0 1 2 3
0 7 -1 0
0
end_operator
begin_operator
serve_sandwich sandw2 child1 tray1 table2
1
0 2
2
0 6 2 3
0 8 -1 0
0
end_operator
begin_operator
serve_sandwich sandw2 child2 tray1 table1
1
0 1
2
0 6 2 3
0 7 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 2
check 2
16
17
check 0
check 0
switch 1
check 0
check 1
22
check 0
check 0
check 0
switch 6
check 0
check 1
23
check 0
check 0
check 0
check 0
switch 2
check 2
18
19
check 0
check 0
switch 1
check 0
check 0
check 0
check 1
25
check 0
switch 6
check 0
check 0
check 0
check 1
27
check 0
check 0
switch 2
check 2
20
21
check 0
check 0
switch 1
check 0
check 0
check 0
check 1
24
check 0
switch 6
check 0
check 0
check 0
check 1
26
check 0
check 0
switch 2
check 0
switch 3
check 0
switch 1
check 0
check 0
check 2
0
8
check 0
check 0
switch 6
check 0
check 0
check 2
4
12
check 0
check 0
check 0
check 0
switch 4
check 0
switch 1
check 0
check 0
check 2
1
9
check 0
check 0
switch 6
check 0
check 0
check 2
5
13
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 3
check 0
switch 1
check 0
check 0
check 2
2
10
check 0
check 0
switch 6
check 0
check 0
check 2
6
14
check 0
check 0
check 0
check 0
switch 4
check 0
switch 1
check 0
check 0
check 2
3
11
check 0
check 0
switch 6
check 0
check 0
check 2
7
15
check 0
check 0
check 0
check 0
check 0
check 0
check 0
end_SG
begin_DTG
2
1
16
0
2
17
0
2
0
18
0
2
19
0
2
0
20
0
1
21
0
end_DTG
begin_DTG
1
2
22
1
0 0
4
0
0
2
2 0
3 0
0
1
2
2 0
4 0
0
2
2
5 0
3 0
0
3
2
5 0
4 0
2
3
24
1
0 2
3
25
1
0 1
0
end_DTG
begin_DTG
4
1
0
2
3 0
1 1
1
1
2
4 0
1 1
1
4
2
3 0
6 1
1
5
2
4 0
6 1
0
end_DTG
begin_DTG
4
1
0
2
2 0
1 1
1
2
2
5 0
1 1
1
4
2
2 0
6 1
1
6
2
5 0
6 1
0
end_DTG
begin_DTG
4
1
1
2
2 0
1 1
1
3
2
5 0
1 1
1
5
2
2 0
6 1
1
7
2
5 0
6 1
0
end_DTG
begin_DTG
4
1
2
2
3 0
1 1
1
3
2
4 0
1 1
1
6
2
3 0
6 1
1
7
2
4 0
6 1
0
end_DTG
begin_DTG
1
2
23
1
0 0
4
0
4
2
2 0
3 0
0
5
2
2 0
4 0
0
6
2
5 0
3 0
0
7
2
5 0
4 0
2
3
26
1
0 2
3
27
1
0 1
0
end_DTG
begin_DTG
0
2
0
25
2
0 1
1 2
0
27
2
0 1
6 2
end_DTG
begin_DTG
0
2
0
24
2
0 2
1 2
0
26
2
0 2
6 2
end_DTG
begin_CG
4
1 3
6 3
8 2
7 2
6
2 4
5 4
3 4
4 4
8 1
7 1
4
3 4
4 4
1 4
6 4
4
2 4
5 4
1 4
6 4
4
2 4
5 4
1 4
6 4
4
3 4
4 4
1 4
6 4
6
2 4
5 4
3 4
4 4
8 1
7 1
0
0
end_CG
