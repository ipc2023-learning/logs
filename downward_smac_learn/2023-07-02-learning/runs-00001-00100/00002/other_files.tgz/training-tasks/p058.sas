begin_version
3
end_version
begin_metric
0
end_metric
43
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var27
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var28
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var29
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var30
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var31
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var32
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var33
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var34
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var35
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var26
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var17
-1
5
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
<none of those>
end_variable
begin_variable
var18
-1
5
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
<none of those>
end_variable
begin_variable
var19
-1
5
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
<none of those>
end_variable
begin_variable
var20
-1
5
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var16
-1
5
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
<none of those>
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var21
-1
5
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var14
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var22
-1
5
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
<none of those>
end_variable
begin_variable
var23
-1
5
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
<none of those>
end_variable
begin_variable
var24
-1
5
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
<none of those>
end_variable
begin_variable
var25
-1
5
Atom at_kitchen_sandwich(sandw9)
Atom notexist(sandw9)
Atom ontray(sandw9, tray1)
Atom ontray(sandw9, tray2)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_bread(bread7)
NegatedAtom at_kitchen_bread(bread7)
end_variable
begin_variable
var15
-1
2
Atom at_kitchen_content(content7)
NegatedAtom at_kitchen_content(content7)
end_variable
begin_variable
var42
-1
2
Atom served(child7)
NegatedAtom served(child7)
end_variable
begin_variable
var41
-1
2
Atom served(child6)
NegatedAtom served(child6)
end_variable
begin_variable
var37
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var36
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var40
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
begin_variable
var39
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_v




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 1
15 3
0
658
2
1 1
15 2
0
651
2
0 1
14 3
0
650
2
1 1
14 2
0
643
2
0 1
13 3
0
642
2
1 1
13 2
0
635
2
0 1
12 3
0
634
2
1 1
12 2
0
627
2
0 1
20 3
end_DTG
begin_DTG
0
20
0
664
2
1 1
23 2
0
697
2
0 1
29 3
0
696
2
1 1
29 2
0
689
2
0 1
28 3
0
688
2
1 1
28 2
0
681
2
0 1
27 3
0
680
2
1 1
27 2
0
673
2
0 1
26 3
0
672
2
1 1
26 2
0
665
2
0 1
23 3
0
624
2
1 1
20 2
0
657
2
0 1
15 3
0
656
2
1 1
15 2
0
649
2
0 1
14 3
0
648
2
1 1
14 2
0
641
2
0 1
13 3
0
640
2
1 1
13 2
0
633
2
0 1
12 3
0
632
2
1 1
12 2
0
625
2
0 1
20 3
end_DTG
begin_DTG
0
20
0
738
3
1 2
23 2
6 0
0
763
3
0 2
29 3
10 0
0
762
3
1 2
29 2
10 0
0
757
3
0 2
28 3
9 0
0
756
3
1 2
28 2
9 0
0
751
3
0 2
27 3
8 0
0
750
3
1 2
27 2
8 0
0
745
3
0 2
26 3
7 0
0
744
3
1 2
26 2
7 0
0
739
3
0 2
23 3
6 0
0
708
3
1 2
20 2
11 0
0
733
3
0 2
15 3
5 0
0
732
3
1 2
15 2
5 0
0
727
3
0 2
14 3
4 0
0
726
3
1 2
14 2
4 0
0
721
3
0 2
13 3
3 0
0
720
3
1 2
13 2
3 0
0
715
3
0 2
12 3
2 0
0
714
3
1 2
12 2
2 0
0
709
3
0 2
20 3
11 0
end_DTG
begin_DTG
0
20
0
736
3
1 3
23 2
6 0
0
761
3
0 3
29 3
10 0
0
760
3
1 3
29 2
10 0
0
755
3
0 3
28 3
9 0
0
754
3
1 3
28 2
9 0
0
749
3
0 3
27 3
8 0
0
748
3
1 3
27 2
8 0
0
743
3
0 3
26 3
7 0
0
742
3
1 3
26 2
7 0
0
737
3
0 3
23 3
6 0
0
706
3
1 3
20 2
11 0
0
731
3
0 3
15 3
5 0
0
730
3
1 3
15 2
5 0
0
725
3
0 3
14 3
4 0
0
724
3
1 3
14 2
4 0
0
719
3
0 3
13 3
3 0
0
718
3
1 3
13 2
3 0
0
713
3
0 3
12 3
2 0
0
712
3
1 3
12 2
2 0
0
707
3
0 3
20 3
11 0
end_DTG
begin_DTG
0
20
0
734
3
1 1
23 2
6 0
0
759
3
0 1
29 3
10 0
0
758
3
1 1
29 2
10 0
0
753
3
0 1
28 3
9 0
0
752
3
1 1
28 2
9 0
0
747
3
0 1
27 3
8 0
0
746
3
1 1
27 2
8 0
0
741
3
0 1
26 3
7 0
0
740
3
1 1
26 2
7 0
0
735
3
0 1
23 3
6 0
0
704
3
1 1
20 2
11 0
0
729
3
0 1
15 3
5 0
0
728
3
1 1
15 2
5 0
0
723
3
0 1
14 3
4 0
0
722
3
1 1
14 2
4 0
0
717
3
0 1
13 3
3 0
0
716
3
1 1
13 2
3 0
0
711
3
0 1
12 3
2 0
0
710
3
1 1
12 2
2 0
0
705
3
0 1
20 3
11 0
end_DTG
begin_CG
17
20 8
12 8
13 8
14 8
15 8
23 8
26 8
27 8
28 8
29 8
39 10
38 10
42 10
41 10
40 10
37 10
36 10
17
20 8
12 8
13 8
14 8
15 8
23 8
26 8
27 8
28 8
29 8
39 10
38 10
42 10
41 10
40 10
37 10
36 10
4
12 6
42 2
41 2
40 2
4
13 6
42 2
41 2
40 2
4
14 6
42 2
41 2
40 2
4
15 6
42 2
41 2
40 2
4
23 6
42 2
41 2
40 2
4
26 6
42 2
41 2
40 2
4
27 6
42 2
41 2
40 2
4
28 6
42 2
41 2
40 2
4
29 6
42 2
41 2
40 2
4
20 6
42 2
41 2
40 2
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
2 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
3 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
4 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
5 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
17
17 10
31 10
18 10
22 10
32 10
25 10
35 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
17
16 10
30 10
19 10
33 10
21 10
24 10
34 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
17
16 10
30 10
19 10
33 10
21 10
24 10
34 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
17
17 10
31 10
18 10
22 10
32 10
25 10
35 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
11 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
17
17 10
31 10
18 10
22 10
32 10
25 10
35 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
17
16 10
30 10
19 10
33 10
21 10
24 10
34 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
6 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
17
17 10
31 10
18 10
22 10
32 10
25 10
35 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
17
16 10
30 10
19 10
33 10
21 10
24 10
34 10
20 7
12 7
13 7
14 7
15 7
23 7
26 7
27 7
28 7
29 7
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
7 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
8 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
9 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
22
16 7
30 10
19 7
33 10
21 7
24 7
34 10
17 7
31 10
18 7
22 7
32 10
25 7
35 10
10 9
39 2
38 2
42 2
41 2
40 2
37 2
36 2
27
17 10
31 20
18 10
22 10
32 20
25 10
35 20
20 10
12 10
13 10
14 10
15 10
23 10
26 10
27 10
28 10
29 10
11 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
10 3
27
16 10
30 20
19 10
33 20
21 10
24 10
34 20
20 10
12 10
13 10
14 10
15 10
23 10
26 10
27 10
28 10
29 10
11 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
10 3
27
16 10
30 20
19 10
33 20
21 10
24 10
34 20
20 10
12 10
13 10
14 10
15 10
23 10
26 10
27 10
28 10
29 10
11 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
10 3
27
17 10
31 20
18 10
22 10
32 20
25 10
35 20
20 10
12 10
13 10
14 10
15 10
23 10
26 10
27 10
28 10
29 10
11 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
10 3
27
17 10
31 20
18 10
22 10
32 20
25 10
35 20
20 10
12 10
13 10
14 10
15 10
23 10
26 10
27 10
28 10
29 10
11 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
10 3
27
16 10
30 20
19 10
33 20
21 10
24 10
34 20
20 10
12 10
13 10
14 10
15 10
23 10
26 10
27 10
28 10
29 10
11 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
10 3
0
0
0
0
0
0
0
end_CG
