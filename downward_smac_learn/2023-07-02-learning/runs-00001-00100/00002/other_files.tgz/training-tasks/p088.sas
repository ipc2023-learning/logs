begin_version
3
end_version
begin_metric
0
end_metric
61
begin_variable
var2
-1
4
Atom at(tray3, kitchen)
Atom at(tray3, table1)
Atom at(tray3, table2)
Atom at(tray3, table3)
end_variable
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var38
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var39
-1
2
Atom no_gluten_sandwich(sandw11)
NegatedAtom no_gluten_sandwich(sandw11)
end_variable
begin_variable
var40
-1
2
Atom no_gluten_sandwich(sandw12)
NegatedAtom no_gluten_sandwich(sandw12)
end_variable
begin_variable
var41
-1
2
Atom no_gluten_sandwich(sandw13)
NegatedAtom no_gluten_sandwich(sandw13)
end_variable
begin_variable
var42
-1
2
Atom no_gluten_sandwich(sandw14)
NegatedAtom no_gluten_sandwich(sandw14)
end_variable
begin_variable
var43
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var44
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var45
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var46
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var47
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var48
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var49
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var50
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var37
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var24
-1
6
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
Atom ontray(sandw10, tray3)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread10)
NegatedAtom at_kitchen_bread(bread10)
end_variable
begin_variable
var15
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var23
-1
6
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
Atom ontray(sandw1, tray3)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var16
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var17
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var25
-1
6
Atom at_kitchen_sandwich(sandw11)
Atom notexist(sandw11)
Atom ontray(sandw11, tray1)
Atom ontray(sandw11, tray2)
Atom ontray(sandw11, tray3)
<none of those>
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_bread(bread9)
NegatedAtom at_kitchen_bread(bread9)
end_variable
begin_variable
var20
-1
2
Atom at_kitchen_content(content7)
NegatedAtom at_kitchen_content(content7)
end_variable
begin_variable
var26
-1
6
Atom at_kitchen_sandwich(sandw12)
Atom notexist(sandw12)
Atom ontray(sandw12, tray1)
Atom ontray(sandw12, tray2)
Atom ontray(sandw12, tray3)
<none of those>
end_variable
begin_variable
var27
-1
6
Atom at_kitchen_sandwich(sandw13)
Atom notexist(sandw13)
Atom ontray(sandw13, tray1)
Atom ontray(sandw13, tray2)
Atom ontray(sandw13, tray3)
<none of those>
end_variable
begin_variable
var28
-1
6
Atom at_kitchen_sandwich(sandw14)
Atom notexist(sandw14)
Atom ontray(sandw14, tray1)
Atom ontray(sandw14, tray2)
Atom ontray(sandw14, tray3)
<none of those>
end_variable
begin_variable
var29
-1
6
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
Atom ontray(sandw2, tray3)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
Atom ontray(sandw3, tray3)
<none of those>
end_variable
begin_variable
var31
-1
6
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
Atom ontray(sandw4, tray3)
<none of those>
end_variable
begin_variable
var32
-1
6
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
Atom ontray(sandw5, tray3)
<none of those>
end_variable
begin_variable
var33
-1
6
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
Atom ontray(sandw6, tray3)
<none of those>
end_variable
begin_variable
var34
-1
6
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom on




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 14
19 14
22 14
23 14
43 14
46 14
27 14
47 14
50 14
20 10
17 10
25 10
28 10
29 10
30 10
31 10
32 10
33 10
34 10
35 10
36 10
37 10
44 10
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
4 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
24
39 14
40 14
19 14
22 14
23 14
43 14
46 14
27 14
47 14
50 14
20 10
17 10
25 10
28 10
29 10
30 10
31 10
32 10
33 10
34 10
35 10
36 10
37 10
44 10
24
38 14
18 14
41 14
42 14
21 14
45 14
24 14
48 14
49 14
26 14
20 10
17 10
25 10
28 10
29 10
30 10
31 10
32 10
33 10
34 10
35 10
36 10
37 10
44 10
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
5 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
6 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
7 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
8 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
9 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
10 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
11 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
12 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
13 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
14 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
38
39 28
40 28
19 14
22 14
23 14
43 28
46 28
27 14
47 28
50 28
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
38 28
18 14
41 28
42 28
21 14
45 28
24 14
48 28
49 28
26 14
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
38 28
18 14
41 28
42 28
21 14
45 28
24 14
48 28
49 28
26 14
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
39 28
40 28
19 14
22 14
23 14
43 28
46 28
27 14
47 28
50 28
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
39 28
40 28
19 14
22 14
23 14
43 28
46 28
27 14
47 28
50 28
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
38 28
18 14
41 28
42 28
21 14
45 28
24 14
48 28
49 28
26 14
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
31
38 16
18 10
41 16
42 16
21 10
45 16
24 10
48 16
49 16
26 10
39 16
40 16
19 10
22 10
23 10
43 16
46 16
27 10
47 16
50 16
15 36
60 3
59 3
54 3
53 3
52 3
58 3
57 3
56 3
55 3
51 3
38
39 28
40 28
19 14
22 14
23 14
43 28
46 28
27 14
47 28
50 28
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
38 28
18 14
41 28
42 28
21 14
45 28
24 14
48 28
49 28
26 14
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
38 28
18 14
41 28
42 28
21 14
45 28
24 14
48 28
49 28
26 14
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
39 28
40 28
19 14
22 14
23 14
43 28
46 28
27 14
47 28
50 28
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
39 28
40 28
19 14
22 14
23 14
43 28
46 28
27 14
47 28
50 28
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
38
38 28
18 14
41 28
42 28
21 14
45 28
24 14
48 28
49 28
26 14
20 16
17 16
25 16
28 16
29 16
30 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
44 16
16 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
0
0
0
0
0
0
0
0
0
0
end_CG
