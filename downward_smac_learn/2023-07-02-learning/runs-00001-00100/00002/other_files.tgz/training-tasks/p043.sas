begin_version
3
end_version
begin_metric
0
end_metric
36
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var23
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var24
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var25
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var26
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var27
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var28
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var29
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var22
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var15
-1
5
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
<none of those>
end_variable
begin_variable
var16
-1
5
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
<none of those>
end_variable
begin_variable
var17
-1
5
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var14
-1
5
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var18
-1
5
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var19
-1
5
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
<none of those>
end_variable
begin_variable
var20
-1
5
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
<none of those>
end_variable
begin_variable
var21
-1
5
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var34
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
begin_variable
var33
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_variable
var31
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var30
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var35
-1
2
Atom served(child6)
NegatedAtom served(child6)
end_variable
begin_variable
var32
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
8
begin_mutex_group
2
9 0
15 1
end_mutex_group
begin_mutex_group
2
2 0
10 1
end_mutex_group
begin_mutex_group
2
3 0
11 1
end_mutex_group
begin_mutex_group
2
4 0
12 1
end_mutex_group
begin_mutex_group
2
5 0
20 1
end_mutex_group
begin_mutex_group
2
6 0
23 1
end_mutex_group
begin_mutex_group
2
7 0
24 1
end_mutex_group
begin_mutex_group
2
8 0
25 1
end_mutex_group
begin_state
0
0
1
1
1
1
1
1
1
1
1
1
1
0
0
1
0
0
0
0
1
0
0
1
1
1
0
0
0
0
1
1
1
1
1
1
end_state
begin_goal
6
30 0
31 0
32 0
33 0
34 0
35 0
end_goal
456
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 26 0 1
0 27 0 1
0 15 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 26 0 1
0 14 0 1
0 15 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 26 0 1
0 17 0 1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
10 1
1
70
2
21 0
10 1
1
82
2
13 0
11 1
1
88
2
16 0
11 1
1
106
2
21 0
11 1
1
118
2
13 0
12 1
1
124
2
16 0
12 1
1
136
2
19 0
12 1
1
142
2
21 0
12 1
1
154
2
13 0
20 1
1
160
2
16 0
20 1
1
172
2
19 0
20 1
1
178
2
21 0
20 1
1
190
2
13 0
23 1
0
end_DTG
begin_DTG
48
1
290
2
27 0
15 1
1
201
2
18 0
23 1
1
202
2
28 0
23 1
1
203
2
22 0
23 1
1
234
2
27 0
24 1
1
235
2
14 0
24 1
1
236
2
17 0
24 1
1
237
2
18 0
24 1
1
238
2
28 0
24 1
1
239
2
22 0
24 1
1
270
2
27 0
25 1
1
271
2
14 0
25 1
1
272
2
17 0
25 1
1
273
2
18 0
25 1
1
274
2
28 0
25 1
1
275
2
22 0
25 1
1
200
2
17 0
23 1
1
291
2
28 0
15 1
1
294
2
27 0
10 1
1
295
2
28 0
10 1
1
298
2
27 0
11 1
1
299
2
28 0
11 1
1
302
2
27 0
12 1
1
303
2
28 0
12 1
1
306
2
27 0
20 1
1
307
2
28 0
20 1
1
310
2
27 0
23 1
1
19
2
14 0
15 1
1
20
2
17 0
15 1
1
21
2
18 0
15 1
1
23
2
22 0
15 1
1
55
2
14 0
10 1
1
56
2
17 0
10 1
1
57
2
18 0
10 1
1
59
2
22 0
10 1
1
91
2
14 0
11 1
1
92
2
17 0
11 1
1
93
2
18 0
11 1
1
95
2
22 0
11 1
1
127
2
14 0
12 1
1
128
2
17 0
12 1
1
129
2
18 0
12 1
1
131
2
22 0
12 1
1
163
2
14 0
20 1
1
164
2
17 0
20 1
1
165
2
18 0
20 1
1
167
2
22 0
20 1
1
199
2
14 0
23 1
0
end_DTG
begin_DTG
0
16
0
366
2
1 2
15 2
0
367
2
0 2
15 3
0
374
2
1 2
10 2
0
375
2
0 2
10 3
0
382
2
1 2
11 2
0
383
2
0 2
11 3
0
390
2
1 2
12 2
0
391
2
0 2
12 3
0
398
2
1 2
20 2
0
399
2
0 2
20 3
0
406
2
1 2
23 2
0
407
2
0 2
23 3
0
414
2
1 2
24 2
0
415
2
0 2
24 3
0
422
2
1 2
25 2
0
423
2
0 2
25 3
end_DTG
begin_DTG
0
16
0
364
2
1 2
15 2
0
365
2
0 2
15 3
0
372
2
1 2
10 2
0
373
2
0 2
10 3
0
380
2
1 2
11 2
0
381
2
0 2
11 3
0
388
2
1 2
12 2
0
389
2
0 2
12 3
0
396
2
1 2
20 2
0
397
2
0 2
20 3
0
404
2
1 2
23 2
0
405
2
0 2
23 3
0
412
2
1 2
24 2
0
413
2
0 2
24 3
0
420
2
1 2
25 2
0
421
2
0 2
25 3
end_DTG
begin_DTG
0
16
0
362
2
1 1
15 2
0
363
2
0 1
15 3
0
370
2
1 1
10 2
0
371
2
0 1
10 3
0
378
2
1 1
11 2
0
379
2
0 1
11 3
0
386
2
1 1
12 2
0
387
2
0 1
12 3
0
394
2
1 1
20 2
0
395
2
0 1
20 3
0
402
2
1 1
23 2
0
403
2
0 1
23 3
0
410
2
1 1
24 2
0
411
2
0 1
24 3
0
418
2
1 1
25 2
0
419
2
0 1
25 3
end_DTG
begin_DTG
0
16
0
360
2
1 1
15 2
0
361
2
0 1
15 3
0
368
2
1 1
10 2
0
369
2
0 1
10 3
0
376
2
1 1
11 2
0
377
2
0 1
11 3
0
384
2
1 1
12 2
0
385
2
0 1
12 3
0
392
2
1 1
20 2
0
393
2
0 1
20 3
0
400
2
1 1
23 2
0
401
2
0 1
23 3
0
408
2
1 1
24 2
0
409
2
0 1
24 3
0
416
2
1 1
25 2
0
417
2
0 1
25 3
end_DTG
begin_DTG
0
16
0
426
3
1 3
15 2
9 0
0
427
3
0 3
15 3
9 0
0
430
3
1 3
10 2
2 0
0
431
3
0 3
10 3
2 0
0
434
3
1 3
11 2
3 0
0
435
3
0 3
11 3
3 0
0
438
3
1 3
12 2
4 0
0
439
3
0 3
12 3
4 0
0
442
3
1 3
20 2
5 0
0
443
3
0 3
20 3
5 0
0
446
3
1 3
23 2
6 0
0
447
3
0 3
23 3
6 0
0
450
3
1 3
24 2
7 0
0
451
3
0 3
24 3
7 0
0
454
3
1 3
25 2
8 0
0
455
3
0 3
25 3
8 0
end_DTG
begin_DTG
0
16
0
424
3
1 1
15 2
9 0
0
425
3
0 1
15 3
9 0
0
428
3
1 1
10 2
2 0
0
429
3
0 1
10 3
2 0
0
432
3
1 1
11 2
3 0
0
433
3
0 1
11 3
3 0
0
436
3
1 1
12 2
4 0
0
437
3
0 1
12 3
4 0
0
440
3
1 1
20 2
5 0
0
441
3
0 1
20 3
5 0
0
444
3
1 1
23 2
6 0
0
445
3
0 1
23 3
6 0
0
448
3
1 1
24 2
7 0
0
449
3
0 1
24 3
7 0
0
452
3
1 1
25 2
8 0
0
453
3
0 1
25 3
8 0
end_DTG
begin_CG
14
15 7
10 7
11 7
12 7
20 7
23 7
24 7
25 7
33 8
32 8
35 8
31 8
30 8
34 8
14
15 7
10 7
11 7
12 7
20 7
23 7
24 7
25 7
33 8
32 8
35 8
31 8
30 8
34 8
3
10 4
35 2
34 2
3
11 4
35 2
34 2
3
12 4
35 2
34 2
3
20 4
35 2
34 2
3
23 4
35 2
34 2
3
24 4
35 2
34 2
3
25 4
35 2
34 2
3
15 4
35 2
34 2
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
2 4
33 2
32 2
35 2
31 2
30 2
34 2
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
3 4
33 2
32 2
35 2
31 2
30 2
34 2
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
4 4
33 2
32 2
35 2
31 2
30 2
34 2
14
27 8
14 8
17 8
18 8
28 8
22 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
14
26 8
13 8
16 8
29 8
19 8
21 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
9 4
33 2
32 2
35 2
31 2
30 2
34 2
14
27 8
14 8
17 8
18 8
28 8
22 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
14
26 8
13 8
16 8
29 8
19 8
21 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
14
26 8
13 8
16 8
29 8
19 8
21 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
14
27 8
14 8
17 8
18 8
28 8
22 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
5 4
33 2
32 2
35 2
31 2
30 2
34 2
14
27 8
14 8
17 8
18 8
28 8
22 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
14
26 8
13 8
16 8
29 8
19 8
21 8
15 6
10 6
11 6
12 6
20 6
23 6
24 6
25 6
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
6 4
33 2
32 2
35 2
31 2
30 2
34 2
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
7 4
33 2
32 2
35 2
31 2
30 2
34 2
19
26 8
13 6
16 6
29 8
19 6
21 6
27 8
14 6
17 6
18 6
28 8
22 6
8 4
33 2
32 2
35 2
31 2
30 2
34 2
22
27 16
14 8
17 8
18 8
28 16
22 8
15 8
10 8
11 8
12 8
20 8
23 8
24 8
25 8
9 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22
26 16
13 8
16 8
29 16
19 8
21 8
15 8
10 8
11 8
12 8
20 8
23 8
24 8
25 8
9 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22
26 16
13 8
16 8
29 16
19 8
21 8
15 8
10 8
11 8
12 8
20 8
23 8
24 8
25 8
9 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
22
27 16
14 8
17 8
18 8
28 16
22 8
15 8
10 8
11 8
12 8
20 8
23 8
24 8
25 8
9 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
0
0
0
0
0
0
end_CG
