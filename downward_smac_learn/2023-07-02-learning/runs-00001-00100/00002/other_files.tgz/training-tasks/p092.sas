begin_version
3
end_version
begin_metric
0
end_metric
63
begin_variable
var2
-1
4
Atom at(tray3, kitchen)
Atom at(tray3, table1)
Atom at(tray3, table2)
Atom at(tray3, table3)
end_variable
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var39
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var40
-1
2
Atom no_gluten_sandwich(sandw11)
NegatedAtom no_gluten_sandwich(sandw11)
end_variable
begin_variable
var41
-1
2
Atom no_gluten_sandwich(sandw12)
NegatedAtom no_gluten_sandwich(sandw12)
end_variable
begin_variable
var42
-1
2
Atom no_gluten_sandwich(sandw13)
NegatedAtom no_gluten_sandwich(sandw13)
end_variable
begin_variable
var43
-1
2
Atom no_gluten_sandwich(sandw14)
NegatedAtom no_gluten_sandwich(sandw14)
end_variable
begin_variable
var44
-1
2
Atom no_gluten_sandwich(sandw15)
NegatedAtom no_gluten_sandwich(sandw15)
end_variable
begin_variable
var45
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var46
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var47
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var48
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var49
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var50
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var51
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var52
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var38
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var24
-1
6
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
Atom ontray(sandw10, tray3)
<none of those>
end_variable
begin_variable
var25
-1
6
Atom at_kitchen_sandwich(sandw11)
Atom notexist(sandw11)
Atom ontray(sandw11, tray1)
Atom ontray(sandw11, tray2)
Atom ontray(sandw11, tray3)
<none of those>
end_variable
begin_variable
var26
-1
6
Atom at_kitchen_sandwich(sandw12)
Atom notexist(sandw12)
Atom ontray(sandw12, tray1)
Atom ontray(sandw12, tray2)
Atom ontray(sandw12, tray3)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var17
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var23
-1
6
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
Atom ontray(sandw1, tray3)
<none of those>
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var19
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var20
-1
2
Atom at_kitchen_content(content7)
NegatedAtom at_kitchen_content(content7)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var27
-1
6
Atom at_kitchen_sandwich(sandw13)
Atom notexist(sandw13)
Atom ontray(sandw13, tray1)
Atom ontray(sandw13, tray2)
Atom ontray(sandw13, tray3)
<none of those>
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_bread(bread7)
NegatedAtom at_kitchen_bread(bread7)
end_variable
begin_variable
var21
-1
2
Atom at_kitchen_content(content8)
NegatedAtom at_kitchen_content(content8)
end_variable
begin_variable
var28
-1
6
Atom at_kitchen_sandwich(sandw14)
Atom notexist(sandw14)
Atom ontray(sandw14, tray1)
Atom ontray(sandw14, tray2)
Atom ontray(sandw14, tray3)
<none of those>
end_variable
begin_variable
var29
-1
6
Atom at_kitchen_sandwich(sandw15)
Atom notexist(sandw15)
Atom ontray(sandw15, tray1)
Atom ontray(sandw15, tray2)
Atom ontray(sandw15, tray3)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
Atom ontray(sandw2, tray3)
<none of those>
end_variable
begin_variable
var31
-1
6
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
Atom ontray(sandw3, tray3)
<none of those>
end_variable
begin_variable
var32
-1
6
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
Atom ontray(sandw4, tray3)
<none of those>
end_variable
begin_variable
var33
-1
6
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
Atom ontray(sandw5, tray3)
<none of those>
end_variable





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8 10
39 10
40 10
25
42 15
43 15
46 15
47 15
22 15
50 15
25 15
26 15
30 15
51 15
23 10
18 10
19 10
20 10
28 10
31 10
32 10
33 10
34 10
35 10
36 10
37 10
38 10
39 10
40 10
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
6 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
25
42 15
43 15
46 15
47 15
22 15
50 15
25 15
26 15
30 15
51 15
23 10
18 10
19 10
20 10
28 10
31 10
32 10
33 10
34 10
35 10
36 10
37 10
38 10
39 10
40 10
25
21 15
41 15
44 15
24 15
45 15
48 15
27 15
29 15
49 15
52 15
23 10
18 10
19 10
20 10
28 10
31 10
32 10
33 10
34 10
35 10
36 10
37 10
38 10
39 10
40 10
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
7 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
8 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
9 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
10 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
11 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
12 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
13 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
14 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
15 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
31
21 10
41 16
44 16
24 10
45 16
48 16
27 10
29 10
49 16
52 16
42 16
43 16
46 16
47 16
22 10
50 16
25 10
26 10
30 10
51 16
16 36
62 3
61 3
56 3
60 3
55 3
59 3
54 3
53 3
58 3
57 3
40
42 30
43 30
46 30
47 30
22 15
50 30
25 15
26 15
30 15
51 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
21 15
41 30
44 30
24 15
45 30
48 30
27 15
29 15
49 30
52 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
21 15
41 30
44 30
24 15
45 30
48 30
27 15
29 15
49 30
52 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
42 30
43 30
46 30
47 30
22 15
50 30
25 15
26 15
30 15
51 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
42 30
43 30
46 30
47 30
22 15
50 30
25 15
26 15
30 15
51 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
21 15
41 30
44 30
24 15
45 30
48 30
27 15
29 15
49 30
52 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
21 15
41 30
44 30
24 15
45 30
48 30
27 15
29 15
49 30
52 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
42 30
43 30
46 30
47 30
22 15
50 30
25 15
26 15
30 15
51 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
42 30
43 30
46 30
47 30
22 15
50 30
25 15
26 15
30 15
51 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
21 15
41 30
44 30
24 15
45 30
48 30
27 15
29 15
49 30
52 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
21 15
41 30
44 30
24 15
45 30
48 30
27 15
29 15
49 30
52 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
40
42 30
43 30
46 30
47 30
22 15
50 30
25 15
26 15
30 15
51 30
23 16
18 16
19 16
20 16
28 16
31 16
32 16
33 16
34 16
35 16
36 16
37 16
38 16
39 16
40 16
17 6
3 6
4 6
5 6
6 6
7 6
8 6
9 6
10 6
11 6
12 6
13 6
14 6
15 6
16 6
0
0
0
0
0
0
0
0
0
0
end_CG
