begin_version
3
end_version
begin_metric
0
end_metric
15
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var11
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var12
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var10
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var7
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var8
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var9
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var13
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var14
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
3
begin_mutex_group
2
3 0
7 1
end_mutex_group
begin_mutex_group
2
1 0
8 1
end_mutex_group
begin_mutex_group
2
2 0
10 1
end_mutex_group
begin_state
0
1
1
1
0
0
0
1
1
0
1
0
0
1
1
end_state
begin_goal
2
13 0
14 0
end_goal
54
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 9 0 1
0 4 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 9 0 1
0 12 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 9 0 1
0 6 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 11 0 1
0 4 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 11 0 1
0 12 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 11 0 1
0 6 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 5 0 1
0 4 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 5 0 1
0 12 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 5 0 1
0 6 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content1
0
3
0 9 0 1
0 4 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content2
0
3
0 9 0 1
0 12 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content3
0
3
0 9 0 1
0 6 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content1
0
3
0 11 0 1
0 4 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content2
0
3
0 11 0 1
0 12 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content3
0
3
0 11 0 1
0 6 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content1
0
3
0 5 0 1
0 4 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content2
0
3
0 5 0 1
0 12 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content3
0
3
0 5 0 1
0 6 0 1
0 8 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread1 content1
0
3
0 9 0 1
0 4 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread1 content2
0
3
0 9 0 1
0 12 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread1 content3
0
3
0 9 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread2 content1
0
3
0 11 0 1
0 4 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread2 content2
0
3
0 11 0 1
0 12 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread2 content3
0
3
0 11 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread3 content1
0
3
0 5 0 1
0 4 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread3 content2
0
3
0 5 0 1
0 12 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread3 content3
0
3
0 5 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw1 bread1 content2
0
4
0 9 0 1
0 12 0 1
0 7 1 0
0 3 -1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw1 bread2 content2
0
4
0 11 0 1
0 12 0 1
0 7 1 0
0 3 -1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw2 bread1 content2
0
4
0 9 0 1
0 12 0 1
0 8 1 0
0 1 -1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw2 bread2 content2
0
4
0 11 0 1
0 12 0 1
0 8 1 0
0 1 -1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw3 bread1 content2
0
4
0 9 0 1
0 12 0 1
0 10 1 0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




no_gluten sandw2 child2 tray1 table2
2
0 2
1 0
2
0 8 2 3
0 14 -1 0
0
end_operator
begin_operator
serve_sandwich_no_gluten sandw3 child2 tray1 table2
2
0 2
2 0
2
0 10 2 3
0 14 -1 0
0
end_operator
0
begin_SG
switch 0
check 0
switch 9
check 3
33
34
35
check 0
check 0
switch 7
check 0
check 1
45
check 0
check 0
check 0
switch 8
check 0
check 1
46
check 0
check 0
check 0
switch 10
check 0
check 1
47
check 0
check 0
check 0
check 0
check 3
36
37
38
switch 9
check 3
39
40
41
check 0
check 0
switch 7
check 0
check 0
check 0
switch 8
check 1
48
check 0
check 0
check 0
check 0
switch 3
check 0
check 1
51
check 0
check 0
check 0
switch 8
check 0
check 0
check 0
switch 10
check 1
49
check 0
check 0
check 0
check 0
switch 1
check 0
check 1
52
check 0
check 0
check 0
switch 10
check 0
check 0
check 0
switch 3
check 1
50
check 0
check 0
switch 2
check 0
check 1
53
check 0
check 0
check 0
check 0
check 3
42
43
44
switch 9
check 0
switch 4
check 0
switch 7
check 0
check 0
check 1
0
check 0
check 0
switch 8
check 0
check 0
check 1
9
check 0
check 0
switch 10
check 0
check 0
check 1
18
check 0
check 0
check 0
check 0
switch 12
check 0
switch 7
check 0
check 0
check 2
1
27
check 0
check 0
switch 8
check 0
check 0
check 2
10
29
check 0
check 0
switch 10
check 0
check 0
check 2
19
31
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 0
check 1
2
check 0
check 0
switch 8
check 0
check 0
check 1
11
check 0
check 0
switch 10
check 0
check 0
check 1
20
check 0
check 0
check 0
check 0
check 0
check 0
switch 11
check 0
switch 4
check 0
switch 7
check 0
check 0
check 1
3
check 0
check 0
switch 8
check 0
check 0
check 1
12
check 0
check 0
switch 10
check 0
check 0
check 1
21
check 0
check 0
check 0
check 0
switch 12
check 0
switch 7
check 0
check 0
check 2
4
28
check 0
check 0
switch 8
check 0
check 0
check 2
13
30
check 0
check 0
switch 10
check 0
check 0
check 2
22
32
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 0
check 1
5
check 0
check 0
switch 8
check 0
check 0
check 1
14
check 0
check 0
switch 10
check 0
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 4
check 0
switch 7
check 0
check 0
check 1
6
check 0
check 0
switch 8
check 0
check 0
check 1
15
check 0
check 0
switch 10
check 0
check 0
check 1
24
check 0
check 0
check 0
check 0
switch 12
check 0
switch 7
check 0
check 0
check 1
7
check 0
check 0
switch 8
check 0
check 0
check 1
16
check 0
check 0
switch 10
check 0
check 0
check 1
25
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 0
check 1
8
check 0
check 0
switch 8
check 0
check 0
check 1
17
check 0
check 0
switch 10
check 0
check 0
check 1
26
check 0
check 0
check 0
check 0
check 0
check 0
check 0
end_SG
begin_DTG
3
1
33
0
2
34
0
3
35
0
3
0
36
0
2
37
0
3
38
0
3
0
39
0
1
40
0
3
41
0
3
0
42
0
1
43
0
2
44
0
end_DTG
begin_DTG
0
2
0
29
3
9 0
12 0
8 1
0
30
3
11 0
12 0
8 1
end_DTG
begin_DTG
0
2
0
31
3
9 0
12 0
10 1
0
32
3
11 0
12 0
10 1
end_DTG
begin_DTG
0
2
0
27
3
9 0
12 0
7 1
0
28
3
11 0
12 0
7 1
end_DTG
begin_DTG
9
1
0
2
9 0
7 1
1
3
2
11 0
7 1
1
6
2
5 0
7 1
1
9
2
9 0
8 1
1
12
2
11 0
8 1
1
15
2
5 0
8 1
1
18
2
9 0
10 1
1
21
2
11 0
10 1
1
24
2
5 0
10 1
0
end_DTG
begin_DTG
9
1
6
2
4 0
7 1
1
7
2
12 0
7 1
1
8
2
6 0
7 1
1
15
2
4 0
8 1
1
16
2
12 0
8 1
1
17
2
6 0
8 1
1
24
2
4 0
10 1
1
25
2
12 0
10 1
1
26
2
6 0
10 1
0
end_DTG
begin_DTG
9
1
2
2
9 0
7 1
1
5
2
11 0
7 1
1
8
2
5 0
7 1
1
11
2
9 0
8 1
1
14
2
11 0
8 1
1
17
2
5 0
8 1
1
20
2
9 0
10 1
1
23
2
11 0
10 1
1
26
2
5 0
10 1
0
end_DTG
begin_DTG
1
2
45
1
0 0
9
0
0
2
9 0
4 0
0
1
2
9 0
12 0
0
2
2
9 0
6 0
0
3
2
11 0
4 0
0
4
2
11 0
12 0
0
5
2
11 0
6 0
0
6
2
5 0
4 0
0
7
2
5 0
12 0
0
8
2
5 0
6 0
1
3
48
1
0 2
0
end_DTG
begin_DTG
1
2
46
1
0 0
9
0
9
2
9 0
4 0
0
10
2
9 0
12 0
0
11
2
9 0
6 0
0
12
2
11 0
4 0
0
13
2
11 0
12 0
0
14
2
11 0
6 0
0
15
2
5 0
4 0
0
16
2
5 0
12 0
0
17
2
5 0
6 0
1
3
49
1
0 2
0
end_DTG
begin_DTG
9
1
0
2
4 0
7 1
1
1
2
12 0
7 1
1
2
2
6 0
7 1
1
9
2
4 0
8 1
1
10
2
12 0
8 1
1
11
2
6 0
8 1
1
18
2
4 0
10 1
1
19
2
12 0
10 1
1
20
2
6 0
10 1
0
end_DTG
begin_DTG
1
2
47
1
0 0
9
0
18
2
9 0
4 0
0
19
2
9 0
12 0
0
20
2
9 0
6 0
0
21
2
11 0
4 0
0
22
2
11 0
12 0
0
23
2
11 0
6 0
0
24
2
5 0
4 0
0
25
2
5 0
12 0
0
26
2
5 0
6 0
1
3
50
1
0 2
0
end_DTG
begin_DTG
9
1
3
2
4 0
7 1
1
4
2
12 0
7 1
1
5
2
6 0
7 1
1
12
2
4 0
8 1
1
13
2
12 0
8 1
1
14
2
6 0
8 1
1
21
2
4 0
10 1
1
22
2
12 0
10 1
1
23
2
6 0
10 1
0
end_DTG
begin_DTG
9
1
1
2
9 0
7 1
1
4
2
11 0
7 1
1
7
2
5 0
7 1
1
10
2
9 0
8 1
1
13
2
11 0
8 1
1
16
2
5 0
8 1
1
19
2
9 0
10 1
1
22
2
11 0
10 1
1
25
2
5 0
10 1
0
end_DTG
begin_DTG
0
3
0
48
2
0 2
7 2
0
49
2
0 2
8 2
0
50
2
0 2
10 2
end_DTG
begin_DTG
0
3
0
51
3
0 2
7 2
3 0
0
52
3
0 2
8 2
1 0
0
53
3
0 2
10 2
2 0
end_DTG
begin_CG
5
7 3
8 3
10 3
13 3
14 3
2
8 1
14 1
2
10 1
14 1
2
7 1
14 1
6
9 3
11 3
5 3
7 3
8 3
10 3
6
4 3
12 3
6 3
7 3
8 3
10 3
6
9 3
11 3
5 3
7 3
8 3
10 3
9
9 4
11 4
5 3
4 3
12 5
6 3
3 2
13 1
14 1
9
9 4
11 4
5 3
4 3
12 5
6 3
1 2
13 1
14 1
9
4 3
12 6
6 3
7 4
8 4
10 4
3 1
1 1
2 1
9
9 4
11 4
5 3
4 3
12 5
6 3
2 2
13 1
14 1
9
4 3
12 6
6 3
7 4
8 4
10 4
3 1
1 1
2 1
9
9 6
11 6
5 3
7 5
8 5
10 5
3 2
1 2
2 2
0
0
end_CG
