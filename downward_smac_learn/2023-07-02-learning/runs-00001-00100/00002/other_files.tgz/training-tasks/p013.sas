begin_version
3
end_version
begin_metric
0
end_metric
24
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var17
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var18
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var19
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var20
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var16
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var11
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var12
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var15
-1
4
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
<none of those>
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var23
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var22
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var21
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
5
begin_mutex_group
2
5 0
10 1
end_mutex_group
begin_mutex_group
2
1 0
13 1
end_mutex_group
begin_mutex_group
2
2 0
14 1
end_mutex_group
begin_mutex_group
2
3 0
15 1
end_mutex_group
begin_mutex_group
2
4 0
18 1
end_mutex_group
begin_state
0
1
1
1
1
1
0
0
0
0
1
0
0
1
1
1
0
0
1
0
0
1
1
1
end_state
begin_goal
3
21 0
22 0
23 0
end_goal
177
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 16 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 16 0 1
0 17 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 16 0 1
0 9 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content4
0
3
0 16 0 1
0 20 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content5
0
3
0 16 0 1
0 12 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 7 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 7 0 1
0 17 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 7 0 1
0 9 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content4
0
3
0 7 0 1
0 20 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content5
0
3
0 7 0 1
0 12 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 8 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 8 0 1
0 17 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 8 0 1
0 9 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content4
0
3
0 8 0 1
0 20 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content5
0
3
0 8 0 1
0 12 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content1
0
3
0 11 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content2
0
3
0 11 0 1
0 17 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content3
0
3
0 11 0 1
0 9 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content4
0
3
0 11 0 1
0 20 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content5
0
3
0 11 0 1
0 12 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread5 content1
0
3
0 19 0 1
0 6




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





10 1
0
end_DTG
begin_DTG
1
2
158
1
0 0
25
0
39
2
8 0
12 0
0
132
2
19 0
20 0
0
131
2
19 0
17 0
0
130
2
16 0
20 0
0
129
2
16 0
17 0
0
49
2
19 0
12 0
0
47
2
19 0
9 0
0
45
2
19 0
6 0
0
44
2
11 0
12 0
0
43
2
11 0
20 0
0
42
2
11 0
9 0
0
41
2
11 0
17 0
0
40
2
11 0
6 0
0
25
2
16 0
6 0
0
38
2
8 0
20 0
0
37
2
8 0
9 0
0
36
2
8 0
17 0
0
35
2
8 0
6 0
0
34
2
7 0
12 0
0
33
2
7 0
20 0
0
32
2
7 0
9 0
0
31
2
7 0
17 0
0
30
2
7 0
6 0
0
29
2
16 0
12 0
0
27
2
16 0
9 0
1
3
163
1
0 3
0
end_DTG
begin_DTG
1
2
159
1
0 0
25
0
64
2
8 0
12 0
0
136
2
19 0
20 0
0
135
2
19 0
17 0
0
134
2
16 0
20 0
0
133
2
16 0
17 0
0
74
2
19 0
12 0
0
72
2
19 0
9 0
0
70
2
19 0
6 0
0
69
2
11 0
12 0
0
68
2
11 0
20 0
0
67
2
11 0
9 0
0
66
2
11 0
17 0
0
65
2
11 0
6 0
0
50
2
16 0
6 0
0
63
2
8 0
20 0
0
62
2
8 0
9 0
0
61
2
8 0
17 0
0
60
2
8 0
6 0
0
59
2
7 0
12 0
0
58
2
7 0
20 0
0
57
2
7 0
9 0
0
56
2
7 0
17 0
0
55
2
7 0
6 0
0
54
2
16 0
12 0
0
52
2
16 0
9 0
1
3
164
1
0 3
0
end_DTG
begin_DTG
1
2
160
1
0 0
25
0
89
2
8 0
12 0
0
140
2
19 0
20 0
0
139
2
19 0
17 0
0
138
2
16 0
20 0
0
137
2
16 0
17 0
0
99
2
19 0
12 0
0
97
2
19 0
9 0
0
95
2
19 0
6 0
0
94
2
11 0
12 0
0
93
2
11 0
20 0
0
92
2
11 0
9 0
0
91
2
11 0
17 0
0
90
2
11 0
6 0
0
75
2
16 0
6 0
0
88
2
8 0
20 0
0
87
2
8 0
9 0
0
86
2
8 0
17 0
0
85
2
8 0
6 0
0
84
2
7 0
12 0
0
83
2
7 0
20 0
0
82
2
7 0
9 0
0
81
2
7 0
17 0
0
80
2
7 0
6 0
0
79
2
16 0
12 0
0
77
2
16 0
9 0
1
3
165
1
0 3
0
end_DTG
begin_DTG
25
1
126
2
20 0
10 1
1
78
2
20 0
15 1
1
79
2
12 0
15 1
1
100
2
6 0
18 1
1
101
2
17 0
18 1
1
102
2
9 0
18 1
1
103
2
20 0
18 1
1
104
2
12 0
18 1
1
125
2
17 0
10 1
1
77
2
9 0
15 1
1
129
2
17 0
13 1
1
130
2
20 0
13 1
1
133
2
17 0
14 1
1
134
2
20 0
14 1
1
137
2
17 0
15 1
1
29
2
12 0
13 1
1
2
2
9 0
10 1
1
4
2
12 0
10 1
1
25
2
6 0
13 1
1
27
2
9 0
13 1
1
0
2
6 0
10 1
1
50
2
6 0
14 1
1
52
2
9 0
14 1
1
54
2
12 0
14 1
1
75
2
6 0
15 1
0
end_DTG
begin_DTG
25
1
127
2
19 0
10 1
1
91
2
11 0
15 1
1
96
2
19 0
15 1
1
101
2
16 0
18 1
1
106
2
7 0
18 1
1
111
2
8 0
18 1
1
116
2
11 0
18 1
1
121
2
19 0
18 1
1
125
2
16 0
10 1
1
86
2
8 0
15 1
1
129
2
16 0
13 1
1
131
2
19 0
13 1
1
133
2
16 0
14 1
1
135
2
19 0
14 1
1
137
2
16 0
15 1
1
6
2
7 0
10 1
1
11
2
8 0
10 1
1
16
2
11 0
10 1
1
31
2
7 0
13 1
1
36
2
8 0
13 1
1
41
2
11 0
13 1
1
56
2
7 0
14 1
1
61
2
8 0
14 1
1
66
2
11 0
14 1
1
81
2
7 0
15 1
0
end_DTG
begin_DTG
1
2
161
1
0 0
25
0
114
2
8 0
12 0
0
144
2
19 0
20 0
0
143
2
19 0
17 0
0
142
2
16 0
20 0
0
141
2
16 0
17 0
0
124
2
19 0
12 0
0
122
2
19 0
9 0
0
120
2
19 0
6 0
0
119
2
11 0
12 0
0
118
2
11 0
20 0
0
117
2
11 0
9 0
0
116
2
11 0
17 0
0
115
2
11 0
6 0
0
100
2
16 0
6 0
0
113
2
8 0
20 0
0
112
2
8 0
9 0
0
111
2
8 0
17 0
0
110
2
8 0
6 0
0
109
2
7 0
12 0
0
108
2
7 0
20 0
0
107
2
7 0
9 0
0
106
2
7 0
17 0
0
105
2
7 0
6 0
0
104
2
16 0
12 0
0
102
2
16 0
9 0
1
3
166
1
0 3
0
end_DTG
begin_DTG
25
1
128
2
20 0
10 1
1
98
2
20 0
15 1
1
99
2
12 0
15 1
1
120
2
6 0
18 1
1
121
2
17 0
18 1
1
122
2
9 0
18 1
1
123
2
20 0
18 1
1
124
2
12 0
18 1
1
127
2
17 0
10 1
1
97
2
9 0
15 1
1
131
2
17 0
13 1
1
132
2
20 0
13 1
1
135
2
17 0
14 1
1
136
2
20 0
14 1
1
139
2
17 0
15 1
1
49
2
12 0
13 1
1
22
2
9 0
10 1
1
24
2
12 0
10 1
1
45
2
6 0
13 1
1
47
2
9 0
13 1
1
20
2
6 0
10 1
1
70
2
6 0
14 1
1
72
2
9 0
14 1
1
74
2
12 0
14 1
1
95
2
6 0
15 1
0
end_DTG
begin_DTG
25
1
128
2
19 0
10 1
1
93
2
11 0
15 1
1
98
2
19 0
15 1
1
103
2
16 0
18 1
1
108
2
7 0
18 1
1
113
2
8 0
18 1
1
118
2
11 0
18 1
1
123
2
19 0
18 1
1
126
2
16 0
10 1
1
88
2
8 0
15 1
1
130
2
16 0
13 1
1
132
2
19 0
13 1
1
134
2
16 0
14 1
1
136
2
19 0
14 1
1
138
2
16 0
15 1
1
8
2
7 0
10 1
1
13
2
8 0
10 1
1
18
2
11 0
10 1
1
33
2
7 0
13 1
1
38
2
8 0
13 1
1
43
2
11 0
13 1
1
58
2
7 0
14 1
1
63
2
8 0
14 1
1
68
2
11 0
14 1
1
83
2
7 0
15 1
0
end_DTG
begin_DTG
0
5
0
162
2
0 3
10 2
0
163
2
0 3
13 2
0
164
2
0 3
14 2
0
165
2
0 3
15 2
0
166
2
0 3
18 2
end_DTG
begin_DTG
0
5
0
168
3
0 3
10 2
5 0
0
170
3
0 3
13 2
1 0
0
172
3
0 3
14 2
2 0
0
174
3
0 3
15 2
3 0
0
176
3
0 3
18 2
4 0
end_DTG
begin_DTG
0
5
0
167
3
0 3
10 2
5 0
0
169
3
0 3
13 2
1 0
0
171
3
0 3
14 2
2 0
0
173
3
0 3
15 2
3 0
0
175
3
0 3
18 2
4 0
end_DTG
begin_CG
8
10 4
13 4
14 4
15 4
18 4
23 5
22 5
21 5
3
13 2
23 1
22 1
3
14 2
23 1
22 1
3
15 2
23 1
22 1
3
18 2
23 1
22 1
3
10 2
23 1
22 1
10
16 5
7 5
8 5
11 5
19 5
10 5
13 5
14 5
15 5
18 5
10
6 5
17 5
9 5
20 5
12 5
10 5
13 5
14 5
15 5
18 5
10
6 5
17 5
9 5
20 5
12 5
10 5
13 5
14 5
15 5
18 5
10
16 5
7 5
8 5
11 5
19 5
10 5
13 5
14 5
15 5
18 5
14
16 7
7 5
8 5
11 5
19 7
6 5
17 7
9 5
20 7
12 5
5 4
23 1
22 1
21 1
10
6 5
17 5
9 5
20 5
12 5
10 5
13 5
14 5
15 5
18 5
10
16 5
7 5
8 5
11 5
19 5
10 5
13 5
14 5
15 5
18 5
14
16 7
7 5
8 5
11 5
19 7
6 5
17 7
9 5
20 7
12 5
1 4
23 1
22 1
21 1
14
16 7
7 5
8 5
11 5
19 7
6 5
17 7
9 5
20 7
12 5
2 4
23 1
22 1
21 1
14
16 7
7 5
8 5
11 5
19 7
6 5
17 7
9 5
20 7
12 5
3 4
23 1
22 1
21 1
15
6 5
17 10
9 5
20 10
12 5
10 7
13 7
14 7
15 7
18 7
5 2
1 2
2 2
3 2
4 2
15
16 10
7 5
8 5
11 5
19 10
10 7
13 7
14 7
15 7
18 7
5 2
1 2
2 2
3 2
4 2
14
16 7
7 5
8 5
11 5
19 7
6 5
17 7
9 5
20 7
12 5
4 4
23 1
22 1
21 1
15
6 5
17 10
9 5
20 10
12 5
10 7
13 7
14 7
15 7
18 7
5 2
1 2
2 2
3 2
4 2
15
16 10
7 5
8 5
11 5
19 10
10 7
13 7
14 7
15 7
18 7
5 2
1 2
2 2
3 2
4 2
0
0
0
end_CG
