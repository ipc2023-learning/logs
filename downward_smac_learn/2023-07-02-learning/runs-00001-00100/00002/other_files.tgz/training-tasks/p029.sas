begin_version
3
end_version
begin_metric
0
end_metric
28
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var18
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var19
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var20
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var21
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var22
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var17
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var12
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var11
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var14
-1
4
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var15
-1
4
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
<none of those>
end_variable
begin_variable
var16
-1
4
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
<none of those>
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var27
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
begin_variable
var25
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var24
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var23
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var26
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
6
begin_mutex_group
2
6 0
11 1
end_mutex_group
begin_mutex_group
2
1 0
7 1
end_mutex_group
begin_mutex_group
2
2 0
8 1
end_mutex_group
begin_mutex_group
2
3 0
14 1
end_mutex_group
begin_mutex_group
2
4 0
19 1
end_mutex_group
begin_mutex_group
2
5 0
20 1
end_mutex_group
begin_state
0
1
1
1
1
1
1
1
1
0
0
1
0
0
1
0
0
0
0
1
1
0
0
1
1
1
1
1
end_state
begin_goal
5
23 0
24 0
25 0
26 0
27 0
end_goal
204
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 9 0 1
0 22 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 9 0 1
0 10 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 9 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content4
0
3
0 9 0 1
0 16 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content5
0
3
0 9 0 1
0 17 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 12 0 1
0 22 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 12 0 1
0 10 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 12 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content4
0
3
0 12 0 1
0 16 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content5
0
3
0 12 0 1
0 17 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 15 0 1
0 22 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 15 0 1
0 10 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 15 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content4
0
3
0 15 0 1
0 16 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content5
0
3
0 15 0 1
0 17 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread4 content1
0
3
0 18 0 1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 1
1
23
2
21 0
11 1
1
18
2
18 0
11 1
1
13
2
15 0
11 1
1
8
2
12 0
11 1
0
end_DTG
begin_DTG
30
1
79
2
9 0
14 1
1
149
2
21 0
20 1
1
144
2
18 0
20 1
1
139
2
15 0
20 1
1
134
2
12 0
20 1
1
129
2
9 0
20 1
1
124
2
21 0
19 1
1
119
2
18 0
19 1
1
114
2
15 0
19 1
1
109
2
12 0
19 1
1
104
2
9 0
19 1
1
99
2
21 0
14 1
1
94
2
18 0
14 1
1
89
2
15 0
14 1
1
84
2
12 0
14 1
1
4
2
9 0
11 1
1
74
2
21 0
8 1
1
69
2
18 0
8 1
1
64
2
15 0
8 1
1
59
2
12 0
8 1
1
54
2
9 0
8 1
1
49
2
21 0
7 1
1
44
2
18 0
7 1
1
39
2
15 0
7 1
1
34
2
12 0
7 1
1
29
2
9 0
7 1
1
24
2
21 0
11 1
1
19
2
18 0
11 1
1
14
2
15 0
11 1
1
9
2
12 0
11 1
0
end_DTG
begin_DTG
30
1
90
2
22 0
14 1
1
144
2
17 0
20 1
1
143
2
16 0
20 1
1
142
2
13 0
20 1
1
141
2
10 0
20 1
1
140
2
22 0
20 1
1
119
2
17 0
19 1
1
118
2
16 0
19 1
1
117
2
13 0
19 1
1
116
2
10 0
19 1
1
115
2
22 0
19 1
1
94
2
17 0
14 1
1
93
2
16 0
14 1
1
92
2
13 0
14 1
1
91
2
10 0
14 1
1
15
2
22 0
11 1
1
69
2
17 0
8 1
1
68
2
16 0
8 1
1
67
2
13 0
8 1
1
66
2
10 0
8 1
1
65
2
22 0
8 1
1
44
2
17 0
7 1
1
43
2
16 0
7 1
1
42
2
13 0
7 1
1
41
2
10 0
7 1
1
40
2
22 0
7 1
1
19
2
17 0
11 1
1
18
2
16 0
11 1
1
17
2
13 0
11 1
1
16
2
10 0
11 1
0
end_DTG
begin_DTG
1
2
172
1
0 0
25
0
113
2
15 0
16 0
0
154
2
21 0
22 0
0
124
2
21 0
17 0
0
123
2
21 0
16 0
0
122
2
21 0
13 0
0
121
2
21 0
10 0
0
119
2
18 0
17 0
0
118
2
18 0
16 0
0
117
2
18 0
13 0
0
116
2
18 0
10 0
0
115
2
18 0
22 0
0
114
2
15 0
17 0
0
100
2
9 0
22 0
0
112
2
15 0
13 0
0
111
2
15 0
10 0
0
110
2
15 0
22 0
0
109
2
12 0
17 0
0
108
2
12 0
16 0
0
107
2
12 0
13 0
0
106
2
12 0
10 0
0
105
2
12 0
22 0
0
104
2
9 0
17 0
0
103
2
9 0
16 0
0
102
2
9 0
13 0
0
101
2
9 0
10 0
3
3
190
1
0 2
3
191
1
0 3
3
193
1
0 1
0
end_DTG
begin_DTG
1
2
173
1
0 0
25
0
138
2
15 0
16 0
0
155
2
21 0
22 0
0
149
2
21 0
17 0
0
148
2
21 0
16 0
0
147
2
21 0
13 0
0
146
2
21 0
10 0
0
144
2
18 0
17 0
0
143
2
18 0
16 0
0
142
2
18 0
13 0
0
141
2
18 0
10 0
0
140
2
18 0
22 0
0
139
2
15 0
17 0
0
125
2
9 0
22 0
0
137
2
15 0
13 0
0
136
2
15 0
10 0
0
135
2
15 0
22 0
0
134
2
12 0
17 0
0
133
2
12 0
16 0
0
132
2
12 0
13 0
0
131
2
12 0
10 0
0
130
2
12 0
22 0
0
129
2
9 0
17 0
0
128
2
9 0
16 0
0
127
2
9 0
13 0
0
126
2
9 0
10 0
3
3
194
1
0 2
3
195
1
0 3
3
197
1
0 1
0
end_DTG
begin_DTG
30
1
147
2
13 0
20 1
1
99
2
17 0
14 1
1
120
2
22 0
19 1
1
121
2
10 0
19 1
1
122
2
13 0
19 1
1
123
2
16 0
19 1
1
124
2
17 0
19 1
1
145
2
22 0
20 1
1
146
2
10 0
20 1
1
98
2
16 0
14 1
1
148
2
16 0
20 1
1
149
2
17 0
20 1
1
150
2
22 0
11 1
1
151
2
22 0
7 1
1
152
2
22 0
8 1
1
153
2
22 0
14 1
1
49
2
17 0
7 1
1
21
2
10 0
11 1
1
22
2
13 0
11 1
1
23
2
16 0
11 1
1
24
2
17 0
11 1
1
46
2
10 0
7 1
1
47
2
13 0
7 1
1
48
2
16 0
7 1
1
71
2
10 0
8 1
1
72
2
13 0
8 1
1
73
2
16 0
8 1
1
74
2
17 0
8 1
1
96
2
10 0
14 1
1
97
2
13 0
14 1
0
end_DTG
begin_DTG
30
1
135
2
15 0
20 1
1
95
2
21 0
14 1
1
100
2
9 0
19 1
1
105
2
12 0
19 1
1
110
2
15 0
19 1
1
115
2
18 0
19 1
1
120
2
21 0
19 1
1
125
2
9 0
20 1
1
130
2
12 0
20 1
1
90
2
18 0
14 1
1
140
2
18 0
20 1
1
145
2
21 0
20 1
1
150
2
21 0
11 1
1
151
2
21 0
7 1
1
152
2
21 0
8 1
1
5
2
12 0
11 1
1
10
2
15 0
11 1
1
15
2
18 0
11 1
1
25
2
9 0
7 1
1
30
2
12 0
7 1
1
35
2
15 0
7 1
1
40
2
18 0
7 1
1
0
2
9 0
11 1
1
50
2
9 0
8 1
1
55
2
12 0
8 1
1
60
2
15 0
8 1
1
65
2
18 0
8 1
1
75
2
9 0
14 1
1
80
2
12 0
14 1
1
85
2
15 0
14 1
0
end_DTG
begin_DTG
0
6
0
177
2
0 1
11 2
0
181
2
0 1
7 2
0
185
2
0 1
8 2
0
189
2
0 1
14 2
0
193
2
0 1
19 2
0
197
2
0 1
20 2
end_DTG
begin_DTG
0
6
0
176
2
0 2
11 2
0
180
2
0 2
7 2
0
184
2
0 2
8 2
0
188
2
0 2
14 2
0
192
2
0 2
19 2
0
196
2
0 2
20 2
end_DTG
begin_DTG
0
6
0
175
2
0 3
11 2
0
179
2
0 3
7 2
0
183
2
0 3
8 2
0
187
2
0 3
14 2
0
191
2
0 3
19 2
0
195
2
0 3
20 2
end_DTG
begin_DTG
0
6
0
174
2
0 2
11 2
0
178
2
0 2
7 2
0
182
2
0 2
8 2
0
186
2
0 2
14 2
0
190
2
0 2
19 2
0
194
2
0 2
20 2
end_DTG
begin_DTG
0
6
0
198
3
0 3
11 2
6 0
0
199
3
0 3
7 2
1 0
0
200
3
0 3
8 2
2 0
0
201
3
0 3
14 2
3 0
0
202
3
0 3
19 2
4 0
0
203
3
0 3
20 2
5 0
end_DTG
begin_CG
11
11 6
7 6
8 6
14 6
19 6
20 6
26 6
25 6
24 6
27 6
23 6
2
7 1
27 1
2
8 1
27 1
2
14 1
27 1
2
19 1
27 1
2
20 1
27 1
2
11 1
27 1
16
9 5
12 5
15 5
18 5
21 6
22 6
10 5
13 5
16 5
17 5
1 1
26 1
25 1
24 1
27 1
23 1
16
9 5
12 5
15 5
18 5
21 6
22 6
10 5
13 5
16 5
17 5
2 1
26 1
25 1
24 1
27 1
23 1
11
22 6
10 6
13 6
16 6
17 6
11 5
7 5
8 5
14 5
19 5
20 5
11
9 6
12 6
15 6
18 6
21 6
11 5
7 5
8 5
14 5
19 5
20 5
16
9 5
12 5
15 5
18 5
21 6
22 6
10 5
13 5
16 5
17 5
6 1
26 1
25 1
24 1
27 1
23 1
11
22 6
10 6
13 6
16 6
17 6
11 5
7 5
8 5
14 5
19 5
20 5
11
9 6
12 6
15 6
18 6
21 6
11 5
7 5
8 5
14 5
19 5
20 5
16
9 5
12 5
15 5
18 5
21 6
22 6
10 5
13 5
16 5
17 5
3 1
26 1
25 1
24 1
27 1
23 1
11
22 6
10 6
13 6
16 6
17 6
11 5
7 5
8 5
14 5
19 5
20 5
11
9 6
12 6
15 6
18 6
21 6
11 5
7 5
8 5
14 5
19 5
20 5
11
9 6
12 6
15 6
18 6
21 6
11 5
7 5
8 5
14 5
19 5
20 5
11
22 6
10 6
13 6
16 6
17 6
11 5
7 5
8 5
14 5
19 5
20 5
16
9 5
12 5
15 5
18 5
21 6
22 6
10 5
13 5
16 5
17 5
4 1
26 1
25 1
24 1
27 1
23 1
16
9 5
12 5
15 5
18 5
21 6
22 6
10 5
13 5
16 5
17 5
5 1
26 1
25 1
24 1
27 1
23 1
17
22 12
10 6
13 6
16 6
17 6
11 6
7 6
8 6
14 6
19 6
20 6
6 1
1 1
2 1
3 1
4 1
5 1
17
9 6
12 6
15 6
18 6
21 12
11 6
7 6
8 6
14 6
19 6
20 6
6 1
1 1
2 1
3 1
4 1
5 1
0
0
0
0
0
end_CG
