begin_version
3
end_version
begin_metric
0
end_metric
30
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var19
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var20
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var21
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var22
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var23
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var24
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var18
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var12
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var13
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var14
-1
4
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
<none of those>
end_variable
begin_variable
var15
-1
4
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var11
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var16
-1
4
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
<none of those>
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var17
-1
4
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var28
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_variable
var27
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var26
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var25
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var29
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
7
begin_mutex_group
2
7 0
14 1
end_mutex_group
begin_mutex_group
2
1 0
8 1
end_mutex_group
begin_mutex_group
2
2 0
9 1
end_mutex_group
begin_mutex_group
2
3 0
10 1
end_mutex_group
begin_mutex_group
2
4 0
11 1
end_mutex_group
begin_mutex_group
2
5 0
19 1
end_mutex_group
begin_mutex_group
2
6 0
22 1
end_mutex_group
begin_state
0
1
1
1
1
1
1
1
1
1
1
1
0
0
1
0
0
0
0
1
0
0
1
0
0
1
1
1
1
1
end_state
begin_goal
5
25 0
26 0
27 0
28 0
29 0
end_goal
236
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 12 0 1
0 13 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 12 0 1
0 16 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 12 0 1
0 24 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content4
0
3
0 12 0 1
0 17 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content5
0
3
0 12 0 1
0 21 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 15 0 1
0 13 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 15 0 1
0 16 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 15 0 1
0 24 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content4
0
3
0 15 0 1
0 17 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content5
0
3
0 15 0 1
0 21 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 23 0 1
0 13 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 23 0 1
0 16 0 1
0 14 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




7 0
10 1
1
99
2
21 0
10 1
1
120
2
13 0
11 1
1
121
2
16 0
11 1
1
122
2
24 0
11 1
1
123
2
17 0
11 1
1
124
2
21 0
11 1
1
145
2
13 0
19 1
1
97
2
24 0
10 1
1
147
2
24 0
19 1
1
148
2
17 0
19 1
1
149
2
21 0
19 1
1
170
2
13 0
22 1
1
171
2
16 0
22 1
1
172
2
24 0
22 1
1
173
2
17 0
22 1
1
174
2
21 0
22 1
1
49
2
21 0
8 1
1
21
2
16 0
14 1
1
22
2
24 0
14 1
1
23
2
17 0
14 1
1
24
2
21 0
14 1
1
45
2
13 0
8 1
1
46
2
16 0
8 1
1
47
2
24 0
8 1
1
48
2
17 0
8 1
1
20
2
13 0
14 1
1
70
2
13 0
9 1
1
71
2
16 0
9 1
1
72
2
24 0
9 1
1
73
2
17 0
9 1
1
74
2
21 0
9 1
1
95
2
13 0
10 1
1
96
2
16 0
10 1
0
end_DTG
begin_DTG
35
1
134
2
15 0
19 1
1
94
2
18 0
10 1
1
99
2
20 0
10 1
1
104
2
12 0
11 1
1
109
2
15 0
11 1
1
114
2
23 0
11 1
1
119
2
18 0
11 1
1
124
2
20 0
11 1
1
129
2
12 0
19 1
1
89
2
23 0
10 1
1
139
2
23 0
19 1
1
144
2
18 0
19 1
1
149
2
20 0
19 1
1
154
2
12 0
22 1
1
159
2
15 0
22 1
1
164
2
23 0
22 1
1
169
2
18 0
22 1
1
174
2
20 0
22 1
1
49
2
20 0
8 1
1
9
2
15 0
14 1
1
14
2
23 0
14 1
1
19
2
18 0
14 1
1
24
2
20 0
14 1
1
29
2
12 0
8 1
1
34
2
15 0
8 1
1
39
2
23 0
8 1
1
44
2
18 0
8 1
1
4
2
12 0
14 1
1
54
2
12 0
9 1
1
59
2
15 0
9 1
1
64
2
23 0
9 1
1
69
2
18 0
9 1
1
74
2
20 0
9 1
1
79
2
12 0
10 1
1
84
2
15 0
10 1
0
end_DTG
begin_DTG
1
2
200
1
0 0
25
0
163
2
23 0
17 0
0
181
2
23 0
24 0
0
174
2
20 0
21 0
0
173
2
20 0
17 0
0
172
2
20 0
24 0
0
171
2
20 0
16 0
0
170
2
20 0
13 0
0
169
2
18 0
21 0
0
168
2
18 0
17 0
0
167
2
18 0
24 0
0
166
2
18 0
16 0
0
165
2
18 0
13 0
0
164
2
23 0
21 0
0
150
2
12 0
13 0
0
161
2
23 0
16 0
0
160
2
23 0
13 0
0
159
2
15 0
21 0
0
158
2
15 0
17 0
0
157
2
15 0
24 0
0
156
2
15 0
16 0
0
155
2
15 0
13 0
0
154
2
12 0
21 0
0
153
2
12 0
17 0
0
152
2
12 0
24 0
0
151
2
12 0
16 0
3
3
225
1
0 1
3
227
1
0 3
3
235
2
0 2
6 0
0
end_DTG
begin_DTG
35
1
162
2
24 0
22 1
1
112
2
24 0
11 1
1
113
2
17 0
11 1
1
114
2
21 0
11 1
1
135
2
13 0
19 1
1
136
2
16 0
19 1
1
137
2
24 0
19 1
1
138
2
17 0
19 1
1
139
2
21 0
19 1
1
160
2
13 0
22 1
1
161
2
16 0
22 1
1
111
2
16 0
11 1
1
163
2
17 0
22 1
1
164
2
21 0
22 1
1
175
2
24 0
14 1
1
176
2
24 0
8 1
1
177
2
24 0
9 1
1
178
2
24 0
10 1
1
61
2
16 0
9 1
1
11
2
16 0
14 1
1
13
2
17 0
14 1
1
14
2
21 0
14 1
1
35
2
13 0
8 1
1
36
2
16 0
8 1
1
38
2
17 0
8 1
1
39
2
21 0
8 1
1
60
2
13 0
9 1
1
10
2
13 0
14 1
1
63
2
17 0
9 1
1
64
2
21 0
9 1
1
85
2
13 0
10 1
1
86
2
16 0
10 1
1
88
2
17 0
10 1
1
89
2
21 0
10 1
1
110
2
13 0
11 1
0
end_DTG
begin_DTG
35
1
162
2
23 0
22 1
1
112
2
23 0
11 1
1
117
2
18 0
11 1
1
122
2
20 0
11 1
1
127
2
12 0
19 1
1
132
2
15 0
19 1
1
137
2
23 0
19 1
1
142
2
18 0
19 1
1
147
2
20 0
19 1
1
152
2
12 0
22 1
1
157
2
15 0
22 1
1
107
2
15 0
11 1
1
167
2
18 0
22 1
1
172
2
20 0
22 1
1
175
2
23 0
14 1
1
176
2
23 0
8 1
1
177
2
23 0
9 1
1
178
2
23 0
10 1
1
57
2
15 0
9 1
1
7
2
15 0
14 1
1
17
2
18 0
14 1
1
22
2
20 0
14 1
1
27
2
12 0
8 1
1
32
2
15 0
8 1
1
42
2
18 0
8 1
1
47
2
20 0
8 1
1
52
2
12 0
9 1
1
2
2
12 0
14 1
1
67
2
18 0
9 1
1
72
2
20 0
9 1
1
77
2
12 0
10 1
1
82
2
15 0
10 1
1
92
2
18 0
10 1
1
97
2
20 0
10 1
1
102
2
12 0
11 1
0
end_DTG
begin_DTG
0
7
0
204
2
0 1
14 2
0
208
2
0 1
8 2
0
212
2
0 1
9 2
0
216
2
0 1
10 2
0
220
2
0 1
11 2
0
224
2
0 1
19 2
0
228
2
0 1
22 2
end_DTG
begin_DTG
0
7
0
203
2
0 3
14 2
0
207
2
0 3
8 2
0
211
2
0 3
9 2
0
215
2
0 3
10 2
0
219
2
0 3
11 2
0
223
2
0 3
19 2
0
227
2
0 3
22 2
end_DTG
begin_DTG
0
7
0
202
2
0 1
14 2
0
206
2
0 1
8 2
0
210
2
0 1
9 2
0
214
2
0 1
10 2
0
218
2
0 1
11 2
0
222
2
0 1
19 2
0
226
2
0 1
22 2
end_DTG
begin_DTG
0
7
0
201
2
0 1
14 2
0
205
2
0 1
8 2
0
209
2
0 1
9 2
0
213
2
0 1
10 2
0
217
2
0 1
11 2
0
221
2
0 1
19 2
0
225
2
0 1
22 2
end_DTG
begin_DTG
0
7
0
229
3
0 2
14 2
7 0
0
230
3
0 2
8 2
1 0
0
231
3
0 2
9 2
2 0
0
232
3
0 2
10 2
3 0
0
233
3
0 2
11 2
4 0
0
234
3
0 2
19 2
5 0
0
235
3
0 2
22 2
6 0
end_DTG
begin_CG
12
14 6
8 6
9 6
10 6
11 6
19 6
22 6
28 7
27 7
26 7
25 7
29 7
2
8 1
29 1
2
9 1
29 1
2
10 1
29 1
2
11 1
29 1
2
19 1
29 1
2
22 1
29 1
2
14 1
29 1
16
12 5
15 5
23 6
18 5
20 5
13 5
16 5
24 6
17 5
21 5
1 1
28 1
27 1
26 1
25 1
29 1
16
12 5
15 5
23 6
18 5
20 5
13 5
16 5
24 6
17 5
21 5
2 1
28 1
27 1
26 1
25 1
29 1
16
12 5
15 5
23 6
18 5
20 5
13 5
16 5
24 6
17 5
21 5
3 1
28 1
27 1
26 1
25 1
29 1
16
12 5
15 5
23 6
18 5
20 5
13 5
16 5
24 6
17 5
21 5
4 1
28 1
27 1
26 1
25 1
29 1
12
13 7
16 7
24 7
17 7
21 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
12
12 7
15 7
23 7
18 7
20 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
16
12 5
15 5
23 6
18 5
20 5
13 5
16 5
24 6
17 5
21 5
7 1
28 1
27 1
26 1
25 1
29 1
12
13 7
16 7
24 7
17 7
21 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
12
12 7
15 7
23 7
18 7
20 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
12
12 7
15 7
23 7
18 7
20 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
12
13 7
16 7
24 7
17 7
21 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
16
12 5
15 5
23 6
18 5
20 5
13 5
16 5
24 6
17 5
21 5
5 1
28 1
27 1
26 1
25 1
29 1
12
13 7
16 7
24 7
17 7
21 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
12
12 7
15 7
23 7
18 7
20 7
14 5
8 5
9 5
10 5
11 5
19 5
22 5
16
12 5
15 5
23 6
18 5
20 5
13 5
16 5
24 6
17 5
21 5
6 1
28 1
27 1
26 1
25 1
29 1
19
13 7
16 7
24 14
17 7
21 7
14 6
8 6
9 6
10 6
11 6
19 6
22 6
7 1
1 1
2 1
3 1
4 1
5 1
6 1
19
12 7
15 7
23 14
18 7
20 7
14 6
8 6
9 6
10 6
11 6
19 6
22 6
7 1
1 1
2 1
3 1
4 1
5 1
6 1
0
0
0
0
0
end_CG
