begin_version
3
end_version
begin_metric
0
end_metric
33
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var21
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var22
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var23
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var24
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var25
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var26
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var20
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var14
-1
4
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var13
-1
4
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var15
-1
4
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
<none of those>
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var16
-1
4
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
<none of those>
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var17
-1
4
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
<none of those>
end_variable
begin_variable
var18
-1
4
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
<none of those>
end_variable
begin_variable
var19
-1
4
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var32
-1
2
Atom served(child6)
NegatedAtom served(child6)
end_variable
begin_variable
var30
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_variable
var29
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var27
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
begin_variable
var31
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
begin_variable
var28
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
7
begin_mutex_group
2
7 0
11 1
end_mutex_group
begin_mutex_group
2
1 0
8 1
end_mutex_group
begin_mutex_group
2
2 0
14 1
end_mutex_group
begin_mutex_group
2
3 0
17 1
end_mutex_group
begin_mutex_group
2
4 0
20 1
end_mutex_group
begin_mutex_group
2
5 0
21 1
end_mutex_group
begin_mutex_group
2
6 0
22 1
end_mutex_group
begin_state
0
1
1
1
1
1
1
1
1
0
0
1
0
0
1
0
0
1
0
0
1
1
1
0
0
0
0
1
1
1
1
1
1
end_state
begin_goal
6
27 0
28 0
29 0
30 0
31 0
32 0
end_goal
341
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 23 0 1
0 10 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 23 0 1
0 24 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 23 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content4
0
3
0 23 0 1
0 16 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content5
0
3
0 23 0 1
0 19 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content6
0
3
0 23 0 1
0 25 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 26 0 1
0 10 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 26 0 1
0 24 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 26 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





76
2
19 0
14 1
1
108
2
10 0
17 1
1
110
2
13 0
17 1
1
111
2
16 0
17 1
1
112
2
19 0
17 1
1
144
2
10 0
20 1
1
146
2
13 0
20 1
1
147
2
16 0
20 1
0
end_DTG
begin_DTG
42
1
252
2
23 0
11 1
1
175
2
18 0
20 1
1
181
2
23 0
21 1
1
187
2
26 0
21 1
1
193
2
9 0
21 1
1
199
2
12 0
21 1
1
205
2
15 0
21 1
1
211
2
18 0
21 1
1
217
2
23 0
22 1
1
223
2
26 0
22 1
1
229
2
9 0
22 1
1
235
2
12 0
22 1
1
241
2
15 0
22 1
1
247
2
18 0
22 1
1
169
2
15 0
20 1
1
254
2
26 0
11 1
1
256
2
23 0
8 1
1
258
2
26 0
8 1
1
260
2
23 0
14 1
1
262
2
26 0
14 1
1
264
2
23 0
17 1
1
266
2
26 0
17 1
1
268
2
23 0
20 1
1
270
2
26 0
20 1
1
85
2
9 0
14 1
1
13
2
9 0
11 1
1
19
2
12 0
11 1
1
25
2
15 0
11 1
1
31
2
18 0
11 1
1
49
2
9 0
8 1
1
55
2
12 0
8 1
1
61
2
15 0
8 1
1
67
2
18 0
8 1
1
91
2
12 0
14 1
1
97
2
15 0
14 1
1
103
2
18 0
14 1
1
121
2
9 0
17 1
1
127
2
12 0
17 1
1
133
2
15 0
17 1
1
139
2
18 0
17 1
1
157
2
9 0
20 1
1
163
2
12 0
20 1
0
end_DTG
begin_DTG
42
1
253
2
23 0
11 1
1
179
2
18 0
20 1
1
185
2
23 0
21 1
1
191
2
26 0
21 1
1
197
2
9 0
21 1
1
203
2
12 0
21 1
1
209
2
15 0
21 1
1
215
2
18 0
21 1
1
221
2
23 0
22 1
1
227
2
26 0
22 1
1
233
2
9 0
22 1
1
239
2
12 0
22 1
1
245
2
15 0
22 1
1
251
2
18 0
22 1
1
173
2
15 0
20 1
1
255
2
26 0
11 1
1
257
2
23 0
8 1
1
259
2
26 0
8 1
1
261
2
23 0
14 1
1
263
2
26 0
14 1
1
265
2
23 0
17 1
1
267
2
26 0
17 1
1
269
2
23 0
20 1
1
271
2
26 0
20 1
1
89
2
9 0
14 1
1
17
2
9 0
11 1
1
23
2
12 0
11 1
1
29
2
15 0
11 1
1
35
2
18 0
11 1
1
53
2
9 0
8 1
1
59
2
12 0
8 1
1
65
2
15 0
8 1
1
71
2
18 0
8 1
1
95
2
12 0
14 1
1
101
2
15 0
14 1
1
107
2
18 0
14 1
1
125
2
9 0
17 1
1
131
2
12 0
17 1
1
137
2
15 0
17 1
1
143
2
18 0
17 1
1
161
2
9 0
20 1
1
167
2
12 0
20 1
0
end_DTG
begin_DTG
42
1
254
2
24 0
11 1
1
155
2
25 0
20 1
1
186
2
10 0
21 1
1
187
2
24 0
21 1
1
188
2
13 0
21 1
1
189
2
16 0
21 1
1
190
2
19 0
21 1
1
191
2
25 0
21 1
1
222
2
10 0
22 1
1
223
2
24 0
22 1
1
224
2
13 0
22 1
1
225
2
16 0
22 1
1
226
2
19 0
22 1
1
227
2
25 0
22 1
1
154
2
19 0
20 1
1
255
2
25 0
11 1
1
258
2
24 0
8 1
1
259
2
25 0
8 1
1
262
2
24 0
14 1
1
263
2
25 0
14 1
1
266
2
24 0
17 1
1
267
2
25 0
17 1
1
270
2
24 0
20 1
1
80
2
13 0
14 1
1
8
2
13 0
11 1
1
9
2
16 0
11 1
1
10
2
19 0
11 1
1
42
2
10 0
8 1
1
44
2
13 0
8 1
1
45
2
16 0
8 1
1
46
2
19 0
8 1
1
78
2
10 0
14 1
1
6
2
10 0
11 1
1
81
2
16 0
14 1
1
82
2
19 0
14 1
1
114
2
10 0
17 1
1
116
2
13 0
17 1
1
117
2
16 0
17 1
1
118
2
19 0
17 1
1
150
2
10 0
20 1
1
152
2
13 0
20 1
1
153
2
16 0
20 1
0
end_DTG
begin_DTG
0
7
0
302
2
0 2
11 2
0
306
2
0 2
8 2
0
310
2
0 2
14 2
0
314
2
0 2
17 2
0
318
2
0 2
20 2
0
322
2
0 2
21 2
0
326
2
0 2
22 2
end_DTG
begin_DTG
0
7
0
301
2
0 1
11 2
0
305
2
0 1
8 2
0
309
2
0 1
14 2
0
313
2
0 1
17 2
0
317
2
0 1
20 2
0
321
2
0 1
21 2
0
325
2
0 1
22 2
end_DTG
begin_DTG
0
7
0
300
2
0 3
11 2
0
304
2
0 3
8 2
0
308
2
0 3
14 2
0
312
2
0 3
17 2
0
316
2
0 3
20 2
0
320
2
0 3
21 2
0
324
2
0 3
22 2
end_DTG
begin_DTG
0
7
0
299
2
0 2
11 2
0
303
2
0 2
8 2
0
307
2
0 2
14 2
0
311
2
0 2
17 2
0
315
2
0 2
20 2
0
319
2
0 2
21 2
0
323
2
0 2
22 2
end_DTG
begin_DTG
0
7
0
328
3
0 3
11 2
7 0
0
330
3
0 3
8 2
1 0
0
332
3
0 3
14 2
2 0
0
334
3
0 3
17 2
3 0
0
336
3
0 3
20 2
4 0
0
338
3
0 3
21 2
5 0
0
340
3
0 3
22 2
6 0
end_DTG
begin_DTG
0
7
0
327
3
0 1
11 2
7 0
0
329
3
0 1
8 2
1 0
0
331
3
0 1
14 2
2 0
0
333
3
0 1
17 2
3 0
0
335
3
0 1
20 2
4 0
0
337
3
0 1
21 2
5 0
0
339
3
0 1
22 2
6 0
end_DTG
begin_CG
13
11 7
8 7
14 7
17 7
20 7
21 7
22 7
30 7
32 7
29 7
28 7
31 7
27 7
3
8 2
32 1
31 1
3
14 2
32 1
31 1
3
17 2
32 1
31 1
3
20 2
32 1
31 1
3
21 2
32 1
31 1
3
22 2
32 1
31 1
3
11 2
32 1
31 1
19
23 8
26 8
9 6
12 6
15 6
18 6
10 6
24 8
13 6
16 6
19 6
25 8
1 4
30 1
32 1
29 1
28 1
31 1
27 1
13
10 7
24 7
13 7
16 7
19 7
25 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
13
23 7
26 7
9 7
12 7
15 7
18 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
19
23 8
26 8
9 6
12 6
15 6
18 6
10 6
24 8
13 6
16 6
19 6
25 8
7 4
30 1
32 1
29 1
28 1
31 1
27 1
13
10 7
24 7
13 7
16 7
19 7
25 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
13
23 7
26 7
9 7
12 7
15 7
18 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
19
23 8
26 8
9 6
12 6
15 6
18 6
10 6
24 8
13 6
16 6
19 6
25 8
2 4
30 1
32 1
29 1
28 1
31 1
27 1
13
10 7
24 7
13 7
16 7
19 7
25 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
13
23 7
26 7
9 7
12 7
15 7
18 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
19
23 8
26 8
9 6
12 6
15 6
18 6
10 6
24 8
13 6
16 6
19 6
25 8
3 4
30 1
32 1
29 1
28 1
31 1
27 1
13
10 7
24 7
13 7
16 7
19 7
25 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
13
23 7
26 7
9 7
12 7
15 7
18 7
11 6
8 6
14 6
17 6
20 6
21 6
22 6
19
23 8
26 8
9 6
12 6
15 6
18 6
10 6
24 8
13 6
16 6
19 6
25 8
4 4
30 1
32 1
29 1
28 1
31 1
27 1
19
23 8
26 8
9 6
12 6
15 6
18 6
10 6
24 8
13 6
16 6
19 6
25 8
5 4
30 1
32 1
29 1
28 1
31 1
27 1
19
23 8
26 8
9 6
12 6
15 6
18 6
10 6
24 8
13 6
16 6
19 6
25 8
6 4
30 1
32 1
29 1
28 1
31 1
27 1
20
10 7
24 14
13 7
16 7
19 7
25 14
11 8
8 8
14 8
17 8
20 8
21 8
22 8
7 2
1 2
2 2
3 2
4 2
5 2
6 2
20
23 14
26 14
9 7
12 7
15 7
18 7
11 8
8 8
14 8
17 8
20 8
21 8
22 8
7 2
1 2
2 2
3 2
4 2
5 2
6 2
20
23 14
26 14
9 7
12 7
15 7
18 7
11 8
8 8
14 8
17 8
20 8
21 8
22 8
7 2
1 2
2 2
3 2
4 2
5 2
6 2
20
10 7
24 14
13 7
16 7
19 7
25 14
11 8
8 8
14 8
17 8
20 8
21 8
22 8
7 2
1 2
2 2
3 2
4 2
5 2
6 2
0
0
0
0
0
0
end_CG
