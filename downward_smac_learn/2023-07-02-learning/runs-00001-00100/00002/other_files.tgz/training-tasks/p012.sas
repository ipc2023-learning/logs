begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var12
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var13
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var11
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var8
-1
5
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var9
-1
5
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
<none of those>
end_variable
begin_variable
var10
-1
5
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var15
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var14
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
3
begin_mutex_group
2
4 0
7 1
end_mutex_group
begin_mutex_group
2
2 0
10 1
end_mutex_group
begin_mutex_group
2
3 0
11 1
end_mutex_group
begin_state
0
0
1
1
1
0
0
1
0
0
1
1
0
0
1
1
end_state
begin_goal
2
14 0
15 0
end_goal
72
begin_operator
make_sandwich sandw1 bread1 content1
0
3
0 5 0 1
0 13 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content2
0
3
0 5 0 1
0 6 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread1 content3
0
3
0 5 0 1
0 9 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content1
0
3
0 8 0 1
0 13 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content2
0
3
0 8 0 1
0 6 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread2 content3
0
3
0 8 0 1
0 9 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content1
0
3
0 12 0 1
0 13 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content2
0
3
0 12 0 1
0 6 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw1 bread3 content3
0
3
0 12 0 1
0 9 0 1
0 7 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content1
0
3
0 5 0 1
0 13 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content2
0
3
0 5 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread1 content3
0
3
0 5 0 1
0 9 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content1
0
3
0 8 0 1
0 13 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content2
0
3
0 8 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread2 content3
0
3
0 8 0 1
0 9 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content1
0
3
0 12 0 1
0 13 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content2
0
3
0 12 0 1
0 6 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw2 bread3 content3
0
3
0 12 0 1
0 9 0 1
0 10 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread1 content1
0
3
0 5 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread1 content2
0
3
0 5 0 1
0 6 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread1 content3
0
3
0 5 0 1
0 9 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread2 content1
0
3
0 8 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread2 content2
0
3
0 8 0 1
0 6 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread2 content3
0
3
0 8 0 1
0 9 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread3 content1
0
3
0 12 0 1
0 13 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread3 content2
0
3
0 12 0 1
0 6 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich sandw3 bread3 content3
0
3
0 12 0 1
0 9 0 1
0 11 1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw1 bread3 content1
0
4
0 12 0 1
0 13 0 1
0 7 1 0
0 4 -1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw2 bread3 content1
0
4
0 12 0 1
0 13 0 1
0 10 1 0
0 2 -1 0
0
end_operator
begin_operator
make_sandwich_no_gluten sandw3 bread3 content1
0
4
0 12 0 1
0 13 0 1
0 11 1 0
0 3




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
check 0
check 0
switch 10
check 1
61
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
check 1
67
check 0
check 0
check 0
switch 10
check 0
check 0
check 0
check 0
switch 11
check 1
63
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
check 1
69
check 0
check 0
check 0
switch 11
check 0
check 0
check 0
check 0
switch 4
check 1
65
check 0
check 0
switch 3
check 0
check 1
71
check 0
check 0
check 0
check 0
switch 5
check 0
switch 13
check 0
switch 7
check 0
check 0
check 1
0
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
9
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
18
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 0
check 1
1
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
10
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
19
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
switch 7
check 0
check 0
check 1
2
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
11
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
20
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 8
check 0
switch 13
check 0
switch 7
check 0
check 0
check 1
3
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
12
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
21
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 0
check 1
4
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
13
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
22
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
switch 7
check 0
check 0
check 1
5
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
14
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
23
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 12
check 0
switch 13
check 0
switch 7
check 0
check 0
check 2
6
27
check 0
check 0
check 0
switch 10
check 0
check 0
check 2
15
28
check 0
check 0
check 0
switch 11
check 0
check 0
check 2
24
29
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 7
check 0
check 0
check 1
7
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
16
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
25
check 0
check 0
check 0
check 0
check 0
switch 9
check 0
switch 7
check 0
check 0
check 1
8
check 0
check 0
check 0
switch 10
check 0
check 0
check 1
17
check 0
check 0
check 0
switch 11
check 0
check 0
check 1
26
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
end_SG
begin_DTG
3
1
42
0
2
43
0
3
44
0
3
0
45
0
2
46
0
3
47
0
3
0
48
0
1
49
0
3
50
0
3
0
51
0
1
52
0
2
53
0
end_DTG
begin_DTG
3
1
30
0
2
31
0
3
32
0
3
0
33
0
2
34
0
3
35
0
3
0
36
0
1
37
0
3
38
0
3
0
39
0
1
40
0
2
41
0
end_DTG
begin_DTG
0
1
0
28
3
12 0
13 0
10 1
end_DTG
begin_DTG
0
1
0
29
3
12 0
13 0
11 1
end_DTG
begin_DTG
0
1
0
27
3
12 0
13 0
7 1
end_DTG
begin_DTG
9
1
0
2
13 0
7 1
1
1
2
6 0
7 1
1
2
2
9 0
7 1
1
9
2
13 0
10 1
1
10
2
6 0
10 1
1
11
2
9 0
10 1
1
18
2
13 0
11 1
1
19
2
6 0
11 1
1
20
2
9 0
11 1
0
end_DTG
begin_DTG
9
1
1
2
5 0
7 1
1
4
2
8 0
7 1
1
7
2
12 0
7 1
1
10
2
5 0
10 1
1
13
2
8 0
10 1
1
16
2
12 0
10 1
1
19
2
5 0
11 1
1
22
2
8 0
11 1
1
25
2
12 0
11 1
0
end_DTG
begin_DTG
2
2
54
1
1 0
3
55
1
0 0
9
0
0
2
5 0
13 0
0
1
2
5 0
6 0
0
2
2
5 0
9 0
0
3
2
8 0
13 0
0
4
2
8 0
6 0
0
5
2
8 0
9 0
0
6
2
12 0
13 0
0
7
2
12 0
6 0
0
8
2
12 0
9 0
1
4
60
1
1 3
1
4
61
1
0 3
0
end_DTG
begin_DTG
9
1
3
2
13 0
7 1
1
4
2
6 0
7 1
1
5
2
9 0
7 1
1
12
2
13 0
10 1
1
13
2
6 0
10 1
1
14
2
9 0
10 1
1
21
2
13 0
11 1
1
22
2
6 0
11 1
1
23
2
9 0
11 1
0
end_DTG
begin_DTG
9
1
2
2
5 0
7 1
1
5
2
8 0
7 1
1
8
2
12 0
7 1
1
11
2
5 0
10 1
1
14
2
8 0
10 1
1
17
2
12 0
10 1
1
20
2
5 0
11 1
1
23
2
8 0
11 1
1
26
2
12 0
11 1
0
end_DTG
begin_DTG
2
2
56
1
1 0
3
57
1
0 0
9
0
9
2
5 0
13 0
0
10
2
5 0
6 0
0
11
2
5 0
9 0
0
12
2
8 0
13 0
0
13
2
8 0
6 0
0
14
2
8 0
9 0
0
15
2
12 0
13 0
0
16
2
12 0
6 0
0
17
2
12 0
9 0
1
4
62
1
1 3
1
4
63
1
0 3
0
end_DTG
begin_DTG
2
2
58
1
1 0
3
59
1
0 0
9
0
18
2
5 0
13 0
0
19
2
5 0
6 0
0
20
2
5 0
9 0
0
21
2
8 0
13 0
0
22
2
8 0
6 0
0
23
2
8 0
9 0
0
24
2
12 0
13 0
0
25
2
12 0
6 0
0
26
2
12 0
9 0
1
4
64
1
1 3
1
4
65
1
0 3
0
end_DTG
begin_DTG
9
1
6
2
13 0
7 1
1
7
2
6 0
7 1
1
8
2
9 0
7 1
1
15
2
13 0
10 1
1
16
2
6 0
10 1
1
17
2
9 0
10 1
1
24
2
13 0
11 1
1
25
2
6 0
11 1
1
26
2
9 0
11 1
0
end_DTG
begin_DTG
9
1
0
2
5 0
7 1
1
3
2
8 0
7 1
1
6
2
12 0
7 1
1
9
2
5 0
10 1
1
12
2
8 0
10 1
1
15
2
12 0
10 1
1
18
2
5 0
11 1
1
21
2
8 0
11 1
1
24
2
12 0
11 1
0
end_DTG
begin_DTG
0
6
0
60
2
1 3
7 2
0
61
2
0 3
7 3
0
62
2
1 3
10 2
0
63
2
0 3
10 3
0
64
2
1 3
11 2
0
65
2
0 3
11 3
end_DTG
begin_DTG
0
6
0
66
3
1 3
7 2
4 0
0
67
3
0 3
7 3
4 0
0
68
3
1 3
10 2
2 0
0
69
3
0 3
10 3
2 0
0
70
3
1 3
11 2
3 0
0
71
3
0 3
11 3
3 0
end_DTG
begin_CG
5
7 3
10 3
11 3
15 3
14 3
5
7 3
10 3
11 3
15 3
14 3
2
10 2
15 2
2
11 2
15 2
2
7 2
15 2
6
13 3
6 3
9 3
7 3
10 3
11 3
6
5 3
8 3
12 3
7 3
10 3
11 3
9
5 3
8 3
12 4
13 4
6 3
9 3
4 1
15 2
14 2
6
13 3
6 3
9 3
7 3
10 3
11 3
6
5 3
8 3
12 3
7 3
10 3
11 3
9
5 3
8 3
12 4
13 4
6 3
9 3
2 1
15 2
14 2
9
5 3
8 3
12 4
13 4
6 3
9 3
3 1
15 2
14 2
9
13 6
6 3
9 3
7 4
10 4
11 4
4 1
2 1
3 1
9
5 3
8 3
12 6
7 4
10 4
11 4
4 1
2 1
3 1
0
0
end_CG
