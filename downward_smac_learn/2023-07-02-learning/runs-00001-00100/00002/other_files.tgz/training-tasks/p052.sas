begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var26
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var27
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var28
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var29
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var30
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var31
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var32
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var33
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var25
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var17
-1
5
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
<none of those>
end_variable
begin_variable
var18
-1
5
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var16
-1
5
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var14
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var19
-1
5
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
<none of those>
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_bread(bread7)
NegatedAtom at_kitchen_bread(bread7)
end_variable
begin_variable
var15
-1
2
Atom at_kitchen_content(content7)
NegatedAtom at_kitchen_content(content7)
end_variable
begin_variable
var20
-1
5
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
<none of those>
end_variable
begin_variable
var21
-1
5
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
<none of those>
end_variable
begin_variable
var22
-1
5
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
<none of those>
end_variable
begin_variable
var23
-1
5
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
<none of those>
end_variable
begin_variable
var24
-1
5
Atom at_kitchen_sandwich(sandw9)
Atom notexist(sandw9)
Atom ontray(sandw9, tray1)
Atom ontray(sandw9, tray2)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var39
-1
2
Atom served(child6)
NegatedAtom served(child6)
end_variable
begin_variable
var38
-1
2
Atom served(child5)
NegatedAtom served(child5)
end_variable
begin_variable
var37
-1
2
Atom served(child4)
NegatedAtom served(child4)
end_variable
begin_variable
var36
-1
2
Atom served(child3)
NegatedAtom served(child3)
end_variable
begin_variable
var40
-1
2
Atom served(child7)
NegatedAtom served(child7)
end_variable
begin_variable
var35
-1
2
Atom served(child2)
NegatedAtom served(child2)
end_variable
begin_variable
var34
-1
2
Atom served(child1)
NegatedAtom served(child1)
end_variable
9
begin_mutex_group
2
10 0
15 1
end_mutex_group
begin_mutex_group
2
2 0
11 1
end_mutex_group
begin_mutex_group
2
3 0
12 1
end_mutex_group
begin_mutex_group
2
4 0
20 1
end_mutex_group
begin_mutex_group





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 3
end_DTG
begin_DTG
0
18
0
601
2
0 3
23 3
0
633
2
0 3
27 3
0
632
2
1 3
27 2
0
625
2
0 3
26 3
0
624
2
1 3
26 2
0
617
2
0 3
25 3
0
616
2
1 3
25 2
0
609
2
0 3
24 3
0
608
2
1 3
24 2
0
568
2
1 3
15 2
0
600
2
1 3
23 2
0
593
2
0 3
20 3
0
592
2
1 3
20 2
0
585
2
0 3
12 3
0
584
2
1 3
12 2
0
577
2
0 3
11 3
0
576
2
1 3
11 2
0
569
2
0 3
15 3
end_DTG
begin_DTG
0
18
0
599
2
0 3
23 3
0
631
2
0 3
27 3
0
630
2
1 3
27 2
0
623
2
0 3
26 3
0
622
2
1 3
26 2
0
615
2
0 3
25 3
0
614
2
1 3
25 2
0
607
2
0 3
24 3
0
606
2
1 3
24 2
0
566
2
1 3
15 2
0
598
2
1 3
23 2
0
591
2
0 3
20 3
0
590
2
1 3
20 2
0
583
2
0 3
12 3
0
582
2
1 3
12 2
0
575
2
0 3
11 3
0
574
2
1 3
11 2
0
567
2
0 3
15 3
end_DTG
begin_DTG
0
18
0
597
2
0 2
23 3
0
629
2
0 2
27 3
0
628
2
1 2
27 2
0
621
2
0 2
26 3
0
620
2
1 2
26 2
0
613
2
0 2
25 3
0
612
2
1 2
25 2
0
605
2
0 2
24 3
0
604
2
1 2
24 2
0
564
2
1 2
15 2
0
596
2
1 2
23 2
0
589
2
0 2
20 3
0
588
2
1 2
20 2
0
581
2
0 2
12 3
0
580
2
1 2
12 2
0
573
2
0 2
11 3
0
572
2
1 2
11 2
0
565
2
0 2
15 3
end_DTG
begin_DTG
0
18
0
665
3
0 3
23 3
5 0
0
689
3
0 3
27 3
9 0
0
688
3
1 3
27 2
9 0
0
683
3
0 3
26 3
8 0
0
682
3
1 3
26 2
8 0
0
677
3
0 3
25 3
7 0
0
676
3
1 3
25 2
7 0
0
671
3
0 3
24 3
6 0
0
670
3
1 3
24 2
6 0
0
640
3
1 3
15 2
10 0
0
664
3
1 3
23 2
5 0
0
659
3
0 3
20 3
4 0
0
658
3
1 3
20 2
4 0
0
653
3
0 3
12 3
3 0
0
652
3
1 3
12 2
3 0
0
647
3
0 3
11 3
2 0
0
646
3
1 3
11 2
2 0
0
641
3
0 3
15 3
10 0
end_DTG
begin_DTG
0
18
0
663
3
0 1
23 3
5 0
0
687
3
0 1
27 3
9 0
0
686
3
1 1
27 2
9 0
0
681
3
0 1
26 3
8 0
0
680
3
1 1
26 2
8 0
0
675
3
0 1
25 3
7 0
0
674
3
1 1
25 2
7 0
0
669
3
0 1
24 3
6 0
0
668
3
1 1
24 2
6 0
0
638
3
1 1
15 2
10 0
0
662
3
1 1
23 2
5 0
0
657
3
0 1
20 3
4 0
0
656
3
1 1
20 2
4 0
0
651
3
0 1
12 3
3 0
0
650
3
1 1
12 2
3 0
0
645
3
0 1
11 3
2 0
0
644
3
1 1
11 2
2 0
0
639
3
0 1
15 3
10 0
end_DTG
begin_DTG
0
18
0
661
3
0 1
23 3
5 0
0
685
3
0 1
27 3
9 0
0
684
3
1 1
27 2
9 0
0
679
3
0 1
26 3
8 0
0
678
3
1 1
26 2
8 0
0
673
3
0 1
25 3
7 0
0
672
3
1 1
25 2
7 0
0
667
3
0 1
24 3
6 0
0
666
3
1 1
24 2
6 0
0
636
3
1 1
15 2
10 0
0
660
3
1 1
23 2
5 0
0
655
3
0 1
20 3
4 0
0
654
3
1 1
20 2
4 0
0
649
3
0 1
12 3
3 0
0
648
3
1 1
12 2
3 0
0
643
3
0 1
11 3
2 0
0
642
3
1 1
11 2
2 0
0
637
3
0 1
15 3
10 0
end_DTG
begin_CG
16
15 8
11 8
12 8
20 8
23 8
24 8
25 8
26 8
27 8
40 9
39 9
37 9
36 9
35 9
34 9
38 9
16
15 8
11 8
12 8
20 8
23 8
24 8
25 8
26 8
27 8
40 9
39 9
37 9
36 9
35 9
34 9
38 9
4
11 6
40 2
39 2
38 2
4
12 6
40 2
39 2
38 2
4
20 6
40 2
39 2
38 2
4
23 6
40 2
39 2
38 2
4
24 6
40 2
39 2
38 2
4
25 6
40 2
39 2
38 2
4
26 6
40 2
39 2
38 2
4
27 6
40 2
39 2
38 2
4
15 6
40 2
39 2
38 2
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
2 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
3 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
16
29 9
14 9
17 9
30 9
33 9
18 9
22 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
16
13 9
16 9
28 9
19 9
31 9
32 9
21 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
10 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
16
29 9
14 9
17 9
30 9
33 9
18 9
22 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
16
13 9
16 9
28 9
19 9
31 9
32 9
21 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
16
13 9
16 9
28 9
19 9
31 9
32 9
21 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
16
29 9
14 9
17 9
30 9
33 9
18 9
22 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
4 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
16
29 9
14 9
17 9
30 9
33 9
18 9
22 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
16
13 9
16 9
28 9
19 9
31 9
32 9
21 9
15 7
11 7
12 7
20 7
23 7
24 7
25 7
26 7
27 7
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
5 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
6 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
7 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
8 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
22
13 7
16 7
28 10
19 7
31 10
32 10
21 7
29 10
14 7
17 7
30 10
33 10
18 7
22 7
9 9
40 2
39 2
37 2
36 2
35 2
34 2
38 2
25
29 18
14 9
17 9
30 18
33 18
18 9
22 9
15 10
11 10
12 10
20 10
23 10
24 10
25 10
26 10
27 10
10 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
25
13 9
16 9
28 18
19 9
31 18
32 18
21 9
15 10
11 10
12 10
20 10
23 10
24 10
25 10
26 10
27 10
10 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
25
13 9
16 9
28 18
19 9
31 18
32 18
21 9
15 10
11 10
12 10
20 10
23 10
24 10
25 10
26 10
27 10
10 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
25
29 18
14 9
17 9
30 18
33 18
18 9
22 9
15 10
11 10
12 10
20 10
23 10
24 10
25 10
26 10
27 10
10 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
25
29 18
14 9
17 9
30 18
33 18
18 9
22 9
15 10
11 10
12 10
20 10
23 10
24 10
25 10
26 10
27 10
10 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
25
13 9
16 9
28 18
19 9
31 18
32 18
21 9
15 10
11 10
12 10
20 10
23 10
24 10
25 10
26 10
27 10
10 3
2 3
3 3
4 3
5 3
6 3
7 3
8 3
9 3
0
0
0
0
0
0
0
end_CG
