begin_version
3
end_version
begin_metric
0
end_metric
48
begin_variable
var1
-1
4
Atom at(tray2, kitchen)
Atom at(tray2, table1)
Atom at(tray2, table2)
Atom at(tray2, table3)
end_variable
begin_variable
var0
-1
4
Atom at(tray1, kitchen)
Atom at(tray1, table1)
Atom at(tray1, table2)
Atom at(tray1, table3)
end_variable
begin_variable
var30
-1
2
Atom no_gluten_sandwich(sandw10)
NegatedAtom no_gluten_sandwich(sandw10)
end_variable
begin_variable
var31
-1
2
Atom no_gluten_sandwich(sandw11)
NegatedAtom no_gluten_sandwich(sandw11)
end_variable
begin_variable
var32
-1
2
Atom no_gluten_sandwich(sandw2)
NegatedAtom no_gluten_sandwich(sandw2)
end_variable
begin_variable
var33
-1
2
Atom no_gluten_sandwich(sandw3)
NegatedAtom no_gluten_sandwich(sandw3)
end_variable
begin_variable
var34
-1
2
Atom no_gluten_sandwich(sandw4)
NegatedAtom no_gluten_sandwich(sandw4)
end_variable
begin_variable
var35
-1
2
Atom no_gluten_sandwich(sandw5)
NegatedAtom no_gluten_sandwich(sandw5)
end_variable
begin_variable
var36
-1
2
Atom no_gluten_sandwich(sandw6)
NegatedAtom no_gluten_sandwich(sandw6)
end_variable
begin_variable
var37
-1
2
Atom no_gluten_sandwich(sandw7)
NegatedAtom no_gluten_sandwich(sandw7)
end_variable
begin_variable
var38
-1
2
Atom no_gluten_sandwich(sandw8)
NegatedAtom no_gluten_sandwich(sandw8)
end_variable
begin_variable
var39
-1
2
Atom no_gluten_sandwich(sandw9)
NegatedAtom no_gluten_sandwich(sandw9)
end_variable
begin_variable
var29
-1
2
Atom no_gluten_sandwich(sandw1)
NegatedAtom no_gluten_sandwich(sandw1)
end_variable
begin_variable
var19
-1
5
Atom at_kitchen_sandwich(sandw10)
Atom notexist(sandw10)
Atom ontray(sandw10, tray1)
Atom ontray(sandw10, tray2)
<none of those>
end_variable
begin_variable
var20
-1
5
Atom at_kitchen_sandwich(sandw11)
Atom notexist(sandw11)
Atom ontray(sandw11, tray1)
Atom ontray(sandw11, tray2)
<none of those>
end_variable
begin_variable
var21
-1
5
Atom at_kitchen_sandwich(sandw2)
Atom notexist(sandw2)
Atom ontray(sandw2, tray1)
Atom ontray(sandw2, tray2)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom at_kitchen_bread(bread1)
NegatedAtom at_kitchen_bread(bread1)
end_variable
begin_variable
var11
-1
2
Atom at_kitchen_content(content2)
NegatedAtom at_kitchen_content(content2)
end_variable
begin_variable
var13
-1
2
Atom at_kitchen_content(content4)
NegatedAtom at_kitchen_content(content4)
end_variable
begin_variable
var4
-1
2
Atom at_kitchen_bread(bread3)
NegatedAtom at_kitchen_bread(bread3)
end_variable
begin_variable
var18
-1
5
Atom at_kitchen_sandwich(sandw1)
Atom notexist(sandw1)
Atom ontray(sandw1, tray1)
Atom ontray(sandw1, tray2)
<none of those>
end_variable
begin_variable
var8
-1
2
Atom at_kitchen_bread(bread7)
NegatedAtom at_kitchen_bread(bread7)
end_variable
begin_variable
var14
-1
2
Atom at_kitchen_content(content5)
NegatedAtom at_kitchen_content(content5)
end_variable
begin_variable
var17
-1
2
Atom at_kitchen_content(content8)
NegatedAtom at_kitchen_content(content8)
end_variable
begin_variable
var9
-1
2
Atom at_kitchen_bread(bread8)
NegatedAtom at_kitchen_bread(bread8)
end_variable
begin_variable
var22
-1
5
Atom at_kitchen_sandwich(sandw3)
Atom notexist(sandw3)
Atom ontray(sandw3, tray1)
Atom ontray(sandw3, tray2)
<none of those>
end_variable
begin_variable
var23
-1
5
Atom at_kitchen_sandwich(sandw4)
Atom notexist(sandw4)
Atom ontray(sandw4, tray1)
Atom ontray(sandw4, tray2)
<none of those>
end_variable
begin_variable
var24
-1
5
Atom at_kitchen_sandwich(sandw5)
Atom notexist(sandw5)
Atom ontray(sandw5, tray1)
Atom ontray(sandw5, tray2)
<none of those>
end_variable
begin_variable
var25
-1
5
Atom at_kitchen_sandwich(sandw6)
Atom notexist(sandw6)
Atom ontray(sandw6, tray1)
Atom ontray(sandw6, tray2)
<none of those>
end_variable
begin_variable
var26
-1
5
Atom at_kitchen_sandwich(sandw7)
Atom notexist(sandw7)
Atom ontray(sandw7, tray1)
Atom ontray(sandw7, tray2)
<none of those>
end_variable
begin_variable
var27
-1
5
Atom at_kitchen_sandwich(sandw8)
Atom notexist(sandw8)
Atom ontray(sandw8, tray1)
Atom ontray(sandw8, tray2)
<none of those>
end_variable
begin_variable
var28
-1
5
Atom at_kitchen_sandwich(sandw9)
Atom notexist(sandw9)
Atom ontray(sandw9, tray1)
Atom ontray(sandw9, tray2)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom at_kitchen_bread(bread2)
NegatedAtom at_kitchen_bread(bread2)
end_variable
begin_variable
var10
-1
2
Atom at_kitchen_content(content1)
NegatedAtom at_kitchen_content(content1)
end_variable
begin_variable
var12
-1
2
Atom at_kitchen_content(content3)
NegatedAtom at_kitchen_content(content3)
end_variable
begin_variable
var5
-1
2
Atom at_kitchen_bread(bread4)
NegatedAtom at_kitchen_bread(bread4)
end_variable
begin_variable
var6
-1
2
Atom at_kitchen_bread(bread5)
NegatedAtom at_kitchen_bread(bread5)
end_variable
begin_variable
var15
-1
2
Atom at_kitchen_content(content6)
NegatedAtom at_kitchen_content(content6)
end_variable
begin_variable
var16
-1
2
Atom at_kitchen_content(content7)
NegatedAtom at_kitchen_content(content7)
end_variable
begin_variable
var7
-1
2
Atom at_kitchen_bread(bread6)
NegatedAtom at_kitchen_bread(bread6)
end_variable
begin_variable
var46
-1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
1088
3
1 1
30 2
10 0
0
1081
3
0 1
29 3
9 0
0
1080
3
1 1
29 2
9 0
0
1073
3
0 1
28 3
8 0
0
1072
3
1 1
28 2
8 0
0
1065
3
0 1
27 3
7 0
0
1064
3
1 1
27 2
7 0
0
1016
3
1 1
20 2
12 0
0
1056
3
1 1
26 2
6 0
0
1049
3
0 1
25 3
5 0
0
1048
3
1 1
25 2
5 0
0
1041
3
0 1
15 3
4 0
0
1040
3
1 1
15 2
4 0
0
1033
3
0 1
14 3
3 0
0
1032
3
1 1
14 2
3 0
0
1025
3
0 1
13 3
2 0
0
1024
3
1 1
13 2
2 0
0
1017
3
0 1
20 3
12 0
end_DTG
begin_DTG
0
22
0
1055
3
0 1
26 3
6 0
0
1095
3
0 1
31 3
11 0
0
1094
3
1 1
31 2
11 0
0
1087
3
0 1
30 3
10 0
0
1086
3
1 1
30 2
10 0
0
1079
3
0 1
29 3
9 0
0
1078
3
1 1
29 2
9 0
0
1071
3
0 1
28 3
8 0
0
1070
3
1 1
28 2
8 0
0
1063
3
0 1
27 3
7 0
0
1062
3
1 1
27 2
7 0
0
1014
3
1 1
20 2
12 0
0
1054
3
1 1
26 2
6 0
0
1047
3
0 1
25 3
5 0
0
1046
3
1 1
25 2
5 0
0
1039
3
0 1
15 3
4 0
0
1038
3
1 1
15 2
4 0
0
1031
3
0 1
14 3
3 0
0
1030
3
1 1
14 2
3 0
0
1023
3
0 1
13 3
2 0
0
1022
3
1 1
13 2
2 0
0
1015
3
0 1
20 3
12 0
end_DTG
begin_CG
19
20 9
13 9
14 9
15 9
25 9
26 9
27 9
28 9
29 9
30 9
31 9
47 11
43 11
46 11
42 11
41 11
45 11
40 11
44 11
19
20 9
13 9
14 9
15 9
25 9
26 9
27 9
28 9
29 9
30 9
31 9
47 11
43 11
46 11
42 11
41 11
45 11
40 11
44 11
5
13 8
47 2
46 2
45 2
44 2
5
14 8
47 2
46 2
45 2
44 2
5
15 8
47 2
46 2
45 2
44 2
5
25 8
47 2
46 2
45 2
44 2
5
26 8
47 2
46 2
45 2
44 2
5
27 8
47 2
46 2
45 2
44 2
5
28 8
47 2
46 2
45 2
44 2
5
29 8
47 2
46 2
45 2
44 2
5
30 8
47 2
46 2
45 2
44 2
5
31 8
47 2
46 2
45 2
44 2
5
20 8
47 2
46 2
45 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
2 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
3 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
4 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
19
33 11
17 11
34 11
18 11
22 11
37 11
38 11
23 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
19
16 11
32 11
19 11
35 11
36 11
39 11
21 11
24 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
19
16 11
32 11
19 11
35 11
36 11
39 11
21 11
24 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
19
33 11
17 11
34 11
18 11
22 11
37 11
38 11
23 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
12 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
19
33 11
17 11
34 11
18 11
22 11
37 11
38 11
23 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
19
16 11
32 11
19 11
35 11
36 11
39 11
21 11
24 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
19
16 11
32 11
19 11
35 11
36 11
39 11
21 11
24 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
19
33 11
17 11
34 11
18 11
22 11
37 11
38 11
23 11
20 8
13 8
14 8
15 8
25 8
26 8
27 8
28 8
29 8
30 8
31 8
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
5 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
6 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
7 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
8 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
9 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
10 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
25
16 8
32 12
19 8
35 12
36 12
39 12
21 8
24 8
33 12
17 8
34 12
18 8
22 8
37 12
38 12
23 8
11 16
47 2
43 2
46 2
42 2
41 2
45 2
40 2
44 2
30
33 22
17 11
34 22
18 11
22 11
37 22
38 22
23 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
30
16 11
32 22
19 11
35 22
36 22
39 22
21 11
24 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
30
16 11
32 22
19 11
35 22
36 22
39 22
21 11
24 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
30
33 22
17 11
34 22
18 11
22 11
37 22
38 22
23 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
30
33 22
17 11
34 22
18 11
22 11
37 22
38 22
23 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
30
16 11
32 22
19 11
35 22
36 22
39 22
21 11
24 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
30
16 11
32 22
19 11
35 22
36 22
39 22
21 11
24 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
30
33 22
17 11
34 22
18 11
22 11
37 22
38 22
23 11
20 12
13 12
14 12
15 12
25 12
26 12
27 12
28 12
29 12
30 12
31 12
12 4
2 4
3 4
4 4
5 4
6 4
7 4
8 4
9 4
10 4
11 4
0
0
0
0
0
0
0
0
end_CG
