begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var9
-1
18
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f15)
Atom lift-at(f16)
Atom lift-at(f17)
Atom lift-at(f18)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var8
-1
3
Atom boarded(p9)
Atom origin(p9, f13)
Atom served(p9)
end_variable
begin_variable
var7
-1
3
Atom boarded(p8)
Atom origin(p8, f14)
Atom served(p8)
end_variable
begin_variable
var6
-1
3
Atom boarded(p7)
Atom origin(p7, f10)
Atom served(p7)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f10)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f10)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f1)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f8)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f16)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f9)
Atom served(p1)
end_variable
0
begin_state
0
1
1
1
1
1
1
1
1
1
end_state
begin_goal
9
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
end_goal
324
begin_operator
board f1 p4
1
0 0
1
0 6 1 0
0
end_operator
begin_operator
board f10 p5
1
0 1
1
0 5 1 0
0
end_operator
begin_operator
board f10 p6
1
0 1
1
0 4 1 0
0
end_operator
begin_operator
board f10 p7
1
0 1
1
0 3 1 0
0
end_operator
begin_operator
board f13 p9
1
0 4
1
0 1 1 0
0
end_operator
begin_operator
board f14 p8
1
0 5
1
0 2 1 0
0
end_operator
begin_operator
board f16 p2
1
0 7
1
0 8 1 0
0
end_operator
begin_operator
board f8 p3
1
0 16
1
0 7 1 0
0
end_operator
begin_operator
board f9 p1
1
0 17
1
0 9 1 0
0
end_operator
begin_operator
depart f1 p1
1
0 0
1
0 9 0 2
0
end_operator
begin_operator
depart f11 p7
1
0 2
1
0 3 0 2
0
end_operator
begin_operator
depart f11 p8
1
0 2
1
0 2 0 2
0
end_operator
begin_operator
depart f12 p2
1
0 3
1
0 8 0 2
0
end_operator
begin_operator
depart f15 p3
1
0 6
1
0 7 0 2
0
end_operator
begin_operator
depart f17 p6
1
0 8
1
0 4 0 2
0
end_operator
begin_operator
depart f4 p4
1
0 12
1
0 6 0 2
0
end_operator
begin_operator
depart f5 p5
1
0 13
1
0 5 0 2
0
end_operator
begin_operator
depart f7 p9
1
0 15
1
0 1 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 13
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 14
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 15
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 16
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 17
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 13
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 14
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 15
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 16
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 17
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 13
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 14
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 15
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 16
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 17
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 10
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 13
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 14
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 15
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 16
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 17
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 10
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 11
0
end_operator
begin_operator
down




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




2
check 0
switch 0
check 0
check 0
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
17
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 17
171
172
173
174
175
176
177
178
179
180
181
182
183
184
185
186
187
check 17
18
19
20
21
22
23
24
25
26
188
189
190
191
192
193
194
195
check 17
27
28
29
30
31
32
33
34
35
36
196
197
198
199
200
201
202
check 17
37
38
39
40
41
42
43
44
45
46
47
203
204
205
206
207
208
check 17
48
49
50
51
52
53
54
55
56
57
58
59
209
210
211
212
213
check 17
60
61
62
63
64
65
66
67
68
69
70
71
72
214
215
216
217
check 17
73
74
75
76
77
78
79
80
81
82
83
84
85
86
218
219
220
check 17
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
221
222
check 17
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
223
check 17
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
check 17
135
224
225
226
227
228
229
230
231
232
233
234
235
236
237
238
239
check 17
136
137
240
241
242
243
244
245
246
247
248
249
250
251
252
253
254
check 17
138
139
140
255
256
257
258
259
260
261
262
263
264
265
266
267
268
check 17
141
142
143
144
269
270
271
272
273
274
275
276
277
278
279
280
281
check 17
145
146
147
148
149
282
283
284
285
286
287
288
289
290
291
292
293
check 17
150
151
152
153
154
155
294
295
296
297
298
299
300
301
302
303
304
check 17
156
157
158
159
160
161
162
305
306
307
308
309
310
311
312
313
314
check 17
163
164
165
166
167
168
169
170
315
316
317
318
319
320
321
322
323
check 0
end_SG
begin_DTG
17
1
171
0
2
172
0
3
173
0
4
174
0
5
175
0
6
176
0
7
177
0
8
178
0
9
179
0
10
180
0
11
181
0
12
182
0
13
183
0
14
184
0
15
185
0
16
186
0
17
187
0
17
0
18
0
2
188
0
3
189
0
4
190
0
5
191
0
6
192
0
7
193
0
8
194
0
9
195
0
10
19
0
11
20
0
12
21
0
13
22
0
14
23
0
15
24
0
16
25
0
17
26
0
17
0
27
0
1
28
0
3
196
0
4
197
0
5
198
0
6
199
0
7
200
0
8
201
0
9
202
0
10
29
0
11
30
0
12
31
0
13
32
0
14
33
0
15
34
0
16
35
0
17
36
0
17
0
37
0
1
38
0
2
39
0
4
203
0
5
204
0
6
205
0
7
206
0
8
207
0
9
208
0
10
40
0
11
41
0
12
42
0
13
43
0
14
44
0
15
45
0
16
46
0
17
47
0
17
0
48
0
1
49
0
2
50
0
3
51
0
5
209
0
6
210
0
7
211
0
8
212
0
9
213
0
10
52
0
11
53
0
12
54
0
13
55
0
14
56
0
15
57
0
16
58
0
17
59
0
17
0
60
0
1
61
0
2
62
0
3
63
0
4
64
0
6
214
0
7
215
0
8
216
0
9
217
0
10
65
0
11
66
0
12
67
0
13
68
0
14
69
0
15
70
0
16
71
0
17
72
0
17
0
73
0
1
74
0
2
75
0
3
76
0
4
77
0
5
78
0
7
218
0
8
219
0
9
220
0
10
79
0
11
80
0
12
81
0
13
82
0
14
83
0
15
84
0
16
85
0
17
86
0
17
0
87
0
1
88
0
2
89
0
3
90
0
4
91
0
5
92
0
6
93
0
8
221
0
9
222
0
10
94
0
11
95
0
12
96
0
13
97
0
14
98
0
15
99
0
16
100
0
17
101
0
17
0
102
0
1
103
0
2
104
0
3
105
0
4
106
0
5
107
0
6
108
0
7
109
0
9
223
0
10
110
0
11
111
0
12
112
0
13
113
0
14
114
0
15
115
0
16
116
0
17
117
0
17
0
118
0
1
119
0
2
120
0
3
121
0
4
122
0
5
123
0
6
124
0
7
125
0
8
126
0
10
127
0
11
128
0
12
129
0
13
130
0
14
131
0
15
132
0
16
133
0
17
134
0
17
0
135
0
1
224
0
2
225
0
3
226
0
4
227
0
5
228
0
6
229
0
7
230
0
8
231
0
9
232
0
11
233
0
12
234
0
13
235
0
14
236
0
15
237
0
16
238
0
17
239
0
17
0
136
0
1
240
0
2
241
0
3
242
0
4
243
0
5
244
0
6
245
0
7
246
0
8
247
0
9
248
0
10
137
0
12
249
0
13
250
0
14
251
0
15
252
0
16
253
0
17
254
0
17
0
138
0
1
255
0
2
256
0
3
257
0
4
258
0
5
259
0
6
260
0
7
261
0
8
262
0
9
263
0
10
139
0
11
140
0
13
264
0
14
265
0
15
266
0
16
267
0
17
268
0
17
0
141
0
1
269
0
2
270
0
3
271
0
4
272
0
5
273
0
6
274
0
7
275
0
8
276
0
9
277
0
10
142
0
11
143
0
12
144
0
14
278
0
15
279
0
16
280
0
17
281
0
17
0
145
0
1
282
0
2
283
0
3
284
0
4
285
0
5
286
0
6
287
0
7
288
0
8
289
0
9
290
0
10
146
0
11
147
0
12
148
0
13
149
0
15
291
0
16
292
0
17
293
0
17
0
150
0
1
294
0
2
295
0
3
296
0
4
297
0
5
298
0
6
299
0
7
300
0
8
301
0
9
302
0
10
151
0
11
152
0
12
153
0
13
154
0
14
155
0
16
303
0
17
304
0
17
0
156
0
1
305
0
2
306
0
3
307
0
4
308
0
5
309
0
6
310
0
7
311
0
8
312
0
9
313
0
10
157
0
11
158
0
12
159
0
13
160
0
14
161
0
15
162
0
17
314
0
17
0
163
0
1
315
0
2
316
0
3
317
0
4
318
0
5
319
0
6
320
0
7
321
0
8
322
0
9
323
0
10
164
0
11
165
0
12
166
0
13
167
0
14
168
0
15
169
0
16
170
0
end_DTG
begin_DTG
1
2
17
1
0 15
1
0
4
1
0 4
0
end_DTG
begin_DTG
1
2
11
1
0 2
1
0
5
1
0 5
0
end_DTG
begin_DTG
1
2
10
1
0 2
1
0
3
1
0 1
0
end_DTG
begin_DTG
1
2
14
1
0 8
1
0
2
1
0 1
0
end_DTG
begin_DTG
1
2
16
1
0 13
1
0
1
1
0 1
0
end_DTG
begin_DTG
1
2
15
1
0 12
1
0
0
1
0 0
0
end_DTG
begin_DTG
1
2
13
1
0 6
1
0
7
1
0 16
0
end_DTG
begin_DTG
1
2
12
1
0 3
1
0
6
1
0 7
0
end_DTG
begin_DTG
1
2
9
1
0 0
1
0
8
1
0 17
0
end_DTG
begin_CG
9
9 2
8 2
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
0
0
end_CG
