begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var8
-1
16
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f15)
Atom lift-at(f16)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var7
-1
3
Atom boarded(p8)
Atom origin(p8, f6)
Atom served(p8)
end_variable
begin_variable
var6
-1
3
Atom boarded(p7)
Atom origin(p7, f13)
Atom served(p7)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f5)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f12)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f6)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f11)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f10)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f4)
Atom served(p1)
end_variable
0
begin_state
3
1
1
1
1
1
1
1
1
end_state
begin_goal
8
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
end_goal
256
begin_operator
board f10 p2
1
0 1
1
0 7 1 0
0
end_operator
begin_operator
board f11 p3
1
0 2
1
0 6 1 0
0
end_operator
begin_operator
board f12 p5
1
0 3
1
0 4 1 0
0
end_operator
begin_operator
board f13 p7
1
0 4
1
0 2 1 0
0
end_operator
begin_operator
board f4 p1
1
0 10
1
0 8 1 0
0
end_operator
begin_operator
board f5 p6
1
0 11
1
0 3 1 0
0
end_operator
begin_operator
board f6 p4
1
0 12
1
0 5 1 0
0
end_operator
begin_operator
board f6 p8
1
0 12
1
0 1 1 0
0
end_operator
begin_operator
depart f1 p1
1
0 0
1
0 8 0 2
0
end_operator
begin_operator
depart f15 p4
1
0 6
1
0 5 0 2
0
end_operator
begin_operator
depart f15 p8
1
0 6
1
0 1 0 2
0
end_operator
begin_operator
depart f2 p6
1
0 8
1
0 3 0 2
0
end_operator
begin_operator
depart f3 p5
1
0 9
1
0 4 0 2
0
end_operator
begin_operator
depart f5 p3
1
0 11
1
0 6 0 2
0
end_operator
begin_operator
depart f6 p7
1
0 12
1
0 2 0 2
0
end_operator
begin_operator
depart f9 p2
1
0 15
1
0 7 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 13
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 14
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 15
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 8
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 13
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 14
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 15
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 8
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 13
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 14
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 15
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 8
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 9
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 10
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 13
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 14
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 15
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 8
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 9
0
end_operator
begin_operator
down f14 f4
0
1
0 0 5 10
0
end_operator
begin_operator
down f14 f5
0
1
0 0 5 11
0
end_operator
begin_operator
down f14 f6
0
1
0 0 5 12
0
end_operator
begin_operator
down f14 f7
0
1
0 0 5 13
0
end_operator
begin_operator
down f14 f8
0
1
0 0 5 14
0
end_operator
begin_oper




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




check 0
check 0
check 0
check 0
check 0
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
12
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
14
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 15
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
check 15
16
17
18
19
20
21
22
23
24
151
152
153
154
155
156
check 15
25
26
27
28
29
30
31
32
33
34
157
158
159
160
161
check 15
35
36
37
38
39
40
41
42
43
44
45
162
163
164
165
check 15
46
47
48
49
50
51
52
53
54
55
56
57
166
167
168
check 15
58
59
60
61
62
63
64
65
66
67
68
69
70
169
170
check 15
71
72
73
74
75
76
77
78
79
80
81
82
83
84
171
check 15
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
check 15
100
172
173
174
175
176
177
178
179
180
181
182
183
184
185
check 15
101
102
186
187
188
189
190
191
192
193
194
195
196
197
198
check 15
103
104
105
199
200
201
202
203
204
205
206
207
208
209
210
check 15
106
107
108
109
211
212
213
214
215
216
217
218
219
220
221
check 15
110
111
112
113
114
222
223
224
225
226
227
228
229
230
231
check 15
115
116
117
118
119
120
232
233
234
235
236
237
238
239
240
check 15
121
122
123
124
125
126
127
241
242
243
244
245
246
247
248
check 15
128
129
130
131
132
133
134
135
249
250
251
252
253
254
255
check 0
end_SG
begin_DTG
15
1
136
0
2
137
0
3
138
0
4
139
0
5
140
0
6
141
0
7
142
0
8
143
0
9
144
0
10
145
0
11
146
0
12
147
0
13
148
0
14
149
0
15
150
0
15
0
16
0
2
151
0
3
152
0
4
153
0
5
154
0
6
155
0
7
156
0
8
17
0
9
18
0
10
19
0
11
20
0
12
21
0
13
22
0
14
23
0
15
24
0
15
0
25
0
1
26
0
3
157
0
4
158
0
5
159
0
6
160
0
7
161
0
8
27
0
9
28
0
10
29
0
11
30
0
12
31
0
13
32
0
14
33
0
15
34
0
15
0
35
0
1
36
0
2
37
0
4
162
0
5
163
0
6
164
0
7
165
0
8
38
0
9
39
0
10
40
0
11
41
0
12
42
0
13
43
0
14
44
0
15
45
0
15
0
46
0
1
47
0
2
48
0
3
49
0
5
166
0
6
167
0
7
168
0
8
50
0
9
51
0
10
52
0
11
53
0
12
54
0
13
55
0
14
56
0
15
57
0
15
0
58
0
1
59
0
2
60
0
3
61
0
4
62
0
6
169
0
7
170
0
8
63
0
9
64
0
10
65
0
11
66
0
12
67
0
13
68
0
14
69
0
15
70
0
15
0
71
0
1
72
0
2
73
0
3
74
0
4
75
0
5
76
0
7
171
0
8
77
0
9
78
0
10
79
0
11
80
0
12
81
0
13
82
0
14
83
0
15
84
0
15
0
85
0
1
86
0
2
87
0
3
88
0
4
89
0
5
90
0
6
91
0
8
92
0
9
93
0
10
94
0
11
95
0
12
96
0
13
97
0
14
98
0
15
99
0
15
0
100
0
1
172
0
2
173
0
3
174
0
4
175
0
5
176
0
6
177
0
7
178
0
9
179
0
10
180
0
11
181
0
12
182
0
13
183
0
14
184
0
15
185
0
15
0
101
0
1
186
0
2
187
0
3
188
0
4
189
0
5
190
0
6
191
0
7
192
0
8
102
0
10
193
0
11
194
0
12
195
0
13
196
0
14
197
0
15
198
0
15
0
103
0
1
199
0
2
200
0
3
201
0
4
202
0
5
203
0
6
204
0
7
205
0
8
104
0
9
105
0
11
206
0
12
207
0
13
208
0
14
209
0
15
210
0
15
0
106
0
1
211
0
2
212
0
3
213
0
4
214
0
5
215
0
6
216
0
7
217
0
8
107
0
9
108
0
10
109
0
12
218
0
13
219
0
14
220
0
15
221
0
15
0
110
0
1
222
0
2
223
0
3
224
0
4
225
0
5
226
0
6
227
0
7
228
0
8
111
0
9
112
0
10
113
0
11
114
0
13
229
0
14
230
0
15
231
0
15
0
115
0
1
232
0
2
233
0
3
234
0
4
235
0
5
236
0
6
237
0
7
238
0
8
116
0
9
117
0
10
118
0
11
119
0
12
120
0
14
239
0
15
240
0
15
0
121
0
1
241
0
2
242
0
3
243
0
4
244
0
5
245
0
6
246
0
7
247
0
8
122
0
9
123
0
10
124
0
11
125
0
12
126
0
13
127
0
15
248
0
15
0
128
0
1
249
0
2
250
0
3
251
0
4
252
0
5
253
0
6
254
0
7
255
0
8
129
0
9
130
0
10
131
0
11
132
0
12
133
0
13
134
0
14
135
0
end_DTG
begin_DTG
1
2
10
1
0 6
1
0
7
1
0 12
0
end_DTG
begin_DTG
1
2
14
1
0 12
1
0
3
1
0 4
0
end_DTG
begin_DTG
1
2
11
1
0 8
1
0
5
1
0 11
0
end_DTG
begin_DTG
1
2
12
1
0 9
1
0
2
1
0 3
0
end_DTG
begin_DTG
1
2
9
1
0 6
1
0
6
1
0 12
0
end_DTG
begin_DTG
1
2
13
1
0 11
1
0
1
1
0 2
0
end_DTG
begin_DTG
1
2
15
1
0 15
1
0
0
1
0 1
0
end_DTG
begin_DTG
1
2
8
1
0 0
1
0
4
1
0 10
0
end_DTG
begin_CG
8
8 2
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
0
end_CG
