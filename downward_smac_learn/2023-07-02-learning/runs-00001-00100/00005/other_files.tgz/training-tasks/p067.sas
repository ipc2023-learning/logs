begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var7
-1
14
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var6
-1
3
Atom boarded(p7)
Atom origin(p7, f7)
Atom served(p7)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f6)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f11)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f14)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f5)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f14)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f3)
Atom served(p1)
end_variable
0
begin_state
13
1
1
1
1
1
1
1
end_state
begin_goal
7
1 2
2 2
3 2
4 2
5 2
6 2
7 2
end_goal
196
begin_operator
board f11 p5
1
0 2
1
0 3 1 0
0
end_operator
begin_operator
board f14 p2
1
0 5
1
0 6 1 0
0
end_operator
begin_operator
board f14 p4
1
0 5
1
0 4 1 0
0
end_operator
begin_operator
board f3 p1
1
0 7
1
0 7 1 0
0
end_operator
begin_operator
board f5 p3
1
0 9
1
0 5 1 0
0
end_operator
begin_operator
board f6 p6
1
0 10
1
0 2 1 0
0
end_operator
begin_operator
board f7 p7
1
0 11
1
0 1 1 0
0
end_operator
begin_operator
depart f1 p4
1
0 0
1
0 4 0 2
0
end_operator
begin_operator
depart f11 p7
1
0 2
1
0 1 0 2
0
end_operator
begin_operator
depart f2 p1
1
0 6
1
0 7 0 2
0
end_operator
begin_operator
depart f5 p2
1
0 9
1
0 6 0 2
0
end_operator
begin_operator
depart f5 p6
1
0 9
1
0 2 0 2
0
end_operator
begin_operator
depart f8 p3
1
0 12
1
0 5 0 2
0
end_operator
begin_operator
depart f8 p5
1
0 12
1
0 3 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 6
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 13
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 6
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 7
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 8
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 13
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 6
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 7
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 8
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 13
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 6
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 7
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 8
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 9
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 10
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 13
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 6
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 7
0
end_operator
begin_operator
down f14 f4
0
1
0 0 5 8
0
end_operator
begin_operator
down f14 f5
0
1
0 0 5 9
0
end_operator
begin_operator
down f14 f6
0
1
0 0 5 10
0
end_operator
begin_operator
down f14 f7
0
1
0 0 5 11
0
end_operator
begin_operator
down f14 f8
0
1
0 0 5 12
0
end_operator
begin_operator
down f14 f9
0
1
0 0 5 13
0
end_operator
begin_operator
down f2 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 7 6
0
end_operator
begin_operator
down f4 f1
0
1
0 0 8 0
0
end_operator
begin_op




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




perator
begin_operator
up f8 f9
0
1
0 0 12 13
0
end_operator
begin_operator
up f9 f10
0
1
0 0 13 1
0
end_operator
begin_operator
up f9 f11
0
1
0 0 13 2
0
end_operator
begin_operator
up f9 f12
0
1
0 0 13 3
0
end_operator
begin_operator
up f9 f13
0
1
0 0 13 4
0
end_operator
begin_operator
up f9 f14
0
1
0 0 13 5
0
end_operator
0
begin_SG
switch 7
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 6
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
12
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
13
check 0
check 0
switch 0
check 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
switch 0
check 0
check 13
105
106
107
108
109
110
111
112
113
114
115
116
117
check 13
14
15
16
17
18
19
20
21
22
118
119
120
121
check 13
23
24
25
26
27
28
29
30
31
32
122
123
124
check 13
33
34
35
36
37
38
39
40
41
42
43
125
126
check 13
44
45
46
47
48
49
50
51
52
53
54
55
127
check 13
56
57
58
59
60
61
62
63
64
65
66
67
68
check 13
69
128
129
130
131
132
133
134
135
136
137
138
139
check 13
70
71
140
141
142
143
144
145
146
147
148
149
150
check 13
72
73
74
151
152
153
154
155
156
157
158
159
160
check 13
75
76
77
78
161
162
163
164
165
166
167
168
169
check 13
79
80
81
82
83
170
171
172
173
174
175
176
177
check 13
84
85
86
87
88
89
178
179
180
181
182
183
184
check 13
90
91
92
93
94
95
96
185
186
187
188
189
190
check 13
97
98
99
100
101
102
103
104
191
192
193
194
195
check 0
end_SG
begin_DTG
13
1
105
0
2
106
0
3
107
0
4
108
0
5
109
0
6
110
0
7
111
0
8
112
0
9
113
0
10
114
0
11
115
0
12
116
0
13
117
0
13
0
14
0
2
118
0
3
119
0
4
120
0
5
121
0
6
15
0
7
16
0
8
17
0
9
18
0
10
19
0
11
20
0
12
21
0
13
22
0
13
0
23
0
1
24
0
3
122
0
4
123
0
5
124
0
6
25
0
7
26
0
8
27
0
9
28
0
10
29
0
11
30
0
12
31
0
13
32
0
13
0
33
0
1
34
0
2
35
0
4
125
0
5
126
0
6
36
0
7
37
0
8
38
0
9
39
0
10
40
0
11
41
0
12
42
0
13
43
0
13
0
44
0
1
45
0
2
46
0
3
47
0
5
127
0
6
48
0
7
49
0
8
50
0
9
51
0
10
52
0
11
53
0
12
54
0
13
55
0
13
0
56
0
1
57
0
2
58
0
3
59
0
4
60
0
6
61
0
7
62
0
8
63
0
9
64
0
10
65
0
11
66
0
12
67
0
13
68
0
13
0
69
0
1
128
0
2
129
0
3
130
0
4
131
0
5
132
0
7
133
0
8
134
0
9
135
0
10
136
0
11
137
0
12
138
0
13
139
0
13
0
70
0
1
140
0
2
141
0
3
142
0
4
143
0
5
144
0
6
71
0
8
145
0
9
146
0
10
147
0
11
148
0
12
149
0
13
150
0
13
0
72
0
1
151
0
2
152
0
3
153
0
4
154
0
5
155
0
6
73
0
7
74
0
9
156
0
10
157
0
11
158
0
12
159
0
13
160
0
13
0
75
0
1
161
0
2
162
0
3
163
0
4
164
0
5
165
0
6
76
0
7
77
0
8
78
0
10
166
0
11
167
0
12
168
0
13
169
0
13
0
79
0
1
170
0
2
171
0
3
172
0
4
173
0
5
174
0
6
80
0
7
81
0
8
82
0
9
83
0
11
175
0
12
176
0
13
177
0
13
0
84
0
1
178
0
2
179
0
3
180
0
4
181
0
5
182
0
6
85
0
7
86
0
8
87
0
9
88
0
10
89
0
12
183
0
13
184
0
13
0
90
0
1
185
0
2
186
0
3
187
0
4
188
0
5
189
0
6
91
0
7
92
0
8
93
0
9
94
0
10
95
0
11
96
0
13
190
0
13
0
97
0
1
191
0
2
192
0
3
193
0
4
194
0
5
195
0
6
98
0
7
99
0
8
100
0
9
101
0
10
102
0
11
103
0
12
104
0
end_DTG
begin_DTG
1
2
8
1
0 2
1
0
6
1
0 11
0
end_DTG
begin_DTG
1
2
11
1
0 9
1
0
5
1
0 10
0
end_DTG
begin_DTG
1
2
13
1
0 12
1
0
0
1
0 2
0
end_DTG
begin_DTG
1
2
7
1
0 0
1
0
2
1
0 5
0
end_DTG
begin_DTG
1
2
12
1
0 12
1
0
4
1
0 9
0
end_DTG
begin_DTG
1
2
10
1
0 9
1
0
1
1
0 5
0
end_DTG
begin_DTG
1
2
9
1
0 6
1
0
3
1
0 7
0
end_DTG
begin_CG
7
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
end_CG
