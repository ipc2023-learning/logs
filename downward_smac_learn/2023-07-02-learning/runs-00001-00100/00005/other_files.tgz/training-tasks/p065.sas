begin_version
3
end_version
begin_metric
0
end_metric
7
begin_variable
var6
-1
14
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f13)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f13)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f5)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f13)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f9)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f9)
Atom served(p1)
end_variable
0
begin_state
11
1
1
1
1
1
1
end_state
begin_goal
6
1 2
2 2
3 2
4 2
5 2
6 2
end_goal
194
begin_operator
board f13 p3
1
0 4
1
0 4 1 0
0
end_operator
begin_operator
board f13 p5
1
0 4
1
0 2 1 0
0
end_operator
begin_operator
board f13 p6
1
0 4
1
0 1 1 0
0
end_operator
begin_operator
board f5 p4
1
0 9
1
0 3 1 0
0
end_operator
begin_operator
board f9 p1
1
0 13
1
0 6 1 0
0
end_operator
begin_operator
board f9 p2
1
0 13
1
0 5 1 0
0
end_operator
begin_operator
depart f10 p2
1
0 1
1
0 5 0 2
0
end_operator
begin_operator
depart f10 p3
1
0 1
1
0 4 0 2
0
end_operator
begin_operator
depart f11 p1
1
0 2
1
0 6 0 2
0
end_operator
begin_operator
depart f11 p5
1
0 2
1
0 2 0 2
0
end_operator
begin_operator
depart f14 p4
1
0 5
1
0 3 0 2
0
end_operator
begin_operator
depart f14 p6
1
0 5
1
0 1 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 6
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 13
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 6
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 7
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 8
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 13
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 6
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 7
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 8
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 13
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 6
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 7
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 8
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 9
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 10
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 13
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 6
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 7
0
end_operator
begin_operator
down f14 f4
0
1
0 0 5 8
0
end_operator
begin_operator
down f14 f5
0
1
0 0 5 9
0
end_operator
begin_operator
down f14 f6
0
1
0 0 5 10
0
end_operator
begin_operator
down f14 f7
0
1
0 0 5 11
0
end_operator
begin_operator
down f14 f8
0
1
0 0 5 12
0
end_operator
begin_operator
down f14 f9
0
1
0 0 5 13
0
end_operator
begin_operator
down f2 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 7 6
0
end_operator
begin_operator
down f4 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 8 6
0
end_operator
begin_operator
down f4 f3
0
1
0 0 8 7
0
end_operator
begin_operator
down f5 f1
0
1
0 0 9 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 9 6
0
end_operator
begin_o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




begin_operator
up f7 f8
0
1
0 0 11 12
0
end_operator
begin_operator
up f7 f9
0
1
0 0 11 13
0
end_operator
begin_operator
up f8 f10
0
1
0 0 12 1
0
end_operator
begin_operator
up f8 f11
0
1
0 0 12 2
0
end_operator
begin_operator
up f8 f12
0
1
0 0 12 3
0
end_operator
begin_operator
up f8 f13
0
1
0 0 12 4
0
end_operator
begin_operator
up f8 f14
0
1
0 0 12 5
0
end_operator
begin_operator
up f8 f9
0
1
0 0 12 13
0
end_operator
begin_operator
up f9 f10
0
1
0 0 13 1
0
end_operator
begin_operator
up f9 f11
0
1
0 0 13 2
0
end_operator
begin_operator
up f9 f12
0
1
0 0 13 3
0
end_operator
begin_operator
up f9 f13
0
1
0 0 13 4
0
end_operator
begin_operator
up f9 f14
0
1
0 0 13 5
0
end_operator
0
begin_SG
switch 6
check 0
switch 0
check 0
check 0
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
switch 5
check 0
switch 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
switch 4
check 0
switch 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
11
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 13
103
104
105
106
107
108
109
110
111
112
113
114
115
check 13
12
13
14
15
16
17
18
19
20
116
117
118
119
check 13
21
22
23
24
25
26
27
28
29
30
120
121
122
check 13
31
32
33
34
35
36
37
38
39
40
41
123
124
check 13
42
43
44
45
46
47
48
49
50
51
52
53
125
check 13
54
55
56
57
58
59
60
61
62
63
64
65
66
check 13
67
126
127
128
129
130
131
132
133
134
135
136
137
check 13
68
69
138
139
140
141
142
143
144
145
146
147
148
check 13
70
71
72
149
150
151
152
153
154
155
156
157
158
check 13
73
74
75
76
159
160
161
162
163
164
165
166
167
check 13
77
78
79
80
81
168
169
170
171
172
173
174
175
check 13
82
83
84
85
86
87
176
177
178
179
180
181
182
check 13
88
89
90
91
92
93
94
183
184
185
186
187
188
check 13
95
96
97
98
99
100
101
102
189
190
191
192
193
check 0
end_SG
begin_DTG
13
1
103
0
2
104
0
3
105
0
4
106
0
5
107
0
6
108
0
7
109
0
8
110
0
9
111
0
10
112
0
11
113
0
12
114
0
13
115
0
13
0
12
0
2
116
0
3
117
0
4
118
0
5
119
0
6
13
0
7
14
0
8
15
0
9
16
0
10
17
0
11
18
0
12
19
0
13
20
0
13
0
21
0
1
22
0
3
120
0
4
121
0
5
122
0
6
23
0
7
24
0
8
25
0
9
26
0
10
27
0
11
28
0
12
29
0
13
30
0
13
0
31
0
1
32
0
2
33
0
4
123
0
5
124
0
6
34
0
7
35
0
8
36
0
9
37
0
10
38
0
11
39
0
12
40
0
13
41
0
13
0
42
0
1
43
0
2
44
0
3
45
0
5
125
0
6
46
0
7
47
0
8
48
0
9
49
0
10
50
0
11
51
0
12
52
0
13
53
0
13
0
54
0
1
55
0
2
56
0
3
57
0
4
58
0
6
59
0
7
60
0
8
61
0
9
62
0
10
63
0
11
64
0
12
65
0
13
66
0
13
0
67
0
1
126
0
2
127
0
3
128
0
4
129
0
5
130
0
7
131
0
8
132
0
9
133
0
10
134
0
11
135
0
12
136
0
13
137
0
13
0
68
0
1
138
0
2
139
0
3
140
0
4
141
0
5
142
0
6
69
0
8
143
0
9
144
0
10
145
0
11
146
0
12
147
0
13
148
0
13
0
70
0
1
149
0
2
150
0
3
151
0
4
152
0
5
153
0
6
71
0
7
72
0
9
154
0
10
155
0
11
156
0
12
157
0
13
158
0
13
0
73
0
1
159
0
2
160
0
3
161
0
4
162
0
5
163
0
6
74
0
7
75
0
8
76
0
10
164
0
11
165
0
12
166
0
13
167
0
13
0
77
0
1
168
0
2
169
0
3
170
0
4
171
0
5
172
0
6
78
0
7
79
0
8
80
0
9
81
0
11
173
0
12
174
0
13
175
0
13
0
82
0
1
176
0
2
177
0
3
178
0
4
179
0
5
180
0
6
83
0
7
84
0
8
85
0
9
86
0
10
87
0
12
181
0
13
182
0
13
0
88
0
1
183
0
2
184
0
3
185
0
4
186
0
5
187
0
6
89
0
7
90
0
8
91
0
9
92
0
10
93
0
11
94
0
13
188
0
13
0
95
0
1
189
0
2
190
0
3
191
0
4
192
0
5
193
0
6
96
0
7
97
0
8
98
0
9
99
0
10
100
0
11
101
0
12
102
0
end_DTG
begin_DTG
1
2
11
1
0 5
1
0
2
1
0 4
0
end_DTG
begin_DTG
1
2
9
1
0 2
1
0
1
1
0 4
0
end_DTG
begin_DTG
1
2
10
1
0 5
1
0
3
1
0 9
0
end_DTG
begin_DTG
1
2
7
1
0 1
1
0
0
1
0 4
0
end_DTG
begin_DTG
1
2
6
1
0 1
1
0
5
1
0 13
0
end_DTG
begin_DTG
1
2
8
1
0 2
1
0
4
1
0 13
0
end_DTG
begin_CG
6
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
end_CG
