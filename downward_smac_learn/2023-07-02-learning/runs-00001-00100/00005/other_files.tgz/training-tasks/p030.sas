begin_version
3
end_version
begin_metric
0
end_metric
3
begin_variable
var2
-1
7
Atom lift-at(f1)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f5)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f3)
Atom served(p1)
end_variable
0
begin_state
0
1
1
end_state
begin_goal
2
1 2
2 2
end_goal
46
begin_operator
board f3 p1
1
0 2
1
0 2 1 0
0
end_operator
begin_operator
board f5 p2
1
0 4
1
0 1 1 0
0
end_operator
begin_operator
depart f1 p2
1
0 0
1
0 1 0 2
0
end_operator
begin_operator
depart f6 p1
1
0 5
1
0 2 0 2
0
end_operator
begin_operator
down f2 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 2 1
0
end_operator
begin_operator
down f4 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 3 1
0
end_operator
begin_operator
down f4 f3
0
1
0 0 3 2
0
end_operator
begin_operator
down f5 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 4 1
0
end_operator
begin_operator
down f5 f3
0
1
0 0 4 2
0
end_operator
begin_operator
down f5 f4
0
1
0 0 4 3
0
end_operator
begin_operator
down f6 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 5 1
0
end_operator
begin_operator
down f6 f3
0
1
0 0 5 2
0
end_operator
begin_operator
down f6 f4
0
1
0 0 5 3
0
end_operator
begin_operator
down f6 f5
0
1
0 0 5 4
0
end_operator
begin_operator
down f7 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 6 1
0
end_operator
begin_operator
down f7 f3
0
1
0 0 6 2
0
end_operator
begin_operator
down f7 f4
0
1
0 0 6 3
0
end_operator
begin_operator
down f7 f5
0
1
0 0 6 4
0
end_operator
begin_operator
down f7 f6
0
1
0 0 6 5
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 4
0
end_operator
begin_operator
up f1 f6
0
1
0 0 0 5
0
end_operator
begin_operator
up f1 f7
0
1
0 0 0 6
0
end_operator
begin_operator
up f2 f3
0
1
0 0 1 2
0
end_operator
begin_operator
up f2 f4
0
1
0 0 1 3
0
end_operator
begin_operator
up f2 f5
0
1
0 0 1 4
0
end_operator
begin_operator
up f2 f6
0
1
0 0 1 5
0
end_operator
begin_operator
up f2 f7
0
1
0 0 1 6
0
end_operator
begin_operator
up f3 f4
0
1
0 0 2 3
0
end_operator
begin_operator
up f3 f5
0
1
0 0 2 4
0
end_operator
begin_operator
up f3 f6
0
1
0 0 2 5
0
end_operator
begin_operator
up f3 f7
0
1
0 0 2 6
0
end_operator
begin_operator
up f4 f5
0
1
0 0 3 4
0
end_operator
begin_operator
up f4 f6
0
1
0 0 3 5
0
end_operator
begin_operator
up f4 f7
0
1
0 0 3 6
0
end_operator
begin_operator
up f5 f6
0
1
0 0 4 5
0
end_operator
begin_operator
up f5 f7
0
1
0 0 4 6
0
end_operator
begin_operator
up f6 f7
0
1
0 0 5 6
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
switch 0
check 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
switch 0
check 0
check 6
25
26
27
28
29
30
check 6
4
31
32
33
34
35
check 6
5
6
36
37
38
39
check 6
7
8
9
40
41
42
check 6
10
11
12
13
43
44
check 6
14
15
16
17
18
45
check 6
19
20
21
22
23
24
check 0
end_SG
begin_DTG
6
1
25
0
2
26
0
3
27
0
4
28
0
5
29
0
6
30
0
6
0
4
0
2
31
0
3
32
0
4
33
0
5
34
0
6
35
0
6
0
5
0
1
6
0
3
36
0
4
37
0
5
38
0
6
39
0
6
0
7
0
1
8
0
2
9
0
4
40
0
5
41
0
6
42
0
6
0
10
0
1
11
0
2
12
0
3
13
0
5
43
0
6
44
0
6
0
14
0
1
15
0
2
16
0
3
17
0
4
18
0
6
45
0
6
0
19
0
1
20
0
2
21
0
3
22
0
4
23
0
5
24
0
end_DTG
begin_DTG
1
2
2
1
0 0
1
0
1
1
0 4
0
end_DTG
begin_DTG
1
2
3
1
0 5
1
0
0
1
0 2
0
end_DTG
begin_CG
2
2 2
1 2
0
0
end_CG
