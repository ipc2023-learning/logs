begin_version
3
end_version
begin_metric
0
end_metric
7
begin_variable
var6
-1
12
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f11)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f10)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f8)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f4)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f2)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f12)
Atom served(p1)
end_variable
0
begin_state
6
1
1
1
1
1
1
end_state
begin_goal
6
1 2
2 2
3 2
4 2
5 2
6 2
end_goal
144
begin_operator
board f10 p5
1
0 1
1
0 2 1 0
0
end_operator
begin_operator
board f11 p6
1
0 2
1
0 1 1 0
0
end_operator
begin_operator
board f12 p1
1
0 3
1
0 6 1 0
0
end_operator
begin_operator
board f2 p2
1
0 4
1
0 5 1 0
0
end_operator
begin_operator
board f4 p3
1
0 6
1
0 4 1 0
0
end_operator
begin_operator
board f8 p4
1
0 10
1
0 3 1 0
0
end_operator
begin_operator
depart f10 p1
1
0 1
1
0 6 0 2
0
end_operator
begin_operator
depart f4 p5
1
0 6
1
0 2 0 2
0
end_operator
begin_operator
depart f5 p3
1
0 7
1
0 4 0 2
0
end_operator
begin_operator
depart f6 p4
1
0 8
1
0 3 0 2
0
end_operator
begin_operator
depart f7 p2
1
0 9
1
0 5 0 2
0
end_operator
begin_operator
depart f7 p6
1
0 9
1
0 1 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 4
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 5
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 6
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 11
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 4
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 5
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 6
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 7
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 8
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 11
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 4
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 5
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 6
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 7
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 8
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 11
0
end_operator
begin_operator
down f2 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 5 4
0
end_operator
begin_operator
down f4 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 6 4
0
end_operator
begin_operator
down f4 f3
0
1
0 0 6 5
0
end_operator
begin_operator
down f5 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 7 4
0
end_operator
begin_operator
down f5 f3
0
1
0 0 7 5
0
end_operator
begin_operator
down f5 f4
0
1
0 0 7 6
0
end_operator
begin_operator
down f6 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 8 4
0
end_operator
begin_operator
down f6 f3
0
1
0 0 8 5
0
end_operator
begin_operator
down f6 f4
0
1
0 0 8 6
0
end_operator
begin_operator
down f6 f5
0
1
0 0 8 7
0
end_operator
begin_operator
down f7 f1
0
1
0 0 9 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 9 4
0
end_operator
begin_operator
down f7 f3
0
1
0 0 9 5
0
end_operator
begin_operator
down f7 f4
0
1
0 0 9 6
0
end_operator
begin_operator
down f7 f5
0
1
0 0 9 7
0
end_operator
begin_operator
down f7 f6
0
1
0 0 9 8
0
end_operator
begin_operator
down f8 f1
0
1
0 0 10 0
0
end_operator
begin_operator
down f8 f2
0
1
0 0 10 4
0
end_operator
begin_operator
down f8 f3
0
1
0 0 10 5
0
end_operator
begin_operator
down f8 f4
0
1
0 0 10 6
0
end_operator
begin_operator
down f8 f5
0
1
0 0 10 7
0
end_operator
begin_operator
down f8 f6
0
1
0 0 10 8
0
end_operator
begin_operator
down f8 f7
0
1
0 0 10 9
0
end_operator
begin_operator
down f9 f1
0
1
0 0 11 0
0
end_operator
begin_operator
down f9 f2
0
1
0 0 11 4
0
end_operator
begin_operator
down f9 f3
0
1
0 0 11 5
0
end_operator
begin_operator
down f9 f4
0
1
0 0 11 6
0
end_operator
begin_operator
down f9 f5
0
1
0 0 11 7
0
end_operator
begin_operator
down f9 f6
0
1
0 0 11 8
0
end_operator
begin_operator
down f9 f7
0
1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





1
0 0 6 7
0
end_operator
begin_operator
up f4 f6
0
1
0 0 6 8
0
end_operator
begin_operator
up f4 f7
0
1
0 0 6 9
0
end_operator
begin_operator
up f4 f8
0
1
0 0 6 10
0
end_operator
begin_operator
up f4 f9
0
1
0 0 6 11
0
end_operator
begin_operator
up f5 f10
0
1
0 0 7 1
0
end_operator
begin_operator
up f5 f11
0
1
0 0 7 2
0
end_operator
begin_operator
up f5 f12
0
1
0 0 7 3
0
end_operator
begin_operator
up f5 f6
0
1
0 0 7 8
0
end_operator
begin_operator
up f5 f7
0
1
0 0 7 9
0
end_operator
begin_operator
up f5 f8
0
1
0 0 7 10
0
end_operator
begin_operator
up f5 f9
0
1
0 0 7 11
0
end_operator
begin_operator
up f6 f10
0
1
0 0 8 1
0
end_operator
begin_operator
up f6 f11
0
1
0 0 8 2
0
end_operator
begin_operator
up f6 f12
0
1
0 0 8 3
0
end_operator
begin_operator
up f6 f7
0
1
0 0 8 9
0
end_operator
begin_operator
up f6 f8
0
1
0 0 8 10
0
end_operator
begin_operator
up f6 f9
0
1
0 0 8 11
0
end_operator
begin_operator
up f7 f10
0
1
0 0 9 1
0
end_operator
begin_operator
up f7 f11
0
1
0 0 9 2
0
end_operator
begin_operator
up f7 f12
0
1
0 0 9 3
0
end_operator
begin_operator
up f7 f8
0
1
0 0 9 10
0
end_operator
begin_operator
up f7 f9
0
1
0 0 9 11
0
end_operator
begin_operator
up f8 f10
0
1
0 0 10 1
0
end_operator
begin_operator
up f8 f11
0
1
0 0 10 2
0
end_operator
begin_operator
up f8 f12
0
1
0 0 10 3
0
end_operator
begin_operator
up f8 f9
0
1
0 0 10 11
0
end_operator
begin_operator
up f9 f10
0
1
0 0 11 1
0
end_operator
begin_operator
up f9 f11
0
1
0 0 11 2
0
end_operator
begin_operator
up f9 f12
0
1
0 0 11 3
0
end_operator
0
begin_SG
switch 6
check 0
switch 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
10
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
9
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
11
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 11
78
79
80
81
82
83
84
85
86
87
88
check 11
12
13
14
15
16
17
18
19
20
89
90
check 11
21
22
23
24
25
26
27
28
29
30
91
check 11
31
32
33
34
35
36
37
38
39
40
41
check 11
42
92
93
94
95
96
97
98
99
100
101
check 11
43
44
102
103
104
105
106
107
108
109
110
check 11
45
46
47
111
112
113
114
115
116
117
118
check 11
48
49
50
51
119
120
121
122
123
124
125
check 11
52
53
54
55
56
126
127
128
129
130
131
check 11
57
58
59
60
61
62
132
133
134
135
136
check 11
63
64
65
66
67
68
69
137
138
139
140
check 11
70
71
72
73
74
75
76
77
141
142
143
check 0
end_SG
begin_DTG
11
1
78
0
2
79
0
3
80
0
4
81
0
5
82
0
6
83
0
7
84
0
8
85
0
9
86
0
10
87
0
11
88
0
11
0
12
0
2
89
0
3
90
0
4
13
0
5
14
0
6
15
0
7
16
0
8
17
0
9
18
0
10
19
0
11
20
0
11
0
21
0
1
22
0
3
91
0
4
23
0
5
24
0
6
25
0
7
26
0
8
27
0
9
28
0
10
29
0
11
30
0
11
0
31
0
1
32
0
2
33
0
4
34
0
5
35
0
6
36
0
7
37
0
8
38
0
9
39
0
10
40
0
11
41
0
11
0
42
0
1
92
0
2
93
0
3
94
0
5
95
0
6
96
0
7
97
0
8
98
0
9
99
0
10
100
0
11
101
0
11
0
43
0
1
102
0
2
103
0
3
104
0
4
44
0
6
105
0
7
106
0
8
107
0
9
108
0
10
109
0
11
110
0
11
0
45
0
1
111
0
2
112
0
3
113
0
4
46
0
5
47
0
7
114
0
8
115
0
9
116
0
10
117
0
11
118
0
11
0
48
0
1
119
0
2
120
0
3
121
0
4
49
0
5
50
0
6
51
0
8
122
0
9
123
0
10
124
0
11
125
0
11
0
52
0
1
126
0
2
127
0
3
128
0
4
53
0
5
54
0
6
55
0
7
56
0
9
129
0
10
130
0
11
131
0
11
0
57
0
1
132
0
2
133
0
3
134
0
4
58
0
5
59
0
6
60
0
7
61
0
8
62
0
10
135
0
11
136
0
11
0
63
0
1
137
0
2
138
0
3
139
0
4
64
0
5
65
0
6
66
0
7
67
0
8
68
0
9
69
0
11
140
0
11
0
70
0
1
141
0
2
142
0
3
143
0
4
71
0
5
72
0
6
73
0
7
74
0
8
75
0
9
76
0
10
77
0
end_DTG
begin_DTG
1
2
11
1
0 9
1
0
1
1
0 2
0
end_DTG
begin_DTG
1
2
7
1
0 6
1
0
0
1
0 1
0
end_DTG
begin_DTG
1
2
9
1
0 8
1
0
5
1
0 10
0
end_DTG
begin_DTG
1
2
8
1
0 7
1
0
4
1
0 6
0
end_DTG
begin_DTG
1
2
10
1
0 9
1
0
3
1
0 4
0
end_DTG
begin_DTG
1
2
6
1
0 1
1
0
2
1
0 3
0
end_DTG
begin_CG
6
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
end_CG
