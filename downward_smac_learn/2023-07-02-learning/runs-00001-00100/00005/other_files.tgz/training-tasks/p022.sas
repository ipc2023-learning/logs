begin_version
3
end_version
begin_metric
0
end_metric
2
begin_variable
var1
-1
5
Atom lift-at(f1)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f3)
Atom served(p1)
end_variable
0
begin_state
0
1
end_state
begin_goal
1
1 2
end_goal
22
begin_operator
board f3 p1
1
0 2
1
0 1 1 0
0
end_operator
begin_operator
depart f5 p1
1
0 4
1
0 1 0 2
0
end_operator
begin_operator
down f2 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 2 1
0
end_operator
begin_operator
down f4 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 3 1
0
end_operator
begin_operator
down f4 f3
0
1
0 0 3 2
0
end_operator
begin_operator
down f5 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 4 1
0
end_operator
begin_operator
down f5 f3
0
1
0 0 4 2
0
end_operator
begin_operator
down f5 f4
0
1
0 0 4 3
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 4
0
end_operator
begin_operator
up f2 f3
0
1
0 0 1 2
0
end_operator
begin_operator
up f2 f4
0
1
0 0 1 3
0
end_operator
begin_operator
up f2 f5
0
1
0 0 1 4
0
end_operator
begin_operator
up f3 f4
0
1
0 0 2 3
0
end_operator
begin_operator
up f3 f5
0
1
0 0 2 4
0
end_operator
begin_operator
up f4 f5
0
1
0 0 3 4
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
switch 0
check 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
switch 0
check 0
check 4
12
13
14
15
check 4
2
16
17
18
check 4
3
4
19
20
check 4
5
6
7
21
check 4
8
9
10
11
check 0
end_SG
begin_DTG
4
1
12
0
2
13
0
3
14
0
4
15
0
4
0
2
0
2
16
0
3
17
0
4
18
0
4
0
3
0
1
4
0
3
19
0
4
20
0
4
0
5
0
1
6
0
2
7
0
4
21
0
4
0
8
0
1
9
0
2
10
0
3
11
0
end_DTG
begin_DTG
1
2
1
1
0 4
1
0
0
1
0 2
0
end_DTG
begin_CG
1
1 2
0
end_CG
