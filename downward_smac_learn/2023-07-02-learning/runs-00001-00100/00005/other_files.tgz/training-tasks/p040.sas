begin_version
3
end_version
begin_metric
0
end_metric
4
begin_variable
var3
-1
9
Atom lift-at(f1)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f5)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f8)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f2)
Atom served(p1)
end_variable
0
begin_state
1
1
1
1
end_state
begin_goal
3
1 2
2 2
3 2
end_goal
78
begin_operator
board f2 p1
1
0 1
1
0 3 1 0
0
end_operator
begin_operator
board f5 p3
1
0 4
1
0 1 1 0
0
end_operator
begin_operator
board f8 p2
1
0 7
1
0 2 1 0
0
end_operator
begin_operator
depart f7 p2
1
0 6
1
0 2 0 2
0
end_operator
begin_operator
depart f8 p1
1
0 7
1
0 3 0 2
0
end_operator
begin_operator
depart f8 p3
1
0 7
1
0 1 0 2
0
end_operator
begin_operator
down f2 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 2 1
0
end_operator
begin_operator
down f4 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 3 1
0
end_operator
begin_operator
down f4 f3
0
1
0 0 3 2
0
end_operator
begin_operator
down f5 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 4 1
0
end_operator
begin_operator
down f5 f3
0
1
0 0 4 2
0
end_operator
begin_operator
down f5 f4
0
1
0 0 4 3
0
end_operator
begin_operator
down f6 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 5 1
0
end_operator
begin_operator
down f6 f3
0
1
0 0 5 2
0
end_operator
begin_operator
down f6 f4
0
1
0 0 5 3
0
end_operator
begin_operator
down f6 f5
0
1
0 0 5 4
0
end_operator
begin_operator
down f7 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 6 1
0
end_operator
begin_operator
down f7 f3
0
1
0 0 6 2
0
end_operator
begin_operator
down f7 f4
0
1
0 0 6 3
0
end_operator
begin_operator
down f7 f5
0
1
0 0 6 4
0
end_operator
begin_operator
down f7 f6
0
1
0 0 6 5
0
end_operator
begin_operator
down f8 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f8 f2
0
1
0 0 7 1
0
end_operator
begin_operator
down f8 f3
0
1
0 0 7 2
0
end_operator
begin_operator
down f8 f4
0
1
0 0 7 3
0
end_operator
begin_operator
down f8 f5
0
1
0 0 7 4
0
end_operator
begin_operator
down f8 f6
0
1
0 0 7 5
0
end_operator
begin_operator
down f8 f7
0
1
0 0 7 6
0
end_operator
begin_operator
down f9 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f9 f2
0
1
0 0 8 1
0
end_operator
begin_operator
down f9 f3
0
1
0 0 8 2
0
end_operator
begin_operator
down f9 f4
0
1
0 0 8 3
0
end_operator
begin_operator
down f9 f5
0
1
0 0 8 4
0
end_operator
begin_operator
down f9 f6
0
1
0 0 8 5
0
end_operator
begin_operator
down f9 f7
0
1
0 0 8 6
0
end_operator
begin_operator
down f9 f8
0
1
0 0 8 7
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 4
0
end_operator
begin_operator
up f1 f6
0
1
0 0 0 5
0
end_operator
begin_operator
up f1 f7
0
1
0 0 0 6
0
end_operator
begin_operator
up f1 f8
0
1
0 0 0 7
0
end_operator
begin_operator
up f1 f9
0
1
0 0 0 8
0
end_operator
begin_operator
up f2 f3
0
1
0 0 1 2
0
end_operator
begin_operator
up f2 f4
0
1
0 0 1 3
0
end_operator
begin_operator
up f2 f5
0
1
0 0 1 4
0
end_operator
begin_operator
up f2 f6
0
1
0 0 1 5
0
end_operator
begin_operator
up f2 f7
0
1
0 0 1 6
0
end_operator
begin_operator
up f2 f8
0
1
0 0 1 7
0
end_operator
begin_operator
up f2 f9
0
1
0 0 1 8
0
end_operator
begin_operator
up f3 f4
0
1
0 0 2 3
0
end_operator
begin_operator
up f3 f5
0
1
0 0 2 4
0
end_operator
begin_operator
up f3 f6
0
1
0 0 2 5
0
end_operator
begin_operator
up f3 f7
0
1
0 0 2 6
0
end_operator
begin_operator
up f3 f8
0
1
0 0 2 7
0
end_operator
begin_operator
up f3 f9
0
1
0 0 2 8
0
end_operator
begin_operator
up f4 f5
0
1
0 0 3 4
0
end_operator
begin_operator
up f4 f6
0
1
0 0 3 5
0
end_operator
begin_operator
up f4 f7
0
1
0 0 3 6
0
end_operator
begin_operator
up f4 f8
0
1
0 0 3 7
0
end_operator
begin_operator
up f4 f9
0
1
0 0 3 8
0
end_operator
begin_operator
up f5 f6
0
1
0 0 4 5
0
end_operator
begin_operator
up f5 f7
0
1
0 0 4 6
0
end_operator
begin_operator
up f5 f8
0
1
0 0 4 7
0
end_operator
begin_operator
up f5 f9
0
1
0 0 4 8
0
end_operator
begin_operator
up f6 f7
0
1
0 0 5 6
0
end_operator
begin_operator
up f6 f8
0
1
0 0 5 7
0
end_operator
begin_operator
up f6 f9
0
1
0 0 5 8
0
end_operator
begin_operator
up f7 f8
0
1
0 0 6 7
0
end_operator
begin_operator
up f7 f9
0
1
0 0 6 8
0
end_operator
begin_operator
up f8 f9
0
1
0 0 7 8
0
end_operator
0
begin_SG
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
switch 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 8
42
43
44
45
46
47
48
49
check 8
6
50
51
52
53
54
55
56
check 8
7
8
57
58
59
60
61
62
check 8
9
10
11
63
64
65
66
67
check 8
12
13
14
15
68
69
70
71
check 8
16
17
18
19
20
72
73
74
check 8
21
22
23
24
25
26
75
76
check 8
27
28
29
30
31
32
33
77
check 8
34
35
36
37
38
39
40
41
check 0
end_SG
begin_DTG
8
1
42
0
2
43
0
3
44
0
4
45
0
5
46
0
6
47
0
7
48
0
8
49
0
8
0
6
0
2
50
0
3
51
0
4
52
0
5
53
0
6
54
0
7
55
0
8
56
0
8
0
7
0
1
8
0
3
57
0
4
58
0
5
59
0
6
60
0
7
61
0
8
62
0
8
0
9
0
1
10
0
2
11
0
4
63
0
5
64
0
6
65
0
7
66
0
8
67
0
8
0
12
0
1
13
0
2
14
0
3
15
0
5
68
0
6
69
0
7
70
0
8
71
0
8
0
16
0
1
17
0
2
18
0
3
19
0
4
20
0
6
72
0
7
73
0
8
74
0
8
0
21
0
1
22
0
2
23
0
3
24
0
4
25
0
5
26
0
7
75
0
8
76
0
8
0
27
0
1
28
0
2
29
0
3
30
0
4
31
0
5
32
0
6
33
0
8
77
0
8
0
34
0
1
35
0
2
36
0
3
37
0
4
38
0
5
39
0
6
40
0
7
41
0
end_DTG
begin_DTG
1
2
5
1
0 7
1
0
1
1
0 4
0
end_DTG
begin_DTG
1
2
3
1
0 6
1
0
2
1
0 7
0
end_DTG
begin_DTG
1
2
4
1
0 7
1
0
0
1
0 1
0
end_DTG
begin_CG
3
3 2
2 2
1 2
0
0
0
end_CG
