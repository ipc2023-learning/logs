begin_version
3
end_version
begin_metric
0
end_metric
5
begin_variable
var4
-1
10
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f5)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f10)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f6)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f10)
Atom served(p1)
end_variable
0
begin_state
2
1
1
1
1
end_state
begin_goal
4
1 2
2 2
3 2
4 2
end_goal
98
begin_operator
board f10 p1
1
0 1
1
0 4 1 0
0
end_operator
begin_operator
board f10 p3
1
0 1
1
0 2 1 0
0
end_operator
begin_operator
board f5 p4
1
0 5
1
0 1 1 0
0
end_operator
begin_operator
board f6 p2
1
0 6
1
0 3 1 0
0
end_operator
begin_operator
depart f10 p2
1
0 1
1
0 3 0 2
0
end_operator
begin_operator
depart f3 p1
1
0 3
1
0 4 0 2
0
end_operator
begin_operator
depart f3 p4
1
0 3
1
0 1 0 2
0
end_operator
begin_operator
depart f6 p3
1
0 6
1
0 2 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 2
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 3
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 4
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 5
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 6
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 9
0
end_operator
begin_operator
down f2 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 3 2
0
end_operator
begin_operator
down f4 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 4 2
0
end_operator
begin_operator
down f4 f3
0
1
0 0 4 3
0
end_operator
begin_operator
down f5 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 5 2
0
end_operator
begin_operator
down f5 f3
0
1
0 0 5 3
0
end_operator
begin_operator
down f5 f4
0
1
0 0 5 4
0
end_operator
begin_operator
down f6 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 6 2
0
end_operator
begin_operator
down f6 f3
0
1
0 0 6 3
0
end_operator
begin_operator
down f6 f4
0
1
0 0 6 4
0
end_operator
begin_operator
down f6 f5
0
1
0 0 6 5
0
end_operator
begin_operator
down f7 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 7 2
0
end_operator
begin_operator
down f7 f3
0
1
0 0 7 3
0
end_operator
begin_operator
down f7 f4
0
1
0 0 7 4
0
end_operator
begin_operator
down f7 f5
0
1
0 0 7 5
0
end_operator
begin_operator
down f7 f6
0
1
0 0 7 6
0
end_operator
begin_operator
down f8 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f8 f2
0
1
0 0 8 2
0
end_operator
begin_operator
down f8 f3
0
1
0 0 8 3
0
end_operator
begin_operator
down f8 f4
0
1
0 0 8 4
0
end_operator
begin_operator
down f8 f5
0
1
0 0 8 5
0
end_operator
begin_operator
down f8 f6
0
1
0 0 8 6
0
end_operator
begin_operator
down f8 f7
0
1
0 0 8 7
0
end_operator
begin_operator
down f9 f1
0
1
0 0 9 0
0
end_operator
begin_operator
down f9 f2
0
1
0 0 9 2
0
end_operator
begin_operator
down f9 f3
0
1
0 0 9 3
0
end_operator
begin_operator
down f9 f4
0
1
0 0 9 4
0
end_operator
begin_operator
down f9 f5
0
1
0 0 9 5
0
end_operator
begin_operator
down f9 f6
0
1
0 0 9 6
0
end_operator
begin_operator
down f9 f7
0
1
0 0 9 7
0
end_operator
begin_operator
down f9 f8
0
1
0 0 9 8
0
end_operator
begin_operator
up f1 f10
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 4
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 5
0
end_operator
begin_operator
up f1 f6
0
1
0 0 0 6
0
end_operator
begin_operator
up f1 f7
0
1
0 0 0 7
0
end_operator
begin_operator
up f1 f8
0
1
0 0 0 8
0
end_operator
begin_operator
up f1 f9
0
1
0 0 0 9
0
end_operator
begin_operator
up f2 f10
0
1
0 0 2 1
0
end_operator
begin_operator
up f2 f3
0
1
0 0 2 3
0
end_operator
begin_operator
up f2 f4
0
1
0 0 2 4
0
end_operator
begin_operator
up f2 f5
0
1
0 0 2 5
0
end_operator
begin_operator
up f2 f6
0
1
0 0 2 6
0
end_operator
begin_operator
up f2 f7
0
1
0 0 2 7
0
end_operator
begin_operator
up f2 f8
0
1
0 0 2 8
0
end_operator
begin_operator
up f2 f9
0
1
0 0 2 9
0
end_operator
begin_operator
up f3 f10
0
1
0 0 3 1
0
end_operator
begin_operator
up f3 f4
0
1
0 0 3 4
0
end_operator
begin_operator
up f3 f5
0
1
0 0 3 5
0
end_operator
begin_operator
up f3 f6
0
1
0 0 3 6
0
end_operator
begin_operator
up f3 f7
0
1
0 0 3 7
0
end_operator
begin_operator
up f3 f8
0
1
0 0 3 8
0
end_operator
begin_operator
up f3 f9
0
1
0 0 3 9
0
end_operator
begin_operator
up f4 f10
0
1
0 0 4 1
0
end_operator
begin_operator
up f4 f5
0
1
0 0 4 5
0
end_operator
begin_operator
up f4 f6
0
1
0 0 4 6
0
end_operator
begin_operator
up f4 f7
0
1
0 0 4 7
0
end_operator
begin_operator
up f4 f8
0
1
0 0 4 8
0
end_operator
begin_operator
up f4 f9
0
1
0 0 4 9
0
end_operator
begin_operator
up f5 f10
0
1
0 0 5 1
0
end_operator
begin_operator
up f5 f6
0
1
0 0 5 6
0
end_operator
begin_operator
up f5 f7
0
1
0 0 5 7
0
end_operator
begin_operator
up f5 f8
0
1
0 0 5 8
0
end_operator
begin_operator
up f5 f9
0
1
0 0 5 9
0
end_operator
begin_operator
up f6 f10
0
1
0 0 6 1
0
end_operator
begin_operator
up f6 f7
0
1
0 0 6 7
0
end_operator
begin_operator
up f6 f8
0
1
0 0 6 8
0
end_operator
begin_operator
up f6 f9
0
1
0 0 6 9
0
end_operator
begin_operator
up f7 f10
0
1
0 0 7 1
0
end_operator
begin_operator
up f7 f8
0
1
0 0 7 8
0
end_operator
begin_operator
up f7 f9
0
1
0 0 7 9
0
end_operator
begin_operator
up f8 f10
0
1
0 0 8 1
0
end_operator
begin_operator
up f8 f9
0
1
0 0 8 9
0
end_operator
begin_operator
up f9 f10
0
1
0 0 9 1
0
end_operator
0
begin_SG
switch 4
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 1
4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 9
53
54
55
56
57
58
59
60
61
check 9
8
9
10
11
12
13
14
15
16
check 9
17
62
63
64
65
66
67
68
69
check 9
18
19
70
71
72
73
74
75
76
check 9
20
21
22
77
78
79
80
81
82
check 9
23
24
25
26
83
84
85
86
87
check 9
27
28
29
30
31
88
89
90
91
check 9
32
33
34
35
36
37
92
93
94
check 9
38
39
40
41
42
43
44
95
96
check 9
45
46
47
48
49
50
51
52
97
check 0
end_SG
begin_DTG
9
1
53
0
2
54
0
3
55
0
4
56
0
5
57
0
6
58
0
7
59
0
8
60
0
9
61
0
9
0
8
0
2
9
0
3
10
0
4
11
0
5
12
0
6
13
0
7
14
0
8
15
0
9
16
0
9
0
17
0
1
62
0
3
63
0
4
64
0
5
65
0
6
66
0
7
67
0
8
68
0
9
69
0
9
0
18
0
1
70
0
2
19
0
4
71
0
5
72
0
6
73
0
7
74
0
8
75
0
9
76
0
9
0
20
0
1
77
0
2
21
0
3
22
0
5
78
0
6
79
0
7
80
0
8
81
0
9
82
0
9
0
23
0
1
83
0
2
24
0
3
25
0
4
26
0
6
84
0
7
85
0
8
86
0
9
87
0
9
0
27
0
1
88
0
2
28
0
3
29
0
4
30
0
5
31
0
7
89
0
8
90
0
9
91
0
9
0
32
0
1
92
0
2
33
0
3
34
0
4
35
0
5
36
0
6
37
0
8
93
0
9
94
0
9
0
38
0
1
95
0
2
39
0
3
40
0
4
41
0
5
42
0
6
43
0
7
44
0
9
96
0
9
0
45
0
1
97
0
2
46
0
3
47
0
4
48
0
5
49
0
6
50
0
7
51
0
8
52
0
end_DTG
begin_DTG
1
2
6
1
0 3
1
0
2
1
0 5
0
end_DTG
begin_DTG
1
2
7
1
0 6
1
0
1
1
0 1
0
end_DTG
begin_DTG
1
2
4
1
0 1
1
0
3
1
0 6
0
end_DTG
begin_DTG
1
2
5
1
0 3
1
0
0
1
0 1
0
end_DTG
begin_CG
4
4 2
3 2
2 2
1 2
0
0
0
0
end_CG
