begin_version
3
end_version
begin_metric
0
end_metric
8
begin_variable
var7
-1
15
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f15)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var6
-1
3
Atom boarded(p7)
Atom origin(p7, f9)
Atom served(p7)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f13)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f7)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f12)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f12)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f13)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f8)
Atom served(p1)
end_variable
0
begin_state
8
1
1
1
1
1
1
1
end_state
begin_goal
7
1 2
2 2
3 2
4 2
5 2
6 2
7 2
end_goal
224
begin_operator
board f12 p3
1
0 3
1
0 5 1 0
0
end_operator
begin_operator
board f12 p4
1
0 3
1
0 4 1 0
0
end_operator
begin_operator
board f13 p2
1
0 4
1
0 6 1 0
0
end_operator
begin_operator
board f13 p6
1
0 4
1
0 2 1 0
0
end_operator
begin_operator
board f7 p5
1
0 12
1
0 3 1 0
0
end_operator
begin_operator
board f8 p1
1
0 13
1
0 7 1 0
0
end_operator
begin_operator
board f9 p7
1
0 14
1
0 1 1 0
0
end_operator
begin_operator
depart f10 p5
1
0 1
1
0 3 0 2
0
end_operator
begin_operator
depart f2 p6
1
0 7
1
0 2 0 2
0
end_operator
begin_operator
depart f2 p7
1
0 7
1
0 1 0 2
0
end_operator
begin_operator
depart f3 p2
1
0 8
1
0 6 0 2
0
end_operator
begin_operator
depart f6 p4
1
0 11
1
0 4 0 2
0
end_operator
begin_operator
depart f7 p3
1
0 12
1
0 5 0 2
0
end_operator
begin_operator
depart f9 p1
1
0 14
1
0 7 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 13
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 14
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 7
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 8
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 13
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 14
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 7
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 8
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 13
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 14
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 7
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 8
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 9
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 10
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 13
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 14
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 7
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 8
0
end_operator
begin_operator
down f14 f4
0
1
0 0 5 9
0
end_operator
begin_operator
down f14 f5
0
1
0 0 5 10
0
end_operator
begin_operator
down f14 f6
0
1
0 0 5 11
0
end_operator
begin_operator
down f14 f7
0
1
0 0 5 12
0
end_operator
begin_operator
down f14 f8
0
1
0 0 5 13
0
end_operator
begin_operator
down f14 f9
0
1
0 0 5 14
0
end_operator
begin_operator
down f15 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f15 f10
0
1
0 0 6 1
0
end_operator
begin_operator
down f15 f11
0
1
0 0 6 2
0
end_operator
begin_operator
down f15 f12
0





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
check 1
13
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
switch 6
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 5
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
12
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 4
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
11
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
9
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
6
check 0
check 0
switch 0
check 0
check 14
119
120
121
122
123
124
125
126
127
128
129
130
131
132
check 14
14
15
16
17
18
19
20
21
22
133
134
135
136
137
check 14
23
24
25
26
27
28
29
30
31
32
138
139
140
141
check 14
33
34
35
36
37
38
39
40
41
42
43
142
143
144
check 14
44
45
46
47
48
49
50
51
52
53
54
55
145
146
check 14
56
57
58
59
60
61
62
63
64
65
66
67
68
147
check 14
69
70
71
72
73
74
75
76
77
78
79
80
81
82
check 14
83
148
149
150
151
152
153
154
155
156
157
158
159
160
check 14
84
85
161
162
163
164
165
166
167
168
169
170
171
172
check 14
86
87
88
173
174
175
176
177
178
179
180
181
182
183
check 14
89
90
91
92
184
185
186
187
188
189
190
191
192
193
check 14
93
94
95
96
97
194
195
196
197
198
199
200
201
202
check 14
98
99
100
101
102
103
203
204
205
206
207
208
209
210
check 14
104
105
106
107
108
109
110
211
212
213
214
215
216
217
check 14
111
112
113
114
115
116
117
118
218
219
220
221
222
223
check 0
end_SG
begin_DTG
14
1
119
0
2
120
0
3
121
0
4
122
0
5
123
0
6
124
0
7
125
0
8
126
0
9
127
0
10
128
0
11
129
0
12
130
0
13
131
0
14
132
0
14
0
14
0
2
133
0
3
134
0
4
135
0
5
136
0
6
137
0
7
15
0
8
16
0
9
17
0
10
18
0
11
19
0
12
20
0
13
21
0
14
22
0
14
0
23
0
1
24
0
3
138
0
4
139
0
5
140
0
6
141
0
7
25
0
8
26
0
9
27
0
10
28
0
11
29
0
12
30
0
13
31
0
14
32
0
14
0
33
0
1
34
0
2
35
0
4
142
0
5
143
0
6
144
0
7
36
0
8
37
0
9
38
0
10
39
0
11
40
0
12
41
0
13
42
0
14
43
0
14
0
44
0
1
45
0
2
46
0
3
47
0
5
145
0
6
146
0
7
48
0
8
49
0
9
50
0
10
51
0
11
52
0
12
53
0
13
54
0
14
55
0
14
0
56
0
1
57
0
2
58
0
3
59
0
4
60
0
6
147
0
7
61
0
8
62
0
9
63
0
10
64
0
11
65
0
12
66
0
13
67
0
14
68
0
14
0
69
0
1
70
0
2
71
0
3
72
0
4
73
0
5
74
0
7
75
0
8
76
0
9
77
0
10
78
0
11
79
0
12
80
0
13
81
0
14
82
0
14
0
83
0
1
148
0
2
149
0
3
150
0
4
151
0
5
152
0
6
153
0
8
154
0
9
155
0
10
156
0
11
157
0
12
158
0
13
159
0
14
160
0
14
0
84
0
1
161
0
2
162
0
3
163
0
4
164
0
5
165
0
6
166
0
7
85
0
9
167
0
10
168
0
11
169
0
12
170
0
13
171
0
14
172
0
14
0
86
0
1
173
0
2
174
0
3
175
0
4
176
0
5
177
0
6
178
0
7
87
0
8
88
0
10
179
0
11
180
0
12
181
0
13
182
0
14
183
0
14
0
89
0
1
184
0
2
185
0
3
186
0
4
187
0
5
188
0
6
189
0
7
90
0
8
91
0
9
92
0
11
190
0
12
191
0
13
192
0
14
193
0
14
0
93
0
1
194
0
2
195
0
3
196
0
4
197
0
5
198
0
6
199
0
7
94
0
8
95
0
9
96
0
10
97
0
12
200
0
13
201
0
14
202
0
14
0
98
0
1
203
0
2
204
0
3
205
0
4
206
0
5
207
0
6
208
0
7
99
0
8
100
0
9
101
0
10
102
0
11
103
0
13
209
0
14
210
0
14
0
104
0
1
211
0
2
212
0
3
213
0
4
214
0
5
215
0
6
216
0
7
105
0
8
106
0
9
107
0
10
108
0
11
109
0
12
110
0
14
217
0
14
0
111
0
1
218
0
2
219
0
3
220
0
4
221
0
5
222
0
6
223
0
7
112
0
8
113
0
9
114
0
10
115
0
11
116
0
12
117
0
13
118
0
end_DTG
begin_DTG
1
2
9
1
0 7
1
0
6
1
0 14
0
end_DTG
begin_DTG
1
2
8
1
0 7
1
0
3
1
0 4
0
end_DTG
begin_DTG
1
2
7
1
0 1
1
0
4
1
0 12
0
end_DTG
begin_DTG
1
2
11
1
0 11
1
0
1
1
0 3
0
end_DTG
begin_DTG
1
2
12
1
0 12
1
0
0
1
0 3
0
end_DTG
begin_DTG
1
2
10
1
0 8
1
0
2
1
0 4
0
end_DTG
begin_DTG
1
2
13
1
0 14
1
0
5
1
0 13
0
end_DTG
begin_CG
7
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
end_CG
