begin_version
3
end_version
begin_metric
0
end_metric
5
begin_variable
var4
-1
9
Atom lift-at(f1)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f2)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f4)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f5)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f9)
Atom served(p1)
end_variable
0
begin_state
5
1
1
1
1
end_state
begin_goal
4
1 2
2 2
3 2
4 2
end_goal
80
begin_operator
board f2 p4
1
0 1
1
0 1 1 0
0
end_operator
begin_operator
board f4 p3
1
0 3
1
0 2 1 0
0
end_operator
begin_operator
board f5 p2
1
0 4
1
0 3 1 0
0
end_operator
begin_operator
board f9 p1
1
0 8
1
0 4 1 0
0
end_operator
begin_operator
depart f1 p1
1
0 0
1
0 4 0 2
0
end_operator
begin_operator
depart f3 p2
1
0 2
1
0 3 0 2
0
end_operator
begin_operator
depart f5 p4
1
0 4
1
0 1 0 2
0
end_operator
begin_operator
depart f6 p3
1
0 5
1
0 2 0 2
0
end_operator
begin_operator
down f2 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 2 1
0
end_operator
begin_operator
down f4 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 3 1
0
end_operator
begin_operator
down f4 f3
0
1
0 0 3 2
0
end_operator
begin_operator
down f5 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 4 1
0
end_operator
begin_operator
down f5 f3
0
1
0 0 4 2
0
end_operator
begin_operator
down f5 f4
0
1
0 0 4 3
0
end_operator
begin_operator
down f6 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 5 1
0
end_operator
begin_operator
down f6 f3
0
1
0 0 5 2
0
end_operator
begin_operator
down f6 f4
0
1
0 0 5 3
0
end_operator
begin_operator
down f6 f5
0
1
0 0 5 4
0
end_operator
begin_operator
down f7 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 6 1
0
end_operator
begin_operator
down f7 f3
0
1
0 0 6 2
0
end_operator
begin_operator
down f7 f4
0
1
0 0 6 3
0
end_operator
begin_operator
down f7 f5
0
1
0 0 6 4
0
end_operator
begin_operator
down f7 f6
0
1
0 0 6 5
0
end_operator
begin_operator
down f8 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f8 f2
0
1
0 0 7 1
0
end_operator
begin_operator
down f8 f3
0
1
0 0 7 2
0
end_operator
begin_operator
down f8 f4
0
1
0 0 7 3
0
end_operator
begin_operator
down f8 f5
0
1
0 0 7 4
0
end_operator
begin_operator
down f8 f6
0
1
0 0 7 5
0
end_operator
begin_operator
down f8 f7
0
1
0 0 7 6
0
end_operator
begin_operator
down f9 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f9 f2
0
1
0 0 8 1
0
end_operator
begin_operator
down f9 f3
0
1
0 0 8 2
0
end_operator
begin_operator
down f9 f4
0
1
0 0 8 3
0
end_operator
begin_operator
down f9 f5
0
1
0 0 8 4
0
end_operator
begin_operator
down f9 f6
0
1
0 0 8 5
0
end_operator
begin_operator
down f9 f7
0
1
0 0 8 6
0
end_operator
begin_operator
down f9 f8
0
1
0 0 8 7
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 4
0
end_operator
begin_operator
up f1 f6
0
1
0 0 0 5
0
end_operator
begin_operator
up f1 f7
0
1
0 0 0 6
0
end_operator
begin_operator
up f1 f8
0
1
0 0 0 7
0
end_operator
begin_operator
up f1 f9
0
1
0 0 0 8
0
end_operator
begin_operator
up f2 f3
0
1
0 0 1 2
0
end_operator
begin_operator
up f2 f4
0
1
0 0 1 3
0
end_operator
begin_operator
up f2 f5
0
1
0 0 1 4
0
end_operator
begin_operator
up f2 f6
0
1
0 0 1 5
0
end_operator
begin_operator
up f2 f7
0
1
0 0 1 6
0
end_operator
begin_operator
up f2 f8
0
1
0 0 1 7
0
end_operator
begin_operator
up f2 f9
0
1
0 0 1 8
0
end_operator
begin_operator
up f3 f4
0
1
0 0 2 3
0
end_operator
begin_operator
up f3 f5
0
1
0 0 2 4
0
end_operator
begin_operator
up f3 f6
0
1
0 0 2 5
0
end_operator
begin_operator
up f3 f7
0
1
0 0 2 6
0
end_operator
begin_operator
up f3 f8
0
1
0 0 2 7
0
end_operator
begin_operator
up f3 f9
0
1
0 0 2 8
0
end_operator
begin_operator
up f4 f5
0
1
0 0 3 4
0
end_operator
begin_operator
up f4 f6
0
1
0 0 3 5
0
end_operator
begin_operator
up f4 f7
0
1
0 0 3 6
0
end_operator
begin_operator
up f4 f8
0
1
0 0 3 7
0
end_operator
begin_operator
up f4 f9
0
1
0 0 3 8
0
end_operator
begin_operator
up f5 f6
0
1
0 0 4 5
0
end_operator
begin_operator
up f5 f7
0
1
0 0 4 6
0
end_operator
begin_operator
up f5 f8
0
1
0 0 4 7
0
end_operator
begin_operator
up f5 f9
0
1
0 0 4 8
0
end_operator
begin_operator
up f6 f7
0
1
0 0 5 6
0
end_operator
begin_operator
up f6 f8
0
1
0 0 5 7
0
end_operator
begin_operator
up f6 f9
0
1
0 0 5 8
0
end_operator
begin_operator
up f7 f8
0
1
0 0 6 7
0
end_operator
begin_operator
up f7 f9
0
1
0 0 6 8
0
end_operator
begin_operator
up f8 f9
0
1
0 0 7 8
0
end_operator
0
begin_SG
switch 4
check 0
switch 0
check 0
check 1
4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 8
44
45
46
47
48
49
50
51
check 8
8
52
53
54
55
56
57
58
check 8
9
10
59
60
61
62
63
64
check 8
11
12
13
65
66
67
68
69
check 8
14
15
16
17
70
71
72
73
check 8
18
19
20
21
22
74
75
76
check 8
23
24
25
26
27
28
77
78
check 8
29
30
31
32
33
34
35
79
check 8
36
37
38
39
40
41
42
43
check 0
end_SG
begin_DTG
8
1
44
0
2
45
0
3
46
0
4
47
0
5
48
0
6
49
0
7
50
0
8
51
0
8
0
8
0
2
52
0
3
53
0
4
54
0
5
55
0
6
56
0
7
57
0
8
58
0
8
0
9
0
1
10
0
3
59
0
4
60
0
5
61
0
6
62
0
7
63
0
8
64
0
8
0
11
0
1
12
0
2
13
0
4
65
0
5
66
0
6
67
0
7
68
0
8
69
0
8
0
14
0
1
15
0
2
16
0
3
17
0
5
70
0
6
71
0
7
72
0
8
73
0
8
0
18
0
1
19
0
2
20
0
3
21
0
4
22
0
6
74
0
7
75
0
8
76
0
8
0
23
0
1
24
0
2
25
0
3
26
0
4
27
0
5
28
0
7
77
0
8
78
0
8
0
29
0
1
30
0
2
31
0
3
32
0
4
33
0
5
34
0
6
35
0
8
79
0
8
0
36
0
1
37
0
2
38
0
3
39
0
4
40
0
5
41
0
6
42
0
7
43
0
end_DTG
begin_DTG
1
2
6
1
0 4
1
0
0
1
0 1
0
end_DTG
begin_DTG
1
2
7
1
0 5
1
0
1
1
0 3
0
end_DTG
begin_DTG
1
2
5
1
0 2
1
0
2
1
0 4
0
end_DTG
begin_DTG
1
2
4
1
0 0
1
0
3
1
0 8
0
end_DTG
begin_CG
4
4 2
3 2
2 2
1 2
0
0
0
0
end_CG
