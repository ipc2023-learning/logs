begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var9
-1
17
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f15)
Atom lift-at(f16)
Atom lift-at(f17)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var8
-1
3
Atom boarded(p9)
Atom origin(p9, f12)
Atom served(p9)
end_variable
begin_variable
var7
-1
3
Atom boarded(p8)
Atom origin(p8, f13)
Atom served(p8)
end_variable
begin_variable
var6
-1
3
Atom boarded(p7)
Atom origin(p7, f13)
Atom served(p7)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f15)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f8)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f7)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f14)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f7)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f11)
Atom served(p1)
end_variable
0
begin_state
14
1
1
1
1
1
1
1
1
1
end_state
begin_goal
9
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
end_goal
290
begin_operator
board f11 p1
1
0 2
1
0 9 1 0
0
end_operator
begin_operator
board f12 p9
1
0 3
1
0 1 1 0
0
end_operator
begin_operator
board f13 p7
1
0 4
1
0 3 1 0
0
end_operator
begin_operator
board f13 p8
1
0 4
1
0 2 1 0
0
end_operator
begin_operator
board f14 p3
1
0 5
1
0 7 1 0
0
end_operator
begin_operator
board f15 p6
1
0 6
1
0 4 1 0
0
end_operator
begin_operator
board f7 p2
1
0 14
1
0 8 1 0
0
end_operator
begin_operator
board f7 p4
1
0 14
1
0 6 1 0
0
end_operator
begin_operator
board f8 p5
1
0 15
1
0 5 1 0
0
end_operator
begin_operator
depart f14 p2
1
0 5
1
0 8 0 2
0
end_operator
begin_operator
depart f14 p6
1
0 5
1
0 4 0 2
0
end_operator
begin_operator
depart f15 p4
1
0 6
1
0 6 0 2
0
end_operator
begin_operator
depart f17 p1
1
0 8
1
0 9 0 2
0
end_operator
begin_operator
depart f17 p9
1
0 8
1
0 1 0 2
0
end_operator
begin_operator
depart f6 p3
1
0 13
1
0 7 0 2
0
end_operator
begin_operator
depart f6 p5
1
0 13
1
0 5 0 2
0
end_operator
begin_operator
depart f8 p8
1
0 15
1
0 2 0 2
0
end_operator
begin_operator
depart f9 p7
1
0 16
1
0 3 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 13
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 14
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 15
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 16
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 13
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 14
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 15
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 16
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 13
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 14
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 15
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 16
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 9
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 10
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 13
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 14
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 15
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 16
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 9
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 10
0
end_operator
begin_operator
down f14 f4
0
1
0 0 5 11




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
17
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
16
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
13
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 16
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
check 16
18
19
20
21
22
23
24
25
26
170
171
172
173
174
175
176
check 16
27
28
29
30
31
32
33
34
35
36
177
178
179
180
181
182
check 16
37
38
39
40
41
42
43
44
45
46
47
183
184
185
186
187
check 16
48
49
50
51
52
53
54
55
56
57
58
59
188
189
190
191
check 16
60
61
62
63
64
65
66
67
68
69
70
71
72
192
193
194
check 16
73
74
75
76
77
78
79
80
81
82
83
84
85
86
195
196
check 16
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
197
check 16
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
check 16
118
198
199
200
201
202
203
204
205
206
207
208
209
210
211
212
check 16
119
120
213
214
215
216
217
218
219
220
221
222
223
224
225
226
check 16
121
122
123
227
228
229
230
231
232
233
234
235
236
237
238
239
check 16
124
125
126
127
240
241
242
243
244
245
246
247
248
249
250
251
check 16
128
129
130
131
132
252
253
254
255
256
257
258
259
260
261
262
check 16
133
134
135
136
137
138
263
264
265
266
267
268
269
270
271
272
check 16
139
140
141
142
143
144
145
273
274
275
276
277
278
279
280
281
check 16
146
147
148
149
150
151
152
153
282
283
284
285
286
287
288
289
check 0
end_SG
begin_DTG
16
1
154
0
2
155
0
3
156
0
4
157
0
5
158
0
6
159
0
7
160
0
8
161
0
9
162
0
10
163
0
11
164
0
12
165
0
13
166
0
14
167
0
15
168
0
16
169
0
16
0
18
0
2
170
0
3
171
0
4
172
0
5
173
0
6
174
0
7
175
0
8
176
0
9
19
0
10
20
0
11
21
0
12
22
0
13
23
0
14
24
0
15
25
0
16
26
0
16
0
27
0
1
28
0
3
177
0
4
178
0
5
179
0
6
180
0
7
181
0
8
182
0
9
29
0
10
30
0
11
31
0
12
32
0
13
33
0
14
34
0
15
35
0
16
36
0
16
0
37
0
1
38
0
2
39
0
4
183
0
5
184
0
6
185
0
7
186
0
8
187
0
9
40
0
10
41
0
11
42
0
12
43
0
13
44
0
14
45
0
15
46
0
16
47
0
16
0
48
0
1
49
0
2
50
0
3
51
0
5
188
0
6
189
0
7
190
0
8
191
0
9
52
0
10
53
0
11
54
0
12
55
0
13
56
0
14
57
0
15
58
0
16
59
0
16
0
60
0
1
61
0
2
62
0
3
63
0
4
64
0
6
192
0
7
193
0
8
194
0
9
65
0
10
66
0
11
67
0
12
68
0
13
69
0
14
70
0
15
71
0
16
72
0
16
0
73
0
1
74
0
2
75
0
3
76
0
4
77
0
5
78
0
7
195
0
8
196
0
9
79
0
10
80
0
11
81
0
12
82
0
13
83
0
14
84
0
15
85
0
16
86
0
16
0
87
0
1
88
0
2
89
0
3
90
0
4
91
0
5
92
0
6
93
0
8
197
0
9
94
0
10
95
0
11
96
0
12
97
0
13
98
0
14
99
0
15
100
0
16
101
0
16
0
102
0
1
103
0
2
104
0
3
105
0
4
106
0
5
107
0
6
108
0
7
109
0
9
110
0
10
111
0
11
112
0
12
113
0
13
114
0
14
115
0
15
116
0
16
117
0
16
0
118
0
1
198
0
2
199
0
3
200
0
4
201
0
5
202
0
6
203
0
7
204
0
8
205
0
10
206
0
11
207
0
12
208
0
13
209
0
14
210
0
15
211
0
16
212
0
16
0
119
0
1
213
0
2
214
0
3
215
0
4
216
0
5
217
0
6
218
0
7
219
0
8
220
0
9
120
0
11
221
0
12
222
0
13
223
0
14
224
0
15
225
0
16
226
0
16
0
121
0
1
227
0
2
228
0
3
229
0
4
230
0
5
231
0
6
232
0
7
233
0
8
234
0
9
122
0
10
123
0
12
235
0
13
236
0
14
237
0
15
238
0
16
239
0
16
0
124
0
1
240
0
2
241
0
3
242
0
4
243
0
5
244
0
6
245
0
7
246
0
8
247
0
9
125
0
10
126
0
11
127
0
13
248
0
14
249
0
15
250
0
16
251
0
16
0
128
0
1
252
0
2
253
0
3
254
0
4
255
0
5
256
0
6
257
0
7
258
0
8
259
0
9
129
0
10
130
0
11
131
0
12
132
0
14
260
0
15
261
0
16
262
0
16
0
133
0
1
263
0
2
264
0
3
265
0
4
266
0
5
267
0
6
268
0
7
269
0
8
270
0
9
134
0
10
135
0
11
136
0
12
137
0
13
138
0
15
271
0
16
272
0
16
0
139
0
1
273
0
2
274
0
3
275
0
4
276
0
5
277
0
6
278
0
7
279
0
8
280
0
9
140
0
10
141
0
11
142
0
12
143
0
13
144
0
14
145
0
16
281
0
16
0
146
0
1
282
0
2
283
0
3
284
0
4
285
0
5
286
0
6
287
0
7
288
0
8
289
0
9
147
0
10
148
0
11
149
0
12
150
0
13
151
0
14
152
0
15
153
0
end_DTG
begin_DTG
1
2
13
1
0 8
1
0
1
1
0 3
0
end_DTG
begin_DTG
1
2
16
1
0 15
1
0
3
1
0 4
0
end_DTG
begin_DTG
1
2
17
1
0 16
1
0
2
1
0 4
0
end_DTG
begin_DTG
1
2
10
1
0 5
1
0
5
1
0 6
0
end_DTG
begin_DTG
1
2
15
1
0 13
1
0
8
1
0 15
0
end_DTG
begin_DTG
1
2
11
1
0 6
1
0
7
1
0 14
0
end_DTG
begin_DTG
1
2
14
1
0 13
1
0
4
1
0 5
0
end_DTG
begin_DTG
1
2
9
1
0 5
1
0
6
1
0 14
0
end_DTG
begin_DTG
1
2
12
1
0 8
1
0
0
1
0 2
0
end_DTG
begin_CG
9
9 2
8 2
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
0
0
end_CG
