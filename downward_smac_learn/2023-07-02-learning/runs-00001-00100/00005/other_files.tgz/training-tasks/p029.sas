begin_version
3
end_version
begin_metric
0
end_metric
3
begin_variable
var2
-1
6
Atom lift-at(f1)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f6)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f1)
Atom served(p1)
end_variable
0
begin_state
4
1
1
end_state
begin_goal
2
1 2
2 2
end_goal
34
begin_operator
board f1 p1
1
0 0
1
0 2 1 0
0
end_operator
begin_operator
board f6 p2
1
0 5
1
0 1 1 0
0
end_operator
begin_operator
depart f5 p1
1
0 4
1
0 2 0 2
0
end_operator
begin_operator
depart f5 p2
1
0 4
1
0 1 0 2
0
end_operator
begin_operator
down f2 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 2 1
0
end_operator
begin_operator
down f4 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 3 1
0
end_operator
begin_operator
down f4 f3
0
1
0 0 3 2
0
end_operator
begin_operator
down f5 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 4 1
0
end_operator
begin_operator
down f5 f3
0
1
0 0 4 2
0
end_operator
begin_operator
down f5 f4
0
1
0 0 4 3
0
end_operator
begin_operator
down f6 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 5 1
0
end_operator
begin_operator
down f6 f3
0
1
0 0 5 2
0
end_operator
begin_operator
down f6 f4
0
1
0 0 5 3
0
end_operator
begin_operator
down f6 f5
0
1
0 0 5 4
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 4
0
end_operator
begin_operator
up f1 f6
0
1
0 0 0 5
0
end_operator
begin_operator
up f2 f3
0
1
0 0 1 2
0
end_operator
begin_operator
up f2 f4
0
1
0 0 1 3
0
end_operator
begin_operator
up f2 f5
0
1
0 0 1 4
0
end_operator
begin_operator
up f2 f6
0
1
0 0 1 5
0
end_operator
begin_operator
up f3 f4
0
1
0 0 2 3
0
end_operator
begin_operator
up f3 f5
0
1
0 0 2 4
0
end_operator
begin_operator
up f3 f6
0
1
0 0 2 5
0
end_operator
begin_operator
up f4 f5
0
1
0 0 3 4
0
end_operator
begin_operator
up f4 f6
0
1
0 0 3 5
0
end_operator
begin_operator
up f5 f6
0
1
0 0 4 5
0
end_operator
0
begin_SG
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
switch 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
switch 0
check 0
check 5
19
20
21
22
23
check 5
4
24
25
26
27
check 5
5
6
28
29
30
check 5
7
8
9
31
32
check 5
10
11
12
13
33
check 5
14
15
16
17
18
check 0
end_SG
begin_DTG
5
1
19
0
2
20
0
3
21
0
4
22
0
5
23
0
5
0
4
0
2
24
0
3
25
0
4
26
0
5
27
0
5
0
5
0
1
6
0
3
28
0
4
29
0
5
30
0
5
0
7
0
1
8
0
2
9
0
4
31
0
5
32
0
5
0
10
0
1
11
0
2
12
0
3
13
0
5
33
0
5
0
14
0
1
15
0
2
16
0
3
17
0
4
18
0
end_DTG
begin_DTG
1
2
3
1
0 4
1
0
1
1
0 5
0
end_DTG
begin_DTG
1
2
2
1
0 4
1
0
0
1
0 0
0
end_DTG
begin_CG
2
2 2
1 2
0
0
end_CG
