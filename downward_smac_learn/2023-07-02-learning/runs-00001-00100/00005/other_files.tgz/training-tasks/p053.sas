begin_version
3
end_version
begin_metric
0
end_metric
6
begin_variable
var5
-1
11
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f1)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f7)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f6)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f7)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f7)
Atom served(p1)
end_variable
0
begin_state
6
1
1
1
1
1
end_state
begin_goal
5
1 2
2 2
3 2
4 2
5 2
end_goal
120
begin_operator
board f1 p5
1
0 0
1
0 1 1 0
0
end_operator
begin_operator
board f6 p3
1
0 7
1
0 3 1 0
0
end_operator
begin_operator
board f7 p1
1
0 8
1
0 5 1 0
0
end_operator
begin_operator
board f7 p2
1
0 8
1
0 4 1 0
0
end_operator
begin_operator
board f7 p4
1
0 8
1
0 2 1 0
0
end_operator
begin_operator
depart f10 p1
1
0 1
1
0 5 0 2
0
end_operator
begin_operator
depart f10 p3
1
0 1
1
0 3 0 2
0
end_operator
begin_operator
depart f10 p5
1
0 1
1
0 1 0 2
0
end_operator
begin_operator
depart f6 p2
1
0 7
1
0 4 0 2
0
end_operator
begin_operator
depart f6 p4
1
0 7
1
0 2 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 3
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 4
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 5
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 6
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 10
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 3
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 4
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 5
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 6
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 7
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 8
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 10
0
end_operator
begin_operator
down f2 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 4 3
0
end_operator
begin_operator
down f4 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 5 3
0
end_operator
begin_operator
down f4 f3
0
1
0 0 5 4
0
end_operator
begin_operator
down f5 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 6 3
0
end_operator
begin_operator
down f5 f3
0
1
0 0 6 4
0
end_operator
begin_operator
down f5 f4
0
1
0 0 6 5
0
end_operator
begin_operator
down f6 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 7 3
0
end_operator
begin_operator
down f6 f3
0
1
0 0 7 4
0
end_operator
begin_operator
down f6 f4
0
1
0 0 7 5
0
end_operator
begin_operator
down f6 f5
0
1
0 0 7 6
0
end_operator
begin_operator
down f7 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 8 3
0
end_operator
begin_operator
down f7 f3
0
1
0 0 8 4
0
end_operator
begin_operator
down f7 f4
0
1
0 0 8 5
0
end_operator
begin_operator
down f7 f5
0
1
0 0 8 6
0
end_operator
begin_operator
down f7 f6
0
1
0 0 8 7
0
end_operator
begin_operator
down f8 f1
0
1
0 0 9 0
0
end_operator
begin_operator
down f8 f2
0
1
0 0 9 3
0
end_operator
begin_operator
down f8 f3
0
1
0 0 9 4
0
end_operator
begin_operator
down f8 f4
0
1
0 0 9 5
0
end_operator
begin_operator
down f8 f5
0
1
0 0 9 6
0
end_operator
begin_operator
down f8 f6
0
1
0 0 9 7
0
end_operator
begin_operator
down f8 f7
0
1
0 0 9 8
0
end_operator
begin_operator
down f9 f1
0
1
0 0 10 0
0
end_operator
begin_operator
down f9 f2
0
1
0 0 10 3
0
end_operator
begin_operator
down f9 f3
0
1
0 0 10 4
0
end_operator
begin_operator
down f9 f4
0
1
0 0 10 5
0
end_operator
begin_operator
down f9 f5
0
1
0 0 10 6
0
end_operator
begin_operator
down f9 f6
0
1
0 0 10 7
0
end_operator
begin_operator
down f9 f7
0
1
0 0 10 8
0
end_operator
begin_operator
down f9 f8
0
1
0 0 10 9
0
end_operator
begin_operator
up f1 f10
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f11
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 4
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 5
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 6
0
end_operator
begin_operator
up f1 f6
0
1
0 0 0 7
0
end_operator
begin_operator
up f1 f7
0
1
0 0 0 8
0
end_operator
begin_operator
up f1 f8
0
1
0 0 0 9
0
end_operator
begin_operator
up f1 f9
0
1
0 0 0 10
0
end_operator
begin_operator
up f10 f11
0
1
0 0 1 2
0
end_operator
begin_operator
up f2 f10
0
1
0 0 3 1
0
end_operator
begin_operator
up f2 f11
0
1
0 0 3 2
0
end_operator
begin_operator
up f2 f3
0
1
0 0 3 4
0
end_operator
begin_operator
up f2 f4
0
1
0 0 3 5
0
end_operator
begin_operator
up f2 f5
0
1
0 0 3 6
0
end_operator
begin_operator
up f2 f6
0
1
0 0 3 7
0
end_operator
begin_operator
up f2 f7
0
1
0 0 3 8
0
end_operator
begin_operator
up f2 f8
0
1
0 0 3 9
0
end_operator
begin_operator
up f2 f9
0
1
0 0 3 10
0
end_operator
begin_operator
up f3 f10
0
1
0 0 4 1
0
end_operator
begin_operator
up f3 f11
0
1
0 0 4 2
0
end_operator
begin_operator
up f3 f4
0
1
0 0 4 5
0
end_operator
begin_operator
up f3 f5
0
1
0 0 4 6
0
end_operator
begin_operator
up f3 f6
0
1
0 0 4 7
0
end_operator
begin_operator
up f3 f7
0
1
0 0 4 8
0
end_operator
begin_operator
up f3 f8
0
1
0 0 4 9
0
end_operator
begin_operator
up f3 f9
0
1
0 0 4 10
0
end_operator
begin_operator
up f4 f10
0
1
0 0 5 1
0
end_operator
begin_operator
up f4 f11
0
1
0 0 5 2
0
end_operator
begin_operator
up f4 f5
0
1
0 0 5 6
0
end_operator
begin_operator
up f4 f6
0
1
0 0 5 7
0
end_operator
begin_operator
up f4 f7
0
1
0 0 5 8
0
end_operator
begin_operator
up f4 f8
0
1
0 0 5 9
0
end_operator
begin_operator
up f4 f9
0
1
0 0 5 10
0
end_operator
begin_operator
up f5 f10
0
1
0 0 6 1
0
end_operator
begin_operator
up f5 f11
0
1
0 0 6 2
0
end_operator
begin_operator
up f5 f6
0
1
0 0 6 7
0
end_operator
begin_operator
up f5 f7
0
1
0 0 6 8
0
end_operator
begin_operator
up f5 f8
0
1
0 0 6 9
0
end_operator
begin_operator
up f5 f9
0
1
0 0 6 10
0
end_operator
begin_operator
up f6 f10
0
1
0 0 7 1
0
end_operator
begin_operator
up f6 f11
0
1
0 0 7 2
0
end_operator
begin_operator
up f6 f7
0
1
0 0 7 8
0
end_operator
begin_operator
up f6 f8
0
1
0 0 7 9
0
end_operator
begin_operator
up f6 f9
0
1
0 0 7 10
0
end_operator
begin_operator
up f7 f10
0
1
0 0 8 1
0
end_operator
begin_operator
up f7 f11
0
1
0 0 8 2
0
end_operator
begin_operator
up f7 f8
0
1
0 0 8 9
0
end_operator
begin_operator
up f7 f9
0
1
0 0 8 10
0
end_operator
begin_operator
up f8 f10
0
1
0 0 9 1
0
end_operator
begin_operator
up f8 f11
0
1
0 0 9 2
0
end_operator
begin_operator
up f8 f9
0
1
0 0 9 10
0
end_operator
begin_operator
up f9 f10
0
1
0 0 10 1
0
end_operator
begin_operator
up f9 f11
0
1
0 0 10 2
0
end_operator
0
begin_SG
switch 5
check 0
switch 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
switch 4
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
8
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
9
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 10
65
66
67
68
69
70
71
72
73
74
check 10
10
11
12
13
14
15
16
17
18
75
check 10
19
20
21
22
23
24
25
26
27
28
check 10
29
76
77
78
79
80
81
82
83
84
check 10
30
31
85
86
87
88
89
90
91
92
check 10
32
33
34
93
94
95
96
97
98
99
check 10
35
36
37
38
100
101
102
103
104
105
check 10
39
40
41
42
43
106
107
108
109
110
check 10
44
45
46
47
48
49
111
112
113
114
check 10
50
51
52
53
54
55
56
115
116
117
check 10
57
58
59
60
61
62
63
64
118
119
check 0
end_SG
begin_DTG
10
1
65
0
2
66
0
3
67
0
4
68
0
5
69
0
6
70
0
7
71
0
8
72
0
9
73
0
10
74
0
10
0
10
0
2
75
0
3
11
0
4
12
0
5
13
0
6
14
0
7
15
0
8
16
0
9
17
0
10
18
0
10
0
19
0
1
20
0
3
21
0
4
22
0
5
23
0
6
24
0
7
25
0
8
26
0
9
27
0
10
28
0
10
0
29
0
1
76
0
2
77
0
4
78
0
5
79
0
6
80
0
7
81
0
8
82
0
9
83
0
10
84
0
10
0
30
0
1
85
0
2
86
0
3
31
0
5
87
0
6
88
0
7
89
0
8
90
0
9
91
0
10
92
0
10
0
32
0
1
93
0
2
94
0
3
33
0
4
34
0
6
95
0
7
96
0
8
97
0
9
98
0
10
99
0
10
0
35
0
1
100
0
2
101
0
3
36
0
4
37
0
5
38
0
7
102
0
8
103
0
9
104
0
10
105
0
10
0
39
0
1
106
0
2
107
0
3
40
0
4
41
0
5
42
0
6
43
0
8
108
0
9
109
0
10
110
0
10
0
44
0
1
111
0
2
112
0
3
45
0
4
46
0
5
47
0
6
48
0
7
49
0
9
113
0
10
114
0
10
0
50
0
1
115
0
2
116
0
3
51
0
4
52
0
5
53
0
6
54
0
7
55
0
8
56
0
10
117
0
10
0
57
0
1
118
0
2
119
0
3
58
0
4
59
0
5
60
0
6
61
0
7
62
0
8
63
0
9
64
0
end_DTG
begin_DTG
1
2
7
1
0 1
1
0
0
1
0 0
0
end_DTG
begin_DTG
1
2
9
1
0 7
1
0
4
1
0 8
0
end_DTG
begin_DTG
1
2
6
1
0 1
1
0
1
1
0 7
0
end_DTG
begin_DTG
1
2
8
1
0 7
1
0
3
1
0 8
0
end_DTG
begin_DTG
1
2
5
1
0 1
1
0
2
1
0 8
0
end_DTG
begin_CG
5
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
end_CG
