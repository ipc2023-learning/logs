begin_version
3
end_version
begin_metric
0
end_metric
2
begin_variable
var1
-1
2
Atom lift-at(f1)
Atom lift-at(f2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f1)
Atom served(p1)
end_variable
0
begin_state
1
1
end_state
begin_goal
1
1 2
end_goal
4
begin_operator
board f1 p1
1
0 0
1
0 1 1 0
0
end_operator
begin_operator
depart f2 p1
1
0 1
1
0 1 0 2
0
end_operator
begin_operator
down f2 f1
0
1
0 0 1 0
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 1
0
end_operator
0
begin_SG
switch 1
check 0
switch 0
check 0
check 0
check 1
1
check 0
switch 0
check 0
check 1
0
check 0
check 0
check 0
switch 0
check 0
check 1
3
check 1
2
check 0
end_SG
begin_DTG
1
1
3
0
1
0
2
0
end_DTG
begin_DTG
1
2
1
1
0 1
1
0
0
1
0 0
0
end_DTG
begin_CG
1
1 2
0
end_CG
