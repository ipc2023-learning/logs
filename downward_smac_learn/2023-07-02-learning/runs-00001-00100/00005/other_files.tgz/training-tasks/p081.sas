begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var8
-1
17
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f15)
Atom lift-at(f16)
Atom lift-at(f17)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var7
-1
3
Atom boarded(p8)
Atom origin(p8, f3)
Atom served(p8)
end_variable
begin_variable
var6
-1
3
Atom boarded(p7)
Atom origin(p7, f4)
Atom served(p7)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f11)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f6)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f10)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f7)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f9)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f3)
Atom served(p1)
end_variable
0
begin_state
12
1
1
1
1
1
1
1
1
end_state
begin_goal
8
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
end_goal
288
begin_operator
board f10 p4
1
0 1
1
0 5 1 0
0
end_operator
begin_operator
board f11 p6
1
0 2
1
0 3 1 0
0
end_operator
begin_operator
board f3 p1
1
0 10
1
0 8 1 0
0
end_operator
begin_operator
board f3 p8
1
0 10
1
0 1 1 0
0
end_operator
begin_operator
board f4 p7
1
0 11
1
0 2 1 0
0
end_operator
begin_operator
board f6 p5
1
0 13
1
0 4 1 0
0
end_operator
begin_operator
board f7 p3
1
0 14
1
0 6 1 0
0
end_operator
begin_operator
board f9 p2
1
0 16
1
0 7 1 0
0
end_operator
begin_operator
depart f14 p1
1
0 5
1
0 8 0 2
0
end_operator
begin_operator
depart f14 p2
1
0 5
1
0 7 0 2
0
end_operator
begin_operator
depart f15 p8
1
0 6
1
0 1 0 2
0
end_operator
begin_operator
depart f3 p3
1
0 10
1
0 6 0 2
0
end_operator
begin_operator
depart f7 p4
1
0 14
1
0 5 0 2
0
end_operator
begin_operator
depart f7 p6
1
0 14
1
0 3 0 2
0
end_operator
begin_operator
depart f8 p5
1
0 15
1
0 4 0 2
0
end_operator
begin_operator
depart f8 p7
1
0 15
1
0 2 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 13
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 14
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 15
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 16
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 13
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 14
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 15
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 16
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 13
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 14
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 15
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 16
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 9
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 10
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 13
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 14
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 15
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 16
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 9
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 10
0
end_operator
begin_operator
down f14 f4
0
1
0 0 5 11
0
end_operator
begin_operator
down f14 f5
0
1
0 0 5 12
0
end_operator
begin_operator
down f14 f6
0
1
0 0 5 13
0
end_operator
begin_operator
down f14 f7
0
1
0 0 5 14
0
end_operator
begin_operator
down f14 f8
0
1
0 0 5 15





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
13
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
15
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
10
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 16
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
check 16
16
17
18
19
20
21
22
23
24
168
169
170
171
172
173
174
check 16
25
26
27
28
29
30
31
32
33
34
175
176
177
178
179
180
check 16
35
36
37
38
39
40
41
42
43
44
45
181
182
183
184
185
check 16
46
47
48
49
50
51
52
53
54
55
56
57
186
187
188
189
check 16
58
59
60
61
62
63
64
65
66
67
68
69
70
190
191
192
check 16
71
72
73
74
75
76
77
78
79
80
81
82
83
84
193
194
check 16
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
195
check 16
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
check 16
116
196
197
198
199
200
201
202
203
204
205
206
207
208
209
210
check 16
117
118
211
212
213
214
215
216
217
218
219
220
221
222
223
224
check 16
119
120
121
225
226
227
228
229
230
231
232
233
234
235
236
237
check 16
122
123
124
125
238
239
240
241
242
243
244
245
246
247
248
249
check 16
126
127
128
129
130
250
251
252
253
254
255
256
257
258
259
260
check 16
131
132
133
134
135
136
261
262
263
264
265
266
267
268
269
270
check 16
137
138
139
140
141
142
143
271
272
273
274
275
276
277
278
279
check 16
144
145
146
147
148
149
150
151
280
281
282
283
284
285
286
287
check 0
end_SG
begin_DTG
16
1
152
0
2
153
0
3
154
0
4
155
0
5
156
0
6
157
0
7
158
0
8
159
0
9
160
0
10
161
0
11
162
0
12
163
0
13
164
0
14
165
0
15
166
0
16
167
0
16
0
16
0
2
168
0
3
169
0
4
170
0
5
171
0
6
172
0
7
173
0
8
174
0
9
17
0
10
18
0
11
19
0
12
20
0
13
21
0
14
22
0
15
23
0
16
24
0
16
0
25
0
1
26
0
3
175
0
4
176
0
5
177
0
6
178
0
7
179
0
8
180
0
9
27
0
10
28
0
11
29
0
12
30
0
13
31
0
14
32
0
15
33
0
16
34
0
16
0
35
0
1
36
0
2
37
0
4
181
0
5
182
0
6
183
0
7
184
0
8
185
0
9
38
0
10
39
0
11
40
0
12
41
0
13
42
0
14
43
0
15
44
0
16
45
0
16
0
46
0
1
47
0
2
48
0
3
49
0
5
186
0
6
187
0
7
188
0
8
189
0
9
50
0
10
51
0
11
52
0
12
53
0
13
54
0
14
55
0
15
56
0
16
57
0
16
0
58
0
1
59
0
2
60
0
3
61
0
4
62
0
6
190
0
7
191
0
8
192
0
9
63
0
10
64
0
11
65
0
12
66
0
13
67
0
14
68
0
15
69
0
16
70
0
16
0
71
0
1
72
0
2
73
0
3
74
0
4
75
0
5
76
0
7
193
0
8
194
0
9
77
0
10
78
0
11
79
0
12
80
0
13
81
0
14
82
0
15
83
0
16
84
0
16
0
85
0
1
86
0
2
87
0
3
88
0
4
89
0
5
90
0
6
91
0
8
195
0
9
92
0
10
93
0
11
94
0
12
95
0
13
96
0
14
97
0
15
98
0
16
99
0
16
0
100
0
1
101
0
2
102
0
3
103
0
4
104
0
5
105
0
6
106
0
7
107
0
9
108
0
10
109
0
11
110
0
12
111
0
13
112
0
14
113
0
15
114
0
16
115
0
16
0
116
0
1
196
0
2
197
0
3
198
0
4
199
0
5
200
0
6
201
0
7
202
0
8
203
0
10
204
0
11
205
0
12
206
0
13
207
0
14
208
0
15
209
0
16
210
0
16
0
117
0
1
211
0
2
212
0
3
213
0
4
214
0
5
215
0
6
216
0
7
217
0
8
218
0
9
118
0
11
219
0
12
220
0
13
221
0
14
222
0
15
223
0
16
224
0
16
0
119
0
1
225
0
2
226
0
3
227
0
4
228
0
5
229
0
6
230
0
7
231
0
8
232
0
9
120
0
10
121
0
12
233
0
13
234
0
14
235
0
15
236
0
16
237
0
16
0
122
0
1
238
0
2
239
0
3
240
0
4
241
0
5
242
0
6
243
0
7
244
0
8
245
0
9
123
0
10
124
0
11
125
0
13
246
0
14
247
0
15
248
0
16
249
0
16
0
126
0
1
250
0
2
251
0
3
252
0
4
253
0
5
254
0
6
255
0
7
256
0
8
257
0
9
127
0
10
128
0
11
129
0
12
130
0
14
258
0
15
259
0
16
260
0
16
0
131
0
1
261
0
2
262
0
3
263
0
4
264
0
5
265
0
6
266
0
7
267
0
8
268
0
9
132
0
10
133
0
11
134
0
12
135
0
13
136
0
15
269
0
16
270
0
16
0
137
0
1
271
0
2
272
0
3
273
0
4
274
0
5
275
0
6
276
0
7
277
0
8
278
0
9
138
0
10
139
0
11
140
0
12
141
0
13
142
0
14
143
0
16
279
0
16
0
144
0
1
280
0
2
281
0
3
282
0
4
283
0
5
284
0
6
285
0
7
286
0
8
287
0
9
145
0
10
146
0
11
147
0
12
148
0
13
149
0
14
150
0
15
151
0
end_DTG
begin_DTG
1
2
10
1
0 6
1
0
3
1
0 10
0
end_DTG
begin_DTG
1
2
15
1
0 15
1
0
4
1
0 11
0
end_DTG
begin_DTG
1
2
13
1
0 14
1
0
1
1
0 2
0
end_DTG
begin_DTG
1
2
14
1
0 15
1
0
5
1
0 13
0
end_DTG
begin_DTG
1
2
12
1
0 14
1
0
0
1
0 1
0
end_DTG
begin_DTG
1
2
11
1
0 10
1
0
6
1
0 14
0
end_DTG
begin_DTG
1
2
9
1
0 5
1
0
7
1
0 16
0
end_DTG
begin_DTG
1
2
8
1
0 5
1
0
2
1
0 10
0
end_DTG
begin_CG
8
8 2
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
0
end_CG
