begin_version
3
end_version
begin_metric
0
end_metric
11
begin_variable
var10
-1
19
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f15)
Atom lift-at(f16)
Atom lift-at(f17)
Atom lift-at(f18)
Atom lift-at(f19)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var9
-1
3
Atom boarded(p9)
Atom origin(p9, f15)
Atom served(p9)
end_variable
begin_variable
var8
-1
3
Atom boarded(p8)
Atom origin(p8, f14)
Atom served(p8)
end_variable
begin_variable
var7
-1
3
Atom boarded(p7)
Atom origin(p7, f1)
Atom served(p7)
end_variable
begin_variable
var6
-1
3
Atom boarded(p6)
Atom origin(p6, f14)
Atom served(p6)
end_variable
begin_variable
var5
-1
3
Atom boarded(p5)
Atom origin(p5, f14)
Atom served(p5)
end_variable
begin_variable
var4
-1
3
Atom boarded(p4)
Atom origin(p4, f10)
Atom served(p4)
end_variable
begin_variable
var3
-1
3
Atom boarded(p3)
Atom origin(p3, f6)
Atom served(p3)
end_variable
begin_variable
var2
-1
3
Atom boarded(p2)
Atom origin(p2, f6)
Atom served(p2)
end_variable
begin_variable
var1
-1
3
Atom boarded(p10)
Atom origin(p10, f5)
Atom served(p10)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f7)
Atom served(p1)
end_variable
0
begin_state
12
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
10
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
end_goal
362
begin_operator
board f1 p7
1
0 0
1
0 3 1 0
0
end_operator
begin_operator
board f10 p4
1
0 1
1
0 6 1 0
0
end_operator
begin_operator
board f14 p5
1
0 5
1
0 5 1 0
0
end_operator
begin_operator
board f14 p6
1
0 5
1
0 4 1 0
0
end_operator
begin_operator
board f14 p8
1
0 5
1
0 2 1 0
0
end_operator
begin_operator
board f15 p9
1
0 6
1
0 1 1 0
0
end_operator
begin_operator
board f5 p10
1
0 14
1
0 9 1 0
0
end_operator
begin_operator
board f6 p2
1
0 15
1
0 8 1 0
0
end_operator
begin_operator
board f6 p3
1
0 15
1
0 7 1 0
0
end_operator
begin_operator
board f7 p1
1
0 16
1
0 10 1 0
0
end_operator
begin_operator
depart f11 p8
1
0 2
1
0 2 0 2
0
end_operator
begin_operator
depart f12 p3
1
0 3
1
0 7 0 2
0
end_operator
begin_operator
depart f13 p10
1
0 4
1
0 9 0 2
0
end_operator
begin_operator
depart f14 p1
1
0 5
1
0 10 0 2
0
end_operator
begin_operator
depart f17 p7
1
0 8
1
0 3 0 2
0
end_operator
begin_operator
depart f18 p2
1
0 9
1
0 8 0 2
0
end_operator
begin_operator
depart f2 p5
1
0 11
1
0 5 0 2
0
end_operator
begin_operator
depart f5 p6
1
0 14
1
0 4 0 2
0
end_operator
begin_operator
depart f6 p4
1
0 15
1
0 6 0 2
0
end_operator
begin_operator
depart f8 p9
1
0 17
1
0 1 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 13
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 14
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 15
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 16
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 17
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 18
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 13
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 14
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 15
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 16
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 17
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 18
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 13
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 14
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 15
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 16
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 17
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 18
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 13
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 14
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 15
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 16
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 17
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 18
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_ope




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 18
191
192
193
194
195
196
197
198
199
200
201
202
203
204
205
206
207
208
check 18
20
21
22
23
24
25
26
27
28
209
210
211
212
213
214
215
216
217
check 18
29
30
31
32
33
34
35
36
37
38
218
219
220
221
222
223
224
225
check 18
39
40
41
42
43
44
45
46
47
48
49
226
227
228
229
230
231
232
check 18
50
51
52
53
54
55
56
57
58
59
60
61
233
234
235
236
237
238
check 18
62
63
64
65
66
67
68
69
70
71
72
73
74
239
240
241
242
243
check 18
75
76
77
78
79
80
81
82
83
84
85
86
87
88
244
245
246
247
check 18
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
248
249
250
check 18
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
251
252
check 18
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
253
check 18
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
check 18
155
254
255
256
257
258
259
260
261
262
263
264
265
266
267
268
269
270
check 18
156
157
271
272
273
274
275
276
277
278
279
280
281
282
283
284
285
286
check 18
158
159
160
287
288
289
290
291
292
293
294
295
296
297
298
299
300
301
check 18
161
162
163
164
302
303
304
305
306
307
308
309
310
311
312
313
314
315
check 18
165
166
167
168
169
316
317
318
319
320
321
322
323
324
325
326
327
328
check 18
170
171
172
173
174
175
329
330
331
332
333
334
335
336
337
338
339
340
check 18
176
177
178
179
180
181
182
341
342
343
344
345
346
347
348
349
350
351
check 18
183
184
185
186
187
188
189
190
352
353
354
355
356
357
358
359
360
361
check 0
end_SG
begin_DTG
18
1
191
0
2
192
0
3
193
0
4
194
0
5
195
0
6
196
0
7
197
0
8
198
0
9
199
0
10
200
0
11
201
0
12
202
0
13
203
0
14
204
0
15
205
0
16
206
0
17
207
0
18
208
0
18
0
20
0
2
209
0
3
210
0
4
211
0
5
212
0
6
213
0
7
214
0
8
215
0
9
216
0
10
217
0
11
21
0
12
22
0
13
23
0
14
24
0
15
25
0
16
26
0
17
27
0
18
28
0
18
0
29
0
1
30
0
3
218
0
4
219
0
5
220
0
6
221
0
7
222
0
8
223
0
9
224
0
10
225
0
11
31
0
12
32
0
13
33
0
14
34
0
15
35
0
16
36
0
17
37
0
18
38
0
18
0
39
0
1
40
0
2
41
0
4
226
0
5
227
0
6
228
0
7
229
0
8
230
0
9
231
0
10
232
0
11
42
0
12
43
0
13
44
0
14
45
0
15
46
0
16
47
0
17
48
0
18
49
0
18
0
50
0
1
51
0
2
52
0
3
53
0
5
233
0
6
234
0
7
235
0
8
236
0
9
237
0
10
238
0
11
54
0
12
55
0
13
56
0
14
57
0
15
58
0
16
59
0
17
60
0
18
61
0
18
0
62
0
1
63
0
2
64
0
3
65
0
4
66
0
6
239
0
7
240
0
8
241
0
9
242
0
10
243
0
11
67
0
12
68
0
13
69
0
14
70
0
15
71
0
16
72
0
17
73
0
18
74
0
18
0
75
0
1
76
0
2
77
0
3
78
0
4
79
0
5
80
0
7
244
0
8
245
0
9
246
0
10
247
0
11
81
0
12
82
0
13
83
0
14
84
0
15
85
0
16
86
0
17
87
0
18
88
0
18
0
89
0
1
90
0
2
91
0
3
92
0
4
93
0
5
94
0
6
95
0
8
248
0
9
249
0
10
250
0
11
96
0
12
97
0
13
98
0
14
99
0
15
100
0
16
101
0
17
102
0
18
103
0
18
0
104
0
1
105
0
2
106
0
3
107
0
4
108
0
5
109
0
6
110
0
7
111
0
9
251
0
10
252
0
11
112
0
12
113
0
13
114
0
14
115
0
15
116
0
16
117
0
17
118
0
18
119
0
18
0
120
0
1
121
0
2
122
0
3
123
0
4
124
0
5
125
0
6
126
0
7
127
0
8
128
0
10
253
0
11
129
0
12
130
0
13
131
0
14
132
0
15
133
0
16
134
0
17
135
0
18
136
0
18
0
137
0
1
138
0
2
139
0
3
140
0
4
141
0
5
142
0
6
143
0
7
144
0
8
145
0
9
146
0
11
147
0
12
148
0
13
149
0
14
150
0
15
151
0
16
152
0
17
153
0
18
154
0
18
0
155
0
1
254
0
2
255
0
3
256
0
4
257
0
5
258
0
6
259
0
7
260
0
8
261
0
9
262
0
10
263
0
12
264
0
13
265
0
14
266
0
15
267
0
16
268
0
17
269
0
18
270
0
18
0
156
0
1
271
0
2
272
0
3
273
0
4
274
0
5
275
0
6
276
0
7
277
0
8
278
0
9
279
0
10
280
0
11
157
0
13
281
0
14
282
0
15
283
0
16
284
0
17
285
0
18
286
0
18
0
158
0
1
287
0
2
288
0
3
289
0
4
290
0
5
291
0
6
292
0
7
293
0
8
294
0
9
295
0
10
296
0
11
159
0
12
160
0
14
297
0
15
298
0
16
299
0
17
300
0
18
301
0
18
0
161
0
1
302
0
2
303
0
3
304
0
4
305
0
5
306
0
6
307
0
7
308
0
8
309
0
9
310
0
10
311
0
11
162
0
12
163
0
13
164
0
15
312
0
16
313
0
17
314
0
18
315
0
18
0
165
0
1
316
0
2
317
0
3
318
0
4
319
0
5
320
0
6
321
0
7
322
0
8
323
0
9
324
0
10
325
0
11
166
0
12
167
0
13
168
0
14
169
0
16
326
0
17
327
0
18
328
0
18
0
170
0
1
329
0
2
330
0
3
331
0
4
332
0
5
333
0
6
334
0
7
335
0
8
336
0
9
337
0
10
338
0
11
171
0
12
172
0
13
173
0
14
174
0
15
175
0
17
339
0
18
340
0
18
0
176
0
1
341
0
2
342
0
3
343
0
4
344
0
5
345
0
6
346
0
7
347
0
8
348
0
9
349
0
10
350
0
11
177
0
12
178
0
13
179
0
14
180
0
15
181
0
16
182
0
18
351
0
18
0
183
0
1
352
0
2
353
0
3
354
0
4
355
0
5
356
0
6
357
0
7
358
0
8
359
0
9
360
0
10
361
0
11
184
0
12
185
0
13
186
0
14
187
0
15
188
0
16
189
0
17
190
0
end_DTG
begin_DTG
1
2
19
1
0 17
1
0
5
1
0 6
0
end_DTG
begin_DTG
1
2
10
1
0 2
1
0
4
1
0 5
0
end_DTG
begin_DTG
1
2
14
1
0 8
1
0
0
1
0 0
0
end_DTG
begin_DTG
1
2
17
1
0 14
1
0
3
1
0 5
0
end_DTG
begin_DTG
1
2
16
1
0 11
1
0
2
1
0 5
0
end_DTG
begin_DTG
1
2
18
1
0 15
1
0
1
1
0 1
0
end_DTG
begin_DTG
1
2
11
1
0 3
1
0
8
1
0 15
0
end_DTG
begin_DTG
1
2
15
1
0 9
1
0
7
1
0 15
0
end_DTG
begin_DTG
1
2
12
1
0 4
1
0
6
1
0 14
0
end_DTG
begin_DTG
1
2
13
1
0 5
1
0
9
1
0 16
0
end_DTG
begin_CG
10
10 2
9 2
8 2
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
0
0
0
end_CG
