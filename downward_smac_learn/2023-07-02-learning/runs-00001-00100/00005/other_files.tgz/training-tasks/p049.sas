begin_version
3
end_version
begin_metric
0
end_metric
6
begin_variable
var5
-1
10
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f5)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f4)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f1)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f4)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f8)
Atom served(p1)
end_variable
0
begin_state
6
1
1
1
1
1
end_state
begin_goal
5
1 2
2 2
3 2
4 2
5 2
end_goal
100
begin_operator
board f1 p3
1
0 0
1
0 3 1 0
0
end_operator
begin_operator
board f4 p2
1
0 4
1
0 4 1 0
0
end_operator
begin_operator
board f4 p4
1
0 4
1
0 2 1 0
0
end_operator
begin_operator
board f5 p5
1
0 5
1
0 1 1 0
0
end_operator
begin_operator
board f8 p1
1
0 8
1
0 5 1 0
0
end_operator
begin_operator
depart f6 p2
1
0 6
1
0 4 0 2
0
end_operator
begin_operator
depart f6 p4
1
0 6
1
0 2 0 2
0
end_operator
begin_operator
depart f7 p1
1
0 7
1
0 5 0 2
0
end_operator
begin_operator
depart f8 p3
1
0 8
1
0 3 0 2
0
end_operator
begin_operator
depart f9 p5
1
0 9
1
0 1 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 2
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 3
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 4
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 5
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 6
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 9
0
end_operator
begin_operator
down f2 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 3 2
0
end_operator
begin_operator
down f4 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 4 2
0
end_operator
begin_operator
down f4 f3
0
1
0 0 4 3
0
end_operator
begin_operator
down f5 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 5 2
0
end_operator
begin_operator
down f5 f3
0
1
0 0 5 3
0
end_operator
begin_operator
down f5 f4
0
1
0 0 5 4
0
end_operator
begin_operator
down f6 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 6 2
0
end_operator
begin_operator
down f6 f3
0
1
0 0 6 3
0
end_operator
begin_operator
down f6 f4
0
1
0 0 6 4
0
end_operator
begin_operator
down f6 f5
0
1
0 0 6 5
0
end_operator
begin_operator
down f7 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 7 2
0
end_operator
begin_operator
down f7 f3
0
1
0 0 7 3
0
end_operator
begin_operator
down f7 f4
0
1
0 0 7 4
0
end_operator
begin_operator
down f7 f5
0
1
0 0 7 5
0
end_operator
begin_operator
down f7 f6
0
1
0 0 7 6
0
end_operator
begin_operator
down f8 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f8 f2
0
1
0 0 8 2
0
end_operator
begin_operator
down f8 f3
0
1
0 0 8 3
0
end_operator
begin_operator
down f8 f4
0
1
0 0 8 4
0
end_operator
begin_operator
down f8 f5
0
1
0 0 8 5
0
end_operator
begin_operator
down f8 f6
0
1
0 0 8 6
0
end_operator
begin_operator
down f8 f7
0
1
0 0 8 7
0
end_operator
begin_operator
down f9 f1
0
1
0 0 9 0
0
end_operator
begin_operator
down f9 f2
0
1
0 0 9 2
0
end_operator
begin_operator
down f9 f3
0
1
0 0 9 3
0
end_operator
begin_operator
down f9 f4
0
1
0 0 9 4
0
end_operator
begin_operator
down f9 f5
0
1
0 0 9 5
0
end_operator
begin_operator
down f9 f6
0
1
0 0 9 6
0
end_operator
begin_operator
down f9 f7
0
1
0 0 9 7
0
end_operator
begin_operator
down f9 f8
0
1
0 0 9 8
0
end_operator
begin_operator
up f1 f10
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f2
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f3
0
1
0 0 0 3
0
end_operator
begin_operator
up f1 f4
0
1
0 0 0 4
0
end_operator
begin_operator
up f1 f5
0
1
0 0 0 5
0
end_operator
begin_operator
up f1 f6
0
1
0 0 0 6
0
end_operator
begin_operator
up f1 f7
0
1
0 0 0 7
0
end_operator
begin_operator
up f1 f8
0
1
0 0 0 8
0
end_operator
begin_operator
up f1 f9
0
1
0 0 0 9
0
end_operator
begin_operator
up f2 f10
0
1
0 0 2 1
0
end_operator
begin_operator
up f2 f3
0
1
0 0 2 3
0
end_operator
begin_operator
up f2 f4
0
1
0 0 2 4
0
end_operator
begin_operator
up f2 f5
0
1
0 0 2 5
0
end_operator
begin_operator
up f2 f6
0
1
0 0 2 6
0
end_operator
begin_operator
up f2 f7
0
1
0 0 2 7
0
end_operator
begin_operator
up f2 f8
0
1
0 0 2 8
0
end_operator
begin_operator
up f2 f9
0
1
0 0 2 9
0
end_operator
begin_operator
up f3 f10
0
1
0 0 3 1
0
end_operator
begin_operator
up f3 f4
0
1
0 0 3 4
0
end_operator
begin_operator
up f3 f5
0
1
0 0 3 5
0
end_operator
begin_operator
up f3 f6
0
1
0 0 3 6
0
end_operator
begin_operator
up f3 f7
0
1
0 0 3 7
0
end_operator
begin_operator
up f3 f8
0
1
0 0 3 8
0
end_operator
begin_operator
up f3 f9
0
1
0 0 3 9
0
end_operator
begin_operator
up f4 f10
0
1
0 0 4 1
0
end_operator
begin_operator
up f4 f5
0
1
0 0 4 5
0
end_operator
begin_operator
up f4 f6
0
1
0 0 4 6
0
end_operator
begin_operator
up f4 f7
0
1
0 0 4 7
0
end_operator
begin_operator
up f4 f8
0
1
0 0 4 8
0
end_operator
begin_operator
up f4 f9
0
1
0 0 4 9
0
end_operator
begin_operator
up f5 f10
0
1
0 0 5 1
0
end_operator
begin_operator
up f5 f6
0
1
0 0 5 6
0
end_operator
begin_operator
up f5 f7
0
1
0 0 5 7
0
end_operator
begin_operator
up f5 f8
0
1
0 0 5 8
0
end_operator
begin_operator
up f5 f9
0
1
0 0 5 9
0
end_operator
begin_operator
up f6 f10
0
1
0 0 6 1
0
end_operator
begin_operator
up f6 f7
0
1
0 0 6 7
0
end_operator
begin_operator
up f6 f8
0
1
0 0 6 8
0
end_operator
begin_operator
up f6 f9
0
1
0 0 6 9
0
end_operator
begin_operator
up f7 f10
0
1
0 0 7 1
0
end_operator
begin_operator
up f7 f8
0
1
0 0 7 8
0
end_operator
begin_operator
up f7 f9
0
1
0 0 7 9
0
end_operator
begin_operator
up f8 f10
0
1
0 0 8 1
0
end_operator
begin_operator
up f8 f9
0
1
0 0 8 9
0
end_operator
begin_operator
up f9 f10
0
1
0 0 9 1
0
end_operator
0
begin_SG
switch 5
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
7
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
switch 4
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
8
check 0
check 0
switch 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
9
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 9
55
56
57
58
59
60
61
62
63
check 9
10
11
12
13
14
15
16
17
18
check 9
19
64
65
66
67
68
69
70
71
check 9
20
21
72
73
74
75
76
77
78
check 9
22
23
24
79
80
81
82
83
84
check 9
25
26
27
28
85
86
87
88
89
check 9
29
30
31
32
33
90
91
92
93
check 9
34
35
36
37
38
39
94
95
96
check 9
40
41
42
43
44
45
46
97
98
check 9
47
48
49
50
51
52
53
54
99
check 0
end_SG
begin_DTG
9
1
55
0
2
56
0
3
57
0
4
58
0
5
59
0
6
60
0
7
61
0
8
62
0
9
63
0
9
0
10
0
2
11
0
3
12
0
4
13
0
5
14
0
6
15
0
7
16
0
8
17
0
9
18
0
9
0
19
0
1
64
0
3
65
0
4
66
0
5
67
0
6
68
0
7
69
0
8
70
0
9
71
0
9
0
20
0
1
72
0
2
21
0
4
73
0
5
74
0
6
75
0
7
76
0
8
77
0
9
78
0
9
0
22
0
1
79
0
2
23
0
3
24
0
5
80
0
6
81
0
7
82
0
8
83
0
9
84
0
9
0
25
0
1
85
0
2
26
0
3
27
0
4
28
0
6
86
0
7
87
0
8
88
0
9
89
0
9
0
29
0
1
90
0
2
30
0
3
31
0
4
32
0
5
33
0
7
91
0
8
92
0
9
93
0
9
0
34
0
1
94
0
2
35
0
3
36
0
4
37
0
5
38
0
6
39
0
8
95
0
9
96
0
9
0
40
0
1
97
0
2
41
0
3
42
0
4
43
0
5
44
0
6
45
0
7
46
0
9
98
0
9
0
47
0
1
99
0
2
48
0
3
49
0
4
50
0
5
51
0
6
52
0
7
53
0
8
54
0
end_DTG
begin_DTG
1
2
9
1
0 9
1
0
3
1
0 5
0
end_DTG
begin_DTG
1
2
6
1
0 6
1
0
2
1
0 4
0
end_DTG
begin_DTG
1
2
8
1
0 8
1
0
0
1
0 0
0
end_DTG
begin_DTG
1
2
5
1
0 6
1
0
1
1
0 4
0
end_DTG
begin_DTG
1
2
7
1
0 7
1
0
4
1
0 8
0
end_DTG
begin_CG
5
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
end_CG
