begin_version
3
end_version
begin_metric
0
end_metric
10
begin_variable
var9
-1
19
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f13)
Atom lift-at(f14)
Atom lift-at(f15)
Atom lift-at(f16)
Atom lift-at(f17)
Atom lift-at(f18)
Atom lift-at(f19)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var8
-1
3
Atom boarded(p9)
Atom origin(p9, f19)
Atom served(p9)
end_variable
begin_variable
var7
-1
3
Atom boarded(p8)
Atom origin(p8, f1)
Atom served(p8)
end_variable
begin_variable
var6
-1
3
Atom boarded(p7)
Atom origin(p7, f5)
Atom served(p7)
end_variable
begin_variable
var5
-1
3
Atom boarded(p6)
Atom origin(p6, f11)
Atom served(p6)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f16)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f11)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f1)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f12)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f10)
Atom served(p1)
end_variable
0
begin_state
15
1
1
1
1
1
1
1
1
1
end_state
begin_goal
9
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
end_goal
360
begin_operator
board f1 p3
1
0 0
1
0 7 1 0
0
end_operator
begin_operator
board f1 p8
1
0 0
1
0 2 1 0
0
end_operator
begin_operator
board f10 p1
1
0 1
1
0 9 1 0
0
end_operator
begin_operator
board f11 p4
1
0 2
1
0 6 1 0
0
end_operator
begin_operator
board f11 p6
1
0 2
1
0 4 1 0
0
end_operator
begin_operator
board f12 p2
1
0 3
1
0 8 1 0
0
end_operator
begin_operator
board f16 p5
1
0 7
1
0 5 1 0
0
end_operator
begin_operator
board f19 p9
1
0 10
1
0 1 1 0
0
end_operator
begin_operator
board f5 p7
1
0 14
1
0 3 1 0
0
end_operator
begin_operator
depart f1 p4
1
0 0
1
0 6 0 2
0
end_operator
begin_operator
depart f10 p2
1
0 1
1
0 8 0 2
0
end_operator
begin_operator
depart f11 p3
1
0 2
1
0 7 0 2
0
end_operator
begin_operator
depart f18 p5
1
0 9
1
0 5 0 2
0
end_operator
begin_operator
depart f18 p6
1
0 9
1
0 4 0 2
0
end_operator
begin_operator
depart f18 p7
1
0 9
1
0 3 0 2
0
end_operator
begin_operator
depart f4 p1
1
0 13
1
0 9 0 2
0
end_operator
begin_operator
depart f5 p9
1
0 14
1
0 1 0 2
0
end_operator
begin_operator
depart f8 p8
1
0 17
1
0 2 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 11
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 12
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 13
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 14
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 15
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 16
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 17
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 18
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 11
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 12
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 13
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 14
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 15
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 16
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 17
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 18
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 11
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 12
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 13
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 14
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 15
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 16
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 17
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 18
0
end_operator
begin_operator
down f13 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f13 f10
0
1
0 0 4 1
0
end_operator
begin_operator
down f13 f11
0
1
0 0 4 2
0
end_operator
begin_operator
down f13 f12
0
1
0 0 4 3
0
end_operator
begin_operator
down f13 f2
0
1
0 0 4 11
0
end_operator
begin_operator
down f13 f3
0
1
0 0 4 12
0
end_operator
begin_operator
down f13 f4
0
1
0 0 4 13
0
end_operator
begin_operator
down f13 f5
0
1
0 0 4 14
0
end_operator
begin_operator
down f13 f6
0
1
0 0 4 15
0
end_operator
begin_operator
down f13 f7
0
1
0 0 4 16
0
end_operator
begin_operator
down f13 f8
0
1
0 0 4 17
0
end_operator
begin_operator
down f13 f9
0
1
0 0 4 18
0
end_operator
begin_operator
down f14 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f14 f10
0
1
0 0 5 1
0
end_operator
begin_operator
down f14 f11
0
1
0 0 5 2
0
end_operator
begin_operator
down f14 f12
0
1
0 0 5 3
0
end_operator
begin_operator
down f14 f13
0
1
0 0 5 4
0
end_operator
begin_operator
down f14 f2
0
1
0 0 5 11
0
end_operator
begin_operator
down f14 f3
0
1
0 0 5 12
0
end_operator





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ck 0
check 0
check 0
check 1
16
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 18
189
190
191
192
193
194
195
196
197
198
199
200
201
202
203
204
205
206
check 18
18
19
20
21
22
23
24
25
26
207
208
209
210
211
212
213
214
215
check 18
27
28
29
30
31
32
33
34
35
36
216
217
218
219
220
221
222
223
check 18
37
38
39
40
41
42
43
44
45
46
47
224
225
226
227
228
229
230
check 18
48
49
50
51
52
53
54
55
56
57
58
59
231
232
233
234
235
236
check 18
60
61
62
63
64
65
66
67
68
69
70
71
72
237
238
239
240
241
check 18
73
74
75
76
77
78
79
80
81
82
83
84
85
86
242
243
244
245
check 18
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
246
247
248
check 18
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
249
250
check 18
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
251
check 18
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
check 18
153
252
253
254
255
256
257
258
259
260
261
262
263
264
265
266
267
268
check 18
154
155
269
270
271
272
273
274
275
276
277
278
279
280
281
282
283
284
check 18
156
157
158
285
286
287
288
289
290
291
292
293
294
295
296
297
298
299
check 18
159
160
161
162
300
301
302
303
304
305
306
307
308
309
310
311
312
313
check 18
163
164
165
166
167
314
315
316
317
318
319
320
321
322
323
324
325
326
check 18
168
169
170
171
172
173
327
328
329
330
331
332
333
334
335
336
337
338
check 18
174
175
176
177
178
179
180
339
340
341
342
343
344
345
346
347
348
349
check 18
181
182
183
184
185
186
187
188
350
351
352
353
354
355
356
357
358
359
check 0
end_SG
begin_DTG
18
1
189
0
2
190
0
3
191
0
4
192
0
5
193
0
6
194
0
7
195
0
8
196
0
9
197
0
10
198
0
11
199
0
12
200
0
13
201
0
14
202
0
15
203
0
16
204
0
17
205
0
18
206
0
18
0
18
0
2
207
0
3
208
0
4
209
0
5
210
0
6
211
0
7
212
0
8
213
0
9
214
0
10
215
0
11
19
0
12
20
0
13
21
0
14
22
0
15
23
0
16
24
0
17
25
0
18
26
0
18
0
27
0
1
28
0
3
216
0
4
217
0
5
218
0
6
219
0
7
220
0
8
221
0
9
222
0
10
223
0
11
29
0
12
30
0
13
31
0
14
32
0
15
33
0
16
34
0
17
35
0
18
36
0
18
0
37
0
1
38
0
2
39
0
4
224
0
5
225
0
6
226
0
7
227
0
8
228
0
9
229
0
10
230
0
11
40
0
12
41
0
13
42
0
14
43
0
15
44
0
16
45
0
17
46
0
18
47
0
18
0
48
0
1
49
0
2
50
0
3
51
0
5
231
0
6
232
0
7
233
0
8
234
0
9
235
0
10
236
0
11
52
0
12
53
0
13
54
0
14
55
0
15
56
0
16
57
0
17
58
0
18
59
0
18
0
60
0
1
61
0
2
62
0
3
63
0
4
64
0
6
237
0
7
238
0
8
239
0
9
240
0
10
241
0
11
65
0
12
66
0
13
67
0
14
68
0
15
69
0
16
70
0
17
71
0
18
72
0
18
0
73
0
1
74
0
2
75
0
3
76
0
4
77
0
5
78
0
7
242
0
8
243
0
9
244
0
10
245
0
11
79
0
12
80
0
13
81
0
14
82
0
15
83
0
16
84
0
17
85
0
18
86
0
18
0
87
0
1
88
0
2
89
0
3
90
0
4
91
0
5
92
0
6
93
0
8
246
0
9
247
0
10
248
0
11
94
0
12
95
0
13
96
0
14
97
0
15
98
0
16
99
0
17
100
0
18
101
0
18
0
102
0
1
103
0
2
104
0
3
105
0
4
106
0
5
107
0
6
108
0
7
109
0
9
249
0
10
250
0
11
110
0
12
111
0
13
112
0
14
113
0
15
114
0
16
115
0
17
116
0
18
117
0
18
0
118
0
1
119
0
2
120
0
3
121
0
4
122
0
5
123
0
6
124
0
7
125
0
8
126
0
10
251
0
11
127
0
12
128
0
13
129
0
14
130
0
15
131
0
16
132
0
17
133
0
18
134
0
18
0
135
0
1
136
0
2
137
0
3
138
0
4
139
0
5
140
0
6
141
0
7
142
0
8
143
0
9
144
0
11
145
0
12
146
0
13
147
0
14
148
0
15
149
0
16
150
0
17
151
0
18
152
0
18
0
153
0
1
252
0
2
253
0
3
254
0
4
255
0
5
256
0
6
257
0
7
258
0
8
259
0
9
260
0
10
261
0
12
262
0
13
263
0
14
264
0
15
265
0
16
266
0
17
267
0
18
268
0
18
0
154
0
1
269
0
2
270
0
3
271
0
4
272
0
5
273
0
6
274
0
7
275
0
8
276
0
9
277
0
10
278
0
11
155
0
13
279
0
14
280
0
15
281
0
16
282
0
17
283
0
18
284
0
18
0
156
0
1
285
0
2
286
0
3
287
0
4
288
0
5
289
0
6
290
0
7
291
0
8
292
0
9
293
0
10
294
0
11
157
0
12
158
0
14
295
0
15
296
0
16
297
0
17
298
0
18
299
0
18
0
159
0
1
300
0
2
301
0
3
302
0
4
303
0
5
304
0
6
305
0
7
306
0
8
307
0
9
308
0
10
309
0
11
160
0
12
161
0
13
162
0
15
310
0
16
311
0
17
312
0
18
313
0
18
0
163
0
1
314
0
2
315
0
3
316
0
4
317
0
5
318
0
6
319
0
7
320
0
8
321
0
9
322
0
10
323
0
11
164
0
12
165
0
13
166
0
14
167
0
16
324
0
17
325
0
18
326
0
18
0
168
0
1
327
0
2
328
0
3
329
0
4
330
0
5
331
0
6
332
0
7
333
0
8
334
0
9
335
0
10
336
0
11
169
0
12
170
0
13
171
0
14
172
0
15
173
0
17
337
0
18
338
0
18
0
174
0
1
339
0
2
340
0
3
341
0
4
342
0
5
343
0
6
344
0
7
345
0
8
346
0
9
347
0
10
348
0
11
175
0
12
176
0
13
177
0
14
178
0
15
179
0
16
180
0
18
349
0
18
0
181
0
1
350
0
2
351
0
3
352
0
4
353
0
5
354
0
6
355
0
7
356
0
8
357
0
9
358
0
10
359
0
11
182
0
12
183
0
13
184
0
14
185
0
15
186
0
16
187
0
17
188
0
end_DTG
begin_DTG
1
2
16
1
0 14
1
0
7
1
0 10
0
end_DTG
begin_DTG
1
2
17
1
0 17
1
0
1
1
0 0
0
end_DTG
begin_DTG
1
2
14
1
0 9
1
0
8
1
0 14
0
end_DTG
begin_DTG
1
2
13
1
0 9
1
0
4
1
0 2
0
end_DTG
begin_DTG
1
2
12
1
0 9
1
0
6
1
0 7
0
end_DTG
begin_DTG
1
2
9
1
0 0
1
0
3
1
0 2
0
end_DTG
begin_DTG
1
2
11
1
0 2
1
0
0
1
0 0
0
end_DTG
begin_DTG
1
2
10
1
0 1
1
0
5
1
0 3
0
end_DTG
begin_DTG
1
2
15
1
0 13
1
0
2
1
0 1
0
end_DTG
begin_CG
9
9 2
8 2
7 2
6 2
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
0
0
0
0
end_CG
