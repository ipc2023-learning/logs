begin_version
3
end_version
begin_metric
0
end_metric
6
begin_variable
var5
-1
12
Atom lift-at(f1)
Atom lift-at(f10)
Atom lift-at(f11)
Atom lift-at(f12)
Atom lift-at(f2)
Atom lift-at(f3)
Atom lift-at(f4)
Atom lift-at(f5)
Atom lift-at(f6)
Atom lift-at(f7)
Atom lift-at(f8)
Atom lift-at(f9)
end_variable
begin_variable
var4
-1
3
Atom boarded(p5)
Atom origin(p5, f4)
Atom served(p5)
end_variable
begin_variable
var3
-1
3
Atom boarded(p4)
Atom origin(p4, f11)
Atom served(p4)
end_variable
begin_variable
var2
-1
3
Atom boarded(p3)
Atom origin(p3, f1)
Atom served(p3)
end_variable
begin_variable
var1
-1
3
Atom boarded(p2)
Atom origin(p2, f3)
Atom served(p2)
end_variable
begin_variable
var0
-1
3
Atom boarded(p1)
Atom origin(p1, f8)
Atom served(p1)
end_variable
0
begin_state
10
1
1
1
1
1
end_state
begin_goal
5
1 2
2 2
3 2
4 2
5 2
end_goal
142
begin_operator
board f1 p3
1
0 0
1
0 3 1 0
0
end_operator
begin_operator
board f11 p4
1
0 2
1
0 2 1 0
0
end_operator
begin_operator
board f3 p2
1
0 5
1
0 4 1 0
0
end_operator
begin_operator
board f4 p5
1
0 6
1
0 1 1 0
0
end_operator
begin_operator
board f8 p1
1
0 10
1
0 5 1 0
0
end_operator
begin_operator
depart f2 p1
1
0 4
1
0 5 0 2
0
end_operator
begin_operator
depart f2 p3
1
0 4
1
0 3 0 2
0
end_operator
begin_operator
depart f3 p5
1
0 5
1
0 1 0 2
0
end_operator
begin_operator
depart f4 p4
1
0 6
1
0 2 0 2
0
end_operator
begin_operator
depart f8 p2
1
0 10
1
0 4 0 2
0
end_operator
begin_operator
down f10 f1
0
1
0 0 1 0
0
end_operator
begin_operator
down f10 f2
0
1
0 0 1 4
0
end_operator
begin_operator
down f10 f3
0
1
0 0 1 5
0
end_operator
begin_operator
down f10 f4
0
1
0 0 1 6
0
end_operator
begin_operator
down f10 f5
0
1
0 0 1 7
0
end_operator
begin_operator
down f10 f6
0
1
0 0 1 8
0
end_operator
begin_operator
down f10 f7
0
1
0 0 1 9
0
end_operator
begin_operator
down f10 f8
0
1
0 0 1 10
0
end_operator
begin_operator
down f10 f9
0
1
0 0 1 11
0
end_operator
begin_operator
down f11 f1
0
1
0 0 2 0
0
end_operator
begin_operator
down f11 f10
0
1
0 0 2 1
0
end_operator
begin_operator
down f11 f2
0
1
0 0 2 4
0
end_operator
begin_operator
down f11 f3
0
1
0 0 2 5
0
end_operator
begin_operator
down f11 f4
0
1
0 0 2 6
0
end_operator
begin_operator
down f11 f5
0
1
0 0 2 7
0
end_operator
begin_operator
down f11 f6
0
1
0 0 2 8
0
end_operator
begin_operator
down f11 f7
0
1
0 0 2 9
0
end_operator
begin_operator
down f11 f8
0
1
0 0 2 10
0
end_operator
begin_operator
down f11 f9
0
1
0 0 2 11
0
end_operator
begin_operator
down f12 f1
0
1
0 0 3 0
0
end_operator
begin_operator
down f12 f10
0
1
0 0 3 1
0
end_operator
begin_operator
down f12 f11
0
1
0 0 3 2
0
end_operator
begin_operator
down f12 f2
0
1
0 0 3 4
0
end_operator
begin_operator
down f12 f3
0
1
0 0 3 5
0
end_operator
begin_operator
down f12 f4
0
1
0 0 3 6
0
end_operator
begin_operator
down f12 f5
0
1
0 0 3 7
0
end_operator
begin_operator
down f12 f6
0
1
0 0 3 8
0
end_operator
begin_operator
down f12 f7
0
1
0 0 3 9
0
end_operator
begin_operator
down f12 f8
0
1
0 0 3 10
0
end_operator
begin_operator
down f12 f9
0
1
0 0 3 11
0
end_operator
begin_operator
down f2 f1
0
1
0 0 4 0
0
end_operator
begin_operator
down f3 f1
0
1
0 0 5 0
0
end_operator
begin_operator
down f3 f2
0
1
0 0 5 4
0
end_operator
begin_operator
down f4 f1
0
1
0 0 6 0
0
end_operator
begin_operator
down f4 f2
0
1
0 0 6 4
0
end_operator
begin_operator
down f4 f3
0
1
0 0 6 5
0
end_operator
begin_operator
down f5 f1
0
1
0 0 7 0
0
end_operator
begin_operator
down f5 f2
0
1
0 0 7 4
0
end_operator
begin_operator
down f5 f3
0
1
0 0 7 5
0
end_operator
begin_operator
down f5 f4
0
1
0 0 7 6
0
end_operator
begin_operator
down f6 f1
0
1
0 0 8 0
0
end_operator
begin_operator
down f6 f2
0
1
0 0 8 4
0
end_operator
begin_operator
down f6 f3
0
1
0 0 8 5
0
end_operator
begin_operator
down f6 f4
0
1
0 0 8 6
0
end_operator
begin_operator
down f6 f5
0
1
0 0 8 7
0
end_operator
begin_operator
down f7 f1
0
1
0 0 9 0
0
end_operator
begin_operator
down f7 f2
0
1
0 0 9 4
0
end_operator
begin_operator
down f7 f3
0
1
0 0 9 5
0
end_operator
begin_operator
down f7 f4
0
1
0 0 9 6
0
end_operator
begin_operator
down f7 f5
0
1
0 0 9 7
0
end_operator
begin_operator
down f7 f6
0
1
0 0 9 8
0
end_operator
begin_operator
down f8 f1
0
1
0 0 10 0
0
end_operator
begin_operator
down f8 f2
0
1
0 0 10 4
0
end_operator
begin_operator
down f8 f3
0
1
0 0 10 5
0
end_operator
begin_operator
down f8 f4
0
1
0 0 10 6
0
end_operator
begin_operator
down f8 f5
0
1
0 0 10 7
0
end_operator
begin_operator
down f8 f6
0
1
0 0 10 8
0
end_operator
begin_operator
down f8 f7
0
1
0 0 10 9
0
end_operator
begin_operator
down f9 f1
0
1
0 0 11 0
0
end_operator
begin_operator
down f9 f2
0
1
0 0 11 4
0
end_operator
begin_operator
down f9 f3
0
1
0 0 11 5
0
end_operator
begin_operator
down f9 f4
0
1
0 0 11 6
0
end_operator
begin_operator
down f9 f5
0
1
0 0 11 7
0
end_operator
begin_operator
down f9 f6
0
1
0 0 11 8
0
end_operator
begin_operator
down f9 f7
0
1
0 0 11 9
0
end_operator
begin_operator
down f9 f8
0
1
0 0 11 10
0
end_operator
begin_operator
up f1 f10
0
1
0 0 0 1
0
end_operator
begin_operator
up f1 f11
0
1
0 0 0 2
0
end_operator
begin_operator
up f1 f12
0
1
0 0 0




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




erator
up f3 f7
0
1
0 0 5 9
0
end_operator
begin_operator
up f3 f8
0
1
0 0 5 10
0
end_operator
begin_operator
up f3 f9
0
1
0 0 5 11
0
end_operator
begin_operator
up f4 f10
0
1
0 0 6 1
0
end_operator
begin_operator
up f4 f11
0
1
0 0 6 2
0
end_operator
begin_operator
up f4 f12
0
1
0 0 6 3
0
end_operator
begin_operator
up f4 f5
0
1
0 0 6 7
0
end_operator
begin_operator
up f4 f6
0
1
0 0 6 8
0
end_operator
begin_operator
up f4 f7
0
1
0 0 6 9
0
end_operator
begin_operator
up f4 f8
0
1
0 0 6 10
0
end_operator
begin_operator
up f4 f9
0
1
0 0 6 11
0
end_operator
begin_operator
up f5 f10
0
1
0 0 7 1
0
end_operator
begin_operator
up f5 f11
0
1
0 0 7 2
0
end_operator
begin_operator
up f5 f12
0
1
0 0 7 3
0
end_operator
begin_operator
up f5 f6
0
1
0 0 7 8
0
end_operator
begin_operator
up f5 f7
0
1
0 0 7 9
0
end_operator
begin_operator
up f5 f8
0
1
0 0 7 10
0
end_operator
begin_operator
up f5 f9
0
1
0 0 7 11
0
end_operator
begin_operator
up f6 f10
0
1
0 0 8 1
0
end_operator
begin_operator
up f6 f11
0
1
0 0 8 2
0
end_operator
begin_operator
up f6 f12
0
1
0 0 8 3
0
end_operator
begin_operator
up f6 f7
0
1
0 0 8 9
0
end_operator
begin_operator
up f6 f8
0
1
0 0 8 10
0
end_operator
begin_operator
up f6 f9
0
1
0 0 8 11
0
end_operator
begin_operator
up f7 f10
0
1
0 0 9 1
0
end_operator
begin_operator
up f7 f11
0
1
0 0 9 2
0
end_operator
begin_operator
up f7 f12
0
1
0 0 9 3
0
end_operator
begin_operator
up f7 f8
0
1
0 0 9 10
0
end_operator
begin_operator
up f7 f9
0
1
0 0 9 11
0
end_operator
begin_operator
up f8 f10
0
1
0 0 10 1
0
end_operator
begin_operator
up f8 f11
0
1
0 0 10 2
0
end_operator
begin_operator
up f8 f12
0
1
0 0 10 3
0
end_operator
begin_operator
up f8 f9
0
1
0 0 10 11
0
end_operator
begin_operator
up f9 f10
0
1
0 0 11 1
0
end_operator
begin_operator
up f9 f11
0
1
0 0 11 2
0
end_operator
begin_operator
up f9 f12
0
1
0 0 11 3
0
end_operator
0
begin_SG
switch 5
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
5
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
4
check 0
check 0
check 0
switch 4
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
9
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
2
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 3
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 1
6
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 1
0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 2
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
8
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 1
1
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 1
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
7
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 0
check 0
check 0
check 0
check 0
check 0
check 1
3
check 0
check 0
check 0
check 0
check 0
check 0
check 0
switch 0
check 0
check 11
76
77
78
79
80
81
82
83
84
85
86
check 11
10
11
12
13
14
15
16
17
18
87
88
check 11
19
20
21
22
23
24
25
26
27
28
89
check 11
29
30
31
32
33
34
35
36
37
38
39
check 11
40
90
91
92
93
94
95
96
97
98
99
check 11
41
42
100
101
102
103
104
105
106
107
108
check 11
43
44
45
109
110
111
112
113
114
115
116
check 11
46
47
48
49
117
118
119
120
121
122
123
check 11
50
51
52
53
54
124
125
126
127
128
129
check 11
55
56
57
58
59
60
130
131
132
133
134
check 11
61
62
63
64
65
66
67
135
136
137
138
check 11
68
69
70
71
72
73
74
75
139
140
141
check 0
end_SG
begin_DTG
11
1
76
0
2
77
0
3
78
0
4
79
0
5
80
0
6
81
0
7
82
0
8
83
0
9
84
0
10
85
0
11
86
0
11
0
10
0
2
87
0
3
88
0
4
11
0
5
12
0
6
13
0
7
14
0
8
15
0
9
16
0
10
17
0
11
18
0
11
0
19
0
1
20
0
3
89
0
4
21
0
5
22
0
6
23
0
7
24
0
8
25
0
9
26
0
10
27
0
11
28
0
11
0
29
0
1
30
0
2
31
0
4
32
0
5
33
0
6
34
0
7
35
0
8
36
0
9
37
0
10
38
0
11
39
0
11
0
40
0
1
90
0
2
91
0
3
92
0
5
93
0
6
94
0
7
95
0
8
96
0
9
97
0
10
98
0
11
99
0
11
0
41
0
1
100
0
2
101
0
3
102
0
4
42
0
6
103
0
7
104
0
8
105
0
9
106
0
10
107
0
11
108
0
11
0
43
0
1
109
0
2
110
0
3
111
0
4
44
0
5
45
0
7
112
0
8
113
0
9
114
0
10
115
0
11
116
0
11
0
46
0
1
117
0
2
118
0
3
119
0
4
47
0
5
48
0
6
49
0
8
120
0
9
121
0
10
122
0
11
123
0
11
0
50
0
1
124
0
2
125
0
3
126
0
4
51
0
5
52
0
6
53
0
7
54
0
9
127
0
10
128
0
11
129
0
11
0
55
0
1
130
0
2
131
0
3
132
0
4
56
0
5
57
0
6
58
0
7
59
0
8
60
0
10
133
0
11
134
0
11
0
61
0
1
135
0
2
136
0
3
137
0
4
62
0
5
63
0
6
64
0
7
65
0
8
66
0
9
67
0
11
138
0
11
0
68
0
1
139
0
2
140
0
3
141
0
4
69
0
5
70
0
6
71
0
7
72
0
8
73
0
9
74
0
10
75
0
end_DTG
begin_DTG
1
2
7
1
0 5
1
0
3
1
0 6
0
end_DTG
begin_DTG
1
2
8
1
0 6
1
0
1
1
0 2
0
end_DTG
begin_DTG
1
2
6
1
0 4
1
0
0
1
0 0
0
end_DTG
begin_DTG
1
2
9
1
0 10
1
0
2
1
0 5
0
end_DTG
begin_DTG
1
2
5
1
0 4
1
0
4
1
0 10
0
end_DTG
begin_CG
5
5 2
4 2
3 2
2 2
1 2
0
0
0
0
0
end_CG
