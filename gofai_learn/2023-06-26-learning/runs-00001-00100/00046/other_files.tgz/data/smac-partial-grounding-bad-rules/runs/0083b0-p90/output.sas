begin_version
3
end_version
begin_metric
0
end_metric
55
begin_variable
var0
-1
2
Atom on-table(b4)
NegatedAtom on-table(b4)
end_variable
begin_variable
var1
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var2
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var3
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var5
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var7
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var8
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var10
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var11
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var12
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var18
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var13
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var16
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var17
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var14
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var15
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var20
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var19
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var21
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var22
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var23
-1
28
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b24, b22)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var25
-1
3
Atom on(b13, b7)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom on(b21, b23)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom on(b14, b18)
Atom on(b14, b24)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b8, b11)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b17, b16)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var30
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var39
-1
8
Atom on(b16, b13)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b21)
Atom on(b16, b24)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var40
-1
10
Atom on(b20, b13)
Atom on(b20, b14)
Atom on(b20, b16)
Atom on(b20, b18)
Atom on(b20, b21)
Atom on(b20, b22)
Atom on(b20, b4)
Atom on(b20, b6)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var31
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var32
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var33
-1
19
Atom on(b19, b1)
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b12)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b20)
Atom on(b19, b22)
Atom on(b19, b23)
Atom on(b19, b26)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b8)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var35
-1
19
Atom on(b27, b1)
Atom on(b27, b10)
Atom on(b27, b12)
Atom on(b27, b15)
Atom on(b27, b16)
Atom on(b27, b19)
Atom on(b27, b2)
Atom on(b27, b20)
Atom on(b27, b22)
Atom on(b27, b23)
Atom on(b27, b26)
Atom on(b27, b3)
Atom on(b27, b4)
Atom on(b27, b5)
Atom on(b27, b6)
Atom on(b27, b8)
Atom on(b27, b9)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var37
-1
19
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b14)
Atom on(b10, b16)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b22)
Atom on(b10, b25)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var41
-1
19
Atom on(b26, b1)
Atom on(b26, b10)
Atom on(b26, b11)
Atom on(b26, b12)
Atom on(b26, b14)
Atom on(b26, b15)
Atom on(b26, b16)
Atom on(b26, b19)
Atom on(b26, b2)
Atom on(b26, b20)
Atom on(b26, b22)
Atom on(b26, b23)
Atom on(b26, b25)
Atom on(b26, b27)
Atom on(b26, b5)
Atom on(b26, b6)
Atom on(b26, b9)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var43
-1
19
Atom on(b9, b1)
Atom on(b9, b11)
Atom on(b9, b14)
Atom on(b9, b15)
Atom on(b9, b16)
Atom on(b9, b19)
Atom on(b9, b2)
Atom on(b9, b20)
Atom on(b9, b22)
Atom on(b9, b25)
Atom on(b9, b26)
Atom on(b9, b27)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var34
-1
20
Atom on(b2, b1)
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b23)
Atom on(b2, b24)
Atom on(b2, b25)
Atom on(b2, b26)
Atom on(b2, b27)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var38
-1
20
Atom on(b15, b11)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b22)
Atom on(b15, b23)
Atom on(b15, b25)
Atom on(b15, b26)
Atom on(b15, b27)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var48
-1
20
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b14)
Atom on(b6, b15)
Atom on(b6, b16)
Atom on(b6, b19)
Atom on(b6, b20)
Atom on(b6, b22)
Atom on(b6, b23)
Atom on(b6, b25)
Atom on(b6, b26)
Atom on(b6, b27)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var49
-1
20
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b14)
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b19)
Atom on(b7, b2)
Atom on(b7, b20)
Atom on(b7, b22)
Atom on(b7, b23)
Atom on(b7, b25)
Atom on(b7, b26)
Atom on(b7, b27)
Atom on(b7, b3)
Atom on(b7, b5)
Atom on(b7, b9)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var36
-1
20
Atom on(b1, b10)
Atom on(b1, b12)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b27)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b9)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var42
-1
21
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b14)
Atom on(b5, b15)
Atom on(b5, b16)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b22)
Atom on(b5, b23)
Atom on(b5, b25)
Atom on(b5, b26)
Atom on(b5, b27)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var45
-1
22
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b22)
Atom on(b12, b25)
Atom on(b12, b26)
Atom on(b12, b27)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var46
-1
21
Atom on(b23, b1)
Atom on(b23, b10)
Atom on(b23, b14)
Atom on(b23, b15)
Atom on(b23, b16)
Atom on(b23, b19)
Atom on(b23, b2)
Atom on(b23, b20)
Atom on(b23, b22)
Atom on(b23, b25)
Atom on(b23, b26)
Atom on(b23, b27)
Atom on(b23, b3)
Atom on(b23, b4)
Atom on(b23, b5)
Atom on(b23, b6)
Atom on(b23, b7)
Atom on(b23, b8)
Atom on(b23, b9)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var47
-1
22
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b19)
Atom on(b3, b2)
Atom on(b3, b20)
Atom on(b3, b22)
Atom on(b3, b23)
Atom on(b3, b25)
Atom on(b3, b26)
Atom on(b3, b27)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var44
-1
22
Atom on(b22, b11)
Atom on(b22, b12)
Atom on(b22, b13)
Atom on(b22, b14)
Atom on(b22, b15)
Atom on(b22, b16)
Atom on(b22, b18)
Atom on(b22, b19)
Atom on(b22, b20)
Atom on(b22, b21)
Atom on(b22, b23)
Atom on(b22, b24)
Atom on(b22, b25)
Atom on(b22, b26)
Atom on(b22, b27)
Atom on(b22, b3)
Atom on(b22, b4)
Atom on(b22, b5)
Atom on(b22, b7)
Atom on(b22, b9)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var50
-1
23
Atom on(b25, b1)
Atom on(b25, b10)
Atom on(b25, b11)
Atom on(b25, b12)
Atom on(b25, b13)
Atom on(b25, b14)
Atom on(b25, b15)
Atom on(b25, b16)
Atom on(b25, b19)
Atom on(b25, b2)
Atom on(b25, b20)
Atom on(b25, b22)
Atom on(b25, b23)
Atom on(b25, b26)
Atom on(b25, b27)
Atom on(b25, b3)
Atom on(b25, b4)
Atom on(b25, b5)
Atom on(b25, b6)
Atom on(b25, b8)
Atom on(b25, b9)
Atom on-table(b25)
<none of those>
end_variable
begin_variable
var51
-1
27
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b26)
Atom on(b11, b27)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var52
-1
4
Atom clear(b25)
Atom on(b18, b25)
Atom on(b4, b25)
<none of those>
end_variable
begin_variable
var53
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var54
-1
2
Atom on-table(b18)
NegatedAtom on-table(b18)
end_variable
4990
begin_mutex_group
28
23 0
23 1
23 2
23 3
23 4
23 5
23 6
23 7
23 8
23 9
23 10
23 11
23 12
23 13
23 14
23 15
23 16
23 17
23 18
23 19
23 20
23 21
23 22
23 23
23 24
23 25
23 26
51 0
end_mutex_group
begin_mutex_group
14
23 1
9 0
51 1
46 0
35 0
40 0
47 0
50 0
38 0
36 0
48 0
45 0
43 0
39 0
end_mutex_group
begin_mutex_group
15
23 2
8 0
51 2
44 0
46 1
35 1
40 1
47 1
50 1
38 1
36 1
48 1
45 1
42 0
43 1
end_mutex_group
begin_mutex_group
16
22 0
51 0
37 0
46 2
41 0
35 2
40 2
49 0
50 2
38 2
48 2
45 2
42 1
43 2
28 0
39 1
end_mutex_group
begin_mutex_group
14
23 3
11 0
51 3
44 1
37 1
35 3
49 1
50 3
38 3
36 2
48 3
45 3
42 2
43 3
end_mutex_group
begin_mutex_group
7
23 4
34 0
51 4
31 0
32 0
49 2
50 4
end_mutex_group
begin_mutex_group
17
23 5
4 0
44 2
37 2
46 3
41 1
35 4
40 3
32 1
49 3
47 2
50 5
38 4
45 4
42 3
43 4
39 2
end_mutex_group
begin_mutex_group
17
23 6
20 0
51 5
44 3
46 4
35 5
40 4
49 4
47 3
50 6
38 5
36 3
48 4
45 5
42 4
43 5
39 3
end_mutex_group
begin_mutex_group
21
23 7
7 0
51 6
44 4
37 3
46 5
41 2
29 0
35 6
40 5
32 2
49 5
47 4
50 7
38 6
36 4
48 5
45 6
42 5
43 6
39 4
end_mutex_group
begin_mutex_group
3
23 8
30 0
51 7
end_mutex_group
begin_mutex_group
7
23 9
2 0
51 8
27 0
31 1
32 3
49 6
end_mutex_group
begin_mutex_group
18
23 10
15 0
51 9
44 5
37 4
46 6
41 3
31 2
40 6
49 7
47 5
50 8
38 7
36 5
48 6
42 6
43 7
39 5
end_mutex_group
begin_mutex_group
15
23 11
10 0
51 10
44 6
37 5
46 7
41 4
47 6
50 9
38 8
36 6
48 7
45 7
43 8
39 6
end_mutex_group
begin_mutex_group
19
23 12
6 0
51 11
44 7
37 6
46 8
41 5
35 7
40 7
49 8
47 7
50 10
38 9
36 7
48 8
45 8
42 7
43 9
39 7
end_mutex_group
begin_mutex_group
7
23 13
33 0
51 12
44 8
31 3
32 4
49 9
end_mutex_group
begin_mutex_group
19
23 14
53 0
51 13
44 9
37 7
46 9
41 6
35 8
32 5
47 8
24 0
50 11
38 10
36 8
48 9
45 9
42 8
43 10
39 8
end_mutex_group
begin_mutex_group
15
23 15
16 0
51 14
41 7
35 9
40 8
26 0
49 10
50 12
38 11
36 9
48 10
45 10
42 9
43 11
end_mutex_group
begin_mutex_group
7
23 16
1 0
51 15
27 1
31 4
40 9
49 11
end_mutex_group
begin_mutex_group
18
23 17
52 0
52 1
52 2
51 16
44 10
37 8
46 10
41 8
40 10
49 12
47 9
38 12
48 11
45 11
42 10
43 12
39 9
end_mutex_group
begin_mutex_group
18
23 18
19 0
51 17
44 11
37 9
46 11
41 9
35 10
40 11
49 13
47 10
50 13
36 10
48 12
45 12
42 11
43 13
39 10
end_mutex_group
begin_mutex_group
17
23 19
12 0
51 18
44 12
37 10
46 12
41 10
40 12
49 14
47 11
50 14
38 13
48 13
45 13
42 12
43 14
39 11
end_mutex_group
begin_mutex_group
16
23 20
21 0
51 19
44 13
37 11
46 13
41 11
40 13
49 15
47 12
50 15
36 11
45 14
42 13
43 15
39 12
end_mutex_group
begin_mutex_group
18
23 21
5 0
51 20
44 14
37 12
46 14
41 12
35 11
40 14
32 6
49 16
47 13
50 16
36 12
48 14
45 15
42 14
39 13
end_mutex_group
begin_mutex_group
15
23 22
17 0
51 21
46 15
41 13
35 12
49 17
47 14
50 17
38 14
36 13
48 15
42 15
43 16
39 14
end_mutex_group
begin_mutex_group
17
23 23
18 0
51 22
44 15
37 13
46 16
41 14
35 13
40 15
32 7
47 15
50 18
38 15
36 14
48 16
45 16
39 15
end_mutex_group
begin_mutex_group
16
23 24
13 0
51 23
44 16
37 14
46 17
25 0
41 15
35 14
40 16
49 18
47 16
48 17
45 17
42 16
39 16
end_mutex_group
begin_mutex_group
13
23 25
3 0
51 24
37 15
46 18
41 16
35 15
40 17
47 17
50 19
36 15
48 18
42 17
end_mutex_group
begin_mutex_group
17
23 26
14 0
51 25
44 17
37 16
46 19
41 17
31 5
35 16
49 19
47 18
50 20
38 16
36 16
48 19
45 18
43 17
end_mutex_group
begin_mutex_group
20
23 1
44 0
44 1
44 2
44 3
44 4
44 5
44 6
44 7
44 8
44 9
44 10
44 11
44 12
44 13
44 14
44 15
44 16
44 17
44 18
end_mutex_group
begin_mutex_group
19
23 2
37 0
37 1
37 2
37 3
37 4
37 5
37 6
37 7
37 8
37 9
37 10
37 11
37 12
37 13
37 14
37 15
37 16
37 17
end_mutex_group
begin_mutex_group
22
23 3
46 0
46 1
46 2
46 3
46 4
46 5
46 6
46 7
46 8
46 9
46 10
46 11
46 12
46 13
46 14
46 15
46 16
46 17
46 18
46 19
46 20
end_mutex_group
begin_mutex_group
3
23 4
25 0
25 1
end_mutex_group
begin_mutex_group
4
23 5
27 0
27 1
27 2
end_mutex_group
begin_mutex_group
20
23 6
41 0
41 1
41 2
41 3
41 4
41 5
41 6
41 7
41 8
41 9
41 10
41 11
41 12
41 13
41 14
41 15
41 16
41 17
41 18
end_mutex_group
begin_mutex_group
8
23 7
31 0
31 1
31 2
31 3
31 4
31 5
31 6
end_mutex_group
begin_mutex_group
3
23 8
29 0
29 1
end_mutex_group
begin_mutex_group
3
23 9
52 1
54 0
end_mutex_group
begin_mutex_group
19
23 10
35 0
35 1
35 2
35 3
35 4
35 5
35 6
35 7
35 8
35 9
35 10
35 11
35 12
35 13
35 14
35 15
35 16
35 17
end_mutex_group
begin_mutex_group
20
23 11
40 0
40 1
40 2
40 3
40 4
40 5
40 6
40 7
40 8
40 9
40 10
40 11
40 12
40 13
40 14
40 15
40 16
40 17
40 18
end_mutex_group
begin_mutex_group
10
23 12
32 0
32 1
32 2
32 3
32 4
32 5
32 6
32 7
32 8
end_mutex_group
begin_mutex_group
3
23 13
26 0
26 1
end_mutex_group
begin_mutex_group
22
23 14
49 0
49 1
49 2
49 3
49 4
49 5
49 6
49 7
49 8
49 9
49 10
49 11
49 12
49 13
49 14
49 15
49 16
49 17
49 18
49 19
49 20
end_mutex_group
begin_mutex_group
21
23 15
47 0
47 1
47 2
47 3
47 4
47 5
47 6
47 7
47 8
47 9
47 10
47 11
47 12
47 13
47 14
47 15
47 16
47 17
47 18
47 19
end_mutex_group
begin_mutex_group
3
23 16
24 0
24 1
end_mutex_group
begin_mutex_group
23
23 17
50 0
50 1
50 2
50 3
50 4
50 5
50 6
50 7
50 8
50 9
50 10
50 11
50 12
50 13
50 14
50 15
50 16
50 17
50 18
50 19
50 20
50 21
end_mutex_group
begin_mutex_group
19
23 18
38 0
38 1
38 2
38 3
38 4
38 5
38 6
38 7
38 8
38 9
38 10
38 11
38 12
38 13
38 14
38 15
38 16
38 17
end_mutex_group
begin_mutex_group
19
23 19
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
36 15
36 16
36 17
end_mutex_group
begin_mutex_group
22
23 20
48 0
48 1
48 2
48 3
48 4
48 5
48 6
48 7
48 8
48 9
48 10
48 11
48 12
48 13
48 14
48 15
48 16
48 17
48 18
48 19
48 20
end_mutex_group
begin_mutex_group
3
23 21
52 2
0 0
end_mutex_group
begin_mutex_group
21
23 22
45 0
45 1
45 2
45 3
45 4
45 5
45 6
45 7
45 8
45 9
45 10
45 11
45 12
45 13
45 14
45 15
45 16
45 17
45 18
45 19
end_mutex_group
begin_mutex_group
20
23 23
42 0
42 1
42 2
42 3
42 4
42 5
42 6
42 7
42 8
42 9
42 10
42 11
42 12
42 13
42 14
42 15
42 16
42 17
42 18
end_mutex_group
begin_mutex_group
20
23 24
43 0
43 1
43 2
43 3
43 4
43 5
43 6
43 7
43 8
43 9
43 10
43 11
43 12
43 13
43 14
43 15
43 16
43 17
43 18
end_mutex_group
begin_mutex_group
3
23 25
28 0
28 1
end_mutex_group
begin_mutex_group
19
23 26
39 0
39 1
39 2
39 3
39 4
39 5
39 6
39 7
39 8
39 9
39 10
39 11
39 12
39 13
39 14
39 15
39 16
39 17
end_mutex_group
begin_mutex_group
2
1 0
24 2
end_mutex_group
begin_mutex_group
2
3 0
23 4
end_mutex_group
begin_mutex_group
2
3 0
23 9
end_mutex_group
begin_mutex_group
2
3 0
25 0
end_mutex_group
begin_mutex_group
2
3 0
25 2
end_mutex_group
begin_mutex_group
2
3 0
27 0
end_mutex_group
begin_mutex_group
2
3 0
28 2
end_mutex_group
begin_mutex_group
2
3 0
52 1
end_mutex_group
begin_mutex_group
2
4 0
27 3
end_mutex_group
begin_mutex_group
2
6 0
32 9
end_mutex_group
begin_mutex_group
2
7 0
31 7
end_mutex_group
begin_mutex_group
2
9 0
23 16
end_mutex_group
begin_mutex_group
2
9 0
24 0
end_mutex_group
begin_mutex_group
2
9 0
24 2
end_mutex_group
begin_mutex_group
2
9 0
44 19
end_mutex_group
begin_mutex_group
2
8 0
37 18
end_mutex_group
begin_mutex_group
2
10 0
40 19
end_mutex_group
begin_mutex_group
2
11 0
23 13
end_mutex_group
begin_mutex_group
2
11 0
23 16
end_mutex_group
begin_mutex_group
2
11 0
24 0
end_mutex_group
begin_mutex_group
2
11 0
24 2
end_mutex_group
begin_mutex_group
2
11 0
26 0
end_mutex_group
begin_mutex_group
2
11 0
26 2
end_mutex_group
begin_mutex_group
2
11 0
46 21
end_mutex_group
begin_mutex_group
2
12 0
23 13
end_mutex_group
begin_mutex_group
2
12 0
23 16
end_mutex_group
begin_mutex_group
2
12 0
24 0
end_mutex_group
begin_mutex_group
2
12 0
24 2
end_mutex_group
begin_mutex_group
2
12 0
26 0
end_mutex_group
begin_mutex_group
2
12 0
26 2
end_mutex_group
begin_mutex_group
2
12 0
36 18
end_mutex_group
begin_mutex_group
2
14 0
39 18
end_mutex_group
begin_mutex_group
2
17 0
45 20
end_mutex_group
begin_mutex_group
2
18 0
23 4
end_mutex_group
begin_mutex_group
2
18 0
23 9
end_mutex_group
begin_mutex_group
2
18 0
25 0
end_mutex_group
begin_mutex_group
2
18 0
25 2
end_mutex_group
begin_mutex_group
2
18 0
27 0
end_mutex_group
begin_mutex_group
2
18 0
42 19
end_mutex_group
begin_mutex_group
2
18 0
52 1
end_mutex_group
begin_mutex_group
2
15 0
35 18
end_mutex_group
begin_mutex_group
2
16 0
23 16
end_mutex_group
begin_mutex_group
2
16 0
24 0
end_mutex_group
begin_mutex_group
2
16 0
24 2
end_mutex_group
begin_mutex_group
2
16 0
47 20
end_mutex_group
begin_mutex_group
2
16 1
23 13
end_mutex_group
begin_mutex_group
2
16 1
26 2
end_mutex_group
begin_mutex_group
2
13 0
23 9
end_mutex_group
begin_mutex_group
2
13 0
27 0
end_mutex_group
begin_mutex_group
2
13 0
43 19
end_mutex_group
begin_mutex_group
2
13 0
52 1
end_mutex_group
begin_mutex_group
2
13 1
23 4
end_mutex_group
begin_mutex_group
2
13 1
25 2
end_mutex_group
begin_mutex_group
2
20 0
41 19
end_mutex_group
begin_mutex_group
2
19 0
23 4
end_mutex_group
begin_mutex_group
2
19 0
23 9
end_mutex_group
begin_mutex_group
2
19 0
25 0
end_mutex_group
begin_mutex_group
2
19 0
25 2
end_mutex_group
begin_mutex_group
2
19 0
27 0
end_mutex_group
begin_mutex_group
2
19 0
38 18
end_mutex_group
begin_mutex_group
2
19 0
52 1
end_mutex_group
begin_mutex_group
2
21 0
23 16
end_mutex_group
begin_mutex_group
2
21 0
24 0
end_mutex_group
begin_mutex_group
2
21 0
24 2
end_mutex_group
begin_mutex_group
2
21 0
48 21
end_mutex_group
begin_mutex_group
2
22 0
23 13
end_mutex_group
begin_mutex_group
2
22 0
23 16
end_mutex_group
begin_mutex_group
2
22 0
23 27
end_mutex_group
begin_mutex_group
2
22 0
24 0
end_mutex_group
begin_mutex_group
2
22 0
24 2
end_mutex_group
begin_mutex_group
2
22 0
26 0
end_mutex_group
begin_mutex_group
2
22 0
26 2
end_mutex_group
begin_mutex_group
2
23 0
24 2
end_mutex_group
begin_mutex_group
2
23 0
25 2
end_mutex_group
begin_mutex_group
2
23 0
26 2
end_mutex_group
begin_mutex_group
2
23 0
27 3
end_mutex_group
begin_mutex_group
2
23 0
28 2
end_mutex_group
begin_mutex_group
2
23 0
29 2
end_mutex_group
begin_mutex_group
2
23 0
35 18
end_mutex_group
begin_mutex_group
2
23 0
40 19
end_mutex_group
begin_mutex_group
2
23 0
36 18
end_mutex_group
begin_mutex_group
2
23 0
44 19
end_mutex_group
begin_mutex_group
2
23 0
37 18
end_mutex_group
begin_mutex_group
2
23 0
41 19
end_mutex_group
begin_mutex_group
2
23 0
31 7
end_mutex_group
begin_mutex_group
2
23 0
32 9
end_mutex_group
begin_mutex_group
2
23 0
38 18
end_mutex_group
begin_mutex_group
2
23 0
45 20
end_mutex_group
begin_mutex_group
2
23 0
39 18
end_mutex_group
begin_mutex_group
2
23 0
49 21
end_mutex_group
begin_mutex_group
2
23 0
46 21
end_mutex_group
begin_mutex_group
2
23 0
47 20
end_mutex_group
begin_mutex_group
2
23 0
48 21
end_mutex_group
begin_mutex_group
2
23 0
42 19
end_mutex_group
begin_mutex_group
2
23 0
43 19
end_mutex_group
begin_mutex_group
2
23 0
50 22
end_mutex_group
begin_mutex_group
2
23 1
24 0
end_mutex_group
begin_mutex_group
2
23 1
24 2
end_mutex_group
begin_mutex_group
2
23 1
25 2
end_mutex_group
begin_mutex_group
2
23 1
26 2
end_mutex_group
begin_mutex_group
2
23 1
27 3
end_mutex_group
begin_mutex_group
2
23 1
28 2
end_mutex_group
begin_mutex_group
2
23 1
29 2
end_mutex_group
begin_mutex_group
2
23 1
35 18
end_mutex_group
begin_mutex_group
2
23 1
40 19
end_mutex_group
begin_mutex_group
2
23 1
36 18
end_mutex_group
begin_mutex_group
2
23 1
37 18
end_mutex_group
begin_mutex_group
2
23 1
41 19
end_mutex_group
begin_mutex_group
2
23 1
31 7
end_mutex_group
begin_mutex_group
2
23 1
32 9
end_mutex_group
begin_mutex_group
2
23 1
38 18
end_mutex_group
begin_mutex_group
2
23 1
45 20
end_mutex_group
begin_mutex_group
2
23 1
39 18
end_mutex_group
begin_mutex_group
2
23 1
49 21
end_mutex_group
begin_mutex_group
2
23 1
46 21
end_mutex_group
begin_mutex_group
2
23 1
47 20
end_mutex_group
begin_mutex_group
2
23 1
48 21
end_mutex_group
begin_mutex_group
2
23 1
42 19
end_mutex_group
begin_mutex_group
2
23 1
43 19
end_mutex_group
begin_mutex_group
2
23 1
50 22
end_mutex_group
begin_mutex_group
2
23 2
24 2
end_mutex_group
begin_mutex_group
2
23 2
25 2
end_mutex_group
begin_mutex_group
2
23 2
26 2
end_mutex_group
begin_mutex_group
2
23 2
27 3
end_mutex_group
begin_mutex_group
2
23 2
28 2
end_mutex_group
begin_mutex_group
2
23 2
29 2
end_mutex_group
begin_mutex_group
2
23 2
35 18
end_mutex_group
begin_mutex_group
2
23 2
40 19
end_mutex_group
begin_mutex_group
2
23 2
36 18
end_mutex_group
begin_mutex_group
2
23 2
44 19
end_mutex_group
begin_mutex_group
2
23 2
41 19
end_mutex_group
begin_mutex_group
2
23 2
31 7
end_mutex_group
begin_mutex_group
2
23 2
32 9
end_mutex_group
begin_mutex_group
2
23 2
38 18
end_mutex_group
begin_mutex_group
2
23 2
45 20
end_mutex_group
begin_mutex_group
2
23 2
39 18
end_mutex_group
begin_mutex_group
2
23 2
49 21
end_mutex_group
begin_mutex_group
2
23 2
46 21
end_mutex_group
begin_mutex_group
2
23 2
47 20
end_mutex_group
begin_mutex_group
2
23 2
48 21
end_mutex_group
begin_mutex_group
2
23 2
42 19
end_mutex_group
begin_mutex_group
2
23 2
43 19
end_mutex_group
begin_mutex_group
2
23 2
50 22
end_mutex_group
begin_mutex_group
2
23 3
24 0
end_mutex_group
begin_mutex_group
2
23 3
24 2
end_mutex_group
begin_mutex_group
2
23 3
25 2
end_mutex_group
begin_mutex_group
2
23 3
26 0
end_mutex_group
begin_mutex_group
2
23 3
26 2
end_mutex_group
begin_mutex_group
2
23 3
27 3
end_mutex_group
begin_mutex_group
2
23 3
28 2
end_mutex_group
begin_mutex_group
2
23 3
29 2
end_mutex_group
begin_mutex_group
2
23 3
35 18
end_mutex_group
begin_mutex_group
2
23 3
40 19
end_mutex_group
begin_mutex_group
2
23 3
36 18
end_mutex_group
begin_mutex_group
2
23 3
44 19
end_mutex_group
begin_mutex_group
2
23 3
37 18
end_mutex_group
begin_mutex_group
2
23 3
41 19
end_mutex_group
begin_mutex_group
2
23 3
31 7
end_mutex_group
begin_mutex_group
2
23 3
32 9
end_mutex_group
begin_mutex_group
2
23 3
38 18
end_mutex_group
begin_mutex_group
2
23 3
45 20
end_mutex_group
begin_mutex_group
2
23 3
39 18
end_mutex_group
begin_mutex_group
2
23 3
49 21
end_mutex_group
begin_mutex_group
2
23 3
47 20
end_mutex_group
begin_mutex_group
2
23 3
48 21
end_mutex_group
begin_mutex_group
2
23 3
42 19
end_mutex_group
begin_mutex_group
2
23 3
43 19
end_mutex_group
begin_mutex_group
2
23 3
50 22
end_mutex_group
begin_mutex_group
2
23 4
24 2
end_mutex_group
begin_mutex_group
2
23 4
26 2
end_mutex_group
begin_mutex_group
2
23 4
27 0
end_mutex_group
begin_mutex_group
2
23 4
27 3
end_mutex_group
begin_mutex_group
2
23 4
28 0
end_mutex_group
begin_mutex_group
2
23 4
28 2
end_mutex_group
begin_mutex_group
2
23 4
29 2
end_mutex_group
begin_mutex_group
2
23 4
35 10
end_mutex_group
begin_mutex_group
2
23 4
35 13
end_mutex_group
begin_mutex_group
2
23 4
35 14
end_mutex_group
begin_mutex_group
2
23 4
35 15
end_mutex_group
begin_mutex_group
2
23 4
35 18
end_mutex_group
begin_mutex_group
2
23 4
40 11
end_mutex_group
begin_mutex_group
2
23 4
40 15
end_mutex_group
begin_mutex_group
2
23 4
40 16
end_mutex_group
begin_mutex_group
2
23 4
40 17
end_mutex_group
begin_mutex_group
2
23 4
40 19
end_mutex_group
begin_mutex_group
2
23 4
36 10
end_mutex_group
begin_mutex_group
2
23 4
36 14
end_mutex_group
begin_mutex_group
2
23 4
36 15




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




r
unstack b11 b22
0
4
0 23 0 27
0 22 0 1
0 53 -1 0
0 51 13 0
1
end_operator
begin_operator
unstack b11 b23
0
4
0 23 0 27
0 22 0 1
0 16 -1 0
0 51 14 0
1
end_operator
begin_operator
unstack b11 b24
0
4
0 23 0 27
0 22 0 1
0 1 -1 0
0 51 15 0
1
end_operator
begin_operator
unstack b11 b25
0
4
0 23 0 27
0 22 0 1
0 52 -1 0
0 51 16 0
1
end_operator
begin_operator
unstack b11 b26
0
4
0 23 0 27
0 22 0 1
0 19 -1 0
0 51 17 0
1
end_operator
begin_operator
unstack b11 b27
0
4
0 23 0 27
0 22 0 1
0 12 -1 0
0 51 18 0
1
end_operator
begin_operator
unstack b11 b3
0
4
0 23 0 27
0 22 0 1
0 21 -1 0
0 51 19 0
1
end_operator
begin_operator
unstack b11 b4
0
4
0 23 0 27
0 22 0 1
0 5 -1 0
0 51 20 0
1
end_operator
begin_operator
unstack b11 b5
0
4
0 23 0 27
0 22 0 1
0 17 -1 0
0 51 21 0
1
end_operator
begin_operator
unstack b11 b6
0
4
0 23 0 27
0 22 0 1
0 18 -1 0
0 51 22 0
1
end_operator
begin_operator
unstack b11 b7
0
4
0 23 0 27
0 22 0 1
0 13 -1 0
0 51 23 0
1
end_operator
begin_operator
unstack b11 b8
0
4
0 23 0 27
0 22 0 1
0 3 -1 0
0 51 24 0
1
end_operator
begin_operator
unstack b11 b9
0
4
0 23 0 27
0 22 0 1
0 14 -1 0
0 51 25 0
1
end_operator
begin_operator
unstack b12 b1
0
4
0 23 0 3
0 9 -1 0
0 11 0 1
0 46 0 21
1
end_operator
begin_operator
unstack b12 b10
0
4
0 23 0 3
0 8 -1 0
0 11 0 1
0 46 1 21
1
end_operator
begin_operator
unstack b12 b11
0
4
0 23 0 3
0 22 -1 0
0 11 0 1
0 46 2 21
1
end_operator
begin_operator
unstack b12 b14
0
4
0 23 0 3
0 11 0 1
0 4 -1 0
0 46 3 21
1
end_operator
begin_operator
unstack b12 b15
0
4
0 23 0 3
0 11 0 1
0 20 -1 0
0 46 4 21
1
end_operator
begin_operator
unstack b12 b16
0
4
0 23 0 3
0 11 0 1
0 7 -1 0
0 46 5 21
1
end_operator
begin_operator
unstack b12 b19
0
4
0 23 0 3
0 11 0 1
0 15 -1 0
0 46 6 21
1
end_operator
begin_operator
unstack b12 b2
0
4
0 23 0 3
0 11 0 1
0 10 -1 0
0 46 7 21
1
end_operator
begin_operator
unstack b12 b20
0
4
0 23 0 3
0 11 0 1
0 6 -1 0
0 46 8 21
1
end_operator
begin_operator
unstack b12 b22
0
4
0 23 0 3
0 11 0 1
0 53 -1 0
0 46 9 21
1
end_operator
begin_operator
unstack b12 b25
0
4
0 23 0 3
0 11 0 1
0 52 -1 0
0 46 10 21
1
end_operator
begin_operator
unstack b12 b26
0
4
0 23 0 3
0 11 0 1
0 19 -1 0
0 46 11 21
1
end_operator
begin_operator
unstack b12 b27
0
4
0 23 0 3
0 11 0 1
0 12 -1 0
0 46 12 21
1
end_operator
begin_operator
unstack b12 b3
0
4
0 23 0 3
0 11 0 1
0 21 -1 0
0 46 13 21
1
end_operator
begin_operator
unstack b12 b4
0
4
0 23 0 3
0 11 0 1
0 5 -1 0
0 46 14 21
1
end_operator
begin_operator
unstack b12 b5
0
4
0 23 0 3
0 11 0 1
0 17 -1 0
0 46 15 21
1
end_operator
begin_operator
unstack b12 b6
0
4
0 23 0 3
0 11 0 1
0 18 -1 0
0 46 16 21
1
end_operator
begin_operator
unstack b12 b7
0
4
0 23 0 3
0 11 0 1
0 13 -1 0
0 46 17 21
1
end_operator
begin_operator
unstack b12 b8
0
4
0 23 0 3
0 11 0 1
0 3 -1 0
0 46 18 21
1
end_operator
begin_operator
unstack b12 b9
0
4
0 23 0 3
0 11 0 1
0 14 -1 0
0 46 19 21
1
end_operator
begin_operator
unstack b13 b7
0
4
0 23 0 4
0 34 0 1
0 13 -1 0
0 25 0 2
1
end_operator
begin_operator
unstack b14 b18
0
4
0 23 0 5
0 4 0 1
0 2 -1 0
0 27 0 3
1
end_operator
begin_operator
unstack b15 b11
0
4
0 23 0 6
0 22 -1 0
0 20 0 1
0 41 0 19
1
end_operator
begin_operator
unstack b15 b14
0
4
0 23 0 6
0 4 -1 0
0 20 0 1
0 41 1 19
1
end_operator
begin_operator
unstack b15 b16
0
4
0 23 0 6
0 20 0 1
0 7 -1 0
0 41 2 19
1
end_operator
begin_operator
unstack b15 b19
0
4
0 23 0 6
0 20 0 1
0 15 -1 0
0 41 3 19
1
end_operator
begin_operator
unstack b15 b2
0
4
0 23 0 6
0 20 0 1
0 10 -1 0
0 41 4 19
1
end_operator
begin_operator
unstack b15 b20
0
4
0 23 0 6
0 20 0 1
0 6 -1 0
0 41 5 19
1
end_operator
begin_operator
unstack b15 b22
0
4
0 23 0 6
0 20 0 1
0 53 -1 0
0 41 6 19
1
end_operator
begin_operator
unstack b15 b23
0
4
0 23 0 6
0 20 0 1
0 16 -1 0
0 41 7 19
1
end_operator
begin_operator
unstack b15 b25
0
4
0 23 0 6
0 20 0 1
0 52 -1 0
0 41 8 19
1
end_operator
begin_operator
unstack b15 b26
0
4
0 23 0 6
0 20 0 1
0 19 -1 0
0 41 9 19
1
end_operator
begin_operator
unstack b15 b27
0
4
0 23 0 6
0 20 0 1
0 12 -1 0
0 41 10 19
1
end_operator
begin_operator
unstack b15 b3
0
4
0 23 0 6
0 20 0 1
0 21 -1 0
0 41 11 19
1
end_operator
begin_operator
unstack b15 b4
0
4
0 23 0 6
0 20 0 1
0 5 -1 0
0 41 12 19
1
end_operator
begin_operator
unstack b15 b5
0
4
0 23 0 6
0 20 0 1
0 17 -1 0
0 41 13 19
1
end_operator
begin_operator
unstack b15 b6
0
4
0 23 0 6
0 20 0 1
0 18 -1 0
0 41 14 19
1
end_operator
begin_operator
unstack b15 b7
0
4
0 23 0 6
0 20 0 1
0 13 -1 0
0 41 15 19
1
end_operator
begin_operator
unstack b15 b8
0
4
0 23 0 6
0 20 0 1
0 3 -1 0
0 41 16 19
1
end_operator
begin_operator
unstack b15 b9
0
4
0 23 0 6
0 20 0 1
0 14 -1 0
0 41 17 19
1
end_operator
begin_operator
unstack b16 b13
0
4
0 23 0 7
0 34 -1 0
0 7 0 1
0 31 0 7
1
end_operator
begin_operator
unstack b16 b18
0
4
0 23 0 7
0 7 0 1
0 2 -1 0
0 31 1 7
1
end_operator
begin_operator
unstack b16 b21
0
4
0 23 0 7
0 7 0 1
0 33 -1 0
0 31 3 7
1
end_operator
begin_operator
unstack b16 b24
0
4
0 23 0 7
0 7 0 1
0 1 -1 0
0 31 4 7
1
end_operator
begin_operator
unstack b16 b9
0
4
0 23 0 7
0 7 0 1
0 14 -1 0
0 31 5 7
1
end_operator
begin_operator
unstack b17 b16
0
4
0 23 0 8
0 7 -1 0
0 30 0 1
0 29 0 2
1
end_operator
begin_operator
unstack b18 b25
0
3
0 23 0 9
0 2 0 1
0 52 1 0
1
end_operator
begin_operator
unstack b19 b1
0
4
0 23 0 10
0 9 -1 0
0 15 0 1
0 35 0 18
1
end_operator
begin_operator
unstack b19 b10
0
4
0 23 0 10
0 8 -1 0
0 15 0 1
0 35 1 18
1
end_operator
begin_operator
unstack b19 b11
0
4
0 23 0 10
0 22 -1 0
0 15 0 1
0 35 2 18
1
end_operator
begin_operator
unstack b19 b12
0
4
0 23 0 10
0 11 -1 0
0 15 0 1
0 35 3 18
1
end_operator
begin_operator
unstack b19 b14
0
4
0 23 0 10
0 4 -1 0
0 15 0 1
0 35 4 18
1
end_operator
begin_operator
unstack b19 b15
0
4
0 23 0 10
0 20 -1 0
0 15 0 1
0 35 5 18
1
end_operator
begin_operator
unstack b19 b16
0
4
0 23 0 10
0 7 -1 0
0 15 0 1
0 35 6 18
1
end_operator
begin_operator
unstack b19 b20
0
4
0 23 0 10
0 15 0 1
0 6 -1 0
0 35 7 18
1
end_operator
begin_operator
unstack b19 b22
0
4
0 23 0 10
0 15 0 1
0 53 -1 0
0 35 8 18
1
end_operator
begin_operator
unstack b19 b23
0
4
0 23 0 10
0 15 0 1
0 16 -1 0
0 35 9 18
1
end_operator
begin_operator
unstack b19 b26
0
4
0 23 0 10
0 15 0 1
0 19 -1 0
0 35 10 18
1
end_operator
begin_operator
unstack b19 b4
0
4
0 23 0 10
0 15 0 1
0 5 -1 0
0 35 11 18
1
end_operator
begin_operator
unstack b19 b5
0
4
0 23 0 10
0 15 0 1
0 17 -1 0
0 35 12 18
1
end_operator
begin_operator
unstack b19 b6
0
4
0 23 0 10
0 15 0 1
0 18 -1 0
0 35 13 18
1
end_operator
begin_operator
unstack b19 b7
0
4
0 23 0 10
0 15 0 1
0 13 -1 0
0 35 14 18
1
end_operator
begin_operator
unstack b19 b8
0
4
0 23 0 10
0 15 0 1
0 3 -1 0
0 35 15 18
1
end_operator
begin_operator
unstack b19 b9
0
4
0 23 0 10
0 15 0 1
0 14 -1 0
0 35 16 18
1
end_operator
begin_operator
unstack b2 b1
0
4
0 23 0 11
0 9 -1 0
0 10 0 1
0 40 0 19
1
end_operator
begin_operator
unstack b2 b10
0
4
0 23 0 11
0 8 -1 0
0 10 0 1
0 40 1 19
1
end_operator
begin_operator
unstack b2 b11
0
4
0 23 0 11
0 22 -1 0
0 10 0 1
0 40 2 19
1
end_operator
begin_operator
unstack b2 b14
0
4
0 23 0 11
0 4 -1 0
0 10 0 1
0 40 3 19
1
end_operator
begin_operator
unstack b2 b15
0
4
0 23 0 11
0 20 -1 0
0 10 0 1
0 40 4 19
1
end_operator
begin_operator
unstack b2 b16
0
4
0 23 0 11
0 7 -1 0
0 10 0 1
0 40 5 19
1
end_operator
begin_operator
unstack b2 b19
0
4
0 23 0 11
0 15 -1 0
0 10 0 1
0 40 6 19
1
end_operator
begin_operator
unstack b2 b20
0
4
0 23 0 11
0 10 0 1
0 6 -1 0
0 40 7 19
1
end_operator
begin_operator
unstack b2 b23
0
4
0 23 0 11
0 10 0 1
0 16 -1 0
0 40 8 19
1
end_operator
begin_operator
unstack b2 b24
0
4
0 23 0 11
0 10 0 1
0 1 -1 0
0 40 9 19
1
end_operator
begin_operator
unstack b2 b25
0
4
0 23 0 11
0 10 0 1
0 52 -1 0
0 40 10 19
1
end_operator
begin_operator
unstack b2 b26
0
4
0 23 0 11
0 10 0 1
0 19 -1 0
0 40 11 19
1
end_operator
begin_operator
unstack b2 b27
0
4
0 23 0 11
0 10 0 1
0 12 -1 0
0 40 12 19
1
end_operator
begin_operator
unstack b2 b3
0
4
0 23 0 11
0 10 0 1
0 21 -1 0
0 40 13 19
1
end_operator
begin_operator
unstack b2 b4
0
4
0 23 0 11
0 10 0 1
0 5 -1 0
0 40 14 19
1
end_operator
begin_operator
unstack b2 b6
0
4
0 23 0 11
0 10 0 1
0 18 -1 0
0 40 15 19
1
end_operator
begin_operator
unstack b2 b7
0
4
0 23 0 11
0 10 0 1
0 13 -1 0
0 40 16 19
1
end_operator
begin_operator
unstack b2 b8
0
4
0 23 0 11
0 10 0 1
0 3 -1 0
0 40 17 19
1
end_operator
begin_operator
unstack b20 b13
0
4
0 23 0 12
0 34 -1 0
0 6 0 1
0 32 0 9
1
end_operator
begin_operator
unstack b20 b14
0
4
0 23 0 12
0 4 -1 0
0 6 0 1
0 32 1 9
1
end_operator
begin_operator
unstack b20 b16
0
4
0 23 0 12
0 7 -1 0
0 6 0 1
0 32 2 9
1
end_operator
begin_operator
unstack b20 b18
0
4
0 23 0 12
0 2 -1 0
0 6 0 1
0 32 3 9
1
end_operator
begin_operator
unstack b20 b21
0
4
0 23 0 12
0 6 0 1
0 33 -1 0
0 32 4 9
1
end_operator
begin_operator
unstack b20 b22
0
4
0 23 0 12
0 6 0 1
0 53 -1 0
0 32 5 9
1
end_operator
begin_operator
unstack b20 b4
0
4
0 23 0 12
0 6 0 1
0 5 -1 0
0 32 6 9
1
end_operator
begin_operator
unstack b21 b23
0
4
0 23 0 13
0 33 0 1
0 16 -1 0
0 26 0 2
1
end_operator
begin_operator
unstack b22 b11
0
4
0 23 0 14
0 22 -1 0
0 53 0 1
0 49 0 21
1
end_operator
begin_operator
unstack b22 b12
0
4
0 23 0 14
0 11 -1 0
0 53 0 1
0 49 1 21
1
end_operator
begin_operator
unstack b22 b13
0
4
0 23 0 14
0 34 -1 0
0 53 0 1
0 49 2 21
1
end_operator
begin_operator
unstack b22 b14
0
4
0 23 0 14
0 4 -1 0
0 53 0 1
0 49 3 21
1
end_operator
begin_operator
unstack b22 b15
0
4
0 23 0 14
0 20 -1 0
0 53 0 1
0 49 4 21
1
end_operator
begin_operator
unstack b22 b16
0
4
0 23 0 14
0 7 -1 0
0 53 0 1
0 49 5 21
1
end_operator
begin_operator
unstack b22 b18
0
4
0 23 0 14
0 2 -1 0
0 53 0 1
0 49 6 21
1
end_operator
begin_operator
unstack b22 b19
0
4
0 23 0 14
0 15 -1 0
0 53 0 1
0 49 7 21
1
end_operator
begin_operator
unstack b22 b20
0
4
0 23 0 14
0 6 -1 0
0 53 0 1
0 49 8 21
1
end_operator
begin_operator
unstack b22 b21
0
4
0 23 0 14
0 33 -1 0
0 53 0 1
0 49 9 21
1
end_operator
begin_operator
unstack b22 b23
0
4
0 23 0 14
0 53 0 1
0 16 -1 0
0 49 10 21
1
end_operator
begin_operator
unstack b22 b24
0
4
0 23 0 14
0 53 0 1
0 1 -1 0
0 49 11 21
1
end_operator
begin_operator
unstack b22 b25
0
4
0 23 0 14
0 53 0 1
0 52 -1 0
0 49 12 21
1
end_operator
begin_operator
unstack b22 b26
0
4
0 23 0 14
0 53 0 1
0 19 -1 0
0 49 13 21
1
end_operator
begin_operator
unstack b22 b27
0
4
0 23 0 14
0 53 0 1
0 12 -1 0
0 49 14 21
1
end_operator
begin_operator
unstack b22 b3
0
4
0 23 0 14
0 53 0 1
0 21 -1 0
0 49 15 21
1
end_operator
begin_operator
unstack b22 b4
0
4
0 23 0 14
0 53 0 1
0 5 -1 0
0 49 16 21
1
end_operator
begin_operator
unstack b22 b5
0
4
0 23 0 14
0 53 0 1
0 17 -1 0
0 49 17 21
1
end_operator
begin_operator
unstack b22 b7
0
4
0 23 0 14
0 53 0 1
0 13 -1 0
0 49 18 21
1
end_operator
begin_operator
unstack b22 b9
0
4
0 23 0 14
0 53 0 1
0 14 -1 0
0 49 19 21
1
end_operator
begin_operator
unstack b23 b1
0
4
0 23 0 15
0 9 -1 0
0 16 0 1
0 47 0 20
1
end_operator
begin_operator
unstack b23 b10
0
4
0 23 0 15
0 8 -1 0
0 16 0 1
0 47 1 20
1
end_operator
begin_operator
unstack b23 b14
0
4
0 23 0 15
0 4 -1 0
0 16 0 1
0 47 2 20
1
end_operator
begin_operator
unstack b23 b15
0
4
0 23 0 15
0 20 -1 0
0 16 0 1
0 47 3 20
1
end_operator
begin_operator
unstack b23 b16
0
4
0 23 0 15
0 7 -1 0
0 16 0 1
0 47 4 20
1
end_operator
begin_operator
unstack b23 b19
0
4
0 23 0 15
0 15 -1 0
0 16 0 1
0 47 5 20
1
end_operator
begin_operator
unstack b23 b2
0
4
0 23 0 15
0 10 -1 0
0 16 0 1
0 47 6 20
1
end_operator
begin_operator
unstack b23 b20
0
4
0 23 0 15
0 6 -1 0
0 16 0 1
0 47 7 20
1
end_operator
begin_operator
unstack b23 b22
0
4
0 23 0 15
0 53 -1 0
0 16 0 1
0 47 8 20
1
end_operator
begin_operator
unstack b23 b25
0
4
0 23 0 15
0 16 0 1
0 52 -1 0
0 47 9 20
1
end_operator
begin_operator
unstack b23 b26
0
4
0 23 0 15
0 16 0 1
0 19 -1 0
0 47 10 20
1
end_operator
begin_operator
unstack b23 b27
0
4
0 23 0 15
0 16 0 1
0 12 -1 0
0 47 11 20
1
end_operator
begin_operator
unstack b23 b3
0
4
0 23 0 15
0 16 0 1
0 21 -1 0
0 47 12 20
1
end_operator
begin_operator
unstack b23 b4
0
4
0 23 0 15
0 16 0 1
0 5 -1 0
0 47 13 20
1
end_operator
begin_operator
unstack b23 b5
0
4
0 23 0 15
0 16 0 1
0 17 -1 0
0 47 14 20
1
end_operator
begin_operator
unstack b23 b6
0
4
0 23 0 15
0 16 0 1
0 18 -1 0
0 47 15 20
1
end_operator
begin_operator
unstack b23 b7
0
4
0 23 0 15
0 16 0 1
0 13 -1 0
0 47 16 20
1
end_operator
begin_operator
unstack b23 b8
0
4
0 23 0 15
0 16 0 1
0 3 -1 0
0 47 17 20
1
end_operator
begin_operator
unstack b23 b9
0
4
0 23 0 15
0 16 0 1
0 14 -1 0
0 47 18 20
1
end_operator
begin_operator
unstack b24 b22
0
4
0 23 0 16
0 53 -1 0
0 1 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b25 b1
0
4
0 23 0 17
0 9 -1 0
0 52 0 3
0 50 0 22
1
end_operator
begin_operator
unstack b25 b10
0
4
0 23 0 17
0 8 -1 0
0 52 0 3
0 50 1 22
1
end_operator
begin_operator
unstack b25 b11
0
4
0 23 0 17
0 22 -1 0
0 52 0 3
0 50 2 22
1
end_operator
begin_operator
unstack b25 b12
0
4
0 23 0 17
0 11 -1 0
0 52 0 3
0 50 3 22
1
end_operator
begin_operator
unstack b25 b13
0
4
0 23 0 17
0 34 -1 0
0 52 0 3
0 50 4 22
1
end_operator
begin_operator
unstack b25 b14
0
4
0 23 0 17
0 4 -1 0
0 52 0 3
0 50 5 22
1
end_operator
begin_operator
unstack b25 b15
0
4
0 23 0 17
0 20 -1 0
0 52 0 3
0 50 6 22
1
end_operator
begin_operator
unstack b25 b16
0
4
0 23 0 17
0 7 -1 0
0 52 0 3
0 50 7 22
1
end_operator
begin_operator
unstack b25 b19
0
4
0 23 0 17
0 15 -1 0
0 52 0 3
0 50 8 22
1
end_operator
begin_operator
unstack b25 b2
0
4
0 23 0 17
0 10 -1 0
0 52 0 3
0 50 9 22
1
end_operator
begin_operator
unstack b25 b20
0
4
0 23 0 17
0 6 -1 0
0 52 0 3
0 50 10 22
1
end_operator
begin_operator
unstack b25 b22
0
4
0 23 0 17
0 53 -1 0
0 52 0 3
0 50 11 22
1
end_operator
begin_operator
unstack b25 b23
0
4
0 23 0 17
0 16 -1 0
0 52 0 3
0 50 12 22
1
end_operator
begin_operator
unstack b25 b26
0
4
0 23 0 17
0 52 0 3
0 19 -1 0
0 50 13 22
1
end_operator
begin_operator
unstack b25 b27
0
4
0 23 0 17
0 52 0 3
0 12 -1 0
0 50 14 22
1
end_operator
begin_operator
unstack b25 b3
0
4
0 23 0 17
0 52 0 3
0 21 -1 0
0 50 15 22
1
end_operator
begin_operator
unstack b25 b4
0
4
0 23 0 17
0 52 0 3
0 5 -1 0
0 50 16 22
1
end_operator
begin_operator
unstack b25 b5
0
4
0 23 0 17
0 52 0 3
0 17 -1 0
0 50 17 22
1
end_operator
begin_operator
unstack b25 b6
0
4
0 23 0 17
0 52 0 3
0 18 -1 0
0 50 18 22
1
end_operator
begin_operator
unstack b25 b8
0
4
0 23 0 17
0 52 0 3
0 3 -1 0
0 50 19 22
1
end_operator
begin_operator
unstack b25 b9
0
4
0 23 0 17
0 52 0 3
0 14 -1 0
0 50 20 22
1
end_operator
begin_operator
unstack b26 b1
0
4
0 23 0 18
0 9 -1 0
0 19 0 1
0 38 0 18
1
end_operator
begin_operator
unstack b26 b10
0
4
0 23 0 18
0 8 -1 0
0 19 0 1
0 38 1 18
1
end_operator
begin_operator
unstack b26 b11
0
4
0 23 0 18
0 22 -1 0
0 19 0 1
0 38 2 18
1
end_operator
begin_operator
unstack b26 b12
0
4
0 23 0 18
0 11 -1 0
0 19 0 1
0 38 3 18
1
end_operator
begin_operator
unstack b26 b14
0
4
0 23 0 18
0 4 -1 0
0 19 0 1
0 38 4 18
1
end_operator
begin_operator
unstack b26 b15
0
4
0 23 0 18
0 20 -1 0
0 19 0 1
0 38 5 18
1
end_operator
begin_operator
unstack b26 b16
0
4
0 23 0 18
0 7 -1 0
0 19 0 1
0 38 6 18
1
end_operator
begin_operator
unstack b26 b19
0
4
0 23 0 18
0 15 -1 0
0 19 0 1
0 38 7 18
1
end_operator
begin_operator
unstack b26 b2
0
4
0 23 0 18
0 10 -1 0
0 19 0 1
0 38 8 18
1
end_operator
begin_operator
unstack b26 b20
0
4
0 23 0 18
0 6 -1 0
0 19 0 1
0 38 9 18
1
end_operator
begin_operator
unstack b26 b22
0
4
0 23 0 18
0 53 -1 0
0 19 0 1
0 38 10 18
1
end_operator
begin_operator
unstack b26 b23
0
4
0 23 0 18
0 16 -1 0
0 19 0 1
0 38 11 18
1
end_operator
begin_operator
unstack b26 b25
0
4
0 23 0 18
0 52 -1 0
0 19 0 1
0 38 12 18
1
end_operator
begin_operator
unstack b26 b27
0
4
0 23 0 18
0 19 0 1
0 12 -1 0
0 38 13 18
1
end_operator
begin_operator
unstack b26 b5
0
4
0 23 0 18
0 19 0 1
0 17 -1 0
0 38 14 18
1
end_operator
begin_operator
unstack b26 b6
0
4
0 23 0 18
0 19 0 1
0 18 -1 0
0 38 15 18
1
end_operator
begin_operator
unstack b26 b9
0
4
0 23 0 18
0 19 0 1
0 14 -1 0
0 38 16 18
1
end_operator
begin_operator
unstack b27 b1
0
4
0 23 0 19
0 9 -1 0
0 12 0 1
0 36 0 18
1
end_operator
begin_operator
unstack b27 b10
0
4
0 23 0 19
0 8 -1 0
0 12 0 1
0 36 1 18
1
end_operator
begin_operator
unstack b27 b12
0
4
0 23 0 19
0 11 -1 0
0 12 0 1
0 36 2 18
1
end_operator
begin_operator
unstack b27 b15
0
4
0 23 0 19
0 20 -1 0
0 12 0 1
0 36 3 18
1
end_operator
begin_operator
unstack b27 b16
0
4
0 23 0 19
0 7 -1 0
0 12 0 1
0 36 4 18
1
end_operator
begin_operator
unstack b27 b19
0
4
0 23 0 19
0 15 -1 0
0 12 0 1
0 36 5 18
1
end_operator
begin_operator
unstack b27 b2
0
4
0 23 0 19
0 10 -1 0
0 12 0 1
0 36 6 18
1
end_operator
begin_operator
unstack b27 b20
0
4
0 23 0 19
0 6 -1 0
0 12 0 1
0 36 7 18
1
end_operator
begin_operator
unstack b27 b22
0
4
0 23 0 19
0 53 -1 0
0 12 0 1
0 36 8 18
1
end_operator
begin_operator
unstack b27 b23
0
4
0 23 0 19
0 16 -1 0
0 12 0 1
0 36 9 18
1
end_operator
begin_operator
unstack b27 b26
0
4
0 23 0 19
0 19 -1 0
0 12 0 1
0 36 10 18
1
end_operator
begin_operator
unstack b27 b3
0
4
0 23 0 19
0 12 0 1
0 21 -1 0
0 36 11 18
1
end_operator
begin_operator
unstack b27 b4
0
4
0 23 0 19
0 12 0 1
0 5 -1 0
0 36 12 18
1
end_operator
begin_operator
unstack b27 b5
0
4
0 23 0 19
0 12 0 1
0 17 -1 0
0 36 13 18
1
end_operator
begin_operator
unstack b27 b6
0
4
0 23 0 19
0 12 0 1
0 18 -1 0
0 36 14 18
1
end_operator
begin_operator
unstack b27 b8
0
4
0 23 0 19
0 12 0 1
0 3 -1 0
0 36 15 18
1
end_operator
begin_operator
unstack b27 b9
0
4
0 23 0 19
0 12 0 1
0 14 -1 0
0 36 16 18
1
end_operator
begin_operator
unstack b3 b1
0
4
0 23 0 20
0 9 -1 0
0 21 0 1
0 48 0 21
1
end_operator
begin_operator
unstack b3 b10
0
4
0 23 0 20
0 8 -1 0
0 21 0 1
0 48 1 21
1
end_operator
begin_operator
unstack b3 b11
0
4
0 23 0 20
0 22 -1 0
0 21 0 1
0 48 2 21
1
end_operator
begin_operator
unstack b3 b12
0
4
0 23 0 20
0 11 -1 0
0 21 0 1
0 48 3 21
1
end_operator
begin_operator
unstack b3 b15
0
4
0 23 0 20
0 20 -1 0
0 21 0 1
0 48 4 21
1
end_operator
begin_operator
unstack b3 b16
0
4
0 23 0 20
0 7 -1 0
0 21 0 1
0 48 5 21
1
end_operator
begin_operator
unstack b3 b19
0
4
0 23 0 20
0 15 -1 0
0 21 0 1
0 48 6 21
1
end_operator
begin_operator
unstack b3 b2
0
4
0 23 0 20
0 10 -1 0
0 21 0 1
0 48 7 21
1
end_operator
begin_operator
unstack b3 b20
0
4
0 23 0 20
0 6 -1 0
0 21 0 1
0 48 8 21
1
end_operator
begin_operator
unstack b3 b22
0
4
0 23 0 20
0 53 -1 0
0 21 0 1
0 48 9 21
1
end_operator
begin_operator
unstack b3 b23
0
4
0 23 0 20
0 16 -1 0
0 21 0 1
0 48 10 21
1
end_operator
begin_operator
unstack b3 b25
0
4
0 23 0 20
0 52 -1 0
0 21 0 1
0 48 11 21
1
end_operator
begin_operator
unstack b3 b26
0
4
0 23 0 20
0 19 -1 0
0 21 0 1
0 48 12 21
1
end_operator
begin_operator
unstack b3 b27
0
4
0 23 0 20
0 12 -1 0
0 21 0 1
0 48 13 21
1
end_operator
begin_operator
unstack b3 b4
0
4
0 23 0 20
0 21 0 1
0 5 -1 0
0 48 14 21
1
end_operator
begin_operator
unstack b3 b5
0
4
0 23 0 20
0 21 0 1
0 17 -1 0
0 48 15 21
1
end_operator
begin_operator
unstack b3 b6
0
4
0 23 0 20
0 21 0 1
0 18 -1 0
0 48 16 21
1
end_operator
begin_operator
unstack b3 b7
0
4
0 23 0 20
0 21 0 1
0 13 -1 0
0 48 17 21
1
end_operator
begin_operator
unstack b3 b8
0
4
0 23 0 20
0 21 0 1
0 3 -1 0
0 48 18 21
1
end_operator
begin_operator
unstack b3 b9
0
4
0 23 0 20
0 21 0 1
0 14 -1 0
0 48 19 21
1
end_operator
begin_operator
unstack b5 b1
0
4
0 23 0 22
0 9 -1 0
0 17 0 1
0 45 0 20
1
end_operator
begin_operator
unstack b5 b10
0
4
0 23 0 22
0 8 -1 0
0 17 0 1
0 45 1 20
1
end_operator
begin_operator
unstack b5 b11
0
4
0 23 0 22
0 22 -1 0
0 17 0 1
0 45 2 20
1
end_operator
begin_operator
unstack b5 b12
0
4
0 23 0 22
0 11 -1 0
0 17 0 1
0 45 3 20
1
end_operator
begin_operator
unstack b5 b14
0
4
0 23 0 22
0 4 -1 0
0 17 0 1
0 45 4 20
1
end_operator
begin_operator
unstack b5 b15
0
4
0 23 0 22
0 20 -1 0
0 17 0 1
0 45 5 20
1
end_operator
begin_operator
unstack b5 b16
0
4
0 23 0 22
0 7 -1 0
0 17 0 1
0 45 6 20
1
end_operator
begin_operator
unstack b5 b2
0
4
0 23 0 22
0 10 -1 0
0 17 0 1
0 45 7 20
1
end_operator
begin_operator
unstack b5 b20
0
4
0 23 0 22
0 6 -1 0
0 17 0 1
0 45 8 20
1
end_operator
begin_operator
unstack b5 b22
0
4
0 23 0 22
0 53 -1 0
0 17 0 1
0 45 9 20
1
end_operator
begin_operator
unstack b5 b23
0
4
0 23 0 22
0 16 -1 0
0 17 0 1
0 45 10 20
1
end_operator
begin_operator
unstack b5 b25
0
4
0 23 0 22
0 52 -1 0
0 17 0 1
0 45 11 20
1
end_operator
begin_operator
unstack b5 b26
0
4
0 23 0 22
0 19 -1 0
0 17 0 1
0 45 12 20
1
end_operator
begin_operator
unstack b5 b27
0
4
0 23 0 22
0 12 -1 0
0 17 0 1
0 45 13 20
1
end_operator
begin_operator
unstack b5 b3
0
4
0 23 0 22
0 21 -1 0
0 17 0 1
0 45 14 20
1
end_operator
begin_operator
unstack b5 b4
0
4
0 23 0 22
0 5 -1 0
0 17 0 1
0 45 15 20
1
end_operator
begin_operator
unstack b5 b6
0
4
0 23 0 22
0 17 0 1
0 18 -1 0
0 45 16 20
1
end_operator
begin_operator
unstack b5 b7
0
4
0 23 0 22
0 17 0 1
0 13 -1 0
0 45 17 20
1
end_operator
begin_operator
unstack b5 b9
0
4
0 23 0 22
0 17 0 1
0 14 -1 0
0 45 18 20
1
end_operator
begin_operator
unstack b6 b10
0
4
0 23 0 23
0 8 -1 0
0 18 0 1
0 42 0 19
1
end_operator
begin_operator
unstack b6 b11
0
4
0 23 0 23
0 22 -1 0
0 18 0 1
0 42 1 19
1
end_operator
begin_operator
unstack b6 b12
0
4
0 23 0 23
0 11 -1 0
0 18 0 1
0 42 2 19
1
end_operator
begin_operator
unstack b6 b14
0
4
0 23 0 23
0 4 -1 0
0 18 0 1
0 42 3 19
1
end_operator
begin_operator
unstack b6 b15
0
4
0 23 0 23
0 20 -1 0
0 18 0 1
0 42 4 19
1
end_operator
begin_operator
unstack b6 b16
0
4
0 23 0 23
0 7 -1 0
0 18 0 1
0 42 5 19
1
end_operator
begin_operator
unstack b6 b19
0
4
0 23 0 23
0 15 -1 0
0 18 0 1
0 42 6 19
1
end_operator
begin_operator
unstack b6 b20
0
4
0 23 0 23
0 6 -1 0
0 18 0 1
0 42 7 19
1
end_operator
begin_operator
unstack b6 b22
0
4
0 23 0 23
0 53 -1 0
0 18 0 1
0 42 8 19
1
end_operator
begin_operator
unstack b6 b23
0
4
0 23 0 23
0 16 -1 0
0 18 0 1
0 42 9 19
1
end_operator
begin_operator
unstack b6 b25
0
4
0 23 0 23
0 52 -1 0
0 18 0 1
0 42 10 19
1
end_operator
begin_operator
unstack b6 b26
0
4
0 23 0 23
0 19 -1 0
0 18 0 1
0 42 11 19
1
end_operator
begin_operator
unstack b6 b27
0
4
0 23 0 23
0 12 -1 0
0 18 0 1
0 42 12 19
1
end_operator
begin_operator
unstack b6 b3
0
4
0 23 0 23
0 21 -1 0
0 18 0 1
0 42 13 19
1
end_operator
begin_operator
unstack b6 b4
0
4
0 23 0 23
0 5 -1 0
0 18 0 1
0 42 14 19
1
end_operator
begin_operator
unstack b6 b5
0
4
0 23 0 23
0 17 -1 0
0 18 0 1
0 42 15 19
1
end_operator
begin_operator
unstack b6 b7
0
4
0 23 0 23
0 18 0 1
0 13 -1 0
0 42 16 19
1
end_operator
begin_operator
unstack b6 b8
0
4
0 23 0 23
0 18 0 1
0 3 -1 0
0 42 17 19
1
end_operator
begin_operator
unstack b7 b1
0
4
0 23 0 24
0 9 -1 0
0 13 0 1
0 43 0 19
1
end_operator
begin_operator
unstack b7 b10
0
4
0 23 0 24
0 8 -1 0
0 13 0 1
0 43 1 19
1
end_operator
begin_operator
unstack b7 b11
0
4
0 23 0 24
0 22 -1 0
0 13 0 1
0 43 2 19
1
end_operator
begin_operator
unstack b7 b12
0
4
0 23 0 24
0 11 -1 0
0 13 0 1
0 43 3 19
1
end_operator
begin_operator
unstack b7 b14
0
4
0 23 0 24
0 4 -1 0
0 13 0 1
0 43 4 19
1
end_operator
begin_operator
unstack b7 b15
0
4
0 23 0 24
0 20 -1 0
0 13 0 1
0 43 5 19
1
end_operator
begin_operator
unstack b7 b16
0
4
0 23 0 24
0 7 -1 0
0 13 0 1
0 43 6 19
1
end_operator
begin_operator
unstack b7 b19
0
4
0 23 0 24
0 15 -1 0
0 13 0 1
0 43 7 19
1
end_operator
begin_operator
unstack b7 b2
0
4
0 23 0 24
0 10 -1 0
0 13 0 1
0 43 8 19
1
end_operator
begin_operator
unstack b7 b20
0
4
0 23 0 24
0 6 -1 0
0 13 0 1
0 43 9 19
1
end_operator
begin_operator
unstack b7 b22
0
4
0 23 0 24
0 53 -1 0
0 13 0 1
0 43 10 19
1
end_operator
begin_operator
unstack b7 b23
0
4
0 23 0 24
0 16 -1 0
0 13 0 1
0 43 11 19
1
end_operator
begin_operator
unstack b7 b25
0
4
0 23 0 24
0 52 -1 0
0 13 0 1
0 43 12 19
1
end_operator
begin_operator
unstack b7 b26
0
4
0 23 0 24
0 19 -1 0
0 13 0 1
0 43 13 19
1
end_operator
begin_operator
unstack b7 b27
0
4
0 23 0 24
0 12 -1 0
0 13 0 1
0 43 14 19
1
end_operator
begin_operator
unstack b7 b3
0
4
0 23 0 24
0 21 -1 0
0 13 0 1
0 43 15 19
1
end_operator
begin_operator
unstack b7 b5
0
4
0 23 0 24
0 17 -1 0
0 13 0 1
0 43 16 19
1
end_operator
begin_operator
unstack b7 b9
0
4
0 23 0 24
0 13 0 1
0 14 -1 0
0 43 17 19
1
end_operator
begin_operator
unstack b8 b11
0
4
0 23 0 25
0 22 -1 0
0 3 0 1
0 28 0 2
1
end_operator
begin_operator
unstack b9 b1
0
4
0 23 0 26
0 9 -1 0
0 14 0 1
0 39 0 18
1
end_operator
begin_operator
unstack b9 b11
0
4
0 23 0 26
0 22 -1 0
0 14 0 1
0 39 1 18
1
end_operator
begin_operator
unstack b9 b14
0
4
0 23 0 26
0 4 -1 0
0 14 0 1
0 39 2 18
1
end_operator
begin_operator
unstack b9 b15
0
4
0 23 0 26
0 20 -1 0
0 14 0 1
0 39 3 18
1
end_operator
begin_operator
unstack b9 b16
0
4
0 23 0 26
0 7 -1 0
0 14 0 1
0 39 4 18
1
end_operator
begin_operator
unstack b9 b19
0
4
0 23 0 26
0 15 -1 0
0 14 0 1
0 39 5 18
1
end_operator
begin_operator
unstack b9 b2
0
4
0 23 0 26
0 10 -1 0
0 14 0 1
0 39 6 18
1
end_operator
begin_operator
unstack b9 b20
0
4
0 23 0 26
0 6 -1 0
0 14 0 1
0 39 7 18
1
end_operator
begin_operator
unstack b9 b22
0
4
0 23 0 26
0 53 -1 0
0 14 0 1
0 39 8 18
1
end_operator
begin_operator
unstack b9 b25
0
4
0 23 0 26
0 52 -1 0
0 14 0 1
0 39 9 18
1
end_operator
begin_operator
unstack b9 b26
0
4
0 23 0 26
0 19 -1 0
0 14 0 1
0 39 10 18
1
end_operator
begin_operator
unstack b9 b27
0
4
0 23 0 26
0 12 -1 0
0 14 0 1
0 39 11 18
1
end_operator
begin_operator
unstack b9 b3
0
4
0 23 0 26
0 21 -1 0
0 14 0 1
0 39 12 18
1
end_operator
begin_operator
unstack b9 b4
0
4
0 23 0 26
0 5 -1 0
0 14 0 1
0 39 13 18
1
end_operator
begin_operator
unstack b9 b5
0
4
0 23 0 26
0 17 -1 0
0 14 0 1
0 39 14 18
1
end_operator
begin_operator
unstack b9 b6
0
4
0 23 0 26
0 18 -1 0
0 14 0 1
0 39 15 18
1
end_operator
begin_operator
unstack b9 b7
0
4
0 23 0 26
0 13 -1 0
0 14 0 1
0 39 16 18
1
end_operator
0
