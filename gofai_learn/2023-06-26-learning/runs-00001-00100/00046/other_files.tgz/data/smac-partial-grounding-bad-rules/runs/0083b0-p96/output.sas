begin_version
3
end_version
begin_metric
0
end_metric
56
begin_variable
var0
-1
2
Atom on-table(b2)
NegatedAtom on-table(b2)
end_variable
begin_variable
var1
-1
2
Atom on-table(b11)
NegatedAtom on-table(b11)
end_variable
begin_variable
var2
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var3
-1
2
Atom clear(b9)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var5
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var7
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var10
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var9
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var8
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var13
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var12
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var14
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var17
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var18
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var15
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var16
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var19
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var21
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var20
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var22
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var23
-1
28
Atom arm-empty()
Atom holding(b1)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b28)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b4, b27)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom on(b17, b11)
Atom on(b17, b21)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom on(b7, b23)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b15, b7)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var28
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var41
-1
4
Atom on(b21, b22)
Atom on(b21, b25)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom clear(b15)
Atom on(b8, b15)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom on(b23, b11)
Atom on(b23, b4)
Atom on(b23, b7)
Atom on(b23, b9)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var42
-1
8
Atom on(b12, b10)
Atom on(b12, b14)
Atom on(b12, b18)
Atom on(b12, b24)
Atom on(b12, b28)
Atom on(b12, b3)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var31
-1
11
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b18)
Atom on(b19, b23)
Atom on(b19, b3)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var48
-1
12
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b20)
Atom on(b5, b21)
Atom on(b5, b22)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var32
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var34
-1
18
Atom on(b20, b10)
Atom on(b20, b11)
Atom on(b20, b12)
Atom on(b20, b16)
Atom on(b20, b19)
Atom on(b20, b21)
Atom on(b20, b22)
Atom on(b20, b23)
Atom on(b20, b24)
Atom on(b20, b26)
Atom on(b20, b27)
Atom on(b20, b28)
Atom on(b20, b3)
Atom on(b20, b5)
Atom on(b20, b6)
Atom on(b20, b7)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var37
-1
18
Atom on(b26, b1)
Atom on(b26, b10)
Atom on(b26, b11)
Atom on(b26, b12)
Atom on(b26, b14)
Atom on(b26, b16)
Atom on(b26, b18)
Atom on(b26, b19)
Atom on(b26, b20)
Atom on(b26, b23)
Atom on(b26, b27)
Atom on(b26, b28)
Atom on(b26, b3)
Atom on(b26, b5)
Atom on(b26, b6)
Atom on(b26, b7)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var38
-1
19
Atom on(b27, b1)
Atom on(b27, b10)
Atom on(b27, b11)
Atom on(b27, b12)
Atom on(b27, b14)
Atom on(b27, b16)
Atom on(b27, b17)
Atom on(b27, b19)
Atom on(b27, b21)
Atom on(b27, b23)
Atom on(b27, b24)
Atom on(b27, b26)
Atom on(b27, b28)
Atom on(b27, b3)
Atom on(b27, b5)
Atom on(b27, b6)
Atom on(b27, b7)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var40
-1
19
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b23)
Atom on(b16, b24)
Atom on(b16, b27)
Atom on(b16, b28)
Atom on(b16, b3)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var47
-1
20
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b12)
Atom on(b10, b14)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b24)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b28)
Atom on(b10, b3)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b8)
Atom on-table(b10)
end_variable
begin_variable
var43
-1
19
Atom on(b28, b1)
Atom on(b28, b10)
Atom on(b28, b12)
Atom on(b28, b14)
Atom on(b28, b16)
Atom on(b28, b17)
Atom on(b28, b18)
Atom on(b28, b19)
Atom on(b28, b20)
Atom on(b28, b21)
Atom on(b28, b22)
Atom on(b28, b24)
Atom on(b28, b26)
Atom on(b28, b3)
Atom on(b28, b4)
Atom on(b28, b5)
Atom on(b28, b6)
Atom on-table(b28)
<none of those>
end_variable
begin_variable
var33
-1
20
Atom on(b18, b1)
Atom on(b18, b10)
Atom on(b18, b11)
Atom on(b18, b12)
Atom on(b18, b13)
Atom on(b18, b16)
Atom on(b18, b17)
Atom on(b18, b19)
Atom on(b18, b20)
Atom on(b18, b22)
Atom on(b18, b23)
Atom on(b18, b24)
Atom on(b18, b26)
Atom on(b18, b27)
Atom on(b18, b3)
Atom on(b18, b5)
Atom on(b18, b6)
Atom on(b18, b7)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var35
-1
20
Atom on(b22, b1)
Atom on(b22, b10)
Atom on(b22, b11)
Atom on(b22, b12)
Atom on(b22, b14)
Atom on(b22, b16)
Atom on(b22, b18)
Atom on(b22, b19)
Atom on(b22, b20)
Atom on(b22, b21)
Atom on(b22, b24)
Atom on(b22, b26)
Atom on(b22, b27)
Atom on(b22, b28)
Atom on(b22, b3)
Atom on(b22, b5)
Atom on(b22, b6)
Atom on(b22, b7)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var44
-1
20
Atom on(b6, b1)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b16)
Atom on(b6, b17)
Atom on(b6, b18)
Atom on(b6, b19)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b22)
Atom on(b6, b24)
Atom on(b6, b25)
Atom on(b6, b27)
Atom on(b6, b28)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var39
-1
21
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b20)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b26)
Atom on(b14, b27)
Atom on(b14, b28)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var36
-1
22
Atom on(b24, b1)
Atom on(b24, b10)
Atom on(b24, b12)
Atom on(b24, b13)
Atom on(b24, b14)
Atom on(b24, b17)
Atom on(b24, b19)
Atom on(b24, b20)
Atom on(b24, b21)
Atom on(b24, b22)
Atom on(b24, b23)
Atom on(b24, b25)
Atom on(b24, b27)
Atom on(b24, b28)
Atom on(b24, b3)
Atom on(b24, b4)
Atom on(b24, b5)
Atom on(b24, b6)
Atom on(b24, b7)
Atom on(b24, b9)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var45
-1
25
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b16)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b27)
Atom on(b1, b28)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var46
-1
26
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b14)
Atom on(b3, b16)
Atom on(b3, b17)
Atom on(b3, b18)
Atom on(b3, b19)
Atom on(b3, b20)
Atom on(b3, b21)
Atom on(b3, b22)
Atom on(b3, b23)
Atom on(b3, b24)
Atom on(b3, b25)
Atom on(b3, b26)
Atom on(b3, b27)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var52
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var49
-1
4
Atom clear(b28)
Atom on(b11, b28)
Atom on(b13, b28)
<none of those>
end_variable
begin_variable
var50
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var51
-1
4
Atom clear(b3)
Atom on(b2, b3)
Atom on(b25, b3)
<none of those>
end_variable
begin_variable
var55
-1
2
Atom on-table(b13)
NegatedAtom on-table(b13)
end_variable
begin_variable
var54
-1
2
Atom on-table(b25)
NegatedAtom on-table(b25)
end_variable
begin_variable
var53
-1
2
Atom on-table(b8)
NegatedAtom on-table(b8)
end_variable
3250
begin_mutex_group
28
23 0
23 1
23 2
23 3
23 4
23 5
23 6
23 7
23 8
23 9
23 10
23 11
23 12
23 13
23 14
23 15
23 16
23 17
23 18
23 19
23 20
23 21
23 22
23 23
23 24
23 25
23 26
40 0
end_mutex_group
begin_mutex_group
13
23 1
22 0
40 1
45 0
39 0
42 0
43 0
46 0
37 0
38 0
41 0
48 0
44 0
end_mutex_group
begin_mutex_group
15
20 0
40 0
47 0
32 0
45 1
39 1
42 1
33 0
36 0
43 1
46 1
37 1
38 1
41 1
48 1
end_mutex_group
begin_mutex_group
14
23 2
7 0
47 1
45 2
39 2
25 0
42 2
33 1
36 1
43 2
31 0
37 2
38 2
48 2
end_mutex_group
begin_mutex_group
16
23 3
49 0
40 2
47 2
45 3
39 3
42 3
36 2
43 3
46 2
37 3
38 3
41 2
48 3
34 0
44 1
end_mutex_group
begin_mutex_group
8
23 4
35 0
47 3
42 4
46 3
48 4
34 1
44 2
end_mutex_group
begin_mutex_group
12
23 5
17 0
40 3
47 4
32 1
43 4
46 4
37 4
38 4
41 3
48 5
44 3
end_mutex_group
begin_mutex_group
3
23 6
30 0
30 1
end_mutex_group
begin_mutex_group
14
23 7
16 0
40 4
47 5
45 4
42 5
33 2
36 3
43 5
37 5
38 5
41 4
48 6
44 4
end_mutex_group
begin_mutex_group
12
23 8
6 0
40 5
45 5
39 4
42 6
33 3
46 5
38 6
41 5
48 7
44 5
end_mutex_group
begin_mutex_group
14
23 9
19 0
40 6
47 6
32 2
45 6
39 5
33 4
43 6
37 6
41 6
48 8
34 2
44 6
end_mutex_group
begin_mutex_group
16
23 10
11 0
40 7
47 7
45 7
39 6
42 7
36 4
43 7
46 6
37 7
38 7
41 7
48 9
34 3
44 7
end_mutex_group
begin_mutex_group
2
23 11
28 0
end_mutex_group
begin_mutex_group
14
23 12
14 0
40 8
47 8
45 8
39 7
42 8
43 8
46 7
37 8
41 8
48 10
34 4
44 8
end_mutex_group
begin_mutex_group
14
23 13
8 0
40 9
47 9
39 8
25 1
36 5
43 9
46 8
38 8
41 9
48 11
34 5
44 9
end_mutex_group
begin_mutex_group
13
23 14
18 0
40 10
47 10
45 9
42 9
36 6
29 0
46 9
41 10
48 12
34 6
44 10
end_mutex_group
begin_mutex_group
13
23 15
9 0
47 11
45 10
39 9
42 10
33 5
36 7
46 10
37 9
38 9
48 13
26 0
end_mutex_group
begin_mutex_group
14
23 16
21 0
40 11
47 12
32 3
45 11
39 10
42 11
36 8
43 10
38 10
41 11
48 14
44 11
end_mutex_group
begin_mutex_group
8
23 17
4 0
47 13
45 12
29 1
46 11
48 15
44 12
end_mutex_group
begin_mutex_group
11
23 18
13 0
40 12
47 14
45 13
42 12
36 9
43 11
38 11
41 12
48 16
end_mutex_group
begin_mutex_group
14
23 19
15 0
40 13
47 15
45 14
39 11
42 13
36 10
43 12
46 12
37 10
48 17
24 0
44 13
end_mutex_group
begin_mutex_group
15
23 20
50 0
50 1
50 2
40 14
47 16
32 4
45 15
39 12
36 11
43 13
46 13
37 11
38 12
44 14
end_mutex_group
begin_mutex_group
16
23 21
52 0
52 1
52 2
40 15
32 5
39 13
42 14
33 6
36 12
43 14
46 14
37 12
38 13
41 13
44 15
end_mutex_group
begin_mutex_group
8
23 22
5 0
47 17
31 1
46 15
41 14
48 18
44 16
end_mutex_group
begin_mutex_group
15
23 23
12 0
40 16
47 18
45 16
39 14
42 15
36 13
43 15
46 16
37 13
38 14
41 15
48 19
44 17
end_mutex_group
begin_mutex_group
15
23 24
51 0
40 17
47 19
45 17
39 15
42 16
36 14
43 16
46 17
37 14
38 15
41 16
48 20
34 7
end_mutex_group
begin_mutex_group
16
23 25
10 0
47 20
45 18
27 0
39 16
42 17
33 7
36 15
43 17
31 2
46 18
37 15
38 16
48 21
34 8
end_mutex_group
begin_mutex_group
6
23 26
2 0
40 18
47 21
48 22
34 9
end_mutex_group
begin_mutex_group
6
3 0
47 22
33 8
31 3
46 19
48 23
end_mutex_group
begin_mutex_group
25
23 1
47 0
47 1
47 2
47 3
47 4
47 5
47 6
47 7
47 8
47 9
47 10
47 11
47 12
47 13
47 14
47 15
47 16
47 17
47 18
47 19
47 20
47 21
47 22
47 23
end_mutex_group
begin_mutex_group
3
23 2
50 1
1 0
end_mutex_group
begin_mutex_group
8
23 3
32 0
32 1
32 2
32 3
32 4
32 5
32 6
end_mutex_group
begin_mutex_group
3
23 4
50 2
53 0
end_mutex_group
begin_mutex_group
21
23 5
45 0
45 1
45 2
45 3
45 4
45 5
45 6
45 7
45 8
45 9
45 10
45 11
45 12
45 13
45 14
45 15
45 16
45 17
45 18
45 19
end_mutex_group
begin_mutex_group
3
23 6
27 0
27 1
end_mutex_group
begin_mutex_group
19
23 7
39 0
39 1
39 2
39 3
39 4
39 5
39 6
39 7
39 8
39 9
39 10
39 11
39 12
39 13
39 14
39 15
39 16
39 17
end_mutex_group
begin_mutex_group
4
23 8
25 0
25 1
25 2
end_mutex_group
begin_mutex_group
20
23 9
42 0
42 1
42 2
42 3
42 4
42 5
42 6
42 7
42 8
42 9
42 10
42 11
42 12
42 13
42 14
42 15
42 16
42 17
42 18
end_mutex_group
begin_mutex_group
11
23 10
33 0
33 1
33 2
33 3
33 4
33 5
33 6
33 7
33 8
33 9
end_mutex_group
begin_mutex_group
3
23 11
52 1
0 0
end_mutex_group
begin_mutex_group
18
23 12
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
36 15
36 16
end_mutex_group
begin_mutex_group
4
23 13
29 0
29 1
29 2
end_mutex_group
begin_mutex_group
20
23 14
43 0
43 1
43 2
43 3
43 4
43 5
43 6
43 7
43 8
43 9
43 10
43 11
43 12
43 13
43 14
43 15
43 16
43 17
43 18
end_mutex_group
begin_mutex_group
6
23 15
31 0
31 1
31 2
31 3
31 4
end_mutex_group
begin_mutex_group
22
23 16
46 0
46 1
46 2
46 3
46 4
46 5
46 6
46 7
46 8
46 9
46 10
46 11
46 12
46 13
46 14
46 15
46 16
46 17
46 18
46 19
46 20
end_mutex_group
begin_mutex_group
3
23 17
52 2
54 0
end_mutex_group
begin_mutex_group
18
23 18
37 0
37 1
37 2
37 3
37 4
37 5
37 6
37 7
37 8
37 9
37 10
37 11
37 12
37 13
37 14
37 15
37 16
end_mutex_group
begin_mutex_group
19
23 19
38 0
38 1
38 2
38 3
38 4
38 5
38 6
38 7
38 8
38 9
38 10
38 11
38 12
38 13
38 14
38 15
38 16
38 17
end_mutex_group
begin_mutex_group
19
23 20
41 0
41 1
41 2
41 3
41 4
41 5
41 6
41 7
41 8
41 9
41 10
41 11
41 12
41 13
41 14
41 15
41 16
41 17
end_mutex_group
begin_mutex_group
26
23 21
48 0
48 1
48 2
48 3
48 4
48 5
48 6
48 7
48 8
48 9
48 10
48 11
48 12
48 13
48 14
48 15
48 16
48 17
48 18
48 19
48 20
48 21
48 22
48 23
48 24
end_mutex_group
begin_mutex_group
3
23 22
24 0
24 1
end_mutex_group
begin_mutex_group
12
23 23
34 0
34 1
34 2
34 3
34 4
34 5
34 6
34 7
34 8
34 9
34 10
end_mutex_group
begin_mutex_group
20
23 24
44 0
44 1
44 2
44 3
44 4
44 5
44 6
44 7
44 8
44 9
44 10
44 11
44 12
44 13
44 14
44 15
44 16
44 17
44 18
end_mutex_group
begin_mutex_group
3
23 25
26 0
26 1
end_mutex_group
begin_mutex_group
3
23 26
30 1
55 0
end_mutex_group
begin_mutex_group
2
0 0
28 1
end_mutex_group
begin_mutex_group
2
1 1
25 0
end_mutex_group
begin_mutex_group
2
3 0
23 4
end_mutex_group
begin_mutex_group
2
3 0
23 17
end_mutex_group
begin_mutex_group
2
3 0
23 22
end_mutex_group
begin_mutex_group
2
3 0
24 0
end_mutex_group
begin_mutex_group
2
3 0
24 2
end_mutex_group
begin_mutex_group
2
3 0
33 4
end_mutex_group
begin_mutex_group
2
3 0
50 2
end_mutex_group
begin_mutex_group
2
3 0
52 2
end_mutex_group
begin_mutex_group
2
4 0
23 4
end_mutex_group
begin_mutex_group
2
4 0
23 22
end_mutex_group
begin_mutex_group
2
4 0
24 0
end_mutex_group
begin_mutex_group
2
4 0
24 2
end_mutex_group
begin_mutex_group
2
4 0
33 4
end_mutex_group
begin_mutex_group
2
4 0
50 2
end_mutex_group
begin_mutex_group
2
5 0
23 4
end_mutex_group
begin_mutex_group
2
5 0
24 2
end_mutex_group
begin_mutex_group
2
5 0
33 4
end_mutex_group
begin_mutex_group
2
5 0
50 2
end_mutex_group
begin_mutex_group
2
6 0
25 3
end_mutex_group
begin_mutex_group
2
10 0
26 2
end_mutex_group
begin_mutex_group
2
9 0
31 5
end_mutex_group
begin_mutex_group
2
8 0
29 3
end_mutex_group
begin_mutex_group
2
11 0
33 10
end_mutex_group
begin_mutex_group
2
13 0
37 17
end_mutex_group
begin_mutex_group
2
12 0
34 11
end_mutex_group
begin_mutex_group
2
14 0
36 17
end_mutex_group
begin_mutex_group
2
17 0
23 4
end_mutex_group
begin_mutex_group
2
17 0
23 22
end_mutex_group
begin_mutex_group
2
17 0
24 0
end_mutex_group
begin_mutex_group
2
17 0
24 2
end_mutex_group
begin_mutex_group
2
17 0
33 4
end_mutex_group
begin_mutex_group
2
17 0
45 20
end_mutex_group
begin_mutex_group
2
17 0
50 2
end_mutex_group
begin_mutex_group
2
18 0
43 19
end_mutex_group
begin_mutex_group
2
15 0
23 4
end_mutex_group
begin_mutex_group
2
15 0
33 4
end_mutex_group
begin_mutex_group
2
15 0
38 18
end_mutex_group
begin_mutex_group
2
15 0
50 2
end_mutex_group
begin_mutex_group
2
15 1
23 22
end_mutex_group
begin_mutex_group
2
15 1
24 2
end_mutex_group
begin_mutex_group
2
16 0
39 18
end_mutex_group
begin_mutex_group
2
19 0
42 19
end_mutex_group
begin_mutex_group
2
21 0
46 21
end_mutex_group
begin_mutex_group
2
20 0
23 27
end_mutex_group
begin_mutex_group
2
22 0
47 24
end_mutex_group
begin_mutex_group
2
23 0
24 2
end_mutex_group
begin_mutex_group
2
23 0
25 3
end_mutex_group
begin_mutex_group
2
23 0
26 2
end_mutex_group
begin_mutex_group
2
23 0
27 2
end_mutex_group
begin_mutex_group
2
23 0
28 1
end_mutex_group
begin_mutex_group
2
23 0
30 2
end_mutex_group
begin_mutex_group
2
23 0
31 5
end_mutex_group
begin_mutex_group
2
23 0
33 10
end_mutex_group
begin_mutex_group
2
23 0
42 19
end_mutex_group
begin_mutex_group
2
23 0
36 17
end_mutex_group
begin_mutex_group
2
23 0
43 19
end_mutex_group
begin_mutex_group
2
23 0
46 21
end_mutex_group
begin_mutex_group
2
23 0
37 17
end_mutex_group
begin_mutex_group
2
23 0
38 18
end_mutex_group
begin_mutex_group
2
23 0
45 20
end_mutex_group
begin_mutex_group
2
23 0
39 18
end_mutex_group
begin_mutex_group
2
23 0
29 3
end_mutex_group
begin_mutex_group
2
23 0
32 7
end_mutex_group
begin_mutex_group
2
23 0
41 18
end_mutex_group
begin_mutex_group
2
23 0
44 19
end_mutex_group
begin_mutex_group
2
23 0
47 24
end_mutex_group
begin_mutex_group
2
23 0
48 25
end_mutex_group
begin_mutex_group
2
23 0
34 11
end_mutex_group
begin_mutex_group
2
23 1
24 2
end_mutex_group
begin_mutex_group
2
23 1
25 3
end_mutex_group
begin_mutex_group
2
23 1
26 2
end_mutex_group
begin_mutex_group
2
23 1
27 2
end_mutex_group
begin_mutex_group
2
23 1
28 1
end_mutex_group
begin_mutex_group
2
23 1
30 2
end_mutex_group
begin_mutex_group
2
23 1
31 5
end_mutex_group
begin_mutex_group
2
23 1
33 10
end_mutex_group
begin_mutex_group
2
23 1
42 19
end_mutex_group
begin_mutex_group
2
23 1
36 17
end_mutex_group
begin_mutex_group
2
23 1
43 19
end_mutex_group
begin_mutex_group
2
23 1
46 21
end_mutex_group
begin_mutex_group
2
23 1
37 17
end_mutex_group
begin_mutex_group
2
23 1
38 18
end_mutex_group
begin_mutex_group
2
23 1
45 20
end_mutex_group
begin_mutex_group
2
23 1
39 18
end_mutex_group
begin_mutex_group
2
23 1
29 3
end_mutex_group
begin_mutex_group
2
23 1
32 7
end_mutex_group
begin_mutex_group
2
23 1
41 18
end_mutex_group
begin_mutex_group
2
23 1
44 19
end_mutex_group
begin_mutex_group
2
23 1
48 25
end_mutex_group
begin_mutex_group
2
23 1
34 11
end_mutex_group
begin_mutex_group
2
23 2
24 2
end_mutex_group
begin_mutex_group
2
23 2
25 3
end_mutex_group
begin_mutex_group
2
23 2
26 2
end_mutex_group
begin_mutex_group
2
23 2
27 2
end_mutex_group
begin_mutex_group
2
23 2
28 1
end_mutex_group
begin_mutex_group
2
23 2
30 2
end_mutex_group
begin_mutex_group
2
23 2
31 5
end_mutex_group
begin_mutex_group
2
23 2
33 10
end_mutex_group
begin_mutex_group
2
23 2
42 19
end_mutex_group
begin_mutex_group
2
23 2
36 17
end_mutex_group
begin_mutex_group
2
23 2
43 19
end_mutex_group
begin_mutex_group
2
23 2
46 21
end_mutex_group
begin_mutex_group
2
23 2
37 17
end_mutex_group
begin_mutex_group
2
23 2
38 18
end_mutex_group
begin_mutex_group
2
23 2
45 20
end_mutex_group
begin_mutex_group
2
23 2
39 18
end_mutex_group
begin_mutex_group
2
23 2
29 3
end_mutex_group
begin_mutex_group
2
23 2
32 7
end_mutex_group
begin_mutex_group
2
23 2
41 18
end_mutex_group
begin_mutex_group
2
23 2
44 19
end_mutex_group
begin_mutex_group
2
23 2
47 24
end_mutex_group
begin_mutex_group
2
23 2
48 25
end_mutex_group
begin_mutex_group
2
23 2
34 11
end_mutex_group
begin_mutex_group
2
23 3
24 2
end_mutex_group
begin_mutex_group
2
23 3
25 3
end_mutex_group
begin_mutex_group
2
23 3
26 2
end_mutex_group
begin_mutex_group
2
23 3
27 2
end_mutex_group
begin_mutex_group
2
23 3
28 1
end_mutex_group
begin_mutex_group
2
23 3
30 2
end_mutex_group
begin_mutex_group
2
23 3
31 5
end_mutex_group
begin_mutex_group
2
23 3
33 10
end_mutex_group
begin_mutex_group
2
23 3
42 19
end_mutex_group
begin_mutex_group
2
23 3
36 17
end_mutex_group
begin_mutex_group
2
23 3
43 19
end_mutex_group
begin_mutex_group
2
23 3
46 21
end_mutex_group
begin_mutex_group
2
23 3
37 17
end_mutex_group
begin_mutex_group
2
23 3
38 18
end_mutex_group
begin_mutex_group
2
23 3
45 20
end_mutex_group
begin_mutex_group
2
23 3
39 18
end_mutex_group
begin_mutex_group
2
23 3
29 3
end_mutex_group
begin_mutex_group
2
23 3
41 18
end_mutex_group
begin_mutex_group
2
23 3
44 19
end_mutex_group
begin_mutex_group
2
23 3
47 24
end_mutex_group
begin_mutex_group
2
23 3
48 25
end_mutex_group
begin_mutex_group
2
23 3
34 11
end_mutex_group
begin_mutex_group
2
23 4
24 1
end_mutex_group
begin_mutex_group
2
23 4
24 2
end_mutex_group
begin_mutex_group
2
23 4
25 3
end_mutex_group
begin_mutex_group
2
23 4
26 2
end_mutex_group
begin_mutex_group
2
23 4
27 2
end_mutex_group
begin_mutex_group
2
23 4
28 1
end_mutex_group
begin_mutex_group
2
23 4
30 2
end_mutex_group
begin_mutex_group
2
23 4
31 1
end_mutex_group
begin_mutex_group
2
23 4
31 3
end_mutex_group
begin_mutex_group
2
23 4
31 5
end_mutex_group
begin_mutex_group
2
23 4
33 4
end_mutex_group
begin_mutex_group
2
23 4
33 6
end_mutex_group
begin_mutex_group
2
23 4
33 8
end_mutex_group
begin_mutex_group
2
23 4
33 10
end_mutex_group
begin_mutex_group
2
23 4
42 13
end_mutex_group
begin_mutex_group
2
23 4
42 14
end_mutex_group
begin_mutex_group
2
23 4
42 19
end_mutex_group
begin_mutex_group
2
23 4
36 10
end_mutex_group
begin_mutex_group
2
23 4
36 11
end_mutex_group
begin_mutex_group
2
23 4
36 12
end_mutex_group
begin_mutex_group
2
23 4
36 17
end_mutex_group
begin_mutex_group
2
23 4
43 4
end_mutex_group
begin_mutex_group
2
23 4
43 12
end_mutex_group
begin_mutex_group
2
23 4
43 13
end_mutex_group
begin_mutex_group
2
23 4
43 14
end_mutex_group
begin_mutex_group
2
23 4
43 19
end_mutex_group
begin_mutex_group
2
23 4
46 4
end_mutex_group
begin_mutex_group
2
23 4
46 11
end_mutex_group
begin_mutex_group
2
23 4
46 12
end_mutex_group
begin_mutex_group
2
23 4
46 13
end_mutex_group
begin_mutex_group
2
23 4
46 14
end_mutex_group
begin_mutex_group
2
23 4
46 15
end_mutex_group
begin_mutex_group
2
23 4
46 19
end_mutex_group
begin_mutex_group
2
23 4
46 21
end_mutex_group
begin_mutex_group
2
23 4
37 4
end_mutex_group
begin_mutex_group
2
23 4
37 10
end_mutex_group
begin_mutex_group
2
23 4
37 11
end_mutex_group
begin_mutex_group
2
23 4
37 12
end_mutex_group
begin_mutex_group
2
23 4
37 17
end_mutex_group
begin_mutex_group
2
23 4
38 0
end_mutex_group
begin_mutex_group
2
23 4
38 1
end_mutex_group
begin_mutex_group
2
23 4
38 2
end_mutex_group
begin_mutex_group
2
23 4
38 3
end_mutex_group
begin_mutex_group
2
23 4
38 5
end_mutex_group
begin_mutex_group
2
23 4
38 6
end_mutex_group
begin_mutex_group
2
23 4
38 7
end_mutex_group
begin_mutex_group
2
23 4
38 8
end_mutex_group
begin_mutex_group
2
23 4
38 9
end_mutex_group
begin_mutex_group
2
23 4
38 10
end_mutex_group
begin_mutex_group
2
23 4
38 11
end_mutex_group
begin_mutex_group
2
23 4
38 12
end_mutex_group
begin_mutex_group
2
23 4
38 13
end_mutex_group
begin_mutex_group
2
23 4
38 14
end_mutex_group
begin_mutex_group
2
23 4
38 15
end_mutex_group
begin_mutex_group
2
23 4
38 16
end_mutex_group
begin_mutex_group
2
23 4
38 17
end_mutex_group
begin_mutex_group
2
23 4
38 18
end_mutex_group
begin_mutex_group
2
23 4
45 0
end_mutex_group
begin_mutex_group
2
23 4
45 1
end_mutex_group
begin_mutex_group
2
23 4
45 2
end_mutex_group
begin_mutex_group
2
23 4
45 3
end_mutex_group
begin_mutex_group
2
23 4
45 4
end_mutex_group
begin_mutex_group
2
23 4
45 5
end_mutex_group
begin_mutex_group
2
23 4
45 6
end_mutex_group
begin_mutex_group
2
23 4
45 7
end_mutex_group
begin_mutex_group
2
23 4
45 8
end_mutex_group
begin_mutex_group
2
23 4
45 9
end_mutex_group
begin_mutex_group
2
23 4
45 10
end_mutex_group
begin_mutex_group
2
23 4
45 11
end_mutex_group
begin_mutex_group
2
23 4
45 13
end_mutex_group
begin_mutex_group
2
23 4
45 14
end_mutex_group
begin_mutex_group
2
23 4
45 15
end_mutex_group
begin_mutex_group
2
23 4
45 16
end_mutex_group
begin_mutex_group
2
23 4
45 17
end_mutex_group
begin_mutex_group
2
23 4
45 18
end_mutex_group
begin_mutex_group
2
23 4
45 19
end_mutex_group
begin_mutex_group
2
23 4
45 20
end_mutex_group
begin_mutex_group
2
23 4
39 11
end_mutex_group
begin_mutex_group
2
23 4
39 12
end_mutex_group
begin_mutex_group
2
23 4
39 13
end_mutex_group
begin_mutex_group
2
23 4
39 18
end_mutex_group
begin_mutex_group
2
23 4
29 1
end_mutex_group
begin_mutex_group
2
23 4
29 3
end_mutex_grou




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1 0
0 44 -1 3
1
end_operator
begin_operator
stack b6 b16
0
4
0 23 24 0
0 16 0 1
0 51 -1 0
0 44 -1 4
1
end_operator
begin_operator
stack b6 b17
0
4
0 23 24 0
0 6 0 1
0 51 -1 0
0 44 -1 5
1
end_operator
begin_operator
stack b6 b18
0
4
0 23 24 0
0 19 0 1
0 51 -1 0
0 44 -1 6
1
end_operator
begin_operator
stack b6 b19
0
4
0 23 24 0
0 11 0 1
0 51 -1 0
0 44 -1 7
1
end_operator
begin_operator
stack b6 b20
0
4
0 23 24 0
0 14 0 1
0 51 -1 0
0 44 -1 8
1
end_operator
begin_operator
stack b6 b21
0
4
0 23 24 0
0 8 0 1
0 51 -1 0
0 44 -1 9
1
end_operator
begin_operator
stack b6 b22
0
4
0 23 24 0
0 18 0 1
0 51 -1 0
0 44 -1 10
1
end_operator
begin_operator
stack b6 b24
0
4
0 23 24 0
0 21 0 1
0 51 -1 0
0 44 -1 11
1
end_operator
begin_operator
stack b6 b25
0
4
0 23 24 0
0 4 0 1
0 51 -1 0
0 44 -1 12
1
end_operator
begin_operator
stack b6 b27
0
4
0 23 24 0
0 15 0 1
0 51 -1 0
0 44 -1 13
1
end_operator
begin_operator
stack b6 b28
0
4
0 23 24 0
0 50 0 3
0 51 -1 0
0 44 -1 14
1
end_operator
begin_operator
stack b6 b3
0
4
0 23 24 0
0 52 0 3
0 51 -1 0
0 44 -1 15
1
end_operator
begin_operator
stack b6 b4
0
4
0 23 24 0
0 5 0 1
0 51 -1 0
0 44 -1 16
1
end_operator
begin_operator
stack b6 b5
0
4
0 23 24 0
0 12 0 1
0 51 -1 0
0 44 -1 17
1
end_operator
begin_operator
stack b7 b23
0
4
0 23 25 0
0 9 0 1
0 10 -1 0
0 26 -1 0
1
end_operator
begin_operator
unstack b1 b10
0
4
0 23 0 1
0 22 0 1
0 20 -1 0
0 47 0 24
1
end_operator
begin_operator
unstack b1 b11
0
4
0 23 0 1
0 22 0 1
0 7 -1 0
0 47 1 24
1
end_operator
begin_operator
unstack b1 b12
0
4
0 23 0 1
0 22 0 1
0 49 -1 0
0 47 2 24
1
end_operator
begin_operator
unstack b1 b13
0
4
0 23 0 1
0 22 0 1
0 35 -1 0
0 47 3 24
1
end_operator
begin_operator
unstack b1 b14
0
4
0 23 0 1
0 22 0 1
0 17 -1 0
0 47 4 24
1
end_operator
begin_operator
unstack b1 b16
0
4
0 23 0 1
0 22 0 1
0 16 -1 0
0 47 5 24
1
end_operator
begin_operator
unstack b1 b18
0
4
0 23 0 1
0 22 0 1
0 19 -1 0
0 47 6 24
1
end_operator
begin_operator
unstack b1 b19
0
4
0 23 0 1
0 22 0 1
0 11 -1 0
0 47 7 24
1
end_operator
begin_operator
unstack b1 b20
0
4
0 23 0 1
0 22 0 1
0 14 -1 0
0 47 8 24
1
end_operator
begin_operator
unstack b1 b21
0
4
0 23 0 1
0 22 0 1
0 8 -1 0
0 47 9 24
1
end_operator
begin_operator
unstack b1 b22
0
4
0 23 0 1
0 22 0 1
0 18 -1 0
0 47 10 24
1
end_operator
begin_operator
unstack b1 b23
0
4
0 23 0 1
0 22 0 1
0 9 -1 0
0 47 11 24
1
end_operator
begin_operator
unstack b1 b24
0
4
0 23 0 1
0 22 0 1
0 21 -1 0
0 47 12 24
1
end_operator
begin_operator
unstack b1 b25
0
4
0 23 0 1
0 22 0 1
0 4 -1 0
0 47 13 24
1
end_operator
begin_operator
unstack b1 b26
0
4
0 23 0 1
0 22 0 1
0 13 -1 0
0 47 14 24
1
end_operator
begin_operator
unstack b1 b27
0
4
0 23 0 1
0 22 0 1
0 15 -1 0
0 47 15 24
1
end_operator
begin_operator
unstack b1 b28
0
4
0 23 0 1
0 22 0 1
0 50 -1 0
0 47 16 24
1
end_operator
begin_operator
unstack b1 b4
0
4
0 23 0 1
0 22 0 1
0 5 -1 0
0 47 17 24
1
end_operator
begin_operator
unstack b1 b5
0
4
0 23 0 1
0 22 0 1
0 12 -1 0
0 47 18 24
1
end_operator
begin_operator
unstack b1 b6
0
4
0 23 0 1
0 22 0 1
0 51 -1 0
0 47 19 24
1
end_operator
begin_operator
unstack b1 b7
0
4
0 23 0 1
0 22 0 1
0 10 -1 0
0 47 20 24
1
end_operator
begin_operator
unstack b1 b8
0
4
0 23 0 1
0 22 0 1
0 2 -1 0
0 47 21 24
1
end_operator
begin_operator
unstack b1 b9
0
4
0 23 0 1
0 22 0 1
0 3 -1 0
0 47 22 24
1
end_operator
begin_operator
unstack b10 b1
0
4
0 23 0 27
0 22 -1 0
0 20 0 1
0 40 1 0
1
end_operator
begin_operator
unstack b10 b12
0
4
0 23 0 27
0 20 0 1
0 49 -1 0
0 40 2 0
1
end_operator
begin_operator
unstack b10 b14
0
4
0 23 0 27
0 20 0 1
0 17 -1 0
0 40 3 0
1
end_operator
begin_operator
unstack b10 b16
0
4
0 23 0 27
0 20 0 1
0 16 -1 0
0 40 4 0
1
end_operator
begin_operator
unstack b10 b17
0
4
0 23 0 27
0 20 0 1
0 6 -1 0
0 40 5 0
1
end_operator
begin_operator
unstack b10 b18
0
4
0 23 0 27
0 20 0 1
0 19 -1 0
0 40 6 0
1
end_operator
begin_operator
unstack b10 b19
0
4
0 23 0 27
0 20 0 1
0 11 -1 0
0 40 7 0
1
end_operator
begin_operator
unstack b10 b20
0
4
0 23 0 27
0 20 0 1
0 14 -1 0
0 40 8 0
1
end_operator
begin_operator
unstack b10 b21
0
4
0 23 0 27
0 20 0 1
0 8 -1 0
0 40 9 0
1
end_operator
begin_operator
unstack b10 b22
0
4
0 23 0 27
0 20 0 1
0 18 -1 0
0 40 10 0
1
end_operator
begin_operator
unstack b10 b24
0
4
0 23 0 27
0 20 0 1
0 21 -1 0
0 40 11 0
1
end_operator
begin_operator
unstack b10 b26
0
4
0 23 0 27
0 20 0 1
0 13 -1 0
0 40 12 0
1
end_operator
begin_operator
unstack b10 b27
0
4
0 23 0 27
0 20 0 1
0 15 -1 0
0 40 13 0
1
end_operator
begin_operator
unstack b10 b28
0
4
0 23 0 27
0 20 0 1
0 50 -1 0
0 40 14 0
1
end_operator
begin_operator
unstack b10 b3
0
4
0 23 0 27
0 20 0 1
0 52 -1 0
0 40 15 0
1
end_operator
begin_operator
unstack b10 b5
0
4
0 23 0 27
0 20 0 1
0 12 -1 0
0 40 16 0
1
end_operator
begin_operator
unstack b10 b6
0
4
0 23 0 27
0 20 0 1
0 51 -1 0
0 40 17 0
1
end_operator
begin_operator
unstack b10 b8
0
4
0 23 0 27
0 20 0 1
0 2 -1 0
0 40 18 0
1
end_operator
begin_operator
unstack b11 b28
0
3
0 23 0 2
0 7 0 1
0 50 1 0
1
end_operator
begin_operator
unstack b12 b10
0
4
0 23 0 3
0 20 -1 0
0 49 0 1
0 32 0 7
1
end_operator
begin_operator
unstack b12 b14
0
4
0 23 0 3
0 49 0 1
0 17 -1 0
0 32 1 7
1
end_operator
begin_operator
unstack b12 b18
0
4
0 23 0 3
0 49 0 1
0 19 -1 0
0 32 2 7
1
end_operator
begin_operator
unstack b12 b28
0
4
0 23 0 3
0 49 0 1
0 50 -1 0
0 32 4 7
1
end_operator
begin_operator
unstack b12 b3
0
4
0 23 0 3
0 49 0 1
0 52 -1 0
0 32 5 7
1
end_operator
begin_operator
unstack b13 b28
0
3
0 23 0 4
0 35 0 1
0 50 2 0
1
end_operator
begin_operator
unstack b14 b1
0
4
0 23 0 5
0 22 -1 0
0 17 0 1
0 45 0 20
1
end_operator
begin_operator
unstack b14 b10
0
4
0 23 0 5
0 20 -1 0
0 17 0 1
0 45 1 20
1
end_operator
begin_operator
unstack b14 b11
0
4
0 23 0 5
0 7 -1 0
0 17 0 1
0 45 2 20
1
end_operator
begin_operator
unstack b14 b12
0
4
0 23 0 5
0 49 -1 0
0 17 0 1
0 45 3 20
1
end_operator
begin_operator
unstack b14 b16
0
4
0 23 0 5
0 17 0 1
0 16 -1 0
0 45 4 20
1
end_operator
begin_operator
unstack b14 b17
0
4
0 23 0 5
0 17 0 1
0 6 -1 0
0 45 5 20
1
end_operator
begin_operator
unstack b14 b18
0
4
0 23 0 5
0 17 0 1
0 19 -1 0
0 45 6 20
1
end_operator
begin_operator
unstack b14 b19
0
4
0 23 0 5
0 17 0 1
0 11 -1 0
0 45 7 20
1
end_operator
begin_operator
unstack b14 b20
0
4
0 23 0 5
0 17 0 1
0 14 -1 0
0 45 8 20
1
end_operator
begin_operator
unstack b14 b22
0
4
0 23 0 5
0 17 0 1
0 18 -1 0
0 45 9 20
1
end_operator
begin_operator
unstack b14 b23
0
4
0 23 0 5
0 17 0 1
0 9 -1 0
0 45 10 20
1
end_operator
begin_operator
unstack b14 b24
0
4
0 23 0 5
0 17 0 1
0 21 -1 0
0 45 11 20
1
end_operator
begin_operator
unstack b14 b25
0
4
0 23 0 5
0 17 0 1
0 4 -1 0
0 45 12 20
1
end_operator
begin_operator
unstack b14 b26
0
4
0 23 0 5
0 17 0 1
0 13 -1 0
0 45 13 20
1
end_operator
begin_operator
unstack b14 b27
0
4
0 23 0 5
0 17 0 1
0 15 -1 0
0 45 14 20
1
end_operator
begin_operator
unstack b14 b28
0
4
0 23 0 5
0 17 0 1
0 50 -1 0
0 45 15 20
1
end_operator
begin_operator
unstack b14 b5
0
4
0 23 0 5
0 17 0 1
0 12 -1 0
0 45 16 20
1
end_operator
begin_operator
unstack b14 b6
0
4
0 23 0 5
0 17 0 1
0 51 -1 0
0 45 17 20
1
end_operator
begin_operator
unstack b14 b7
0
4
0 23 0 5
0 17 0 1
0 10 -1 0
0 45 18 20
1
end_operator
begin_operator
unstack b16 b1
0
4
0 23 0 7
0 22 -1 0
0 16 0 1
0 39 0 18
1
end_operator
begin_operator
unstack b16 b10
0
4
0 23 0 7
0 20 -1 0
0 16 0 1
0 39 1 18
1
end_operator
begin_operator
unstack b16 b11
0
4
0 23 0 7
0 7 -1 0
0 16 0 1
0 39 2 18
1
end_operator
begin_operator
unstack b16 b12
0
4
0 23 0 7
0 49 -1 0
0 16 0 1
0 39 3 18
1
end_operator
begin_operator
unstack b16 b17
0
4
0 23 0 7
0 16 0 1
0 6 -1 0
0 39 4 18
1
end_operator
begin_operator
unstack b16 b18
0
4
0 23 0 7
0 16 0 1
0 19 -1 0
0 39 5 18
1
end_operator
begin_operator
unstack b16 b19
0
4
0 23 0 7
0 16 0 1
0 11 -1 0
0 39 6 18
1
end_operator
begin_operator
unstack b16 b20
0
4
0 23 0 7
0 16 0 1
0 14 -1 0
0 39 7 18
1
end_operator
begin_operator
unstack b16 b21
0
4
0 23 0 7
0 16 0 1
0 8 -1 0
0 39 8 18
1
end_operator
begin_operator
unstack b16 b23
0
4
0 23 0 7
0 16 0 1
0 9 -1 0
0 39 9 18
1
end_operator
begin_operator
unstack b16 b24
0
4
0 23 0 7
0 16 0 1
0 21 -1 0
0 39 10 18
1
end_operator
begin_operator
unstack b16 b27
0
4
0 23 0 7
0 16 0 1
0 15 -1 0
0 39 11 18
1
end_operator
begin_operator
unstack b16 b28
0
4
0 23 0 7
0 16 0 1
0 50 -1 0
0 39 12 18
1
end_operator
begin_operator
unstack b16 b3
0
4
0 23 0 7
0 16 0 1
0 52 -1 0
0 39 13 18
1
end_operator
begin_operator
unstack b16 b5
0
4
0 23 0 7
0 16 0 1
0 12 -1 0
0 39 14 18
1
end_operator
begin_operator
unstack b16 b6
0
4
0 23 0 7
0 16 0 1
0 51 -1 0
0 39 15 18
1
end_operator
begin_operator
unstack b16 b7
0
4
0 23 0 7
0 16 0 1
0 10 -1 0
0 39 16 18
1
end_operator
begin_operator
unstack b17 b11
0
4
0 23 0 8
0 7 -1 0
0 6 0 1
0 25 0 3
1
end_operator
begin_operator
unstack b18 b1
0
4
0 23 0 9
0 22 -1 0
0 19 0 1
0 42 0 19
1
end_operator
begin_operator
unstack b18 b10
0
4
0 23 0 9
0 20 -1 0
0 19 0 1
0 42 1 19
1
end_operator
begin_operator
unstack b18 b11
0
4
0 23 0 9
0 7 -1 0
0 19 0 1
0 42 2 19
1
end_operator
begin_operator
unstack b18 b12
0
4
0 23 0 9
0 49 -1 0
0 19 0 1
0 42 3 19
1
end_operator
begin_operator
unstack b18 b13
0
4
0 23 0 9
0 35 -1 0
0 19 0 1
0 42 4 19
1
end_operator
begin_operator
unstack b18 b16
0
4
0 23 0 9
0 16 -1 0
0 19 0 1
0 42 5 19
1
end_operator
begin_operator
unstack b18 b17
0
4
0 23 0 9
0 6 -1 0
0 19 0 1
0 42 6 19
1
end_operator
begin_operator
unstack b18 b19
0
4
0 23 0 9
0 19 0 1
0 11 -1 0
0 42 7 19
1
end_operator
begin_operator
unstack b18 b20
0
4
0 23 0 9
0 19 0 1
0 14 -1 0
0 42 8 19
1
end_operator
begin_operator
unstack b18 b22
0
4
0 23 0 9
0 19 0 1
0 18 -1 0
0 42 9 19
1
end_operator
begin_operator
unstack b18 b23
0
4
0 23 0 9
0 19 0 1
0 9 -1 0
0 42 10 19
1
end_operator
begin_operator
unstack b18 b24
0
4
0 23 0 9
0 19 0 1
0 21 -1 0
0 42 11 19
1
end_operator
begin_operator
unstack b18 b26
0
4
0 23 0 9
0 19 0 1
0 13 -1 0
0 42 12 19
1
end_operator
begin_operator
unstack b18 b27
0
4
0 23 0 9
0 19 0 1
0 15 -1 0
0 42 13 19
1
end_operator
begin_operator
unstack b18 b3
0
4
0 23 0 9
0 19 0 1
0 52 -1 0
0 42 14 19
1
end_operator
begin_operator
unstack b18 b5
0
4
0 23 0 9
0 19 0 1
0 12 -1 0
0 42 15 19
1
end_operator
begin_operator
unstack b18 b6
0
4
0 23 0 9
0 19 0 1
0 51 -1 0
0 42 16 19
1
end_operator
begin_operator
unstack b18 b7
0
4
0 23 0 9
0 19 0 1
0 10 -1 0
0 42 17 19
1
end_operator
begin_operator
unstack b19 b10
0
4
0 23 0 10
0 20 -1 0
0 11 0 1
0 33 0 10
1
end_operator
begin_operator
unstack b19 b11
0
4
0 23 0 10
0 7 -1 0
0 11 0 1
0 33 1 10
1
end_operator
begin_operator
unstack b19 b16
0
4
0 23 0 10
0 16 -1 0
0 11 0 1
0 33 2 10
1
end_operator
begin_operator
unstack b19 b17
0
4
0 23 0 10
0 6 -1 0
0 11 0 1
0 33 3 10
1
end_operator
begin_operator
unstack b19 b18
0
4
0 23 0 10
0 19 -1 0
0 11 0 1
0 33 4 10
1
end_operator
begin_operator
unstack b19 b23
0
4
0 23 0 10
0 11 0 1
0 9 -1 0
0 33 5 10
1
end_operator
begin_operator
unstack b19 b3
0
4
0 23 0 10
0 11 0 1
0 52 -1 0
0 33 6 10
1
end_operator
begin_operator
unstack b19 b7
0
4
0 23 0 10
0 11 0 1
0 10 -1 0
0 33 7 10
1
end_operator
begin_operator
unstack b19 b9
0
4
0 23 0 10
0 11 0 1
0 3 -1 0
0 33 8 10
1
end_operator
begin_operator
unstack b2 b3
0
3
0 23 0 11
0 28 0 1
0 52 1 0
1
end_operator
begin_operator
unstack b20 b10
0
4
0 23 0 12
0 20 -1 0
0 14 0 1
0 36 0 17
1
end_operator
begin_operator
unstack b20 b11
0
4
0 23 0 12
0 7 -1 0
0 14 0 1
0 36 1 17
1
end_operator
begin_operator
unstack b20 b12
0
4
0 23 0 12
0 49 -1 0
0 14 0 1
0 36 2 17
1
end_operator
begin_operator
unstack b20 b16
0
4
0 23 0 12
0 16 -1 0
0 14 0 1
0 36 3 17
1
end_operator
begin_operator
unstack b20 b19
0
4
0 23 0 12
0 11 -1 0
0 14 0 1
0 36 4 17
1
end_operator
begin_operator
unstack b20 b21
0
4
0 23 0 12
0 14 0 1
0 8 -1 0
0 36 5 17
1
end_operator
begin_operator
unstack b20 b22
0
4
0 23 0 12
0 14 0 1
0 18 -1 0
0 36 6 17
1
end_operator
begin_operator
unstack b20 b23
0
4
0 23 0 12
0 14 0 1
0 9 -1 0
0 36 7 17
1
end_operator
begin_operator
unstack b20 b24
0
4
0 23 0 12
0 14 0 1
0 21 -1 0
0 36 8 17
1
end_operator
begin_operator
unstack b20 b26
0
4
0 23 0 12
0 14 0 1
0 13 -1 0
0 36 9 17
1
end_operator
begin_operator
unstack b20 b27
0
4
0 23 0 12
0 14 0 1
0 15 -1 0
0 36 10 17
1
end_operator
begin_operator
unstack b20 b28
0
4
0 23 0 12
0 14 0 1
0 50 -1 0
0 36 11 17
1
end_operator
begin_operator
unstack b20 b3
0
4
0 23 0 12
0 14 0 1
0 52 -1 0
0 36 12 17
1
end_operator
begin_operator
unstack b20 b5
0
4
0 23 0 12
0 14 0 1
0 12 -1 0
0 36 13 17
1
end_operator
begin_operator
unstack b20 b6
0
4
0 23 0 12
0 14 0 1
0 51 -1 0
0 36 14 17
1
end_operator
begin_operator
unstack b20 b7
0
4
0 23 0 12
0 14 0 1
0 10 -1 0
0 36 15 17
1
end_operator
begin_operator
unstack b21 b22
0
4
0 23 0 13
0 8 0 1
0 18 -1 0
0 29 0 3
1
end_operator
begin_operator
unstack b22 b1
0
4
0 23 0 14
0 22 -1 0
0 18 0 1
0 43 0 19
1
end_operator
begin_operator
unstack b22 b10
0
4
0 23 0 14
0 20 -1 0
0 18 0 1
0 43 1 19
1
end_operator
begin_operator
unstack b22 b11
0
4
0 23 0 14
0 7 -1 0
0 18 0 1
0 43 2 19
1
end_operator
begin_operator
unstack b22 b12
0
4
0 23 0 14
0 49 -1 0
0 18 0 1
0 43 3 19
1
end_operator
begin_operator
unstack b22 b14
0
4
0 23 0 14
0 17 -1 0
0 18 0 1
0 43 4 19
1
end_operator
begin_operator
unstack b22 b16
0
4
0 23 0 14
0 16 -1 0
0 18 0 1
0 43 5 19
1
end_operator
begin_operator
unstack b22 b18
0
4
0 23 0 14
0 19 -1 0
0 18 0 1
0 43 6 19
1
end_operator
begin_operator
unstack b22 b19
0
4
0 23 0 14
0 11 -1 0
0 18 0 1
0 43 7 19
1
end_operator
begin_operator
unstack b22 b20
0
4
0 23 0 14
0 14 -1 0
0 18 0 1
0 43 8 19
1
end_operator
begin_operator
unstack b22 b21
0
4
0 23 0 14
0 8 -1 0
0 18 0 1
0 43 9 19
1
end_operator
begin_operator
unstack b22 b24
0
4
0 23 0 14
0 18 0 1
0 21 -1 0
0 43 10 19
1
end_operator
begin_operator
unstack b22 b26
0
4
0 23 0 14
0 18 0 1
0 13 -1 0
0 43 11 19
1
end_operator
begin_operator
unstack b22 b27
0
4
0 23 0 14
0 18 0 1
0 15 -1 0
0 43 12 19
1
end_operator
begin_operator
unstack b22 b28
0
4
0 23 0 14
0 18 0 1
0 50 -1 0
0 43 13 19
1
end_operator
begin_operator
unstack b22 b3
0
4
0 23 0 14
0 18 0 1
0 52 -1 0
0 43 14 19
1
end_operator
begin_operator
unstack b22 b5
0
4
0 23 0 14
0 18 0 1
0 12 -1 0
0 43 15 19
1
end_operator
begin_operator
unstack b22 b6
0
4
0 23 0 14
0 18 0 1
0 51 -1 0
0 43 16 19
1
end_operator
begin_operator
unstack b22 b7
0
4
0 23 0 14
0 18 0 1
0 10 -1 0
0 43 17 19
1
end_operator
begin_operator
unstack b23 b11
0
4
0 23 0 15
0 7 -1 0
0 9 0 1
0 31 0 5
1
end_operator
begin_operator
unstack b23 b4
0
4
0 23 0 15
0 9 0 1
0 5 -1 0
0 31 1 5
1
end_operator
begin_operator
unstack b23 b7
0
4
0 23 0 15
0 9 0 1
0 10 -1 0
0 31 2 5
1
end_operator
begin_operator
unstack b23 b9
0
4
0 23 0 15
0 9 0 1
0 3 -1 0
0 31 3 5
1
end_operator
begin_operator
unstack b24 b1
0
4
0 23 0 16
0 22 -1 0
0 21 0 1
0 46 0 21
1
end_operator
begin_operator
unstack b24 b10
0
4
0 23 0 16
0 20 -1 0
0 21 0 1
0 46 1 21
1
end_operator
begin_operator
unstack b24 b12
0
4
0 23 0 16
0 49 -1 0
0 21 0 1
0 46 2 21
1
end_operator
begin_operator
unstack b24 b13
0
4
0 23 0 16
0 35 -1 0
0 21 0 1
0 46 3 21
1
end_operator
begin_operator
unstack b24 b14
0
4
0 23 0 16
0 17 -1 0
0 21 0 1
0 46 4 21
1
end_operator
begin_operator
unstack b24 b17
0
4
0 23 0 16
0 6 -1 0
0 21 0 1
0 46 5 21
1
end_operator
begin_operator
unstack b24 b19
0
4
0 23 0 16
0 11 -1 0
0 21 0 1
0 46 6 21
1
end_operator
begin_operator
unstack b24 b20
0
4
0 23 0 16
0 14 -1 0
0 21 0 1
0 46 7 21
1
end_operator
begin_operator
unstack b24 b21
0
4
0 23 0 16
0 8 -1 0
0 21 0 1
0 46 8 21
1
end_operator
begin_operator
unstack b24 b22
0
4
0 23 0 16
0 18 -1 0
0 21 0 1
0 46 9 21
1
end_operator
begin_operator
unstack b24 b23
0
4
0 23 0 16
0 9 -1 0
0 21 0 1
0 46 10 21
1
end_operator
begin_operator
unstack b24 b25
0
4
0 23 0 16
0 21 0 1
0 4 -1 0
0 46 11 21
1
end_operator
begin_operator
unstack b24 b27
0
4
0 23 0 16
0 21 0 1
0 15 -1 0
0 46 12 21
1
end_operator
begin_operator
unstack b24 b28
0
4
0 23 0 16
0 21 0 1
0 50 -1 0
0 46 13 21
1
end_operator
begin_operator
unstack b24 b3
0
4
0 23 0 16
0 21 0 1
0 52 -1 0
0 46 14 21
1
end_operator
begin_operator
unstack b24 b4
0
4
0 23 0 16
0 21 0 1
0 5 -1 0
0 46 15 21
1
end_operator
begin_operator
unstack b24 b5
0
4
0 23 0 16
0 21 0 1
0 12 -1 0
0 46 16 21
1
end_operator
begin_operator
unstack b24 b6
0
4
0 23 0 16
0 21 0 1
0 51 -1 0
0 46 17 21
1
end_operator
begin_operator
unstack b24 b7
0
4
0 23 0 16
0 21 0 1
0 10 -1 0
0 46 18 21
1
end_operator
begin_operator
unstack b24 b9
0
4
0 23 0 16
0 21 0 1
0 3 -1 0
0 46 19 21
1
end_operator
begin_operator
unstack b25 b3
0
3
0 23 0 17
0 4 0 1
0 52 2 0
1
end_operator
begin_operator
unstack b26 b1
0
4
0 23 0 18
0 22 -1 0
0 13 0 1
0 37 0 17
1
end_operator
begin_operator
unstack b26 b10
0
4
0 23 0 18
0 20 -1 0
0 13 0 1
0 37 1 17
1
end_operator
begin_operator
unstack b26 b11
0
4
0 23 0 18
0 7 -1 0
0 13 0 1
0 37 2 17
1
end_operator
begin_operator
unstack b26 b12
0
4
0 23 0 18
0 49 -1 0
0 13 0 1
0 37 3 17
1
end_operator
begin_operator
unstack b26 b14
0
4
0 23 0 18
0 17 -1 0
0 13 0 1
0 37 4 17
1
end_operator
begin_operator
unstack b26 b16
0
4
0 23 0 18
0 16 -1 0
0 13 0 1
0 37 5 17
1
end_operator
begin_operator
unstack b26 b18
0
4
0 23 0 18
0 19 -1 0
0 13 0 1
0 37 6 17
1
end_operator
begin_operator
unstack b26 b19
0
4
0 23 0 18
0 11 -1 0
0 13 0 1
0 37 7 17
1
end_operator
begin_operator
unstack b26 b20
0
4
0 23 0 18
0 14 -1 0
0 13 0 1
0 37 8 17
1
end_operator
begin_operator
unstack b26 b23
0
4
0 23 0 18
0 9 -1 0
0 13 0 1
0 37 9 17
1
end_operator
begin_operator
unstack b26 b27
0
4
0 23 0 18
0 13 0 1
0 15 -1 0
0 37 10 17
1
end_operator
begin_operator
unstack b26 b28
0
4
0 23 0 18
0 13 0 1
0 50 -1 0
0 37 11 17
1
end_operator
begin_operator
unstack b26 b3
0
4
0 23 0 18
0 13 0 1
0 52 -1 0
0 37 12 17
1
end_operator
begin_operator
unstack b26 b5
0
4
0 23 0 18
0 13 0 1
0 12 -1 0
0 37 13 17
1
end_operator
begin_operator
unstack b26 b6
0
4
0 23 0 18
0 13 0 1
0 51 -1 0
0 37 14 17
1
end_operator
begin_operator
unstack b26 b7
0
4
0 23 0 18
0 13 0 1
0 10 -1 0
0 37 15 17
1
end_operator
begin_operator
unstack b27 b1
0
4
0 23 0 19
0 22 -1 0
0 15 0 1
0 38 0 18
1
end_operator
begin_operator
unstack b27 b10
0
4
0 23 0 19
0 20 -1 0
0 15 0 1
0 38 1 18
1
end_operator
begin_operator
unstack b27 b11
0
4
0 23 0 19
0 7 -1 0
0 15 0 1
0 38 2 18
1
end_operator
begin_operator
unstack b27 b12
0
4
0 23 0 19
0 49 -1 0
0 15 0 1
0 38 3 18
1
end_operator
begin_operator
unstack b27 b14
0
4
0 23 0 19
0 17 -1 0
0 15 0 1
0 38 4 18
1
end_operator
begin_operator
unstack b27 b16
0
4
0 23 0 19
0 16 -1 0
0 15 0 1
0 38 5 18
1
end_operator
begin_operator
unstack b27 b17
0
4
0 23 0 19
0 6 -1 0
0 15 0 1
0 38 6 18
1
end_operator
begin_operator
unstack b27 b19
0
4
0 23 0 19
0 11 -1 0
0 15 0 1
0 38 7 18
1
end_operator
begin_operator
unstack b27 b21
0
4
0 23 0 19
0 8 -1 0
0 15 0 1
0 38 8 18
1
end_operator
begin_operator
unstack b27 b23
0
4
0 23 0 19
0 9 -1 0
0 15 0 1
0 38 9 18
1
end_operator
begin_operator
unstack b27 b24
0
4
0 23 0 19
0 21 -1 0
0 15 0 1
0 38 10 18
1
end_operator
begin_operator
unstack b27 b26
0
4
0 23 0 19
0 13 -1 0
0 15 0 1
0 38 11 18
1
end_operator
begin_operator
unstack b27 b28
0
4
0 23 0 19
0 15 0 1
0 50 -1 0
0 38 12 18
1
end_operator
begin_operator
unstack b27 b3
0
4
0 23 0 19
0 15 0 1
0 52 -1 0
0 38 13 18
1
end_operator
begin_operator
unstack b27 b5
0
4
0 23 0 19
0 15 0 1
0 12 -1 0
0 38 14 18
1
end_operator
begin_operator
unstack b27 b6
0
4
0 23 0 19
0 15 0 1
0 51 -1 0
0 38 15 18
1
end_operator
begin_operator
unstack b27 b7
0
4
0 23 0 19
0 15 0 1
0 10 -1 0
0 38 16 18
1
end_operator
begin_operator
unstack b28 b1
0
4
0 23 0 20
0 22 -1 0
0 50 0 3
0 41 0 18
1
end_operator
begin_operator
unstack b28 b10
0
4
0 23 0 20
0 20 -1 0
0 50 0 3
0 41 1 18
1
end_operator
begin_operator
unstack b28 b12
0
4
0 23 0 20
0 49 -1 0
0 50 0 3
0 41 2 18
1
end_operator
begin_operator
unstack b28 b14
0
4
0 23 0 20
0 17 -1 0
0 50 0 3
0 41 3 18
1
end_operator
begin_operator
unstack b28 b16
0
4
0 23 0 20
0 16 -1 0
0 50 0 3
0 41 4 18
1
end_operator
begin_operator
unstack b28 b17
0
4
0 23 0 20
0 6 -1 0
0 50 0 3
0 41 5 18
1
end_operator
begin_operator
unstack b28 b18
0
4
0 23 0 20
0 19 -1 0
0 50 0 3
0 41 6 18
1
end_operator
begin_operator
unstack b28 b19
0
4
0 23 0 20
0 11 -1 0
0 50 0 3
0 41 7 18
1
end_operator
begin_operator
unstack b28 b20
0
4
0 23 0 20
0 14 -1 0
0 50 0 3
0 41 8 18
1
end_operator
begin_operator
unstack b28 b21
0
4
0 23 0 20
0 8 -1 0
0 50 0 3
0 41 9 18
1
end_operator
begin_operator
unstack b28 b22
0
4
0 23 0 20
0 18 -1 0
0 50 0 3
0 41 10 18
1
end_operator
begin_operator
unstack b28 b24
0
4
0 23 0 20
0 21 -1 0
0 50 0 3
0 41 11 18
1
end_operator
begin_operator
unstack b28 b26
0
4
0 23 0 20
0 13 -1 0
0 50 0 3
0 41 12 18
1
end_operator
begin_operator
unstack b28 b3
0
4
0 23 0 20
0 50 0 3
0 52 -1 0
0 41 13 18
1
end_operator
begin_operator
unstack b28 b4
0
4
0 23 0 20
0 50 0 3
0 5 -1 0
0 41 14 18
1
end_operator
begin_operator
unstack b28 b5
0
4
0 23 0 20
0 50 0 3
0 12 -1 0
0 41 15 18
1
end_operator
begin_operator
unstack b28 b6
0
4
0 23 0 20
0 50 0 3
0 51 -1 0
0 41 16 18
1
end_operator
begin_operator
unstack b3 b1
0
4
0 23 0 21
0 22 -1 0
0 52 0 3
0 48 0 25
1
end_operator
begin_operator
unstack b3 b10
0
4
0 23 0 21
0 20 -1 0
0 52 0 3
0 48 1 25
1
end_operator
begin_operator
unstack b3 b11
0
4
0 23 0 21
0 7 -1 0
0 52 0 3
0 48 2 25
1
end_operator
begin_operator
unstack b3 b12
0
4
0 23 0 21
0 49 -1 0
0 52 0 3
0 48 3 25
1
end_operator
begin_operator
unstack b3 b13
0
4
0 23 0 21
0 35 -1 0
0 52 0 3
0 48 4 25
1
end_operator
begin_operator
unstack b3 b14
0
4
0 23 0 21
0 17 -1 0
0 52 0 3
0 48 5 25
1
end_operator
begin_operator
unstack b3 b16
0
4
0 23 0 21
0 16 -1 0
0 52 0 3
0 48 6 25
1
end_operator
begin_operator
unstack b3 b17
0
4
0 23 0 21
0 6 -1 0
0 52 0 3
0 48 7 25
1
end_operator
begin_operator
unstack b3 b18
0
4
0 23 0 21
0 19 -1 0
0 52 0 3
0 48 8 25
1
end_operator
begin_operator
unstack b3 b19
0
4
0 23 0 21
0 11 -1 0
0 52 0 3
0 48 9 25
1
end_operator
begin_operator
unstack b3 b20
0
4
0 23 0 21
0 14 -1 0
0 52 0 3
0 48 10 25
1
end_operator
begin_operator
unstack b3 b21
0
4
0 23 0 21
0 8 -1 0
0 52 0 3
0 48 11 25
1
end_operator
begin_operator
unstack b3 b22
0
4
0 23 0 21
0 18 -1 0
0 52 0 3
0 48 12 25
1
end_operator
begin_operator
unstack b3 b23
0
4
0 23 0 21
0 9 -1 0
0 52 0 3
0 48 13 25
1
end_operator
begin_operator
unstack b3 b24
0
4
0 23 0 21
0 21 -1 0
0 52 0 3
0 48 14 25
1
end_operator
begin_operator
unstack b3 b25
0
4
0 23 0 21
0 4 -1 0
0 52 0 3
0 48 15 25
1
end_operator
begin_operator
unstack b3 b26
0
4
0 23 0 21
0 13 -1 0
0 52 0 3
0 48 16 25
1
end_operator
begin_operator
unstack b3 b27
0
4
0 23 0 21
0 15 -1 0
0 52 0 3
0 48 17 25
1
end_operator
begin_operator
unstack b3 b4
0
4
0 23 0 21
0 52 0 3
0 5 -1 0
0 48 18 25
1
end_operator
begin_operator
unstack b3 b5
0
4
0 23 0 21
0 52 0 3
0 12 -1 0
0 48 19 25
1
end_operator
begin_operator
unstack b3 b6
0
4
0 23 0 21
0 52 0 3
0 51 -1 0
0 48 20 25
1
end_operator
begin_operator
unstack b3 b7
0
4
0 23 0 21
0 52 0 3
0 10 -1 0
0 48 21 25
1
end_operator
begin_operator
unstack b3 b8
0
4
0 23 0 21
0 52 0 3
0 2 -1 0
0 48 22 25
1
end_operator
begin_operator
unstack b3 b9
0
4
0 23 0 21
0 52 0 3
0 3 -1 0
0 48 23 25
1
end_operator
begin_operator
unstack b4 b27
0
4
0 23 0 22
0 15 -1 0
0 5 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b5 b12
0
4
0 23 0 23
0 49 -1 0
0 12 0 1
0 34 0 11
1
end_operator
begin_operator
unstack b5 b13
0
4
0 23 0 23
0 35 -1 0
0 12 0 1
0 34 1 11
1
end_operator
begin_operator
unstack b5 b18
0
4
0 23 0 23
0 19 -1 0
0 12 0 1
0 34 2 11
1
end_operator
begin_operator
unstack b5 b19
0
4
0 23 0 23
0 11 -1 0
0 12 0 1
0 34 3 11
1
end_operator
begin_operator
unstack b5 b20
0
4
0 23 0 23
0 14 -1 0
0 12 0 1
0 34 4 11
1
end_operator
begin_operator
unstack b5 b21
0
4
0 23 0 23
0 8 -1 0
0 12 0 1
0 34 5 11
1
end_operator
begin_operator
unstack b5 b22
0
4
0 23 0 23
0 18 -1 0
0 12 0 1
0 34 6 11
1
end_operator
begin_operator
unstack b5 b6
0
4
0 23 0 23
0 12 0 1
0 51 -1 0
0 34 7 11
1
end_operator
begin_operator
unstack b5 b7
0
4
0 23 0 23
0 12 0 1
0 10 -1 0
0 34 8 11
1
end_operator
begin_operator
unstack b6 b1
0
4
0 23 0 24
0 22 -1 0
0 51 0 1
0 44 0 19
1
end_operator
begin_operator
unstack b6 b12
0
4
0 23 0 24
0 49 -1 0
0 51 0 1
0 44 1 19
1
end_operator
begin_operator
unstack b6 b13
0
4
0 23 0 24
0 35 -1 0
0 51 0 1
0 44 2 19
1
end_operator
begin_operator
unstack b6 b14
0
4
0 23 0 24
0 17 -1 0
0 51 0 1
0 44 3 19
1
end_operator
begin_operator
unstack b6 b16
0
4
0 23 0 24
0 16 -1 0
0 51 0 1
0 44 4 19
1
end_operator
begin_operator
unstack b6 b17
0
4
0 23 0 24
0 6 -1 0
0 51 0 1
0 44 5 19
1
end_operator
begin_operator
unstack b6 b18
0
4
0 23 0 24
0 19 -1 0
0 51 0 1
0 44 6 19
1
end_operator
begin_operator
unstack b6 b19
0
4
0 23 0 24
0 11 -1 0
0 51 0 1
0 44 7 19
1
end_operator
begin_operator
unstack b6 b20
0
4
0 23 0 24
0 14 -1 0
0 51 0 1
0 44 8 19
1
end_operator
begin_operator
unstack b6 b21
0
4
0 23 0 24
0 8 -1 0
0 51 0 1
0 44 9 19
1
end_operator
begin_operator
unstack b6 b22
0
4
0 23 0 24
0 18 -1 0
0 51 0 1
0 44 10 19
1
end_operator
begin_operator
unstack b6 b24
0
4
0 23 0 24
0 21 -1 0
0 51 0 1
0 44 11 19
1
end_operator
begin_operator
unstack b6 b25
0
4
0 23 0 24
0 4 -1 0
0 51 0 1
0 44 12 19
1
end_operator
begin_operator
unstack b6 b27
0
4
0 23 0 24
0 15 -1 0
0 51 0 1
0 44 13 19
1
end_operator
begin_operator
unstack b6 b28
0
4
0 23 0 24
0 50 -1 0
0 51 0 1
0 44 14 19
1
end_operator
begin_operator
unstack b6 b3
0
4
0 23 0 24
0 52 -1 0
0 51 0 1
0 44 15 19
1
end_operator
begin_operator
unstack b6 b4
0
4
0 23 0 24
0 5 -1 0
0 51 0 1
0 44 16 19
1
end_operator
begin_operator
unstack b6 b5
0
4
0 23 0 24
0 12 -1 0
0 51 0 1
0 44 17 19
1
end_operator
begin_operator
unstack b8 b15
0
3
0 23 0 26
0 30 1 0
0 2 0 1
1
end_operator
0
