begin_version
3
end_version
begin_metric
0
end_metric
43
begin_variable
var0
-1
2
Atom on-table(b3)
NegatedAtom on-table(b3)
end_variable
begin_variable
var1
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var2
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var3
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var4
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var7
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var8
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var9
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var10
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var11
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var14
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var13
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var15
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var16
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var17
-1
22
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var18
-1
3
Atom on(b12, b14)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var19
-1
3
Atom on(b19, b5)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var20
-1
3
Atom on(b13, b21)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom on(b21, b13)
Atom on(b21, b16)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom on(b7, b17)
Atom on(b7, b21)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom on(b8, b10)
Atom on(b8, b6)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom on(b11, b1)
Atom on(b11, b4)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b6, b1)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom clear(b3)
Atom on(b20, b3)
<none of those>
end_variable
begin_variable
var27
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var33
-1
13
Atom on(b16, b1)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b2)
Atom on(b16, b21)
Atom on(b16, b4)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var31
-1
14
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b13)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b2)
Atom on(b14, b21)
Atom on(b14, b5)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var29
-1
14
Atom on(b5, b1)
Atom on(b5, b13)
Atom on(b5, b14)
Atom on(b5, b16)
Atom on(b5, b17)
Atom on(b5, b18)
Atom on(b5, b2)
Atom on(b5, b21)
Atom on(b5, b4)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var37
-1
14
Atom on(b2, b1)
Atom on(b2, b11)
Atom on(b2, b13)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b5)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var28
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var32
-1
15
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b16)
Atom on(b10, b18)
Atom on(b10, b2)
Atom on(b10, b21)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var34
-1
16
Atom on(b9, b1)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b14)
Atom on(b9, b15)
Atom on(b9, b16)
Atom on(b9, b17)
Atom on(b9, b18)
Atom on(b9, b19)
Atom on(b9, b20)
Atom on(b9, b4)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var30
-1
17
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var35
-1
17
Atom on(b4, b1)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b15)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b18)
Atom on(b4, b19)
Atom on(b4, b2)
Atom on(b4, b20)
Atom on(b4, b21)
Atom on(b4, b5)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var36
-1
17
Atom on(b17, b11)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b21)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b7)
Atom on(b17, b8)
Atom on(b17, b9)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var38
-1
18
Atom on(b18, b1)
Atom on(b18, b11)
Atom on(b18, b12)
Atom on(b18, b13)
Atom on(b18, b14)
Atom on(b18, b15)
Atom on(b18, b16)
Atom on(b18, b17)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b20)
Atom on(b18, b21)
Atom on(b18, b5)
Atom on(b18, b7)
Atom on(b18, b8)
Atom on(b18, b9)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var39
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var40
-1
4
Atom clear(b18)
Atom on(b15, b18)
Atom on(b3, b18)
<none of those>
end_variable
begin_variable
var42
-1
2
Atom on-table(b15)
NegatedAtom on-table(b15)
end_variable
begin_variable
var41
-1
2
Atom on-table(b20)
NegatedAtom on-table(b20)
end_variable
2863
begin_mutex_group
12
17 1
16 0
33 0
24 0
29 0
28 0
38 0
31 0
36 0
30 0
25 0
34 0
end_mutex_group
begin_mutex_group
4
17 2
9 0
29 1
23 0
end_mutex_group
begin_mutex_group
10
17 3
4 0
35 0
33 1
29 2
37 0
38 1
31 1
36 1
34 1
end_mutex_group
begin_mutex_group
6
17 4
1 0
35 1
38 2
36 2
34 2
end_mutex_group
begin_mutex_group
13
17 5
5 0
35 2
33 2
29 3
28 1
37 1
38 3
31 2
21 0
36 3
30 1
34 3
end_mutex_group
begin_mutex_group
10
17 6
10 0
35 3
33 3
18 0
28 2
37 2
38 4
30 2
34 4
end_mutex_group
begin_mutex_group
7
17 7
3 0
35 4
37 3
38 5
36 4
34 5
end_mutex_group
begin_mutex_group
12
17 8
13 0
35 5
33 4
29 4
37 4
38 6
31 3
21 1
36 5
30 3
34 6
end_mutex_group
begin_mutex_group
10
17 9
15 0
29 5
28 3
38 7
31 4
36 6
30 4
22 0
34 7
end_mutex_group
begin_mutex_group
12
17 10
40 0
40 1
40 2
33 5
29 6
28 4
37 5
31 5
36 7
30 5
34 8
end_mutex_group
begin_mutex_group
7
17 11
2 0
35 6
37 6
38 8
36 8
34 9
end_mutex_group
begin_mutex_group
10
17 12
12 0
35 7
33 6
29 7
28 5
37 7
38 9
36 9
30 6
end_mutex_group
begin_mutex_group
8
17 13
32 0
35 8
37 8
38 10
31 6
36 10
34 10
end_mutex_group
begin_mutex_group
13
17 14
8 0
35 9
33 7
20 0
29 8
28 6
37 9
38 11
31 7
36 11
30 7
22 1
end_mutex_group
begin_mutex_group
3
17 15
26 0
26 1
end_mutex_group
begin_mutex_group
9
17 16
14 0
35 10
33 8
24 1
28 7
37 10
30 8
34 11
end_mutex_group
begin_mutex_group
10
17 17
11 0
35 11
33 9
29 9
37 11
38 12
19 0
31 8
36 12
end_mutex_group
begin_mutex_group
3
17 18
27 0
23 1
end_mutex_group
begin_mutex_group
12
17 19
6 0
35 12
33 10
29 10
28 8
37 12
38 13
31 9
36 13
30 9
34 12
end_mutex_group
begin_mutex_group
12
17 20
7 0
35 13
33 11
29 11
28 9
37 13
38 14
31 10
36 14
30 10
34 13
end_mutex_group
begin_mutex_group
9
17 21
39 0
35 14
33 12
28 10
37 14
38 15
31 11
30 11
end_mutex_group
begin_mutex_group
17
17 1
35 0
35 1
35 2
35 3
35 4
35 5
35 6
35 7
35 8
35 9
35 10
35 11
35 12
35 13
35 14
35 15
end_mutex_group
begin_mutex_group
15
17 2
33 0
33 1
33 2
33 3
33 4
33 5
33 6
33 7
33 8
33 9
33 10
33 11
33 12
33 13
end_mutex_group
begin_mutex_group
4
17 3
24 0
24 1
24 2
end_mutex_group
begin_mutex_group
3
17 4
18 0
18 1
end_mutex_group
begin_mutex_group
3
17 5
20 0
20 1
end_mutex_group
begin_mutex_group
14
17 6
29 0
29 1
29 2
29 3
29 4
29 5
29 6
29 7
29 8
29 9
29 10
29 11
29 12
end_mutex_group
begin_mutex_group
3
17 7
40 1
41 0
end_mutex_group
begin_mutex_group
13
17 8
28 0
28 1
28 2
28 3
28 4
28 5
28 6
28 7
28 8
28 9
28 10
28 11
end_mutex_group
begin_mutex_group
17
17 9
37 0
37 1
37 2
37 3
37 4
37 5
37 6
37 7
37 8
37 9
37 10
37 11
37 12
37 13
37 14
37 15
end_mutex_group
begin_mutex_group
18
17 10
38 0
38 1
38 2
38 3
38 4
38 5
38 6
38 7
38 8
38 9
38 10
38 11
38 12
38 13
38 14
38 15
38 16
end_mutex_group
begin_mutex_group
3
17 11
19 0
19 1
end_mutex_group
begin_mutex_group
14
17 12
31 0
31 1
31 2
31 3
31 4
31 5
31 6
31 7
31 8
31 9
31 10
31 11
31 12
end_mutex_group
begin_mutex_group
3
17 13
26 1
42 0
end_mutex_group
begin_mutex_group
4
17 14
21 0
21 1
21 2
end_mutex_group
begin_mutex_group
3
17 15
40 2
0 0
end_mutex_group
begin_mutex_group
17
17 16
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
36 15
end_mutex_group
begin_mutex_group
14
17 17
30 0
30 1
30 2
30 3
30 4
30 5
30 6
30 7
30 8
30 9
30 10
30 11
30 12
end_mutex_group
begin_mutex_group
3
17 18
25 0
25 1
end_mutex_group
begin_mutex_group
4
17 19
22 0
22 1
22 2
end_mutex_group
begin_mutex_group
4
17 20
23 0
23 1
23 2
end_mutex_group
begin_mutex_group
16
17 21
34 0
34 1
34 2
34 3
34 4
34 5
34 6
34 7
34 8
34 9
34 10
34 11
34 12
34 13
34 14
end_mutex_group
begin_mutex_group
2
0 0
26 2
end_mutex_group
begin_mutex_group
2
0 1
17 4
end_mutex_group
begin_mutex_group
2
0 1
17 7
end_mutex_group
begin_mutex_group
2
0 1
17 11
end_mutex_group
begin_mutex_group
2
0 1
17 13
end_mutex_group
begin_mutex_group
2
0 1
18 0
end_mutex_group
begin_mutex_group
2
0 1
18 2
end_mutex_group
begin_mutex_group
2
0 1
19 0
end_mutex_group
begin_mutex_group
2
0 1
19 2
end_mutex_group
begin_mutex_group
2
0 1
24 0
end_mutex_group
begin_mutex_group
2
0 1
26 1
end_mutex_group
begin_mutex_group
2
0 1
40 1
end_mutex_group
begin_mutex_group
2
1 0
17 7
end_mutex_group
begin_mutex_group
2
1 0
18 2
end_mutex_group
begin_mutex_group
2
1 0
24 0
end_mutex_group
begin_mutex_group
2
1 0
40 1
end_mutex_group
begin_mutex_group
2
2 0
17 4
end_mutex_group
begin_mutex_group
2
2 0
17 7
end_mutex_group
begin_mutex_group
2
2 0
18 0
end_mutex_group
begin_mutex_group
2
2 0
18 2
end_mutex_group
begin_mutex_group
2
2 0
19 2
end_mutex_group
begin_mutex_group
2
2 0
24 0
end_mutex_group
begin_mutex_group
2
2 0
40 1
end_mutex_group
begin_mutex_group
2
3 0
24 0
end_mutex_group
begin_mutex_group
2
4 0
24 3
end_mutex_group
begin_mutex_group
2
5 0
20 2
end_mutex_group
begin_mutex_group
2
5 0
22 1
end_mutex_group
begin_mutex_group
2
6 0
22 3
end_mutex_group
begin_mutex_group
2
7 0
23 3
end_mutex_group
begin_mutex_group
2
8 0
21 3
end_mutex_group
begin_mutex_group
2
9 0
17 4
end_mutex_group
begin_mutex_group
2
9 0
17 7
end_mutex_group
begin_mutex_group
2
9 0
18 0
end_mutex_group
begin_mutex_group
2
9 0
18 2
end_mutex_group
begin_mutex_group
2
9 0
24 0
end_mutex_group
begin_mutex_group
2
9 0
33 14
end_mutex_group
begin_mutex_group
2
9 0
40 1
end_mutex_group
begin_mutex_group
2
10 0
17 7
end_mutex_group
begin_mutex_group
2
10 0
24 0
end_mutex_group
begin_mutex_group
2
10 0
29 13
end_mutex_group
begin_mutex_group
2
10 0
40 1
end_mutex_group
begin_mutex_group
2
10 1
17 4
end_mutex_group
begin_mutex_group
2
10 1
18 2
end_mutex_group
begin_mutex_group
2
11 0
17 4
end_mutex_group
begin_mutex_group
2
11 0
17 7
end_mutex_group
begin_mutex_group
2
11 0
18 0
end_mutex_group
begin_mutex_group
2
11 0
18 2
end_mutex_group
begin_mutex_group
2
11 0
24 0
end_mutex_group
begin_mutex_group
2
11 0
30 13
end_mutex_group
begin_mutex_group
2
11 0
40 1
end_mutex_group
begin_mutex_group
2
11 1
17 11
end_mutex_group
begin_mutex_group
2
11 1
19 2
end_mutex_group
begin_mutex_group
2
12 0
17 4
end_mutex_group
begin_mutex_group
2
12 0
17 7
end_mutex_group
begin_mutex_group
2
12 0
17 11
end_mutex_group
begin_mutex_group
2
12 0
18 0
end_mutex_group
begin_mutex_group
2
12 0
18 2
end_mutex_group
begin_mutex_group
2
12 0
19 0
end_mutex_group
begin_mutex_group
2
12 0
19 2
end_mutex_group
begin_mutex_group
2
12 0
24 0
end_mutex_group
begin_mutex_group
2
12 0
31 13
end_mutex_group
begin_mutex_group
2
12 0
40 1
end_mutex_group
begin_mutex_group
2
14 0
17 7
end_mutex_group
begin_mutex_group
2
14 0
24 0
end_mutex_group
begin_mutex_group
2
14 0
36 16
end_mutex_group
begin_mutex_group
2
14 0
40 1
end_mutex_group
begin_mutex_group
2
13 0
17 7
end_mutex_group
begin_mutex_group
2
13 0
24 0
end_mutex_group
begin_mutex_group
2
13 0
28 12
end_mutex_group
begin_mutex_group
2
13 0
40 1
end_mutex_group
begin_mutex_group
2
15 0
37 16
end_mutex_group
begin_mutex_group
2
16 0
35 16
end_mutex_group
begin_mutex_group
2
17 0
18 2
end_mutex_group
begin_mutex_group
2
17 0
19 2
end_mutex_group
begin_mutex_group
2
17 0
20 2
end_mutex_group
begin_mutex_group
2
17 0
21 3
end_mutex_group
begin_mutex_group
2
17 0
22 3
end_mutex_group
begin_mutex_group
2
17 0
23 3
end_mutex_group
begin_mutex_group
2
17 0
25 2
end_mutex_group
begin_mutex_group
2
17 0
24 3
end_mutex_group
begin_mutex_group
2
17 0
26 2
end_mutex_group
begin_mutex_group
2
17 0
30 13
end_mutex_group
begin_mutex_group
2
17 0
35 16
end_mutex_group
begin_mutex_group
2
17 0
29 13
end_mutex_group
begin_mutex_group
2
17 0
33 14
end_mutex_group
begin_mutex_group
2
17 0
28 12
end_mutex_group
begin_mutex_group
2
17 0
34 15
end_mutex_group
begin_mutex_group
2
17 0
36 16
end_mutex_group
begin_mutex_group
2
17 0
37 16
end_mutex_group
begin_mutex_group
2
17 0
31 13
end_mutex_group
begin_mutex_group
2
17 0
38 17
end_mutex_group
begin_mutex_group
2
17 1
18 2
end_mutex_group
begin_mutex_group
2
17 1
19 2
end_mutex_group
begin_mutex_group
2
17 1
20 2
end_mutex_group
begin_mutex_group
2
17 1
21 3
end_mutex_group
begin_mutex_group
2
17 1
22 3
end_mutex_group
begin_mutex_group
2
17 1
23 3
end_mutex_group
begin_mutex_group
2
17 1
25 2
end_mutex_group
begin_mutex_group
2
17 1
24 3
end_mutex_group
begin_mutex_group
2
17 1
26 2
end_mutex_group
begin_mutex_group
2
17 1
30 13
end_mutex_group
begin_mutex_group
2
17 1
29 13
end_mutex_group
begin_mutex_group
2
17 1
33 14
end_mutex_group
begin_mutex_group
2
17 1
28 12
end_mutex_group
begin_mutex_group
2
17 1
34 15
end_mutex_group
begin_mutex_group
2
17 1
36 16
end_mutex_group
begin_mutex_group
2
17 1
37 16
end_mutex_group
begin_mutex_group
2
17 1
31 13
end_mutex_group
begin_mutex_group
2
17 1
38 17
end_mutex_group
begin_mutex_group
2
17 2
18 0
end_mutex_group
begin_mutex_group
2
17 2
18 2
end_mutex_group
begin_mutex_group
2
17 2
19 2
end_mutex_group
begin_mutex_group
2
17 2
20 2
end_mutex_group
begin_mutex_group
2
17 2
21 3
end_mutex_group
begin_mutex_group
2
17 2
22 3
end_mutex_group
begin_mutex_group
2
17 2
23 3
end_mutex_group
begin_mutex_group
2
17 2
25 2
end_mutex_group
begin_mutex_group
2
17 2
24 0
end_mutex_group
begin_mutex_group
2
17 2
24 3
end_mutex_group
begin_mutex_group
2
17 2
26 2
end_mutex_group
begin_mutex_group
2
17 2
30 13
end_mutex_group
begin_mutex_group
2
17 2
35 16
end_mutex_group
begin_mutex_group
2
17 2
29 13
end_mutex_group
begin_mutex_group
2
17 2
28 12
end_mutex_group
begin_mutex_group
2
17 2
34 15
end_mutex_group
begin_mutex_group
2
17 2
36 16
end_mutex_group
begin_mutex_group
2
17 2
37 16
end_mutex_group
begin_mutex_group
2
17 2
31 13
end_mutex_group
begin_mutex_group
2
17 2
38 17
end_mutex_group
begin_mutex_group
2
17 2
40 1
end_mutex_group
begin_mutex_group
2
17 3
18 2
end_mutex_group
begin_mutex_group
2
17 3
19 2
end_mutex_group
begin_mutex_group
2
17 3
20 2
end_mutex_group
begin_mutex_group
2
17 3
21 3
end_mutex_group
begin_mutex_group
2
17 3
22 3
end_mutex_group
begin_mutex_group
2
17 3
23 3
end_mutex_group
begin_mutex_group
2
17 3
25 2
end_mutex_group
begin_mutex_group
2
17 3
26 2
end_mutex_group
begin_mutex_group
2
17 3
30 13
end_mutex_group
begin_mutex_group
2
17 3
35 16
end_mutex_group
begin_mutex_group
2
17 3
29 13
end_mutex_group
begin_mutex_group
2
17 3
33 14
end_mutex_group
begin_mutex_group
2
17 3
28 12
end_mutex_group
begin_mutex_group
2
17 3
34 15
end_mutex_group
begin_mutex_group
2
17 3
36 16
end_mutex_group
begin_mutex_group
2
17 3
37 16
end_mutex_group
begin_mutex_group
2
17 3
31 13
end_mutex_group
begin_mutex_group
2
17 3
38 17
end_mutex_group
begin_mutex_group
2
17 4
19 1
end_mutex_group
begin_mutex_group
2
17 4
19 2
end_mutex_group
begin_mutex_group
2
17 4
20 2
end_mutex_group
begin_mutex_group
2
17 4
21 3
end_mutex_group
begin_mutex_group
2
17 4
22 3
end_mutex_group
begin_mutex_group
2
17 4
23 0
end_mutex_group
begin_mutex_group
2
17 4
23 3
end_mutex_group
begin_mutex_group
2
17 4
25 2
end_mutex_group
begin_mutex_group
2
17 4
24 0
end_mutex_group
begin_mutex_group
2
17 4
24 3
end_mutex_group
begin_mutex_group
2
17 4
26 0
end_mutex_group
begin_mutex_group
2
17 4
26 2
end_mutex_group
begin_mutex_group
2
17 4
32 0
end_mutex_group
begin_mutex_group
2
17 4
30 0
end_mutex_group
begin_mutex_group
2
17 4
30 1
end_mutex_group
begin_mutex_group
2
17 4
30 2
end_mutex_group
begin_mutex_group
2
17 4
30 3
end_mutex_group
begin_mutex_group
2
17 4
30 4
end_mutex_group
begin_mutex_group
2
17 4
30 5
end_mutex_group
begin_mutex_group
2
17 4
30 7
end_mutex_group
begin_mutex_group
2
17 4
30 8
end_mutex_group
begin_mutex_group
2
17 4
30 9
end_mutex_group
begin_mutex_group
2
17 4
30 10
end_mutex_group
begin_mutex_group
2
17 4
30 11
end_mutex_group
begin_mutex_group
2
17 4
30 12
end_mutex_group
begin_mutex_group
2
17 4
30 13
end_mutex_group
begin_mutex_group
2
17 4
35 3
end_mutex_group
begin_mutex_group
2
17 4
35 6
end_mutex_group
begin_mutex_group
2
17 4
35 7
end_mutex_group
begin_mutex_group
2
17 4
35 8
end_mutex_group
begin_mutex_group
2
17 4
35 11
end_mutex_group
begin_mutex_group
2
17 4
35 14
end_mutex_group
begin_mutex_group
2
17 4
35 16
end_mutex_group
begin_mutex_group
2
17 4
29 0
end_mutex_group
begin_mutex_group
2
17 4
29 2
end_mutex_group
begin_mutex_group
2
17 4
29 3
end_mutex_group
begin_mutex_group
2
17 4
29 4
end_mutex_group
begin_mutex_group
2
17 4
29 5
end_mutex_group
begin_mutex_group
2
17 4
29 6
end_mutex_group
begin_mutex_group
2
17 4
29 7
end_mutex_group
begin_mutex_group
2
17 4
29 8
end_mutex_group
begin_mutex_group
2
17 4
29 9
end_mutex_group
begin_mutex_group
2
17 4
29 10
end_mutex_group
begin_mutex_group
2
17 4
29 11
end_mutex_group
begin_mutex_group
2
17 4
29 12
end_mutex_group
begin_mutex_group
2
17 4
29 13
end_mutex_group
begin_mutex_group
2
17 4
33 0
end_mutex_group
begin_mutex_group
2
17 4
33 1
end_mutex_group
begin_mutex_group
2
17 4
33 2
end_mutex_group
begin_mutex_group
2
17 4
33 3
end_mutex_group
begin_mutex_group
2
17 4
33 4
end_mutex_group
begin_mutex_group
2
17 4
33 5
end_mutex_group
begin_mutex_group
2
17 4
33 6
end_mutex_group
begin_mutex_group
2
17 4
33 7
end_mutex_group
begin_mutex_group
2
17 4
33 8
end_mutex_group
begin_mutex_group
2
17 4
33 9
end_mutex_group
begin_mutex_group
2
17 4
33 10
end_mutex_group
begin_mutex_group
2
17 4
33 11
end_mutex_group
begin_mutex_group
2
17 4
33 13
end_mutex_group
begin_mutex_group
2
17 4
33 14
end_mutex_group
begin_mutex_group
2
17 4
28 2
end_mutex_group
begin_mutex_group
2
17 4
28 5
end_mutex_group
begin_mutex_group
2
17 4
28 10
end_mutex_group
begin_mutex_group
2
17 4
28 12
end_mutex_group
begin_mutex_group
2
17 4
34 0
end_mutex_group
begin_mutex_group
2
17 4
34 1
end_mutex_group
begin_mutex_group
2
17 4
34 3
end_mutex_group
begin_mutex_group
2
17 4
34 4
end_mutex_group
begin_mutex_group
2
17 4
34 5
end_mutex_group
begin_mutex_group
2
17 4
34 6
end_mutex_group
begin_mutex_group
2
17 4
34 7
end_mutex_group
begin_mutex_group
2
17 4
34 8
end_mutex_group
begin_mutex_group
2
17 4
34 10
end_mutex_group
begin_mutex_group
2
17 4
34 11
end_mutex_group
begin_mutex_group
2
17 4
34 12
end_mutex_group
begin_mutex_group
2
17 4
34 13
end_mutex_group
begin_mutex_group
2
17 4
34 14
end_mutex_group
begin_mutex_group
2
17 4
34 15
end_mutex_group
begin_mutex_group
2
17 4
36 8
end_mutex_group
begin_mutex_group
2
17 4
36 9
end_mutex_group
begin_mutex_group
2
17 4
36 10
end_mutex_group
begin_mutex_group
2
17 4
36 12
end_mutex_group
begin_mutex_group
2
17 4
36 16
end_mutex_group
begin_mutex_group
2
17 4
37 2
end_mutex_group
begin_mutex_group
2
17 4
37 6
end_mutex_group
begin_mutex_group
2
17 4
37 7
end_mutex_group
begin_mutex_group
2
17 4
37 8
end_mutex_group
begin_mutex_group
2
17 4
37 11
end_mutex_group
begin_mutex_group
2
17 4
37 14
end_mutex_group
begin_mutex_group
2
17 4
37 16
end_mutex_group
begin_mutex_group
2
17 4
31 0
end_mutex_group
begin_mutex_group
2
17 4
31 1
end_mutex_group
begin_mutex_group
2
17 4
31 2
end_mutex_group
begin_mutex_group
2
17 4
31 3
end_mutex_group
begin_mutex_group
2
17 4
31 4
end_mutex_group
begin_mutex_group
2
17 4
31 5
end_mutex_group
begin_mutex_group
2
17 4
31 7
end_mutex_group
begin_mutex_group
2
17 4
31 8
end_mutex_group
begin_mutex_group
2
17 4
31 9
end_mutex_group
begin_mutex_group
2
17 4
31 10
end_mutex_group
begin_mutex_group
2
17 4
31 11
end_mutex_group
begin_mutex_group
2
17 4
31 12
end_mutex_group
begin_mutex_group
2
17 4
31 13
end_mutex_group
begin_mutex_group
2
17 4
38 4
end_mutex_group
begin_mutex_group
2
17 4
38 8
end_mutex_group
begin_mutex_group
2
17 4
38 9
end_mutex_group
begin_mutex_group
2
17 4
38 10
end_mutex_group
begin_mutex_group
2
17 4
38 12
end_mutex_group
begin_mutex_group
2
17 4
38 15
end_mutex_group
begin_mutex_group
2
17 4
38 17
end_mutex_group
begin_mutex_group
2
17 4
39 0
end_mutex_group
begin_mutex_group
2
17 4
40 1
end_mutex_group
begin_mutex_group
2
17 4
40 2
end_mutex_group
begin_mutex_group
2
17 4
42 0
end_mutex_group
begin_mutex_group
2
17 5
18 2
end_mutex_group
begin_mutex_group
2
17 5
19 2
end_mutex_group
begin_mutex_group
2
17 5
21 3
end_mutex_group
begin_mutex_group
2
17 5
22 1
end_mutex_group
begin_mutex_group
2
17 5
22 3
end_mutex_group
begin_mutex_group
2
17 5
23 3
end_mutex_group
begin_mutex_group
2
17 5
25 2
end_mutex_group
begin_mutex_group
2
17 5
24 3
end_mutex_group
begin_mutex_group
2
17 5
26 2
end_mutex_group
begin_mutex_group
2
17 5
30 13
end_mutex_group
begin_mutex_group
2
17 5
35 16
end_mutex_group
begin_mutex_group
2
17 5
29 13
end_mutex_group
begin_mutex_group
2
17 5
33 14
end_mutex_group
begin_mutex_group
2
17 5
28 12
end_mutex_group
begin_mutex_group
2
17 5
34 15
end_mutex_group
begin_mutex_group
2
17 5
36 16
end_mutex_group
begin_mutex_group
2
17 5
37 16
end_mutex_group
begin_mutex_group
2
17 5
31 13
end_mutex_group
begin_mutex_group
2
17 5
38 17
end_mutex_group
begin_mutex_group
2
17 6
18 2
end_mutex_group
begin_mutex_group
2
17 6
19 2
end_mutex_group
begin_mutex_group
2
17 6
20 2
end_mutex_group
begin_mutex_group
2
17 6
21 3
end_mutex_group
begin_mutex_group
2
17 6
22 3
end_mutex_group
begin_mutex_group
2
17 6
23 3
end_mutex_group
begin_mutex_group
2
17 6
25 2
end_mutex_group
begin_mutex_group
2
17 6
24 0
end_mutex_group
begin_mutex_group
2
17 6
24 3
end_mutex_group
begin_mutex_group
2
17 6
26 2
end_mutex_group
begin_mutex_group
2
17 6
30 13
end_mutex_group
begin_mutex_group
2
17 6
35 16
end_mutex_group
begin_mutex_group
2
17 6
33 14
end_mutex_group
begin_mutex_group
2
17 6
28 12
end_mutex_group
begin_mutex_group
2
17 6
34 15
end_mutex_group
begin_mutex_group
2
17 6
36 16
end_mutex_group
begin_mutex_group
2
17 6
37 16
end_mutex_group
begin_mutex_group
2
17 6
31 13
end_mutex_group
begin_mutex_group
2
17 6
38 17
end_mutex_group
begin_mutex_group
2
17 6
40 1
end_mutex_group
begin_mutex_group
2
17 7
18 1
end_mutex_group
begin_mutex_group
2
17 7
18 2
end_mutex_group
begin_mutex_group
2
17 7
19 1
end_mutex_group
begin_mutex_group
2
17 7
19 2
end_mutex_group
begin_mutex_group
2
17 7
20 2
end_mutex_group
begin_mutex_group
2
17 7
21 1
end_mutex_group
begin_mutex_group
2
17 7
21 3
end_mutex_group
begin_mutex_group
2
17 7
22 3
end_mutex_group
begin_mutex_group
2
17 7
23 0
end_mutex_group
begin_mutex_group
2
17 7
23 3
end_mutex_group
begin_mutex_group
2
17 7
25 2
end_mutex_group
begin_mutex_group
2
17 7
24 0
end_mutex_group
begin_mutex_group
2
17 7
24 1
end_mutex_group
begin_mutex_group
2
17 7
24 3
end_mutex_group
begin_mutex_group
2
17 7
26 0
end_mutex_group
begin_mutex_group
2
17 7
26 2
end_mutex_group
begin_mutex_group
2
17 7
32 0
end_mutex_group
begin_mutex_group
2
17 7
30 0
end_mutex_group
begin_mutex_group
2
17 7
30 1
end_mutex_group
begin_mutex_group
2
17 7
30 2
end_mutex_group
begin_mutex_group
2
17 7
30 3
end_mutex_group
begin_mutex_group
2
17 7
30 4
end_mutex_group
begin_mutex_group
2
17 7
30 5
end_mutex_group
begin_mutex_group
2
17 7
30 7
end_mutex_group
begin_mutex_group
2
17 7
30 8
end_mutex_group
begin_mutex_group
2
17 7
30 9
end_mutex_group
begin_mutex_group
2
17 7
30 10
end_mutex_group
begin_mutex_group
2
17 7
30 11
end_mutex_group
begin_mutex_group
2
17 7
30 12
end_mutex_group
begin_mutex_group
2
17 7
30 13
end_mutex_group
begin_mutex_group
2
17 7
35 1
end_mutex_group
begin_mutex_group
2
17 7
35 3
end_mutex_group
begin_mutex_group
2
17 7
35 5
end_mutex_group
begin_mutex_group
2
17 7
35 6
end_mutex_group
begin_mutex_group
2
17 7
35 7
end_mutex_group
begin_mutex_group
2
17 7
35 8
end_mutex_group
begin_mutex_group
2
17 7
35 10
end_mutex_group
begin_mutex_group
2
17 7
35 11
end_mutex_group
begin_mutex_group
2
17 7
35 14
end_mutex_group
begin_mutex_group
2
17 7
35 16
end_mutex_group
begin_mutex_group
2
17 7
29 0
end_mutex_group
begin_mute




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




wn b16
0
3
0 17 8 0
0 13 -1 0
0 28 -1 11
1
end_operator
begin_operator
putdown b17
0
3
0 17 9 0
0 15 -1 0
0 37 -1 15
1
end_operator
begin_operator
putdown b18
0
3
0 17 10 0
0 40 -1 0
0 38 -1 16
1
end_operator
begin_operator
putdown b19
0
3
0 17 11 0
0 2 -1 0
0 19 -1 1
1
end_operator
begin_operator
putdown b2
0
3
0 17 12 0
0 12 -1 0
0 31 -1 12
1
end_operator
begin_operator
putdown b20
0
3
0 17 13 0
0 32 -1 0
0 42 -1 0
1
end_operator
begin_operator
putdown b21
0
3
0 17 14 0
0 8 -1 0
0 21 -1 2
1
end_operator
begin_operator
putdown b4
0
3
0 17 16 0
0 14 -1 0
0 36 -1 15
1
end_operator
begin_operator
putdown b5
0
3
0 17 17 0
0 11 -1 0
0 30 -1 12
1
end_operator
begin_operator
putdown b7
0
3
0 17 19 0
0 6 -1 0
0 22 -1 2
1
end_operator
begin_operator
putdown b8
0
3
0 17 20 0
0 7 -1 0
0 23 -1 2
1
end_operator
begin_operator
putdown b9
0
3
0 17 21 0
0 39 -1 0
0 34 -1 14
1
end_operator
begin_operator
stack b1 b11
0
4
0 17 1 0
0 16 -1 0
0 4 0 1
0 35 -1 0
1
end_operator
begin_operator
stack b1 b12
0
4
0 17 1 0
0 16 -1 0
0 1 0 1
0 35 -1 1
1
end_operator
begin_operator
stack b1 b13
0
4
0 17 1 0
0 16 -1 0
0 5 0 1
0 35 -1 2
1
end_operator
begin_operator
stack b1 b14
0
4
0 17 1 0
0 16 -1 0
0 10 0 1
0 35 -1 3
1
end_operator
begin_operator
stack b1 b15
0
4
0 17 1 0
0 16 -1 0
0 3 0 1
0 35 -1 4
1
end_operator
begin_operator
stack b1 b16
0
4
0 17 1 0
0 16 -1 0
0 13 0 1
0 35 -1 5
1
end_operator
begin_operator
stack b1 b19
0
4
0 17 1 0
0 16 -1 0
0 2 0 1
0 35 -1 6
1
end_operator
begin_operator
stack b1 b2
0
4
0 17 1 0
0 16 -1 0
0 12 0 1
0 35 -1 7
1
end_operator
begin_operator
stack b1 b20
0
4
0 17 1 0
0 16 -1 0
0 32 0 1
0 35 -1 8
1
end_operator
begin_operator
stack b1 b21
0
4
0 17 1 0
0 16 -1 0
0 8 0 1
0 35 -1 9
1
end_operator
begin_operator
stack b1 b4
0
4
0 17 1 0
0 16 -1 0
0 14 0 1
0 35 -1 10
1
end_operator
begin_operator
stack b1 b5
0
4
0 17 1 0
0 16 -1 0
0 11 0 1
0 35 -1 11
1
end_operator
begin_operator
stack b1 b7
0
4
0 17 1 0
0 16 -1 0
0 6 0 1
0 35 -1 12
1
end_operator
begin_operator
stack b1 b8
0
4
0 17 1 0
0 16 -1 0
0 7 0 1
0 35 -1 13
1
end_operator
begin_operator
stack b1 b9
0
4
0 17 1 0
0 16 -1 0
0 39 0 1
0 35 -1 14
1
end_operator
begin_operator
stack b10 b1
0
4
0 17 2 0
0 16 0 1
0 9 -1 0
0 33 -1 0
1
end_operator
begin_operator
stack b10 b11
0
4
0 17 2 0
0 9 -1 0
0 4 0 1
0 33 -1 1
1
end_operator
begin_operator
stack b10 b13
0
4
0 17 2 0
0 9 -1 0
0 5 0 1
0 33 -1 2
1
end_operator
begin_operator
stack b10 b14
0
4
0 17 2 0
0 9 -1 0
0 10 0 1
0 33 -1 3
1
end_operator
begin_operator
stack b10 b16
0
4
0 17 2 0
0 9 -1 0
0 13 0 1
0 33 -1 4
1
end_operator
begin_operator
stack b10 b18
0
4
0 17 2 0
0 9 -1 0
0 40 0 3
0 33 -1 5
1
end_operator
begin_operator
stack b10 b2
0
4
0 17 2 0
0 9 -1 0
0 12 0 1
0 33 -1 6
1
end_operator
begin_operator
stack b10 b21
0
4
0 17 2 0
0 9 -1 0
0 8 0 1
0 33 -1 7
1
end_operator
begin_operator
stack b10 b4
0
4
0 17 2 0
0 9 -1 0
0 14 0 1
0 33 -1 8
1
end_operator
begin_operator
stack b10 b5
0
4
0 17 2 0
0 9 -1 0
0 11 0 1
0 33 -1 9
1
end_operator
begin_operator
stack b10 b7
0
4
0 17 2 0
0 9 -1 0
0 6 0 1
0 33 -1 10
1
end_operator
begin_operator
stack b10 b8
0
4
0 17 2 0
0 9 -1 0
0 7 0 1
0 33 -1 11
1
end_operator
begin_operator
stack b10 b9
0
4
0 17 2 0
0 9 -1 0
0 39 0 1
0 33 -1 12
1
end_operator
begin_operator
stack b11 b4
0
4
0 17 3 0
0 4 -1 0
0 14 0 1
0 24 -1 1
1
end_operator
begin_operator
stack b13 b21
0
4
0 17 5 0
0 5 -1 0
0 8 0 1
0 20 -1 0
1
end_operator
begin_operator
stack b14 b1
0
4
0 17 6 0
0 16 0 1
0 10 -1 0
0 29 -1 0
1
end_operator
begin_operator
stack b14 b10
0
4
0 17 6 0
0 9 0 1
0 10 -1 0
0 29 -1 1
1
end_operator
begin_operator
stack b14 b11
0
4
0 17 6 0
0 4 0 1
0 10 -1 0
0 29 -1 2
1
end_operator
begin_operator
stack b14 b13
0
4
0 17 6 0
0 5 0 1
0 10 -1 0
0 29 -1 3
1
end_operator
begin_operator
stack b14 b16
0
4
0 17 6 0
0 10 -1 0
0 13 0 1
0 29 -1 4
1
end_operator
begin_operator
stack b14 b17
0
4
0 17 6 0
0 10 -1 0
0 15 0 1
0 29 -1 5
1
end_operator
begin_operator
stack b14 b18
0
4
0 17 6 0
0 10 -1 0
0 40 0 3
0 29 -1 6
1
end_operator
begin_operator
stack b14 b2
0
4
0 17 6 0
0 10 -1 0
0 12 0 1
0 29 -1 7
1
end_operator
begin_operator
stack b14 b21
0
4
0 17 6 0
0 10 -1 0
0 8 0 1
0 29 -1 8
1
end_operator
begin_operator
stack b14 b5
0
4
0 17 6 0
0 10 -1 0
0 11 0 1
0 29 -1 9
1
end_operator
begin_operator
stack b14 b7
0
4
0 17 6 0
0 10 -1 0
0 6 0 1
0 29 -1 10
1
end_operator
begin_operator
stack b14 b8
0
4
0 17 6 0
0 10 -1 0
0 7 0 1
0 29 -1 11
1
end_operator
begin_operator
stack b16 b1
0
4
0 17 8 0
0 16 0 1
0 13 -1 0
0 28 -1 0
1
end_operator
begin_operator
stack b16 b13
0
4
0 17 8 0
0 5 0 1
0 13 -1 0
0 28 -1 1
1
end_operator
begin_operator
stack b16 b14
0
4
0 17 8 0
0 10 0 1
0 13 -1 0
0 28 -1 2
1
end_operator
begin_operator
stack b16 b17
0
4
0 17 8 0
0 13 -1 0
0 15 0 1
0 28 -1 3
1
end_operator
begin_operator
stack b16 b18
0
4
0 17 8 0
0 13 -1 0
0 40 0 3
0 28 -1 4
1
end_operator
begin_operator
stack b16 b2
0
4
0 17 8 0
0 13 -1 0
0 12 0 1
0 28 -1 5
1
end_operator
begin_operator
stack b16 b21
0
4
0 17 8 0
0 13 -1 0
0 8 0 1
0 28 -1 6
1
end_operator
begin_operator
stack b16 b4
0
4
0 17 8 0
0 13 -1 0
0 14 0 1
0 28 -1 7
1
end_operator
begin_operator
stack b16 b7
0
4
0 17 8 0
0 13 -1 0
0 6 0 1
0 28 -1 8
1
end_operator
begin_operator
stack b16 b8
0
4
0 17 8 0
0 13 -1 0
0 7 0 1
0 28 -1 9
1
end_operator
begin_operator
stack b16 b9
0
4
0 17 8 0
0 13 -1 0
0 39 0 1
0 28 -1 10
1
end_operator
begin_operator
stack b17 b11
0
4
0 17 9 0
0 4 0 1
0 15 -1 0
0 37 -1 0
1
end_operator
begin_operator
stack b17 b13
0
4
0 17 9 0
0 5 0 1
0 15 -1 0
0 37 -1 1
1
end_operator
begin_operator
stack b17 b14
0
4
0 17 9 0
0 10 0 1
0 15 -1 0
0 37 -1 2
1
end_operator
begin_operator
stack b17 b15
0
4
0 17 9 0
0 3 0 1
0 15 -1 0
0 37 -1 3
1
end_operator
begin_operator
stack b17 b16
0
4
0 17 9 0
0 13 0 1
0 15 -1 0
0 37 -1 4
1
end_operator
begin_operator
stack b17 b18
0
4
0 17 9 0
0 15 -1 0
0 40 0 3
0 37 -1 5
1
end_operator
begin_operator
stack b17 b19
0
4
0 17 9 0
0 15 -1 0
0 2 0 1
0 37 -1 6
1
end_operator
begin_operator
stack b17 b2
0
4
0 17 9 0
0 15 -1 0
0 12 0 1
0 37 -1 7
1
end_operator
begin_operator
stack b17 b20
0
4
0 17 9 0
0 15 -1 0
0 32 0 1
0 37 -1 8
1
end_operator
begin_operator
stack b17 b21
0
4
0 17 9 0
0 15 -1 0
0 8 0 1
0 37 -1 9
1
end_operator
begin_operator
stack b17 b4
0
4
0 17 9 0
0 15 -1 0
0 14 0 1
0 37 -1 10
1
end_operator
begin_operator
stack b17 b5
0
4
0 17 9 0
0 15 -1 0
0 11 0 1
0 37 -1 11
1
end_operator
begin_operator
stack b17 b7
0
4
0 17 9 0
0 15 -1 0
0 6 0 1
0 37 -1 12
1
end_operator
begin_operator
stack b17 b8
0
4
0 17 9 0
0 15 -1 0
0 7 0 1
0 37 -1 13
1
end_operator
begin_operator
stack b17 b9
0
4
0 17 9 0
0 15 -1 0
0 39 0 1
0 37 -1 14
1
end_operator
begin_operator
stack b18 b1
0
4
0 17 10 0
0 16 0 1
0 40 -1 0
0 38 -1 0
1
end_operator
begin_operator
stack b18 b11
0
4
0 17 10 0
0 4 0 1
0 40 -1 0
0 38 -1 1
1
end_operator
begin_operator
stack b18 b12
0
4
0 17 10 0
0 1 0 1
0 40 -1 0
0 38 -1 2
1
end_operator
begin_operator
stack b18 b13
0
4
0 17 10 0
0 5 0 1
0 40 -1 0
0 38 -1 3
1
end_operator
begin_operator
stack b18 b14
0
4
0 17 10 0
0 10 0 1
0 40 -1 0
0 38 -1 4
1
end_operator
begin_operator
stack b18 b15
0
4
0 17 10 0
0 3 0 1
0 40 -1 0
0 38 -1 5
1
end_operator
begin_operator
stack b18 b16
0
4
0 17 10 0
0 13 0 1
0 40 -1 0
0 38 -1 6
1
end_operator
begin_operator
stack b18 b17
0
4
0 17 10 0
0 15 0 1
0 40 -1 0
0 38 -1 7
1
end_operator
begin_operator
stack b18 b19
0
4
0 17 10 0
0 40 -1 0
0 2 0 1
0 38 -1 8
1
end_operator
begin_operator
stack b18 b2
0
4
0 17 10 0
0 40 -1 0
0 12 0 1
0 38 -1 9
1
end_operator
begin_operator
stack b18 b20
0
4
0 17 10 0
0 40 -1 0
0 32 0 1
0 38 -1 10
1
end_operator
begin_operator
stack b18 b21
0
4
0 17 10 0
0 40 -1 0
0 8 0 1
0 38 -1 11
1
end_operator
begin_operator
stack b18 b5
0
4
0 17 10 0
0 40 -1 0
0 11 0 1
0 38 -1 12
1
end_operator
begin_operator
stack b18 b7
0
4
0 17 10 0
0 40 -1 0
0 6 0 1
0 38 -1 13
1
end_operator
begin_operator
stack b18 b8
0
4
0 17 10 0
0 40 -1 0
0 7 0 1
0 38 -1 14
1
end_operator
begin_operator
stack b18 b9
0
4
0 17 10 0
0 40 -1 0
0 39 0 1
0 38 -1 15
1
end_operator
begin_operator
stack b2 b1
0
4
0 17 12 0
0 16 0 1
0 12 -1 0
0 31 -1 0
1
end_operator
begin_operator
stack b2 b11
0
4
0 17 12 0
0 4 0 1
0 12 -1 0
0 31 -1 1
1
end_operator
begin_operator
stack b2 b13
0
4
0 17 12 0
0 5 0 1
0 12 -1 0
0 31 -1 2
1
end_operator
begin_operator
stack b2 b16
0
4
0 17 12 0
0 13 0 1
0 12 -1 0
0 31 -1 3
1
end_operator
begin_operator
stack b2 b17
0
4
0 17 12 0
0 15 0 1
0 12 -1 0
0 31 -1 4
1
end_operator
begin_operator
stack b2 b18
0
4
0 17 12 0
0 40 0 3
0 12 -1 0
0 31 -1 5
1
end_operator
begin_operator
stack b2 b20
0
4
0 17 12 0
0 12 -1 0
0 32 0 1
0 31 -1 6
1
end_operator
begin_operator
stack b2 b21
0
4
0 17 12 0
0 12 -1 0
0 8 0 1
0 31 -1 7
1
end_operator
begin_operator
stack b2 b5
0
4
0 17 12 0
0 12 -1 0
0 11 0 1
0 31 -1 8
1
end_operator
begin_operator
stack b2 b7
0
4
0 17 12 0
0 12 -1 0
0 6 0 1
0 31 -1 9
1
end_operator
begin_operator
stack b2 b8
0
4
0 17 12 0
0 12 -1 0
0 7 0 1
0 31 -1 10
1
end_operator
begin_operator
stack b2 b9
0
4
0 17 12 0
0 12 -1 0
0 39 0 1
0 31 -1 11
1
end_operator
begin_operator
stack b21 b16
0
4
0 17 14 0
0 13 0 1
0 8 -1 0
0 21 -1 1
1
end_operator
begin_operator
stack b3 b18
0
3
0 17 15 0
0 40 0 2
0 26 -1 0
1
end_operator
begin_operator
stack b4 b1
0
4
0 17 16 0
0 16 0 1
0 14 -1 0
0 36 -1 0
1
end_operator
begin_operator
stack b4 b11
0
4
0 17 16 0
0 4 0 1
0 14 -1 0
0 36 -1 1
1
end_operator
begin_operator
stack b4 b12
0
4
0 17 16 0
0 1 0 1
0 14 -1 0
0 36 -1 2
1
end_operator
begin_operator
stack b4 b13
0
4
0 17 16 0
0 5 0 1
0 14 -1 0
0 36 -1 3
1
end_operator
begin_operator
stack b4 b15
0
4
0 17 16 0
0 3 0 1
0 14 -1 0
0 36 -1 4
1
end_operator
begin_operator
stack b4 b16
0
4
0 17 16 0
0 13 0 1
0 14 -1 0
0 36 -1 5
1
end_operator
begin_operator
stack b4 b17
0
4
0 17 16 0
0 15 0 1
0 14 -1 0
0 36 -1 6
1
end_operator
begin_operator
stack b4 b18
0
4
0 17 16 0
0 40 0 3
0 14 -1 0
0 36 -1 7
1
end_operator
begin_operator
stack b4 b19
0
4
0 17 16 0
0 2 0 1
0 14 -1 0
0 36 -1 8
1
end_operator
begin_operator
stack b4 b2
0
4
0 17 16 0
0 12 0 1
0 14 -1 0
0 36 -1 9
1
end_operator
begin_operator
stack b4 b20
0
4
0 17 16 0
0 32 0 1
0 14 -1 0
0 36 -1 10
1
end_operator
begin_operator
stack b4 b21
0
4
0 17 16 0
0 8 0 1
0 14 -1 0
0 36 -1 11
1
end_operator
begin_operator
stack b4 b5
0
4
0 17 16 0
0 14 -1 0
0 11 0 1
0 36 -1 12
1
end_operator
begin_operator
stack b4 b7
0
4
0 17 16 0
0 14 -1 0
0 6 0 1
0 36 -1 13
1
end_operator
begin_operator
stack b4 b8
0
4
0 17 16 0
0 14 -1 0
0 7 0 1
0 36 -1 14
1
end_operator
begin_operator
stack b5 b1
0
4
0 17 17 0
0 16 0 1
0 11 -1 0
0 30 -1 0
1
end_operator
begin_operator
stack b5 b13
0
4
0 17 17 0
0 5 0 1
0 11 -1 0
0 30 -1 1
1
end_operator
begin_operator
stack b5 b14
0
4
0 17 17 0
0 10 0 1
0 11 -1 0
0 30 -1 2
1
end_operator
begin_operator
stack b5 b16
0
4
0 17 17 0
0 13 0 1
0 11 -1 0
0 30 -1 3
1
end_operator
begin_operator
stack b5 b17
0
4
0 17 17 0
0 15 0 1
0 11 -1 0
0 30 -1 4
1
end_operator
begin_operator
stack b5 b18
0
4
0 17 17 0
0 40 0 3
0 11 -1 0
0 30 -1 5
1
end_operator
begin_operator
stack b5 b2
0
4
0 17 17 0
0 12 0 1
0 11 -1 0
0 30 -1 6
1
end_operator
begin_operator
stack b5 b21
0
4
0 17 17 0
0 8 0 1
0 11 -1 0
0 30 -1 7
1
end_operator
begin_operator
stack b5 b4
0
4
0 17 17 0
0 14 0 1
0 11 -1 0
0 30 -1 8
1
end_operator
begin_operator
stack b5 b7
0
4
0 17 17 0
0 11 -1 0
0 6 0 1
0 30 -1 9
1
end_operator
begin_operator
stack b5 b8
0
4
0 17 17 0
0 11 -1 0
0 7 0 1
0 30 -1 10
1
end_operator
begin_operator
stack b5 b9
0
4
0 17 17 0
0 11 -1 0
0 39 0 1
0 30 -1 11
1
end_operator
begin_operator
stack b6 b1
0
4
0 17 18 0
0 16 0 1
0 27 -1 0
0 25 -1 0
1
end_operator
begin_operator
stack b7 b17
0
4
0 17 19 0
0 15 0 1
0 6 -1 0
0 22 -1 0
1
end_operator
begin_operator
stack b8 b10
0
4
0 17 20 0
0 9 0 1
0 7 -1 0
0 23 -1 0
1
end_operator
begin_operator
stack b9 b1
0
4
0 17 21 0
0 16 0 1
0 39 -1 0
0 34 -1 0
1
end_operator
begin_operator
stack b9 b11
0
4
0 17 21 0
0 4 0 1
0 39 -1 0
0 34 -1 1
1
end_operator
begin_operator
stack b9 b12
0
4
0 17 21 0
0 1 0 1
0 39 -1 0
0 34 -1 2
1
end_operator
begin_operator
stack b9 b13
0
4
0 17 21 0
0 5 0 1
0 39 -1 0
0 34 -1 3
1
end_operator
begin_operator
stack b9 b14
0
4
0 17 21 0
0 10 0 1
0 39 -1 0
0 34 -1 4
1
end_operator
begin_operator
stack b9 b15
0
4
0 17 21 0
0 3 0 1
0 39 -1 0
0 34 -1 5
1
end_operator
begin_operator
stack b9 b16
0
4
0 17 21 0
0 13 0 1
0 39 -1 0
0 34 -1 6
1
end_operator
begin_operator
stack b9 b17
0
4
0 17 21 0
0 15 0 1
0 39 -1 0
0 34 -1 7
1
end_operator
begin_operator
stack b9 b18
0
4
0 17 21 0
0 40 0 3
0 39 -1 0
0 34 -1 8
1
end_operator
begin_operator
stack b9 b19
0
4
0 17 21 0
0 2 0 1
0 39 -1 0
0 34 -1 9
1
end_operator
begin_operator
stack b9 b20
0
4
0 17 21 0
0 32 0 1
0 39 -1 0
0 34 -1 10
1
end_operator
begin_operator
stack b9 b4
0
4
0 17 21 0
0 14 0 1
0 39 -1 0
0 34 -1 11
1
end_operator
begin_operator
stack b9 b7
0
4
0 17 21 0
0 6 0 1
0 39 -1 0
0 34 -1 12
1
end_operator
begin_operator
stack b9 b8
0
4
0 17 21 0
0 7 0 1
0 39 -1 0
0 34 -1 13
1
end_operator
begin_operator
unstack b1 b11
0
4
0 17 0 1
0 16 0 1
0 4 -1 0
0 35 0 16
1
end_operator
begin_operator
unstack b1 b12
0
4
0 17 0 1
0 16 0 1
0 1 -1 0
0 35 1 16
1
end_operator
begin_operator
unstack b1 b13
0
4
0 17 0 1
0 16 0 1
0 5 -1 0
0 35 2 16
1
end_operator
begin_operator
unstack b1 b14
0
4
0 17 0 1
0 16 0 1
0 10 -1 0
0 35 3 16
1
end_operator
begin_operator
unstack b1 b15
0
4
0 17 0 1
0 16 0 1
0 3 -1 0
0 35 4 16
1
end_operator
begin_operator
unstack b1 b16
0
4
0 17 0 1
0 16 0 1
0 13 -1 0
0 35 5 16
1
end_operator
begin_operator
unstack b1 b19
0
4
0 17 0 1
0 16 0 1
0 2 -1 0
0 35 6 16
1
end_operator
begin_operator
unstack b1 b2
0
4
0 17 0 1
0 16 0 1
0 12 -1 0
0 35 7 16
1
end_operator
begin_operator
unstack b1 b20
0
4
0 17 0 1
0 16 0 1
0 32 -1 0
0 35 8 16
1
end_operator
begin_operator
unstack b1 b21
0
4
0 17 0 1
0 16 0 1
0 8 -1 0
0 35 9 16
1
end_operator
begin_operator
unstack b1 b4
0
4
0 17 0 1
0 16 0 1
0 14 -1 0
0 35 10 16
1
end_operator
begin_operator
unstack b1 b5
0
4
0 17 0 1
0 16 0 1
0 11 -1 0
0 35 11 16
1
end_operator
begin_operator
unstack b1 b7
0
4
0 17 0 1
0 16 0 1
0 6 -1 0
0 35 12 16
1
end_operator
begin_operator
unstack b1 b8
0
4
0 17 0 1
0 16 0 1
0 7 -1 0
0 35 13 16
1
end_operator
begin_operator
unstack b1 b9
0
4
0 17 0 1
0 16 0 1
0 39 -1 0
0 35 14 16
1
end_operator
begin_operator
unstack b10 b1
0
4
0 17 0 2
0 16 -1 0
0 9 0 1
0 33 0 14
1
end_operator
begin_operator
unstack b10 b11
0
4
0 17 0 2
0 9 0 1
0 4 -1 0
0 33 1 14
1
end_operator
begin_operator
unstack b10 b13
0
4
0 17 0 2
0 9 0 1
0 5 -1 0
0 33 2 14
1
end_operator
begin_operator
unstack b10 b14
0
4
0 17 0 2
0 9 0 1
0 10 -1 0
0 33 3 14
1
end_operator
begin_operator
unstack b10 b16
0
4
0 17 0 2
0 9 0 1
0 13 -1 0
0 33 4 14
1
end_operator
begin_operator
unstack b10 b18
0
4
0 17 0 2
0 9 0 1
0 40 -1 0
0 33 5 14
1
end_operator
begin_operator
unstack b10 b2
0
4
0 17 0 2
0 9 0 1
0 12 -1 0
0 33 6 14
1
end_operator
begin_operator
unstack b10 b21
0
4
0 17 0 2
0 9 0 1
0 8 -1 0
0 33 7 14
1
end_operator
begin_operator
unstack b10 b4
0
4
0 17 0 2
0 9 0 1
0 14 -1 0
0 33 8 14
1
end_operator
begin_operator
unstack b10 b5
0
4
0 17 0 2
0 9 0 1
0 11 -1 0
0 33 9 14
1
end_operator
begin_operator
unstack b10 b7
0
4
0 17 0 2
0 9 0 1
0 6 -1 0
0 33 10 14
1
end_operator
begin_operator
unstack b10 b8
0
4
0 17 0 2
0 9 0 1
0 7 -1 0
0 33 11 14
1
end_operator
begin_operator
unstack b10 b9
0
4
0 17 0 2
0 9 0 1
0 39 -1 0
0 33 12 14
1
end_operator
begin_operator
unstack b11 b1
0
4
0 17 0 3
0 16 -1 0
0 4 0 1
0 24 0 3
1
end_operator
begin_operator
unstack b12 b14
0
4
0 17 0 4
0 1 0 1
0 10 -1 0
0 18 0 2
1
end_operator
begin_operator
unstack b13 b21
0
4
0 17 0 5
0 5 0 1
0 8 -1 0
0 20 0 2
1
end_operator
begin_operator
unstack b14 b1
0
4
0 17 0 6
0 16 -1 0
0 10 0 1
0 29 0 13
1
end_operator
begin_operator
unstack b14 b10
0
4
0 17 0 6
0 9 -1 0
0 10 0 1
0 29 1 13
1
end_operator
begin_operator
unstack b14 b11
0
4
0 17 0 6
0 4 -1 0
0 10 0 1
0 29 2 13
1
end_operator
begin_operator
unstack b14 b13
0
4
0 17 0 6
0 5 -1 0
0 10 0 1
0 29 3 13
1
end_operator
begin_operator
unstack b14 b16
0
4
0 17 0 6
0 10 0 1
0 13 -1 0
0 29 4 13
1
end_operator
begin_operator
unstack b14 b17
0
4
0 17 0 6
0 10 0 1
0 15 -1 0
0 29 5 13
1
end_operator
begin_operator
unstack b14 b18
0
4
0 17 0 6
0 10 0 1
0 40 -1 0
0 29 6 13
1
end_operator
begin_operator
unstack b14 b2
0
4
0 17 0 6
0 10 0 1
0 12 -1 0
0 29 7 13
1
end_operator
begin_operator
unstack b14 b21
0
4
0 17 0 6
0 10 0 1
0 8 -1 0
0 29 8 13
1
end_operator
begin_operator
unstack b14 b5
0
4
0 17 0 6
0 10 0 1
0 11 -1 0
0 29 9 13
1
end_operator
begin_operator
unstack b14 b7
0
4
0 17 0 6
0 10 0 1
0 6 -1 0
0 29 10 13
1
end_operator
begin_operator
unstack b14 b8
0
4
0 17 0 6
0 10 0 1
0 7 -1 0
0 29 11 13
1
end_operator
begin_operator
unstack b15 b18
0
3
0 17 0 7
0 3 0 1
0 40 1 0
1
end_operator
begin_operator
unstack b16 b1
0
4
0 17 0 8
0 16 -1 0
0 13 0 1
0 28 0 12
1
end_operator
begin_operator
unstack b16 b13
0
4
0 17 0 8
0 5 -1 0
0 13 0 1
0 28 1 12
1
end_operator
begin_operator
unstack b16 b14
0
4
0 17 0 8
0 10 -1 0
0 13 0 1
0 28 2 12
1
end_operator
begin_operator
unstack b16 b17
0
4
0 17 0 8
0 13 0 1
0 15 -1 0
0 28 3 12
1
end_operator
begin_operator
unstack b16 b18
0
4
0 17 0 8
0 13 0 1
0 40 -1 0
0 28 4 12
1
end_operator
begin_operator
unstack b16 b2
0
4
0 17 0 8
0 13 0 1
0 12 -1 0
0 28 5 12
1
end_operator
begin_operator
unstack b16 b21
0
4
0 17 0 8
0 13 0 1
0 8 -1 0
0 28 6 12
1
end_operator
begin_operator
unstack b16 b4
0
4
0 17 0 8
0 13 0 1
0 14 -1 0
0 28 7 12
1
end_operator
begin_operator
unstack b16 b7
0
4
0 17 0 8
0 13 0 1
0 6 -1 0
0 28 8 12
1
end_operator
begin_operator
unstack b16 b8
0
4
0 17 0 8
0 13 0 1
0 7 -1 0
0 28 9 12
1
end_operator
begin_operator
unstack b16 b9
0
4
0 17 0 8
0 13 0 1
0 39 -1 0
0 28 10 12
1
end_operator
begin_operator
unstack b17 b11
0
4
0 17 0 9
0 4 -1 0
0 15 0 1
0 37 0 16
1
end_operator
begin_operator
unstack b17 b13
0
4
0 17 0 9
0 5 -1 0
0 15 0 1
0 37 1 16
1
end_operator
begin_operator
unstack b17 b14
0
4
0 17 0 9
0 10 -1 0
0 15 0 1
0 37 2 16
1
end_operator
begin_operator
unstack b17 b15
0
4
0 17 0 9
0 3 -1 0
0 15 0 1
0 37 3 16
1
end_operator
begin_operator
unstack b17 b16
0
4
0 17 0 9
0 13 -1 0
0 15 0 1
0 37 4 16
1
end_operator
begin_operator
unstack b17 b18
0
4
0 17 0 9
0 15 0 1
0 40 -1 0
0 37 5 16
1
end_operator
begin_operator
unstack b17 b19
0
4
0 17 0 9
0 15 0 1
0 2 -1 0
0 37 6 16
1
end_operator
begin_operator
unstack b17 b2
0
4
0 17 0 9
0 15 0 1
0 12 -1 0
0 37 7 16
1
end_operator
begin_operator
unstack b17 b20
0
4
0 17 0 9
0 15 0 1
0 32 -1 0
0 37 8 16
1
end_operator
begin_operator
unstack b17 b21
0
4
0 17 0 9
0 15 0 1
0 8 -1 0
0 37 9 16
1
end_operator
begin_operator
unstack b17 b4
0
4
0 17 0 9
0 15 0 1
0 14 -1 0
0 37 10 16
1
end_operator
begin_operator
unstack b17 b5
0
4
0 17 0 9
0 15 0 1
0 11 -1 0
0 37 11 16
1
end_operator
begin_operator
unstack b17 b7
0
4
0 17 0 9
0 15 0 1
0 6 -1 0
0 37 12 16
1
end_operator
begin_operator
unstack b17 b8
0
4
0 17 0 9
0 15 0 1
0 7 -1 0
0 37 13 16
1
end_operator
begin_operator
unstack b17 b9
0
4
0 17 0 9
0 15 0 1
0 39 -1 0
0 37 14 16
1
end_operator
begin_operator
unstack b18 b1
0
4
0 17 0 10
0 16 -1 0
0 40 0 3
0 38 0 17
1
end_operator
begin_operator
unstack b18 b11
0
4
0 17 0 10
0 4 -1 0
0 40 0 3
0 38 1 17
1
end_operator
begin_operator
unstack b18 b12
0
4
0 17 0 10
0 1 -1 0
0 40 0 3
0 38 2 17
1
end_operator
begin_operator
unstack b18 b13
0
4
0 17 0 10
0 5 -1 0
0 40 0 3
0 38 3 17
1
end_operator
begin_operator
unstack b18 b14
0
4
0 17 0 10
0 10 -1 0
0 40 0 3
0 38 4 17
1
end_operator
begin_operator
unstack b18 b15
0
4
0 17 0 10
0 3 -1 0
0 40 0 3
0 38 5 17
1
end_operator
begin_operator
unstack b18 b16
0
4
0 17 0 10
0 13 -1 0
0 40 0 3
0 38 6 17
1
end_operator
begin_operator
unstack b18 b17
0
4
0 17 0 10
0 15 -1 0
0 40 0 3
0 38 7 17
1
end_operator
begin_operator
unstack b18 b19
0
4
0 17 0 10
0 40 0 3
0 2 -1 0
0 38 8 17
1
end_operator
begin_operator
unstack b18 b2
0
4
0 17 0 10
0 40 0 3
0 12 -1 0
0 38 9 17
1
end_operator
begin_operator
unstack b18 b20
0
4
0 17 0 10
0 40 0 3
0 32 -1 0
0 38 10 17
1
end_operator
begin_operator
unstack b18 b21
0
4
0 17 0 10
0 40 0 3
0 8 -1 0
0 38 11 17
1
end_operator
begin_operator
unstack b18 b5
0
4
0 17 0 10
0 40 0 3
0 11 -1 0
0 38 12 17
1
end_operator
begin_operator
unstack b18 b7
0
4
0 17 0 10
0 40 0 3
0 6 -1 0
0 38 13 17
1
end_operator
begin_operator
unstack b18 b8
0
4
0 17 0 10
0 40 0 3
0 7 -1 0
0 38 14 17
1
end_operator
begin_operator
unstack b18 b9
0
4
0 17 0 10
0 40 0 3
0 39 -1 0
0 38 15 17
1
end_operator
begin_operator
unstack b19 b5
0
4
0 17 0 11
0 2 0 1
0 11 -1 0
0 19 0 2
1
end_operator
begin_operator
unstack b2 b1
0
4
0 17 0 12
0 16 -1 0
0 12 0 1
0 31 0 13
1
end_operator
begin_operator
unstack b2 b11
0
4
0 17 0 12
0 4 -1 0
0 12 0 1
0 31 1 13
1
end_operator
begin_operator
unstack b2 b13
0
4
0 17 0 12
0 5 -1 0
0 12 0 1
0 31 2 13
1
end_operator
begin_operator
unstack b2 b16
0
4
0 17 0 12
0 13 -1 0
0 12 0 1
0 31 3 13
1
end_operator
begin_operator
unstack b2 b17
0
4
0 17 0 12
0 15 -1 0
0 12 0 1
0 31 4 13
1
end_operator
begin_operator
unstack b2 b18
0
4
0 17 0 12
0 40 -1 0
0 12 0 1
0 31 5 13
1
end_operator
begin_operator
unstack b2 b20
0
4
0 17 0 12
0 12 0 1
0 32 -1 0
0 31 6 13
1
end_operator
begin_operator
unstack b2 b21
0
4
0 17 0 12
0 12 0 1
0 8 -1 0
0 31 7 13
1
end_operator
begin_operator
unstack b2 b5
0
4
0 17 0 12
0 12 0 1
0 11 -1 0
0 31 8 13
1
end_operator
begin_operator
unstack b2 b7
0
4
0 17 0 12
0 12 0 1
0 6 -1 0
0 31 9 13
1
end_operator
begin_operator
unstack b2 b8
0
4
0 17 0 12
0 12 0 1
0 7 -1 0
0 31 10 13
1
end_operator
begin_operator
unstack b2 b9
0
4
0 17 0 12
0 12 0 1
0 39 -1 0
0 31 11 13
1
end_operator
begin_operator
unstack b20 b3
0
3
0 17 0 13
0 32 0 1
0 26 1 0
1
end_operator
begin_operator
unstack b21 b13
0
4
0 17 0 14
0 5 -1 0
0 8 0 1
0 21 0 3
1
end_operator
begin_operator
unstack b3 b18
0
3
0 17 0 15
0 40 2 0
0 26 0 2
1
end_operator
begin_operator
unstack b4 b1
0
4
0 17 0 16
0 16 -1 0
0 14 0 1
0 36 0 16
1
end_operator
begin_operator
unstack b4 b11
0
4
0 17 0 16
0 4 -1 0
0 14 0 1
0 36 1 16
1
end_operator
begin_operator
unstack b4 b12
0
4
0 17 0 16
0 1 -1 0
0 14 0 1
0 36 2 16
1
end_operator
begin_operator
unstack b4 b13
0
4
0 17 0 16
0 5 -1 0
0 14 0 1
0 36 3 16
1
end_operator
begin_operator
unstack b4 b15
0
4
0 17 0 16
0 3 -1 0
0 14 0 1
0 36 4 16
1
end_operator
begin_operator
unstack b4 b16
0
4
0 17 0 16
0 13 -1 0
0 14 0 1
0 36 5 16
1
end_operator
begin_operator
unstack b4 b17
0
4
0 17 0 16
0 15 -1 0
0 14 0 1
0 36 6 16
1
end_operator
begin_operator
unstack b4 b18
0
4
0 17 0 16
0 40 -1 0
0 14 0 1
0 36 7 16
1
end_operator
begin_operator
unstack b4 b19
0
4
0 17 0 16
0 2 -1 0
0 14 0 1
0 36 8 16
1
end_operator
begin_operator
unstack b4 b2
0
4
0 17 0 16
0 12 -1 0
0 14 0 1
0 36 9 16
1
end_operator
begin_operator
unstack b4 b20
0
4
0 17 0 16
0 32 -1 0
0 14 0 1
0 36 10 16
1
end_operator
begin_operator
unstack b4 b21
0
4
0 17 0 16
0 8 -1 0
0 14 0 1
0 36 11 16
1
end_operator
begin_operator
unstack b4 b5
0
4
0 17 0 16
0 14 0 1
0 11 -1 0
0 36 12 16
1
end_operator
begin_operator
unstack b4 b7
0
4
0 17 0 16
0 14 0 1
0 6 -1 0
0 36 13 16
1
end_operator
begin_operator
unstack b4 b8
0
4
0 17 0 16
0 14 0 1
0 7 -1 0
0 36 14 16
1
end_operator
begin_operator
unstack b5 b1
0
4
0 17 0 17
0 16 -1 0
0 11 0 1
0 30 0 13
1
end_operator
begin_operator
unstack b5 b13
0
4
0 17 0 17
0 5 -1 0
0 11 0 1
0 30 1 13
1
end_operator
begin_operator
unstack b5 b14
0
4
0 17 0 17
0 10 -1 0
0 11 0 1
0 30 2 13
1
end_operator
begin_operator
unstack b5 b16
0
4
0 17 0 17
0 13 -1 0
0 11 0 1
0 30 3 13
1
end_operator
begin_operator
unstack b5 b17
0
4
0 17 0 17
0 15 -1 0
0 11 0 1
0 30 4 13
1
end_operator
begin_operator
unstack b5 b18
0
4
0 17 0 17
0 40 -1 0
0 11 0 1
0 30 5 13
1
end_operator
begin_operator
unstack b5 b2
0
4
0 17 0 17
0 12 -1 0
0 11 0 1
0 30 6 13
1
end_operator
begin_operator
unstack b5 b21
0
4
0 17 0 17
0 8 -1 0
0 11 0 1
0 30 7 13
1
end_operator
begin_operator
unstack b5 b4
0
4
0 17 0 17
0 14 -1 0
0 11 0 1
0 30 8 13
1
end_operator
begin_operator
unstack b5 b7
0
4
0 17 0 17
0 11 0 1
0 6 -1 0
0 30 9 13
1
end_operator
begin_operator
unstack b5 b8
0
4
0 17 0 17
0 11 0 1
0 7 -1 0
0 30 10 13
1
end_operator
begin_operator
unstack b5 b9
0
4
0 17 0 17
0 11 0 1
0 39 -1 0
0 30 11 13
1
end_operator
begin_operator
unstack b6 b1
0
4
0 17 0 18
0 16 -1 0
0 27 0 1
0 25 0 2
1
end_operator
begin_operator
unstack b7 b21
0
4
0 17 0 19
0 8 -1 0
0 6 0 1
0 22 1 3
1
end_operator
begin_operator
unstack b8 b6
0
4
0 17 0 20
0 27 -1 0
0 7 0 1
0 23 1 3
1
end_operator
begin_operator
unstack b9 b1
0
4
0 17 0 21
0 16 -1 0
0 39 0 1
0 34 0 15
1
end_operator
begin_operator
unstack b9 b11
0
4
0 17 0 21
0 4 -1 0
0 39 0 1
0 34 1 15
1
end_operator
begin_operator
unstack b9 b12
0
4
0 17 0 21
0 1 -1 0
0 39 0 1
0 34 2 15
1
end_operator
begin_operator
unstack b9 b14
0
4
0 17 0 21
0 10 -1 0
0 39 0 1
0 34 4 15
1
end_operator
begin_operator
unstack b9 b15
0
4
0 17 0 21
0 3 -1 0
0 39 0 1
0 34 5 15
1
end_operator
begin_operator
unstack b9 b16
0
4
0 17 0 21
0 13 -1 0
0 39 0 1
0 34 6 15
1
end_operator
begin_operator
unstack b9 b17
0
4
0 17 0 21
0 15 -1 0
0 39 0 1
0 34 7 15
1
end_operator
begin_operator
unstack b9 b18
0
4
0 17 0 21
0 40 -1 0
0 39 0 1
0 34 8 15
1
end_operator
begin_operator
unstack b9 b19
0
4
0 17 0 21
0 2 -1 0
0 39 0 1
0 34 9 15
1
end_operator
begin_operator
unstack b9 b20
0
4
0 17 0 21
0 32 -1 0
0 39 0 1
0 34 10 15
1
end_operator
begin_operator
unstack b9 b4
0
4
0 17 0 21
0 14 -1 0
0 39 0 1
0 34 11 15
1
end_operator
begin_operator
unstack b9 b7
0
4
0 17 0 21
0 6 -1 0
0 39 0 1
0 34 12 15
1
end_operator
begin_operator
unstack b9 b8
0
4
0 17 0 21
0 7 -1 0
0 39 0 1
0 34 13 15
1
end_operator
0
