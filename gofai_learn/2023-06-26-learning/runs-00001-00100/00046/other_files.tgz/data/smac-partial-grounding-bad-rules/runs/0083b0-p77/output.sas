begin_version
3
end_version
begin_metric
0
end_metric
47
begin_variable
var0
-1
2
Atom on-table(b15)
NegatedAtom on-table(b15)
end_variable
begin_variable
var1
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var2
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var3
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var4
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var5
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var10
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var6
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var7
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var9
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var11
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var13
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var12
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var14
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var15
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var17
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var16
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var18
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var19
-1
13
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b12)
Atom holding(b14)
Atom holding(b15)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b3)
Atom holding(b7)
Atom holding(b8)
<none of those>
end_variable
begin_variable
var20
-1
3
Atom on(b21, b9)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var21
-1
3
Atom on(b3, b15)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var22
-1
3
Atom on(b8, b7)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var23
-1
3
Atom on(b1, b19)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b10, b21)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom on(b12, b10)
Atom on(b12, b3)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom on(b20, b12)
Atom on(b20, b14)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom on(b7, b1)
Atom on(b7, b18)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var41
-1
4
Atom holding(b11)
Atom on(b11, b13)
Atom on(b11, b8)
Atom on-table(b11)
end_variable
begin_variable
var28
-1
3
Atom on(b2, b4)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var33
-1
5
Atom holding(b9)
Atom on(b9, b16)
Atom on(b9, b20)
Atom on(b9, b6)
Atom on-table(b9)
end_variable
begin_variable
var35
-1
9
Atom holding(b18)
Atom on(b18, b15)
Atom on(b18, b16)
Atom on(b18, b20)
Atom on(b18, b22)
Atom on(b18, b4)
Atom on(b18, b5)
Atom on(b18, b9)
Atom on-table(b18)
end_variable
begin_variable
var31
-1
9
Atom holding(b16)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b18)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b5)
Atom on-table(b16)
end_variable
begin_variable
var37
-1
12
Atom holding(b22)
Atom on(b22, b1)
Atom on(b22, b14)
Atom on(b22, b15)
Atom on(b22, b16)
Atom on(b22, b18)
Atom on(b22, b21)
Atom on(b22, b23)
Atom on(b22, b4)
Atom on(b22, b5)
Atom on(b22, b9)
Atom on-table(b22)
end_variable
begin_variable
var29
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var30
-1
4
Atom clear(b2)
Atom on(b14, b2)
Atom on(b15, b2)
<none of those>
end_variable
begin_variable
var42
-1
16
Atom holding(b17)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b20)
Atom on(b17, b22)
Atom on(b17, b23)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b7)
Atom on(b17, b9)
Atom on-table(b17)
end_variable
begin_variable
var36
-1
17
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b19)
Atom on(b13, b20)
Atom on(b13, b22)
Atom on(b13, b23)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var38
-1
17
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b13)
Atom on(b4, b15)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b19)
Atom on(b4, b2)
Atom on(b4, b20)
Atom on(b4, b22)
Atom on(b4, b23)
Atom on(b4, b5)
Atom on(b4, b7)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var39
-1
17
Atom holding(b5)
Atom on(b5, b1)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b15)
Atom on(b5, b16)
Atom on(b5, b17)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b22)
Atom on(b5, b23)
Atom on(b5, b4)
Atom on(b5, b7)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var40
-1
17
Atom holding(b23)
Atom on(b23, b11)
Atom on(b23, b12)
Atom on(b23, b14)
Atom on(b23, b16)
Atom on(b23, b17)
Atom on(b23, b18)
Atom on(b23, b19)
Atom on(b23, b2)
Atom on(b23, b20)
Atom on(b23, b21)
Atom on(b23, b22)
Atom on(b23, b4)
Atom on(b23, b5)
Atom on(b23, b7)
Atom on(b23, b9)
Atom on-table(b23)
end_variable
begin_variable
var34
-1
17
Atom holding(b6)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b16)
Atom on(b6, b18)
Atom on(b6, b19)
Atom on(b6, b2)
Atom on(b6, b21)
Atom on(b6, b22)
Atom on(b6, b23)
Atom on(b6, b4)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var32
-1
18
Atom holding(b19)
Atom on(b19, b1)
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b12)
Atom on(b19, b13)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b18)
Atom on(b19, b2)
Atom on(b19, b20)
Atom on(b19, b22)
Atom on(b19, b23)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
end_variable
begin_variable
var43
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var45
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var44
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var46
-1
2
Atom on-table(b14)
NegatedAtom on-table(b14)
end_variable
1613
begin_mutex_group
24
19 0
19 1
19 2
19 3
19 4
19 5
19 6
19 7
19 8
19 9
19 10
19 11
28 0
37 0
32 0
36 0
31 0
42 0
33 0
40 0
38 0
39 0
41 0
30 0
end_mutex_group
begin_mutex_group
8
19 1
5 0
37 1
42 1
33 1
38 1
39 1
27 0
end_mutex_group
begin_mutex_group
7
19 2
3 0
37 2
36 1
42 2
38 2
25 0
end_mutex_group
begin_mutex_group
8
6 0
28 0
37 3
36 2
42 3
40 1
38 3
41 1
end_mutex_group
begin_mutex_group
9
19 3
9 0
37 4
36 3
42 4
40 2
39 2
41 2
26 0
end_mutex_group
begin_mutex_group
9
15 0
28 1
37 0
32 1
36 4
42 5
38 4
39 3
41 3
end_mutex_group
begin_mutex_group
7
19 4
34 0
32 2
33 2
40 3
41 4
26 1
end_mutex_group
begin_mutex_group
9
19 5
7 0
37 5
31 1
42 6
33 3
38 5
39 4
21 0
end_mutex_group
begin_mutex_group
12
12 0
37 6
32 0
36 5
31 2
42 7
33 4
40 4
38 6
39 5
41 5
30 1
end_mutex_group
begin_mutex_group
6
13 0
37 7
36 0
40 5
38 7
39 6
end_mutex_group
begin_mutex_group
10
11 0
32 3
36 6
31 0
42 8
33 5
40 6
39 7
41 6
27 1
end_mutex_group
begin_mutex_group
9
17 0
37 8
36 7
42 0
40 7
38 8
39 8
41 7
23 0
end_mutex_group
begin_mutex_group
9
19 6
35 0
35 1
35 2
42 9
40 8
38 9
39 9
41 8
end_mutex_group
begin_mutex_group
10
19 7
10 0
37 9
36 8
31 3
42 10
40 9
38 10
39 10
30 2
end_mutex_group
begin_mutex_group
7
19 8
4 0
32 4
33 6
40 10
41 9
24 0
end_mutex_group
begin_mutex_group
11
14 0
37 10
32 5
36 9
31 4
42 11
33 0
40 11
38 11
39 11
41 10
end_mutex_group
begin_mutex_group
10
45 0
37 11
32 6
36 10
42 12
33 7
40 0
38 12
39 12
41 11
end_mutex_group
begin_mutex_group
3
19 9
1 0
25 1
end_mutex_group
begin_mutex_group
11
18 0
37 12
36 11
31 5
42 13
33 8
40 12
38 0
39 13
41 12
29 0
end_mutex_group
begin_mutex_group
10
16 0
37 13
32 7
36 12
31 6
42 14
33 9
40 13
38 13
39 0
end_mutex_group
begin_mutex_group
3
43 0
41 0
30 3
end_mutex_group
begin_mutex_group
9
19 10
8 0
36 13
42 15
40 14
38 14
39 14
41 13
22 0
end_mutex_group
begin_mutex_group
5
19 11
2 0
28 2
37 14
41 14
end_mutex_group
begin_mutex_group
12
44 0
37 15
36 14
31 7
42 16
33 10
40 15
38 15
39 15
41 15
30 0
20 0
end_mutex_group
begin_mutex_group
3
19 1
23 0
23 1
end_mutex_group
begin_mutex_group
3
19 2
24 0
24 1
end_mutex_group
begin_mutex_group
4
19 3
25 0
25 1
25 2
end_mutex_group
begin_mutex_group
3
19 4
35 1
46 0
end_mutex_group
begin_mutex_group
3
19 5
35 2
0 0
end_mutex_group
begin_mutex_group
3
19 6
29 0
29 1
end_mutex_group
begin_mutex_group
4
19 7
26 0
26 1
26 2
end_mutex_group
begin_mutex_group
3
19 8
20 0
20 1
end_mutex_group
begin_mutex_group
3
19 9
21 0
21 1
end_mutex_group
begin_mutex_group
4
19 10
27 0
27 1
27 2
end_mutex_group
begin_mutex_group
3
19 11
22 0
22 1
end_mutex_group
begin_mutex_group
2
0 1
19 9
end_mutex_group
begin_mutex_group
2
0 1
21 0
end_mutex_group
begin_mutex_group
2
0 1
21 2
end_mutex_group
begin_mutex_group
2
1 0
21 2
end_mutex_group
begin_mutex_group
2
2 0
22 2
end_mutex_group
begin_mutex_group
2
2 0
28 1
end_mutex_group
begin_mutex_group
2
3 0
24 2
end_mutex_group
begin_mutex_group
2
4 0
20 2
end_mutex_group
begin_mutex_group
2
5 0
19 11
end_mutex_group
begin_mutex_group
2
5 0
22 0
end_mutex_group
begin_mutex_group
2
5 0
22 2
end_mutex_group
begin_mutex_group
2
5 0
23 2
end_mutex_group
begin_mutex_group
2
5 0
28 1
end_mutex_group
begin_mutex_group
2
7 1
19 9
end_mutex_group
begin_mutex_group
2
7 1
21 2
end_mutex_group
begin_mutex_group
2
9 0
25 3
end_mutex_group
begin_mutex_group
2
8 0
27 3
end_mutex_group
begin_mutex_group
2
8 0
28 1
end_mutex_group
begin_mutex_group
2
8 1
19 11
end_mutex_group
begin_mutex_group
2
8 1
22 2
end_mutex_group
begin_mutex_group
2
10 0
19 8
end_mutex_group
begin_mutex_group
2
10 0
20 0
end_mutex_group
begin_mutex_group
2
10 0
20 2
end_mutex_group
begin_mutex_group
2
10 0
26 3
end_mutex_group
begin_mutex_group
2
17 0
19 8
end_mutex_group
begin_mutex_group
2
17 0
20 0
end_mutex_group
begin_mutex_group
2
17 0
20 2
end_mutex_group
begin_mutex_group
2
19 0
20 2
end_mutex_group
begin_mutex_group
2
19 0
21 2
end_mutex_group
begin_mutex_group
2
19 0
22 2
end_mutex_group
begin_mutex_group
2
19 0
23 2
end_mutex_group
begin_mutex_group
2
19 0
24 2
end_mutex_group
begin_mutex_group
2
19 0
25 3
end_mutex_group
begin_mutex_group
2
19 0
26 3
end_mutex_group
begin_mutex_group
2
19 0
27 3
end_mutex_group
begin_mutex_group
2
19 0
29 2
end_mutex_group
begin_mutex_group
2
19 1
20 2
end_mutex_group
begin_mutex_group
2
19 1
21 2
end_mutex_group
begin_mutex_group
2
19 1
22 0
end_mutex_group
begin_mutex_group
2
19 1
22 2
end_mutex_group
begin_mutex_group
2
19 1
24 2
end_mutex_group
begin_mutex_group
2
19 1
25 3
end_mutex_group
begin_mutex_group
2
19 1
26 3
end_mutex_group
begin_mutex_group
2
19 1
27 3
end_mutex_group
begin_mutex_group
2
19 1
29 2
end_mutex_group
begin_mutex_group
2
19 1
28 1
end_mutex_group
begin_mutex_group
2
19 2
20 2
end_mutex_group
begin_mutex_group
2
19 2
21 2
end_mutex_group
begin_mutex_group
2
19 2
22 2
end_mutex_group
begin_mutex_group
2
19 2
23 2
end_mutex_group
begin_mutex_group
2
19 2
25 3
end_mutex_group
begin_mutex_group
2
19 2
26 3
end_mutex_group
begin_mutex_group
2
19 2
27 3
end_mutex_group
begin_mutex_group
2
19 2
29 2
end_mutex_group
begin_mutex_group
2
19 3
20 2
end_mutex_group
begin_mutex_group
2
19 3
21 2
end_mutex_group
begin_mutex_group
2
19 3
22 2
end_mutex_group
begin_mutex_group
2
19 3
23 2
end_mutex_group
begin_mutex_group
2
19 3
24 2
end_mutex_group
begin_mutex_group
2
19 3
26 3
end_mutex_group
begin_mutex_group
2
19 3
27 3
end_mutex_group
begin_mutex_group
2
19 3
29 2
end_mutex_group
begin_mutex_group
2
19 4
20 0
end_mutex_group
begin_mutex_group
2
19 4
20 2
end_mutex_group
begin_mutex_group
2
19 4
21 2
end_mutex_group
begin_mutex_group
2
19 4
22 2
end_mutex_group
begin_mutex_group
2
19 4
23 2
end_mutex_group
begin_mutex_group
2
19 4
24 2
end_mutex_group
begin_mutex_group
2
19 4
25 3
end_mutex_group
begin_mutex_group
2
19 4
26 3
end_mutex_group
begin_mutex_group
2
19 4
27 3
end_mutex_group
begin_mutex_group
2
19 4
29 0
end_mutex_group
begin_mutex_group
2
19 4
29 2
end_mutex_group
begin_mutex_group
2
19 4
35 2
end_mutex_group
begin_mutex_group
2
19 4
35 3
end_mutex_group
begin_mutex_group
2
19 4
42 9
end_mutex_group
begin_mutex_group
2
19 4
41 8
end_mutex_group
begin_mutex_group
2
19 4
38 9
end_mutex_group
begin_mutex_group
2
19 4
39 9
end_mutex_group
begin_mutex_group
2
19 4
40 8
end_mutex_group
begin_mutex_group
2
19 5
20 2
end_mutex_group
begin_mutex_group
2
19 5
21 2
end_mutex_group
begin_mutex_group
2
19 5
22 2
end_mutex_group
begin_mutex_group
2
19 5
23 2
end_mutex_group
begin_mutex_group
2
19 5
24 2
end_mutex_group
begin_mutex_group
2
19 5
25 3
end_mutex_group
begin_mutex_group
2
19 5
26 3
end_mutex_group
begin_mutex_group
2
19 5
27 3
end_mutex_group
begin_mutex_group
2
19 5
29 2
end_mutex_group
begin_mutex_group
2
19 6
20 0
end_mutex_group
begin_mutex_group
2
19 6
20 2
end_mutex_group
begin_mutex_group
2
19 6
21 2
end_mutex_group
begin_mutex_group
2
19 6
22 2
end_mutex_group
begin_mutex_group
2
19 6
23 2
end_mutex_group
begin_mutex_group
2
19 6
24 2
end_mutex_group
begin_mutex_group
2
19 6
25 3
end_mutex_group
begin_mutex_group
2
19 6
26 1
end_mutex_group
begin_mutex_group
2
19 6
26 3
end_mutex_group
begin_mutex_group
2
19 6
27 3
end_mutex_group
begin_mutex_group
2
19 7
20 0
end_mutex_group
begin_mutex_group
2
19 7
20 2
end_mutex_group
begin_mutex_group
2
19 7
21 2
end_mutex_group
begin_mutex_group
2
19 7
22 2
end_mutex_group
begin_mutex_group
2
19 7
23 2
end_mutex_group
begin_mutex_group
2
19 7
24 2
end_mutex_group
begin_mutex_group
2
19 7
25 3
end_mutex_group
begin_mutex_group
2
19 7
27 3
end_mutex_group
begin_mutex_group
2
19 7
29 2
end_mutex_group
begin_mutex_group
2
19 8
21 2
end_mutex_group
begin_mutex_group
2
19 8
22 2
end_mutex_group
begin_mutex_group
2
19 8
23 0
end_mutex_group
begin_mutex_group
2
19 8
23 2
end_mutex_group
begin_mutex_group
2
19 8
24 2
end_mutex_group
begin_mutex_group
2
19 8
25 3
end_mutex_group
begin_mutex_group
2
19 8
26 0
end_mutex_group
begin_mutex_group
2
19 8
26 2
end_mutex_group
begin_mutex_group
2
19 8
26 3
end_mutex_group
begin_mutex_group
2
19 8
27 3
end_mutex_group
begin_mutex_group
2
19 8
29 0
end_mutex_group
begin_mutex_group
2
19 8
29 2
end_mutex_group
begin_mutex_group
2
19 8
34 0
end_mutex_group
begin_mutex_group
2
19 8
35 0
end_mutex_group
begin_mutex_group
2
19 8
35 2
end_mutex_group
begin_mutex_group
2
19 8
35 3
end_mutex_group
begin_mutex_group
2
19 8
32 2
end_mutex_group
begin_mutex_group
2
19 8
42 1
end_mutex_group
begin_mutex_group
2
19 8
42 2
end_mutex_group
begin_mutex_group
2
19 8
42 3
end_mutex_group
begin_mutex_group
2
19 8
42 4
end_mutex_group
begin_mutex_group
2
19 8
42 5
end_mutex_group
begin_mutex_group
2
19 8
42 6
end_mutex_group
begin_mutex_group
2
19 8
42 7
end_mutex_group
begin_mutex_group
2
19 8
42 8
end_mutex_group
begin_mutex_group
2
19 8
42 9
end_mutex_group
begin_mutex_group
2
19 8
42 11
end_mutex_group
begin_mutex_group
2
19 8
42 12
end_mutex_group
begin_mutex_group
2
19 8
42 13
end_mutex_group
begin_mutex_group
2
19 8
42 14
end_mutex_group
begin_mutex_group
2
19 8
42 15
end_mutex_group
begin_mutex_group
2
19 8
42 16
end_mutex_group
begin_mutex_group
2
19 8
42 17
end_mutex_group
begin_mutex_group
2
19 8
30 1
end_mutex_group
begin_mutex_group
2
19 8
30 2
end_mutex_group
begin_mutex_group
2
19 8
30 4
end_mutex_group
begin_mutex_group
2
19 8
41 1
end_mutex_group
begin_mutex_group
2
19 8
41 2
end_mutex_group
begin_mutex_group
2
19 8
41 3
end_mutex_group
begin_mutex_group
2
19 8
41 4
end_mutex_group
begin_mutex_group
2
19 8
41 5
end_mutex_group
begin_mutex_group
2
19 8
41 6
end_mutex_group
begin_mutex_group
2
19 8
41 8
end_mutex_group
begin_mutex_group
2
19 8
41 10
end_mutex_group
begin_mutex_group
2
19 8
41 11
end_mutex_group
begin_mutex_group
2
19 8
41 12
end_mutex_group
begin_mutex_group
2
19 8
41 13
end_mutex_group
begin_mutex_group
2
19 8
41 14
end_mutex_group
begin_mutex_group
2
19 8
41 15
end_mutex_group
begin_mutex_group
2
19 8
41 16
end_mutex_group
begin_mutex_group
2
19 8
31 3
end_mutex_group
begin_mutex_group
2
19 8
31 7
end_mutex_group
begin_mutex_group
2
19 8
37 8
end_mutex_group
begin_mutex_group
2
19 8
37 9
end_mutex_group
begin_mutex_group
2
19 8
37 15
end_mutex_group
begin_mutex_group
2
19 8
33 2
end_mutex_group
begin_mutex_group
2
19 8
33 10
end_mutex_group
begin_mutex_group
2
19 8
38 8
end_mutex_group
begin_mutex_group
2
19 8
38 9
end_mutex_group
begin_mutex_group
2
19 8
38 10
end_mutex_group
begin_mutex_group
2
19 8
38 15
end_mutex_group
begin_mutex_group
2
19 8
39 8
end_mutex_group
begin_mutex_group
2
19 8
39 9
end_mutex_group
begin_mutex_group
2
19 8
39 10
end_mutex_group
begin_mutex_group
2
19 8
39 15
end_mutex_group
begin_mutex_group
2
19 8
40 3
end_mutex_group
begin_mutex_group
2
19 8
40 7
end_mutex_group
begin_mutex_group
2
19 8
40 8
end_mutex_group
begin_mutex_group
2
19 8
40 9
end_mutex_group
begin_mutex_group
2
19 8
40 15
end_mutex_group
begin_mutex_group
2
19 8
36 7
end_mutex_group
begin_mutex_group
2
19 8
36 8
end_mutex_group
begin_mutex_group
2
19 8
36 14
end_mutex_group
begin_mutex_group
2
19 8
43 0
end_mutex_group
begin_mutex_group
2
19 8
44 1
end_mutex_group
begin_mutex_group
2
19 8
46 0
end_mutex_group
begin_mutex_group
2
19 9
20 2
end_mutex_group
begin_mutex_group
2
19 9
22 2
end_mutex_group
begin_mutex_group
2
19 9
23 2
end_mutex_group
begin_mutex_group
2
19 9
24 2
end_mutex_group
begin_mutex_group
2
19 9
25 3
end_mutex_group
begin_mutex_group
2
19 9
26 3
end_mutex_group
begin_mutex_group
2
19 9
27 3
end_mutex_group
begin_mutex_group
2
19 9
29 2
end_mutex_group
begin_mutex_group
2
19 9
35 2
end_mutex_group
begin_mutex_group
2
19 9
42 6
end_mutex_group
begin_mutex_group
2
19 9
31 1
end_mutex_group
begin_mutex_group
2
19 9
37 5
end_mutex_group
begin_mutex_group
2
19 9
33 3
end_mutex_group
begin_mutex_group
2
19 9
38 5
end_mutex_group
begin_mutex_group
2
19 9
39 4
end_mutex_group
begin_mutex_group
2
19 10
20 2
end_mutex_group
begin_mutex_group
2
19 10
21 2
end_mutex_group
begin_mutex_group
2
19 10
22 2
end_mutex_group
begin_mutex_group
2
19 10
23 2
end_mutex_group
begin_mutex_group
2
19 10
24 2
end_mutex_group
begin_mutex_group
2
19 10
25 3
end_mutex_group
begin_mutex_group
2
19 10
26 3
end_mutex_group
begin_mutex_group
2
19 10
29 2
end_mutex_group
begin_mutex_group
2
19 10
28 1
end_mutex_group
begin_mutex_group
2
19 11
20 2
end_mutex_group
begin_mutex_group
2
19 11
21 2
end_mutex_group
begin_mutex_group
2
19 11
23 0
end_mutex_group
begin_mutex_group
2
19 11
23 2
end_mutex_group
begin_mutex_group
2
19 11
24 2
end_mutex_group
begin_mutex_group
2
19 11
25 3
end_mutex_group
begin_mutex_group
2
19 11
26 3
end_mutex_group
begin_mutex_group
2
19 11
27 1
end_mutex_group
begin_mutex_group
2
19 11
27 2
end_mutex_group
begin_mutex_group
2
19 11
27 3
end_mutex_group
begin_mutex_group
2
19 11
29 2
end_mutex_group
begin_mutex_group
2
19 11
42 1
end_mutex_group
begin_mutex_group
2
19 11
42 15
end_mutex_group
begin_mutex_group
2
19 11
41 13
end_mutex_group
begin_mutex_group
2
19 11
37 1
end_mutex_group
begin_mutex_group
2
19 11
33 1
end_mutex_group
begin_mutex_group
2
19 11
38 1
end_mutex_group
begin_mutex_group
2
19 11
38 14
end_mutex_group
begin_mutex_group
2
19 11
39 1
end_mutex_group
begin_mutex_group
2
19 11
39 14
end_mutex_group
begin_mutex_group
2
19 11
40 14
end_mutex_group
begin_mutex_group
2
19 11
28 1
end_mutex_group
begin_mutex_group
2
19 11
36 13
end_mutex_group
begin_mutex_group
2
19 12
20 2
end_mutex_group
begin_mutex_group
2
19 12
21 2
end_mutex_group
begin_mutex_group
2
19 12
22 2
end_mutex_group
begin_mutex_group
2
19 12
23 2
end_mutex_group
begin_mutex_group
2
19 12
24 2
end_mutex_group
begin_mutex_group
2
19 12
25 3
end_mutex_group
begin_mutex_group
2
19 12
26 3
end_mutex_group
begin_mutex_group
2
19 12
27 3
end_mutex_group
begin_mutex_group
2
19 12
29 2
end_mutex_group
begin_mutex_group
2
20 0
23 0
end_mutex_group
begin_mutex_group
2
20 0
26 0
end_mutex_group
begin_mutex_group
2
20 0
26 2
end_mutex_group
begin_mutex_group
2
20 0
26 3
end_mutex_group
begin_mutex_group
2
20 0
29 0
end_mutex_group
begin_mutex_group
2
20 0
29 2
end_mutex_group
begin_mutex_group
2
20 0
34 0
end_mutex_group
begin_mutex_group
2
20 0
35 0
end_mutex_group
begin_mutex_group
2
20 0
35 2
end_mutex_group
begin_mutex_group
2
20 0
35 3
end_mutex_group
begin_mutex_group
2
20 0
32 2
end_mutex_group
begin_mutex_group
2
20 0
42 0
end_mutex_group
begin_mutex_group
2
20 0
42 1
end_mutex_group
begin_mutex_group
2
20 0
42 2
end_mutex_group
begin_mutex_group
2
20 0
42 3
end_mutex_group
begin_mutex_group
2
20 0
42 4
end_mutex_group
begin_mutex_group
2
20 0
42 5
end_mutex_group
begin_mutex_group
2
20 0
42 6
end_mutex_group
begin_mutex_group
2
20 0
42 7
end_mutex_group
begin_mutex_group
2
20 0
42 8
end_mutex_group
begin_mutex_group
2
20 0
42 9
end_mutex_group
begin_mutex_group
2
20 0
42 11
end_mutex_group
begin_mutex_group
2
20 0
42 12
end_mutex_group
begin_mutex_group
2
20 0
42 13
end_mutex_group
begin_mutex_group
2
20 0
42 14
end_mutex_group
begin_mutex_group
2
20 0
42 15
end_mutex_group
begin_mutex_group
2
20 0
42 17
end_mutex_group
begin_mutex_group
2
20 0
30 1
end_mutex_group
begin_mutex_group
2
20 0
30 2
end_mutex_group
begin_mutex_group
2
20 0
30 4
end_mutex_group
begin_mutex_group
2
20 0
41 0
end_mutex_group
begin_mutex_group
2
20 0
41 1
end_mutex_group
begin_mutex_group
2
20 0
41 2
end_mutex_group
begin_mutex_group
2
20 0
41 3
end_mutex_group
begin_mutex_group
2
20 0
41 4
end_mutex_group
begin_mutex_group
2
20 0
41 5
end_mutex_group
begin_mutex_group
2
20 0
41 6
end_mutex_group
begin_mutex_group
2
20 0
41 8
end_mutex_group
begin_mutex_group
2
20 0
41 9
end_mutex_group
begin_mutex_group
2
20 0
41 10
end_mutex_group
begin_mutex_group
2
20 0
41 11
end_mutex_group
begin_mutex_group
2
20 0
41 12
end_mutex_group
begin_mutex_group
2
20 0
41 13
end_mutex_group
begin_mutex_group
2
20 0
41 14
end_mutex_group
begin_mutex_group
2
20 0
41 16
end_mutex_group
begin_mutex_group
2
20 0
31 3
end_mutex_group
begin_mutex_group
2
20 0
37 8
end_mutex_group
begin_mutex_group
2
20 0
37 9
end_mutex_group
begin_mutex_group
2
20 0
33 2
end_mutex_group
begin_mutex_group
2
20 0
38 8
end_mutex_group
begin_mutex_group
2
20 0
38 9
end_mutex_group
begin_mutex_group
2
20 0
38 10
end_mutex_group
begin_mutex_group
2
20 0
39 8
end_mutex_group
begin_mutex_group
2
20 0
39 9
end_mutex_group
begin_mutex_group
2
20 0
39 10
end_mutex_group
begin_mutex_group
2
20 0
40 3
end_mutex_group
begin_mutex_group
2
20 0
40 7
end_mutex_group
begin_mutex_group
2
20 0
40 8
end_mutex_group
begin_mutex_group
2
20 0
40 9
end_mutex_group
begin_mutex_group
2
20 0
36 7
end_mutex_group
begin_mutex_group
2
20 0
36 8
end_mutex_group
begin_mutex_group
2
20 0
43 0
end_mutex_group
begin_mutex_group
2
20 0
46 0
end_mutex_group
begin_mutex_group
2
20 2
21 2
end_mutex_group
begin_mutex_group
2
20 2
22 2
end_mutex_group
begin_mutex_group
2
20 2
23 0
end_mutex_group
begin_mutex_group
2
20 2
23 2
end_mutex_group
begin_mutex_group
2
20 2
24 0
end_mutex_group
begin_mutex_group
2
20 2
24 2
end_mutex_group
begin_mutex_group
2
20 2
25 3
end_mutex_group
begin_mutex_group
2
20 2
26 0
end_mutex_group
begin_mutex_group
2
20 2
26 2
end_mutex_group
begin_mutex_group
2
20 2
26 3
end_mutex_group
begin_mutex_group
2
20 2
27 3
end_mutex_group
begin_mutex_group
2
20 2
29 0
end_mutex_group
begin_mutex_group
2
20 2
29 2
end_mutex_group
begin_mutex_group
2
20 2
34 0
end_mutex_group
begin_mutex_group
2
20 2
35 0
end_mutex_group
begin_mutex_group
2
20 2
35 2
end_mutex_group
begin_mutex_group
2
20 2
35 3
end_mutex_group
begin_mutex_group
2
20 2
32 0
end_mutex_group
begin_mutex_group
2
20 2
32 2
end_mutex_group
begin_mutex_group
2
20 2
32 4
end_mutex_group
begin_mutex_group
2
20 2
42 0
end_mutex_group
begin_mutex_group
2
20 2
42 1
end_mutex_group
begin_mutex_group
2
20 2
42 2
end_mutex_group
begin_mutex_group
2
20 2
42 3
end_mutex_group
begin_mutex_group
2
20 2
42 4
end_mutex_group
begin_mutex_group
2
20 2
42 5
end_mutex_group
begin_mutex_group
2
20 2
42 6
end_mutex_group
begin_mutex_group
2
20 2
42 7
end_mutex_group
begin_mutex_group
2
20 2
42 8
end_mutex_group
begin_mutex_group
2
20 2
42 9
end_mutex_group
begin_mutex_group
2
20 2
42 11
end_mutex_group
begin_mutex_group
2
20 2
42 12
end_mutex_group
begin_mutex_group
2
20 2
42 13
end_mutex_group
begin_mutex_group
2
20 2
42 14
end_mutex_group
begin_mutex_group
2
20 2
42 15
end_mutex_group
begin_mutex_group
2
20 2
42 16
end_mutex_group
begin_mutex_group
2
20 2
42 17
end_mutex_group
begin_mutex_group
2
20 2
30 0
end_mutex_group
begin_mutex_group
2
20 2
30 1
end_mutex_group
begin_mutex_group
2
20 2
30 2
end_mutex_group
begin_mutex_group
2
20 2
30 4
end_mutex_group
begin_mutex_group
2
20 2
41 0
end_mutex_group
begin_mutex_group
2
20 2
41 1
end_mutex_group
begin_mutex_group
2
20 2
41 2
end_mutex_group
begin_mutex_group
2
20 2
41 3
end_mutex_group
begin_mutex_group
2
20 2
41 4
end_mutex_group
begin_mutex_group
2
20 2
41 5
end_mutex_group
begin_mutex_group
2
20 2
41 6
end_mutex_group
begin_mutex_group
2
20 2
41 8
end_mutex_group
begin_mutex_group
2
20 2
41 9
end_mutex_group
begin_mutex_group
2
20 2
41 10
end_mutex_group
begin_mutex_group
2
20 2
41 11
end_mutex_group
begin_mutex_group
2
20 2
41 12
end_mutex_group
begin_mutex_group
2
20 2
41 13
end_mutex_group
begin_mutex_group
2
20 2
41 14
end_mutex_group
begin_mutex_group
2
20 2
41 15
end_mutex_group
begin_mutex_group
2
20 2
41 16
end_mutex_gr




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




tdown b11
0
3
0 19 -1 0
0 6 -1 0
0 28 0 3
1
end_operator
begin_operator
putdown b12
0
3
0 19 3 0
0 9 -1 0
0 25 -1 2
1
end_operator
begin_operator
putdown b13
0
3
0 19 -1 0
0 15 -1 0
0 37 0 16
1
end_operator
begin_operator
putdown b14
0
3
0 19 4 0
0 34 -1 0
0 46 -1 0
1
end_operator
begin_operator
putdown b16
0
3
0 19 -1 0
0 12 -1 0
0 32 0 8
1
end_operator
begin_operator
putdown b17
0
3
0 19 -1 0
0 13 -1 0
0 36 0 15
1
end_operator
begin_operator
putdown b18
0
3
0 19 -1 0
0 11 -1 0
0 31 0 8
1
end_operator
begin_operator
putdown b19
0
3
0 19 -1 0
0 17 -1 0
0 42 0 17
1
end_operator
begin_operator
putdown b20
0
3
0 19 7 0
0 10 -1 0
0 26 -1 2
1
end_operator
begin_operator
putdown b21
0
3
0 19 8 0
0 4 -1 0
0 20 -1 1
1
end_operator
begin_operator
putdown b22
0
3
0 19 -1 0
0 14 -1 0
0 33 0 11
1
end_operator
begin_operator
putdown b23
0
3
0 19 -1 0
0 45 -1 0
0 40 0 16
1
end_operator
begin_operator
putdown b3
0
3
0 19 9 0
0 1 -1 0
0 21 -1 1
1
end_operator
begin_operator
putdown b4
0
3
0 19 -1 0
0 18 -1 0
0 38 0 16
1
end_operator
begin_operator
putdown b5
0
3
0 19 -1 0
0 16 -1 0
0 39 0 16
1
end_operator
begin_operator
putdown b6
0
3
0 19 -1 0
0 43 -1 0
0 41 0 16
1
end_operator
begin_operator
putdown b7
0
3
0 19 10 0
0 8 -1 0
0 27 -1 2
1
end_operator
begin_operator
putdown b8
0
3
0 19 11 0
0 2 -1 0
0 22 -1 1
1
end_operator
begin_operator
putdown b9
0
3
0 19 -1 0
0 44 -1 0
0 30 0 4
1
end_operator
begin_operator
stack b1 b19
0
4
0 19 1 0
0 5 -1 0
0 17 0 1
0 23 -1 0
1
end_operator
begin_operator
stack b10 b21
0
4
0 19 2 0
0 3 -1 0
0 4 0 1
0 24 -1 0
1
end_operator
begin_operator
stack b11 b8
0
4
0 19 -1 0
0 6 -1 0
0 2 0 1
0 28 0 2
1
end_operator
begin_operator
stack b12 b3
0
4
0 19 3 0
0 9 -1 0
0 1 0 1
0 25 -1 1
1
end_operator
begin_operator
stack b13 b1
0
4
0 19 -1 0
0 5 0 1
0 15 -1 0
0 37 0 1
1
end_operator
begin_operator
stack b13 b10
0
4
0 19 -1 0
0 3 0 1
0 15 -1 0
0 37 0 2
1
end_operator
begin_operator
stack b13 b11
0
4
0 19 -1 0
0 6 0 1
0 15 -1 0
0 37 0 3
1
end_operator
begin_operator
stack b13 b12
0
4
0 19 -1 0
0 9 0 1
0 15 -1 0
0 37 0 4
1
end_operator
begin_operator
stack b13 b15
0
4
0 19 -1 0
0 15 -1 0
0 7 0 1
0 37 0 5
1
end_operator
begin_operator
stack b13 b16
0
4
0 19 -1 0
0 15 -1 0
0 12 0 1
0 37 0 6
1
end_operator
begin_operator
stack b13 b17
0
4
0 19 -1 0
0 15 -1 0
0 13 0 1
0 37 0 7
1
end_operator
begin_operator
stack b13 b19
0
4
0 19 -1 0
0 15 -1 0
0 17 0 1
0 37 0 8
1
end_operator
begin_operator
stack b13 b20
0
4
0 19 -1 0
0 15 -1 0
0 10 0 1
0 37 0 9
1
end_operator
begin_operator
stack b13 b22
0
4
0 19 -1 0
0 15 -1 0
0 14 0 1
0 37 0 10
1
end_operator
begin_operator
stack b13 b23
0
4
0 19 -1 0
0 15 -1 0
0 45 0 1
0 37 0 11
1
end_operator
begin_operator
stack b13 b4
0
4
0 19 -1 0
0 15 -1 0
0 18 0 1
0 37 0 12
1
end_operator
begin_operator
stack b13 b5
0
4
0 19 -1 0
0 15 -1 0
0 16 0 1
0 37 0 13
1
end_operator
begin_operator
stack b13 b8
0
4
0 19 -1 0
0 15 -1 0
0 2 0 1
0 37 0 14
1
end_operator
begin_operator
stack b13 b9
0
4
0 19 -1 0
0 15 -1 0
0 44 0 1
0 37 0 15
1
end_operator
begin_operator
stack b15 b2
0
3
0 19 5 0
0 7 -1 0
0 35 0 2
1
end_operator
begin_operator
stack b16 b13
0
4
0 19 -1 0
0 15 0 1
0 12 -1 0
0 32 0 1
1
end_operator
begin_operator
stack b16 b14
0
4
0 19 -1 0
0 34 0 1
0 12 -1 0
0 32 0 2
1
end_operator
begin_operator
stack b16 b18
0
4
0 19 -1 0
0 12 -1 0
0 11 0 1
0 32 0 3
1
end_operator
begin_operator
stack b16 b21
0
4
0 19 -1 0
0 12 -1 0
0 4 0 1
0 32 0 4
1
end_operator
begin_operator
stack b16 b22
0
4
0 19 -1 0
0 12 -1 0
0 14 0 1
0 32 0 5
1
end_operator
begin_operator
stack b16 b23
0
4
0 19 -1 0
0 12 -1 0
0 45 0 1
0 32 0 6
1
end_operator
begin_operator
stack b16 b5
0
4
0 19 -1 0
0 12 -1 0
0 16 0 1
0 32 0 7
1
end_operator
begin_operator
stack b17 b10
0
4
0 19 -1 0
0 3 0 1
0 13 -1 0
0 36 0 1
1
end_operator
begin_operator
stack b17 b11
0
4
0 19 -1 0
0 6 0 1
0 13 -1 0
0 36 0 2
1
end_operator
begin_operator
stack b17 b12
0
4
0 19 -1 0
0 9 0 1
0 13 -1 0
0 36 0 3
1
end_operator
begin_operator
stack b17 b13
0
4
0 19 -1 0
0 15 0 1
0 13 -1 0
0 36 0 4
1
end_operator
begin_operator
stack b17 b16
0
4
0 19 -1 0
0 12 0 1
0 13 -1 0
0 36 0 5
1
end_operator
begin_operator
stack b17 b18
0
4
0 19 -1 0
0 13 -1 0
0 11 0 1
0 36 0 6
1
end_operator
begin_operator
stack b17 b19
0
4
0 19 -1 0
0 13 -1 0
0 17 0 1
0 36 0 7
1
end_operator
begin_operator
stack b17 b20
0
4
0 19 -1 0
0 13 -1 0
0 10 0 1
0 36 0 8
1
end_operator
begin_operator
stack b17 b22
0
4
0 19 -1 0
0 13 -1 0
0 14 0 1
0 36 0 9
1
end_operator
begin_operator
stack b17 b23
0
4
0 19 -1 0
0 13 -1 0
0 45 0 1
0 36 0 10
1
end_operator
begin_operator
stack b17 b4
0
4
0 19 -1 0
0 13 -1 0
0 18 0 1
0 36 0 11
1
end_operator
begin_operator
stack b17 b5
0
4
0 19 -1 0
0 13 -1 0
0 16 0 1
0 36 0 12
1
end_operator
begin_operator
stack b17 b7
0
4
0 19 -1 0
0 13 -1 0
0 8 0 1
0 36 0 13
1
end_operator
begin_operator
stack b17 b9
0
4
0 19 -1 0
0 13 -1 0
0 44 0 1
0 36 0 14
1
end_operator
begin_operator
stack b18 b15
0
4
0 19 -1 0
0 7 0 1
0 11 -1 0
0 31 0 1
1
end_operator
begin_operator
stack b18 b16
0
4
0 19 -1 0
0 12 0 1
0 11 -1 0
0 31 0 2
1
end_operator
begin_operator
stack b18 b20
0
4
0 19 -1 0
0 11 -1 0
0 10 0 1
0 31 0 3
1
end_operator
begin_operator
stack b18 b22
0
4
0 19 -1 0
0 11 -1 0
0 14 0 1
0 31 0 4
1
end_operator
begin_operator
stack b18 b4
0
4
0 19 -1 0
0 11 -1 0
0 18 0 1
0 31 0 5
1
end_operator
begin_operator
stack b18 b5
0
4
0 19 -1 0
0 11 -1 0
0 16 0 1
0 31 0 6
1
end_operator
begin_operator
stack b18 b9
0
4
0 19 -1 0
0 11 -1 0
0 44 0 1
0 31 0 7
1
end_operator
begin_operator
stack b19 b1
0
4
0 19 -1 0
0 5 0 1
0 17 -1 0
0 42 0 1
1
end_operator
begin_operator
stack b19 b10
0
4
0 19 -1 0
0 3 0 1
0 17 -1 0
0 42 0 2
1
end_operator
begin_operator
stack b19 b11
0
4
0 19 -1 0
0 6 0 1
0 17 -1 0
0 42 0 3
1
end_operator
begin_operator
stack b19 b12
0
4
0 19 -1 0
0 9 0 1
0 17 -1 0
0 42 0 4
1
end_operator
begin_operator
stack b19 b13
0
4
0 19 -1 0
0 15 0 1
0 17 -1 0
0 42 0 5
1
end_operator
begin_operator
stack b19 b15
0
4
0 19 -1 0
0 7 0 1
0 17 -1 0
0 42 0 6
1
end_operator
begin_operator
stack b19 b16
0
4
0 19 -1 0
0 12 0 1
0 17 -1 0
0 42 0 7
1
end_operator
begin_operator
stack b19 b18
0
4
0 19 -1 0
0 11 0 1
0 17 -1 0
0 42 0 8
1
end_operator
begin_operator
stack b19 b2
0
4
0 19 -1 0
0 17 -1 0
0 35 0 3
0 42 0 9
1
end_operator
begin_operator
stack b19 b20
0
4
0 19 -1 0
0 17 -1 0
0 10 0 1
0 42 0 10
1
end_operator
begin_operator
stack b19 b22
0
4
0 19 -1 0
0 17 -1 0
0 14 0 1
0 42 0 11
1
end_operator
begin_operator
stack b19 b23
0
4
0 19 -1 0
0 17 -1 0
0 45 0 1
0 42 0 12
1
end_operator
begin_operator
stack b19 b4
0
4
0 19 -1 0
0 17 -1 0
0 18 0 1
0 42 0 13
1
end_operator
begin_operator
stack b19 b5
0
4
0 19 -1 0
0 17 -1 0
0 16 0 1
0 42 0 14
1
end_operator
begin_operator
stack b19 b7
0
4
0 19 -1 0
0 17 -1 0
0 8 0 1
0 42 0 15
1
end_operator
begin_operator
stack b19 b9
0
4
0 19 -1 0
0 17 -1 0
0 44 0 1
0 42 0 16
1
end_operator
begin_operator
stack b2 b4
0
4
0 19 6 0
0 35 -1 0
0 18 0 1
0 29 -1 0
1
end_operator
begin_operator
stack b20 b12
0
4
0 19 7 0
0 9 0 1
0 10 -1 0
0 26 -1 0
1
end_operator
begin_operator
stack b22 b1
0
4
0 19 -1 0
0 5 0 1
0 14 -1 0
0 33 0 1
1
end_operator
begin_operator
stack b22 b14
0
4
0 19 -1 0
0 34 0 1
0 14 -1 0
0 33 0 2
1
end_operator
begin_operator
stack b22 b15
0
4
0 19 -1 0
0 7 0 1
0 14 -1 0
0 33 0 3
1
end_operator
begin_operator
stack b22 b16
0
4
0 19 -1 0
0 12 0 1
0 14 -1 0
0 33 0 4
1
end_operator
begin_operator
stack b22 b18
0
4
0 19 -1 0
0 11 0 1
0 14 -1 0
0 33 0 5
1
end_operator
begin_operator
stack b22 b21
0
4
0 19 -1 0
0 4 0 1
0 14 -1 0
0 33 0 6
1
end_operator
begin_operator
stack b22 b23
0
4
0 19 -1 0
0 14 -1 0
0 45 0 1
0 33 0 7
1
end_operator
begin_operator
stack b22 b4
0
4
0 19 -1 0
0 14 -1 0
0 18 0 1
0 33 0 8
1
end_operator
begin_operator
stack b22 b5
0
4
0 19 -1 0
0 14 -1 0
0 16 0 1
0 33 0 9
1
end_operator
begin_operator
stack b22 b9
0
4
0 19 -1 0
0 14 -1 0
0 44 0 1
0 33 0 10
1
end_operator
begin_operator
stack b23 b11
0
4
0 19 -1 0
0 6 0 1
0 45 -1 0
0 40 0 1
1
end_operator
begin_operator
stack b23 b12
0
4
0 19 -1 0
0 9 0 1
0 45 -1 0
0 40 0 2
1
end_operator
begin_operator
stack b23 b14
0
4
0 19 -1 0
0 34 0 1
0 45 -1 0
0 40 0 3
1
end_operator
begin_operator
stack b23 b16
0
4
0 19 -1 0
0 12 0 1
0 45 -1 0
0 40 0 4
1
end_operator
begin_operator
stack b23 b17
0
4
0 19 -1 0
0 13 0 1
0 45 -1 0
0 40 0 5
1
end_operator
begin_operator
stack b23 b18
0
4
0 19 -1 0
0 11 0 1
0 45 -1 0
0 40 0 6
1
end_operator
begin_operator
stack b23 b19
0
4
0 19 -1 0
0 17 0 1
0 45 -1 0
0 40 0 7
1
end_operator
begin_operator
stack b23 b2
0
4
0 19 -1 0
0 35 0 3
0 45 -1 0
0 40 0 8
1
end_operator
begin_operator
stack b23 b20
0
4
0 19 -1 0
0 10 0 1
0 45 -1 0
0 40 0 9
1
end_operator
begin_operator
stack b23 b21
0
4
0 19 -1 0
0 4 0 1
0 45 -1 0
0 40 0 10
1
end_operator
begin_operator
stack b23 b22
0
4
0 19 -1 0
0 14 0 1
0 45 -1 0
0 40 0 11
1
end_operator
begin_operator
stack b23 b4
0
4
0 19 -1 0
0 45 -1 0
0 18 0 1
0 40 0 12
1
end_operator
begin_operator
stack b23 b5
0
4
0 19 -1 0
0 45 -1 0
0 16 0 1
0 40 0 13
1
end_operator
begin_operator
stack b23 b7
0
4
0 19 -1 0
0 45 -1 0
0 8 0 1
0 40 0 14
1
end_operator
begin_operator
stack b23 b9
0
4
0 19 -1 0
0 45 -1 0
0 44 0 1
0 40 0 15
1
end_operator
begin_operator
stack b4 b1
0
4
0 19 -1 0
0 5 0 1
0 18 -1 0
0 38 0 1
1
end_operator
begin_operator
stack b4 b10
0
4
0 19 -1 0
0 3 0 1
0 18 -1 0
0 38 0 2
1
end_operator
begin_operator
stack b4 b11
0
4
0 19 -1 0
0 6 0 1
0 18 -1 0
0 38 0 3
1
end_operator
begin_operator
stack b4 b13
0
4
0 19 -1 0
0 15 0 1
0 18 -1 0
0 38 0 4
1
end_operator
begin_operator
stack b4 b15
0
4
0 19 -1 0
0 7 0 1
0 18 -1 0
0 38 0 5
1
end_operator
begin_operator
stack b4 b16
0
4
0 19 -1 0
0 12 0 1
0 18 -1 0
0 38 0 6
1
end_operator
begin_operator
stack b4 b17
0
4
0 19 -1 0
0 13 0 1
0 18 -1 0
0 38 0 7
1
end_operator
begin_operator
stack b4 b19
0
4
0 19 -1 0
0 17 0 1
0 18 -1 0
0 38 0 8
1
end_operator
begin_operator
stack b4 b2
0
4
0 19 -1 0
0 35 0 3
0 18 -1 0
0 38 0 9
1
end_operator
begin_operator
stack b4 b20
0
4
0 19 -1 0
0 10 0 1
0 18 -1 0
0 38 0 10
1
end_operator
begin_operator
stack b4 b22
0
4
0 19 -1 0
0 14 0 1
0 18 -1 0
0 38 0 11
1
end_operator
begin_operator
stack b4 b23
0
4
0 19 -1 0
0 45 0 1
0 18 -1 0
0 38 0 12
1
end_operator
begin_operator
stack b4 b5
0
4
0 19 -1 0
0 18 -1 0
0 16 0 1
0 38 0 13
1
end_operator
begin_operator
stack b4 b7
0
4
0 19 -1 0
0 18 -1 0
0 8 0 1
0 38 0 14
1
end_operator
begin_operator
stack b4 b9
0
4
0 19 -1 0
0 18 -1 0
0 44 0 1
0 38 0 15
1
end_operator
begin_operator
stack b5 b1
0
4
0 19 -1 0
0 5 0 1
0 16 -1 0
0 39 0 1
1
end_operator
begin_operator
stack b5 b12
0
4
0 19 -1 0
0 9 0 1
0 16 -1 0
0 39 0 2
1
end_operator
begin_operator
stack b5 b13
0
4
0 19 -1 0
0 15 0 1
0 16 -1 0
0 39 0 3
1
end_operator
begin_operator
stack b5 b15
0
4
0 19 -1 0
0 7 0 1
0 16 -1 0
0 39 0 4
1
end_operator
begin_operator
stack b5 b16
0
4
0 19 -1 0
0 12 0 1
0 16 -1 0
0 39 0 5
1
end_operator
begin_operator
stack b5 b17
0
4
0 19 -1 0
0 13 0 1
0 16 -1 0
0 39 0 6
1
end_operator
begin_operator
stack b5 b18
0
4
0 19 -1 0
0 11 0 1
0 16 -1 0
0 39 0 7
1
end_operator
begin_operator
stack b5 b19
0
4
0 19 -1 0
0 17 0 1
0 16 -1 0
0 39 0 8
1
end_operator
begin_operator
stack b5 b2
0
4
0 19 -1 0
0 35 0 3
0 16 -1 0
0 39 0 9
1
end_operator
begin_operator
stack b5 b20
0
4
0 19 -1 0
0 10 0 1
0 16 -1 0
0 39 0 10
1
end_operator
begin_operator
stack b5 b22
0
4
0 19 -1 0
0 14 0 1
0 16 -1 0
0 39 0 11
1
end_operator
begin_operator
stack b5 b23
0
4
0 19 -1 0
0 45 0 1
0 16 -1 0
0 39 0 12
1
end_operator
begin_operator
stack b5 b4
0
4
0 19 -1 0
0 18 0 1
0 16 -1 0
0 39 0 13
1
end_operator
begin_operator
stack b5 b7
0
4
0 19 -1 0
0 16 -1 0
0 8 0 1
0 39 0 14
1
end_operator
begin_operator
stack b5 b9
0
4
0 19 -1 0
0 16 -1 0
0 44 0 1
0 39 0 15
1
end_operator
begin_operator
stack b6 b11
0
4
0 19 -1 0
0 6 0 1
0 43 -1 0
0 41 0 1
1
end_operator
begin_operator
stack b6 b12
0
4
0 19 -1 0
0 9 0 1
0 43 -1 0
0 41 0 2
1
end_operator
begin_operator
stack b6 b13
0
4
0 19 -1 0
0 15 0 1
0 43 -1 0
0 41 0 3
1
end_operator
begin_operator
stack b6 b14
0
4
0 19 -1 0
0 34 0 1
0 43 -1 0
0 41 0 4
1
end_operator
begin_operator
stack b6 b16
0
4
0 19 -1 0
0 12 0 1
0 43 -1 0
0 41 0 5
1
end_operator
begin_operator
stack b6 b18
0
4
0 19 -1 0
0 11 0 1
0 43 -1 0
0 41 0 6
1
end_operator
begin_operator
stack b6 b19
0
4
0 19 -1 0
0 17 0 1
0 43 -1 0
0 41 0 7
1
end_operator
begin_operator
stack b6 b2
0
4
0 19 -1 0
0 35 0 3
0 43 -1 0
0 41 0 8
1
end_operator
begin_operator
stack b6 b21
0
4
0 19 -1 0
0 4 0 1
0 43 -1 0
0 41 0 9
1
end_operator
begin_operator
stack b6 b22
0
4
0 19 -1 0
0 14 0 1
0 43 -1 0
0 41 0 10
1
end_operator
begin_operator
stack b6 b23
0
4
0 19 -1 0
0 45 0 1
0 43 -1 0
0 41 0 11
1
end_operator
begin_operator
stack b6 b4
0
4
0 19 -1 0
0 18 0 1
0 43 -1 0
0 41 0 12
1
end_operator
begin_operator
stack b6 b7
0
4
0 19 -1 0
0 43 -1 0
0 8 0 1
0 41 0 13
1
end_operator
begin_operator
stack b6 b8
0
4
0 19 -1 0
0 43 -1 0
0 2 0 1
0 41 0 14
1
end_operator
begin_operator
stack b6 b9
0
4
0 19 -1 0
0 43 -1 0
0 44 0 1
0 41 0 15
1
end_operator
begin_operator
stack b7 b18
0
4
0 19 10 0
0 11 0 1
0 8 -1 0
0 27 -1 1
1
end_operator
begin_operator
stack b9 b16
0
4
0 19 -1 0
0 12 0 1
0 44 -1 0
0 30 0 1
1
end_operator
begin_operator
stack b9 b20
0
4
0 19 -1 0
0 10 0 1
0 44 -1 0
0 30 0 2
1
end_operator
begin_operator
stack b9 b6
0
4
0 19 -1 0
0 43 0 1
0 44 -1 0
0 30 0 3
1
end_operator
begin_operator
unstack b1 b19
0
4
0 19 0 1
0 5 0 1
0 17 -1 0
0 23 0 2
1
end_operator
begin_operator
unstack b10 b21
0
4
0 19 0 2
0 3 0 1
0 4 -1 0
0 24 0 2
1
end_operator
begin_operator
unstack b11 b13
0
4
0 19 0 12
0 6 0 1
0 15 -1 0
0 28 1 0
1
end_operator
begin_operator
unstack b12 b10
0
4
0 19 0 3
0 3 -1 0
0 9 0 1
0 25 0 3
1
end_operator
begin_operator
unstack b13 b1
0
4
0 19 0 12
0 5 -1 0
0 15 0 1
0 37 1 0
1
end_operator
begin_operator
unstack b13 b10
0
4
0 19 0 12
0 3 -1 0
0 15 0 1
0 37 2 0
1
end_operator
begin_operator
unstack b13 b11
0
4
0 19 0 12
0 6 -1 0
0 15 0 1
0 37 3 0
1
end_operator
begin_operator
unstack b13 b12
0
4
0 19 0 12
0 9 -1 0
0 15 0 1
0 37 4 0
1
end_operator
begin_operator
unstack b13 b15
0
4
0 19 0 12
0 15 0 1
0 7 -1 0
0 37 5 0
1
end_operator
begin_operator
unstack b13 b16
0
4
0 19 0 12
0 15 0 1
0 12 -1 0
0 37 6 0
1
end_operator
begin_operator
unstack b13 b17
0
4
0 19 0 12
0 15 0 1
0 13 -1 0
0 37 7 0
1
end_operator
begin_operator
unstack b13 b19
0
4
0 19 0 12
0 15 0 1
0 17 -1 0
0 37 8 0
1
end_operator
begin_operator
unstack b13 b20
0
4
0 19 0 12
0 15 0 1
0 10 -1 0
0 37 9 0
1
end_operator
begin_operator
unstack b13 b22
0
4
0 19 0 12
0 15 0 1
0 14 -1 0
0 37 10 0
1
end_operator
begin_operator
unstack b13 b23
0
4
0 19 0 12
0 15 0 1
0 45 -1 0
0 37 11 0
1
end_operator
begin_operator
unstack b13 b4
0
4
0 19 0 12
0 15 0 1
0 18 -1 0
0 37 12 0
1
end_operator
begin_operator
unstack b13 b5
0
4
0 19 0 12
0 15 0 1
0 16 -1 0
0 37 13 0
1
end_operator
begin_operator
unstack b13 b8
0
4
0 19 0 12
0 15 0 1
0 2 -1 0
0 37 14 0
1
end_operator
begin_operator
unstack b13 b9
0
4
0 19 0 12
0 15 0 1
0 44 -1 0
0 37 15 0
1
end_operator
begin_operator
unstack b14 b2
0
3
0 19 0 4
0 34 0 1
0 35 1 0
1
end_operator
begin_operator
unstack b15 b2
0
3
0 19 0 5
0 7 0 1
0 35 2 0
1
end_operator
begin_operator
unstack b16 b14
0
4
0 19 0 12
0 34 -1 0
0 12 0 1
0 32 2 0
1
end_operator
begin_operator
unstack b16 b18
0
4
0 19 0 12
0 12 0 1
0 11 -1 0
0 32 3 0
1
end_operator
begin_operator
unstack b16 b21
0
4
0 19 0 12
0 12 0 1
0 4 -1 0
0 32 4 0
1
end_operator
begin_operator
unstack b16 b22
0
4
0 19 0 12
0 12 0 1
0 14 -1 0
0 32 5 0
1
end_operator
begin_operator
unstack b16 b23
0
4
0 19 0 12
0 12 0 1
0 45 -1 0
0 32 6 0
1
end_operator
begin_operator
unstack b16 b5
0
4
0 19 0 12
0 12 0 1
0 16 -1 0
0 32 7 0
1
end_operator
begin_operator
unstack b17 b11
0
4
0 19 0 12
0 6 -1 0
0 13 0 1
0 36 2 0
1
end_operator
begin_operator
unstack b17 b12
0
4
0 19 0 12
0 9 -1 0
0 13 0 1
0 36 3 0
1
end_operator
begin_operator
unstack b17 b13
0
4
0 19 0 12
0 15 -1 0
0 13 0 1
0 36 4 0
1
end_operator
begin_operator
unstack b17 b16
0
4
0 19 0 12
0 12 -1 0
0 13 0 1
0 36 5 0
1
end_operator
begin_operator
unstack b17 b18
0
4
0 19 0 12
0 13 0 1
0 11 -1 0
0 36 6 0
1
end_operator
begin_operator
unstack b17 b19
0
4
0 19 0 12
0 13 0 1
0 17 -1 0
0 36 7 0
1
end_operator
begin_operator
unstack b17 b20
0
4
0 19 0 12
0 13 0 1
0 10 -1 0
0 36 8 0
1
end_operator
begin_operator
unstack b17 b22
0
4
0 19 0 12
0 13 0 1
0 14 -1 0
0 36 9 0
1
end_operator
begin_operator
unstack b17 b23
0
4
0 19 0 12
0 13 0 1
0 45 -1 0
0 36 10 0
1
end_operator
begin_operator
unstack b17 b4
0
4
0 19 0 12
0 13 0 1
0 18 -1 0
0 36 11 0
1
end_operator
begin_operator
unstack b17 b5
0
4
0 19 0 12
0 13 0 1
0 16 -1 0
0 36 12 0
1
end_operator
begin_operator
unstack b17 b7
0
4
0 19 0 12
0 13 0 1
0 8 -1 0
0 36 13 0
1
end_operator
begin_operator
unstack b17 b9
0
4
0 19 0 12
0 13 0 1
0 44 -1 0
0 36 14 0
1
end_operator
begin_operator
unstack b18 b15
0
4
0 19 0 12
0 7 -1 0
0 11 0 1
0 31 1 0
1
end_operator
begin_operator
unstack b18 b16
0
4
0 19 0 12
0 12 -1 0
0 11 0 1
0 31 2 0
1
end_operator
begin_operator
unstack b18 b22
0
4
0 19 0 12
0 11 0 1
0 14 -1 0
0 31 4 0
1
end_operator
begin_operator
unstack b18 b4
0
4
0 19 0 12
0 11 0 1
0 18 -1 0
0 31 5 0
1
end_operator
begin_operator
unstack b18 b5
0
4
0 19 0 12
0 11 0 1
0 16 -1 0
0 31 6 0
1
end_operator
begin_operator
unstack b18 b9
0
4
0 19 0 12
0 11 0 1
0 44 -1 0
0 31 7 0
1
end_operator
begin_operator
unstack b19 b1
0
4
0 19 0 12
0 5 -1 0
0 17 0 1
0 42 1 0
1
end_operator
begin_operator
unstack b19 b10
0
4
0 19 0 12
0 3 -1 0
0 17 0 1
0 42 2 0
1
end_operator
begin_operator
unstack b19 b11
0
4
0 19 0 12
0 6 -1 0
0 17 0 1
0 42 3 0
1
end_operator
begin_operator
unstack b19 b12
0
4
0 19 0 12
0 9 -1 0
0 17 0 1
0 42 4 0
1
end_operator
begin_operator
unstack b19 b13
0
4
0 19 0 12
0 15 -1 0
0 17 0 1
0 42 5 0
1
end_operator
begin_operator
unstack b19 b15
0
4
0 19 0 12
0 7 -1 0
0 17 0 1
0 42 6 0
1
end_operator
begin_operator
unstack b19 b16
0
4
0 19 0 12
0 12 -1 0
0 17 0 1
0 42 7 0
1
end_operator
begin_operator
unstack b19 b18
0
4
0 19 0 12
0 11 -1 0
0 17 0 1
0 42 8 0
1
end_operator
begin_operator
unstack b19 b2
0
4
0 19 0 12
0 17 0 1
0 35 -1 0
0 42 9 0
1
end_operator
begin_operator
unstack b19 b20
0
4
0 19 0 12
0 17 0 1
0 10 -1 0
0 42 10 0
1
end_operator
begin_operator
unstack b19 b22
0
4
0 19 0 12
0 17 0 1
0 14 -1 0
0 42 11 0
1
end_operator
begin_operator
unstack b19 b23
0
4
0 19 0 12
0 17 0 1
0 45 -1 0
0 42 12 0
1
end_operator
begin_operator
unstack b19 b4
0
4
0 19 0 12
0 17 0 1
0 18 -1 0
0 42 13 0
1
end_operator
begin_operator
unstack b19 b5
0
4
0 19 0 12
0 17 0 1
0 16 -1 0
0 42 14 0
1
end_operator
begin_operator
unstack b19 b7
0
4
0 19 0 12
0 17 0 1
0 8 -1 0
0 42 15 0
1
end_operator
begin_operator
unstack b19 b9
0
4
0 19 0 12
0 17 0 1
0 44 -1 0
0 42 16 0
1
end_operator
begin_operator
unstack b2 b4
0
4
0 19 0 6
0 35 0 3
0 18 -1 0
0 29 0 2
1
end_operator
begin_operator
unstack b20 b12
0
4
0 19 0 7
0 9 -1 0
0 10 0 1
0 26 0 3
1
end_operator
begin_operator
unstack b20 b14
0
4
0 19 0 7
0 34 -1 0
0 10 0 1
0 26 1 3
1
end_operator
begin_operator
unstack b21 b9
0
4
0 19 0 8
0 4 0 1
0 44 -1 0
0 20 0 2
1
end_operator
begin_operator
unstack b22 b14
0
4
0 19 0 12
0 34 -1 0
0 14 0 1
0 33 2 0
1
end_operator
begin_operator
unstack b22 b15
0
4
0 19 0 12
0 7 -1 0
0 14 0 1
0 33 3 0
1
end_operator
begin_operator
unstack b22 b16
0
4
0 19 0 12
0 12 -1 0
0 14 0 1
0 33 4 0
1
end_operator
begin_operator
unstack b22 b18
0
4
0 19 0 12
0 11 -1 0
0 14 0 1
0 33 5 0
1
end_operator
begin_operator
unstack b22 b21
0
4
0 19 0 12
0 4 -1 0
0 14 0 1
0 33 6 0
1
end_operator
begin_operator
unstack b22 b23
0
4
0 19 0 12
0 14 0 1
0 45 -1 0
0 33 7 0
1
end_operator
begin_operator
unstack b22 b4
0
4
0 19 0 12
0 14 0 1
0 18 -1 0
0 33 8 0
1
end_operator
begin_operator
unstack b22 b5
0
4
0 19 0 12
0 14 0 1
0 16 -1 0
0 33 9 0
1
end_operator
begin_operator
unstack b22 b9
0
4
0 19 0 12
0 14 0 1
0 44 -1 0
0 33 10 0
1
end_operator
begin_operator
unstack b23 b11
0
4
0 19 0 12
0 6 -1 0
0 45 0 1
0 40 1 0
1
end_operator
begin_operator
unstack b23 b12
0
4
0 19 0 12
0 9 -1 0
0 45 0 1
0 40 2 0
1
end_operator
begin_operator
unstack b23 b14
0
4
0 19 0 12
0 34 -1 0
0 45 0 1
0 40 3 0
1
end_operator
begin_operator
unstack b23 b16
0
4
0 19 0 12
0 12 -1 0
0 45 0 1
0 40 4 0
1
end_operator
begin_operator
unstack b23 b17
0
4
0 19 0 12
0 13 -1 0
0 45 0 1
0 40 5 0
1
end_operator
begin_operator
unstack b23 b18
0
4
0 19 0 12
0 11 -1 0
0 45 0 1
0 40 6 0
1
end_operator
begin_operator
unstack b23 b19
0
4
0 19 0 12
0 17 -1 0
0 45 0 1
0 40 7 0
1
end_operator
begin_operator
unstack b23 b2
0
4
0 19 0 12
0 35 -1 0
0 45 0 1
0 40 8 0
1
end_operator
begin_operator
unstack b23 b20
0
4
0 19 0 12
0 10 -1 0
0 45 0 1
0 40 9 0
1
end_operator
begin_operator
unstack b23 b21
0
4
0 19 0 12
0 4 -1 0
0 45 0 1
0 40 10 0
1
end_operator
begin_operator
unstack b23 b22
0
4
0 19 0 12
0 14 -1 0
0 45 0 1
0 40 11 0
1
end_operator
begin_operator
unstack b23 b4
0
4
0 19 0 12
0 45 0 1
0 18 -1 0
0 40 12 0
1
end_operator
begin_operator
unstack b23 b5
0
4
0 19 0 12
0 45 0 1
0 16 -1 0
0 40 13 0
1
end_operator
begin_operator
unstack b23 b7
0
4
0 19 0 12
0 45 0 1
0 8 -1 0
0 40 14 0
1
end_operator
begin_operator
unstack b23 b9
0
4
0 19 0 12
0 45 0 1
0 44 -1 0
0 40 15 0
1
end_operator
begin_operator
unstack b3 b15
0
4
0 19 0 9
0 7 -1 0
0 1 0 1
0 21 0 2
1
end_operator
begin_operator
unstack b4 b1
0
4
0 19 0 12
0 5 -1 0
0 18 0 1
0 38 1 0
1
end_operator
begin_operator
unstack b4 b10
0
4
0 19 0 12
0 3 -1 0
0 18 0 1
0 38 2 0
1
end_operator
begin_operator
unstack b4 b11
0
4
0 19 0 12
0 6 -1 0
0 18 0 1
0 38 3 0
1
end_operator
begin_operator
unstack b4 b13
0
4
0 19 0 12
0 15 -1 0
0 18 0 1
0 38 4 0
1
end_operator
begin_operator
unstack b4 b15
0
4
0 19 0 12
0 7 -1 0
0 18 0 1
0 38 5 0
1
end_operator
begin_operator
unstack b4 b16
0
4
0 19 0 12
0 12 -1 0
0 18 0 1
0 38 6 0
1
end_operator
begin_operator
unstack b4 b17
0
4
0 19 0 12
0 13 -1 0
0 18 0 1
0 38 7 0
1
end_operator
begin_operator
unstack b4 b19
0
4
0 19 0 12
0 17 -1 0
0 18 0 1
0 38 8 0
1
end_operator
begin_operator
unstack b4 b2
0
4
0 19 0 12
0 35 -1 0
0 18 0 1
0 38 9 0
1
end_operator
begin_operator
unstack b4 b20
0
4
0 19 0 12
0 10 -1 0
0 18 0 1
0 38 10 0
1
end_operator
begin_operator
unstack b4 b22
0
4
0 19 0 12
0 14 -1 0
0 18 0 1
0 38 11 0
1
end_operator
begin_operator
unstack b4 b23
0
4
0 19 0 12
0 45 -1 0
0 18 0 1
0 38 12 0
1
end_operator
begin_operator
unstack b4 b5
0
4
0 19 0 12
0 18 0 1
0 16 -1 0
0 38 13 0
1
end_operator
begin_operator
unstack b4 b7
0
4
0 19 0 12
0 18 0 1
0 8 -1 0
0 38 14 0
1
end_operator
begin_operator
unstack b4 b9
0
4
0 19 0 12
0 18 0 1
0 44 -1 0
0 38 15 0
1
end_operator
begin_operator
unstack b5 b1
0
4
0 19 0 12
0 5 -1 0
0 16 0 1
0 39 1 0
1
end_operator
begin_operator
unstack b5 b12
0
4
0 19 0 12
0 9 -1 0
0 16 0 1
0 39 2 0
1
end_operator
begin_operator
unstack b5 b13
0
4
0 19 0 12
0 15 -1 0
0 16 0 1
0 39 3 0
1
end_operator
begin_operator
unstack b5 b15
0
4
0 19 0 12
0 7 -1 0
0 16 0 1
0 39 4 0
1
end_operator
begin_operator
unstack b5 b16
0
4
0 19 0 12
0 12 -1 0
0 16 0 1
0 39 5 0
1
end_operator
begin_operator
unstack b5 b17
0
4
0 19 0 12
0 13 -1 0
0 16 0 1
0 39 6 0
1
end_operator
begin_operator
unstack b5 b18
0
4
0 19 0 12
0 11 -1 0
0 16 0 1
0 39 7 0
1
end_operator
begin_operator
unstack b5 b19
0
4
0 19 0 12
0 17 -1 0
0 16 0 1
0 39 8 0
1
end_operator
begin_operator
unstack b5 b2
0
4
0 19 0 12
0 35 -1 0
0 16 0 1
0 39 9 0
1
end_operator
begin_operator
unstack b5 b20
0
4
0 19 0 12
0 10 -1 0
0 16 0 1
0 39 10 0
1
end_operator
begin_operator
unstack b5 b22
0
4
0 19 0 12
0 14 -1 0
0 16 0 1
0 39 11 0
1
end_operator
begin_operator
unstack b5 b23
0
4
0 19 0 12
0 45 -1 0
0 16 0 1
0 39 12 0
1
end_operator
begin_operator
unstack b5 b4
0
4
0 19 0 12
0 18 -1 0
0 16 0 1
0 39 13 0
1
end_operator
begin_operator
unstack b5 b7
0
4
0 19 0 12
0 16 0 1
0 8 -1 0
0 39 14 0
1
end_operator
begin_operator
unstack b5 b9
0
4
0 19 0 12
0 16 0 1
0 44 -1 0
0 39 15 0
1
end_operator
begin_operator
unstack b6 b11
0
4
0 19 0 12
0 6 -1 0
0 43 0 1
0 41 1 0
1
end_operator
begin_operator
unstack b6 b12
0
4
0 19 0 12
0 9 -1 0
0 43 0 1
0 41 2 0
1
end_operator
begin_operator
unstack b6 b13
0
4
0 19 0 12
0 15 -1 0
0 43 0 1
0 41 3 0
1
end_operator
begin_operator
unstack b6 b14
0
4
0 19 0 12
0 34 -1 0
0 43 0 1
0 41 4 0
1
end_operator
begin_operator
unstack b6 b16
0
4
0 19 0 12
0 12 -1 0
0 43 0 1
0 41 5 0
1
end_operator
begin_operator
unstack b6 b18
0
4
0 19 0 12
0 11 -1 0
0 43 0 1
0 41 6 0
1
end_operator
begin_operator
unstack b6 b19
0
4
0 19 0 12
0 17 -1 0
0 43 0 1
0 41 7 0
1
end_operator
begin_operator
unstack b6 b2
0
4
0 19 0 12
0 35 -1 0
0 43 0 1
0 41 8 0
1
end_operator
begin_operator
unstack b6 b21
0
4
0 19 0 12
0 4 -1 0
0 43 0 1
0 41 9 0
1
end_operator
begin_operator
unstack b6 b22
0
4
0 19 0 12
0 14 -1 0
0 43 0 1
0 41 10 0
1
end_operator
begin_operator
unstack b6 b23
0
4
0 19 0 12
0 45 -1 0
0 43 0 1
0 41 11 0
1
end_operator
begin_operator
unstack b6 b4
0
4
0 19 0 12
0 18 -1 0
0 43 0 1
0 41 12 0
1
end_operator
begin_operator
unstack b6 b7
0
4
0 19 0 12
0 43 0 1
0 8 -1 0
0 41 13 0
1
end_operator
begin_operator
unstack b6 b8
0
4
0 19 0 12
0 43 0 1
0 2 -1 0
0 41 14 0
1
end_operator
begin_operator
unstack b6 b9
0
4
0 19 0 12
0 43 0 1
0 44 -1 0
0 41 15 0
1
end_operator
begin_operator
unstack b7 b1
0
4
0 19 0 10
0 5 -1 0
0 8 0 1
0 27 0 3
1
end_operator
begin_operator
unstack b8 b7
0
4
0 19 0 11
0 8 -1 0
0 2 0 1
0 22 0 2
1
end_operator
begin_operator
unstack b9 b16
0
4
0 19 0 12
0 12 -1 0
0 44 0 1
0 30 1 0
1
end_operator
begin_operator
unstack b9 b20
0
4
0 19 0 12
0 10 -1 0
0 44 0 1
0 30 2 0
1
end_operator
begin_operator
unstack b9 b6
0
4
0 19 0 12
0 43 -1 0
0 44 0 1
0 30 3 0
1
end_operator
0
