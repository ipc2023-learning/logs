begin_version
3
end_version
begin_metric
0
end_metric
48
begin_variable
var0
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var2
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var1
-1
2
Atom clear(b1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var4
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var5
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var7
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var8
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var10
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var9
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var11
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var12
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var13
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var14
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var15
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var16
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var17
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var18
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var19
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var20
-1
24
Atom arm-empty()
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
<none of those>
end_variable
begin_variable
var21
-1
3
Atom on(b11, b20)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var22
-1
3
Atom on(b17, b4)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var23
-1
3
Atom on(b23, b5)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom on(b14, b11)
Atom on(b14, b18)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom on(b24, b1)
Atom on(b24, b17)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom on(b4, b22)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b5, b2)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b18, b10)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var29
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var30
-1
9
Atom on(b10, b13)
Atom on(b10, b16)
Atom on(b10, b2)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b24)
Atom on(b10, b8)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var41
-1
11
Atom on(b8, b10)
Atom on(b8, b16)
Atom on(b8, b2)
Atom on(b8, b20)
Atom on(b8, b21)
Atom on(b8, b22)
Atom on(b8, b24)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var31
-1
15
Atom on(b22, b10)
Atom on(b22, b13)
Atom on(b22, b15)
Atom on(b22, b16)
Atom on(b22, b19)
Atom on(b22, b2)
Atom on(b22, b24)
Atom on(b22, b3)
Atom on(b22, b4)
Atom on(b22, b5)
Atom on(b22, b7)
Atom on(b22, b8)
Atom on(b22, b9)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var32
-1
16
Atom on(b13, b10)
Atom on(b13, b12)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b21)
Atom on(b13, b24)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b9)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var40
-1
16
Atom on(b6, b10)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b16)
Atom on(b6, b19)
Atom on(b6, b2)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b22)
Atom on(b6, b24)
Atom on(b6, b3)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var36
-1
17
Atom on(b19, b10)
Atom on(b19, b13)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b2)
Atom on(b19, b20)
Atom on(b19, b21)
Atom on(b19, b22)
Atom on(b19, b24)
Atom on(b19, b3)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var37
-1
17
Atom on(b2, b10)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b22)
Atom on(b2, b24)
Atom on(b2, b3)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var42
-1
17
Atom on(b7, b10)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b19)
Atom on(b7, b2)
Atom on(b7, b20)
Atom on(b7, b21)
Atom on(b7, b22)
Atom on(b7, b23)
Atom on(b7, b24)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var43
-1
17
Atom on(b21, b10)
Atom on(b21, b12)
Atom on(b21, b15)
Atom on(b21, b16)
Atom on(b21, b17)
Atom on(b21, b19)
Atom on(b21, b2)
Atom on(b21, b20)
Atom on(b21, b22)
Atom on(b21, b24)
Atom on(b21, b3)
Atom on(b21, b6)
Atom on(b21, b7)
Atom on(b21, b8)
Atom on(b21, b9)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var39
-1
18
Atom on(b3, b10)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b19)
Atom on(b3, b2)
Atom on(b3, b20)
Atom on(b3, b21)
Atom on(b3, b22)
Atom on(b3, b23)
Atom on(b3, b24)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var33
-1
19
Atom on(b16, b10)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b24)
Atom on(b16, b3)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var38
-1
19
Atom on(b20, b10)
Atom on(b20, b12)
Atom on(b20, b13)
Atom on(b20, b14)
Atom on(b20, b15)
Atom on(b20, b16)
Atom on(b20, b19)
Atom on(b20, b2)
Atom on(b20, b21)
Atom on(b20, b22)
Atom on(b20, b24)
Atom on(b20, b3)
Atom on(b20, b4)
Atom on(b20, b5)
Atom on(b20, b7)
Atom on(b20, b8)
Atom on(b20, b9)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var34
-1
20
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b13)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var35
-1
20
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b12)
Atom on(b15, b13)
Atom on(b15, b16)
Atom on(b15, b17)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b21)
Atom on(b15, b22)
Atom on(b15, b23)
Atom on(b15, b24)
Atom on(b15, b5)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var44
-1
21
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b15)
Atom on(b9, b16)
Atom on(b9, b17)
Atom on(b9, b19)
Atom on(b9, b2)
Atom on(b9, b20)
Atom on(b9, b21)
Atom on(b9, b22)
Atom on(b9, b23)
Atom on(b9, b3)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var45
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var46
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var47
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
2836
begin_mutex_group
24
20 0
20 1
20 2
20 3
20 4
20 5
20 6
20 7
20 8
20 9
20 10
20 11
20 12
20 13
20 14
20 15
20 16
20 17
20 18
20 19
20 20
20 21
20 22
44 0
end_mutex_group
begin_mutex_group
5
2 0
44 1
42 0
43 0
25 0
end_mutex_group
begin_mutex_group
17
20 1
9 0
44 2
42 1
33 0
43 1
40 0
28 0
35 0
36 0
41 0
38 0
32 0
39 0
34 0
37 0
31 0
end_mutex_group
begin_mutex_group
3
20 2
0 0
24 0
end_mutex_group
begin_mutex_group
12
20 3
15 0
44 3
33 1
43 2
40 1
36 1
41 1
38 1
39 1
34 1
37 1
end_mutex_group
begin_mutex_group
14
20 4
11 0
44 4
30 0
42 2
43 3
40 2
35 1
36 2
41 2
32 1
39 2
34 2
37 2
end_mutex_group
begin_mutex_group
4
20 5
1 0
36 3
41 3
end_mutex_group
begin_mutex_group
13
20 6
17 0
44 5
42 3
33 2
40 3
35 2
36 4
41 4
38 2
32 2
39 3
37 3
end_mutex_group
begin_mutex_group
16
20 7
47 0
44 6
30 1
42 4
33 3
43 4
35 3
36 5
41 5
38 3
32 3
39 4
34 3
37 4
31 1
end_mutex_group
begin_mutex_group
7
20 8
3 0
44 7
43 5
40 4
38 4
25 1
end_mutex_group
begin_mutex_group
3
20 9
29 0
24 1
end_mutex_group
begin_mutex_group
13
20 10
13 0
44 8
42 5
33 4
43 6
36 6
41 6
38 5
32 4
39 5
34 4
37 5
end_mutex_group
begin_mutex_group
17
20 11
18 0
44 9
30 2
42 6
33 5
43 7
40 5
35 4
41 7
38 6
32 5
39 6
27 0
34 5
37 6
31 2
end_mutex_group
begin_mutex_group
14
20 12
16 0
44 10
21 0
42 7
43 8
40 6
35 5
36 7
38 7
39 7
34 6
37 7
31 3
end_mutex_group
begin_mutex_group
15
20 13
45 0
44 11
30 3
42 8
33 6
43 9
40 7
35 6
36 8
41 8
39 8
34 7
37 8
31 4
end_mutex_group
begin_mutex_group
16
20 14
14 0
44 12
30 4
42 9
43 10
40 8
35 7
36 9
41 9
38 8
39 9
26 0
34 8
37 9
31 5
end_mutex_group
begin_mutex_group
8
20 15
4 0
44 13
42 10
43 11
40 9
39 10
37 10
end_mutex_group
begin_mutex_group
15
20 16
7 0
30 5
33 7
43 12
40 10
35 8
36 10
41 10
38 9
32 6
39 11
34 9
37 11
31 6
end_mutex_group
begin_mutex_group
12
20 17
12 0
44 14
42 11
33 8
40 11
35 9
36 11
41 11
38 10
32 7
34 10
end_mutex_group
begin_mutex_group
9
20 18
5 0
44 15
42 12
33 9
22 0
35 10
41 12
32 8
end_mutex_group
begin_mutex_group
11
20 19
6 0
44 16
42 13
33 10
43 13
40 12
35 11
41 13
32 9
23 0
end_mutex_group
begin_mutex_group
12
20 20
10 0
44 17
42 14
33 11
43 14
40 13
35 12
38 11
39 12
37 12
31 7
end_mutex_group
begin_mutex_group
15
20 21
46 0
44 18
42 15
33 12
43 15
40 14
35 13
36 12
41 14
38 12
32 10
39 13
34 11
31 8
end_mutex_group
begin_mutex_group
14
20 22
8 0
44 19
30 6
42 16
43 16
40 15
36 13
41 15
38 13
32 11
39 14
34 12
37 13
end_mutex_group
begin_mutex_group
14
19 0
44 0
42 17
33 13
43 17
40 16
35 14
36 14
41 16
38 14
32 12
39 15
34 13
37 14
end_mutex_group
begin_mutex_group
9
20 1
30 0
30 1
30 2
30 3
30 4
30 5
30 6
30 7
end_mutex_group
begin_mutex_group
3
20 2
21 0
21 1
end_mutex_group
begin_mutex_group
20
20 3
42 0
42 1
42 2
42 3
42 4
42 5
42 6
42 7
42 8
42 9
42 10
42 11
42 12
42 13
42 14
42 15
42 16
42 17
42 18
end_mutex_group
begin_mutex_group
16
20 4
33 0
33 1
33 2
33 3
33 4
33 5
33 6
33 7
33 8
33 9
33 10
33 11
33 12
33 13
33 14
end_mutex_group
begin_mutex_group
4
20 5
24 0
24 1
24 2
end_mutex_group
begin_mutex_group
20
20 6
43 0
43 1
43 2
43 3
43 4
43 5
43 6
43 7
43 8
43 9
43 10
43 11
43 12
43 13
43 14
43 15
43 16
43 17
43 18
end_mutex_group
begin_mutex_group
19
20 7
40 0
40 1
40 2
40 3
40 4
40 5
40 6
40 7
40 8
40 9
40 10
40 11
40 12
40 13
40 14
40 15
40 16
40 17
end_mutex_group
begin_mutex_group
3
20 8
22 0
22 1
end_mutex_group
begin_mutex_group
3
20 9
28 0
28 1
end_mutex_group
begin_mutex_group
17
20 10
35 0
35 1
35 2
35 3
35 4
35 5
35 6
35 7
35 8
35 9
35 10
35 11
35 12
35 13
35 14
35 15
end_mutex_group
begin_mutex_group
17
20 11
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
36 15
end_mutex_group
begin_mutex_group
19
20 12
41 0
41 1
41 2
41 3
41 4
41 5
41 6
41 7
41 8
41 9
41 10
41 11
41 12
41 13
41 14
41 15
41 16
41 17
end_mutex_group
begin_mutex_group
17
20 13
38 0
38 1
38 2
38 3
38 4
38 5
38 6
38 7
38 8
38 9
38 10
38 11
38 12
38 13
38 14
38 15
end_mutex_group
begin_mutex_group
15
20 14
32 0
32 1
32 2
32 3
32 4
32 5
32 6
32 7
32 8
32 9
32 10
32 11
32 12
32 13
end_mutex_group
begin_mutex_group
3
20 15
23 0
23 1
end_mutex_group
begin_mutex_group
4
20 16
25 0
25 1
25 2
end_mutex_group
begin_mutex_group
18
20 17
39 0
39 1
39 2
39 3
39 4
39 5
39 6
39 7
39 8
39 9
39 10
39 11
39 12
39 13
39 14
39 15
39 16
end_mutex_group
begin_mutex_group
3
20 18
26 0
26 1
end_mutex_group
begin_mutex_group
3
20 19
27 0
27 1
end_mutex_group
begin_mutex_group
16
20 20
34 0
34 1
34 2
34 3
34 4
34 5
34 6
34 7
34 8
34 9
34 10
34 11
34 12
34 13
34 14
end_mutex_group
begin_mutex_group
17
20 21
37 0
37 1
37 2
37 3
37 4
37 5
37 6
37 7
37 8
37 9
37 10
37 11
37 12
37 13
37 14
37 15
end_mutex_group
begin_mutex_group
11
20 22
31 0
31 1
31 2
31 3
31 4
31 5
31 6
31 7
31 8
31 9
end_mutex_group
begin_mutex_group
2
0 0
21 2
end_mutex_group
begin_mutex_group
2
1 0
20 2
end_mutex_group
begin_mutex_group
2
1 0
21 0
end_mutex_group
begin_mutex_group
2
1 0
21 2
end_mutex_group
begin_mutex_group
2
1 0
24 3
end_mutex_group
begin_mutex_group
2
3 0
22 2
end_mutex_group
begin_mutex_group
2
3 0
40 5
end_mutex_group
begin_mutex_group
2
4 0
23 2
end_mutex_group
begin_mutex_group
2
5 0
26 2
end_mutex_group
begin_mutex_group
2
5 0
40 5
end_mutex_group
begin_mutex_group
2
5 1
20 8
end_mutex_group
begin_mutex_group
2
5 1
22 2
end_mutex_group
begin_mutex_group
2
6 0
27 2
end_mutex_group
begin_mutex_group
2
6 1
20 15
end_mutex_group
begin_mutex_group
2
6 1
23 2
end_mutex_group
begin_mutex_group
2
7 0
25 3
end_mutex_group
begin_mutex_group
2
8 0
31 10
end_mutex_group
begin_mutex_group
2
10 0
40 5
end_mutex_group
begin_mutex_group
2
10 0
34 15
end_mutex_group
begin_mutex_group
2
9 0
30 8
end_mutex_group
begin_mutex_group
2
11 0
33 15
end_mutex_group
begin_mutex_group
2
12 0
39 17
end_mutex_group
begin_mutex_group
2
13 0
40 5
end_mutex_group
begin_mutex_group
2
13 0
35 16
end_mutex_group
begin_mutex_group
2
14 0
32 14
end_mutex_group
begin_mutex_group
2
15 0
40 5
end_mutex_group
begin_mutex_group
2
15 0
42 19
end_mutex_group
begin_mutex_group
2
16 0
41 18
end_mutex_group
begin_mutex_group
2
16 1
20 2
end_mutex_group
begin_mutex_group
2
16 1
21 2
end_mutex_group
begin_mutex_group
2
17 0
40 5
end_mutex_group
begin_mutex_group
2
17 0
43 19
end_mutex_group
begin_mutex_group
2
18 0
36 16
end_mutex_group
begin_mutex_group
2
19 0
20 23
end_mutex_group
begin_mutex_group
2
20 0
21 2
end_mutex_group
begin_mutex_group
2
20 0
22 2
end_mutex_group
begin_mutex_group
2
20 0
23 2
end_mutex_group
begin_mutex_group
2
20 0
24 3
end_mutex_group
begin_mutex_group
2
20 0
25 3
end_mutex_group
begin_mutex_group
2
20 0
26 2
end_mutex_group
begin_mutex_group
2
20 0
27 2
end_mutex_group
begin_mutex_group
2
20 0
28 2
end_mutex_group
begin_mutex_group
2
20 0
30 8
end_mutex_group
begin_mutex_group
2
20 0
32 14
end_mutex_group
begin_mutex_group
2
20 0
33 15
end_mutex_group
begin_mutex_group
2
20 0
40 18
end_mutex_group
begin_mutex_group
2
20 0
42 19
end_mutex_group
begin_mutex_group
2
20 0
43 19
end_mutex_group
begin_mutex_group
2
20 0
35 16
end_mutex_group
begin_mutex_group
2
20 0
36 16
end_mutex_group
begin_mutex_group
2
20 0
41 18
end_mutex_group
begin_mutex_group
2
20 0
39 17
end_mutex_group
begin_mutex_group
2
20 0
34 15
end_mutex_group
begin_mutex_group
2
20 0
31 10
end_mutex_group
begin_mutex_group
2
20 0
37 16
end_mutex_group
begin_mutex_group
2
20 0
38 16
end_mutex_group
begin_mutex_group
2
20 1
21 2
end_mutex_group
begin_mutex_group
2
20 1
22 2
end_mutex_group
begin_mutex_group
2
20 1
23 2
end_mutex_group
begin_mutex_group
2
20 1
24 3
end_mutex_group
begin_mutex_group
2
20 1
25 3
end_mutex_group
begin_mutex_group
2
20 1
26 2
end_mutex_group
begin_mutex_group
2
20 1
27 2
end_mutex_group
begin_mutex_group
2
20 1
28 2
end_mutex_group
begin_mutex_group
2
20 1
32 14
end_mutex_group
begin_mutex_group
2
20 1
33 15
end_mutex_group
begin_mutex_group
2
20 1
40 18
end_mutex_group
begin_mutex_group
2
20 1
42 19
end_mutex_group
begin_mutex_group
2
20 1
43 19
end_mutex_group
begin_mutex_group
2
20 1
35 16
end_mutex_group
begin_mutex_group
2
20 1
36 16
end_mutex_group
begin_mutex_group
2
20 1
41 18
end_mutex_group
begin_mutex_group
2
20 1
39 17
end_mutex_group
begin_mutex_group
2
20 1
34 15
end_mutex_group
begin_mutex_group
2
20 1
31 10
end_mutex_group
begin_mutex_group
2
20 1
37 16
end_mutex_group
begin_mutex_group
2
20 1
38 16
end_mutex_group
begin_mutex_group
2
20 2
22 2
end_mutex_group
begin_mutex_group
2
20 2
23 2
end_mutex_group
begin_mutex_group
2
20 2
24 2
end_mutex_group
begin_mutex_group
2
20 2
24 3
end_mutex_group
begin_mutex_group
2
20 2
25 3
end_mutex_group
begin_mutex_group
2
20 2
26 2
end_mutex_group
begin_mutex_group
2
20 2
27 2
end_mutex_group
begin_mutex_group
2
20 2
28 0
end_mutex_group
begin_mutex_group
2
20 2
28 2
end_mutex_group
begin_mutex_group
2
20 2
29 0
end_mutex_group
begin_mutex_group
2
20 2
30 8
end_mutex_group
begin_mutex_group
2
20 2
32 14
end_mutex_group
begin_mutex_group
2
20 2
33 15
end_mutex_group
begin_mutex_group
2
20 2
40 6
end_mutex_group
begin_mutex_group
2
20 2
40 18
end_mutex_group
begin_mutex_group
2
20 2
42 7
end_mutex_group
begin_mutex_group
2
20 2
42 19
end_mutex_group
begin_mutex_group
2
20 2
43 8
end_mutex_group
begin_mutex_group
2
20 2
43 19
end_mutex_group
begin_mutex_group
2
20 2
35 5
end_mutex_group
begin_mutex_group
2
20 2
35 16
end_mutex_group
begin_mutex_group
2
20 2
36 3
end_mutex_group
begin_mutex_group
2
20 2
36 7
end_mutex_group
begin_mutex_group
2
20 2
36 16
end_mutex_group
begin_mutex_group
2
20 2
41 0
end_mutex_group
begin_mutex_group
2
20 2
41 1
end_mutex_group
begin_mutex_group
2
20 2
41 2
end_mutex_group
begin_mutex_group
2
20 2
41 4
end_mutex_group
begin_mutex_group
2
20 2
41 5
end_mutex_group
begin_mutex_group
2
20 2
41 6
end_mutex_group
begin_mutex_group
2
20 2
41 7
end_mutex_group
begin_mutex_group
2
20 2
41 8
end_mutex_group
begin_mutex_group
2
20 2
41 9
end_mutex_group
begin_mutex_group
2
20 2
41 10
end_mutex_group
begin_mutex_group
2
20 2
41 11
end_mutex_group
begin_mutex_group
2
20 2
41 12
end_mutex_group
begin_mutex_group
2
20 2
41 13
end_mutex_group
begin_mutex_group
2
20 2
41 14
end_mutex_group
begin_mutex_group
2
20 2
41 15
end_mutex_group
begin_mutex_group
2
20 2
41 16
end_mutex_group
begin_mutex_group
2
20 2
41 17
end_mutex_group
begin_mutex_group
2
20 2
41 18
end_mutex_group
begin_mutex_group
2
20 2
39 7
end_mutex_group
begin_mutex_group
2
20 2
39 17
end_mutex_group
begin_mutex_group
2
20 2
34 6
end_mutex_group
begin_mutex_group
2
20 2
34 15
end_mutex_group
begin_mutex_group
2
20 2
31 3
end_mutex_group
begin_mutex_group
2
20 2
31 10
end_mutex_group
begin_mutex_group
2
20 2
37 7
end_mutex_group
begin_mutex_group
2
20 2
37 16
end_mutex_group
begin_mutex_group
2
20 2
38 7
end_mutex_group
begin_mutex_group
2
20 2
38 16
end_mutex_group
begin_mutex_group
2
20 2
44 10
end_mutex_group
begin_mutex_group
2
20 3
21 2
end_mutex_group
begin_mutex_group
2
20 3
22 2
end_mutex_group
begin_mutex_group
2
20 3
23 2
end_mutex_group
begin_mutex_group
2
20 3
24 3
end_mutex_group
begin_mutex_group
2
20 3
25 3
end_mutex_group
begin_mutex_group
2
20 3
26 2
end_mutex_group
begin_mutex_group
2
20 3
27 2
end_mutex_group
begin_mutex_group
2
20 3
28 2
end_mutex_group
begin_mutex_group
2
20 3
30 8
end_mutex_group
begin_mutex_group
2
20 3
32 14
end_mutex_group
begin_mutex_group
2
20 3
33 15
end_mutex_group
begin_mutex_group
2
20 3
40 5
end_mutex_group
begin_mutex_group
2
20 3
40 18
end_mutex_group
begin_mutex_group
2
20 3
43 19
end_mutex_group
begin_mutex_group
2
20 3
35 16
end_mutex_group
begin_mutex_group
2
20 3
36 16
end_mutex_group
begin_mutex_group
2
20 3
41 18
end_mutex_group
begin_mutex_group
2
20 3
39 17
end_mutex_group
begin_mutex_group
2
20 3
34 15
end_mutex_group
begin_mutex_group
2
20 3
31 10
end_mutex_group
begin_mutex_group
2
20 3
37 16
end_mutex_group
begin_mutex_group
2
20 3
38 16
end_mutex_group
begin_mutex_group
2
20 4
21 2
end_mutex_group
begin_mutex_group
2
20 4
22 2
end_mutex_group
begin_mutex_group
2
20 4
23 2
end_mutex_group
begin_mutex_group
2
20 4
24 3
end_mutex_group
begin_mutex_group
2
20 4
25 3
end_mutex_group
begin_mutex_group
2
20 4
26 2
end_mutex_group
begin_mutex_group
2
20 4
27 2
end_mutex_group
begin_mutex_group
2
20 4
28 2
end_mutex_group
begin_mutex_group
2
20 4
30 8
end_mutex_group
begin_mutex_group
2
20 4
32 14
end_mutex_group
begin_mutex_group
2
20 4
40 18
end_mutex_group
begin_mutex_group
2
20 4
42 19
end_mutex_group
begin_mutex_group
2
20 4
43 19
end_mutex_group
begin_mutex_group
2
20 4
35 16
end_mutex_group
begin_mutex_group
2
20 4
36 16
end_mutex_group
begin_mutex_group
2
20 4
41 18
end_mutex_group
begin_mutex_group
2
20 4
39 17
end_mutex_group
begin_mutex_group
2
20 4
34 15
end_mutex_group
begin_mutex_group
2
20 4
31 10
end_mutex_group
begin_mutex_group
2
20 4
37 16
end_mutex_group
begin_mutex_group
2
20 4
38 16
end_mutex_group
begin_mutex_group
2
20 5
21 0
end_mutex_group
begin_mutex_group
2
20 5
21 2
end_mutex_group
begin_mutex_group
2
20 5
22 2
end_mutex_group
begin_mutex_group
2
20 5
23 2
end_mutex_group
begin_mutex_group
2
20 5
25 3
end_mutex_group
begin_mutex_group
2
20 5
26 2
end_mutex_group
begin_mutex_group
2
20 5
27 2
end_mutex_group
begin_mutex_group
2
20 5
28 2
end_mutex_group
begin_mutex_group
2
20 5
30 8
end_mutex_group
begin_mutex_group
2
20 5
32 14
end_mutex_group
begin_mutex_group
2
20 5
33 15
end_mutex_group
begin_mutex_group
2
20 5
40 18
end_mutex_group
begin_mutex_group
2
20 5
42 19
end_mutex_group
begin_mutex_group
2
20 5
43 19
end_mutex_group
begin_mutex_group
2
20 5
35 16
end_mutex_group
begin_mutex_group
2
20 5
36 16
end_mutex_group
begin_mutex_group
2
20 5
41 18
end_mutex_group
begin_mutex_group
2
20 5
39 17
end_mutex_group
begin_mutex_group
2
20 5
34 15
end_mutex_group
begin_mutex_group
2
20 5
31 10
end_mutex_group
begin_mutex_group
2
20 5
37 16
end_mutex_group
begin_mutex_group
2
20 5
38 16
end_mutex_group
begin_mutex_group
2
20 6
21 2
end_mutex_group
begin_mutex_group
2
20 6
22 2
end_mutex_group
begin_mutex_group
2
20 6
23 2
end_mutex_group
begin_mutex_group
2
20 6
24 3
end_mutex_group
begin_mutex_group
2
20 6
25 3
end_mutex_group
begin_mutex_group
2
20 6
26 2
end_mutex_group
begin_mutex_group
2
20 6
27 2
end_mutex_group
begin_mutex_group
2
20 6
28 2
end_mutex_group
begin_mutex_group
2
20 6
30 8
end_mutex_group
begin_mutex_group
2
20 6
32 14
end_mutex_group
begin_mutex_group
2
20 6
33 15
end_mutex_group
begin_mutex_group
2
20 6
40 5
end_mutex_group
begin_mutex_group
2
20 6
40 18
end_mutex_group
begin_mutex_group
2
20 6
42 19
end_mutex_group
begin_mutex_group
2
20 6
35 16
end_mutex_group
begin_mutex_group
2
20 6
36 16
end_mutex_group
begin_mutex_group
2
20 6
41 18
end_mutex_group
begin_mutex_group
2
20 6
39 17
end_mutex_group
begin_mutex_group
2
20 6
34 15
end_mutex_group
begin_mutex_group
2
20 6
31 10
end_mutex_group
begin_mutex_group
2
20 6
37 16
end_mutex_group
begin_mutex_group
2
20 6
38 16
end_mutex_group
begin_mutex_group
2
20 7
21 2
end_mutex_group
begin_mutex_group
2
20 7
22 2
end_mutex_group
begin_mutex_group
2
20 7
23 2
end_mutex_group
begin_mutex_group
2
20 7
24 3
end_mutex_group
begin_mutex_group
2
20 7
25 3
end_mutex_group
begin_mutex_group
2
20 7
26 2
end_mutex_group
begin_mutex_group
2
20 7
27 2
end_mutex_group
begin_mutex_group
2
20 7
28 2
end_mutex_group
begin_mutex_group
2
20 7
30 8
end_mutex_group
begin_mutex_group
2
20 7
32 14
end_mutex_group
begin_mutex_group
2
20 7
33 15
end_mutex_group
begin_mutex_group
2
20 7
42 19
end_mutex_group
begin_mutex_group
2
20 7
43 19
end_mutex_group
begin_mutex_group
2
20 7
35 16
end_mutex_group
begin_mutex_group
2
20 7
36 16
end_mutex_group
begin_mutex_group
2
20 7
41 18
end_mutex_group
begin_mutex_group
2
20 7
39 17
end_mutex_group
begin_mutex_group
2
20 7
34 15
end_mutex_group
begin_mutex_group
2
20 7
31 10
end_mutex_group
begin_mutex_group
2
20 7
37 16
end_mutex_group
begin_mutex_group
2
20 7
38 16
end_mutex_group
begin_mutex_group
2
20 8
21 2
end_mutex_group
begin_mutex_group
2
20 8
23 2
end_mutex_group
begin_mutex_group
2
20 8
24 3
end_mutex_group
begin_mutex_group
2
20 8
25 3
end_mutex_group
begin_mutex_group
2
20 8
26 0
end_mutex_group
begin_mutex_group
2
20 8
26 2
end_mutex_group
begin_mutex_group
2
20 8
27 2
end_mutex_group
begin_mutex_group
2
20 8
28 2
end_mutex_group
begin_mutex_group
2
20 8
30 8
end_mutex_group
begin_mutex_group
2
20 8
32 8
end_mutex_group
begin_mutex_group
2
20 8
32 14
end_mutex_group
begin_mutex_group
2
20 8
33 9
end_mutex_group
begin_mutex_group
2
20 8
33 15
end_mutex_group
begin_mutex_group
2
20 8
40 5
end_mutex_group
begin_mutex_group
2
20 8
40 18
end_mutex_group
begin_mutex_group
2
20 8
42 12
end_mutex_group
begin_mutex_group
2
20 8
42 19
end_mutex_group
begin_mutex_group
2
20 8
43 19
end_mutex_group
begin_mutex_group
2
20 8
35 10
end_mutex_group
begin_mutex_group
2
20 8
35 16
end_mutex_group
begin_mutex_group
2
20 8
36 16
end_mutex_group
begin_mutex_group
2
20 8
41 12
end_mutex_group
begin_mutex_group
2
20 8
41 18
end_mutex_group
begin_mutex_group
2
20 8
39 17
end_mutex_group
begin_mutex_group
2
20 8
34 15
end_mutex_group
begin_mutex_group
2
20 8
31 10
end_mutex_group
begin_mutex_group
2
20 8
37 16
end_mutex_group
begin_mutex_group
2
20 8
38 16
end_mutex_group
begin_mutex_group
2
20 8
44 15
end_mutex_group
begin_mutex_group
2
20 9
21 0
end_mutex_group
begin_mutex_group
2
20 9
21 2
end_mutex_group
begin_mutex_group
2
20 9
22 2
end_mutex_group
begin_mutex_group
2
20 9
23 2
end_mutex_group
begin_mutex_group
2
20 9
24 3
end_mutex_group
begin_mutex_group
2
20 9
25 3
end_mutex_group
begin_mutex_group
2
20 9
26 2
end_mutex_group
begin_mutex_group
2
20 9
27 2
end_mutex_group
begin_mutex_group
2
20 9
30 8
end_mutex_group
begin_mutex




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




rator
stack b3 b2
0
4
0 20 17 0
0 18 0 1
0 12 -1 0
0 39 -1 6
1
end_operator
begin_operator
stack b3 b20
0
4
0 20 17 0
0 16 0 1
0 12 -1 0
0 39 -1 7
1
end_operator
begin_operator
stack b3 b21
0
4
0 20 17 0
0 45 0 1
0 12 -1 0
0 39 -1 8
1
end_operator
begin_operator
stack b3 b22
0
4
0 20 17 0
0 14 0 1
0 12 -1 0
0 39 -1 9
1
end_operator
begin_operator
stack b3 b23
0
4
0 20 17 0
0 4 0 1
0 12 -1 0
0 39 -1 10
1
end_operator
begin_operator
stack b3 b24
0
4
0 20 17 0
0 7 0 1
0 12 -1 0
0 39 -1 11
1
end_operator
begin_operator
stack b3 b6
0
4
0 20 17 0
0 12 -1 0
0 10 0 1
0 39 -1 12
1
end_operator
begin_operator
stack b3 b7
0
4
0 20 17 0
0 12 -1 0
0 46 0 1
0 39 -1 13
1
end_operator
begin_operator
stack b3 b8
0
4
0 20 17 0
0 12 -1 0
0 8 0 1
0 39 -1 14
1
end_operator
begin_operator
stack b3 b9
0
4
0 20 17 0
0 12 -1 0
0 19 0 1
0 39 -1 15
1
end_operator
begin_operator
stack b4 b22
0
4
0 20 18 0
0 14 0 1
0 5 -1 0
0 26 -1 0
1
end_operator
begin_operator
stack b5 b2
0
4
0 20 19 0
0 18 0 1
0 6 -1 0
0 27 -1 0
1
end_operator
begin_operator
stack b6 b10
0
4
0 20 20 0
0 9 0 1
0 10 -1 0
0 34 -1 0
1
end_operator
begin_operator
stack b6 b12
0
4
0 20 20 0
0 15 0 1
0 10 -1 0
0 34 -1 1
1
end_operator
begin_operator
stack b6 b13
0
4
0 20 20 0
0 11 0 1
0 10 -1 0
0 34 -1 2
1
end_operator
begin_operator
stack b6 b16
0
4
0 20 20 0
0 47 0 1
0 10 -1 0
0 34 -1 3
1
end_operator
begin_operator
stack b6 b19
0
4
0 20 20 0
0 13 0 1
0 10 -1 0
0 34 -1 4
1
end_operator
begin_operator
stack b6 b2
0
4
0 20 20 0
0 18 0 1
0 10 -1 0
0 34 -1 5
1
end_operator
begin_operator
stack b6 b20
0
4
0 20 20 0
0 16 0 1
0 10 -1 0
0 34 -1 6
1
end_operator
begin_operator
stack b6 b21
0
4
0 20 20 0
0 45 0 1
0 10 -1 0
0 34 -1 7
1
end_operator
begin_operator
stack b6 b22
0
4
0 20 20 0
0 14 0 1
0 10 -1 0
0 34 -1 8
1
end_operator
begin_operator
stack b6 b24
0
4
0 20 20 0
0 7 0 1
0 10 -1 0
0 34 -1 9
1
end_operator
begin_operator
stack b6 b3
0
4
0 20 20 0
0 12 0 1
0 10 -1 0
0 34 -1 10
1
end_operator
begin_operator
stack b6 b7
0
4
0 20 20 0
0 10 -1 0
0 46 0 1
0 34 -1 11
1
end_operator
begin_operator
stack b6 b8
0
4
0 20 20 0
0 10 -1 0
0 8 0 1
0 34 -1 12
1
end_operator
begin_operator
stack b6 b9
0
4
0 20 20 0
0 10 -1 0
0 19 0 1
0 34 -1 13
1
end_operator
begin_operator
stack b7 b10
0
4
0 20 21 0
0 9 0 1
0 46 -1 0
0 37 -1 0
1
end_operator
begin_operator
stack b7 b12
0
4
0 20 21 0
0 15 0 1
0 46 -1 0
0 37 -1 1
1
end_operator
begin_operator
stack b7 b13
0
4
0 20 21 0
0 11 0 1
0 46 -1 0
0 37 -1 2
1
end_operator
begin_operator
stack b7 b15
0
4
0 20 21 0
0 17 0 1
0 46 -1 0
0 37 -1 3
1
end_operator
begin_operator
stack b7 b16
0
4
0 20 21 0
0 47 0 1
0 46 -1 0
0 37 -1 4
1
end_operator
begin_operator
stack b7 b19
0
4
0 20 21 0
0 13 0 1
0 46 -1 0
0 37 -1 5
1
end_operator
begin_operator
stack b7 b2
0
4
0 20 21 0
0 18 0 1
0 46 -1 0
0 37 -1 6
1
end_operator
begin_operator
stack b7 b20
0
4
0 20 21 0
0 16 0 1
0 46 -1 0
0 37 -1 7
1
end_operator
begin_operator
stack b7 b21
0
4
0 20 21 0
0 45 0 1
0 46 -1 0
0 37 -1 8
1
end_operator
begin_operator
stack b7 b22
0
4
0 20 21 0
0 14 0 1
0 46 -1 0
0 37 -1 9
1
end_operator
begin_operator
stack b7 b23
0
4
0 20 21 0
0 4 0 1
0 46 -1 0
0 37 -1 10
1
end_operator
begin_operator
stack b7 b24
0
4
0 20 21 0
0 7 0 1
0 46 -1 0
0 37 -1 11
1
end_operator
begin_operator
stack b7 b6
0
4
0 20 21 0
0 10 0 1
0 46 -1 0
0 37 -1 12
1
end_operator
begin_operator
stack b7 b8
0
4
0 20 21 0
0 46 -1 0
0 8 0 1
0 37 -1 13
1
end_operator
begin_operator
stack b7 b9
0
4
0 20 21 0
0 46 -1 0
0 19 0 1
0 37 -1 14
1
end_operator
begin_operator
stack b8 b10
0
4
0 20 22 0
0 9 0 1
0 8 -1 0
0 31 -1 0
1
end_operator
begin_operator
stack b8 b16
0
4
0 20 22 0
0 47 0 1
0 8 -1 0
0 31 -1 1
1
end_operator
begin_operator
stack b8 b2
0
4
0 20 22 0
0 18 0 1
0 8 -1 0
0 31 -1 2
1
end_operator
begin_operator
stack b8 b20
0
4
0 20 22 0
0 16 0 1
0 8 -1 0
0 31 -1 3
1
end_operator
begin_operator
stack b8 b21
0
4
0 20 22 0
0 45 0 1
0 8 -1 0
0 31 -1 4
1
end_operator
begin_operator
stack b8 b22
0
4
0 20 22 0
0 14 0 1
0 8 -1 0
0 31 -1 5
1
end_operator
begin_operator
stack b8 b24
0
4
0 20 22 0
0 7 0 1
0 8 -1 0
0 31 -1 6
1
end_operator
begin_operator
stack b8 b6
0
4
0 20 22 0
0 10 0 1
0 8 -1 0
0 31 -1 7
1
end_operator
begin_operator
stack b8 b7
0
4
0 20 22 0
0 46 0 1
0 8 -1 0
0 31 -1 8
1
end_operator
begin_operator
stack b9 b1
0
4
0 20 -1 0
0 2 0 1
0 19 -1 0
0 44 0 1
1
end_operator
begin_operator
stack b9 b10
0
4
0 20 -1 0
0 9 0 1
0 19 -1 0
0 44 0 2
1
end_operator
begin_operator
stack b9 b12
0
4
0 20 -1 0
0 15 0 1
0 19 -1 0
0 44 0 3
1
end_operator
begin_operator
stack b9 b13
0
4
0 20 -1 0
0 11 0 1
0 19 -1 0
0 44 0 4
1
end_operator
begin_operator
stack b9 b15
0
4
0 20 -1 0
0 17 0 1
0 19 -1 0
0 44 0 5
1
end_operator
begin_operator
stack b9 b16
0
4
0 20 -1 0
0 47 0 1
0 19 -1 0
0 44 0 6
1
end_operator
begin_operator
stack b9 b17
0
4
0 20 -1 0
0 3 0 1
0 19 -1 0
0 44 0 7
1
end_operator
begin_operator
stack b9 b19
0
4
0 20 -1 0
0 13 0 1
0 19 -1 0
0 44 0 8
1
end_operator
begin_operator
stack b9 b2
0
4
0 20 -1 0
0 18 0 1
0 19 -1 0
0 44 0 9
1
end_operator
begin_operator
stack b9 b20
0
4
0 20 -1 0
0 16 0 1
0 19 -1 0
0 44 0 10
1
end_operator
begin_operator
stack b9 b21
0
4
0 20 -1 0
0 45 0 1
0 19 -1 0
0 44 0 11
1
end_operator
begin_operator
stack b9 b22
0
4
0 20 -1 0
0 14 0 1
0 19 -1 0
0 44 0 12
1
end_operator
begin_operator
stack b9 b23
0
4
0 20 -1 0
0 4 0 1
0 19 -1 0
0 44 0 13
1
end_operator
begin_operator
stack b9 b3
0
4
0 20 -1 0
0 12 0 1
0 19 -1 0
0 44 0 14
1
end_operator
begin_operator
stack b9 b4
0
4
0 20 -1 0
0 5 0 1
0 19 -1 0
0 44 0 15
1
end_operator
begin_operator
stack b9 b5
0
4
0 20 -1 0
0 6 0 1
0 19 -1 0
0 44 0 16
1
end_operator
begin_operator
stack b9 b6
0
4
0 20 -1 0
0 10 0 1
0 19 -1 0
0 44 0 17
1
end_operator
begin_operator
stack b9 b7
0
4
0 20 -1 0
0 46 0 1
0 19 -1 0
0 44 0 18
1
end_operator
begin_operator
stack b9 b8
0
4
0 20 -1 0
0 8 0 1
0 19 -1 0
0 44 0 19
1
end_operator
begin_operator
unstack b10 b16
0
4
0 20 0 1
0 9 0 1
0 47 -1 0
0 30 1 8
1
end_operator
begin_operator
unstack b10 b2
0
4
0 20 0 1
0 9 0 1
0 18 -1 0
0 30 2 8
1
end_operator
begin_operator
unstack b10 b21
0
4
0 20 0 1
0 9 0 1
0 45 -1 0
0 30 3 8
1
end_operator
begin_operator
unstack b10 b22
0
4
0 20 0 1
0 9 0 1
0 14 -1 0
0 30 4 8
1
end_operator
begin_operator
unstack b10 b24
0
4
0 20 0 1
0 9 0 1
0 7 -1 0
0 30 5 8
1
end_operator
begin_operator
unstack b10 b8
0
4
0 20 0 1
0 9 0 1
0 8 -1 0
0 30 6 8
1
end_operator
begin_operator
unstack b11 b20
0
4
0 20 0 2
0 0 0 1
0 16 -1 0
0 21 0 2
1
end_operator
begin_operator
unstack b12 b1
0
4
0 20 0 3
0 2 -1 0
0 15 0 1
0 42 0 19
1
end_operator
begin_operator
unstack b12 b10
0
4
0 20 0 3
0 9 -1 0
0 15 0 1
0 42 1 19
1
end_operator
begin_operator
unstack b12 b13
0
4
0 20 0 3
0 15 0 1
0 11 -1 0
0 42 2 19
1
end_operator
begin_operator
unstack b12 b15
0
4
0 20 0 3
0 15 0 1
0 17 -1 0
0 42 3 19
1
end_operator
begin_operator
unstack b12 b16
0
4
0 20 0 3
0 15 0 1
0 47 -1 0
0 42 4 19
1
end_operator
begin_operator
unstack b12 b19
0
4
0 20 0 3
0 15 0 1
0 13 -1 0
0 42 5 19
1
end_operator
begin_operator
unstack b12 b2
0
4
0 20 0 3
0 15 0 1
0 18 -1 0
0 42 6 19
1
end_operator
begin_operator
unstack b12 b20
0
4
0 20 0 3
0 15 0 1
0 16 -1 0
0 42 7 19
1
end_operator
begin_operator
unstack b12 b21
0
4
0 20 0 3
0 15 0 1
0 45 -1 0
0 42 8 19
1
end_operator
begin_operator
unstack b12 b22
0
4
0 20 0 3
0 15 0 1
0 14 -1 0
0 42 9 19
1
end_operator
begin_operator
unstack b12 b23
0
4
0 20 0 3
0 15 0 1
0 4 -1 0
0 42 10 19
1
end_operator
begin_operator
unstack b12 b3
0
4
0 20 0 3
0 15 0 1
0 12 -1 0
0 42 11 19
1
end_operator
begin_operator
unstack b12 b4
0
4
0 20 0 3
0 15 0 1
0 5 -1 0
0 42 12 19
1
end_operator
begin_operator
unstack b12 b5
0
4
0 20 0 3
0 15 0 1
0 6 -1 0
0 42 13 19
1
end_operator
begin_operator
unstack b12 b6
0
4
0 20 0 3
0 15 0 1
0 10 -1 0
0 42 14 19
1
end_operator
begin_operator
unstack b12 b7
0
4
0 20 0 3
0 15 0 1
0 46 -1 0
0 42 15 19
1
end_operator
begin_operator
unstack b12 b8
0
4
0 20 0 3
0 15 0 1
0 8 -1 0
0 42 16 19
1
end_operator
begin_operator
unstack b12 b9
0
4
0 20 0 3
0 15 0 1
0 19 -1 0
0 42 17 19
1
end_operator
begin_operator
unstack b13 b10
0
4
0 20 0 4
0 9 -1 0
0 11 0 1
0 33 0 15
1
end_operator
begin_operator
unstack b13 b12
0
4
0 20 0 4
0 15 -1 0
0 11 0 1
0 33 1 15
1
end_operator
begin_operator
unstack b13 b15
0
4
0 20 0 4
0 11 0 1
0 17 -1 0
0 33 2 15
1
end_operator
begin_operator
unstack b13 b16
0
4
0 20 0 4
0 11 0 1
0 47 -1 0
0 33 3 15
1
end_operator
begin_operator
unstack b13 b19
0
4
0 20 0 4
0 11 0 1
0 13 -1 0
0 33 4 15
1
end_operator
begin_operator
unstack b13 b2
0
4
0 20 0 4
0 11 0 1
0 18 -1 0
0 33 5 15
1
end_operator
begin_operator
unstack b13 b21
0
4
0 20 0 4
0 11 0 1
0 45 -1 0
0 33 6 15
1
end_operator
begin_operator
unstack b13 b24
0
4
0 20 0 4
0 11 0 1
0 7 -1 0
0 33 7 15
1
end_operator
begin_operator
unstack b13 b3
0
4
0 20 0 4
0 11 0 1
0 12 -1 0
0 33 8 15
1
end_operator
begin_operator
unstack b13 b4
0
4
0 20 0 4
0 11 0 1
0 5 -1 0
0 33 9 15
1
end_operator
begin_operator
unstack b13 b5
0
4
0 20 0 4
0 11 0 1
0 6 -1 0
0 33 10 15
1
end_operator
begin_operator
unstack b13 b6
0
4
0 20 0 4
0 11 0 1
0 10 -1 0
0 33 11 15
1
end_operator
begin_operator
unstack b13 b7
0
4
0 20 0 4
0 11 0 1
0 46 -1 0
0 33 12 15
1
end_operator
begin_operator
unstack b13 b9
0
4
0 20 0 4
0 11 0 1
0 19 -1 0
0 33 13 15
1
end_operator
begin_operator
unstack b14 b18
0
4
0 20 0 5
0 1 0 1
0 29 -1 0
0 24 1 3
1
end_operator
begin_operator
unstack b15 b1
0
4
0 20 0 6
0 2 -1 0
0 17 0 1
0 43 0 19
1
end_operator
begin_operator
unstack b15 b10
0
4
0 20 0 6
0 9 -1 0
0 17 0 1
0 43 1 19
1
end_operator
begin_operator
unstack b15 b12
0
4
0 20 0 6
0 15 -1 0
0 17 0 1
0 43 2 19
1
end_operator
begin_operator
unstack b15 b13
0
4
0 20 0 6
0 11 -1 0
0 17 0 1
0 43 3 19
1
end_operator
begin_operator
unstack b15 b16
0
4
0 20 0 6
0 17 0 1
0 47 -1 0
0 43 4 19
1
end_operator
begin_operator
unstack b15 b17
0
4
0 20 0 6
0 17 0 1
0 3 -1 0
0 43 5 19
1
end_operator
begin_operator
unstack b15 b19
0
4
0 20 0 6
0 17 0 1
0 13 -1 0
0 43 6 19
1
end_operator
begin_operator
unstack b15 b2
0
4
0 20 0 6
0 17 0 1
0 18 -1 0
0 43 7 19
1
end_operator
begin_operator
unstack b15 b20
0
4
0 20 0 6
0 17 0 1
0 16 -1 0
0 43 8 19
1
end_operator
begin_operator
unstack b15 b21
0
4
0 20 0 6
0 17 0 1
0 45 -1 0
0 43 9 19
1
end_operator
begin_operator
unstack b15 b22
0
4
0 20 0 6
0 17 0 1
0 14 -1 0
0 43 10 19
1
end_operator
begin_operator
unstack b15 b23
0
4
0 20 0 6
0 17 0 1
0 4 -1 0
0 43 11 19
1
end_operator
begin_operator
unstack b15 b24
0
4
0 20 0 6
0 17 0 1
0 7 -1 0
0 43 12 19
1
end_operator
begin_operator
unstack b15 b5
0
4
0 20 0 6
0 17 0 1
0 6 -1 0
0 43 13 19
1
end_operator
begin_operator
unstack b15 b6
0
4
0 20 0 6
0 17 0 1
0 10 -1 0
0 43 14 19
1
end_operator
begin_operator
unstack b15 b7
0
4
0 20 0 6
0 17 0 1
0 46 -1 0
0 43 15 19
1
end_operator
begin_operator
unstack b15 b8
0
4
0 20 0 6
0 17 0 1
0 8 -1 0
0 43 16 19
1
end_operator
begin_operator
unstack b15 b9
0
4
0 20 0 6
0 17 0 1
0 19 -1 0
0 43 17 19
1
end_operator
begin_operator
unstack b16 b10
0
4
0 20 0 7
0 9 -1 0
0 47 0 1
0 40 0 18
1
end_operator
begin_operator
unstack b16 b12
0
4
0 20 0 7
0 15 -1 0
0 47 0 1
0 40 1 18
1
end_operator
begin_operator
unstack b16 b13
0
4
0 20 0 7
0 11 -1 0
0 47 0 1
0 40 2 18
1
end_operator
begin_operator
unstack b16 b15
0
4
0 20 0 7
0 17 -1 0
0 47 0 1
0 40 3 18
1
end_operator
begin_operator
unstack b16 b17
0
4
0 20 0 7
0 47 0 1
0 3 -1 0
0 40 4 18
1
end_operator
begin_operator
unstack b16 b2
0
4
0 20 0 7
0 47 0 1
0 18 -1 0
0 40 5 18
1
end_operator
begin_operator
unstack b16 b20
0
4
0 20 0 7
0 47 0 1
0 16 -1 0
0 40 6 18
1
end_operator
begin_operator
unstack b16 b21
0
4
0 20 0 7
0 47 0 1
0 45 -1 0
0 40 7 18
1
end_operator
begin_operator
unstack b16 b22
0
4
0 20 0 7
0 47 0 1
0 14 -1 0
0 40 8 18
1
end_operator
begin_operator
unstack b16 b23
0
4
0 20 0 7
0 47 0 1
0 4 -1 0
0 40 9 18
1
end_operator
begin_operator
unstack b16 b24
0
4
0 20 0 7
0 47 0 1
0 7 -1 0
0 40 10 18
1
end_operator
begin_operator
unstack b16 b3
0
4
0 20 0 7
0 47 0 1
0 12 -1 0
0 40 11 18
1
end_operator
begin_operator
unstack b16 b6
0
4
0 20 0 7
0 47 0 1
0 10 -1 0
0 40 13 18
1
end_operator
begin_operator
unstack b16 b7
0
4
0 20 0 7
0 47 0 1
0 46 -1 0
0 40 14 18
1
end_operator
begin_operator
unstack b16 b8
0
4
0 20 0 7
0 47 0 1
0 8 -1 0
0 40 15 18
1
end_operator
begin_operator
unstack b16 b9
0
4
0 20 0 7
0 47 0 1
0 19 -1 0
0 40 16 18
1
end_operator
begin_operator
unstack b17 b4
0
4
0 20 0 8
0 3 0 1
0 5 -1 0
0 22 0 2
1
end_operator
begin_operator
unstack b18 b10
0
4
0 20 0 9
0 9 -1 0
0 29 0 1
0 28 0 2
1
end_operator
begin_operator
unstack b19 b10
0
4
0 20 0 10
0 9 -1 0
0 13 0 1
0 35 0 16
1
end_operator
begin_operator
unstack b19 b13
0
4
0 20 0 10
0 11 -1 0
0 13 0 1
0 35 1 16
1
end_operator
begin_operator
unstack b19 b15
0
4
0 20 0 10
0 17 -1 0
0 13 0 1
0 35 2 16
1
end_operator
begin_operator
unstack b19 b16
0
4
0 20 0 10
0 47 -1 0
0 13 0 1
0 35 3 16
1
end_operator
begin_operator
unstack b19 b2
0
4
0 20 0 10
0 13 0 1
0 18 -1 0
0 35 4 16
1
end_operator
begin_operator
unstack b19 b20
0
4
0 20 0 10
0 13 0 1
0 16 -1 0
0 35 5 16
1
end_operator
begin_operator
unstack b19 b21
0
4
0 20 0 10
0 13 0 1
0 45 -1 0
0 35 6 16
1
end_operator
begin_operator
unstack b19 b22
0
4
0 20 0 10
0 13 0 1
0 14 -1 0
0 35 7 16
1
end_operator
begin_operator
unstack b19 b24
0
4
0 20 0 10
0 13 0 1
0 7 -1 0
0 35 8 16
1
end_operator
begin_operator
unstack b19 b3
0
4
0 20 0 10
0 13 0 1
0 12 -1 0
0 35 9 16
1
end_operator
begin_operator
unstack b19 b4
0
4
0 20 0 10
0 13 0 1
0 5 -1 0
0 35 10 16
1
end_operator
begin_operator
unstack b19 b5
0
4
0 20 0 10
0 13 0 1
0 6 -1 0
0 35 11 16
1
end_operator
begin_operator
unstack b19 b6
0
4
0 20 0 10
0 13 0 1
0 10 -1 0
0 35 12 16
1
end_operator
begin_operator
unstack b19 b7
0
4
0 20 0 10
0 13 0 1
0 46 -1 0
0 35 13 16
1
end_operator
begin_operator
unstack b19 b9
0
4
0 20 0 10
0 13 0 1
0 19 -1 0
0 35 14 16
1
end_operator
begin_operator
unstack b2 b10
0
4
0 20 0 11
0 9 -1 0
0 18 0 1
0 36 0 16
1
end_operator
begin_operator
unstack b2 b12
0
4
0 20 0 11
0 15 -1 0
0 18 0 1
0 36 1 16
1
end_operator
begin_operator
unstack b2 b13
0
4
0 20 0 11
0 11 -1 0
0 18 0 1
0 36 2 16
1
end_operator
begin_operator
unstack b2 b15
0
4
0 20 0 11
0 17 -1 0
0 18 0 1
0 36 4 16
1
end_operator
begin_operator
unstack b2 b16
0
4
0 20 0 11
0 47 -1 0
0 18 0 1
0 36 5 16
1
end_operator
begin_operator
unstack b2 b19
0
4
0 20 0 11
0 13 -1 0
0 18 0 1
0 36 6 16
1
end_operator
begin_operator
unstack b2 b20
0
4
0 20 0 11
0 18 0 1
0 16 -1 0
0 36 7 16
1
end_operator
begin_operator
unstack b2 b21
0
4
0 20 0 11
0 18 0 1
0 45 -1 0
0 36 8 16
1
end_operator
begin_operator
unstack b2 b22
0
4
0 20 0 11
0 18 0 1
0 14 -1 0
0 36 9 16
1
end_operator
begin_operator
unstack b2 b24
0
4
0 20 0 11
0 18 0 1
0 7 -1 0
0 36 10 16
1
end_operator
begin_operator
unstack b2 b3
0
4
0 20 0 11
0 18 0 1
0 12 -1 0
0 36 11 16
1
end_operator
begin_operator
unstack b2 b7
0
4
0 20 0 11
0 18 0 1
0 46 -1 0
0 36 12 16
1
end_operator
begin_operator
unstack b2 b8
0
4
0 20 0 11
0 18 0 1
0 8 -1 0
0 36 13 16
1
end_operator
begin_operator
unstack b2 b9
0
4
0 20 0 11
0 18 0 1
0 19 -1 0
0 36 14 16
1
end_operator
begin_operator
unstack b20 b10
0
4
0 20 0 12
0 9 -1 0
0 16 0 1
0 41 0 18
1
end_operator
begin_operator
unstack b20 b12
0
4
0 20 0 12
0 15 -1 0
0 16 0 1
0 41 1 18
1
end_operator
begin_operator
unstack b20 b13
0
4
0 20 0 12
0 11 -1 0
0 16 0 1
0 41 2 18
1
end_operator
begin_operator
unstack b20 b14
0
4
0 20 0 12
0 1 -1 0
0 16 0 1
0 41 3 18
1
end_operator
begin_operator
unstack b20 b15
0
4
0 20 0 12
0 17 -1 0
0 16 0 1
0 41 4 18
1
end_operator
begin_operator
unstack b20 b16
0
4
0 20 0 12
0 47 -1 0
0 16 0 1
0 41 5 18
1
end_operator
begin_operator
unstack b20 b19
0
4
0 20 0 12
0 13 -1 0
0 16 0 1
0 41 6 18
1
end_operator
begin_operator
unstack b20 b2
0
4
0 20 0 12
0 18 -1 0
0 16 0 1
0 41 7 18
1
end_operator
begin_operator
unstack b20 b21
0
4
0 20 0 12
0 16 0 1
0 45 -1 0
0 41 8 18
1
end_operator
begin_operator
unstack b20 b22
0
4
0 20 0 12
0 16 0 1
0 14 -1 0
0 41 9 18
1
end_operator
begin_operator
unstack b20 b24
0
4
0 20 0 12
0 16 0 1
0 7 -1 0
0 41 10 18
1
end_operator
begin_operator
unstack b20 b3
0
4
0 20 0 12
0 16 0 1
0 12 -1 0
0 41 11 18
1
end_operator
begin_operator
unstack b20 b4
0
4
0 20 0 12
0 16 0 1
0 5 -1 0
0 41 12 18
1
end_operator
begin_operator
unstack b20 b5
0
4
0 20 0 12
0 16 0 1
0 6 -1 0
0 41 13 18
1
end_operator
begin_operator
unstack b20 b7
0
4
0 20 0 12
0 16 0 1
0 46 -1 0
0 41 14 18
1
end_operator
begin_operator
unstack b20 b8
0
4
0 20 0 12
0 16 0 1
0 8 -1 0
0 41 15 18
1
end_operator
begin_operator
unstack b20 b9
0
4
0 20 0 12
0 16 0 1
0 19 -1 0
0 41 16 18
1
end_operator
begin_operator
unstack b21 b10
0
4
0 20 0 13
0 9 -1 0
0 45 0 1
0 38 0 16
1
end_operator
begin_operator
unstack b21 b12
0
4
0 20 0 13
0 15 -1 0
0 45 0 1
0 38 1 16
1
end_operator
begin_operator
unstack b21 b15
0
4
0 20 0 13
0 17 -1 0
0 45 0 1
0 38 2 16
1
end_operator
begin_operator
unstack b21 b16
0
4
0 20 0 13
0 47 -1 0
0 45 0 1
0 38 3 16
1
end_operator
begin_operator
unstack b21 b17
0
4
0 20 0 13
0 3 -1 0
0 45 0 1
0 38 4 16
1
end_operator
begin_operator
unstack b21 b19
0
4
0 20 0 13
0 13 -1 0
0 45 0 1
0 38 5 16
1
end_operator
begin_operator
unstack b21 b2
0
4
0 20 0 13
0 18 -1 0
0 45 0 1
0 38 6 16
1
end_operator
begin_operator
unstack b21 b20
0
4
0 20 0 13
0 16 -1 0
0 45 0 1
0 38 7 16
1
end_operator
begin_operator
unstack b21 b22
0
4
0 20 0 13
0 45 0 1
0 14 -1 0
0 38 8 16
1
end_operator
begin_operator
unstack b21 b24
0
4
0 20 0 13
0 45 0 1
0 7 -1 0
0 38 9 16
1
end_operator
begin_operator
unstack b21 b3
0
4
0 20 0 13
0 45 0 1
0 12 -1 0
0 38 10 16
1
end_operator
begin_operator
unstack b21 b6
0
4
0 20 0 13
0 45 0 1
0 10 -1 0
0 38 11 16
1
end_operator
begin_operator
unstack b21 b7
0
4
0 20 0 13
0 45 0 1
0 46 -1 0
0 38 12 16
1
end_operator
begin_operator
unstack b21 b8
0
4
0 20 0 13
0 45 0 1
0 8 -1 0
0 38 13 16
1
end_operator
begin_operator
unstack b21 b9
0
4
0 20 0 13
0 45 0 1
0 19 -1 0
0 38 14 16
1
end_operator
begin_operator
unstack b22 b10
0
4
0 20 0 14
0 9 -1 0
0 14 0 1
0 32 0 14
1
end_operator
begin_operator
unstack b22 b13
0
4
0 20 0 14
0 11 -1 0
0 14 0 1
0 32 1 14
1
end_operator
begin_operator
unstack b22 b15
0
4
0 20 0 14
0 17 -1 0
0 14 0 1
0 32 2 14
1
end_operator
begin_operator
unstack b22 b16
0
4
0 20 0 14
0 47 -1 0
0 14 0 1
0 32 3 14
1
end_operator
begin_operator
unstack b22 b19
0
4
0 20 0 14
0 13 -1 0
0 14 0 1
0 32 4 14
1
end_operator
begin_operator
unstack b22 b2
0
4
0 20 0 14
0 18 -1 0
0 14 0 1
0 32 5 14
1
end_operator
begin_operator
unstack b22 b24
0
4
0 20 0 14
0 14 0 1
0 7 -1 0
0 32 6 14
1
end_operator
begin_operator
unstack b22 b3
0
4
0 20 0 14
0 14 0 1
0 12 -1 0
0 32 7 14
1
end_operator
begin_operator
unstack b22 b4
0
4
0 20 0 14
0 14 0 1
0 5 -1 0
0 32 8 14
1
end_operator
begin_operator
unstack b22 b5
0
4
0 20 0 14
0 14 0 1
0 6 -1 0
0 32 9 14
1
end_operator
begin_operator
unstack b22 b7
0
4
0 20 0 14
0 14 0 1
0 46 -1 0
0 32 10 14
1
end_operator
begin_operator
unstack b22 b8
0
4
0 20 0 14
0 14 0 1
0 8 -1 0
0 32 11 14
1
end_operator
begin_operator
unstack b22 b9
0
4
0 20 0 14
0 14 0 1
0 19 -1 0
0 32 12 14
1
end_operator
begin_operator
unstack b23 b5
0
4
0 20 0 15
0 4 0 1
0 6 -1 0
0 23 0 2
1
end_operator
begin_operator
unstack b24 b1
0
4
0 20 0 16
0 2 -1 0
0 7 0 1
0 25 0 3
1
end_operator
begin_operator
unstack b24 b17
0
4
0 20 0 16
0 3 -1 0
0 7 0 1
0 25 1 3
1
end_operator
begin_operator
unstack b3 b10
0
4
0 20 0 17
0 9 -1 0
0 12 0 1
0 39 0 17
1
end_operator
begin_operator
unstack b3 b12
0
4
0 20 0 17
0 15 -1 0
0 12 0 1
0 39 1 17
1
end_operator
begin_operator
unstack b3 b13
0
4
0 20 0 17
0 11 -1 0
0 12 0 1
0 39 2 17
1
end_operator
begin_operator
unstack b3 b15
0
4
0 20 0 17
0 17 -1 0
0 12 0 1
0 39 3 17
1
end_operator
begin_operator
unstack b3 b16
0
4
0 20 0 17
0 47 -1 0
0 12 0 1
0 39 4 17
1
end_operator
begin_operator
unstack b3 b19
0
4
0 20 0 17
0 13 -1 0
0 12 0 1
0 39 5 17
1
end_operator
begin_operator
unstack b3 b2
0
4
0 20 0 17
0 18 -1 0
0 12 0 1
0 39 6 17
1
end_operator
begin_operator
unstack b3 b20
0
4
0 20 0 17
0 16 -1 0
0 12 0 1
0 39 7 17
1
end_operator
begin_operator
unstack b3 b21
0
4
0 20 0 17
0 45 -1 0
0 12 0 1
0 39 8 17
1
end_operator
begin_operator
unstack b3 b22
0
4
0 20 0 17
0 14 -1 0
0 12 0 1
0 39 9 17
1
end_operator
begin_operator
unstack b3 b23
0
4
0 20 0 17
0 4 -1 0
0 12 0 1
0 39 10 17
1
end_operator
begin_operator
unstack b3 b24
0
4
0 20 0 17
0 7 -1 0
0 12 0 1
0 39 11 17
1
end_operator
begin_operator
unstack b3 b6
0
4
0 20 0 17
0 12 0 1
0 10 -1 0
0 39 12 17
1
end_operator
begin_operator
unstack b3 b7
0
4
0 20 0 17
0 12 0 1
0 46 -1 0
0 39 13 17
1
end_operator
begin_operator
unstack b3 b8
0
4
0 20 0 17
0 12 0 1
0 8 -1 0
0 39 14 17
1
end_operator
begin_operator
unstack b3 b9
0
4
0 20 0 17
0 12 0 1
0 19 -1 0
0 39 15 17
1
end_operator
begin_operator
unstack b4 b22
0
4
0 20 0 18
0 14 -1 0
0 5 0 1
0 26 0 2
1
end_operator
begin_operator
unstack b5 b2
0
4
0 20 0 19
0 18 -1 0
0 6 0 1
0 27 0 2
1
end_operator
begin_operator
unstack b6 b10
0
4
0 20 0 20
0 9 -1 0
0 10 0 1
0 34 0 15
1
end_operator
begin_operator
unstack b6 b12
0
4
0 20 0 20
0 15 -1 0
0 10 0 1
0 34 1 15
1
end_operator
begin_operator
unstack b6 b13
0
4
0 20 0 20
0 11 -1 0
0 10 0 1
0 34 2 15
1
end_operator
begin_operator
unstack b6 b16
0
4
0 20 0 20
0 47 -1 0
0 10 0 1
0 34 3 15
1
end_operator
begin_operator
unstack b6 b19
0
4
0 20 0 20
0 13 -1 0
0 10 0 1
0 34 4 15
1
end_operator
begin_operator
unstack b6 b2
0
4
0 20 0 20
0 18 -1 0
0 10 0 1
0 34 5 15
1
end_operator
begin_operator
unstack b6 b20
0
4
0 20 0 20
0 16 -1 0
0 10 0 1
0 34 6 15
1
end_operator
begin_operator
unstack b6 b21
0
4
0 20 0 20
0 45 -1 0
0 10 0 1
0 34 7 15
1
end_operator
begin_operator
unstack b6 b22
0
4
0 20 0 20
0 14 -1 0
0 10 0 1
0 34 8 15
1
end_operator
begin_operator
unstack b6 b24
0
4
0 20 0 20
0 7 -1 0
0 10 0 1
0 34 9 15
1
end_operator
begin_operator
unstack b6 b3
0
4
0 20 0 20
0 12 -1 0
0 10 0 1
0 34 10 15
1
end_operator
begin_operator
unstack b6 b7
0
4
0 20 0 20
0 10 0 1
0 46 -1 0
0 34 11 15
1
end_operator
begin_operator
unstack b6 b8
0
4
0 20 0 20
0 10 0 1
0 8 -1 0
0 34 12 15
1
end_operator
begin_operator
unstack b6 b9
0
4
0 20 0 20
0 10 0 1
0 19 -1 0
0 34 13 15
1
end_operator
begin_operator
unstack b7 b10
0
4
0 20 0 21
0 9 -1 0
0 46 0 1
0 37 0 16
1
end_operator
begin_operator
unstack b7 b12
0
4
0 20 0 21
0 15 -1 0
0 46 0 1
0 37 1 16
1
end_operator
begin_operator
unstack b7 b13
0
4
0 20 0 21
0 11 -1 0
0 46 0 1
0 37 2 16
1
end_operator
begin_operator
unstack b7 b15
0
4
0 20 0 21
0 17 -1 0
0 46 0 1
0 37 3 16
1
end_operator
begin_operator
unstack b7 b16
0
4
0 20 0 21
0 47 -1 0
0 46 0 1
0 37 4 16
1
end_operator
begin_operator
unstack b7 b19
0
4
0 20 0 21
0 13 -1 0
0 46 0 1
0 37 5 16
1
end_operator
begin_operator
unstack b7 b2
0
4
0 20 0 21
0 18 -1 0
0 46 0 1
0 37 6 16
1
end_operator
begin_operator
unstack b7 b20
0
4
0 20 0 21
0 16 -1 0
0 46 0 1
0 37 7 16
1
end_operator
begin_operator
unstack b7 b21
0
4
0 20 0 21
0 45 -1 0
0 46 0 1
0 37 8 16
1
end_operator
begin_operator
unstack b7 b22
0
4
0 20 0 21
0 14 -1 0
0 46 0 1
0 37 9 16
1
end_operator
begin_operator
unstack b7 b23
0
4
0 20 0 21
0 4 -1 0
0 46 0 1
0 37 10 16
1
end_operator
begin_operator
unstack b7 b24
0
4
0 20 0 21
0 7 -1 0
0 46 0 1
0 37 11 16
1
end_operator
begin_operator
unstack b7 b6
0
4
0 20 0 21
0 10 -1 0
0 46 0 1
0 37 12 16
1
end_operator
begin_operator
unstack b7 b8
0
4
0 20 0 21
0 46 0 1
0 8 -1 0
0 37 13 16
1
end_operator
begin_operator
unstack b8 b10
0
4
0 20 0 22
0 9 -1 0
0 8 0 1
0 31 0 10
1
end_operator
begin_operator
unstack b8 b16
0
4
0 20 0 22
0 47 -1 0
0 8 0 1
0 31 1 10
1
end_operator
begin_operator
unstack b8 b2
0
4
0 20 0 22
0 18 -1 0
0 8 0 1
0 31 2 10
1
end_operator
begin_operator
unstack b8 b20
0
4
0 20 0 22
0 16 -1 0
0 8 0 1
0 31 3 10
1
end_operator
begin_operator
unstack b8 b21
0
4
0 20 0 22
0 45 -1 0
0 8 0 1
0 31 4 10
1
end_operator
begin_operator
unstack b8 b22
0
4
0 20 0 22
0 14 -1 0
0 8 0 1
0 31 5 10
1
end_operator
begin_operator
unstack b8 b24
0
4
0 20 0 22
0 7 -1 0
0 8 0 1
0 31 6 10
1
end_operator
begin_operator
unstack b8 b7
0
4
0 20 0 22
0 46 -1 0
0 8 0 1
0 31 8 10
1
end_operator
begin_operator
unstack b9 b1
0
4
0 20 0 23
0 2 -1 0
0 19 0 1
0 44 1 0
1
end_operator
begin_operator
unstack b9 b10
0
4
0 20 0 23
0 9 -1 0
0 19 0 1
0 44 2 0
1
end_operator
begin_operator
unstack b9 b12
0
4
0 20 0 23
0 15 -1 0
0 19 0 1
0 44 3 0
1
end_operator
begin_operator
unstack b9 b13
0
4
0 20 0 23
0 11 -1 0
0 19 0 1
0 44 4 0
1
end_operator
begin_operator
unstack b9 b15
0
4
0 20 0 23
0 17 -1 0
0 19 0 1
0 44 5 0
1
end_operator
begin_operator
unstack b9 b16
0
4
0 20 0 23
0 47 -1 0
0 19 0 1
0 44 6 0
1
end_operator
begin_operator
unstack b9 b17
0
4
0 20 0 23
0 3 -1 0
0 19 0 1
0 44 7 0
1
end_operator
begin_operator
unstack b9 b19
0
4
0 20 0 23
0 13 -1 0
0 19 0 1
0 44 8 0
1
end_operator
begin_operator
unstack b9 b2
0
4
0 20 0 23
0 18 -1 0
0 19 0 1
0 44 9 0
1
end_operator
begin_operator
unstack b9 b20
0
4
0 20 0 23
0 16 -1 0
0 19 0 1
0 44 10 0
1
end_operator
begin_operator
unstack b9 b21
0
4
0 20 0 23
0 45 -1 0
0 19 0 1
0 44 11 0
1
end_operator
begin_operator
unstack b9 b22
0
4
0 20 0 23
0 14 -1 0
0 19 0 1
0 44 12 0
1
end_operator
begin_operator
unstack b9 b23
0
4
0 20 0 23
0 4 -1 0
0 19 0 1
0 44 13 0
1
end_operator
begin_operator
unstack b9 b4
0
4
0 20 0 23
0 5 -1 0
0 19 0 1
0 44 15 0
1
end_operator
begin_operator
unstack b9 b5
0
4
0 20 0 23
0 6 -1 0
0 19 0 1
0 44 16 0
1
end_operator
begin_operator
unstack b9 b6
0
4
0 20 0 23
0 10 -1 0
0 19 0 1
0 44 17 0
1
end_operator
begin_operator
unstack b9 b7
0
4
0 20 0 23
0 46 -1 0
0 19 0 1
0 44 18 0
1
end_operator
begin_operator
unstack b9 b8
0
4
0 20 0 23
0 8 -1 0
0 19 0 1
0 44 19 0
1
end_operator
0
