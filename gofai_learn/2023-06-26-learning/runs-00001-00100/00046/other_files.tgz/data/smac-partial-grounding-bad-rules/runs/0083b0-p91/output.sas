begin_version
3
end_version
begin_metric
0
end_metric
54
begin_variable
var0
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var1
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var2
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var3
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var4
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var5
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var6
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var7
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var9
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var8
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var12
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var13
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var14
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var15
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var17
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var18
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var16
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var19
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var20
-1
27
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var21
-1
3
Atom on(b12, b4)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var22
-1
3
Atom on(b17, b18)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var23
-1
3
Atom on(b22, b8)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b5, b2)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var25
-1
3
Atom on(b9, b16)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom on(b1, b12)
Atom on(b1, b24)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b25, b24)
Atom on-table(b25)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b8, b19)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b23, b22)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var31
-1
4
Atom on(b13, b1)
Atom on(b13, b27)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var30
-1
3
Atom clear(b23)
Atom on(b21, b23)
<none of those>
end_variable
begin_variable
var35
-1
10
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b13)
Atom on(b19, b26)
Atom on(b19, b27)
Atom on(b19, b4)
Atom on(b19, b8)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var34
-1
18
Atom on(b18, b1)
Atom on(b18, b11)
Atom on(b18, b13)
Atom on(b18, b14)
Atom on(b18, b16)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b24)
Atom on(b18, b25)
Atom on(b18, b26)
Atom on(b18, b27)
Atom on(b18, b3)
Atom on(b18, b4)
Atom on(b18, b6)
Atom on(b18, b7)
Atom on(b18, b9)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var40
-1
19
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b24)
Atom on(b16, b25)
Atom on(b16, b26)
Atom on(b16, b27)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var33
-1
19
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b13)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b24)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var38
-1
19
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b13)
Atom on(b14, b16)
Atom on(b14, b18)
Atom on(b14, b2)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b26)
Atom on(b14, b27)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var39
-1
20
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b25)
Atom on(b15, b26)
Atom on(b15, b27)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15, b6)
Atom on(b15, b7)
Atom on(b15, b8)
Atom on(b15, b9)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var41
-1
19
Atom on(b2, b1)
Atom on(b2, b11)
Atom on(b2, b13)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b24)
Atom on(b2, b25)
Atom on(b2, b26)
Atom on(b2, b27)
Atom on(b2, b3)
Atom on(b2, b4)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var32
-1
20
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b15)
Atom on(b11, b17)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b24)
Atom on(b11, b26)
Atom on(b11, b27)
Atom on(b11, b3)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b9)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var36
-1
22
Atom on(b26, b1)
Atom on(b26, b10)
Atom on(b26, b11)
Atom on(b26, b12)
Atom on(b26, b13)
Atom on(b26, b15)
Atom on(b26, b16)
Atom on(b26, b17)
Atom on(b26, b18)
Atom on(b26, b19)
Atom on(b26, b21)
Atom on(b26, b22)
Atom on(b26, b25)
Atom on(b26, b27)
Atom on(b26, b3)
Atom on(b26, b4)
Atom on(b26, b5)
Atom on(b26, b6)
Atom on(b26, b7)
Atom on(b26, b9)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var43
-1
22
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b18)
Atom on(b7, b19)
Atom on(b7, b21)
Atom on(b7, b22)
Atom on(b7, b24)
Atom on(b7, b26)
Atom on(b7, b27)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b9)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var44
-1
22
Atom on(b27, b1)
Atom on(b27, b10)
Atom on(b27, b11)
Atom on(b27, b12)
Atom on(b27, b13)
Atom on(b27, b15)
Atom on(b27, b16)
Atom on(b27, b17)
Atom on(b27, b18)
Atom on(b27, b19)
Atom on(b27, b2)
Atom on(b27, b21)
Atom on(b27, b22)
Atom on(b27, b24)
Atom on(b27, b26)
Atom on(b27, b3)
Atom on(b27, b4)
Atom on(b27, b6)
Atom on(b27, b7)
Atom on(b27, b9)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var45
-1
22
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b15)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b18)
Atom on(b4, b19)
Atom on(b4, b2)
Atom on(b4, b21)
Atom on(b4, b22)
Atom on(b4, b24)
Atom on(b4, b26)
Atom on(b4, b27)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b7)
Atom on(b4, b9)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var37
-1
24
Atom on(b24, b1)
Atom on(b24, b10)
Atom on(b24, b11)
Atom on(b24, b12)
Atom on(b24, b13)
Atom on(b24, b14)
Atom on(b24, b15)
Atom on(b24, b16)
Atom on(b24, b17)
Atom on(b24, b18)
Atom on(b24, b19)
Atom on(b24, b2)
Atom on(b24, b21)
Atom on(b24, b22)
Atom on(b24, b25)
Atom on(b24, b26)
Atom on(b24, b27)
Atom on(b24, b3)
Atom on(b24, b5)
Atom on(b24, b7)
Atom on(b24, b8)
Atom on(b24, b9)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var42
-1
24
Atom on(b3, b1)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b17)
Atom on(b3, b18)
Atom on(b3, b19)
Atom on(b3, b2)
Atom on(b3, b21)
Atom on(b3, b22)
Atom on(b3, b24)
Atom on(b3, b25)
Atom on(b3, b26)
Atom on(b3, b27)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b6)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var46
-1
25
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b15)
Atom on(b6, b16)
Atom on(b6, b17)
Atom on(b6, b18)
Atom on(b6, b19)
Atom on(b6, b21)
Atom on(b6, b22)
Atom on(b6, b24)
Atom on(b6, b25)
Atom on(b6, b26)
Atom on(b6, b27)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var47
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var48
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var49
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var50
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var51
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var52
-1
2
Atom on-table(b21)
NegatedAtom on-table(b21)
end_variable
begin_variable
var53
-1
2
Atom clear(b20)
<none of those>
end_variable
3873
begin_mutex_group
16
20 1
7 0
35 0
30 0
36 0
37 0
34 0
33 0
38 0
44 0
40 0
42 0
45 0
43 0
46 0
41 0
end_mutex_group
begin_mutex_group
14
20 2
13 0
39 0
36 1
37 1
34 1
32 0
44 1
40 1
42 1
45 1
43 1
46 1
41 1
end_mutex_group
begin_mutex_group
16
20 3
49 0
35 1
36 2
37 2
34 2
33 1
32 1
38 1
44 2
40 2
42 2
45 2
43 2
46 2
41 2
end_mutex_group
begin_mutex_group
11
20 4
3 0
26 0
39 1
44 3
40 3
42 3
45 3
43 3
46 3
41 3
end_mutex_group
begin_mutex_group
17
20 5
48 0
35 2
39 2
36 3
37 3
34 3
33 2
32 2
38 2
44 4
40 4
42 4
45 4
43 4
46 4
41 4
end_mutex_group
begin_mutex_group
8
20 6
9 0
37 4
34 4
33 3
44 5
46 5
41 5
end_mutex_group
begin_mutex_group
13
20 7
12 0
35 3
39 3
34 5
38 3
44 6
40 5
42 5
45 5
43 5
46 6
41 6
end_mutex_group
begin_mutex_group
15
20 8
14 0
35 4
36 4
37 5
33 4
38 4
44 7
40 6
42 6
45 6
43 6
46 7
41 7
25 0
end_mutex_group
begin_mutex_group
10
20 9
1 0
39 4
38 5
44 8
40 7
42 7
45 7
43 7
46 8
end_mutex_group
begin_mutex_group
14
20 10
10 0
35 5
36 5
37 6
22 0
38 6
44 9
40 8
42 8
45 8
43 8
46 9
41 8
end_mutex_group
begin_mutex_group
14
20 11
8 0
35 6
39 5
37 7
33 5
44 10
40 9
42 9
45 9
43 9
46 10
41 9
28 0
end_mutex_group
begin_mutex_group
13
20 12
11 0
35 7
39 6
36 6
37 8
34 6
33 6
44 11
42 10
45 10
43 10
24 0
end_mutex_group
begin_mutex_group
2
53 0
34 7
end_mutex_group
begin_mutex_group
10
20 13
2 0
39 7
44 12
40 10
42 11
45 11
43 11
46 11
41 10
end_mutex_group
begin_mutex_group
11
20 14
5 0
39 8
29 0
44 13
40 11
42 12
45 12
43 12
46 12
41 11
end_mutex_group
begin_mutex_group
3
20 15
31 0
31 1
end_mutex_group
begin_mutex_group
15
20 16
18 0
26 1
35 8
39 9
36 7
34 8
33 7
38 7
27 0
42 13
45 13
43 13
46 13
41 12
end_mutex_group
begin_mutex_group
11
20 17
4 0
36 8
37 9
34 9
33 8
38 8
44 14
40 12
45 14
46 14
end_mutex_group
begin_mutex_group
16
20 18
17 0
35 9
39 10
36 9
37 10
34 10
33 9
32 3
38 9
44 15
42 14
45 15
43 14
46 15
41 13
end_mutex_group
begin_mutex_group
17
20 19
50 0
35 10
39 11
30 1
36 10
37 11
34 11
33 10
32 4
38 10
44 16
40 13
45 16
43 15
46 16
41 14
end_mutex_group
begin_mutex_group
15
20 20
19 0
35 11
39 12
36 11
37 12
34 12
33 11
38 11
44 17
40 14
42 15
43 16
46 17
41 15
end_mutex_group
begin_mutex_group
16
20 21
51 0
35 12
39 13
21 0
36 12
37 13
34 13
33 12
32 5
38 12
40 15
42 16
45 17
46 18
41 16
end_mutex_group
begin_mutex_group
9
20 22
0 0
39 14
44 18
40 16
45 18
43 17
46 19
41 17
end_mutex_group
begin_mutex_group
13
20 23
16 0
35 13
39 15
36 13
37 14
34 14
33 13
38 13
40 17
42 17
45 19
41 18
end_mutex_group
begin_mutex_group
14
20 24
15 0
35 14
39 16
36 14
37 15
34 15
33 14
38 14
44 19
40 18
42 18
43 18
46 20
end_mutex_group
begin_mutex_group
11
20 25
6 0
35 15
36 15
37 16
32 6
38 15
23 0
44 20
45 20
46 21
end_mutex_group
begin_mutex_group
17
20 26
47 0
35 16
39 17
36 16
37 17
34 16
33 15
32 7
38 16
44 21
40 19
42 19
45 21
43 19
46 22
41 19
end_mutex_group
begin_mutex_group
4
20 1
26 0
26 1
26 2
end_mutex_group
begin_mutex_group
19
20 2
35 0
35 1
35 2
35 3
35 4
35 5
35 6
35 7
35 8
35 9
35 10
35 11
35 12
35 13
35 14
35 15
35 16
35 17
end_mutex_group
begin_mutex_group
20
20 3
39 0
39 1
39 2
39 3
39 4
39 5
39 6
39 7
39 8
39 9
39 10
39 11
39 12
39 13
39 14
39 15
39 16
39 17
39 18
end_mutex_group
begin_mutex_group
3
20 4
21 0
21 1
end_mutex_group
begin_mutex_group
4
20 5
30 0
30 1
30 2
end_mutex_group
begin_mutex_group
19
20 6
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
36 15
36 16
36 17
end_mutex_group
begin_mutex_group
20
20 7
37 0
37 1
37 2
37 3
37 4
37 5
37 6
37 7
37 8
37 9
37 10
37 11
37 12
37 13
37 14
37 15
37 16
37 17
37 18
end_mutex_group
begin_mutex_group
19
20 8
34 0
34 1
34 2
34 3
34 4
34 5
34 6
34 7
34 8
34 9
34 10
34 11
34 12
34 13
34 14
34 15
34 16
34 17
end_mutex_group
begin_mutex_group
3
20 9
22 0
22 1
end_mutex_group
begin_mutex_group
18
20 10
33 0
33 1
33 2
33 3
33 4
33 5
33 6
33 7
33 8
33 9
33 10
33 11
33 12
33 13
33 14
33 15
33 16
end_mutex_group
begin_mutex_group
10
20 11
32 0
32 1
32 2
32 3
32 4
32 5
32 6
32 7
32 8
end_mutex_group
begin_mutex_group
19
20 12
38 0
38 1
38 2
38 3
38 4
38 5
38 6
38 7
38 8
38 9
38 10
38 11
38 12
38 13
38 14
38 15
38 16
38 17
end_mutex_group
begin_mutex_group
3
20 13
31 1
52 0
end_mutex_group
begin_mutex_group
3
20 14
23 0
23 1
end_mutex_group
begin_mutex_group
3
20 15
29 0
29 1
end_mutex_group
begin_mutex_group
24
20 16
44 0
44 1
44 2
44 3
44 4
44 5
44 6
44 7
44 8
44 9
44 10
44 11
44 12
44 13
44 14
44 15
44 16
44 17
44 18
44 19
44 20
44 21
44 22
end_mutex_group
begin_mutex_group
3
20 17
27 0
27 1
end_mutex_group
begin_mutex_group
22
20 18
40 0
40 1
40 2
40 3
40 4
40 5
40 6
40 7
40 8
40 9
40 10
40 11
40 12
40 13
40 14
40 15
40 16
40 17
40 18
40 19
40 20
end_mutex_group
begin_mutex_group
22
20 19
42 0
42 1
42 2
42 3
42 4
42 5
42 6
42 7
42 8
42 9
42 10
42 11
42 12
42 13
42 14
42 15
42 16
42 17
42 18
42 19
42 20
end_mutex_group
begin_mutex_group
24
20 20
45 0
45 1
45 2
45 3
45 4
45 5
45 6
45 7
45 8
45 9
45 10
45 11
45 12
45 13
45 14
45 15
45 16
45 17
45 18
45 19
45 20
45 21
45 22
end_mutex_group
begin_mutex_group
22
20 21
43 0
43 1
43 2
43 3
43 4
43 5
43 6
43 7
43 8
43 9
43 10
43 11
43 12
43 13
43 14
43 15
43 16
43 17
43 18
43 19
43 20
end_mutex_group
begin_mutex_group
3
20 22
24 0
24 1
end_mutex_group
begin_mutex_group
25
20 23
46 0
46 1
46 2
46 3
46 4
46 5
46 6
46 7
46 8
46 9
46 10
46 11
46 12
46 13
46 14
46 15
46 16
46 17
46 18
46 19
46 20
46 21
46 22
46 23
end_mutex_group
begin_mutex_group
22
20 24
41 0
41 1
41 2
41 3
41 4
41 5
41 6
41 7
41 8
41 9
41 10
41 11
41 12
41 13
41 14
41 15
41 16
41 17
41 18
41 19
41 20
end_mutex_group
begin_mutex_group
3
20 25
28 0
28 1
end_mutex_group
begin_mutex_group
3
20 26
25 0
25 1
end_mutex_group
begin_mutex_group
2
0 0
24 2
end_mutex_group
begin_mutex_group
2
0 0
30 1
end_mutex_group
begin_mutex_group
2
1 0
20 22
end_mutex_group
begin_mutex_group
2
1 0
22 2
end_mutex_group
begin_mutex_group
2
1 0
24 0
end_mutex_group
begin_mutex_group
2
1 0
24 2
end_mutex_group
begin_mutex_group
2
1 0
30 1
end_mutex_group
begin_mutex_group
2
2 0
20 4
end_mutex_group
begin_mutex_group
2
2 0
21 0
end_mutex_group
begin_mutex_group
2
2 0
21 2
end_mutex_group
begin_mutex_group
2
2 0
26 1
end_mutex_group
begin_mutex_group
2
3 0
21 2
end_mutex_group
begin_mutex_group
2
3 0
26 1
end_mutex_group
begin_mutex_group
2
4 0
20 9
end_mutex_group
begin_mutex_group
2
4 0
20 22
end_mutex_group
begin_mutex_group
2
4 0
22 0
end_mutex_group
begin_mutex_group
2
4 0
22 2
end_mutex_group
begin_mutex_group
2
4 0
24 0
end_mutex_group
begin_mutex_group
2
4 0
24 2
end_mutex_group
begin_mutex_group
2
4 0
27 2
end_mutex_group
begin_mutex_group
2
4 0
30 1
end_mutex_group
begin_mutex_group
2
4 0
37 4
end_mutex_group
begin_mutex_group
2
5 0
23 2
end_mutex_group
begin_mutex_group
2
6 0
28 2
end_mutex_group
begin_mutex_group
2
6 1
20 14
end_mutex_group
begin_mutex_group
2
6 1
23 2
end_mutex_group
begin_mutex_group
2
7 0
26 3
end_mutex_group
begin_mutex_group
2
9 0
20 9
end_mutex_group
begin_mutex_group
2
9 0
20 22
end_mutex_group
begin_mutex_group
2
9 0
22 0
end_mutex_group
begin_mutex_group
2
9 0
22 2
end_mutex_group
begin_mutex_group
2
9 0
24 0
end_mutex_group
begin_mutex_group
2
9 0
24 2
end_mutex_group
begin_mutex_group
2
9 0
30 1
end_mutex_group
begin_mutex_group
2
9 0
36 18
end_mutex_group
begin_mutex_group
2
8 0
32 9
end_mutex_group
begin_mutex_group
2
10 0
20 22
end_mutex_group
begin_mutex_group
2
10 0
24 0
end_mutex_group
begin_mutex_group
2
10 0
24 2
end_mutex_group
begin_mutex_group
2
10 0
30 1
end_mutex_group
begin_mutex_group
2
10 0
33 17
end_mutex_group
begin_mutex_group
2
10 1
20 9
end_mutex_group
begin_mutex_group
2
10 1
22 2
end_mutex_group
begin_mutex_group
2
11 0
30 1
end_mutex_group
begin_mutex_group
2
11 0
38 18
end_mutex_group
begin_mutex_group
2
11 1
20 22
end_mutex_group
begin_mutex_group
2
11 1
24 2
end_mutex_group
begin_mutex_group
2
12 0
20 9
end_mutex_group
begin_mutex_group
2
12 0
20 22
end_mutex_group
begin_mutex_group
2
12 0
22 0
end_mutex_group
begin_mutex_group
2
12 0
22 2
end_mutex_group
begin_mutex_group
2
12 0
24 0
end_mutex_group
begin_mutex_group
2
12 0
24 2
end_mutex_group
begin_mutex_group
2
12 0
30 1
end_mutex_group
begin_mutex_group
2
12 0
37 19
end_mutex_group
begin_mutex_group
2
13 0
20 4
end_mutex_group
begin_mutex_group
2
13 0
21 0
end_mutex_group
begin_mutex_group
2
13 0
21 2
end_mutex_group
begin_mutex_group
2
13 0
26 1
end_mutex_group
begin_mutex_group
2
13 0
35 18
end_mutex_group
begin_mutex_group
2
14 0
34 18
end_mutex_group
begin_mutex_group
2
14 1
20 26
end_mutex_group
begin_mutex_group
2
14 1
25 2
end_mutex_group
begin_mutex_group
2
15 0
30 1
end_mutex_group
begin_mutex_group
2
15 0
41 21
end_mutex_group
begin_mutex_group
2
18 0
44 23
end_mutex_group
begin_mutex_group
2
16 0
20 4
end_mutex_group
begin_mutex_group
2
16 0
21 0
end_mutex_group
begin_mutex_group
2
16 0
21 2
end_mutex_group
begin_mutex_group
2
16 0
26 1
end_mutex_group
begin_mutex_group
2
16 0
46 24
end_mutex_group
begin_mutex_group
2
17 0
40 21
end_mutex_group
begin_mutex_group
2
19 0
20 9
end_mutex_group
begin_mutex_group
2
19 0
20 22
end_mutex_group
begin_mutex_group
2
19 0
22 0
end_mutex_group
begin_mutex_group
2
19 0
22 2
end_mutex_group
begin_mutex_group
2
19 0
24 0
end_mutex_group
begin_mutex_group
2
19 0
24 2
end_mutex_group
begin_mutex_group
2
19 0
30 1
end_mutex_group
begin_mutex_group
2
19 0
45 23
end_mutex_group
begin_mutex_group
2
20 0
21 2
end_mutex_group
begin_mutex_group
2
20 0
22 2
end_mutex_group
begin_mutex_group
2
20 0
23 2
end_mutex_group
begin_mutex_group
2
20 0
24 2
end_mutex_group
begin_mutex_group
2
20 0
25 2
end_mutex_group
begin_mutex_group
2
20 0
26 3
end_mutex_group
begin_mutex_group
2
20 0
27 2
end_mutex_group
begin_mutex_group
2
20 0
28 2
end_mutex_group
begin_mutex_group
2
20 0
29 2
end_mutex_group
begin_mutex_group
2
20 0
31 2
end_mutex_group
begin_mutex_group
2
20 0
30 3
end_mutex_group
begin_mutex_group
2
20 0
39 19
end_mutex_group
begin_mutex_group
2
20 0
35 18
end_mutex_group
begin_mutex_group
2
20 0
33 17
end_mutex_group
begin_mutex_group
2
20 0
32 9
end_mutex_group
begin_mutex_group
2
20 0
40 21
end_mutex_group
begin_mutex_group
2
20 0
44 23
end_mutex_group
begin_mutex_group
2
20 0
36 18
end_mutex_group
begin_mutex_group
2
20 0
37 19
end_mutex_group
begin_mutex_group
2
20 0
34 18
end_mutex_group
begin_mutex_group
2
20 0
38 18
end_mutex_group
begin_mutex_group
2
20 0
45 23
end_mutex_group
begin_mutex_group
2
20 0
41 21
end_mutex_group
begin_mutex_group
2
20 0
42 21
end_mutex_group
begin_mutex_group
2
20 0
43 21
end_mutex_group
begin_mutex_group
2
20 0
46 24
end_mutex_group
begin_mutex_group
2
20 1
21 2
end_mutex_group
begin_mutex_group
2
20 1
22 2
end_mutex_group
begin_mutex_group
2
20 1
23 2
end_mutex_group
begin_mutex_group
2
20 1
24 2
end_mutex_group
begin_mutex_group
2
20 1
25 2
end_mutex_group
begin_mutex_group
2
20 1
27 2
end_mutex_group
begin_mutex_group
2
20 1
28 2
end_mutex_group
begin_mutex_group
2
20 1
29 2
end_mutex_group
begin_mutex_group
2
20 1
31 2
end_mutex_group
begin_mutex_group
2
20 1
30 3
end_mutex_group
begin_mutex_group
2
20 1
39 19
end_mutex_group
begin_mutex_group
2
20 1
35 18
end_mutex_group
begin_mutex_group
2
20 1
33 17
end_mutex_group
begin_mutex_group
2
20 1
32 9
end_mutex_group
begin_mutex_group
2
20 1
40 21
end_mutex_group
begin_mutex_group
2
20 1
44 23
end_mutex_group
begin_mutex_group
2
20 1
36 18
end_mutex_group
begin_mutex_group
2
20 1
37 19
end_mutex_group
begin_mutex_group
2
20 1
34 18
end_mutex_group
begin_mutex_group
2
20 1
38 18
end_mutex_group
begin_mutex_group
2
20 1
45 23
end_mutex_group
begin_mutex_group
2
20 1
41 21
end_mutex_group
begin_mutex_group
2
20 1
42 21
end_mutex_group
begin_mutex_group
2
20 1
43 21
end_mutex_group
begin_mutex_group
2
20 1
46 24
end_mutex_group
begin_mutex_group
2
20 2
21 0
end_mutex_group
begin_mutex_group
2
20 2
21 2
end_mutex_group
begin_mutex_group
2
20 2
22 2
end_mutex_group
begin_mutex_group
2
20 2
23 2
end_mutex_group
begin_mutex_group
2
20 2
24 2
end_mutex_group
begin_mutex_group
2
20 2
25 2
end_mutex_group
begin_mutex_group
2
20 2
26 1
end_mutex_group
begin_mutex_group
2
20 2
26 3
end_mutex_group
begin_mutex_group
2
20 2
27 2
end_mutex_group
begin_mutex_group
2
20 2
28 2
end_mutex_group
begin_mutex_group
2
20 2
29 2
end_mutex_group
begin_mutex_group
2
20 2
31 2
end_mutex_group
begin_mutex_group
2
20 2
30 3
end_mutex_group
begin_mutex_group
2
20 2
39 19
end_mutex_group
begin_mutex_group
2
20 2
33 17
end_mutex_group
begin_mutex_group
2
20 2
32 9
end_mutex_group
begin_mutex_group
2
20 2
40 21
end_mutex_group
begin_mutex_group
2
20 2
44 23
end_mutex_group
begin_mutex_group
2
20 2
36 18
end_mutex_group
begin_mutex_group
2
20 2
37 19
end_mutex_group
begin_mutex_group
2
20 2
34 18
end_mutex_group
begin_mutex_group
2
20 2
38 18
end_mutex_group
begin_mutex_group
2
20 2
45 23
end_mutex_group
begin_mutex_group
2
20 2
41 21
end_mutex_group
begin_mutex_group
2
20 2
42 21
end_mutex_group
begin_mutex_group
2
20 2
43 21
end_mutex_group
begin_mutex_group
2
20 2
46 24
end_mutex_group
begin_mutex_group
2
20 3
21 2
end_mutex_group
begin_mutex_group
2
20 3
22 2
end_mutex_group
begin_mutex_group
2
20 3
23 2
end_mutex_group
begin_mutex_group
2
20 3
24 2
end_mutex_group
begin_mutex_group
2
20 3
25 2
end_mutex_group
begin_mutex_group
2
20 3
26 3
end_mutex_group
begin_mutex_group
2
20 3
27 2
end_mutex_group
begin_mutex_group
2
20 3
28 2
end_mutex_group
begin_mutex_group
2
20 3
29 2
end_mutex_group
begin_mutex_group
2
20 3
31 2
end_mutex_group
begin_mutex_group
2
20 3
30 3
end_mutex_group
begin_mutex_group
2
20 3
35 18
end_mutex_group
begin_mutex_group
2
20 3
33 17
end_mutex_group
begin_mutex_group
2
20 3
32 9
end_mutex_group
begin_mutex_group
2
20 3
40 21
end_mutex_group
begin_mutex_group
2
20 3
44 23
end_mutex_group
begin_mutex_group
2
20 3
36 18
end_mutex_group
begin_mutex_group
2
20 3
37 19
end_mutex_group
begin_mutex_group
2
20 3
34 18
end_mutex_group
begin_mutex_group
2
20 3
38 18
end_mutex_group
begin_mutex_group
2
20 3
45 23
end_mutex_group
begin_mutex_group
2
20 3
41 21
end_mutex_group
begin_mutex_group
2
20 3
42 21
end_mutex_group
begin_mutex_group
2
20 3
43 21
end_mutex_group
begin_mutex_group
2
20 3
46 24
end_mutex_group
begin_mutex_group
2
20 4
22 2
end_mutex_group
begin_mutex_group
2
20 4
23 2
end_mutex_group
begin_mutex_group
2
20 4
24 2
end_mutex_group
begin_mutex_group
2
20 4
25 2
end_mutex_group
begin_mutex_group
2
20 4
26 1
end_mutex_group
begin_mutex_group
2
20 4
26 3
end_mutex_group
begin_mutex_group
2
20 4
27 2
end_mutex_group
begin_mutex_group
2
20 4
28 2
end_mutex_group
begin_mutex_group
2
20 4
29 0
end_mutex_group
begin_mutex_group
2
20 4
29 2
end_mutex_group
begin_mutex_group
2
20 4
31 0
end_mutex_group
begin_mutex_group
2
20 4
31 2
end_mutex_group
begin_mutex_group
2
20 4
30 3
end_mutex_group
begin_mutex_group
2
20 4
39 0
end_mutex_group
begin_mutex_group
2
20 4
39 7
end_mutex_group
begin_mutex_group
2
20 4
39 13
end_mutex_group
begin_mutex_group
2
20 4
39 15
end_mutex_group
begin_mutex_group
2
20 4
39 19
end_mutex_group
begin_mutex_group
2
20 4
35 0
end_mutex_group
begin_mutex_group
2
20 4
35 1
end_mutex_group
begin_mutex_group
2
20 4
35 2
end_mutex_group
begin_mutex_group
2
20 4
35 3
end_mutex_group
begin_mutex_group
2
20 4
35 4
end_mutex_group
begin_mutex_group
2
20 4
35 5
end_mutex_group
begin_mutex_group
2
20 4
35 6
end_mutex_group
begin_mutex_group
2
20 4
35 7
end_mutex_group
begin_mutex_group
2
20 4
35 8
end_mutex_group
begin_mutex_group
2
20 4
35 9
end_mutex_group
begin_mutex_group
2
20 4
35 10
end_mutex_group
begin_mutex_group
2
20 4
35 11
end_mutex_group
begin_mutex_group
2
20 4
35 12
end_mutex_group
begin_mutex_group
2
20 4
35 14
end_mutex_group
begin_mutex_group
2
20 4
35 15
end_mutex_group
begin_mutex_group
2
20 4
35 16
end_mutex_group
begin_mutex_group
2
20 4
35 17
end_mutex_group
begin_mutex_group
2
20 4
35 18
end_mutex_group
begin_mutex_group
2
20 4
33 12
end_mutex_group
begin_mutex_group
2
20 4
33 13
end_mutex_group
begin_mutex_group
2
20 4
33 17
end_mutex_group
begin_mutex_group
2
20 4
32 0
end_mutex_group
begin_mutex_group
2
20 4
32 5
end_mutex_group
begin_mutex_group
2
20 4
32 9
end_mutex_group
be




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0
0 17 0 1
0 15 -1 0
0 41 -1 13
1
end_operator
begin_operator
stack b7 b27
0
4
0 20 24 0
0 50 0 1
0 15 -1 0
0 41 -1 14
1
end_operator
begin_operator
stack b7 b3
0
4
0 20 24 0
0 19 0 1
0 15 -1 0
0 41 -1 15
1
end_operator
begin_operator
stack b7 b4
0
4
0 20 24 0
0 51 0 1
0 15 -1 0
0 41 -1 16
1
end_operator
begin_operator
stack b7 b5
0
4
0 20 24 0
0 0 0 1
0 15 -1 0
0 41 -1 17
1
end_operator
begin_operator
stack b7 b6
0
4
0 20 24 0
0 16 0 1
0 15 -1 0
0 41 -1 18
1
end_operator
begin_operator
stack b7 b9
0
4
0 20 24 0
0 15 -1 0
0 47 0 1
0 41 -1 19
1
end_operator
begin_operator
stack b8 b19
0
4
0 20 25 0
0 8 0 1
0 6 -1 0
0 28 -1 0
1
end_operator
begin_operator
unstack b1 b24
0
4
0 20 0 1
0 7 0 1
0 18 -1 0
0 26 1 3
1
end_operator
begin_operator
unstack b10 b1
0
4
0 20 0 2
0 7 -1 0
0 13 0 1
0 35 0 18
1
end_operator
begin_operator
unstack b10 b11
0
4
0 20 0 2
0 13 0 1
0 49 -1 0
0 35 1 18
1
end_operator
begin_operator
unstack b10 b13
0
4
0 20 0 2
0 13 0 1
0 48 -1 0
0 35 2 18
1
end_operator
begin_operator
unstack b10 b15
0
4
0 20 0 2
0 13 0 1
0 12 -1 0
0 35 3 18
1
end_operator
begin_operator
unstack b10 b16
0
4
0 20 0 2
0 13 0 1
0 14 -1 0
0 35 4 18
1
end_operator
begin_operator
unstack b10 b18
0
4
0 20 0 2
0 13 0 1
0 10 -1 0
0 35 5 18
1
end_operator
begin_operator
unstack b10 b19
0
4
0 20 0 2
0 13 0 1
0 8 -1 0
0 35 6 18
1
end_operator
begin_operator
unstack b10 b2
0
4
0 20 0 2
0 13 0 1
0 11 -1 0
0 35 7 18
1
end_operator
begin_operator
unstack b10 b24
0
4
0 20 0 2
0 13 0 1
0 18 -1 0
0 35 8 18
1
end_operator
begin_operator
unstack b10 b26
0
4
0 20 0 2
0 13 0 1
0 17 -1 0
0 35 9 18
1
end_operator
begin_operator
unstack b10 b27
0
4
0 20 0 2
0 13 0 1
0 50 -1 0
0 35 10 18
1
end_operator
begin_operator
unstack b10 b3
0
4
0 20 0 2
0 13 0 1
0 19 -1 0
0 35 11 18
1
end_operator
begin_operator
unstack b10 b4
0
4
0 20 0 2
0 13 0 1
0 51 -1 0
0 35 12 18
1
end_operator
begin_operator
unstack b10 b6
0
4
0 20 0 2
0 13 0 1
0 16 -1 0
0 35 13 18
1
end_operator
begin_operator
unstack b10 b7
0
4
0 20 0 2
0 13 0 1
0 15 -1 0
0 35 14 18
1
end_operator
begin_operator
unstack b10 b8
0
4
0 20 0 2
0 13 0 1
0 6 -1 0
0 35 15 18
1
end_operator
begin_operator
unstack b10 b9
0
4
0 20 0 2
0 13 0 1
0 47 -1 0
0 35 16 18
1
end_operator
begin_operator
unstack b11 b10
0
4
0 20 0 3
0 13 -1 0
0 49 0 1
0 39 0 19
1
end_operator
begin_operator
unstack b11 b12
0
4
0 20 0 3
0 49 0 1
0 3 -1 0
0 39 1 19
1
end_operator
begin_operator
unstack b11 b13
0
4
0 20 0 3
0 49 0 1
0 48 -1 0
0 39 2 19
1
end_operator
begin_operator
unstack b11 b15
0
4
0 20 0 3
0 49 0 1
0 12 -1 0
0 39 3 19
1
end_operator
begin_operator
unstack b11 b17
0
4
0 20 0 3
0 49 0 1
0 1 -1 0
0 39 4 19
1
end_operator
begin_operator
unstack b11 b19
0
4
0 20 0 3
0 49 0 1
0 8 -1 0
0 39 5 19
1
end_operator
begin_operator
unstack b11 b2
0
4
0 20 0 3
0 49 0 1
0 11 -1 0
0 39 6 19
1
end_operator
begin_operator
unstack b11 b21
0
4
0 20 0 3
0 49 0 1
0 2 -1 0
0 39 7 19
1
end_operator
begin_operator
unstack b11 b22
0
4
0 20 0 3
0 49 0 1
0 5 -1 0
0 39 8 19
1
end_operator
begin_operator
unstack b11 b24
0
4
0 20 0 3
0 49 0 1
0 18 -1 0
0 39 9 19
1
end_operator
begin_operator
unstack b11 b26
0
4
0 20 0 3
0 49 0 1
0 17 -1 0
0 39 10 19
1
end_operator
begin_operator
unstack b11 b27
0
4
0 20 0 3
0 49 0 1
0 50 -1 0
0 39 11 19
1
end_operator
begin_operator
unstack b11 b3
0
4
0 20 0 3
0 49 0 1
0 19 -1 0
0 39 12 19
1
end_operator
begin_operator
unstack b11 b4
0
4
0 20 0 3
0 49 0 1
0 51 -1 0
0 39 13 19
1
end_operator
begin_operator
unstack b11 b5
0
4
0 20 0 3
0 49 0 1
0 0 -1 0
0 39 14 19
1
end_operator
begin_operator
unstack b11 b6
0
4
0 20 0 3
0 49 0 1
0 16 -1 0
0 39 15 19
1
end_operator
begin_operator
unstack b11 b7
0
4
0 20 0 3
0 49 0 1
0 15 -1 0
0 39 16 19
1
end_operator
begin_operator
unstack b11 b9
0
4
0 20 0 3
0 49 0 1
0 47 -1 0
0 39 17 19
1
end_operator
begin_operator
unstack b12 b4
0
4
0 20 0 4
0 3 0 1
0 51 -1 0
0 21 0 2
1
end_operator
begin_operator
unstack b13 b1
0
4
0 20 0 5
0 7 -1 0
0 48 0 1
0 30 0 3
1
end_operator
begin_operator
unstack b13 b27
0
4
0 20 0 5
0 48 0 1
0 50 -1 0
0 30 1 3
1
end_operator
begin_operator
unstack b14 b1
0
4
0 20 0 6
0 7 -1 0
0 9 0 1
0 36 0 18
1
end_operator
begin_operator
unstack b14 b10
0
4
0 20 0 6
0 13 -1 0
0 9 0 1
0 36 1 18
1
end_operator
begin_operator
unstack b14 b11
0
4
0 20 0 6
0 49 -1 0
0 9 0 1
0 36 2 18
1
end_operator
begin_operator
unstack b14 b13
0
4
0 20 0 6
0 48 -1 0
0 9 0 1
0 36 3 18
1
end_operator
begin_operator
unstack b14 b16
0
4
0 20 0 6
0 9 0 1
0 14 -1 0
0 36 4 18
1
end_operator
begin_operator
unstack b14 b18
0
4
0 20 0 6
0 9 0 1
0 10 -1 0
0 36 5 18
1
end_operator
begin_operator
unstack b14 b2
0
4
0 20 0 6
0 9 0 1
0 11 -1 0
0 36 6 18
1
end_operator
begin_operator
unstack b14 b24
0
4
0 20 0 6
0 9 0 1
0 18 -1 0
0 36 7 18
1
end_operator
begin_operator
unstack b14 b25
0
4
0 20 0 6
0 9 0 1
0 4 -1 0
0 36 8 18
1
end_operator
begin_operator
unstack b14 b26
0
4
0 20 0 6
0 9 0 1
0 17 -1 0
0 36 9 18
1
end_operator
begin_operator
unstack b14 b27
0
4
0 20 0 6
0 9 0 1
0 50 -1 0
0 36 10 18
1
end_operator
begin_operator
unstack b14 b3
0
4
0 20 0 6
0 9 0 1
0 19 -1 0
0 36 11 18
1
end_operator
begin_operator
unstack b14 b4
0
4
0 20 0 6
0 9 0 1
0 51 -1 0
0 36 12 18
1
end_operator
begin_operator
unstack b14 b6
0
4
0 20 0 6
0 9 0 1
0 16 -1 0
0 36 13 18
1
end_operator
begin_operator
unstack b14 b7
0
4
0 20 0 6
0 9 0 1
0 15 -1 0
0 36 14 18
1
end_operator
begin_operator
unstack b14 b8
0
4
0 20 0 6
0 9 0 1
0 6 -1 0
0 36 15 18
1
end_operator
begin_operator
unstack b14 b9
0
4
0 20 0 6
0 9 0 1
0 47 -1 0
0 36 16 18
1
end_operator
begin_operator
unstack b15 b1
0
4
0 20 0 7
0 7 -1 0
0 12 0 1
0 37 0 19
1
end_operator
begin_operator
unstack b15 b10
0
4
0 20 0 7
0 13 -1 0
0 12 0 1
0 37 1 19
1
end_operator
begin_operator
unstack b15 b11
0
4
0 20 0 7
0 49 -1 0
0 12 0 1
0 37 2 19
1
end_operator
begin_operator
unstack b15 b13
0
4
0 20 0 7
0 48 -1 0
0 12 0 1
0 37 3 19
1
end_operator
begin_operator
unstack b15 b14
0
4
0 20 0 7
0 9 -1 0
0 12 0 1
0 37 4 19
1
end_operator
begin_operator
unstack b15 b16
0
4
0 20 0 7
0 12 0 1
0 14 -1 0
0 37 5 19
1
end_operator
begin_operator
unstack b15 b18
0
4
0 20 0 7
0 12 0 1
0 10 -1 0
0 37 6 19
1
end_operator
begin_operator
unstack b15 b19
0
4
0 20 0 7
0 12 0 1
0 8 -1 0
0 37 7 19
1
end_operator
begin_operator
unstack b15 b2
0
4
0 20 0 7
0 12 0 1
0 11 -1 0
0 37 8 19
1
end_operator
begin_operator
unstack b15 b26
0
4
0 20 0 7
0 12 0 1
0 17 -1 0
0 37 10 19
1
end_operator
begin_operator
unstack b15 b27
0
4
0 20 0 7
0 12 0 1
0 50 -1 0
0 37 11 19
1
end_operator
begin_operator
unstack b15 b3
0
4
0 20 0 7
0 12 0 1
0 19 -1 0
0 37 12 19
1
end_operator
begin_operator
unstack b15 b4
0
4
0 20 0 7
0 12 0 1
0 51 -1 0
0 37 13 19
1
end_operator
begin_operator
unstack b15 b6
0
4
0 20 0 7
0 12 0 1
0 16 -1 0
0 37 14 19
1
end_operator
begin_operator
unstack b15 b7
0
4
0 20 0 7
0 12 0 1
0 15 -1 0
0 37 15 19
1
end_operator
begin_operator
unstack b15 b8
0
4
0 20 0 7
0 12 0 1
0 6 -1 0
0 37 16 19
1
end_operator
begin_operator
unstack b15 b9
0
4
0 20 0 7
0 12 0 1
0 47 -1 0
0 37 17 19
1
end_operator
begin_operator
unstack b16 b1
0
4
0 20 0 8
0 7 -1 0
0 14 0 1
0 34 0 18
1
end_operator
begin_operator
unstack b16 b10
0
4
0 20 0 8
0 13 -1 0
0 14 0 1
0 34 1 18
1
end_operator
begin_operator
unstack b16 b11
0
4
0 20 0 8
0 49 -1 0
0 14 0 1
0 34 2 18
1
end_operator
begin_operator
unstack b16 b13
0
4
0 20 0 8
0 48 -1 0
0 14 0 1
0 34 3 18
1
end_operator
begin_operator
unstack b16 b14
0
4
0 20 0 8
0 9 -1 0
0 14 0 1
0 34 4 18
1
end_operator
begin_operator
unstack b16 b15
0
4
0 20 0 8
0 12 -1 0
0 14 0 1
0 34 5 18
1
end_operator
begin_operator
unstack b16 b2
0
4
0 20 0 8
0 14 0 1
0 11 -1 0
0 34 6 18
1
end_operator
begin_operator
unstack b16 b20
0
4
0 20 0 8
0 14 0 1
0 53 -1 0
0 34 7 18
1
end_operator
begin_operator
unstack b16 b24
0
4
0 20 0 8
0 14 0 1
0 18 -1 0
0 34 8 18
1
end_operator
begin_operator
unstack b16 b25
0
4
0 20 0 8
0 14 0 1
0 4 -1 0
0 34 9 18
1
end_operator
begin_operator
unstack b16 b26
0
4
0 20 0 8
0 14 0 1
0 17 -1 0
0 34 10 18
1
end_operator
begin_operator
unstack b16 b27
0
4
0 20 0 8
0 14 0 1
0 50 -1 0
0 34 11 18
1
end_operator
begin_operator
unstack b16 b3
0
4
0 20 0 8
0 14 0 1
0 19 -1 0
0 34 12 18
1
end_operator
begin_operator
unstack b16 b4
0
4
0 20 0 8
0 14 0 1
0 51 -1 0
0 34 13 18
1
end_operator
begin_operator
unstack b16 b6
0
4
0 20 0 8
0 14 0 1
0 16 -1 0
0 34 14 18
1
end_operator
begin_operator
unstack b16 b7
0
4
0 20 0 8
0 14 0 1
0 15 -1 0
0 34 15 18
1
end_operator
begin_operator
unstack b16 b9
0
4
0 20 0 8
0 14 0 1
0 47 -1 0
0 34 16 18
1
end_operator
begin_operator
unstack b17 b18
0
4
0 20 0 9
0 1 0 1
0 10 -1 0
0 22 0 2
1
end_operator
begin_operator
unstack b18 b1
0
4
0 20 0 10
0 7 -1 0
0 10 0 1
0 33 0 17
1
end_operator
begin_operator
unstack b18 b11
0
4
0 20 0 10
0 49 -1 0
0 10 0 1
0 33 1 17
1
end_operator
begin_operator
unstack b18 b13
0
4
0 20 0 10
0 48 -1 0
0 10 0 1
0 33 2 17
1
end_operator
begin_operator
unstack b18 b14
0
4
0 20 0 10
0 9 -1 0
0 10 0 1
0 33 3 17
1
end_operator
begin_operator
unstack b18 b16
0
4
0 20 0 10
0 14 -1 0
0 10 0 1
0 33 4 17
1
end_operator
begin_operator
unstack b18 b19
0
4
0 20 0 10
0 10 0 1
0 8 -1 0
0 33 5 17
1
end_operator
begin_operator
unstack b18 b2
0
4
0 20 0 10
0 10 0 1
0 11 -1 0
0 33 6 17
1
end_operator
begin_operator
unstack b18 b24
0
4
0 20 0 10
0 10 0 1
0 18 -1 0
0 33 7 17
1
end_operator
begin_operator
unstack b18 b25
0
4
0 20 0 10
0 10 0 1
0 4 -1 0
0 33 8 17
1
end_operator
begin_operator
unstack b18 b26
0
4
0 20 0 10
0 10 0 1
0 17 -1 0
0 33 9 17
1
end_operator
begin_operator
unstack b18 b27
0
4
0 20 0 10
0 10 0 1
0 50 -1 0
0 33 10 17
1
end_operator
begin_operator
unstack b18 b3
0
4
0 20 0 10
0 10 0 1
0 19 -1 0
0 33 11 17
1
end_operator
begin_operator
unstack b18 b4
0
4
0 20 0 10
0 10 0 1
0 51 -1 0
0 33 12 17
1
end_operator
begin_operator
unstack b18 b6
0
4
0 20 0 10
0 10 0 1
0 16 -1 0
0 33 13 17
1
end_operator
begin_operator
unstack b18 b7
0
4
0 20 0 10
0 10 0 1
0 15 -1 0
0 33 14 17
1
end_operator
begin_operator
unstack b18 b9
0
4
0 20 0 10
0 10 0 1
0 47 -1 0
0 33 15 17
1
end_operator
begin_operator
unstack b19 b11
0
4
0 20 0 11
0 49 -1 0
0 8 0 1
0 32 1 9
1
end_operator
begin_operator
unstack b19 b13
0
4
0 20 0 11
0 48 -1 0
0 8 0 1
0 32 2 9
1
end_operator
begin_operator
unstack b19 b26
0
4
0 20 0 11
0 8 0 1
0 17 -1 0
0 32 3 9
1
end_operator
begin_operator
unstack b19 b27
0
4
0 20 0 11
0 8 0 1
0 50 -1 0
0 32 4 9
1
end_operator
begin_operator
unstack b19 b4
0
4
0 20 0 11
0 8 0 1
0 51 -1 0
0 32 5 9
1
end_operator
begin_operator
unstack b19 b8
0
4
0 20 0 11
0 8 0 1
0 6 -1 0
0 32 6 9
1
end_operator
begin_operator
unstack b19 b9
0
4
0 20 0 11
0 8 0 1
0 47 -1 0
0 32 7 9
1
end_operator
begin_operator
unstack b2 b1
0
4
0 20 0 12
0 7 -1 0
0 11 0 1
0 38 0 18
1
end_operator
begin_operator
unstack b2 b11
0
4
0 20 0 12
0 49 -1 0
0 11 0 1
0 38 1 18
1
end_operator
begin_operator
unstack b2 b13
0
4
0 20 0 12
0 48 -1 0
0 11 0 1
0 38 2 18
1
end_operator
begin_operator
unstack b2 b15
0
4
0 20 0 12
0 12 -1 0
0 11 0 1
0 38 3 18
1
end_operator
begin_operator
unstack b2 b16
0
4
0 20 0 12
0 14 -1 0
0 11 0 1
0 38 4 18
1
end_operator
begin_operator
unstack b2 b17
0
4
0 20 0 12
0 1 -1 0
0 11 0 1
0 38 5 18
1
end_operator
begin_operator
unstack b2 b24
0
4
0 20 0 12
0 11 0 1
0 18 -1 0
0 38 7 18
1
end_operator
begin_operator
unstack b2 b25
0
4
0 20 0 12
0 11 0 1
0 4 -1 0
0 38 8 18
1
end_operator
begin_operator
unstack b2 b26
0
4
0 20 0 12
0 11 0 1
0 17 -1 0
0 38 9 18
1
end_operator
begin_operator
unstack b2 b27
0
4
0 20 0 12
0 11 0 1
0 50 -1 0
0 38 10 18
1
end_operator
begin_operator
unstack b2 b3
0
4
0 20 0 12
0 11 0 1
0 19 -1 0
0 38 11 18
1
end_operator
begin_operator
unstack b2 b4
0
4
0 20 0 12
0 11 0 1
0 51 -1 0
0 38 12 18
1
end_operator
begin_operator
unstack b2 b6
0
4
0 20 0 12
0 11 0 1
0 16 -1 0
0 38 13 18
1
end_operator
begin_operator
unstack b2 b7
0
4
0 20 0 12
0 11 0 1
0 15 -1 0
0 38 14 18
1
end_operator
begin_operator
unstack b2 b8
0
4
0 20 0 12
0 11 0 1
0 6 -1 0
0 38 15 18
1
end_operator
begin_operator
unstack b2 b9
0
4
0 20 0 12
0 11 0 1
0 47 -1 0
0 38 16 18
1
end_operator
begin_operator
unstack b21 b23
0
3
0 20 0 13
0 2 0 1
0 31 1 0
1
end_operator
begin_operator
unstack b22 b8
0
4
0 20 0 14
0 5 0 1
0 6 -1 0
0 23 0 2
1
end_operator
begin_operator
unstack b23 b22
0
4
0 20 0 15
0 5 -1 0
0 31 0 2
0 29 0 2
1
end_operator
begin_operator
unstack b24 b1
0
4
0 20 0 16
0 7 -1 0
0 18 0 1
0 44 0 23
1
end_operator
begin_operator
unstack b24 b10
0
4
0 20 0 16
0 13 -1 0
0 18 0 1
0 44 1 23
1
end_operator
begin_operator
unstack b24 b11
0
4
0 20 0 16
0 49 -1 0
0 18 0 1
0 44 2 23
1
end_operator
begin_operator
unstack b24 b12
0
4
0 20 0 16
0 3 -1 0
0 18 0 1
0 44 3 23
1
end_operator
begin_operator
unstack b24 b13
0
4
0 20 0 16
0 48 -1 0
0 18 0 1
0 44 4 23
1
end_operator
begin_operator
unstack b24 b14
0
4
0 20 0 16
0 9 -1 0
0 18 0 1
0 44 5 23
1
end_operator
begin_operator
unstack b24 b15
0
4
0 20 0 16
0 12 -1 0
0 18 0 1
0 44 6 23
1
end_operator
begin_operator
unstack b24 b16
0
4
0 20 0 16
0 14 -1 0
0 18 0 1
0 44 7 23
1
end_operator
begin_operator
unstack b24 b17
0
4
0 20 0 16
0 1 -1 0
0 18 0 1
0 44 8 23
1
end_operator
begin_operator
unstack b24 b18
0
4
0 20 0 16
0 10 -1 0
0 18 0 1
0 44 9 23
1
end_operator
begin_operator
unstack b24 b19
0
4
0 20 0 16
0 8 -1 0
0 18 0 1
0 44 10 23
1
end_operator
begin_operator
unstack b24 b2
0
4
0 20 0 16
0 11 -1 0
0 18 0 1
0 44 11 23
1
end_operator
begin_operator
unstack b24 b21
0
4
0 20 0 16
0 2 -1 0
0 18 0 1
0 44 12 23
1
end_operator
begin_operator
unstack b24 b22
0
4
0 20 0 16
0 5 -1 0
0 18 0 1
0 44 13 23
1
end_operator
begin_operator
unstack b24 b25
0
4
0 20 0 16
0 18 0 1
0 4 -1 0
0 44 14 23
1
end_operator
begin_operator
unstack b24 b26
0
4
0 20 0 16
0 18 0 1
0 17 -1 0
0 44 15 23
1
end_operator
begin_operator
unstack b24 b27
0
4
0 20 0 16
0 18 0 1
0 50 -1 0
0 44 16 23
1
end_operator
begin_operator
unstack b24 b3
0
4
0 20 0 16
0 18 0 1
0 19 -1 0
0 44 17 23
1
end_operator
begin_operator
unstack b24 b5
0
4
0 20 0 16
0 18 0 1
0 0 -1 0
0 44 18 23
1
end_operator
begin_operator
unstack b24 b7
0
4
0 20 0 16
0 18 0 1
0 15 -1 0
0 44 19 23
1
end_operator
begin_operator
unstack b24 b8
0
4
0 20 0 16
0 18 0 1
0 6 -1 0
0 44 20 23
1
end_operator
begin_operator
unstack b24 b9
0
4
0 20 0 16
0 18 0 1
0 47 -1 0
0 44 21 23
1
end_operator
begin_operator
unstack b25 b24
0
4
0 20 0 17
0 18 -1 0
0 4 0 1
0 27 0 2
1
end_operator
begin_operator
unstack b26 b1
0
4
0 20 0 18
0 7 -1 0
0 17 0 1
0 40 0 21
1
end_operator
begin_operator
unstack b26 b10
0
4
0 20 0 18
0 13 -1 0
0 17 0 1
0 40 1 21
1
end_operator
begin_operator
unstack b26 b11
0
4
0 20 0 18
0 49 -1 0
0 17 0 1
0 40 2 21
1
end_operator
begin_operator
unstack b26 b12
0
4
0 20 0 18
0 3 -1 0
0 17 0 1
0 40 3 21
1
end_operator
begin_operator
unstack b26 b13
0
4
0 20 0 18
0 48 -1 0
0 17 0 1
0 40 4 21
1
end_operator
begin_operator
unstack b26 b15
0
4
0 20 0 18
0 12 -1 0
0 17 0 1
0 40 5 21
1
end_operator
begin_operator
unstack b26 b16
0
4
0 20 0 18
0 14 -1 0
0 17 0 1
0 40 6 21
1
end_operator
begin_operator
unstack b26 b17
0
4
0 20 0 18
0 1 -1 0
0 17 0 1
0 40 7 21
1
end_operator
begin_operator
unstack b26 b18
0
4
0 20 0 18
0 10 -1 0
0 17 0 1
0 40 8 21
1
end_operator
begin_operator
unstack b26 b19
0
4
0 20 0 18
0 8 -1 0
0 17 0 1
0 40 9 21
1
end_operator
begin_operator
unstack b26 b21
0
4
0 20 0 18
0 2 -1 0
0 17 0 1
0 40 10 21
1
end_operator
begin_operator
unstack b26 b22
0
4
0 20 0 18
0 5 -1 0
0 17 0 1
0 40 11 21
1
end_operator
begin_operator
unstack b26 b25
0
4
0 20 0 18
0 4 -1 0
0 17 0 1
0 40 12 21
1
end_operator
begin_operator
unstack b26 b27
0
4
0 20 0 18
0 17 0 1
0 50 -1 0
0 40 13 21
1
end_operator
begin_operator
unstack b26 b3
0
4
0 20 0 18
0 17 0 1
0 19 -1 0
0 40 14 21
1
end_operator
begin_operator
unstack b26 b4
0
4
0 20 0 18
0 17 0 1
0 51 -1 0
0 40 15 21
1
end_operator
begin_operator
unstack b26 b5
0
4
0 20 0 18
0 17 0 1
0 0 -1 0
0 40 16 21
1
end_operator
begin_operator
unstack b26 b6
0
4
0 20 0 18
0 17 0 1
0 16 -1 0
0 40 17 21
1
end_operator
begin_operator
unstack b26 b7
0
4
0 20 0 18
0 17 0 1
0 15 -1 0
0 40 18 21
1
end_operator
begin_operator
unstack b26 b9
0
4
0 20 0 18
0 17 0 1
0 47 -1 0
0 40 19 21
1
end_operator
begin_operator
unstack b27 b1
0
4
0 20 0 19
0 7 -1 0
0 50 0 1
0 42 0 21
1
end_operator
begin_operator
unstack b27 b10
0
4
0 20 0 19
0 13 -1 0
0 50 0 1
0 42 1 21
1
end_operator
begin_operator
unstack b27 b11
0
4
0 20 0 19
0 49 -1 0
0 50 0 1
0 42 2 21
1
end_operator
begin_operator
unstack b27 b12
0
4
0 20 0 19
0 3 -1 0
0 50 0 1
0 42 3 21
1
end_operator
begin_operator
unstack b27 b13
0
4
0 20 0 19
0 48 -1 0
0 50 0 1
0 42 4 21
1
end_operator
begin_operator
unstack b27 b15
0
4
0 20 0 19
0 12 -1 0
0 50 0 1
0 42 5 21
1
end_operator
begin_operator
unstack b27 b16
0
4
0 20 0 19
0 14 -1 0
0 50 0 1
0 42 6 21
1
end_operator
begin_operator
unstack b27 b17
0
4
0 20 0 19
0 1 -1 0
0 50 0 1
0 42 7 21
1
end_operator
begin_operator
unstack b27 b18
0
4
0 20 0 19
0 10 -1 0
0 50 0 1
0 42 8 21
1
end_operator
begin_operator
unstack b27 b19
0
4
0 20 0 19
0 8 -1 0
0 50 0 1
0 42 9 21
1
end_operator
begin_operator
unstack b27 b2
0
4
0 20 0 19
0 11 -1 0
0 50 0 1
0 42 10 21
1
end_operator
begin_operator
unstack b27 b21
0
4
0 20 0 19
0 2 -1 0
0 50 0 1
0 42 11 21
1
end_operator
begin_operator
unstack b27 b22
0
4
0 20 0 19
0 5 -1 0
0 50 0 1
0 42 12 21
1
end_operator
begin_operator
unstack b27 b24
0
4
0 20 0 19
0 18 -1 0
0 50 0 1
0 42 13 21
1
end_operator
begin_operator
unstack b27 b26
0
4
0 20 0 19
0 17 -1 0
0 50 0 1
0 42 14 21
1
end_operator
begin_operator
unstack b27 b3
0
4
0 20 0 19
0 50 0 1
0 19 -1 0
0 42 15 21
1
end_operator
begin_operator
unstack b27 b4
0
4
0 20 0 19
0 50 0 1
0 51 -1 0
0 42 16 21
1
end_operator
begin_operator
unstack b27 b6
0
4
0 20 0 19
0 50 0 1
0 16 -1 0
0 42 17 21
1
end_operator
begin_operator
unstack b27 b7
0
4
0 20 0 19
0 50 0 1
0 15 -1 0
0 42 18 21
1
end_operator
begin_operator
unstack b27 b9
0
4
0 20 0 19
0 50 0 1
0 47 -1 0
0 42 19 21
1
end_operator
begin_operator
unstack b3 b1
0
4
0 20 0 20
0 7 -1 0
0 19 0 1
0 45 0 23
1
end_operator
begin_operator
unstack b3 b10
0
4
0 20 0 20
0 13 -1 0
0 19 0 1
0 45 1 23
1
end_operator
begin_operator
unstack b3 b11
0
4
0 20 0 20
0 49 -1 0
0 19 0 1
0 45 2 23
1
end_operator
begin_operator
unstack b3 b12
0
4
0 20 0 20
0 3 -1 0
0 19 0 1
0 45 3 23
1
end_operator
begin_operator
unstack b3 b13
0
4
0 20 0 20
0 48 -1 0
0 19 0 1
0 45 4 23
1
end_operator
begin_operator
unstack b3 b15
0
4
0 20 0 20
0 12 -1 0
0 19 0 1
0 45 5 23
1
end_operator
begin_operator
unstack b3 b16
0
4
0 20 0 20
0 14 -1 0
0 19 0 1
0 45 6 23
1
end_operator
begin_operator
unstack b3 b17
0
4
0 20 0 20
0 1 -1 0
0 19 0 1
0 45 7 23
1
end_operator
begin_operator
unstack b3 b18
0
4
0 20 0 20
0 10 -1 0
0 19 0 1
0 45 8 23
1
end_operator
begin_operator
unstack b3 b19
0
4
0 20 0 20
0 8 -1 0
0 19 0 1
0 45 9 23
1
end_operator
begin_operator
unstack b3 b2
0
4
0 20 0 20
0 11 -1 0
0 19 0 1
0 45 10 23
1
end_operator
begin_operator
unstack b3 b21
0
4
0 20 0 20
0 2 -1 0
0 19 0 1
0 45 11 23
1
end_operator
begin_operator
unstack b3 b22
0
4
0 20 0 20
0 5 -1 0
0 19 0 1
0 45 12 23
1
end_operator
begin_operator
unstack b3 b24
0
4
0 20 0 20
0 18 -1 0
0 19 0 1
0 45 13 23
1
end_operator
begin_operator
unstack b3 b25
0
4
0 20 0 20
0 4 -1 0
0 19 0 1
0 45 14 23
1
end_operator
begin_operator
unstack b3 b26
0
4
0 20 0 20
0 17 -1 0
0 19 0 1
0 45 15 23
1
end_operator
begin_operator
unstack b3 b27
0
4
0 20 0 20
0 50 -1 0
0 19 0 1
0 45 16 23
1
end_operator
begin_operator
unstack b3 b4
0
4
0 20 0 20
0 19 0 1
0 51 -1 0
0 45 17 23
1
end_operator
begin_operator
unstack b3 b5
0
4
0 20 0 20
0 19 0 1
0 0 -1 0
0 45 18 23
1
end_operator
begin_operator
unstack b3 b6
0
4
0 20 0 20
0 19 0 1
0 16 -1 0
0 45 19 23
1
end_operator
begin_operator
unstack b3 b8
0
4
0 20 0 20
0 19 0 1
0 6 -1 0
0 45 20 23
1
end_operator
begin_operator
unstack b3 b9
0
4
0 20 0 20
0 19 0 1
0 47 -1 0
0 45 21 23
1
end_operator
begin_operator
unstack b4 b1
0
4
0 20 0 21
0 7 -1 0
0 51 0 1
0 43 0 21
1
end_operator
begin_operator
unstack b4 b10
0
4
0 20 0 21
0 13 -1 0
0 51 0 1
0 43 1 21
1
end_operator
begin_operator
unstack b4 b11
0
4
0 20 0 21
0 49 -1 0
0 51 0 1
0 43 2 21
1
end_operator
begin_operator
unstack b4 b12
0
4
0 20 0 21
0 3 -1 0
0 51 0 1
0 43 3 21
1
end_operator
begin_operator
unstack b4 b13
0
4
0 20 0 21
0 48 -1 0
0 51 0 1
0 43 4 21
1
end_operator
begin_operator
unstack b4 b15
0
4
0 20 0 21
0 12 -1 0
0 51 0 1
0 43 5 21
1
end_operator
begin_operator
unstack b4 b16
0
4
0 20 0 21
0 14 -1 0
0 51 0 1
0 43 6 21
1
end_operator
begin_operator
unstack b4 b17
0
4
0 20 0 21
0 1 -1 0
0 51 0 1
0 43 7 21
1
end_operator
begin_operator
unstack b4 b18
0
4
0 20 0 21
0 10 -1 0
0 51 0 1
0 43 8 21
1
end_operator
begin_operator
unstack b4 b19
0
4
0 20 0 21
0 8 -1 0
0 51 0 1
0 43 9 21
1
end_operator
begin_operator
unstack b4 b2
0
4
0 20 0 21
0 11 -1 0
0 51 0 1
0 43 10 21
1
end_operator
begin_operator
unstack b4 b21
0
4
0 20 0 21
0 2 -1 0
0 51 0 1
0 43 11 21
1
end_operator
begin_operator
unstack b4 b22
0
4
0 20 0 21
0 5 -1 0
0 51 0 1
0 43 12 21
1
end_operator
begin_operator
unstack b4 b24
0
4
0 20 0 21
0 18 -1 0
0 51 0 1
0 43 13 21
1
end_operator
begin_operator
unstack b4 b26
0
4
0 20 0 21
0 17 -1 0
0 51 0 1
0 43 14 21
1
end_operator
begin_operator
unstack b4 b27
0
4
0 20 0 21
0 50 -1 0
0 51 0 1
0 43 15 21
1
end_operator
begin_operator
unstack b4 b3
0
4
0 20 0 21
0 19 -1 0
0 51 0 1
0 43 16 21
1
end_operator
begin_operator
unstack b4 b5
0
4
0 20 0 21
0 51 0 1
0 0 -1 0
0 43 17 21
1
end_operator
begin_operator
unstack b4 b7
0
4
0 20 0 21
0 51 0 1
0 15 -1 0
0 43 18 21
1
end_operator
begin_operator
unstack b4 b9
0
4
0 20 0 21
0 51 0 1
0 47 -1 0
0 43 19 21
1
end_operator
begin_operator
unstack b5 b2
0
4
0 20 0 22
0 11 -1 0
0 0 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b6 b1
0
4
0 20 0 23
0 7 -1 0
0 16 0 1
0 46 0 24
1
end_operator
begin_operator
unstack b6 b10
0
4
0 20 0 23
0 13 -1 0
0 16 0 1
0 46 1 24
1
end_operator
begin_operator
unstack b6 b11
0
4
0 20 0 23
0 49 -1 0
0 16 0 1
0 46 2 24
1
end_operator
begin_operator
unstack b6 b12
0
4
0 20 0 23
0 3 -1 0
0 16 0 1
0 46 3 24
1
end_operator
begin_operator
unstack b6 b13
0
4
0 20 0 23
0 48 -1 0
0 16 0 1
0 46 4 24
1
end_operator
begin_operator
unstack b6 b14
0
4
0 20 0 23
0 9 -1 0
0 16 0 1
0 46 5 24
1
end_operator
begin_operator
unstack b6 b15
0
4
0 20 0 23
0 12 -1 0
0 16 0 1
0 46 6 24
1
end_operator
begin_operator
unstack b6 b16
0
4
0 20 0 23
0 14 -1 0
0 16 0 1
0 46 7 24
1
end_operator
begin_operator
unstack b6 b17
0
4
0 20 0 23
0 1 -1 0
0 16 0 1
0 46 8 24
1
end_operator
begin_operator
unstack b6 b18
0
4
0 20 0 23
0 10 -1 0
0 16 0 1
0 46 9 24
1
end_operator
begin_operator
unstack b6 b19
0
4
0 20 0 23
0 8 -1 0
0 16 0 1
0 46 10 24
1
end_operator
begin_operator
unstack b6 b21
0
4
0 20 0 23
0 2 -1 0
0 16 0 1
0 46 11 24
1
end_operator
begin_operator
unstack b6 b22
0
4
0 20 0 23
0 5 -1 0
0 16 0 1
0 46 12 24
1
end_operator
begin_operator
unstack b6 b24
0
4
0 20 0 23
0 18 -1 0
0 16 0 1
0 46 13 24
1
end_operator
begin_operator
unstack b6 b25
0
4
0 20 0 23
0 4 -1 0
0 16 0 1
0 46 14 24
1
end_operator
begin_operator
unstack b6 b26
0
4
0 20 0 23
0 17 -1 0
0 16 0 1
0 46 15 24
1
end_operator
begin_operator
unstack b6 b27
0
4
0 20 0 23
0 50 -1 0
0 16 0 1
0 46 16 24
1
end_operator
begin_operator
unstack b6 b3
0
4
0 20 0 23
0 19 -1 0
0 16 0 1
0 46 17 24
1
end_operator
begin_operator
unstack b6 b4
0
4
0 20 0 23
0 51 -1 0
0 16 0 1
0 46 18 24
1
end_operator
begin_operator
unstack b6 b5
0
4
0 20 0 23
0 0 -1 0
0 16 0 1
0 46 19 24
1
end_operator
begin_operator
unstack b6 b7
0
4
0 20 0 23
0 16 0 1
0 15 -1 0
0 46 20 24
1
end_operator
begin_operator
unstack b6 b8
0
4
0 20 0 23
0 16 0 1
0 6 -1 0
0 46 21 24
1
end_operator
begin_operator
unstack b6 b9
0
4
0 20 0 23
0 16 0 1
0 47 -1 0
0 46 22 24
1
end_operator
begin_operator
unstack b7 b1
0
4
0 20 0 24
0 7 -1 0
0 15 0 1
0 41 0 21
1
end_operator
begin_operator
unstack b7 b10
0
4
0 20 0 24
0 13 -1 0
0 15 0 1
0 41 1 21
1
end_operator
begin_operator
unstack b7 b11
0
4
0 20 0 24
0 49 -1 0
0 15 0 1
0 41 2 21
1
end_operator
begin_operator
unstack b7 b12
0
4
0 20 0 24
0 3 -1 0
0 15 0 1
0 41 3 21
1
end_operator
begin_operator
unstack b7 b13
0
4
0 20 0 24
0 48 -1 0
0 15 0 1
0 41 4 21
1
end_operator
begin_operator
unstack b7 b14
0
4
0 20 0 24
0 9 -1 0
0 15 0 1
0 41 5 21
1
end_operator
begin_operator
unstack b7 b15
0
4
0 20 0 24
0 12 -1 0
0 15 0 1
0 41 6 21
1
end_operator
begin_operator
unstack b7 b16
0
4
0 20 0 24
0 14 -1 0
0 15 0 1
0 41 7 21
1
end_operator
begin_operator
unstack b7 b18
0
4
0 20 0 24
0 10 -1 0
0 15 0 1
0 41 8 21
1
end_operator
begin_operator
unstack b7 b19
0
4
0 20 0 24
0 8 -1 0
0 15 0 1
0 41 9 21
1
end_operator
begin_operator
unstack b7 b21
0
4
0 20 0 24
0 2 -1 0
0 15 0 1
0 41 10 21
1
end_operator
begin_operator
unstack b7 b22
0
4
0 20 0 24
0 5 -1 0
0 15 0 1
0 41 11 21
1
end_operator
begin_operator
unstack b7 b24
0
4
0 20 0 24
0 18 -1 0
0 15 0 1
0 41 12 21
1
end_operator
begin_operator
unstack b7 b26
0
4
0 20 0 24
0 17 -1 0
0 15 0 1
0 41 13 21
1
end_operator
begin_operator
unstack b7 b27
0
4
0 20 0 24
0 50 -1 0
0 15 0 1
0 41 14 21
1
end_operator
begin_operator
unstack b7 b3
0
4
0 20 0 24
0 19 -1 0
0 15 0 1
0 41 15 21
1
end_operator
begin_operator
unstack b7 b4
0
4
0 20 0 24
0 51 -1 0
0 15 0 1
0 41 16 21
1
end_operator
begin_operator
unstack b7 b5
0
4
0 20 0 24
0 0 -1 0
0 15 0 1
0 41 17 21
1
end_operator
begin_operator
unstack b7 b6
0
4
0 20 0 24
0 16 -1 0
0 15 0 1
0 41 18 21
1
end_operator
begin_operator
unstack b7 b9
0
4
0 20 0 24
0 15 0 1
0 47 -1 0
0 41 19 21
1
end_operator
begin_operator
unstack b8 b19
0
4
0 20 0 25
0 8 -1 0
0 6 0 1
0 28 0 2
1
end_operator
begin_operator
unstack b9 b16
0
4
0 20 0 26
0 14 -1 0
0 47 0 1
0 25 0 2
1
end_operator
0
