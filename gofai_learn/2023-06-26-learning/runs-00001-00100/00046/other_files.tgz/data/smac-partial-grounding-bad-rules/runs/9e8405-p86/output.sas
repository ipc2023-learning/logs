begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var0
-1
2
Atom clear(b24)
<none of those>
end_variable
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var7
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var8
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var2
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var3
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var4
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var5
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var6
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var9
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var10
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var12
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var13
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var14
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var16
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var11
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var15
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var19
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var17
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var18
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var20
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var21
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var22
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var23
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var24
-1
25
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b25)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var25
-1
4
Atom on(b15, b2)
Atom on(b15, b24)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom on(b21, b1)
Atom on(b21, b5)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom on(b25, b11)
Atom on(b25, b9)
Atom on-table(b25)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b1, b21)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var46
-1
3
Atom on(b9, b3)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var48
-1
3
Atom on(b18, b4)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var47
-1
3
Atom on(b12, b13)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var49
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var28
-1
10
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b21)
Atom on(b7, b22)
Atom on(b7, b23)
Atom on(b7, b4)
Atom on(b7, b6)
Atom on(b7, b9)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var31
-1
16
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b25)
Atom on(b11, b4)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b9)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var32
-1
16
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b20)
Atom on(b13, b21)
Atom on(b13, b25)
Atom on(b13, b4)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b9)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var34
-1
16
Atom on(b4, b14)
Atom on(b4, b15)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b18)
Atom on(b4, b19)
Atom on(b4, b21)
Atom on(b4, b22)
Atom on(b4, b23)
Atom on(b4, b3)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b9)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var33
-1
17
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b13)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b18)
Atom on(b3, b19)
Atom on(b3, b20)
Atom on(b3, b21)
Atom on(b3, b23)
Atom on(b3, b25)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b7)
Atom on(b3, b9)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var35
-1
17
Atom on(b19, b11)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b2)
Atom on(b19, b21)
Atom on(b19, b22)
Atom on(b19, b23)
Atom on(b19, b25)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var37
-1
18
Atom on(b20, b11)
Atom on(b20, b13)
Atom on(b20, b14)
Atom on(b20, b15)
Atom on(b20, b16)
Atom on(b20, b17)
Atom on(b20, b18)
Atom on(b20, b19)
Atom on(b20, b21)
Atom on(b20, b22)
Atom on(b20, b23)
Atom on(b20, b25)
Atom on(b20, b4)
Atom on(b20, b6)
Atom on(b20, b7)
Atom on(b20, b9)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var41
-1
18
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b15)
Atom on(b6, b16)
Atom on(b6, b18)
Atom on(b6, b2)
Atom on(b6, b22)
Atom on(b6, b23)
Atom on(b6, b24)
Atom on(b6, b25)
Atom on(b6, b3)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on(b6, b9)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var36
-1
19
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b13)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b23)
Atom on(b2, b25)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b6)
Atom on(b2, b7)
Atom on(b2, b9)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var38
-1
19
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b13)
Atom on(b5, b15)
Atom on(b5, b16)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b21)
Atom on(b5, b23)
Atom on(b5, b25)
Atom on(b5, b3)
Atom on(b5, b4)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var40
-1
19
Atom on(b10, b11)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b25)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var30
-1
20
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b13)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b19)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b21)
Atom on(b17, b22)
Atom on(b17, b23)
Atom on(b17, b25)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var39
-1
21
Atom on(b14, b10)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b2)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b25)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var43
-1
21
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b2)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b24)
Atom on(b16, b25)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var44
-1
21
Atom on(b22, b1)
Atom on(b22, b10)
Atom on(b22, b13)
Atom on(b22, b14)
Atom on(b22, b15)
Atom on(b22, b16)
Atom on(b22, b17)
Atom on(b22, b18)
Atom on(b22, b19)
Atom on(b22, b2)
Atom on(b22, b20)
Atom on(b22, b21)
Atom on(b22, b23)
Atom on(b22, b25)
Atom on(b22, b3)
Atom on(b22, b5)
Atom on(b22, b6)
Atom on(b22, b7)
Atom on(b22, b9)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var45
-1
21
Atom on(b23, b10)
Atom on(b23, b11)
Atom on(b23, b13)
Atom on(b23, b14)
Atom on(b23, b15)
Atom on(b23, b16)
Atom on(b23, b17)
Atom on(b23, b18)
Atom on(b23, b19)
Atom on(b23, b2)
Atom on(b23, b20)
Atom on(b23, b21)
Atom on(b23, b22)
Atom on(b23, b25)
Atom on(b23, b3)
Atom on(b23, b5)
Atom on(b23, b6)
Atom on(b23, b8)
Atom on(b23, b9)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var42
-1
21
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b15)
Atom on(b8, b16)
Atom on(b8, b17)
Atom on(b8, b18)
Atom on(b8, b19)
Atom on(b8, b2)
Atom on(b8, b20)
Atom on(b8, b21)
Atom on(b8, b23)
Atom on(b8, b25)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
<none of those>
end_variable
8559
begin_mutex_group
5
24 1
1 0
26 0
47 0
40 0
end_mutex_group
begin_mutex_group
13
24 2
14 0
35 0
45 0
46 0
44 0
41 0
47 1
48 0
37 0
42 0
40 1
49 0
end_mutex_group
begin_mutex_group
14
24 3
10 0
43 0
35 1
46 1
44 1
38 0
41 1
39 0
48 1
27 0
37 1
42 1
49 1
end_mutex_group
begin_mutex_group
3
24 4
32 0
49 2
end_mutex_group
begin_mutex_group
15
24 5
12 0
43 1
31 0
45 1
46 2
44 2
41 2
39 1
47 2
48 2
37 2
42 2
40 2
49 3
end_mutex_group
begin_mutex_group
12
24 6
18 0
43 2
34 0
35 2
46 3
38 1
39 2
47 3
48 3
36 0
40 3
end_mutex_group
begin_mutex_group
19
24 7
5 0
43 3
34 1
35 3
45 2
46 4
44 3
38 2
41 3
39 3
47 4
48 4
37 3
36 1
42 3
40 4
33 0
49 4
end_mutex_group
begin_mutex_group
17
24 8
22 0
43 4
35 4
45 3
44 4
38 3
41 4
39 4
47 5
48 5
37 4
36 2
42 4
40 5
33 1
49 5
end_mutex_group
begin_mutex_group
12
24 9
15 0
34 2
45 4
46 5
38 4
41 5
39 5
47 6
48 6
36 3
49 6
end_mutex_group
begin_mutex_group
17
24 10
3 0
43 5
34 3
35 5
45 5
46 6
44 5
41 6
39 6
47 7
48 7
37 5
36 4
42 5
40 6
49 7
end_mutex_group
begin_mutex_group
16
24 11
19 0
43 6
34 4
35 6
45 6
46 7
44 6
41 7
39 7
47 8
48 8
37 6
36 5
42 6
49 8
end_mutex_group
begin_mutex_group
12
24 12
13 0
45 7
25 0
46 8
44 7
38 5
47 9
48 9
42 7
40 7
49 9
end_mutex_group
begin_mutex_group
13
24 13
11 0
43 7
34 5
35 7
45 8
44 8
41 8
47 10
48 10
37 7
42 8
49 10
end_mutex_group
begin_mutex_group
19
24 14
6 0
28 0
43 8
34 6
35 8
45 9
46 9
44 9
38 6
41 9
39 8
47 11
48 11
37 8
36 6
42 9
33 2
49 11
end_mutex_group
begin_mutex_group
12
24 15
17 0
34 7
45 10
46 10
44 10
38 7
39 9
48 12
36 7
40 8
33 3
end_mutex_group
begin_mutex_group
17
24 16
23 0
43 9
34 8
45 11
46 11
44 11
38 8
41 10
39 10
47 12
37 9
36 8
42 10
40 9
33 4
49 12
end_mutex_group
begin_mutex_group
5
0 0
43 10
25 1
46 12
40 10
end_mutex_group
begin_mutex_group
17
24 17
4 0
43 11
34 9
35 9
45 12
46 13
44 12
38 9
41 11
39 11
47 13
48 13
37 10
42 11
40 11
49 13
end_mutex_group
begin_mutex_group
13
24 18
9 0
43 12
45 13
46 14
44 13
47 14
48 14
36 9
42 12
40 12
49 14
29 0
end_mutex_group
begin_mutex_group
16
24 19
16 0
43 13
34 10
35 10
45 14
46 15
44 14
30 0
38 10
41 12
39 12
37 11
42 13
33 5
49 15
end_mutex_group
begin_mutex_group
14
24 20
20 0
45 15
46 16
44 15
38 11
41 13
26 1
47 15
48 15
37 12
36 10
40 13
49 16
end_mutex_group
begin_mutex_group
17
24 21
21 0
43 14
34 11
35 11
45 16
46 17
44 16
38 12
41 14
39 13
47 16
48 16
36 11
42 14
33 6
49 17
end_mutex_group
begin_mutex_group
17
24 22
8 0
43 15
34 12
35 12
45 17
46 18
44 17
38 13
41 15
39 14
47 17
37 13
36 12
42 15
40 14
49 18
end_mutex_group
begin_mutex_group
4
24 23
7 0
45 18
48 17
end_mutex_group
begin_mutex_group
17
24 24
2 0
43 16
34 13
35 13
38 14
41 16
39 15
47 18
48 18
27 1
37 14
36 13
42 16
40 15
33 7
49 19
end_mutex_group
begin_mutex_group
3
24 1
28 0
28 1
end_mutex_group
begin_mutex_group
19
24 2
43 0
43 1
43 2
43 3
43 4
43 5
43 6
43 7
43 8
43 9
43 10
43 11
43 12
43 13
43 14
43 15
43 16
43 17
end_mutex_group
begin_mutex_group
16
24 3
34 0
34 1
34 2
34 3
34 4
34 5
34 6
34 7
34 8
34 9
34 10
34 11
34 12
34 13
34 14
end_mutex_group
begin_mutex_group
3
24 4
31 0
31 1
end_mutex_group
begin_mutex_group
16
24 5
35 0
35 1
35 2
35 3
35 4
35 5
35 6
35 7
35 8
35 9
35 10
35 11
35 12
35 13
35 14
end_mutex_group
begin_mutex_group
21
24 6
45 0
45 1
45 2
45 3
45 4
45 5
45 6
45 7
45 8
45 9
45 10
45 11
45 12
45 13
45 14
45 15
45 16
45 17
45 18
45 19
end_mutex_group
begin_mutex_group
4
24 7
25 0
25 1
25 2
end_mutex_group
begin_mutex_group
21
24 8
46 0
46 1
46 2
46 3
46 4
46 5
46 6
46 7
46 8
46 9
46 10
46 11
46 12
46 13
46 14
46 15
46 16
46 17
46 18
46 19
end_mutex_group
begin_mutex_group
20
24 9
44 0
44 1
44 2
44 3
44 4
44 5
44 6
44 7
44 8
44 9
44 10
44 11
44 12
44 13
44 14
44 15
44 16
44 17
44 18
end_mutex_group
begin_mutex_group
3
24 10
30 0
30 1
end_mutex_group
begin_mutex_group
17
24 11
38 0
38 1
38 2
38 3
38 4
38 5
38 6
38 7
38 8
38 9
38 10
38 11
38 12
38 13
38 14
38 15
end_mutex_group
begin_mutex_group
19
24 12
41 0
41 1
41 2
41 3
41 4
41 5
41 6
41 7
41 8
41 9
41 10
41 11
41 12
41 13
41 14
41 15
41 16
41 17
end_mutex_group
begin_mutex_group
18
24 13
39 0
39 1
39 2
39 3
39 4
39 5
39 6
39 7
39 8
39 9
39 10
39 11
39 12
39 13
39 14
39 15
39 16
end_mutex_group
begin_mutex_group
4
24 14
26 0
26 1
26 2
end_mutex_group
begin_mutex_group
21
24 15
47 0
47 1
47 2
47 3
47 4
47 5
47 6
47 7
47 8
47 9
47 10
47 11
47 12
47 13
47 14
47 15
47 16
47 17
47 18
47 19
end_mutex_group
begin_mutex_group
21
24 16
48 0
48 1
48 2
48 3
48 4
48 5
48 6
48 7
48 8
48 9
48 10
48 11
48 12
48 13
48 14
48 15
48 16
48 17
48 18
48 19
end_mutex_group
begin_mutex_group
4
24 17
27 0
27 1
27 2
end_mutex_group
begin_mutex_group
17
24 18
37 0
37 1
37 2
37 3
37 4
37 5
37 6
37 7
37 8
37 9
37 10
37 11
37 12
37 13
37 14
37 15
end_mutex_group
begin_mutex_group
16
24 19
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
end_mutex_group
begin_mutex_group
19
24 20
42 0
42 1
42 2
42 3
42 4
42 5
42 6
42 7
42 8
42 9
42 10
42 11
42 12
42 13
42 14
42 15
42 16
42 17
end_mutex_group
begin_mutex_group
18
24 21
40 0
40 1
40 2
40 3
40 4
40 5
40 6
40 7
40 8
40 9
40 10
40 11
40 12
40 13
40 14
40 15
40 16
end_mutex_group
begin_mutex_group
10
24 22
33 0
33 1
33 2
33 3
33 4
33 5
33 6
33 7
33 8
end_mutex_group
begin_mutex_group
21
24 23
49 0
49 1
49 2
49 3
49 4
49 5
49 6
49 7
49 8
49 9
49 10
49 11
49 12
49 13
49 14
49 15
49 16
49 17
49 18
49 19
end_mutex_group
begin_mutex_group
3
24 24
29 0
29 1
end_mutex_group
begin_mutex_group
2
0 0
48 4
end_mutex_group
begin_mutex_group
2
1 0
28 2
end_mutex_group
begin_mutex_group
2
4 0
27 3
end_mutex_group
begin_mutex_group
2
5 0
25 3
end_mutex_group
begin_mutex_group
2
6 0
26 3
end_mutex_group
begin_mutex_group
2
7 0
33 5
end_mutex_group
begin_mutex_group
2
7 0
44 10
end_mutex_group
begin_mutex_group
2
7 0
34 5
end_mutex_group
begin_mutex_group
2
7 0
35 0
end_mutex_group
begin_mutex_group
2
7 0
37 12
end_mutex_group
begin_mutex_group
2
7 0
36 5
end_mutex_group
begin_mutex_group
2
7 0
38 0
end_mutex_group
begin_mutex_group
2
7 0
41 5
end_mutex_group
begin_mutex_group
2
7 0
39 1
end_mutex_group
begin_mutex_group
2
7 0
42 7
end_mutex_group
begin_mutex_group
2
7 0
43 12
end_mutex_group
begin_mutex_group
2
7 0
40 14
end_mutex_group
begin_mutex_group
2
7 0
49 20
end_mutex_group
begin_mutex_group
2
7 0
47 3
end_mutex_group
begin_mutex_group
2
7 1
49 12
end_mutex_group
begin_mutex_group
2
8 0
33 9
end_mutex_group
begin_mutex_group
2
2 0
46 13
end_mutex_group
begin_mutex_group
2
2 0
29 2
end_mutex_group
begin_mutex_group
2
3 0
30 2
end_mutex_group
begin_mutex_group
2
9 0
33 5
end_mutex_group
begin_mutex_group
2
9 0
34 5
end_mutex_group
begin_mutex_group
2
9 0
35 0
end_mutex_group
begin_mutex_group
2
9 0
37 16
end_mutex_group
begin_mutex_group
2
9 0
36 5
end_mutex_group
begin_mutex_group
2
9 0
38 0
end_mutex_group
begin_mutex_group
2
9 0
39 1
end_mutex_group
begin_mutex_group
2
9 0
40 14
end_mutex_group
begin_mutex_group
2
10 0
33 5
end_mutex_group
begin_mutex_group
2
10 0
34 15
end_mutex_group
begin_mutex_group
2
10 0
36 5
end_mutex_group
begin_mutex_group
2
10 0
40 14
end_mutex_group
begin_mutex_group
2
15 0
33 5
end_mutex_group
begin_mutex_group
2
15 0
44 19
end_mutex_group
begin_mutex_group
2
15 0
34 5
end_mutex_group
begin_mutex_group
2
15 0
35 0
end_mutex_group
begin_mutex_group
2
15 0
37 12
end_mutex_group
begin_mutex_group
2
15 0
36 5
end_mutex_group
begin_mutex_group
2
15 0
38 0
end_mutex_group
begin_mutex_group
2
15 0
39 1
end_mutex_group
begin_mutex_group
2
15 0
42 7
end_mutex_group
begin_mutex_group
2
15 0
43 12
end_mutex_group
begin_mutex_group
2
15 0
40 14
end_mutex_group
begin_mutex_group
2
11 0
33 5
end_mutex_group
begin_mutex_group
2
11 0
36 5
end_mutex_group
begin_mutex_group
2
11 0
38 0
end_mutex_group
begin_mutex_group
2
11 0
39 17
end_mutex_group
begin_mutex_group
2
11 0
40 14
end_mutex_group
begin_mutex_group
2
12 0
33 5
end_mutex_group
begin_mutex_group
2
12 0
34 5
end_mutex_group
begin_mutex_group
2
12 0
35 15
end_mutex_group
begin_mutex_group
2
12 0
36 5
end_mutex_group
begin_mutex_group
2
12 0
38 0
end_mutex_group
begin_mutex_group
2
12 0
40 14
end_mutex_group
begin_mutex_group
2
13 0
33 5
end_mutex_group
begin_mutex_group
2
13 0
34 5
end_mutex_group
begin_mutex_group
2
13 0
35 0
end_mutex_group
begin_mutex_group
2
13 0
37 12
end_mutex_group
begin_mutex_group
2
13 0
36 5
end_mutex_group
begin_mutex_group
2
13 0
38 0
end_mutex_group
begin_mutex_group
2
13 0
41 18
end_mutex_group
begin_mutex_group
2
13 0
39 1
end_mutex_group
begin_mutex_group
2
13 0
43 12
end_mutex_group
begin_mutex_group
2
13 0
40 14
end_mutex_group
begin_mutex_group
2
16 0
36 15
end_mutex_group
begin_mutex_group
2
16 0
40 14
end_mutex_group
begin_mutex_group
2
14 0
33 5
end_mutex_group
begin_mutex_group
2
14 0
34 5
end_mutex_group
begin_mutex_group
2
14 0
36 5
end_mutex_group
begin_mutex_group
2
14 0
38 0
end_mutex_group
begin_mutex_group
2
14 0
39 1
end_mutex_group
begin_mutex_group
2
14 0
43 18
end_mutex_group
begin_mutex_group
2
14 0
40 14
end_mutex_group
begin_mutex_group
2
18 0
33 5
end_mutex_group
begin_mutex_group
2
18 0
44 10
end_mutex_group
begin_mutex_group
2
18 0
34 5
end_mutex_group
begin_mutex_group
2
18 0
35 0
end_mutex_group
begin_mutex_group
2
18 0
37 12
end_mutex_group
begin_mutex_group
2
18 0
36 5
end_mutex_group
begin_mutex_group
2
18 0
38 0
end_mutex_group
begin_mutex_group
2
18 0
41 5
end_mutex_group
begin_mutex_group
2
18 0
39 1
end_mutex_group
begin_mutex_group
2
18 0
42 7
end_mutex_group
begin_mutex_group
2
18 0
45 20
end_mutex_group
begin_mutex_group
2
18 0
43 12
end_mutex_group
begin_mutex_group
2
18 0
40 14
end_mutex_group
begin_mutex_group
2
19 0
33 5
end_mutex_group
begin_mutex_group
2
19 0
38 16
end_mutex_group
begin_mutex_group
2
19 0
40 14
end_mutex_group
begin_mutex_group
2
17 0
33 5
end_mutex_group
begin_mutex_group
2
17 0
34 5
end_mutex_group
begin_mutex_group
2
17 0
35 0
end_mutex_group
begin_mutex_group
2
17 0
37 12
end_mutex_group
begin_mutex_group
2
17 0
36 5
end_mutex_group
begin_mutex_group
2
17 0
38 0
end_mutex_group
begin_mutex_group
2
17 0
41 5
end_mutex_group
begin_mutex_group
2
17 0
39 1
end_mutex_group
begin_mutex_group
2
17 0
42 7
end_mutex_group
begin_mutex_group
2
17 0
43 12
end_mutex_group
begin_mutex_group
2
17 0
40 14
end_mutex_group
begin_mutex_group
2
17 0
47 20
end_mutex_group
begin_mutex_group
2
20 0
33 5
end_mutex_group
begin_mutex_group
2
20 0
34 5
end_mutex_group
begin_mutex_group
2
20 0
35 0
end_mutex_group
begin_mutex_group
2
20 0
36 5
end_mutex_group
begin_mutex_group
2
20 0
38 0
end_mutex_group
begin_mutex_group
2
20 0
39 1
end_mutex_group
begin_mutex_group
2
20 0
42 18
end_mutex_group
begin_mutex_group
2
20 0
43 12
end_mutex_group
begin_mutex_group
2
20 0
40 14
end_mutex_group
begin_mutex_group
2
21 0
40 17
end_mutex_group
begin_mutex_group
2
22 0
46 20
end_mutex_group
begin_mutex_group
2
23 0
48 20
end_mutex_group
begin_mutex_group
2
24 0
25 3
end_mutex_group
begin_mutex_group
2
24 0
26 3
end_mutex_group
begin_mutex_group
2
24 0
27 3
end_mutex_group
begin_mutex_group
2
24 0
33 9
end_mutex_group
begin_mutex_group
2
24 0
28 2
end_mutex_group
begin_mutex_group
2
24 0
44 19
end_mutex_group
begin_mutex_group
2
24 0
34 15
end_mutex_group
begin_mutex_group
2
24 0
35 15
end_mutex_group
begin_mutex_group
2
24 0
37 16
end_mutex_group
begin_mutex_group
2
24 0
36 15
end_mutex_group
begin_mutex_group
2
24 0
38 16
end_mutex_group
begin_mutex_group
2
24 0
41 18
end_mutex_group
begin_mutex_group
2
24 0
39 17
end_mutex_group
begin_mutex_group
2
24 0
42 18
end_mutex_group
begin_mutex_group
2
24 0
45 20
end_mutex_group
begin_mutex_group
2
24 0
43 18
end_mutex_group
begin_mutex_group
2
24 0
40 17
end_mutex_group
begin_mutex_group
2
24 0
49 20
end_mutex_group
begin_mutex_group
2
24 0
46 20
end_mutex_group
begin_mutex_group
2
24 0
47 20
end_mutex_group
begin_mutex_group
2
24 0
48 20
end_mutex_group
begin_mutex_group
2
24 0
29 2
end_mutex_group
begin_mutex_group
2
24 0
31 2
end_mutex_group
begin_mutex_group
2
24 0
30 2
end_mutex_group
begin_mutex_group
2
24 1
25 3
end_mutex_group
begin_mutex_group
2
24 1
26 3
end_mutex_group
begin_mutex_group
2
24 1
27 3
end_mutex_group
begin_mutex_group
2
24 1
33 9
end_mutex_group
begin_mutex_group
2
24 1
44 19
end_mutex_group
begin_mutex_group
2
24 1
34 15
end_mutex_group
begin_mutex_group
2
24 1
35 15
end_mutex_group
begin_mutex_group
2
24 1
37 16
end_mutex_group
begin_mutex_group
2
24 1
36 15
end_mutex_group
begin_mutex_group
2
24 1
38 16
end_mutex_group
begin_mutex_group
2
24 1
41 18
end_mutex_group
begin_mutex_group
2
24 1
39 17
end_mutex_group
begin_mutex_group
2
24 1
42 18
end_mutex_group
begin_mutex_group
2
24 1
45 20
end_mutex_group
begin_mutex_group
2
24 1
43 18
end_mutex_group
begin_mutex_group
2
24 1
40 17
end_mutex_group
begin_mutex_group
2
24 1
49 20
end_mutex_group
begin_mutex_group
2
24 1
46 20
end_mutex_group
begin_mutex_group
2
24 1
47 20
end_mutex_group
begin_mutex_group
2
24 1
48 20
end_mutex_group
begin_mutex_group
2
24 1
29 2
end_mutex_group
begin_mutex_group
2
24 1
31 2
end_mutex_group
begin_mutex_group
2
24 1
30 2
end_mutex_group
begin_mutex_group
2
24 2
25 3
end_mutex_group
begin_mutex_group
2
24 2
26 3
end_mutex_group
begin_mutex_group
2
24 2
27 3
end_mutex_group
begin_mutex_group
2
24 2
33 5
end_mutex_group
begin_mutex_group
2
24 2
33 9
end_mutex_group
begin_mutex_group
2
24 2
28 2
end_mutex_group
begin_mutex_group
2
24 2
44 19
end_mutex_group
begin_mutex_group
2
24 2
34 5
end_mutex_group
begin_mutex_group
2
24 2
34 15
end_mutex_group
begin_mutex_group
2
24 2
35 15
end_mutex_group
begin_mutex_group
2
24 2
37 16
end_mutex_group
begin_mutex_group
2
24 2
36 5
end_mutex_group
begin_mutex_group
2
24 2
36 15
end_mutex_group
begin_mutex_group
2
24 2
38 0
end_mutex_group
begin_mutex_group
2
24 2
38 16
end_mutex_group
begin_mutex_group
2
24 2
41 18
end_mutex_group
begin_mutex_group
2
24 2
39 1
end_mutex_group
begin_mutex_group
2
24 2
39 17
end_mutex_group
begin_mutex_group
2
24 2
42 18
end_mutex_group
begin_mutex_group
2
24 2
45 20
end_mutex_group
begin_mutex_group
2
24 2
40 14
end_mutex_group
begin_mutex_group
2
24 2
40 17
end_mutex_group
begin_mutex_group
2
24 2
49 20
end_mutex_group
begin_mutex_group
2
24 2
46 20
end_mutex_group
begin_mutex_group
2
24 2
47 20
end_mutex_group
begin_mutex_group
2
24 2
48 20
end_mutex_group
begin_mutex_group
2
24 2
29 2
end_mutex_group
begin_mutex_group
2
24 2
31 2
end_mutex_group
begin_mutex_group
2
24 2
30 2
end_mutex_group
begin_mutex_group
2
24 3
25 3
end_mutex_group
begin_mutex_group
2
24 3
26 3
end_mutex_group
begin_mutex_group
2
24 3
27 3
end_mutex_group
begin_mutex_group
2
24 3
33 5
end_mutex_group
begin_mutex_group
2
24 3
33 9
end_mutex_group
begin_mutex_group
2
24 3
28 2
end_mutex_group
begin_mutex_group
2
24 3
44 19
end_mutex_group
begin_mutex_group
2
24 3
35 15
end_mutex_group
begin_mutex_group
2
24 3
37 16
end_mutex_group
begin_mutex_group
2
24 3
36 5
end_mutex_group
begin_mutex_group
2
24 3
36 15
end_mutex_group
begin_mutex_group
2
24 3
38 16
end_mutex_group
begin_mutex_group
2
24 3
41 18
end_mutex_group
begin_mutex_group
2
24 3
39 17
end_mutex_group
begin_mutex_group
2
24 3
42 18
end_mutex_group
begin_mutex_group
2
24 3
45 20
end_mutex_group
begin_mutex_group
2
24 3
43 18
end_mutex_group
begin_mutex_group
2
24 3
40 14
end_mutex_group
begin_mutex_group
2
24 3
40 17
end_mutex_group
begin_mutex_group
2
24 3
49 20
end_mutex_group
begin_mutex_group
2
24 3
46 20
end_mutex_group
begin_mutex_group
2
24 3
47 20
end_mutex_group
begin_mutex_group
2
24 3
48 20
end_mutex_group
begin_mutex_group
2
24 3
29 2
end_mutex_group
begin_mutex_group
2
24 3
31 2
end_mutex_group
begin_mutex_group
2
24 3
30 2
end_mutex_group
begin_mutex_group
2
24 4
25 3
end_mutex_group
begin_mutex_group
2
24 4
26 3
end_mutex_group
begin_mutex_group
2
24 4
27 3
end_mutex_group
begin_mutex_group
2
24 4
33 5
end_mutex_group
begin_mutex_group
2
24 4
33 9
end_mutex_group
begin_mutex_group
2
24 4
28 2
end_mutex_group
begin_mutex_group
2
24 4
44 10
end_mutex_group
begin_mutex_group
2
24 4
44 19
end_mutex_group
begin_mutex_group
2
24 4
34 5
end_mutex_group
begin_mutex_group
2
24 4
34 15
end_mutex_group
begin_mutex_group
2
24 4
35 0
end_mutex_group
begin_mutex_group
2
24 4
35 15
end_mutex_group
begin_mutex_group
2
24 4
37 12
end_mutex_group
begin_mutex_group
2
24 4
37 16
end_mutex_group
begin_mutex_group
2
24 4
36 5
end_mutex_group
begin_mutex_group
2
24 4
36 15
end_mutex_group
begin_mutex_group
2
24 4
38 0
end_mutex_group
begin_mutex_group
2
24 4
38 16
end_mutex_group
begin_mutex_group
2
24 4
4




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




tor
stack b6 b3
0
4
0 24 21 0
0 9 0 1
0 21 -1 0
0 40 -1 12
1
end_operator
begin_operator
stack b6 b5
0
4
0 24 21 0
0 20 0 1
0 21 -1 0
0 40 -1 13
1
end_operator
begin_operator
stack b6 b9
0
4
0 24 21 0
0 21 -1 0
0 2 0 1
0 40 -1 15
1
end_operator
begin_operator
stack b7 b15
0
4
0 24 22 0
0 5 0 1
0 8 -1 0
0 33 -1 0
1
end_operator
begin_operator
stack b7 b16
0
4
0 24 22 0
0 22 0 1
0 8 -1 0
0 33 -1 1
1
end_operator
begin_operator
stack b7 b21
0
4
0 24 22 0
0 6 0 1
0 8 -1 0
0 33 -1 2
1
end_operator
begin_operator
stack b7 b22
0
4
0 24 22 0
0 17 0 1
0 8 -1 0
0 33 -1 3
1
end_operator
begin_operator
stack b7 b23
0
4
0 24 22 0
0 23 0 1
0 8 -1 0
0 33 -1 4
1
end_operator
begin_operator
stack b7 b6
0
4
0 24 22 0
0 21 0 1
0 8 -1 0
0 33 -1 6
1
end_operator
begin_operator
stack b7 b9
0
4
0 24 22 0
0 8 -1 0
0 2 0 1
0 33 -1 7
1
end_operator
begin_operator
stack b8 b10
0
4
0 24 23 0
0 14 0 1
0 7 -1 0
0 49 -1 0
1
end_operator
begin_operator
stack b8 b11
0
4
0 24 23 0
0 10 0 1
0 7 -1 0
0 49 -1 1
1
end_operator
begin_operator
stack b8 b13
0
4
0 24 23 0
0 12 0 1
0 7 -1 0
0 49 -1 3
1
end_operator
begin_operator
stack b8 b15
0
4
0 24 23 0
0 5 0 1
0 7 -1 0
0 49 -1 4
1
end_operator
begin_operator
stack b8 b16
0
4
0 24 23 0
0 22 0 1
0 7 -1 0
0 49 -1 5
1
end_operator
begin_operator
stack b8 b17
0
4
0 24 23 0
0 15 0 1
0 7 -1 0
0 49 -1 6
1
end_operator
begin_operator
stack b8 b18
0
4
0 24 23 0
0 3 0 1
0 7 -1 0
0 49 -1 7
1
end_operator
begin_operator
stack b8 b19
0
4
0 24 23 0
0 19 0 1
0 7 -1 0
0 49 -1 8
1
end_operator
begin_operator
stack b8 b2
0
4
0 24 23 0
0 13 0 1
0 7 -1 0
0 49 -1 9
1
end_operator
begin_operator
stack b8 b20
0
4
0 24 23 0
0 11 0 1
0 7 -1 0
0 49 -1 10
1
end_operator
begin_operator
stack b8 b21
0
4
0 24 23 0
0 6 0 1
0 7 -1 0
0 49 -1 11
1
end_operator
begin_operator
stack b8 b23
0
4
0 24 23 0
0 23 0 1
0 7 -1 0
0 49 -1 12
1
end_operator
begin_operator
stack b8 b25
0
4
0 24 23 0
0 4 0 1
0 7 -1 0
0 49 -1 13
1
end_operator
begin_operator
stack b8 b3
0
4
0 24 23 0
0 9 0 1
0 7 -1 0
0 49 -1 14
1
end_operator
begin_operator
stack b8 b4
0
4
0 24 23 0
0 16 0 1
0 7 -1 0
0 49 -1 15
1
end_operator
begin_operator
stack b8 b5
0
4
0 24 23 0
0 20 0 1
0 7 -1 0
0 49 -1 16
1
end_operator
begin_operator
stack b8 b6
0
4
0 24 23 0
0 21 0 1
0 7 -1 0
0 49 -1 17
1
end_operator
begin_operator
stack b8 b7
0
4
0 24 23 0
0 8 0 1
0 7 -1 0
0 49 -1 18
1
end_operator
begin_operator
stack b8 b9
0
4
0 24 23 0
0 7 -1 0
0 2 0 1
0 49 -1 19
1
end_operator
begin_operator
stack b9 b3
0
4
0 24 24 0
0 9 0 1
0 2 -1 0
0 29 -1 0
1
end_operator
begin_operator
unstack b10 b11
0
4
0 24 0 2
0 14 0 1
0 10 -1 0
0 43 0 18
1
end_operator
begin_operator
unstack b10 b13
0
4
0 24 0 2
0 14 0 1
0 12 -1 0
0 43 1 18
1
end_operator
begin_operator
unstack b10 b14
0
4
0 24 0 2
0 14 0 1
0 18 -1 0
0 43 2 18
1
end_operator
begin_operator
unstack b10 b15
0
4
0 24 0 2
0 14 0 1
0 5 -1 0
0 43 3 18
1
end_operator
begin_operator
unstack b10 b16
0
4
0 24 0 2
0 14 0 1
0 22 -1 0
0 43 4 18
1
end_operator
begin_operator
unstack b10 b18
0
4
0 24 0 2
0 14 0 1
0 3 -1 0
0 43 5 18
1
end_operator
begin_operator
unstack b10 b19
0
4
0 24 0 2
0 14 0 1
0 19 -1 0
0 43 6 18
1
end_operator
begin_operator
unstack b10 b20
0
4
0 24 0 2
0 14 0 1
0 11 -1 0
0 43 7 18
1
end_operator
begin_operator
unstack b10 b21
0
4
0 24 0 2
0 14 0 1
0 6 -1 0
0 43 8 18
1
end_operator
begin_operator
unstack b10 b23
0
4
0 24 0 2
0 14 0 1
0 23 -1 0
0 43 9 18
1
end_operator
begin_operator
unstack b10 b25
0
4
0 24 0 2
0 14 0 1
0 4 -1 0
0 43 11 18
1
end_operator
begin_operator
unstack b10 b3
0
4
0 24 0 2
0 14 0 1
0 9 -1 0
0 43 12 18
1
end_operator
begin_operator
unstack b10 b4
0
4
0 24 0 2
0 14 0 1
0 16 -1 0
0 43 13 18
1
end_operator
begin_operator
unstack b10 b6
0
4
0 24 0 2
0 14 0 1
0 21 -1 0
0 43 14 18
1
end_operator
begin_operator
unstack b10 b7
0
4
0 24 0 2
0 14 0 1
0 8 -1 0
0 43 15 18
1
end_operator
begin_operator
unstack b10 b9
0
4
0 24 0 2
0 14 0 1
0 2 -1 0
0 43 16 18
1
end_operator
begin_operator
unstack b11 b14
0
4
0 24 0 3
0 10 0 1
0 18 -1 0
0 34 0 15
1
end_operator
begin_operator
unstack b11 b17
0
4
0 24 0 3
0 10 0 1
0 15 -1 0
0 34 2 15
1
end_operator
begin_operator
unstack b11 b18
0
4
0 24 0 3
0 10 0 1
0 3 -1 0
0 34 3 15
1
end_operator
begin_operator
unstack b11 b19
0
4
0 24 0 3
0 10 0 1
0 19 -1 0
0 34 4 15
1
end_operator
begin_operator
unstack b11 b20
0
4
0 24 0 3
0 10 0 1
0 11 -1 0
0 34 5 15
1
end_operator
begin_operator
unstack b11 b21
0
4
0 24 0 3
0 10 0 1
0 6 -1 0
0 34 6 15
1
end_operator
begin_operator
unstack b11 b22
0
4
0 24 0 3
0 10 0 1
0 17 -1 0
0 34 7 15
1
end_operator
begin_operator
unstack b11 b23
0
4
0 24 0 3
0 10 0 1
0 23 -1 0
0 34 8 15
1
end_operator
begin_operator
unstack b11 b25
0
4
0 24 0 3
0 10 0 1
0 4 -1 0
0 34 9 15
1
end_operator
begin_operator
unstack b11 b4
0
4
0 24 0 3
0 10 0 1
0 16 -1 0
0 34 10 15
1
end_operator
begin_operator
unstack b11 b6
0
4
0 24 0 3
0 10 0 1
0 21 -1 0
0 34 11 15
1
end_operator
begin_operator
unstack b11 b7
0
4
0 24 0 3
0 10 0 1
0 8 -1 0
0 34 12 15
1
end_operator
begin_operator
unstack b11 b9
0
4
0 24 0 3
0 10 0 1
0 2 -1 0
0 34 13 15
1
end_operator
begin_operator
unstack b13 b10
0
4
0 24 0 5
0 14 -1 0
0 12 0 1
0 35 0 15
1
end_operator
begin_operator
unstack b13 b11
0
4
0 24 0 5
0 10 -1 0
0 12 0 1
0 35 1 15
1
end_operator
begin_operator
unstack b13 b14
0
4
0 24 0 5
0 12 0 1
0 18 -1 0
0 35 2 15
1
end_operator
begin_operator
unstack b13 b15
0
4
0 24 0 5
0 12 0 1
0 5 -1 0
0 35 3 15
1
end_operator
begin_operator
unstack b13 b16
0
4
0 24 0 5
0 12 0 1
0 22 -1 0
0 35 4 15
1
end_operator
begin_operator
unstack b13 b18
0
4
0 24 0 5
0 12 0 1
0 3 -1 0
0 35 5 15
1
end_operator
begin_operator
unstack b13 b20
0
4
0 24 0 5
0 12 0 1
0 11 -1 0
0 35 7 15
1
end_operator
begin_operator
unstack b13 b21
0
4
0 24 0 5
0 12 0 1
0 6 -1 0
0 35 8 15
1
end_operator
begin_operator
unstack b13 b25
0
4
0 24 0 5
0 12 0 1
0 4 -1 0
0 35 9 15
1
end_operator
begin_operator
unstack b13 b4
0
4
0 24 0 5
0 12 0 1
0 16 -1 0
0 35 10 15
1
end_operator
begin_operator
unstack b13 b6
0
4
0 24 0 5
0 12 0 1
0 21 -1 0
0 35 11 15
1
end_operator
begin_operator
unstack b13 b7
0
4
0 24 0 5
0 12 0 1
0 8 -1 0
0 35 12 15
1
end_operator
begin_operator
unstack b13 b9
0
4
0 24 0 5
0 12 0 1
0 2 -1 0
0 35 13 15
1
end_operator
begin_operator
unstack b14 b10
0
4
0 24 0 6
0 14 -1 0
0 18 0 1
0 45 0 20
1
end_operator
begin_operator
unstack b14 b13
0
4
0 24 0 6
0 12 -1 0
0 18 0 1
0 45 1 20
1
end_operator
begin_operator
unstack b14 b15
0
4
0 24 0 6
0 18 0 1
0 5 -1 0
0 45 2 20
1
end_operator
begin_operator
unstack b14 b16
0
4
0 24 0 6
0 18 0 1
0 22 -1 0
0 45 3 20
1
end_operator
begin_operator
unstack b14 b17
0
4
0 24 0 6
0 18 0 1
0 15 -1 0
0 45 4 20
1
end_operator
begin_operator
unstack b14 b18
0
4
0 24 0 6
0 18 0 1
0 3 -1 0
0 45 5 20
1
end_operator
begin_operator
unstack b14 b19
0
4
0 24 0 6
0 18 0 1
0 19 -1 0
0 45 6 20
1
end_operator
begin_operator
unstack b14 b2
0
4
0 24 0 6
0 18 0 1
0 13 -1 0
0 45 7 20
1
end_operator
begin_operator
unstack b14 b20
0
4
0 24 0 6
0 18 0 1
0 11 -1 0
0 45 8 20
1
end_operator
begin_operator
unstack b14 b21
0
4
0 24 0 6
0 18 0 1
0 6 -1 0
0 45 9 20
1
end_operator
begin_operator
unstack b14 b22
0
4
0 24 0 6
0 18 0 1
0 17 -1 0
0 45 10 20
1
end_operator
begin_operator
unstack b14 b23
0
4
0 24 0 6
0 18 0 1
0 23 -1 0
0 45 11 20
1
end_operator
begin_operator
unstack b14 b3
0
4
0 24 0 6
0 18 0 1
0 9 -1 0
0 45 13 20
1
end_operator
begin_operator
unstack b14 b4
0
4
0 24 0 6
0 18 0 1
0 16 -1 0
0 45 14 20
1
end_operator
begin_operator
unstack b14 b5
0
4
0 24 0 6
0 18 0 1
0 20 -1 0
0 45 15 20
1
end_operator
begin_operator
unstack b14 b6
0
4
0 24 0 6
0 18 0 1
0 21 -1 0
0 45 16 20
1
end_operator
begin_operator
unstack b14 b7
0
4
0 24 0 6
0 18 0 1
0 8 -1 0
0 45 17 20
1
end_operator
begin_operator
unstack b14 b8
0
4
0 24 0 6
0 18 0 1
0 7 -1 0
0 45 18 20
1
end_operator
begin_operator
unstack b15 b24
0
4
0 24 0 7
0 5 0 1
0 0 -1 0
0 25 1 3
1
end_operator
begin_operator
unstack b16 b10
0
4
0 24 0 8
0 14 -1 0
0 22 0 1
0 46 0 20
1
end_operator
begin_operator
unstack b16 b11
0
4
0 24 0 8
0 10 -1 0
0 22 0 1
0 46 1 20
1
end_operator
begin_operator
unstack b16 b13
0
4
0 24 0 8
0 12 -1 0
0 22 0 1
0 46 2 20
1
end_operator
begin_operator
unstack b16 b14
0
4
0 24 0 8
0 18 -1 0
0 22 0 1
0 46 3 20
1
end_operator
begin_operator
unstack b16 b15
0
4
0 24 0 8
0 5 -1 0
0 22 0 1
0 46 4 20
1
end_operator
begin_operator
unstack b16 b17
0
4
0 24 0 8
0 22 0 1
0 15 -1 0
0 46 5 20
1
end_operator
begin_operator
unstack b16 b18
0
4
0 24 0 8
0 22 0 1
0 3 -1 0
0 46 6 20
1
end_operator
begin_operator
unstack b16 b19
0
4
0 24 0 8
0 22 0 1
0 19 -1 0
0 46 7 20
1
end_operator
begin_operator
unstack b16 b2
0
4
0 24 0 8
0 22 0 1
0 13 -1 0
0 46 8 20
1
end_operator
begin_operator
unstack b16 b21
0
4
0 24 0 8
0 22 0 1
0 6 -1 0
0 46 9 20
1
end_operator
begin_operator
unstack b16 b22
0
4
0 24 0 8
0 22 0 1
0 17 -1 0
0 46 10 20
1
end_operator
begin_operator
unstack b16 b23
0
4
0 24 0 8
0 22 0 1
0 23 -1 0
0 46 11 20
1
end_operator
begin_operator
unstack b16 b24
0
4
0 24 0 8
0 22 0 1
0 0 -1 0
0 46 12 20
1
end_operator
begin_operator
unstack b16 b25
0
4
0 24 0 8
0 22 0 1
0 4 -1 0
0 46 13 20
1
end_operator
begin_operator
unstack b16 b3
0
4
0 24 0 8
0 22 0 1
0 9 -1 0
0 46 14 20
1
end_operator
begin_operator
unstack b16 b4
0
4
0 24 0 8
0 22 0 1
0 16 -1 0
0 46 15 20
1
end_operator
begin_operator
unstack b16 b5
0
4
0 24 0 8
0 22 0 1
0 20 -1 0
0 46 16 20
1
end_operator
begin_operator
unstack b16 b7
0
4
0 24 0 8
0 22 0 1
0 8 -1 0
0 46 18 20
1
end_operator
begin_operator
unstack b17 b11
0
4
0 24 0 9
0 10 -1 0
0 15 0 1
0 44 1 19
1
end_operator
begin_operator
unstack b17 b13
0
4
0 24 0 9
0 12 -1 0
0 15 0 1
0 44 2 19
1
end_operator
begin_operator
unstack b17 b15
0
4
0 24 0 9
0 5 -1 0
0 15 0 1
0 44 3 19
1
end_operator
begin_operator
unstack b17 b16
0
4
0 24 0 9
0 22 -1 0
0 15 0 1
0 44 4 19
1
end_operator
begin_operator
unstack b17 b18
0
4
0 24 0 9
0 15 0 1
0 3 -1 0
0 44 5 19
1
end_operator
begin_operator
unstack b17 b19
0
4
0 24 0 9
0 15 0 1
0 19 -1 0
0 44 6 19
1
end_operator
begin_operator
unstack b17 b2
0
4
0 24 0 9
0 15 0 1
0 13 -1 0
0 44 7 19
1
end_operator
begin_operator
unstack b17 b20
0
4
0 24 0 9
0 15 0 1
0 11 -1 0
0 44 8 19
1
end_operator
begin_operator
unstack b17 b21
0
4
0 24 0 9
0 15 0 1
0 6 -1 0
0 44 9 19
1
end_operator
begin_operator
unstack b17 b22
0
4
0 24 0 9
0 15 0 1
0 17 -1 0
0 44 10 19
1
end_operator
begin_operator
unstack b17 b23
0
4
0 24 0 9
0 15 0 1
0 23 -1 0
0 44 11 19
1
end_operator
begin_operator
unstack b17 b25
0
4
0 24 0 9
0 15 0 1
0 4 -1 0
0 44 12 19
1
end_operator
begin_operator
unstack b17 b3
0
4
0 24 0 9
0 15 0 1
0 9 -1 0
0 44 13 19
1
end_operator
begin_operator
unstack b17 b4
0
4
0 24 0 9
0 15 0 1
0 16 -1 0
0 44 14 19
1
end_operator
begin_operator
unstack b17 b5
0
4
0 24 0 9
0 15 0 1
0 20 -1 0
0 44 15 19
1
end_operator
begin_operator
unstack b17 b6
0
4
0 24 0 9
0 15 0 1
0 21 -1 0
0 44 16 19
1
end_operator
begin_operator
unstack b17 b7
0
4
0 24 0 9
0 15 0 1
0 8 -1 0
0 44 17 19
1
end_operator
begin_operator
unstack b19 b11
0
4
0 24 0 11
0 10 -1 0
0 19 0 1
0 38 0 16
1
end_operator
begin_operator
unstack b19 b14
0
4
0 24 0 11
0 18 -1 0
0 19 0 1
0 38 1 16
1
end_operator
begin_operator
unstack b19 b15
0
4
0 24 0 11
0 5 -1 0
0 19 0 1
0 38 2 16
1
end_operator
begin_operator
unstack b19 b16
0
4
0 24 0 11
0 22 -1 0
0 19 0 1
0 38 3 16
1
end_operator
begin_operator
unstack b19 b17
0
4
0 24 0 11
0 15 -1 0
0 19 0 1
0 38 4 16
1
end_operator
begin_operator
unstack b19 b2
0
4
0 24 0 11
0 19 0 1
0 13 -1 0
0 38 5 16
1
end_operator
begin_operator
unstack b19 b21
0
4
0 24 0 11
0 19 0 1
0 6 -1 0
0 38 6 16
1
end_operator
begin_operator
unstack b19 b22
0
4
0 24 0 11
0 19 0 1
0 17 -1 0
0 38 7 16
1
end_operator
begin_operator
unstack b19 b25
0
4
0 24 0 11
0 19 0 1
0 4 -1 0
0 38 9 16
1
end_operator
begin_operator
unstack b19 b4
0
4
0 24 0 11
0 19 0 1
0 16 -1 0
0 38 10 16
1
end_operator
begin_operator
unstack b19 b5
0
4
0 24 0 11
0 19 0 1
0 20 -1 0
0 38 11 16
1
end_operator
begin_operator
unstack b19 b6
0
4
0 24 0 11
0 19 0 1
0 21 -1 0
0 38 12 16
1
end_operator
begin_operator
unstack b19 b7
0
4
0 24 0 11
0 19 0 1
0 8 -1 0
0 38 13 16
1
end_operator
begin_operator
unstack b19 b9
0
4
0 24 0 11
0 19 0 1
0 2 -1 0
0 38 14 16
1
end_operator
begin_operator
unstack b2 b10
0
4
0 24 0 12
0 14 -1 0
0 13 0 1
0 41 0 18
1
end_operator
begin_operator
unstack b2 b11
0
4
0 24 0 12
0 10 -1 0
0 13 0 1
0 41 1 18
1
end_operator
begin_operator
unstack b2 b13
0
4
0 24 0 12
0 12 -1 0
0 13 0 1
0 41 2 18
1
end_operator
begin_operator
unstack b2 b15
0
4
0 24 0 12
0 5 -1 0
0 13 0 1
0 41 3 18
1
end_operator
begin_operator
unstack b2 b16
0
4
0 24 0 12
0 22 -1 0
0 13 0 1
0 41 4 18
1
end_operator
begin_operator
unstack b2 b17
0
4
0 24 0 12
0 15 -1 0
0 13 0 1
0 41 5 18
1
end_operator
begin_operator
unstack b2 b18
0
4
0 24 0 12
0 3 -1 0
0 13 0 1
0 41 6 18
1
end_operator
begin_operator
unstack b2 b19
0
4
0 24 0 12
0 19 -1 0
0 13 0 1
0 41 7 18
1
end_operator
begin_operator
unstack b2 b20
0
4
0 24 0 12
0 13 0 1
0 11 -1 0
0 41 8 18
1
end_operator
begin_operator
unstack b2 b21
0
4
0 24 0 12
0 13 0 1
0 6 -1 0
0 41 9 18
1
end_operator
begin_operator
unstack b2 b23
0
4
0 24 0 12
0 13 0 1
0 23 -1 0
0 41 10 18
1
end_operator
begin_operator
unstack b2 b25
0
4
0 24 0 12
0 13 0 1
0 4 -1 0
0 41 11 18
1
end_operator
begin_operator
unstack b2 b4
0
4
0 24 0 12
0 13 0 1
0 16 -1 0
0 41 12 18
1
end_operator
begin_operator
unstack b2 b5
0
4
0 24 0 12
0 13 0 1
0 20 -1 0
0 41 13 18
1
end_operator
begin_operator
unstack b2 b6
0
4
0 24 0 12
0 13 0 1
0 21 -1 0
0 41 14 18
1
end_operator
begin_operator
unstack b2 b7
0
4
0 24 0 12
0 13 0 1
0 8 -1 0
0 41 15 18
1
end_operator
begin_operator
unstack b20 b11
0
4
0 24 0 13
0 10 -1 0
0 11 0 1
0 39 0 17
1
end_operator
begin_operator
unstack b20 b13
0
4
0 24 0 13
0 12 -1 0
0 11 0 1
0 39 1 17
1
end_operator
begin_operator
unstack b20 b14
0
4
0 24 0 13
0 18 -1 0
0 11 0 1
0 39 2 17
1
end_operator
begin_operator
unstack b20 b15
0
4
0 24 0 13
0 5 -1 0
0 11 0 1
0 39 3 17
1
end_operator
begin_operator
unstack b20 b16
0
4
0 24 0 13
0 22 -1 0
0 11 0 1
0 39 4 17
1
end_operator
begin_operator
unstack b20 b18
0
4
0 24 0 13
0 3 -1 0
0 11 0 1
0 39 6 17
1
end_operator
begin_operator
unstack b20 b19
0
4
0 24 0 13
0 19 -1 0
0 11 0 1
0 39 7 17
1
end_operator
begin_operator
unstack b20 b21
0
4
0 24 0 13
0 11 0 1
0 6 -1 0
0 39 8 17
1
end_operator
begin_operator
unstack b20 b22
0
4
0 24 0 13
0 11 0 1
0 17 -1 0
0 39 9 17
1
end_operator
begin_operator
unstack b20 b23
0
4
0 24 0 13
0 11 0 1
0 23 -1 0
0 39 10 17
1
end_operator
begin_operator
unstack b20 b25
0
4
0 24 0 13
0 11 0 1
0 4 -1 0
0 39 11 17
1
end_operator
begin_operator
unstack b20 b4
0
4
0 24 0 13
0 11 0 1
0 16 -1 0
0 39 12 17
1
end_operator
begin_operator
unstack b20 b6
0
4
0 24 0 13
0 11 0 1
0 21 -1 0
0 39 13 17
1
end_operator
begin_operator
unstack b20 b7
0
4
0 24 0 13
0 11 0 1
0 8 -1 0
0 39 14 17
1
end_operator
begin_operator
unstack b20 b9
0
4
0 24 0 13
0 11 0 1
0 2 -1 0
0 39 15 17
1
end_operator
begin_operator
unstack b21 b1
0
4
0 24 0 14
0 1 -1 0
0 6 0 1
0 26 0 3
1
end_operator
begin_operator
unstack b22 b1
0
4
0 24 0 15
0 1 -1 0
0 17 0 1
0 47 0 20
1
end_operator
begin_operator
unstack b22 b10
0
4
0 24 0 15
0 14 -1 0
0 17 0 1
0 47 1 20
1
end_operator
begin_operator
unstack b22 b13
0
4
0 24 0 15
0 12 -1 0
0 17 0 1
0 47 2 20
1
end_operator
begin_operator
unstack b22 b14
0
4
0 24 0 15
0 18 -1 0
0 17 0 1
0 47 3 20
1
end_operator
begin_operator
unstack b22 b15
0
4
0 24 0 15
0 5 -1 0
0 17 0 1
0 47 4 20
1
end_operator
begin_operator
unstack b22 b16
0
4
0 24 0 15
0 22 -1 0
0 17 0 1
0 47 5 20
1
end_operator
begin_operator
unstack b22 b17
0
4
0 24 0 15
0 15 -1 0
0 17 0 1
0 47 6 20
1
end_operator
begin_operator
unstack b22 b19
0
4
0 24 0 15
0 19 -1 0
0 17 0 1
0 47 8 20
1
end_operator
begin_operator
unstack b22 b2
0
4
0 24 0 15
0 13 -1 0
0 17 0 1
0 47 9 20
1
end_operator
begin_operator
unstack b22 b20
0
4
0 24 0 15
0 11 -1 0
0 17 0 1
0 47 10 20
1
end_operator
begin_operator
unstack b22 b21
0
4
0 24 0 15
0 6 -1 0
0 17 0 1
0 47 11 20
1
end_operator
begin_operator
unstack b22 b23
0
4
0 24 0 15
0 17 0 1
0 23 -1 0
0 47 12 20
1
end_operator
begin_operator
unstack b22 b25
0
4
0 24 0 15
0 17 0 1
0 4 -1 0
0 47 13 20
1
end_operator
begin_operator
unstack b22 b3
0
4
0 24 0 15
0 17 0 1
0 9 -1 0
0 47 14 20
1
end_operator
begin_operator
unstack b22 b5
0
4
0 24 0 15
0 17 0 1
0 20 -1 0
0 47 15 20
1
end_operator
begin_operator
unstack b22 b6
0
4
0 24 0 15
0 17 0 1
0 21 -1 0
0 47 16 20
1
end_operator
begin_operator
unstack b22 b7
0
4
0 24 0 15
0 17 0 1
0 8 -1 0
0 47 17 20
1
end_operator
begin_operator
unstack b22 b9
0
4
0 24 0 15
0 17 0 1
0 2 -1 0
0 47 18 20
1
end_operator
begin_operator
unstack b23 b10
0
4
0 24 0 16
0 14 -1 0
0 23 0 1
0 48 0 20
1
end_operator
begin_operator
unstack b23 b11
0
4
0 24 0 16
0 10 -1 0
0 23 0 1
0 48 1 20
1
end_operator
begin_operator
unstack b23 b13
0
4
0 24 0 16
0 12 -1 0
0 23 0 1
0 48 2 20
1
end_operator
begin_operator
unstack b23 b14
0
4
0 24 0 16
0 18 -1 0
0 23 0 1
0 48 3 20
1
end_operator
begin_operator
unstack b23 b15
0
4
0 24 0 16
0 5 -1 0
0 23 0 1
0 48 4 20
1
end_operator
begin_operator
unstack b23 b16
0
4
0 24 0 16
0 22 -1 0
0 23 0 1
0 48 5 20
1
end_operator
begin_operator
unstack b23 b17
0
4
0 24 0 16
0 15 -1 0
0 23 0 1
0 48 6 20
1
end_operator
begin_operator
unstack b23 b18
0
4
0 24 0 16
0 3 -1 0
0 23 0 1
0 48 7 20
1
end_operator
begin_operator
unstack b23 b19
0
4
0 24 0 16
0 19 -1 0
0 23 0 1
0 48 8 20
1
end_operator
begin_operator
unstack b23 b2
0
4
0 24 0 16
0 13 -1 0
0 23 0 1
0 48 9 20
1
end_operator
begin_operator
unstack b23 b20
0
4
0 24 0 16
0 11 -1 0
0 23 0 1
0 48 10 20
1
end_operator
begin_operator
unstack b23 b21
0
4
0 24 0 16
0 6 -1 0
0 23 0 1
0 48 11 20
1
end_operator
begin_operator
unstack b23 b22
0
4
0 24 0 16
0 17 -1 0
0 23 0 1
0 48 12 20
1
end_operator
begin_operator
unstack b23 b25
0
4
0 24 0 16
0 23 0 1
0 4 -1 0
0 48 13 20
1
end_operator
begin_operator
unstack b23 b3
0
4
0 24 0 16
0 23 0 1
0 9 -1 0
0 48 14 20
1
end_operator
begin_operator
unstack b23 b5
0
4
0 24 0 16
0 23 0 1
0 20 -1 0
0 48 15 20
1
end_operator
begin_operator
unstack b23 b6
0
4
0 24 0 16
0 23 0 1
0 21 -1 0
0 48 16 20
1
end_operator
begin_operator
unstack b23 b9
0
4
0 24 0 16
0 23 0 1
0 2 -1 0
0 48 18 20
1
end_operator
begin_operator
unstack b25 b9
0
4
0 24 0 17
0 4 0 1
0 2 -1 0
0 27 1 3
1
end_operator
begin_operator
unstack b3 b10
0
4
0 24 0 18
0 14 -1 0
0 9 0 1
0 37 0 16
1
end_operator
begin_operator
unstack b3 b11
0
4
0 24 0 18
0 10 -1 0
0 9 0 1
0 37 1 16
1
end_operator
begin_operator
unstack b3 b13
0
4
0 24 0 18
0 12 -1 0
0 9 0 1
0 37 2 16
1
end_operator
begin_operator
unstack b3 b15
0
4
0 24 0 18
0 5 -1 0
0 9 0 1
0 37 3 16
1
end_operator
begin_operator
unstack b3 b18
0
4
0 24 0 18
0 3 -1 0
0 9 0 1
0 37 5 16
1
end_operator
begin_operator
unstack b3 b19
0
4
0 24 0 18
0 19 -1 0
0 9 0 1
0 37 6 16
1
end_operator
begin_operator
unstack b3 b20
0
4
0 24 0 18
0 11 -1 0
0 9 0 1
0 37 7 16
1
end_operator
begin_operator
unstack b3 b21
0
4
0 24 0 18
0 6 -1 0
0 9 0 1
0 37 8 16
1
end_operator
begin_operator
unstack b3 b23
0
4
0 24 0 18
0 23 -1 0
0 9 0 1
0 37 9 16
1
end_operator
begin_operator
unstack b3 b25
0
4
0 24 0 18
0 4 -1 0
0 9 0 1
0 37 10 16
1
end_operator
begin_operator
unstack b3 b4
0
4
0 24 0 18
0 9 0 1
0 16 -1 0
0 37 11 16
1
end_operator
begin_operator
unstack b3 b5
0
4
0 24 0 18
0 9 0 1
0 20 -1 0
0 37 12 16
1
end_operator
begin_operator
unstack b3 b7
0
4
0 24 0 18
0 9 0 1
0 8 -1 0
0 37 13 16
1
end_operator
begin_operator
unstack b3 b9
0
4
0 24 0 18
0 9 0 1
0 2 -1 0
0 37 14 16
1
end_operator
begin_operator
unstack b4 b15
0
4
0 24 0 19
0 5 -1 0
0 16 0 1
0 36 1 15
1
end_operator
begin_operator
unstack b4 b16
0
4
0 24 0 19
0 22 -1 0
0 16 0 1
0 36 2 15
1
end_operator
begin_operator
unstack b4 b17
0
4
0 24 0 19
0 15 -1 0
0 16 0 1
0 36 3 15
1
end_operator
begin_operator
unstack b4 b18
0
4
0 24 0 19
0 3 -1 0
0 16 0 1
0 36 4 15
1
end_operator
begin_operator
unstack b4 b19
0
4
0 24 0 19
0 19 -1 0
0 16 0 1
0 36 5 15
1
end_operator
begin_operator
unstack b4 b21
0
4
0 24 0 19
0 6 -1 0
0 16 0 1
0 36 6 15
1
end_operator
begin_operator
unstack b4 b22
0
4
0 24 0 19
0 17 -1 0
0 16 0 1
0 36 7 15
1
end_operator
begin_operator
unstack b4 b23
0
4
0 24 0 19
0 23 -1 0
0 16 0 1
0 36 8 15
1
end_operator
begin_operator
unstack b4 b3
0
4
0 24 0 19
0 9 -1 0
0 16 0 1
0 36 9 15
1
end_operator
begin_operator
unstack b4 b5
0
4
0 24 0 19
0 16 0 1
0 20 -1 0
0 36 10 15
1
end_operator
begin_operator
unstack b4 b6
0
4
0 24 0 19
0 16 0 1
0 21 -1 0
0 36 11 15
1
end_operator
begin_operator
unstack b4 b7
0
4
0 24 0 19
0 16 0 1
0 8 -1 0
0 36 12 15
1
end_operator
begin_operator
unstack b4 b9
0
4
0 24 0 19
0 16 0 1
0 2 -1 0
0 36 13 15
1
end_operator
begin_operator
unstack b5 b10
0
4
0 24 0 20
0 14 -1 0
0 20 0 1
0 42 0 18
1
end_operator
begin_operator
unstack b5 b11
0
4
0 24 0 20
0 10 -1 0
0 20 0 1
0 42 1 18
1
end_operator
begin_operator
unstack b5 b13
0
4
0 24 0 20
0 12 -1 0
0 20 0 1
0 42 2 18
1
end_operator
begin_operator
unstack b5 b15
0
4
0 24 0 20
0 5 -1 0
0 20 0 1
0 42 3 18
1
end_operator
begin_operator
unstack b5 b16
0
4
0 24 0 20
0 22 -1 0
0 20 0 1
0 42 4 18
1
end_operator
begin_operator
unstack b5 b18
0
4
0 24 0 20
0 3 -1 0
0 20 0 1
0 42 5 18
1
end_operator
begin_operator
unstack b5 b19
0
4
0 24 0 20
0 19 -1 0
0 20 0 1
0 42 6 18
1
end_operator
begin_operator
unstack b5 b2
0
4
0 24 0 20
0 13 -1 0
0 20 0 1
0 42 7 18
1
end_operator
begin_operator
unstack b5 b21
0
4
0 24 0 20
0 6 -1 0
0 20 0 1
0 42 9 18
1
end_operator
begin_operator
unstack b5 b23
0
4
0 24 0 20
0 23 -1 0
0 20 0 1
0 42 10 18
1
end_operator
begin_operator
unstack b5 b25
0
4
0 24 0 20
0 4 -1 0
0 20 0 1
0 42 11 18
1
end_operator
begin_operator
unstack b5 b3
0
4
0 24 0 20
0 9 -1 0
0 20 0 1
0 42 12 18
1
end_operator
begin_operator
unstack b5 b4
0
4
0 24 0 20
0 16 -1 0
0 20 0 1
0 42 13 18
1
end_operator
begin_operator
unstack b5 b6
0
4
0 24 0 20
0 20 0 1
0 21 -1 0
0 42 14 18
1
end_operator
begin_operator
unstack b5 b7
0
4
0 24 0 20
0 20 0 1
0 8 -1 0
0 42 15 18
1
end_operator
begin_operator
unstack b5 b9
0
4
0 24 0 20
0 20 0 1
0 2 -1 0
0 42 16 18
1
end_operator
begin_operator
unstack b6 b10
0
4
0 24 0 21
0 14 -1 0
0 21 0 1
0 40 1 17
1
end_operator
begin_operator
unstack b6 b13
0
4
0 24 0 21
0 12 -1 0
0 21 0 1
0 40 2 17
1
end_operator
begin_operator
unstack b6 b14
0
4
0 24 0 21
0 18 -1 0
0 21 0 1
0 40 3 17
1
end_operator
begin_operator
unstack b6 b15
0
4
0 24 0 21
0 5 -1 0
0 21 0 1
0 40 4 17
1
end_operator
begin_operator
unstack b6 b16
0
4
0 24 0 21
0 22 -1 0
0 21 0 1
0 40 5 17
1
end_operator
begin_operator
unstack b6 b18
0
4
0 24 0 21
0 3 -1 0
0 21 0 1
0 40 6 17
1
end_operator
begin_operator
unstack b6 b2
0
4
0 24 0 21
0 13 -1 0
0 21 0 1
0 40 7 17
1
end_operator
begin_operator
unstack b6 b22
0
4
0 24 0 21
0 17 -1 0
0 21 0 1
0 40 8 17
1
end_operator
begin_operator
unstack b6 b23
0
4
0 24 0 21
0 23 -1 0
0 21 0 1
0 40 9 17
1
end_operator
begin_operator
unstack b6 b24
0
4
0 24 0 21
0 0 -1 0
0 21 0 1
0 40 10 17
1
end_operator
begin_operator
unstack b6 b25
0
4
0 24 0 21
0 4 -1 0
0 21 0 1
0 40 11 17
1
end_operator
begin_operator
unstack b6 b3
0
4
0 24 0 21
0 9 -1 0
0 21 0 1
0 40 12 17
1
end_operator
begin_operator
unstack b6 b5
0
4
0 24 0 21
0 20 -1 0
0 21 0 1
0 40 13 17
1
end_operator
begin_operator
unstack b6 b7
0
4
0 24 0 21
0 21 0 1
0 8 -1 0
0 40 14 17
1
end_operator
begin_operator
unstack b6 b9
0
4
0 24 0 21
0 21 0 1
0 2 -1 0
0 40 15 17
1
end_operator
begin_operator
unstack b7 b15
0
4
0 24 0 22
0 5 -1 0
0 8 0 1
0 33 0 9
1
end_operator
begin_operator
unstack b7 b16
0
4
0 24 0 22
0 22 -1 0
0 8 0 1
0 33 1 9
1
end_operator
begin_operator
unstack b7 b21
0
4
0 24 0 22
0 6 -1 0
0 8 0 1
0 33 2 9
1
end_operator
begin_operator
unstack b7 b23
0
4
0 24 0 22
0 23 -1 0
0 8 0 1
0 33 4 9
1
end_operator
begin_operator
unstack b7 b4
0
4
0 24 0 22
0 16 -1 0
0 8 0 1
0 33 5 9
1
end_operator
begin_operator
unstack b7 b6
0
4
0 24 0 22
0 21 -1 0
0 8 0 1
0 33 6 9
1
end_operator
begin_operator
unstack b7 b9
0
4
0 24 0 22
0 8 0 1
0 2 -1 0
0 33 7 9
1
end_operator
begin_operator
unstack b8 b10
0
4
0 24 0 23
0 14 -1 0
0 7 0 1
0 49 0 20
1
end_operator
begin_operator
unstack b8 b11
0
4
0 24 0 23
0 10 -1 0
0 7 0 1
0 49 1 20
1
end_operator
begin_operator
unstack b8 b12
0
4
0 24 0 23
0 32 -1 0
0 7 0 1
0 49 2 20
1
end_operator
begin_operator
unstack b8 b13
0
4
0 24 0 23
0 12 -1 0
0 7 0 1
0 49 3 20
1
end_operator
begin_operator
unstack b8 b15
0
4
0 24 0 23
0 5 -1 0
0 7 0 1
0 49 4 20
1
end_operator
begin_operator
unstack b8 b16
0
4
0 24 0 23
0 22 -1 0
0 7 0 1
0 49 5 20
1
end_operator
begin_operator
unstack b8 b17
0
4
0 24 0 23
0 15 -1 0
0 7 0 1
0 49 6 20
1
end_operator
begin_operator
unstack b8 b18
0
4
0 24 0 23
0 3 -1 0
0 7 0 1
0 49 7 20
1
end_operator
begin_operator
unstack b8 b19
0
4
0 24 0 23
0 19 -1 0
0 7 0 1
0 49 8 20
1
end_operator
begin_operator
unstack b8 b2
0
4
0 24 0 23
0 13 -1 0
0 7 0 1
0 49 9 20
1
end_operator
begin_operator
unstack b8 b20
0
4
0 24 0 23
0 11 -1 0
0 7 0 1
0 49 10 20
1
end_operator
begin_operator
unstack b8 b21
0
4
0 24 0 23
0 6 -1 0
0 7 0 1
0 49 11 20
1
end_operator
begin_operator
unstack b8 b23
0
4
0 24 0 23
0 23 -1 0
0 7 0 1
0 49 12 20
1
end_operator
begin_operator
unstack b8 b25
0
4
0 24 0 23
0 4 -1 0
0 7 0 1
0 49 13 20
1
end_operator
begin_operator
unstack b8 b3
0
4
0 24 0 23
0 9 -1 0
0 7 0 1
0 49 14 20
1
end_operator
begin_operator
unstack b8 b4
0
4
0 24 0 23
0 16 -1 0
0 7 0 1
0 49 15 20
1
end_operator
begin_operator
unstack b8 b5
0
4
0 24 0 23
0 20 -1 0
0 7 0 1
0 49 16 20
1
end_operator
begin_operator
unstack b8 b6
0
4
0 24 0 23
0 21 -1 0
0 7 0 1
0 49 17 20
1
end_operator
begin_operator
unstack b8 b9
0
4
0 24 0 23
0 7 0 1
0 2 -1 0
0 49 19 20
1
end_operator
0
