begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var0
-1
2
Atom on-table(b3)
NegatedAtom on-table(b3)
end_variable
begin_variable
var1
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var2
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var3
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var5
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var4
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var8
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var7
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var6
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var9
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var10
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var11
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var12
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var13
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var14
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var15
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var16
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var17
-1
8
Atom arm-empty()
Atom holding(b14)
Atom holding(b15)
Atom holding(b18)
Atom holding(b2)
Atom holding(b3)
Atom holding(b6)
<none of those>
end_variable
begin_variable
var18
-1
3
Atom on(b14, b7)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var19
-1
3
Atom on(b2, b13)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var20
-1
4
Atom on(b6, b16)
Atom on(b6, b18)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var21
-1
3
Atom on(b18, b2)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom holding(b12)
Atom on(b12, b11)
Atom on(b12, b3)
Atom on-table(b12)
end_variable
begin_variable
var36
-1
4
Atom holding(b16)
Atom on(b16, b14)
Atom on(b16, b20)
Atom on-table(b16)
end_variable
begin_variable
var22
-1
6
Atom holding(b20)
Atom on(b20, b16)
Atom on(b20, b17)
Atom on(b20, b2)
Atom on(b20, b7)
Atom on-table(b20)
end_variable
begin_variable
var33
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var32
-1
5
Atom holding(b19)
Atom on(b19, b15)
Atom on(b19, b2)
Atom on(b19, b8)
Atom on-table(b19)
end_variable
begin_variable
var23
-1
12
Atom holding(b10)
Atom on(b10, b1)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b19)
Atom on(b10, b4)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var24
-1
12
Atom holding(b11)
Atom on(b11, b1)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b20)
Atom on(b11, b6)
Atom on(b11, b8)
Atom on-table(b11)
end_variable
begin_variable
var30
-1
13
Atom holding(b1)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b20)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on-table(b1)
end_variable
begin_variable
var29
-1
13
Atom holding(b17)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b4)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b9)
Atom on-table(b17)
end_variable
begin_variable
var25
-1
14
Atom holding(b8)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b13)
Atom on(b8, b15)
Atom on(b8, b16)
Atom on(b8, b17)
Atom on(b8, b19)
Atom on(b8, b2)
Atom on(b8, b20)
Atom on(b8, b4)
Atom on(b8, b6)
Atom on(b8, b9)
Atom on-table(b8)
end_variable
begin_variable
var26
-1
14
Atom holding(b9)
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b17)
Atom on(b9, b19)
Atom on(b9, b20)
Atom on(b9, b4)
Atom on(b9, b6)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var34
-1
14
Atom holding(b5)
Atom on(b5, b10)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b15)
Atom on(b5, b17)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b4)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
end_variable
begin_variable
var35
-1
4
Atom clear(b5)
Atom on(b15, b5)
Atom on(b3, b5)
<none of those>
end_variable
begin_variable
var31
-1
15
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b17)
Atom on(b4, b18)
Atom on(b4, b19)
Atom on(b4, b20)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
end_variable
begin_variable
var37
-1
16
Atom holding(b7)
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b17)
Atom on(b7, b19)
Atom on(b7, b2)
Atom on(b7, b20)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
end_variable
begin_variable
var28
-1
17
Atom holding(b13)
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b4)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
end_variable
begin_variable
var39
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var38
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var40
-1
2
Atom on-table(b15)
NegatedAtom on-table(b15)
end_variable
2060
begin_mutex_group
21
17 0
17 1
17 2
17 3
17 4
17 5
17 6
29 0
27 0
28 0
22 0
37 0
23 0
30 0
26 0
24 0
35 0
33 0
36 0
31 0
32 0
end_mutex_group
begin_mutex_group
8
11 0
29 0
27 1
28 1
37 1
35 1
36 1
32 1
end_mutex_group
begin_mutex_group
7
10 0
27 0
37 2
35 2
33 1
36 2
32 2
end_mutex_group
begin_mutex_group
8
9 0
29 1
28 0
22 1
35 3
36 3
31 1
32 3
end_mutex_group
begin_mutex_group
11
7 0
29 2
27 2
28 2
22 0
37 3
35 4
33 2
36 4
31 2
32 4
end_mutex_group
begin_mutex_group
12
16 0
29 3
27 3
28 3
37 0
30 1
35 5
33 3
36 5
31 3
32 5
19 0
end_mutex_group
begin_mutex_group
7
17 1
1 0
29 4
37 4
23 1
30 2
36 6
end_mutex_group
begin_mutex_group
8
17 2
2 0
37 5
30 3
26 1
33 4
36 7
31 4
end_mutex_group
begin_mutex_group
11
6 0
29 5
27 4
28 4
37 6
23 0
30 4
24 1
36 8
31 5
20 0
end_mutex_group
begin_mutex_group
12
39 0
29 6
27 5
28 5
37 7
30 0
24 2
35 6
33 5
36 9
31 6
32 6
end_mutex_group
begin_mutex_group
9
17 3
3 0
29 7
28 6
37 8
30 5
35 7
33 6
20 1
end_mutex_group
begin_mutex_group
11
38 0
29 8
27 6
28 7
37 9
26 0
35 8
33 7
36 10
31 7
32 7
end_mutex_group
begin_mutex_group
10
17 4
5 0
37 10
30 6
26 2
24 3
33 8
36 11
31 8
21 0
end_mutex_group
begin_mutex_group
11
8 0
29 9
28 8
23 2
30 7
24 0
35 9
33 9
36 12
31 9
32 8
end_mutex_group
begin_mutex_group
3
17 5
25 0
22 2
end_mutex_group
begin_mutex_group
8
13 0
27 7
37 11
30 8
35 0
33 10
31 10
32 9
end_mutex_group
begin_mutex_group
4
34 0
34 1
34 2
33 0
end_mutex_group
begin_mutex_group
8
17 6
4 0
28 9
37 12
30 9
35 10
31 11
32 10
end_mutex_group
begin_mutex_group
10
15 0
29 10
27 8
37 13
30 10
24 4
35 11
36 0
32 11
18 0
end_mutex_group
begin_mutex_group
11
14 0
29 11
27 9
28 10
37 14
26 3
35 12
33 11
36 13
31 0
32 12
end_mutex_group
begin_mutex_group
9
12 0
27 10
37 15
30 11
35 13
33 12
36 14
31 12
32 0
end_mutex_group
begin_mutex_group
3
17 1
18 0
18 1
end_mutex_group
begin_mutex_group
3
17 2
34 1
40 0
end_mutex_group
begin_mutex_group
3
17 3
21 0
21 1
end_mutex_group
begin_mutex_group
3
17 4
19 0
19 1
end_mutex_group
begin_mutex_group
3
17 5
34 2
0 0
end_mutex_group
begin_mutex_group
4
17 6
20 0
20 1
20 2
end_mutex_group
begin_mutex_group
2
0 1
17 4
end_mutex_group
begin_mutex_group
2
0 1
19 0
end_mutex_group
begin_mutex_group
2
0 1
19 2
end_mutex_group
begin_mutex_group
2
0 1
24 3
end_mutex_group
begin_mutex_group
2
0 1
22 2
end_mutex_group
begin_mutex_group
2
0 1
37 3
end_mutex_group
begin_mutex_group
2
0 1
23 2
end_mutex_group
begin_mutex_group
2
1 0
17 2
end_mutex_group
begin_mutex_group
2
1 0
18 2
end_mutex_group
begin_mutex_group
2
1 0
28 1
end_mutex_group
begin_mutex_group
2
1 0
31 1
end_mutex_group
begin_mutex_group
2
1 0
30 3
end_mutex_group
begin_mutex_group
2
1 0
33 7
end_mutex_group
begin_mutex_group
2
1 0
34 1
end_mutex_group
begin_mutex_group
2
3 0
17 1
end_mutex_group
begin_mutex_group
2
3 0
17 2
end_mutex_group
begin_mutex_group
2
3 0
18 0
end_mutex_group
begin_mutex_group
2
3 0
18 2
end_mutex_group
begin_mutex_group
2
3 0
21 2
end_mutex_group
begin_mutex_group
2
3 0
27 10
end_mutex_group
begin_mutex_group
2
3 0
28 1
end_mutex_group
begin_mutex_group
2
3 0
31 1
end_mutex_group
begin_mutex_group
2
3 0
32 9
end_mutex_group
begin_mutex_group
2
3 0
30 3
end_mutex_group
begin_mutex_group
2
3 0
29 4
end_mutex_group
begin_mutex_group
2
3 0
33 7
end_mutex_group
begin_mutex_group
2
3 0
34 1
end_mutex_group
begin_mutex_group
2
3 0
36 2
end_mutex_group
begin_mutex_group
2
5 0
19 2
end_mutex_group
begin_mutex_group
2
5 0
23 2
end_mutex_group
begin_mutex_group
2
4 0
17 1
end_mutex_group
begin_mutex_group
2
4 0
17 2
end_mutex_group
begin_mutex_group
2
4 0
18 0
end_mutex_group
begin_mutex_group
2
4 0
18 2
end_mutex_group
begin_mutex_group
2
4 0
20 3
end_mutex_group
begin_mutex_group
2
4 0
27 10
end_mutex_group
begin_mutex_group
2
4 0
28 1
end_mutex_group
begin_mutex_group
2
4 0
31 1
end_mutex_group
begin_mutex_group
2
4 0
32 9
end_mutex_group
begin_mutex_group
2
4 0
30 3
end_mutex_group
begin_mutex_group
2
4 0
29 4
end_mutex_group
begin_mutex_group
2
4 0
33 7
end_mutex_group
begin_mutex_group
2
4 0
34 1
end_mutex_group
begin_mutex_group
2
4 0
36 2
end_mutex_group
begin_mutex_group
2
7 0
17 4
end_mutex_group
begin_mutex_group
2
7 0
19 0
end_mutex_group
begin_mutex_group
2
7 0
19 2
end_mutex_group
begin_mutex_group
2
7 0
24 3
end_mutex_group
begin_mutex_group
2
7 0
23 2
end_mutex_group
begin_mutex_group
2
9 0
17 2
end_mutex_group
begin_mutex_group
2
9 0
30 3
end_mutex_group
begin_mutex_group
2
9 0
33 7
end_mutex_group
begin_mutex_group
2
9 0
34 1
end_mutex_group
begin_mutex_group
2
10 0
17 1
end_mutex_group
begin_mutex_group
2
10 0
17 2
end_mutex_group
begin_mutex_group
2
10 0
18 0
end_mutex_group
begin_mutex_group
2
10 0
18 2
end_mutex_group
begin_mutex_group
2
10 0
28 1
end_mutex_group
begin_mutex_group
2
10 0
31 1
end_mutex_group
begin_mutex_group
2
10 0
30 3
end_mutex_group
begin_mutex_group
2
10 0
29 4
end_mutex_group
begin_mutex_group
2
10 0
33 7
end_mutex_group
begin_mutex_group
2
10 0
34 1
end_mutex_group
begin_mutex_group
2
11 0
17 2
end_mutex_group
begin_mutex_group
2
11 0
31 1
end_mutex_group
begin_mutex_group
2
11 0
30 3
end_mutex_group
begin_mutex_group
2
11 0
33 7
end_mutex_group
begin_mutex_group
2
11 0
34 1
end_mutex_group
begin_mutex_group
2
12 0
17 1
end_mutex_group
begin_mutex_group
2
12 0
17 2
end_mutex_group
begin_mutex_group
2
12 0
18 0
end_mutex_group
begin_mutex_group
2
12 0
18 2
end_mutex_group
begin_mutex_group
2
12 0
28 1
end_mutex_group
begin_mutex_group
2
12 0
31 1
end_mutex_group
begin_mutex_group
2
12 0
30 3
end_mutex_group
begin_mutex_group
2
12 0
29 4
end_mutex_group
begin_mutex_group
2
12 0
33 7
end_mutex_group
begin_mutex_group
2
12 0
34 1
end_mutex_group
begin_mutex_group
2
12 0
36 2
end_mutex_group
begin_mutex_group
2
13 0
17 1
end_mutex_group
begin_mutex_group
2
13 0
17 2
end_mutex_group
begin_mutex_group
2
13 0
18 0
end_mutex_group
begin_mutex_group
2
13 0
18 2
end_mutex_group
begin_mutex_group
2
13 0
27 10
end_mutex_group
begin_mutex_group
2
13 0
28 1
end_mutex_group
begin_mutex_group
2
13 0
31 1
end_mutex_group
begin_mutex_group
2
13 0
30 3
end_mutex_group
begin_mutex_group
2
13 0
29 4
end_mutex_group
begin_mutex_group
2
13 0
33 7
end_mutex_group
begin_mutex_group
2
13 0
34 1
end_mutex_group
begin_mutex_group
2
13 0
36 2
end_mutex_group
begin_mutex_group
2
14 0
17 2
end_mutex_group
begin_mutex_group
2
14 0
30 3
end_mutex_group
begin_mutex_group
2
14 0
33 7
end_mutex_group
begin_mutex_group
2
14 0
34 1
end_mutex_group
begin_mutex_group
2
15 0
17 2
end_mutex_group
begin_mutex_group
2
15 0
28 1
end_mutex_group
begin_mutex_group
2
15 0
31 1
end_mutex_group
begin_mutex_group
2
15 0
30 3
end_mutex_group
begin_mutex_group
2
15 0
29 4
end_mutex_group
begin_mutex_group
2
15 0
33 7
end_mutex_group
begin_mutex_group
2
15 0
34 1
end_mutex_group
begin_mutex_group
2
15 1
17 1
end_mutex_group
begin_mutex_group
2
15 1
18 2
end_mutex_group
begin_mutex_group
2
16 0
24 3
end_mutex_group
begin_mutex_group
2
16 0
23 2
end_mutex_group
begin_mutex_group
2
16 1
17 4
end_mutex_group
begin_mutex_group
2
16 1
19 2
end_mutex_group
begin_mutex_group
2
17 0
18 2
end_mutex_group
begin_mutex_group
2
17 0
19 2
end_mutex_group
begin_mutex_group
2
17 0
20 3
end_mutex_group
begin_mutex_group
2
17 0
21 2
end_mutex_group
begin_mutex_group
2
17 0
34 3
end_mutex_group
begin_mutex_group
2
17 1
19 2
end_mutex_group
begin_mutex_group
2
17 1
20 0
end_mutex_group
begin_mutex_group
2
17 1
20 2
end_mutex_group
begin_mutex_group
2
17 1
20 3
end_mutex_group
begin_mutex_group
2
17 1
21 0
end_mutex_group
begin_mutex_group
2
17 1
21 2
end_mutex_group
begin_mutex_group
2
17 1
24 4
end_mutex_group
begin_mutex_group
2
17 1
27 1
end_mutex_group
begin_mutex_group
2
17 1
27 2
end_mutex_group
begin_mutex_group
2
17 1
27 3
end_mutex_group
begin_mutex_group
2
17 1
27 4
end_mutex_group
begin_mutex_group
2
17 1
27 5
end_mutex_group
begin_mutex_group
2
17 1
27 6
end_mutex_group
begin_mutex_group
2
17 1
27 7
end_mutex_group
begin_mutex_group
2
17 1
27 8
end_mutex_group
begin_mutex_group
2
17 1
27 9
end_mutex_group
begin_mutex_group
2
17 1
27 11
end_mutex_group
begin_mutex_group
2
17 1
28 1
end_mutex_group
begin_mutex_group
2
17 1
28 6
end_mutex_group
begin_mutex_group
2
17 1
28 9
end_mutex_group
begin_mutex_group
2
17 1
31 1
end_mutex_group
begin_mutex_group
2
17 1
31 10
end_mutex_group
begin_mutex_group
2
17 1
31 11
end_mutex_group
begin_mutex_group
2
17 1
31 12
end_mutex_group
begin_mutex_group
2
17 1
32 1
end_mutex_group
begin_mutex_group
2
17 1
32 2
end_mutex_group
begin_mutex_group
2
17 1
32 3
end_mutex_group
begin_mutex_group
2
17 1
32 4
end_mutex_group
begin_mutex_group
2
17 1
32 5
end_mutex_group
begin_mutex_group
2
17 1
32 6
end_mutex_group
begin_mutex_group
2
17 1
32 7
end_mutex_group
begin_mutex_group
2
17 1
32 8
end_mutex_group
begin_mutex_group
2
17 1
32 10
end_mutex_group
begin_mutex_group
2
17 1
32 11
end_mutex_group
begin_mutex_group
2
17 1
32 12
end_mutex_group
begin_mutex_group
2
17 1
32 13
end_mutex_group
begin_mutex_group
2
17 1
37 2
end_mutex_group
begin_mutex_group
2
17 1
37 8
end_mutex_group
begin_mutex_group
2
17 1
37 11
end_mutex_group
begin_mutex_group
2
17 1
37 12
end_mutex_group
begin_mutex_group
2
17 1
37 13
end_mutex_group
begin_mutex_group
2
17 1
37 15
end_mutex_group
begin_mutex_group
2
17 1
30 3
end_mutex_group
begin_mutex_group
2
17 1
30 5
end_mutex_group
begin_mutex_group
2
17 1
30 8
end_mutex_group
begin_mutex_group
2
17 1
30 9
end_mutex_group
begin_mutex_group
2
17 1
30 10
end_mutex_group
begin_mutex_group
2
17 1
30 11
end_mutex_group
begin_mutex_group
2
17 1
29 7
end_mutex_group
begin_mutex_group
2
17 1
29 10
end_mutex_group
begin_mutex_group
2
17 1
35 1
end_mutex_group
begin_mutex_group
2
17 1
35 2
end_mutex_group
begin_mutex_group
2
17 1
35 3
end_mutex_group
begin_mutex_group
2
17 1
35 4
end_mutex_group
begin_mutex_group
2
17 1
35 5
end_mutex_group
begin_mutex_group
2
17 1
35 6
end_mutex_group
begin_mutex_group
2
17 1
35 7
end_mutex_group
begin_mutex_group
2
17 1
35 8
end_mutex_group
begin_mutex_group
2
17 1
35 9
end_mutex_group
begin_mutex_group
2
17 1
35 11
end_mutex_group
begin_mutex_group
2
17 1
35 12
end_mutex_group
begin_mutex_group
2
17 1
35 13
end_mutex_group
begin_mutex_group
2
17 1
35 14
end_mutex_group
begin_mutex_group
2
17 1
33 1
end_mutex_group
begin_mutex_group
2
17 1
33 6
end_mutex_group
begin_mutex_group
2
17 1
33 7
end_mutex_group
begin_mutex_group
2
17 1
33 10
end_mutex_group
begin_mutex_group
2
17 1
33 12
end_mutex_group
begin_mutex_group
2
17 1
34 1
end_mutex_group
begin_mutex_group
2
17 1
34 3
end_mutex_group
begin_mutex_group
2
17 1
36 1
end_mutex_group
begin_mutex_group
2
17 1
36 3
end_mutex_group
begin_mutex_group
2
17 1
36 4
end_mutex_group
begin_mutex_group
2
17 1
36 5
end_mutex_group
begin_mutex_group
2
17 1
36 7
end_mutex_group
begin_mutex_group
2
17 1
36 8
end_mutex_group
begin_mutex_group
2
17 1
36 9
end_mutex_group
begin_mutex_group
2
17 1
36 10
end_mutex_group
begin_mutex_group
2
17 1
36 11
end_mutex_group
begin_mutex_group
2
17 1
36 12
end_mutex_group
begin_mutex_group
2
17 1
36 13
end_mutex_group
begin_mutex_group
2
17 1
36 14
end_mutex_group
begin_mutex_group
2
17 1
36 15
end_mutex_group
begin_mutex_group
2
17 2
18 1
end_mutex_group
begin_mutex_group
2
17 2
18 2
end_mutex_group
begin_mutex_group
2
17 2
19 2
end_mutex_group
begin_mutex_group
2
17 2
20 0
end_mutex_group
begin_mutex_group
2
17 2
20 2
end_mutex_group
begin_mutex_group
2
17 2
20 3
end_mutex_group
begin_mutex_group
2
17 2
21 0
end_mutex_group
begin_mutex_group
2
17 2
21 2
end_mutex_group
begin_mutex_group
2
17 2
24 4
end_mutex_group
begin_mutex_group
2
17 2
27 1
end_mutex_group
begin_mutex_group
2
17 2
27 2
end_mutex_group
begin_mutex_group
2
17 2
27 3
end_mutex_group
begin_mutex_group
2
17 2
27 4
end_mutex_group
begin_mutex_group
2
17 2
27 5
end_mutex_group
begin_mutex_group
2
17 2
27 6
end_mutex_group
begin_mutex_group
2
17 2
27 7
end_mutex_group
begin_mutex_group
2
17 2
27 8
end_mutex_group
begin_mutex_group
2
17 2
27 9
end_mutex_group
begin_mutex_group
2
17 2
27 11
end_mutex_group
begin_mutex_group
2
17 2
28 2
end_mutex_group
begin_mutex_group
2
17 2
28 3
end_mutex_group
begin_mutex_group
2
17 2
28 4
end_mutex_group
begin_mutex_group
2
17 2
28 5
end_mutex_group
begin_mutex_group
2
17 2
28 6
end_mutex_group
begin_mutex_group
2
17 2
28 7
end_mutex_group
begin_mutex_group
2
17 2
28 8
end_mutex_group
begin_mutex_group
2
17 2
28 9
end_mutex_group
begin_mutex_group
2
17 2
28 10
end_mutex_group
begin_mutex_group
2
17 2
28 11
end_mutex_group
begin_mutex_group
2
17 2
31 2
end_mutex_group
begin_mutex_group
2
17 2
31 3
end_mutex_group
begin_mutex_group
2
17 2
31 5
end_mutex_group
begin_mutex_group
2
17 2
31 6
end_mutex_group
begin_mutex_group
2
17 2
31 7
end_mutex_group
begin_mutex_group
2
17 2
31 8
end_mutex_group
begin_mutex_group
2
17 2
31 9
end_mutex_group
begin_mutex_group
2
17 2
31 10
end_mutex_group
begin_mutex_group
2
17 2
31 11
end_mutex_group
begin_mutex_group
2
17 2
31 12
end_mutex_group
begin_mutex_group
2
17 2
31 13
end_mutex_group
begin_mutex_group
2
17 2
32 1
end_mutex_group
begin_mutex_group
2
17 2
32 2
end_mutex_group
begin_mutex_group
2
17 2
32 3
end_mutex_group
begin_mutex_group
2
17 2
32 4
end_mutex_group
begin_mutex_group
2
17 2
32 5
end_mutex_group
begin_mutex_group
2
17 2
32 6
end_mutex_group
begin_mutex_group
2
17 2
32 7
end_mutex_group
begin_mutex_group
2
17 2
32 8
end_mutex_group
begin_mutex_group
2
17 2
32 10
end_mutex_group
begin_mutex_group
2
17 2
32 11
end_mutex_group
begin_mutex_group
2
17 2
32 12
end_mutex_group
begin_mutex_group
2
17 2
32 13
end_mutex_group
begin_mutex_group
2
17 2
22 1
end_mutex_group
begin_mutex_group
2
17 2
37 1
end_mutex_group
begin_mutex_group
2
17 2
37 2
end_mutex_group
begin_mutex_group
2
17 2
37 4
end_mutex_group
begin_mutex_group
2
17 2
37 8
end_mutex_group
begin_mutex_group
2
17 2
37 9
end_mutex_group
begin_mutex_group
2
17 2
37 11
end_mutex_group
begin_mutex_group
2
17 2
37 12
end_mutex_group
begin_mutex_group
2
17 2
37 13
end_mutex_group
begin_mutex_group
2
17 2
37 14
end_mutex_group
begin_mutex_group
2
17 2
37 15
end_mutex_group
begin_mutex_group
2
17 2
30 2
end_mutex_group
begin_mutex_group
2
17 2
30 5
end_mutex_group
begin_mutex_group
2
17 2
30 8
end_mutex_group
begin_mutex_group
2
17 2
30 9
end_mutex_group
begin_mutex_group
2
17 2
30 10
end_mutex_group
begin_mutex_group
2
17 2
30 11
end_mutex_group
begin_mutex_group
2
17 2
29 1
end_mutex_group
begin_mutex_group
2
17 2
29 2
end_mutex_group
begin_mutex_group
2
17 2
29 3
end_mutex_group
begin_mutex_group
2
17 2
29 5
end_mutex_group
begin_mutex_group
2
17 2
29 6
end_mutex_group
begin_mutex_group
2
17 2
29 7
end_mutex_group
begin_mutex_group
2
17 2
29 8
end_mutex_group
begin_mutex_group
2
17 2
29 9
end_mutex_group
begin_mutex_group
2
17 2
29 10
end_mutex_group
begin_mutex_group
2
17 2
29 11
end_mutex_group
begin_mutex_group
2
17 2
29 12
end_mutex_group
begin_mutex_group
2
17 2
35 1
end_mutex_group
begin_mutex_group
2
17 2
35 2
end_mutex_group
begin_mutex_group
2
17 2
35 3
end_mutex_group
begin_mutex_group
2
17 2
35 4
end_mutex_group
begin_mutex_group
2
17 2
35 5
end_mutex_group
begin_mutex_group
2
17 2
35 6
end_mutex_group
begin_mutex_group
2
17 2
35 7
end_mutex_group
begin_mutex_group
2
17 2
35 8
end_mutex_group
begin_mutex_group
2
17 2
35 9
end_mutex_group
begin_mutex_group
2
17 2
35 11
end_mutex_group
begin_mutex_group
2
17 2
35 12
end_mutex_group
begin_mutex_group
2
17 2
35 13
end_mutex_group
begin_mutex_group
2
17 2
35 14
end_mutex_group
begin_mutex_group
2
17 2
26 2
end_mutex_group
begin_mutex_group
2
17 2
26 4
end_mutex_group
begin_mutex_group
2
17 2
33 1
end_mutex_group
begin_mutex_group
2
17 2
33 2
end_mutex_group
begin_mutex_group
2
17 2
33 3
end_mutex_group
begin_mutex_group
2
17 2
33 5
end_mutex_group
begin_mutex_group
2
17 2
33 6
end_mutex_group
begin_mutex_group
2
17 2
33 8
end_mutex_group
begin_mutex_group
2
17 2
33 9
end_mutex_group
begin_mutex_group
2
17 2
33 10
end_mutex_group
begin_mutex_group
2
17 2
33 11
end_mutex_group
begin_mutex_group
2
17 2
33 12
end_mutex_group
begin_mutex_group
2
17 2
33 13
end_mutex_group
begin_mutex_group
2
17 2
34 2
end_mutex_group
begin_mutex_group
2
17 2
34 3
end_mutex_group
begin_mutex_group
2
17 2
23 1
end_mutex_group
begin_mutex_group
2
17 2
36 1
end_mutex_group
begin_mutex_group
2
17 2
36 3
end_mutex_group
begin_mutex_group
2
17 2
36 4
end_mutex_group
begin_mutex_group
2
17 2
36 5
end_mutex_group
begin_mutex_group
2
17 2
36 6
end_mutex_group
begin_mutex_group
2
17 2
36 8
end_mutex_group
begin_mutex_group
2
17 2
36 9
end_mutex_group
begin_mutex_group
2
17 2
36 10
end_mutex_group
begin_mutex_group
2
17 2
36 11
end_mutex_group
begin_mutex_group
2
17 2
36 12
end_mutex_group
begin_mutex_group
2
17 2
36 13
end_mutex_group
begin_mutex_group
2
17 2
36 14
end_mutex_group
begin_mutex_group
2
17 2
36 15
end_mutex_group
begin_mutex_group
2
17 2
38 0
end_mutex_group
begin_mutex_group
2
17 3
18 0
end_mutex_group
begin_mutex_group
2
17 3
18 2
end_mutex_group
begin_mutex_group
2
17 3
19 2
end_mutex_group
begin_mutex_group
2
17 3
20 3
end_mutex_group
begin_mutex_group
2
17 3
27 10
end_mutex_group
begin_mutex_group
2
17 3
28 1
end_mutex_group
begin_mutex_group
2
17 3
31 1
end_mutex_group
begin_mutex_group
2
17 3
32 9
end_mutex_group
begin_mutex_group
2
17 3
30 3
end_mutex_group
begin_mutex_group
2
17 3
29 4
end_mutex_group
begin_mutex_group
2
17 3
33 7
end_mutex_group
begin_mutex_group
2
17 3
34 1
end_mutex_group
begin_mutex_group
2
17 3
34 3
end_mutex_group
begin_mutex_group
2
17 3
36 2
end_mutex_group
begin_mutex_group
2
17 4
18 2
end_mutex_group
begin_mutex_group
2
17 4
20 3
end_mutex_group
begin_mutex_group
2
17 4
21 2
end_mutex_group
begin_mutex_group
2
17 4
27 2
end_mutex_group
begin_mutex_group
2
17 4
27 3
end_mutex_group
begin_mutex_group
2
17 4
28 2
end_mutex_group
begin_mutex_group
2
17 4
28 3
end_mutex_group
begin_mutex_group
2
17 4
31 2
end_mutex_group
begin_mutex_group
2
17 4
31 3
end_mutex_group
begin_mutex_group
2
17 4
32 4
end_mutex_group
begin_mutex_group
2
17 4
32 5
end_mutex_group
begin_mutex_group
2
17 4
22 1
end_mutex_group
begin_mutex_group
2
17 4
22 3
end_mutex_group
begin_mutex_group
2
17 4
37 1
end_mutex_group
begin_mutex_group
2
17 4
37 2
end_mutex_group
begin_mutex_group
2
17 4
37 4
end_mutex_group
begin_mutex_group
2
17 4
37 5
end_mutex_group
begin_mutex_group
2
17 4
37 6
end_mutex_group
begin_mutex_group
2
17 4
37 7
end_mutex_group
begin_mutex_group
2
17 4
37 8
end_mutex_group
begin_mutex_group
2
17 4
37 9
end_mutex_group
begin_mutex_group
2
17 4
37 11
end_mutex_group
begin_mutex_group
2
17 4
37 12
end_mutex_group
begin_mutex_group
2
17 4
37 13
end_mutex_group
begin_mutex_group
2
17 4
37 14
end_mutex_group
begin_mutex_group
2
17 4
37 15
end_mutex_group
begin_mutex_group
2
17 4
37 16
end_mutex_group
begin_mutex_group
2
17 4
30 1
end_mutex_group
begin_mutex_group
2
17 4
29 2
end_mutex_group
begin_mutex_group
2
17 4
29 3
end_mutex_group
begin_mutex_group
2
17 4
35 4
end_mutex_group
begin_mutex_group
2
17 4
35 5
end_mutex_group
begin_mutex_group
2
17 4
25 0
end_mutex_group
begin_mutex_group
2
17 4
33 2
end_mutex_group
begin_mutex_group
2
17 4
33 3
end_mutex_group
begin_mutex_group
2
17 4
34 2
end_mutex_group
begin_mutex_group
2
17 4
34 3
end_mutex_group
begin_mutex_group
2
17 4
23 2
end_mutex_group
begin_mutex_group
2
17 4
36 4
end_mutex_group
begin_mutex_group
2
17 4
36 5
end_mutex_group
begin_mutex_group
2
17 5
18 2
end_mutex_group
begin_mutex_group
2
17 5
19 0
end_mutex_group
begin_mutex_group
2
17 5
19 2
end_mutex_group
begin_mutex_group
2
17 5
20 3
end_mutex_group
begin_mutex_group
2
17 5
21 2
end_mutex_group
begin_mutex_group
2
17 5
24 3
end_mutex_group
begin_mutex_group
2
17 5
37 3
end_mutex_group
begin_mutex_group
2
17 5
34 3
end_mutex_group
begin_mutex_group
2
17 5
23 2
end_mutex_group
begin_mutex_group
2
17 6
18 0
end_mutex_group
begin_mutex_group
2
17 6
18 2
end_mutex_group
begin_mutex_group
2
17 6
19 2
end_mutex_group
begin_mutex_group
2
17 6
21 2
end_mutex_group
begin_mutex_group
2
17 6
27 10
end_mutex_group
begin_mutex_group
2
17 6
28 1
end_mutex_group





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
end_mutex_group
begin_mutex_group
2
38 0
40 1
end_mutex_group
begin_mutex_group
2
0 1
1 0
end_mutex_group
begin_mutex_group
2
0 1
17 1
end_mutex_group
begin_mutex_group
2
0 1
17 2
end_mutex_group
begin_mutex_group
2
0 1
18 0
end_mutex_group
begin_mutex_group
2
0 1
18 2
end_mutex_group
begin_mutex_group
2
0 1
20 1
end_mutex_group
begin_mutex_group
2
0 1
27 10
end_mutex_group
begin_mutex_group
2
0 1
28 1
end_mutex_group
begin_mutex_group
2
0 1
31 1
end_mutex_group
begin_mutex_group
2
0 1
32 9
end_mutex_group
begin_mutex_group
2
0 1
37 4
end_mutex_group
begin_mutex_group
2
0 1
30 2
end_mutex_group
begin_mutex_group
2
0 1
30 3
end_mutex_group
begin_mutex_group
2
0 1
29 4
end_mutex_group
begin_mutex_group
2
0 1
33 7
end_mutex_group
begin_mutex_group
2
0 1
34 1
end_mutex_group
begin_mutex_group
2
0 1
23 0
end_mutex_group
begin_mutex_group
2
0 1
23 3
end_mutex_group
begin_mutex_group
2
0 1
36 2
end_mutex_group
begin_mutex_group
2
0 1
36 6
end_mutex_group
begin_mutex_group
2
0 1
40 1
end_mutex_group
begin_state
0
1
1
1
1
1
0
1
1
1
1
1
1
1
1
1
1
0
0
0
1
1
2
2
3
1
3
10
1
4
3
1
9
7
1
10
2
3
1
0
1
end_state
begin_goal
23
18 1
19 1
20 0
21 0
22 1
23 1
24 4
25 0
26 3
27 2
28 8
29 7
30 1
31 12
32 1
33 10
34 2
35 10
36 7
37 2
38 0
39 0
40 0
end_goal
291
begin_operator
pickup b1
0
3
0 17 0 7
0 11 0 1
0 29 12 0
1
end_operator
begin_operator
pickup b10
0
3
0 17 0 7
0 10 0 1
0 27 11 0
1
end_operator
begin_operator
pickup b11
0
3
0 17 0 7
0 9 0 1
0 28 11 0
1
end_operator
begin_operator
pickup b12
0
3
0 17 0 7
0 7 0 1
0 22 3 0
1
end_operator
begin_operator
pickup b13
0
3
0 17 0 7
0 16 0 1
0 37 16 0
1
end_operator
begin_operator
pickup b16
0
3
0 17 0 7
0 6 0 1
0 23 3 0
1
end_operator
begin_operator
pickup b17
0
3
0 17 0 7
0 39 0 1
0 30 12 0
1
end_operator
begin_operator
pickup b18
0
3
0 17 0 3
0 3 0 1
0 21 1 2
1
end_operator
begin_operator
pickup b19
0
3
0 17 0 7
0 38 0 1
0 26 4 0
1
end_operator
begin_operator
pickup b20
0
3
0 17 0 7
0 8 0 1
0 24 5 0
1
end_operator
begin_operator
pickup b3
0
3
0 17 0 5
0 25 0 1
0 0 0 1
1
end_operator
begin_operator
pickup b4
0
3
0 17 0 7
0 13 0 1
0 35 14 0
1
end_operator
begin_operator
pickup b5
0
3
0 17 0 7
0 34 0 3
0 33 13 0
1
end_operator
begin_operator
pickup b6
0
3
0 17 0 6
0 4 0 1
0 20 2 3
1
end_operator
begin_operator
pickup b7
0
3
0 17 0 7
0 15 0 1
0 36 15 0
1
end_operator
begin_operator
pickup b8
0
3
0 17 0 7
0 14 0 1
0 31 13 0
1
end_operator
begin_operator
pickup b9
0
3
0 17 0 7
0 12 0 1
0 32 13 0
1
end_operator
begin_operator
putdown b1
0
3
0 17 -1 0
0 11 -1 0
0 29 0 12
1
end_operator
begin_operator
putdown b10
0
3
0 17 -1 0
0 10 -1 0
0 27 0 11
1
end_operator
begin_operator
putdown b11
0
3
0 17 -1 0
0 9 -1 0
0 28 0 11
1
end_operator
begin_operator
putdown b12
0
3
0 17 -1 0
0 7 -1 0
0 22 0 3
1
end_operator
begin_operator
putdown b13
0
3
0 17 -1 0
0 16 -1 0
0 37 0 16
1
end_operator
begin_operator
putdown b14
0
3
0 17 1 0
0 1 -1 0
0 18 -1 1
1
end_operator
begin_operator
putdown b15
0
3
0 17 2 0
0 2 -1 0
0 40 -1 0
1
end_operator
begin_operator
putdown b16
0
3
0 17 -1 0
0 6 -1 0
0 23 0 3
1
end_operator
begin_operator
putdown b17
0
3
0 17 -1 0
0 39 -1 0
0 30 0 12
1
end_operator
begin_operator
putdown b19
0
3
0 17 -1 0
0 38 -1 0
0 26 0 4
1
end_operator
begin_operator
putdown b2
0
3
0 17 4 0
0 5 -1 0
0 19 -1 1
1
end_operator
begin_operator
putdown b20
0
3
0 17 -1 0
0 8 -1 0
0 24 0 5
1
end_operator
begin_operator
putdown b4
0
3
0 17 -1 0
0 13 -1 0
0 35 0 14
1
end_operator
begin_operator
putdown b5
0
3
0 17 -1 0
0 34 -1 0
0 33 0 13
1
end_operator
begin_operator
putdown b6
0
3
0 17 6 0
0 4 -1 0
0 20 -1 2
1
end_operator
begin_operator
putdown b7
0
3
0 17 -1 0
0 15 -1 0
0 36 0 15
1
end_operator
begin_operator
putdown b8
0
3
0 17 -1 0
0 14 -1 0
0 31 0 13
1
end_operator
begin_operator
putdown b9
0
3
0 17 -1 0
0 12 -1 0
0 32 0 13
1
end_operator
begin_operator
stack b1 b11
0
4
0 17 -1 0
0 11 -1 0
0 9 0 1
0 29 0 1
1
end_operator
begin_operator
stack b1 b12
0
4
0 17 -1 0
0 11 -1 0
0 7 0 1
0 29 0 2
1
end_operator
begin_operator
stack b1 b13
0
4
0 17 -1 0
0 11 -1 0
0 16 0 1
0 29 0 3
1
end_operator
begin_operator
stack b1 b16
0
4
0 17 -1 0
0 11 -1 0
0 6 0 1
0 29 0 5
1
end_operator
begin_operator
stack b1 b17
0
4
0 17 -1 0
0 11 -1 0
0 39 0 1
0 29 0 6
1
end_operator
begin_operator
stack b1 b18
0
4
0 17 -1 0
0 11 -1 0
0 3 0 1
0 29 0 7
1
end_operator
begin_operator
stack b1 b19
0
4
0 17 -1 0
0 11 -1 0
0 38 0 1
0 29 0 8
1
end_operator
begin_operator
stack b1 b20
0
4
0 17 -1 0
0 11 -1 0
0 8 0 1
0 29 0 9
1
end_operator
begin_operator
stack b1 b7
0
4
0 17 -1 0
0 11 -1 0
0 15 0 1
0 29 0 10
1
end_operator
begin_operator
stack b1 b8
0
4
0 17 -1 0
0 11 -1 0
0 14 0 1
0 29 0 11
1
end_operator
begin_operator
stack b10 b1
0
4
0 17 -1 0
0 11 0 1
0 10 -1 0
0 27 0 1
1
end_operator
begin_operator
stack b10 b12
0
4
0 17 -1 0
0 10 -1 0
0 7 0 1
0 27 0 2
1
end_operator
begin_operator
stack b10 b13
0
4
0 17 -1 0
0 10 -1 0
0 16 0 1
0 27 0 3
1
end_operator
begin_operator
stack b10 b16
0
4
0 17 -1 0
0 10 -1 0
0 6 0 1
0 27 0 4
1
end_operator
begin_operator
stack b10 b17
0
4
0 17 -1 0
0 10 -1 0
0 39 0 1
0 27 0 5
1
end_operator
begin_operator
stack b10 b19
0
4
0 17 -1 0
0 10 -1 0
0 38 0 1
0 27 0 6
1
end_operator
begin_operator
stack b10 b4
0
4
0 17 -1 0
0 10 -1 0
0 13 0 1
0 27 0 7
1
end_operator
begin_operator
stack b10 b7
0
4
0 17 -1 0
0 10 -1 0
0 15 0 1
0 27 0 8
1
end_operator
begin_operator
stack b10 b8
0
4
0 17 -1 0
0 10 -1 0
0 14 0 1
0 27 0 9
1
end_operator
begin_operator
stack b11 b12
0
4
0 17 -1 0
0 9 -1 0
0 7 0 1
0 28 0 2
1
end_operator
begin_operator
stack b11 b13
0
4
0 17 -1 0
0 9 -1 0
0 16 0 1
0 28 0 3
1
end_operator
begin_operator
stack b11 b16
0
4
0 17 -1 0
0 9 -1 0
0 6 0 1
0 28 0 4
1
end_operator
begin_operator
stack b11 b17
0
4
0 17 -1 0
0 9 -1 0
0 39 0 1
0 28 0 5
1
end_operator
begin_operator
stack b11 b18
0
4
0 17 -1 0
0 9 -1 0
0 3 0 1
0 28 0 6
1
end_operator
begin_operator
stack b11 b19
0
4
0 17 -1 0
0 9 -1 0
0 38 0 1
0 28 0 7
1
end_operator
begin_operator
stack b11 b20
0
4
0 17 -1 0
0 9 -1 0
0 8 0 1
0 28 0 8
1
end_operator
begin_operator
stack b11 b6
0
4
0 17 -1 0
0 9 -1 0
0 4 0 1
0 28 0 9
1
end_operator
begin_operator
stack b11 b8
0
4
0 17 -1 0
0 9 -1 0
0 14 0 1
0 28 0 10
1
end_operator
begin_operator
stack b12 b11
0
4
0 17 -1 0
0 9 0 1
0 7 -1 0
0 22 0 1
1
end_operator
begin_operator
stack b13 b1
0
4
0 17 -1 0
0 11 0 1
0 16 -1 0
0 37 0 1
1
end_operator
begin_operator
stack b13 b10
0
4
0 17 -1 0
0 10 0 1
0 16 -1 0
0 37 0 2
1
end_operator
begin_operator
stack b13 b14
0
4
0 17 -1 0
0 16 -1 0
0 1 0 1
0 37 0 4
1
end_operator
begin_operator
stack b13 b15
0
4
0 17 -1 0
0 16 -1 0
0 2 0 1
0 37 0 5
1
end_operator
begin_operator
stack b13 b16
0
4
0 17 -1 0
0 16 -1 0
0 6 0 1
0 37 0 6
1
end_operator
begin_operator
stack b13 b17
0
4
0 17 -1 0
0 16 -1 0
0 39 0 1
0 37 0 7
1
end_operator
begin_operator
stack b13 b18
0
4
0 17 -1 0
0 16 -1 0
0 3 0 1
0 37 0 8
1
end_operator
begin_operator
stack b13 b19
0
4
0 17 -1 0
0 16 -1 0
0 38 0 1
0 37 0 9
1
end_operator
begin_operator
stack b13 b2
0
4
0 17 -1 0
0 16 -1 0
0 5 0 1
0 37 0 10
1
end_operator
begin_operator
stack b13 b4
0
4
0 17 -1 0
0 16 -1 0
0 13 0 1
0 37 0 11
1
end_operator
begin_operator
stack b13 b6
0
4
0 17 -1 0
0 16 -1 0
0 4 0 1
0 37 0 12
1
end_operator
begin_operator
stack b13 b7
0
4
0 17 -1 0
0 16 -1 0
0 15 0 1
0 37 0 13
1
end_operator
begin_operator
stack b13 b8
0
4
0 17 -1 0
0 16 -1 0
0 14 0 1
0 37 0 14
1
end_operator
begin_operator
stack b13 b9
0
4
0 17 -1 0
0 16 -1 0
0 12 0 1
0 37 0 15
1
end_operator
begin_operator
stack b16 b14
0
4
0 17 -1 0
0 1 0 1
0 6 -1 0
0 23 0 1
1
end_operator
begin_operator
stack b17 b13
0
4
0 17 -1 0
0 16 0 1
0 39 -1 0
0 30 0 1
1
end_operator
begin_operator
stack b17 b14
0
4
0 17 -1 0
0 1 0 1
0 39 -1 0
0 30 0 2
1
end_operator
begin_operator
stack b17 b16
0
4
0 17 -1 0
0 6 0 1
0 39 -1 0
0 30 0 4
1
end_operator
begin_operator
stack b17 b18
0
4
0 17 -1 0
0 39 -1 0
0 3 0 1
0 30 0 5
1
end_operator
begin_operator
stack b17 b2
0
4
0 17 -1 0
0 39 -1 0
0 5 0 1
0 30 0 6
1
end_operator
begin_operator
stack b17 b20
0
4
0 17 -1 0
0 39 -1 0
0 8 0 1
0 30 0 7
1
end_operator
begin_operator
stack b17 b4
0
4
0 17 -1 0
0 39 -1 0
0 13 0 1
0 30 0 8
1
end_operator
begin_operator
stack b17 b6
0
4
0 17 -1 0
0 39 -1 0
0 4 0 1
0 30 0 9
1
end_operator
begin_operator
stack b17 b7
0
4
0 17 -1 0
0 39 -1 0
0 15 0 1
0 30 0 10
1
end_operator
begin_operator
stack b17 b9
0
4
0 17 -1 0
0 39 -1 0
0 12 0 1
0 30 0 11
1
end_operator
begin_operator
stack b18 b2
0
4
0 17 3 0
0 3 -1 0
0 5 0 1
0 21 -1 0
1
end_operator
begin_operator
stack b19 b15
0
4
0 17 -1 0
0 2 0 1
0 38 -1 0
0 26 0 1
1
end_operator
begin_operator
stack b19 b2
0
4
0 17 -1 0
0 38 -1 0
0 5 0 1
0 26 0 2
1
end_operator
begin_operator
stack b19 b8
0
4
0 17 -1 0
0 38 -1 0
0 14 0 1
0 26 0 3
1
end_operator
begin_operator
stack b20 b16
0
4
0 17 -1 0
0 6 0 1
0 8 -1 0
0 24 0 1
1
end_operator
begin_operator
stack b20 b17
0
4
0 17 -1 0
0 39 0 1
0 8 -1 0
0 24 0 2
1
end_operator
begin_operator
stack b20 b7
0
4
0 17 -1 0
0 8 -1 0
0 15 0 1
0 24 0 4
1
end_operator
begin_operator
stack b3 b5
0
3
0 17 5 0
0 25 -1 0
0 34 0 2
1
end_operator
begin_operator
stack b4 b1
0
4
0 17 -1 0
0 11 0 1
0 13 -1 0
0 35 0 1
1
end_operator
begin_operator
stack b4 b10
0
4
0 17 -1 0
0 10 0 1
0 13 -1 0
0 35 0 2
1
end_operator
begin_operator
stack b4 b11
0
4
0 17 -1 0
0 9 0 1
0 13 -1 0
0 35 0 3
1
end_operator
begin_operator
stack b4 b12
0
4
0 17 -1 0
0 7 0 1
0 13 -1 0
0 35 0 4
1
end_operator
begin_operator
stack b4 b13
0
4
0 17 -1 0
0 16 0 1
0 13 -1 0
0 35 0 5
1
end_operator
begin_operator
stack b4 b17
0
4
0 17 -1 0
0 39 0 1
0 13 -1 0
0 35 0 6
1
end_operator
begin_operator
stack b4 b18
0
4
0 17 -1 0
0 3 0 1
0 13 -1 0
0 35 0 7
1
end_operator
begin_operator
stack b4 b19
0
4
0 17 -1 0
0 38 0 1
0 13 -1 0
0 35 0 8
1
end_operator
begin_operator
stack b4 b20
0
4
0 17 -1 0
0 8 0 1
0 13 -1 0
0 35 0 9
1
end_operator
begin_operator
stack b4 b6
0
4
0 17 -1 0
0 13 -1 0
0 4 0 1
0 35 0 10
1
end_operator
begin_operator
stack b4 b7
0
4
0 17 -1 0
0 13 -1 0
0 15 0 1
0 35 0 11
1
end_operator
begin_operator
stack b4 b8
0
4
0 17 -1 0
0 13 -1 0
0 14 0 1
0 35 0 12
1
end_operator
begin_operator
stack b4 b9
0
4
0 17 -1 0
0 13 -1 0
0 12 0 1
0 35 0 13
1
end_operator
begin_operator
stack b5 b10
0
4
0 17 -1 0
0 10 0 1
0 34 -1 0
0 33 0 1
1
end_operator
begin_operator
stack b5 b12
0
4
0 17 -1 0
0 7 0 1
0 34 -1 0
0 33 0 2
1
end_operator
begin_operator
stack b5 b13
0
4
0 17 -1 0
0 16 0 1
0 34 -1 0
0 33 0 3
1
end_operator
begin_operator
stack b5 b15
0
4
0 17 -1 0
0 2 0 1
0 34 -1 0
0 33 0 4
1
end_operator
begin_operator
stack b5 b17
0
4
0 17 -1 0
0 39 0 1
0 34 -1 0
0 33 0 5
1
end_operator
begin_operator
stack b5 b18
0
4
0 17 -1 0
0 3 0 1
0 34 -1 0
0 33 0 6
1
end_operator
begin_operator
stack b5 b2
0
4
0 17 -1 0
0 5 0 1
0 34 -1 0
0 33 0 8
1
end_operator
begin_operator
stack b5 b20
0
4
0 17 -1 0
0 8 0 1
0 34 -1 0
0 33 0 9
1
end_operator
begin_operator
stack b5 b4
0
4
0 17 -1 0
0 13 0 1
0 34 -1 0
0 33 0 10
1
end_operator
begin_operator
stack b5 b8
0
4
0 17 -1 0
0 34 -1 0
0 14 0 1
0 33 0 11
1
end_operator
begin_operator
stack b5 b9
0
4
0 17 -1 0
0 34 -1 0
0 12 0 1
0 33 0 12
1
end_operator
begin_operator
stack b6 b16
0
4
0 17 6 0
0 6 0 1
0 4 -1 0
0 20 -1 0
1
end_operator
begin_operator
stack b7 b1
0
4
0 17 -1 0
0 11 0 1
0 15 -1 0
0 36 0 1
1
end_operator
begin_operator
stack b7 b11
0
4
0 17 -1 0
0 9 0 1
0 15 -1 0
0 36 0 3
1
end_operator
begin_operator
stack b7 b12
0
4
0 17 -1 0
0 7 0 1
0 15 -1 0
0 36 0 4
1
end_operator
begin_operator
stack b7 b13
0
4
0 17 -1 0
0 16 0 1
0 15 -1 0
0 36 0 5
1
end_operator
begin_operator
stack b7 b14
0
4
0 17 -1 0
0 1 0 1
0 15 -1 0
0 36 0 6
1
end_operator
begin_operator
stack b7 b15
0
4
0 17 -1 0
0 2 0 1
0 15 -1 0
0 36 0 7
1
end_operator
begin_operator
stack b7 b16
0
4
0 17 -1 0
0 6 0 1
0 15 -1 0
0 36 0 8
1
end_operator
begin_operator
stack b7 b17
0
4
0 17 -1 0
0 39 0 1
0 15 -1 0
0 36 0 9
1
end_operator
begin_operator
stack b7 b19
0
4
0 17 -1 0
0 38 0 1
0 15 -1 0
0 36 0 10
1
end_operator
begin_operator
stack b7 b2
0
4
0 17 -1 0
0 5 0 1
0 15 -1 0
0 36 0 11
1
end_operator
begin_operator
stack b7 b20
0
4
0 17 -1 0
0 8 0 1
0 15 -1 0
0 36 0 12
1
end_operator
begin_operator
stack b7 b8
0
4
0 17 -1 0
0 15 -1 0
0 14 0 1
0 36 0 13
1
end_operator
begin_operator
stack b7 b9
0
4
0 17 -1 0
0 15 -1 0
0 12 0 1
0 36 0 14
1
end_operator
begin_operator
stack b8 b12
0
4
0 17 -1 0
0 7 0 1
0 14 -1 0
0 31 0 2
1
end_operator
begin_operator
stack b8 b13
0
4
0 17 -1 0
0 16 0 1
0 14 -1 0
0 31 0 3
1
end_operator
begin_operator
stack b8 b15
0
4
0 17 -1 0
0 2 0 1
0 14 -1 0
0 31 0 4
1
end_operator
begin_operator
stack b8 b16
0
4
0 17 -1 0
0 6 0 1
0 14 -1 0
0 31 0 5
1
end_operator
begin_operator
stack b8 b17
0
4
0 17 -1 0
0 39 0 1
0 14 -1 0
0 31 0 6
1
end_operator
begin_operator
stack b8 b19
0
4
0 17 -1 0
0 38 0 1
0 14 -1 0
0 31 0 7
1
end_operator
begin_operator
stack b8 b2
0
4
0 17 -1 0
0 5 0 1
0 14 -1 0
0 31 0 8
1
end_operator
begin_operator
stack b8 b20
0
4
0 17 -1 0
0 8 0 1
0 14 -1 0
0 31 0 9
1
end_operator
begin_operator
stack b8 b4
0
4
0 17 -1 0
0 13 0 1
0 14 -1 0
0 31 0 10
1
end_operator
begin_operator
stack b8 b6
0
4
0 17 -1 0
0 4 0 1
0 14 -1 0
0 31 0 11
1
end_operator
begin_operator
stack b8 b9
0
4
0 17 -1 0
0 14 -1 0
0 12 0 1
0 31 0 12
1
end_operator
begin_operator
stack b9 b1
0
4
0 17 -1 0
0 11 0 1
0 12 -1 0
0 32 0 1
1
end_operator
begin_operator
stack b9 b10
0
4
0 17 -1 0
0 10 0 1
0 12 -1 0
0 32 0 2
1
end_operator
begin_operator
stack b9 b11
0
4
0 17 -1 0
0 9 0 1
0 12 -1 0
0 32 0 3
1
end_operator
begin_operator
stack b9 b12
0
4
0 17 -1 0
0 7 0 1
0 12 -1 0
0 32 0 4
1
end_operator
begin_operator
stack b9 b13
0
4
0 17 -1 0
0 16 0 1
0 12 -1 0
0 32 0 5
1
end_operator
begin_operator
stack b9 b17
0
4
0 17 -1 0
0 39 0 1
0 12 -1 0
0 32 0 6
1
end_operator
begin_operator
stack b9 b19
0
4
0 17 -1 0
0 38 0 1
0 12 -1 0
0 32 0 7
1
end_operator
begin_operator
stack b9 b20
0
4
0 17 -1 0
0 8 0 1
0 12 -1 0
0 32 0 8
1
end_operator
begin_operator
stack b9 b6
0
4
0 17 -1 0
0 4 0 1
0 12 -1 0
0 32 0 10
1
end_operator
begin_operator
stack b9 b7
0
4
0 17 -1 0
0 15 0 1
0 12 -1 0
0 32 0 11
1
end_operator
begin_operator
stack b9 b8
0
4
0 17 -1 0
0 14 0 1
0 12 -1 0
0 32 0 12
1
end_operator
begin_operator
unstack b1 b11
0
4
0 17 0 7
0 11 0 1
0 9 -1 0
0 29 1 0
1
end_operator
begin_operator
unstack b1 b12
0
4
0 17 0 7
0 11 0 1
0 7 -1 0
0 29 2 0
1
end_operator
begin_operator
unstack b1 b13
0
4
0 17 0 7
0 11 0 1
0 16 -1 0
0 29 3 0
1
end_operator
begin_operator
unstack b1 b14
0
4
0 17 0 7
0 11 0 1
0 1 -1 0
0 29 4 0
1
end_operator
begin_operator
unstack b1 b16
0
4
0 17 0 7
0 11 0 1
0 6 -1 0
0 29 5 0
1
end_operator
begin_operator
unstack b1 b17
0
4
0 17 0 7
0 11 0 1
0 39 -1 0
0 29 6 0
1
end_operator
begin_operator
unstack b1 b19
0
4
0 17 0 7
0 11 0 1
0 38 -1 0
0 29 8 0
1
end_operator
begin_operator
unstack b1 b20
0
4
0 17 0 7
0 11 0 1
0 8 -1 0
0 29 9 0
1
end_operator
begin_operator
unstack b1 b7
0
4
0 17 0 7
0 11 0 1
0 15 -1 0
0 29 10 0
1
end_operator
begin_operator
unstack b1 b8
0
4
0 17 0 7
0 11 0 1
0 14 -1 0
0 29 11 0
1
end_operator
begin_operator
unstack b10 b1
0
4
0 17 0 7
0 11 -1 0
0 10 0 1
0 27 1 0
1
end_operator
begin_operator
unstack b10 b12
0
4
0 17 0 7
0 10 0 1
0 7 -1 0
0 27 2 0
1
end_operator
begin_operator
unstack b10 b13
0
4
0 17 0 7
0 10 0 1
0 16 -1 0
0 27 3 0
1
end_operator
begin_operator
unstack b10 b16
0
4
0 17 0 7
0 10 0 1
0 6 -1 0
0 27 4 0
1
end_operator
begin_operator
unstack b10 b17
0
4
0 17 0 7
0 10 0 1
0 39 -1 0
0 27 5 0
1
end_operator
begin_operator
unstack b10 b19
0
4
0 17 0 7
0 10 0 1
0 38 -1 0
0 27 6 0
1
end_operator
begin_operator
unstack b10 b4
0
4
0 17 0 7
0 10 0 1
0 13 -1 0
0 27 7 0
1
end_operator
begin_operator
unstack b10 b7
0
4
0 17 0 7
0 10 0 1
0 15 -1 0
0 27 8 0
1
end_operator
begin_operator
unstack b10 b8
0
4
0 17 0 7
0 10 0 1
0 14 -1 0
0 27 9 0
1
end_operator
begin_operator
unstack b10 b9
0
4
0 17 0 7
0 10 0 1
0 12 -1 0
0 27 10 0
1
end_operator
begin_operator
unstack b11 b1
0
4
0 17 0 7
0 11 -1 0
0 9 0 1
0 28 1 0
1
end_operator
begin_operator
unstack b11 b12
0
4
0 17 0 7
0 9 0 1
0 7 -1 0
0 28 2 0
1
end_operator
begin_operator
unstack b11 b13
0
4
0 17 0 7
0 9 0 1
0 16 -1 0
0 28 3 0
1
end_operator
begin_operator
unstack b11 b16
0
4
0 17 0 7
0 9 0 1
0 6 -1 0
0 28 4 0
1
end_operator
begin_operator
unstack b11 b17
0
4
0 17 0 7
0 9 0 1
0 39 -1 0
0 28 5 0
1
end_operator
begin_operator
unstack b11 b18
0
4
0 17 0 7
0 9 0 1
0 3 -1 0
0 28 6 0
1
end_operator
begin_operator
unstack b11 b19
0
4
0 17 0 7
0 9 0 1
0 38 -1 0
0 28 7 0
1
end_operator
begin_operator
unstack b11 b20
0
4
0 17 0 7
0 9 0 1
0 8 -1 0
0 28 8 0
1
end_operator
begin_operator
unstack b11 b6
0
4
0 17 0 7
0 9 0 1
0 4 -1 0
0 28 9 0
1
end_operator
begin_operator
unstack b11 b8
0
4
0 17 0 7
0 9 0 1
0 14 -1 0
0 28 10 0
1
end_operator
begin_operator
unstack b12 b3
0
4
0 17 0 7
0 7 0 1
0 25 -1 0
0 22 2 0
1
end_operator
begin_operator
unstack b13 b1
0
4
0 17 0 7
0 11 -1 0
0 16 0 1
0 37 1 0
1
end_operator
begin_operator
unstack b13 b10
0
4
0 17 0 7
0 10 -1 0
0 16 0 1
0 37 2 0
1
end_operator
begin_operator
unstack b13 b12
0
4
0 17 0 7
0 7 -1 0
0 16 0 1
0 37 3 0
1
end_operator
begin_operator
unstack b13 b14
0
4
0 17 0 7
0 16 0 1
0 1 -1 0
0 37 4 0
1
end_operator
begin_operator
unstack b13 b15
0
4
0 17 0 7
0 16 0 1
0 2 -1 0
0 37 5 0
1
end_operator
begin_operator
unstack b13 b16
0
4
0 17 0 7
0 16 0 1
0 6 -1 0
0 37 6 0
1
end_operator
begin_operator
unstack b13 b17
0
4
0 17 0 7
0 16 0 1
0 39 -1 0
0 37 7 0
1
end_operator
begin_operator
unstack b13 b18
0
4
0 17 0 7
0 16 0 1
0 3 -1 0
0 37 8 0
1
end_operator
begin_operator
unstack b13 b19
0
4
0 17 0 7
0 16 0 1
0 38 -1 0
0 37 9 0
1
end_operator
begin_operator
unstack b13 b2
0
4
0 17 0 7
0 16 0 1
0 5 -1 0
0 37 10 0
1
end_operator
begin_operator
unstack b13 b4
0
4
0 17 0 7
0 16 0 1
0 13 -1 0
0 37 11 0
1
end_operator
begin_operator
unstack b13 b6
0
4
0 17 0 7
0 16 0 1
0 4 -1 0
0 37 12 0
1
end_operator
begin_operator
unstack b13 b7
0
4
0 17 0 7
0 16 0 1
0 15 -1 0
0 37 13 0
1
end_operator
begin_operator
unstack b13 b8
0
4
0 17 0 7
0 16 0 1
0 14 -1 0
0 37 14 0
1
end_operator
begin_operator
unstack b13 b9
0
4
0 17 0 7
0 16 0 1
0 12 -1 0
0 37 15 0
1
end_operator
begin_operator
unstack b14 b7
0
4
0 17 0 1
0 1 0 1
0 15 -1 0
0 18 0 2
1
end_operator
begin_operator
unstack b15 b5
0
3
0 17 0 2
0 2 0 1
0 34 1 0
1
end_operator
begin_operator
unstack b16 b20
0
4
0 17 0 7
0 6 0 1
0 8 -1 0
0 23 2 0
1
end_operator
begin_operator
unstack b17 b13
0
4
0 17 0 7
0 16 -1 0
0 39 0 1
0 30 1 0
1
end_operator
begin_operator
unstack b17 b14
0
4
0 17 0 7
0 1 -1 0
0 39 0 1
0 30 2 0
1
end_operator
begin_operator
unstack b17 b15
0
4
0 17 0 7
0 2 -1 0
0 39 0 1
0 30 3 0
1
end_operator
begin_operator
unstack b17 b16
0
4
0 17 0 7
0 6 -1 0
0 39 0 1
0 30 4 0
1
end_operator
begin_operator
unstack b17 b18
0
4
0 17 0 7
0 39 0 1
0 3 -1 0
0 30 5 0
1
end_operator
begin_operator
unstack b17 b2
0
4
0 17 0 7
0 39 0 1
0 5 -1 0
0 30 6 0
1
end_operator
begin_operator
unstack b17 b20
0
4
0 17 0 7
0 39 0 1
0 8 -1 0
0 30 7 0
1
end_operator
begin_operator
unstack b17 b4
0
4
0 17 0 7
0 39 0 1
0 13 -1 0
0 30 8 0
1
end_operator
begin_operator
unstack b17 b6
0
4
0 17 0 7
0 39 0 1
0 4 -1 0
0 30 9 0
1
end_operator
begin_operator
unstack b17 b7
0
4
0 17 0 7
0 39 0 1
0 15 -1 0
0 30 10 0
1
end_operator
begin_operator
unstack b17 b9
0
4
0 17 0 7
0 39 0 1
0 12 -1 0
0 30 11 0
1
end_operator
begin_operator
unstack b18 b2
0
4
0 17 0 3
0 3 0 1
0 5 -1 0
0 21 0 2
1
end_operator
begin_operator
unstack b19 b15
0
4
0 17 0 7
0 2 -1 0
0 38 0 1
0 26 1 0
1
end_operator
begin_operator
unstack b19 b2
0
4
0 17 0 7
0 38 0 1
0 5 -1 0
0 26 2 0
1
end_operator
begin_operator
unstack b19 b8
0
4
0 17 0 7
0 38 0 1
0 14 -1 0
0 26 3 0
1
end_operator
begin_operator
unstack b2 b13
0
4
0 17 0 4
0 16 -1 0
0 5 0 1
0 19 0 2
1
end_operator
begin_operator
unstack b20 b16
0
4
0 17 0 7
0 6 -1 0
0 8 0 1
0 24 1 0
1
end_operator
begin_operator
unstack b20 b17
0
4
0 17 0 7
0 39 -1 0
0 8 0 1
0 24 2 0
1
end_operator
begin_operator
unstack b20 b2
0
4
0 17 0 7
0 5 -1 0
0 8 0 1
0 24 3 0
1
end_operator
begin_operator
unstack b20 b7
0
4
0 17 0 7
0 8 0 1
0 15 -1 0
0 24 4 0
1
end_operator
begin_operator
unstack b3 b5
0
3
0 17 0 5
0 25 0 1
0 34 2 0
1
end_operator
begin_operator
unstack b4 b1
0
4
0 17 0 7
0 11 -1 0
0 13 0 1
0 35 1 0
1
end_operator
begin_operator
unstack b4 b10
0
4
0 17 0 7
0 10 -1 0
0 13 0 1
0 35 2 0
1
end_operator
begin_operator
unstack b4 b11
0
4
0 17 0 7
0 9 -1 0
0 13 0 1
0 35 3 0
1
end_operator
begin_operator
unstack b4 b12
0
4
0 17 0 7
0 7 -1 0
0 13 0 1
0 35 4 0
1
end_operator
begin_operator
unstack b4 b13
0
4
0 17 0 7
0 16 -1 0
0 13 0 1
0 35 5 0
1
end_operator
begin_operator
unstack b4 b17
0
4
0 17 0 7
0 39 -1 0
0 13 0 1
0 35 6 0
1
end_operator
begin_operator
unstack b4 b18
0
4
0 17 0 7
0 3 -1 0
0 13 0 1
0 35 7 0
1
end_operator
begin_operator
unstack b4 b19
0
4
0 17 0 7
0 38 -1 0
0 13 0 1
0 35 8 0
1
end_operator
begin_operator
unstack b4 b20
0
4
0 17 0 7
0 8 -1 0
0 13 0 1
0 35 9 0
1
end_operator
begin_operator
unstack b4 b6
0
4
0 17 0 7
0 13 0 1
0 4 -1 0
0 35 10 0
1
end_operator
begin_operator
unstack b4 b7
0
4
0 17 0 7
0 13 0 1
0 15 -1 0
0 35 11 0
1
end_operator
begin_operator
unstack b4 b8
0
4
0 17 0 7
0 13 0 1
0 14 -1 0
0 35 12 0
1
end_operator
begin_operator
unstack b4 b9
0
4
0 17 0 7
0 13 0 1
0 12 -1 0
0 35 13 0
1
end_operator
begin_operator
unstack b5 b10
0
4
0 17 0 7
0 10 -1 0
0 34 0 3
0 33 1 0
1
end_operator
begin_operator
unstack b5 b12
0
4
0 17 0 7
0 7 -1 0
0 34 0 3
0 33 2 0
1
end_operator
begin_operator
unstack b5 b13
0
4
0 17 0 7
0 16 -1 0
0 34 0 3
0 33 3 0
1
end_operator
begin_operator
unstack b5 b15
0
4
0 17 0 7
0 2 -1 0
0 34 0 3
0 33 4 0
1
end_operator
begin_operator
unstack b5 b17
0
4
0 17 0 7
0 39 -1 0
0 34 0 3
0 33 5 0
1
end_operator
begin_operator
unstack b5 b18
0
4
0 17 0 7
0 3 -1 0
0 34 0 3
0 33 6 0
1
end_operator
begin_operator
unstack b5 b19
0
4
0 17 0 7
0 38 -1 0
0 34 0 3
0 33 7 0
1
end_operator
begin_operator
unstack b5 b2
0
4
0 17 0 7
0 5 -1 0
0 34 0 3
0 33 8 0
1
end_operator
begin_operator
unstack b5 b20
0
4
0 17 0 7
0 8 -1 0
0 34 0 3
0 33 9 0
1
end_operator
begin_operator
unstack b5 b4
0
4
0 17 0 7
0 13 -1 0
0 34 0 3
0 33 10 0
1
end_operator
begin_operator
unstack b5 b8
0
4
0 17 0 7
0 34 0 3
0 14 -1 0
0 33 11 0
1
end_operator
begin_operator
unstack b5 b9
0
4
0 17 0 7
0 34 0 3
0 12 -1 0
0 33 12 0
1
end_operator
begin_operator
unstack b6 b16
0
4
0 17 0 6
0 6 -1 0
0 4 0 1
0 20 0 3
1
end_operator
begin_operator
unstack b6 b18
0
4
0 17 0 6
0 3 -1 0
0 4 0 1
0 20 1 3
1
end_operator
begin_operator
unstack b7 b1
0
4
0 17 0 7
0 11 -1 0
0 15 0 1
0 36 1 0
1
end_operator
begin_operator
unstack b7 b10
0
4
0 17 0 7
0 10 -1 0
0 15 0 1
0 36 2 0
1
end_operator
begin_operator
unstack b7 b11
0
4
0 17 0 7
0 9 -1 0
0 15 0 1
0 36 3 0
1
end_operator
begin_operator
unstack b7 b12
0
4
0 17 0 7
0 7 -1 0
0 15 0 1
0 36 4 0
1
end_operator
begin_operator
unstack b7 b13
0
4
0 17 0 7
0 16 -1 0
0 15 0 1
0 36 5 0
1
end_operator
begin_operator
unstack b7 b14
0
4
0 17 0 7
0 1 -1 0
0 15 0 1
0 36 6 0
1
end_operator
begin_operator
unstack b7 b15
0
4
0 17 0 7
0 2 -1 0
0 15 0 1
0 36 7 0
1
end_operator
begin_operator
unstack b7 b16
0
4
0 17 0 7
0 6 -1 0
0 15 0 1
0 36 8 0
1
end_operator
begin_operator
unstack b7 b17
0
4
0 17 0 7
0 39 -1 0
0 15 0 1
0 36 9 0
1
end_operator
begin_operator
unstack b7 b19
0
4
0 17 0 7
0 38 -1 0
0 15 0 1
0 36 10 0
1
end_operator
begin_operator
unstack b7 b2
0
4
0 17 0 7
0 5 -1 0
0 15 0 1
0 36 11 0
1
end_operator
begin_operator
unstack b7 b20
0
4
0 17 0 7
0 8 -1 0
0 15 0 1
0 36 12 0
1
end_operator
begin_operator
unstack b7 b8
0
4
0 17 0 7
0 15 0 1
0 14 -1 0
0 36 13 0
1
end_operator
begin_operator
unstack b7 b9
0
4
0 17 0 7
0 15 0 1
0 12 -1 0
0 36 14 0
1
end_operator
begin_operator
unstack b8 b11
0
4
0 17 0 7
0 9 -1 0
0 14 0 1
0 31 1 0
1
end_operator
begin_operator
unstack b8 b12
0
4
0 17 0 7
0 7 -1 0
0 14 0 1
0 31 2 0
1
end_operator
begin_operator
unstack b8 b13
0
4
0 17 0 7
0 16 -1 0
0 14 0 1
0 31 3 0
1
end_operator
begin_operator
unstack b8 b15
0
4
0 17 0 7
0 2 -1 0
0 14 0 1
0 31 4 0
1
end_operator
begin_operator
unstack b8 b16
0
4
0 17 0 7
0 6 -1 0
0 14 0 1
0 31 5 0
1
end_operator
begin_operator
unstack b8 b17
0
4
0 17 0 7
0 39 -1 0
0 14 0 1
0 31 6 0
1
end_operator
begin_operator
unstack b8 b19
0
4
0 17 0 7
0 38 -1 0
0 14 0 1
0 31 7 0
1
end_operator
begin_operator
unstack b8 b2
0
4
0 17 0 7
0 5 -1 0
0 14 0 1
0 31 8 0
1
end_operator
begin_operator
unstack b8 b20
0
4
0 17 0 7
0 8 -1 0
0 14 0 1
0 31 9 0
1
end_operator
begin_operator
unstack b8 b4
0
4
0 17 0 7
0 13 -1 0
0 14 0 1
0 31 10 0
1
end_operator
begin_operator
unstack b8 b6
0
4
0 17 0 7
0 4 -1 0
0 14 0 1
0 31 11 0
1
end_operator
begin_operator
unstack b9 b1
0
4
0 17 0 7
0 11 -1 0
0 12 0 1
0 32 1 0
1
end_operator
begin_operator
unstack b9 b10
0
4
0 17 0 7
0 10 -1 0
0 12 0 1
0 32 2 0
1
end_operator
begin_operator
unstack b9 b11
0
4
0 17 0 7
0 9 -1 0
0 12 0 1
0 32 3 0
1
end_operator
begin_operator
unstack b9 b12
0
4
0 17 0 7
0 7 -1 0
0 12 0 1
0 32 4 0
1
end_operator
begin_operator
unstack b9 b13
0
4
0 17 0 7
0 16 -1 0
0 12 0 1
0 32 5 0
1
end_operator
begin_operator
unstack b9 b17
0
4
0 17 0 7
0 39 -1 0
0 12 0 1
0 32 6 0
1
end_operator
begin_operator
unstack b9 b19
0
4
0 17 0 7
0 38 -1 0
0 12 0 1
0 32 7 0
1
end_operator
begin_operator
unstack b9 b20
0
4
0 17 0 7
0 8 -1 0
0 12 0 1
0 32 8 0
1
end_operator
begin_operator
unstack b9 b4
0
4
0 17 0 7
0 13 -1 0
0 12 0 1
0 32 9 0
1
end_operator
begin_operator
unstack b9 b6
0
4
0 17 0 7
0 4 -1 0
0 12 0 1
0 32 10 0
1
end_operator
begin_operator
unstack b9 b7
0
4
0 17 0 7
0 15 -1 0
0 12 0 1
0 32 11 0
1
end_operator
begin_operator
unstack b9 b8
0
4
0 17 0 7
0 14 -1 0
0 12 0 1
0 32 12 0
1
end_operator
0
