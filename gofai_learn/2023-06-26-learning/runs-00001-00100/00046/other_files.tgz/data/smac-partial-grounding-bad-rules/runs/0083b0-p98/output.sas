begin_version
3
end_version
begin_metric
0
end_metric
59
begin_variable
var0
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var1
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var2
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var3
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var4
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var5
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var6
-1
2
Atom clear(b29)
NegatedAtom clear(b29)
end_variable
begin_variable
var7
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var8
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var9
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var11
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var12
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var10
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var13
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var14
-1
2
Atom clear(b28)
NegatedAtom clear(b28)
end_variable
begin_variable
var15
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var17
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var16
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var19
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var20
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var18
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var21
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var22
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var24
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var23
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var25
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var26
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var27
-1
30
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b28)
Atom holding(b29)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var28
-1
3
Atom on(b1, b24)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b8, b29)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var30
-1
3
Atom on(b2, b6)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var31
-1
4
Atom on(b20, b13)
Atom on(b20, b26)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var32
-1
3
Atom on(b21, b11)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var33
-1
3
Atom on(b26, b15)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var34
-1
3
Atom on(b29, b19)
Atom on-table(b29)
<none of those>
end_variable
begin_variable
var35
-1
3
Atom on(b3, b5)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var36
-1
4
Atom on(b7, b1)
Atom on(b7, b11)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var37
-1
4
Atom on(b9, b17)
Atom on(b9, b27)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var38
-1
5
Atom on(b27, b22)
Atom on(b27, b23)
Atom on(b27, b25)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var48
-1
11
Atom on(b15, b17)
Atom on(b15, b22)
Atom on(b15, b23)
Atom on(b15, b24)
Atom on(b15, b27)
Atom on(b15, b28)
Atom on(b15, b4)
Atom on(b15, b7)
Atom on(b15, b9)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var44
-1
12
Atom on(b28, b10)
Atom on(b28, b13)
Atom on(b28, b15)
Atom on(b28, b22)
Atom on(b28, b23)
Atom on(b28, b24)
Atom on(b28, b27)
Atom on(b28, b4)
Atom on(b28, b7)
Atom on(b28, b8)
Atom on-table(b28)
<none of those>
end_variable
begin_variable
var47
-1
12
Atom on(b13, b15)
Atom on(b13, b17)
Atom on(b13, b22)
Atom on(b13, b23)
Atom on(b13, b24)
Atom on(b13, b27)
Atom on(b13, b28)
Atom on(b13, b29)
Atom on(b13, b4)
Atom on(b13, b7)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var51
-1
12
Atom on(b4, b13)
Atom on(b4, b15)
Atom on(b4, b17)
Atom on(b4, b22)
Atom on(b4, b23)
Atom on(b4, b24)
Atom on(b4, b27)
Atom on(b4, b28)
Atom on(b4, b3)
Atom on(b4, b7)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var45
-1
21
Atom on(b11, b10)
Atom on(b11, b12)
Atom on(b11, b13)
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b20)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b28)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b9)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var52
-1
21
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b14)
Atom on(b5, b15)
Atom on(b5, b16)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b20)
Atom on(b5, b22)
Atom on(b5, b23)
Atom on(b5, b24)
Atom on(b5, b25)
Atom on(b5, b27)
Atom on(b5, b28)
Atom on(b5, b4)
Atom on(b5, b7)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var39
-1
22
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b18)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b25)
Atom on(b12, b27)
Atom on(b12, b28)
Atom on(b12, b29)
Atom on(b12, b3)
Atom on(b12, b6)
Atom on(b12, b9)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var40
-1
22
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b13)
Atom on(b14, b15)
Atom on(b14, b16)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b20)
Atom on(b14, b21)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b27)
Atom on(b14, b28)
Atom on(b14, b29)
Atom on(b14, b5)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b9)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var46
-1
23
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b18)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b21)
Atom on(b17, b23)
Atom on(b17, b24)
Atom on(b17, b25)
Atom on(b17, b27)
Atom on(b17, b28)
Atom on(b17, b29)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b5)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b9)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var41
-1
23
Atom on(b18, b10)
Atom on(b18, b11)
Atom on(b18, b12)
Atom on(b18, b13)
Atom on(b18, b14)
Atom on(b18, b15)
Atom on(b18, b16)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b20)
Atom on(b18, b22)
Atom on(b18, b23)
Atom on(b18, b24)
Atom on(b18, b25)
Atom on(b18, b27)
Atom on(b18, b28)
Atom on(b18, b29)
Atom on(b18, b4)
Atom on(b18, b5)
Atom on(b18, b6)
Atom on(b18, b9)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var42
-1
23
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b12)
Atom on(b19, b13)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b18)
Atom on(b19, b2)
Atom on(b19, b22)
Atom on(b19, b23)
Atom on(b19, b25)
Atom on(b19, b27)
Atom on(b19, b28)
Atom on(b19, b29)
Atom on(b19, b3)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var43
-1
23
Atom on(b23, b10)
Atom on(b23, b11)
Atom on(b23, b12)
Atom on(b23, b13)
Atom on(b23, b14)
Atom on(b23, b15)
Atom on(b23, b19)
Atom on(b23, b2)
Atom on(b23, b20)
Atom on(b23, b21)
Atom on(b23, b22)
Atom on(b23, b24)
Atom on(b23, b27)
Atom on(b23, b28)
Atom on(b23, b29)
Atom on(b23, b3)
Atom on(b23, b5)
Atom on(b23, b6)
Atom on(b23, b7)
Atom on(b23, b8)
Atom on(b23, b9)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var50
-1
24
Atom on(b25, b10)
Atom on(b25, b11)
Atom on(b25, b12)
Atom on(b25, b13)
Atom on(b25, b14)
Atom on(b25, b15)
Atom on(b25, b16)
Atom on(b25, b19)
Atom on(b25, b2)
Atom on(b25, b20)
Atom on(b25, b21)
Atom on(b25, b22)
Atom on(b25, b23)
Atom on(b25, b24)
Atom on(b25, b27)
Atom on(b25, b28)
Atom on(b25, b29)
Atom on(b25, b3)
Atom on(b25, b4)
Atom on(b25, b6)
Atom on(b25, b7)
Atom on(b25, b9)
Atom on-table(b25)
<none of those>
end_variable
begin_variable
var53
-1
23
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b16)
Atom on(b6, b18)
Atom on(b6, b19)
Atom on(b6, b2)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b22)
Atom on(b6, b23)
Atom on(b6, b24)
Atom on(b6, b25)
Atom on(b6, b27)
Atom on(b6, b28)
Atom on(b6, b29)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b7)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var56
-1
24
Atom on(b22, b11)
Atom on(b22, b12)
Atom on(b22, b13)
Atom on(b22, b14)
Atom on(b22, b15)
Atom on(b22, b16)
Atom on(b22, b17)
Atom on(b22, b18)
Atom on(b22, b19)
Atom on(b22, b2)
Atom on(b22, b20)
Atom on(b22, b21)
Atom on(b22, b23)
Atom on(b22, b24)
Atom on(b22, b25)
Atom on(b22, b27)
Atom on(b22, b28)
Atom on(b22, b4)
Atom on(b22, b5)
Atom on(b22, b7)
Atom on(b22, b8)
Atom on(b22, b9)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var49
-1
25
Atom on(b24, b10)
Atom on(b24, b11)
Atom on(b24, b13)
Atom on(b24, b14)
Atom on(b24, b15)
Atom on(b24, b16)
Atom on(b24, b18)
Atom on(b24, b19)
Atom on(b24, b2)
Atom on(b24, b20)
Atom on(b24, b21)
Atom on(b24, b22)
Atom on(b24, b23)
Atom on(b24, b25)
Atom on(b24, b27)
Atom on(b24, b29)
Atom on(b24, b3)
Atom on(b24, b4)
Atom on(b24, b5)
Atom on(b24, b6)
Atom on(b24, b7)
Atom on(b24, b8)
Atom on(b24, b9)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var54
-1
26
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b16)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b25)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b28)
Atom on(b10, b29)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var55
-1
26
Atom on(b16, b10)
Atom on(b16, b12)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b24)
Atom on(b16, b25)
Atom on(b16, b27)
Atom on(b16, b28)
Atom on(b16, b29)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b5)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var57
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var58
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
6789
begin_mutex_group
3
27 1
0 0
36 0
end_mutex_group
begin_mutex_group
14
27 2
22 0
43 0
45 0
46 0
56 0
47 0
48 0
49 0
50 0
54 0
51 0
40 0
44 0
end_mutex_group
begin_mutex_group
16
27 3
18 0
55 0
45 1
46 1
47 1
48 1
49 1
32 0
53 0
50 1
54 1
51 1
44 1
52 0
36 1
end_mutex_group
begin_mutex_group
13
27 4
15 0
55 1
43 1
56 1
47 2
48 2
49 2
53 1
50 2
51 2
44 2
52 1
end_mutex_group
begin_mutex_group
18
27 5
13 0
55 2
43 2
45 2
46 2
56 2
48 3
49 3
31 0
53 2
50 3
54 2
51 3
40 1
42 0
44 3
52 2
end_mutex_group
begin_mutex_group
15
27 6
21 0
55 3
43 3
45 3
56 3
47 3
48 4
49 4
53 3
50 4
54 3
51 4
44 4
52 3
end_mutex_group
begin_mutex_group
18
27 7
11 0
43 4
45 4
41 0
46 3
56 4
47 4
48 5
49 5
53 4
50 5
54 4
51 5
33 0
40 2
42 1
44 5
end_mutex_group
begin_mutex_group
13
27 8
24 0
55 4
43 5
45 5
46 4
48 6
49 6
53 5
54 5
51 6
44 6
52 4
end_mutex_group
begin_mutex_group
8
27 9
12 0
41 1
39 0
56 5
53 6
42 2
37 0
end_mutex_group
begin_mutex_group
13
27 10
17 0
55 5
43 6
45 6
46 5
56 6
47 5
49 7
53 7
54 6
44 7
52 5
end_mutex_group
begin_mutex_group
14
27 11
20 0
55 6
43 7
46 6
56 7
48 7
53 8
50 6
54 7
51 7
34 0
44 8
52 6
end_mutex_group
begin_mutex_group
13
27 12
5 0
55 7
45 7
56 8
47 6
48 8
49 8
53 9
50 7
54 8
51 8
52 7
end_mutex_group
begin_mutex_group
15
27 13
7 0
55 8
43 8
45 8
46 7
56 9
47 7
48 9
53 10
50 8
54 9
51 9
44 9
52 8
end_mutex_group
begin_mutex_group
12
27 14
4 0
55 9
45 9
46 8
56 10
47 8
53 11
50 9
54 10
51 10
52 9
end_mutex_group
begin_mutex_group
19
27 15
58 0
55 10
43 9
45 10
41 2
46 9
39 1
56 11
48 10
49 9
50 10
54 11
51 11
38 0
40 3
42 3
44 10
52 10
end_mutex_group
begin_mutex_group
20
27 16
25 0
55 11
43 10
45 11
41 3
46 10
39 2
56 12
47 9
48 11
49 10
53 12
54 12
51 12
38 1
40 4
42 4
44 11
52 11
end_mutex_group
begin_mutex_group
19
27 17
26 0
28 0
55 12
43 11
45 12
41 4
46 11
39 3
56 13
47 10
48 12
53 13
50 11
51 13
40 5
42 5
44 12
52 12
end_mutex_group
begin_mutex_group
15
27 18
23 0
55 13
43 12
45 13
46 12
56 14
47 11
48 13
49 11
53 14
54 13
38 2
44 13
52 13
end_mutex_group
begin_mutex_group
4
27 19
1 0
55 14
31 1
end_mutex_group
begin_mutex_group
20
27 20
57 0
55 15
45 14
41 5
46 13
39 4
56 15
47 12
48 14
49 12
53 15
50 12
54 14
51 14
40 6
42 6
44 14
52 14
37 1
end_mutex_group
begin_mutex_group
18
27 21
14 0
55 16
43 13
45 15
41 6
46 14
39 5
56 16
47 13
48 15
49 13
53 16
50 13
51 15
42 7
44 15
52 15
end_mutex_group
begin_mutex_group
15
27 22
6 0
55 17
45 16
41 7
46 15
56 17
47 14
48 16
49 14
50 14
54 15
51 16
52 16
29 0
end_mutex_group
begin_mutex_group
12
27 23
3 0
55 18
45 17
56 18
47 15
49 15
50 15
54 16
51 17
42 8
52 17
end_mutex_group
begin_mutex_group
16
27 24
10 0
55 19
43 14
41 8
39 6
56 19
47 16
48 17
49 16
53 17
54 17
51 18
40 7
44 16
52 18
end_mutex_group
begin_mutex_group
14
27 25
16 0
55 20
43 15
46 16
56 20
47 17
48 18
49 17
53 18
50 16
54 18
35 0
52 19
end_mutex_group
begin_mutex_group
14
27 26
19 0
55 21
43 16
45 18
46 17
56 21
47 18
48 19
49 18
30 0
50 17
54 19
51 19
end_mutex_group
begin_mutex_group
18
27 27
9 0
55 22
43 17
41 9
46 18
39 7
56 22
47 19
49 19
53 19
50 18
54 20
51 20
40 8
42 9
44 17
52 20
end_mutex_group
begin_mutex_group
6
27 28
2 0
53 20
50 19
54 21
40 9
end_mutex_group
begin_mutex_group
16
27 29
8 0
55 23
43 18
45 19
46 19
39 8
56 23
47 20
48 20
49 20
53 21
50 20
54 22
51 21
44 18
end_mutex_group
begin_mutex_group
3
27 1
28 0
28 1
end_mutex_group
begin_mutex_group
26
27 2
55 0
55 1
55 2
55 3
55 4
55 5
55 6
55 7
55 8
55 9
55 10
55 11
55 12
55 13
55 14
55 15
55 16
55 17
55 18
55 19
55 20
55 21
55 22
55 23
55 24
end_mutex_group
begin_mutex_group
21
27 3
43 0
43 1
43 2
43 3
43 4
43 5
43 6
43 7
43 8
43 9
43 10
43 11
43 12
43 13
43 14
43 15
43 16
43 17
43 18
43 19
end_mutex_group
begin_mutex_group
22
27 4
45 0
45 1
45 2
45 3
45 4
45 5
45 6
45 7
45 8
45 9
45 10
45 11
45 12
45 13
45 14
45 15
45 16
45 17
45 18
45 19
45 20
end_mutex_group
begin_mutex_group
12
27 5
41 0
41 1
41 2
41 3
41 4
41 5
41 6
41 7
41 8
41 9
41 10
end_mutex_group
begin_mutex_group
22
27 6
46 0
46 1
46 2
46 3
46 4
46 5
46 6
46 7
46 8
46 9
46 10
46 11
46 12
46 13
46 14
46 15
46 16
46 17
46 18
46 19
46 20
end_mutex_group
begin_mutex_group
11
27 7
39 0
39 1
39 2
39 3
39 4
39 5
39 6
39 7
39 8
39 9
end_mutex_group
begin_mutex_group
26
27 8
56 0
56 1
56 2
56 3
56 4
56 5
56 6
56 7
56 8
56 9
56 10
56 11
56 12
56 13
56 14
56 15
56 16
56 17
56 18
56 19
56 20
56 21
56 22
56 23
56 24
end_mutex_group
begin_mutex_group
23
27 9
47 0
47 1
47 2
47 3
47 4
47 5
47 6
47 7
47 8
47 9
47 10
47 11
47 12
47 13
47 14
47 15
47 16
47 17
47 18
47 19
47 20
47 21
end_mutex_group
begin_mutex_group
23
27 10
48 0
48 1
48 2
48 3
48 4
48 5
48 6
48 7
48 8
48 9
48 10
48 11
48 12
48 13
48 14
48 15
48 16
48 17
48 18
48 19
48 20
48 21
end_mutex_group
begin_mutex_group
23
27 11
49 0
49 1
49 2
49 3
49 4
49 5
49 6
49 7
49 8
49 9
49 10
49 11
49 12
49 13
49 14
49 15
49 16
49 17
49 18
49 19
49 20
49 21
end_mutex_group
begin_mutex_group
3
27 12
30 0
30 1
end_mutex_group
begin_mutex_group
4
27 13
31 0
31 1
31 2
end_mutex_group
begin_mutex_group
3
27 14
32 0
32 1
end_mutex_group
begin_mutex_group
24
27 15
53 0
53 1
53 2
53 3
53 4
53 5
53 6
53 7
53 8
53 9
53 10
53 11
53 12
53 13
53 14
53 15
53 16
53 17
53 18
53 19
53 20
53 21
53 22
end_mutex_group
begin_mutex_group
23
27 16
50 0
50 1
50 2
50 3
50 4
50 5
50 6
50 7
50 8
50 9
50 10
50 11
50 12
50 13
50 14
50 15
50 16
50 17
50 18
50 19
50 20
50 21
end_mutex_group
begin_mutex_group
25
27 17
54 0
54 1
54 2
54 3
54 4
54 5
54 6
54 7
54 8
54 9
54 10
54 11
54 12
54 13
54 14
54 15
54 16
54 17
54 18
54 19
54 20
54 21
54 22
54 23
end_mutex_group
begin_mutex_group
24
27 18
51 0
51 1
51 2
51 3
51 4
51 5
51 6
51 7
51 8
51 9
51 10
51 11
51 12
51 13
51 14
51 15
51 16
51 17
51 18
51 19
51 20
51 21
51 22
end_mutex_group
begin_mutex_group
3
27 19
33 0
33 1
end_mutex_group
begin_mutex_group
5
27 20
38 0
38 1
38 2
38 3
end_mutex_group
begin_mutex_group
12
27 21
40 0
40 1
40 2
40 3
40 4
40 5
40 6
40 7
40 8
40 9
40 10
end_mutex_group
begin_mutex_group
3
27 22
34 0
34 1
end_mutex_group
begin_mutex_group
3
27 23
35 0
35 1
end_mutex_group
begin_mutex_group
12
27 24
42 0
42 1
42 2
42 3
42 4
42 5
42 6
42 7
42 8
42 9
42 10
end_mutex_group
begin_mutex_group
21
27 25
44 0
44 1
44 2
44 3
44 4
44 5
44 6
44 7
44 8
44 9
44 10
44 11
44 12
44 13
44 14
44 15
44 16
44 17
44 18
44 19
end_mutex_group
begin_mutex_group
23
27 26
52 0
52 1
52 2
52 3
52 4
52 5
52 6
52 7
52 8
52 9
52 10
52 11
52 12
52 13
52 14
52 15
52 16
52 17
52 18
52 19
52 20
52 21
end_mutex_group
begin_mutex_group
4
27 27
36 0
36 1
36 2
end_mutex_group
begin_mutex_group
3
27 28
29 0
29 1
end_mutex_group
begin_mutex_group
4
27 29
37 0
37 1
37 2
end_mutex_group
begin_mutex_group
2
0 0
28 2
end_mutex_group
begin_mutex_group
2
1 0
27 1
end_mutex_group
begin_mutex_group
2
1 0
28 0
end_mutex_group
begin_mutex_group
2
1 0
28 2
end_mutex_group
begin_mutex_group
2
1 0
33 2
end_mutex_group
begin_mutex_group
2
2 0
29 2
end_mutex_group
begin_mutex_group
2
3 0
35 2
end_mutex_group
begin_mutex_group
2
3 0
36 1
end_mutex_group
begin_mutex_group
2
3 0
37 1
end_mutex_group
begin_mutex_group
2
3 0
38 2
end_mutex_group
begin_mutex_group
2
4 0
32 2
end_mutex_group
begin_mutex_group
2
4 0
39 0
end_mutex_group
begin_mutex_group
2
5 0
30 2
end_mutex_group
begin_mutex_group
2
6 0
34 2
end_mutex_group
begin_mutex_group
2
6 1
27 28
end_mutex_group
begin_mutex_group
2
6 1
29 2
end_mutex_group
begin_mutex_group
2
7 0
27 1
end_mutex_group
begin_mutex_group
2
7 0
28 0
end_mutex_group
begin_mutex_group
2
7 0
28 2
end_mutex_group
begin_mutex_group
2
7 0
31 3
end_mutex_group
begin_mutex_group
2
8 0
36 1
end_mutex_group
begin_mutex_group
2
8 0
37 3
end_mutex_group
begin_mutex_group
2
9 0
36 3
end_mutex_group
begin_mutex_group
2
12 0
47 22
end_mutex_group
begin_mutex_group
2
10 0
42 11
end_mutex_group
begin_mutex_group
2
11 0
39 10
end_mutex_group
begin_mutex_group
2
13 0
41 11
end_mutex_group
begin_mutex_group
2
14 0
40 11
end_mutex_group
begin_mutex_group
2
15 0
27 1
end_mutex_group
begin_mutex_group
2
15 0
28 0
end_mutex_group
begin_mutex_group
2
15 0
28 2
end_mutex_group
begin_mutex_group
2
15 0
45 21
end_mutex_group
begin_mutex_group
2
17 0
48 22
end_mutex_group
begin_mutex_group
2
17 0
39 0
end_mutex_group
begin_mutex_group
2
16 0
27 1
end_mutex_group
begin_mutex_group
2
16 0
28 0
end_mutex_group
begin_mutex_group
2
16 0
28 2
end_mutex_group
begin_mutex_group
2
16 0
44 20
end_mutex_group
begin_mutex_group
2
20 0
27 1
end_mutex_group
begin_mutex_group
2
20 0
28 0
end_mutex_group
begin_mutex_group
2
20 0
28 2
end_mutex_group
begin_mutex_group
2
20 0
49 22
end_mutex_group
begin_mutex_group
2
18 0
43 20
end_mutex_group
begin_mutex_group
2
19 0
27 1
end_mutex_group
begin_mutex_group
2
19 0
28 0
end_mutex_group
begin_mutex_group
2
19 0
28 2
end_mutex_group
begin_mutex_group
2
19 0
52 22
end_mutex_group
begin_mutex_group
2
21 0
46 21
end_mutex_group
begin_mutex_group
2
22 0
27 1
end_mutex_group
begin_mutex_group
2
22 0
28 0
end_mutex_group
begin_mutex_group
2
22 0
28 2
end_mutex_group
begin_mutex_group
2
22 0
55 25
end_mutex_group
begin_mutex_group
2
24 0
56 25
end_mutex_group
begin_mutex_group
2
23 0
36 1
end_mutex_group
begin_mutex_group
2
23 0
37 1
end_mutex_group
begin_mutex_group
2
23 0
51 23
end_mutex_group
begin_mutex_group
2
25 0
50 22
end_mutex_group
begin_mutex_group
2
26 0
54 24
end_mutex_group
begin_mutex_group
2
26 1
27 1
end_mutex_group
begin_mutex_group
2
26 1
28 2
end_mutex_group
begin_mutex_group
2
27 0
28 2
end_mutex_group
begin_mutex_group
2
27 0
29 2
end_mutex_group
begin_mutex_group
2
27 0
30 2
end_mutex_group
begin_mutex_group
2
27 0
31 3
end_mutex_group
begin_mutex_group
2
27 0
32 2
end_mutex_group
begin_mutex_group
2
27 0
33 2
end_mutex_group
begin_mutex_group
2
27 0
34 2
end_mutex_group
begin_mutex_group
2
27 0
35 2
end_mutex_group
begin_mutex_group
2
27 0
36 3
end_mutex_group
begin_mutex_group
2
27 0
37 3
end_mutex_group
begin_mutex_group
2
27 0
38 4
end_mutex_group
begin_mutex_group
2
27 0
45 21
end_mutex_group
begin_mutex_group
2
27 0
46 21
end_mutex_group
begin_mutex_group
2
27 0
48 22
end_mutex_group
begin_mutex_group
2
27 0
49 22
end_mutex_group
begin_mutex_group
2
27 0
50 22
end_mutex_group
begin_mutex_group
2
27 0
40 11
end_mutex_group
begin_mutex_group
2
27 0
43 20
end_mutex_group
begin_mutex_group
2
27 0
47 22
end_mutex_group
begin_mutex_group
2
27 0
41 11
end_mutex_group
begin_mutex_group
2
27 0
39 10
end_mutex_group
begin_mutex_group
2
27 0
54 24
end_mutex_group
begin_mutex_group
2
27 0
51 23
end_mutex_group
begin_mutex_group
2
27 0
42 11
end_mutex_group
begin_mutex_group
2
27 0
44 20
end_mutex_group
begin_mutex_group
2
27 0
52 22
end_mutex_group
begin_mutex_group
2
27 0
55 25
end_mutex_group
begin_mutex_group
2
27 0
56 25
end_mutex_group
begin_mutex_group
2
27 0
53 23
end_mutex_group
begin_mutex_group
2
27 1
29 2
end_mutex_group
begin_mutex_group
2
27 1
30 0
end_mutex_group
begin_mutex_group
2
27 1
30 2
end_mutex_group
begin_mutex_group
2
27 1
31 0
end_mutex_group
begin_mutex_group
2
27 1
31 2
end_mutex_group
begin_mutex_group
2
27 1
31 3
end_mutex_group
begin_mutex_group
2
27 1
32 2
end_mutex_group
begin_mutex_group
2
27 1
33 0
end_mutex_group
begin_mutex_group
2
27 1
33 2
end_mutex_group
begin_mutex_group
2
27 1
34 0
end_mutex_group
begin_mutex_group
2
27 1
34 2
end_mutex_group
begin_mutex_group
2
27 1
35 0
end_mutex_group
begin_mutex_group
2
27 1
35 2
end_mutex_group
begin_mutex_group
2
27 1
36 3
end_mutex_group
begin_mutex_group
2
27 1
37 3
end_mutex_group
begin_mutex_group
2
27 1
38 4
end_mutex_group
begin_mutex_group
2
27 1
45 0
end_mutex_group
begin_mutex_group
2
27 1
45 1
end_mutex_group
begin_mutex_group
2
27 1
45 2
end_mutex_group
begin_mutex_group
2
27 1
45 3
end_mutex_group
begin_mutex_group
2
27 1
45 4
end_mutex_group
begin_mutex_group
2
27 1
45 5
end_mutex_group
begin_mutex_group
2
27 1
45 6
end_mutex_group
begin_mutex_group
2
27 1
45 7
end_mutex_group
begin_mutex_group
2
27 1
45 8
end_mutex_group
begin_mutex_group
2
27 1
45 9
end_mutex_group
begin_mutex_group
2
27 1
45 10
end_mutex_group
begin_mutex_group
2
27 1
45 11
end_mutex_group
begin_mutex_group
2
27 1
45 12
end_mutex_group
begin_mutex_group
2
27 1
45 13
end_mutex_group
begin_mutex_group
2
27 1
45 14
end_mutex_group
begin_mutex_group
2
27 1
45 15
end_mutex_group
begin_mutex_group
2
27 1
45 16
end_mutex_group
begin_mutex_group
2
27 1
45 17
end_mutex_group
begin_mutex_group
2
27 1
45 19
end_mutex_group
begin_mutex_group
2
27 1
45 20
end_mutex_group
begin_mutex_group
2
27 1
45 21
end_mutex_group
begin_mutex_group
2
27 1
46 0
end_mutex_group
begin_mutex_group
2
27 1
46 6
end_mutex_group
begin_mutex_group
2
27 1
46 7
end_mutex_group
begin_mutex_group
2
27 1
46 11
end_mutex_group
begin_mutex_group
2
27 1
46 16
end_mutex_group
begin_mutex_group
2
27 1
46 17
end_mutex_group
begin_mutex_group
2
27 1
46 21
end_mutex_group
begin_mutex_group
2
27 1
48 0
end_mutex_group
begin_mutex_group
2
27 1
48 2
end_mutex_group
begin_mutex_group
2
27 1
48 7
end_mutex_group
begin_mutex_group
2
27 1
48 9
end_mutex_group
begin_mutex_group
2
27 1
48 12
end_mutex_group
begin_mutex_group
2
27 1
48 18
end_mutex_group
begin_mutex_group
2
27 1
48 19
end_mutex_group
begin_mutex_group
2
27 1
48 22
end_mutex_group
begin_mutex_group
2
27 1
49 1
end_mutex_group
begin_mutex_group
2
27 1
49 2
end_mutex_group
begin_mutex_group
2
27 1
49 3
end_mutex_group
begin_mutex_group
2
27 1
49 4
end_mutex_group
begin_mutex_group
2
27 1
49 5
end_mutex_group
begin_mutex_group
2
27 1
49 6
end_mutex_group
begin_mutex_group
2
27 1
49 7
end_mutex_group
begin_mutex_group
2
27 1
49 8
end_mutex_group
begin_mutex_group
2
27 1
49 9
end_mutex_group
begin_mutex_group
2
27 1
49 10
end_mutex_group
begin_mutex_group
2
27 1
49 11
end_mutex_group
begin_mutex_group
2
27 1
49 12
end_mutex_group
begin_mutex_group
2
27 1
49 13
end_mutex_group
begin_mutex_group
2
27 1
49 14
end_mutex_group
begin_mutex_group
2
27 1
49 15
end_mutex_group
begin_mutex_group
2
27 1
49 16
end_mutex_group
begin_mutex_group
2
27 1
49 17
end_mutex_group
begin_mutex_group
2
27 1
49 18
end_mutex_group
begin_mutex_group
2
27 1
49 19
end_mutex_group
begin_mutex_group
2
27 1
49 20
end_mutex_group
begin_mutex_group
2
27 1
49 21
end_mutex_group
begin_mutex_group
2
27 1
49 22
end_mutex_group
begin_mutex_group
2
27 1
50 0
end_mutex_group
begin_mutex_group
2
27 1
50 2
end_mutex_group
begin_mutex_group
2
27 1
50 6
end_mutex_group
begin_mutex_group
2
27 1
50 8
end_mutex_group
begin_mutex_group
2
27 1
50 11
end_mutex_group




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




23
0
4
0 27 0 4
0 15 0 1
0 25 -1 0
0 45 11 21
1
end_operator
begin_operator
unstack b12 b24
0
4
0 27 0 4
0 15 0 1
0 26 -1 0
0 45 12 21
1
end_operator
begin_operator
unstack b12 b25
0
4
0 27 0 4
0 15 0 1
0 23 -1 0
0 45 13 21
1
end_operator
begin_operator
unstack b12 b27
0
4
0 27 0 4
0 15 0 1
0 57 -1 0
0 45 14 21
1
end_operator
begin_operator
unstack b12 b28
0
4
0 27 0 4
0 15 0 1
0 14 -1 0
0 45 15 21
1
end_operator
begin_operator
unstack b12 b29
0
4
0 27 0 4
0 15 0 1
0 6 -1 0
0 45 16 21
1
end_operator
begin_operator
unstack b12 b3
0
4
0 27 0 4
0 15 0 1
0 3 -1 0
0 45 17 21
1
end_operator
begin_operator
unstack b12 b6
0
4
0 27 0 4
0 15 0 1
0 19 -1 0
0 45 18 21
1
end_operator
begin_operator
unstack b12 b9
0
4
0 27 0 4
0 15 0 1
0 8 -1 0
0 45 19 21
1
end_operator
begin_operator
unstack b13 b15
0
4
0 27 0 5
0 13 0 1
0 11 -1 0
0 41 0 11
1
end_operator
begin_operator
unstack b13 b17
0
4
0 27 0 5
0 13 0 1
0 12 -1 0
0 41 1 11
1
end_operator
begin_operator
unstack b13 b22
0
4
0 27 0 5
0 13 0 1
0 58 -1 0
0 41 2 11
1
end_operator
begin_operator
unstack b13 b23
0
4
0 27 0 5
0 13 0 1
0 25 -1 0
0 41 3 11
1
end_operator
begin_operator
unstack b13 b24
0
4
0 27 0 5
0 13 0 1
0 26 -1 0
0 41 4 11
1
end_operator
begin_operator
unstack b13 b27
0
4
0 27 0 5
0 13 0 1
0 57 -1 0
0 41 5 11
1
end_operator
begin_operator
unstack b13 b28
0
4
0 27 0 5
0 13 0 1
0 14 -1 0
0 41 6 11
1
end_operator
begin_operator
unstack b13 b4
0
4
0 27 0 5
0 13 0 1
0 10 -1 0
0 41 8 11
1
end_operator
begin_operator
unstack b13 b7
0
4
0 27 0 5
0 13 0 1
0 9 -1 0
0 41 9 11
1
end_operator
begin_operator
unstack b14 b10
0
4
0 27 0 6
0 22 -1 0
0 21 0 1
0 46 0 21
1
end_operator
begin_operator
unstack b14 b11
0
4
0 27 0 6
0 18 -1 0
0 21 0 1
0 46 1 21
1
end_operator
begin_operator
unstack b14 b13
0
4
0 27 0 6
0 13 -1 0
0 21 0 1
0 46 2 21
1
end_operator
begin_operator
unstack b14 b15
0
4
0 27 0 6
0 21 0 1
0 11 -1 0
0 46 3 21
1
end_operator
begin_operator
unstack b14 b16
0
4
0 27 0 6
0 21 0 1
0 24 -1 0
0 46 4 21
1
end_operator
begin_operator
unstack b14 b18
0
4
0 27 0 6
0 21 0 1
0 17 -1 0
0 46 5 21
1
end_operator
begin_operator
unstack b14 b19
0
4
0 27 0 6
0 21 0 1
0 20 -1 0
0 46 6 21
1
end_operator
begin_operator
unstack b14 b20
0
4
0 27 0 6
0 21 0 1
0 7 -1 0
0 46 7 21
1
end_operator
begin_operator
unstack b14 b21
0
4
0 27 0 6
0 21 0 1
0 4 -1 0
0 46 8 21
1
end_operator
begin_operator
unstack b14 b22
0
4
0 27 0 6
0 21 0 1
0 58 -1 0
0 46 9 21
1
end_operator
begin_operator
unstack b14 b23
0
4
0 27 0 6
0 21 0 1
0 25 -1 0
0 46 10 21
1
end_operator
begin_operator
unstack b14 b24
0
4
0 27 0 6
0 21 0 1
0 26 -1 0
0 46 11 21
1
end_operator
begin_operator
unstack b14 b25
0
4
0 27 0 6
0 21 0 1
0 23 -1 0
0 46 12 21
1
end_operator
begin_operator
unstack b14 b27
0
4
0 27 0 6
0 21 0 1
0 57 -1 0
0 46 13 21
1
end_operator
begin_operator
unstack b14 b28
0
4
0 27 0 6
0 21 0 1
0 14 -1 0
0 46 14 21
1
end_operator
begin_operator
unstack b14 b29
0
4
0 27 0 6
0 21 0 1
0 6 -1 0
0 46 15 21
1
end_operator
begin_operator
unstack b14 b5
0
4
0 27 0 6
0 21 0 1
0 16 -1 0
0 46 16 21
1
end_operator
begin_operator
unstack b14 b6
0
4
0 27 0 6
0 21 0 1
0 19 -1 0
0 46 17 21
1
end_operator
begin_operator
unstack b14 b7
0
4
0 27 0 6
0 21 0 1
0 9 -1 0
0 46 18 21
1
end_operator
begin_operator
unstack b14 b9
0
4
0 27 0 6
0 21 0 1
0 8 -1 0
0 46 19 21
1
end_operator
begin_operator
unstack b15 b17
0
4
0 27 0 7
0 11 0 1
0 12 -1 0
0 39 0 10
1
end_operator
begin_operator
unstack b15 b22
0
4
0 27 0 7
0 11 0 1
0 58 -1 0
0 39 1 10
1
end_operator
begin_operator
unstack b15 b23
0
4
0 27 0 7
0 11 0 1
0 25 -1 0
0 39 2 10
1
end_operator
begin_operator
unstack b15 b24
0
4
0 27 0 7
0 11 0 1
0 26 -1 0
0 39 3 10
1
end_operator
begin_operator
unstack b15 b27
0
4
0 27 0 7
0 11 0 1
0 57 -1 0
0 39 4 10
1
end_operator
begin_operator
unstack b15 b28
0
4
0 27 0 7
0 11 0 1
0 14 -1 0
0 39 5 10
1
end_operator
begin_operator
unstack b15 b4
0
4
0 27 0 7
0 11 0 1
0 10 -1 0
0 39 6 10
1
end_operator
begin_operator
unstack b15 b7
0
4
0 27 0 7
0 11 0 1
0 9 -1 0
0 39 7 10
1
end_operator
begin_operator
unstack b16 b10
0
4
0 27 0 8
0 22 -1 0
0 24 0 1
0 56 0 25
1
end_operator
begin_operator
unstack b16 b12
0
4
0 27 0 8
0 15 -1 0
0 24 0 1
0 56 1 25
1
end_operator
begin_operator
unstack b16 b13
0
4
0 27 0 8
0 13 -1 0
0 24 0 1
0 56 2 25
1
end_operator
begin_operator
unstack b16 b14
0
4
0 27 0 8
0 21 -1 0
0 24 0 1
0 56 3 25
1
end_operator
begin_operator
unstack b16 b15
0
4
0 27 0 8
0 11 -1 0
0 24 0 1
0 56 4 25
1
end_operator
begin_operator
unstack b16 b17
0
4
0 27 0 8
0 24 0 1
0 12 -1 0
0 56 5 25
1
end_operator
begin_operator
unstack b16 b18
0
4
0 27 0 8
0 24 0 1
0 17 -1 0
0 56 6 25
1
end_operator
begin_operator
unstack b16 b19
0
4
0 27 0 8
0 24 0 1
0 20 -1 0
0 56 7 25
1
end_operator
begin_operator
unstack b16 b2
0
4
0 27 0 8
0 24 0 1
0 5 -1 0
0 56 8 25
1
end_operator
begin_operator
unstack b16 b20
0
4
0 27 0 8
0 24 0 1
0 7 -1 0
0 56 9 25
1
end_operator
begin_operator
unstack b16 b21
0
4
0 27 0 8
0 24 0 1
0 4 -1 0
0 56 10 25
1
end_operator
begin_operator
unstack b16 b22
0
4
0 27 0 8
0 24 0 1
0 58 -1 0
0 56 11 25
1
end_operator
begin_operator
unstack b16 b23
0
4
0 27 0 8
0 24 0 1
0 25 -1 0
0 56 12 25
1
end_operator
begin_operator
unstack b16 b24
0
4
0 27 0 8
0 24 0 1
0 26 -1 0
0 56 13 25
1
end_operator
begin_operator
unstack b16 b25
0
4
0 27 0 8
0 24 0 1
0 23 -1 0
0 56 14 25
1
end_operator
begin_operator
unstack b16 b27
0
4
0 27 0 8
0 24 0 1
0 57 -1 0
0 56 15 25
1
end_operator
begin_operator
unstack b16 b28
0
4
0 27 0 8
0 24 0 1
0 14 -1 0
0 56 16 25
1
end_operator
begin_operator
unstack b16 b29
0
4
0 27 0 8
0 24 0 1
0 6 -1 0
0 56 17 25
1
end_operator
begin_operator
unstack b16 b3
0
4
0 27 0 8
0 24 0 1
0 3 -1 0
0 56 18 25
1
end_operator
begin_operator
unstack b16 b4
0
4
0 27 0 8
0 24 0 1
0 10 -1 0
0 56 19 25
1
end_operator
begin_operator
unstack b16 b5
0
4
0 27 0 8
0 24 0 1
0 16 -1 0
0 56 20 25
1
end_operator
begin_operator
unstack b16 b6
0
4
0 27 0 8
0 24 0 1
0 19 -1 0
0 56 21 25
1
end_operator
begin_operator
unstack b16 b7
0
4
0 27 0 8
0 24 0 1
0 9 -1 0
0 56 22 25
1
end_operator
begin_operator
unstack b16 b9
0
4
0 27 0 8
0 24 0 1
0 8 -1 0
0 56 23 25
1
end_operator
begin_operator
unstack b17 b10
0
4
0 27 0 9
0 22 -1 0
0 12 0 1
0 47 0 22
1
end_operator
begin_operator
unstack b17 b11
0
4
0 27 0 9
0 18 -1 0
0 12 0 1
0 47 1 22
1
end_operator
begin_operator
unstack b17 b12
0
4
0 27 0 9
0 15 -1 0
0 12 0 1
0 47 2 22
1
end_operator
begin_operator
unstack b17 b14
0
4
0 27 0 9
0 21 -1 0
0 12 0 1
0 47 3 22
1
end_operator
begin_operator
unstack b17 b15
0
4
0 27 0 9
0 11 -1 0
0 12 0 1
0 47 4 22
1
end_operator
begin_operator
unstack b17 b18
0
4
0 27 0 9
0 12 0 1
0 17 -1 0
0 47 5 22
1
end_operator
begin_operator
unstack b17 b2
0
4
0 27 0 9
0 12 0 1
0 5 -1 0
0 47 6 22
1
end_operator
begin_operator
unstack b17 b20
0
4
0 27 0 9
0 12 0 1
0 7 -1 0
0 47 7 22
1
end_operator
begin_operator
unstack b17 b21
0
4
0 27 0 9
0 12 0 1
0 4 -1 0
0 47 8 22
1
end_operator
begin_operator
unstack b17 b23
0
4
0 27 0 9
0 12 0 1
0 25 -1 0
0 47 9 22
1
end_operator
begin_operator
unstack b17 b24
0
4
0 27 0 9
0 12 0 1
0 26 -1 0
0 47 10 22
1
end_operator
begin_operator
unstack b17 b25
0
4
0 27 0 9
0 12 0 1
0 23 -1 0
0 47 11 22
1
end_operator
begin_operator
unstack b17 b27
0
4
0 27 0 9
0 12 0 1
0 57 -1 0
0 47 12 22
1
end_operator
begin_operator
unstack b17 b28
0
4
0 27 0 9
0 12 0 1
0 14 -1 0
0 47 13 22
1
end_operator
begin_operator
unstack b17 b29
0
4
0 27 0 9
0 12 0 1
0 6 -1 0
0 47 14 22
1
end_operator
begin_operator
unstack b17 b3
0
4
0 27 0 9
0 12 0 1
0 3 -1 0
0 47 15 22
1
end_operator
begin_operator
unstack b17 b4
0
4
0 27 0 9
0 12 0 1
0 10 -1 0
0 47 16 22
1
end_operator
begin_operator
unstack b17 b5
0
4
0 27 0 9
0 12 0 1
0 16 -1 0
0 47 17 22
1
end_operator
begin_operator
unstack b17 b6
0
4
0 27 0 9
0 12 0 1
0 19 -1 0
0 47 18 22
1
end_operator
begin_operator
unstack b17 b7
0
4
0 27 0 9
0 12 0 1
0 9 -1 0
0 47 19 22
1
end_operator
begin_operator
unstack b17 b9
0
4
0 27 0 9
0 12 0 1
0 8 -1 0
0 47 20 22
1
end_operator
begin_operator
unstack b18 b10
0
4
0 27 0 10
0 22 -1 0
0 17 0 1
0 48 0 22
1
end_operator
begin_operator
unstack b18 b11
0
4
0 27 0 10
0 18 -1 0
0 17 0 1
0 48 1 22
1
end_operator
begin_operator
unstack b18 b12
0
4
0 27 0 10
0 15 -1 0
0 17 0 1
0 48 2 22
1
end_operator
begin_operator
unstack b18 b13
0
4
0 27 0 10
0 13 -1 0
0 17 0 1
0 48 3 22
1
end_operator
begin_operator
unstack b18 b14
0
4
0 27 0 10
0 21 -1 0
0 17 0 1
0 48 4 22
1
end_operator
begin_operator
unstack b18 b15
0
4
0 27 0 10
0 11 -1 0
0 17 0 1
0 48 5 22
1
end_operator
begin_operator
unstack b18 b16
0
4
0 27 0 10
0 24 -1 0
0 17 0 1
0 48 6 22
1
end_operator
begin_operator
unstack b18 b19
0
4
0 27 0 10
0 17 0 1
0 20 -1 0
0 48 7 22
1
end_operator
begin_operator
unstack b18 b2
0
4
0 27 0 10
0 17 0 1
0 5 -1 0
0 48 8 22
1
end_operator
begin_operator
unstack b18 b20
0
4
0 27 0 10
0 17 0 1
0 7 -1 0
0 48 9 22
1
end_operator
begin_operator
unstack b18 b22
0
4
0 27 0 10
0 17 0 1
0 58 -1 0
0 48 10 22
1
end_operator
begin_operator
unstack b18 b23
0
4
0 27 0 10
0 17 0 1
0 25 -1 0
0 48 11 22
1
end_operator
begin_operator
unstack b18 b24
0
4
0 27 0 10
0 17 0 1
0 26 -1 0
0 48 12 22
1
end_operator
begin_operator
unstack b18 b25
0
4
0 27 0 10
0 17 0 1
0 23 -1 0
0 48 13 22
1
end_operator
begin_operator
unstack b18 b27
0
4
0 27 0 10
0 17 0 1
0 57 -1 0
0 48 14 22
1
end_operator
begin_operator
unstack b18 b28
0
4
0 27 0 10
0 17 0 1
0 14 -1 0
0 48 15 22
1
end_operator
begin_operator
unstack b18 b29
0
4
0 27 0 10
0 17 0 1
0 6 -1 0
0 48 16 22
1
end_operator
begin_operator
unstack b18 b4
0
4
0 27 0 10
0 17 0 1
0 10 -1 0
0 48 17 22
1
end_operator
begin_operator
unstack b18 b5
0
4
0 27 0 10
0 17 0 1
0 16 -1 0
0 48 18 22
1
end_operator
begin_operator
unstack b18 b6
0
4
0 27 0 10
0 17 0 1
0 19 -1 0
0 48 19 22
1
end_operator
begin_operator
unstack b18 b9
0
4
0 27 0 10
0 17 0 1
0 8 -1 0
0 48 20 22
1
end_operator
begin_operator
unstack b19 b10
0
4
0 27 0 11
0 22 -1 0
0 20 0 1
0 49 0 22
1
end_operator
begin_operator
unstack b19 b11
0
4
0 27 0 11
0 18 -1 0
0 20 0 1
0 49 1 22
1
end_operator
begin_operator
unstack b19 b12
0
4
0 27 0 11
0 15 -1 0
0 20 0 1
0 49 2 22
1
end_operator
begin_operator
unstack b19 b13
0
4
0 27 0 11
0 13 -1 0
0 20 0 1
0 49 3 22
1
end_operator
begin_operator
unstack b19 b14
0
4
0 27 0 11
0 21 -1 0
0 20 0 1
0 49 4 22
1
end_operator
begin_operator
unstack b19 b15
0
4
0 27 0 11
0 11 -1 0
0 20 0 1
0 49 5 22
1
end_operator
begin_operator
unstack b19 b16
0
4
0 27 0 11
0 24 -1 0
0 20 0 1
0 49 6 22
1
end_operator
begin_operator
unstack b19 b18
0
4
0 27 0 11
0 17 -1 0
0 20 0 1
0 49 7 22
1
end_operator
begin_operator
unstack b19 b2
0
4
0 27 0 11
0 20 0 1
0 5 -1 0
0 49 8 22
1
end_operator
begin_operator
unstack b19 b22
0
4
0 27 0 11
0 20 0 1
0 58 -1 0
0 49 9 22
1
end_operator
begin_operator
unstack b19 b23
0
4
0 27 0 11
0 20 0 1
0 25 -1 0
0 49 10 22
1
end_operator
begin_operator
unstack b19 b25
0
4
0 27 0 11
0 20 0 1
0 23 -1 0
0 49 11 22
1
end_operator
begin_operator
unstack b19 b27
0
4
0 27 0 11
0 20 0 1
0 57 -1 0
0 49 12 22
1
end_operator
begin_operator
unstack b19 b28
0
4
0 27 0 11
0 20 0 1
0 14 -1 0
0 49 13 22
1
end_operator
begin_operator
unstack b19 b29
0
4
0 27 0 11
0 20 0 1
0 6 -1 0
0 49 14 22
1
end_operator
begin_operator
unstack b19 b3
0
4
0 27 0 11
0 20 0 1
0 3 -1 0
0 49 15 22
1
end_operator
begin_operator
unstack b19 b4
0
4
0 27 0 11
0 20 0 1
0 10 -1 0
0 49 16 22
1
end_operator
begin_operator
unstack b19 b5
0
4
0 27 0 11
0 20 0 1
0 16 -1 0
0 49 17 22
1
end_operator
begin_operator
unstack b19 b6
0
4
0 27 0 11
0 20 0 1
0 19 -1 0
0 49 18 22
1
end_operator
begin_operator
unstack b19 b7
0
4
0 27 0 11
0 20 0 1
0 9 -1 0
0 49 19 22
1
end_operator
begin_operator
unstack b19 b9
0
4
0 27 0 11
0 20 0 1
0 8 -1 0
0 49 20 22
1
end_operator
begin_operator
unstack b2 b6
0
4
0 27 0 12
0 5 0 1
0 19 -1 0
0 30 0 2
1
end_operator
begin_operator
unstack b20 b26
0
4
0 27 0 13
0 7 0 1
0 1 -1 0
0 31 1 3
1
end_operator
begin_operator
unstack b21 b11
0
4
0 27 0 14
0 18 -1 0
0 4 0 1
0 32 0 2
1
end_operator
begin_operator
unstack b22 b11
0
4
0 27 0 15
0 18 -1 0
0 58 0 1
0 53 0 23
1
end_operator
begin_operator
unstack b22 b12
0
4
0 27 0 15
0 15 -1 0
0 58 0 1
0 53 1 23
1
end_operator
begin_operator
unstack b22 b13
0
4
0 27 0 15
0 13 -1 0
0 58 0 1
0 53 2 23
1
end_operator
begin_operator
unstack b22 b14
0
4
0 27 0 15
0 21 -1 0
0 58 0 1
0 53 3 23
1
end_operator
begin_operator
unstack b22 b15
0
4
0 27 0 15
0 11 -1 0
0 58 0 1
0 53 4 23
1
end_operator
begin_operator
unstack b22 b16
0
4
0 27 0 15
0 24 -1 0
0 58 0 1
0 53 5 23
1
end_operator
begin_operator
unstack b22 b17
0
4
0 27 0 15
0 12 -1 0
0 58 0 1
0 53 6 23
1
end_operator
begin_operator
unstack b22 b18
0
4
0 27 0 15
0 17 -1 0
0 58 0 1
0 53 7 23
1
end_operator
begin_operator
unstack b22 b19
0
4
0 27 0 15
0 20 -1 0
0 58 0 1
0 53 8 23
1
end_operator
begin_operator
unstack b22 b20
0
4
0 27 0 15
0 7 -1 0
0 58 0 1
0 53 10 23
1
end_operator
begin_operator
unstack b22 b21
0
4
0 27 0 15
0 4 -1 0
0 58 0 1
0 53 11 23
1
end_operator
begin_operator
unstack b22 b23
0
4
0 27 0 15
0 58 0 1
0 25 -1 0
0 53 12 23
1
end_operator
begin_operator
unstack b22 b24
0
4
0 27 0 15
0 58 0 1
0 26 -1 0
0 53 13 23
1
end_operator
begin_operator
unstack b22 b25
0
4
0 27 0 15
0 58 0 1
0 23 -1 0
0 53 14 23
1
end_operator
begin_operator
unstack b22 b27
0
4
0 27 0 15
0 58 0 1
0 57 -1 0
0 53 15 23
1
end_operator
begin_operator
unstack b22 b28
0
4
0 27 0 15
0 58 0 1
0 14 -1 0
0 53 16 23
1
end_operator
begin_operator
unstack b22 b4
0
4
0 27 0 15
0 58 0 1
0 10 -1 0
0 53 17 23
1
end_operator
begin_operator
unstack b22 b5
0
4
0 27 0 15
0 58 0 1
0 16 -1 0
0 53 18 23
1
end_operator
begin_operator
unstack b22 b7
0
4
0 27 0 15
0 58 0 1
0 9 -1 0
0 53 19 23
1
end_operator
begin_operator
unstack b22 b8
0
4
0 27 0 15
0 58 0 1
0 2 -1 0
0 53 20 23
1
end_operator
begin_operator
unstack b22 b9
0
4
0 27 0 15
0 58 0 1
0 8 -1 0
0 53 21 23
1
end_operator
begin_operator
unstack b23 b10
0
4
0 27 0 16
0 22 -1 0
0 25 0 1
0 50 0 22
1
end_operator
begin_operator
unstack b23 b11
0
4
0 27 0 16
0 18 -1 0
0 25 0 1
0 50 1 22
1
end_operator
begin_operator
unstack b23 b12
0
4
0 27 0 16
0 15 -1 0
0 25 0 1
0 50 2 22
1
end_operator
begin_operator
unstack b23 b13
0
4
0 27 0 16
0 13 -1 0
0 25 0 1
0 50 3 22
1
end_operator
begin_operator
unstack b23 b14
0
4
0 27 0 16
0 21 -1 0
0 25 0 1
0 50 4 22
1
end_operator
begin_operator
unstack b23 b15
0
4
0 27 0 16
0 11 -1 0
0 25 0 1
0 50 5 22
1
end_operator
begin_operator
unstack b23 b19
0
4
0 27 0 16
0 20 -1 0
0 25 0 1
0 50 6 22
1
end_operator
begin_operator
unstack b23 b2
0
4
0 27 0 16
0 5 -1 0
0 25 0 1
0 50 7 22
1
end_operator
begin_operator
unstack b23 b20
0
4
0 27 0 16
0 7 -1 0
0 25 0 1
0 50 8 22
1
end_operator
begin_operator
unstack b23 b21
0
4
0 27 0 16
0 4 -1 0
0 25 0 1
0 50 9 22
1
end_operator
begin_operator
unstack b23 b22
0
4
0 27 0 16
0 58 -1 0
0 25 0 1
0 50 10 22
1
end_operator
begin_operator
unstack b23 b24
0
4
0 27 0 16
0 25 0 1
0 26 -1 0
0 50 11 22
1
end_operator
begin_operator
unstack b23 b27
0
4
0 27 0 16
0 25 0 1
0 57 -1 0
0 50 12 22
1
end_operator
begin_operator
unstack b23 b28
0
4
0 27 0 16
0 25 0 1
0 14 -1 0
0 50 13 22
1
end_operator
begin_operator
unstack b23 b29
0
4
0 27 0 16
0 25 0 1
0 6 -1 0
0 50 14 22
1
end_operator
begin_operator
unstack b23 b3
0
4
0 27 0 16
0 25 0 1
0 3 -1 0
0 50 15 22
1
end_operator
begin_operator
unstack b23 b5
0
4
0 27 0 16
0 25 0 1
0 16 -1 0
0 50 16 22
1
end_operator
begin_operator
unstack b23 b6
0
4
0 27 0 16
0 25 0 1
0 19 -1 0
0 50 17 22
1
end_operator
begin_operator
unstack b23 b7
0
4
0 27 0 16
0 25 0 1
0 9 -1 0
0 50 18 22
1
end_operator
begin_operator
unstack b23 b8
0
4
0 27 0 16
0 25 0 1
0 2 -1 0
0 50 19 22
1
end_operator
begin_operator
unstack b23 b9
0
4
0 27 0 16
0 25 0 1
0 8 -1 0
0 50 20 22
1
end_operator
begin_operator
unstack b24 b10
0
4
0 27 0 17
0 22 -1 0
0 26 0 1
0 54 0 24
1
end_operator
begin_operator
unstack b24 b11
0
4
0 27 0 17
0 18 -1 0
0 26 0 1
0 54 1 24
1
end_operator
begin_operator
unstack b24 b13
0
4
0 27 0 17
0 13 -1 0
0 26 0 1
0 54 2 24
1
end_operator
begin_operator
unstack b24 b14
0
4
0 27 0 17
0 21 -1 0
0 26 0 1
0 54 3 24
1
end_operator
begin_operator
unstack b24 b15
0
4
0 27 0 17
0 11 -1 0
0 26 0 1
0 54 4 24
1
end_operator
begin_operator
unstack b24 b16
0
4
0 27 0 17
0 24 -1 0
0 26 0 1
0 54 5 24
1
end_operator
begin_operator
unstack b24 b18
0
4
0 27 0 17
0 17 -1 0
0 26 0 1
0 54 6 24
1
end_operator
begin_operator
unstack b24 b19
0
4
0 27 0 17
0 20 -1 0
0 26 0 1
0 54 7 24
1
end_operator
begin_operator
unstack b24 b2
0
4
0 27 0 17
0 5 -1 0
0 26 0 1
0 54 8 24
1
end_operator
begin_operator
unstack b24 b20
0
4
0 27 0 17
0 7 -1 0
0 26 0 1
0 54 9 24
1
end_operator
begin_operator
unstack b24 b21
0
4
0 27 0 17
0 4 -1 0
0 26 0 1
0 54 10 24
1
end_operator
begin_operator
unstack b24 b22
0
4
0 27 0 17
0 58 -1 0
0 26 0 1
0 54 11 24
1
end_operator
begin_operator
unstack b24 b23
0
4
0 27 0 17
0 25 -1 0
0 26 0 1
0 54 12 24
1
end_operator
begin_operator
unstack b24 b25
0
4
0 27 0 17
0 26 0 1
0 23 -1 0
0 54 13 24
1
end_operator
begin_operator
unstack b24 b27
0
4
0 27 0 17
0 26 0 1
0 57 -1 0
0 54 14 24
1
end_operator
begin_operator
unstack b24 b29
0
4
0 27 0 17
0 26 0 1
0 6 -1 0
0 54 15 24
1
end_operator
begin_operator
unstack b24 b3
0
4
0 27 0 17
0 26 0 1
0 3 -1 0
0 54 16 24
1
end_operator
begin_operator
unstack b24 b4
0
4
0 27 0 17
0 26 0 1
0 10 -1 0
0 54 17 24
1
end_operator
begin_operator
unstack b24 b5
0
4
0 27 0 17
0 26 0 1
0 16 -1 0
0 54 18 24
1
end_operator
begin_operator
unstack b24 b6
0
4
0 27 0 17
0 26 0 1
0 19 -1 0
0 54 19 24
1
end_operator
begin_operator
unstack b24 b7
0
4
0 27 0 17
0 26 0 1
0 9 -1 0
0 54 20 24
1
end_operator
begin_operator
unstack b24 b8
0
4
0 27 0 17
0 26 0 1
0 2 -1 0
0 54 21 24
1
end_operator
begin_operator
unstack b24 b9
0
4
0 27 0 17
0 26 0 1
0 8 -1 0
0 54 22 24
1
end_operator
begin_operator
unstack b25 b10
0
4
0 27 0 18
0 22 -1 0
0 23 0 1
0 51 0 23
1
end_operator
begin_operator
unstack b25 b11
0
4
0 27 0 18
0 18 -1 0
0 23 0 1
0 51 1 23
1
end_operator
begin_operator
unstack b25 b12
0
4
0 27 0 18
0 15 -1 0
0 23 0 1
0 51 2 23
1
end_operator
begin_operator
unstack b25 b13
0
4
0 27 0 18
0 13 -1 0
0 23 0 1
0 51 3 23
1
end_operator
begin_operator
unstack b25 b14
0
4
0 27 0 18
0 21 -1 0
0 23 0 1
0 51 4 23
1
end_operator
begin_operator
unstack b25 b15
0
4
0 27 0 18
0 11 -1 0
0 23 0 1
0 51 5 23
1
end_operator
begin_operator
unstack b25 b16
0
4
0 27 0 18
0 24 -1 0
0 23 0 1
0 51 6 23
1
end_operator
begin_operator
unstack b25 b19
0
4
0 27 0 18
0 20 -1 0
0 23 0 1
0 51 7 23
1
end_operator
begin_operator
unstack b25 b2
0
4
0 27 0 18
0 5 -1 0
0 23 0 1
0 51 8 23
1
end_operator
begin_operator
unstack b25 b20
0
4
0 27 0 18
0 7 -1 0
0 23 0 1
0 51 9 23
1
end_operator
begin_operator
unstack b25 b21
0
4
0 27 0 18
0 4 -1 0
0 23 0 1
0 51 10 23
1
end_operator
begin_operator
unstack b25 b22
0
4
0 27 0 18
0 58 -1 0
0 23 0 1
0 51 11 23
1
end_operator
begin_operator
unstack b25 b23
0
4
0 27 0 18
0 25 -1 0
0 23 0 1
0 51 12 23
1
end_operator
begin_operator
unstack b25 b24
0
4
0 27 0 18
0 26 -1 0
0 23 0 1
0 51 13 23
1
end_operator
begin_operator
unstack b25 b27
0
4
0 27 0 18
0 23 0 1
0 57 -1 0
0 51 14 23
1
end_operator
begin_operator
unstack b25 b28
0
4
0 27 0 18
0 23 0 1
0 14 -1 0
0 51 15 23
1
end_operator
begin_operator
unstack b25 b29
0
4
0 27 0 18
0 23 0 1
0 6 -1 0
0 51 16 23
1
end_operator
begin_operator
unstack b25 b3
0
4
0 27 0 18
0 23 0 1
0 3 -1 0
0 51 17 23
1
end_operator
begin_operator
unstack b25 b4
0
4
0 27 0 18
0 23 0 1
0 10 -1 0
0 51 18 23
1
end_operator
begin_operator
unstack b25 b6
0
4
0 27 0 18
0 23 0 1
0 19 -1 0
0 51 19 23
1
end_operator
begin_operator
unstack b25 b7
0
4
0 27 0 18
0 23 0 1
0 9 -1 0
0 51 20 23
1
end_operator
begin_operator
unstack b25 b9
0
4
0 27 0 18
0 23 0 1
0 8 -1 0
0 51 21 23
1
end_operator
begin_operator
unstack b26 b15
0
4
0 27 0 19
0 11 -1 0
0 1 0 1
0 33 0 2
1
end_operator
begin_operator
unstack b27 b22
0
4
0 27 0 20
0 58 -1 0
0 57 0 1
0 38 0 4
1
end_operator
begin_operator
unstack b27 b23
0
4
0 27 0 20
0 25 -1 0
0 57 0 1
0 38 1 4
1
end_operator
begin_operator
unstack b27 b25
0
4
0 27 0 20
0 23 -1 0
0 57 0 1
0 38 2 4
1
end_operator
begin_operator
unstack b28 b13
0
4
0 27 0 21
0 13 -1 0
0 14 0 1
0 40 1 11
1
end_operator
begin_operator
unstack b28 b15
0
4
0 27 0 21
0 11 -1 0
0 14 0 1
0 40 2 11
1
end_operator
begin_operator
unstack b28 b22
0
4
0 27 0 21
0 58 -1 0
0 14 0 1
0 40 3 11
1
end_operator
begin_operator
unstack b28 b23
0
4
0 27 0 21
0 25 -1 0
0 14 0 1
0 40 4 11
1
end_operator
begin_operator
unstack b28 b24
0
4
0 27 0 21
0 26 -1 0
0 14 0 1
0 40 5 11
1
end_operator
begin_operator
unstack b28 b27
0
4
0 27 0 21
0 57 -1 0
0 14 0 1
0 40 6 11
1
end_operator
begin_operator
unstack b28 b4
0
4
0 27 0 21
0 14 0 1
0 10 -1 0
0 40 7 11
1
end_operator
begin_operator
unstack b28 b7
0
4
0 27 0 21
0 14 0 1
0 9 -1 0
0 40 8 11
1
end_operator
begin_operator
unstack b28 b8
0
4
0 27 0 21
0 14 0 1
0 2 -1 0
0 40 9 11
1
end_operator
begin_operator
unstack b29 b19
0
4
0 27 0 22
0 20 -1 0
0 6 0 1
0 34 0 2
1
end_operator
begin_operator
unstack b3 b5
0
4
0 27 0 23
0 3 0 1
0 16 -1 0
0 35 0 2
1
end_operator
begin_operator
unstack b4 b13
0
4
0 27 0 24
0 13 -1 0
0 10 0 1
0 42 0 11
1
end_operator
begin_operator
unstack b4 b15
0
4
0 27 0 24
0 11 -1 0
0 10 0 1
0 42 1 11
1
end_operator
begin_operator
unstack b4 b17
0
4
0 27 0 24
0 12 -1 0
0 10 0 1
0 42 2 11
1
end_operator
begin_operator
unstack b4 b22
0
4
0 27 0 24
0 58 -1 0
0 10 0 1
0 42 3 11
1
end_operator
begin_operator
unstack b4 b23
0
4
0 27 0 24
0 25 -1 0
0 10 0 1
0 42 4 11
1
end_operator
begin_operator
unstack b4 b24
0
4
0 27 0 24
0 26 -1 0
0 10 0 1
0 42 5 11
1
end_operator
begin_operator
unstack b4 b27
0
4
0 27 0 24
0 57 -1 0
0 10 0 1
0 42 6 11
1
end_operator
begin_operator
unstack b4 b28
0
4
0 27 0 24
0 14 -1 0
0 10 0 1
0 42 7 11
1
end_operator
begin_operator
unstack b4 b7
0
4
0 27 0 24
0 10 0 1
0 9 -1 0
0 42 9 11
1
end_operator
begin_operator
unstack b5 b10
0
4
0 27 0 25
0 22 -1 0
0 16 0 1
0 44 0 20
1
end_operator
begin_operator
unstack b5 b11
0
4
0 27 0 25
0 18 -1 0
0 16 0 1
0 44 1 20
1
end_operator
begin_operator
unstack b5 b12
0
4
0 27 0 25
0 15 -1 0
0 16 0 1
0 44 2 20
1
end_operator
begin_operator
unstack b5 b13
0
4
0 27 0 25
0 13 -1 0
0 16 0 1
0 44 3 20
1
end_operator
begin_operator
unstack b5 b14
0
4
0 27 0 25
0 21 -1 0
0 16 0 1
0 44 4 20
1
end_operator
begin_operator
unstack b5 b15
0
4
0 27 0 25
0 11 -1 0
0 16 0 1
0 44 5 20
1
end_operator
begin_operator
unstack b5 b16
0
4
0 27 0 25
0 24 -1 0
0 16 0 1
0 44 6 20
1
end_operator
begin_operator
unstack b5 b18
0
4
0 27 0 25
0 17 -1 0
0 16 0 1
0 44 7 20
1
end_operator
begin_operator
unstack b5 b19
0
4
0 27 0 25
0 20 -1 0
0 16 0 1
0 44 8 20
1
end_operator
begin_operator
unstack b5 b20
0
4
0 27 0 25
0 7 -1 0
0 16 0 1
0 44 9 20
1
end_operator
begin_operator
unstack b5 b22
0
4
0 27 0 25
0 58 -1 0
0 16 0 1
0 44 10 20
1
end_operator
begin_operator
unstack b5 b23
0
4
0 27 0 25
0 25 -1 0
0 16 0 1
0 44 11 20
1
end_operator
begin_operator
unstack b5 b24
0
4
0 27 0 25
0 26 -1 0
0 16 0 1
0 44 12 20
1
end_operator
begin_operator
unstack b5 b25
0
4
0 27 0 25
0 23 -1 0
0 16 0 1
0 44 13 20
1
end_operator
begin_operator
unstack b5 b27
0
4
0 27 0 25
0 57 -1 0
0 16 0 1
0 44 14 20
1
end_operator
begin_operator
unstack b5 b28
0
4
0 27 0 25
0 14 -1 0
0 16 0 1
0 44 15 20
1
end_operator
begin_operator
unstack b5 b4
0
4
0 27 0 25
0 10 -1 0
0 16 0 1
0 44 16 20
1
end_operator
begin_operator
unstack b5 b7
0
4
0 27 0 25
0 16 0 1
0 9 -1 0
0 44 17 20
1
end_operator
begin_operator
unstack b5 b9
0
4
0 27 0 25
0 16 0 1
0 8 -1 0
0 44 18 20
1
end_operator
begin_operator
unstack b6 b11
0
4
0 27 0 26
0 18 -1 0
0 19 0 1
0 52 0 22
1
end_operator
begin_operator
unstack b6 b12
0
4
0 27 0 26
0 15 -1 0
0 19 0 1
0 52 1 22
1
end_operator
begin_operator
unstack b6 b13
0
4
0 27 0 26
0 13 -1 0
0 19 0 1
0 52 2 22
1
end_operator
begin_operator
unstack b6 b14
0
4
0 27 0 26
0 21 -1 0
0 19 0 1
0 52 3 22
1
end_operator
begin_operator
unstack b6 b16
0
4
0 27 0 26
0 24 -1 0
0 19 0 1
0 52 4 22
1
end_operator
begin_operator
unstack b6 b18
0
4
0 27 0 26
0 17 -1 0
0 19 0 1
0 52 5 22
1
end_operator
begin_operator
unstack b6 b19
0
4
0 27 0 26
0 20 -1 0
0 19 0 1
0 52 6 22
1
end_operator
begin_operator
unstack b6 b2
0
4
0 27 0 26
0 5 -1 0
0 19 0 1
0 52 7 22
1
end_operator
begin_operator
unstack b6 b20
0
4
0 27 0 26
0 7 -1 0
0 19 0 1
0 52 8 22
1
end_operator
begin_operator
unstack b6 b21
0
4
0 27 0 26
0 4 -1 0
0 19 0 1
0 52 9 22
1
end_operator
begin_operator
unstack b6 b22
0
4
0 27 0 26
0 58 -1 0
0 19 0 1
0 52 10 22
1
end_operator
begin_operator
unstack b6 b23
0
4
0 27 0 26
0 25 -1 0
0 19 0 1
0 52 11 22
1
end_operator
begin_operator
unstack b6 b24
0
4
0 27 0 26
0 26 -1 0
0 19 0 1
0 52 12 22
1
end_operator
begin_operator
unstack b6 b25
0
4
0 27 0 26
0 23 -1 0
0 19 0 1
0 52 13 22
1
end_operator
begin_operator
unstack b6 b27
0
4
0 27 0 26
0 57 -1 0
0 19 0 1
0 52 14 22
1
end_operator
begin_operator
unstack b6 b28
0
4
0 27 0 26
0 14 -1 0
0 19 0 1
0 52 15 22
1
end_operator
begin_operator
unstack b6 b29
0
4
0 27 0 26
0 6 -1 0
0 19 0 1
0 52 16 22
1
end_operator
begin_operator
unstack b6 b3
0
4
0 27 0 26
0 3 -1 0
0 19 0 1
0 52 17 22
1
end_operator
begin_operator
unstack b6 b4
0
4
0 27 0 26
0 10 -1 0
0 19 0 1
0 52 18 22
1
end_operator
begin_operator
unstack b6 b5
0
4
0 27 0 26
0 16 -1 0
0 19 0 1
0 52 19 22
1
end_operator
begin_operator
unstack b6 b7
0
4
0 27 0 26
0 19 0 1
0 9 -1 0
0 52 20 22
1
end_operator
begin_operator
unstack b7 b11
0
4
0 27 0 27
0 18 -1 0
0 9 0 1
0 36 1 3
1
end_operator
begin_operator
unstack b8 b29
0
4
0 27 0 28
0 6 -1 0
0 2 0 1
0 29 0 2
1
end_operator
begin_operator
unstack b9 b27
0
4
0 27 0 29
0 57 -1 0
0 8 0 1
0 37 1 3
1
end_operator
0
