begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var0
-1
2
Atom on-table(b3)
NegatedAtom on-table(b3)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var1
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var3
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var4
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var5
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var7
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var6
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var8
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var9
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var11
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var12
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var10
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var13
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var14
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var15
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var16
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var17
-1
21
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var18
-1
3
Atom on(b14, b7)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var19
-1
3
Atom on(b2, b13)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var20
-1
3
Atom on(b18, b2)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom on(b6, b16)
Atom on(b6, b18)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom on(b16, b14)
Atom on(b16, b20)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var23
-1
5
Atom on(b17, b13)
Atom on(b17, b15)
Atom on(b17, b6)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var22
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var24
-1
5
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b8)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var27
-1
14
Atom on(b10, b1)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b20)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var31
-1
14
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b13)
Atom on(b4, b17)
Atom on(b4, b19)
Atom on(b4, b20)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var33
-1
14
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b13)
Atom on(b9, b16)
Atom on(b9, b17)
Atom on(b9, b19)
Atom on(b9, b20)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var28
-1
15
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b13)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b20)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var30
-1
15
Atom on(b20, b1)
Atom on(b20, b10)
Atom on(b20, b11)
Atom on(b20, b16)
Atom on(b20, b17)
Atom on(b20, b19)
Atom on(b20, b2)
Atom on(b20, b4)
Atom on(b20, b5)
Atom on(b20, b6)
Atom on(b20, b7)
Atom on(b20, b8)
Atom on(b20, b9)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var35
-1
17
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var25
-1
16
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b13)
Atom on(b5, b15)
Atom on(b5, b16)
Atom on(b5, b17)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b4)
Atom on(b5, b7)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var26
-1
17
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b18)
Atom on(b7, b19)
Atom on(b7, b2)
Atom on(b7, b20)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var32
-1
17
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b13)
Atom on(b8, b14)
Atom on(b8, b15)
Atom on(b8, b16)
Atom on(b8, b17)
Atom on(b8, b18)
Atom on(b8, b19)
Atom on(b8, b20)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on(b8, b9)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var34
-1
17
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b20)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var36
-1
18
Atom on(b13, b1)
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b12)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b17)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b8)
Atom on(b13, b9)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var37
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var39
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var38
-1
4
Atom clear(b5)
Atom on(b15, b5)
Atom on(b3, b5)
<none of those>
end_variable
begin_variable
var40
-1
2
Atom on-table(b15)
NegatedAtom on-table(b15)
end_variable
2149
begin_mutex_group
11
17 1
14 0
26 0
29 0
31 0
36 0
30 0
27 0
32 0
33 0
28 0
end_mutex_group
begin_mutex_group
12
17 2
9 0
35 0
29 1
31 1
36 1
30 1
27 1
32 1
33 1
34 0
28 1
end_mutex_group
begin_mutex_group
11
17 3
13 0
35 1
31 2
36 2
30 2
27 2
32 2
33 2
34 1
28 2
end_mutex_group
begin_mutex_group
5
17 4
7 0
35 2
26 1
36 3
end_mutex_group
begin_mutex_group
13
17 5
16 0
35 3
26 2
29 2
31 3
23 0
19 0
27 3
32 3
33 3
34 2
28 3
end_mutex_group
begin_mutex_group
8
17 6
2 0
35 4
36 4
22 0
25 0
33 4
34 3
end_mutex_group
begin_mutex_group
8
17 7
3 0
36 5
23 1
25 1
32 4
33 5
34 4
end_mutex_group
begin_mutex_group
13
17 8
6 0
35 5
26 3
29 3
31 4
36 6
30 3
32 5
21 0
33 6
34 5
28 4
end_mutex_group
begin_mutex_group
12
17 9
37 0
35 6
26 4
29 4
31 5
36 7
30 4
27 4
32 6
34 6
28 5
end_mutex_group
begin_mutex_group
11
17 10
4 0
35 7
26 5
29 5
31 6
36 8
32 7
21 1
33 7
34 7
end_mutex_group
begin_mutex_group
13
17 11
38 0
35 8
26 6
29 6
31 7
36 9
30 5
27 5
32 8
33 8
34 8
28 6
end_mutex_group
begin_mutex_group
7
17 12
1 0
36 10
20 0
30 6
32 9
33 9
end_mutex_group
begin_mutex_group
11
17 13
12 0
35 9
26 7
29 7
22 1
27 6
32 10
33 10
34 9
28 7
end_mutex_group
begin_mutex_group
3
17 14
24 0
31 8
end_mutex_group
begin_mutex_group
11
17 15
11 0
35 10
29 8
31 9
36 11
30 7
32 11
33 11
34 10
28 8
end_mutex_group
begin_mutex_group
14
17 16
39 0
39 1
39 2
35 11
26 8
29 9
31 10
36 12
30 8
27 7
33 12
34 11
28 9
end_mutex_group
begin_mutex_group
12
17 17
5 0
35 12
26 9
29 10
31 11
36 13
23 2
30 9
27 8
33 13
34 12
end_mutex_group
begin_mutex_group
9
17 18
8 0
31 12
18 0
30 10
27 9
32 12
34 13
28 10
end_mutex_group
begin_mutex_group
12
17 19
15 0
35 13
26 10
29 11
31 13
36 14
25 2
30 11
27 10
33 14
28 11
end_mutex_group
begin_mutex_group
11
17 20
10 0
35 14
26 11
29 12
31 14
36 15
30 12
27 11
32 13
34 14
end_mutex_group
begin_mutex_group
17
17 1
35 0
35 1
35 2
35 3
35 4
35 5
35 6
35 7
35 8
35 9
35 10
35 11
35 12
35 13
35 14
35 15
end_mutex_group
begin_mutex_group
14
17 2
26 0
26 1
26 2
26 3
26 4
26 5
26 6
26 7
26 8
26 9
26 10
26 11
26 12
end_mutex_group
begin_mutex_group
15
17 3
29 0
29 1
29 2
29 3
29 4
29 5
29 6
29 7
29 8
29 9
29 10
29 11
29 12
29 13
end_mutex_group
begin_mutex_group
17
17 4
31 0
31 1
31 2
31 3
31 4
31 5
31 6
31 7
31 8
31 9
31 10
31 11
31 12
31 13
31 14
31 15
end_mutex_group
begin_mutex_group
18
17 5
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
36 15
36 16
end_mutex_group
begin_mutex_group
3
17 6
18 0
18 1
end_mutex_group
begin_mutex_group
3
17 7
39 1
40 0
end_mutex_group
begin_mutex_group
4
17 8
22 0
22 1
22 2
end_mutex_group
begin_mutex_group
5
17 9
23 0
23 1
23 2
23 3
end_mutex_group
begin_mutex_group
3
17 10
20 0
20 1
end_mutex_group
begin_mutex_group
5
17 11
25 0
25 1
25 2
25 3
end_mutex_group
begin_mutex_group
3
17 12
19 0
19 1
end_mutex_group
begin_mutex_group
15
17 13
30 0
30 1
30 2
30 3
30 4
30 5
30 6
30 7
30 8
30 9
30 10
30 11
30 12
30 13
end_mutex_group
begin_mutex_group
3
17 14
39 2
0 0
end_mutex_group
begin_mutex_group
14
17 15
27 0
27 1
27 2
27 3
27 4
27 5
27 6
27 7
27 8
27 9
27 10
27 11
27 12
end_mutex_group
begin_mutex_group
16
17 16
32 0
32 1
32 2
32 3
32 4
32 5
32 6
32 7
32 8
32 9
32 10
32 11
32 12
32 13
32 14
end_mutex_group
begin_mutex_group
4
17 17
21 0
21 1
21 2
end_mutex_group
begin_mutex_group
17
17 18
33 0
33 1
33 2
33 3
33 4
33 5
33 6
33 7
33 8
33 9
33 10
33 11
33 12
33 13
33 14
33 15
end_mutex_group
begin_mutex_group
17
17 19
34 0
34 1
34 2
34 3
34 4
34 5
34 6
34 7
34 8
34 9
34 10
34 11
34 12
34 13
34 14
34 15
end_mutex_group
begin_mutex_group
14
17 20
28 0
28 1
28 2
28 3
28 4
28 5
28 6
28 7
28 8
28 9
28 10
28 11
28 12
end_mutex_group
begin_mutex_group
2
0 1
17 12
end_mutex_group
begin_mutex_group
2
0 1
19 0
end_mutex_group
begin_mutex_group
2
0 1
19 2
end_mutex_group
begin_mutex_group
2
0 1
31 8
end_mutex_group
begin_mutex_group
2
0 1
36 3
end_mutex_group
begin_mutex_group
2
2 0
17 7
end_mutex_group
begin_mutex_group
2
2 0
18 2
end_mutex_group
begin_mutex_group
2
2 0
23 1
end_mutex_group
begin_mutex_group
2
2 0
39 1
end_mutex_group
begin_mutex_group
2
1 0
19 2
end_mutex_group
begin_mutex_group
2
4 0
17 6
end_mutex_group
begin_mutex_group
2
4 0
17 7
end_mutex_group
begin_mutex_group
2
4 0
18 0
end_mutex_group
begin_mutex_group
2
4 0
18 2
end_mutex_group
begin_mutex_group
2
4 0
20 2
end_mutex_group
begin_mutex_group
2
4 0
23 1
end_mutex_group
begin_mutex_group
2
4 0
39 1
end_mutex_group
begin_mutex_group
2
5 0
17 6
end_mutex_group
begin_mutex_group
2
5 0
17 7
end_mutex_group
begin_mutex_group
2
5 0
18 0
end_mutex_group
begin_mutex_group
2
5 0
18 2
end_mutex_group
begin_mutex_group
2
5 0
21 3
end_mutex_group
begin_mutex_group
2
5 0
23 1
end_mutex_group
begin_mutex_group
2
5 0
39 1
end_mutex_group
begin_mutex_group
2
7 0
17 12
end_mutex_group
begin_mutex_group
2
7 0
19 0
end_mutex_group
begin_mutex_group
2
7 0
19 2
end_mutex_group
begin_mutex_group
2
7 0
31 16
end_mutex_group
begin_mutex_group
2
6 0
22 3
end_mutex_group
begin_mutex_group
2
8 0
17 7
end_mutex_group
begin_mutex_group
2
8 0
23 1
end_mutex_group
begin_mutex_group
2
8 0
33 16
end_mutex_group
begin_mutex_group
2
8 0
39 1
end_mutex_group
begin_mutex_group
2
8 1
17 6
end_mutex_group
begin_mutex_group
2
8 1
18 2
end_mutex_group
begin_mutex_group
2
9 0
17 6
end_mutex_group
begin_mutex_group
2
9 0
17 7
end_mutex_group
begin_mutex_group
2
9 0
18 0
end_mutex_group
begin_mutex_group
2
9 0
18 2
end_mutex_group
begin_mutex_group
2
9 0
23 1
end_mutex_group
begin_mutex_group
2
9 0
26 13
end_mutex_group
begin_mutex_group
2
9 0
39 1
end_mutex_group
begin_mutex_group
2
12 0
30 14
end_mutex_group
begin_mutex_group
2
10 0
17 6
end_mutex_group
begin_mutex_group
2
10 0
17 7
end_mutex_group
begin_mutex_group
2
10 0
18 0
end_mutex_group
begin_mutex_group
2
10 0
18 2
end_mutex_group
begin_mutex_group
2
10 0
23 1
end_mutex_group
begin_mutex_group
2
10 0
28 13
end_mutex_group
begin_mutex_group
2
10 0
39 1
end_mutex_group
begin_mutex_group
2
11 0
17 6
end_mutex_group
begin_mutex_group
2
11 0
17 7
end_mutex_group
begin_mutex_group
2
11 0
18 0
end_mutex_group
begin_mutex_group
2
11 0
18 2
end_mutex_group
begin_mutex_group
2
11 0
23 1
end_mutex_group
begin_mutex_group
2
11 0
27 13
end_mutex_group
begin_mutex_group
2
11 0
39 1
end_mutex_group
begin_mutex_group
2
13 0
17 7
end_mutex_group
begin_mutex_group
2
13 0
23 1
end_mutex_group
begin_mutex_group
2
13 0
29 14
end_mutex_group
begin_mutex_group
2
13 0
39 1
end_mutex_group
begin_mutex_group
2
14 0
17 7
end_mutex_group
begin_mutex_group
2
14 0
23 1
end_mutex_group
begin_mutex_group
2
14 0
35 16
end_mutex_group
begin_mutex_group
2
14 0
39 1
end_mutex_group
begin_mutex_group
2
15 0
17 7
end_mutex_group
begin_mutex_group
2
15 0
23 1
end_mutex_group
begin_mutex_group
2
15 0
34 16
end_mutex_group
begin_mutex_group
2
15 0
39 1
end_mutex_group
begin_mutex_group
2
16 0
36 17
end_mutex_group
begin_mutex_group
2
16 1
17 12
end_mutex_group
begin_mutex_group
2
16 1
19 2
end_mutex_group
begin_mutex_group
2
17 0
18 2
end_mutex_group
begin_mutex_group
2
17 0
19 2
end_mutex_group
begin_mutex_group
2
17 0
20 2
end_mutex_group
begin_mutex_group
2
17 0
21 3
end_mutex_group
begin_mutex_group
2
17 0
23 4
end_mutex_group
begin_mutex_group
2
17 0
25 4
end_mutex_group
begin_mutex_group
2
17 0
32 15
end_mutex_group
begin_mutex_group
2
17 0
33 16
end_mutex_group
begin_mutex_group
2
17 0
26 13
end_mutex_group
begin_mutex_group
2
17 0
29 14
end_mutex_group
begin_mutex_group
2
17 0
22 3
end_mutex_group
begin_mutex_group
2
17 0
30 14
end_mutex_group
begin_mutex_group
2
17 0
27 13
end_mutex_group
begin_mutex_group
2
17 0
34 16
end_mutex_group
begin_mutex_group
2
17 0
28 13
end_mutex_group
begin_mutex_group
2
17 0
35 16
end_mutex_group
begin_mutex_group
2
17 0
31 16
end_mutex_group
begin_mutex_group
2
17 0
36 17
end_mutex_group
begin_mutex_group
2
17 1
18 2
end_mutex_group
begin_mutex_group
2
17 1
19 2
end_mutex_group
begin_mutex_group
2
17 1
20 2
end_mutex_group
begin_mutex_group
2
17 1
21 3
end_mutex_group
begin_mutex_group
2
17 1
23 1
end_mutex_group
begin_mutex_group
2
17 1
23 4
end_mutex_group
begin_mutex_group
2
17 1
25 4
end_mutex_group
begin_mutex_group
2
17 1
32 15
end_mutex_group
begin_mutex_group
2
17 1
33 16
end_mutex_group
begin_mutex_group
2
17 1
26 13
end_mutex_group
begin_mutex_group
2
17 1
29 14
end_mutex_group
begin_mutex_group
2
17 1
22 3
end_mutex_group
begin_mutex_group
2
17 1
30 14
end_mutex_group
begin_mutex_group
2
17 1
27 13
end_mutex_group
begin_mutex_group
2
17 1
34 16
end_mutex_group
begin_mutex_group
2
17 1
28 13
end_mutex_group
begin_mutex_group
2
17 1
31 16
end_mutex_group
begin_mutex_group
2
17 1
36 17
end_mutex_group
begin_mutex_group
2
17 1
39 1
end_mutex_group
begin_mutex_group
2
17 2
18 0
end_mutex_group
begin_mutex_group
2
17 2
18 2
end_mutex_group
begin_mutex_group
2
17 2
19 2
end_mutex_group
begin_mutex_group
2
17 2
20 2
end_mutex_group
begin_mutex_group
2
17 2
21 3
end_mutex_group
begin_mutex_group
2
17 2
23 1
end_mutex_group
begin_mutex_group
2
17 2
23 4
end_mutex_group
begin_mutex_group
2
17 2
25 4
end_mutex_group
begin_mutex_group
2
17 2
32 15
end_mutex_group
begin_mutex_group
2
17 2
33 16
end_mutex_group
begin_mutex_group
2
17 2
29 14
end_mutex_group
begin_mutex_group
2
17 2
22 3
end_mutex_group
begin_mutex_group
2
17 2
30 14
end_mutex_group
begin_mutex_group
2
17 2
27 13
end_mutex_group
begin_mutex_group
2
17 2
34 16
end_mutex_group
begin_mutex_group
2
17 2
28 13
end_mutex_group
begin_mutex_group
2
17 2
35 16
end_mutex_group
begin_mutex_group
2
17 2
31 16
end_mutex_group
begin_mutex_group
2
17 2
36 17
end_mutex_group
begin_mutex_group
2
17 2
39 1
end_mutex_group
begin_mutex_group
2
17 3
18 2
end_mutex_group
begin_mutex_group
2
17 3
19 2
end_mutex_group
begin_mutex_group
2
17 3
20 2
end_mutex_group
begin_mutex_group
2
17 3
21 3
end_mutex_group
begin_mutex_group
2
17 3
23 1
end_mutex_group
begin_mutex_group
2
17 3
23 4
end_mutex_group
begin_mutex_group
2
17 3
25 4
end_mutex_group
begin_mutex_group
2
17 3
32 15
end_mutex_group
begin_mutex_group
2
17 3
33 16
end_mutex_group
begin_mutex_group
2
17 3
26 13
end_mutex_group
begin_mutex_group
2
17 3
22 3
end_mutex_group
begin_mutex_group
2
17 3
30 14
end_mutex_group
begin_mutex_group
2
17 3
27 13
end_mutex_group
begin_mutex_group
2
17 3
34 16
end_mutex_group
begin_mutex_group
2
17 3
28 13
end_mutex_group
begin_mutex_group
2
17 3
35 16
end_mutex_group
begin_mutex_group
2
17 3
31 16
end_mutex_group
begin_mutex_group
2
17 3
36 17
end_mutex_group
begin_mutex_group
2
17 3
39 1
end_mutex_group
begin_mutex_group
2
17 4
18 2
end_mutex_group
begin_mutex_group
2
17 4
19 0
end_mutex_group
begin_mutex_group
2
17 4
19 2
end_mutex_group
begin_mutex_group
2
17 4
20 2
end_mutex_group
begin_mutex_group
2
17 4
21 3
end_mutex_group
begin_mutex_group
2
17 4
23 4
end_mutex_group
begin_mutex_group
2
17 4
25 4
end_mutex_group
begin_mutex_group
2
17 4
32 15
end_mutex_group
begin_mutex_group
2
17 4
33 16
end_mutex_group
begin_mutex_group
2
17 4
26 13
end_mutex_group
begin_mutex_group
2
17 4
29 14
end_mutex_group
begin_mutex_group
2
17 4
22 3
end_mutex_group
begin_mutex_group
2
17 4
30 14
end_mutex_group
begin_mutex_group
2
17 4
27 13
end_mutex_group
begin_mutex_group
2
17 4
34 16
end_mutex_group
begin_mutex_group
2
17 4
28 13
end_mutex_group
begin_mutex_group
2
17 4
35 16
end_mutex_group
begin_mutex_group
2
17 4
36 17
end_mutex_group
begin_mutex_group
2
17 5
18 2
end_mutex_group
begin_mutex_group
2
17 5
19 2
end_mutex_group
begin_mutex_group
2
17 5
20 2
end_mutex_group
begin_mutex_group
2
17 5
21 3
end_mutex_group
begin_mutex_group
2
17 5
23 4
end_mutex_group
begin_mutex_group
2
17 5
25 4
end_mutex_group
begin_mutex_group
2
17 5
32 15
end_mutex_group
begin_mutex_group
2
17 5
33 16
end_mutex_group
begin_mutex_group
2
17 5
26 13
end_mutex_group
begin_mutex_group
2
17 5
29 14
end_mutex_group
begin_mutex_group
2
17 5
22 3
end_mutex_group
begin_mutex_group
2
17 5
30 14
end_mutex_group
begin_mutex_group
2
17 5
27 13
end_mutex_group
begin_mutex_group
2
17 5
34 16
end_mutex_group
begin_mutex_group
2
17 5
28 13
end_mutex_group
begin_mutex_group
2
17 5
35 16
end_mutex_group
begin_mutex_group
2
17 5
31 16
end_mutex_group
begin_mutex_group
2
17 6
19 2
end_mutex_group
begin_mutex_group
2
17 6
20 0
end_mutex_group
begin_mutex_group
2
17 6
20 2
end_mutex_group
begin_mutex_group
2
17 6
21 0
end_mutex_group
begin_mutex_group
2
17 6
21 2
end_mutex_group
begin_mutex_group
2
17 6
21 3
end_mutex_group
begin_mutex_group
2
17 6
23 1
end_mutex_group
begin_mutex_group
2
17 6
23 2
end_mutex_group
begin_mutex_group
2
17 6
23 4
end_mutex_group
begin_mutex_group
2
17 6
25 4
end_mutex_group
begin_mutex_group
2
17 6
32 1
end_mutex_group
begin_mutex_group
2
17 6
32 7
end_mutex_group
begin_mutex_group
2
17 6
32 11
end_mutex_group
begin_mutex_group
2
17 6
32 12
end_mutex_group
begin_mutex_group
2
17 6
32 13
end_mutex_group
begin_mutex_group
2
17 6
32 15
end_mutex_group
begin_mutex_group
2
17 6
33 0
end_mutex_group
begin_mutex_group
2
17 6
33 2
end_mutex_group
begin_mutex_group
2
17 6
33 3
end_mutex_group
begin_mutex_group
2
17 6
33 5
end_mutex_group
begin_mutex_group
2
17 6
33 6
end_mutex_group
begin_mutex_group
2
17 6
33 7
end_mutex_group
begin_mutex_group
2
17 6
33 8
end_mutex_group
begin_mutex_group
2
17 6
33 9
end_mutex_group
begin_mutex_group
2
17 6
33 10
end_mutex_group
begin_mutex_group
2
17 6
33 11
end_mutex_group
begin_mutex_group
2
17 6
33 12
end_mutex_group
begin_mutex_group
2
17 6
33 13
end_mutex_group
begin_mutex_group
2
17 6
33 14
end_mutex_group
begin_mutex_group
2
17 6
33 15
end_mutex_group
begin_mutex_group
2
17 6
33 16
end_mutex_group
begin_mutex_group
2
17 6
26 0
end_mutex_group
begin_mutex_group
2
17 6
26 1
end_mutex_group
begin_mutex_group
2
17 6
26 2
end_mutex_group
begin_mutex_group
2
17 6
26 3
end_mutex_group
begin_mutex_group
2
17 6
26 4
end_mutex_group
begin_mutex_group
2
17 6
26 5
end_mutex_group
begin_mutex_group
2
17 6
26 6
end_mutex_group
begin_mutex_group
2
17 6
26 7
end_mutex_group
begin_mutex_group
2
17 6
26 8
end_mutex_group
begin_mutex_group
2
17 6
26 9
end_mutex_group
begin_mutex_group
2
17 6
26 10
end_mutex_group
begin_mutex_group
2
17 6
26 12
end_mutex_group
begin_mutex_group
2
17 6
26 13
end_mutex_group
begin_mutex_group
2
17 6
29 1
end_mutex_group
begin_mutex_group
2
17 6
29 5
end_mutex_group
begin_mutex_group
2
17 6
29 8
end_mutex_group
begin_mutex_group
2
17 6
29 10
end_mutex_group
begin_mutex_group
2
17 6
29 12
end_mutex_group
begin_mutex_group
2
17 6
29 14
end_mutex_group
begin_mutex_group
2
17 6
22 3
end_mutex_group
begin_mutex_group
2
17 6
30 1
end_mutex_group
begin_mutex_group
2
17 6
30 7
end_mutex_group
begin_mutex_group
2
17 6
30 9
end_mutex_group
begin_mutex_group
2
17 6
30 10
end_mutex_group
begin_mutex_group
2
17 6
30 12
end_mutex_group
begin_mutex_group
2
17 6
30 14
end_mutex_group
begin_mutex_group
2
17 6
27 0
end_mutex_group
begin_mutex_group
2
17 6
27 1
end_mutex_group
begin_mutex_group
2
17 6
27 2
end_mutex_group
begin_mutex_group
2
17 6
27 3
end_mutex_group
begin_mutex_group
2
17 6
27 4
end_mutex_group
begin_mutex_group
2
17 6
27 5
end_mutex_group
begin_mutex_group
2
17 6
27 6
end_mutex_group
begin_mutex_group
2
17 6
27 7
end_mutex_group
begin_mutex_group
2
17 6
27 9
end_mutex_group
begin_mutex_group
2
17 6
27 10
end_mutex_group
begin_mutex_group
2
17 6
27 11
end_mutex_group
begin_mutex_group
2
17 6
27 12
end_mutex_group
begin_mutex_group
2
17 6
27 13
end_mutex_group
begin_mutex_group
2
17 6
34 0
end_mutex_group
begin_mutex_group
2
17 6
34 7
end_mutex_group
begin_mutex_group
2
17 6
34 10
end_mutex_group
begin_mutex_group
2
17 6
34 12
end_mutex_group
begin_mutex_group
2
17 6
34 13
end_mutex_group
begin_mutex_group
2
17 6
34 14
end_mutex_group
begin_mutex_group
2
17 6
34 16
end_mutex_group
begin_mutex_group
2
17 6
28 0
end_mutex_group
begin_mutex_group
2
17 6
28 1
end_mutex_group
begin_mutex_group
2
17 6
28 2
end_mutex_group
begin_mutex_group
2
17 6
28 3
end_mutex_group
begin_mutex_group
2
17 6
28 4
end_mutex_group
begin_mutex_group
2
17 6
28 5
end_mutex_group
begin_mutex_group
2
17 6
28 6
end_mutex_group
begin_mutex_group
2
17 6
28 7
end_mutex_group
begin_mutex_group
2
17 6
28 9
end_mutex_group
begin_mutex_group
2
17 6
28 10
end_mutex_group
begin_mutex_group
2
17 6
28 11
end_mutex_group
begin_mutex_group
2
17 6
28 12
end_mutex_group
begin_mutex_group
2
17 6
28 13
end_mutex_group
begin_mutex_group
2
17 6
35 0
end_mutex_group
begin_mutex_group
2
17 6
35 7
end_mutex_group
begin_mutex_group
2
17 6
35 10
end_mutex_group
begin_mutex_group
2
17 6
35 12
end_mutex_group
begin_mutex_group
2
17 6
35 14
end_mutex_group
begin_mutex_group
2
17 6
35 16
end_mutex_group
begin_mutex_group
2
17 6
31 1
end_mutex_group
begin_mutex_group
2
17 6
31 6
end_mutex_group
begin_mutex_group
2
17 6
31 9
end_mutex_group
begin_mutex_group
2
17 6
31 11
end_mutex_group
begin_mutex_group
2
17 6
31 12
end_mutex_group
begin_mutex_group
2
17 6
31 14
end_mutex_group
begin_mutex_group
2
17 6
31 16
end_mutex_group
begin_mutex_group
2
17 6
36 1
end_mutex_group
begin_mutex_group
2
17 6
36 8
end_mutex_group
begin_mutex_group
2
17 6
36 11
end_mutex_group
begin_mutex_group
2
17 6
36 13
end_mutex_group
begin_mutex_group
2
17 6
36 15
end_mutex_group
begin_mutex_group
2
17 6
36 17
end_mutex_group
begin_mutex_group
2
17 6
39 1
end_mutex_group
begin_mutex_group
2
17 7
18 1
end_mutex_group
begin_mutex_group
2
17 7
18 2
end_mutex_group
begin_mutex_group
2
17 7
19 2
end_mutex_group
begin_mutex_group
2
17 7
20 0
end_mutex_group
begin_mutex_group
2
17 7
20 2
end_mutex_group
begin_mutex_group
2
17 7
21 0
end_mutex_group
begin_mutex_group
2
17 7
21 2
end_mutex_group
begin_mutex_group
2
17 7
21 3
end_mutex_group
begin_mutex_group
2
17 7
23 2
end_mutex_group
begin_mutex_group
2
17 7
23 4
end_mutex_group
begin_mutex_group
2
17 7
25 0
end_mutex_group
begin_mutex_group
2
17 7
25 3
end_mutex_group
begin_mutex_group
2
17 7
25 4
end_mutex_group
begin_mutex_group
2
17 7
32 0
end_mutex_group
begin_mutex_group
2
17 7
32 1
end_mutex_group
begin_mutex_group
2
17 7
32 2
end_mutex_group
begin_mutex_group
2
17 7
32 3
end_mutex_group
begin_mutex_group
2
17 7
32 5
end_mutex_group
begin_mutex_group
2
17 7
32 6
end_mutex_group
begin_mutex_group
2
17 7
32 7
end_mutex_group
begin_mutex_group
2
17 7
32 9
end_mutex_group
begin_mutex_group
2
17 7
32 10
end_mutex_group
begin_mutex_group
2
17 7
32 11
end_mutex_group
begin_mutex_group
2
17 7
32 12
end_mutex_group
begin_mutex_group
2
17 7
32 13
end_mutex_group
begin_mutex_group
2
17 7
32 14
end_mutex_group
begin_mutex_group
2
17 7
32 15
end_mutex_group
begin_mutex_group
2
17 7
33 0
end_mutex_group
begin_mutex_group
2
17 7
33 2
end_mutex_group
begin_mutex_group
2
17 7
33 3
end_mutex_group
begin_mutex_group
2
17 7
33 4
end_mutex_group
begin_mutex_group
2
17 7
33 6
end_mutex_group
begin_mutex_group
2
17 7
33 7
end_mutex_group
begin_mutex_group
2
17 7
33 8
end_mutex_group
begin_mutex_group
2
17 7
33 9
end_mutex_group
begin_mutex_group
2
17 7
33 10
end_mutex_group
begin_mutex_group
2
17 7
33 11
end_mutex_group
begin_mutex_group
2
17 7
33 12
end_mutex_group
begin_mutex_group
2
17 7
33 13
end_mutex_group
begin_mutex_group
2
17 7
33 14
end_mutex_group
begin_mutex_group
2
17 7
33 15
end_mutex_group
begin_mutex_group
2
17 7
33 16
end_mutex_group
begin_mutex_group
2
17 7
26 0
end_mutex_group
begin_mutex_group
2
17 7
26 1
end_mutex_group
begin_mutex_group
2
17




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




tor
begin_operator
stack b10 b9
0
4
0 17 2 0
0 9 -1 0
0 10 0 1
0 26 -1 11
1
end_operator
begin_operator
stack b11 b1
0
4
0 17 3 0
0 14 0 1
0 13 -1 0
0 29 -1 0
1
end_operator
begin_operator
stack b11 b10
0
4
0 17 3 0
0 9 0 1
0 13 -1 0
0 29 -1 1
1
end_operator
begin_operator
stack b11 b13
0
4
0 17 3 0
0 13 -1 0
0 16 0 1
0 29 -1 2
1
end_operator
begin_operator
stack b11 b16
0
4
0 17 3 0
0 13 -1 0
0 6 0 1
0 29 -1 3
1
end_operator
begin_operator
stack b11 b17
0
4
0 17 3 0
0 13 -1 0
0 37 0 1
0 29 -1 4
1
end_operator
begin_operator
stack b11 b18
0
4
0 17 3 0
0 13 -1 0
0 4 0 1
0 29 -1 5
1
end_operator
begin_operator
stack b11 b19
0
4
0 17 3 0
0 13 -1 0
0 38 0 1
0 29 -1 6
1
end_operator
begin_operator
stack b11 b20
0
4
0 17 3 0
0 13 -1 0
0 12 0 1
0 29 -1 7
1
end_operator
begin_operator
stack b11 b4
0
4
0 17 3 0
0 13 -1 0
0 11 0 1
0 29 -1 8
1
end_operator
begin_operator
stack b11 b5
0
4
0 17 3 0
0 13 -1 0
0 39 0 3
0 29 -1 9
1
end_operator
begin_operator
stack b11 b6
0
4
0 17 3 0
0 13 -1 0
0 5 0 1
0 29 -1 10
1
end_operator
begin_operator
stack b11 b8
0
4
0 17 3 0
0 13 -1 0
0 15 0 1
0 29 -1 11
1
end_operator
begin_operator
stack b11 b9
0
4
0 17 3 0
0 13 -1 0
0 10 0 1
0 29 -1 12
1
end_operator
begin_operator
stack b12 b1
0
4
0 17 4 0
0 14 0 1
0 7 -1 0
0 31 -1 0
1
end_operator
begin_operator
stack b12 b10
0
4
0 17 4 0
0 9 0 1
0 7 -1 0
0 31 -1 1
1
end_operator
begin_operator
stack b12 b11
0
4
0 17 4 0
0 13 0 1
0 7 -1 0
0 31 -1 2
1
end_operator
begin_operator
stack b12 b13
0
4
0 17 4 0
0 7 -1 0
0 16 0 1
0 31 -1 3
1
end_operator
begin_operator
stack b12 b16
0
4
0 17 4 0
0 7 -1 0
0 6 0 1
0 31 -1 4
1
end_operator
begin_operator
stack b12 b17
0
4
0 17 4 0
0 7 -1 0
0 37 0 1
0 31 -1 5
1
end_operator
begin_operator
stack b12 b18
0
4
0 17 4 0
0 7 -1 0
0 4 0 1
0 31 -1 6
1
end_operator
begin_operator
stack b12 b19
0
4
0 17 4 0
0 7 -1 0
0 38 0 1
0 31 -1 7
1
end_operator
begin_operator
stack b12 b4
0
4
0 17 4 0
0 7 -1 0
0 11 0 1
0 31 -1 9
1
end_operator
begin_operator
stack b12 b5
0
4
0 17 4 0
0 7 -1 0
0 39 0 3
0 31 -1 10
1
end_operator
begin_operator
stack b12 b6
0
4
0 17 4 0
0 7 -1 0
0 5 0 1
0 31 -1 11
1
end_operator
begin_operator
stack b12 b7
0
4
0 17 4 0
0 7 -1 0
0 8 0 1
0 31 -1 12
1
end_operator
begin_operator
stack b12 b8
0
4
0 17 4 0
0 7 -1 0
0 15 0 1
0 31 -1 13
1
end_operator
begin_operator
stack b12 b9
0
4
0 17 4 0
0 7 -1 0
0 10 0 1
0 31 -1 14
1
end_operator
begin_operator
stack b13 b1
0
4
0 17 5 0
0 14 0 1
0 16 -1 0
0 36 -1 0
1
end_operator
begin_operator
stack b13 b10
0
4
0 17 5 0
0 9 0 1
0 16 -1 0
0 36 -1 1
1
end_operator
begin_operator
stack b13 b11
0
4
0 17 5 0
0 13 0 1
0 16 -1 0
0 36 -1 2
1
end_operator
begin_operator
stack b13 b14
0
4
0 17 5 0
0 16 -1 0
0 2 0 1
0 36 -1 4
1
end_operator
begin_operator
stack b13 b15
0
4
0 17 5 0
0 16 -1 0
0 3 0 1
0 36 -1 5
1
end_operator
begin_operator
stack b13 b16
0
4
0 17 5 0
0 16 -1 0
0 6 0 1
0 36 -1 6
1
end_operator
begin_operator
stack b13 b17
0
4
0 17 5 0
0 16 -1 0
0 37 0 1
0 36 -1 7
1
end_operator
begin_operator
stack b13 b18
0
4
0 17 5 0
0 16 -1 0
0 4 0 1
0 36 -1 8
1
end_operator
begin_operator
stack b13 b19
0
4
0 17 5 0
0 16 -1 0
0 38 0 1
0 36 -1 9
1
end_operator
begin_operator
stack b13 b2
0
4
0 17 5 0
0 16 -1 0
0 1 0 1
0 36 -1 10
1
end_operator
begin_operator
stack b13 b4
0
4
0 17 5 0
0 16 -1 0
0 11 0 1
0 36 -1 11
1
end_operator
begin_operator
stack b13 b5
0
4
0 17 5 0
0 16 -1 0
0 39 0 3
0 36 -1 12
1
end_operator
begin_operator
stack b13 b6
0
4
0 17 5 0
0 16 -1 0
0 5 0 1
0 36 -1 13
1
end_operator
begin_operator
stack b13 b8
0
4
0 17 5 0
0 16 -1 0
0 15 0 1
0 36 -1 14
1
end_operator
begin_operator
stack b13 b9
0
4
0 17 5 0
0 16 -1 0
0 10 0 1
0 36 -1 15
1
end_operator
begin_operator
stack b16 b14
0
4
0 17 8 0
0 2 0 1
0 6 -1 0
0 22 -1 0
1
end_operator
begin_operator
stack b16 b20
0
4
0 17 8 0
0 6 -1 0
0 12 0 1
0 22 -1 1
1
end_operator
begin_operator
stack b17 b13
0
4
0 17 9 0
0 16 0 1
0 37 -1 0
0 23 -1 0
1
end_operator
begin_operator
stack b17 b6
0
4
0 17 9 0
0 37 -1 0
0 5 0 1
0 23 -1 2
1
end_operator
begin_operator
stack b18 b2
0
4
0 17 10 0
0 4 -1 0
0 1 0 1
0 20 -1 0
1
end_operator
begin_operator
stack b19 b14
0
4
0 17 11 0
0 2 0 1
0 38 -1 0
0 25 -1 0
1
end_operator
begin_operator
stack b19 b15
0
4
0 17 11 0
0 3 0 1
0 38 -1 0
0 25 -1 1
1
end_operator
begin_operator
stack b19 b8
0
4
0 17 11 0
0 38 -1 0
0 15 0 1
0 25 -1 2
1
end_operator
begin_operator
stack b20 b1
0
4
0 17 13 0
0 14 0 1
0 12 -1 0
0 30 -1 0
1
end_operator
begin_operator
stack b20 b10
0
4
0 17 13 0
0 9 0 1
0 12 -1 0
0 30 -1 1
1
end_operator
begin_operator
stack b20 b11
0
4
0 17 13 0
0 13 0 1
0 12 -1 0
0 30 -1 2
1
end_operator
begin_operator
stack b20 b16
0
4
0 17 13 0
0 6 0 1
0 12 -1 0
0 30 -1 3
1
end_operator
begin_operator
stack b20 b17
0
4
0 17 13 0
0 37 0 1
0 12 -1 0
0 30 -1 4
1
end_operator
begin_operator
stack b20 b19
0
4
0 17 13 0
0 38 0 1
0 12 -1 0
0 30 -1 5
1
end_operator
begin_operator
stack b20 b2
0
4
0 17 13 0
0 1 0 1
0 12 -1 0
0 30 -1 6
1
end_operator
begin_operator
stack b20 b4
0
4
0 17 13 0
0 12 -1 0
0 11 0 1
0 30 -1 7
1
end_operator
begin_operator
stack b20 b5
0
4
0 17 13 0
0 12 -1 0
0 39 0 3
0 30 -1 8
1
end_operator
begin_operator
stack b20 b6
0
4
0 17 13 0
0 12 -1 0
0 5 0 1
0 30 -1 9
1
end_operator
begin_operator
stack b20 b7
0
4
0 17 13 0
0 12 -1 0
0 8 0 1
0 30 -1 10
1
end_operator
begin_operator
stack b20 b8
0
4
0 17 13 0
0 12 -1 0
0 15 0 1
0 30 -1 11
1
end_operator
begin_operator
stack b20 b9
0
4
0 17 13 0
0 12 -1 0
0 10 0 1
0 30 -1 12
1
end_operator
begin_operator
stack b3 b5
0
3
0 17 14 0
0 24 -1 0
0 39 0 2
1
end_operator
begin_operator
stack b4 b1
0
4
0 17 15 0
0 14 0 1
0 11 -1 0
0 27 -1 0
1
end_operator
begin_operator
stack b4 b10
0
4
0 17 15 0
0 9 0 1
0 11 -1 0
0 27 -1 1
1
end_operator
begin_operator
stack b4 b11
0
4
0 17 15 0
0 13 0 1
0 11 -1 0
0 27 -1 2
1
end_operator
begin_operator
stack b4 b13
0
4
0 17 15 0
0 16 0 1
0 11 -1 0
0 27 -1 3
1
end_operator
begin_operator
stack b4 b17
0
4
0 17 15 0
0 37 0 1
0 11 -1 0
0 27 -1 4
1
end_operator
begin_operator
stack b4 b19
0
4
0 17 15 0
0 38 0 1
0 11 -1 0
0 27 -1 5
1
end_operator
begin_operator
stack b4 b20
0
4
0 17 15 0
0 12 0 1
0 11 -1 0
0 27 -1 6
1
end_operator
begin_operator
stack b4 b5
0
4
0 17 15 0
0 11 -1 0
0 39 0 3
0 27 -1 7
1
end_operator
begin_operator
stack b4 b6
0
4
0 17 15 0
0 11 -1 0
0 5 0 1
0 27 -1 8
1
end_operator
begin_operator
stack b4 b7
0
4
0 17 15 0
0 11 -1 0
0 8 0 1
0 27 -1 9
1
end_operator
begin_operator
stack b4 b8
0
4
0 17 15 0
0 11 -1 0
0 15 0 1
0 27 -1 10
1
end_operator
begin_operator
stack b4 b9
0
4
0 17 15 0
0 11 -1 0
0 10 0 1
0 27 -1 11
1
end_operator
begin_operator
stack b5 b1
0
4
0 17 16 0
0 14 0 1
0 39 -1 0
0 32 -1 0
1
end_operator
begin_operator
stack b5 b10
0
4
0 17 16 0
0 9 0 1
0 39 -1 0
0 32 -1 1
1
end_operator
begin_operator
stack b5 b11
0
4
0 17 16 0
0 13 0 1
0 39 -1 0
0 32 -1 2
1
end_operator
begin_operator
stack b5 b13
0
4
0 17 16 0
0 16 0 1
0 39 -1 0
0 32 -1 3
1
end_operator
begin_operator
stack b5 b15
0
4
0 17 16 0
0 3 0 1
0 39 -1 0
0 32 -1 4
1
end_operator
begin_operator
stack b5 b16
0
4
0 17 16 0
0 6 0 1
0 39 -1 0
0 32 -1 5
1
end_operator
begin_operator
stack b5 b17
0
4
0 17 16 0
0 37 0 1
0 39 -1 0
0 32 -1 6
1
end_operator
begin_operator
stack b5 b18
0
4
0 17 16 0
0 4 0 1
0 39 -1 0
0 32 -1 7
1
end_operator
begin_operator
stack b5 b19
0
4
0 17 16 0
0 38 0 1
0 39 -1 0
0 32 -1 8
1
end_operator
begin_operator
stack b5 b2
0
4
0 17 16 0
0 1 0 1
0 39 -1 0
0 32 -1 9
1
end_operator
begin_operator
stack b5 b20
0
4
0 17 16 0
0 12 0 1
0 39 -1 0
0 32 -1 10
1
end_operator
begin_operator
stack b5 b4
0
4
0 17 16 0
0 11 0 1
0 39 -1 0
0 32 -1 11
1
end_operator
begin_operator
stack b5 b7
0
4
0 17 16 0
0 39 -1 0
0 8 0 1
0 32 -1 12
1
end_operator
begin_operator
stack b5 b9
0
4
0 17 16 0
0 39 -1 0
0 10 0 1
0 32 -1 13
1
end_operator
begin_operator
stack b6 b16
0
4
0 17 17 0
0 6 0 1
0 5 -1 0
0 21 -1 0
1
end_operator
begin_operator
stack b7 b1
0
4
0 17 18 0
0 14 0 1
0 8 -1 0
0 33 -1 0
1
end_operator
begin_operator
stack b7 b10
0
4
0 17 18 0
0 9 0 1
0 8 -1 0
0 33 -1 1
1
end_operator
begin_operator
stack b7 b11
0
4
0 17 18 0
0 13 0 1
0 8 -1 0
0 33 -1 2
1
end_operator
begin_operator
stack b7 b13
0
4
0 17 18 0
0 16 0 1
0 8 -1 0
0 33 -1 3
1
end_operator
begin_operator
stack b7 b14
0
4
0 17 18 0
0 2 0 1
0 8 -1 0
0 33 -1 4
1
end_operator
begin_operator
stack b7 b15
0
4
0 17 18 0
0 3 0 1
0 8 -1 0
0 33 -1 5
1
end_operator
begin_operator
stack b7 b16
0
4
0 17 18 0
0 6 0 1
0 8 -1 0
0 33 -1 6
1
end_operator
begin_operator
stack b7 b18
0
4
0 17 18 0
0 4 0 1
0 8 -1 0
0 33 -1 7
1
end_operator
begin_operator
stack b7 b19
0
4
0 17 18 0
0 38 0 1
0 8 -1 0
0 33 -1 8
1
end_operator
begin_operator
stack b7 b2
0
4
0 17 18 0
0 1 0 1
0 8 -1 0
0 33 -1 9
1
end_operator
begin_operator
stack b7 b20
0
4
0 17 18 0
0 12 0 1
0 8 -1 0
0 33 -1 10
1
end_operator
begin_operator
stack b7 b4
0
4
0 17 18 0
0 11 0 1
0 8 -1 0
0 33 -1 11
1
end_operator
begin_operator
stack b7 b5
0
4
0 17 18 0
0 39 0 3
0 8 -1 0
0 33 -1 12
1
end_operator
begin_operator
stack b7 b6
0
4
0 17 18 0
0 5 0 1
0 8 -1 0
0 33 -1 13
1
end_operator
begin_operator
stack b7 b8
0
4
0 17 18 0
0 8 -1 0
0 15 0 1
0 33 -1 14
1
end_operator
begin_operator
stack b8 b10
0
4
0 17 19 0
0 9 0 1
0 15 -1 0
0 34 -1 0
1
end_operator
begin_operator
stack b8 b11
0
4
0 17 19 0
0 13 0 1
0 15 -1 0
0 34 -1 1
1
end_operator
begin_operator
stack b8 b13
0
4
0 17 19 0
0 16 0 1
0 15 -1 0
0 34 -1 2
1
end_operator
begin_operator
stack b8 b14
0
4
0 17 19 0
0 2 0 1
0 15 -1 0
0 34 -1 3
1
end_operator
begin_operator
stack b8 b15
0
4
0 17 19 0
0 3 0 1
0 15 -1 0
0 34 -1 4
1
end_operator
begin_operator
stack b8 b16
0
4
0 17 19 0
0 6 0 1
0 15 -1 0
0 34 -1 5
1
end_operator
begin_operator
stack b8 b17
0
4
0 17 19 0
0 37 0 1
0 15 -1 0
0 34 -1 6
1
end_operator
begin_operator
stack b8 b18
0
4
0 17 19 0
0 4 0 1
0 15 -1 0
0 34 -1 7
1
end_operator
begin_operator
stack b8 b19
0
4
0 17 19 0
0 38 0 1
0 15 -1 0
0 34 -1 8
1
end_operator
begin_operator
stack b8 b20
0
4
0 17 19 0
0 12 0 1
0 15 -1 0
0 34 -1 9
1
end_operator
begin_operator
stack b8 b4
0
4
0 17 19 0
0 11 0 1
0 15 -1 0
0 34 -1 10
1
end_operator
begin_operator
stack b8 b5
0
4
0 17 19 0
0 39 0 3
0 15 -1 0
0 34 -1 11
1
end_operator
begin_operator
stack b8 b6
0
4
0 17 19 0
0 5 0 1
0 15 -1 0
0 34 -1 12
1
end_operator
begin_operator
stack b8 b7
0
4
0 17 19 0
0 8 0 1
0 15 -1 0
0 34 -1 13
1
end_operator
begin_operator
stack b8 b9
0
4
0 17 19 0
0 15 -1 0
0 10 0 1
0 34 -1 14
1
end_operator
begin_operator
stack b9 b1
0
4
0 17 20 0
0 14 0 1
0 10 -1 0
0 28 -1 0
1
end_operator
begin_operator
stack b9 b10
0
4
0 17 20 0
0 9 0 1
0 10 -1 0
0 28 -1 1
1
end_operator
begin_operator
stack b9 b11
0
4
0 17 20 0
0 13 0 1
0 10 -1 0
0 28 -1 2
1
end_operator
begin_operator
stack b9 b13
0
4
0 17 20 0
0 16 0 1
0 10 -1 0
0 28 -1 3
1
end_operator
begin_operator
stack b9 b16
0
4
0 17 20 0
0 6 0 1
0 10 -1 0
0 28 -1 4
1
end_operator
begin_operator
stack b9 b17
0
4
0 17 20 0
0 37 0 1
0 10 -1 0
0 28 -1 5
1
end_operator
begin_operator
stack b9 b19
0
4
0 17 20 0
0 38 0 1
0 10 -1 0
0 28 -1 6
1
end_operator
begin_operator
stack b9 b20
0
4
0 17 20 0
0 12 0 1
0 10 -1 0
0 28 -1 7
1
end_operator
begin_operator
stack b9 b4
0
4
0 17 20 0
0 11 0 1
0 10 -1 0
0 28 -1 8
1
end_operator
begin_operator
stack b9 b5
0
4
0 17 20 0
0 39 0 3
0 10 -1 0
0 28 -1 9
1
end_operator
begin_operator
stack b9 b7
0
4
0 17 20 0
0 8 0 1
0 10 -1 0
0 28 -1 10
1
end_operator
begin_operator
stack b9 b8
0
4
0 17 20 0
0 15 0 1
0 10 -1 0
0 28 -1 11
1
end_operator
begin_operator
unstack b1 b10
0
4
0 17 0 1
0 14 0 1
0 9 -1 0
0 35 0 16
1
end_operator
begin_operator
unstack b1 b11
0
4
0 17 0 1
0 14 0 1
0 13 -1 0
0 35 1 16
1
end_operator
begin_operator
unstack b1 b12
0
4
0 17 0 1
0 14 0 1
0 7 -1 0
0 35 2 16
1
end_operator
begin_operator
unstack b1 b13
0
4
0 17 0 1
0 14 0 1
0 16 -1 0
0 35 3 16
1
end_operator
begin_operator
unstack b1 b14
0
4
0 17 0 1
0 14 0 1
0 2 -1 0
0 35 4 16
1
end_operator
begin_operator
unstack b1 b16
0
4
0 17 0 1
0 14 0 1
0 6 -1 0
0 35 5 16
1
end_operator
begin_operator
unstack b1 b17
0
4
0 17 0 1
0 14 0 1
0 37 -1 0
0 35 6 16
1
end_operator
begin_operator
unstack b1 b19
0
4
0 17 0 1
0 14 0 1
0 38 -1 0
0 35 8 16
1
end_operator
begin_operator
unstack b1 b20
0
4
0 17 0 1
0 14 0 1
0 12 -1 0
0 35 9 16
1
end_operator
begin_operator
unstack b1 b4
0
4
0 17 0 1
0 14 0 1
0 11 -1 0
0 35 10 16
1
end_operator
begin_operator
unstack b1 b5
0
4
0 17 0 1
0 14 0 1
0 39 -1 0
0 35 11 16
1
end_operator
begin_operator
unstack b1 b6
0
4
0 17 0 1
0 14 0 1
0 5 -1 0
0 35 12 16
1
end_operator
begin_operator
unstack b1 b8
0
4
0 17 0 1
0 14 0 1
0 15 -1 0
0 35 13 16
1
end_operator
begin_operator
unstack b1 b9
0
4
0 17 0 1
0 14 0 1
0 10 -1 0
0 35 14 16
1
end_operator
begin_operator
unstack b10 b1
0
4
0 17 0 2
0 14 -1 0
0 9 0 1
0 26 0 13
1
end_operator
begin_operator
unstack b10 b13
0
4
0 17 0 2
0 9 0 1
0 16 -1 0
0 26 2 13
1
end_operator
begin_operator
unstack b10 b16
0
4
0 17 0 2
0 9 0 1
0 6 -1 0
0 26 3 13
1
end_operator
begin_operator
unstack b10 b17
0
4
0 17 0 2
0 9 0 1
0 37 -1 0
0 26 4 13
1
end_operator
begin_operator
unstack b10 b18
0
4
0 17 0 2
0 9 0 1
0 4 -1 0
0 26 5 13
1
end_operator
begin_operator
unstack b10 b19
0
4
0 17 0 2
0 9 0 1
0 38 -1 0
0 26 6 13
1
end_operator
begin_operator
unstack b10 b20
0
4
0 17 0 2
0 9 0 1
0 12 -1 0
0 26 7 13
1
end_operator
begin_operator
unstack b10 b5
0
4
0 17 0 2
0 9 0 1
0 39 -1 0
0 26 8 13
1
end_operator
begin_operator
unstack b10 b6
0
4
0 17 0 2
0 9 0 1
0 5 -1 0
0 26 9 13
1
end_operator
begin_operator
unstack b10 b8
0
4
0 17 0 2
0 9 0 1
0 15 -1 0
0 26 10 13
1
end_operator
begin_operator
unstack b10 b9
0
4
0 17 0 2
0 9 0 1
0 10 -1 0
0 26 11 13
1
end_operator
begin_operator
unstack b11 b1
0
4
0 17 0 3
0 14 -1 0
0 13 0 1
0 29 0 14
1
end_operator
begin_operator
unstack b11 b10
0
4
0 17 0 3
0 9 -1 0
0 13 0 1
0 29 1 14
1
end_operator
begin_operator
unstack b11 b13
0
4
0 17 0 3
0 13 0 1
0 16 -1 0
0 29 2 14
1
end_operator
begin_operator
unstack b11 b16
0
4
0 17 0 3
0 13 0 1
0 6 -1 0
0 29 3 14
1
end_operator
begin_operator
unstack b11 b17
0
4
0 17 0 3
0 13 0 1
0 37 -1 0
0 29 4 14
1
end_operator
begin_operator
unstack b11 b18
0
4
0 17 0 3
0 13 0 1
0 4 -1 0
0 29 5 14
1
end_operator
begin_operator
unstack b11 b19
0
4
0 17 0 3
0 13 0 1
0 38 -1 0
0 29 6 14
1
end_operator
begin_operator
unstack b11 b20
0
4
0 17 0 3
0 13 0 1
0 12 -1 0
0 29 7 14
1
end_operator
begin_operator
unstack b11 b4
0
4
0 17 0 3
0 13 0 1
0 11 -1 0
0 29 8 14
1
end_operator
begin_operator
unstack b11 b5
0
4
0 17 0 3
0 13 0 1
0 39 -1 0
0 29 9 14
1
end_operator
begin_operator
unstack b11 b6
0
4
0 17 0 3
0 13 0 1
0 5 -1 0
0 29 10 14
1
end_operator
begin_operator
unstack b11 b8
0
4
0 17 0 3
0 13 0 1
0 15 -1 0
0 29 11 14
1
end_operator
begin_operator
unstack b11 b9
0
4
0 17 0 3
0 13 0 1
0 10 -1 0
0 29 12 14
1
end_operator
begin_operator
unstack b12 b1
0
4
0 17 0 4
0 14 -1 0
0 7 0 1
0 31 0 16
1
end_operator
begin_operator
unstack b12 b10
0
4
0 17 0 4
0 9 -1 0
0 7 0 1
0 31 1 16
1
end_operator
begin_operator
unstack b12 b11
0
4
0 17 0 4
0 13 -1 0
0 7 0 1
0 31 2 16
1
end_operator
begin_operator
unstack b12 b13
0
4
0 17 0 4
0 7 0 1
0 16 -1 0
0 31 3 16
1
end_operator
begin_operator
unstack b12 b16
0
4
0 17 0 4
0 7 0 1
0 6 -1 0
0 31 4 16
1
end_operator
begin_operator
unstack b12 b17
0
4
0 17 0 4
0 7 0 1
0 37 -1 0
0 31 5 16
1
end_operator
begin_operator
unstack b12 b18
0
4
0 17 0 4
0 7 0 1
0 4 -1 0
0 31 6 16
1
end_operator
begin_operator
unstack b12 b19
0
4
0 17 0 4
0 7 0 1
0 38 -1 0
0 31 7 16
1
end_operator
begin_operator
unstack b12 b3
0
4
0 17 0 4
0 7 0 1
0 24 -1 0
0 31 8 16
1
end_operator
begin_operator
unstack b12 b4
0
4
0 17 0 4
0 7 0 1
0 11 -1 0
0 31 9 16
1
end_operator
begin_operator
unstack b12 b5
0
4
0 17 0 4
0 7 0 1
0 39 -1 0
0 31 10 16
1
end_operator
begin_operator
unstack b12 b6
0
4
0 17 0 4
0 7 0 1
0 5 -1 0
0 31 11 16
1
end_operator
begin_operator
unstack b12 b7
0
4
0 17 0 4
0 7 0 1
0 8 -1 0
0 31 12 16
1
end_operator
begin_operator
unstack b12 b8
0
4
0 17 0 4
0 7 0 1
0 15 -1 0
0 31 13 16
1
end_operator
begin_operator
unstack b12 b9
0
4
0 17 0 4
0 7 0 1
0 10 -1 0
0 31 14 16
1
end_operator
begin_operator
unstack b13 b1
0
4
0 17 0 5
0 14 -1 0
0 16 0 1
0 36 0 17
1
end_operator
begin_operator
unstack b13 b10
0
4
0 17 0 5
0 9 -1 0
0 16 0 1
0 36 1 17
1
end_operator
begin_operator
unstack b13 b11
0
4
0 17 0 5
0 13 -1 0
0 16 0 1
0 36 2 17
1
end_operator
begin_operator
unstack b13 b12
0
4
0 17 0 5
0 7 -1 0
0 16 0 1
0 36 3 17
1
end_operator
begin_operator
unstack b13 b14
0
4
0 17 0 5
0 16 0 1
0 2 -1 0
0 36 4 17
1
end_operator
begin_operator
unstack b13 b15
0
4
0 17 0 5
0 16 0 1
0 3 -1 0
0 36 5 17
1
end_operator
begin_operator
unstack b13 b16
0
4
0 17 0 5
0 16 0 1
0 6 -1 0
0 36 6 17
1
end_operator
begin_operator
unstack b13 b17
0
4
0 17 0 5
0 16 0 1
0 37 -1 0
0 36 7 17
1
end_operator
begin_operator
unstack b13 b18
0
4
0 17 0 5
0 16 0 1
0 4 -1 0
0 36 8 17
1
end_operator
begin_operator
unstack b13 b19
0
4
0 17 0 5
0 16 0 1
0 38 -1 0
0 36 9 17
1
end_operator
begin_operator
unstack b13 b2
0
4
0 17 0 5
0 16 0 1
0 1 -1 0
0 36 10 17
1
end_operator
begin_operator
unstack b13 b4
0
4
0 17 0 5
0 16 0 1
0 11 -1 0
0 36 11 17
1
end_operator
begin_operator
unstack b13 b5
0
4
0 17 0 5
0 16 0 1
0 39 -1 0
0 36 12 17
1
end_operator
begin_operator
unstack b13 b6
0
4
0 17 0 5
0 16 0 1
0 5 -1 0
0 36 13 17
1
end_operator
begin_operator
unstack b13 b8
0
4
0 17 0 5
0 16 0 1
0 15 -1 0
0 36 14 17
1
end_operator
begin_operator
unstack b13 b9
0
4
0 17 0 5
0 16 0 1
0 10 -1 0
0 36 15 17
1
end_operator
begin_operator
unstack b14 b7
0
4
0 17 0 6
0 2 0 1
0 8 -1 0
0 18 0 2
1
end_operator
begin_operator
unstack b15 b5
0
3
0 17 0 7
0 3 0 1
0 39 1 0
1
end_operator
begin_operator
unstack b16 b20
0
4
0 17 0 8
0 6 0 1
0 12 -1 0
0 22 1 3
1
end_operator
begin_operator
unstack b17 b13
0
4
0 17 0 9
0 16 -1 0
0 37 0 1
0 23 0 4
1
end_operator
begin_operator
unstack b17 b15
0
4
0 17 0 9
0 3 -1 0
0 37 0 1
0 23 1 4
1
end_operator
begin_operator
unstack b17 b6
0
4
0 17 0 9
0 37 0 1
0 5 -1 0
0 23 2 4
1
end_operator
begin_operator
unstack b18 b2
0
4
0 17 0 10
0 4 0 1
0 1 -1 0
0 20 0 2
1
end_operator
begin_operator
unstack b19 b14
0
4
0 17 0 11
0 2 -1 0
0 38 0 1
0 25 0 4
1
end_operator
begin_operator
unstack b19 b15
0
4
0 17 0 11
0 3 -1 0
0 38 0 1
0 25 1 4
1
end_operator
begin_operator
unstack b19 b8
0
4
0 17 0 11
0 38 0 1
0 15 -1 0
0 25 2 4
1
end_operator
begin_operator
unstack b2 b13
0
4
0 17 0 12
0 16 -1 0
0 1 0 1
0 19 0 2
1
end_operator
begin_operator
unstack b20 b1
0
4
0 17 0 13
0 14 -1 0
0 12 0 1
0 30 0 14
1
end_operator
begin_operator
unstack b20 b10
0
4
0 17 0 13
0 9 -1 0
0 12 0 1
0 30 1 14
1
end_operator
begin_operator
unstack b20 b11
0
4
0 17 0 13
0 13 -1 0
0 12 0 1
0 30 2 14
1
end_operator
begin_operator
unstack b20 b16
0
4
0 17 0 13
0 6 -1 0
0 12 0 1
0 30 3 14
1
end_operator
begin_operator
unstack b20 b17
0
4
0 17 0 13
0 37 -1 0
0 12 0 1
0 30 4 14
1
end_operator
begin_operator
unstack b20 b19
0
4
0 17 0 13
0 38 -1 0
0 12 0 1
0 30 5 14
1
end_operator
begin_operator
unstack b20 b2
0
4
0 17 0 13
0 1 -1 0
0 12 0 1
0 30 6 14
1
end_operator
begin_operator
unstack b20 b4
0
4
0 17 0 13
0 12 0 1
0 11 -1 0
0 30 7 14
1
end_operator
begin_operator
unstack b20 b5
0
4
0 17 0 13
0 12 0 1
0 39 -1 0
0 30 8 14
1
end_operator
begin_operator
unstack b20 b6
0
4
0 17 0 13
0 12 0 1
0 5 -1 0
0 30 9 14
1
end_operator
begin_operator
unstack b20 b7
0
4
0 17 0 13
0 12 0 1
0 8 -1 0
0 30 10 14
1
end_operator
begin_operator
unstack b20 b8
0
4
0 17 0 13
0 12 0 1
0 15 -1 0
0 30 11 14
1
end_operator
begin_operator
unstack b20 b9
0
4
0 17 0 13
0 12 0 1
0 10 -1 0
0 30 12 14
1
end_operator
begin_operator
unstack b3 b5
0
3
0 17 0 14
0 24 0 1
0 39 2 0
1
end_operator
begin_operator
unstack b4 b1
0
4
0 17 0 15
0 14 -1 0
0 11 0 1
0 27 0 13
1
end_operator
begin_operator
unstack b4 b10
0
4
0 17 0 15
0 9 -1 0
0 11 0 1
0 27 1 13
1
end_operator
begin_operator
unstack b4 b11
0
4
0 17 0 15
0 13 -1 0
0 11 0 1
0 27 2 13
1
end_operator
begin_operator
unstack b4 b13
0
4
0 17 0 15
0 16 -1 0
0 11 0 1
0 27 3 13
1
end_operator
begin_operator
unstack b4 b17
0
4
0 17 0 15
0 37 -1 0
0 11 0 1
0 27 4 13
1
end_operator
begin_operator
unstack b4 b19
0
4
0 17 0 15
0 38 -1 0
0 11 0 1
0 27 5 13
1
end_operator
begin_operator
unstack b4 b20
0
4
0 17 0 15
0 12 -1 0
0 11 0 1
0 27 6 13
1
end_operator
begin_operator
unstack b4 b5
0
4
0 17 0 15
0 11 0 1
0 39 -1 0
0 27 7 13
1
end_operator
begin_operator
unstack b4 b6
0
4
0 17 0 15
0 11 0 1
0 5 -1 0
0 27 8 13
1
end_operator
begin_operator
unstack b4 b7
0
4
0 17 0 15
0 11 0 1
0 8 -1 0
0 27 9 13
1
end_operator
begin_operator
unstack b4 b8
0
4
0 17 0 15
0 11 0 1
0 15 -1 0
0 27 10 13
1
end_operator
begin_operator
unstack b4 b9
0
4
0 17 0 15
0 11 0 1
0 10 -1 0
0 27 11 13
1
end_operator
begin_operator
unstack b5 b1
0
4
0 17 0 16
0 14 -1 0
0 39 0 3
0 32 0 15
1
end_operator
begin_operator
unstack b5 b10
0
4
0 17 0 16
0 9 -1 0
0 39 0 3
0 32 1 15
1
end_operator
begin_operator
unstack b5 b11
0
4
0 17 0 16
0 13 -1 0
0 39 0 3
0 32 2 15
1
end_operator
begin_operator
unstack b5 b13
0
4
0 17 0 16
0 16 -1 0
0 39 0 3
0 32 3 15
1
end_operator
begin_operator
unstack b5 b15
0
4
0 17 0 16
0 3 -1 0
0 39 0 3
0 32 4 15
1
end_operator
begin_operator
unstack b5 b16
0
4
0 17 0 16
0 6 -1 0
0 39 0 3
0 32 5 15
1
end_operator
begin_operator
unstack b5 b17
0
4
0 17 0 16
0 37 -1 0
0 39 0 3
0 32 6 15
1
end_operator
begin_operator
unstack b5 b18
0
4
0 17 0 16
0 4 -1 0
0 39 0 3
0 32 7 15
1
end_operator
begin_operator
unstack b5 b19
0
4
0 17 0 16
0 38 -1 0
0 39 0 3
0 32 8 15
1
end_operator
begin_operator
unstack b5 b2
0
4
0 17 0 16
0 1 -1 0
0 39 0 3
0 32 9 15
1
end_operator
begin_operator
unstack b5 b20
0
4
0 17 0 16
0 12 -1 0
0 39 0 3
0 32 10 15
1
end_operator
begin_operator
unstack b5 b4
0
4
0 17 0 16
0 11 -1 0
0 39 0 3
0 32 11 15
1
end_operator
begin_operator
unstack b5 b7
0
4
0 17 0 16
0 39 0 3
0 8 -1 0
0 32 12 15
1
end_operator
begin_operator
unstack b5 b9
0
4
0 17 0 16
0 39 0 3
0 10 -1 0
0 32 13 15
1
end_operator
begin_operator
unstack b6 b18
0
4
0 17 0 17
0 4 -1 0
0 5 0 1
0 21 1 3
1
end_operator
begin_operator
unstack b7 b1
0
4
0 17 0 18
0 14 -1 0
0 8 0 1
0 33 0 16
1
end_operator
begin_operator
unstack b7 b10
0
4
0 17 0 18
0 9 -1 0
0 8 0 1
0 33 1 16
1
end_operator
begin_operator
unstack b7 b11
0
4
0 17 0 18
0 13 -1 0
0 8 0 1
0 33 2 16
1
end_operator
begin_operator
unstack b7 b13
0
4
0 17 0 18
0 16 -1 0
0 8 0 1
0 33 3 16
1
end_operator
begin_operator
unstack b7 b14
0
4
0 17 0 18
0 2 -1 0
0 8 0 1
0 33 4 16
1
end_operator
begin_operator
unstack b7 b15
0
4
0 17 0 18
0 3 -1 0
0 8 0 1
0 33 5 16
1
end_operator
begin_operator
unstack b7 b16
0
4
0 17 0 18
0 6 -1 0
0 8 0 1
0 33 6 16
1
end_operator
begin_operator
unstack b7 b18
0
4
0 17 0 18
0 4 -1 0
0 8 0 1
0 33 7 16
1
end_operator
begin_operator
unstack b7 b19
0
4
0 17 0 18
0 38 -1 0
0 8 0 1
0 33 8 16
1
end_operator
begin_operator
unstack b7 b2
0
4
0 17 0 18
0 1 -1 0
0 8 0 1
0 33 9 16
1
end_operator
begin_operator
unstack b7 b20
0
4
0 17 0 18
0 12 -1 0
0 8 0 1
0 33 10 16
1
end_operator
begin_operator
unstack b7 b4
0
4
0 17 0 18
0 11 -1 0
0 8 0 1
0 33 11 16
1
end_operator
begin_operator
unstack b7 b5
0
4
0 17 0 18
0 39 -1 0
0 8 0 1
0 33 12 16
1
end_operator
begin_operator
unstack b7 b6
0
4
0 17 0 18
0 5 -1 0
0 8 0 1
0 33 13 16
1
end_operator
begin_operator
unstack b7 b8
0
4
0 17 0 18
0 8 0 1
0 15 -1 0
0 33 14 16
1
end_operator
begin_operator
unstack b8 b10
0
4
0 17 0 19
0 9 -1 0
0 15 0 1
0 34 0 16
1
end_operator
begin_operator
unstack b8 b11
0
4
0 17 0 19
0 13 -1 0
0 15 0 1
0 34 1 16
1
end_operator
begin_operator
unstack b8 b13
0
4
0 17 0 19
0 16 -1 0
0 15 0 1
0 34 2 16
1
end_operator
begin_operator
unstack b8 b14
0
4
0 17 0 19
0 2 -1 0
0 15 0 1
0 34 3 16
1
end_operator
begin_operator
unstack b8 b15
0
4
0 17 0 19
0 3 -1 0
0 15 0 1
0 34 4 16
1
end_operator
begin_operator
unstack b8 b16
0
4
0 17 0 19
0 6 -1 0
0 15 0 1
0 34 5 16
1
end_operator
begin_operator
unstack b8 b17
0
4
0 17 0 19
0 37 -1 0
0 15 0 1
0 34 6 16
1
end_operator
begin_operator
unstack b8 b18
0
4
0 17 0 19
0 4 -1 0
0 15 0 1
0 34 7 16
1
end_operator
begin_operator
unstack b8 b19
0
4
0 17 0 19
0 38 -1 0
0 15 0 1
0 34 8 16
1
end_operator
begin_operator
unstack b8 b20
0
4
0 17 0 19
0 12 -1 0
0 15 0 1
0 34 9 16
1
end_operator
begin_operator
unstack b8 b4
0
4
0 17 0 19
0 11 -1 0
0 15 0 1
0 34 10 16
1
end_operator
begin_operator
unstack b8 b5
0
4
0 17 0 19
0 39 -1 0
0 15 0 1
0 34 11 16
1
end_operator
begin_operator
unstack b8 b6
0
4
0 17 0 19
0 5 -1 0
0 15 0 1
0 34 12 16
1
end_operator
begin_operator
unstack b8 b7
0
4
0 17 0 19
0 8 -1 0
0 15 0 1
0 34 13 16
1
end_operator
begin_operator
unstack b8 b9
0
4
0 17 0 19
0 15 0 1
0 10 -1 0
0 34 14 16
1
end_operator
begin_operator
unstack b9 b1
0
4
0 17 0 20
0 14 -1 0
0 10 0 1
0 28 0 13
1
end_operator
begin_operator
unstack b9 b10
0
4
0 17 0 20
0 9 -1 0
0 10 0 1
0 28 1 13
1
end_operator
begin_operator
unstack b9 b11
0
4
0 17 0 20
0 13 -1 0
0 10 0 1
0 28 2 13
1
end_operator
begin_operator
unstack b9 b13
0
4
0 17 0 20
0 16 -1 0
0 10 0 1
0 28 3 13
1
end_operator
begin_operator
unstack b9 b16
0
4
0 17 0 20
0 6 -1 0
0 10 0 1
0 28 4 13
1
end_operator
begin_operator
unstack b9 b17
0
4
0 17 0 20
0 37 -1 0
0 10 0 1
0 28 5 13
1
end_operator
begin_operator
unstack b9 b19
0
4
0 17 0 20
0 38 -1 0
0 10 0 1
0 28 6 13
1
end_operator
begin_operator
unstack b9 b20
0
4
0 17 0 20
0 12 -1 0
0 10 0 1
0 28 7 13
1
end_operator
begin_operator
unstack b9 b4
0
4
0 17 0 20
0 11 -1 0
0 10 0 1
0 28 8 13
1
end_operator
begin_operator
unstack b9 b5
0
4
0 17 0 20
0 39 -1 0
0 10 0 1
0 28 9 13
1
end_operator
begin_operator
unstack b9 b7
0
4
0 17 0 20
0 8 -1 0
0 10 0 1
0 28 10 13
1
end_operator
begin_operator
unstack b9 b8
0
4
0 17 0 20
0 15 -1 0
0 10 0 1
0 28 11 13
1
end_operator
0
