begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var0
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var2
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var1
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var5
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var3
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var4
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var6
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var9
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var8
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var7
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var12
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var13
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var14
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var15
-1
21
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b13)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
<none of those>
end_variable
begin_variable
var16
-1
3
Atom on(b13, b21)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var17
-1
3
Atom on(b15, b6)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var18
-1
3
Atom on(b17, b18)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var19
-1
3
Atom on(b16, b15)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var20
-1
3
Atom on(b19, b17)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom on(b11, b12)
Atom on(b11, b20)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom on(b21, b13)
Atom on(b21, b4)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var23
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var24
-1
3
Atom on(b7, b11)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var33
-1
4
Atom on(b3, b11)
Atom on(b3, b15)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var25
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var26
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var29
-1
12
Atom on(b18, b1)
Atom on(b18, b10)
Atom on(b18, b11)
Atom on(b18, b12)
Atom on(b18, b20)
Atom on(b18, b21)
Atom on(b18, b3)
Atom on(b18, b4)
Atom on(b18, b5)
Atom on(b18, b8)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var30
-1
11
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b18)
Atom on(b4, b2)
Atom on(b4, b20)
Atom on(b4, b21)
Atom on(b4, b9)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var27
-1
13
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b18)
Atom on(b9, b2)
Atom on(b9, b20)
Atom on(b9, b21)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b8)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var28
-1
13
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b18)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b9)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var35
-1
14
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b18)
Atom on(b6, b2)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var31
-1
14
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b21)
Atom on(b5, b4)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var37
-1
16
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b14)
Atom on(b12, b18)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var32
-1
15
Atom on(b10, b1)
Atom on(b10, b12)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b8)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var34
-1
16
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b3)
Atom on(b2, b6)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var38
-1
16
Atom on(b8, b1)
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b12)
Atom on(b8, b16)
Atom on(b8, b18)
Atom on(b8, b2)
Atom on(b8, b20)
Atom on(b8, b21)
Atom on(b8, b3)
Atom on(b8, b4)
Atom on(b8, b5)
Atom on(b8, b6)
Atom on(b8, b9)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var36
-1
17
Atom on(b20, b1)
Atom on(b20, b10)
Atom on(b20, b11)
Atom on(b20, b12)
Atom on(b20, b15)
Atom on(b20, b16)
Atom on(b20, b17)
Atom on(b20, b18)
Atom on(b20, b2)
Atom on(b20, b21)
Atom on(b20, b3)
Atom on(b20, b4)
Atom on(b20, b5)
Atom on(b20, b6)
Atom on(b20, b9)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var39
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var40
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var41
-1
2
Atom clear(b14)
<none of those>
end_variable
3385
begin_mutex_group
21
15 0
15 1
15 2
15 3
15 4
15 5
15 6
15 7
15 8
15 9
15 10
15 11
15 12
15 13
15 14
15 15
15 16
15 17
15 18
15 19
34 0
end_mutex_group
begin_mutex_group
10
15 1
8 0
34 1
35 0
28 0
38 0
29 0
33 0
32 0
37 0
end_mutex_group
begin_mutex_group
12
15 2
39 0
34 2
31 0
28 1
36 0
38 1
29 1
33 1
32 1
37 1
30 0
end_mutex_group
begin_mutex_group
14
15 3
5 0
34 3
31 1
28 2
36 1
38 2
25 0
29 2
33 2
32 2
24 0
37 2
30 1
end_mutex_group
begin_mutex_group
12
14 0
34 0
35 1
21 0
28 3
36 2
38 3
29 3
33 3
32 3
37 3
30 2
end_mutex_group
begin_mutex_group
3
15 4
0 0
22 0
end_mutex_group
begin_mutex_group
2
41 0
34 4
end_mutex_group
begin_mutex_group
7
15 5
2 0
35 2
19 0
36 3
38 4
25 1
end_mutex_group
begin_mutex_group
6
15 6
27 0
35 3
36 4
38 5
37 4
end_mutex_group
begin_mutex_group
6
15 7
1 0
35 4
20 0
36 5
38 6
end_mutex_group
begin_mutex_group
12
15 8
10 0
34 5
31 2
18 0
36 6
38 7
29 4
33 4
32 4
37 5
30 3
end_mutex_group
begin_mutex_group
5
15 9
26 0
35 5
36 7
33 5
end_mutex_group
begin_mutex_group
11
15 10
13 0
34 6
31 3
35 6
38 8
29 5
33 6
32 5
37 6
30 4
end_mutex_group
begin_mutex_group
13
15 11
40 0
34 7
31 4
35 7
21 1
28 4
36 8
29 6
33 7
32 6
37 7
30 5
end_mutex_group
begin_mutex_group
14
15 12
4 0
34 8
31 5
35 8
16 0
28 5
36 9
38 9
29 7
33 8
32 7
37 8
30 6
end_mutex_group
begin_mutex_group
9
15 13
3 0
34 9
31 6
35 9
28 6
36 10
38 10
37 9
end_mutex_group
begin_mutex_group
12
15 14
7 0
34 10
31 7
35 10
28 7
38 11
22 1
33 9
32 8
37 10
30 7
end_mutex_group
begin_mutex_group
9
15 15
9 0
34 11
31 8
28 8
38 12
32 9
37 11
30 8
end_mutex_group
begin_mutex_group
10
15 16
11 0
34 12
31 9
35 11
17 0
36 11
38 13
37 12
30 9
end_mutex_group
begin_mutex_group
2
15 17
23 0
end_mutex_group
begin_mutex_group
9
15 18
12 0
34 13
35 12
28 9
36 12
33 10
32 10
30 10
end_mutex_group
begin_mutex_group
10
15 19
6 0
34 14
31 10
36 13
38 14
29 8
33 11
32 11
37 13
end_mutex_group
begin_mutex_group
13
15 1
31 0
31 1
31 2
31 3
31 4
31 5
31 6
31 7
31 8
31 9
31 10
31 11
end_mutex_group
begin_mutex_group
15
15 2
35 0
35 1
35 2
35 3
35 4
35 5
35 6
35 7
35 8
35 9
35 10
35 11
35 12
35 13
end_mutex_group
begin_mutex_group
4
15 3
21 0
21 1
21 2
end_mutex_group
begin_mutex_group
3
15 4
16 0
16 1
end_mutex_group
begin_mutex_group
3
15 5
17 0
17 1
end_mutex_group
begin_mutex_group
3
15 6
19 0
19 1
end_mutex_group
begin_mutex_group
3
15 7
18 0
18 1
end_mutex_group
begin_mutex_group
12
15 8
28 0
28 1
28 2
28 3
28 4
28 5
28 6
28 7
28 8
28 9
28 10
end_mutex_group
begin_mutex_group
3
15 9
20 0
20 1
end_mutex_group
begin_mutex_group
16
15 10
36 0
36 1
36 2
36 3
36 4
36 5
36 6
36 7
36 8
36 9
36 10
36 11
36 12
36 13
36 14
end_mutex_group
begin_mutex_group
17
15 11
38 0
38 1
38 2
38 3
38 4
38 5
38 6
38 7
38 8
38 9
38 10
38 11
38 12
38 13
38 14
38 15
end_mutex_group
begin_mutex_group
4
15 12
22 0
22 1
22 2
end_mutex_group
begin_mutex_group
4
15 13
25 0
25 1
25 2
end_mutex_group
begin_mutex_group
11
15 14
29 0
29 1
29 2
29 3
29 4
29 5
29 6
29 7
29 8
29 9
end_mutex_group
begin_mutex_group
14
15 15
33 0
33 1
33 2
33 3
33 4
33 5
33 6
33 7
33 8
33 9
33 10
33 11
33 12
end_mutex_group
begin_mutex_group
14
15 16
32 0
32 1
32 2
32 3
32 4
32 5
32 6
32 7
32 8
32 9
32 10
32 11
32 12
end_mutex_group
begin_mutex_group
3
15 17
24 0
24 1
end_mutex_group
begin_mutex_group
16
15 18
37 0
37 1
37 2
37 3
37 4
37 5
37 6
37 7
37 8
37 9
37 10
37 11
37 12
37 13
37 14
end_mutex_group
begin_mutex_group
13
15 19
30 0
30 1
30 2
30 3
30 4
30 5
30 6
30 7
30 8
30 9
30 10
30 11
end_mutex_group
begin_mutex_group
2
0 0
16 2
end_mutex_group
begin_mutex_group
2
0 1
16 0
end_mutex_group
begin_mutex_group
2
2 0
15 4
end_mutex_group
begin_mutex_group
2
2 0
16 0
end_mutex_group
begin_mutex_group
2
2 0
16 2
end_mutex_group
begin_mutex_group
2
2 0
17 2
end_mutex_group
begin_mutex_group
2
2 0
21 1
end_mutex_group
begin_mutex_group
2
2 0
22 1
end_mutex_group
begin_mutex_group
2
2 0
30 10
end_mutex_group
begin_mutex_group
2
2 1
15 6
end_mutex_group
begin_mutex_group
2
2 1
19 2
end_mutex_group
begin_mutex_group
2
1 0
15 4
end_mutex_group
begin_mutex_group
2
1 0
15 5
end_mutex_group
begin_mutex_group
2
1 0
15 6
end_mutex_group
begin_mutex_group
2
1 0
16 0
end_mutex_group
begin_mutex_group
2
1 0
16 2
end_mutex_group
begin_mutex_group
2
1 0
17 0
end_mutex_group
begin_mutex_group
2
1 0
17 2
end_mutex_group
begin_mutex_group
2
1 0
18 2
end_mutex_group
begin_mutex_group
2
1 0
19 0
end_mutex_group
begin_mutex_group
2
1 0
19 2
end_mutex_group
begin_mutex_group
2
1 0
21 1
end_mutex_group
begin_mutex_group
2
1 0
22 1
end_mutex_group
begin_mutex_group
2
1 0
30 10
end_mutex_group
begin_mutex_group
2
1 1
15 9
end_mutex_group
begin_mutex_group
2
1 1
20 2
end_mutex_group
begin_mutex_group
2
4 0
22 3
end_mutex_group
begin_mutex_group
2
4 1
15 4
end_mutex_group
begin_mutex_group
2
4 1
16 2
end_mutex_group
begin_mutex_group
2
5 0
15 4
end_mutex_group
begin_mutex_group
2
5 0
16 0
end_mutex_group
begin_mutex_group
2
5 0
16 2
end_mutex_group
begin_mutex_group
2
5 0
21 3
end_mutex_group
begin_mutex_group
2
5 0
22 1
end_mutex_group
begin_mutex_group
2
3 0
15 4
end_mutex_group
begin_mutex_group
2
3 0
16 0
end_mutex_group
begin_mutex_group
2
3 0
16 2
end_mutex_group
begin_mutex_group
2
3 0
22 1
end_mutex_group
begin_mutex_group
2
3 0
25 3
end_mutex_group
begin_mutex_group
2
6 0
15 4
end_mutex_group
begin_mutex_group
2
6 0
16 0
end_mutex_group
begin_mutex_group
2
6 0
16 2
end_mutex_group
begin_mutex_group
2
6 0
21 1
end_mutex_group
begin_mutex_group
2
6 0
22 1
end_mutex_group
begin_mutex_group
2
6 0
30 12
end_mutex_group
begin_mutex_group
2
9 0
15 4
end_mutex_group
begin_mutex_group
2
9 0
15 5
end_mutex_group
begin_mutex_group
2
9 0
15 6
end_mutex_group
begin_mutex_group
2
9 0
16 0
end_mutex_group
begin_mutex_group
2
9 0
16 2
end_mutex_group
begin_mutex_group
2
9 0
17 0
end_mutex_group
begin_mutex_group
2
9 0
17 2
end_mutex_group
begin_mutex_group
2
9 0
19 0
end_mutex_group
begin_mutex_group
2
9 0
19 2
end_mutex_group
begin_mutex_group
2
9 0
21 1
end_mutex_group
begin_mutex_group
2
9 0
22 1
end_mutex_group
begin_mutex_group
2
9 0
30 10
end_mutex_group
begin_mutex_group
2
9 0
33 13
end_mutex_group
begin_mutex_group
2
8 0
15 4
end_mutex_group
begin_mutex_group
2
8 0
15 5
end_mutex_group
begin_mutex_group
2
8 0
15 6
end_mutex_group
begin_mutex_group
2
8 0
15 7
end_mutex_group
begin_mutex_group
2
8 0
15 9
end_mutex_group
begin_mutex_group
2
8 0
16 0
end_mutex_group
begin_mutex_group
2
8 0
16 2
end_mutex_group
begin_mutex_group
2
8 0
17 0
end_mutex_group
begin_mutex_group
2
8 0
17 2
end_mutex_group
begin_mutex_group
2
8 0
18 0
end_mutex_group
begin_mutex_group
2
8 0
18 2
end_mutex_group
begin_mutex_group
2
8 0
19 0
end_mutex_group
begin_mutex_group
2
8 0
19 2
end_mutex_group
begin_mutex_group
2
8 0
20 0
end_mutex_group
begin_mutex_group
2
8 0
20 2
end_mutex_group
begin_mutex_group
2
8 0
21 1
end_mutex_group
begin_mutex_group
2
8 0
22 1
end_mutex_group
begin_mutex_group
2
8 0
30 10
end_mutex_group
begin_mutex_group
2
8 0
31 12
end_mutex_group
begin_mutex_group
2
7 0
15 4
end_mutex_group
begin_mutex_group
2
7 0
16 0
end_mutex_group
begin_mutex_group
2
7 0
16 2
end_mutex_group
begin_mutex_group
2
7 0
29 10
end_mutex_group
begin_mutex_group
2
10 0
15 4
end_mutex_group
begin_mutex_group
2
10 0
15 5
end_mutex_group
begin_mutex_group
2
10 0
15 6
end_mutex_group
begin_mutex_group
2
10 0
15 9
end_mutex_group
begin_mutex_group
2
10 0
16 0
end_mutex_group
begin_mutex_group
2
10 0
16 2
end_mutex_group
begin_mutex_group
2
10 0
17 0
end_mutex_group
begin_mutex_group
2
10 0
17 2
end_mutex_group
begin_mutex_group
2
10 0
19 0
end_mutex_group
begin_mutex_group
2
10 0
19 2
end_mutex_group
begin_mutex_group
2
10 0
20 0
end_mutex_group
begin_mutex_group
2
10 0
20 2
end_mutex_group
begin_mutex_group
2
10 0
21 1
end_mutex_group
begin_mutex_group
2
10 0
22 1
end_mutex_group
begin_mutex_group
2
10 0
30 10
end_mutex_group
begin_mutex_group
2
10 0
28 11
end_mutex_group
begin_mutex_group
2
10 1
15 7
end_mutex_group
begin_mutex_group
2
10 1
18 2
end_mutex_group
begin_mutex_group
2
11 0
15 4
end_mutex_group
begin_mutex_group
2
11 0
15 6
end_mutex_group
begin_mutex_group
2
11 0
16 0
end_mutex_group
begin_mutex_group
2
11 0
16 2
end_mutex_group
begin_mutex_group
2
11 0
19 0
end_mutex_group
begin_mutex_group
2
11 0
19 2
end_mutex_group
begin_mutex_group
2
11 0
21 1
end_mutex_group
begin_mutex_group
2
11 0
22 1
end_mutex_group
begin_mutex_group
2
11 0
30 10
end_mutex_group
begin_mutex_group
2
11 0
32 13
end_mutex_group
begin_mutex_group
2
11 1
15 5
end_mutex_group
begin_mutex_group
2
11 1
17 2
end_mutex_group
begin_mutex_group
2
12 0
15 4
end_mutex_group
begin_mutex_group
2
12 0
16 0
end_mutex_group
begin_mutex_group
2
12 0
16 2
end_mutex_group
begin_mutex_group
2
12 0
21 1
end_mutex_group
begin_mutex_group
2
12 0
22 1
end_mutex_group
begin_mutex_group
2
12 0
37 15
end_mutex_group
begin_mutex_group
2
13 0
15 4
end_mutex_group
begin_mutex_group
2
13 0
15 5
end_mutex_group
begin_mutex_group
2
13 0
15 6
end_mutex_group
begin_mutex_group
2
13 0
15 7
end_mutex_group
begin_mutex_group
2
13 0
15 9
end_mutex_group
begin_mutex_group
2
13 0
16 0
end_mutex_group
begin_mutex_group
2
13 0
16 2
end_mutex_group
begin_mutex_group
2
13 0
17 0
end_mutex_group
begin_mutex_group
2
13 0
17 2
end_mutex_group
begin_mutex_group
2
13 0
18 0
end_mutex_group
begin_mutex_group
2
13 0
18 2
end_mutex_group
begin_mutex_group
2
13 0
19 0
end_mutex_group
begin_mutex_group
2
13 0
19 2
end_mutex_group
begin_mutex_group
2
13 0
20 0
end_mutex_group
begin_mutex_group
2
13 0
20 2
end_mutex_group
begin_mutex_group
2
13 0
21 1
end_mutex_group
begin_mutex_group
2
13 0
22 1
end_mutex_group
begin_mutex_group
2
13 0
30 10
end_mutex_group
begin_mutex_group
2
13 0
28 0
end_mutex_group
begin_mutex_group
2
13 0
36 15
end_mutex_group
begin_mutex_group
2
14 0
15 4
end_mutex_group
begin_mutex_group
2
14 0
15 5
end_mutex_group
begin_mutex_group
2
14 0
15 6
end_mutex_group
begin_mutex_group
2
14 0
15 7
end_mutex_group
begin_mutex_group
2
14 0
15 9
end_mutex_group
begin_mutex_group
2
14 0
15 20
end_mutex_group
begin_mutex_group
2
14 0
16 0
end_mutex_group
begin_mutex_group
2
14 0
16 2
end_mutex_group
begin_mutex_group
2
14 0
17 0
end_mutex_group
begin_mutex_group
2
14 0
17 2
end_mutex_group
begin_mutex_group
2
14 0
18 0
end_mutex_group
begin_mutex_group
2
14 0
18 2
end_mutex_group
begin_mutex_group
2
14 0
19 0
end_mutex_group
begin_mutex_group
2
14 0
19 2
end_mutex_group
begin_mutex_group
2
14 0
20 0
end_mutex_group
begin_mutex_group
2
14 0
20 2
end_mutex_group
begin_mutex_group
2
14 0
21 1
end_mutex_group
begin_mutex_group
2
14 0
22 1
end_mutex_group
begin_mutex_group
2
14 0
30 10
end_mutex_group
begin_mutex_group
2
14 0
28 0
end_mutex_group
begin_mutex_group
2
15 0
16 2
end_mutex_group
begin_mutex_group
2
15 0
17 2
end_mutex_group
begin_mutex_group
2
15 0
18 2
end_mutex_group
begin_mutex_group
2
15 0
19 2
end_mutex_group
begin_mutex_group
2
15 0
20 2
end_mutex_group
begin_mutex_group
2
15 0
21 3
end_mutex_group
begin_mutex_group
2
15 0
22 3
end_mutex_group
begin_mutex_group
2
15 0
23 1
end_mutex_group
begin_mutex_group
2
15 0
24 2
end_mutex_group
begin_mutex_group
2
15 0
30 12
end_mutex_group
begin_mutex_group
2
15 0
31 12
end_mutex_group
begin_mutex_group
2
15 0
28 11
end_mutex_group
begin_mutex_group
2
15 0
29 10
end_mutex_group
begin_mutex_group
2
15 0
33 13
end_mutex_group
begin_mutex_group
2
15 0
35 14
end_mutex_group
begin_mutex_group
2
15 0
25 3
end_mutex_group
begin_mutex_group
2
15 0
36 15
end_mutex_group
begin_mutex_group
2
15 0
32 13
end_mutex_group
begin_mutex_group
2
15 0
38 16
end_mutex_group
begin_mutex_group
2
15 0
37 15
end_mutex_group
begin_mutex_group
2
15 1
16 0
end_mutex_group
begin_mutex_group
2
15 1
16 2
end_mutex_group
begin_mutex_group
2
15 1
17 0
end_mutex_group
begin_mutex_group
2
15 1
17 2
end_mutex_group
begin_mutex_group
2
15 1
18 0
end_mutex_group
begin_mutex_group
2
15 1
18 2
end_mutex_group
begin_mutex_group
2
15 1
19 0
end_mutex_group
begin_mutex_group
2
15 1
19 2
end_mutex_group
begin_mutex_group
2
15 1
20 0
end_mutex_group
begin_mutex_group
2
15 1
20 2
end_mutex_group
begin_mutex_group
2
15 1
21 1
end_mutex_group
begin_mutex_group
2
15 1
21 3
end_mutex_group
begin_mutex_group
2
15 1
22 1
end_mutex_group
begin_mutex_group
2
15 1
22 3
end_mutex_group
begin_mutex_group
2
15 1
23 1
end_mutex_group
begin_mutex_group
2
15 1
24 2
end_mutex_group
begin_mutex_group
2
15 1
30 10
end_mutex_group
begin_mutex_group
2
15 1
30 12
end_mutex_group
begin_mutex_group
2
15 1
28 11
end_mutex_group
begin_mutex_group
2
15 1
29 10
end_mutex_group
begin_mutex_group
2
15 1
33 13
end_mutex_group
begin_mutex_group
2
15 1
35 14
end_mutex_group
begin_mutex_group
2
15 1
25 3
end_mutex_group
begin_mutex_group
2
15 1
36 15
end_mutex_group
begin_mutex_group
2
15 1
32 13
end_mutex_group
begin_mutex_group
2
15 1
38 16
end_mutex_group
begin_mutex_group
2
15 1
37 15
end_mutex_group
begin_mutex_group
2
15 2
16 0
end_mutex_group
begin_mutex_group
2
15 2
16 2
end_mutex_group
begin_mutex_group
2
15 2
17 2
end_mutex_group
begin_mutex_group
2
15 2
18 2
end_mutex_group
begin_mutex_group
2
15 2
19 2
end_mutex_group
begin_mutex_group
2
15 2
20 2
end_mutex_group
begin_mutex_group
2
15 2
21 3
end_mutex_group
begin_mutex_group
2
15 2
22 1
end_mutex_group
begin_mutex_group
2
15 2
22 3
end_mutex_group
begin_mutex_group
2
15 2
23 1
end_mutex_group
begin_mutex_group
2
15 2
24 2
end_mutex_group
begin_mutex_group
2
15 2
30 12
end_mutex_group
begin_mutex_group
2
15 2
31 12
end_mutex_group
begin_mutex_group
2
15 2
28 11
end_mutex_group
begin_mutex_group
2
15 2
29 10
end_mutex_group
begin_mutex_group
2
15 2
33 13
end_mutex_group
begin_mutex_group
2
15 2
25 3
end_mutex_group
begin_mutex_group
2
15 2
36 15
end_mutex_group
begin_mutex_group
2
15 2
32 13
end_mutex_group
begin_mutex_group
2
15 2
38 16
end_mutex_group
begin_mutex_group
2
15 2
37 15
end_mutex_group
begin_mutex_group
2
15 3
16 0
end_mutex_group
begin_mutex_group
2
15 3
16 2
end_mutex_group
begin_mutex_group
2
15 3
17 2
end_mutex_group
begin_mutex_group
2
15 3
18 2
end_mutex_group
begin_mutex_group
2
15 3
19 2
end_mutex_group
begin_mutex_group
2
15 3
20 2
end_mutex_group
begin_mutex_group
2
15 3
22 1
end_mutex_group
begin_mutex_group
2
15 3
22 3
end_mutex_group
begin_mutex_group
2
15 3
23 1
end_mutex_group
begin_mutex_group
2
15 3
24 2
end_mutex_group
begin_mutex_group
2
15 3
30 12
end_mutex_group
begin_mutex_group
2
15 3
31 12
end_mutex_group
begin_mutex_group
2
15 3
28 11
end_mutex_group
begin_mutex_group
2
15 3
29 10
end_mutex_group
begin_mutex_group
2
15 3
33 13
end_mutex_group
begin_mutex_group
2
15 3
35 14
end_mutex_group
begin_mutex_group
2
15 3
25 3
end_mutex_group
begin_mutex_group
2
15 3
36 15
end_mutex_group
begin_mutex_group
2
15 3
32 13
end_mutex_group
begin_mutex_group
2
15 3
38 16
end_mutex_group
begin_mutex_group
2
15 3
37 15
end_mutex_group
begin_mutex_group
2
15 4
17 1
end_mutex_group
begin_mutex_group
2
15 4
17 2
end_mutex_group
begin_mutex_group
2
15 4
18 1
end_mutex_group
begin_mutex_group
2
15 4
18 2
end_mutex_group
begin_mutex_group
2
15 4
19 1
end_mutex_group
begin_mutex_group
2
15 4
19 2
end_mutex_group
begin_mutex_group
2
15 4
20 1
end_mutex_group
begin_mutex_group
2
15 4
20 2
end_mutex_group
begin_mutex_group
2
15 4
21 0
end_mutex_group
begin_mutex_group
2
15 4
21 2
end_mutex_group
begin_mutex_group
2
15 4
21 3
end_mutex_group
begin_mutex_group
2
15 4
22 2
end_mutex_group
begin_mutex_group
2
15 4
22 3
end_mutex_group
begin_mutex_group
2
15 4
23 1
end_mutex_group
begin_mutex_group
2
15 4
24 0
end_mutex_group
begin_mutex_group
2
15 4
24 2
end_mutex_group
begin_mutex_group
2
15 4
26 0
end_mutex_group
begin_mutex_group
2
15 4
27 0
end_mutex_group
begin_mutex_group
2
15 4
30 0
end_mutex_group
begin_mutex_group
2
15 4
30 1
end_mutex_group
begin_mutex_group
2
15 4
30 2
end_mutex_group
begin_mutex_group
2
15 4
30 3
end_mutex_group
begin_mutex_group
2
15 4
30 4
end_mutex_group
begin_mutex_group
2
15 4
30 5
end_mutex_group
begin_mutex_group
2
15 4
30 6
end_mutex_group
begin_mutex_group
2
15 4
30 7
end_mutex_group
begin_mutex_group
2
15 4
30 8
end_mutex_group
begin_mutex_group
2
15 4
30 9
end_mutex_group
begin_mutex_group
2
15 4
30 11
end_mutex_group
begin_mutex_group
2
15 4
30 12
end_mutex_group
begin_mutex_group
2
15 4
31 0
end_mutex_group
begin_mutex_group
2
15 4
31 1
end_mutex_group
begin_mutex_group
2
15 4
31 2
end_mutex_group
begin_mutex_group
2
15 4
31 4
end_mutex_group
begin_mutex_group
2
15 4
31 5
end_mutex_group
begin_mutex_group
2
15 4
31 6
end_mutex_group
begin_mutex_group
2
15 4
31 7
end_mutex_group
begin_mutex_group
2
15 4
31 8
end_mutex_group
begin_mutex_group
2
15 4
31 9
end_mutex_group
begin_mutex_group
2
15 4
31 10
end_mutex_group
begin_mutex_group
2
15 4
31 11
end_mutex_group
begin_mutex_group
2
15 4
31 12
end_mutex_group
begin_mutex_group
2
15 4
28 1
end_mutex_group
begin_mutex_group
2
15 4
28 2
end_mutex_group
begin_mutex_group
2
15 4
28 3
end_mutex_group
begin_mutex_group
2
15 4
28 4
end_mutex_group
begin_mutex_group
2
15 4
28 5
end_mutex_group
begin_mutex_group
2
15 4
28 6
end_mutex_group
begin_mutex_group
2
15 4
28 7
end_mutex_group
begin_mutex_group
2
15 4
28 8
end_mutex_group
begin_mutex_group
2
15 4
28 9
end_mutex_group
begin_mutex_group
2
15 4
28 10
end_mutex_group
begin_mutex_group
2
15 4
28 11
end_mutex_group
begin_mutex_group
2
15 4
29 0
end_mutex_group
begin_mutex_group
2
15 4
29 2
end_mutex_group
begin_mutex_group
2
15 4
29 3
end_mutex_group
begin_mutex_group
2
15 4
29 4
end_mutex_group
begin_mutex_group
2
15 4
29 5
end_mutex_group
begin_mutex_group
2
15 4
29 6
end_mutex_group
begin_mutex_group
2
15 4
29 7
end_mutex_group
begin_mutex_group
2
15 4
29 8
end_mutex_group
begin_mutex_group
2
15 4
29 9
end_mutex_group
begin_mutex_group
2
15 4
29 10
end_mutex_group
begin_mutex_group
2
15 4
33 0
end_mutex_group
begin_mutex_group
2
15 4
33 1
end_mutex_group
begin_mutex_group
2
15 4
33 2
end_mutex_group
begin_mutex_group
2
15 4
33 3
end_mutex_group
begin_mutex_group
2
15 4
33 4
end_mutex_group
begin_mutex_group
2
15 4
33 6
end_mutex_group
begin_mutex_group
2
15 4
33 7
end_mutex_group
begin_mutex_group
2
15 4
33 8
end_mutex_group
begin_mutex_group
2
15 4
33 9
end_mutex_group
begin_mutex_group
2
15 4
33 10
end_mutex_group
begin_mutex_group
2
15 4
33 11
end_mutex_group
begin_mutex_group
2
15 4
33 12
end_mutex_group
begin_mutex_group
2
15 4
33 13
end_mutex_group
begin_mutex_group
2
15 4
35 0
end_mutex_group
begin_mutex_group
2
15 4
35 1
end_mutex_group
begin_mutex_group
2
15 4
35 2
end_mutex_group
begin_mutex_group
2
15 4
35 3
end_mutex_group
begin_mutex_group
2
15 4
35 4
end_mutex_group
begin_mutex_group
2
15 4
35 5
end_mutex_group
begin_mutex_group
2
15 4
35 6
end_mutex_group
begin_mutex_group
2
15 4
35 7
end_mutex_group
begin_mutex_group
2
15 4
35 8
end_mutex_group
begin_mutex_group
2
15 4
35 10
end_mutex_group
begin_mutex_group
2
15 4
35 11
end_mutex_group
begin_mutex_group
2
15 4
35 12
end_mutex_group
begin_mutex_group
2
15 4
35 13
end_mutex_group
begin_mutex_group
2
15 4
35 14
end_mutex_group
begin_mutex_group
2
15 4
25 1
end_mutex_group
begin_mutex_group
2
15 4
25 2
end_mutex_group
begin_mutex_group
2
15 4
25 3
end_mutex_group
begin_mutex_group
2
15 4
36 0
end_mutex_group
begin_mutex_group
2
15 4
36 1
end_mutex_group
begin_mutex_group
2
15 4
36 3
end_mutex_group
begin_mutex_group
2
15 4
36 4
end_mutex_group
begin_mutex_group
2
15 4
36 5
end_mutex_group
begin_mutex_group
2
15 4
36 6
end_mutex_group
begin_mutex_group
2
15 4
36 7
end_mutex_group
begin_mutex_group
2
15 4
36 8
end_mutex_group
begin_mutex_group
2
15 4
36 9
end_mutex_group
begin_mutex_group
2
15 4
36 10
end_mutex_group
begin_mutex_group
2
15 4
3




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




nd_operator
begin_operator
putdown b10
0
3
0 15 2 0
0 39 -1 0
0 35 -1 13
1
end_operator
begin_operator
putdown b11
0
3
0 15 3 0
0 5 -1 0
0 21 -1 2
1
end_operator
begin_operator
putdown b12
0
3
0 15 -1 0
0 14 -1 0
0 34 0 15
1
end_operator
begin_operator
putdown b13
0
3
0 15 4 0
0 0 -1 0
0 16 -1 1
1
end_operator
begin_operator
putdown b15
0
3
0 15 5 0
0 2 -1 0
0 17 -1 1
1
end_operator
begin_operator
putdown b16
0
3
0 15 6 0
0 27 -1 0
0 19 -1 1
1
end_operator
begin_operator
putdown b17
0
3
0 15 7 0
0 1 -1 0
0 18 -1 1
1
end_operator
begin_operator
putdown b18
0
3
0 15 8 0
0 10 -1 0
0 28 -1 10
1
end_operator
begin_operator
putdown b19
0
3
0 15 9 0
0 26 -1 0
0 20 -1 1
1
end_operator
begin_operator
putdown b2
0
3
0 15 10 0
0 13 -1 0
0 36 -1 14
1
end_operator
begin_operator
putdown b20
0
3
0 15 11 0
0 40 -1 0
0 38 -1 15
1
end_operator
begin_operator
putdown b21
0
3
0 15 12 0
0 4 -1 0
0 22 -1 2
1
end_operator
begin_operator
putdown b3
0
3
0 15 13 0
0 3 -1 0
0 25 -1 2
1
end_operator
begin_operator
putdown b4
0
3
0 15 14 0
0 7 -1 0
0 29 -1 9
1
end_operator
begin_operator
putdown b5
0
3
0 15 15 0
0 9 -1 0
0 33 -1 12
1
end_operator
begin_operator
putdown b6
0
3
0 15 16 0
0 11 -1 0
0 32 -1 12
1
end_operator
begin_operator
putdown b8
0
3
0 15 18 0
0 12 -1 0
0 37 -1 14
1
end_operator
begin_operator
putdown b9
0
3
0 15 19 0
0 6 -1 0
0 30 -1 11
1
end_operator
begin_operator
stack b1 b10
0
4
0 15 1 0
0 8 -1 0
0 39 0 1
0 31 -1 0
1
end_operator
begin_operator
stack b1 b11
0
4
0 15 1 0
0 8 -1 0
0 5 0 1
0 31 -1 1
1
end_operator
begin_operator
stack b1 b18
0
4
0 15 1 0
0 8 -1 0
0 10 0 1
0 31 -1 2
1
end_operator
begin_operator
stack b1 b2
0
4
0 15 1 0
0 8 -1 0
0 13 0 1
0 31 -1 3
1
end_operator
begin_operator
stack b1 b20
0
4
0 15 1 0
0 8 -1 0
0 40 0 1
0 31 -1 4
1
end_operator
begin_operator
stack b1 b21
0
4
0 15 1 0
0 8 -1 0
0 4 0 1
0 31 -1 5
1
end_operator
begin_operator
stack b1 b3
0
4
0 15 1 0
0 8 -1 0
0 3 0 1
0 31 -1 6
1
end_operator
begin_operator
stack b1 b4
0
4
0 15 1 0
0 8 -1 0
0 7 0 1
0 31 -1 7
1
end_operator
begin_operator
stack b1 b5
0
4
0 15 1 0
0 8 -1 0
0 9 0 1
0 31 -1 8
1
end_operator
begin_operator
stack b1 b6
0
4
0 15 1 0
0 8 -1 0
0 11 0 1
0 31 -1 9
1
end_operator
begin_operator
stack b1 b9
0
4
0 15 1 0
0 8 -1 0
0 6 0 1
0 31 -1 10
1
end_operator
begin_operator
stack b10 b1
0
4
0 15 2 0
0 8 0 1
0 39 -1 0
0 35 -1 0
1
end_operator
begin_operator
stack b10 b12
0
4
0 15 2 0
0 39 -1 0
0 14 0 1
0 35 -1 1
1
end_operator
begin_operator
stack b10 b15
0
4
0 15 2 0
0 39 -1 0
0 2 0 1
0 35 -1 2
1
end_operator
begin_operator
stack b10 b16
0
4
0 15 2 0
0 39 -1 0
0 27 0 1
0 35 -1 3
1
end_operator
begin_operator
stack b10 b17
0
4
0 15 2 0
0 39 -1 0
0 1 0 1
0 35 -1 4
1
end_operator
begin_operator
stack b10 b19
0
4
0 15 2 0
0 39 -1 0
0 26 0 1
0 35 -1 5
1
end_operator
begin_operator
stack b10 b2
0
4
0 15 2 0
0 39 -1 0
0 13 0 1
0 35 -1 6
1
end_operator
begin_operator
stack b10 b20
0
4
0 15 2 0
0 39 -1 0
0 40 0 1
0 35 -1 7
1
end_operator
begin_operator
stack b10 b21
0
4
0 15 2 0
0 39 -1 0
0 4 0 1
0 35 -1 8
1
end_operator
begin_operator
stack b10 b3
0
4
0 15 2 0
0 39 -1 0
0 3 0 1
0 35 -1 9
1
end_operator
begin_operator
stack b10 b4
0
4
0 15 2 0
0 39 -1 0
0 7 0 1
0 35 -1 10
1
end_operator
begin_operator
stack b10 b6
0
4
0 15 2 0
0 39 -1 0
0 11 0 1
0 35 -1 11
1
end_operator
begin_operator
stack b10 b8
0
4
0 15 2 0
0 39 -1 0
0 12 0 1
0 35 -1 12
1
end_operator
begin_operator
stack b11 b12
0
4
0 15 3 0
0 5 -1 0
0 14 0 1
0 21 -1 0
1
end_operator
begin_operator
stack b12 b1
0
4
0 15 -1 0
0 8 0 1
0 14 -1 0
0 34 0 1
1
end_operator
begin_operator
stack b12 b10
0
4
0 15 -1 0
0 39 0 1
0 14 -1 0
0 34 0 2
1
end_operator
begin_operator
stack b12 b11
0
4
0 15 -1 0
0 5 0 1
0 14 -1 0
0 34 0 3
1
end_operator
begin_operator
stack b12 b18
0
4
0 15 -1 0
0 14 -1 0
0 10 0 1
0 34 0 5
1
end_operator
begin_operator
stack b12 b2
0
4
0 15 -1 0
0 14 -1 0
0 13 0 1
0 34 0 6
1
end_operator
begin_operator
stack b12 b20
0
4
0 15 -1 0
0 14 -1 0
0 40 0 1
0 34 0 7
1
end_operator
begin_operator
stack b12 b21
0
4
0 15 -1 0
0 14 -1 0
0 4 0 1
0 34 0 8
1
end_operator
begin_operator
stack b12 b3
0
4
0 15 -1 0
0 14 -1 0
0 3 0 1
0 34 0 9
1
end_operator
begin_operator
stack b12 b4
0
4
0 15 -1 0
0 14 -1 0
0 7 0 1
0 34 0 10
1
end_operator
begin_operator
stack b12 b5
0
4
0 15 -1 0
0 14 -1 0
0 9 0 1
0 34 0 11
1
end_operator
begin_operator
stack b12 b6
0
4
0 15 -1 0
0 14 -1 0
0 11 0 1
0 34 0 12
1
end_operator
begin_operator
stack b12 b8
0
4
0 15 -1 0
0 14 -1 0
0 12 0 1
0 34 0 13
1
end_operator
begin_operator
stack b12 b9
0
4
0 15 -1 0
0 14 -1 0
0 6 0 1
0 34 0 14
1
end_operator
begin_operator
stack b18 b10
0
4
0 15 8 0
0 39 0 1
0 10 -1 0
0 28 -1 1
1
end_operator
begin_operator
stack b18 b11
0
4
0 15 8 0
0 5 0 1
0 10 -1 0
0 28 -1 2
1
end_operator
begin_operator
stack b18 b12
0
4
0 15 8 0
0 14 0 1
0 10 -1 0
0 28 -1 3
1
end_operator
begin_operator
stack b18 b20
0
4
0 15 8 0
0 10 -1 0
0 40 0 1
0 28 -1 4
1
end_operator
begin_operator
stack b18 b21
0
4
0 15 8 0
0 10 -1 0
0 4 0 1
0 28 -1 5
1
end_operator
begin_operator
stack b18 b3
0
4
0 15 8 0
0 10 -1 0
0 3 0 1
0 28 -1 6
1
end_operator
begin_operator
stack b18 b4
0
4
0 15 8 0
0 10 -1 0
0 7 0 1
0 28 -1 7
1
end_operator
begin_operator
stack b18 b5
0
4
0 15 8 0
0 10 -1 0
0 9 0 1
0 28 -1 8
1
end_operator
begin_operator
stack b18 b8
0
4
0 15 8 0
0 10 -1 0
0 12 0 1
0 28 -1 9
1
end_operator
begin_operator
stack b2 b10
0
4
0 15 10 0
0 39 0 1
0 13 -1 0
0 36 -1 0
1
end_operator
begin_operator
stack b2 b11
0
4
0 15 10 0
0 5 0 1
0 13 -1 0
0 36 -1 1
1
end_operator
begin_operator
stack b2 b12
0
4
0 15 10 0
0 14 0 1
0 13 -1 0
0 36 -1 2
1
end_operator
begin_operator
stack b2 b15
0
4
0 15 10 0
0 2 0 1
0 13 -1 0
0 36 -1 3
1
end_operator
begin_operator
stack b2 b16
0
4
0 15 10 0
0 27 0 1
0 13 -1 0
0 36 -1 4
1
end_operator
begin_operator
stack b2 b17
0
4
0 15 10 0
0 1 0 1
0 13 -1 0
0 36 -1 5
1
end_operator
begin_operator
stack b2 b18
0
4
0 15 10 0
0 10 0 1
0 13 -1 0
0 36 -1 6
1
end_operator
begin_operator
stack b2 b19
0
4
0 15 10 0
0 26 0 1
0 13 -1 0
0 36 -1 7
1
end_operator
begin_operator
stack b2 b20
0
4
0 15 10 0
0 13 -1 0
0 40 0 1
0 36 -1 8
1
end_operator
begin_operator
stack b2 b21
0
4
0 15 10 0
0 13 -1 0
0 4 0 1
0 36 -1 9
1
end_operator
begin_operator
stack b2 b3
0
4
0 15 10 0
0 13 -1 0
0 3 0 1
0 36 -1 10
1
end_operator
begin_operator
stack b2 b6
0
4
0 15 10 0
0 13 -1 0
0 11 0 1
0 36 -1 11
1
end_operator
begin_operator
stack b2 b8
0
4
0 15 10 0
0 13 -1 0
0 12 0 1
0 36 -1 12
1
end_operator
begin_operator
stack b2 b9
0
4
0 15 10 0
0 13 -1 0
0 6 0 1
0 36 -1 13
1
end_operator
begin_operator
stack b20 b1
0
4
0 15 11 0
0 8 0 1
0 40 -1 0
0 38 -1 0
1
end_operator
begin_operator
stack b20 b10
0
4
0 15 11 0
0 39 0 1
0 40 -1 0
0 38 -1 1
1
end_operator
begin_operator
stack b20 b11
0
4
0 15 11 0
0 5 0 1
0 40 -1 0
0 38 -1 2
1
end_operator
begin_operator
stack b20 b12
0
4
0 15 11 0
0 14 0 1
0 40 -1 0
0 38 -1 3
1
end_operator
begin_operator
stack b20 b15
0
4
0 15 11 0
0 2 0 1
0 40 -1 0
0 38 -1 4
1
end_operator
begin_operator
stack b20 b16
0
4
0 15 11 0
0 27 0 1
0 40 -1 0
0 38 -1 5
1
end_operator
begin_operator
stack b20 b17
0
4
0 15 11 0
0 1 0 1
0 40 -1 0
0 38 -1 6
1
end_operator
begin_operator
stack b20 b18
0
4
0 15 11 0
0 10 0 1
0 40 -1 0
0 38 -1 7
1
end_operator
begin_operator
stack b20 b2
0
4
0 15 11 0
0 13 0 1
0 40 -1 0
0 38 -1 8
1
end_operator
begin_operator
stack b20 b21
0
4
0 15 11 0
0 40 -1 0
0 4 0 1
0 38 -1 9
1
end_operator
begin_operator
stack b20 b3
0
4
0 15 11 0
0 40 -1 0
0 3 0 1
0 38 -1 10
1
end_operator
begin_operator
stack b20 b4
0
4
0 15 11 0
0 40 -1 0
0 7 0 1
0 38 -1 11
1
end_operator
begin_operator
stack b20 b5
0
4
0 15 11 0
0 40 -1 0
0 9 0 1
0 38 -1 12
1
end_operator
begin_operator
stack b20 b6
0
4
0 15 11 0
0 40 -1 0
0 11 0 1
0 38 -1 13
1
end_operator
begin_operator
stack b20 b9
0
4
0 15 11 0
0 40 -1 0
0 6 0 1
0 38 -1 14
1
end_operator
begin_operator
stack b21 b13
0
4
0 15 12 0
0 0 0 1
0 4 -1 0
0 22 -1 0
1
end_operator
begin_operator
stack b3 b11
0
4
0 15 13 0
0 5 0 1
0 3 -1 0
0 25 -1 0
1
end_operator
begin_operator
stack b3 b15
0
4
0 15 13 0
0 2 0 1
0 3 -1 0
0 25 -1 1
1
end_operator
begin_operator
stack b4 b1
0
4
0 15 14 0
0 8 0 1
0 7 -1 0
0 29 -1 0
1
end_operator
begin_operator
stack b4 b10
0
4
0 15 14 0
0 39 0 1
0 7 -1 0
0 29 -1 1
1
end_operator
begin_operator
stack b4 b11
0
4
0 15 14 0
0 5 0 1
0 7 -1 0
0 29 -1 2
1
end_operator
begin_operator
stack b4 b12
0
4
0 15 14 0
0 14 0 1
0 7 -1 0
0 29 -1 3
1
end_operator
begin_operator
stack b4 b18
0
4
0 15 14 0
0 10 0 1
0 7 -1 0
0 29 -1 4
1
end_operator
begin_operator
stack b4 b2
0
4
0 15 14 0
0 13 0 1
0 7 -1 0
0 29 -1 5
1
end_operator
begin_operator
stack b4 b20
0
4
0 15 14 0
0 40 0 1
0 7 -1 0
0 29 -1 6
1
end_operator
begin_operator
stack b4 b21
0
4
0 15 14 0
0 4 0 1
0 7 -1 0
0 29 -1 7
1
end_operator
begin_operator
stack b4 b9
0
4
0 15 14 0
0 7 -1 0
0 6 0 1
0 29 -1 8
1
end_operator
begin_operator
stack b5 b1
0
4
0 15 15 0
0 8 0 1
0 9 -1 0
0 33 -1 0
1
end_operator
begin_operator
stack b5 b10
0
4
0 15 15 0
0 39 0 1
0 9 -1 0
0 33 -1 1
1
end_operator
begin_operator
stack b5 b11
0
4
0 15 15 0
0 5 0 1
0 9 -1 0
0 33 -1 2
1
end_operator
begin_operator
stack b5 b12
0
4
0 15 15 0
0 14 0 1
0 9 -1 0
0 33 -1 3
1
end_operator
begin_operator
stack b5 b18
0
4
0 15 15 0
0 10 0 1
0 9 -1 0
0 33 -1 4
1
end_operator
begin_operator
stack b5 b19
0
4
0 15 15 0
0 26 0 1
0 9 -1 0
0 33 -1 5
1
end_operator
begin_operator
stack b5 b2
0
4
0 15 15 0
0 13 0 1
0 9 -1 0
0 33 -1 6
1
end_operator
begin_operator
stack b5 b20
0
4
0 15 15 0
0 40 0 1
0 9 -1 0
0 33 -1 7
1
end_operator
begin_operator
stack b5 b21
0
4
0 15 15 0
0 4 0 1
0 9 -1 0
0 33 -1 8
1
end_operator
begin_operator
stack b5 b4
0
4
0 15 15 0
0 7 0 1
0 9 -1 0
0 33 -1 9
1
end_operator
begin_operator
stack b5 b8
0
4
0 15 15 0
0 9 -1 0
0 12 0 1
0 33 -1 10
1
end_operator
begin_operator
stack b5 b9
0
4
0 15 15 0
0 9 -1 0
0 6 0 1
0 33 -1 11
1
end_operator
begin_operator
stack b6 b1
0
4
0 15 16 0
0 8 0 1
0 11 -1 0
0 32 -1 0
1
end_operator
begin_operator
stack b6 b10
0
4
0 15 16 0
0 39 0 1
0 11 -1 0
0 32 -1 1
1
end_operator
begin_operator
stack b6 b11
0
4
0 15 16 0
0 5 0 1
0 11 -1 0
0 32 -1 2
1
end_operator
begin_operator
stack b6 b12
0
4
0 15 16 0
0 14 0 1
0 11 -1 0
0 32 -1 3
1
end_operator
begin_operator
stack b6 b18
0
4
0 15 16 0
0 10 0 1
0 11 -1 0
0 32 -1 4
1
end_operator
begin_operator
stack b6 b2
0
4
0 15 16 0
0 13 0 1
0 11 -1 0
0 32 -1 5
1
end_operator
begin_operator
stack b6 b20
0
4
0 15 16 0
0 40 0 1
0 11 -1 0
0 32 -1 6
1
end_operator
begin_operator
stack b6 b21
0
4
0 15 16 0
0 4 0 1
0 11 -1 0
0 32 -1 7
1
end_operator
begin_operator
stack b6 b4
0
4
0 15 16 0
0 7 0 1
0 11 -1 0
0 32 -1 8
1
end_operator
begin_operator
stack b6 b5
0
4
0 15 16 0
0 9 0 1
0 11 -1 0
0 32 -1 9
1
end_operator
begin_operator
stack b6 b8
0
4
0 15 16 0
0 11 -1 0
0 12 0 1
0 32 -1 10
1
end_operator
begin_operator
stack b6 b9
0
4
0 15 16 0
0 11 -1 0
0 6 0 1
0 32 -1 11
1
end_operator
begin_operator
stack b7 b11
0
4
0 15 17 0
0 5 0 1
0 23 -1 0
0 24 -1 0
1
end_operator
begin_operator
stack b8 b1
0
4
0 15 18 0
0 8 0 1
0 12 -1 0
0 37 -1 0
1
end_operator
begin_operator
stack b8 b10
0
4
0 15 18 0
0 39 0 1
0 12 -1 0
0 37 -1 1
1
end_operator
begin_operator
stack b8 b11
0
4
0 15 18 0
0 5 0 1
0 12 -1 0
0 37 -1 2
1
end_operator
begin_operator
stack b8 b12
0
4
0 15 18 0
0 14 0 1
0 12 -1 0
0 37 -1 3
1
end_operator
begin_operator
stack b8 b16
0
4
0 15 18 0
0 27 0 1
0 12 -1 0
0 37 -1 4
1
end_operator
begin_operator
stack b8 b18
0
4
0 15 18 0
0 10 0 1
0 12 -1 0
0 37 -1 5
1
end_operator
begin_operator
stack b8 b2
0
4
0 15 18 0
0 13 0 1
0 12 -1 0
0 37 -1 6
1
end_operator
begin_operator
stack b8 b20
0
4
0 15 18 0
0 40 0 1
0 12 -1 0
0 37 -1 7
1
end_operator
begin_operator
stack b8 b21
0
4
0 15 18 0
0 4 0 1
0 12 -1 0
0 37 -1 8
1
end_operator
begin_operator
stack b8 b3
0
4
0 15 18 0
0 3 0 1
0 12 -1 0
0 37 -1 9
1
end_operator
begin_operator
stack b8 b4
0
4
0 15 18 0
0 7 0 1
0 12 -1 0
0 37 -1 10
1
end_operator
begin_operator
stack b8 b5
0
4
0 15 18 0
0 9 0 1
0 12 -1 0
0 37 -1 11
1
end_operator
begin_operator
stack b8 b6
0
4
0 15 18 0
0 11 0 1
0 12 -1 0
0 37 -1 12
1
end_operator
begin_operator
stack b8 b9
0
4
0 15 18 0
0 12 -1 0
0 6 0 1
0 37 -1 13
1
end_operator
begin_operator
stack b9 b10
0
4
0 15 19 0
0 39 0 1
0 6 -1 0
0 30 -1 0
1
end_operator
begin_operator
stack b9 b11
0
4
0 15 19 0
0 5 0 1
0 6 -1 0
0 30 -1 1
1
end_operator
begin_operator
stack b9 b12
0
4
0 15 19 0
0 14 0 1
0 6 -1 0
0 30 -1 2
1
end_operator
begin_operator
stack b9 b18
0
4
0 15 19 0
0 10 0 1
0 6 -1 0
0 30 -1 3
1
end_operator
begin_operator
stack b9 b2
0
4
0 15 19 0
0 13 0 1
0 6 -1 0
0 30 -1 4
1
end_operator
begin_operator
stack b9 b20
0
4
0 15 19 0
0 40 0 1
0 6 -1 0
0 30 -1 5
1
end_operator
begin_operator
stack b9 b21
0
4
0 15 19 0
0 4 0 1
0 6 -1 0
0 30 -1 6
1
end_operator
begin_operator
stack b9 b4
0
4
0 15 19 0
0 7 0 1
0 6 -1 0
0 30 -1 7
1
end_operator
begin_operator
stack b9 b5
0
4
0 15 19 0
0 9 0 1
0 6 -1 0
0 30 -1 8
1
end_operator
begin_operator
stack b9 b6
0
4
0 15 19 0
0 11 0 1
0 6 -1 0
0 30 -1 9
1
end_operator
begin_operator
unstack b1 b10
0
4
0 15 0 1
0 8 0 1
0 39 -1 0
0 31 0 12
1
end_operator
begin_operator
unstack b1 b11
0
4
0 15 0 1
0 8 0 1
0 5 -1 0
0 31 1 12
1
end_operator
begin_operator
unstack b1 b18
0
4
0 15 0 1
0 8 0 1
0 10 -1 0
0 31 2 12
1
end_operator
begin_operator
unstack b1 b2
0
4
0 15 0 1
0 8 0 1
0 13 -1 0
0 31 3 12
1
end_operator
begin_operator
unstack b1 b20
0
4
0 15 0 1
0 8 0 1
0 40 -1 0
0 31 4 12
1
end_operator
begin_operator
unstack b1 b21
0
4
0 15 0 1
0 8 0 1
0 4 -1 0
0 31 5 12
1
end_operator
begin_operator
unstack b1 b3
0
4
0 15 0 1
0 8 0 1
0 3 -1 0
0 31 6 12
1
end_operator
begin_operator
unstack b1 b4
0
4
0 15 0 1
0 8 0 1
0 7 -1 0
0 31 7 12
1
end_operator
begin_operator
unstack b1 b5
0
4
0 15 0 1
0 8 0 1
0 9 -1 0
0 31 8 12
1
end_operator
begin_operator
unstack b1 b6
0
4
0 15 0 1
0 8 0 1
0 11 -1 0
0 31 9 12
1
end_operator
begin_operator
unstack b1 b9
0
4
0 15 0 1
0 8 0 1
0 6 -1 0
0 31 10 12
1
end_operator
begin_operator
unstack b10 b1
0
4
0 15 0 2
0 8 -1 0
0 39 0 1
0 35 0 14
1
end_operator
begin_operator
unstack b10 b12
0
4
0 15 0 2
0 39 0 1
0 14 -1 0
0 35 1 14
1
end_operator
begin_operator
unstack b10 b15
0
4
0 15 0 2
0 39 0 1
0 2 -1 0
0 35 2 14
1
end_operator
begin_operator
unstack b10 b16
0
4
0 15 0 2
0 39 0 1
0 27 -1 0
0 35 3 14
1
end_operator
begin_operator
unstack b10 b17
0
4
0 15 0 2
0 39 0 1
0 1 -1 0
0 35 4 14
1
end_operator
begin_operator
unstack b10 b19
0
4
0 15 0 2
0 39 0 1
0 26 -1 0
0 35 5 14
1
end_operator
begin_operator
unstack b10 b2
0
4
0 15 0 2
0 39 0 1
0 13 -1 0
0 35 6 14
1
end_operator
begin_operator
unstack b10 b20
0
4
0 15 0 2
0 39 0 1
0 40 -1 0
0 35 7 14
1
end_operator
begin_operator
unstack b10 b21
0
4
0 15 0 2
0 39 0 1
0 4 -1 0
0 35 8 14
1
end_operator
begin_operator
unstack b10 b3
0
4
0 15 0 2
0 39 0 1
0 3 -1 0
0 35 9 14
1
end_operator
begin_operator
unstack b10 b4
0
4
0 15 0 2
0 39 0 1
0 7 -1 0
0 35 10 14
1
end_operator
begin_operator
unstack b10 b6
0
4
0 15 0 2
0 39 0 1
0 11 -1 0
0 35 11 14
1
end_operator
begin_operator
unstack b10 b8
0
4
0 15 0 2
0 39 0 1
0 12 -1 0
0 35 12 14
1
end_operator
begin_operator
unstack b11 b12
0
4
0 15 0 3
0 5 0 1
0 14 -1 0
0 21 0 3
1
end_operator
begin_operator
unstack b11 b20
0
4
0 15 0 3
0 5 0 1
0 40 -1 0
0 21 1 3
1
end_operator
begin_operator
unstack b12 b1
0
4
0 15 0 20
0 8 -1 0
0 14 0 1
0 34 1 0
1
end_operator
begin_operator
unstack b12 b10
0
4
0 15 0 20
0 39 -1 0
0 14 0 1
0 34 2 0
1
end_operator
begin_operator
unstack b12 b11
0
4
0 15 0 20
0 5 -1 0
0 14 0 1
0 34 3 0
1
end_operator
begin_operator
unstack b12 b14
0
4
0 15 0 20
0 14 0 1
0 41 -1 0
0 34 4 0
1
end_operator
begin_operator
unstack b12 b18
0
4
0 15 0 20
0 14 0 1
0 10 -1 0
0 34 5 0
1
end_operator
begin_operator
unstack b12 b2
0
4
0 15 0 20
0 14 0 1
0 13 -1 0
0 34 6 0
1
end_operator
begin_operator
unstack b12 b20
0
4
0 15 0 20
0 14 0 1
0 40 -1 0
0 34 7 0
1
end_operator
begin_operator
unstack b12 b21
0
4
0 15 0 20
0 14 0 1
0 4 -1 0
0 34 8 0
1
end_operator
begin_operator
unstack b12 b3
0
4
0 15 0 20
0 14 0 1
0 3 -1 0
0 34 9 0
1
end_operator
begin_operator
unstack b12 b4
0
4
0 15 0 20
0 14 0 1
0 7 -1 0
0 34 10 0
1
end_operator
begin_operator
unstack b12 b5
0
4
0 15 0 20
0 14 0 1
0 9 -1 0
0 34 11 0
1
end_operator
begin_operator
unstack b12 b6
0
4
0 15 0 20
0 14 0 1
0 11 -1 0
0 34 12 0
1
end_operator
begin_operator
unstack b12 b8
0
4
0 15 0 20
0 14 0 1
0 12 -1 0
0 34 13 0
1
end_operator
begin_operator
unstack b12 b9
0
4
0 15 0 20
0 14 0 1
0 6 -1 0
0 34 14 0
1
end_operator
begin_operator
unstack b13 b21
0
4
0 15 0 4
0 0 0 1
0 4 -1 0
0 16 0 2
1
end_operator
begin_operator
unstack b15 b6
0
4
0 15 0 5
0 2 0 1
0 11 -1 0
0 17 0 2
1
end_operator
begin_operator
unstack b16 b15
0
4
0 15 0 6
0 2 -1 0
0 27 0 1
0 19 0 2
1
end_operator
begin_operator
unstack b17 b18
0
4
0 15 0 7
0 1 0 1
0 10 -1 0
0 18 0 2
1
end_operator
begin_operator
unstack b18 b1
0
4
0 15 0 8
0 8 -1 0
0 10 0 1
0 28 0 11
1
end_operator
begin_operator
unstack b18 b10
0
4
0 15 0 8
0 39 -1 0
0 10 0 1
0 28 1 11
1
end_operator
begin_operator
unstack b18 b11
0
4
0 15 0 8
0 5 -1 0
0 10 0 1
0 28 2 11
1
end_operator
begin_operator
unstack b18 b12
0
4
0 15 0 8
0 14 -1 0
0 10 0 1
0 28 3 11
1
end_operator
begin_operator
unstack b18 b20
0
4
0 15 0 8
0 10 0 1
0 40 -1 0
0 28 4 11
1
end_operator
begin_operator
unstack b18 b21
0
4
0 15 0 8
0 10 0 1
0 4 -1 0
0 28 5 11
1
end_operator
begin_operator
unstack b18 b3
0
4
0 15 0 8
0 10 0 1
0 3 -1 0
0 28 6 11
1
end_operator
begin_operator
unstack b18 b4
0
4
0 15 0 8
0 10 0 1
0 7 -1 0
0 28 7 11
1
end_operator
begin_operator
unstack b18 b5
0
4
0 15 0 8
0 10 0 1
0 9 -1 0
0 28 8 11
1
end_operator
begin_operator
unstack b18 b8
0
4
0 15 0 8
0 10 0 1
0 12 -1 0
0 28 9 11
1
end_operator
begin_operator
unstack b19 b17
0
4
0 15 0 9
0 1 -1 0
0 26 0 1
0 20 0 2
1
end_operator
begin_operator
unstack b2 b10
0
4
0 15 0 10
0 39 -1 0
0 13 0 1
0 36 0 15
1
end_operator
begin_operator
unstack b2 b11
0
4
0 15 0 10
0 5 -1 0
0 13 0 1
0 36 1 15
1
end_operator
begin_operator
unstack b2 b12
0
4
0 15 0 10
0 14 -1 0
0 13 0 1
0 36 2 15
1
end_operator
begin_operator
unstack b2 b15
0
4
0 15 0 10
0 2 -1 0
0 13 0 1
0 36 3 15
1
end_operator
begin_operator
unstack b2 b16
0
4
0 15 0 10
0 27 -1 0
0 13 0 1
0 36 4 15
1
end_operator
begin_operator
unstack b2 b17
0
4
0 15 0 10
0 1 -1 0
0 13 0 1
0 36 5 15
1
end_operator
begin_operator
unstack b2 b18
0
4
0 15 0 10
0 10 -1 0
0 13 0 1
0 36 6 15
1
end_operator
begin_operator
unstack b2 b19
0
4
0 15 0 10
0 26 -1 0
0 13 0 1
0 36 7 15
1
end_operator
begin_operator
unstack b2 b20
0
4
0 15 0 10
0 13 0 1
0 40 -1 0
0 36 8 15
1
end_operator
begin_operator
unstack b2 b21
0
4
0 15 0 10
0 13 0 1
0 4 -1 0
0 36 9 15
1
end_operator
begin_operator
unstack b2 b3
0
4
0 15 0 10
0 13 0 1
0 3 -1 0
0 36 10 15
1
end_operator
begin_operator
unstack b2 b6
0
4
0 15 0 10
0 13 0 1
0 11 -1 0
0 36 11 15
1
end_operator
begin_operator
unstack b2 b8
0
4
0 15 0 10
0 13 0 1
0 12 -1 0
0 36 12 15
1
end_operator
begin_operator
unstack b2 b9
0
4
0 15 0 10
0 13 0 1
0 6 -1 0
0 36 13 15
1
end_operator
begin_operator
unstack b20 b1
0
4
0 15 0 11
0 8 -1 0
0 40 0 1
0 38 0 16
1
end_operator
begin_operator
unstack b20 b10
0
4
0 15 0 11
0 39 -1 0
0 40 0 1
0 38 1 16
1
end_operator
begin_operator
unstack b20 b11
0
4
0 15 0 11
0 5 -1 0
0 40 0 1
0 38 2 16
1
end_operator
begin_operator
unstack b20 b12
0
4
0 15 0 11
0 14 -1 0
0 40 0 1
0 38 3 16
1
end_operator
begin_operator
unstack b20 b15
0
4
0 15 0 11
0 2 -1 0
0 40 0 1
0 38 4 16
1
end_operator
begin_operator
unstack b20 b16
0
4
0 15 0 11
0 27 -1 0
0 40 0 1
0 38 5 16
1
end_operator
begin_operator
unstack b20 b17
0
4
0 15 0 11
0 1 -1 0
0 40 0 1
0 38 6 16
1
end_operator
begin_operator
unstack b20 b18
0
4
0 15 0 11
0 10 -1 0
0 40 0 1
0 38 7 16
1
end_operator
begin_operator
unstack b20 b2
0
4
0 15 0 11
0 13 -1 0
0 40 0 1
0 38 8 16
1
end_operator
begin_operator
unstack b20 b21
0
4
0 15 0 11
0 40 0 1
0 4 -1 0
0 38 9 16
1
end_operator
begin_operator
unstack b20 b3
0
4
0 15 0 11
0 40 0 1
0 3 -1 0
0 38 10 16
1
end_operator
begin_operator
unstack b20 b4
0
4
0 15 0 11
0 40 0 1
0 7 -1 0
0 38 11 16
1
end_operator
begin_operator
unstack b20 b5
0
4
0 15 0 11
0 40 0 1
0 9 -1 0
0 38 12 16
1
end_operator
begin_operator
unstack b20 b6
0
4
0 15 0 11
0 40 0 1
0 11 -1 0
0 38 13 16
1
end_operator
begin_operator
unstack b20 b9
0
4
0 15 0 11
0 40 0 1
0 6 -1 0
0 38 14 16
1
end_operator
begin_operator
unstack b21 b4
0
4
0 15 0 12
0 4 0 1
0 7 -1 0
0 22 1 3
1
end_operator
begin_operator
unstack b3 b11
0
4
0 15 0 13
0 5 -1 0
0 3 0 1
0 25 0 3
1
end_operator
begin_operator
unstack b4 b1
0
4
0 15 0 14
0 8 -1 0
0 7 0 1
0 29 0 10
1
end_operator
begin_operator
unstack b4 b10
0
4
0 15 0 14
0 39 -1 0
0 7 0 1
0 29 1 10
1
end_operator
begin_operator
unstack b4 b11
0
4
0 15 0 14
0 5 -1 0
0 7 0 1
0 29 2 10
1
end_operator
begin_operator
unstack b4 b12
0
4
0 15 0 14
0 14 -1 0
0 7 0 1
0 29 3 10
1
end_operator
begin_operator
unstack b4 b18
0
4
0 15 0 14
0 10 -1 0
0 7 0 1
0 29 4 10
1
end_operator
begin_operator
unstack b4 b2
0
4
0 15 0 14
0 13 -1 0
0 7 0 1
0 29 5 10
1
end_operator
begin_operator
unstack b4 b20
0
4
0 15 0 14
0 40 -1 0
0 7 0 1
0 29 6 10
1
end_operator
begin_operator
unstack b4 b21
0
4
0 15 0 14
0 4 -1 0
0 7 0 1
0 29 7 10
1
end_operator
begin_operator
unstack b4 b9
0
4
0 15 0 14
0 7 0 1
0 6 -1 0
0 29 8 10
1
end_operator
begin_operator
unstack b5 b1
0
4
0 15 0 15
0 8 -1 0
0 9 0 1
0 33 0 13
1
end_operator
begin_operator
unstack b5 b10
0
4
0 15 0 15
0 39 -1 0
0 9 0 1
0 33 1 13
1
end_operator
begin_operator
unstack b5 b11
0
4
0 15 0 15
0 5 -1 0
0 9 0 1
0 33 2 13
1
end_operator
begin_operator
unstack b5 b12
0
4
0 15 0 15
0 14 -1 0
0 9 0 1
0 33 3 13
1
end_operator
begin_operator
unstack b5 b18
0
4
0 15 0 15
0 10 -1 0
0 9 0 1
0 33 4 13
1
end_operator
begin_operator
unstack b5 b19
0
4
0 15 0 15
0 26 -1 0
0 9 0 1
0 33 5 13
1
end_operator
begin_operator
unstack b5 b2
0
4
0 15 0 15
0 13 -1 0
0 9 0 1
0 33 6 13
1
end_operator
begin_operator
unstack b5 b20
0
4
0 15 0 15
0 40 -1 0
0 9 0 1
0 33 7 13
1
end_operator
begin_operator
unstack b5 b21
0
4
0 15 0 15
0 4 -1 0
0 9 0 1
0 33 8 13
1
end_operator
begin_operator
unstack b5 b4
0
4
0 15 0 15
0 7 -1 0
0 9 0 1
0 33 9 13
1
end_operator
begin_operator
unstack b5 b8
0
4
0 15 0 15
0 9 0 1
0 12 -1 0
0 33 10 13
1
end_operator
begin_operator
unstack b5 b9
0
4
0 15 0 15
0 9 0 1
0 6 -1 0
0 33 11 13
1
end_operator
begin_operator
unstack b6 b1
0
4
0 15 0 16
0 8 -1 0
0 11 0 1
0 32 0 13
1
end_operator
begin_operator
unstack b6 b10
0
4
0 15 0 16
0 39 -1 0
0 11 0 1
0 32 1 13
1
end_operator
begin_operator
unstack b6 b11
0
4
0 15 0 16
0 5 -1 0
0 11 0 1
0 32 2 13
1
end_operator
begin_operator
unstack b6 b12
0
4
0 15 0 16
0 14 -1 0
0 11 0 1
0 32 3 13
1
end_operator
begin_operator
unstack b6 b18
0
4
0 15 0 16
0 10 -1 0
0 11 0 1
0 32 4 13
1
end_operator
begin_operator
unstack b6 b2
0
4
0 15 0 16
0 13 -1 0
0 11 0 1
0 32 5 13
1
end_operator
begin_operator
unstack b6 b20
0
4
0 15 0 16
0 40 -1 0
0 11 0 1
0 32 6 13
1
end_operator
begin_operator
unstack b6 b21
0
4
0 15 0 16
0 4 -1 0
0 11 0 1
0 32 7 13
1
end_operator
begin_operator
unstack b6 b4
0
4
0 15 0 16
0 7 -1 0
0 11 0 1
0 32 8 13
1
end_operator
begin_operator
unstack b6 b5
0
4
0 15 0 16
0 9 -1 0
0 11 0 1
0 32 9 13
1
end_operator
begin_operator
unstack b6 b8
0
4
0 15 0 16
0 11 0 1
0 12 -1 0
0 32 10 13
1
end_operator
begin_operator
unstack b6 b9
0
4
0 15 0 16
0 11 0 1
0 6 -1 0
0 32 11 13
1
end_operator
begin_operator
unstack b7 b11
0
4
0 15 0 17
0 5 -1 0
0 23 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b8 b1
0
4
0 15 0 18
0 8 -1 0
0 12 0 1
0 37 0 15
1
end_operator
begin_operator
unstack b8 b10
0
4
0 15 0 18
0 39 -1 0
0 12 0 1
0 37 1 15
1
end_operator
begin_operator
unstack b8 b11
0
4
0 15 0 18
0 5 -1 0
0 12 0 1
0 37 2 15
1
end_operator
begin_operator
unstack b8 b12
0
4
0 15 0 18
0 14 -1 0
0 12 0 1
0 37 3 15
1
end_operator
begin_operator
unstack b8 b16
0
4
0 15 0 18
0 27 -1 0
0 12 0 1
0 37 4 15
1
end_operator
begin_operator
unstack b8 b18
0
4
0 15 0 18
0 10 -1 0
0 12 0 1
0 37 5 15
1
end_operator
begin_operator
unstack b8 b2
0
4
0 15 0 18
0 13 -1 0
0 12 0 1
0 37 6 15
1
end_operator
begin_operator
unstack b8 b20
0
4
0 15 0 18
0 40 -1 0
0 12 0 1
0 37 7 15
1
end_operator
begin_operator
unstack b8 b21
0
4
0 15 0 18
0 4 -1 0
0 12 0 1
0 37 8 15
1
end_operator
begin_operator
unstack b8 b3
0
4
0 15 0 18
0 3 -1 0
0 12 0 1
0 37 9 15
1
end_operator
begin_operator
unstack b8 b4
0
4
0 15 0 18
0 7 -1 0
0 12 0 1
0 37 10 15
1
end_operator
begin_operator
unstack b8 b5
0
4
0 15 0 18
0 9 -1 0
0 12 0 1
0 37 11 15
1
end_operator
begin_operator
unstack b8 b6
0
4
0 15 0 18
0 11 -1 0
0 12 0 1
0 37 12 15
1
end_operator
begin_operator
unstack b8 b9
0
4
0 15 0 18
0 12 0 1
0 6 -1 0
0 37 13 15
1
end_operator
begin_operator
unstack b9 b10
0
4
0 15 0 19
0 39 -1 0
0 6 0 1
0 30 0 12
1
end_operator
begin_operator
unstack b9 b11
0
4
0 15 0 19
0 5 -1 0
0 6 0 1
0 30 1 12
1
end_operator
begin_operator
unstack b9 b12
0
4
0 15 0 19
0 14 -1 0
0 6 0 1
0 30 2 12
1
end_operator
begin_operator
unstack b9 b18
0
4
0 15 0 19
0 10 -1 0
0 6 0 1
0 30 3 12
1
end_operator
begin_operator
unstack b9 b2
0
4
0 15 0 19
0 13 -1 0
0 6 0 1
0 30 4 12
1
end_operator
begin_operator
unstack b9 b20
0
4
0 15 0 19
0 40 -1 0
0 6 0 1
0 30 5 12
1
end_operator
begin_operator
unstack b9 b21
0
4
0 15 0 19
0 4 -1 0
0 6 0 1
0 30 6 12
1
end_operator
begin_operator
unstack b9 b4
0
4
0 15 0 19
0 7 -1 0
0 6 0 1
0 30 7 12
1
end_operator
begin_operator
unstack b9 b5
0
4
0 15 0 19
0 9 -1 0
0 6 0 1
0 30 8 12
1
end_operator
begin_operator
unstack b9 b6
0
4
0 15 0 19
0 11 -1 0
0 6 0 1
0 30 9 12
1
end_operator
begin_operator
unstack b9 b8
0
4
0 15 0 19
0 12 -1 0
0 6 0 1
0 30 10 12
1
end_operator
0
