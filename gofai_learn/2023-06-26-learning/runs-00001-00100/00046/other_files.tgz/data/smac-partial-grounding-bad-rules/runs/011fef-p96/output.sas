begin_version
3
end_version
begin_metric
0
end_metric
56
begin_variable
var0
-1
2
Atom on-table(b2)
NegatedAtom on-table(b2)
end_variable
begin_variable
var1
-1
2
Atom on-table(b11)
NegatedAtom on-table(b11)
end_variable
begin_variable
var2
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var4
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var3
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var5
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b9)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var8
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var14
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var11
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var9
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var10
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var12
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var13
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var15
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var16
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var17
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var18
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var19
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var20
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var21
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var22
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var23
-1
13
Atom arm-empty()
Atom holding(b11)
Atom holding(b13)
Atom holding(b15)
Atom holding(b17)
Atom holding(b2)
Atom holding(b23)
Atom holding(b25)
Atom holding(b4)
Atom holding(b5)
Atom holding(b7)
Atom holding(b8)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b4, b27)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var25
-1
3
Atom on(b8, b15)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom on(b17, b11)
Atom on(b17, b21)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b7, b23)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var30
-1
4
Atom on(b5, b7)
Atom on(b5, b8)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var32
-1
4
Atom holding(b18)
Atom on(b18, b13)
Atom on(b18, b22)
Atom on-table(b18)
end_variable
begin_variable
var49
-1
4
Atom holding(b21)
Atom on(b21, b22)
Atom on(b21, b25)
Atom on-table(b21)
end_variable
begin_variable
var28
-1
3
Atom on(b15, b7)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var35
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var36
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var29
-1
6
Atom on(b23, b11)
Atom on(b23, b4)
Atom on(b23, b7)
Atom on(b23, b9)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var31
-1
10
Atom holding(b20)
Atom on(b20, b10)
Atom on(b20, b12)
Atom on(b20, b19)
Atom on(b20, b21)
Atom on(b20, b23)
Atom on(b20, b26)
Atom on(b20, b6)
Atom on(b20, b7)
Atom on-table(b20)
end_variable
begin_variable
var34
-1
11
Atom holding(b10)
Atom on(b10, b12)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b8)
Atom on-table(b10)
end_variable
begin_variable
var40
-1
12
Atom holding(b12)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b14)
Atom on(b12, b18)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b28)
Atom on(b12, b3)
Atom on(b12, b7)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var33
-1
13
Atom holding(b22)
Atom on(b22, b10)
Atom on(b22, b11)
Atom on(b22, b12)
Atom on(b22, b14)
Atom on(b22, b16)
Atom on(b22, b18)
Atom on(b22, b19)
Atom on(b22, b20)
Atom on(b22, b23)
Atom on(b22, b6)
Atom on(b22, b7)
Atom on-table(b22)
end_variable
begin_variable
var37
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var39
-1
17
Atom holding(b27)
Atom on(b27, b1)
Atom on(b27, b10)
Atom on(b27, b11)
Atom on(b27, b12)
Atom on(b27, b14)
Atom on(b27, b16)
Atom on(b27, b17)
Atom on(b27, b18)
Atom on(b27, b19)
Atom on(b27, b22)
Atom on(b27, b23)
Atom on(b27, b24)
Atom on(b27, b28)
Atom on(b27, b6)
Atom on(b27, b7)
Atom on-table(b27)
end_variable
begin_variable
var43
-1
17
Atom holding(b26)
Atom on(b26, b1)
Atom on(b26, b10)
Atom on(b26, b12)
Atom on(b26, b16)
Atom on(b26, b18)
Atom on(b26, b19)
Atom on(b26, b20)
Atom on(b26, b21)
Atom on(b26, b23)
Atom on(b26, b24)
Atom on(b26, b27)
Atom on(b26, b28)
Atom on(b26, b3)
Atom on(b26, b6)
Atom on(b26, b7)
Atom on-table(b26)
end_variable
begin_variable
var47
-1
17
Atom holding(b28)
Atom on(b28, b1)
Atom on(b28, b10)
Atom on(b28, b12)
Atom on(b28, b16)
Atom on(b28, b17)
Atom on(b28, b18)
Atom on(b28, b19)
Atom on(b28, b20)
Atom on(b28, b21)
Atom on(b28, b22)
Atom on(b28, b24)
Atom on(b28, b26)
Atom on(b28, b27)
Atom on(b28, b4)
Atom on(b28, b6)
Atom on-table(b28)
end_variable
begin_variable
var41
-1
19
Atom holding(b16)
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b14)
Atom on(b16, b17)
Atom on(b16, b19)
Atom on(b16, b20)
Atom on(b16, b21)
Atom on(b16, b22)
Atom on(b16, b23)
Atom on(b16, b24)
Atom on(b16, b27)
Atom on(b16, b28)
Atom on(b16, b3)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on-table(b16)
end_variable
begin_variable
var44
-1
20
Atom holding(b6)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b16)
Atom on(b6, b19)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b22)
Atom on(b6, b23)
Atom on(b6, b25)
Atom on(b6, b26)
Atom on(b6, b27)
Atom on(b6, b28)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
end_variable
begin_variable
var42
-1
21
Atom holding(b19)
Atom on(b19, b1)
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b12)
Atom on(b19, b13)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b18)
Atom on(b19, b20)
Atom on(b19, b21)
Atom on(b19, b22)
Atom on(b19, b23)
Atom on(b19, b24)
Atom on(b19, b25)
Atom on(b19, b26)
Atom on(b19, b3)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
end_variable
begin_variable
var46
-1
21
Atom holding(b14)
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b12)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b19)
Atom on(b14, b20)
Atom on(b14, b22)
Atom on(b14, b23)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b26)
Atom on(b14, b27)
Atom on(b14, b28)
Atom on(b14, b3)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on-table(b14)
end_variable
begin_variable
var38
-1
23
Atom holding(b24)
Atom on(b24, b1)
Atom on(b24, b10)
Atom on(b24, b11)
Atom on(b24, b12)
Atom on(b24, b13)
Atom on(b24, b14)
Atom on(b24, b17)
Atom on(b24, b18)
Atom on(b24, b19)
Atom on(b24, b21)
Atom on(b24, b22)
Atom on(b24, b23)
Atom on(b24, b26)
Atom on(b24, b27)
Atom on(b24, b28)
Atom on(b24, b3)
Atom on(b24, b4)
Atom on(b24, b6)
Atom on(b24, b7)
Atom on(b24, b8)
Atom on(b24, b9)
Atom on-table(b24)
end_variable
begin_variable
var45
-1
24
Atom holding(b3)
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b12)
Atom on(b3, b13)
Atom on(b3, b14)
Atom on(b3, b16)
Atom on(b3, b17)
Atom on(b3, b18)
Atom on(b3, b19)
Atom on(b3, b20)
Atom on(b3, b21)
Atom on(b3, b22)
Atom on(b3, b23)
Atom on(b3, b24)
Atom on(b3, b25)
Atom on(b3, b26)
Atom on(b3, b27)
Atom on(b3, b4)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on(b3, b8)
Atom on(b3, b9)
Atom on-table(b3)
end_variable
begin_variable
var48
-1
25
Atom holding(b1)
Atom on(b1, b10)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b16)
Atom on(b1, b17)
Atom on(b1, b18)
Atom on(b1, b19)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b22)
Atom on(b1, b23)
Atom on(b1, b24)
Atom on(b1, b25)
Atom on(b1, b26)
Atom on(b1, b27)
Atom on(b1, b28)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b6)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
end_variable
begin_variable
var50
-1
4
Atom clear(b28)
Atom on(b11, b28)
Atom on(b13, b28)
<none of those>
end_variable
begin_variable
var53
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var51
-1
4
Atom clear(b3)
Atom on(b2, b3)
Atom on(b25, b3)
<none of those>
end_variable
begin_variable
var52
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var55
-1
2
Atom on-table(b13)
NegatedAtom on-table(b13)
end_variable
begin_variable
var54
-1
2
Atom on-table(b25)
NegatedAtom on-table(b25)
end_variable
2913
begin_mutex_group
28
23 0
23 1
23 2
23 3
23 4
23 5
23 6
23 7
23 8
23 9
23 10
23 11
49 0
36 0
37 0
46 0
43 0
29 0
45 0
35 0
30 0
38 0
47 0
41 0
40 0
42 0
48 0
44 0
end_mutex_group
begin_mutex_group
9
21 0
49 0
46 1
43 1
45 1
47 1
41 1
40 1
42 1
end_mutex_group
begin_mutex_group
14
14 0
49 1
36 0
37 1
46 2
43 2
45 2
35 1
38 1
47 2
41 2
40 2
42 2
48 1
end_mutex_group
begin_mutex_group
12
23 1
8 0
37 2
46 3
43 3
45 3
38 2
47 3
40 3
48 2
26 0
34 0
end_mutex_group
begin_mutex_group
15
51 0
49 2
36 1
37 0
46 4
43 4
45 4
35 2
38 3
47 4
41 3
40 4
42 3
48 3
44 1
end_mutex_group
begin_mutex_group
8
23 2
39 0
49 3
29 1
45 5
47 5
48 4
44 2
end_mutex_group
begin_mutex_group
10
19 0
49 4
37 3
46 0
43 5
38 4
47 6
40 5
48 5
44 3
end_mutex_group
begin_mutex_group
3
23 3
33 0
25 0
end_mutex_group
begin_mutex_group
11
18 0
49 5
46 5
43 0
45 6
38 5
41 4
40 6
42 4
48 6
44 4
end_mutex_group
begin_mutex_group
10
23 4
7 0
49 6
46 6
43 6
45 7
47 7
40 7
42 5
48 7
end_mutex_group
begin_mutex_group
13
10 0
49 7
36 2
37 4
46 7
29 0
45 8
38 6
47 8
41 5
40 8
42 6
48 8
end_mutex_group
begin_mutex_group
14
22 0
49 8
36 3
46 8
43 7
45 0
35 3
38 7
47 9
41 6
40 9
42 7
48 9
44 5
end_mutex_group
begin_mutex_group
2
23 5
32 0
end_mutex_group
begin_mutex_group
12
13 0
49 9
36 4
46 9
43 8
45 9
35 0
38 8
41 7
42 8
48 10
44 6
end_mutex_group
begin_mutex_group
13
9 0
49 10
36 5
43 9
45 10
35 4
30 0
47 10
41 8
42 9
48 11
44 7
26 1
end_mutex_group
begin_mutex_group
14
15 0
49 11
36 6
46 10
43 10
29 2
45 11
30 1
38 0
47 11
40 10
42 10
48 12
44 8
end_mutex_group
begin_mutex_group
15
23 6
12 0
49 12
37 5
46 11
43 11
45 12
35 5
38 9
47 12
41 9
40 11
48 13
44 9
27 0
end_mutex_group
begin_mutex_group
11
20 0
49 13
37 6
46 12
43 12
45 13
47 0
41 10
40 12
42 11
48 14
end_mutex_group
begin_mutex_group
8
23 7
4 0
49 14
46 13
45 14
30 2
48 15
44 10
end_mutex_group
begin_mutex_group
10
16 0
49 15
46 14
45 15
35 6
47 13
41 0
42 12
48 16
44 11
end_mutex_group
begin_mutex_group
11
17 0
49 16
46 15
43 13
47 14
41 11
40 0
42 13
48 17
44 12
24 0
end_mutex_group
begin_mutex_group
12
50 0
50 1
50 2
49 17
37 7
46 16
43 14
47 15
41 12
40 13
42 0
44 13
end_mutex_group
begin_mutex_group
12
52 0
52 1
52 2
49 18
37 8
46 17
43 15
45 16
47 16
41 13
48 0
44 14
end_mutex_group
begin_mutex_group
8
23 8
5 0
49 19
47 17
42 14
48 18
44 15
34 1
end_mutex_group
begin_mutex_group
3
23 9
2 0
36 7
end_mutex_group
begin_mutex_group
14
53 0
49 20
36 8
46 18
43 16
45 17
35 7
38 10
47 18
41 14
40 14
42 15
48 19
44 0
end_mutex_group
begin_mutex_group
17
23 10
11 0
49 21
37 9
46 19
43 17
45 18
35 8
38 11
47 19
41 15
40 15
48 20
44 16
31 0
34 2
28 0
end_mutex_group
begin_mutex_group
8
23 11
3 0
49 22
36 9
47 20
48 21
44 17
28 1
end_mutex_group
begin_mutex_group
8
6 0
49 23
37 10
45 19
47 21
48 22
44 18
34 3
end_mutex_group
begin_mutex_group
3
23 1
50 1
1 0
end_mutex_group
begin_mutex_group
3
23 2
50 2
54 0
end_mutex_group
begin_mutex_group
3
23 3
31 0
31 1
end_mutex_group
begin_mutex_group
4
23 4
26 0
26 1
26 2
end_mutex_group
begin_mutex_group
3
23 5
52 1
0 0
end_mutex_group
begin_mutex_group
6
23 6
34 0
34 1
34 2
34 3
34 4
end_mutex_group
begin_mutex_group
3
23 7
52 2
55 0
end_mutex_group
begin_mutex_group
3
23 8
24 0
24 1
end_mutex_group
begin_mutex_group
4
23 9
28 0
28 1
28 2
end_mutex_group
begin_mutex_group
3
23 10
27 0
27 1
end_mutex_group
begin_mutex_group
3
23 11
25 0
25 1
end_mutex_group
begin_mutex_group
2
1 1
26 0
end_mutex_group
begin_mutex_group
2
1 1
47 7
end_mutex_group
begin_mutex_group
2
1 1
41 1
end_mutex_group
begin_mutex_group
2
1 1
44 6
end_mutex_group
begin_mutex_group
2
1 1
49 13
end_mutex_group
begin_mutex_group
2
2 0
28 3
end_mutex_group
begin_mutex_group
2
4 0
23 2
end_mutex_group
begin_mutex_group
2
4 0
23 8
end_mutex_group
begin_mutex_group
2
4 0
24 0
end_mutex_group
begin_mutex_group
2
4 0
24 2
end_mutex_group
begin_mutex_group
2
4 0
29 1
end_mutex_group
begin_mutex_group
2
4 0
40 5
end_mutex_group
begin_mutex_group
2
4 0
45 8
end_mutex_group
begin_mutex_group
2
4 0
42 14
end_mutex_group
begin_mutex_group
2
4 0
50 2
end_mutex_group
begin_mutex_group
2
3 0
25 2
end_mutex_group
begin_mutex_group
2
3 0
37 1
end_mutex_group
begin_mutex_group
2
5 0
23 2
end_mutex_group
begin_mutex_group
2
5 0
24 2
end_mutex_group
begin_mutex_group
2
5 0
29 1
end_mutex_group
begin_mutex_group
2
5 0
45 8
end_mutex_group
begin_mutex_group
2
5 0
50 2
end_mutex_group
begin_mutex_group
2
6 0
23 2
end_mutex_group
begin_mutex_group
2
6 0
23 7
end_mutex_group
begin_mutex_group
2
6 0
23 8
end_mutex_group
begin_mutex_group
2
6 0
24 0
end_mutex_group
begin_mutex_group
2
6 0
24 2
end_mutex_group
begin_mutex_group
2
6 0
29 1
end_mutex_group
begin_mutex_group
2
6 0
40 5
end_mutex_group
begin_mutex_group
2
6 0
45 8
end_mutex_group
begin_mutex_group
2
6 0
46 13
end_mutex_group
begin_mutex_group
2
6 0
42 14
end_mutex_group
begin_mutex_group
2
6 0
50 2
end_mutex_group
begin_mutex_group
2
6 0
52 2
end_mutex_group
begin_mutex_group
2
7 0
26 3
end_mutex_group
begin_mutex_group
2
7 0
41 1
end_mutex_group
begin_mutex_group
2
7 0
44 6
end_mutex_group
begin_mutex_group
2
7 0
49 13
end_mutex_group
begin_mutex_group
2
8 0
47 7
end_mutex_group
begin_mutex_group
2
8 0
41 1
end_mutex_group
begin_mutex_group
2
8 0
44 6
end_mutex_group
begin_mutex_group
2
8 0
49 13
end_mutex_group
begin_mutex_group
2
11 0
27 2
end_mutex_group
begin_mutex_group
2
12 0
34 5
end_mutex_group
begin_mutex_group
2
12 0
38 5
end_mutex_group
begin_mutex_group
2
12 0
30 1
end_mutex_group
begin_mutex_group
2
16 0
44 6
end_mutex_group
begin_mutex_group
2
17 0
23 2
end_mutex_group
begin_mutex_group
2
17 0
29 1
end_mutex_group
begin_mutex_group
2
17 0
45 8
end_mutex_group
begin_mutex_group
2
17 0
42 14
end_mutex_group
begin_mutex_group
2
17 0
50 2
end_mutex_group
begin_mutex_group
2
17 1
23 8
end_mutex_group
begin_mutex_group
2
17 1
24 2
end_mutex_group
begin_mutex_group
2
18 0
30 1
end_mutex_group
begin_mutex_group
2
19 0
23 2
end_mutex_group
begin_mutex_group
2
19 0
23 8
end_mutex_group
begin_mutex_group
2
19 0
24 0
end_mutex_group
begin_mutex_group
2
19 0
24 2
end_mutex_group
begin_mutex_group
2
19 0
29 1
end_mutex_group
begin_mutex_group
2
19 0
45 8
end_mutex_group
begin_mutex_group
2
19 0
42 14
end_mutex_group
begin_mutex_group
2
19 0
50 2
end_mutex_group
begin_mutex_group
2
20 0
41 1
end_mutex_group
begin_mutex_group
2
20 0
44 6
end_mutex_group
begin_mutex_group
2
21 0
44 6
end_mutex_group
begin_mutex_group
2
23 0
24 2
end_mutex_group
begin_mutex_group
2
23 0
25 2
end_mutex_group
begin_mutex_group
2
23 0
26 3
end_mutex_group
begin_mutex_group
2
23 0
27 2
end_mutex_group
begin_mutex_group
2
23 0
31 2
end_mutex_group
begin_mutex_group
2
23 0
34 5
end_mutex_group
begin_mutex_group
2
23 0
28 3
end_mutex_group
begin_mutex_group
2
23 1
24 2
end_mutex_group
begin_mutex_group
2
23 1
25 2
end_mutex_group
begin_mutex_group
2
23 1
26 3
end_mutex_group
begin_mutex_group
2
23 1
27 2
end_mutex_group
begin_mutex_group
2
23 1
31 2
end_mutex_group
begin_mutex_group
2
23 1
34 5
end_mutex_group
begin_mutex_group
2
23 1
28 3
end_mutex_group
begin_mutex_group
2
23 1
47 7
end_mutex_group
begin_mutex_group
2
23 1
41 1
end_mutex_group
begin_mutex_group
2
23 1
44 6
end_mutex_group
begin_mutex_group
2
23 1
49 13
end_mutex_group
begin_mutex_group
2
23 2
24 1
end_mutex_group
begin_mutex_group
2
23 2
24 2
end_mutex_group
begin_mutex_group
2
23 2
25 2
end_mutex_group
begin_mutex_group
2
23 2
26 3
end_mutex_group
begin_mutex_group
2
23 2
27 2
end_mutex_group
begin_mutex_group
2
23 2
31 2
end_mutex_group
begin_mutex_group
2
23 2
34 1
end_mutex_group
begin_mutex_group
2
23 2
34 3
end_mutex_group
begin_mutex_group
2
23 2
34 5
end_mutex_group
begin_mutex_group
2
23 2
28 3
end_mutex_group
begin_mutex_group
2
23 2
38 4
end_mutex_group
begin_mutex_group
2
23 2
47 6
end_mutex_group
begin_mutex_group
2
23 2
47 14
end_mutex_group
begin_mutex_group
2
23 2
47 15
end_mutex_group
begin_mutex_group
2
23 2
47 16
end_mutex_group
begin_mutex_group
2
23 2
47 17
end_mutex_group
begin_mutex_group
2
23 2
47 21
end_mutex_group
begin_mutex_group
2
23 2
40 1
end_mutex_group
begin_mutex_group
2
23 2
40 2
end_mutex_group
begin_mutex_group
2
23 2
40 3
end_mutex_group
begin_mutex_group
2
23 2
40 4
end_mutex_group
begin_mutex_group
2
23 2
40 6
end_mutex_group
begin_mutex_group
2
23 2
40 7
end_mutex_group
begin_mutex_group
2
23 2
40 8
end_mutex_group
begin_mutex_group
2
23 2
40 9
end_mutex_group
begin_mutex_group
2
23 2
40 10
end_mutex_group
begin_mutex_group
2
23 2
40 11
end_mutex_group
begin_mutex_group
2
23 2
40 12
end_mutex_group
begin_mutex_group
2
23 2
40 13
end_mutex_group
begin_mutex_group
2
23 2
40 14
end_mutex_group
begin_mutex_group
2
23 2
40 15
end_mutex_group
begin_mutex_group
2
23 2
40 16
end_mutex_group
begin_mutex_group
2
23 2
37 3
end_mutex_group
begin_mutex_group
2
23 2
37 7
end_mutex_group
begin_mutex_group
2
23 2
37 8
end_mutex_group
begin_mutex_group
2
23 2
37 10
end_mutex_group
begin_mutex_group
2
23 2
43 5
end_mutex_group
begin_mutex_group
2
23 2
43 13
end_mutex_group
begin_mutex_group
2
23 2
43 14
end_mutex_group
begin_mutex_group
2
23 2
43 15
end_mutex_group
begin_mutex_group
2
23 2
45 8
end_mutex_group
begin_mutex_group
2
23 2
45 14
end_mutex_group
begin_mutex_group
2
23 2
45 16
end_mutex_group
begin_mutex_group
2
23 2
45 19
end_mutex_group
begin_mutex_group
2
23 2
41 11
end_mutex_group
begin_mutex_group
2
23 2
41 12
end_mutex_group
begin_mutex_group
2
23 2
41 13
end_mutex_group
begin_mutex_group
2
23 2
44 3
end_mutex_group
begin_mutex_group
2
23 2
44 10
end_mutex_group
begin_mutex_group
2
23 2
44 12
end_mutex_group
begin_mutex_group
2
23 2
44 13
end_mutex_group
begin_mutex_group
2
23 2
44 14
end_mutex_group
begin_mutex_group
2
23 2
44 15
end_mutex_group
begin_mutex_group
2
23 2
44 18
end_mutex_group
begin_mutex_group
2
23 2
48 1
end_mutex_group
begin_mutex_group
2
23 2
48 2
end_mutex_group
begin_mutex_group
2
23 2
48 3
end_mutex_group
begin_mutex_group
2
23 2
48 5
end_mutex_group
begin_mutex_group
2
23 2
48 6
end_mutex_group
begin_mutex_group
2
23 2
48 7
end_mutex_group
begin_mutex_group
2
23 2
48 8
end_mutex_group
begin_mutex_group
2
23 2
48 9
end_mutex_group
begin_mutex_group
2
23 2
48 10
end_mutex_group
begin_mutex_group
2
23 2
48 11
end_mutex_group
begin_mutex_group
2
23 2
48 12
end_mutex_group
begin_mutex_group
2
23 2
48 13
end_mutex_group
begin_mutex_group
2
23 2
48 14
end_mutex_group
begin_mutex_group
2
23 2
48 15
end_mutex_group
begin_mutex_group
2
23 2
48 16
end_mutex_group
begin_mutex_group
2
23 2
48 17
end_mutex_group
begin_mutex_group
2
23 2
48 18
end_mutex_group
begin_mutex_group
2
23 2
48 19
end_mutex_group
begin_mutex_group
2
23 2
48 20
end_mutex_group
begin_mutex_group
2
23 2
48 21
end_mutex_group
begin_mutex_group
2
23 2
48 23
end_mutex_group
begin_mutex_group
2
23 2
46 1
end_mutex_group
begin_mutex_group
2
23 2
46 2
end_mutex_group
begin_mutex_group
2
23 2
46 3
end_mutex_group
begin_mutex_group
2
23 2
46 4
end_mutex_group
begin_mutex_group
2
23 2
46 5
end_mutex_group
begin_mutex_group
2
23 2
46 6
end_mutex_group
begin_mutex_group
2
23 2
46 7
end_mutex_group
begin_mutex_group
2
23 2
46 8
end_mutex_group
begin_mutex_group
2
23 2
46 9
end_mutex_group
begin_mutex_group
2
23 2
46 10
end_mutex_group
begin_mutex_group
2
23 2
46 11
end_mutex_group
begin_mutex_group
2
23 2
46 12
end_mutex_group
begin_mutex_group
2
23 2
46 14
end_mutex_group
begin_mutex_group
2
23 2
46 15
end_mutex_group
begin_mutex_group
2
23 2
46 16
end_mutex_group
begin_mutex_group
2
23 2
46 17
end_mutex_group
begin_mutex_group
2
23 2
46 18
end_mutex_group
begin_mutex_group
2
23 2
46 19
end_mutex_group
begin_mutex_group
2
23 2
46 20
end_mutex_group
begin_mutex_group
2
23 2
42 1
end_mutex_group
begin_mutex_group
2
23 2
42 2
end_mutex_group
begin_mutex_group
2
23 2
42 3
end_mutex_group
begin_mutex_group
2
23 2
42 4
end_mutex_group
begin_mutex_group
2
23 2
42 5
end_mutex_group
begin_mutex_group
2
23 2
42 6
end_mutex_group
begin_mutex_group
2
23 2
42 7
end_mutex_group
begin_mutex_group
2
23 2
42 8
end_mutex_group
begin_mutex_group
2
23 2
42 9
end_mutex_group
begin_mutex_group
2
23 2
42 10
end_mutex_group
begin_mutex_group
2
23 2
42 11
end_mutex_group
begin_mutex_group
2
23 2
42 12
end_mutex_group
begin_mutex_group
2
23 2
42 13
end_mutex_group
begin_mutex_group
2
23 2
42 15
end_mutex_group
begin_mutex_group
2
23 2
42 16
end_mutex_group
begin_mutex_group
2
23 2
49 4
end_mutex_group
begin_mutex_group
2
23 2
49 14
end_mutex_group
begin_mutex_group
2
23 2
49 16
end_mutex_group
begin_mutex_group
2
23 2
49 17
end_mutex_group
begin_mutex_group
2
23 2
49 18
end_mutex_group
begin_mutex_group
2
23 2
49 19
end_mutex_group
begin_mutex_group
2
23 2
49 23
end_mutex_group
begin_mutex_group
2
23 2
30 2
end_mutex_group
begin_mutex_group
2
23 2
50 1
end_mutex_group
begin_mutex_group
2
23 2
50 3
end_mutex_group
begin_mutex_group
2
23 2
52 0
end_mutex_group
begin_mutex_group
2
23 2
52 1
end_mutex_group
begin_mutex_group
2
23 2
52 3
end_mutex_group
begin_mutex_group
2
23 2
55 0
end_mutex_group
begin_mutex_group
2
23 3
24 2
end_mutex_group
begin_mutex_group
2
23 3
25 2
end_mutex_group
begin_mutex_group
2
23 3
26 3
end_mutex_group
begin_mutex_group
2
23 3
27 2
end_mutex_group
begin_mutex_group
2
23 3
34 5
end_mutex_group
begin_mutex_group
2
23 3
28 3
end_mutex_group
begin_mutex_group
2
23 3
36 9
end_mutex_group
begin_mutex_group
2
23 3
37 1
end_mutex_group
begin_mutex_group
2
23 4
24 2
end_mutex_group
begin_mutex_group
2
23 4
25 2
end_mutex_group
begin_mutex_group
2
23 4
27 2
end_mutex_group
begin_mutex_group
2
23 4
31 2
end_mutex_group
begin_mutex_group
2
23 4
34 5
end_mutex_group
begin_mutex_group
2
23 4
28 3
end_mutex_group
begin_mutex_group
2
23 4
41 1
end_mutex_group
begin_mutex_group
2
23 4
44 6
end_mutex_group
begin_mutex_group
2
23 4
49 13
end_mutex_group
begin_mutex_group
2
23 5
24 2
end_mutex_group
begin_mutex_group
2
23 5
25 2
end_mutex_group
begin_mutex_group
2
23 5
26 3
end_mutex_group
begin_mutex_group
2
23 5
27 2
end_mutex_group
begin_mutex_group
2
23 5
31 2
end_mutex_group
begin_mutex_group
2
23 5
34 5
end_mutex_group
begin_mutex_group
2
23 5
28 3
end_mutex_group
begin_mutex_group
2
23 6
24 2
end_mutex_group
begin_mutex_group
2
23 6
25 2
end_mutex_group
begin_mutex_group
2
23 6
26 3
end_mutex_group
begin_mutex_group
2
23 6
27 2
end_mutex_group
begin_mutex_group
2
23 6
31 2
end_mutex_group
begin_mutex_group
2
23 6
28 3
end_mutex_group
begin_mutex_group
2
23 6
38 5
end_mutex_group
begin_mutex_group
2
23 6
30 1
end_mutex_group
begin_mutex_group
2
23 7
24 0
end_mutex_group
begin_mutex_group
2
23 7
24 2
end_mutex_group
begin_mutex_group
2
23 7
25 2
end_mutex_group
begin_mutex_group
2
23 7
26 3
end_mutex_group
begin_mutex_group
2
23 7
27 2
end_mutex_group
begin_mutex_group
2
23 7
31 2
end_mutex_group
begin_mutex_group
2
23 7
34 3
end_mutex_group
begin_mutex_group
2
23 7
34 5
end_mutex_group
begin_mutex_group
2
23 7
28 3
end_mutex_group
begin_mutex_group
2
23 7
29 1
end_mutex_group
begin_mutex_group
2
23 7
47 16
end_mutex_group
begin_mutex_group
2
23 7
47 21
end_mutex_group
begin_mutex_group
2
23 7
40 5
end_mutex_group
begin_mutex_group
2
23 7
37 8
end_mutex_group
begin_mutex_group
2
23 7
37 10
end_mutex_group
begin_mutex_group
2
23 7
43 15
end_mutex_group
begin_mutex_group
2
23 7
45 8
end_mutex_group
begin_mutex_group
2
23 7
45 16
end_mutex_group
begin_mutex_group
2
23 7
45 19
end_mutex_group
begin_mutex_group
2
23 7
41 13
end_mutex_group
begin_mutex_group
2
23 7
44 14
end_mutex_group
begin_mutex_group
2
23 7
44 18
end_mutex_group
begin_mutex_group
2
23 7
48 1
end_mutex_group
begin_mutex_group
2
23 7
48 2
end_mutex_group
begin_mutex_group
2
23 7
48 3
end_mutex_group
begin_mutex_group
2
23 7
48 4
end_mutex_group
begin_mutex_group
2
23 7
48 5
end_mutex_group
begin_mutex_group
2
23 7
48 6
end_mutex_group
begin_mutex_group
2
23 7
48 7
end_mutex_group
begin_mutex_group
2
23 7
48 8
end_mutex_group
begin_mutex_group
2
23 7
48 9
end_mutex_group
begin_mutex_group
2
23 7
48 10
end_mutex_group
begin_mutex_group
2
23 7
48 11
end_mutex_group
begin_mutex_group
2
23 7
48 12
end_mutex_group
begin_mutex_group
2
23 7
48 13
end_mutex_group
begin_mutex_group
2
23 7
48 14
end_mutex_group
begin_mutex_group
2
23 7
48 16
end_mutex_group
begin_mutex_group
2
23 7
48 17
end_mutex_group
begin_mutex_group
2
23 7
48 18
end_mutex_group
begin_mutex_group
2
23 7
48 19
end_mutex_group
begin_mutex_group
2
23 7
48 20
end_mutex_group
begin_mutex_group
2
23 7
48 21
end_mutex_group
begin_mutex_group
2
23 7
48 23
end_mutex_group
begin_mutex_group
2
23 7
46 17
end_mutex_group
begin_mutex_group
2
23 7
42 14
end_mutex_group
begin_mutex_group
2
23 7
49 18
end_mutex_group
begin_mutex_group
2
23 7
49 23
end_mutex_group
begin_mutex_group
2
23 7
50 2
end_mutex_group
begin_mutex_group
2
23 7
52 1
end_mutex_group
begin_mutex_group
2
23 7
52 3
end_mutex_group
begin_mutex_group
2
23 8
25 2
end_mutex_group
begin_mutex_group
2
23 8
26 3
end_mutex_group
begin_mutex_group
2
23 8
27 2





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 40 0 11
1
end_operator
begin_operator
stack b27 b24
0
4
0 23 -1 0
0 20 0 1
0 17 -1 0
0 40 0 12
1
end_operator
begin_operator
stack b27 b28
0
4
0 23 -1 0
0 17 -1 0
0 50 0 3
0 40 0 13
1
end_operator
begin_operator
stack b27 b6
0
4
0 23 -1 0
0 17 -1 0
0 53 0 1
0 40 0 14
1
end_operator
begin_operator
stack b27 b7
0
4
0 23 -1 0
0 17 -1 0
0 11 0 1
0 40 0 15
1
end_operator
begin_operator
stack b28 b1
0
4
0 23 -1 0
0 21 0 1
0 50 -1 0
0 42 0 1
1
end_operator
begin_operator
stack b28 b10
0
4
0 23 -1 0
0 14 0 1
0 50 -1 0
0 42 0 2
1
end_operator
begin_operator
stack b28 b12
0
4
0 23 -1 0
0 51 0 1
0 50 -1 0
0 42 0 3
1
end_operator
begin_operator
stack b28 b16
0
4
0 23 -1 0
0 18 0 1
0 50 -1 0
0 42 0 4
1
end_operator
begin_operator
stack b28 b17
0
4
0 23 -1 0
0 7 0 1
0 50 -1 0
0 42 0 5
1
end_operator
begin_operator
stack b28 b18
0
4
0 23 -1 0
0 10 0 1
0 50 -1 0
0 42 0 6
1
end_operator
begin_operator
stack b28 b19
0
4
0 23 -1 0
0 22 0 1
0 50 -1 0
0 42 0 7
1
end_operator
begin_operator
stack b28 b20
0
4
0 23 -1 0
0 13 0 1
0 50 -1 0
0 42 0 8
1
end_operator
begin_operator
stack b28 b21
0
4
0 23 -1 0
0 9 0 1
0 50 -1 0
0 42 0 9
1
end_operator
begin_operator
stack b28 b22
0
4
0 23 -1 0
0 15 0 1
0 50 -1 0
0 42 0 10
1
end_operator
begin_operator
stack b28 b24
0
4
0 23 -1 0
0 20 0 1
0 50 -1 0
0 42 0 11
1
end_operator
begin_operator
stack b28 b26
0
4
0 23 -1 0
0 16 0 1
0 50 -1 0
0 42 0 12
1
end_operator
begin_operator
stack b28 b27
0
4
0 23 -1 0
0 17 0 1
0 50 -1 0
0 42 0 13
1
end_operator
begin_operator
stack b28 b6
0
4
0 23 -1 0
0 50 -1 0
0 53 0 1
0 42 0 15
1
end_operator
begin_operator
stack b3 b10
0
4
0 23 -1 0
0 14 0 1
0 52 -1 0
0 48 0 1
1
end_operator
begin_operator
stack b3 b11
0
4
0 23 -1 0
0 8 0 1
0 52 -1 0
0 48 0 2
1
end_operator
begin_operator
stack b3 b12
0
4
0 23 -1 0
0 51 0 1
0 52 -1 0
0 48 0 3
1
end_operator
begin_operator
stack b3 b13
0
4
0 23 -1 0
0 39 0 1
0 52 -1 0
0 48 0 4
1
end_operator
begin_operator
stack b3 b14
0
4
0 23 -1 0
0 19 0 1
0 52 -1 0
0 48 0 5
1
end_operator
begin_operator
stack b3 b16
0
4
0 23 -1 0
0 18 0 1
0 52 -1 0
0 48 0 6
1
end_operator
begin_operator
stack b3 b17
0
4
0 23 -1 0
0 7 0 1
0 52 -1 0
0 48 0 7
1
end_operator
begin_operator
stack b3 b18
0
4
0 23 -1 0
0 10 0 1
0 52 -1 0
0 48 0 8
1
end_operator
begin_operator
stack b3 b19
0
4
0 23 -1 0
0 22 0 1
0 52 -1 0
0 48 0 9
1
end_operator
begin_operator
stack b3 b20
0
4
0 23 -1 0
0 13 0 1
0 52 -1 0
0 48 0 10
1
end_operator
begin_operator
stack b3 b21
0
4
0 23 -1 0
0 9 0 1
0 52 -1 0
0 48 0 11
1
end_operator
begin_operator
stack b3 b22
0
4
0 23 -1 0
0 15 0 1
0 52 -1 0
0 48 0 12
1
end_operator
begin_operator
stack b3 b23
0
4
0 23 -1 0
0 12 0 1
0 52 -1 0
0 48 0 13
1
end_operator
begin_operator
stack b3 b24
0
4
0 23 -1 0
0 20 0 1
0 52 -1 0
0 48 0 14
1
end_operator
begin_operator
stack b3 b25
0
4
0 23 -1 0
0 4 0 1
0 52 -1 0
0 48 0 15
1
end_operator
begin_operator
stack b3 b26
0
4
0 23 -1 0
0 16 0 1
0 52 -1 0
0 48 0 16
1
end_operator
begin_operator
stack b3 b27
0
4
0 23 -1 0
0 17 0 1
0 52 -1 0
0 48 0 17
1
end_operator
begin_operator
stack b3 b4
0
4
0 23 -1 0
0 52 -1 0
0 5 0 1
0 48 0 18
1
end_operator
begin_operator
stack b3 b6
0
4
0 23 -1 0
0 52 -1 0
0 53 0 1
0 48 0 19
1
end_operator
begin_operator
stack b3 b7
0
4
0 23 -1 0
0 52 -1 0
0 11 0 1
0 48 0 20
1
end_operator
begin_operator
stack b3 b8
0
4
0 23 -1 0
0 52 -1 0
0 3 0 1
0 48 0 21
1
end_operator
begin_operator
stack b5 b8
0
4
0 23 9 0
0 2 -1 0
0 3 0 1
0 28 -1 1
1
end_operator
begin_operator
stack b6 b12
0
4
0 23 -1 0
0 51 0 1
0 53 -1 0
0 44 0 1
1
end_operator
begin_operator
stack b6 b13
0
4
0 23 -1 0
0 39 0 1
0 53 -1 0
0 44 0 2
1
end_operator
begin_operator
stack b6 b14
0
4
0 23 -1 0
0 19 0 1
0 53 -1 0
0 44 0 3
1
end_operator
begin_operator
stack b6 b16
0
4
0 23 -1 0
0 18 0 1
0 53 -1 0
0 44 0 4
1
end_operator
begin_operator
stack b6 b19
0
4
0 23 -1 0
0 22 0 1
0 53 -1 0
0 44 0 5
1
end_operator
begin_operator
stack b6 b21
0
4
0 23 -1 0
0 9 0 1
0 53 -1 0
0 44 0 7
1
end_operator
begin_operator
stack b6 b22
0
4
0 23 -1 0
0 15 0 1
0 53 -1 0
0 44 0 8
1
end_operator
begin_operator
stack b6 b23
0
4
0 23 -1 0
0 12 0 1
0 53 -1 0
0 44 0 9
1
end_operator
begin_operator
stack b6 b25
0
4
0 23 -1 0
0 4 0 1
0 53 -1 0
0 44 0 10
1
end_operator
begin_operator
stack b6 b26
0
4
0 23 -1 0
0 16 0 1
0 53 -1 0
0 44 0 11
1
end_operator
begin_operator
stack b6 b27
0
4
0 23 -1 0
0 17 0 1
0 53 -1 0
0 44 0 12
1
end_operator
begin_operator
stack b6 b28
0
4
0 23 -1 0
0 50 0 3
0 53 -1 0
0 44 0 13
1
end_operator
begin_operator
stack b6 b3
0
4
0 23 -1 0
0 52 0 3
0 53 -1 0
0 44 0 14
1
end_operator
begin_operator
stack b6 b4
0
4
0 23 -1 0
0 5 0 1
0 53 -1 0
0 44 0 15
1
end_operator
begin_operator
stack b6 b7
0
4
0 23 -1 0
0 53 -1 0
0 11 0 1
0 44 0 16
1
end_operator
begin_operator
stack b6 b8
0
4
0 23 -1 0
0 53 -1 0
0 3 0 1
0 44 0 17
1
end_operator
begin_operator
stack b6 b9
0
4
0 23 -1 0
0 53 -1 0
0 6 0 1
0 44 0 18
1
end_operator
begin_operator
stack b7 b23
0
4
0 23 10 0
0 12 0 1
0 11 -1 0
0 27 -1 0
1
end_operator
begin_operator
unstack b1 b10
0
4
0 23 0 12
0 21 0 1
0 14 -1 0
0 49 1 0
1
end_operator
begin_operator
unstack b1 b12
0
4
0 23 0 12
0 21 0 1
0 51 -1 0
0 49 2 0
1
end_operator
begin_operator
unstack b1 b13
0
4
0 23 0 12
0 21 0 1
0 39 -1 0
0 49 3 0
1
end_operator
begin_operator
unstack b1 b14
0
4
0 23 0 12
0 21 0 1
0 19 -1 0
0 49 4 0
1
end_operator
begin_operator
unstack b1 b16
0
4
0 23 0 12
0 21 0 1
0 18 -1 0
0 49 5 0
1
end_operator
begin_operator
unstack b1 b17
0
4
0 23 0 12
0 21 0 1
0 7 -1 0
0 49 6 0
1
end_operator
begin_operator
unstack b1 b18
0
4
0 23 0 12
0 21 0 1
0 10 -1 0
0 49 7 0
1
end_operator
begin_operator
unstack b1 b19
0
4
0 23 0 12
0 21 0 1
0 22 -1 0
0 49 8 0
1
end_operator
begin_operator
unstack b1 b20
0
4
0 23 0 12
0 21 0 1
0 13 -1 0
0 49 9 0
1
end_operator
begin_operator
unstack b1 b21
0
4
0 23 0 12
0 21 0 1
0 9 -1 0
0 49 10 0
1
end_operator
begin_operator
unstack b1 b22
0
4
0 23 0 12
0 21 0 1
0 15 -1 0
0 49 11 0
1
end_operator
begin_operator
unstack b1 b23
0
4
0 23 0 12
0 21 0 1
0 12 -1 0
0 49 12 0
1
end_operator
begin_operator
unstack b1 b24
0
4
0 23 0 12
0 21 0 1
0 20 -1 0
0 49 13 0
1
end_operator
begin_operator
unstack b1 b25
0
4
0 23 0 12
0 21 0 1
0 4 -1 0
0 49 14 0
1
end_operator
begin_operator
unstack b1 b26
0
4
0 23 0 12
0 21 0 1
0 16 -1 0
0 49 15 0
1
end_operator
begin_operator
unstack b1 b27
0
4
0 23 0 12
0 21 0 1
0 17 -1 0
0 49 16 0
1
end_operator
begin_operator
unstack b1 b28
0
4
0 23 0 12
0 21 0 1
0 50 -1 0
0 49 17 0
1
end_operator
begin_operator
unstack b1 b3
0
4
0 23 0 12
0 21 0 1
0 52 -1 0
0 49 18 0
1
end_operator
begin_operator
unstack b1 b4
0
4
0 23 0 12
0 21 0 1
0 5 -1 0
0 49 19 0
1
end_operator
begin_operator
unstack b1 b6
0
4
0 23 0 12
0 21 0 1
0 53 -1 0
0 49 20 0
1
end_operator
begin_operator
unstack b1 b7
0
4
0 23 0 12
0 21 0 1
0 11 -1 0
0 49 21 0
1
end_operator
begin_operator
unstack b1 b8
0
4
0 23 0 12
0 21 0 1
0 3 -1 0
0 49 22 0
1
end_operator
begin_operator
unstack b1 b9
0
4
0 23 0 12
0 21 0 1
0 6 -1 0
0 49 23 0
1
end_operator
begin_operator
unstack b10 b12
0
4
0 23 0 12
0 14 0 1
0 51 -1 0
0 36 1 0
1
end_operator
begin_operator
unstack b10 b18
0
4
0 23 0 12
0 14 0 1
0 10 -1 0
0 36 2 0
1
end_operator
begin_operator
unstack b10 b19
0
4
0 23 0 12
0 14 0 1
0 22 -1 0
0 36 3 0
1
end_operator
begin_operator
unstack b10 b20
0
4
0 23 0 12
0 14 0 1
0 13 -1 0
0 36 4 0
1
end_operator
begin_operator
unstack b10 b21
0
4
0 23 0 12
0 14 0 1
0 9 -1 0
0 36 5 0
1
end_operator
begin_operator
unstack b10 b22
0
4
0 23 0 12
0 14 0 1
0 15 -1 0
0 36 6 0
1
end_operator
begin_operator
unstack b10 b6
0
4
0 23 0 12
0 14 0 1
0 53 -1 0
0 36 8 0
1
end_operator
begin_operator
unstack b10 b8
0
4
0 23 0 12
0 14 0 1
0 3 -1 0
0 36 9 0
1
end_operator
begin_operator
unstack b11 b28
0
3
0 23 0 1
0 8 0 1
0 50 1 0
1
end_operator
begin_operator
unstack b12 b10
0
4
0 23 0 12
0 14 -1 0
0 51 0 1
0 37 1 0
1
end_operator
begin_operator
unstack b12 b11
0
4
0 23 0 12
0 8 -1 0
0 51 0 1
0 37 2 0
1
end_operator
begin_operator
unstack b12 b14
0
4
0 23 0 12
0 51 0 1
0 19 -1 0
0 37 3 0
1
end_operator
begin_operator
unstack b12 b18
0
4
0 23 0 12
0 51 0 1
0 10 -1 0
0 37 4 0
1
end_operator
begin_operator
unstack b12 b23
0
4
0 23 0 12
0 51 0 1
0 12 -1 0
0 37 5 0
1
end_operator
begin_operator
unstack b12 b28
0
4
0 23 0 12
0 51 0 1
0 50 -1 0
0 37 7 0
1
end_operator
begin_operator
unstack b12 b3
0
4
0 23 0 12
0 51 0 1
0 52 -1 0
0 37 8 0
1
end_operator
begin_operator
unstack b12 b7
0
4
0 23 0 12
0 51 0 1
0 11 -1 0
0 37 9 0
1
end_operator
begin_operator
unstack b12 b9
0
4
0 23 0 12
0 51 0 1
0 6 -1 0
0 37 10 0
1
end_operator
begin_operator
unstack b13 b28
0
3
0 23 0 2
0 39 0 1
0 50 2 0
1
end_operator
begin_operator
unstack b14 b1
0
4
0 23 0 12
0 21 -1 0
0 19 0 1
0 46 1 0
1
end_operator
begin_operator
unstack b14 b10
0
4
0 23 0 12
0 14 -1 0
0 19 0 1
0 46 2 0
1
end_operator
begin_operator
unstack b14 b11
0
4
0 23 0 12
0 8 -1 0
0 19 0 1
0 46 3 0
1
end_operator
begin_operator
unstack b14 b12
0
4
0 23 0 12
0 51 -1 0
0 19 0 1
0 46 4 0
1
end_operator
begin_operator
unstack b14 b16
0
4
0 23 0 12
0 19 0 1
0 18 -1 0
0 46 5 0
1
end_operator
begin_operator
unstack b14 b17
0
4
0 23 0 12
0 19 0 1
0 7 -1 0
0 46 6 0
1
end_operator
begin_operator
unstack b14 b18
0
4
0 23 0 12
0 19 0 1
0 10 -1 0
0 46 7 0
1
end_operator
begin_operator
unstack b14 b19
0
4
0 23 0 12
0 19 0 1
0 22 -1 0
0 46 8 0
1
end_operator
begin_operator
unstack b14 b20
0
4
0 23 0 12
0 19 0 1
0 13 -1 0
0 46 9 0
1
end_operator
begin_operator
unstack b14 b22
0
4
0 23 0 12
0 19 0 1
0 15 -1 0
0 46 10 0
1
end_operator
begin_operator
unstack b14 b23
0
4
0 23 0 12
0 19 0 1
0 12 -1 0
0 46 11 0
1
end_operator
begin_operator
unstack b14 b24
0
4
0 23 0 12
0 19 0 1
0 20 -1 0
0 46 12 0
1
end_operator
begin_operator
unstack b14 b25
0
4
0 23 0 12
0 19 0 1
0 4 -1 0
0 46 13 0
1
end_operator
begin_operator
unstack b14 b26
0
4
0 23 0 12
0 19 0 1
0 16 -1 0
0 46 14 0
1
end_operator
begin_operator
unstack b14 b27
0
4
0 23 0 12
0 19 0 1
0 17 -1 0
0 46 15 0
1
end_operator
begin_operator
unstack b14 b28
0
4
0 23 0 12
0 19 0 1
0 50 -1 0
0 46 16 0
1
end_operator
begin_operator
unstack b14 b3
0
4
0 23 0 12
0 19 0 1
0 52 -1 0
0 46 17 0
1
end_operator
begin_operator
unstack b14 b6
0
4
0 23 0 12
0 19 0 1
0 53 -1 0
0 46 18 0
1
end_operator
begin_operator
unstack b14 b7
0
4
0 23 0 12
0 19 0 1
0 11 -1 0
0 46 19 0
1
end_operator
begin_operator
unstack b15 b7
0
4
0 23 0 3
0 33 0 1
0 11 -1 0
0 31 0 2
1
end_operator
begin_operator
unstack b16 b1
0
4
0 23 0 12
0 21 -1 0
0 18 0 1
0 43 1 0
1
end_operator
begin_operator
unstack b16 b10
0
4
0 23 0 12
0 14 -1 0
0 18 0 1
0 43 2 0
1
end_operator
begin_operator
unstack b16 b11
0
4
0 23 0 12
0 8 -1 0
0 18 0 1
0 43 3 0
1
end_operator
begin_operator
unstack b16 b12
0
4
0 23 0 12
0 51 -1 0
0 18 0 1
0 43 4 0
1
end_operator
begin_operator
unstack b16 b14
0
4
0 23 0 12
0 19 -1 0
0 18 0 1
0 43 5 0
1
end_operator
begin_operator
unstack b16 b17
0
4
0 23 0 12
0 18 0 1
0 7 -1 0
0 43 6 0
1
end_operator
begin_operator
unstack b16 b19
0
4
0 23 0 12
0 18 0 1
0 22 -1 0
0 43 7 0
1
end_operator
begin_operator
unstack b16 b20
0
4
0 23 0 12
0 18 0 1
0 13 -1 0
0 43 8 0
1
end_operator
begin_operator
unstack b16 b21
0
4
0 23 0 12
0 18 0 1
0 9 -1 0
0 43 9 0
1
end_operator
begin_operator
unstack b16 b22
0
4
0 23 0 12
0 18 0 1
0 15 -1 0
0 43 10 0
1
end_operator
begin_operator
unstack b16 b23
0
4
0 23 0 12
0 18 0 1
0 12 -1 0
0 43 11 0
1
end_operator
begin_operator
unstack b16 b24
0
4
0 23 0 12
0 18 0 1
0 20 -1 0
0 43 12 0
1
end_operator
begin_operator
unstack b16 b27
0
4
0 23 0 12
0 18 0 1
0 17 -1 0
0 43 13 0
1
end_operator
begin_operator
unstack b16 b28
0
4
0 23 0 12
0 18 0 1
0 50 -1 0
0 43 14 0
1
end_operator
begin_operator
unstack b16 b3
0
4
0 23 0 12
0 18 0 1
0 52 -1 0
0 43 15 0
1
end_operator
begin_operator
unstack b16 b6
0
4
0 23 0 12
0 18 0 1
0 53 -1 0
0 43 16 0
1
end_operator
begin_operator
unstack b16 b7
0
4
0 23 0 12
0 18 0 1
0 11 -1 0
0 43 17 0
1
end_operator
begin_operator
unstack b17 b11
0
4
0 23 0 4
0 8 -1 0
0 7 0 1
0 26 0 3
1
end_operator
begin_operator
unstack b17 b21
0
4
0 23 0 4
0 7 0 1
0 9 -1 0
0 26 1 3
1
end_operator
begin_operator
unstack b18 b13
0
4
0 23 0 12
0 39 -1 0
0 10 0 1
0 29 1 0
1
end_operator
begin_operator
unstack b19 b1
0
4
0 23 0 12
0 21 -1 0
0 22 0 1
0 45 1 0
1
end_operator
begin_operator
unstack b19 b10
0
4
0 23 0 12
0 14 -1 0
0 22 0 1
0 45 2 0
1
end_operator
begin_operator
unstack b19 b11
0
4
0 23 0 12
0 8 -1 0
0 22 0 1
0 45 3 0
1
end_operator
begin_operator
unstack b19 b12
0
4
0 23 0 12
0 51 -1 0
0 22 0 1
0 45 4 0
1
end_operator
begin_operator
unstack b19 b13
0
4
0 23 0 12
0 39 -1 0
0 22 0 1
0 45 5 0
1
end_operator
begin_operator
unstack b19 b16
0
4
0 23 0 12
0 18 -1 0
0 22 0 1
0 45 6 0
1
end_operator
begin_operator
unstack b19 b17
0
4
0 23 0 12
0 7 -1 0
0 22 0 1
0 45 7 0
1
end_operator
begin_operator
unstack b19 b18
0
4
0 23 0 12
0 10 -1 0
0 22 0 1
0 45 8 0
1
end_operator
begin_operator
unstack b19 b20
0
4
0 23 0 12
0 22 0 1
0 13 -1 0
0 45 9 0
1
end_operator
begin_operator
unstack b19 b21
0
4
0 23 0 12
0 22 0 1
0 9 -1 0
0 45 10 0
1
end_operator
begin_operator
unstack b19 b22
0
4
0 23 0 12
0 22 0 1
0 15 -1 0
0 45 11 0
1
end_operator
begin_operator
unstack b19 b23
0
4
0 23 0 12
0 22 0 1
0 12 -1 0
0 45 12 0
1
end_operator
begin_operator
unstack b19 b24
0
4
0 23 0 12
0 22 0 1
0 20 -1 0
0 45 13 0
1
end_operator
begin_operator
unstack b19 b25
0
4
0 23 0 12
0 22 0 1
0 4 -1 0
0 45 14 0
1
end_operator
begin_operator
unstack b19 b26
0
4
0 23 0 12
0 22 0 1
0 16 -1 0
0 45 15 0
1
end_operator
begin_operator
unstack b19 b3
0
4
0 23 0 12
0 22 0 1
0 52 -1 0
0 45 16 0
1
end_operator
begin_operator
unstack b19 b6
0
4
0 23 0 12
0 22 0 1
0 53 -1 0
0 45 17 0
1
end_operator
begin_operator
unstack b19 b7
0
4
0 23 0 12
0 22 0 1
0 11 -1 0
0 45 18 0
1
end_operator
begin_operator
unstack b19 b9
0
4
0 23 0 12
0 22 0 1
0 6 -1 0
0 45 19 0
1
end_operator
begin_operator
unstack b2 b3
0
3
0 23 0 5
0 32 0 1
0 52 1 0
1
end_operator
begin_operator
unstack b20 b10
0
4
0 23 0 12
0 14 -1 0
0 13 0 1
0 35 1 0
1
end_operator
begin_operator
unstack b20 b12
0
4
0 23 0 12
0 51 -1 0
0 13 0 1
0 35 2 0
1
end_operator
begin_operator
unstack b20 b19
0
4
0 23 0 12
0 22 -1 0
0 13 0 1
0 35 3 0
1
end_operator
begin_operator
unstack b20 b21
0
4
0 23 0 12
0 13 0 1
0 9 -1 0
0 35 4 0
1
end_operator
begin_operator
unstack b20 b23
0
4
0 23 0 12
0 13 0 1
0 12 -1 0
0 35 5 0
1
end_operator
begin_operator
unstack b20 b26
0
4
0 23 0 12
0 13 0 1
0 16 -1 0
0 35 6 0
1
end_operator
begin_operator
unstack b20 b6
0
4
0 23 0 12
0 13 0 1
0 53 -1 0
0 35 7 0
1
end_operator
begin_operator
unstack b20 b7
0
4
0 23 0 12
0 13 0 1
0 11 -1 0
0 35 8 0
1
end_operator
begin_operator
unstack b21 b22
0
4
0 23 0 12
0 9 0 1
0 15 -1 0
0 30 1 0
1
end_operator
begin_operator
unstack b22 b10
0
4
0 23 0 12
0 14 -1 0
0 15 0 1
0 38 1 0
1
end_operator
begin_operator
unstack b22 b11
0
4
0 23 0 12
0 8 -1 0
0 15 0 1
0 38 2 0
1
end_operator
begin_operator
unstack b22 b12
0
4
0 23 0 12
0 51 -1 0
0 15 0 1
0 38 3 0
1
end_operator
begin_operator
unstack b22 b14
0
4
0 23 0 12
0 19 -1 0
0 15 0 1
0 38 4 0
1
end_operator
begin_operator
unstack b22 b16
0
4
0 23 0 12
0 18 -1 0
0 15 0 1
0 38 5 0
1
end_operator
begin_operator
unstack b22 b18
0
4
0 23 0 12
0 10 -1 0
0 15 0 1
0 38 6 0
1
end_operator
begin_operator
unstack b22 b19
0
4
0 23 0 12
0 22 -1 0
0 15 0 1
0 38 7 0
1
end_operator
begin_operator
unstack b22 b20
0
4
0 23 0 12
0 13 -1 0
0 15 0 1
0 38 8 0
1
end_operator
begin_operator
unstack b22 b23
0
4
0 23 0 12
0 15 0 1
0 12 -1 0
0 38 9 0
1
end_operator
begin_operator
unstack b22 b6
0
4
0 23 0 12
0 15 0 1
0 53 -1 0
0 38 10 0
1
end_operator
begin_operator
unstack b22 b7
0
4
0 23 0 12
0 15 0 1
0 11 -1 0
0 38 11 0
1
end_operator
begin_operator
unstack b23 b11
0
4
0 23 0 6
0 8 -1 0
0 12 0 1
0 34 0 5
1
end_operator
begin_operator
unstack b23 b4
0
4
0 23 0 6
0 12 0 1
0 5 -1 0
0 34 1 5
1
end_operator
begin_operator
unstack b23 b7
0
4
0 23 0 6
0 12 0 1
0 11 -1 0
0 34 2 5
1
end_operator
begin_operator
unstack b23 b9
0
4
0 23 0 6
0 12 0 1
0 6 -1 0
0 34 3 5
1
end_operator
begin_operator
unstack b24 b1
0
4
0 23 0 12
0 21 -1 0
0 20 0 1
0 47 1 0
1
end_operator
begin_operator
unstack b24 b10
0
4
0 23 0 12
0 14 -1 0
0 20 0 1
0 47 2 0
1
end_operator
begin_operator
unstack b24 b11
0
4
0 23 0 12
0 8 -1 0
0 20 0 1
0 47 3 0
1
end_operator
begin_operator
unstack b24 b12
0
4
0 23 0 12
0 51 -1 0
0 20 0 1
0 47 4 0
1
end_operator
begin_operator
unstack b24 b13
0
4
0 23 0 12
0 39 -1 0
0 20 0 1
0 47 5 0
1
end_operator
begin_operator
unstack b24 b14
0
4
0 23 0 12
0 19 -1 0
0 20 0 1
0 47 6 0
1
end_operator
begin_operator
unstack b24 b17
0
4
0 23 0 12
0 7 -1 0
0 20 0 1
0 47 7 0
1
end_operator
begin_operator
unstack b24 b18
0
4
0 23 0 12
0 10 -1 0
0 20 0 1
0 47 8 0
1
end_operator
begin_operator
unstack b24 b19
0
4
0 23 0 12
0 22 -1 0
0 20 0 1
0 47 9 0
1
end_operator
begin_operator
unstack b24 b21
0
4
0 23 0 12
0 9 -1 0
0 20 0 1
0 47 10 0
1
end_operator
begin_operator
unstack b24 b22
0
4
0 23 0 12
0 15 -1 0
0 20 0 1
0 47 11 0
1
end_operator
begin_operator
unstack b24 b23
0
4
0 23 0 12
0 12 -1 0
0 20 0 1
0 47 12 0
1
end_operator
begin_operator
unstack b24 b26
0
4
0 23 0 12
0 20 0 1
0 16 -1 0
0 47 13 0
1
end_operator
begin_operator
unstack b24 b27
0
4
0 23 0 12
0 20 0 1
0 17 -1 0
0 47 14 0
1
end_operator
begin_operator
unstack b24 b28
0
4
0 23 0 12
0 20 0 1
0 50 -1 0
0 47 15 0
1
end_operator
begin_operator
unstack b24 b3
0
4
0 23 0 12
0 20 0 1
0 52 -1 0
0 47 16 0
1
end_operator
begin_operator
unstack b24 b4
0
4
0 23 0 12
0 20 0 1
0 5 -1 0
0 47 17 0
1
end_operator
begin_operator
unstack b24 b6
0
4
0 23 0 12
0 20 0 1
0 53 -1 0
0 47 18 0
1
end_operator
begin_operator
unstack b24 b7
0
4
0 23 0 12
0 20 0 1
0 11 -1 0
0 47 19 0
1
end_operator
begin_operator
unstack b24 b8
0
4
0 23 0 12
0 20 0 1
0 3 -1 0
0 47 20 0
1
end_operator
begin_operator
unstack b24 b9
0
4
0 23 0 12
0 20 0 1
0 6 -1 0
0 47 21 0
1
end_operator
begin_operator
unstack b25 b3
0
3
0 23 0 7
0 4 0 1
0 52 2 0
1
end_operator
begin_operator
unstack b26 b1
0
4
0 23 0 12
0 21 -1 0
0 16 0 1
0 41 1 0
1
end_operator
begin_operator
unstack b26 b10
0
4
0 23 0 12
0 14 -1 0
0 16 0 1
0 41 2 0
1
end_operator
begin_operator
unstack b26 b12
0
4
0 23 0 12
0 51 -1 0
0 16 0 1
0 41 3 0
1
end_operator
begin_operator
unstack b26 b16
0
4
0 23 0 12
0 18 -1 0
0 16 0 1
0 41 4 0
1
end_operator
begin_operator
unstack b26 b18
0
4
0 23 0 12
0 10 -1 0
0 16 0 1
0 41 5 0
1
end_operator
begin_operator
unstack b26 b19
0
4
0 23 0 12
0 22 -1 0
0 16 0 1
0 41 6 0
1
end_operator
begin_operator
unstack b26 b20
0
4
0 23 0 12
0 13 -1 0
0 16 0 1
0 41 7 0
1
end_operator
begin_operator
unstack b26 b21
0
4
0 23 0 12
0 9 -1 0
0 16 0 1
0 41 8 0
1
end_operator
begin_operator
unstack b26 b23
0
4
0 23 0 12
0 12 -1 0
0 16 0 1
0 41 9 0
1
end_operator
begin_operator
unstack b26 b24
0
4
0 23 0 12
0 20 -1 0
0 16 0 1
0 41 10 0
1
end_operator
begin_operator
unstack b26 b27
0
4
0 23 0 12
0 16 0 1
0 17 -1 0
0 41 11 0
1
end_operator
begin_operator
unstack b26 b28
0
4
0 23 0 12
0 16 0 1
0 50 -1 0
0 41 12 0
1
end_operator
begin_operator
unstack b26 b3
0
4
0 23 0 12
0 16 0 1
0 52 -1 0
0 41 13 0
1
end_operator
begin_operator
unstack b26 b6
0
4
0 23 0 12
0 16 0 1
0 53 -1 0
0 41 14 0
1
end_operator
begin_operator
unstack b26 b7
0
4
0 23 0 12
0 16 0 1
0 11 -1 0
0 41 15 0
1
end_operator
begin_operator
unstack b27 b1
0
4
0 23 0 12
0 21 -1 0
0 17 0 1
0 40 1 0
1
end_operator
begin_operator
unstack b27 b10
0
4
0 23 0 12
0 14 -1 0
0 17 0 1
0 40 2 0
1
end_operator
begin_operator
unstack b27 b11
0
4
0 23 0 12
0 8 -1 0
0 17 0 1
0 40 3 0
1
end_operator
begin_operator
unstack b27 b12
0
4
0 23 0 12
0 51 -1 0
0 17 0 1
0 40 4 0
1
end_operator
begin_operator
unstack b27 b14
0
4
0 23 0 12
0 19 -1 0
0 17 0 1
0 40 5 0
1
end_operator
begin_operator
unstack b27 b16
0
4
0 23 0 12
0 18 -1 0
0 17 0 1
0 40 6 0
1
end_operator
begin_operator
unstack b27 b17
0
4
0 23 0 12
0 7 -1 0
0 17 0 1
0 40 7 0
1
end_operator
begin_operator
unstack b27 b18
0
4
0 23 0 12
0 10 -1 0
0 17 0 1
0 40 8 0
1
end_operator
begin_operator
unstack b27 b19
0
4
0 23 0 12
0 22 -1 0
0 17 0 1
0 40 9 0
1
end_operator
begin_operator
unstack b27 b22
0
4
0 23 0 12
0 15 -1 0
0 17 0 1
0 40 10 0
1
end_operator
begin_operator
unstack b27 b23
0
4
0 23 0 12
0 12 -1 0
0 17 0 1
0 40 11 0
1
end_operator
begin_operator
unstack b27 b24
0
4
0 23 0 12
0 20 -1 0
0 17 0 1
0 40 12 0
1
end_operator
begin_operator
unstack b27 b28
0
4
0 23 0 12
0 17 0 1
0 50 -1 0
0 40 13 0
1
end_operator
begin_operator
unstack b27 b6
0
4
0 23 0 12
0 17 0 1
0 53 -1 0
0 40 14 0
1
end_operator
begin_operator
unstack b27 b7
0
4
0 23 0 12
0 17 0 1
0 11 -1 0
0 40 15 0
1
end_operator
begin_operator
unstack b28 b1
0
4
0 23 0 12
0 21 -1 0
0 50 0 3
0 42 1 0
1
end_operator
begin_operator
unstack b28 b10
0
4
0 23 0 12
0 14 -1 0
0 50 0 3
0 42 2 0
1
end_operator
begin_operator
unstack b28 b12
0
4
0 23 0 12
0 51 -1 0
0 50 0 3
0 42 3 0
1
end_operator
begin_operator
unstack b28 b16
0
4
0 23 0 12
0 18 -1 0
0 50 0 3
0 42 4 0
1
end_operator
begin_operator
unstack b28 b17
0
4
0 23 0 12
0 7 -1 0
0 50 0 3
0 42 5 0
1
end_operator
begin_operator
unstack b28 b18
0
4
0 23 0 12
0 10 -1 0
0 50 0 3
0 42 6 0
1
end_operator
begin_operator
unstack b28 b19
0
4
0 23 0 12
0 22 -1 0
0 50 0 3
0 42 7 0
1
end_operator
begin_operator
unstack b28 b20
0
4
0 23 0 12
0 13 -1 0
0 50 0 3
0 42 8 0
1
end_operator
begin_operator
unstack b28 b21
0
4
0 23 0 12
0 9 -1 0
0 50 0 3
0 42 9 0
1
end_operator
begin_operator
unstack b28 b22
0
4
0 23 0 12
0 15 -1 0
0 50 0 3
0 42 10 0
1
end_operator
begin_operator
unstack b28 b24
0
4
0 23 0 12
0 20 -1 0
0 50 0 3
0 42 11 0
1
end_operator
begin_operator
unstack b28 b26
0
4
0 23 0 12
0 16 -1 0
0 50 0 3
0 42 12 0
1
end_operator
begin_operator
unstack b28 b27
0
4
0 23 0 12
0 17 -1 0
0 50 0 3
0 42 13 0
1
end_operator
begin_operator
unstack b28 b4
0
4
0 23 0 12
0 50 0 3
0 5 -1 0
0 42 14 0
1
end_operator
begin_operator
unstack b28 b6
0
4
0 23 0 12
0 50 0 3
0 53 -1 0
0 42 15 0
1
end_operator
begin_operator
unstack b3 b10
0
4
0 23 0 12
0 14 -1 0
0 52 0 3
0 48 1 0
1
end_operator
begin_operator
unstack b3 b11
0
4
0 23 0 12
0 8 -1 0
0 52 0 3
0 48 2 0
1
end_operator
begin_operator
unstack b3 b12
0
4
0 23 0 12
0 51 -1 0
0 52 0 3
0 48 3 0
1
end_operator
begin_operator
unstack b3 b13
0
4
0 23 0 12
0 39 -1 0
0 52 0 3
0 48 4 0
1
end_operator
begin_operator
unstack b3 b14
0
4
0 23 0 12
0 19 -1 0
0 52 0 3
0 48 5 0
1
end_operator
begin_operator
unstack b3 b16
0
4
0 23 0 12
0 18 -1 0
0 52 0 3
0 48 6 0
1
end_operator
begin_operator
unstack b3 b17
0
4
0 23 0 12
0 7 -1 0
0 52 0 3
0 48 7 0
1
end_operator
begin_operator
unstack b3 b18
0
4
0 23 0 12
0 10 -1 0
0 52 0 3
0 48 8 0
1
end_operator
begin_operator
unstack b3 b19
0
4
0 23 0 12
0 22 -1 0
0 52 0 3
0 48 9 0
1
end_operator
begin_operator
unstack b3 b20
0
4
0 23 0 12
0 13 -1 0
0 52 0 3
0 48 10 0
1
end_operator
begin_operator
unstack b3 b21
0
4
0 23 0 12
0 9 -1 0
0 52 0 3
0 48 11 0
1
end_operator
begin_operator
unstack b3 b22
0
4
0 23 0 12
0 15 -1 0
0 52 0 3
0 48 12 0
1
end_operator
begin_operator
unstack b3 b23
0
4
0 23 0 12
0 12 -1 0
0 52 0 3
0 48 13 0
1
end_operator
begin_operator
unstack b3 b24
0
4
0 23 0 12
0 20 -1 0
0 52 0 3
0 48 14 0
1
end_operator
begin_operator
unstack b3 b25
0
4
0 23 0 12
0 4 -1 0
0 52 0 3
0 48 15 0
1
end_operator
begin_operator
unstack b3 b26
0
4
0 23 0 12
0 16 -1 0
0 52 0 3
0 48 16 0
1
end_operator
begin_operator
unstack b3 b27
0
4
0 23 0 12
0 17 -1 0
0 52 0 3
0 48 17 0
1
end_operator
begin_operator
unstack b3 b4
0
4
0 23 0 12
0 52 0 3
0 5 -1 0
0 48 18 0
1
end_operator
begin_operator
unstack b3 b6
0
4
0 23 0 12
0 52 0 3
0 53 -1 0
0 48 19 0
1
end_operator
begin_operator
unstack b3 b7
0
4
0 23 0 12
0 52 0 3
0 11 -1 0
0 48 20 0
1
end_operator
begin_operator
unstack b3 b8
0
4
0 23 0 12
0 52 0 3
0 3 -1 0
0 48 21 0
1
end_operator
begin_operator
unstack b3 b9
0
4
0 23 0 12
0 52 0 3
0 6 -1 0
0 48 22 0
1
end_operator
begin_operator
unstack b4 b27
0
4
0 23 0 8
0 17 -1 0
0 5 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b5 b7
0
4
0 23 0 9
0 2 0 1
0 11 -1 0
0 28 0 3
1
end_operator
begin_operator
unstack b6 b12
0
4
0 23 0 12
0 51 -1 0
0 53 0 1
0 44 1 0
1
end_operator
begin_operator
unstack b6 b13
0
4
0 23 0 12
0 39 -1 0
0 53 0 1
0 44 2 0
1
end_operator
begin_operator
unstack b6 b14
0
4
0 23 0 12
0 19 -1 0
0 53 0 1
0 44 3 0
1
end_operator
begin_operator
unstack b6 b16
0
4
0 23 0 12
0 18 -1 0
0 53 0 1
0 44 4 0
1
end_operator
begin_operator
unstack b6 b19
0
4
0 23 0 12
0 22 -1 0
0 53 0 1
0 44 5 0
1
end_operator
begin_operator
unstack b6 b20
0
4
0 23 0 12
0 13 -1 0
0 53 0 1
0 44 6 0
1
end_operator
begin_operator
unstack b6 b21
0
4
0 23 0 12
0 9 -1 0
0 53 0 1
0 44 7 0
1
end_operator
begin_operator
unstack b6 b22
0
4
0 23 0 12
0 15 -1 0
0 53 0 1
0 44 8 0
1
end_operator
begin_operator
unstack b6 b23
0
4
0 23 0 12
0 12 -1 0
0 53 0 1
0 44 9 0
1
end_operator
begin_operator
unstack b6 b25
0
4
0 23 0 12
0 4 -1 0
0 53 0 1
0 44 10 0
1
end_operator
begin_operator
unstack b6 b26
0
4
0 23 0 12
0 16 -1 0
0 53 0 1
0 44 11 0
1
end_operator
begin_operator
unstack b6 b27
0
4
0 23 0 12
0 17 -1 0
0 53 0 1
0 44 12 0
1
end_operator
begin_operator
unstack b6 b28
0
4
0 23 0 12
0 50 -1 0
0 53 0 1
0 44 13 0
1
end_operator
begin_operator
unstack b6 b3
0
4
0 23 0 12
0 52 -1 0
0 53 0 1
0 44 14 0
1
end_operator
begin_operator
unstack b6 b4
0
4
0 23 0 12
0 5 -1 0
0 53 0 1
0 44 15 0
1
end_operator
begin_operator
unstack b6 b7
0
4
0 23 0 12
0 53 0 1
0 11 -1 0
0 44 16 0
1
end_operator
begin_operator
unstack b6 b8
0
4
0 23 0 12
0 53 0 1
0 3 -1 0
0 44 17 0
1
end_operator
begin_operator
unstack b6 b9
0
4
0 23 0 12
0 53 0 1
0 6 -1 0
0 44 18 0
1
end_operator
begin_operator
unstack b8 b15
0
4
0 23 0 11
0 33 -1 0
0 3 0 1
0 25 0 2
1
end_operator
0
