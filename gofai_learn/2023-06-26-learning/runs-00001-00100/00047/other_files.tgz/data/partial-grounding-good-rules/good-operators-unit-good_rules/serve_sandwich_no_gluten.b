%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% modes:
:- discontiguous('ini:at_kitchen_bread'/2).
:- discontiguous('goal:at_kitchen_bread'/2).
:- modeb(*, 'ini:at_kitchen_bread'(+'type:object', +task_id)).
:- modeb(*, 'goal:at_kitchen_bread'(+'type:object', +task_id)).
:- discontiguous('ini:at_kitchen_content'/2).
:- discontiguous('goal:at_kitchen_content'/2).
:- modeb(*, 'ini:at_kitchen_content'(+'type:object', +task_id)).
:- modeb(*, 'goal:at_kitchen_content'(+'type:object', +task_id)).
:- discontiguous('ini:at_kitchen_sandwich'/2).
:- discontiguous('goal:at_kitchen_sandwich'/2).
:- modeb(*, 'ini:at_kitchen_sandwich'(+'type:object', +task_id)).
:- modeb(*, 'goal:at_kitchen_sandwich'(+'type:object', +task_id)).
:- discontiguous('ini:no_gluten_bread'/2).
:- discontiguous('goal:no_gluten_bread'/2).
:- modeb(*, 'ini:no_gluten_bread'(+'type:object', +task_id)).
:- modeb(*, 'goal:no_gluten_bread'(+'type:object', +task_id)).
:- discontiguous('ini:no_gluten_content'/2).
:- discontiguous('goal:no_gluten_content'/2).
:- modeb(*, 'ini:no_gluten_content'(+'type:object', +task_id)).
:- modeb(*, 'goal:no_gluten_content'(+'type:object', +task_id)).
:- discontiguous('ini:ontray'/3).
:- discontiguous('goal:ontray'/3).
:- modeb(*, 'ini:ontray'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:ontray'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:ontray'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:ontray'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:no_gluten_sandwich'/2).
:- discontiguous('goal:no_gluten_sandwich'/2).
:- modeb(*, 'ini:no_gluten_sandwich'(+'type:object', +task_id)).
:- modeb(*, 'goal:no_gluten_sandwich'(+'type:object', +task_id)).
:- discontiguous('ini:allergic_gluten'/2).
:- discontiguous('goal:allergic_gluten'/2).
:- modeb(*, 'ini:allergic_gluten'(+'type:object', +task_id)).
:- modeb(*, 'goal:allergic_gluten'(+'type:object', +task_id)).
:- discontiguous('ini:not_allergic_gluten'/2).
:- discontiguous('goal:not_allergic_gluten'/2).
:- modeb(*, 'ini:not_allergic_gluten'(+'type:object', +task_id)).
:- modeb(*, 'goal:not_allergic_gluten'(+'type:object', +task_id)).
:- discontiguous('ini:served'/2).
:- discontiguous('goal:served'/2).
:- modeb(*, 'ini:served'(+'type:object', +task_id)).
:- modeb(*, 'goal:served'(+'type:object', +task_id)).
:- discontiguous('ini:waiting'/3).
:- discontiguous('goal:waiting'/3).
:- modeb(*, 'ini:waiting'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:waiting'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:waiting'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:waiting'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:at'/3).
:- discontiguous('goal:at'/3).
:- modeb(*, 'ini:at'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:at'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:at'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:at'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:notexist'/2).
:- discontiguous('goal:notexist'/2).
:- modeb(*, 'ini:notexist'(+'type:object', +task_id)).
:- modeb(*, 'goal:notexist'(+'type:object', +task_id)).

% types and constants

:- modeh(1, class(+'type:object', +'type:object', +'type:object', +'type:object', +task_id)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% determinations:
:- determination(class/5, 'ini:at_kitchen_bread'/2).
:- determination(class/5, 'goal:at_kitchen_bread'/2).
:- determination(class/5, 'ini:at_kitchen_content'/2).
:- determination(class/5, 'goal:at_kitchen_content'/2).
:- determination(class/5, 'ini:at_kitchen_sandwich'/2).
:- determination(class/5, 'goal:at_kitchen_sandwich'/2).
:- determination(class/5, 'ini:no_gluten_bread'/2).
:- determination(class/5, 'goal:no_gluten_bread'/2).
:- determination(class/5, 'ini:no_gluten_content'/2).
:- determination(class/5, 'goal:no_gluten_content'/2).
:- determination(class/5, 'ini:ontray'/3).
:- determination(class/5, 'goal:ontray'/3).
:- determination(class/5, 'ini:no_gluten_sandwich'/2).
:- determination(class/5, 'goal:no_gluten_sandwich'/2).
:- determination(class/5, 'ini:allergic_gluten'/2).
:- determination(class/5, 'goal:allergic_gluten'/2).
:- determination(class/5, 'ini:not_allergic_gluten'/2).
:- determination(class/5, 'goal:not_allergic_gluten'/2).
:- determination(class/5, 'ini:served'/2).
:- determination(class/5, 'goal:served'/2).
:- determination(class/5, 'ini:waiting'/3).
:- determination(class/5, 'goal:waiting'/3).
:- determination(class/5, 'ini:at'/3).
:- determination(class/5, 'goal:at'/3).
:- determination(class/5, 'ini:notexist'/2).
:- determination(class/5, 'goal:notexist'/2).

'type:object'('obj:kitchen').
'type:object'('obj:child1').
'type:object'('obj:tray1').
'type:object'('obj:sandw1').
'type:object'('obj:bread1').
'type:object'('obj:content1').
'type:object'('obj:table1').
'type:object'('obj:sandw2').
'type:object'('obj:bread2').
'type:object'('obj:content2').
'type:object'('obj:table2').
'type:object'('obj:tray2').
'type:object'('obj:child2').
'type:object'('obj:sandw3').
'type:object'('obj:bread3').
'type:object'('obj:content3').
'type:object'('obj:table3').
'type:object'('obj:child3').
'type:object'('obj:sandw4').
'type:object'('obj:sandw5').
'type:object'('obj:bread4').
'type:object'('obj:bread5').
'type:object'('obj:content4').
'type:object'('obj:content5').
'type:object'('obj:child4').
'type:object'('obj:child5').
'type:object'('obj:sandw6').
'type:object'('obj:sandw7').
'type:object'('obj:child6').
'type:object'('obj:bread6').
'type:object'('obj:content6').
'type:object'('obj:sandw8').


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p01
'ini:at'('obj:tray1','obj:kitchen','p01').
'ini:notexist'('obj:sandw1','p01').
'ini:at_kitchen_content'('obj:content1','p01').
'ini:not_allergic_gluten'('obj:child1','p01').
'ini:waiting'('obj:child1','obj:table1','p01').
'ini:at_kitchen_bread'('obj:bread1','p01').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p01

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p02
'ini:no_gluten_content'('obj:content1','p02').
'ini:no_gluten_bread'('obj:bread1','p02').
'ini:at'('obj:tray1','obj:kitchen','p02').
'ini:notexist'('obj:sandw1','p02').
'ini:at_kitchen_content'('obj:content1','p02').
'ini:waiting'('obj:child1','obj:table1','p02').
'ini:at_kitchen_bread'('obj:bread1','p02').
'ini:allergic_gluten'('obj:child1','p02').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p02

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p03
'ini:at_kitchen_content'('obj:content2','p03').
'ini:no_gluten_bread'('obj:bread2','p03').
'ini:waiting'('obj:child1','obj:table2','p03').
'ini:no_gluten_content'('obj:content1','p03').
'ini:notexist'('obj:sandw2','p03').
'ini:at'('obj:tray1','obj:kitchen','p03').
'ini:notexist'('obj:sandw1','p03').
'ini:at_kitchen_content'('obj:content1','p03').
'ini:at_kitchen_bread'('obj:bread1','p03').
'ini:at_kitchen_bread'('obj:bread2','p03').
'ini:allergic_gluten'('obj:child1','p03').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p03

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p04
'ini:at_kitchen_content'('obj:content2','p04').
'ini:no_gluten_bread'('obj:bread1','p04').
'ini:notexist'('obj:sandw2','p04').
'ini:at'('obj:tray1','obj:kitchen','p04').
'ini:no_gluten_content'('obj:content2','p04').
'ini:notexist'('obj:sandw1','p04').
'ini:at_kitchen_content'('obj:content1','p04').
'ini:waiting'('obj:child1','obj:table1','p04').
'ini:at_kitchen_bread'('obj:bread1','p04').
'ini:at_kitchen_bread'('obj:bread2','p04').
'ini:at'('obj:tray2','obj:kitchen','p04').
'ini:allergic_gluten'('obj:child1','p04').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p04

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p05
'ini:at_kitchen_content'('obj:content2','p05').
'ini:no_gluten_bread'('obj:bread2','p05').
'ini:waiting'('obj:child1','obj:table2','p05').
'ini:no_gluten_bread'('obj:bread1','p05').
'ini:no_gluten_content'('obj:content1','p05').
'ini:at'('obj:tray1','obj:kitchen','p05').
'ini:no_gluten_content'('obj:content2','p05').
'ini:notexist'('obj:sandw2','p05').
'ini:notexist'('obj:sandw1','p05').
'ini:not_allergic_gluten'('obj:child2','p05').
'ini:at_kitchen_content'('obj:content1','p05').
'ini:not_allergic_gluten'('obj:child1','p05').
'ini:waiting'('obj:child2','obj:table1','p05').
'ini:at_kitchen_bread'('obj:bread1','p05').
'ini:at_kitchen_bread'('obj:bread2','p05').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p05
'goal:served'('obj:child1','p05').
'goal:served'('obj:child2','p05').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p06
'ini:at_kitchen_content'('obj:content2','p06').
'ini:no_gluten_bread'('obj:bread2','p06').
'ini:notexist'('obj:sandw2','p06').
'ini:at'('obj:tray1','obj:kitchen','p06').
'ini:no_gluten_content'('obj:content2','p06').
'ini:notexist'('obj:sandw1','p06').
'ini:not_allergic_gluten'('obj:child2','p06').
'ini:at_kitchen_content'('obj:content1','p06').
'ini:waiting'('obj:child1','obj:table1','p06').
'ini:waiting'('obj:child2','obj:table1','p06').
'ini:at_kitchen_bread'('obj:bread1','p06').
'ini:at_kitchen_bread'('obj:bread2','p06').
'ini:allergic_gluten'('obj:child1','p06').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p06
'goal:served'('obj:child1','p06').
'goal:served'('obj:child2','p06').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p07
'ini:at_kitchen_content'('obj:content2','p07').
'ini:no_gluten_bread'('obj:bread2','p07').
'ini:waiting'('obj:child1','obj:table2','p07').
'ini:no_gluten_bread'('obj:bread1','p07').
'ini:no_gluten_content'('obj:content1','p07').
'ini:at'('obj:tray1','obj:kitchen','p07').
'ini:no_gluten_content'('obj:content2','p07').
'ini:waiting'('obj:child2','obj:table2','p07').
'ini:notexist'('obj:sandw1','p07').
'ini:notexist'('obj:sandw2','p07').
'ini:at_kitchen_content'('obj:content1','p07').
'ini:at_kitchen_bread'('obj:bread1','p07').
'ini:at_kitchen_bread'('obj:bread2','p07').
'ini:allergic_gluten'('obj:child2','p07').
'ini:allergic_gluten'('obj:child1','p07').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p07
'goal:served'('obj:child1','p07').
'goal:served'('obj:child2','p07').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p08
'ini:at_kitchen_content'('obj:content2','p08').
'ini:no_gluten_bread'('obj:bread2','p08').
'ini:no_gluten_bread'('obj:bread1','p08').
'ini:no_gluten_content'('obj:content1','p08').
'ini:at'('obj:tray1','obj:kitchen','p08').
'ini:no_gluten_content'('obj:content2','p08').
'ini:waiting'('obj:child2','obj:table2','p08').
'ini:notexist'('obj:sandw1','p08').
'ini:notexist'('obj:sandw2','p08').
'ini:not_allergic_gluten'('obj:child2','p08').
'ini:at_kitchen_content'('obj:content1','p08').
'ini:not_allergic_gluten'('obj:child1','p08').
'ini:waiting'('obj:child1','obj:table1','p08').
'ini:at_kitchen_bread'('obj:bread1','p08').
'ini:at_kitchen_bread'('obj:bread2','p08').
'ini:at'('obj:tray2','obj:kitchen','p08').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p08
'goal:served'('obj:child1','p08').
'goal:served'('obj:child2','p08').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p09
'ini:at_kitchen_content'('obj:content2','p09').
'ini:waiting'('obj:child1','obj:table2','p09').
'ini:no_gluten_bread'('obj:bread1','p09').
'ini:no_gluten_content'('obj:content1','p09').
'ini:at'('obj:tray1','obj:kitchen','p09').
'ini:waiting'('obj:child2','obj:table2','p09').
'ini:notexist'('obj:sandw2','p09').
'ini:notexist'('obj:sandw1','p09').
'ini:at_kitchen_content'('obj:content1','p09').
'ini:not_allergic_gluten'('obj:child1','p09').
'ini:at_kitchen_bread'('obj:bread1','p09').
'ini:at_kitchen_bread'('obj:bread2','p09').
'ini:allergic_gluten'('obj:child2','p09').
'ini:at'('obj:tray2','obj:kitchen','p09').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p09
'goal:served'('obj:child1','p09').
'goal:served'('obj:child2','p09').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p10
'ini:at_kitchen_content'('obj:content2','p10').
'ini:no_gluten_bread'('obj:bread2','p10').
'ini:no_gluten_bread'('obj:bread1','p10').
'ini:no_gluten_content'('obj:content1','p10').
'ini:at'('obj:tray1','obj:kitchen','p10').
'ini:no_gluten_content'('obj:content2','p10').
'ini:waiting'('obj:child2','obj:table2','p10').
'ini:notexist'('obj:sandw1','p10').
'ini:notexist'('obj:sandw2','p10').
'ini:at_kitchen_content'('obj:content1','p10').
'ini:waiting'('obj:child1','obj:table1','p10').
'ini:at_kitchen_bread'('obj:bread1','p10').
'ini:at_kitchen_bread'('obj:bread2','p10').
'ini:allergic_gluten'('obj:child2','p10').
'ini:at'('obj:tray2','obj:kitchen','p10').
'ini:allergic_gluten'('obj:child1','p10').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p10
'goal:served'('obj:child1','p10').
'goal:served'('obj:child2','p10').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p11
'ini:at_kitchen_content'('obj:content2','p11').
'ini:at_kitchen_content'('obj:content3','p11').
'ini:no_gluten_bread'('obj:bread2','p11').
'ini:waiting'('obj:child1','obj:table2','p11').
'ini:at_kitchen_bread'('obj:bread3','p11').
'ini:no_gluten_bread'('obj:bread1','p11').
'ini:notexist'('obj:sandw2','p11').
'ini:at'('obj:tray1','obj:kitchen','p11').
'ini:no_gluten_content'('obj:content2','p11').
'ini:waiting'('obj:child2','obj:table2','p11').
'ini:notexist'('obj:sandw1','p11').
'ini:notexist'('obj:sandw3','p11').
'ini:at_kitchen_content'('obj:content1','p11').
'ini:not_allergic_gluten'('obj:child1','p11').
'ini:at_kitchen_bread'('obj:bread1','p11').
'ini:at_kitchen_bread'('obj:bread2','p11').
'ini:allergic_gluten'('obj:child2','p11').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p11
'goal:served'('obj:child1','p11').
'goal:served'('obj:child2','p11').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p12
'ini:at_kitchen_content'('obj:content2','p12').
'ini:at_kitchen_content'('obj:content3','p12').
'ini:at_kitchen_bread'('obj:bread3','p12').
'ini:no_gluten_content'('obj:content1','p12').
'ini:notexist'('obj:sandw2','p12').
'ini:at'('obj:tray1','obj:kitchen','p12').
'ini:notexist'('obj:sandw3','p12').
'ini:notexist'('obj:sandw1','p12').
'ini:waiting'('obj:child1','obj:table3','p12').
'ini:not_allergic_gluten'('obj:child2','p12').
'ini:at_kitchen_content'('obj:content1','p12').
'ini:waiting'('obj:child2','obj:table3','p12').
'ini:no_gluten_bread'('obj:bread3','p12').
'ini:at_kitchen_bread'('obj:bread1','p12').
'ini:at_kitchen_bread'('obj:bread2','p12').
'ini:at'('obj:tray2','obj:kitchen','p12').
'ini:allergic_gluten'('obj:child1','p12').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p12
'goal:served'('obj:child1','p12').
'goal:served'('obj:child2','p12').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p13
'ini:at_kitchen_bread'('obj:bread5','p13').
'ini:at'('obj:tray1','obj:kitchen','p13').
'ini:at_kitchen_content'('obj:content1','p13').
'ini:no_gluten_bread'('obj:bread5','p13').
'ini:at_kitchen_bread'('obj:bread2','p13').
'ini:no_gluten_content'('obj:content2','p13').
'ini:at_kitchen_bread'('obj:bread4','p13').
'ini:at_kitchen_content'('obj:content4','p13').
'ini:at_kitchen_bread'('obj:bread1','p13').
'ini:allergic_gluten'('obj:child2','p13').
'ini:allergic_gluten'('obj:child1','p13').
'ini:notexist'('obj:sandw4','p13').
'ini:at_kitchen_content'('obj:content5','p13').
'ini:not_allergic_gluten'('obj:child3','p13').
'ini:no_gluten_bread'('obj:bread1','p13').
'ini:notexist'('obj:sandw2','p13').
'ini:notexist'('obj:sandw5','p13').
'ini:waiting'('obj:child3','obj:table3','p13').
'ini:no_gluten_content'('obj:content4','p13').
'ini:notexist'('obj:sandw3','p13').
'ini:at_kitchen_content'('obj:content2','p13').
'ini:at_kitchen_content'('obj:content3','p13').
'ini:at_kitchen_bread'('obj:bread3','p13').
'ini:notexist'('obj:sandw1','p13').
'ini:waiting'('obj:child1','obj:table3','p13').
'ini:waiting'('obj:child2','obj:table3','p13').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p13
'goal:served'('obj:child1','p13').
'goal:served'('obj:child2','p13').
'goal:served'('obj:child3','p13').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p14
'ini:at'('obj:tray1','obj:kitchen','p14').
'ini:at_kitchen_content'('obj:content1','p14').
'ini:at_kitchen_bread'('obj:bread2','p14').
'ini:at_kitchen_bread'('obj:bread4','p14').
'ini:at_kitchen_content'('obj:content4','p14').
'ini:waiting'('obj:child2','obj:table2','p14').
'ini:at_kitchen_bread'('obj:bread1','p14').
'ini:notexist'('obj:sandw4','p14').
'ini:not_allergic_gluten'('obj:child3','p14').
'ini:notexist'('obj:sandw2','p14').
'ini:waiting'('obj:child4','obj:table1','p14').
'ini:waiting'('obj:child3','obj:table3','p14').
'ini:notexist'('obj:sandw3','p14').
'ini:at_kitchen_content'('obj:content2','p14').
'ini:at_kitchen_content'('obj:content3','p14').
'ini:at_kitchen_bread'('obj:bread3','p14').
'ini:notexist'('obj:sandw1','p14').
'ini:not_allergic_gluten'('obj:child2','p14').
'ini:not_allergic_gluten'('obj:child1','p14').
'ini:waiting'('obj:child1','obj:table1','p14').
'ini:not_allergic_gluten'('obj:child4','p14').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p14
'goal:served'('obj:child1','p14').
'goal:served'('obj:child2','p14').
'goal:served'('obj:child3','p14').
'goal:served'('obj:child4','p14').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p15
'ini:at'('obj:tray1','obj:kitchen','p15').
'ini:at_kitchen_content'('obj:content1','p15').
'ini:at_kitchen_bread'('obj:bread2','p15').
'ini:at_kitchen_bread'('obj:bread4','p15').
'ini:at_kitchen_content'('obj:content4','p15').
'ini:waiting'('obj:child1','obj:table2','p15').
'ini:at_kitchen_bread'('obj:bread1','p15').
'ini:notexist'('obj:sandw4','p15').
'ini:not_allergic_gluten'('obj:child3','p15').
'ini:notexist'('obj:sandw2','p15').
'ini:waiting'('obj:child4','obj:table1','p15').
'ini:waiting'('obj:child3','obj:table3','p15').
'ini:notexist'('obj:sandw3','p15').
'ini:at_kitchen_content'('obj:content2','p15').
'ini:at_kitchen_content'('obj:content3','p15').
'ini:at_kitchen_bread'('obj:bread3','p15').
'ini:notexist'('obj:sandw1','p15').
'ini:not_allergic_gluten'('obj:child2','p15').
'ini:not_allergic_gluten'('obj:child1','p15').
'ini:waiting'('obj:child2','obj:table3','p15').
'ini:not_allergic_gluten'('obj:child4','p15').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p15
'goal:served'('obj:child1','p15').
'goal:served'('obj:child2','p15').
'goal:served'('obj:child3','p15').
'goal:served'('obj:child4','p15').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p16
'ini:at'('obj:tray1','obj:kitchen','p16').
'ini:at_kitchen_content'('obj:content1','p16').
'ini:at_kitchen_bread'('obj:bread2','p16').
'ini:at_kitchen_bread'('obj:bread4','p16').
'ini:at_kitchen_content'('obj:content4','p16').
'ini:at_kitchen_bread'('obj:bread1','p16').
'ini:notexist'('obj:sandw4','p16').
'ini:not_allergic_gluten'('obj:child3','p16').
'ini:notexist'('obj:sandw2','p16').
'ini:waiting'('obj:child4','obj:table1','p16').
'ini:waiting'('obj:child3','obj:table1','p16').
'ini:notexist'('obj:sandw3','p16').
'ini:at_kitchen_content'('obj:content2','p16').
'ini:at_kitchen_content'('obj:content3','p16').
'ini:at_kitchen_bread'('obj:bread3','p16').
'ini:notexist'('obj:sandw1','p16').
'ini:waiting'('obj:child1','obj:table3','p16').
'ini:not_allergic_gluten'('obj:child2','p16').
'ini:not_allergic_gluten'('obj:child1','p16').
'ini:waiting'('obj:child2','obj:table1','p16').
'ini:not_allergic_gluten'('obj:child4','p16').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p16
'goal:served'('obj:child1','p16').
'goal:served'('obj:child2','p16').
'goal:served'('obj:child3','p16').
'goal:served'('obj:child4','p16').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p17
'ini:at'('obj:tray1','obj:kitchen','p17').
'ini:at_kitchen_content'('obj:content1','p17').
'ini:at_kitchen_bread'('obj:bread2','p17').
'ini:at_kitchen_bread'('obj:bread4','p17').
'ini:at_kitchen_content'('obj:content4','p17').
'ini:waiting'('obj:child1','obj:table2','p17').
'ini:waiting'('obj:child3','obj:table2','p17').
'ini:at_kitchen_bread'('obj:bread1','p17').
'ini:notexist'('obj:sandw4','p17').
'ini:not_allergic_gluten'('obj:child3','p17').
'ini:notexist'('obj:sandw2','p17').
'ini:waiting'('obj:child4','obj:table1','p17').
'ini:notexist'('obj:sandw3','p17').
'ini:at_kitchen_content'('obj:content2','p17').
'ini:at_kitchen_content'('obj:content3','p17').
'ini:at_kitchen_bread'('obj:bread3','p17').
'ini:notexist'('obj:sandw1','p17').
'ini:not_allergic_gluten'('obj:child2','p17').
'ini:not_allergic_gluten'('obj:child1','p17').
'ini:waiting'('obj:child2','obj:table1','p17').
'ini:not_allergic_gluten'('obj:child4','p17').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p17
'goal:served'('obj:child1','p17').
'goal:served'('obj:child2','p17').
'goal:served'('obj:child3','p17').
'goal:served'('obj:child4','p17').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p18
'ini:at'('obj:tray1','obj:kitchen','p18').
'ini:at_kitchen_content'('obj:content1','p18').
'ini:at_kitchen_bread'('obj:bread2','p18').
'ini:at_kitchen_bread'('obj:bread4','p18').
'ini:at_kitchen_content'('obj:content4','p18').
'ini:waiting'('obj:child3','obj:table2','p18').
'ini:at_kitchen_bread'('obj:bread1','p18').
'ini:notexist'('obj:sandw4','p18').
'ini:not_allergic_gluten'('obj:child3','p18').
'ini:notexist'('obj:sandw2','p18').
'ini:waiting'('obj:child4','obj:table3','p18').
'ini:notexist'('obj:sandw3','p18').
'ini:at_kitchen_content'('obj:content2','p18').
'ini:at_kitchen_content'('obj:content3','p18').
'ini:at_kitchen_bread'('obj:bread3','p18').
'ini:notexist'('obj:sandw1','p18').
'ini:not_allergic_gluten'('obj:child2','p18').
'ini:not_allergic_gluten'('obj:child1','p18').
'ini:waiting'('obj:child2','obj:table1','p18').
'ini:waiting'('obj:child1','obj:table1','p18').
'ini:not_allergic_gluten'('obj:child4','p18').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p18
'goal:served'('obj:child1','p18').
'goal:served'('obj:child2','p18').
'goal:served'('obj:child3','p18').
'goal:served'('obj:child4','p18').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p19
'ini:at'('obj:tray1','obj:kitchen','p19').
'ini:at_kitchen_content'('obj:content1','p19').
'ini:at_kitchen_bread'('obj:bread2','p19').
'ini:at_kitchen_bread'('obj:bread4','p19').
'ini:at_kitchen_content'('obj:content4','p19').
'ini:waiting'('obj:child3','obj:table2','p19').
'ini:at_kitchen_bread'('obj:bread1','p19').
'ini:notexist'('obj:sandw4','p19').
'ini:not_allergic_gluten'('obj:child3','p19').
'ini:notexist'('obj:sandw2','p19').
'ini:notexist'('obj:sandw3','p19').
'ini:at_kitchen_content'('obj:content2','p19').
'ini:at_kitchen_content'('obj:content3','p19').
'ini:at_kitchen_bread'('obj:bread3','p19').
'ini:notexist'('obj:sandw1','p19').
'ini:not_allergic_gluten'('obj:child2','p19').
'ini:not_allergic_gluten'('obj:child1','p19').
'ini:waiting'('obj:child1','obj:table1','p19').
'ini:waiting'('obj:child2','obj:table3','p19').
'ini:not_allergic_gluten'('obj:child4','p19').
'ini:waiting'('obj:child4','obj:table2','p19').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p19
'goal:served'('obj:child1','p19').
'goal:served'('obj:child2','p19').
'goal:served'('obj:child3','p19').
'goal:served'('obj:child4','p19').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p20
'ini:at'('obj:tray1','obj:kitchen','p20').
'ini:at_kitchen_content'('obj:content1','p20').
'ini:at_kitchen_bread'('obj:bread2','p20').
'ini:at_kitchen_bread'('obj:bread4','p20').
'ini:at_kitchen_content'('obj:content4','p20').
'ini:at_kitchen_bread'('obj:bread1','p20').
'ini:notexist'('obj:sandw4','p20').
'ini:not_allergic_gluten'('obj:child3','p20').
'ini:notexist'('obj:sandw2','p20').
'ini:waiting'('obj:child3','obj:table1','p20').
'ini:notexist'('obj:sandw3','p20').
'ini:at_kitchen_content'('obj:content2','p20').
'ini:at_kitchen_content'('obj:content3','p20').
'ini:at_kitchen_bread'('obj:bread3','p20').
'ini:notexist'('obj:sandw1','p20').
'ini:not_allergic_gluten'('obj:child2','p20').
'ini:not_allergic_gluten'('obj:child1','p20').
'ini:waiting'('obj:child1','obj:table1','p20').
'ini:waiting'('obj:child2','obj:table3','p20').
'ini:not_allergic_gluten'('obj:child4','p20').
'ini:waiting'('obj:child4','obj:table2','p20').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p20
'goal:served'('obj:child1','p20').
'goal:served'('obj:child2','p20').
'goal:served'('obj:child3','p20').
'goal:served'('obj:child4','p20').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p21
'ini:at'('obj:tray1','obj:kitchen','p21').
'ini:at_kitchen_content'('obj:content1','p21').
'ini:at_kitchen_bread'('obj:bread2','p21').
'ini:at_kitchen_bread'('obj:bread4','p21').
'ini:at_kitchen_content'('obj:content4','p21').
'ini:waiting'('obj:child3','obj:table2','p21').
'ini:at_kitchen_bread'('obj:bread1','p21').
'ini:notexist'('obj:sandw4','p21').
'ini:not_allergic_gluten'('obj:child3','p21').
'ini:notexist'('obj:sandw2','p21').
'ini:waiting'('obj:child4','obj:table1','p21').
'ini:notexist'('obj:sandw3','p21').
'ini:at_kitchen_content'('obj:content2','p21').
'ini:at_kitchen_content'('obj:content3','p21').
'ini:at_kitchen_bread'('obj:bread3','p21').
'ini:notexist'('obj:sandw1','p21').
'ini:not_allergic_gluten'('obj:child2','p21').
'ini:not_allergic_gluten'('obj:child1','p21').
'ini:waiting'('obj:child1','obj:table1','p21').
'ini:waiting'('obj:child2','obj:table3','p21').
'ini:not_allergic_gluten'('obj:child4','p21').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p21
'goal:served'('obj:child1','p21').
'goal:served'('obj:child2','p21').
'goal:served'('obj:child3','p21').
'goal:served'('obj:child4','p21').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p22
'ini:at'('obj:tray1','obj:kitchen','p22').
'ini:at_kitchen_content'('obj:content1','p22').
'ini:at_kitchen_bread'('obj:bread2','p22').
'ini:at_kitchen_bread'('obj:bread4','p22').
'ini:at_kitchen_content'('obj:content4','p22').
'ini:at_kitchen_bread'('obj:bread1','p22').
'ini:notexist'('obj:sandw4','p22').
'ini:not_allergic_gluten'('obj:child3','p22').
'ini:notexist'('obj:sandw2','p22').
'ini:waiting'('obj:child4','obj:table1','p22').
'ini:notexist'('obj:sandw5','p22').
'ini:waiting'('obj:child3','obj:table3','p22').
'ini:notexist'('obj:sandw3','p22').
'ini:at_kitchen_content'('obj:content2','p22').
'ini:at_kitchen_content'('obj:content3','p22').
'ini:at_kitchen_bread'('obj:bread3','p22').
'ini:notexist'('obj:sandw1','p22').
'ini:not_allergic_gluten'('obj:child2','p22').
'ini:not_allergic_glu




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




6').
'ini:at_kitchen_content'('obj:content4','p36').
'ini:at_kitchen_bread'('obj:bread1','p36').
'ini:waiting'('obj:child5','obj:table2','p36').
'ini:notexist'('obj:sandw4','p36').
'ini:at_kitchen_content'('obj:content5','p36').
'ini:not_allergic_gluten'('obj:child3','p36').
'ini:notexist'('obj:sandw2','p36').
'ini:waiting'('obj:child4','obj:table1','p36').
'ini:notexist'('obj:sandw5','p36').
'ini:waiting'('obj:child3','obj:table3','p36').
'ini:notexist'('obj:sandw3','p36').
'ini:at_kitchen_content'('obj:content2','p36').
'ini:at_kitchen_content'('obj:content3','p36').
'ini:at_kitchen_bread'('obj:bread3','p36').
'ini:notexist'('obj:sandw1','p36').
'ini:not_allergic_gluten'('obj:child2','p36').
'ini:not_allergic_gluten'('obj:child1','p36').
'ini:waiting'('obj:child2','obj:table1','p36').
'ini:waiting'('obj:child1','obj:table1','p36').
'ini:no_gluten_bread'('obj:bread3','p36').
'ini:notexist'('obj:sandw7','p36').
'ini:not_allergic_gluten'('obj:child4','p36').
'ini:notexist'('obj:sandw6','p36').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p36
'goal:served'('obj:child1','p36').
'goal:served'('obj:child2','p36').
'goal:served'('obj:child3','p36').
'goal:served'('obj:child4','p36').
'goal:served'('obj:child5','p36').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p37
'ini:at_kitchen_bread'('obj:bread5','p37').
'ini:at'('obj:tray1','obj:kitchen','p37').
'ini:waiting'('obj:child5','obj:table1','p37').
'ini:allergic_gluten'('obj:child5','p37').
'ini:at_kitchen_content'('obj:content1','p37').
'ini:at_kitchen_bread'('obj:bread2','p37').
'ini:at_kitchen_bread'('obj:bread4','p37').
'ini:at_kitchen_content'('obj:content4','p37').
'ini:waiting'('obj:child3','obj:table2','p37').
'ini:at_kitchen_bread'('obj:bread1','p37').
'ini:notexist'('obj:sandw4','p37').
'ini:at_kitchen_content'('obj:content5','p37').
'ini:not_allergic_gluten'('obj:child3','p37').
'ini:no_gluten_bread'('obj:bread1','p37').
'ini:no_gluten_content'('obj:content1','p37').
'ini:notexist'('obj:sandw2','p37').
'ini:notexist'('obj:sandw6','p37').
'ini:notexist'('obj:sandw5','p37').
'ini:notexist'('obj:sandw3','p37').
'ini:at_kitchen_content'('obj:content2','p37').
'ini:at_kitchen_content'('obj:content3','p37').
'ini:at_kitchen_bread'('obj:bread3','p37').
'ini:notexist'('obj:sandw1','p37').
'ini:not_allergic_gluten'('obj:child2','p37').
'ini:not_allergic_gluten'('obj:child1','p37').
'ini:waiting'('obj:child1','obj:table1','p37').
'ini:waiting'('obj:child2','obj:table3','p37').
'ini:notexist'('obj:sandw7','p37').
'ini:not_allergic_gluten'('obj:child4','p37').
'ini:waiting'('obj:child4','obj:table2','p37').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p37
'goal:served'('obj:child1','p37').
'goal:served'('obj:child2','p37').
'goal:served'('obj:child3','p37').
'goal:served'('obj:child4','p37').
'goal:served'('obj:child5','p37').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p38
'ini:at_kitchen_bread'('obj:bread5','p38').
'ini:at'('obj:tray1','obj:kitchen','p38').
'ini:waiting'('obj:child5','obj:table1','p38').
'ini:at_kitchen_content'('obj:content1','p38').
'ini:no_gluten_bread'('obj:bread5','p38').
'ini:at_kitchen_bread'('obj:bread2','p38').
'ini:at_kitchen_bread'('obj:bread4','p38').
'ini:no_gluten_content'('obj:content3','p38').
'ini:at_kitchen_content'('obj:content4','p38').
'ini:waiting'('obj:child3','obj:table2','p38').
'ini:at_kitchen_bread'('obj:bread1','p38').
'ini:notexist'('obj:sandw4','p38').
'ini:at_kitchen_content'('obj:content5','p38').
'ini:not_allergic_gluten'('obj:child5','p38').
'ini:not_allergic_gluten'('obj:child3','p38').
'ini:allergic_gluten'('obj:child4','p38').
'ini:notexist'('obj:sandw2','p38').
'ini:waiting'('obj:child4','obj:table3','p38').
'ini:notexist'('obj:sandw5','p38').
'ini:notexist'('obj:sandw3','p38').
'ini:at_kitchen_content'('obj:content2','p38').
'ini:at_kitchen_content'('obj:content3','p38').
'ini:at_kitchen_bread'('obj:bread3','p38').
'ini:notexist'('obj:sandw1','p38').
'ini:waiting'('obj:child1','obj:table3','p38').
'ini:not_allergic_gluten'('obj:child2','p38').
'ini:not_allergic_gluten'('obj:child1','p38').
'ini:waiting'('obj:child2','obj:table3','p38').
'ini:notexist'('obj:sandw7','p38').
'ini:notexist'('obj:sandw6','p38').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p38
'goal:served'('obj:child1','p38').
'goal:served'('obj:child2','p38').
'goal:served'('obj:child3','p38').
'goal:served'('obj:child4','p38').
'goal:served'('obj:child5','p38').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p39
'ini:at_kitchen_bread'('obj:bread5','p39').
'ini:at_kitchen_content'('obj:content6','p39').
'ini:at'('obj:tray1','obj:kitchen','p39').
'ini:waiting'('obj:child5','obj:table1','p39').
'ini:allergic_gluten'('obj:child5','p39').
'ini:at_kitchen_content'('obj:content1','p39').
'ini:allergic_gluten'('obj:child3','p39').
'ini:no_gluten_bread'('obj:bread6','p39').
'ini:at_kitchen_bread'('obj:bread2','p39').
'ini:at_kitchen_bread'('obj:bread4','p39').
'ini:no_gluten_content'('obj:content3','p39').
'ini:at_kitchen_content'('obj:content4','p39').
'ini:waiting'('obj:child3','obj:table2','p39').
'ini:at_kitchen_bread'('obj:bread1','p39').
'ini:not_allergic_gluten'('obj:child6','p39').
'ini:notexist'('obj:sandw4','p39').
'ini:at_kitchen_content'('obj:content5','p39').
'ini:no_gluten_bread'('obj:bread1','p39').
'ini:notexist'('obj:sandw2','p39').
'ini:waiting'('obj:child4','obj:table1','p39').
'ini:notexist'('obj:sandw5','p39').
'ini:waiting'('obj:child6','obj:table3','p39').
'ini:notexist'('obj:sandw3','p39').
'ini:at_kitchen_content'('obj:content2','p39').
'ini:at_kitchen_content'('obj:content3','p39').
'ini:at_kitchen_bread'('obj:bread3','p39').
'ini:notexist'('obj:sandw1','p39').
'ini:not_allergic_gluten'('obj:child2','p39').
'ini:no_gluten_content'('obj:content5','p39').
'ini:not_allergic_gluten'('obj:child1','p39').
'ini:waiting'('obj:child2','obj:table1','p39').
'ini:waiting'('obj:child1','obj:table1','p39').
'ini:notexist'('obj:sandw7','p39').
'ini:not_allergic_gluten'('obj:child4','p39').
'ini:notexist'('obj:sandw6','p39').
'ini:at_kitchen_bread'('obj:bread6','p39').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p39
'goal:served'('obj:child1','p39').
'goal:served'('obj:child2','p39').
'goal:served'('obj:child3','p39').
'goal:served'('obj:child4','p39').
'goal:served'('obj:child5','p39').
'goal:served'('obj:child6','p39').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p40
'ini:at_kitchen_bread'('obj:bread5','p40').
'ini:at_kitchen_content'('obj:content6','p40').
'ini:at'('obj:tray1','obj:kitchen','p40').
'ini:allergic_gluten'('obj:child5','p40').
'ini:at_kitchen_content'('obj:content1','p40').
'ini:at_kitchen_bread'('obj:bread2','p40').
'ini:at_kitchen_bread'('obj:bread4','p40').
'ini:no_gluten_content'('obj:content2','p40').
'ini:at_kitchen_content'('obj:content4','p40').
'ini:no_gluten_bread'('obj:bread2','p40').
'ini:waiting'('obj:child1','obj:table2','p40').
'ini:waiting'('obj:child6','obj:table2','p40').
'ini:at_kitchen_bread'('obj:bread1','p40').
'ini:not_allergic_gluten'('obj:child6','p40').
'ini:allergic_gluten'('obj:child2','p40').
'ini:no_gluten_content'('obj:content6','p40').
'ini:notexist'('obj:sandw4','p40').
'ini:at_kitchen_content'('obj:content5','p40').
'ini:not_allergic_gluten'('obj:child3','p40').
'ini:no_gluten_bread'('obj:bread1','p40').
'ini:notexist'('obj:sandw2','p40').
'ini:waiting'('obj:child4','obj:table1','p40').
'ini:notexist'('obj:sandw5','p40').
'ini:waiting'('obj:child3','obj:table3','p40').
'ini:notexist'('obj:sandw3','p40').
'ini:at_kitchen_content'('obj:content2','p40').
'ini:at_kitchen_content'('obj:content3','p40').
'ini:at_kitchen_bread'('obj:bread3','p40').
'ini:waiting'('obj:child5','obj:table3','p40').
'ini:notexist'('obj:sandw1','p40').
'ini:not_allergic_gluten'('obj:child1','p40').
'ini:waiting'('obj:child2','obj:table1','p40').
'ini:notexist'('obj:sandw7','p40').
'ini:not_allergic_gluten'('obj:child4','p40').
'ini:notexist'('obj:sandw6','p40').
'ini:at_kitchen_bread'('obj:bread6','p40').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p40
'goal:served'('obj:child1','p40').
'goal:served'('obj:child2','p40').
'goal:served'('obj:child3','p40').
'goal:served'('obj:child4','p40').
'goal:served'('obj:child5','p40').
'goal:served'('obj:child6','p40').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p41
'ini:at_kitchen_bread'('obj:bread5','p41').
'ini:at_kitchen_content'('obj:content6','p41').
'ini:at'('obj:tray1','obj:kitchen','p41').
'ini:waiting'('obj:child5','obj:table1','p41').
'ini:allergic_gluten'('obj:child3','p41').
'ini:at_kitchen_content'('obj:content1','p41').
'ini:at_kitchen_bread'('obj:bread2','p41').
'ini:at_kitchen_bread'('obj:bread4','p41').
'ini:no_gluten_content'('obj:content2','p41').
'ini:at_kitchen_content'('obj:content4','p41').
'ini:no_gluten_bread'('obj:bread2','p41').
'ini:waiting'('obj:child1','obj:table2','p41').
'ini:waiting'('obj:child6','obj:table2','p41').
'ini:at_kitchen_bread'('obj:bread1','p41').
'ini:not_allergic_gluten'('obj:child6','p41').
'ini:allergic_gluten'('obj:child2','p41').
'ini:notexist'('obj:sandw4','p41').
'ini:at_kitchen_content'('obj:content5','p41').
'ini:not_allergic_gluten'('obj:child5','p41').
'ini:no_gluten_bread'('obj:bread1','p41').
'ini:no_gluten_content'('obj:content1','p41').
'ini:notexist'('obj:sandw2','p41').
'ini:notexist'('obj:sandw6','p41').
'ini:notexist'('obj:sandw5','p41').
'ini:waiting'('obj:child3','obj:table3','p41').
'ini:notexist'('obj:sandw3','p41').
'ini:at_kitchen_content'('obj:content2','p41').
'ini:at_kitchen_content'('obj:content3','p41').
'ini:at_kitchen_bread'('obj:bread3','p41').
'ini:notexist'('obj:sandw1','p41').
'ini:not_allergic_gluten'('obj:child1','p41').
'ini:waiting'('obj:child2','obj:table3','p41').
'ini:notexist'('obj:sandw7','p41').
'ini:not_allergic_gluten'('obj:child4','p41').
'ini:waiting'('obj:child4','obj:table2','p41').
'ini:at_kitchen_bread'('obj:bread6','p41').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p41
'goal:served'('obj:child1','p41').
'goal:served'('obj:child2','p41').
'goal:served'('obj:child3','p41').
'goal:served'('obj:child4','p41').
'goal:served'('obj:child5','p41').
'goal:served'('obj:child6','p41').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p42
'ini:at_kitchen_bread'('obj:bread5','p42').
'ini:allergic_gluten'('obj:child6','p42').
'ini:at_kitchen_content'('obj:content6','p42').
'ini:at'('obj:tray1','obj:kitchen','p42').
'ini:allergic_gluten'('obj:child5','p42').
'ini:at_kitchen_content'('obj:content1','p42').
'ini:no_gluten_bread'('obj:bread5','p42').
'ini:at_kitchen_bread'('obj:bread2','p42').
'ini:at_kitchen_bread'('obj:bread4','p42').
'ini:no_gluten_content'('obj:content3','p42').
'ini:no_gluten_content'('obj:content2','p42').
'ini:at_kitchen_content'('obj:content4','p42').
'ini:waiting'('obj:child1','obj:table2','p42').
'ini:no_gluten_bread'('obj:bread4','p42').
'ini:waiting'('obj:child3','obj:table2','p42').
'ini:at_kitchen_bread'('obj:bread1','p42').
'ini:notexist'('obj:sandw4','p42').
'ini:at_kitchen_content'('obj:content5','p42').
'ini:not_allergic_gluten'('obj:child3','p42').
'ini:notexist'('obj:sandw2','p42').
'ini:notexist'('obj:sandw6','p42').
'ini:notexist'('obj:sandw5','p42').
'ini:notexist'('obj:sandw3','p42').
'ini:at_kitchen_content'('obj:content2','p42').
'ini:at_kitchen_content'('obj:content3','p42').
'ini:at_kitchen_bread'('obj:bread3','p42').
'ini:waiting'('obj:child5','obj:table3','p42').
'ini:notexist'('obj:sandw1','p42').
'ini:not_allergic_gluten'('obj:child2','p42').
'ini:not_allergic_gluten'('obj:child1','p42').
'ini:waiting'('obj:child2','obj:table3','p42').
'ini:notexist'('obj:sandw7','p42').
'ini:waiting'('obj:child6','obj:table1','p42').
'ini:not_allergic_gluten'('obj:child4','p42').
'ini:waiting'('obj:child4','obj:table2','p42').
'ini:at_kitchen_bread'('obj:bread6','p42').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p42
'goal:served'('obj:child1','p42').
'goal:served'('obj:child2','p42').
'goal:served'('obj:child3','p42').
'goal:served'('obj:child4','p42').
'goal:served'('obj:child5','p42').
'goal:served'('obj:child6','p42').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p43
'ini:at_kitchen_bread'('obj:bread5','p43').
'ini:allergic_gluten'('obj:child6','p43').
'ini:at_kitchen_content'('obj:content6','p43').
'ini:at'('obj:tray1','obj:kitchen','p43').
'ini:waiting'('obj:child5','obj:table1','p43').
'ini:at_kitchen_content'('obj:content1','p43').
'ini:no_gluten_bread'('obj:bread6','p43').
'ini:no_gluten_bread'('obj:bread5','p43').
'ini:notexist'('obj:sandw8','p43').
'ini:at_kitchen_bread'('obj:bread4','p43').
'ini:at_kitchen_bread'('obj:bread2','p43').
'ini:at_kitchen_content'('obj:content4','p43').
'ini:waiting'('obj:child6','obj:table2','p43').
'ini:waiting'('obj:child2','obj:table2','p43').
'ini:at_kitchen_bread'('obj:bread1','p43').
'ini:no_gluten_content'('obj:content6','p43').
'ini:notexist'('obj:sandw4','p43').
'ini:at_kitchen_content'('obj:content5','p43').
'ini:not_allergic_gluten'('obj:child5','p43').
'ini:not_allergic_gluten'('obj:child3','p43').
'ini:allergic_gluten'('obj:child4','p43').
'ini:notexist'('obj:sandw2','p43').
'ini:waiting'('obj:child4','obj:table1','p43').
'ini:notexist'('obj:sandw5','p43').
'ini:waiting'('obj:child3','obj:table1','p43').
'ini:no_gluten_content'('obj:content4','p43').
'ini:notexist'('obj:sandw3','p43').
'ini:at'('obj:tray2','obj:kitchen','p43').
'ini:at_kitchen_content'('obj:content2','p43').
'ini:at_kitchen_content'('obj:content3','p43').
'ini:at_kitchen_bread'('obj:bread3','p43').
'ini:notexist'('obj:sandw1','p43').
'ini:waiting'('obj:child1','obj:table3','p43').
'ini:not_allergic_gluten'('obj:child2','p43').
'ini:not_allergic_gluten'('obj:child1','p43').
'ini:notexist'('obj:sandw7','p43').
'ini:notexist'('obj:sandw6','p43').
'ini:at_kitchen_bread'('obj:bread6','p43').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p43
'goal:served'('obj:child1','p43').
'goal:served'('obj:child2','p43').
'goal:served'('obj:child3','p43').
'goal:served'('obj:child4','p43').
'goal:served'('obj:child5','p43').
'goal:served'('obj:child6','p43').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p44
'ini:at_kitchen_bread'('obj:bread5','p44').
'ini:allergic_gluten'('obj:child6','p44').
'ini:at_kitchen_content'('obj:content6','p44').
'ini:at'('obj:tray1','obj:kitchen','p44').
'ini:allergic_gluten'('obj:child3','p44').
'ini:at_kitchen_content'('obj:content1','p44').
'ini:notexist'('obj:sandw8','p44').
'ini:at_kitchen_bread'('obj:bread4','p44').
'ini:at_kitchen_bread'('obj:bread2','p44').
'ini:at_kitchen_content'('obj:content4','p44').
'ini:no_gluten_bread'('obj:bread4','p44').
'ini:at_kitchen_bread'('obj:bread1','p44').
'ini:waiting'('obj:child5','obj:table2','p44').
'ini:notexist'('obj:sandw4','p44').
'ini:at_kitchen_content'('obj:content5','p44').
'ini:not_allergic_gluten'('obj:child5','p44').
'ini:no_gluten_bread'('obj:bread1','p44').
'ini:no_gluten_content'('obj:content1','p44').
'ini:notexist'('obj:sandw2','p44').
'ini:notexist'('obj:sandw6','p44').
'ini:notexist'('obj:sandw5','p44').
'ini:waiting'('obj:child6','obj:table3','p44').
'ini:waiting'('obj:child3','obj:table1','p44').
'ini:notexist'('obj:sandw3','p44').
'ini:at'('obj:tray2','obj:kitchen','p44').
'ini:at_kitchen_content'('obj:content2','p44').
'ini:at_kitchen_content'('obj:content3','p44').
'ini:at_kitchen_bread'('obj:bread3','p44').
'ini:notexist'('obj:sandw1','p44').
'ini:not_allergic_gluten'('obj:child2','p44').
'ini:no_gluten_content'('obj:content5','p44').
'ini:not_allergic_gluten'('obj:child1','p44').
'ini:waiting'('obj:child2','obj:table1','p44').
'ini:waiting'('obj:child1','obj:table1','p44').
'ini:notexist'('obj:sandw7','p44').
'ini:not_allergic_gluten'('obj:child4','p44').
'ini:waiting'('obj:child4','obj:table2','p44').
'ini:at_kitchen_bread'('obj:bread6','p44').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p44
'goal:served'('obj:child1','p44').
'goal:served'('obj:child2','p44').
'goal:served'('obj:child3','p44').
'goal:served'('obj:child4','p44').
'goal:served'('obj:child5','p44').
'goal:served'('obj:child6','p44').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p45
'ini:at_kitchen_bread'('obj:bread5','p45').
'ini:at_kitchen_content'('obj:content6','p45').
'ini:at'('obj:tray1','obj:kitchen','p45').
'ini:allergic_gluten'('obj:child5','p45').
'ini:at_kitchen_content'('obj:content1','p45').
'ini:no_gluten_bread'('obj:bread6','p45').
'ini:no_gluten_bread'('obj:bread5','p45').
'ini:notexist'('obj:sandw8','p45').
'ini:at_kitchen_bread'('obj:bread4','p45').
'ini:at_kitchen_bread'('obj:bread2','p45').
'ini:no_gluten_content'('obj:content3','p45').
'ini:at_kitchen_content'('obj:content4','p45').
'ini:waiting'('obj:child1','obj:table2','p45').
'ini:waiting'('obj:child6','obj:table2','p45').
'ini:waiting'('obj:child3','obj:table2','p45').
'ini:at_kitchen_bread'('obj:bread1','p45').
'ini:not_allergic_gluten'('obj:child6','p45').
'ini:allergic_gluten'('obj:child2','p45').
'ini:waiting'('obj:child5','obj:table2','p45').
'ini:notexist'('obj:sandw4','p45').
'ini:at_kitchen_content'('obj:content5','p45').
'ini:not_allergic_gluten'('obj:child3','p45').
'ini:no_gluten_content'('obj:content1','p45').
'ini:notexist'('obj:sandw2','p45').
'ini:waiting'('obj:child4','obj:table1','p45').
'ini:notexist'('obj:sandw5','p45').
'ini:notexist'('obj:sandw3','p45').
'ini:at'('obj:tray2','obj:kitchen','p45').
'ini:at_kitchen_content'('obj:content2','p45').
'ini:at_kitchen_content'('obj:content3','p45').
'ini:at_kitchen_bread'('obj:bread3','p45').
'ini:notexist'('obj:sandw1','p45').
'ini:not_allergic_gluten'('obj:child1','p45').
'ini:waiting'('obj:child2','obj:table1','p45').
'ini:notexist'('obj:sandw7','p45').
'ini:not_allergic_gluten'('obj:child4','p45').
'ini:notexist'('obj:sandw6','p45').
'ini:at_kitchen_bread'('obj:bread6','p45').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p45
'goal:served'('obj:child1','p45').
'goal:served'('obj:child2','p45').
'goal:served'('obj:child3','p45').
'goal:served'('obj:child4','p45').
'goal:served'('obj:child5','p45').
'goal:served'('obj:child6','p45').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p46
'ini:at_kitchen_bread'('obj:bread5','p46').
'ini:at_kitchen_content'('obj:content6','p46').
'ini:at'('obj:tray1','obj:kitchen','p46').
'ini:allergic_gluten'('obj:child3','p46').
'ini:at_kitchen_content'('obj:content1','p46').
'ini:no_gluten_bread'('obj:bread6','p46').
'ini:notexist'('obj:sandw8','p46').
'ini:at_kitchen_bread'('obj:bread4','p46').
'ini:at_kitchen_bread'('obj:bread2','p46').
'ini:at_kitchen_content'('obj:content4','p46').
'ini:waiting'('obj:child3','obj:table2','p46').
'ini:at_kitchen_bread'('obj:bread1','p46').
'ini:not_allergic_gluten'('obj:child6','p46').
'ini:notexist'('obj:sandw4','p46').
'ini:at_kitchen_content'('obj:content5','p46').
'ini:not_allergic_gluten'('obj:child5','p46').
'ini:allergic_gluten'('obj:child4','p46').
'ini:no_gluten_bread'('obj:bread1','p46').
'ini:no_gluten_content'('obj:content1','p46').
'ini:notexist'('obj:sandw2','p46').
'ini:notexist'('obj:sandw5','p46').
'ini:notexist'('obj:sandw6','p46').
'ini:notexist'('obj:sandw3','p46').
'ini:at'('obj:tray2','obj:kitchen','p46').
'ini:at_kitchen_content'('obj:content2','p46').
'ini:at_kitchen_content'('obj:content3','p46').
'ini:at_kitchen_bread'('obj:bread3','p46').
'ini:waiting'('obj:child5','obj:table3','p46').
'ini:notexist'('obj:sandw1','p46').
'ini:waiting'('obj:child1','obj:table3','p46').
'ini:not_allergic_gluten'('obj:child2','p46').
'ini:no_gluten_content'('obj:content5','p46').
'ini:not_allergic_gluten'('obj:child1','p46').
'ini:waiting'('obj:child2','obj:table3','p46').
'ini:waiting'('obj:child6','obj:table1','p46').
'ini:notexist'('obj:sandw7','p46').
'ini:waiting'('obj:child4','obj:table2','p46').
'ini:at_kitchen_bread'('obj:bread6','p46').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p46
'goal:served'('obj:child1','p46').
'goal:served'('obj:child2','p46').
'goal:served'('obj:child3','p46').
'goal:served'('obj:child4','p46').
'goal:served'('obj:child5','p46').
'goal:served'('obj:child6','p46').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p47
'ini:at_kitchen_bread'('obj:bread5','p47').
'ini:at_kitchen_content'('obj:content6','p47').
'ini:at'('obj:tray1','obj:kitchen','p47').
'ini:allergic_gluten'('obj:child3','p47').
'ini:at_kitchen_content'('obj:content1','p47').
'ini:notexist'('obj:sandw8','p47').
'ini:at_kitchen_bread'('obj:bread4','p47').
'ini:at_kitchen_bread'('obj:bread2','p47').
'ini:at_kitchen_content'('obj:content4','p47').
'ini:no_gluten_bread'('obj:bread2','p47').
'ini:waiting'('obj:child6','obj:table2','p47').
'ini:waiting'('obj:child3','obj:table2','p47').
'ini:at_kitchen_bread'('obj:bread1','p47').
'ini:not_allergic_gluten'('obj:child6','p47').
'ini:allergic_gluten'('obj:child1','p47').
'ini:notexist'('obj:sandw4','p47').
'ini:at_kitchen_content'('obj:content5','p47').
'ini:not_allergic_gluten'('obj:child5','p47').
'ini:no_gluten_bread'('obj:bread1','p47').
'ini:notexist'('obj:sandw2','p47').
'ini:waiting'('obj:child4','obj:table3','p47').
'ini:notexist'('obj:sandw5','p47').
'ini:no_gluten_content'('obj:content4','p47').
'ini:notexist'('obj:sandw3','p47').
'ini:at'('obj:tray2','obj:kitchen','p47').
'ini:at_kitchen_content'('obj:content2','p47').
'ini:at_kitchen_content'('obj:content3','p47').
'ini:at_kitchen_bread'('obj:bread3','p47').
'ini:waiting'('obj:child5','obj:table3','p47').
'ini:notexist'('obj:sandw1','p47').
'ini:waiting'('obj:child1','obj:table3','p47').
'ini:not_allergic_gluten'('obj:child2','p47').
'ini:no_gluten_content'('obj:content5','p47').
'ini:waiting'('obj:child2','obj:table3','p47').
'ini:notexist'('obj:sandw7','p47').
'ini:not_allergic_gluten'('obj:child4','p47').
'ini:notexist'('obj:sandw6','p47').
'ini:at_kitchen_bread'('obj:bread6','p47').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p47
'goal:served'('obj:child1','p47').
'goal:served'('obj:child2','p47').
'goal:served'('obj:child3','p47').
'goal:served'('obj:child4','p47').
'goal:served'('obj:child5','p47').
'goal:served'('obj:child6','p47').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p48
'ini:at_kitchen_bread'('obj:bread5','p48').
'ini:allergic_gluten'('obj:child6','p48').
'ini:at_kitchen_content'('obj:content6','p48').
'ini:at'('obj:tray1','obj:kitchen','p48').
'ini:at_kitchen_content'('obj:content1','p48').
'ini:no_gluten_bread'('obj:bread6','p48').
'ini:notexist'('obj:sandw8','p48').
'ini:at_kitchen_bread'('obj:bread4','p48').
'ini:at_kitchen_bread'('obj:bread2','p48').
'ini:no_gluten_content'('obj:content3','p48').
'ini:at_kitchen_content'('obj:content4','p48').
'ini:waiting'('obj:child1','obj:table2','p48').
'ini:waiting'('obj:child6','obj:table2','p48').
'ini:at_kitchen_bread'('obj:bread1','p48').
'ini:allergic_gluten'('obj:child2','p48').
'ini:notexist'('obj:sandw4','p48').
'ini:at_kitchen_content'('obj:content5','p48').
'ini:not_allergic_gluten'('obj:child5','p48').
'ini:not_allergic_gluten'('obj:child3','p48').
'ini:notexist'('obj:sandw2','p48').
'ini:waiting'('obj:child4','obj:table1','p48').
'ini:notexist'('obj:sandw5','p48').
'ini:waiting'('obj:child3','obj:table1','p48').
'ini:notexist'('obj:sandw3','p48').
'ini:at'('obj:tray2','obj:kitchen','p48').
'ini:at_kitchen_content'('obj:content2','p48').
'ini:at_kitchen_content'('obj:content3','p48').
'ini:at_kitchen_bread'('obj:bread3','p48').
'ini:waiting'('obj:child5','obj:table3','p48').
'ini:notexist'('obj:sandw1','p48').
'ini:no_gluten_content'('obj:content5','p48').
'ini:not_allergic_gluten'('obj:child1','p48').
'ini:waiting'('obj:child2','obj:table1','p48').
'ini:notexist'('obj:sandw7','p48').
'ini:no_gluten_bread'('obj:bread3','p48').
'ini:not_allergic_gluten'('obj:child4','p48').
'ini:notexist'('obj:sandw6','p48').
'ini:at_kitchen_bread'('obj:bread6','p48').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p48
'goal:served'('obj:child1','p48').
'goal:served'('obj:child2','p48').
'goal:served'('obj:child3','p48').
'goal:served'('obj:child4','p48').
'goal:served'('obj:child5','p48').
'goal:served'('obj:child6','p48').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p49
'ini:at_kitchen_bread'('obj:bread5','p49').
'ini:at_kitchen_content'('obj:content6','p49').
'ini:at'('obj:tray1','obj:kitchen','p49').
'ini:waiting'('obj:child5','obj:table1','p49').
'ini:allergic_gluten'('obj:child5','p49').
'ini:at_kitchen_content'('obj:content1','p49').
'ini:no_gluten_bread'('obj:bread6','p49').
'ini:notexist'('obj:sandw8','p49').
'ini:at_kitchen_bread'('obj:bread4','p49').
'ini:at_kitchen_bread'('obj:bread2','p49').
'ini:no_gluten_content'('obj:content3','p49').
'ini:at_kitchen_content'('obj:content4','p49').
'ini:no_gluten_bread'('obj:bread2','p49').
'ini:waiting'('obj:child6','obj:table2','p49').
'ini:at_kitchen_bread'('obj:bread1','p49').
'ini:not_allergic_gluten'('obj:child6','p49').
'ini:notexist'('obj:sandw4','p49').
'ini:at_kitchen_content'('obj:content5','p49').
'ini:not_allergic_gluten'('obj:child3','p49').
'ini:allergic_gluten'('obj:child4','p49').
'ini:notexist'('obj:sandw2','p49').
'ini:notexist'('obj:sandw6','p49').
'ini:notexist'('obj:sandw5','p49').
'ini:waiting'('obj:child3','obj:table1','p49').
'ini:no_gluten_content'('obj:content4','p49').
'ini:notexist'('obj:sandw3','p49').
'ini:at'('obj:tray2','obj:kitchen','p49').
'ini:at_kitchen_content'('obj:content2','p49').
'ini:at_kitchen_content'('obj:content3','p49').
'ini:at_kitchen_bread'('obj:bread3','p49').
'ini:notexist'('obj:sandw1','p49').
'ini:not_allergic_gluten'('obj:child2','p49').
'ini:not_allergic_gluten'('obj:child1','p49').
'ini:waiting'('obj:child1','obj:table1','p49').
'ini:waiting'('obj:child2','obj:table3','p49').
'ini:notexist'('obj:sandw7','p49').
'ini:waiting'('obj:child4','obj:table2','p49').
'ini:at_kitchen_bread'('obj:bread6','p49').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p49
'goal:served'('obj:child1','p49').
'goal:served'('obj:child2','p49').
'goal:served'('obj:child3','p49').
'goal:served'('obj:child4','p49').
'goal:served'('obj:child5','p49').
'goal:served'('obj:child6','p49').
