%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% specify tree type:
:- set(tree_type,class_probability).
:- set(classes,[ground,dont_ground]).
:- set(dependent,4). % second arg of class is to predicted

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% modes:
:- discontiguous('ini:connected'/3).
:- discontiguous('goal:connected'/3).
:- modeb(*, 'ini:connected'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:connected'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:connected'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:connected'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:at-robot'/2).
:- discontiguous('goal:at-robot'/2).
:- modeb(*, 'ini:at-robot'(+'type:object', +task_id)).
:- modeb(*, 'goal:at-robot'(+'type:object', +task_id)).
:- discontiguous('ini:visited'/2).
:- discontiguous('goal:visited'/2).
:- modeb(*, 'ini:visited'(+'type:object', +task_id)).
:- modeb(*, 'goal:visited'(+'type:object', +task_id)).

% types and constants

:- modeh(1, class(+'type:object', +'type:object', +task_id, -class)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% determinations:
:- determination(class/4, 'ini:connected'/3).
:- determination(class/4, 'goal:connected'/3).
:- determination(class/4, 'ini:at-robot'/2).
:- determination(class/4, 'goal:at-robot'/2).
:- determination(class/4, 'ini:visited'/2).
:- determination(class/4, 'goal:visited'/2).

'type:object'('obj:loc-x0-y0').
'type:object'('obj:loc-x0-y1').
'type:object'('obj:loc-x1-y0').
'type:object'('obj:loc-x1-y1').
'type:object'('obj:loc-x0-y2').
'type:object'('obj:loc-x1-y2').
'type:object'('obj:loc-x2-y0').
'type:object'('obj:loc-x2-y1').
'type:object'('obj:loc-x2-y2').
'type:object'('obj:loc-x0-y3').
'type:object'('obj:loc-x1-y3').
'type:object'('obj:loc-x2-y3').
'type:object'('obj:loc-x3-y0').
'type:object'('obj:loc-x3-y1').
'type:object'('obj:loc-x3-y2').
'type:object'('obj:loc-x3-y3').
'type:object'('obj:loc-x0-y4').
'type:object'('obj:loc-x1-y4').
'type:object'('obj:loc-x2-y4').
'type:object'('obj:loc-x3-y4').
'type:object'('obj:loc-x4-y0').
'type:object'('obj:loc-x4-y1').
'type:object'('obj:loc-x4-y2').
'type:object'('obj:loc-x4-y3').
'type:object'('obj:loc-x4-y4').
'type:object'('obj:loc-x0-y5').
'type:object'('obj:loc-x1-y5').
'type:object'('obj:loc-x2-y5').
'type:object'('obj:loc-x3-y5').
'type:object'('obj:loc-x4-y5').
'type:object'('obj:loc-x5-y0').
'type:object'('obj:loc-x5-y1').
'type:object'('obj:loc-x5-y2').
'type:object'('obj:loc-x5-y3').
'type:object'('obj:loc-x5-y4').
'type:object'('obj:loc-x5-y5').


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p01
'ini:at-robot'('obj:loc-x0-y0','p01').
'ini:connected'('obj:loc-x1-y1','obj:loc-x0-y1','p01').
'ini:connected'('obj:loc-x1-y0','obj:loc-x1-y1','p01').
'ini:connected'('obj:loc-x0-y1','obj:loc-x1-y1','p01').
'ini:connected'('obj:loc-x0-y0','obj:loc-x0-y1','p01').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y0','p01').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y0','p01').
'ini:connected'('obj:loc-x1-y0','obj:loc-x0-y0','p01').
'ini:connected'('obj:loc-x0-y0','obj:loc-x1-y0','p01').
'ini:visited'('obj:loc-x0-y0','p01').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p01
'goal:visited'('obj:loc-x0-y0','p01').
'goal:visited'('obj:loc-x0-y1','p01').
'goal:visited'('obj:loc-x1-y0','p01').
'goal:visited'('obj:loc-x1-y1','p01').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p02
'ini:connected'('obj:loc-x1-y1','obj:loc-x0-y1','p02').
'ini:connected'('obj:loc-x1-y0','obj:loc-x1-y1','p02').
'ini:connected'('obj:loc-x0-y1','obj:loc-x1-y1','p02').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y0','p02').
'ini:connected'('obj:loc-x1-y2','obj:loc-x1-y1','p02').
'ini:connected'('obj:loc-x0-y2','obj:loc-x1-y2','p02').
'ini:connected'('obj:loc-x1-y0','obj:loc-x2-y0','p02').
'ini:connected'('obj:loc-x0-y0','obj:loc-x1-y0','p02').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y2','p02').
'ini:connected'('obj:loc-x1-y2','obj:loc-x0-y2','p02').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y0','p02').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y2','p02').
'ini:connected'('obj:loc-x0-y0','obj:loc-x0-y1','p02').
'ini:connected'('obj:loc-x2-y2','obj:loc-x2-y1','p02').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y0','p02').
'ini:connected'('obj:loc-x1-y0','obj:loc-x0-y0','p02').
'ini:at-robot'('obj:loc-x1-y0','p02').
'ini:connected'('obj:loc-x1-y2','obj:loc-x2-y2','p02').
'ini:connected'('obj:loc-x2-y0','obj:loc-x2-y1','p02').
'ini:connected'('obj:loc-x2-y0','obj:loc-x1-y0','p02').
'ini:connected'('obj:loc-x0-y2','obj:loc-x0-y1','p02').
'ini:connected'('obj:loc-x1-y1','obj:loc-x2-y1','p02').
'ini:connected'('obj:loc-x2-y1','obj:loc-x1-y1','p02').
'ini:visited'('obj:loc-x1-y0','p02').
'ini:connected'('obj:loc-x2-y2','obj:loc-x1-y2','p02').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y2','p02').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p02
'goal:visited'('obj:loc-x0-y0','p02').
'goal:visited'('obj:loc-x0-y1','p02').
'goal:visited'('obj:loc-x0-y2','p02').
'goal:visited'('obj:loc-x1-y0','p02').
'goal:visited'('obj:loc-x1-y1','p02').
'goal:visited'('obj:loc-x1-y2','p02').
'goal:visited'('obj:loc-x2-y0','p02').
'goal:visited'('obj:loc-x2-y1','p02').
'goal:visited'('obj:loc-x2-y2','p02').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p03
'ini:connected'('obj:loc-x1-y1','obj:loc-x0-y1','p03').
'ini:connected'('obj:loc-x2-y3','obj:loc-x1-y3','p03').
'ini:connected'('obj:loc-x1-y0','obj:loc-x1-y1','p03').
'ini:connected'('obj:loc-x0-y1','obj:loc-x1-y1','p03').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y0','p03').
'ini:connected'('obj:loc-x0-y3','obj:loc-x1-y3','p03').
'ini:connected'('obj:loc-x1-y2','obj:loc-x1-y1','p03').
'ini:connected'('obj:loc-x3-y1','obj:loc-x2-y1','p03').
'ini:connected'('obj:loc-x0-y2','obj:loc-x1-y2','p03').
'ini:connected'('obj:loc-x1-y0','obj:loc-x2-y0','p03').
'ini:connected'('obj:loc-x0-y0','obj:loc-x1-y0','p03').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y2','p03').
'ini:connected'('obj:loc-x3-y0','obj:loc-x3-y1','p03').
'ini:connected'('obj:loc-x2-y3','obj:loc-x3-y3','p03').
'ini:connected'('obj:loc-x3-y2','obj:loc-x3-y3','p03').
'ini:connected'('obj:loc-x1-y2','obj:loc-x0-y2','p03').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y0','p03').
'ini:at-robot'('obj:loc-x3-y3','p03').
'ini:connected'('obj:loc-x1-y3','obj:loc-x0-y3','p03').
'ini:connected'('obj:loc-x0-y3','obj:loc-x0-y2','p03').
'ini:connected'('obj:loc-x3-y1','obj:loc-x3-y2','p03').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y2','p03').
'ini:connected'('obj:loc-x2-y1','obj:loc-x3-y1','p03').
'ini:connected'('obj:loc-x0-y2','obj:loc-x0-y3','p03').
'ini:connected'('obj:loc-x0-y0','obj:loc-x0-y1','p03').
'ini:connected'('obj:loc-x1-y3','obj:loc-x2-y3','p03').
'ini:connected'('obj:loc-x2-y2','obj:loc-x2-y1','p03').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y0','p03').
'ini:connected'('obj:loc-x1-y0','obj:loc-x0-y0','p03').
'ini:connected'('obj:loc-x3-y2','obj:loc-x3-y1','p03').
'ini:connected'('obj:loc-x3-y3','obj:loc-x2-y3','p03').
'ini:visited'('obj:loc-x3-y3','p03').
'ini:connected'('obj:loc-x1-y3','obj:loc-x1-y2','p03').
'ini:connected'('obj:loc-x3-y3','obj:loc-x3-y2','p03').
'ini:connected'('obj:loc-x1-y2','obj:loc-x2-y2','p03').
'ini:connected'('obj:loc-x2-y0','obj:loc-x3-y0','p03').
'ini:connected'('obj:loc-x2-y0','obj:loc-x2-y1','p03').
'ini:connected'('obj:loc-x2-y0','obj:loc-x1-y0','p03').
'ini:connected'('obj:loc-x1-y2','obj:loc-x1-y3','p03').
'ini:connected'('obj:loc-x3-y1','obj:loc-x3-y0','p03').
'ini:connected'('obj:loc-x0-y2','obj:loc-x0-y1','p03').
'ini:connected'('obj:loc-x3-y0','obj:loc-x2-y0','p03').
'ini:connected'('obj:loc-x2-y3','obj:loc-x2-y2','p03').
'ini:connected'('obj:loc-x2-y2','obj:loc-x2-y3','p03').
'ini:connected'('obj:loc-x1-y1','obj:loc-x2-y1','p03').
'ini:connected'('obj:loc-x2-y1','obj:loc-x1-y1','p03').
'ini:connected'('obj:loc-x2-y2','obj:loc-x3-y2','p03').
'ini:connected'('obj:loc-x3-y2','obj:loc-x2-y2','p03').
'ini:connected'('obj:loc-x2-y2','obj:loc-x1-y2','p03').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y2','p03').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p03
'goal:visited'('obj:loc-x0-y0','p03').
'goal:visited'('obj:loc-x0-y1','p03').
'goal:visited'('obj:loc-x0-y2','p03').
'goal:visited'('obj:loc-x0-y3','p03').
'goal:visited'('obj:loc-x1-y0','p03').
'goal:visited'('obj:loc-x1-y1','p03').
'goal:visited'('obj:loc-x1-y2','p03').
'goal:visited'('obj:loc-x1-y3','p03').
'goal:visited'('obj:loc-x2-y0','p03').
'goal:visited'('obj:loc-x2-y1','p03').
'goal:visited'('obj:loc-x2-y2','p03').
'goal:visited'('obj:loc-x2-y3','p03').
'goal:visited'('obj:loc-x3-y0','p03').
'goal:visited'('obj:loc-x3-y1','p03').
'goal:visited'('obj:loc-x3-y2','p03').
'goal:visited'('obj:loc-x3-y3','p03').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p04
'ini:connected'('obj:loc-x2-y3','obj:loc-x1-y3','p04').
'ini:connected'('obj:loc-x4-y0','obj:loc-x4-y1','p04').
'ini:connected'('obj:loc-x3-y3','obj:loc-x4-y3','p04').
'ini:connected'('obj:loc-x4-y3','obj:loc-x3-y3','p04').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y2','p04').
'ini:connected'('obj:loc-x3-y1','obj:loc-x4-y1','p04').
'ini:connected'('obj:loc-x3-y2','obj:loc-x3-y3','p04').
'ini:at-robot'('obj:loc-x3-y3','p04').
'ini:connected'('obj:loc-x3-y4','obj:loc-x4-y4','p04').
'ini:connected'('obj:loc-x2-y4','obj:loc-x3-y4','p04').
'ini:connected'('obj:loc-x3-y1','obj:loc-x3-y2','p04').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y2','p04').
'ini:connected'('obj:loc-x2-y1','obj:loc-x3-y1','p04').
'ini:connected'('obj:loc-x3-y2','obj:loc-x4-y2','p04').
'ini:connected'('obj:loc-x1-y3','obj:loc-x2-y3','p04').
'ini:connected'('obj:loc-x3-y2','obj:loc-x3-y1','p04').
'ini:connected'('obj:loc-x4-y1','obj:loc-x4-y2','p04').
'ini:connected'('obj:loc-x3-y3','obj:loc-x3-y4','p04').
'ini:connected'('obj:loc-x2-y1','obj:loc-x1-y1','p04').
'ini:connected'('obj:loc-x4-y2','obj:loc-x4-y3','p04').
'ini:connected'('obj:loc-x2-y4','obj:loc-x2-y3','p04').
'ini:connected'('obj:loc-x1-y0','obj:loc-x1-y1','p04').
'ini:connected'('obj:loc-x1-y2','obj:loc-x1-y1','p04').
'ini:connected'('obj:loc-x3-y1','obj:loc-x2-y1','p04').
'ini:connected'('obj:loc-x4-y4','obj:loc-x4-y3','p04').
'ini:connected'('obj:loc-x0-y0','obj:loc-x1-y0','p04').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y0','p04').
'ini:connected'('obj:loc-x1-y3','obj:loc-x0-y3','p04').
'ini:connected'('obj:loc-x4-y2','obj:loc-x3-y2','p04').
'ini:connected'('obj:loc-x4-y0','obj:loc-x3-y0','p04').
'ini:visited'('obj:loc-x3-y3','p04').
'ini:connected'('obj:loc-x1-y3','obj:loc-x1-y2','p04').
'ini:connected'('obj:loc-x4-y3','obj:loc-x4-y4','p04').
'ini:connected'('obj:loc-x3-y1','obj:loc-x3-y0','p04').
'ini:connected'('obj:loc-x2-y3','obj:loc-x2-y2','p04').
'ini:connected'('obj:loc-x1-y1','obj:loc-x2-y1','p04').
'ini:connected'('obj:loc-x3-y2','obj:loc-x2-y2','p04').
'ini:connected'('obj:loc-x1-y3','obj:loc-x1-y4','p04').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y2','p04').
'ini:connected'('obj:loc-x1-y1','obj:loc-x0-y1','p04').
'ini:connected'('obj:loc-x0-y1','obj:loc-x1-y1','p04').
'ini:connected'('obj:loc-x3-y0','obj:loc-x4-y0','p04').
'ini:connected'('obj:loc-x0-y3','obj:loc-x1-y3','p04').
'ini:connected'('obj:loc-x4-y1','obj:loc-x3-y1','p04').
'ini:connected'('obj:loc-x3-y0','obj:loc-x3-y1','p04').
'ini:connected'('obj:loc-x2-y3','obj:loc-x2-y4','p04').
'ini:connected'('obj:loc-x2-y3','obj:loc-x3-y3','p04').
'ini:connected'('obj:loc-x1-y2','obj:loc-x0-y2','p04').
'ini:connected'('obj:loc-x0-y3','obj:loc-x0-y2','p04').
'ini:connected'('obj:loc-x0-y2','obj:loc-x0-y3','p04').
'ini:connected'('obj:loc-x0-y0','obj:loc-x0-y1','p04').
'ini:connected'('obj:loc-x1-y0','obj:loc-x0-y0','p04').
'ini:connected'('obj:loc-x3-y3','obj:loc-x2-y3','p04').
'ini:connected'('obj:loc-x3-y3','obj:loc-x3-y2','p04').
'ini:connected'('obj:loc-x2-y0','obj:loc-x2-y1','p04').
'ini:connected'('obj:loc-x2-y0','obj:loc-x1-y0','p04').
'ini:connected'('obj:loc-x0-y2','obj:loc-x0-y1','p04').
'ini:connected'('obj:loc-x2-y2','obj:loc-x2-y3','p04').
'ini:connected'('obj:loc-x2-y2','obj:loc-x3-y2','p04').
'ini:connected'('obj:loc-x0-y3','obj:loc-x0-y4','p04').
'ini:connected'('obj:loc-x1-y4','obj:loc-x0-y4','p04').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y0','p04').
'ini:connected'('obj:loc-x1-y4','obj:loc-x1-y3','p04').
'ini:connected'('obj:loc-x0-y2','obj:loc-x1-y2','p04').
'ini:connected'('obj:loc-x1-y0','obj:loc-x2-y0','p04').
'ini:connected'('obj:loc-x1-y4','obj:loc-x2-y4','p04').
'ini:connected'('obj:loc-x2-y4','obj:loc-x1-y4','p04').
'ini:connected'('obj:loc-x4-y3','obj:loc-x4-y2','p04').
'ini:connected'('obj:loc-x4-y2','obj:loc-x4-y1','p04').
'ini:connected'('obj:loc-x2-y2','obj:loc-x2-y1','p04').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y0','p04').
'ini:connected'('obj:loc-x1-y2','obj:loc-x2-y2','p04').
'ini:connected'('obj:loc-x0-y4','obj:loc-x1-y4','p04').
'ini:connected'('obj:loc-x2-y0','obj:loc-x3-y0','p04').
'ini:connected'('obj:loc-x4-y1','obj:loc-x4-y0','p04').
'ini:connected'('obj:loc-x4-y4','obj:loc-x3-y4','p04').
'ini:connected'('obj:loc-x1-y2','obj:loc-x1-y3','p04').
'ini:connected'('obj:loc-x3-y0','obj:loc-x2-y0','p04').
'ini:connected'('obj:loc-x0-y4','obj:loc-x0-y3','p04').
'ini:connected'('obj:loc-x3-y4','obj:loc-x2-y4','p04').
'ini:connected'('obj:loc-x2-y2','obj:loc-x1-y2','p04').
'ini:connected'('obj:loc-x3-y4','obj:loc-x3-y3','p04').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p04
'goal:visited'('obj:loc-x0-y0','p04').
'goal:visited'('obj:loc-x0-y1','p04').
'goal:visited'('obj:loc-x0-y2','p04').
'goal:visited'('obj:loc-x0-y3','p04').
'goal:visited'('obj:loc-x0-y4','p04').
'goal:visited'('obj:loc-x1-y0','p04').
'goal:visited'('obj:loc-x1-y1','p04').
'goal:visited'('obj:loc-x1-y2','p04').
'goal:visited'('obj:loc-x1-y3','p04').
'goal:visited'('obj:loc-x1-y4','p04').
'goal:visited'('obj:loc-x2-y0','p04').
'goal:visited'('obj:loc-x2-y1','p04').
'goal:visited'('obj:loc-x2-y2','p04').
'goal:visited'('obj:loc-x2-y3','p04').
'goal:visited'('obj:loc-x2-y4','p04').
'goal:visited'('obj:loc-x3-y0','p04').
'goal:visited'('obj:loc-x3-y1','p04').
'goal:visited'('obj:loc-x3-y2','p04').
'goal:visited'('obj:loc-x3-y3','p04').
'goal:visited'('obj:loc-x3-y4','p04').
'goal:visited'('obj:loc-x4-y0','p04').
'goal:visited'('obj:loc-x4-y1','p04').
'goal:visited'('obj:loc-x4-y2','p04').
'goal:visited'('obj:loc-x4-y3','p04').
'goal:visited'('obj:loc-x4-y4','p04').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p05
'ini:connected'('obj:loc-x2-y3','obj:loc-x1-y3','p05').
'ini:connected'('obj:loc-x5-y3','obj:loc-x5-y4','p05').
'ini:connected'('obj:loc-x5-y5','obj:loc-x5-y4','p05').
'ini:connected'('obj:loc-x4-y0','obj:loc-x4-y1','p05').
'ini:connected'('obj:loc-x3-y3','obj:loc-x4-y3','p05').
'ini:connected'('obj:loc-x4-y3','obj:loc-x3-y3','p05').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y2','p05').
'ini:connected'('obj:loc-x5-y4','obj:loc-x5-y5','p05').
'ini:connected'('obj:loc-x5-y1','obj:loc-x5-y2','p05').
'ini:connected'('obj:loc-x3-y1','obj:loc-x4-y1','p05').
'ini:connected'('obj:loc-x3-y2','obj:loc-x3-y3','p05').
'ini:connected'('obj:loc-x4-y4','obj:loc-x4-y5','p05').
'ini:connected'('obj:loc-x3-y4','obj:loc-x4-y4','p05').
'ini:connected'('obj:loc-x2-y4','obj:loc-x3-y4','p05').
'ini:connected'('obj:loc-x3-y1','obj:loc-x3-y2','p05').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y2','p05').
'ini:connected'('obj:loc-x2-y1','obj:loc-x3-y1','p05').
'ini:connected'('obj:loc-x3-y2','obj:loc-x4-y2','p05').
'ini:connected'('obj:loc-x2-y5','obj:loc-x3-y5','p05').
'ini:connected'('obj:loc-x1-y5','obj:loc-x1-y4','p05').
'ini:connected'('obj:loc-x1-y3','obj:loc-x2-y3','p05').
'ini:connected'('obj:loc-x3-y2','obj:loc-x3-y1','p05').
'ini:connected'('obj:loc-x4-y1','obj:loc-x4-y2','p05').
'ini:connected'('obj:loc-x3-y3','obj:loc-x3-y4','p05').
'ini:connected'('obj:loc-x5-y0','obj:loc-x4-y0','p05').
'ini:connected'('obj:loc-x2-y1','obj:loc-x1-y1','p05').
'ini:connected'('obj:loc-x5-y4','obj:loc-x5-y3','p05').
'ini:connected'('obj:loc-x4-y2','obj:loc-x4-y3','p05').
'ini:connected'('obj:loc-x2-y4','obj:loc-x2-y3','p05').
'ini:connected'('obj:loc-x1-y0','obj:loc-x1-y1','p05').
'ini:connected'('obj:loc-x3-y5','obj:loc-x3-y4','p05').
'ini:connected'('obj:loc-x1-y2','obj:loc-x1-y1','p05').
'ini:connected'('obj:loc-x3-y1','obj:loc-x2-y1','p05').
'ini:connected'('obj:loc-x4-y4','obj:loc-x4-y3','p05').
'ini:connected'('obj:loc-x0-y0','obj:loc-x1-y0','p05').
'ini:connected'('obj:loc-x5-y3','obj:loc-x5-y2','p05').
'ini:connected'('obj:loc-x4-y2','obj:loc-x5-y2','p05').
'ini:connected'('obj:loc-x4-y4','obj:loc-x5-y4','p05').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y0','p05').
'ini:connected'('obj:loc-x1-y3','obj:loc-x0-y3','p05').
'ini:connected'('obj:loc-x3-y5','obj:loc-x2-y5','p05').
'ini:connected'('obj:loc-x4-y2','obj:loc-x3-y2','p05').
'ini:connected'('obj:loc-x4-y0','obj:loc-x3-y0','p05').
'ini:connected'('obj:loc-x4-y3','obj:loc-x5-y3','p05').
'ini:connected'('obj:loc-x1-y3','obj:loc-x1-y2','p05').
'ini:connected'('obj:loc-x3-y5','obj:loc-x4-y5','p05').
'ini:connected'('obj:loc-x4-y3','obj:loc-x4-y4','p05').
'ini:connected'('obj:loc-x0-y5','obj:loc-x1-y5','p05').
'ini:connected'('obj:loc-x2-y5','obj:loc-x1-y5','p05').
'ini:connected'('obj:loc-x3-y1','obj:loc-x3-y0','p05').
'ini:connected'('obj:loc-x1-y5','obj:loc-x2-y5','p05').
'ini:connected'('obj:loc-x2-y3','obj:loc-x2-y2','p05').
'ini:connected'('obj:loc-x1-y1','obj:loc-x2-y1','p05').
'ini:connected'('obj:loc-x3-y2','obj:loc-x2-y2','p05').
'ini:connected'('obj:loc-x1-y3','obj:loc-x1-y4','p05').
'ini:connected'('obj:loc-x0-y1','obj:loc-x0-y2','p05').
'ini:connected'('obj:loc-x5-y0','obj:loc-x5-y1','p05').
'ini:connected'('obj:loc-x1-y1','obj:loc-x0-y1','p05').
'ini:connected'('obj:loc-x0-y4','obj:loc-x0-y5','p05').
'ini:connected'('obj:loc-x0-y1','obj:loc-x1-y1','p05').
'ini:connected'('obj:loc-x3-y0','obj:loc-x4-y0','p05').
'ini:connected'('obj:loc-x0-y3','obj:loc-x1-y3','p05').
'ini:connected'('obj:loc-x4-y1','obj:loc-x3-y1','p05').
'ini:connected'('obj:loc-x3-y0','obj:loc-x3-y1','p05').
'ini:connected'('obj:loc-x2-y3','obj:loc-x2-y4','p05').
'ini:connected'('obj:loc-x2-y3','obj:loc-x3-y3','p05').
'ini:connected'('obj:loc-x1-y2','obj:loc-x0-y2','p05').
'ini:connected'('obj:loc-x4-y5','obj:loc-x5-y5','p05').
'ini:connected'('obj:loc-x0-y3','obj:loc-x0-y2','p05').
'ini:connected'('obj:loc-x1-y4','obj:loc-x1-y5','p05').
'ini:connected'('obj:loc-x2-y4','obj:loc-x2-y5','p05').
'ini:connected'('obj:loc-x2-y5','obj:loc-x2-y4','p05').
'ini:connected'('obj:loc-x0-y2','obj:loc-x0-y3','p05').
'ini:connected'('obj:loc-x0-y0','obj:loc-x0-y1','p05').
'ini:connected'('obj:loc-x5-y1','obj:loc-x4-y1','p05').
'ini:connected'('obj:loc-x1-y0','obj:loc-x0-y0','p05').
'ini:connected'('obj:loc-x3-y3','obj:loc-x2-y3','p05').
'ini:connected'('obj:loc-x5-y2','obj:loc-x5-y1','p05').
'ini:connected'('obj:loc-x3-y3','obj:loc-x3-y2','p05').
'ini:connected'('obj:loc-x5-y1','obj:loc-x5-y0','p05').
'ini:connected'('obj:loc-x2-y0','obj:loc-x2-y1','p05').
'ini:connected'('obj:loc-x2-y0','obj:loc-x1-y0','p05').
'ini:connected'('obj:loc-x0-y2','obj:loc-x0-y1','p05').
'ini:connected'('obj:loc-x1-y5','obj:loc-x0-y5','p05').
'ini:connected'('obj:loc-x2-y2','obj:loc-x2-y3','p05').
'ini:connected'('obj:loc-x2-y2','obj:loc-x3-y2','p05').
'ini:connected'('obj:loc-x5-y2','obj:loc-x5-y3','p05').
'ini:connected'('obj:loc-x5-y4','obj:loc-x4-y4','p05').
'ini:connected'('obj:loc-x0-y3','obj:loc-x0-y4','p05').
'ini:connected'('obj:loc-x1-y4','obj:loc-x0-y4','p05').
'ini:connected'('obj:loc-x4-y5','obj:loc-x4-y4','p05').
'ini:connected'('obj:loc-x2-y1','obj:loc-x2-y0','p05').
'ini:connected'('obj:loc-x5-y5','obj:loc-x4-y5','p05').
'ini:connected'('obj:loc-x1-y4','obj:loc-x1-y3','p05').
'ini:connected'('obj:loc-x0-y2','obj:loc-x1-y2','p05').
'ini:connected'('obj:loc-x1-y0','obj:loc-x2-y0','p05').
'ini:connected'('obj:loc-x1-y4','obj:loc-x2-y4','p05').
'ini:connected'('obj:loc-x4-y0','obj:loc-x5-y0','p05').
'ini:connected'('obj:loc-x2-y4','obj:loc-x1-y4','p05').
'ini:connected'('obj:loc-x4-y3','obj:loc-x4-y2','p05').
'ini:connected'('obj:loc-x4-y5','obj:loc-x3-y5','p05').
'ini:connected'('obj:loc-x4-y2','obj:loc-x4-y1','p05').
'ini:connected'('obj:loc-x2-y2','obj:loc-x2-y1','p05').
'ini:connected'('obj:loc-x1-y1','obj:loc-x1-y0','p05').
'ini:connected'('obj:loc-x3-y4','obj:loc-x3-y5','p05').
'ini:connected'('obj:loc-x5-y2','obj:loc-x4-y2','p05').
'ini:at-robot'('obj:loc-x1-y0','p05').
'ini:connected'('obj:loc-x1-y2','obj:loc-x2-y2','p05').
'ini:connected'('obj:loc-x0-y4','obj:loc-x1-y4','p05').
'ini:connected'('obj:loc-x2-y0','obj:loc-x3-y0','p05').
'ini:connected'('obj:loc-x4-y1','obj:loc-x4-y0','p05').
'ini:connected'('obj:loc-x4-y4','obj:loc-x3-y4','p05').
'ini:connected'('obj:loc-x1-y2','obj:loc-x1-y3','p05').
'ini:connected'('obj:loc-x4-y1','obj:loc-x5-y1','p05').
'ini:connected'('obj:loc-x3-y0','obj:loc-x2-y0','p05').
'ini:connected'('obj:loc-x0-y4','obj:loc-x0-y3','p05').
'ini:connected'('obj:loc-x5-y3','obj:loc-x4-y3','p05').
'ini:visited'('obj:loc-x1-y0','p05').
'ini:connected'('obj:loc-x3-y4','obj:loc-x2-y4','p05').
'ini:connected'('obj:loc-x2-y2','obj:loc-x1-y2','p05').
'ini:connected'('obj:loc-x3-y4','obj:loc-x3-y3','p05').
'ini:connected'('obj:loc-x0-y5','obj:loc-x0-y4','p05').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p05
'goal:visited'('obj:loc-x0-y0','p05').
'goal:visited'('obj:loc-x0-y1','p05').
'goal:visited'('obj:loc-x0-y2','p05').
'goal:visited'('obj:loc-x0-y3','p05').
'goal:visited'('obj:loc-x0-y4','p05').
'goal:visited'('obj:loc-x0-y5','p05').
'goal:visited'('obj:loc-x1-y0','p05').
'goal:visited'('obj:loc-x1-y1','p05').
'goal:visited'('obj:loc-x1-y2','p05').
'goal:visited'('obj:loc-x1-y3','p05').
'goal:visited'('obj:loc-x1-y4','p05').
'goal:visited'('obj:loc-x1-y5','p05').
'goal:visited'('obj:loc-x2-y0','p05').
'goal:visited'('obj:loc-x2-y1','p05').
'goal:visited'('obj:loc-x2-y2','p05').
'goal:visited'('obj:loc-x2-y3','p05').
'goal:visited'('obj:loc-x2-y4','p05').
'goal:visited'('obj:loc-x2-y5','p05').
'goal:visited'('obj:loc-x3-y0','p05').
'goal:visited'('obj:loc-x3-y1','p05').
'goal:visited'('obj:loc-x3-y2','p05').
'goal:visited'('obj:loc-x3-y3','p05').
'goal:visited'('obj:loc-x3-y4','p05').
'goal:visited'('obj:loc-x3-y5','p05').
'goal:visited'('obj:loc-x4-y0','p05').
'goal:visited'('obj:loc-x4-y1','p05').
'goal:visited'('obj:loc-x4-y2','p05').
'goal:visited'('obj:loc-x4-y3','p05').
'goal:visited'('obj:loc-x4-y4','p05').
'goal:visited'('obj:loc-x4-y5','p05').
'goal:visited'('obj:loc-x5-y0','p05').
'goal:visited'('obj:loc-x5-y1','p05').
'goal:visited'('obj:loc-x5-y2','p05').
'goal:visited'('obj:loc-x5-y3','p05').
'goal:visited'('obj:loc-x5-y4','p05').
'goal:visited'('obj:loc-x5-y5','p05').
