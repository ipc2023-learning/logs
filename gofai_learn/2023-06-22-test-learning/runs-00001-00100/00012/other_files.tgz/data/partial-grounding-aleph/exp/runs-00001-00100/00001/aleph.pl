%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A Learning Engine for Proposing Hypotheses                              %
%                                                                         %
% A L E P H                                                               %
% Version 5    (last modified: Sun Mar 11 03:25:37 UTC 2007)              %
%                                                                         %
% This is the source for Aleph written and maintained                     %
% by Ashwin Srinivasan (ashwin@comlab.ox.ac.uk)                           %
%                                                                         %
%                                                                         %
% It was originally written to run with the Yap Prolog Compiler           %
% Yap can be found at: http://sourceforge.net/projects/yap/               %
% Yap must be compiled with -DDEPTH_LIMIT=1                               %
%                                                                         %
% It should also run with SWI Prolog, although performance may be         %
% sub-optimal.                                                            %
%                                                                         %
% If you obtain this version of Aleph and have not already done so        %
% please subscribe to the Aleph mailing list. You can do this by          %
% mailing majordomo@comlab.ox.ac.uk with the following command in the     %
% body of the mail message: subscribe aleph                               %
%                                                                         %
% Aleph is freely available for academic purposes.                        %
% If you intend to use it for commercial purposes then                    %
% please contact Ashwin Srinivasan first.                                 %
%                                                                         %
% A simple on-line manual is available on the Web at                      %
% www.comlab.ox.ac.uk/oucl/research/areas/machlearn/Aleph/index.html      %
%                                                                         %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% C O M P I L E R   S P E C I F I C


prolog_type(yap):-
	predicate_property(yap_flag(_,_),built_in), !.
prolog_type(swi).

init(yap):-
	source,
	system_predicate(false,false), hide(false),
	style_check(single_var),
	% yap_flag(profiling,on),
	assert_static((aleph_random(X):- X is random)),
	(predicate_property(alarm(_,_,_),built_in) ->
		assert_static((remove_alarm(X):- alarm(0,_,_)));
		assert_static(alarm(_,_,_)),
		assert_static(remove_alarm(_))),
	assert_static((aleph_consult(F):- consult(F))),
	assert_static((aleph_reconsult(F):- reconsult(F))),
        (predicate_property(thread_local(_),built_in) -> true;
		assert_static(thread_local(_))),
	assert_static(broadcast(_)),
	assert_static((aleph_background_predicate(Lit):-
				predicate_property(Lit,P),
				((P = static); (P = dynamic); (P = built_in)), !)),
	(predicate_property(delete_file(_),built_in) -> true;
		assert_static(delete_file(_))).

init(swi):-
	redefine_system_predicate(false),
	style_check(+singleton),
	style_check(-discontiguous),
	dynamic(false/0),
	dynamic(example/3),
	assert((aleph_random(X):- I = 1000000, X is float(random(I-1))/float(I))),
	arithmetic_function(inf/0), assert(inf(1e10)),
	assert((gc:- garbage_collect)),
	assert((depth_bound_call(G,L):-
			call_with_depth_limit(G,L,R),
			R \= depth_limit_exceeded)),
	(predicate_property(numbervars(_,_,_),built_in) -> true;
		assert((numbervars(A,B,C):- numbervars(A,'$VAR',B,C)))),
	assert((assert_static(X):- assert(X))),
	assert((system(X):- shell(X))),
	assert((exists(X):- exists_file(X))),
	assert((aleph_reconsult(F):- consult(F))),
	assert((aleph_consult(X):- aleph_open(X,read,S), repeat,
			read(S,F), (F = end_of_file -> close(S), !;
					assertz(F),fail))),
	use_module(library(broadcast)),
        (predicate_property(alarm(_,_,_),built_in) ->
		use_module(library(time));
                assert(alarm(_,_,_)),
                assert(remove_alarm(_))),
        (predicate_property(thread_local(_),built_in) -> true;
		assert(thread_local(_))),
	assert((aleph_background_predicate(Lit):-
				predicate_property(Lit,P),
				((P=interpreted);(P=built_in)), ! )),
	(predicate_property(delete_file(_),built_in) -> true;
		assert_static(delete_file(_))).

:- prolog_type(Type), init(Type).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A L E P H


aleph_version(5).
aleph_version_date('Sun Mar 11 03:25:37 UTC 2007').
aleph_manual('http://www.comlab.ox.ac.uk/oucl/groups/machlearn/Aleph/index.html').

:- op(500,fy,#).
:- op(500,fy,*).
:- op(900,xfy,because).

:- dynamic '$aleph_feature'/2.
:- dynamic '$aleph_global'/2.
:- dynamic '$aleph_good'/3.

:- dynamic '$aleph_local'/2.

:- dynamic '$aleph_sat'/2.
:- dynamic '$aleph_sat_atom'/2.
:- dynamic '$aleph_sat_ovars'/2.
:- dynamic '$aleph_sat_ivars'/2.
:- dynamic '$aleph_sat_varsequiv'/2.
:- dynamic '$aleph_sat_varscopy'/3.
:- dynamic '$aleph_sat_terms'/4.
:- dynamic '$aleph_sat_vars'/4.
:- dynamic '$aleph_sat_litinfo'/6.

:- dynamic '$aleph_search_cache'/1.
:- dynamic '$aleph_search_prunecache'/1.
:- dynamic '$aleph_search'/2.
:- dynamic '$aleph_search_seen'/2.
:- dynamic '$aleph_search_expansion'/4.
:- dynamic '$aleph_search_gain'/4.
:- dynamic '$aleph_search_node'/8.

:- dynamic '$aleph_link_vars'/2.
:- dynamic '$aleph_has_vars'/3.
:- dynamic '$aleph_has_ovar'/4.
:- dynamic '$aleph_has_ivar'/4.
:- dynamic '$aleph_determination'/2.

:- thread_local('$aleph_search_cache'/1).
:- thread_local('$aleph_search_prunecache'/1).
:- thread_local('$aleph_search'/2).
:- thread_local('$aleph_search_seen'/2).
:- thread_local('$aleph_search_expansion'/4).
:- thread_local('$aleph_search_gain'/4).
:- thread_local('$aleph_search_node'/8).


:- multifile false/0.
:- multifile prune/1.
:- multifile refine/2.
:- multifile cost/3.
:- multifile prove/2.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% C O N S T R U C T   B O T T O M

% get_atoms(+Preds,+Depth,+MaxDepth,+Last,-LastLit)
% layered generation of ground atoms to add to bottom clause
%	Preds is list of PName/Arity entries obtained from the determinations
%	Depth is current variable-chain depth
%	MaxDepth is maximum allowed variable chain depth (i setting)
%	Last is last atom number so far
%	Lastlit is atom number after all atoms to MaxDepth have been generated
get_atoms([],_,_,Last,Last):- !.
get_atoms(Preds,Depth,MaxDepth,Last,LastLit):-
	Depth =< MaxDepth,
	Depth0 is Depth - 1,
	'$aleph_sat_terms'(_,Depth0,_,_),	% new terms generated ?
	!,
	get_atoms1(Preds,Depth,MaxDepth,Last,Last1),
	Depth1 is Depth + 1,
	get_atoms(Preds,Depth1,MaxDepth,Last1,LastLit).
get_atoms(_,_,_,Last,Last).

% auxiliary predicate used by get_atoms/5
get_atoms1([],_,_,Last,Last).
get_atoms1([Pred|Preds],Depth,MaxDepth,Last,LastLit):-
	gen_layer(Pred,Depth),
	flatten(Depth,MaxDepth,Last,Last1),
	get_atoms1(Preds,Depth,MaxDepth,Last1,LastLit).

% flatten(+Depth,+MaxDepth,+Last,-LastLit)
% flatten a set of ground atoms by replacing all in/out terms with variables
%	constants are wrapped in a special term called aleph_const(...)
%	eg suppose p/3 had modes p(+char,+char,#int)
%	then p(a,a,3) becomes p(X,X,aleph_const(3))
% ground atoms to be flattened are assumed to be in the i.d.b atoms
% vars and terms are actually integers which are stored in vars/terms databases
%	so eg above actually becomes p(1,1,aleph_const(3)).
%	where variable 1 stands for term 2 (say) which in turn stands for a
%	Depth is current variable-chain depth
%	MaxDepth is maximum allowed variable chain depth (i setting)
%	Last is last atom number so far
%	Lastlit is atom number after ground atoms here have been flattened
% If permute_bottom is set to true, then the order of ground atoms is
% shuffled. The empirical utility of doing this has been investigated by
% P. Schorn in "Random Local Bottom Clause Permutations for Better Search Space
% Exploration in Progol-like ILP Systems.", 16th International Conference on
% ILP (ILP 2006).
flatten(Depth,MaxDepth,Last,Last1):-
	retractall('$aleph_local'(flatten_num,_)),
	asserta('$aleph_local'(flatten_num,Last)),
	'$aleph_sat_atom'(_,_), !,
	(setting(permute_bottom,Permute) -> true; Permute = false),
	flatten_atoms(Permute,Depth,MaxDepth,Last1).
flatten(_,_,_,Last):-
	retract('$aleph_local'(flatten_num,Last)), !.

flatten_atoms(true,Depth,MaxDepth,Last1):-
	findall(L-M,retract('$aleph_sat_atom'(L,M)),LitModes),
	aleph_rpermute(LitModes,PLitModes),
	aleph_member(Lit1-Mode,PLitModes),
	retract('$aleph_local'(flatten_num,LastSoFar)),
	(Lit1 = not(Lit) -> Negated = true; Lit = Lit1, Negated = false),
	flatten_atom(Depth,MaxDepth,Lit,Negated,Mode,LastSoFar,Last1),
	asserta('$aleph_local'(flatten_num,Last1)),
	fail.
flatten_atoms(false,Depth,MaxDepth,Last1):-
	repeat,
	retract('$aleph_sat_atom'(Lit1,Mode)),
	retract('$aleph_local'(flatten_num,LastSoFar)),
	(Lit1 = not(Lit) -> Negated = true; Lit = Lit1, Negated = false),
	flatten_atom(Depth,MaxDepth,Lit,Negated,Mode,LastSoFar,Last1),
	asserta('$aleph_local'(flatten_num,Last1)),
	('$aleph_sat_atom'(_,_) ->
			fail;
			retract('$aleph_local'(flatten_num,Last1))), !.
flatten_atoms(_,_,_,Last):-
	retract('$aleph_local'(flatten_num,Last)), !.


% flatten_atom(+Depth,+Depth1,+Lit,+Negated,+Mode,+Last,-Last1)
%	update lits database by adding ``flattened atoms''. This involves:
%	replacing ground terms at +/- positions in Lit with variables
%	and wrapping # positions in Lit within a special term stucture
%	Mode contains actual mode and term-place numbers and types for +/-/# 
%	Last is the last literal number in the lits database at present
%	Last1 is the last literal number after the update
flatten_atom(Depth,Depth1,Lit,Negated,Mode,Last,Last1):-
	arg(3,Mode,O), arg(4,Mode,C),
	integrate_args(Depth,Lit,O),
	integrate_args(Depth,Lit,C),
	(Depth = Depth1 -> CheckOArgs = true; CheckOArgs = false),
	flatten_lits(Lit,CheckOArgs,Depth,Negated,Mode,Last,Last1).

% variabilise literals by replacing terms with variables
% if var splitting is on then new equalities are introduced into bottom clause
% if at final i-layer, then literals with o/p args that do not contain at least
% 	one output var from head are discarded
flatten_lits(Lit,CheckOArgs,Depth,Negated,Mode,Last,_):-
	functor(Lit,Name,Arity),
	asserta('$aleph_local'(flatten_lits,Last)),
	Depth1 is Depth - 1,
	functor(OldFAtom,Name,Arity),
	flatten_lit(Lit,Mode,OldFAtom,_,_),
	functor(FAtom,Name,Arity),
	apply_equivs(Depth1,Arity,OldFAtom,FAtom),
	retract('$aleph_local'(flatten_lits,OldLast)),
	(CheckOArgs = true -> 
		arg(3,Mode,Out),
		get_vars(FAtom,Out,OVars),
		(in_path(OVars) ->
			add_new_lit(Depth,FAtom,Mode,OldLast,Negated,NewLast);
			NewLast = OldLast) ;
		add_new_lit(Depth,FAtom,Mode,OldLast,Negated,NewLast)),
	asserta('$aleph_local'(flatten_lits,NewLast)),
	fail.
flatten_lits(_,_,_,_,_,_,Last1):-
	retract('$aleph_local'(flatten_lits,Last1)).


% flatten_lit(+Lit,+Mode,+FAtom,-IVars,-OVars)
% variabilise Lit as FAtom
%	Mode contains actual mode and 
%	In, Out, Const positions as term-place numbers with types
% 	replace ground terms with integers denoting variables
%	or special terms denoting constants
% 	variable numbers arising from variable splits are disallowed
%	returns Input and Output variable numbers
flatten_lit(Lit,mode(Mode,In,Out,Const),FAtom,IVars,OVars):-
	functor(Mode,_,Arity),
	once(copy_modeterms(Mode,FAtom,Arity)),
	flatten_vars(In,Lit,FAtom,IVars),
	flatten_vars(Out,Lit,FAtom,OVars),
	flatten_consts(Const,Lit,FAtom).

% flatten_vars(+TPList,+Lit,+FAtom,-Vars):-
% FAtom is Lit with terms-places in TPList replaced by variables
flatten_vars([],_,_,[]).
flatten_vars([Pos/Type|Rest],Lit,FAtom,[Var|Vars]):-
	tparg(Pos,Lit,Term),
	'$aleph_sat_terms'(TNo,_,Term,Type),
	'$aleph_sat_vars'(Var,TNo,_,_),
	\+('$aleph_sat_varscopy'(Var,_,_)),
	tparg(Pos,FAtom,Var),
	flatten_vars(Rest,Lit,FAtom,Vars).

% replace a list of terms at places marked by # in the modes
% with a special term structure denoting a constant
flatten_consts([],_,_).
flatten_consts([Pos/_|Rest],Lit,FAtom):-
	tparg(Pos,Lit,Term),
	tparg(Pos,FAtom,aleph_const(Term)),
	flatten_consts(Rest,Lit,FAtom).

% in_path(+ListOfOutputVars)
% check to avoid generating useless literals in the last i layer
in_path(OVars):-
	'$aleph_sat'(hovars,Vars), !,
	(Vars=[];OVars=[];intersects(Vars,OVars)).
in_path(_).

% update_equivs(+VariableEquivalences,+IDepth)
% update variable equivalences created at a particular i-depth
% is non-empty only if variable splitting is allowed
update_equivs([],_):- !.
update_equivs(Equivs,Depth):-
	retract('$aleph_sat_varsequiv'(Depth,Eq1)), !,
	update_equiv_lists(Equivs,Eq1,Eq2),
	asserta('$aleph_sat_varsequiv'(Depth,Eq2)).
update_equivs(Equivs,Depth):-
	Depth1 is Depth - 1,
	get_equivs(Depth1,Eq1),
	update_equiv_lists(Equivs,Eq1,Eq2),
	asserta('$aleph_sat_varsequiv'(Depth,Eq2)).

update_equiv_lists([],E,E):- !.
update_equiv_lists([Var/E1|Equivs],ESoFar,E):-
	aleph_delete(Var/E2,ESoFar,ELeft), !,
	update_list(E1,E2,E3),
	update_equiv_lists(Equivs,[Var/E3|ELeft],E).
update_equiv_lists([Equiv|Equivs],ESoFar,E):-
	update_equiv_lists(Equivs,[Equiv|ESoFar],E).

% get variable equivalences at a particular depth
% recursively descend to greatest depth below this for which equivs exist
% also returns the database reference of entry
get_equivs(Depth,[]):-
	Depth < 0, !.
get_equivs(Depth,Equivs):-
	'$aleph_sat_varsequiv'(Depth,Equivs), !.
get_equivs(Depth,E):-
	Depth1 is Depth - 1,
	get_equivs(Depth1,E).

% apply equivalences inherited from Depth to a flattened literal
% if no variable splitting, then succeeds only once
apply_equivs(Depth,Arity,Old,New):-
	get_equivs(Depth,Equivs),
	rename(Arity,Equivs,[],Old,New).

% rename args using list of Var/Equivalences
rename(_,[],_,L,L):- !.
rename(0,_,_,_,_):- !.
rename(Pos,Equivs,Subst0,Old,New):-
        arg(Pos,Old,OldVar),
        aleph_member(OldVar/Equiv,Equivs), !,
        aleph_member(NewVar,Equiv),
        arg(Pos,New,NewVar),
        Pos1 is Pos - 1,
        rename(Pos1,Equivs,[OldVar/NewVar|Subst0],Old,New).
rename(Pos,Equivs,Subst0,Old,New):-
        arg(Pos,Old,OldVar),
        (aleph_member(OldVar/NewVar,Subst0) ->
                arg(Pos,New,NewVar);
                arg(Pos,New,OldVar)),
        Pos1 is Pos - 1,
        rename(Pos1,Equivs,Subst0,Old,New).


% add a new literal to lits database
% performs variable splitting if splitvars is set to true
add_new_lit(Depth,FAtom,Mode,OldLast,Negated,NewLast):-
	arg(1,Mode,M),
	functor(FAtom,Name,Arity),
	functor(SplitAtom,Name,Arity),
	once(copy_modeterms(M,SplitAtom,Arity)),
	arg(2,Mode,In), arg(3,Mode,Out), arg(4,Mode,Const),
        split_vars(Depth,FAtom,In,Out,Const,SplitAtom,IVars,OVars,Equivs),
        update_equivs(Equivs,Depth),
        add_lit(OldLast,Negated,SplitAtom,In,Out,IVars,OVars,LitNum),
        insert_eqs(Equivs,Depth,LitNum,NewLast), !.

% modify the literal database: check if performing lazy evaluation
% of bottom clause, and update input and output terms in literal
add_lit(Last,Negated,FAtom,I,O,_,_,Last):-
	setting(construct_bottom,CBot),
	(CBot = false ; CBot = reduction), 
	(Negated = true -> Lit = not(FAtom); Lit = FAtom),
	'$aleph_sat_litinfo'(_,0,Lit,I,O,_), !.
add_lit(Last,Negated,FAtom,In,Out,IVars,OVars,LitNum):-
	LitNum is Last + 1,
	update_iterms(LitNum,IVars),
	update_oterms(LitNum,OVars,[],Dependents),
	add_litinfo(LitNum,Negated,FAtom,In,Out,Dependents),
	assertz('$aleph_sat_ivars'(LitNum,IVars)),
	assertz('$aleph_sat_ovars'(LitNum,OVars)), !.


% update lits database after checking that the atom does not exist
% used during updates of lit database by lazy evaluation
update_lit(LitNum,true,FAtom,I,O,D):-
	'$aleph_sat_litinfo'(LitNum,0,not(FAtom),I,O,D), !.
update_lit(LitNum,false,FAtom,I,O,D):-
	'$aleph_sat_litinfo'(LitNum,0,FAtom,I,O,D), !.
update_lit(LitNum,Negated,FAtom,I,O,D):-
	gen_nlitnum(LitNum),
	add_litinfo(LitNum,Negated,FAtom,I,O,D), 
	get_vars(FAtom,I,IVars),
	get_vars(FAtom,O,OVars),
	assertz('$aleph_sat_ivars'(LitNum,K,IVars)),
	assertz('$aleph_sat_ovars'(LitNum,K,OVars)), !.

% add a literal to lits database without checking
add_litinfo(LitNum,true,FAtom,I,O,D):-
	!,
	assertz('$aleph_sat_litinfo'(LitNum,0,not(FAtom),I,O,D)).
add_litinfo(LitNum,_,FAtom,I,O,D):-
	assertz('$aleph_sat_litinfo'(LitNum,0,FAtom,I,O,D)).
	
% update database with input terms of literal
update_iterms(_,[]).
update_iterms(LitNum,[VarNum|Vars]):-
	retract('$aleph_sat_vars'(VarNum,TNo,I,O)),
	update(I,LitNum,NewI),
	asserta('$aleph_sat_vars'(VarNum,TNo,NewI,O)),
	update_dependents(LitNum,O),
	update_iterms(LitNum,Vars).

% update database with output terms of literal
% return list of dependent literals
update_oterms(_,[],Dependents,Dependents).
update_oterms(LitNum,[VarNum|Vars],DSoFar,Dependents):-
	retract('$aleph_sat_vars'(VarNum,TNo,I,O)),
	update(O,LitNum,NewO),
	asserta('$aleph_sat_vars'(VarNum,TNo,I,NewO)),
	update_list(I,DSoFar,D1),
	update_oterms(LitNum,Vars,D1,Dependents).

% update Dependent list of literals with LitNum
update_dependents(_,[]).
update_dependents(LitNum,[Lit|Lits]):-
	retract('$aleph_sat_litinfo'(Lit,Depth,Atom,ITerms,OTerms,Dependents)),
	update(Dependents,LitNum,NewD),
	asserta('$aleph_sat_litinfo'(Lit,Depth,Atom,ITerms,OTerms,NewD)),
	update_dependents(LitNum,Lits).

% update dependents of head with literals that are simply generators
% 	that is, literals that require no input args
update_generators:-
	findall(L,('$aleph_sat_litinfo'(L,_,_,[],_,_),L>1),GList),
	GList \= [], !,
	retract('$aleph_sat_litinfo'(1,Depth,Lit,I,O,D)),
	aleph_append(D,GList,D1),
	asserta('$aleph_sat_litinfo'(1,Depth,Lit,I,O,D1)).
update_generators.

% mark literals 
mark_lits(Lits):-
	aleph_member(Lit,Lits),
	asserta('$aleph_local'(marked,Lit/0)),
	fail.
mark_lits(_).
	
% recursively mark literals with minimum depth to bind output vars in head
mark_lits([],_,_).
mark_lits(Lits,OldVars,Depth):-
	mark_lits(Lits,Depth,true,[],Predecessors,OldVars,NewVars),
	aleph_delete_list(Lits,Predecessors,P1),
	Depth1 is Depth + 1,
	mark_lits(P1,NewVars,Depth1).

mark_lits([],_,_,P,P,V,V).
mark_lits([Lit|Lits],Depth,GetPreds,PSoFar,P,VSoFar,V):-
	retract('$aleph_local'(marked,Lit/Depth0)), !,
	(Depth < Depth0 ->
		mark_lit(Lit,Depth,GetPreds,VSoFar,P1,V2),
		update_list(P1,PSoFar,P2),
		mark_lits(Lits,Depth,GetPreds,P2,P,V2,V);
		asserta('$aleph_local'(marked,Lit/Depth0)),
		mark_lits(Lits,Depth,GetPreds,PSoFar,P,VSoFar,V)).
mark_lits([Lit|Lits],Depth,GetPreds,PSoFar,P,VSoFar,V):-
	mark_lit(Lit,Depth,GetPreds,VSoFar,P1,V2), !,
	update_list(P1,PSoFar,P2),
	mark_lits(Lits,Depth,GetPreds,P2,P,V2,V).
mark_lits([_|Lits],Depth,GetPreds,PSoFar,P,VSoFar,V):-
	mark_lits(Lits,Depth,GetPreds,PSoFar,P,VSoFar,V).

mark_lit(Lit,Depth,GetPreds,VSoFar,P1,V1):-
	retract('$aleph_sat_litinfo'(Lit,_,Atom,I,O,D)),
	asserta('$aleph_local'(marked,Lit/Depth)),
	asserta('$aleph_sat_litinfo'(Lit,Depth,Atom,I,O,D)),
	(GetPreds = false ->
		P1 = [],
		V1 = VSoFar;
		get_vars(Atom,O,OVars),
		update_list(OVars,VSoFar,V1),
		get_predicates(D,V1,D1),
		mark_lits(D1,Depth,false,[],_,VSoFar,_),
		get_vars(Atom,I,IVars),
		get_predecessors(IVars,[],P1)).

% mark lits that produce outputs that are not used by any other literal
mark_floating_lits(Lit,Last):-
	Lit > Last, !.
mark_floating_lits(Lit,Last):-
	'$aleph_sat_litinfo'(Lit,_,_,_,O,D),
	O \= [],
	(D = []; D = [Lit]), !,
	asserta('$aleph_local'(marked,Lit/0)),
	Lit1 is Lit + 1,
	mark_floating_lits(Lit1,Last).
mark_floating_lits(Lit,Last):-
	Lit1 is Lit + 1,
	mark_floating_lits(Lit1,Last).
	
% mark lits in bottom clause that are specified redundant by user
% requires definition of redundant/2 that have distinguished first arg ``bottom''
mark_redundant_lits(Lit,Last):-
	Lit > Last, !.
mark_redundant_lits(Lit,Last):-
	get_pclause([Lit],[],Atom,_,_,_),
	redundant(bottom,Atom), !,
	asserta('$aleph_local'(marked,Lit/0)),
	Lit1 is Lit + 1,
	mark_redundant_lits(Lit1,Last).
mark_redundant_lits(Lit,Last):-
	Lit1 is Lit + 1,
	mark_redundant_lits(Lit1,Last).

% get literals that are linked and do not link to any others (ie predicates)
get_predicates([],_,[]).
get_predicates([Lit|Lits],Vars,[Lit|T]):-
	'$aleph_sat_litinfo'(Lit,_,Atom,I,_,[]),
	get_vars(Atom,I,IVars),
	aleph_subset1(IVars,Vars), !,
	get_predicates(Lits,Vars,T).
get_predicates([_|Lits],Vars,T):-
	get_predicates(Lits,Vars,T).

% get all predecessors in the bottom clause of a set of literals
get_predecessors([],[]).
get_predecessors([Lit|Lits],P):-
	(Lit = 1 -> Pred = [];
		get_ivars1(false,Lit,IVars),
		get_predecessors(IVars,[],Pred)),
	get_predecessors(Pred,PPred),
	update_list(Pred,PPred,P1),
	get_predecessors(Lits,P2),
	update_list(P2,P1,P).

% get list of literals in the bottom clause that produce a set of vars
get_predecessors([],P,P).
get_predecessors([Var|Vars],PSoFar,P):-
	'$aleph_sat_vars'(Var,_,_,O),
	update_list(O,PSoFar,P1),
	get_predecessors(Vars,P1,P).

% removal of literals in bottom clause by negative-based reduction.
% A greedy strategy is employed, as implemented within the ILP system
% Golem (see Muggleton and Feng, "Efficient induction
% of logic programs", Inductive Logic Programming, S. Muggleton (ed.),
% AFP Press). In this, given a clause H:- B1, B2,...Bn, let Bi be the
% first literal s.t. H:-B1,...,Bi covers no more than the allowable number
% of negatives. The clause H:- Bi,B1,...,Bi-1 is then reduced. The
% process continues until there is no change in the length of a clause
% within an iteration. The algorithm is O(n^2).
rm_nreduce(Last,N):-
	setting(nreduce_bottom,true), !,
	get_litnums(1,Last,BottomLits),
        '$aleph_global'(atoms,atoms(neg,Neg)),
	setting(depth,Depth),
	setting(prooftime,Time),
	setting(proof_strategy,Proof),
	setting(noise,Noise),
	neg_reduce(BottomLits,Neg,Last,Depth/Time/Proof,Noise),
	get_marked(1,Last,Lits),
	length(Lits,N),
	p1_message('negative-based removal'), p_message(N/Last).
rm_nreduce(_,0).

neg_reduce([Head|Body],Neg,Last,DepthTime,Noise):-
	get_pclause([Head],[],Clause,TV,_,_),
	neg_reduce(Body,Clause,TV,2,Neg,DepthTime,Noise,NewLast),
	NewLast \= Last, !,
	NewLast1 is NewLast - 1,
	aleph_remove_n(NewLast1,[Head|Body],Prefix,[LastLit|Rest]),
	mark_lits(Rest),
	insert_lastlit(LastLit,Prefix,Lits1),
	neg_reduce(Lits1,Neg,NewLast,DepthTime,Noise).
neg_reduce(_,_,_,_,_).

neg_reduce([],_,_,N,_,_,_,N).
neg_reduce([L1|Lits],C,TV,N,Neg,ProofFlags,Noise,LastLit):-
	get_pclause([L1],TV,Lit1,TV1,_,_),
	extend_clause(C,Lit1,Clause),
        prove(ProofFlags,neg,Clause,Neg,NegCover,Count),
	Count > Noise, !,
	N1 is N + 1,
	neg_reduce(Lits,Clause,TV1,N1,NegCover,ProofFlags,Noise,LastLit).
neg_reduce(_,_,_,N,_,_,_,N).

% insert_lastlit(LastLit,[1|Lits],Lits1):-
	% find_last_ancestor(Lits,LastLit,1,2,Last),
	% aleph_remove_n(Last,[1|Lits],Prefix,Suffix),
	% aleph_append([LastLit|Suffix],Prefix,Lits1).

insert_lastlit(LastLit,Lits,Lits1):-
	get_predecessors([LastLit],Prefix),
	aleph_delete_list(Prefix,Lits,Suffix),
	aleph_append([LastLit|Suffix],Prefix,Lits1).

	
find_last_ancestor([],_,Last,_,Last):- !.
find_last_ancestor([Lit|Lits],L,_,LitNum,Last):-
	'$aleph_sat_litinfo'(Lit,_,_,_,_,D), 
	aleph_member1(L,D), !,
	NextLit is LitNum + 1,
	find_last_ancestor(Lits,L,LitNum,NextLit,Last).
find_last_ancestor([_|Lits],L,Last0,LitNum,Last):-
	NextLit is LitNum + 1,
	find_last_ancestor(Lits,L,Last0,NextLit,Last).

% removal of literals that are repeated because of mode differences
rm_moderepeats(_,_):-
	'$aleph_sat_litinfo'(Lit1,_,Pred1,_,_,_),
	'$aleph_sat_litinfo'(Lit2,_,Pred1,_,_,_),
	Lit1 >= 1, Lit2 > Lit1,
	retract('$aleph_sat_litinfo'(Lit2,_,Pred1,_,_,_)),
	asserta('$aleph_local'(marked,Lit2/0)),
	fail.
rm_moderepeats(Last,N):-
	'$aleph_local'(marked,_), !,
	get_marked(1,Last,Lits),
	length(Lits,N),
	p1_message('repeated literals'), p_message(N/Last),
	remove_lits(Lits).
rm_moderepeats(_,0).
	
% removal of symmetric literals
rm_symmetric(_,_):-
	'$aleph_global'(symmetric,_),
	'$aleph_sat_litinfo'(Lit1,_,Pred1,[I1|T1],_,_),
	is_symmetric(Pred1,Name,Arity),
	get_vars(Pred1,[I1|T1],S1),
	'$aleph_sat_litinfo'(Lit2,_,Pred2,[I2|T2],_,_),
	Lit1 \= Lit2,
	is_symmetric(Pred2,Name,Arity),
	Pred1 =.. [_|Args1],
	Pred2 =.. [_|Args2],
	symmetric_match(Args1,Args2),
	get_vars(Pred2,[I2|T2],S2),
	equal_set(S1,S2),
	asserta('$aleph_local'(marked,Lit2/0)),
	retract('$aleph_sat_litinfo'(Lit2,_,Pred2,[I2|T2],_,_)),
	fail.
rm_symmetric(Last,N):-
	'$aleph_local'(marked,_), !,
	get_marked(1,Last,Lits),
	length(Lits,N),
	p1_message('symmetric literals'), p_message(N/Last),
	remove_lits(Lits).
rm_symmetric(_,0).

is_symmetric(not(Pred),not(Name),Arity):-
	!,
	functor(Pred,Name,Arity),
	'$aleph_global'(symmetric,symmetric(Name/Arity)).
is_symmetric(Pred,Name,Arity):-
	functor(Pred,Name,Arity),
	'$aleph_global'(symmetric,symmetric(Name/Arity)).

symmetric_match([],[]).
symmetric_match([aleph_const(Term)|Terms1],[aleph_const(Term)|Terms2]):-
	!,
	symmetric_match(Terms1,Terms2).
symmetric_match([Term1|Terms1],[Term2|Terms2]):-
	integer(Term1), integer(Term2),
	symmetric_match(Terms1,Terms2).
	
% removal of literals that are repeated because of commutativity
rm_commutative(_,_):-
	'$aleph_global'(commutative,commutative(Name/Arity)),
	p1_message('checking commutative literals'), p_message(Name/Arity),
	functor(Pred,Name,Arity), functor(Pred1,Name,Arity),
	'$aleph_sat_litinfo'(Lit1,_,Pre




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ph_global'(theory,theory(RuleId,_,Rule,_,_)),
        pp_dclause(Rule),
        fail.
write_rule(_).

write_features(File):-
        aleph_open(File,write,Stream),
        set_output(Stream),
	listing('$aleph_feature'/2),
        close(Stream),
        set_output(user_output).
write_features(_).


best_hypothesis(Head1,Body1,[P,N,L]):-
	'$aleph_search'(selected,selected([P,N,L|_],Clause,_,_)),
	split_clause(Clause,Head2,Body2), !,
	Head1 = Head2, Body1 = Body2.

hypothesis(Head1,Body1,Label):-
	'$aleph_search'(pclause,pclause(Head2,Body2)), !,
	Head1 = Head2, Body1 = Body2,
	get_hyp_label((Head2:-Body2),Label).
hypothesis(Head1,Body1,Label):-
        '$aleph_global'(hypothesis,hypothesis(_,Theory,_,_)),
	(Theory = [_|_] -> aleph_member(Clause,Theory);
		Theory = Clause),
	split_clause(Clause,Head2,Body2), 
	Head1 = Head2, Body1 = Body2,
	get_hyp_label((Head2:-Body2),Label).

rdhyp:-
	retractall('$aleph_search'(pclause,_)),
	retractall('$aleph_search'(covers,_)),
	retractall('$aleph_search'(coversn,_)),
        read(Clause),
        add_hyp(Clause),
        nl,
        show(hypothesis).

addhyp:-
	'$aleph_global'(hypothesis,hypothesis(Label,Theory,PCover,NCover)),
	Theory = [_|_], !,
	add_theory(Label,Theory,PCover,NCover).
addhyp:-
        '$aleph_global'(hypothesis,hypothesis(Label,_,PCover,_)), !,   
        rm_seeds,
        worse_coversets(PCover,pos,Label,Worse),
        (Worse = [] -> true;
        	'$aleph_global'(last_clause,last_clause(NewClause)),
                update_coversets(Worse,NewClause,pos,Label)), !.
addhyp:-
        '$aleph_search'(selected,selected(Label,RClause,PCover,NCover)), !,
        add_hyp(Label,RClause,PCover,NCover),
        rm_seeds,
        worse_coversets(PCover,pos,Label,Worse),
        (Worse = [] -> true;
        	'$aleph_global'(last_clause,last_clause(NewClause)),
                update_coversets(Worse,NewClause,pos,Label)), !.

% add bottom clause as hypothesis
%	provided minacc, noise and search constraints are met
%	otherwise the example saturated is added as hypothesis
add_bottom:-
	retractall('$aleph_search'(selected,selected(_,_,_,_))),
	bottom(Bottom),
	add_hyp(Bottom),
        '$aleph_global'(hypothesis,hypothesis(Label,Clause,_,_)),
	(clause_ok(Clause,Label) -> true;
		'$aleph_sat'(example,example(Num,Type)),
		example(Num,Type,Example),
		retract('$aleph_global'(hypothesis,hypothesis(_,_,_,_))),
		setting(evalfn,Evalfn),
		complete_label(Evalfn,Example,[1,0,1],Label1),
		asserta('$aleph_global'(hypothesis,hypothesis(Label1,(Example:-true),[Num-Num],[])))).

	
% specialise a hypothesis by recursive construction of
% abnormality predicates
sphyp:-
	retractall('$aleph_search'(sphyp,hypothesis(_,_,_,_))),
	retractall('$aleph_search'(gcwshyp,hypothesis(_,_,_,_))),
        retract('$aleph_global'(hypothesis,
				hypothesis([P,N,L|T],Clause,PCover,NCover))),
        asserta('$aleph_search'(sphyp,hypothesis([P,N,L|T],Clause,PCover,NCover))),
        store(searchstate),
        gcws,
        retractall('$aleph_global'(hypothesis,hypothesis(_,_,_,_))),
        asserta('$aleph_global'(hypothesis,
			hypothesis([P,N,L|T],Clause,PCover,NCover))),
        reinstate(searchstate).

addgcws:-
        retract('$aleph_search'(gcwshyp,hypothesis(Label,C,P,N))), !,   
	asserta('$aleph_search'(gcwshyp,hypothesis(Label,C,P,N))),
	addhyp,
	add_gcws.

rmhyp:-
        retract('$aleph_search'(pclause,pclause(Head,Body))),
        asserta('$aleph_local'(pclause,pclause(Head,Body))), !.
rmhyp:-
        retract('$aleph_global'(hypothesis,hypothesis(Label,Clause1,P,N))),
        asserta('$aleph_local'(hypothesis,hypothesis(Label,Clause1,P,N))), !.
rmhyp.


covers:-
        get_hyp(Hypothesis),
        label_create(Hypothesis,Label),
        extract_cover(pos,Label,P),
        examples(pos,P),
	length(P,PC),
	p1_message('examples covered'),
	p_message(PC),
	retractall('$aleph_search'(covers,_)),
	asserta('$aleph_search'(covers,covers(P,PC))).
coversn:-
        get_hyp(Hypothesis),
        label_create(Hypothesis,Label),
        extract_cover(neg,Label,N),
        examples(neg,N),
	length(N,NC),
	p1_message('examples covered'),
	p_message(NC),
	retractall('$aleph_search'(coversn,_)),
	asserta('$aleph_search'(coversn,coversn(N,NC))).

% covers(-Number)
% 	as in covers/0, but first checks if being done
% 	within a greedy search
covers(P):-
	get_hyp(Hypothesis),
	(setting(greedy,true) -> 
		'$aleph_global'(atoms,atoms_left(pos,Pos));
		'$aleph_global'(atoms,atoms(pos,Pos))),
	label_create(Hypothesis,pos,Pos,Label),
	retractall('$aleph_search'(covers,_)),
	extract_pos(Label,PCover),
	interval_count(PCover,P),
	asserta('$aleph_search'(covers,covers(PCover,P))).

% coversn(-Number)
% 	as in coversn/0, but first checks if being done
% 	within a greedy search
coversn(N):-
	get_hyp(Hypothesis),
	(setting(greedy,true) ->
		'$aleph_global'(atoms_left,atoms_left(neg,Neg));
		'$aleph_global'(atoms_left,atoms(neg,Neg))),
	label_create(Hypothesis,neg,Neg,Label),
	retractall('$aleph_search'(coversn,_)),
	extract_neg(Label,NCover),
	interval_count(NCover,N),
	asserta('$aleph_search'(coversn,coverns(NCover,N))).

% covers(-List,-Number)
% 	as in covers/1, but returns list of examples covered and their count
covers(PList,P):-
	get_hyp(Hypothesis),
	(setting(greedy,true) -> 
		'$aleph_global'(atoms,atoms_left(pos,Pos));
		'$aleph_global'(atoms,atoms(pos,Pos))),
	label_create(Hypothesis,pos,Pos,Label),
	retractall('$aleph_search'(covers,_)),
	extract_pos(Label,PCover),
	intervals_to_list(PCover,PList),
	length(PList,P),
	asserta('$aleph_search'(covers,covers(PCover,P))).

% coversn(-List,-Number)
% 	as in coversn/1, but returns list of examples covered and their count
coversn(NList,N):-
	get_hyp(Hypothesis),
	(setting(greedy,true) ->
		'$aleph_global'(atoms_left,atoms_left(neg,Neg));
		'$aleph_global'(atoms_left,atoms(neg,Neg))),
	label_create(Hypothesis,neg,Neg,Label),
	retractall('$aleph_search'(coversn,_)),
	extract_neg(Label,NCover),
	intervals_to_list(NCover,NList),
	length(NList,N),
	asserta('$aleph_search'(coversn,coverns(NCover,N))).

example_saturated(Example):-
	'$aleph_sat'(example,example(Num,Type)),
	example(Num,Type,Example).

reset:-
        clean_up,
	clear_cache,
	aleph_abolish('$aleph_global'/2),
	aleph_abolish(example/3),
	assert_static(example(0,uspec,false)),
	set_default(_),
	!.

% Generic timing routine due to Mark Reid.
% Under cygwin, cputime cannot be trusted
% so walltime is used instead. To use cputime, set the body of this
% predicate to "Time is cputime".
stopwatch(Time) :-
        Time is cputime.
%       statistics(walltime,[Time|_]).

wallclock(Time):-
	statistics(real_time,[Time|_]).

time(P,N,[Mean,Sd]):-
        time_loop(N,P,Times),
	mean(Times,Mean),
	sd(Times,Sd).

test(F,Flag,N,T):-
	retractall('$aleph_local'(covered,_)),
	retractall('$aleph_local'(total,_)),
	asserta('$aleph_local'(covered,0)),
	asserta('$aleph_local'(total,0)),
	(F = [_|_] ->
		test_files(F,Flag);
		test_file(F,Flag)
	),
	retract('$aleph_local'(covered,N)),
	retract('$aleph_local'(total,T)).

test_files([],_).
test_files([File|Files],Flag):-
	test_file(File,Flag),
	test_files(Files,Flag).

test_file('?',_):- !.
test_file(File,Flag):-
	setting(portray_examples,Pretty),
	aleph_open(File,read,Stream), !,
	repeat,
	read(Stream,Example),
	(Example = end_of_file -> close(Stream);
		retract('$aleph_local'(total,T0)),
		T1 is T0 + 1,
		asserta('$aleph_local'(total,T1)),
		(once(depth_bound_call(Example)) ->
			(Flag = show ->
				p1_message(covered),
				aleph_portray(Example,Pretty),
				nl;
				true);
			(Flag = show ->
				p1_message('not covered'),
				aleph_portray(Example,Pretty),
				nl;
				true),
			fail),
		retract('$aleph_local'(covered,N0)),
		N1 is N0 + 1,
		asserta('$aleph_local'(covered,N1)),
		fail),
	!.
test_file(File,_):-
	p1_message('cannot open'), p_message(File).

in(false,_):-
	!,
	fail.
in(bottom,Lit):-
	!,
        '$aleph_sat'(lastlit,Last),
        get_clause(1,Last,[],FlatClause),
	aleph_member(Lit,FlatClause).
in((Head:-true),Head):- !.
in((Head:-Body),L):-
	!,
	in((Head,Body),L).
in((L1,_),L1).
in((_,R),L):-
	!,
	in(R,L).
in(L,L).

in((L1,L),L1,L).
in((L1,L),L2,(L1,Rest)):-
	!,
	in(L,L2,Rest).
in(L,L,true).

% draw a random number from a distribution
random(X,normal(Mean,Sigma)):-
	var(X), !,
	normal(Mean,Sigma,X).
random(X,normal(_,_)):-
	!,
	number(X).
	% X >= Mean - 3*Sigma,
	% X =< Mean + 3*Sigma.
random(X,Distr):-
	Distr = [_|_],
	var(X), !,
        draw_element(Distr,X1),
	X = X1.
random(X,Distr):-
	Distr = [_|_],
	nonvar(X), !,
        aleph_member(Prob-X,Distr), 
	Prob > 0.0.

mean(L,M):-
	sum(L,Sum),
	length(L,N),
	M is Sum/N.

sd(L,Sd):-
	length(L,N),
	(N = 1 -> Sd = 0.0;
		sum(L,Sum),
		sumsq(L,SumSq),
		Sd is sqrt(SumSq/(N-1) - (Sum*Sum)/(N*(N-1)))).

sum([],0).
sum([X|T],S):-
	sum(T,S1),
	S is X + S1.

sumsq([],0).
sumsq([X|T],S):-
	sumsq(T,S1),
	S is X*X + S1.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% auxilliary definitions  for some of the above

set_default(A):-
	default_setting(A,B),
	set(A,B),
	fail.
set_default(_).

default_setting(A,B):-
	set_def(A,_,_,_,B,_),
	B \= ''.

% special case for threads as only SWI supports it
check_setting(threads,B):-
	set_def(threads,_,_,Dom,_,_),
	check_legal(Dom,B), 
	prolog_type(P),
	(B > 1 ->
		(P = swi -> true;
                	err_message(set(threads,B)),
                	fail
		);
		true
	), !.
check_setting(A,B):-
	set_def(A,_,_,Dom,_,_), !,
	(check_legal(Dom,B) -> true;
		err_message(set(A,B))).
check_setting(_,_).

check_legal(int(L)-int(U),X):-
	!,
	number(L,IL),
	number(U,IU),
	number(X,IX),
	IX >= IL,
	IX =< IU.
check_legal(float(L)-float(U),X):-
	!,
	number(L,FL),
	number(U,FU),
	number(X,FX),
	FX >= FL,
	FX =< FU.
check_legal([H|T],X):-
	!,
	aleph_member1(X,[H|T]).
check_legal(read(filename),X):-
	X \= '?',
	!,
	exists(X).
check_legal(_,_).

number(+inf,Inf):-
	Inf is inf, !.
number(-inf,MInf):-
	MInf is -inf, !.
number(X,Y):-
	Y is X, !.

setting_definition(A,B,C,D,E,F1):-
	set_def(A,B,C,D,E,F),
	(F = noshow -> F1 = dontshow; F = F1).

% set_def(Parameter,Class,TextDescr,Type,Default,Flag)
set_def(abduce, search-search_strategy,
	'Abduce Atoms and Generalise',
	[true, false], false,
	show).
set_def(best, search-search_space,
	'Label to beat',
	prolog_term,'',
	show).
set_def(cache_clauselength, miscellaneous,
	'Maximum Length of Cached Clauses',
	int(1)-int(+inf), 3,
	show).
set_def(caching, miscellaneous,
	'Cache Clauses in Search',
	[true, false], false,
	show).
set_def(check_redundant, miscellaneous,
	'Check for Redundant Literals',
	[true, false], false,
	show).
set_def(check_good, miscellaneous,
	'Check good clauses for duplicates',
	[true, false], false,
	show).
set_def(check_useless, saturation,
	'Remove I/O unconnected Literals',
	[true, false], false,
	show).
set_def(classes, tree,
	'Class labels',
	prolog_term,'',
	show).
set_def(clauselength_distribution, search-search_strategy,
	'Probablity Distribution over Clauses',
	prolog_term,'',
	show).
set_def(clauselength, search-search_space,
	'Maximum Clause Length',
	int(1)-int(+inf), 4,
	show).
set_def(clauses, search-search_space,
	'Maximum Clauses per Theory',
	int(1)-int(+inf),'',
	show).
set_def(condition, evaluation,
	'Condition SLP',
	[true, false], false,
	show).
set_def(confidence, tree,
	'Confidence for Rule Pruning',
	float(0.0)-float(1.0), 0.95,
	show).
set_def(construct_bottom, saturation,
	'Build a bottom clause',
	[saturation, reduction, false], saturation,
	show).
set_def(depth, miscellaneous,
	'Theorem Proving Depth',
	int(1)-int(+inf), 10,
	show).
set_def(evalfn, evaluation,
	'Evaluation Function',
	[coverage, compression, posonly, pbayes, accuracy, laplace,
	auto_m, mestimate, mse, entropy, gini, sd, wracc, user], coverage,
	show).
set_def(explore, search-search_space,
	'Exhaustive Search of all alternatives',
	[true, false], false,
	show).
set_def(good, miscellaneous,
	'Store good clauses',
	[true, false], false,
	show).
set_def(goodfile, miscellaneous,
	'File of good clauses',
	write(filename),'',
	show).
set_def(gsamplesize, evaluation,
	'Size of random sample',
	int(1)-int(+inf), 100,
	show).
set_def(i, saturation,
	'bound layers of new variables',
	int(1)-int(+inf), 2,
	show).
set_def(interactive, search-search_strategy,
	'Interactive theory construction',
	[true, false], false,
	show).
set_def(language, search-search_space,
	'Maximum occurrence of any predicate symbol in a clause',
	int(1)-int(+inf), +inf,
	show).
set_def(lazy_negs, evaluation,
	'Lazy theorem proving on negative examples',
	[true, false], false,
	show).
set_def(lazy_on_contradiction, evaluation,
	'Lazy theorem proving on contradictions',
	[true, false], false,
	show).
set_def(lazy_on_cost, evaluation,
	'Lazy theorem proving on cost',
	[true, false], false,
	show).
set_def(lookahead, search-search_space,
	'Lookahead for automatic refinement operator',
	int(1)-int(+inf), 1,
	show).
set_def(m, evaluation,
	'M-estimate',
	float(0.0)-float(+inf),'',
	show).
set_def(max_abducibles, search-search_space,
	'Maximum number of atoms in an abductive explanation',
	int(1)-int(+inf), 2,
	show).
set_def(max_features, miscellaneous,
	'Maximum number of features to be constructed',
	int(1)-int(+inf), +inf,
	show).
set_def(minacc, evaluation,
	'Minimum clause accuracy',
	float(0.0)-float(1.0), 0.0,
	show).
set_def(mingain, tree,
	'Minimum expected gain',
	float(0.000001)-float(+inf), 0.05,
	show).
set_def(minpos, evaluation,
	'Minimum pos covered by a clause',
	int(0)-int(+inf), 1,
	show).
set_def(minposfrac, evaluation,
	'Minimum proportion of positives covered by a clause',
	float(0.0)-float(1.0), 0,
	show).
set_def(minscore, evaluation,
	'Minimum utility of an acceptable clause',
	float(-inf)-float(+inf), -inf,
	show).
set_def(moves, search-search_strategy,
	'Number of moves in a randomised local search',
	int(0)-int(+inf), 5,
	show).
set_def(newvars, search-search_space,
	'Existential variables in a clause',
	int(0)-int(+inf), +inf,
	show).
set_def(nodes, search-search_space,
	'Nodes to be explored in the search',
	int(1)-int(+inf), 5000,
	show).
set_def(noise, evaluation,
	'Maximum negatives covered',
	int(0)-int(+inf), 0,
	show).
set_def(nreduce_bottom, saturation,
	'Negative examples based reduction of bottom clause',
	[true, false], false,
	show).
set_def(openlist, search-search_space,
	'Beam width in a greedy search',
	int(1)-int(+inf), +inf,
	show).
set_def(optimise_clauses, miscellaneous,
	'Perform query Optimisation',
	[true, false], false,
	show).
set_def(permute_bottom, saturation,
	'Randomly permute order of negative literals in the bottom clause',
	[true, false], false,
	show).
set_def(portray_examples, miscellaneous,
	'Pretty print examples',
	[true, false], false,
	show).
set_def(portray_hypothesis, miscellaneous,
	'Pretty print hypotheses',
	[true, false], false,
	show).
set_def(portray_literals, miscellaneous,
	'Pretty print literals',
	[true, false], false,
	show).
set_def(portray_search, miscellaneous,
	'Pretty print search',
	[true, false], false,
	show).
set_def(print, miscellaneous,
	'Literals printed per line',
	int(1)-int(+inf), 4,
	show).
set_def(prior, miscellaneous,
	'Prior class distribution',
	prolog_term,'',
	show-ro).
set_def(proof_strategy, miscellaneous,
	'Current proof strategy',
	[restricted_sld, sld, user], restricted_sld,
	show).
set_def(prooftime, miscellaneous,
	'Theorem proving time',
	float(0.0)-float(+inf), +inf,
	show).
set_def(prune_tree, tree,
	'Tree pruning',
	[true, false], false,
	show).
set_def(recordfile, miscellaneous,
	'Log filename',
	write(filename),'',
	show).
set_def(record, miscellaneous,
	'Log to file',
	[true, false], false,
	show).
set_def(refineop, search-search_strategy,
	'Current refinement operator',
	[user, auto, scs, false],'',
	show-ro).
set_def(refine, search-search_strategy,
	'Nature of customised refinement operator',
	[user, auto, scs, false], false,
	show).
set_def(resample, search-search_strategy,
	'Number of times to resample an example',
	int(1)-int(+inf), 1,
	show).
set_def(rls_type, search-search_strategy,
	'Type of randomised local search',
	[gsat, wsat, rrr, anneal], gsat,
	show).
set_def(rulefile, miscellaneous,
	'Rule file',
	write(filename),'',
	show).
set_def(samplesize, search-search_strategy,
	'Size of sample',
	int(0)-int(+inf), 0,
	show).
set_def(scs_percentile, search-search_strategy,
	'Percentile of good clauses for SCS search',
	float(0.0)-float(100.0),'',
	show).
set_def(scs_prob, search-search_strategy,
	'Probability of getting a good clause in SCS search',
	float(0.0)-float(1.0),'',
	show).
set_def(scs_sample, search-search_strategy,
	'Sample size in SCS search',
	int(1)-int(+inf), '',
	show).
set_def(search, search-search_strategy,
	'Search Strategy',
	[bf, df, heuristic, ibs, ils, rls, scs, id, ic, ar, false], bf,
	show).
set_def(searchstrat, search-search_strategy,
	'Current Search Strategy',
	[bf, df, heuristic, ibs, ils, rls, scs, id, ic, ar], bf,
	show-ro).
set_def(searchtime, search-search_strategy,
	'Search time in seconds',
	float(0.0)-float(+inf), +inf,
	show).
set_def(skolemvars, miscellaneous,
	'Counter for non-ground examples',
	int(1)-int(+inf), 10000,
	show).
set_def(splitvars, saturation,
	'Split variable co-refencing',
	[true, false], false,
	show).
set_def(stage, miscellaneous,
	'Aleph processing mode',
	[saturation, reduction, command], command,
	show-ro).
set_def(store_bottom, saturation,
	'Store bottom',
	[true, false], false,
	show).
set_def(subsample, search-search_strategy,
	'Subsample for evaluating a clause',
	[true,false], false,
	show).
set_def(subsamplesize, search-search_strategy,
	'Size of subsample for evaluating a clause',
	int(1)-int(+inf), +inf,
	show).
set_def(temperature, search-search_strategy,
	'Temperature for randomised search annealing',
	float(0.0)-float(+inf), '',
	show).
set_def(test_neg, miscellaneous,
	'Negative examples for testing theory',
	read(filename),'',
	show).
set_def(test_pos, miscellaneous,
	'Positive examples for testing theory',
	read(filename),'',
	show).
set_def(threads, miscellaneous,
	'Number of threads',
	int(1)-int(+inf), 1,
        show).
set_def(train_neg, miscellaneous,
	'Negative examples for training',
	read(filename),'',
	show).
set_def(train_pos, miscellaneous,
	'Positive examples for training',
	read(filename),'',
	show).
set_def(tree_type, tree,
	'Type of tree to construct',
	[classification, class_probability, regression, model], '',
	show).
set_def(tries, search-search_strategy,
	'Number of restarts for a randomised search',
	int(1)-int(+inf), 10,
	show).
set_def(typeoverlap, miscellaneous,
	'Type overlap for induce_modes',
	float(0.0)-float(1.0), 0.95,
	show).
set_def(uniform_sample, search-search_strategy,
	'Distribution to draw clauses from randomly',
	[true, false], false,
	show).
set_def(updateback, miscellaneous,
	'Update background knowledge with clauses found on search',
	[true, false], true,
	noshow).
set_def(verbosity, miscellaneous,
	'Level of verbosity',
	int(0)-int(+inf), 1,
	show).
set_def(version, miscellaneous,
	'Aleph version',
	int(0)-int(+inf), 5,
	show-ro).
set_def(walk, search-search_strategy,
	'Random walk probability for Walksat',
	float(0.0)-float(1.0), '',
	show).


% the following needed for compatibility with P-Progol
special_consideration(search,ida):-
	set(search,bf), set(evalfn,coverage), !.
special_consideration(search,compression):-
	set(search,heuristic), set(evalfn,compression), !.
special_consideration(search,posonly):-
	set(search,heuristic), set(evalfn,posonly), !.
special_consideration(search,user):-
	set(search,heuristic), set(evalfn,user), !.

special_consideration(refine,Refine):-
	set(refineop,Refine), !.
special_consideration(refineop,auto):-
	gen_auto_refine, !.

special_consideration(portray_literals,true):-
	set(print,1), !.

special_consideration(record,true):-
	noset(recordfile_stream),
	(setting(recordfile,F) -> 
		aleph_open(F,append,Stream),
		set(recordfile_stream,Stream);
		true), !.
special_consideration(record,false):-
	noset(recordfile_stream), !.
special_consideration(recordfile,File):-
	noset(recordfile_stream), 
	(setting(record,true) -> 
		aleph_open(File,append,Stream),
		set(recordfile_stream,Stream);
		true), !.
special_consideration(good,true):-
	noset(goodfile_stream),
	(setting(goodfile,F) -> 
		aleph_open(F,append,Stream),
		set(goodfile_stream,Stream);
		true), !.
special_consideration(good,false):-
	noset(goodfile_stream), !.
special_consideration(goodfile,File):-
	noset(goodfile_stream), 
	(setting(good,true) -> 
		aleph_open(File,append,Stream),
		set(goodfile_stream,Stream);
		true), !.
special_consideration(minscore,_):-
	aleph_abolish('$aleph_feature'/2), !.
special_consideration(_,_).

rm_special_consideration(portray_literals,_):-
	set_default(print), !.
rm_special_consideration(refine,_):-
	set_default(refineop), !.
rm_special_consideration(record,_):-
	noset(recordfile_stream), !.
rm_special_consideration(recordfile_stream,_):-
	(setting(recordfile_stream,S) -> close(S); true), !.
rm_special_consideration(good,_):-
	noset(goodfile_stream), !.
rm_special_consideration(goodfile_stream,_):-
	(setting(goodfile_stream,S) -> close(S); true), !.
rm_special_consideration(_,_).


get_hyp((Head:-Body)):-
	'$aleph_search'(pclause,pclause(Head,Body)), !.
get_hyp(Hypothesis):-
        '$aleph_global'(hypothesis,hypothesis(_,Hypothesis,_,_)).

add_hyp(end_of_file):- !.
add_hyp(Clause):-
        nlits(Clause,L),
	label_create(Clause,Label),
        extract_count(pos,Label,PCount),
        extract_count(neg,Label,NCount),
        retractall('$aleph_global'(hypothesis,hypothesis(_,_,_,_))),
        extract_pos(Label,P),
        extract_neg(Label,N),
	setting(evalfn,Evalfn),
	complete_label(Evalfn,Clause,[PCount,NCount,L],Label1),
        asserta('$aleph_global'(hypothesis,hypothesis(Label1,Clause,P,N))).

add_hyp(Label,Clause,P,N):-
        retractall('$aleph_global'(hypothesis,hypothesis(_,_,_,_))),
        asserta('$aleph_global'(hypothesis,hypothesis(Label,Clause,P,N))).

add_theory(Label,Theory,PCover,NCover):-
        aleph_member(C,Theory),
	add_hyp(Label,C,PCover,NCover),
	update_theory(_),
        fail.
add_theory(_,_,PCover,NCover):-
	rm_seeds(pos,PCover),
	(setting(evalfn,posonly) -> rm_seeds(rand,NCover); true),
	'$aleph_global'(atoms_left,atoms_left(pos,PLeft)),
	interval_count(PLeft,PL),
	p1_message('atoms left'), p_message(PL), !.

add_gcws:-
	retract('$aleph_search'(gcwshyp,hypothesis(L,C,P,N))),
	asserta('$aleph_global'(hypothesis,hypothesis(L,C,P,N))),
	update_theory(_),
	fail.
add_gcws.


restorehyp:-
	retract('$aleph_local'(pclause,pclause(Head,Body))),
	assertz('$aleph_search'(pclause,pclause(Head,Body))), !.
restorehyp:-
	retract('$aleph_local'(hypothesis,hypothesis(Label,Clause1,P,N))),
        asserta('$aleph_global'(hypothesis,hypothesis(Label,Clause1,P,N))), !.
restorehyp.

get_hyp_label(_,Label):- var(Label), !.
get_hyp_label((_:-Body),[P,N,L]):-
        nlits(Body,L1),
        L is L1 + 1,
        ('$aleph_search'(covers,covers(_,P))-> true;
                        covers(_),
                        '$aleph_search'(covers,covers(_,P))),
        ('$aleph_search'(coversn,coverns(_,N))-> true;
                        coversn(_),
                        '$aleph_search'(coversn,coversn(_,N))).
 

show_global(Key,Pred):-
        '$aleph_global'(Key,Pred),
        copy_term(Pred,Pred1), numbervars(Pred1,0,_),
        aleph_writeq(Pred1), write('.'), nl,
        fail.
show_global(_,_).

aleph_portray(hypothesis,true):-
	aleph_portray(hypothesis), !.
aleph_portray(hypothesis,false):- 
	p_message('hypothesis'),
	hypothesis(Head,Body,_),
	pp_dclause((Head:-Body)), !.
aleph_portray(_,hypothesis):-  !.

aleph_portray(search,true):-
	aleph_portray(search), !.
aleph_portray(search,_):- !.

aleph_portray(train_pos,true):-
	aleph_portray(train_pos), !.
aleph_portray(train_pos,_):-
	!,
	setting(train_pos,File),
	show_file(File).

aleph_portray(train_neg,true):-
	aleph_portray(train_neg), !.
aleph_portray(train_neg,_):-
	!,
	setting(train_neg,File),
	show_file(File).

aleph_portray(test_pos,true):-
	aleph_portray(test_pos), !.
aleph_portray(test_pos,_):-
	!,
	setting(test_pos,File),
	show_file(File).

aleph_portray(test_neg,true):-
	aleph_portray(test_neg), !.
aleph_portray(test_neg,_):-
	!,
	setting(test_neg,File),
	show_file(File).

aleph_portray(Lit,true):-
	aleph_portray(Lit), !.
aleph_portray(Lit,_):-
        aleph_writeq(Lit).

aleph_writeq(Lit):-
	write_term(Lit,[numbervars(true),quoted(true)]).

show_file(File):-
	aleph_open(File,read,Stream), 
	repeat,
	read(Stream,Clause),
	(Clause = end_of_file -> close(Stream);
		writeq(Clause), write('.'), nl,
		fail).

time_loop(0,_,[]):- !.
time_loop(N,P,[T|Times]):-
	wallclock(S),
        P,
	wallclock(F),
	T is F - S,
        N1 is N - 1,
        time_loop(N1,P,Times).

list_profile :-
        % get number of calls for each profiled procedure
        findall(D-P,profile_data(P,calls,D),LP),
        % sort them
        sort(LP,SLP),
        % and output (note the most often called predicates will come last
        write_profile_data(SLP).

write_profile_data([]).
        write_profile_data([D-P|SLP]) :-
        % just swap the two calls to get most often called predicates first.
        format('~w: ~w~n', [P,D]),
        write_profile_data(SLP).
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F I N A L  C O M M A N D S

:-
	nl, nl,
	write('A L E P H'), nl,
	aleph_version(Version), write('Version '), write(Version), nl,
	aleph_version_date(Date), write('Last modified: '), write(Date), nl, nl,
	aleph_manual(Man),
	write('Manual: '),
	write(Man), nl, nl.

:- aleph_version(V), set(version,V), reset.
