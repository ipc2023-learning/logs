class(A,B,C,D) :-
   'ini:at-robot'(B,C), random(D,[0.75-dont_ground,0.25-ground]).
class(A,B,C,D) :-
   not 'ini:at-robot'(B,C), random(D,[0.994949-ground,0.00505051-dont_ground]).
