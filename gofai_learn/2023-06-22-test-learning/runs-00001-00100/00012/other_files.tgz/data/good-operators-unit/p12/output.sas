begin_version
3
end_version
begin_metric
0
end_metric
169
begin_variable
var0
-1
169
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var3
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var4
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var5
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var6
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var7
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var8
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var9
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var10
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var11
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var12
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var13
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var14
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var15
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var16
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var17
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var18
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var19
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var20
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var21
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var22
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var23
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var24
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var25
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var26
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var27
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var28
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var29
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var30
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var31
-1
2
Atom visited(loc-x10-y2)
NegatedAtom visited(loc-x10-y2)
end_variable
begin_variable
var32
-1
2
Atom visited(loc-x10-y3)
NegatedAtom visited(loc-x10-y3)
end_variable
begin_variable
var33
-1
2
Atom visited(loc-x10-y4)
NegatedAtom visited(loc-x10-y4)
end_variable
begin_variable
var34
-1
2
Atom visited(loc-x10-y5)
NegatedAtom visited(loc-x10-y5)
end_variable
begin_variable
var35
-1
2
Atom visited(loc-x10-y6)
NegatedAtom visited(loc-x10-y6)
end_variable
begin_variable
var36
-1
2
Atom visited(loc-x10-y7)
NegatedAtom visited(loc-x10-y7)
end_variable
begin_variable
var37
-1
2
Atom visited(loc-x10-y8)
NegatedAtom visited(loc-x10-y8)
end_variable
begin_variable
var38
-1
2
Atom visited(loc-x10-y9)
NegatedAtom visited(loc-x10-y9)
end_variable
begin_variable
var39
-1
2
Atom visited(loc-x11-y0)
NegatedAtom visited(loc-x11-y0)
end_variable
begin_variable
var40
-1
2
Atom visited(loc-x11-y1)
NegatedAtom visited(loc-x11-y1)
end_variable
begin_variable
var41
-1
2
Atom visited(loc-x11-y10)
NegatedAtom visited(loc-x11-y10)
end_variable
begin_variable
var42
-1
2
Atom visited(loc-x11-y11)
NegatedAtom visited(loc-x11-y11)
end_variable
begin_variable
var43
-1
2
Atom visited(loc-x11-y12)
NegatedAtom visited(loc-x11-y12)
end_variable
begin_variable
var44
-1
2
Atom visited(loc-x11-y2)
NegatedAtom visited(loc-x11-y2)
end_variable
begin_variable
var45
-1
2
Atom visited(loc-x11-y3)
NegatedAtom visited(loc-x11-y3)
end_variable
begin_variable
var46
-1
2
Atom visited(loc-x11-y4)
NegatedAtom visited(loc-x11-y4)
end_variable
begin_variable
var47
-1
2
Atom visited(loc-x11-y5)
NegatedAtom visited(loc-x11-y5)
end_variable
begin_variable
var48
-1
2
Atom visited(loc-x11-y6)
NegatedAtom visited(loc-x11-y6)
end_variable
begin_variable
var49
-1
2
Atom visited(loc-x11-y7)
NegatedAtom visited(loc-x11-y7)
end_variable
begin_variable
var50
-1
2
Atom visited(loc-x11-y8)
NegatedAtom visited(loc-x11-y8)
end_variable
begin_variable
var51
-1
2
Atom visited(loc-x11-y9)
NegatedAtom visited(loc-x11-y9)
end_variable
begin_variable
var52
-1
2
Atom visited(loc-x12-y0)
NegatedAtom visited(loc-x12-y0)
end_variable
begin_variable
var53
-1
2
Atom visited(loc-x12-y1)
NegatedAtom visited(loc-x12-y1)
end_variable
begin_variable
var54
-1
2
Atom visited(loc-x12-y10)
NegatedAtom visited(loc-x12-y10)
end_variable
begin_variable
var55
-1
2
Atom visited(loc-x12-y11)
NegatedAtom visited(loc-x12-y11)
end_variable
begin_variable
var56
-1
2
Atom visited(loc-x12-y12)
NegatedAtom visited(loc-x12-y12)
end_variable
begin_variable
var57
-1
2
Atom visited(loc-x12-y2)
NegatedAtom visited(loc-x12-y2)
end_variable
begin_variable
var58
-1
2
Atom visited(loc-x12-y3)
NegatedAtom visited(loc-x12-y3)
end_variable
begin_variable
var59
-1
2
Atom visited(loc-x12-y4)
NegatedAtom visited(loc-x12-y4)
end_variable
begin_variable
var60
-1
2
Atom visited(loc-x12-y5)
NegatedAtom visited(loc-x12-y5)
end_variable
begin_variable
var61
-1
2
Atom visited(loc-x12-y6)
NegatedAtom visited(loc-x12-y6)
end_variable
begin_variable
var62
-1
2
Atom visited(loc-x12-y7)
NegatedAtom visited(loc-x12-y7)
end_variable
begin_variable
var63
-1
2
Atom visited(loc-x12-y8)
NegatedAtom visited(loc-x12-y8)
end_variable
begin_variable
var64
-1
2
Atom visited(loc-x12-y9)
NegatedAtom visited(loc-x12-y9)
end_variable
begin_variable
var65
-1
2
Atom visited(loc-x2-y0)
NegatedAtom visited(loc-x2-y0)
end_variable
begin_variable
var66
-1
2
Atom visited(loc-x2-y1)
NegatedAtom visited(loc-x2-y1)
end_variable
begin_variable
var67
-1
2
Atom visited(loc-x2-y10)
NegatedAtom visited(loc-x2-y10)
end_variable
begin_variable
var68
-1
2
Atom visited(loc-x2-y11)
NegatedAtom visited(loc-x2-y11)
end_variable
begin_variable
var69
-1
2
Atom visited(loc-x2-y12)
NegatedAtom visited(loc-x2-y12)
end_variable
begin_variable
var70
-1
2
Atom visited(loc-x2-y2)
NegatedAtom visited(loc-x2-y2)
end_variable
begin_variable
var71
-1
2
Atom visited(loc-x2-y3)
NegatedAtom visited(loc-x2-y3)
end_variable
begin_variable
var72
-1
2
Atom visited(loc-x2-y4)
NegatedAtom visited(loc-x2-y4)
end_variable
begin_variable
var73
-1
2
Atom visited(loc-x2-y5)
NegatedAtom visited(loc-x2-y5)
end_variable
begin_variable
var74
-1
2
Atom visited(loc-x2-y6)
NegatedAtom visited(loc-x2-y6)
end_variable
begin_variable
var75
-1
2
Atom visited(loc-x2-y7)
NegatedAtom visited(loc-x2-y7)
end_variable
begin_variable
var76
-1
2
Atom visited(loc-x2-y8)
NegatedAtom visited(loc-x2-y8)
end_variable
begin_variable
var77
-1
2
Atom visited(loc-x2-y9)
NegatedAtom visited(loc-x2-y9)
end_variable
begin_variable
var78
-1
2
Atom visited(loc-x3-y0)
NegatedAtom visited(loc-x3-y0)
end_variable
begin_variable
var79
-1
2
Atom visited(loc-x3-y1)
NegatedAtom visited(loc-x3-y1)
end_variable
begin_variable
var80
-1
2
Atom visited(loc-x3-y10)
NegatedAtom visited(loc-x3-y10)
end_variable
begin_variable
var81
-1
2
Atom visited(loc-x3-y11)
NegatedAtom visited(loc-x3-y11)
end_variable
begin_variable
var82
-1
2
Atom visited(loc-x3-y12)
NegatedAtom visited(loc-x3-y12)
end_variable
begin_variable
var83
-1
2
Atom visited(loc-x3-y2)
NegatedAtom visited(loc-x3-y2)
end_variable
begin_variable
var84
-1
2
Atom visited(loc-x3-y3)
NegatedAtom visited(loc-x3-y3)
end_variable
begin_variable
var85
-1
2
Atom visited(loc-x3-y4)
NegatedAtom visited(loc-x3-y4)
end_variable
begin_variable
var86
-1
2
Atom visited(loc-x3-y5)
NegatedAtom visited(loc-x3-y5)
end_variable
begin_variable
var87
-1
2
Atom visited(loc-x3-y6)
NegatedAtom visited(loc-x3-y6)
end_variable
begin_variable
var88
-1
2
Atom visited(loc-x3-y7)
NegatedAtom visited(loc-x3-y7)
end_variable
begin_variable
var89
-1
2
Atom visited(loc-x3-y8)
NegatedAtom visited(loc-x3-y8)
end_variable
begin_variable
var90
-1
2
Atom visited(loc-x3-y9)
NegatedAtom visited(loc-x3-y9)
end_variable
begin_variable
var91
-1
2
Atom visited(loc-x4-y0)
NegatedAtom visited(loc-x4-y0)
end_variable
begin_variable
var92
-1
2
Atom visited(loc-x4-y1)
NegatedAtom visited(loc-x4-y1)
end_variable
begin_variable
var93
-1
2
Atom visited(loc-x4-y10)
NegatedAtom visited(loc-x4-y10)
end_variable
begin_variable
var94
-1
2
Atom visited(loc-x4-y11)
NegatedAtom visited(loc-x4-y11)
end_variable
begin_variable
var95
-1
2
Atom visited(loc-x4-y12)
NegatedAtom visited(loc-x4-y12)
end_variable
begin_variable
var96
-1
2
Atom visited(loc-x4-y2)
NegatedAtom visited(loc-x4-y2)
end_variable
begin_variable
var97
-1
2
Atom visited(loc-x4-y3)
NegatedAtom visited(loc-x4-y3)
end_variable
begin_variable
var98
-1
2
Atom visited(loc-x4-y4)
NegatedAtom visited(loc-x4-y4)
end_variable
begin_variable
var99
-1
2
Atom visited(loc-x4-y5)
NegatedAtom visited(loc-x4-y5)
end_variable
begin_variable
var100
-1
2
Atom visited(loc-x4-y6)
NegatedAtom visited(loc-x4-y6)
end_variable
begin_variable
var101
-1
2
Atom visited(loc-x4-y7)
NegatedAtom visited(loc-x4-y7)
end_variable
begin_variable
var102
-1
2
Atom visited(loc-x4-y8)
NegatedAtom visited(loc-x4-y8)
end_variable
begin_variable
var103
-1
2
Atom visited(loc-x4-y9)
NegatedAtom visited(loc-x4-y9)
end_variable
begin_variable
var104
-1
2
Atom visited(loc-x5-y0)
NegatedAtom visited(loc-x5-y0)
end_variable
begin_variable
var105
-1
2
Atom visited(loc-x5-y1)
NegatedAtom visited(loc-x5-y1)
end_variable
begin_variable
var106
-1
2
Atom visited(loc-x5-y10)
NegatedAtom visited(loc-x5-y10)
end_variable
begin_variable
var107
-1
2
Atom visited(loc-x5-y11)
NegatedAtom visited(loc-x5-y11)
end_variable
begin_variable
var108
-1
2
Atom visited(loc-x5-y12)
NegatedAtom visited(loc-x5-y12)
end_variable
begin_variable
var109
-1
2
Atom visited(loc-x5-y2)
NegatedAtom visited(loc-x5-y2)
end_variable
begin_variable
var110
-1
2
Atom visited(loc-x5-y3)
NegatedAtom visited(loc-x5-y3)
end_variable
begin_variable
var111
-1
2
Atom visited(loc-x5-y4)
NegatedAtom visited(loc-x5-y4)
end_variable
begin_variable
var112
-1
2
Atom visited(loc-x5-y5)
NegatedAtom visited(loc-x5-y5)
end_variable
begin_variable
var113
-1
2
Atom visited(loc-x5-y6)
NegatedAtom visited(loc-x5-y6)
end_variable
begin_variable
var114
-1
2
Atom visited(loc-x5-y7)
NegatedAtom visited(loc-x5-y7)
end_variable
begin_variable
var115
-1
2
Atom visited(loc-x5-y8)
NegatedAtom visited(loc-x5-y8)
end_variable
begin_variable
var116
-1
2
Atom visited(loc-x5-y9)
NegatedAtom visited(loc-x5-y9)
end_variable
begin_variable
var117
-1
2
Atom visited(loc-x6-y0)
NegatedAtom visited(loc-x6-y0)
end_variable
begin_variable
var118
-1
2
Atom visited(loc-x6-y1)
NegatedAtom visited(loc-x6-y1)
end_variable
begin_variable
var119
-1
2
Atom visited(loc-x6-y10)
NegatedAtom visited(loc-x6-y10)
end_variable
begin_variable
var120
-1
2
Atom visited(loc-x6-y11)
NegatedAtom visited(loc-x6-y11)
end_variable
begin_variable
var121
-1
2
Atom visited(loc-x6-y12)
NegatedAtom visited(loc-x6-y12)
end_variable
begin_variable
var122
-1
2
Atom visited(loc-x6-y2)
NegatedAtom visited(loc-x6-y2)
end_variable
begin_variable
var123
-1
2
Atom visited(loc-x6-y3)
NegatedAtom visited(loc-x6-y3)
end_variable
begin_variable
var124
-1
2
Atom visited(loc-x6-y4)
NegatedAtom visited(loc-x6-y4)
end_variable
begin_variable
var125
-1
2
Atom visited(loc-x6-y5)
NegatedAtom visited(loc-x6-y5)
end_variable
begin_variable
var126
-1
2
Atom visited(loc-x6-y6)
NegatedAtom visited(loc-x6-y6)
end_variable
begin_variable
var127
-1
2
Atom visited(loc-x6-y7)
NegatedAtom visited(loc-x6-y7)
end_variable
begin_variable
var128
-1
2
Atom visited(loc-x6-y8)
NegatedAtom visited(loc-x6-y8)
end_variable
begin_variable
var129
-1
2
Atom visited(loc-x6-y9)
NegatedAtom visited(loc-x6-y9)
end_variable
begin_variable
var130
-1
2
Atom visited(loc-x7-y0)
NegatedAtom visited(loc-x7-y0)
end_variable
begin_variable
var131
-1
2
Atom visited(loc-x7-y1)
NegatedAtom visited(loc-x7-y1)
end_variable
begin_variable
var132
-1
2
Atom visited(loc-x7-y10)
NegatedAtom visited(loc-x7-y10)
end_variable
begin_variable
var133
-1
2
Atom visited(loc-x7-y11)
NegatedAtom visited(loc-x7-y11)
end_variable
begin_variable
var134
-1
2
Atom visited(loc-x7-y12)
NegatedAtom visited(loc-x7-y12)
end_variable
begin_variable
var135
-1
2
Atom visited(loc-x7-y2)
NegatedAtom visited(loc-x7-y2)
end_variable
begin_variable
var136
-1
2
Atom visited(loc-x7-y3)
NegatedAtom visited(loc-x7-y3)
end_variable
begin_variable
var137
-1
2
Atom visited(loc-x7-y4)
NegatedAtom visited(loc-x7-y4)
end_variable
begin_variable
var138
-1
2
Atom visited(loc-x7-y5)
NegatedAtom visited(loc-x7-y5)
end_variable
begin_variable
var139
-1
2
Atom visited(loc-x7-y6)
NegatedAtom visited(loc-x7-y6)
end_variable
begin_variable
var140
-1
2
Atom visited(loc-x7-y7)
NegatedAtom visited(loc-x7-y7)
end_variable
begin_variable
var141
-1
2
Atom visited(loc-x7-y8)
NegatedAtom visited(loc-x7-y8)
end_variable
begin_variable
var142
-1
2
Atom visited(loc-x7-y9)
NegatedAtom visited(loc-x7-y9)
end_variable
begin_variable
var143
-1
2
Atom visited(loc-x8-y0)
NegatedAtom visited(loc-x8-y0)
end_variable
begin_variable
var144
-1
2
Atom visited(loc-x8-y1)
NegatedAtom visited(loc-x8-y1)
end_variable
begin_variable
var145
-1
2
Atom visited(loc-x8-y10)
NegatedAtom visited(loc-x8-y10)
end_variable
begin_variable
var146
-1
2
Atom visited(loc-x8-y11)
NegatedAtom visited(loc-x8-y11)
end_variable
begin_variable
var147
-1
2
Atom visited(loc-x8-y12)
NegatedAtom visited(loc-x8-y12)
end_variable
begin_variable
var148
-1
2
Atom visited(loc-x8-y2)
NegatedAtom visited(loc-x8-y2)
end_variable
begin_variable
var149
-1
2
Atom visited(loc-x8-y3)
NegatedAtom visited(loc-x8-y3)
end_variable
begin_variable
var150
-1
2
Atom visited(loc-x8-y4)
NegatedAtom visited(loc-x8-y4)
end_variable
begin_variable
var151
-1
2
Atom visited(loc-x8-y5)
NegatedAtom visited(loc-x8-y5)
end_variable
begin_variable
var152
-1
2
Atom visited(loc-x8-y6)
NegatedAtom visited(loc-x8-y6)
end_variable
begin_variable
var153
-1
2
Atom visited(loc-x8-y7)
NegatedAtom visited(loc-x8-y7)
end_variable
begin_variable
var154
-1
2
Atom visited(loc-x8-y8)
NegatedAtom visited(loc-x8-y8)
end_variable
begin_variable
var155
-1
2
Atom visited(loc-x8-y9)
NegatedAtom visited(loc-x8-y9)
end_variable
begin_variable
var156
-1
2
Atom visited(loc-x9-y0)
NegatedAtom visited(loc-x9-y0)
end_variable
begin_variable
var157
-1
2
Atom visited(loc-x9-y1)
NegatedAtom visited(loc-x9-y1)
end_variable
begin_variable
var158
-1
2
Atom visited(loc-x9-y10)
NegatedAtom visited(loc-x9-y10)
end_variable
begin_variable
var159
-1
2
Atom visited(loc-x9-y11)
NegatedAtom visited(loc-x9-y11)
end_variable
begin_variable
var160
-1
2
Atom visited(loc-x9-y12)
NegatedAtom visited(loc-x9-y12)
end_variable
begin_variable
var161
-1
2
Atom visited(loc-x9-y2)
NegatedAtom visited(loc-x9-y2)
end_variable
begin_variable
var162
-1
2
Atom visited(loc-x9-y3)
NegatedAtom visited(loc-x9-y3)
end_variable
begin_variable
var163
-1
2
Atom visited(loc-x9-y4)
NegatedAtom visited(loc-x9-y4)
end_variable
begin_variable
var164
-1
2
Atom visited(loc-x9-y5)
NegatedAtom visited(loc-x9-y5)
end_variable
begin_variable
var165
-1
2
Atom visited(loc-x9-y6)
NegatedAtom visited(loc-x9-y6)
end_variable
begin_variable
var166
-1
2
Atom visited(loc-x9-y7)
NegatedAtom visited(loc-x9-y7)
end_variable
begin_variable
var167
-1
2
Atom visited(loc-x9-y8)
NegatedAtom visited(loc-x9-y8)
end_variable
begin_variable
var168
-1
2
Atom visited(loc-x9-y9)
NegatedAtom visited(loc-x9-y9)
end_variable
1
begin_mutex_group
169
0 0
0 1
0 2
0 3
0 4
0 5
0 6
0 7
0 8
0 9
0 10
0 11
0 12
0 13
0 14
0 15
0 16
0 17
0 18
0 19
0 20
0 21
0 22
0 23
0 24
0 25
0 26
0 27
0 28
0 29
0 30
0 31
0 32
0 33
0 34
0 35
0 36
0 37
0 38
0 39
0 40
0 41
0 42
0 43
0 44
0 45
0 46
0 47
0 48
0 49
0 50
0 51
0 52
0 53
0 54
0 55
0 56
0 57
0 58
0 59
0 60
0 61
0 62
0 63
0 64
0 65
0 66
0 67
0 68
0 69
0 70
0 71
0 72
0 73
0 74
0 75
0 76
0 77
0 78
0 79
0 80
0 81
0 82
0 83
0 84
0 85
0 86
0 87
0 88
0 89
0 90
0 91
0 92
0 93
0 94
0 95
0 96
0 97
0 98
0 99
0 100
0 101
0 102
0 103
0 104
0 105
0 106
0 107
0 108
0 109
0 110
0 111
0 112
0 113
0 114
0 115
0 116
0 117
0 118
0 119
0 120
0 121
0 122
0 123
0 124
0 125
0 126
0 127
0 128
0 129
0 130
0 131
0 132
0 133
0 134
0 135
0 136
0 137
0 138
0 139
0 140
0 141
0 142
0 143
0 144
0 145
0 146
0 147
0 148
0 149
0 150
0 151
0 152
0 153
0 154
0 155
0 156
0 157
0 158
0 159
0 160
0 161
0 162
0 163
0 164
0 165
0 166
0 167
0 168
end_mutex_group
begin_state
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
end_state
begin_goal
168
1 0
2 0
3 0
4 0
5 0
6 0
7 0
8 0
9 0
10 0
11 0
12 0
13 0
14 0
15 0
16 0
17 0
18 0
19 0
20 0
21 0
22 0
23 0
24 0
25 0
26 0
27 0
28 0
29 0
30 0
31 0
32 0
33 0
34 0
35 0
36 0
37 0
38 0
39 0
40 0
41 0
42 0
43 0
44 0
45 0
46 0
47 0
48 0
49 0
50 0
51 0
52 0
53 0
54 0
55 0
56 0
57 0
58 0
59 0
60 0
61 0
62 0
63 0
64 0
65 0
66 0
67 0
68 0
69 0
70 0
71 0
72 0
73 0
74 0
75 0
76 0
77 0
78 0
79 0
80 0
81 0
82 0
83 0
84 0
85 0
86 0
87 0
88 0
89 0
90 0
91 0
92 0
93 0
94 0
95 0
96 0
97 0
98 0
99 0
100 0
101 0
102 0
103 0
104 0
105 0
106 0
107 0
108 0
109 0
110 0
111 0
112 0
113 0
114 0
115 0
116 0
117 0
118 0
119 0
120 0
121 0
122 0
123 0
124 0
125 0
126 0
127 0
128 0
129 0
130 0
131 0
132 0
133 0
134 0
135 0
136 0
137 0
138 0
139 0
140 0
141 0
142 0
143 0
144 0
145 0
146 0
147 0
148 0
149 0
150 0
151 0
152 0
153 0
154 0
155 0
156 0
157 0
158 0
159 0
160 0
161 0
162 0
163 0
164 0
165 0
166 0
167 0
168 0
end_goal
624
begin_operator
move loc-x0-y0 loc-x0-y1
0
2
0 0 0 1
0 1 -1 0
1
end_operator
begin_operator
move loc-x0-y0 loc-x1-y0
0
2
0 0 0 13
0 13 -1 0
1
end_operator
begin_operator
move loc-x0-y1 loc-x0-y0
0
1
0 0 1 0
1
end_operator
begin_operator
move loc-x0-y1 loc-x0-y2
0
2
0 0 1 5
0 5 -1 0
1
end_operator
begin_operator
move loc-x0-y1 loc-x1-y1
0
2
0 0 1 14
0 14 -1 0
1
end_operator
begin_operator
move loc-x0-y10 loc-x0-y11
0
2
0 0 2 3
0 3 -1 0
1
end_operator
begin_operator
move loc-x0-y10 loc-x0-y9
0
2
0 0 2 12
0 12 -1 0
1
end_operator
begin_operator
move loc-x0-y10 loc-x1-y10
0
2
0 0 2 15
0 15 -1 0
1
end_operator
begin_operator
move loc-x0-y11 loc-x0-y10
0
2
0 0 3 2
0 2 -1 0
1
end_operator
begin_operator
move loc-x0-y11 loc-x0-y12
0
2
0 0 3 4
0 4 -1 0
1
end_operator
begin_operator
move loc-x0-y11 loc-x1-y11
0
2
0 0 3 16
0 16 -1 0
1
end_operator
begin_operator
move loc-x0-y12 loc-x0-y11
0
2
0 0 4 3
0 3 -1 0
1
end_operator
begin_operator
move loc-x0-y12 loc-x1-y12
0
2
0 0 4 17
0 17 -1 0
1
end_operator
begin_operator
move loc-x0-y2 loc-x0-y1
0
2
0 0 5 1
0 1 -1 0
1
end_operator
begin_operator
move loc-x0-y2 loc-x0-y3
0
2
0 0 5 6
0 6 -1 0
1
end_operator
begin_operator
move loc-x0-y2 loc-x1-y2
0
2
0 0 5 18
0 18 -1 0
1
end_operator
begin_operator
move loc-x0-y3 loc-x0-y2
0
2
0 0 6 5
0 5 -1 0
1
end_operator
begin_operator
move loc-x0-y3 loc-x0-y4
0
2
0 0 6 7
0 7 -1 0
1
end_operator
begin_operator
move loc-x0-y3 loc-x1-y3
0
2
0 0 6 19
0 19 -1 0
1
end_operator
begin_operator
move loc-x0-y4 loc-x0-y3
0
2
0 0 7 6
0 6 -1 0
1
end_operator
begin_operator
move loc-x0-y4 loc-x0-y5
0
2
0 0 7 8
0 8 -1 0
1
end_operator
begin_operator
move loc-x0-y4 loc-x1-y4
0
2
0 0 7 20
0 20 -1 0
1
end_operator
begin_operator
move loc-x0-y5 loc-x0-y4
0
2
0 0 8 7
0 7 -1 0
1
end_operator
begin_operator
move loc-x0-y5 loc-x0-y6
0
2
0 0 8 9
0 9 -1 0
1
end_operator
begin_operator
move loc-x0-y5 loc-x1-y5
0
2
0 0 8 21
0 21 -1 0
1
end_operator
begin_operator
move loc-x0-y6 loc-x0-y5
0
2
0 0 9 8
0 8 -1 0
1
end_operator
begin_operator
move loc-x0-y6 loc-x0-y7
0
2
0 0 9 10
0 10 -1 0
1
end_operator
begin_operator
move loc-x0-y6 loc-x1-y6
0
2
0 0 9 22
0 22 -1 0
1
end_operator
begin_operator
move loc-x0-y7 loc-x0-y6
0
2
0 0 10 9
0 9 -1 0
1
end_operator
begin_operator
move loc-x0-y7 loc-x0-y8
0
2
0 0 10 11
0 11 -1 0
1
end_operator
begin_operator
move loc-x0-y7 loc-x1-y7
0
2
0 0 10 23
0 23 -1 0
1
end_operator
begin_operator
move loc-x0-y8 loc-x0-y7
0
2
0 0 11 10
0 10 -1 0
1
end_operator
begin_operator
move loc-x0-y8 loc-x0-y9
0
2
0 0 11 12
0 12 -1 0
1
end_operator
begin_operator
move loc-x0-y8 loc-x1-y8
0
2
0 0 11 24
0 24 -1 0
1
end_operator
begin_operator
move loc-x0-y9 loc-x0-y10
0
2
0 0 12 2
0 2 -1 0
1
end_operator
begin_operator
move loc-x0-y9 loc-x0-y8
0
2
0 0 12 11
0 11 -1 0
1
end_operator
begin_operator
move loc-x0-y9 loc-x1-y9
0
2
0 0 12 25
0 25 -1 0
1
end_operator
begin_operator
move loc-x1-y0 loc-x0-y0
0
1
0 0 13 0
1
end_operator
begin_operator
move loc-x




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 87 100
0 100 -1 0
1
end_operator
begin_operator
move loc-x3-y7 loc-x2-y7
0
2
0 0 88 75
0 75 -1 0
1
end_operator
begin_operator
move loc-x3-y7 loc-x3-y6
0
2
0 0 88 87
0 87 -1 0
1
end_operator
begin_operator
move loc-x3-y7 loc-x3-y8
0
2
0 0 88 89
0 89 -1 0
1
end_operator
begin_operator
move loc-x3-y7 loc-x4-y7
0
2
0 0 88 101
0 101 -1 0
1
end_operator
begin_operator
move loc-x3-y8 loc-x2-y8
0
2
0 0 89 76
0 76 -1 0
1
end_operator
begin_operator
move loc-x3-y8 loc-x3-y7
0
2
0 0 89 88
0 88 -1 0
1
end_operator
begin_operator
move loc-x3-y8 loc-x3-y9
0
2
0 0 89 90
0 90 -1 0
1
end_operator
begin_operator
move loc-x3-y8 loc-x4-y8
0
2
0 0 89 102
0 102 -1 0
1
end_operator
begin_operator
move loc-x3-y9 loc-x2-y9
0
2
0 0 90 77
0 77 -1 0
1
end_operator
begin_operator
move loc-x3-y9 loc-x3-y10
0
2
0 0 90 80
0 80 -1 0
1
end_operator
begin_operator
move loc-x3-y9 loc-x3-y8
0
2
0 0 90 89
0 89 -1 0
1
end_operator
begin_operator
move loc-x3-y9 loc-x4-y9
0
2
0 0 90 103
0 103 -1 0
1
end_operator
begin_operator
move loc-x4-y0 loc-x3-y0
0
2
0 0 91 78
0 78 -1 0
1
end_operator
begin_operator
move loc-x4-y0 loc-x4-y1
0
2
0 0 91 92
0 92 -1 0
1
end_operator
begin_operator
move loc-x4-y0 loc-x5-y0
0
2
0 0 91 104
0 104 -1 0
1
end_operator
begin_operator
move loc-x4-y1 loc-x3-y1
0
2
0 0 92 79
0 79 -1 0
1
end_operator
begin_operator
move loc-x4-y1 loc-x4-y0
0
2
0 0 92 91
0 91 -1 0
1
end_operator
begin_operator
move loc-x4-y1 loc-x4-y2
0
2
0 0 92 96
0 96 -1 0
1
end_operator
begin_operator
move loc-x4-y1 loc-x5-y1
0
2
0 0 92 105
0 105 -1 0
1
end_operator
begin_operator
move loc-x4-y10 loc-x3-y10
0
2
0 0 93 80
0 80 -1 0
1
end_operator
begin_operator
move loc-x4-y10 loc-x4-y11
0
2
0 0 93 94
0 94 -1 0
1
end_operator
begin_operator
move loc-x4-y10 loc-x4-y9
0
2
0 0 93 103
0 103 -1 0
1
end_operator
begin_operator
move loc-x4-y10 loc-x5-y10
0
2
0 0 93 106
0 106 -1 0
1
end_operator
begin_operator
move loc-x4-y11 loc-x3-y11
0
2
0 0 94 81
0 81 -1 0
1
end_operator
begin_operator
move loc-x4-y11 loc-x4-y10
0
2
0 0 94 93
0 93 -1 0
1
end_operator
begin_operator
move loc-x4-y11 loc-x4-y12
0
2
0 0 94 95
0 95 -1 0
1
end_operator
begin_operator
move loc-x4-y11 loc-x5-y11
0
2
0 0 94 107
0 107 -1 0
1
end_operator
begin_operator
move loc-x4-y12 loc-x3-y12
0
2
0 0 95 82
0 82 -1 0
1
end_operator
begin_operator
move loc-x4-y12 loc-x4-y11
0
2
0 0 95 94
0 94 -1 0
1
end_operator
begin_operator
move loc-x4-y12 loc-x5-y12
0
2
0 0 95 108
0 108 -1 0
1
end_operator
begin_operator
move loc-x4-y2 loc-x3-y2
0
2
0 0 96 83
0 83 -1 0
1
end_operator
begin_operator
move loc-x4-y2 loc-x4-y1
0
2
0 0 96 92
0 92 -1 0
1
end_operator
begin_operator
move loc-x4-y2 loc-x4-y3
0
2
0 0 96 97
0 97 -1 0
1
end_operator
begin_operator
move loc-x4-y2 loc-x5-y2
0
2
0 0 96 109
0 109 -1 0
1
end_operator
begin_operator
move loc-x4-y3 loc-x3-y3
0
2
0 0 97 84
0 84 -1 0
1
end_operator
begin_operator
move loc-x4-y3 loc-x4-y2
0
2
0 0 97 96
0 96 -1 0
1
end_operator
begin_operator
move loc-x4-y3 loc-x4-y4
0
2
0 0 97 98
0 98 -1 0
1
end_operator
begin_operator
move loc-x4-y3 loc-x5-y3
0
2
0 0 97 110
0 110 -1 0
1
end_operator
begin_operator
move loc-x4-y4 loc-x3-y4
0
2
0 0 98 85
0 85 -1 0
1
end_operator
begin_operator
move loc-x4-y4 loc-x4-y3
0
2
0 0 98 97
0 97 -1 0
1
end_operator
begin_operator
move loc-x4-y4 loc-x4-y5
0
2
0 0 98 99
0 99 -1 0
1
end_operator
begin_operator
move loc-x4-y4 loc-x5-y4
0
2
0 0 98 111
0 111 -1 0
1
end_operator
begin_operator
move loc-x4-y5 loc-x3-y5
0
2
0 0 99 86
0 86 -1 0
1
end_operator
begin_operator
move loc-x4-y5 loc-x4-y4
0
2
0 0 99 98
0 98 -1 0
1
end_operator
begin_operator
move loc-x4-y5 loc-x4-y6
0
2
0 0 99 100
0 100 -1 0
1
end_operator
begin_operator
move loc-x4-y5 loc-x5-y5
0
2
0 0 99 112
0 112 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x3-y6
0
2
0 0 100 87
0 87 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x4-y5
0
2
0 0 100 99
0 99 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x4-y7
0
2
0 0 100 101
0 101 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x5-y6
0
2
0 0 100 113
0 113 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x3-y7
0
2
0 0 101 88
0 88 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x4-y6
0
2
0 0 101 100
0 100 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x4-y8
0
2
0 0 101 102
0 102 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x5-y7
0
2
0 0 101 114
0 114 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x3-y8
0
2
0 0 102 89
0 89 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x4-y7
0
2
0 0 102 101
0 101 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x4-y9
0
2
0 0 102 103
0 103 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x5-y8
0
2
0 0 102 115
0 115 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x3-y9
0
2
0 0 103 90
0 90 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x4-y10
0
2
0 0 103 93
0 93 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x4-y8
0
2
0 0 103 102
0 102 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x5-y9
0
2
0 0 103 116
0 116 -1 0
1
end_operator
begin_operator
move loc-x5-y0 loc-x4-y0
0
2
0 0 104 91
0 91 -1 0
1
end_operator
begin_operator
move loc-x5-y0 loc-x5-y1
0
2
0 0 104 105
0 105 -1 0
1
end_operator
begin_operator
move loc-x5-y0 loc-x6-y0
0
2
0 0 104 117
0 117 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x4-y1
0
2
0 0 105 92
0 92 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x5-y0
0
2
0 0 105 104
0 104 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x5-y2
0
2
0 0 105 109
0 109 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x6-y1
0
2
0 0 105 118
0 118 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x4-y10
0
2
0 0 106 93
0 93 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x5-y11
0
2
0 0 106 107
0 107 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x5-y9
0
2
0 0 106 116
0 116 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x6-y10
0
2
0 0 106 119
0 119 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x4-y11
0
2
0 0 107 94
0 94 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x5-y10
0
2
0 0 107 106
0 106 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x5-y12
0
2
0 0 107 108
0 108 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x6-y11
0
2
0 0 107 120
0 120 -1 0
1
end_operator
begin_operator
move loc-x5-y12 loc-x4-y12
0
2
0 0 108 95
0 95 -1 0
1
end_operator
begin_operator
move loc-x5-y12 loc-x5-y11
0
2
0 0 108 107
0 107 -1 0
1
end_operator
begin_operator
move loc-x5-y12 loc-x6-y12
0
2
0 0 108 121
0 121 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x4-y2
0
2
0 0 109 96
0 96 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x5-y1
0
2
0 0 109 105
0 105 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x5-y3
0
2
0 0 109 110
0 110 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x6-y2
0
2
0 0 109 122
0 122 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x4-y3
0
2
0 0 110 97
0 97 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x5-y2
0
2
0 0 110 109
0 109 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x5-y4
0
2
0 0 110 111
0 111 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x6-y3
0
2
0 0 110 123
0 123 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x4-y4
0
2
0 0 111 98
0 98 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x5-y3
0
2
0 0 111 110
0 110 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x5-y5
0
2
0 0 111 112
0 112 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x6-y4
0
2
0 0 111 124
0 124 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x4-y5
0
2
0 0 112 99
0 99 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x5-y4
0
2
0 0 112 111
0 111 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x5-y6
0
2
0 0 112 113
0 113 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x6-y5
0
2
0 0 112 125
0 125 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x4-y6
0
2
0 0 113 100
0 100 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x5-y5
0
2
0 0 113 112
0 112 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x5-y7
0
2
0 0 113 114
0 114 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x6-y6
0
2
0 0 113 126
0 126 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x4-y7
0
2
0 0 114 101
0 101 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y6
0
2
0 0 114 113
0 113 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y8
0
2
0 0 114 115
0 115 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x6-y7
0
2
0 0 114 127
0 127 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x4-y8
0
2
0 0 115 102
0 102 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y7
0
2
0 0 115 114
0 114 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y9
0
2
0 0 115 116
0 116 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x6-y8
0
2
0 0 115 128
0 128 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x4-y9
0
2
0 0 116 103
0 103 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y10
0
2
0 0 116 106
0 106 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y8
0
2
0 0 116 115
0 115 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x6-y9
0
2
0 0 116 129
0 129 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x5-y0
0
2
0 0 117 104
0 104 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x6-y1
0
2
0 0 117 118
0 118 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x7-y0
0
2
0 0 117 130
0 130 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x5-y1
0
2
0 0 118 105
0 105 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y0
0
2
0 0 118 117
0 117 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y2
0
2
0 0 118 122
0 122 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x7-y1
0
2
0 0 118 131
0 131 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x5-y10
0
2
0 0 119 106
0 106 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y11
0
2
0 0 119 120
0 120 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y9
0
2
0 0 119 129
0 129 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x7-y10
0
2
0 0 119 132
0 132 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x5-y11
0
2
0 0 120 107
0 107 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y10
0
2
0 0 120 119
0 119 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y12
0
2
0 0 120 121
0 121 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x7-y11
0
2
0 0 120 133
0 133 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x5-y12
0
2
0 0 121 108
0 108 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y11
0
2
0 0 121 120
0 120 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x7-y12
0
2
0 0 121 134
0 134 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x5-y2
0
2
0 0 122 109
0 109 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y1
0
2
0 0 122 118
0 118 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y3
0
2
0 0 122 123
0 123 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x7-y2
0
2
0 0 122 135
0 135 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x5-y3
0
2
0 0 123 110
0 110 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y2
0
2
0 0 123 122
0 122 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y4
0
2
0 0 123 124
0 124 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x7-y3
0
2
0 0 123 136
0 136 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x5-y4
0
2
0 0 124 111
0 111 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y3
0
2
0 0 124 123
0 123 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y5
0
2
0 0 124 125
0 125 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x7-y4
0
2
0 0 124 137
0 137 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x5-y5
0
2
0 0 125 112
0 112 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y4
0
2
0 0 125 124
0 124 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y6
0
2
0 0 125 126
0 126 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x7-y5
0
2
0 0 125 138
0 138 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x5-y6
0
2
0 0 126 113
0 113 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y5
0
2
0 0 126 125
0 125 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y7
0
2
0 0 126 127
0 127 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x7-y6
0
2
0 0 126 139
0 139 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x5-y7
0
2
0 0 127 114
0 114 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y6
0
2
0 0 127 126
0 126 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y8
0
2
0 0 127 128
0 128 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x7-y7
0
2
0 0 127 140
0 140 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x5-y8
0
2
0 0 128 115
0 115 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y7
0
2
0 0 128 127
0 127 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y9
0
2
0 0 128 129
0 129 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x7-y8
0
2
0 0 128 141
0 141 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x5-y9
0
2
0 0 129 116
0 116 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y10
0
2
0 0 129 119
0 119 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y8
0
2
0 0 129 128
0 128 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x7-y9
0
2
0 0 129 142
0 142 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x6-y0
0
2
0 0 130 117
0 117 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x7-y1
0
2
0 0 130 131
0 131 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x8-y0
0
2
0 0 130 143
0 143 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x6-y1
0
2
0 0 131 118
0 118 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y0
0
2
0 0 131 130
0 130 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y2
0
2
0 0 131 135
0 135 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x8-y1
0
2
0 0 131 144
0 144 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x6-y10
0
2
0 0 132 119
0 119 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y11
0
2
0 0 132 133
0 133 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y9
0
2
0 0 132 142
0 142 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x8-y10
0
2
0 0 132 145
0 145 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 133 120
0 120 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 133 132
0 132 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 133 134
0 134 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 133 146
0 146 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 134 121
0 121 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 134 133
0 133 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 134 147
0 147 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 135 122
0 122 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 135 131
0 131 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 135 136
0 136 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 135 148
0 148 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 136 123
0 123 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 136 135
0 135 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 136 137
0 137 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 136 149
0 149 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 137 124
0 124 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 137 136
0 136 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 137 138
0 138 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 137 150
0 150 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 138 125
0 125 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 138 137
0 137 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 138 139
0 139 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 138 151
0 151 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 139 126
0 126 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 139 138
0 138 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 139 140
0 140 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 139 152
0 152 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 140 127
0 127 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 140 139
0 139 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 140 141
0 141 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 140 153
0 153 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 141 128
0 128 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 141 140
0 140 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 141 142
0 142 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 141 154
0 154 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 142 129
0 129 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 142 132
0 132 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 142 141
0 141 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 142 155
0 155 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 143 130
0 130 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 143 144
0 144 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 143 156
0 156 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 144 131
0 131 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 144 143
0 143 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 144 148
0 148 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 144 157
0 157 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 145 132
0 132 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 145 146
0 146 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 145 155
0 155 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 145 158
0 158 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 146 133
0 133 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 146 145
0 145 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 146 147
0 147 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 146 159
0 159 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 147 134
0 134 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 147 146
0 146 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 147 160
0 160 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 148 135
0 135 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 148 144
0 144 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 148 149
0 149 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 148 161
0 161 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 149 136
0 136 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 149 148
0 148 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 149 150
0 150 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 149 162
0 162 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 150 137
0 137 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 150 149
0 149 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 150 151
0 151 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 150 163
0 163 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 151 138
0 138 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 151 150
0 150 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 151 152
0 152 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 151 164
0 164 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 152 139
0 139 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 152 151
0 151 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 152 153
0 153 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 152 165
0 165 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 153 140
0 140 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 153 152
0 152 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 153 154
0 154 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 153 166
0 166 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 154 141
0 141 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 154 153
0 153 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 154 155
0 155 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 154 167
0 167 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 155 142
0 142 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 155 145
0 145 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 155 154
0 154 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 155 168
0 168 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 156 26
0 26 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 156 143
0 143 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 156 157
0 157 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 157 27
0 27 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 157 144
0 144 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 157 156
0 156 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 157 161
0 161 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 158 28
0 28 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 158 145
0 145 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 158 159
0 159 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 158 168
0 168 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 159 29
0 29 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 159 146
0 146 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 159 158
0 158 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 159 160
0 160 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 160 30
0 30 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 160 147
0 147 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 160 159
0 159 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 161 31
0 31 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 161 148
0 148 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 161 157
0 157 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 161 162
0 162 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 162 32
0 32 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 162 149
0 149 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 162 161
0 161 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 162 163
0 163 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 163 33
0 33 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 163 150
0 150 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 163 162
0 162 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 163 164
0 164 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 164 34
0 34 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 164 151
0 151 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 164 163
0 163 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 164 165
0 165 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 165 35
0 35 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 165 152
0 152 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 165 164
0 164 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 165 166
0 166 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 166 36
0 36 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 166 153
0 153 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 166 165
0 165 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 166 167
0 167 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 167 37
0 37 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 167 154
0 154 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 167 166
0 166 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 167 168
0 168 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 168 38
0 38 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 168 155
0 155 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 168 158
0 158 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 168 167
0 167 -1 0
1
end_operator
0
