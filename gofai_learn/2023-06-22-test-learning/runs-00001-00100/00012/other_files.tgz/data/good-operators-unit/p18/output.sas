begin_version
3
end_version
begin_metric
0
end_metric
361
begin_variable
var0
-1
361
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y17)
Atom at-robot(loc-x0-y18)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y17)
Atom at-robot(loc-x1-y18)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y17)
Atom at-robot(loc-x10-y18)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y17)
Atom at-robot(loc-x11-y18)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y17)
Atom at-robot(loc-x12-y18)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y17)
Atom at-robot(loc-x13-y18)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y17)
Atom at-robot(loc-x14-y18)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y17)
Atom at-robot(loc-x15-y18)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y17)
Atom at-robot(loc-x16-y18)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x17-y0)
Atom at-robot(loc-x17-y1)
Atom at-robot(loc-x17-y10)
Atom at-robot(loc-x17-y11)
Atom at-robot(loc-x17-y12)
Atom at-robot(loc-x17-y13)
Atom at-robot(loc-x17-y14)
Atom at-robot(loc-x17-y15)
Atom at-robot(loc-x17-y16)
Atom at-robot(loc-x17-y17)
Atom at-robot(loc-x17-y18)
Atom at-robot(loc-x17-y2)
Atom at-robot(loc-x17-y3)
Atom at-robot(loc-x17-y4)
Atom at-robot(loc-x17-y5)
Atom at-robot(loc-x17-y6)
Atom at-robot(loc-x17-y7)
Atom at-robot(loc-x17-y8)
Atom at-robot(loc-x17-y9)
Atom at-robot(loc-x18-y0)
Atom at-robot(loc-x18-y1)
Atom at-robot(loc-x18-y10)
Atom at-robot(loc-x18-y11)
Atom at-robot(loc-x18-y12)
Atom at-robot(loc-x18-y13)
Atom at-robot(loc-x18-y14)
Atom at-robot(loc-x18-y15)
Atom at-robot(loc-x18-y16)
Atom at-robot(loc-x18-y17)
Atom at-robot(loc-x18-y18)
Atom at-robot(loc-x18-y2)
Atom at-robot(loc-x18-y3)
Atom at-robot(loc-x18-y4)
Atom at-robot(loc-x18-y5)
Atom at-robot(loc-x18-y6)
Atom at-robot(loc-x18-y7)
Atom at-robot(loc-x18-y8)
Atom at-robot(loc-x18-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y17)
Atom at-robot(loc-x2-y18)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y17)
Atom at-robot(loc-x3-y18)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y17)
Atom at-robot(loc-x4-y18)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y17)
Atom at-robot(loc-x5-y18)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y17)
Atom at-robot(loc-x6-y18)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y17)
Atom at-robot(loc-x7-y18)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y17)
Atom at-robot(loc-x8-y18)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y17)
Atom at-robot(loc-x9-y18)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var3
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var4
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var5
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var6
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var7
-1
2
Atom visited(loc-x0-y14)
NegatedAtom visited(loc-x0-y14)
end_variable
begin_variable
var8
-1
2
Atom visited(loc-x0-y15)
NegatedAtom visited(loc-x0-y15)
end_variable
begin_variable
var9
-1
2
Atom visited(loc-x0-y16)
NegatedAtom visited(loc-x0-y16)
end_variable
begin_variable
var10
-1
2
Atom visited(loc-x0-y17)
NegatedAtom visited(loc-x0-y17)
end_variable
begin_variable
var11
-1
2
Atom visited(loc-x0-y18)
NegatedAtom visited(loc-x0-y18)
end_variable
begin_variable
var12
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var13
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var14
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var15
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var16
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var17
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var18
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var19
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var20
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var21
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var22
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var23
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var24
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var25
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var26
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var27
-1
2
Atom visited(loc-x1-y15)
NegatedAtom visited(loc-x1-y15)
end_variable
begin_variable
var28
-1
2
Atom visited(loc-x1-y16)
NegatedAtom visited(loc-x1-y16)
end_variable
begin_variable
var29
-1
2
Atom visited(loc-x1-y17)
NegatedAtom visited(loc-x1-y17)
end_variable
begin_variable
var30
-1
2
Atom visited(loc-x1-y18)
NegatedAtom visited(loc-x1-y18)
end_variable
begin_variable
var31
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var32
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var33
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var34
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var35
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var36
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var37
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var38
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var39
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var40
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var41
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var42
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var43
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var44
-1
2
Atom visited(loc-x10-y13)
NegatedAtom visited(loc-x10-y13)
end_variable
begin_variable
var45
-1
2
Atom visited(loc-x10-y14)
NegatedAtom visited(loc-x10-y14)
end_variable
begin_variable
var46
-1
2
Atom visited(loc-x10-y15)
NegatedAtom visited(loc-x10-y15)
end_variable
begin_variable
var47
-1
2
Atom visited(loc-x10-y16)
NegatedAtom visited(loc-x10-y16)
end_variable
begin_variable
var48
-1
2
Atom visited(loc-x10-y17)
NegatedAtom visited(loc-x10-y17)
end_variable
begin_variable
var49
-1
2
Atom visited(loc-x10-y18)
NegatedAtom visited(loc-x10-y18)
end_variable
begin_variable
var50
-1
2
Atom visited(loc-x10-y2)
NegatedAtom visited(loc-x10-y2)
end_variable
begin_variable
var51
-1
2
Atom visited(loc-x10-y3)
NegatedAtom visited(loc-x10-y3)
end_variable
begin_variable
var52
-1
2
Atom visited(loc-x10-y4)
NegatedAtom visited(loc-x10-y4)
end_variable
begin_variable
var53
-1
2
Atom visited(loc-x10-y5)
NegatedAtom visited(loc-x10-y5)
end_variable
begin_variable
var54
-1
2
Atom visited(loc-x10-y6)
NegatedAtom visited(loc-x10-y6)
end_variable
begin_variable
var55
-1
2
Atom visited(loc-x10-y7)
NegatedAtom visited(loc-x10-y7)
end_variable
begin_variable
var56
-1
2
Atom visited(loc-x10-y8)
NegatedAtom visited(loc-x10-y8)
end_variable
begin_variable
var57
-1
2
Atom visited(loc-x10-y9)
NegatedAtom visited(loc-x10-y9)
end_variable
begin_variable
var58
-1
2
Atom visited(loc-x11-y0)
NegatedAtom visited(loc-x11-y0)
end_variable
begin_variable
var59
-1
2
Atom visited(loc-x11-y1)
NegatedAtom visited(loc-x11-y1)
end_variable
begin_variable
var60
-1
2
Atom visited(loc-x11-y10)
NegatedAtom visited(loc-x11-y10)
end_variable
begin_variable
var61
-1
2
Atom visited(loc-x11-y11)
NegatedAtom visited(loc-x11-y11)
end_variable
begin_variable
var62
-1
2
Atom visited(loc-x11-y12)
NegatedAtom visited(loc-x11-y12)
end_variable
begin_variable
var63
-1
2
Atom visited(loc-x11-y13)
NegatedAtom visited(loc-x11-y13)
end_variable
begin_variable
var64
-1
2
Atom visited(loc-x11-y14)
NegatedAtom visited(loc-x11-y14)
end_variable
begin_variable
var65
-1
2
Atom visited(loc-x11-y15)
NegatedAtom visited(loc-x11-y15)
end_variable
begin_variable
var66
-1
2
Atom visited(loc-x11-y16)
NegatedAtom visited(loc-x11-y16)
end_variable
begin_variable
var67
-1
2
Atom visited(loc-x11-y17)
NegatedAtom visited(loc-x11-y17)
end_variable
begin_variable
var68
-1
2
Atom visited(loc-x11-y18)
NegatedAtom visited(loc-x11-y18)
end_variable
begin_variable
var69
-1
2
Atom visited(loc-x11-y2)
NegatedAtom visited(loc-x11-y2)
end_variable
begin_variable
var70
-1
2
Atom visited(loc-x11-y3)
NegatedAtom visited(loc-x11-y3)
end_variable
begin_variable
var71
-1
2
Atom visited(loc-x11-y4)
NegatedAtom visited(loc-x11-y4)
end_variable
begin_variable
var72
-1
2
Atom visited(loc-x11-y5)
NegatedAtom visited(loc-x11-y5)
end_variable
begin_variable
var73
-1
2
Atom visited(loc-x11-y6)
NegatedAtom visited(loc-x11-y6)
end_variable
begin_variable
var74
-1
2
Atom visited(loc-x11-y7)
NegatedAtom visited(loc-x11-y7)
end_variable
begin_variable
var75
-1
2
Atom visited(loc-x11-y8)
NegatedAtom visited(loc-x11-y8)
end_variable
begin_variable
var76
-1
2
Atom visited(loc-x11-y9)
NegatedAtom visited(loc-x11-y9)
end_variable
begin_variable
var77
-1
2
Atom visited(loc-x12-y0)
NegatedAtom visited(loc-x12-y0)
end_variable
begin_variable
var78
-1
2
Atom visited(loc-x12-y1)
NegatedAtom visited(loc-x12-y1)
end_variable
begin_variable
var79
-1
2
Atom visited(loc-x12-y10)
NegatedAtom visited(loc-x12-y10)
end_variable
begin_variable
var80
-1
2
Atom visited(loc-x12-y11)
NegatedAtom visited(loc-x12-y11)
end_variable
begin_variable
var81
-1
2
Atom visited(loc-x12-y12)
NegatedAtom visited(loc-x12-y12)
end_variable
begin_variable
var82
-1
2
Atom visited(loc-x12-y13)
NegatedAtom visited(loc-x12-y13)
end_variable
begin_variable
var83
-1
2
Atom visited(loc-x12-y14)
NegatedAtom visited(loc-x12-y14)
end_variable
begin_variable
var84
-1
2
Atom visited(loc-x12-y15)
NegatedAtom visited(loc-x12-y15)
end_variable
begin_variable
var85
-1
2
Atom visited(loc-x12-y16)
NegatedAtom visited(loc-x12-y16)
end_variable
begin_variable
var86
-1
2
Atom visited(loc-x12-y17)
NegatedAtom visited(loc-x12-y17)
end_variable
begin_variable
var87
-1
2
Atom visited(loc-x12-y18)
NegatedAtom visited(loc-x12-y18)
end_variable
begin_variable
var88
-1
2
Atom visited(loc-x12-y2)
NegatedAtom visited(loc-x12-y2)
end_variable
begin_variable
var89
-1
2
Atom visited(loc-x12-y3)
NegatedAtom visited(loc-x12-y3)
end_variable
begin_variable
var90
-1
2
Atom visited(loc-x12-y4)
NegatedAtom visited(loc-x12-y4)
end_variable
begin_variable
var91
-1
2
Atom visited(loc-x12-y5)
NegatedAtom visited(loc-x12-y5)
end_variable
begin_variable
var92
-1
2
Atom visited(loc-x12-y6)
NegatedAtom visited(loc-x12-y6)
end_variable
begin_variable
var93
-1
2
Atom visited(loc-x12-y7)
NegatedAtom visited(loc-x12-y7)
end_variable
begin_variable
var94
-1
2
Atom visited(loc-x12-y8)
NegatedAtom visited(loc-x12-y8)
end_variable
begin_variable
var95
-1
2
Atom visited(loc-x12-y9)
NegatedAtom visited(loc-x12-y9)
end_variable
begin_variable
var96
-1
2
Atom visited(loc-x13-y0)
NegatedAtom visited(loc-x13-y0)
end_variable
begin_variable
var97
-1
2
Atom visited(loc-x13-y1)
NegatedAtom visited(loc-x13-y1)
end_variable
begin_variable
var98
-1
2
Atom visited(loc-x13-y10)
NegatedAtom visited(loc-x13-y10)
end_variable
begin_variable
var99
-1
2
Atom visited(loc-x13-y11)
NegatedAtom visited(loc-x13-y11)
end_variable
begin_variable
var100
-1
2
Atom visited(loc-x13-y12)
NegatedAtom visited(loc-x13-y12)
end_variable
begin_variable
var101
-1
2
Atom visited(loc-x13-y13)
NegatedAtom visited(loc-x13-y13)
end_variable
begin_variable
var102
-1
2
Atom visited(loc-x13-y14)
NegatedAtom visited(loc-x13-y14)
end_variable
begin_variable
var103
-1
2
Atom visited(loc-x13-y15)
NegatedAtom visited(loc-x13-y15)
end_variable
begin_variable
var104
-1
2
Atom visited(loc-x13-y16)
NegatedAtom visited(loc-x13-y16)
end_variable
begin_variable
var105
-1
2
Atom visited(loc-x13-y17)
NegatedAtom visited(loc-x13-y17)
end_variable
begin_variable
var106
-1
2
Atom visited(loc-x13-y18)
NegatedAtom visited(loc-x13-y18)
end_variable
begin_variable
var107
-1
2
Atom visited(loc-x13-y2)
NegatedAtom visited(loc-x13-y2)
end_variable
begin_variable
var108
-1
2
Atom visited(loc-x13-y3)
NegatedAtom visited(loc-x13-y3)
end_variable
begin_variable
var109
-1
2
Atom visited(loc-x13-y4)
NegatedAtom visited(loc-x13-y4)
end_variable
begin_variable
var110
-1
2
Atom visited(loc-x13-y5)
NegatedAtom visited(loc-x13-y5)
end_variable
begin_variable
var111
-1
2
Atom visited(loc-x13-y6)
NegatedAtom visited(loc-x13-y6)
end_variable
begin_variable
var112
-1
2
Atom visited(loc-x13-y7)
NegatedAtom visited(loc-x13-y7)
end_variable
begin_variable
var113
-1
2
Atom visited(loc-x13-y8)
NegatedAtom visited(loc-x13-y8)
end_variable
begin_variable
var114
-1
2
Atom visited(loc-x13-y9)
NegatedAtom visited(loc-x13-y9)
end_variable
begin_variable
var115
-1
2
Atom visited(loc-x14-y0)
NegatedAtom visited(loc-x14-y0)
end_variable
begin_variable
var116
-1
2
Atom visited(loc-x14-y1)
NegatedAtom visited(loc-x14-y1)
end_variable
begin_variable
var117
-1
2
Atom visited(loc-x14-y10)
NegatedAtom visited(loc-x14-y10)
end_variable
begin_variable
var118
-1
2
Atom visited(loc-x14-y11)
NegatedAtom visited(loc-x14-y11)
end_variable
begin_variable
var119
-1
2
Atom visited(loc-x14-y12)
NegatedAtom visited(loc-x14-y12)
end_variable
begin_variable
var120
-1
2
Atom visited(loc-x14-y13)
NegatedAtom visited(loc-x14-y13)
end_variable
begin_variable
var121
-1
2
Atom visited(loc-x14-y14)
NegatedAtom visited(loc-x14-y14)
end_variable
begin_variable
var122
-1
2
Atom visited(loc-x14-y16)
NegatedAtom visited(loc-x14-y16)
end_variable
begin_variable
var123
-1
2
Atom visited(loc-x14-y17)
NegatedAtom visited(loc-x14-y17)
end_variable
begin_variable
var124
-1
2
Atom visited(loc-x14-y18)
NegatedAtom visited(loc-x14-y18)
end_variable
begin_variable
var125
-1
2
Atom visited(loc-x14-y2)
NegatedAtom visited(loc-x14-y2)
end_variable
begin_variable
var126
-1
2
Atom visited(loc-x14-y3)
NegatedAtom visited(loc-x14-y3)
end_variable
begin_variable
var127
-1
2
Atom visited(loc-x14-y4)
NegatedAtom visited(loc-x14-y4)
end_variable
begin_variable
var128
-1
2
Atom visited(loc-x14-y5)
NegatedAtom visited(loc-x14-y5)
end_variable
begin_variable
var129
-1
2
Atom visited(loc-x14-y6)
NegatedAtom visited(loc-x14-y6)
end_variable
begin_variable
var130
-1
2
Atom visited(loc-x14-y7)
NegatedAtom visited(loc-x14-y7)
end_variable
begin_variable
var131
-1
2
Atom visited(loc-x14-y8)
NegatedAtom visited(loc-x14-y8)
end_variable
begin_variable
var132
-1
2
Atom visited(loc-x14-y9)
NegatedAtom visited(loc-x14-y9)
end_variable
begin_variable
var133
-1
2
Atom visited(loc-x15-y0)
NegatedAtom visited(loc-x15-y0)
end_variable
begin_variable
var134
-1
2
Atom visited(loc-x15-y1)
NegatedAtom visited(loc-x15-y1)
end_variable
begin_variable
var135
-1
2
Atom visited(loc-x15-y10)
NegatedAtom visited(loc-x15-y10)
end_variable
begin_variable
var136
-1
2
Atom visited(loc-x15-y11)
NegatedAtom visited(loc-x15-y11)
end_variable
begin_variable
var137
-1
2
Atom visited(loc-x15-y12)
NegatedAtom visited(loc-x15-y12)
end_variable
begin_variable
var138
-1
2
Atom visited(loc-x15-y13)
NegatedAtom visited(loc-x15-y13)
end_variable
begin_variable
var139
-1
2
Atom visited(loc-x15-y14)
NegatedAtom visited(loc-x15-y14)
end_variable
begin_variable
var140
-1
2
Atom visited(loc-x15-y15)
NegatedAtom visited(loc-x15-y15)
end_variable
begin_variable
var141
-1
2
Atom visited(loc-x15-y16)
NegatedAtom visited(loc-x15-y16)
end_variable
begin_variable
var142
-1
2
Atom visited(loc-x15-y17)
NegatedAtom visited(loc-x15-y17)
end_variable
begin_variable
var143
-1
2
Atom visited(loc-x15-y18)
NegatedAtom visited(loc-x15-y18)
end_variable
begin_variable
var144
-1
2
Atom visited(loc-x15-y2)
NegatedAtom visited(loc-x15-y2)
end_variable
begin_variable
var145
-1
2
Atom visited(loc-x15-y3)
NegatedAtom visited(loc-x15-y3)
end_variable
begin_variable
var146
-1
2
Atom visited(loc-x15-y4)
NegatedAtom visited(loc-x15-y4)
end_variable
begin_variable
var147
-1
2
Atom visited(loc-x15-y5)
NegatedAtom visited(loc-x15-y5)
end_variable
begin_variable
var148
-1
2
Atom visited(loc-x15-y6)
NegatedAtom visited(loc-x15-y6)
end_variable
begin_variable
var149
-1
2
Atom visited(loc-x15-y7)
NegatedAtom visited(loc-x15-y7)
end_variable
begin_variable
var150
-1
2
Atom visited(loc-x15-y8)
NegatedAtom visited(loc-x15-y8)
end_variable
begin_variable
var151
-1
2
Atom visited(loc-x15-y9)
NegatedAtom visited(loc-x15-y9)
end_variable
begin_variable
var152
-1
2
Atom visited(loc-x16-y0)
NegatedAtom visited(loc-x16-y0)
end_variable
begin_variable
var153
-1
2
Atom visited(loc-x16-y1)
NegatedAtom visited(loc-x16-y1)
end_variable
begin_variable
var154
-1
2
Atom visited(loc-x16-y10)
NegatedAtom visited(loc-x16-y10)
end_variable
begin_variable
var155
-1
2
Atom visited(loc-x16-y11)
NegatedAtom visited(loc-x16-y11)
end_variable
begin_variable
var156
-1
2
Atom visited(loc-x16-y12)
NegatedAtom visited(loc-x16-y12)
end_variable
begin_variable
var157
-1
2
Atom visited(loc-x16-y13)
NegatedAtom visited(loc-x16-y13)
end_variable
begin_variable
var158
-1
2
Atom visited(loc-x16-y14)
NegatedAtom visited(loc-x16-y14)
end_variable
begin_variable
var159
-1
2
Atom visited(loc-x16-y15)
NegatedAtom visited(loc-x16-y15)
end_variable
begin_variable
var160
-1
2
Atom visited(loc-x16-y16)
NegatedAtom visited(loc-x16-y16)
end_variable
begin_variable
var161
-1
2
Atom visited(loc-x16-y17)
NegatedAtom visited(loc-x16-y17)
end_variable
begin_variable
var162
-1
2
Atom visited(loc-x16-y18)
NegatedAtom visited(loc-x16-y18)
end_variable
begin_variable
var163
-1
2
Atom visited(loc-x16-y2)
NegatedAtom visited(loc-x16-y2)
end_variable
begin_variable
var164
-1
2
Atom visited(loc-x16-y3)
NegatedAtom visited(loc-x16-y3)
end_variable
begin_variable
var165
-1
2
Atom visited(loc-x16-y4)
NegatedAtom visited(loc-x16-y4)
end_variable
begin_variable
var166
-1
2
Atom visited(loc-x16-y5)
NegatedAtom visited(loc-x16-y5)
end_variable
begin_variable
var167
-1
2
Atom visited(loc-x16-y6)
Negat




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




gin_operator
move loc-x5-y6 loc-x6-y6
0
2
0 0 281 300
0 300 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x4-y7
0
2
0 0 282 263
0 263 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y6
0
2
0 0 282 281
0 281 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y8
0
2
0 0 282 283
0 283 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x6-y7
0
2
0 0 282 301
0 301 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x4-y8
0
2
0 0 283 264
0 264 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y7
0
2
0 0 283 282
0 282 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y9
0
2
0 0 283 284
0 284 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x6-y8
0
2
0 0 283 302
0 302 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x4-y9
0
2
0 0 284 265
0 265 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y10
0
2
0 0 284 268
0 268 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y8
0
2
0 0 284 283
0 283 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x6-y9
0
2
0 0 284 303
0 303 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x5-y0
0
2
0 0 285 266
0 266 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x6-y1
0
2
0 0 285 286
0 286 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x7-y0
0
2
0 0 285 304
0 304 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x5-y1
0
2
0 0 286 267
0 267 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y0
0
2
0 0 286 285
0 285 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y2
0
2
0 0 286 296
0 296 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x7-y1
0
2
0 0 286 305
0 305 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x5-y10
0
2
0 0 287 268
0 268 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y11
0
2
0 0 287 288
0 288 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y9
0
2
0 0 287 303
0 303 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x7-y10
0
2
0 0 287 306
0 306 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x5-y11
0
2
0 0 288 269
0 269 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y10
0
2
0 0 288 287
0 287 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y12
0
2
0 0 288 289
0 289 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x7-y11
0
2
0 0 288 307
0 307 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x5-y12
0
2
0 0 289 270
0 270 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y11
0
2
0 0 289 288
0 288 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y13
0
2
0 0 289 290
0 290 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x7-y12
0
2
0 0 289 308
0 308 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x5-y13
0
2
0 0 290 271
0 271 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y12
0
2
0 0 290 289
0 289 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y14
0
2
0 0 290 291
0 291 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x7-y13
0
2
0 0 290 309
0 309 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x5-y14
0
2
0 0 291 272
0 272 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y13
0
2
0 0 291 290
0 290 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y15
0
2
0 0 291 292
0 292 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x7-y14
0
2
0 0 291 310
0 310 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x5-y15
0
2
0 0 292 273
0 273 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y14
0
2
0 0 292 291
0 291 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y16
0
2
0 0 292 293
0 293 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x7-y15
0
2
0 0 292 311
0 311 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x5-y16
0
2
0 0 293 274
0 274 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x6-y15
0
2
0 0 293 292
0 292 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x6-y17
0
2
0 0 293 294
0 294 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x7-y16
0
2
0 0 293 312
0 312 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x5-y17
0
2
0 0 294 275
0 275 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x6-y16
0
2
0 0 294 293
0 293 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x6-y18
0
2
0 0 294 295
0 295 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x7-y17
0
2
0 0 294 313
0 313 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x5-y18
0
2
0 0 295 276
0 276 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x6-y17
0
2
0 0 295 294
0 294 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x7-y18
0
2
0 0 295 314
0 314 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x5-y2
0
2
0 0 296 277
0 277 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y1
0
2
0 0 296 286
0 286 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y3
0
2
0 0 296 297
0 297 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x7-y2
0
2
0 0 296 315
0 315 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x5-y3
0
2
0 0 297 278
0 278 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y2
0
2
0 0 297 296
0 296 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y4
0
2
0 0 297 298
0 298 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x7-y3
0
2
0 0 297 316
0 316 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x5-y4
0
2
0 0 298 279
0 279 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y3
0
2
0 0 298 297
0 297 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y5
0
2
0 0 298 299
0 299 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x7-y4
0
2
0 0 298 317
0 317 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x5-y5
0
2
0 0 299 280
0 280 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y4
0
2
0 0 299 298
0 298 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y6
0
2
0 0 299 300
0 300 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x7-y5
0
2
0 0 299 318
0 318 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x5-y6
0
2
0 0 300 281
0 281 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y5
0
2
0 0 300 299
0 299 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y7
0
2
0 0 300 301
0 301 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x7-y6
0
2
0 0 300 319
0 319 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x5-y7
0
2
0 0 301 282
0 282 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y6
0
2
0 0 301 300
0 300 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y8
0
2
0 0 301 302
0 302 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x7-y7
0
2
0 0 301 320
0 320 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x5-y8
0
2
0 0 302 283
0 283 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y7
0
2
0 0 302 301
0 301 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y9
0
2
0 0 302 303
0 303 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x7-y8
0
2
0 0 302 321
0 321 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x5-y9
0
2
0 0 303 284
0 284 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y10
0
2
0 0 303 287
0 287 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y8
0
2
0 0 303 302
0 302 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x7-y9
0
2
0 0 303 322
0 322 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x6-y0
0
2
0 0 304 285
0 285 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x7-y1
0
2
0 0 304 305
0 305 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x8-y0
0
2
0 0 304 323
0 323 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x6-y1
0
2
0 0 305 286
0 286 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y0
0
2
0 0 305 304
0 304 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y2
0
2
0 0 305 315
0 315 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x8-y1
0
2
0 0 305 324
0 324 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x6-y10
0
2
0 0 306 287
0 287 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y11
0
2
0 0 306 307
0 307 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y9
0
2
0 0 306 322
0 322 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x8-y10
0
2
0 0 306 325
0 325 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 307 288
0 288 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 307 306
0 306 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 307 308
0 308 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 307 326
0 326 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 308 289
0 289 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 308 307
0 307 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y13
0
2
0 0 308 309
0 309 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 308 327
0 327 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x6-y13
0
2
0 0 309 290
0 290 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y12
0
2
0 0 309 308
0 308 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y14
0
2
0 0 309 310
0 310 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x8-y13
0
2
0 0 309 328
0 328 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 310 291
0 291 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 310 309
0 309 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y15
0
2
0 0 310 311
0 311 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 310 329
0 329 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x6-y15
0
2
0 0 311 292
0 292 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y14
0
2
0 0 311 310
0 310 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y16
0
2
0 0 311 312
0 312 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x8-y15
0
2
0 0 311 330
0 330 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x6-y16
0
2
0 0 312 293
0 293 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y15
0
2
0 0 312 311
0 311 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y17
0
2
0 0 312 313
0 313 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x8-y16
0
2
0 0 312 331
0 331 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x6-y17
0
2
0 0 313 294
0 294 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y16
0
2
0 0 313 312
0 312 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y18
0
2
0 0 313 314
0 314 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x8-y17
0
2
0 0 313 332
0 332 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x6-y18
0
2
0 0 314 295
0 295 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y17
0
2
0 0 314 313
0 313 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x8-y18
0
2
0 0 314 333
0 333 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 315 296
0 296 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 315 305
0 305 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 315 316
0 316 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 315 334
0 334 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 316 297
0 297 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 316 315
0 315 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 316 317
0 317 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 316 335
0 335 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 317 298
0 298 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 317 316
0 316 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 317 318
0 318 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 317 336
0 336 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 318 299
0 299 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 318 317
0 317 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 318 319
0 319 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 318 337
0 337 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 319 300
0 300 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 319 318
0 318 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 319 320
0 320 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 319 338
0 338 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 320 301
0 301 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 320 319
0 319 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 320 321
0 321 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 320 339
0 339 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 321 302
0 302 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 321 320
0 320 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 321 322
0 322 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 321 340
0 340 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 322 303
0 303 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 322 306
0 306 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 322 321
0 321 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 322 341
0 341 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 323 304
0 304 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 323 324
0 324 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 323 342
0 342 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 324 305
0 305 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 324 323
0 323 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 324 334
0 334 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 324 343
0 343 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 325 306
0 306 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 325 326
0 326 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 325 341
0 341 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 325 344
0 344 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 326 307
0 307 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 326 325
0 325 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 326 327
0 327 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 326 345
0 345 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 327 308
0 308 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 327 326
0 326 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 327 328
0 328 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 327 346
0 346 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 328 309
0 309 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 328 327
0 327 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 328 329
0 329 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 328 347
0 347 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 329 310
0 310 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 329 328
0 328 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 329 330
0 330 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 329 348
0 348 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 330 311
0 311 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y14
0
2
0 0 330 329
0 329 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y16
0
2
0 0 330 331
0 331 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 330 349
0 349 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 331 312
0 312 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y15
0
2
0 0 331 330
0 330 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y17
0
2
0 0 331 332
0 332 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 331 350
0 350 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x7-y17
0
2
0 0 332 313
0 313 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y16
0
2
0 0 332 331
0 331 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y18
0
2
0 0 332 333
0 333 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x9-y17
0
2
0 0 332 351
0 351 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x7-y18
0
2
0 0 333 314
0 314 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y17
0
2
0 0 333 332
0 332 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x9-y18
0
2
0 0 333 352
0 352 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 334 315
0 315 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 334 324
0 324 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 334 335
0 335 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 334 353
0 353 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 335 316
0 316 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 335 334
0 334 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 335 336
0 336 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 335 354
0 354 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 336 317
0 317 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 336 335
0 335 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 336 337
0 337 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 336 355
0 355 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 337 318
0 318 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 337 336
0 336 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 337 338
0 338 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 337 356
0 356 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 338 319
0 319 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 338 337
0 337 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 338 339
0 339 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 338 357
0 357 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 339 320
0 320 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 339 338
0 338 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 339 340
0 340 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 339 358
0 358 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 340 321
0 321 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 340 339
0 339 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 340 341
0 341 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 340 359
0 359 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 341 322
0 322 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 341 325
0 325 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 341 340
0 340 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 341 360
0 360 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 342 38
0 39 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 342 323
0 323 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 342 343
0 343 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 343 39
0 40 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 343 324
0 324 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 343 342
0 342 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 343 353
0 353 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 344 40
0 41 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 344 325
0 325 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 344 345
0 345 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 344 360
0 360 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 345 41
0 42 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 345 326
0 326 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 345 344
0 344 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 345 346
0 346 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 346 42
0 43 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 346 327
0 327 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 346 345
0 345 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 346 347
0 347 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 347 43
0 44 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 347 328
0 328 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 347 346
0 346 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 347 348
0 348 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 348 44
0 45 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 348 329
0 329 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 348 347
0 347 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y15
0
2
0 0 348 349
0 349 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 349 45
0 46 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x8-y15
0
2
0 0 349 330
0 330 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y14
0
2
0 0 349 348
0 348 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y16
0
2
0 0 349 350
0 350 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 350 46
0 47 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x8-y16
0
2
0 0 350 331
0 331 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y15
0
2
0 0 350 349
0 349 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y17
0
2
0 0 350 351
0 351 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x10-y17
0
2
0 0 351 47
0 48 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x8-y17
0
2
0 0 351 332
0 332 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y16
0
2
0 0 351 350
0 350 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y18
0
2
0 0 351 352
0 352 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x10-y18
0
2
0 0 352 48
0 49 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x8-y18
0
2
0 0 352 333
0 333 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y17
0
2
0 0 352 351
0 351 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 353 49
0 50 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 353 334
0 334 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 353 343
0 343 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 353 354
0 354 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 354 50
0 51 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 354 335
0 335 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 354 353
0 353 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 354 355
0 355 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 355 51
0 52 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 355 336
0 336 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 355 354
0 354 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 355 356
0 356 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 356 52
0 53 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 356 337
0 337 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 356 355
0 355 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 356 357
0 357 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 357 53
0 54 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 357 338
0 338 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 357 356
0 356 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 357 358
0 358 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 358 54
0 55 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 358 339
0 339 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 358 357
0 357 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 358 359
0 359 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 359 55
0 56 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 359 340
0 340 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 359 358
0 358 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 359 360
0 360 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 360 56
0 57 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 360 341
0 341 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 360 344
0 344 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 360 359
0 359 -1 0
1
end_operator
0
