begin_version
3
end_version
begin_metric
0
end_metric
441
begin_variable
var0
-1
441
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y17)
Atom at-robot(loc-x0-y18)
Atom at-robot(loc-x0-y19)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y20)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y17)
Atom at-robot(loc-x1-y18)
Atom at-robot(loc-x1-y19)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y20)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y17)
Atom at-robot(loc-x10-y18)
Atom at-robot(loc-x10-y19)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y20)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y17)
Atom at-robot(loc-x11-y18)
Atom at-robot(loc-x11-y19)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y20)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y17)
Atom at-robot(loc-x12-y18)
Atom at-robot(loc-x12-y19)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y20)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y17)
Atom at-robot(loc-x13-y18)
Atom at-robot(loc-x13-y19)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y20)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y17)
Atom at-robot(loc-x14-y18)
Atom at-robot(loc-x14-y19)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y20)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y17)
Atom at-robot(loc-x15-y18)
Atom at-robot(loc-x15-y19)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y20)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y17)
Atom at-robot(loc-x16-y18)
Atom at-robot(loc-x16-y19)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y20)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x17-y0)
Atom at-robot(loc-x17-y1)
Atom at-robot(loc-x17-y10)
Atom at-robot(loc-x17-y11)
Atom at-robot(loc-x17-y12)
Atom at-robot(loc-x17-y13)
Atom at-robot(loc-x17-y14)
Atom at-robot(loc-x17-y15)
Atom at-robot(loc-x17-y16)
Atom at-robot(loc-x17-y17)
Atom at-robot(loc-x17-y18)
Atom at-robot(loc-x17-y19)
Atom at-robot(loc-x17-y2)
Atom at-robot(loc-x17-y20)
Atom at-robot(loc-x17-y3)
Atom at-robot(loc-x17-y4)
Atom at-robot(loc-x17-y5)
Atom at-robot(loc-x17-y6)
Atom at-robot(loc-x17-y7)
Atom at-robot(loc-x17-y8)
Atom at-robot(loc-x17-y9)
Atom at-robot(loc-x18-y0)
Atom at-robot(loc-x18-y1)
Atom at-robot(loc-x18-y10)
Atom at-robot(loc-x18-y11)
Atom at-robot(loc-x18-y12)
Atom at-robot(loc-x18-y13)
Atom at-robot(loc-x18-y14)
Atom at-robot(loc-x18-y15)
Atom at-robot(loc-x18-y16)
Atom at-robot(loc-x18-y17)
Atom at-robot(loc-x18-y18)
Atom at-robot(loc-x18-y19)
Atom at-robot(loc-x18-y2)
Atom at-robot(loc-x18-y20)
Atom at-robot(loc-x18-y3)
Atom at-robot(loc-x18-y4)
Atom at-robot(loc-x18-y5)
Atom at-robot(loc-x18-y6)
Atom at-robot(loc-x18-y7)
Atom at-robot(loc-x18-y8)
Atom at-robot(loc-x18-y9)
Atom at-robot(loc-x19-y0)
Atom at-robot(loc-x19-y1)
Atom at-robot(loc-x19-y10)
Atom at-robot(loc-x19-y11)
Atom at-robot(loc-x19-y12)
Atom at-robot(loc-x19-y13)
Atom at-robot(loc-x19-y14)
Atom at-robot(loc-x19-y15)
Atom at-robot(loc-x19-y16)
Atom at-robot(loc-x19-y17)
Atom at-robot(loc-x19-y18)
Atom at-robot(loc-x19-y19)
Atom at-robot(loc-x19-y2)
Atom at-robot(loc-x19-y20)
Atom at-robot(loc-x19-y3)
Atom at-robot(loc-x19-y4)
Atom at-robot(loc-x19-y5)
Atom at-robot(loc-x19-y6)
Atom at-robot(loc-x19-y7)
Atom at-robot(loc-x19-y8)
Atom at-robot(loc-x19-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y17)
Atom at-robot(loc-x2-y18)
Atom at-robot(loc-x2-y19)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y20)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x20-y0)
Atom at-robot(loc-x20-y1)
Atom at-robot(loc-x20-y10)
Atom at-robot(loc-x20-y11)
Atom at-robot(loc-x20-y12)
Atom at-robot(loc-x20-y13)
Atom at-robot(loc-x20-y14)
Atom at-robot(loc-x20-y15)
Atom at-robot(loc-x20-y16)
Atom at-robot(loc-x20-y17)
Atom at-robot(loc-x20-y18)
Atom at-robot(loc-x20-y19)
Atom at-robot(loc-x20-y2)
Atom at-robot(loc-x20-y20)
Atom at-robot(loc-x20-y3)
Atom at-robot(loc-x20-y4)
Atom at-robot(loc-x20-y5)
Atom at-robot(loc-x20-y6)
Atom at-robot(loc-x20-y7)
Atom at-robot(loc-x20-y8)
Atom at-robot(loc-x20-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y17)
Atom at-robot(loc-x3-y18)
Atom at-robot(loc-x3-y19)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y20)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y17)
Atom at-robot(loc-x4-y18)
Atom at-robot(loc-x4-y19)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y20)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y17)
Atom at-robot(loc-x5-y18)
Atom at-robot(loc-x5-y19)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y20)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y17)
Atom at-robot(loc-x6-y18)
Atom at-robot(loc-x6-y19)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y20)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y17)
Atom at-robot(loc-x7-y18)
Atom at-robot(loc-x7-y19)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y20)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y17)
Atom at-robot(loc-x8-y18)
Atom at-robot(loc-x8-y19)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y20)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y17)
Atom at-robot(loc-x9-y18)
Atom at-robot(loc-x9-y19)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y20)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var3
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var4
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var5
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var6
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var7
-1
2
Atom visited(loc-x0-y14)
NegatedAtom visited(loc-x0-y14)
end_variable
begin_variable
var8
-1
2
Atom visited(loc-x0-y15)
NegatedAtom visited(loc-x0-y15)
end_variable
begin_variable
var9
-1
2
Atom visited(loc-x0-y16)
NegatedAtom visited(loc-x0-y16)
end_variable
begin_variable
var10
-1
2
Atom visited(loc-x0-y17)
NegatedAtom visited(loc-x0-y17)
end_variable
begin_variable
var11
-1
2
Atom visited(loc-x0-y18)
NegatedAtom visited(loc-x0-y18)
end_variable
begin_variable
var12
-1
2
Atom visited(loc-x0-y19)
NegatedAtom visited(loc-x0-y19)
end_variable
begin_variable
var13
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var14
-1
2
Atom visited(loc-x0-y20)
NegatedAtom visited(loc-x0-y20)
end_variable
begin_variable
var15
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var16
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var17
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var18
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var19
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var20
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var21
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var22
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var23
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var24
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var25
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var26
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var27
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var28
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var29
-1
2
Atom visited(loc-x1-y15)
NegatedAtom visited(loc-x1-y15)
end_variable
begin_variable
var30
-1
2
Atom visited(loc-x1-y16)
NegatedAtom visited(loc-x1-y16)
end_variable
begin_variable
var31
-1
2
Atom visited(loc-x1-y17)
NegatedAtom visited(loc-x1-y17)
end_variable
begin_variable
var32
-1
2
Atom visited(loc-x1-y18)
NegatedAtom visited(loc-x1-y18)
end_variable
begin_variable
var33
-1
2
Atom visited(loc-x1-y19)
NegatedAtom visited(loc-x1-y19)
end_variable
begin_variable
var34
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var35
-1
2
Atom visited(loc-x1-y20)
NegatedAtom visited(loc-x1-y20)
end_variable
begin_variable
var36
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var37
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var38
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var39
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var40
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var41
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var42
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var43
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var44
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var45
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var46
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var47
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var48
-1
2
Atom visited(loc-x10-y13)
NegatedAtom visited(loc-x10-y13)
end_variable
begin_variable
var49
-1
2
Atom visited(loc-x10-y14)
NegatedAtom visited(loc-x10-y14)
end_variable
begin_variable
var50
-1
2
Atom visited(loc-x10-y15)
NegatedAtom visited(loc-x10-y15)
end_variable
begin_variable
var51
-1
2
Atom visited(loc-x10-y16)
NegatedAtom visited(loc-x10-y16)
end_variable
begin_variable
var52
-1
2
Atom visited(loc-x10-y17)
NegatedAtom visited(loc-x10-y17)
end_variable
begin_variable
var53
-1
2
Atom visited(loc-x10-y18)
NegatedAtom visited(loc-x10-y18)
end_variable
begin_variable
var54
-1
2
Atom visited(loc-x10-y19)
NegatedAtom visited(loc-x10-y19)
end_variable
begin_variable
var55
-1
2
Atom visited(loc-x10-y2)
NegatedAtom visited(loc-x10-y2)
end_variable
begin_variable
var56
-1
2
Atom visited(loc-x10-y20)
NegatedAtom visited(loc-x10-y20)
end_variable
begin_variable
var57
-1
2
Atom visited(loc-x10-y3)
NegatedAtom visited(loc-x10-y3)
end_variable
begin_variable
var58
-1
2
Atom visited(loc-x10-y4)
NegatedAtom visited(loc-x10-y4)
end_variable
begin_variable
var59
-1
2
Atom visited(loc-x10-y5)
NegatedAtom visited(loc-x10-y5)
end_variable
begin_variable
var60
-1
2
Atom visited(loc-x10-y6)
NegatedAtom visited(loc-x10-y6)
end_variable
begin_variable
var61
-1
2
Atom visited(loc-x10-y7)
NegatedAtom visited(loc-x10-y7)
end_variable
begin_variable
var62
-1
2
Atom visited(loc-x10-y8)
NegatedAtom visited(loc-x10-y8)
end_variable
begin_variable
var63
-1
2
Atom visited(loc-x10-y9)
NegatedAtom visited(loc-x10-y9)
end_variable
begin_variable
var64
-1
2
Atom visited(loc-x11-y0)
NegatedAtom visited(loc-x11-y0)
end_variable
begin_variable
var65
-1
2
Atom visited(loc-x11-y1)
NegatedAtom visited(loc-x11-y1)
end_variable
begin_variable
var66
-1
2
Atom visited(loc-x11-y10)
NegatedAtom visited(loc-x11-y10)
end_variable
begin_variable
var67
-1
2
Atom visited(loc-x11-y11)
NegatedAtom visited(loc-x11-y11)
end_variable
begin_variable
var68
-1
2
Atom visited(loc-x11-y12)
NegatedAtom visited(loc-x11-y12)
end_variable
begin_variable
var69
-1
2
Atom visited(loc-x11-y13)
NegatedAtom visited(loc-x11-y13)
end_variable
begin_variable
var70
-1
2
Atom visited(loc-x11-y14)
NegatedAtom visited(loc-x11-y14)
end_variable
begin_variable
var71
-1
2
Atom visited(loc-x11-y15)
NegatedAtom visited(loc-x11-y15)
end_variable
begin_variable
var72
-1
2
Atom visited(loc-x11-y16)
NegatedAtom visited(loc-x11-y16)
end_variable
begin_variable
var73
-1
2
Atom visited(loc-x11-y17)
NegatedAtom visited(loc-x11-y17)
end_variable
begin_variable
var74
-1
2
Atom visited(loc-x11-y18)
NegatedAtom visited(loc-x11-y18)
end_variable
begin_variable
var75
-1
2
Atom visited(loc-x11-y19)
NegatedAtom visited(loc-x11-y19)
end_variable
begin_variable
var76
-1
2
Atom visited(loc-x11-y2)
NegatedAtom visited(loc-x11-y2)
end_variable
begin_variable
var77
-1
2
Atom visited(loc-x11-y20)
NegatedAtom visited(loc-x11-y20)
end_variable
begin_variable
var78
-1
2
Atom visited(loc-x11-y3)
NegatedAtom visited(loc-x11-y3)
end_variable
begin_variable
var79
-1
2
Atom visited(loc-x11-y4)
NegatedAtom visited(loc-x11-y4)
end_variable
begin_variable
var80
-1
2
Atom visited(loc-x11-y5)
NegatedAtom visited(loc-x11-y5)
end_variable
begin_variable
var81
-1
2
Atom visited(loc-x11-y6)
NegatedAtom visited(loc-x11-y6)
end_variable
begin_variable
var82
-1
2
Atom visited(loc-x11-y8)
NegatedAtom visited(loc-x11-y8)
end_variable
begin_variable
var83
-1
2
Atom visited(loc-x11-y9)
NegatedAtom visited(loc-x11-y9)
end_variable
begin_variable
var84
-1
2
Atom visited(loc-x12-y0)
NegatedAtom visited(loc-x12-y0)
end_variable
begin_variable
var85
-1
2
Atom visited(loc-x12-y1)
NegatedAtom visited(loc-x12-y1)
end_variable
begin_variable
var86
-1
2
Atom visited(loc-x12-y10)
NegatedAtom visited(loc-x12-y10)
end_variable
begin_variable
var87
-1
2
Atom visited(loc-x12-y11)
NegatedAtom visited(loc-x12-y11)
end_variable
begin_variable
var88
-1
2
Atom visited(loc-x12-y12)
NegatedAtom visited(loc-x12-y12)
end_variable
begin_variable
var89
-1
2
Atom visited(loc-x12-y13)
NegatedAtom visited(loc-x12-y13)
end_variable
begin_variable
var90
-1
2
Atom visited(loc-x12-y14)
NegatedAtom visited(loc-x12-y14)
end_variable
begin_variable
var91
-1
2
Atom visited(loc-x12-y15)
NegatedAtom visited(loc-x12-y15)
end_variable
begin_variable
var92
-1
2
Atom visited(loc-x12-y16)
NegatedAtom visited(loc-x12-y16)
end_variable
begin_variable
var93
-1
2
Atom visited(loc-x12-y17)
NegatedAtom visited(loc-x12-y17)
end_variable
begin_variable
var94
-1
2
Atom visited(loc-x12-y18)
NegatedAtom visited(loc-x12-y18)
end_variable
begin_variable
var95
-1
2
Atom visited(loc-x12-y19)
NegatedAtom visited(loc-x12-y19)
end_variable
begin_variable
var96
-1
2
Atom visited(loc-x12-y2)
NegatedAtom visited(loc-x12-y2)
end_variable
begin_variable
var97
-1
2
Atom visited(loc-x12-y20)
NegatedAtom visited(loc-x12-y20)
end_variable
begin_variable
var98
-1
2
Atom visited(loc-x12-y3)
NegatedAtom visited(loc-x12-y3)
end_variable
begin_variable
var99
-1
2
Atom visited(loc-x12-y4)
NegatedAtom visited(loc-x12-y4)
end_variable
begin_variable
var100
-1
2
Atom visited(loc-x12-y5)
NegatedAtom visited(loc-x12-y5)
end_variable
begin_variable
var101
-1
2
Atom visited(loc-x12-y6)
NegatedAtom visited(loc-x12-y6)
end_variable
begin_variable
var102
-1
2
Atom visited(loc-x12-y7)
NegatedAtom visited(loc-x12-y7)
end_variable
begin_variable
var103
-1
2
Atom visited(loc-x12-y8)
NegatedAtom visited(loc-x12-y8)
end_variable
begin_variable
var104
-1
2
Atom visited(loc-x12-y9)
NegatedAtom visited(loc-x12-y9)
end_variable
begin_variable
var105
-1
2
Atom visited(loc-x13-y0)
NegatedAtom visited(loc-x13-y0)
end_variable
begin_variable
var106
-1
2
Atom visited(loc-x13-y1)
NegatedAtom visited(loc-x13-y1)
end_variable
begin_variable
var107
-1
2
Atom visited(loc-x13-y10)
NegatedAtom visited(loc-x13-y10)
end_variable
begin_variable
var108
-1
2
Atom visited(loc-x13-y11)
NegatedAtom visited(loc-x13-y11)
end_variable
begin_variable
var109
-1
2
Atom visited(loc-x13-y12)
NegatedAtom visited(loc-x13-y12)
end_variable
begin_variable
var110
-1
2
Atom visited(loc-x13-y13)
NegatedAtom visited(loc-x13-y13)
end_variable
begin_variable
var111
-1
2
Atom visited(loc-x13-y14)
NegatedAtom visited(loc-x13-y14)
end_variable
begin_variable
var112
-1
2
Atom visited(loc-x13-y15)
NegatedAtom visited(loc-x13-y15)
end_variable
begin_variable
var113
-1
2
Atom visited(loc-x13-y16)
NegatedAtom visited(loc-x13-y16)
end_variable
begin_variable
var114
-1
2
Atom visited(loc-x13-y17)
NegatedAtom visited(loc-x13-y17)
end_variable
begin_variable
var115
-1
2
Atom visited(loc-x13-y18)
NegatedAtom visited(loc-x13-y18)
end_variable
begin_variable
var116
-1
2
Atom visited(loc-x13-y19)
NegatedAtom visited(loc-x13-y19)
end_variable
begin_variable
var117
-1
2
Atom visited(loc-x13-y2)
NegatedAtom visited(loc-x13-y2)
end_variable
begin_variable
var118
-1
2
Atom visited(loc-x13-y20)
NegatedAtom visited(loc-x13-y20)
end_variable
begin_variable
var119
-1
2
Atom visited(loc-x13-y3)
NegatedAtom visited(loc-x13-y3)
end_variable
begin_variable
var120
-1
2
Atom visited(loc-x13-y4)
NegatedAtom visited(loc-x13-y4)
end_variable
begin_variable
var121
-1
2
Atom visited(loc-x13-y5)
NegatedAtom visited(loc-x13-y5)
end_variable
begin_variable
var122
-1
2
Atom visited(loc-x13-y6)
NegatedAtom visited(loc-x13-y6)
end_variable
begin_variable
var123
-1
2
Atom visited(loc-x13-y7)
NegatedAtom visited(loc-x13-y7)
end_variable
begin_variable
var124
-1
2
Atom visited(loc-x13-y8)
NegatedAtom visited(loc-x13-y8)
end_variable
begin_variable
var125
-1
2
Atom visited(loc-x13-y9)
NegatedAtom visited(loc-x13-y9)
end_variable
begin_variable
var126
-1
2
Atom visited(loc-x14-y0)
NegatedAtom visited(loc-x14-y0)
end_variable
begin_variable
var127
-1
2
Atom visited(loc-x14-y1)
NegatedAtom visited(loc-x14-y1)
end_variable
begin_variable
var128
-1
2
Atom visited(loc-x14-y10)
NegatedAtom visited(loc-x14-y10)
end_variable
begin_variable
var129
-1
2
Atom visited(loc-x14-y11)
NegatedAtom visited(loc-x14-y11)
end_variable
begin_variable
var130
-1
2
Atom visited(loc-x14-y12)
NegatedAtom visited(loc-x14-y12)
end_variable
begin_variable
var131
-1
2
Atom visited(loc-x14-y13)
NegatedAtom visited(loc-x14-y13)
end_variable
begin_variable
var132
-1
2
Atom visited(loc-x14-y14)
NegatedAtom visited(loc-x14-y14)
end_variable
begin_variable
var133
-1
2
Atom visited(loc-x14-y15)
NegatedAtom visited(loc-x14-y15)
end_variable
begin_variable
var134
-1
2
Atom visited(loc-x14-y16)
NegatedAtom visited(loc-x14-y16)
end_variable
begin_variable
var135
-1
2
Atom visited(loc-x14-y17)
NegatedAtom visited(loc-x14-y17)
end_variable
begin_variable
var136
-1
2
Atom visited(loc-x14-y18)
NegatedAtom visited(loc-x14-y18)
end_variable
begin_variable
var137
-1
2
Atom visited(loc-x14-y19)
NegatedAtom visited(loc-x14-y19)
end_variable
begin_variable
var138
-1
2
Atom visited(loc-x14-y2)
NegatedAtom visited(loc-x14-y2)
end_variable
begin_variable
var139
-1
2
Atom visited(loc-x14-y20)
NegatedAtom visited(loc-x14-y20)
end_variable
begin_variable
var140
-1
2
Atom visited(loc-x14-y3)
NegatedAtom visited(loc-x14-y3)
end_variable
begin_variable
var141
-1
2
Atom visited(loc-x14-y4)
NegatedAtom visited(loc-x14-y4)
end_variable
begin_variable
var142
-1
2
Atom visited(loc-x14-y5)
NegatedAtom visited(loc-x14-y5)
end_variable
begin_variable
var143
-1
2
Atom visited(loc-x14-y6)
NegatedAtom visited(loc-x14-y6)
end_variable
begin_variable
var144
-1
2
Atom visited(loc-x14-y7)
NegatedAtom visited(loc-x14-y7)
end_variable
begin_variable
var145
-1
2
Atom visited(loc-x14-y8)
NegatedAtom visited(loc-x14-y8)
e




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




3
0
2
0 0 362 341
0 341 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y12
0
2
0 0 362 361
0 361 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y14
0
2
0 0 362 363
0 363 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x7-y13
0
2
0 0 362 383
0 383 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x5-y14
0
2
0 0 363 342
0 342 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y13
0
2
0 0 363 362
0 362 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y15
0
2
0 0 363 364
0 364 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x7-y14
0
2
0 0 363 384
0 384 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x5-y15
0
2
0 0 364 343
0 343 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y14
0
2
0 0 364 363
0 363 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y16
0
2
0 0 364 365
0 365 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x7-y15
0
2
0 0 364 385
0 385 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x5-y16
0
2
0 0 365 344
0 344 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x6-y15
0
2
0 0 365 364
0 364 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x6-y17
0
2
0 0 365 366
0 366 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x7-y16
0
2
0 0 365 386
0 386 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x5-y17
0
2
0 0 366 345
0 345 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x6-y16
0
2
0 0 366 365
0 365 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x6-y18
0
2
0 0 366 367
0 367 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x7-y17
0
2
0 0 366 387
0 387 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x5-y18
0
2
0 0 367 346
0 346 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x6-y17
0
2
0 0 367 366
0 366 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x6-y19
0
2
0 0 367 368
0 368 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x7-y18
0
2
0 0 367 388
0 388 -1 0
1
end_operator
begin_operator
move loc-x6-y19 loc-x5-y19
0
2
0 0 368 347
0 347 -1 0
1
end_operator
begin_operator
move loc-x6-y19 loc-x6-y18
0
2
0 0 368 367
0 367 -1 0
1
end_operator
begin_operator
move loc-x6-y19 loc-x6-y20
0
2
0 0 368 370
0 370 -1 0
1
end_operator
begin_operator
move loc-x6-y19 loc-x7-y19
0
2
0 0 368 389
0 389 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x5-y2
0
2
0 0 369 348
0 348 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y1
0
2
0 0 369 358
0 358 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y3
0
2
0 0 369 371
0 371 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x7-y2
0
2
0 0 369 390
0 390 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x5-y20
0
2
0 0 370 349
0 349 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x6-y19
0
2
0 0 370 368
0 368 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x7-y20
0
2
0 0 370 391
0 391 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x5-y3
0
2
0 0 371 350
0 350 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y2
0
2
0 0 371 369
0 369 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y4
0
2
0 0 371 372
0 372 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x7-y3
0
2
0 0 371 392
0 392 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x5-y4
0
2
0 0 372 351
0 351 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y3
0
2
0 0 372 371
0 371 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y5
0
2
0 0 372 373
0 373 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x7-y4
0
2
0 0 372 393
0 393 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x5-y5
0
2
0 0 373 352
0 352 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y4
0
2
0 0 373 372
0 372 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y6
0
2
0 0 373 374
0 374 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x7-y5
0
2
0 0 373 394
0 394 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x5-y6
0
2
0 0 374 353
0 353 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y5
0
2
0 0 374 373
0 373 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y7
0
2
0 0 374 375
0 375 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x7-y6
0
2
0 0 374 395
0 395 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x5-y7
0
2
0 0 375 354
0 354 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y6
0
2
0 0 375 374
0 374 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y8
0
2
0 0 375 376
0 376 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x7-y7
0
2
0 0 375 396
0 396 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x5-y8
0
2
0 0 376 355
0 355 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y7
0
2
0 0 376 375
0 375 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y9
0
2
0 0 376 377
0 377 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x7-y8
0
2
0 0 376 397
0 397 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x5-y9
0
2
0 0 377 356
0 356 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y10
0
2
0 0 377 359
0 359 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y8
0
2
0 0 377 376
0 376 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x7-y9
0
2
0 0 377 398
0 398 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x6-y0
0
2
0 0 378 357
0 357 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x7-y1
0
2
0 0 378 379
0 379 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x8-y0
0
2
0 0 378 399
0 399 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x6-y1
0
2
0 0 379 358
0 358 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y0
0
2
0 0 379 378
0 378 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y2
0
2
0 0 379 390
0 390 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x8-y1
0
2
0 0 379 400
0 400 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x6-y10
0
2
0 0 380 359
0 359 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y11
0
2
0 0 380 381
0 381 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y9
0
2
0 0 380 398
0 398 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x8-y10
0
2
0 0 380 401
0 401 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 381 360
0 360 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 381 380
0 380 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 381 382
0 382 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 381 402
0 402 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 382 361
0 361 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 382 381
0 381 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y13
0
2
0 0 382 383
0 383 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 382 403
0 403 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x6-y13
0
2
0 0 383 362
0 362 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y12
0
2
0 0 383 382
0 382 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y14
0
2
0 0 383 384
0 384 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x8-y13
0
2
0 0 383 404
0 404 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 384 363
0 363 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 384 383
0 383 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y15
0
2
0 0 384 385
0 385 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 384 405
0 405 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x6-y15
0
2
0 0 385 364
0 364 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y14
0
2
0 0 385 384
0 384 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y16
0
2
0 0 385 386
0 386 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x8-y15
0
2
0 0 385 406
0 406 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x6-y16
0
2
0 0 386 365
0 365 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y15
0
2
0 0 386 385
0 385 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y17
0
2
0 0 386 387
0 387 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x8-y16
0
2
0 0 386 407
0 407 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x6-y17
0
2
0 0 387 366
0 366 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y16
0
2
0 0 387 386
0 386 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y18
0
2
0 0 387 388
0 388 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x8-y17
0
2
0 0 387 408
0 408 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x6-y18
0
2
0 0 388 367
0 367 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y17
0
2
0 0 388 387
0 387 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y19
0
2
0 0 388 389
0 389 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x8-y18
0
2
0 0 388 409
0 409 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x6-y19
0
2
0 0 389 368
0 368 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y18
0
2
0 0 389 388
0 388 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y20
0
2
0 0 389 391
0 391 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x8-y19
0
2
0 0 389 410
0 410 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 390 369
0 369 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 390 379
0 379 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 390 392
0 392 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 390 411
0 411 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x6-y20
0
2
0 0 391 370
0 370 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x7-y19
0
2
0 0 391 389
0 389 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x8-y20
0
2
0 0 391 412
0 412 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 392 371
0 371 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 392 390
0 390 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 392 393
0 393 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 392 413
0 413 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 393 372
0 372 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 393 392
0 392 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 393 394
0 394 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 393 414
0 414 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 394 373
0 373 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 394 393
0 393 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 394 395
0 395 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 394 415
0 415 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 395 374
0 374 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 395 394
0 394 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 395 396
0 396 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 395 416
0 416 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 396 375
0 375 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 396 395
0 395 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 396 397
0 397 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 396 417
0 417 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 397 376
0 376 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 397 396
0 396 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 397 398
0 398 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 397 418
0 418 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 398 377
0 377 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 398 380
0 380 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 398 397
0 397 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 398 419
0 419 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 399 378
0 378 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 399 400
0 400 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 399 420
0 420 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 400 379
0 379 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 400 399
0 399 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 400 411
0 411 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 400 421
0 421 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 401 380
0 380 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 401 402
0 402 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 401 419
0 419 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 401 422
0 422 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 402 381
0 381 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 402 401
0 401 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 402 403
0 403 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 402 423
0 423 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 403 382
0 382 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 403 402
0 402 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 403 404
0 404 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 403 424
0 424 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 404 383
0 383 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 404 403
0 403 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 404 405
0 405 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 404 425
0 425 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 405 384
0 384 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 405 404
0 404 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 405 406
0 406 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 405 426
0 426 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 406 385
0 385 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y14
0
2
0 0 406 405
0 405 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y16
0
2
0 0 406 407
0 407 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 406 427
0 427 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 407 386
0 386 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y15
0
2
0 0 407 406
0 406 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y17
0
2
0 0 407 408
0 408 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 407 428
0 428 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x7-y17
0
2
0 0 408 387
0 387 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y16
0
2
0 0 408 407
0 407 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y18
0
2
0 0 408 409
0 409 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x9-y17
0
2
0 0 408 429
0 429 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x7-y18
0
2
0 0 409 388
0 388 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y17
0
2
0 0 409 408
0 408 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y19
0
2
0 0 409 410
0 410 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x9-y18
0
2
0 0 409 430
0 430 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x7-y19
0
2
0 0 410 389
0 389 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y18
0
2
0 0 410 409
0 409 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y20
0
2
0 0 410 412
0 412 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x9-y19
0
2
0 0 410 431
0 431 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 411 390
0 390 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 411 400
0 400 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 411 413
0 413 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 411 432
0 432 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x7-y20
0
2
0 0 412 391
0 391 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y19
0
2
0 0 412 410
0 410 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x9-y20
0
2
0 0 412 433
0 433 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 413 392
0 392 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 413 411
0 411 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 413 414
0 414 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 413 434
0 434 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 414 393
0 393 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 414 413
0 413 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 414 415
0 415 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 414 435
0 435 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 415 394
0 394 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 415 414
0 414 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 415 416
0 416 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 415 436
0 436 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 416 395
0 395 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 416 415
0 415 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 416 417
0 417 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 416 437
0 437 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 417 396
0 396 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 417 416
0 416 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 417 418
0 418 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 417 438
0 438 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 418 397
0 397 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 418 417
0 417 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 418 419
0 419 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 418 439
0 439 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 419 398
0 398 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 419 401
0 401 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 419 418
0 418 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 419 440
0 440 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 420 42
0 43 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 420 399
0 399 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 420 421
0 421 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 421 43
0 44 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 421 400
0 400 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 421 420
0 420 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 421 432
0 432 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 422 44
0 45 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 422 401
0 401 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 422 423
0 423 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 422 440
0 440 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 423 45
0 46 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 423 402
0 402 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 423 422
0 422 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 423 424
0 424 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 424 46
0 47 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 424 403
0 403 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 424 423
0 423 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 424 425
0 425 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 425 47
0 48 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 425 404
0 404 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 425 424
0 424 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 425 426
0 426 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 426 48
0 49 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 426 405
0 405 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 426 425
0 425 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y15
0
2
0 0 426 427
0 427 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 427 49
0 50 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x8-y15
0
2
0 0 427 406
0 406 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y14
0
2
0 0 427 426
0 426 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y16
0
2
0 0 427 428
0 428 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 428 50
0 51 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x8-y16
0
2
0 0 428 407
0 407 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y15
0
2
0 0 428 427
0 427 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y17
0
2
0 0 428 429
0 429 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x10-y17
0
2
0 0 429 51
0 52 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x8-y17
0
2
0 0 429 408
0 408 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y16
0
2
0 0 429 428
0 428 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y18
0
2
0 0 429 430
0 430 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x10-y18
0
2
0 0 430 52
0 53 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x8-y18
0
2
0 0 430 409
0 409 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y17
0
2
0 0 430 429
0 429 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y19
0
2
0 0 430 431
0 431 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x10-y19
0
2
0 0 431 53
0 54 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x8-y19
0
2
0 0 431 410
0 410 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y18
0
2
0 0 431 430
0 430 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y20
0
2
0 0 431 433
0 433 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 432 54
0 55 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 432 411
0 411 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 432 421
0 421 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 432 434
0 434 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x10-y20
0
2
0 0 433 55
0 56 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x8-y20
0
2
0 0 433 412
0 412 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y19
0
2
0 0 433 431
0 431 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 434 56
0 57 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 434 413
0 413 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 434 432
0 432 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 434 435
0 435 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 435 57
0 58 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 435 414
0 414 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 435 434
0 434 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 435 436
0 436 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 436 58
0 59 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 436 415
0 415 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 436 435
0 435 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 436 437
0 437 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 437 59
0 60 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 437 416
0 416 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 437 436
0 436 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 437 438
0 438 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 438 60
0 61 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 438 417
0 417 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 438 437
0 437 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 438 439
0 439 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 439 61
0 62 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 439 418
0 418 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 439 438
0 438 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 439 440
0 440 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 440 62
0 63 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 440 419
0 419 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 440 422
0 422 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 440 439
0 439 -1 0
1
end_operator
0
