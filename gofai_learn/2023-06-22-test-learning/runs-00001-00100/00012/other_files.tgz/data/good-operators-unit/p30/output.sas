begin_version
3
end_version
begin_metric
0
end_metric
961
begin_variable
var0
-1
961
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y17)
Atom at-robot(loc-x0-y18)
Atom at-robot(loc-x0-y19)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y20)
Atom at-robot(loc-x0-y21)
Atom at-robot(loc-x0-y22)
Atom at-robot(loc-x0-y23)
Atom at-robot(loc-x0-y24)
Atom at-robot(loc-x0-y25)
Atom at-robot(loc-x0-y26)
Atom at-robot(loc-x0-y27)
Atom at-robot(loc-x0-y28)
Atom at-robot(loc-x0-y29)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y30)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y17)
Atom at-robot(loc-x1-y18)
Atom at-robot(loc-x1-y19)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y20)
Atom at-robot(loc-x1-y21)
Atom at-robot(loc-x1-y22)
Atom at-robot(loc-x1-y23)
Atom at-robot(loc-x1-y24)
Atom at-robot(loc-x1-y25)
Atom at-robot(loc-x1-y26)
Atom at-robot(loc-x1-y27)
Atom at-robot(loc-x1-y28)
Atom at-robot(loc-x1-y29)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y30)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y17)
Atom at-robot(loc-x10-y18)
Atom at-robot(loc-x10-y19)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y20)
Atom at-robot(loc-x10-y21)
Atom at-robot(loc-x10-y22)
Atom at-robot(loc-x10-y23)
Atom at-robot(loc-x10-y24)
Atom at-robot(loc-x10-y25)
Atom at-robot(loc-x10-y26)
Atom at-robot(loc-x10-y27)
Atom at-robot(loc-x10-y28)
Atom at-robot(loc-x10-y29)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y30)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y17)
Atom at-robot(loc-x11-y18)
Atom at-robot(loc-x11-y19)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y20)
Atom at-robot(loc-x11-y21)
Atom at-robot(loc-x11-y22)
Atom at-robot(loc-x11-y23)
Atom at-robot(loc-x11-y24)
Atom at-robot(loc-x11-y25)
Atom at-robot(loc-x11-y26)
Atom at-robot(loc-x11-y27)
Atom at-robot(loc-x11-y28)
Atom at-robot(loc-x11-y29)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y30)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y17)
Atom at-robot(loc-x12-y18)
Atom at-robot(loc-x12-y19)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y20)
Atom at-robot(loc-x12-y21)
Atom at-robot(loc-x12-y22)
Atom at-robot(loc-x12-y23)
Atom at-robot(loc-x12-y24)
Atom at-robot(loc-x12-y25)
Atom at-robot(loc-x12-y26)
Atom at-robot(loc-x12-y27)
Atom at-robot(loc-x12-y28)
Atom at-robot(loc-x12-y29)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y30)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y17)
Atom at-robot(loc-x13-y18)
Atom at-robot(loc-x13-y19)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y20)
Atom at-robot(loc-x13-y21)
Atom at-robot(loc-x13-y22)
Atom at-robot(loc-x13-y23)
Atom at-robot(loc-x13-y24)
Atom at-robot(loc-x13-y25)
Atom at-robot(loc-x13-y26)
Atom at-robot(loc-x13-y27)
Atom at-robot(loc-x13-y28)
Atom at-robot(loc-x13-y29)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y30)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y17)
Atom at-robot(loc-x14-y18)
Atom at-robot(loc-x14-y19)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y20)
Atom at-robot(loc-x14-y21)
Atom at-robot(loc-x14-y22)
Atom at-robot(loc-x14-y23)
Atom at-robot(loc-x14-y24)
Atom at-robot(loc-x14-y25)
Atom at-robot(loc-x14-y26)
Atom at-robot(loc-x14-y27)
Atom at-robot(loc-x14-y28)
Atom at-robot(loc-x14-y29)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y30)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y17)
Atom at-robot(loc-x15-y18)
Atom at-robot(loc-x15-y19)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y20)
Atom at-robot(loc-x15-y21)
Atom at-robot(loc-x15-y22)
Atom at-robot(loc-x15-y23)
Atom at-robot(loc-x15-y24)
Atom at-robot(loc-x15-y25)
Atom at-robot(loc-x15-y26)
Atom at-robot(loc-x15-y27)
Atom at-robot(loc-x15-y28)
Atom at-robot(loc-x15-y29)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y30)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y17)
Atom at-robot(loc-x16-y18)
Atom at-robot(loc-x16-y19)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y20)
Atom at-robot(loc-x16-y21)
Atom at-robot(loc-x16-y22)
Atom at-robot(loc-x16-y23)
Atom at-robot(loc-x16-y24)
Atom at-robot(loc-x16-y25)
Atom at-robot(loc-x16-y26)
Atom at-robot(loc-x16-y27)
Atom at-robot(loc-x16-y28)
Atom at-robot(loc-x16-y29)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y30)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x17-y0)
Atom at-robot(loc-x17-y1)
Atom at-robot(loc-x17-y10)
Atom at-robot(loc-x17-y11)
Atom at-robot(loc-x17-y12)
Atom at-robot(loc-x17-y13)
Atom at-robot(loc-x17-y14)
Atom at-robot(loc-x17-y15)
Atom at-robot(loc-x17-y16)
Atom at-robot(loc-x17-y17)
Atom at-robot(loc-x17-y18)
Atom at-robot(loc-x17-y19)
Atom at-robot(loc-x17-y2)
Atom at-robot(loc-x17-y20)
Atom at-robot(loc-x17-y21)
Atom at-robot(loc-x17-y22)
Atom at-robot(loc-x17-y23)
Atom at-robot(loc-x17-y24)
Atom at-robot(loc-x17-y25)
Atom at-robot(loc-x17-y26)
Atom at-robot(loc-x17-y27)
Atom at-robot(loc-x17-y28)
Atom at-robot(loc-x17-y29)
Atom at-robot(loc-x17-y3)
Atom at-robot(loc-x17-y30)
Atom at-robot(loc-x17-y4)
Atom at-robot(loc-x17-y5)
Atom at-robot(loc-x17-y6)
Atom at-robot(loc-x17-y7)
Atom at-robot(loc-x17-y8)
Atom at-robot(loc-x17-y9)
Atom at-robot(loc-x18-y0)
Atom at-robot(loc-x18-y1)
Atom at-robot(loc-x18-y10)
Atom at-robot(loc-x18-y11)
Atom at-robot(loc-x18-y12)
Atom at-robot(loc-x18-y13)
Atom at-robot(loc-x18-y14)
Atom at-robot(loc-x18-y15)
Atom at-robot(loc-x18-y16)
Atom at-robot(loc-x18-y17)
Atom at-robot(loc-x18-y18)
Atom at-robot(loc-x18-y19)
Atom at-robot(loc-x18-y2)
Atom at-robot(loc-x18-y20)
Atom at-robot(loc-x18-y21)
Atom at-robot(loc-x18-y22)
Atom at-robot(loc-x18-y23)
Atom at-robot(loc-x18-y24)
Atom at-robot(loc-x18-y25)
Atom at-robot(loc-x18-y26)
Atom at-robot(loc-x18-y27)
Atom at-robot(loc-x18-y28)
Atom at-robot(loc-x18-y29)
Atom at-robot(loc-x18-y3)
Atom at-robot(loc-x18-y30)
Atom at-robot(loc-x18-y4)
Atom at-robot(loc-x18-y5)
Atom at-robot(loc-x18-y6)
Atom at-robot(loc-x18-y7)
Atom at-robot(loc-x18-y8)
Atom at-robot(loc-x18-y9)
Atom at-robot(loc-x19-y0)
Atom at-robot(loc-x19-y1)
Atom at-robot(loc-x19-y10)
Atom at-robot(loc-x19-y11)
Atom at-robot(loc-x19-y12)
Atom at-robot(loc-x19-y13)
Atom at-robot(loc-x19-y14)
Atom at-robot(loc-x19-y15)
Atom at-robot(loc-x19-y16)
Atom at-robot(loc-x19-y17)
Atom at-robot(loc-x19-y18)
Atom at-robot(loc-x19-y19)
Atom at-robot(loc-x19-y2)
Atom at-robot(loc-x19-y20)
Atom at-robot(loc-x19-y21)
Atom at-robot(loc-x19-y22)
Atom at-robot(loc-x19-y23)
Atom at-robot(loc-x19-y24)
Atom at-robot(loc-x19-y25)
Atom at-robot(loc-x19-y26)
Atom at-robot(loc-x19-y27)
Atom at-robot(loc-x19-y28)
Atom at-robot(loc-x19-y29)
Atom at-robot(loc-x19-y3)
Atom at-robot(loc-x19-y30)
Atom at-robot(loc-x19-y4)
Atom at-robot(loc-x19-y5)
Atom at-robot(loc-x19-y6)
Atom at-robot(loc-x19-y7)
Atom at-robot(loc-x19-y8)
Atom at-robot(loc-x19-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y17)
Atom at-robot(loc-x2-y18)
Atom at-robot(loc-x2-y19)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y20)
Atom at-robot(loc-x2-y21)
Atom at-robot(loc-x2-y22)
Atom at-robot(loc-x2-y23)
Atom at-robot(loc-x2-y24)
Atom at-robot(loc-x2-y25)
Atom at-robot(loc-x2-y26)
Atom at-robot(loc-x2-y27)
Atom at-robot(loc-x2-y28)
Atom at-robot(loc-x2-y29)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y30)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x20-y0)
Atom at-robot(loc-x20-y1)
Atom at-robot(loc-x20-y10)
Atom at-robot(loc-x20-y11)
Atom at-robot(loc-x20-y12)
Atom at-robot(loc-x20-y13)
Atom at-robot(loc-x20-y14)
Atom at-robot(loc-x20-y15)
Atom at-robot(loc-x20-y16)
Atom at-robot(loc-x20-y17)
Atom at-robot(loc-x20-y18)
Atom at-robot(loc-x20-y19)
Atom at-robot(loc-x20-y2)
Atom at-robot(loc-x20-y20)
Atom at-robot(loc-x20-y21)
Atom at-robot(loc-x20-y22)
Atom at-robot(loc-x20-y23)
Atom at-robot(loc-x20-y24)
Atom at-robot(loc-x20-y25)
Atom at-robot(loc-x20-y26)
Atom at-robot(loc-x20-y27)
Atom at-robot(loc-x20-y28)
Atom at-robot(loc-x20-y29)
Atom at-robot(loc-x20-y3)
Atom at-robot(loc-x20-y30)
Atom at-robot(loc-x20-y4)
Atom at-robot(loc-x20-y5)
Atom at-robot(loc-x20-y6)
Atom at-robot(loc-x20-y7)
Atom at-robot(loc-x20-y8)
Atom at-robot(loc-x20-y9)
Atom at-robot(loc-x21-y0)
Atom at-robot(loc-x21-y1)
Atom at-robot(loc-x21-y10)
Atom at-robot(loc-x21-y11)
Atom at-robot(loc-x21-y12)
Atom at-robot(loc-x21-y13)
Atom at-robot(loc-x21-y14)
Atom at-robot(loc-x21-y15)
Atom at-robot(loc-x21-y16)
Atom at-robot(loc-x21-y17)
Atom at-robot(loc-x21-y18)
Atom at-robot(loc-x21-y19)
Atom at-robot(loc-x21-y2)
Atom at-robot(loc-x21-y20)
Atom at-robot(loc-x21-y21)
Atom at-robot(loc-x21-y22)
Atom at-robot(loc-x21-y23)
Atom at-robot(loc-x21-y24)
Atom at-robot(loc-x21-y25)
Atom at-robot(loc-x21-y26)
Atom at-robot(loc-x21-y27)
Atom at-robot(loc-x21-y28)
Atom at-robot(loc-x21-y29)
Atom at-robot(loc-x21-y3)
Atom at-robot(loc-x21-y30)
Atom at-robot(loc-x21-y4)
Atom at-robot(loc-x21-y5)
Atom at-robot(loc-x21-y6)
Atom at-robot(loc-x21-y7)
Atom at-robot(loc-x21-y8)
Atom at-robot(loc-x21-y9)
Atom at-robot(loc-x22-y0)
Atom at-robot(loc-x22-y1)
Atom at-robot(loc-x22-y10)
Atom at-robot(loc-x22-y11)
Atom at-robot(loc-x22-y12)
Atom at-robot(loc-x22-y13)
Atom at-robot(loc-x22-y14)
Atom at-robot(loc-x22-y15)
Atom at-robot(loc-x22-y16)
Atom at-robot(loc-x22-y17)
Atom at-robot(loc-x22-y18)
Atom at-robot(loc-x22-y19)
Atom at-robot(loc-x22-y2)
Atom at-robot(loc-x22-y20)
Atom at-robot(loc-x22-y21)
Atom at-robot(loc-x22-y22)
Atom at-robot(loc-x22-y23)
Atom at-robot(loc-x22-y24)
Atom at-robot(loc-x22-y25)
Atom at-robot(loc-x22-y26)
Atom at-robot(loc-x22-y27)
Atom at-robot(loc-x22-y28)
Atom at-robot(loc-x22-y29)
Atom at-robot(loc-x22-y3)
Atom at-robot(loc-x22-y30)
Atom at-robot(loc-x22-y4)
Atom at-robot(loc-x22-y5)
Atom at-robot(loc-x22-y6)
Atom at-robot(loc-x22-y7)
Atom at-robot(loc-x22-y8)
Atom at-robot(loc-x22-y9)
Atom at-robot(loc-x23-y0)
Atom at-robot(loc-x23-y1)
Atom at-robot(loc-x23-y10)
Atom at-robot(loc-x23-y11)
Atom at-robot(loc-x23-y12)
Atom at-robot(loc-x23-y13)
Atom at-robot(loc-x23-y14)
Atom at-robot(loc-x23-y15)
Atom at-robot(loc-x23-y16)
Atom at-robot(loc-x23-y17)
Atom at-robot(loc-x23-y18)
Atom at-robot(loc-x23-y19)
Atom at-robot(loc-x23-y2)
Atom at-robot(loc-x23-y20)
Atom at-robot(loc-x23-y21)
Atom at-robot(loc-x23-y22)
Atom at-robot(loc-x23-y23)
Atom at-robot(loc-x23-y24)
Atom at-robot(loc-x23-y25)
Atom at-robot(loc-x23-y26)
Atom at-robot(loc-x23-y27)
Atom at-robot(loc-x23-y28)
Atom at-robot(loc-x23-y29)
Atom at-robot(loc-x23-y3)
Atom at-robot(loc-x23-y30)
Atom at-robot(loc-x23-y4)
Atom at-robot(loc-x23-y5)
Atom at-robot(loc-x23-y6)
Atom at-robot(loc-x23-y7)
Atom at-robot(loc-x23-y8)
Atom at-robot(loc-x23-y9)
Atom at-robot(loc-x24-y0)
Atom at-robot(loc-x24-y1)
Atom at-robot(loc-x24-y10)
Atom at-robot(loc-x24-y11)
Atom at-robot(loc-x24-y12)
Atom at-robot(loc-x24-y13)
Atom at-robot(loc-x24-y14)
Atom at-robot(loc-x24-y15)
Atom at-robot(loc-x24-y16)
Atom at-robot(loc-x24-y17)
Atom at-robot(loc-x24-y18)
Atom at-robot(loc-x24-y19)
Atom at-robot(loc-x24-y2)
Atom at-robot(loc-x24-y20)
Atom at-robot(loc-x24-y21)
Atom at-robot(loc-x24-y22)
Atom at-robot(loc-x24-y23)
Atom at-robot(loc-x24-y24)
Atom at-robot(loc-x24-y25)
Atom at-robot(loc-x24-y26)
Atom at-robot(loc-x24-y27)
Atom at-robot(loc-x24-y28)
Atom at-robot(loc-x24-y29)
Atom at-robot(loc-x24-y3)
Atom at-robot(loc-x24-y30)
Atom at-robot(loc-x24-y4)
Atom at-robot(loc-x24-y5)
Atom at-robot(loc-x24-y6)
Atom at-robot(loc-x24-y7)
Atom at-robot(loc-x24-y8)
Atom at-robot(loc-x24-y9)
Atom at-robot(loc-x25-y0)
Atom at-robot(loc-x25-y1)
Atom at-robot(loc-x25-y10)
Atom at-robot(loc-x25-y11)
Atom at-robot(loc-x25-y12)
Atom at-robot(loc-x25-y13)
Atom at-robot(loc-x25-y14)
Atom at-robot(loc-x25-y15)
Atom at-robot(loc-x25-y16)
Atom at-robot(loc-x25-y17)
Atom at-robot(loc-x25-y18)
Atom at-robot(loc-x25-y19)
Atom at-robot(loc-x25-y2)
Atom at-robot(loc-x25-y20)
Atom at-robot(loc-x25-y21)
Atom at-robot(loc-x25-y22)
Atom at-robot(loc-x25-y23)
Atom at-robot(loc-x25-y24)
Atom at-robot(loc-x25-y25)
Atom at-robot(loc-x25-y26)
Atom at-robot(loc-x25-y27)
Atom at-robot(loc-x25-y28)
Atom at-robot(loc-x25-y29)
Atom at-robot(loc-x25-y3)
Atom at-robot(loc-x25-y30)
Atom at-robot(loc-x25-y4)
Atom at-robot(loc-x25-y5)
Atom at-robot(loc-x25-y6)
Atom at-robot(loc-x25-y7)
Atom at-robot(loc-x25-y8)
Atom at-robot(loc-x25-y9)
Atom at-robot(loc-x26-y0)
Atom at-robot(loc-x26-y1)
Atom at-robot(loc-x26-y10)
Atom at-robot(loc-x26-y11)
Atom at-robot(loc-x26-y12)
Atom at-robot(loc-x26-y13)
Atom at-robot(loc-x26-y14)
Atom at-robot(loc-x26-y15)
Atom at-robot(loc-x26-y16)
Atom at-robot(loc-x26-y17)
Atom at-robot(loc-x26-y18)
Atom at-robot(loc-x26-y19)
Atom at-robot(loc-x26-y2)
Atom at-robot(loc-x26-y20)
Atom at-robot(loc-x26-y21)
Atom at-robot(loc-x26-y22)
Atom at-robot(loc-x26-y23)
Atom at-robot(loc-x26-y24)
Atom at-robot(loc-x26-y25)
Atom at-robot(loc-x26-y26)
Atom at-robot(loc-x26-y27)
Atom at-robot(loc-x26-y28)
Atom at-robot(loc-x26-y29)
Atom at-robot(loc-x26-y3)
Atom at-robot(loc-x26-y30)
Atom at-robot(loc-x26-y4)
Atom at-robot(loc-x26-y5)
Atom at-robot(loc-x26-y6)
Atom at-robot(loc-x26-y7)
Atom at-robot(loc-x26-y8)
Atom at-robot(loc-x26-y9)
Atom at-robot(loc-x27-y0)
Atom at-robot(loc-x27-y1)
Atom at-robot(loc-x27-y10)
Atom at-robot(loc-x27-y11)
Atom at-robot(loc-x27-y12)
Atom at-robot(loc-x27-y13)
Atom at-robot(loc-x27-y14)
Atom at-robot(loc-x27-y15)
Atom at-robot(loc-x27-y16)
Atom at-robot(loc-x27-y17)
Atom at-robot(loc-x27-y18)
Atom at-robot(loc-x27-y19)
Atom at-robot(loc-x27-y2)
Atom at-robot(loc-x27-y20)
Atom at-robot(loc-x27-y21)
Atom at-robot(loc-x27-y22)
Atom at-robot(loc-x27-y23)
Atom at-robot(loc-x27-y24)
Atom at-robot(loc-x27-y25)
Atom at-robot(loc-x27-y26)
Atom at-robot(loc-x27-y27)
Atom at-robot(loc-x27-y28)
Atom at-robot(loc-x27-y29)
Atom at-robot(loc-x27-y3)
Atom at-robot(loc-x27-y30)
Atom at-robot(loc-x27-y4)
Atom at-robot(loc-x27-y5)
Atom at-robot(loc-x27-y6)
Atom at-robot(loc-x27-y7)
Atom at-robot(loc-x27-y8)
Atom at-robot(loc-x27-y9)
Atom at-robot(loc-x28-y0)
Atom at-robot(loc-x28-y1)
Atom at-robot(loc-x28-y10)
Atom at-robot(loc-x28-y11)
Atom at-robot(loc-x28-y12)
Atom at-robot(loc-x28-y13)
Atom at-robot(loc-x28-y14)
Atom at-robot(loc-x28-y15)
Atom at-robot(loc-x28-y16)
Atom at-robot(loc-x28-y17)
Atom at-robot(loc-x28-y18)
Atom at-robot(loc-x28-y19)
Atom at-robot(loc-x28-y2)
Atom at-robot(loc-x28-y20)
Atom at-robot(loc-x28-y21)
Atom at-robot(loc-x28-y22)
Atom at-robot(loc-x28-y23)
Atom at-robot(loc-x28-y24)
Atom at-robot(loc-x28-y25)
Atom at-robot(loc-x28-y26)
Atom at-robot(loc-x28-y27)
Atom at-robot(loc-x28-y28)
Atom at-robot(loc-x28-y29)
Atom at-robot(loc-x28-y3)
Atom at-robot(loc-x28-y30)
Atom at-robot(loc-x28-y4)
Atom at-robot(loc-x28-y5)
Atom at-robot(loc-x28-y6)
Atom at-robot(loc-x28-y7)
Atom at-robot(loc-x28-y8)
Atom at-robot(loc-x28-y9)
Atom at-robot(loc-x29-y0)
Atom at-robot(loc-x29-y1)
Atom at-robot(loc-x29-y10)
Atom at-robot(loc-x29-y11)
Atom at-robot(loc-x29-y12)
Atom at-robot(loc-x29-y13)
Atom at-robot(loc-x29-y14)
Atom at-robot(loc-x29-y15)
Atom at-robot(loc-x29-y16)
Atom at-robot(loc-x29-y17)
Atom at-robot(loc-x29-y18)
Atom at-robot(loc-x29-y19)
Atom at-robot(loc-x29-y2)
Atom at-robot(loc-x29-y20)
Atom at-robot(loc-x29-y21)
Atom at-robot(loc-x29-y22)
Atom at-robot(loc-x29-y23)
Atom at-robot(loc-x29-y24)
Atom at-robot(loc-x29-y25)
Atom at-robot(loc-x29-y26)
Atom at-robot(loc-x29-y27)
Atom at-robot(loc-x29-y28)
Atom at-robot(loc-x29-y29)
Atom at-robot(loc-x29-y3)
Atom at-robot(loc-x29-y30)
Atom at-robot(loc-x29-y4)
Atom at-robot(loc-x29-y5)
Atom at-robot(loc-x29-y6)
Atom at-robot(loc-x29-y7)
Atom at-robot(loc-x29-y8)
Atom at-robot(loc-x29-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y17)
Atom at-robot(loc-x3-y18)
Atom at-robot(loc-x3-y19)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y20)
Atom at-robot(loc-x3-y21)
Atom at-robot(loc-x3-y22)
Atom at-robot(loc-x3-y23)
Atom at-robot(loc-x3-y24)
Atom at-robot(loc-x3-y25)
Atom at-robot(loc-x3-y26)
Atom at-robot(loc-x3-y27)
Atom at-robot(loc-x3-y28)
Atom at-robot(loc-x3-y29)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y30)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x30-y0)
Atom at-robot(loc-x30-y1)
Atom at-robot(loc-x30-y10)
Atom at-robot(loc-x30-y11)
Atom at-robot(loc-x30-y12)
Atom at-robot(loc-x30-y13)
Atom at-robot(loc-x30-y14)
Atom at-robot(loc-x30-y15)
Atom at-robot(loc-x30-y16)
Atom at-robot(loc-x30-y17)
Atom at-robot(loc-x30-y18)
Atom at-robot(loc-x30-y19)
Atom at-robot(loc-x30-y2)
Atom at-robot(loc-x30-y20)
Atom at-robot(loc-x30-y21)
Atom at-robot(loc-x30-y22)
Atom at-robot(loc-x30-y23)
Atom at-robot(loc-x30-y24)
Atom at-robot(loc-x30-y25)
Atom at-robot(loc-x30-y26)
Atom at-robot(loc-x30-y27)
Atom at-robot(loc-x30-y28)
Atom at-robot(loc-x30-y29)
Atom at-robot(loc-x30-y3)
Atom at-robot(loc-x30-y30)
Atom at-robot(loc-x30-y4)
Atom at-robot(loc-x30-y5)
Atom at-robot(loc-x30-y6)
Atom at-robot(loc-x30-y7)
Atom at-robot(loc-x30-y8)
Atom at-robot(loc-x30-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y17)
Atom at-robot(loc-x4-y18)
Atom at-robot(loc-x4-y19)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y20)
Atom at-robot(loc-x4-y21)
Atom at-robot(loc-x4-y22)
Atom at-robot(loc-x4-y23)
Atom at-robot(loc-x4-y24)
Atom at-robot(loc-x4-y25)
Atom at-robot(loc-x4-y26)
Atom at-robot(loc-x4-y27)
Atom at-robot(loc-x4-y28)
Atom at-robot(loc-x4-y29)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y30)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y17)
Atom at-robot(loc-x5-y18)
Atom at-robot(loc-x5-y19)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y20)
Atom at-robot(loc-x5-y21)
Atom at-robot(loc-x5-y22)
Atom at-robot(loc-x5-y23)
Atom at-robot(loc-x5-y24)
Atom at-robot(loc-x5-y25)
Atom at-robot(loc-x5-y26)
Atom at-robot(loc-x5-y27)
Atom at-robot(loc-x5-y28)
Atom at-robot(loc-x5-y29)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y30)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y17)
Atom at-robot(loc-x6-y18)
Atom at-robot(loc-x6-y19)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y20)
Atom at-robot(loc-x6-y21)
Atom at-robot(loc-x6-y22)
Atom at-robot(loc-x6-y23)
Atom at-robot(loc-x6-y24)
Atom at-robot(loc-x6-y25)
Atom at-robot(loc-x6-y26)
Atom at-robot(loc-x6-y27)
Atom at-robot(loc-x6-y28)
Atom at-robot(loc-x6-y29)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y30)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y17)
Atom at-robot(loc-x7-y18)
Atom at-robot(loc-x7-y19)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y20)
Atom at-robot(loc-x7-y21)
Atom at-robot(loc-x7-y22)
Atom at-robot(loc-x7-y23)
Atom at-robot(loc-x7-y24)
Atom at-robot(loc-x7-y25)
Atom at-robot(loc-x7-y26)
Atom at-robot(loc-x7-y27)
Atom at-robot(loc-x7-y28)
Atom at-robot(loc-x7-y29)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y30)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y17)
Atom at-robot(loc-x8-y18)
Atom at-robot(loc-x8-y19)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y20)
Atom at-robot(loc-x8-y21)
Atom at-robot(loc-x8-y22)
Atom at-robot(loc-x8-y23)
Atom at-robot(loc-x8-y24)
Atom at-robot(loc-x8-y25)
Atom at-robot(loc-x8-y26)
Atom at-robot(loc-x8-y27)
Atom at-robot(loc-x8-y28)
Atom at-robot(loc-x8-y29)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y30)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y17)
Atom at-robot(loc-x9-y18)
Atom at-robot(loc-x9-y19)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y20)
Atom at-robot(loc-x9-y21)
Atom at-robot(loc-x9-y22)
Atom at-robot(loc-x9-y23)
Atom at-robot(loc-x9-y24)
Atom at-robot(loc-x9-y25)
Atom at-robot(loc-x9-y26)
Atom at-robot(loc-x9-y27)
Atom at-robot(loc-x9-y28)
Atom at-robot(loc-x9-y29)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y30)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
en




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




oc-x8-y21
0
2
0 0 882 913
0 913 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x6-y22
0
2
0 0 883 852
0 852 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x7-y21
0
2
0 0 883 882
0 882 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x7-y23
0
2
0 0 883 884
0 884 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x8-y22
0
2
0 0 883 914
0 914 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x6-y23
0
2
0 0 884 853
0 853 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x7-y22
0
2
0 0 884 883
0 883 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x7-y24
0
2
0 0 884 885
0 885 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x8-y23
0
2
0 0 884 915
0 915 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x6-y24
0
2
0 0 885 854
0 854 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x7-y23
0
2
0 0 885 884
0 884 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x7-y25
0
2
0 0 885 886
0 886 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x8-y24
0
2
0 0 885 916
0 916 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x6-y25
0
2
0 0 886 855
0 855 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x7-y24
0
2
0 0 886 885
0 885 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x7-y26
0
2
0 0 886 887
0 887 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x8-y25
0
2
0 0 886 917
0 917 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x6-y26
0
2
0 0 887 856
0 856 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x7-y25
0
2
0 0 887 886
0 886 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x7-y27
0
2
0 0 887 888
0 888 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x8-y26
0
2
0 0 887 918
0 918 -1 0
1
end_operator
begin_operator
move loc-x7-y27 loc-x6-y27
0
2
0 0 888 857
0 857 -1 0
1
end_operator
begin_operator
move loc-x7-y27 loc-x7-y26
0
2
0 0 888 887
0 887 -1 0
1
end_operator
begin_operator
move loc-x7-y27 loc-x7-y28
0
2
0 0 888 889
0 889 -1 0
1
end_operator
begin_operator
move loc-x7-y27 loc-x8-y27
0
2
0 0 888 919
0 919 -1 0
1
end_operator
begin_operator
move loc-x7-y28 loc-x6-y28
0
2
0 0 889 858
0 858 -1 0
1
end_operator
begin_operator
move loc-x7-y28 loc-x7-y27
0
2
0 0 889 888
0 888 -1 0
1
end_operator
begin_operator
move loc-x7-y28 loc-x7-y29
0
2
0 0 889 890
0 890 -1 0
1
end_operator
begin_operator
move loc-x7-y28 loc-x8-y28
0
2
0 0 889 920
0 920 -1 0
1
end_operator
begin_operator
move loc-x7-y29 loc-x6-y29
0
2
0 0 890 859
0 859 -1 0
1
end_operator
begin_operator
move loc-x7-y29 loc-x7-y28
0
2
0 0 890 889
0 889 -1 0
1
end_operator
begin_operator
move loc-x7-y29 loc-x7-y30
0
2
0 0 890 892
0 892 -1 0
1
end_operator
begin_operator
move loc-x7-y29 loc-x8-y29
0
2
0 0 890 921
0 921 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 891 860
0 860 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 891 880
0 880 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 891 893
0 893 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 891 922
0 922 -1 0
1
end_operator
begin_operator
move loc-x7-y30 loc-x6-y30
0
2
0 0 892 861
0 861 -1 0
1
end_operator
begin_operator
move loc-x7-y30 loc-x7-y29
0
2
0 0 892 890
0 890 -1 0
1
end_operator
begin_operator
move loc-x7-y30 loc-x8-y30
0
2
0 0 892 923
0 923 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 893 862
0 862 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 893 891
0 891 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 893 894
0 894 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 893 924
0 924 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 894 863
0 863 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 894 893
0 893 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 894 895
0 895 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 894 925
0 925 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 895 864
0 864 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 895 894
0 894 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 895 896
0 896 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 895 926
0 926 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 896 865
0 865 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 896 895
0 895 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 896 897
0 897 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 896 927
0 927 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 897 866
0 866 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 897 896
0 896 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 897 898
0 898 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 897 928
0 928 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 898 867
0 867 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 898 870
0 870 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 898 897
0 897 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 898 929
0 929 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 899 868
0 868 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 899 900
0 900 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 899 930
0 930 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 900 869
0 869 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 900 899
0 899 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 900 911
0 911 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 900 931
0 931 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 901 870
0 870 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 901 902
0 902 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 901 929
0 929 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 901 932
0 932 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 902 871
0 871 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 902 901
0 901 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 902 903
0 903 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 902 933
0 933 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 903 872
0 872 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 903 902
0 902 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 903 904
0 904 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 903 934
0 934 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 904 873
0 873 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 904 903
0 903 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 904 905
0 905 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 904 935
0 935 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 905 874
0 874 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 905 904
0 904 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 905 906
0 906 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 905 936
0 936 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 906 875
0 875 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y14
0
2
0 0 906 905
0 905 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y16
0
2
0 0 906 907
0 907 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 906 937
0 937 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 907 876
0 876 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y15
0
2
0 0 907 906
0 906 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y17
0
2
0 0 907 908
0 908 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 907 938
0 938 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x7-y17
0
2
0 0 908 877
0 877 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y16
0
2
0 0 908 907
0 907 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y18
0
2
0 0 908 909
0 909 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x9-y17
0
2
0 0 908 939
0 939 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x7-y18
0
2
0 0 909 878
0 878 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y17
0
2
0 0 909 908
0 908 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y19
0
2
0 0 909 910
0 910 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x9-y18
0
2
0 0 909 940
0 940 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x7-y19
0
2
0 0 910 879
0 879 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y18
0
2
0 0 910 909
0 909 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y20
0
2
0 0 910 912
0 912 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x9-y19
0
2
0 0 910 941
0 941 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 911 880
0 880 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 911 900
0 900 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 911 922
0 922 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 911 942
0 942 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x7-y20
0
2
0 0 912 881
0 881 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y19
0
2
0 0 912 910
0 910 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y21
0
2
0 0 912 913
0 913 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x9-y20
0
2
0 0 912 943
0 943 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x7-y21
0
2
0 0 913 882
0 882 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y20
0
2
0 0 913 912
0 912 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y22
0
2
0 0 913 914
0 914 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x9-y21
0
2
0 0 913 944
0 944 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x7-y22
0
2
0 0 914 883
0 883 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x8-y21
0
2
0 0 914 913
0 913 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x8-y23
0
2
0 0 914 915
0 915 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x9-y22
0
2
0 0 914 945
0 945 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x7-y23
0
2
0 0 915 884
0 884 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x8-y22
0
2
0 0 915 914
0 914 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x8-y24
0
2
0 0 915 916
0 916 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x9-y23
0
2
0 0 915 946
0 946 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x7-y24
0
2
0 0 916 885
0 885 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x8-y23
0
2
0 0 916 915
0 915 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x8-y25
0
2
0 0 916 917
0 917 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x9-y24
0
2
0 0 916 947
0 947 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x7-y25
0
2
0 0 917 886
0 886 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x8-y24
0
2
0 0 917 916
0 916 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x8-y26
0
2
0 0 917 918
0 918 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x9-y25
0
2
0 0 917 948
0 948 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x7-y26
0
2
0 0 918 887
0 887 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x8-y25
0
2
0 0 918 917
0 917 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x8-y27
0
2
0 0 918 919
0 919 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x9-y26
0
2
0 0 918 949
0 949 -1 0
1
end_operator
begin_operator
move loc-x8-y27 loc-x7-y27
0
2
0 0 919 888
0 888 -1 0
1
end_operator
begin_operator
move loc-x8-y27 loc-x8-y26
0
2
0 0 919 918
0 918 -1 0
1
end_operator
begin_operator
move loc-x8-y27 loc-x8-y28
0
2
0 0 919 920
0 920 -1 0
1
end_operator
begin_operator
move loc-x8-y27 loc-x9-y27
0
2
0 0 919 950
0 950 -1 0
1
end_operator
begin_operator
move loc-x8-y28 loc-x7-y28
0
2
0 0 920 889
0 889 -1 0
1
end_operator
begin_operator
move loc-x8-y28 loc-x8-y27
0
2
0 0 920 919
0 919 -1 0
1
end_operator
begin_operator
move loc-x8-y28 loc-x8-y29
0
2
0 0 920 921
0 921 -1 0
1
end_operator
begin_operator
move loc-x8-y28 loc-x9-y28
0
2
0 0 920 951
0 951 -1 0
1
end_operator
begin_operator
move loc-x8-y29 loc-x7-y29
0
2
0 0 921 890
0 890 -1 0
1
end_operator
begin_operator
move loc-x8-y29 loc-x8-y28
0
2
0 0 921 920
0 920 -1 0
1
end_operator
begin_operator
move loc-x8-y29 loc-x8-y30
0
2
0 0 921 923
0 923 -1 0
1
end_operator
begin_operator
move loc-x8-y29 loc-x9-y29
0
2
0 0 921 952
0 952 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 922 891
0 891 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 922 911
0 911 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 922 924
0 924 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 922 953
0 953 -1 0
1
end_operator
begin_operator
move loc-x8-y30 loc-x7-y30
0
2
0 0 923 892
0 892 -1 0
1
end_operator
begin_operator
move loc-x8-y30 loc-x8-y29
0
2
0 0 923 921
0 921 -1 0
1
end_operator
begin_operator
move loc-x8-y30 loc-x9-y30
0
2
0 0 923 954
0 954 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 924 893
0 893 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 924 922
0 922 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 924 925
0 925 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 924 955
0 955 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 925 894
0 894 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 925 924
0 924 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 925 926
0 926 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 925 956
0 956 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 926 895
0 895 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 926 925
0 925 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 926 927
0 927 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 926 957
0 957 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 927 896
0 896 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 927 926
0 926 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 927 928
0 928 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 927 958
0 958 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 928 897
0 897 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 928 927
0 927 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 928 929
0 929 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 928 959
0 959 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 929 898
0 898 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 929 901
0 901 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 929 928
0 928 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 929 960
0 960 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 930 62
0 63 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 930 899
0 899 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 930 931
0 931 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 931 63
0 64 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 931 900
0 900 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 931 930
0 930 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 931 942
0 942 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 932 64
0 65 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 932 901
0 901 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 932 933
0 933 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 932 960
0 960 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 933 65
0 66 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 933 902
0 902 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 933 932
0 932 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 933 934
0 934 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 934 66
0 67 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 934 903
0 903 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 934 933
0 933 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 934 935
0 935 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 935 67
0 68 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 935 904
0 904 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 935 934
0 934 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 935 936
0 936 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 936 68
0 69 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 936 905
0 905 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 936 935
0 935 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y15
0
2
0 0 936 937
0 937 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 937 69
0 70 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x8-y15
0
2
0 0 937 906
0 906 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y14
0
2
0 0 937 936
0 936 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y16
0
2
0 0 937 938
0 938 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 938 70
0 71 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x8-y16
0
2
0 0 938 907
0 907 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y15
0
2
0 0 938 937
0 937 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y17
0
2
0 0 938 939
0 939 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x10-y17
0
2
0 0 939 71
0 72 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x8-y17
0
2
0 0 939 908
0 908 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y16
0
2
0 0 939 938
0 938 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y18
0
2
0 0 939 940
0 940 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x10-y18
0
2
0 0 940 72
0 73 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x8-y18
0
2
0 0 940 909
0 909 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y17
0
2
0 0 940 939
0 939 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y19
0
2
0 0 940 941
0 941 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x10-y19
0
2
0 0 941 73
0 74 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x8-y19
0
2
0 0 941 910
0 910 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y18
0
2
0 0 941 940
0 940 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y20
0
2
0 0 941 943
0 943 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 942 74
0 75 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 942 911
0 911 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 942 931
0 931 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 942 953
0 953 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x10-y20
0
2
0 0 943 75
0 76 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x8-y20
0
2
0 0 943 912
0 912 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y19
0
2
0 0 943 941
0 941 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y21
0
2
0 0 943 944
0 944 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x10-y21
0
2
0 0 944 76
0 77 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x8-y21
0
2
0 0 944 913
0 913 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y20
0
2
0 0 944 943
0 943 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y22
0
2
0 0 944 945
0 945 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x10-y22
0
2
0 0 945 77
0 78 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x8-y22
0
2
0 0 945 914
0 914 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x9-y21
0
2
0 0 945 944
0 944 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x9-y23
0
2
0 0 945 946
0 946 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x10-y23
0
2
0 0 946 78
0 79 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x8-y23
0
2
0 0 946 915
0 915 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x9-y22
0
2
0 0 946 945
0 945 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x9-y24
0
2
0 0 946 947
0 947 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x10-y24
0
2
0 0 947 79
0 80 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x8-y24
0
2
0 0 947 916
0 916 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x9-y23
0
2
0 0 947 946
0 946 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x9-y25
0
2
0 0 947 948
0 948 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x10-y25
0
2
0 0 948 80
0 81 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x8-y25
0
2
0 0 948 917
0 917 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x9-y24
0
2
0 0 948 947
0 947 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x9-y26
0
2
0 0 948 949
0 949 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x10-y26
0
2
0 0 949 81
0 82 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x8-y26
0
2
0 0 949 918
0 918 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x9-y25
0
2
0 0 949 948
0 948 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x9-y27
0
2
0 0 949 950
0 950 -1 0
1
end_operator
begin_operator
move loc-x9-y27 loc-x10-y27
0
2
0 0 950 82
0 83 -1 0
1
end_operator
begin_operator
move loc-x9-y27 loc-x8-y27
0
2
0 0 950 919
0 919 -1 0
1
end_operator
begin_operator
move loc-x9-y27 loc-x9-y26
0
2
0 0 950 949
0 949 -1 0
1
end_operator
begin_operator
move loc-x9-y27 loc-x9-y28
0
2
0 0 950 951
0 951 -1 0
1
end_operator
begin_operator
move loc-x9-y28 loc-x10-y28
0
2
0 0 951 83
0 84 -1 0
1
end_operator
begin_operator
move loc-x9-y28 loc-x8-y28
0
2
0 0 951 920
0 920 -1 0
1
end_operator
begin_operator
move loc-x9-y28 loc-x9-y27
0
2
0 0 951 950
0 950 -1 0
1
end_operator
begin_operator
move loc-x9-y28 loc-x9-y29
0
2
0 0 951 952
0 952 -1 0
1
end_operator
begin_operator
move loc-x9-y29 loc-x10-y29
0
2
0 0 952 84
0 85 -1 0
1
end_operator
begin_operator
move loc-x9-y29 loc-x8-y29
0
2
0 0 952 921
0 921 -1 0
1
end_operator
begin_operator
move loc-x9-y29 loc-x9-y28
0
2
0 0 952 951
0 951 -1 0
1
end_operator
begin_operator
move loc-x9-y29 loc-x9-y30
0
2
0 0 952 954
0 954 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 953 85
0 86 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 953 922
0 922 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 953 942
0 942 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 953 955
0 955 -1 0
1
end_operator
begin_operator
move loc-x9-y30 loc-x10-y30
0
2
0 0 954 86
0 87 -1 0
1
end_operator
begin_operator
move loc-x9-y30 loc-x8-y30
0
2
0 0 954 923
0 923 -1 0
1
end_operator
begin_operator
move loc-x9-y30 loc-x9-y29
0
2
0 0 954 952
0 952 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 955 87
0 88 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 955 924
0 924 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 955 953
0 953 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 955 956
0 956 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 956 88
0 89 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 956 925
0 925 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 956 955
0 955 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 956 957
0 957 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 957 89
0 90 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 957 926
0 926 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 957 956
0 956 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 957 958
0 958 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 958 90
0 91 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 958 927
0 927 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 958 957
0 957 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 958 959
0 959 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 959 91
0 92 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 959 928
0 928 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 959 958
0 958 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 959 960
0 960 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 960 92
0 93 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 960 929
0 929 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 960 932
0 932 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 960 959
0 959 -1 0
1
end_operator
0
