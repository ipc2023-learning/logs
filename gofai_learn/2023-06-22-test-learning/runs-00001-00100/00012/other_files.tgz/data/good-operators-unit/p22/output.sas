begin_version
3
end_version
begin_metric
0
end_metric
529
begin_variable
var0
-1
529
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y17)
Atom at-robot(loc-x0-y18)
Atom at-robot(loc-x0-y19)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y20)
Atom at-robot(loc-x0-y21)
Atom at-robot(loc-x0-y22)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y17)
Atom at-robot(loc-x1-y18)
Atom at-robot(loc-x1-y19)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y20)
Atom at-robot(loc-x1-y21)
Atom at-robot(loc-x1-y22)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y17)
Atom at-robot(loc-x10-y18)
Atom at-robot(loc-x10-y19)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y20)
Atom at-robot(loc-x10-y21)
Atom at-robot(loc-x10-y22)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y17)
Atom at-robot(loc-x11-y18)
Atom at-robot(loc-x11-y19)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y20)
Atom at-robot(loc-x11-y21)
Atom at-robot(loc-x11-y22)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y17)
Atom at-robot(loc-x12-y18)
Atom at-robot(loc-x12-y19)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y20)
Atom at-robot(loc-x12-y21)
Atom at-robot(loc-x12-y22)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y17)
Atom at-robot(loc-x13-y18)
Atom at-robot(loc-x13-y19)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y20)
Atom at-robot(loc-x13-y21)
Atom at-robot(loc-x13-y22)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y17)
Atom at-robot(loc-x14-y18)
Atom at-robot(loc-x14-y19)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y20)
Atom at-robot(loc-x14-y21)
Atom at-robot(loc-x14-y22)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y17)
Atom at-robot(loc-x15-y18)
Atom at-robot(loc-x15-y19)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y20)
Atom at-robot(loc-x15-y21)
Atom at-robot(loc-x15-y22)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y17)
Atom at-robot(loc-x16-y18)
Atom at-robot(loc-x16-y19)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y20)
Atom at-robot(loc-x16-y21)
Atom at-robot(loc-x16-y22)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x17-y0)
Atom at-robot(loc-x17-y1)
Atom at-robot(loc-x17-y10)
Atom at-robot(loc-x17-y11)
Atom at-robot(loc-x17-y12)
Atom at-robot(loc-x17-y13)
Atom at-robot(loc-x17-y14)
Atom at-robot(loc-x17-y15)
Atom at-robot(loc-x17-y16)
Atom at-robot(loc-x17-y17)
Atom at-robot(loc-x17-y18)
Atom at-robot(loc-x17-y19)
Atom at-robot(loc-x17-y2)
Atom at-robot(loc-x17-y20)
Atom at-robot(loc-x17-y21)
Atom at-robot(loc-x17-y22)
Atom at-robot(loc-x17-y3)
Atom at-robot(loc-x17-y4)
Atom at-robot(loc-x17-y5)
Atom at-robot(loc-x17-y6)
Atom at-robot(loc-x17-y7)
Atom at-robot(loc-x17-y8)
Atom at-robot(loc-x17-y9)
Atom at-robot(loc-x18-y0)
Atom at-robot(loc-x18-y1)
Atom at-robot(loc-x18-y10)
Atom at-robot(loc-x18-y11)
Atom at-robot(loc-x18-y12)
Atom at-robot(loc-x18-y13)
Atom at-robot(loc-x18-y14)
Atom at-robot(loc-x18-y15)
Atom at-robot(loc-x18-y16)
Atom at-robot(loc-x18-y17)
Atom at-robot(loc-x18-y18)
Atom at-robot(loc-x18-y19)
Atom at-robot(loc-x18-y2)
Atom at-robot(loc-x18-y20)
Atom at-robot(loc-x18-y21)
Atom at-robot(loc-x18-y22)
Atom at-robot(loc-x18-y3)
Atom at-robot(loc-x18-y4)
Atom at-robot(loc-x18-y5)
Atom at-robot(loc-x18-y6)
Atom at-robot(loc-x18-y7)
Atom at-robot(loc-x18-y8)
Atom at-robot(loc-x18-y9)
Atom at-robot(loc-x19-y0)
Atom at-robot(loc-x19-y1)
Atom at-robot(loc-x19-y10)
Atom at-robot(loc-x19-y11)
Atom at-robot(loc-x19-y12)
Atom at-robot(loc-x19-y13)
Atom at-robot(loc-x19-y14)
Atom at-robot(loc-x19-y15)
Atom at-robot(loc-x19-y16)
Atom at-robot(loc-x19-y17)
Atom at-robot(loc-x19-y18)
Atom at-robot(loc-x19-y19)
Atom at-robot(loc-x19-y2)
Atom at-robot(loc-x19-y20)
Atom at-robot(loc-x19-y21)
Atom at-robot(loc-x19-y22)
Atom at-robot(loc-x19-y3)
Atom at-robot(loc-x19-y4)
Atom at-robot(loc-x19-y5)
Atom at-robot(loc-x19-y6)
Atom at-robot(loc-x19-y7)
Atom at-robot(loc-x19-y8)
Atom at-robot(loc-x19-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y17)
Atom at-robot(loc-x2-y18)
Atom at-robot(loc-x2-y19)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y20)
Atom at-robot(loc-x2-y21)
Atom at-robot(loc-x2-y22)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x20-y0)
Atom at-robot(loc-x20-y1)
Atom at-robot(loc-x20-y10)
Atom at-robot(loc-x20-y11)
Atom at-robot(loc-x20-y12)
Atom at-robot(loc-x20-y13)
Atom at-robot(loc-x20-y14)
Atom at-robot(loc-x20-y15)
Atom at-robot(loc-x20-y16)
Atom at-robot(loc-x20-y17)
Atom at-robot(loc-x20-y18)
Atom at-robot(loc-x20-y19)
Atom at-robot(loc-x20-y2)
Atom at-robot(loc-x20-y20)
Atom at-robot(loc-x20-y21)
Atom at-robot(loc-x20-y22)
Atom at-robot(loc-x20-y3)
Atom at-robot(loc-x20-y4)
Atom at-robot(loc-x20-y5)
Atom at-robot(loc-x20-y6)
Atom at-robot(loc-x20-y7)
Atom at-robot(loc-x20-y8)
Atom at-robot(loc-x20-y9)
Atom at-robot(loc-x21-y0)
Atom at-robot(loc-x21-y1)
Atom at-robot(loc-x21-y10)
Atom at-robot(loc-x21-y11)
Atom at-robot(loc-x21-y12)
Atom at-robot(loc-x21-y13)
Atom at-robot(loc-x21-y14)
Atom at-robot(loc-x21-y15)
Atom at-robot(loc-x21-y16)
Atom at-robot(loc-x21-y17)
Atom at-robot(loc-x21-y18)
Atom at-robot(loc-x21-y19)
Atom at-robot(loc-x21-y2)
Atom at-robot(loc-x21-y20)
Atom at-robot(loc-x21-y21)
Atom at-robot(loc-x21-y22)
Atom at-robot(loc-x21-y3)
Atom at-robot(loc-x21-y4)
Atom at-robot(loc-x21-y5)
Atom at-robot(loc-x21-y6)
Atom at-robot(loc-x21-y7)
Atom at-robot(loc-x21-y8)
Atom at-robot(loc-x21-y9)
Atom at-robot(loc-x22-y0)
Atom at-robot(loc-x22-y1)
Atom at-robot(loc-x22-y10)
Atom at-robot(loc-x22-y11)
Atom at-robot(loc-x22-y12)
Atom at-robot(loc-x22-y13)
Atom at-robot(loc-x22-y14)
Atom at-robot(loc-x22-y15)
Atom at-robot(loc-x22-y16)
Atom at-robot(loc-x22-y17)
Atom at-robot(loc-x22-y18)
Atom at-robot(loc-x22-y19)
Atom at-robot(loc-x22-y2)
Atom at-robot(loc-x22-y20)
Atom at-robot(loc-x22-y21)
Atom at-robot(loc-x22-y22)
Atom at-robot(loc-x22-y3)
Atom at-robot(loc-x22-y4)
Atom at-robot(loc-x22-y5)
Atom at-robot(loc-x22-y6)
Atom at-robot(loc-x22-y7)
Atom at-robot(loc-x22-y8)
Atom at-robot(loc-x22-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y17)
Atom at-robot(loc-x3-y18)
Atom at-robot(loc-x3-y19)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y20)
Atom at-robot(loc-x3-y21)
Atom at-robot(loc-x3-y22)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y17)
Atom at-robot(loc-x4-y18)
Atom at-robot(loc-x4-y19)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y20)
Atom at-robot(loc-x4-y21)
Atom at-robot(loc-x4-y22)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y17)
Atom at-robot(loc-x5-y18)
Atom at-robot(loc-x5-y19)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y20)
Atom at-robot(loc-x5-y21)
Atom at-robot(loc-x5-y22)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y17)
Atom at-robot(loc-x6-y18)
Atom at-robot(loc-x6-y19)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y20)
Atom at-robot(loc-x6-y21)
Atom at-robot(loc-x6-y22)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y17)
Atom at-robot(loc-x7-y18)
Atom at-robot(loc-x7-y19)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y20)
Atom at-robot(loc-x7-y21)
Atom at-robot(loc-x7-y22)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y17)
Atom at-robot(loc-x8-y18)
Atom at-robot(loc-x8-y19)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y20)
Atom at-robot(loc-x8-y21)
Atom at-robot(loc-x8-y22)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y17)
Atom at-robot(loc-x9-y18)
Atom at-robot(loc-x9-y19)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y20)
Atom at-robot(loc-x9-y21)
Atom at-robot(loc-x9-y22)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var3
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var4
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var5
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var6
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var7
-1
2
Atom visited(loc-x0-y14)
NegatedAtom visited(loc-x0-y14)
end_variable
begin_variable
var8
-1
2
Atom visited(loc-x0-y15)
NegatedAtom visited(loc-x0-y15)
end_variable
begin_variable
var9
-1
2
Atom visited(loc-x0-y16)
NegatedAtom visited(loc-x0-y16)
end_variable
begin_variable
var10
-1
2
Atom visited(loc-x0-y17)
NegatedAtom visited(loc-x0-y17)
end_variable
begin_variable
var11
-1
2
Atom visited(loc-x0-y18)
NegatedAtom visited(loc-x0-y18)
end_variable
begin_variable
var12
-1
2
Atom visited(loc-x0-y19)
NegatedAtom visited(loc-x0-y19)
end_variable
begin_variable
var13
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var14
-1
2
Atom visited(loc-x0-y20)
NegatedAtom visited(loc-x0-y20)
end_variable
begin_variable
var15
-1
2
Atom visited(loc-x0-y21)
NegatedAtom visited(loc-x0-y21)
end_variable
begin_variable
var16
-1
2
Atom visited(loc-x0-y22)
NegatedAtom visited(loc-x0-y22)
end_variable
begin_variable
var17
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var18
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var19
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var20
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var21
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var22
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var23
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var24
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var25
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var26
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var27
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var28
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var29
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var30
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var31
-1
2
Atom visited(loc-x1-y15)
NegatedAtom visited(loc-x1-y15)
end_variable
begin_variable
var32
-1
2
Atom visited(loc-x1-y16)
NegatedAtom visited(loc-x1-y16)
end_variable
begin_variable
var33
-1
2
Atom visited(loc-x1-y17)
NegatedAtom visited(loc-x1-y17)
end_variable
begin_variable
var34
-1
2
Atom visited(loc-x1-y18)
NegatedAtom visited(loc-x1-y18)
end_variable
begin_variable
var35
-1
2
Atom visited(loc-x1-y19)
NegatedAtom visited(loc-x1-y19)
end_variable
begin_variable
var36
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var37
-1
2
Atom visited(loc-x1-y20)
NegatedAtom visited(loc-x1-y20)
end_variable
begin_variable
var38
-1
2
Atom visited(loc-x1-y21)
NegatedAtom visited(loc-x1-y21)
end_variable
begin_variable
var39
-1
2
Atom visited(loc-x1-y22)
NegatedAtom visited(loc-x1-y22)
end_variable
begin_variable
var40
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var41
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var42
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var43
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var44
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var45
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var46
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var47
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var48
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var49
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var50
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var51
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var52
-1
2
Atom visited(loc-x10-y13)
NegatedAtom visited(loc-x10-y13)
end_variable
begin_variable
var53
-1
2
Atom visited(loc-x10-y14)
NegatedAtom visited(loc-x10-y14)
end_variable
begin_variable
var54
-1
2
Atom visited(loc-x10-y15)
NegatedAtom visited(loc-x10-y15)
end_variable
begin_variable
var55
-1
2
Atom visited(loc-x10-y16)
NegatedAtom visited(loc-x10-y16)
end_variable
begin_variable
var56
-1
2
Atom visited(loc-x10-y17)
NegatedAtom visited(loc-x10-y17)
end_variable
begin_variable
var57
-1
2
Atom visited(loc-x10-y18)
NegatedAtom visited(loc-x10-y18)
end_variable
begin_variable
var58
-1
2
Atom visited(loc-x10-y19)
NegatedAtom visited(loc-x10-y19)
end_variable
begin_variable
var59
-1
2
Atom visited(loc-x10-y2)
NegatedAtom visited(loc-x10-y2)
end_variable
begin_variable
var60
-1
2
Atom visited(loc-x10-y20)
NegatedAtom visited(loc-x10-y20)
end_variable
begin_variable
var61
-1
2
Atom visited(loc-x10-y21)
NegatedAtom visited(loc-x10-y21)
end_variable
begin_variable
var62
-1
2
Atom visited(loc-x10-y22)
NegatedAtom visited(loc-x10-y22)
end_variable
begin_variable
var63
-1
2
Atom visited(loc-x10-y3)
NegatedAtom visited(loc-x10-y3)
end_variable
begin_variable
var64
-1
2
Atom visited(loc-x10-y4)
NegatedAtom visited(loc-x10-y4)
end_variable
begin_variable
var65
-1
2
Atom visited(loc-x10-y5)
NegatedAtom visited(loc-x10-y5)
end_variable
begin_variable
var66
-1
2
Atom visited(loc-x10-y6)
NegatedAtom visited(loc-x10-y6)
end_variable
begin_variable
var67
-1
2
Atom visited(loc-x10-y7)
NegatedAtom visited(loc-x10-y7)
end_variable
begin_variable
var68
-1
2
Atom visited(loc-x10-y8)
NegatedAtom visited(loc-x10-y8)
end_variable
begin_variable
var69
-1
2
Atom visited(loc-x10-y9)
NegatedAtom visited(loc-x10-y9)
end_variable
begin_variable
var70
-1
2
Atom visited(loc-x11-y0)
NegatedAtom visited(loc-x11-y0)
end_variable
begin_variable
var71
-1
2
Atom visited(loc-x11-y1)
NegatedAtom visited(loc-x11-y1)
end_variable
begin_variable
var72
-1
2
Atom visited(loc-x11-y10)
NegatedAtom visited(loc-x11-y10)
end_variable
begin_variable
var73
-1
2
Atom visited(loc-x11-y11)
NegatedAtom visited(loc-x11-y11)
end_variable
begin_variable
var74
-1
2
Atom visited(loc-x11-y12)
NegatedAtom visited(loc-x11-y12)
end_variable
begin_variable
var75
-1
2
Atom visited(loc-x11-y13)
NegatedAtom visited(loc-x11-y13)
end_variable
begin_variable
var76
-1
2
Atom visited(loc-x11-y14)
NegatedAtom visited(loc-x11-y14)
end_variable
begin_variable
var77
-1
2
Atom visited(loc-x11-y15)
NegatedAtom visited(loc-x11-y15)
end_variable
begin_variable
var78
-1
2
Atom visited(loc-x11-y16)
NegatedAtom visited(loc-x11-y16)
end_variable
begin_variable
var79
-1
2
Atom visited(loc-x11-y17)
NegatedAtom visited(loc-x11-y17)
end_variable
begin_variable
var80
-1
2
Atom visited(loc-x11-y18)
NegatedAtom visited(loc-x11-y18)
end_variable
begin_variable
var81
-1
2
Atom visited(loc-x11-y19)
NegatedAtom visited(loc-x11-y19)
end_variable
begin_variable
var82
-1
2
Atom visited(loc-x11-y2)
NegatedAtom visited(loc-x11-y2)
end_variable
begin_variable
var83
-1
2
Atom visited(loc-x11-y20)
NegatedAtom visited(loc-x11-y20)
end_variable
begin_variable
var84
-1
2
Atom visited(loc-x11-y21)
NegatedAtom visited(loc-x11-y21)
end_variable
begin_variable
var85
-1
2
Atom visited(loc-x11-y22)
NegatedAtom visited(loc-x11-y22)
end_variable
begin_variable
var86
-1
2
Atom visited(loc-x11-y3)
NegatedAtom visited(loc-x11-y3)
end_variable
begin_variable
var87
-1
2
Atom visited(loc-x11-y4)
NegatedAtom visited(loc-x11-y4)
end_variable
begin_variable
var88
-1
2
Atom visited(loc-x11-y5)
NegatedAtom visited(loc-x11-y5)
end_variable
begin_variable
var89
-1
2
Atom visited(loc-x11-y6)
NegatedAtom visited(loc-x11-y6)
end_variable
begin_variable
var90
-1
2
Atom visited(loc-x11-y7)
NegatedAtom visited(loc-x11-y7)
end_variable
begin_variable
var91
-1
2
Atom visited(loc-x11-y8)
NegatedAtom visited(loc-x11-y8)
end_variable
begin_variable
var92
-1
2
Atom visited(loc-x11-y9)
NegatedAtom visited(loc-x11-y9)
end_variable
begin_variable
var93
-1
2
Atom visited(loc-x12-y0)
NegatedAtom visited(loc-x12-y0)
end_variable
begin_variable
var94
-1
2
Atom visited(loc-x12-y1)
NegatedAtom visited(loc-x12-y1)
end_variable
begin_variable
var95
-1
2
Atom visited(loc-x12-y10)
NegatedAtom visited(loc-x12-y10)
end_variable
begin_variable
var96
-1
2
Atom visited(loc-x12-y11)
NegatedAtom visited(loc-x12-y11)
end_variable
begin_variable
var97
-1
2
Atom visited(loc-x12-y12)
NegatedAtom visited(loc-x12-y12)
end_variable
begin_variable
var98
-1
2
Atom visited(loc-x12-y13)
NegatedAtom visited(loc-x12-y13)
end_variable
begin_variable
var99
-1
2
Atom visited(loc-x12-y14)
NegatedAtom visited(loc-x12-y14)
end_variable
begin_variable
var100
-1
2
Atom visited(loc-x12-y15)
NegatedAtom visited(loc-x12-y15)
end_variable
begin_variable
var101
-1
2
Atom visited(loc-x12-y16)
NegatedAtom visited(loc-x12-y16)
end_variable
begin_variable
var102
-1
2
Atom visited(loc-x12-y17)
NegatedAtom visited(loc-x12-y17)
end_variable
begin_variable
var103
-1
2
Atom visited(loc-x12-y18)
NegatedAtom visited(loc-x12-y18)
end_variable
begin_variable
var104
-1
2
Atom visited(loc-x12-y19)
NegatedAtom visited(loc-x12-y19)
end_variable
begin_variable
var105
-1
2
Atom visited(loc-x12-y2)
NegatedAtom visited(loc-x12-y2)
end_variable
begin_variable
var106
-1
2
Atom visited(loc-x12-y20)
NegatedAtom visited(loc-x12-y20)
end_variable
begin_variable
var107
-1
2
Atom visited(loc-x12-y21)
NegatedAtom visited(loc-x12-y21)
end_variable
begin_variable
var108
-1
2
Atom visited(loc-x12-y22)
NegatedAtom visited(loc-x12-y22)
end_variable
begin_variable
var109
-1
2
Atom visited(loc-x12-y3)
NegatedAtom visited(loc-x12-y3)
end_variable
begin_variable
var110
-1
2
Atom visited(loc-x12-y4)
NegatedAtom visited(loc-x12-y4)
end_variable
begin_variable
var111
-1
2
Atom visited(loc-x12-y5)
NegatedAtom visited(loc-x12-y5)
end_variable
begin_variable
var112
-1
2
Atom visited(loc-x12-y6)
NegatedAtom visited(loc-x12-y6)
end_variable
begin_variable
var113
-1
2
Atom visited(loc-x12-y7)
NegatedAtom visited(loc-x12-y7)
end_variable
begin_variable
var114
-1
2
Atom visited(loc-x12-y8)
NegatedAtom visited(loc-x12-y8)
end_variable
begin_variable
var115
-1
2
Atom visited(loc-x12-y9)
NegatedAtom visited(loc-x12-y9)
end_variable
begin_variable
var116
-1
2
Atom visited(loc-x13-y0)
NegatedAtom visited(loc-x13-y0)
end_variable
begin_variable
var117
-1
2
Atom visited(loc-x13-y1)
NegatedAtom visited(loc-x13-y1)
end_variable
begin_variable
var118
-1
2
Atom visited(loc-x13-y10)
NegatedAtom visited(loc-x13-y10)
end_variable
begin_variable
var119
-1
2
Atom visited(loc-x13-y11)
NegatedAtom visited(loc-x13-y11)
end_variable
begin_variable
var120
-1
2
Atom visited(loc-x13-y12)
NegatedAtom visited(loc-x13-y12)
end_variable
begin_variable
var121
-1
2
Atom visited(loc-x13-y13)
NegatedAtom visited(loc-x13-y13)
end_variable
begi




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 0 450 427
0 427 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x6-y19
0
2
0 0 450 448
0 448 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x6-y21
0
2
0 0 450 451
0 451 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x7-y20
0
2
0 0 450 473
0 473 -1 0
1
end_operator
begin_operator
move loc-x6-y21 loc-x5-y21
0
2
0 0 451 428
0 428 -1 0
1
end_operator
begin_operator
move loc-x6-y21 loc-x6-y20
0
2
0 0 451 450
0 450 -1 0
1
end_operator
begin_operator
move loc-x6-y21 loc-x6-y22
0
2
0 0 451 452
0 452 -1 0
1
end_operator
begin_operator
move loc-x6-y21 loc-x7-y21
0
2
0 0 451 474
0 474 -1 0
1
end_operator
begin_operator
move loc-x6-y22 loc-x5-y22
0
2
0 0 452 429
0 429 -1 0
1
end_operator
begin_operator
move loc-x6-y22 loc-x6-y21
0
2
0 0 452 451
0 451 -1 0
1
end_operator
begin_operator
move loc-x6-y22 loc-x7-y22
0
2
0 0 452 475
0 475 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x5-y3
0
2
0 0 453 430
0 430 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y2
0
2
0 0 453 449
0 449 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y4
0
2
0 0 453 454
0 454 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x7-y3
0
2
0 0 453 476
0 476 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x5-y4
0
2
0 0 454 431
0 431 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y3
0
2
0 0 454 453
0 453 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y5
0
2
0 0 454 455
0 455 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x7-y4
0
2
0 0 454 477
0 477 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x5-y5
0
2
0 0 455 432
0 432 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y4
0
2
0 0 455 454
0 454 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y6
0
2
0 0 455 456
0 456 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x7-y5
0
2
0 0 455 478
0 478 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x5-y6
0
2
0 0 456 433
0 433 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y5
0
2
0 0 456 455
0 455 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y7
0
2
0 0 456 457
0 457 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x7-y6
0
2
0 0 456 479
0 479 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x5-y7
0
2
0 0 457 434
0 434 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y6
0
2
0 0 457 456
0 456 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y8
0
2
0 0 457 458
0 458 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x7-y7
0
2
0 0 457 480
0 480 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x5-y8
0
2
0 0 458 435
0 435 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y7
0
2
0 0 458 457
0 457 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y9
0
2
0 0 458 459
0 459 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x7-y8
0
2
0 0 458 481
0 481 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x5-y9
0
2
0 0 459 436
0 436 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y10
0
2
0 0 459 439
0 439 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y8
0
2
0 0 459 458
0 458 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x7-y9
0
2
0 0 459 482
0 482 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x6-y0
0
2
0 0 460 437
0 437 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x7-y1
0
2
0 0 460 461
0 461 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x8-y0
0
2
0 0 460 483
0 483 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x6-y1
0
2
0 0 461 438
0 438 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y0
0
2
0 0 461 460
0 460 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y2
0
2
0 0 461 472
0 472 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x8-y1
0
2
0 0 461 484
0 484 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x6-y10
0
2
0 0 462 439
0 439 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y11
0
2
0 0 462 463
0 463 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y9
0
2
0 0 462 482
0 482 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x8-y10
0
2
0 0 462 485
0 485 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 463 440
0 440 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 463 462
0 462 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 463 464
0 464 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 463 486
0 486 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 464 441
0 441 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 464 463
0 463 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y13
0
2
0 0 464 465
0 465 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 464 487
0 487 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x6-y13
0
2
0 0 465 442
0 442 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y12
0
2
0 0 465 464
0 464 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y14
0
2
0 0 465 466
0 466 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x8-y13
0
2
0 0 465 488
0 488 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 466 443
0 443 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 466 465
0 465 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y15
0
2
0 0 466 467
0 467 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 466 489
0 489 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x6-y15
0
2
0 0 467 444
0 444 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y14
0
2
0 0 467 466
0 466 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y16
0
2
0 0 467 468
0 468 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x8-y15
0
2
0 0 467 490
0 490 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x6-y16
0
2
0 0 468 445
0 445 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y15
0
2
0 0 468 467
0 467 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y17
0
2
0 0 468 469
0 469 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x8-y16
0
2
0 0 468 491
0 491 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x6-y17
0
2
0 0 469 446
0 446 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y16
0
2
0 0 469 468
0 468 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y18
0
2
0 0 469 470
0 470 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x8-y17
0
2
0 0 469 492
0 492 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x6-y18
0
2
0 0 470 447
0 447 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y17
0
2
0 0 470 469
0 469 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y19
0
2
0 0 470 471
0 471 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x8-y18
0
2
0 0 470 493
0 493 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x6-y19
0
2
0 0 471 448
0 448 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y18
0
2
0 0 471 470
0 470 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y20
0
2
0 0 471 473
0 473 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x8-y19
0
2
0 0 471 494
0 494 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 472 449
0 449 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 472 461
0 461 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 472 476
0 476 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 472 495
0 495 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x6-y20
0
2
0 0 473 450
0 450 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x7-y19
0
2
0 0 473 471
0 471 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x7-y21
0
2
0 0 473 474
0 474 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x8-y20
0
2
0 0 473 496
0 496 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x6-y21
0
2
0 0 474 451
0 451 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x7-y20
0
2
0 0 474 473
0 473 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x7-y22
0
2
0 0 474 475
0 475 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x8-y21
0
2
0 0 474 497
0 497 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x6-y22
0
2
0 0 475 452
0 452 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x7-y21
0
2
0 0 475 474
0 474 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x8-y22
0
2
0 0 475 498
0 498 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 476 453
0 453 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 476 472
0 472 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 476 477
0 477 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 476 499
0 499 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 477 454
0 454 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 477 476
0 476 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 477 478
0 478 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 477 500
0 500 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 478 455
0 455 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 478 477
0 477 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 478 479
0 479 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 478 501
0 501 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 479 456
0 456 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 479 478
0 478 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 479 480
0 480 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 479 502
0 502 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 480 457
0 457 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 480 479
0 479 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 480 481
0 481 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 480 503
0 503 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 481 458
0 458 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 481 480
0 480 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 481 482
0 482 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 481 504
0 504 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 482 459
0 459 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 482 462
0 462 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 482 481
0 481 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 482 505
0 505 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 483 460
0 460 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 483 484
0 484 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 483 506
0 506 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 484 461
0 461 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 484 483
0 483 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 484 495
0 495 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 484 507
0 507 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 485 462
0 462 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 485 486
0 486 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 485 505
0 505 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 485 508
0 508 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 486 463
0 463 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 486 485
0 485 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 486 487
0 487 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 486 509
0 509 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 487 464
0 464 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 487 486
0 486 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 487 488
0 488 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 487 510
0 510 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 488 465
0 465 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 488 487
0 487 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 488 489
0 489 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 488 511
0 511 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 489 466
0 466 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 489 488
0 488 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 489 490
0 490 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 489 512
0 512 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 490 467
0 467 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y14
0
2
0 0 490 489
0 489 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y16
0
2
0 0 490 491
0 491 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 490 513
0 513 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 491 468
0 468 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y15
0
2
0 0 491 490
0 490 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y17
0
2
0 0 491 492
0 492 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 491 514
0 514 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x7-y17
0
2
0 0 492 469
0 469 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y16
0
2
0 0 492 491
0 491 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y18
0
2
0 0 492 493
0 493 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x9-y17
0
2
0 0 492 515
0 515 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x7-y18
0
2
0 0 493 470
0 470 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y17
0
2
0 0 493 492
0 492 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y19
0
2
0 0 493 494
0 494 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x9-y18
0
2
0 0 493 516
0 516 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x7-y19
0
2
0 0 494 471
0 471 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y18
0
2
0 0 494 493
0 493 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y20
0
2
0 0 494 496
0 496 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x9-y19
0
2
0 0 494 517
0 517 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 495 472
0 472 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 495 484
0 484 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 495 499
0 499 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 495 518
0 518 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x7-y20
0
2
0 0 496 473
0 473 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y19
0
2
0 0 496 494
0 494 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y21
0
2
0 0 496 497
0 497 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x9-y20
0
2
0 0 496 519
0 519 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x7-y21
0
2
0 0 497 474
0 474 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y20
0
2
0 0 497 496
0 496 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y22
0
2
0 0 497 498
0 498 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x9-y21
0
2
0 0 497 520
0 520 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x7-y22
0
2
0 0 498 475
0 475 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x8-y21
0
2
0 0 498 497
0 497 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x9-y22
0
2
0 0 498 521
0 521 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 499 476
0 476 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 499 495
0 495 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 499 500
0 500 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 499 522
0 522 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 500 477
0 477 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 500 499
0 499 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 500 501
0 501 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 500 523
0 523 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 501 478
0 478 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 501 500
0 500 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 501 502
0 502 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 501 524
0 524 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 502 479
0 479 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 502 501
0 501 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 502 503
0 503 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 502 525
0 525 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 503 480
0 480 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 503 502
0 502 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 503 504
0 504 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 503 526
0 526 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 504 481
0 481 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 504 503
0 503 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 504 505
0 505 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 504 527
0 527 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 505 482
0 482 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 505 485
0 485 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 505 504
0 504 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 505 528
0 528 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 506 46
0 47 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 506 483
0 483 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 506 507
0 507 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 507 47
0 48 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 507 484
0 484 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 507 506
0 506 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 507 518
0 518 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 508 48
0 49 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 508 485
0 485 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 508 509
0 509 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 508 528
0 528 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 509 49
0 50 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 509 486
0 486 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 509 508
0 508 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 509 510
0 510 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 510 50
0 51 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 510 487
0 487 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 510 509
0 509 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 510 511
0 511 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 511 51
0 52 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 511 488
0 488 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 511 510
0 510 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 511 512
0 512 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 512 52
0 53 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 512 489
0 489 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 512 511
0 511 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y15
0
2
0 0 512 513
0 513 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 513 53
0 54 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x8-y15
0
2
0 0 513 490
0 490 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y14
0
2
0 0 513 512
0 512 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y16
0
2
0 0 513 514
0 514 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 514 54
0 55 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x8-y16
0
2
0 0 514 491
0 491 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y15
0
2
0 0 514 513
0 513 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y17
0
2
0 0 514 515
0 515 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x10-y17
0
2
0 0 515 55
0 56 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x8-y17
0
2
0 0 515 492
0 492 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y16
0
2
0 0 515 514
0 514 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y18
0
2
0 0 515 516
0 516 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x10-y18
0
2
0 0 516 56
0 57 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x8-y18
0
2
0 0 516 493
0 493 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y17
0
2
0 0 516 515
0 515 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y19
0
2
0 0 516 517
0 517 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x10-y19
0
2
0 0 517 57
0 58 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x8-y19
0
2
0 0 517 494
0 494 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y18
0
2
0 0 517 516
0 516 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y20
0
2
0 0 517 519
0 519 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 518 58
0 59 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 518 495
0 495 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 518 507
0 507 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 518 522
0 522 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x10-y20
0
2
0 0 519 59
0 60 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x8-y20
0
2
0 0 519 496
0 496 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y19
0
2
0 0 519 517
0 517 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y21
0
2
0 0 519 520
0 520 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x10-y21
0
2
0 0 520 60
0 61 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x8-y21
0
2
0 0 520 497
0 497 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y20
0
2
0 0 520 519
0 519 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y22
0
2
0 0 520 521
0 521 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x10-y22
0
2
0 0 521 61
0 62 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x8-y22
0
2
0 0 521 498
0 498 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x9-y21
0
2
0 0 521 520
0 520 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 522 62
0 63 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 522 499
0 499 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 522 518
0 518 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 522 523
0 523 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 523 63
0 64 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 523 500
0 500 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 523 522
0 522 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 523 524
0 524 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 524 64
0 65 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 524 501
0 501 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 524 523
0 523 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 524 525
0 525 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 525 65
0 66 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 525 502
0 502 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 525 524
0 524 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 525 526
0 526 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 526 66
0 67 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 526 503
0 503 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 526 525
0 525 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 526 527
0 527 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 527 67
0 68 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 527 504
0 504 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 527 526
0 526 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 527 528
0 528 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 528 68
0 69 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 528 505
0 505 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 528 508
0 508 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 528 527
0 527 -1 0
1
end_operator
0
