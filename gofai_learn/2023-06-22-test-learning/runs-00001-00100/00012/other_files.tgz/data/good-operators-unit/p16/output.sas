begin_version
3
end_version
begin_metric
0
end_metric
289
begin_variable
var0
-1
289
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var3
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var4
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var5
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var6
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var7
-1
2
Atom visited(loc-x0-y14)
NegatedAtom visited(loc-x0-y14)
end_variable
begin_variable
var8
-1
2
Atom visited(loc-x0-y15)
NegatedAtom visited(loc-x0-y15)
end_variable
begin_variable
var9
-1
2
Atom visited(loc-x0-y16)
NegatedAtom visited(loc-x0-y16)
end_variable
begin_variable
var10
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var11
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var12
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var13
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var14
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var15
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var16
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var17
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var18
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var19
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var20
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var21
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var22
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var23
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var24
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var25
-1
2
Atom visited(loc-x1-y15)
NegatedAtom visited(loc-x1-y15)
end_variable
begin_variable
var26
-1
2
Atom visited(loc-x1-y16)
NegatedAtom visited(loc-x1-y16)
end_variable
begin_variable
var27
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var28
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var29
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var30
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var31
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var32
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var33
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var34
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var35
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var36
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var37
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var38
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var39
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var40
-1
2
Atom visited(loc-x10-y13)
NegatedAtom visited(loc-x10-y13)
end_variable
begin_variable
var41
-1
2
Atom visited(loc-x10-y14)
NegatedAtom visited(loc-x10-y14)
end_variable
begin_variable
var42
-1
2
Atom visited(loc-x10-y15)
NegatedAtom visited(loc-x10-y15)
end_variable
begin_variable
var43
-1
2
Atom visited(loc-x10-y16)
NegatedAtom visited(loc-x10-y16)
end_variable
begin_variable
var44
-1
2
Atom visited(loc-x10-y2)
NegatedAtom visited(loc-x10-y2)
end_variable
begin_variable
var45
-1
2
Atom visited(loc-x10-y3)
NegatedAtom visited(loc-x10-y3)
end_variable
begin_variable
var46
-1
2
Atom visited(loc-x10-y4)
NegatedAtom visited(loc-x10-y4)
end_variable
begin_variable
var47
-1
2
Atom visited(loc-x10-y5)
NegatedAtom visited(loc-x10-y5)
end_variable
begin_variable
var48
-1
2
Atom visited(loc-x10-y6)
NegatedAtom visited(loc-x10-y6)
end_variable
begin_variable
var49
-1
2
Atom visited(loc-x10-y7)
NegatedAtom visited(loc-x10-y7)
end_variable
begin_variable
var50
-1
2
Atom visited(loc-x10-y8)
NegatedAtom visited(loc-x10-y8)
end_variable
begin_variable
var51
-1
2
Atom visited(loc-x10-y9)
NegatedAtom visited(loc-x10-y9)
end_variable
begin_variable
var52
-1
2
Atom visited(loc-x11-y0)
NegatedAtom visited(loc-x11-y0)
end_variable
begin_variable
var53
-1
2
Atom visited(loc-x11-y1)
NegatedAtom visited(loc-x11-y1)
end_variable
begin_variable
var54
-1
2
Atom visited(loc-x11-y10)
NegatedAtom visited(loc-x11-y10)
end_variable
begin_variable
var55
-1
2
Atom visited(loc-x11-y11)
NegatedAtom visited(loc-x11-y11)
end_variable
begin_variable
var56
-1
2
Atom visited(loc-x11-y12)
NegatedAtom visited(loc-x11-y12)
end_variable
begin_variable
var57
-1
2
Atom visited(loc-x11-y13)
NegatedAtom visited(loc-x11-y13)
end_variable
begin_variable
var58
-1
2
Atom visited(loc-x11-y14)
NegatedAtom visited(loc-x11-y14)
end_variable
begin_variable
var59
-1
2
Atom visited(loc-x11-y15)
NegatedAtom visited(loc-x11-y15)
end_variable
begin_variable
var60
-1
2
Atom visited(loc-x11-y16)
NegatedAtom visited(loc-x11-y16)
end_variable
begin_variable
var61
-1
2
Atom visited(loc-x11-y2)
NegatedAtom visited(loc-x11-y2)
end_variable
begin_variable
var62
-1
2
Atom visited(loc-x11-y3)
NegatedAtom visited(loc-x11-y3)
end_variable
begin_variable
var63
-1
2
Atom visited(loc-x11-y4)
NegatedAtom visited(loc-x11-y4)
end_variable
begin_variable
var64
-1
2
Atom visited(loc-x11-y5)
NegatedAtom visited(loc-x11-y5)
end_variable
begin_variable
var65
-1
2
Atom visited(loc-x11-y6)
NegatedAtom visited(loc-x11-y6)
end_variable
begin_variable
var66
-1
2
Atom visited(loc-x11-y7)
NegatedAtom visited(loc-x11-y7)
end_variable
begin_variable
var67
-1
2
Atom visited(loc-x11-y8)
NegatedAtom visited(loc-x11-y8)
end_variable
begin_variable
var68
-1
2
Atom visited(loc-x11-y9)
NegatedAtom visited(loc-x11-y9)
end_variable
begin_variable
var69
-1
2
Atom visited(loc-x12-y0)
NegatedAtom visited(loc-x12-y0)
end_variable
begin_variable
var70
-1
2
Atom visited(loc-x12-y1)
NegatedAtom visited(loc-x12-y1)
end_variable
begin_variable
var71
-1
2
Atom visited(loc-x12-y10)
NegatedAtom visited(loc-x12-y10)
end_variable
begin_variable
var72
-1
2
Atom visited(loc-x12-y11)
NegatedAtom visited(loc-x12-y11)
end_variable
begin_variable
var73
-1
2
Atom visited(loc-x12-y12)
NegatedAtom visited(loc-x12-y12)
end_variable
begin_variable
var74
-1
2
Atom visited(loc-x12-y13)
NegatedAtom visited(loc-x12-y13)
end_variable
begin_variable
var75
-1
2
Atom visited(loc-x12-y14)
NegatedAtom visited(loc-x12-y14)
end_variable
begin_variable
var76
-1
2
Atom visited(loc-x12-y15)
NegatedAtom visited(loc-x12-y15)
end_variable
begin_variable
var77
-1
2
Atom visited(loc-x12-y16)
NegatedAtom visited(loc-x12-y16)
end_variable
begin_variable
var78
-1
2
Atom visited(loc-x12-y2)
NegatedAtom visited(loc-x12-y2)
end_variable
begin_variable
var79
-1
2
Atom visited(loc-x12-y3)
NegatedAtom visited(loc-x12-y3)
end_variable
begin_variable
var80
-1
2
Atom visited(loc-x12-y4)
NegatedAtom visited(loc-x12-y4)
end_variable
begin_variable
var81
-1
2
Atom visited(loc-x12-y5)
NegatedAtom visited(loc-x12-y5)
end_variable
begin_variable
var82
-1
2
Atom visited(loc-x12-y6)
NegatedAtom visited(loc-x12-y6)
end_variable
begin_variable
var83
-1
2
Atom visited(loc-x12-y7)
NegatedAtom visited(loc-x12-y7)
end_variable
begin_variable
var84
-1
2
Atom visited(loc-x12-y8)
NegatedAtom visited(loc-x12-y8)
end_variable
begin_variable
var85
-1
2
Atom visited(loc-x12-y9)
NegatedAtom visited(loc-x12-y9)
end_variable
begin_variable
var86
-1
2
Atom visited(loc-x13-y1)
NegatedAtom visited(loc-x13-y1)
end_variable
begin_variable
var87
-1
2
Atom visited(loc-x13-y10)
NegatedAtom visited(loc-x13-y10)
end_variable
begin_variable
var88
-1
2
Atom visited(loc-x13-y11)
NegatedAtom visited(loc-x13-y11)
end_variable
begin_variable
var89
-1
2
Atom visited(loc-x13-y12)
NegatedAtom visited(loc-x13-y12)
end_variable
begin_variable
var90
-1
2
Atom visited(loc-x13-y13)
NegatedAtom visited(loc-x13-y13)
end_variable
begin_variable
var91
-1
2
Atom visited(loc-x13-y14)
NegatedAtom visited(loc-x13-y14)
end_variable
begin_variable
var92
-1
2
Atom visited(loc-x13-y15)
NegatedAtom visited(loc-x13-y15)
end_variable
begin_variable
var93
-1
2
Atom visited(loc-x13-y16)
NegatedAtom visited(loc-x13-y16)
end_variable
begin_variable
var94
-1
2
Atom visited(loc-x13-y2)
NegatedAtom visited(loc-x13-y2)
end_variable
begin_variable
var95
-1
2
Atom visited(loc-x13-y3)
NegatedAtom visited(loc-x13-y3)
end_variable
begin_variable
var96
-1
2
Atom visited(loc-x13-y4)
NegatedAtom visited(loc-x13-y4)
end_variable
begin_variable
var97
-1
2
Atom visited(loc-x13-y5)
NegatedAtom visited(loc-x13-y5)
end_variable
begin_variable
var98
-1
2
Atom visited(loc-x13-y6)
NegatedAtom visited(loc-x13-y6)
end_variable
begin_variable
var99
-1
2
Atom visited(loc-x13-y7)
NegatedAtom visited(loc-x13-y7)
end_variable
begin_variable
var100
-1
2
Atom visited(loc-x13-y8)
NegatedAtom visited(loc-x13-y8)
end_variable
begin_variable
var101
-1
2
Atom visited(loc-x13-y9)
NegatedAtom visited(loc-x13-y9)
end_variable
begin_variable
var102
-1
2
Atom visited(loc-x14-y0)
NegatedAtom visited(loc-x14-y0)
end_variable
begin_variable
var103
-1
2
Atom visited(loc-x14-y1)
NegatedAtom visited(loc-x14-y1)
end_variable
begin_variable
var104
-1
2
Atom visited(loc-x14-y10)
NegatedAtom visited(loc-x14-y10)
end_variable
begin_variable
var105
-1
2
Atom visited(loc-x14-y11)
NegatedAtom visited(loc-x14-y11)
end_variable
begin_variable
var106
-1
2
Atom visited(loc-x14-y12)
NegatedAtom visited(loc-x14-y12)
end_variable
begin_variable
var107
-1
2
Atom visited(loc-x14-y13)
NegatedAtom visited(loc-x14-y13)
end_variable
begin_variable
var108
-1
2
Atom visited(loc-x14-y14)
NegatedAtom visited(loc-x14-y14)
end_variable
begin_variable
var109
-1
2
Atom visited(loc-x14-y15)
NegatedAtom visited(loc-x14-y15)
end_variable
begin_variable
var110
-1
2
Atom visited(loc-x14-y16)
NegatedAtom visited(loc-x14-y16)
end_variable
begin_variable
var111
-1
2
Atom visited(loc-x14-y2)
NegatedAtom visited(loc-x14-y2)
end_variable
begin_variable
var112
-1
2
Atom visited(loc-x14-y3)
NegatedAtom visited(loc-x14-y3)
end_variable
begin_variable
var113
-1
2
Atom visited(loc-x14-y4)
NegatedAtom visited(loc-x14-y4)
end_variable
begin_variable
var114
-1
2
Atom visited(loc-x14-y5)
NegatedAtom visited(loc-x14-y5)
end_variable
begin_variable
var115
-1
2
Atom visited(loc-x14-y6)
NegatedAtom visited(loc-x14-y6)
end_variable
begin_variable
var116
-1
2
Atom visited(loc-x14-y7)
NegatedAtom visited(loc-x14-y7)
end_variable
begin_variable
var117
-1
2
Atom visited(loc-x14-y8)
NegatedAtom visited(loc-x14-y8)
end_variable
begin_variable
var118
-1
2
Atom visited(loc-x14-y9)
NegatedAtom visited(loc-x14-y9)
end_variable
begin_variable
var119
-1
2
Atom visited(loc-x15-y0)
NegatedAtom visited(loc-x15-y0)
end_variable
begin_variable
var120
-1
2
Atom visited(loc-x15-y1)
NegatedAtom visited(loc-x15-y1)
end_variable
begin_variable
var121
-1
2
Atom visited(loc-x15-y10)
NegatedAtom visited(loc-x15-y10)
end_variable
begin_variable
var122
-1
2
Atom visited(loc-x15-y11)
NegatedAtom visited(loc-x15-y11)
end_variable
begin_variable
var123
-1
2
Atom visited(loc-x15-y12)
NegatedAtom visited(loc-x15-y12)
end_variable
begin_variable
var124
-1
2
Atom visited(loc-x15-y13)
NegatedAtom visited(loc-x15-y13)
end_variable
begin_variable
var125
-1
2
Atom visited(loc-x15-y14)
NegatedAtom visited(loc-x15-y14)
end_variable
begin_variable
var126
-1
2
Atom visited(loc-x15-y15)
NegatedAtom visited(loc-x15-y15)
end_variable
begin_variable
var127
-1
2
Atom visited(loc-x15-y16)
NegatedAtom visited(loc-x15-y16)
end_variable
begin_variable
var128
-1
2
Atom visited(loc-x15-y2)
NegatedAtom visited(loc-x15-y2)
end_variable
begin_variable
var129
-1
2
Atom visited(loc-x15-y3)
NegatedAtom visited(loc-x15-y3)
end_variable
begin_variable
var130
-1
2
Atom visited(loc-x15-y4)
NegatedAtom visited(loc-x15-y4)
end_variable
begin_variable
var131
-1
2
Atom visited(loc-x15-y5)
NegatedAtom visited(loc-x15-y5)
end_variable
begin_variable
var132
-1
2
Atom visited(loc-x15-y6)
NegatedAtom visited(loc-x15-y6)
end_variable
begin_variable
var133
-1
2
Atom visited(loc-x15-y7)
NegatedAtom visited(loc-x15-y7)
end_variable
begin_variable
var134
-1
2
Atom visited(loc-x15-y8)
NegatedAtom visited(loc-x15-y8)
end_variable
begin_variable
var135
-1
2
Atom visited(loc-x15-y9)
NegatedAtom visited(loc-x15-y9)
end_variable
begin_variable
var136
-1
2
Atom visited(loc-x16-y0)
NegatedAtom visited(loc-x16-y0)
end_variable
begin_variable
var137
-1
2
Atom visited(loc-x16-y1)
NegatedAtom visited(loc-x16-y1)
end_variable
begin_variable
var138
-1
2
Atom visited(loc-x16-y10)
NegatedAtom visited(loc-x16-y10)
end_variable
begin_variable
var139
-1
2
Atom visited(loc-x16-y11)
NegatedAtom visited(loc-x16-y11)
end_variable
begin_variable
var140
-1
2
Atom visited(loc-x16-y12)
NegatedAtom visited(loc-x16-y12)
end_variable
begin_variable
var141
-1
2
Atom visited(loc-x16-y13)
NegatedAtom visited(loc-x16-y13)
end_variable
begin_variable
var142
-1
2
Atom visited(loc-x16-y14)
NegatedAtom visited(loc-x16-y14)
end_variable
begin_variable
var143
-1
2
Atom visited(loc-x16-y15)
NegatedAtom visited(loc-x16-y15)
end_variable
begin_variable
var144
-1
2
Atom visited(loc-x16-y16)
NegatedAtom visited(loc-x16-y16)
end_variable
begin_variable
var145
-1
2
Atom visited(loc-x16-y2)
NegatedAtom visited(loc-x16-y2)
end_variable
begin_variable
var146
-1
2
Atom visited(loc-x16-y3)
NegatedAtom visited(loc-x16-y3)
end_variable
begin_variable
var147
-1
2
Atom visited(loc-x16-y4)
NegatedAtom visited(loc-x16-y4)
end_variable
begin_variable
var148
-1
2
Atom visited(loc-x16-y5)
NegatedAtom visited(loc-x16-y5)
end_variable
begin_variable
var149
-1
2
Atom visited(loc-x16-y6)
NegatedAtom visited(loc-x16-y6)
end_variable
begin_variable
var150
-1
2
Atom visited(loc-x16-y7)
NegatedAtom visited(loc-x16-y7)
end_variable
begin_variable
var151
-1
2
Atom visited(loc-x16-y8)
NegatedAtom visited(loc-x16-y8)
end_variable
begin_variable
var152
-1
2
Atom visited(loc-x16-y9)
NegatedAtom visited(loc-x16-y9)
end_variable
begin_variable
var153
-1
2
Atom visited(loc-x2-y0)
NegatedAtom visited(loc-x2-y0)
end_variable
begin_variable
var154
-1
2
Atom visited(loc-x2-y1)
NegatedAtom visited(loc-x2-y1)
end_variable
begin_variable
var155
-1
2
Atom visited(loc-x2-y10)
NegatedAtom visited(loc-x2-y10)
end_variable
begin_variable
var156
-1
2
Atom visited(loc-x2-y11)
NegatedAtom visited(loc-x2-y11)
end_variable
begin_variable
var157
-1
2
Atom visited(loc-x2-y12)
NegatedAtom visited(loc-x2-y12)
end_variable
begin_variable
var158
-1
2
Atom visited(loc-x2-y13)
NegatedAtom visited(loc-x2-y13)
end_variable
begin_variable
var159
-1
2
Atom visited(loc-x2-y14)
NegatedAtom visited(loc-x2-y14)
end_variable
begin_variable
var160
-1
2
Atom visited(loc-x2-y15)
NegatedAtom visited(loc-x2-y15)
end_variable
begin_variable
var161
-1
2
Atom visited(loc-x2-y16)
NegatedAtom visited(loc-x2-y16)
end_variable
begin_variable
var162
-1
2
Atom visited(loc-x2-y2)
NegatedAtom visited(loc-x2-y2)
end_variable
begin_variable
var163
-1
2
Atom visited(loc-x2-y3)
NegatedAtom visited(loc-x2-y3)
end_variable
begin_variable
var164
-1
2
Atom visited(loc-x2-y4)
NegatedAtom visited(loc-x2-y4)
end_variable
begin_variable
var165
-1
2
Atom visited(loc-x2-y5)
NegatedAtom visited(loc-x2-y5)
end_variable
begin_variable
var166
-1
2
Atom visited(loc-x2-y6)
NegatedAtom visited(loc-x2-y6)
end_variable
begin_variable
var167
-1
2
Atom visited(loc-x2-y7)
NegatedAtom visited(loc-x2-y7)
end_variable
begin_variable
var168
-1
2
Atom visited(loc-x2-y8)
NegatedAtom visited(loc-x2-y8)
end_variable
begin_variable
var169
-1
2
Atom visited(loc-x2-y9)
NegatedAtom visited(loc-x2-y9)
end_variable
begin_variable
var170
-1
2
Atom visited(loc-x3-y0)
NegatedAtom visited(loc-x3-y0)
end_variable
begin_variable
var171
-1
2
Atom visited(loc-x3-y1)
NegatedAtom visited(loc-x3-y1)
end_variable
begin_variable
var172
-1
2
Atom visited(loc-x3-y10)
NegatedAtom visited(loc-x3-y10)
end_variable
begin_variable
var173
-1
2
Atom visited(loc-x3-y11)
NegatedAtom visited(loc-x3-y11)
end_variable
begin_variable
var174
-1
2
Atom visited(loc-x3-y12)
NegatedAtom visited(loc-x3-y12)
end_variable
begin_variable
var175
-1
2
Atom visited(loc-x3-y13)
NegatedAtom visited(loc-x3-y13)
end_variable
begin_variable
var176
-1
2
Atom visited(loc-x3-y14)
NegatedAtom visited(loc-x3-y14)
end_variable
begin_variable
var177
-1
2
Atom visited(loc-x3-y15)
NegatedAtom visited(loc-x3-y15)
end_variable
begin_variable
var178
-1
2
Atom visited(loc-x3-y16)
NegatedAtom visited(loc-x3-y16)
end_variable
begin_variable
var179
-1
2
Atom visited(loc-x3-y2)
NegatedAtom visited(loc-x3-y2)
end_variable
begin_variable
var180
-1
2
Atom visited(loc-x3-y3)
NegatedAtom visited(loc-x3-y3)
end_variable
begin_variable
var181
-1
2
Atom visited(loc-x3-y4)
NegatedAtom visited(loc-x3-y4)
end_variable
begin_variable
var182
-1
2
Atom visited(loc-x3-y5)
NegatedAtom visited(loc-x3-y5)
end_variable
begin_variable
var183
-1
2
Atom visited(loc-x3-y6)
NegatedAtom visited(loc-x3-y6)
end_variable
begin_variable
var184
-1
2
Atom visited(loc-x3-y7)
NegatedAtom visited(loc-x3-y7)
end_variable
begin_variable
var185
-1
2
Atom visited(loc-x3-y8)
NegatedAtom visited(loc-x3-y8)
end_variable
begin_variable
var186
-1
2
Atom visited(loc-x3-y9)
NegatedAtom visited(loc-x3-y9)
end_variable
begin_variable
var187
-1
2
Atom visited(loc-x4-y0)
NegatedAtom visited(loc-x4-y0)
end_v




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




209 208
0 208 -1 0
1
end_operator
begin_operator
move loc-x5-y13 loc-x5-y14
0
2
0 0 209 210
0 210 -1 0
1
end_operator
begin_operator
move loc-x5-y13 loc-x6-y13
0
2
0 0 209 226
0 226 -1 0
1
end_operator
begin_operator
move loc-x5-y14 loc-x4-y14
0
2
0 0 210 193
0 193 -1 0
1
end_operator
begin_operator
move loc-x5-y14 loc-x5-y13
0
2
0 0 210 209
0 209 -1 0
1
end_operator
begin_operator
move loc-x5-y14 loc-x5-y15
0
2
0 0 210 211
0 211 -1 0
1
end_operator
begin_operator
move loc-x5-y14 loc-x6-y14
0
2
0 0 210 227
0 227 -1 0
1
end_operator
begin_operator
move loc-x5-y15 loc-x4-y15
0
2
0 0 211 194
0 194 -1 0
1
end_operator
begin_operator
move loc-x5-y15 loc-x5-y14
0
2
0 0 211 210
0 210 -1 0
1
end_operator
begin_operator
move loc-x5-y15 loc-x5-y16
0
2
0 0 211 212
0 212 -1 0
1
end_operator
begin_operator
move loc-x5-y15 loc-x6-y15
0
2
0 0 211 228
0 228 -1 0
1
end_operator
begin_operator
move loc-x5-y16 loc-x4-y16
0
2
0 0 212 195
0 195 -1 0
1
end_operator
begin_operator
move loc-x5-y16 loc-x5-y15
0
2
0 0 212 211
0 211 -1 0
1
end_operator
begin_operator
move loc-x5-y16 loc-x6-y16
0
2
0 0 212 229
0 229 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x4-y2
0
2
0 0 213 196
0 196 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x5-y1
0
2
0 0 213 205
0 205 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x5-y3
0
2
0 0 213 214
0 214 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x6-y2
0
2
0 0 213 230
0 230 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x4-y3
0
2
0 0 214 197
0 197 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x5-y2
0
2
0 0 214 213
0 213 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x5-y4
0
2
0 0 214 215
0 215 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x6-y3
0
2
0 0 214 231
0 231 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x4-y4
0
2
0 0 215 198
0 198 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x5-y3
0
2
0 0 215 214
0 214 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x5-y5
0
2
0 0 215 216
0 216 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x6-y4
0
2
0 0 215 232
0 232 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x4-y5
0
2
0 0 216 199
0 199 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x5-y4
0
2
0 0 216 215
0 215 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x5-y6
0
2
0 0 216 217
0 217 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x6-y5
0
2
0 0 216 233
0 233 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x4-y6
0
2
0 0 217 200
0 200 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x5-y5
0
2
0 0 217 216
0 216 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x5-y7
0
2
0 0 217 218
0 218 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x6-y6
0
2
0 0 217 234
0 234 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x4-y7
0
2
0 0 218 201
0 201 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y6
0
2
0 0 218 217
0 217 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y8
0
2
0 0 218 219
0 219 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x6-y7
0
2
0 0 218 235
0 235 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x4-y8
0
2
0 0 219 202
0 202 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y7
0
2
0 0 219 218
0 218 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y9
0
2
0 0 219 220
0 220 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x6-y8
0
2
0 0 219 236
0 236 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x4-y9
0
2
0 0 220 203
0 203 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y10
0
2
0 0 220 206
0 206 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y8
0
2
0 0 220 219
0 219 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x6-y9
0
2
0 0 220 237
0 237 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x5-y0
0
2
0 0 221 204
0 204 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x6-y1
0
2
0 0 221 222
0 222 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x7-y0
0
2
0 0 221 238
0 238 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x5-y1
0
2
0 0 222 205
0 205 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y0
0
2
0 0 222 221
0 221 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y2
0
2
0 0 222 230
0 230 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x7-y1
0
2
0 0 222 239
0 239 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x5-y10
0
2
0 0 223 206
0 206 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y11
0
2
0 0 223 224
0 224 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y9
0
2
0 0 223 237
0 237 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x7-y10
0
2
0 0 223 240
0 240 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x5-y11
0
2
0 0 224 207
0 207 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y10
0
2
0 0 224 223
0 223 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y12
0
2
0 0 224 225
0 225 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x7-y11
0
2
0 0 224 241
0 241 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x5-y12
0
2
0 0 225 208
0 208 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y11
0
2
0 0 225 224
0 224 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y13
0
2
0 0 225 226
0 226 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x7-y12
0
2
0 0 225 242
0 242 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x5-y13
0
2
0 0 226 209
0 209 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y12
0
2
0 0 226 225
0 225 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y14
0
2
0 0 226 227
0 227 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x7-y13
0
2
0 0 226 243
0 243 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x5-y14
0
2
0 0 227 210
0 210 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y13
0
2
0 0 227 226
0 226 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y15
0
2
0 0 227 228
0 228 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x7-y14
0
2
0 0 227 244
0 244 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x5-y15
0
2
0 0 228 211
0 211 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y14
0
2
0 0 228 227
0 227 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y16
0
2
0 0 228 229
0 229 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x7-y15
0
2
0 0 228 245
0 245 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x5-y16
0
2
0 0 229 212
0 212 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x6-y15
0
2
0 0 229 228
0 228 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x7-y16
0
2
0 0 229 246
0 246 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x5-y2
0
2
0 0 230 213
0 213 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y1
0
2
0 0 230 222
0 222 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y3
0
2
0 0 230 231
0 231 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x7-y2
0
2
0 0 230 247
0 247 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x5-y3
0
2
0 0 231 214
0 214 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y2
0
2
0 0 231 230
0 230 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y4
0
2
0 0 231 232
0 232 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x7-y3
0
2
0 0 231 248
0 248 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x5-y4
0
2
0 0 232 215
0 215 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y3
0
2
0 0 232 231
0 231 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y5
0
2
0 0 232 233
0 233 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x7-y4
0
2
0 0 232 249
0 249 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x5-y5
0
2
0 0 233 216
0 216 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y4
0
2
0 0 233 232
0 232 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y6
0
2
0 0 233 234
0 234 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x7-y5
0
2
0 0 233 250
0 250 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x5-y6
0
2
0 0 234 217
0 217 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y5
0
2
0 0 234 233
0 233 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y7
0
2
0 0 234 235
0 235 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x7-y6
0
2
0 0 234 251
0 251 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x5-y7
0
2
0 0 235 218
0 218 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y6
0
2
0 0 235 234
0 234 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y8
0
2
0 0 235 236
0 236 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x7-y7
0
2
0 0 235 252
0 252 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x5-y8
0
2
0 0 236 219
0 219 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y7
0
2
0 0 236 235
0 235 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y9
0
2
0 0 236 237
0 237 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x7-y8
0
2
0 0 236 253
0 253 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x5-y9
0
2
0 0 237 220
0 220 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y10
0
2
0 0 237 223
0 223 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y8
0
2
0 0 237 236
0 236 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x7-y9
0
2
0 0 237 254
0 254 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x6-y0
0
2
0 0 238 221
0 221 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x7-y1
0
2
0 0 238 239
0 239 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x8-y0
0
2
0 0 238 255
0 255 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x6-y1
0
2
0 0 239 222
0 222 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y0
0
2
0 0 239 238
0 238 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y2
0
2
0 0 239 247
0 247 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x8-y1
0
2
0 0 239 256
0 256 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x6-y10
0
2
0 0 240 223
0 223 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y11
0
2
0 0 240 241
0 241 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y9
0
2
0 0 240 254
0 254 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x8-y10
0
2
0 0 240 257
0 257 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 241 224
0 224 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 241 240
0 240 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 241 242
0 242 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 241 258
0 258 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 242 225
0 225 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 242 241
0 241 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y13
0
2
0 0 242 243
0 243 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 242 259
0 259 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x6-y13
0
2
0 0 243 226
0 226 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y12
0
2
0 0 243 242
0 242 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y14
0
2
0 0 243 244
0 244 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x8-y13
0
2
0 0 243 260
0 260 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 244 227
0 227 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 244 243
0 243 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y15
0
2
0 0 244 245
0 245 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 244 261
0 261 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x6-y15
0
2
0 0 245 228
0 228 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y14
0
2
0 0 245 244
0 244 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y16
0
2
0 0 245 246
0 246 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x8-y15
0
2
0 0 245 262
0 262 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x6-y16
0
2
0 0 246 229
0 229 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y15
0
2
0 0 246 245
0 245 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x8-y16
0
2
0 0 246 263
0 263 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 247 230
0 230 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 247 239
0 239 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 247 248
0 248 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 247 264
0 264 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 248 231
0 231 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 248 247
0 247 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 248 249
0 249 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 248 265
0 265 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 249 232
0 232 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 249 248
0 248 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 249 250
0 250 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 249 266
0 266 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 250 233
0 233 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 250 249
0 249 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 250 251
0 251 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 250 267
0 267 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 251 234
0 234 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 251 250
0 250 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 251 252
0 252 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 251 268
0 268 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 252 235
0 235 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 252 251
0 251 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 252 253
0 253 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 252 269
0 269 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 253 236
0 236 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 253 252
0 252 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 253 254
0 254 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 253 270
0 270 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 254 237
0 237 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 254 240
0 240 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 254 253
0 253 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 254 271
0 271 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 255 238
0 238 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 255 256
0 256 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 255 272
0 272 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 256 239
0 239 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 256 255
0 255 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 256 264
0 264 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 256 273
0 273 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 257 240
0 240 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 257 258
0 258 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 257 271
0 271 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 257 274
0 274 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 258 241
0 241 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 258 257
0 257 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 258 259
0 259 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 258 275
0 275 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 259 242
0 242 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 259 258
0 258 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 259 260
0 260 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 259 276
0 276 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 260 243
0 243 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 260 259
0 259 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 260 261
0 261 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 260 277
0 277 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 261 244
0 244 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 261 260
0 260 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 261 262
0 262 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 261 278
0 278 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 262 245
0 245 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y14
0
2
0 0 262 261
0 261 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y16
0
2
0 0 262 263
0 263 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 262 279
0 279 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 263 246
0 246 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y15
0
2
0 0 263 262
0 262 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 263 280
0 280 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 264 247
0 247 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 264 256
0 256 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 264 265
0 265 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 264 281
0 281 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 265 248
0 248 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 265 264
0 264 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 265 266
0 266 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 265 282
0 282 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 266 249
0 249 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 266 265
0 265 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 266 267
0 267 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 266 283
0 283 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 267 250
0 250 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 267 266
0 266 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 267 268
0 268 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 267 284
0 284 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 268 251
0 251 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 268 267
0 267 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 268 269
0 269 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 268 285
0 285 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 269 252
0 252 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 269 268
0 268 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 269 270
0 270 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 269 286
0 286 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 270 253
0 253 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 270 269
0 269 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 270 271
0 271 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 270 287
0 287 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 271 254
0 254 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 271 257
0 257 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 271 270
0 270 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 271 288
0 288 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 272 34
0 35 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 272 255
0 255 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 272 273
0 273 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 273 35
0 36 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 273 256
0 256 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 273 272
0 272 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 273 281
0 281 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 274 36
0 37 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 274 257
0 257 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 274 275
0 275 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 274 288
0 288 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 275 37
0 38 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 275 258
0 258 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 275 274
0 274 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 275 276
0 276 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 276 38
0 39 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 276 259
0 259 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 276 275
0 275 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 276 277
0 277 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 277 39
0 40 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 277 260
0 260 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 277 276
0 276 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 277 278
0 278 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 278 40
0 41 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 278 261
0 261 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 278 277
0 277 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y15
0
2
0 0 278 279
0 279 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 279 41
0 42 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x8-y15
0
2
0 0 279 262
0 262 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y14
0
2
0 0 279 278
0 278 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y16
0
2
0 0 279 280
0 280 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 280 42
0 43 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x8-y16
0
2
0 0 280 263
0 263 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y15
0
2
0 0 280 279
0 279 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 281 43
0 44 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 281 264
0 264 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 281 273
0 273 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 281 282
0 282 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 282 44
0 45 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 282 265
0 265 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 282 281
0 281 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 282 283
0 283 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 283 45
0 46 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 283 266
0 266 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 283 282
0 282 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 283 284
0 284 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 284 46
0 47 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 284 267
0 267 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 284 283
0 283 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 284 285
0 285 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 285 47
0 48 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 285 268
0 268 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 285 284
0 284 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 285 286
0 286 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 286 48
0 49 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 286 269
0 269 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 286 285
0 285 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 286 287
0 287 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 287 49
0 50 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 287 270
0 270 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 287 286
0 286 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 287 288
0 288 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 288 50
0 51 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 288 271
0 271 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 288 274
0 274 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 288 287
0 287 -1 0
1
end_operator
0
