begin_version
3
end_version
begin_metric
0
end_metric
225
begin_variable
var0
-1
225
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var3
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var4
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var5
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var6
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var7
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var8
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var9
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var10
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var11
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var12
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var13
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var14
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var15
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var16
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var17
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var18
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var19
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var20
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var21
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var22
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var23
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var24
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var25
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var26
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var27
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var28
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var29
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var30
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var31
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var32
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var33
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var34
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var35
-1
2
Atom visited(loc-x10-y13)
NegatedAtom visited(loc-x10-y13)
end_variable
begin_variable
var36
-1
2
Atom visited(loc-x10-y14)
NegatedAtom visited(loc-x10-y14)
end_variable
begin_variable
var37
-1
2
Atom visited(loc-x10-y2)
NegatedAtom visited(loc-x10-y2)
end_variable
begin_variable
var38
-1
2
Atom visited(loc-x10-y3)
NegatedAtom visited(loc-x10-y3)
end_variable
begin_variable
var39
-1
2
Atom visited(loc-x10-y4)
NegatedAtom visited(loc-x10-y4)
end_variable
begin_variable
var40
-1
2
Atom visited(loc-x10-y5)
NegatedAtom visited(loc-x10-y5)
end_variable
begin_variable
var41
-1
2
Atom visited(loc-x10-y6)
NegatedAtom visited(loc-x10-y6)
end_variable
begin_variable
var42
-1
2
Atom visited(loc-x10-y7)
NegatedAtom visited(loc-x10-y7)
end_variable
begin_variable
var43
-1
2
Atom visited(loc-x10-y8)
NegatedAtom visited(loc-x10-y8)
end_variable
begin_variable
var44
-1
2
Atom visited(loc-x10-y9)
NegatedAtom visited(loc-x10-y9)
end_variable
begin_variable
var45
-1
2
Atom visited(loc-x11-y0)
NegatedAtom visited(loc-x11-y0)
end_variable
begin_variable
var46
-1
2
Atom visited(loc-x11-y1)
NegatedAtom visited(loc-x11-y1)
end_variable
begin_variable
var47
-1
2
Atom visited(loc-x11-y10)
NegatedAtom visited(loc-x11-y10)
end_variable
begin_variable
var48
-1
2
Atom visited(loc-x11-y11)
NegatedAtom visited(loc-x11-y11)
end_variable
begin_variable
var49
-1
2
Atom visited(loc-x11-y12)
NegatedAtom visited(loc-x11-y12)
end_variable
begin_variable
var50
-1
2
Atom visited(loc-x11-y13)
NegatedAtom visited(loc-x11-y13)
end_variable
begin_variable
var51
-1
2
Atom visited(loc-x11-y14)
NegatedAtom visited(loc-x11-y14)
end_variable
begin_variable
var52
-1
2
Atom visited(loc-x11-y2)
NegatedAtom visited(loc-x11-y2)
end_variable
begin_variable
var53
-1
2
Atom visited(loc-x11-y3)
NegatedAtom visited(loc-x11-y3)
end_variable
begin_variable
var54
-1
2
Atom visited(loc-x11-y4)
NegatedAtom visited(loc-x11-y4)
end_variable
begin_variable
var55
-1
2
Atom visited(loc-x11-y5)
NegatedAtom visited(loc-x11-y5)
end_variable
begin_variable
var56
-1
2
Atom visited(loc-x11-y6)
NegatedAtom visited(loc-x11-y6)
end_variable
begin_variable
var57
-1
2
Atom visited(loc-x11-y7)
NegatedAtom visited(loc-x11-y7)
end_variable
begin_variable
var58
-1
2
Atom visited(loc-x11-y8)
NegatedAtom visited(loc-x11-y8)
end_variable
begin_variable
var59
-1
2
Atom visited(loc-x11-y9)
NegatedAtom visited(loc-x11-y9)
end_variable
begin_variable
var60
-1
2
Atom visited(loc-x12-y0)
NegatedAtom visited(loc-x12-y0)
end_variable
begin_variable
var61
-1
2
Atom visited(loc-x12-y1)
NegatedAtom visited(loc-x12-y1)
end_variable
begin_variable
var62
-1
2
Atom visited(loc-x12-y10)
NegatedAtom visited(loc-x12-y10)
end_variable
begin_variable
var63
-1
2
Atom visited(loc-x12-y11)
NegatedAtom visited(loc-x12-y11)
end_variable
begin_variable
var64
-1
2
Atom visited(loc-x12-y12)
NegatedAtom visited(loc-x12-y12)
end_variable
begin_variable
var65
-1
2
Atom visited(loc-x12-y13)
NegatedAtom visited(loc-x12-y13)
end_variable
begin_variable
var66
-1
2
Atom visited(loc-x12-y14)
NegatedAtom visited(loc-x12-y14)
end_variable
begin_variable
var67
-1
2
Atom visited(loc-x12-y2)
NegatedAtom visited(loc-x12-y2)
end_variable
begin_variable
var68
-1
2
Atom visited(loc-x12-y3)
NegatedAtom visited(loc-x12-y3)
end_variable
begin_variable
var69
-1
2
Atom visited(loc-x12-y4)
NegatedAtom visited(loc-x12-y4)
end_variable
begin_variable
var70
-1
2
Atom visited(loc-x12-y5)
NegatedAtom visited(loc-x12-y5)
end_variable
begin_variable
var71
-1
2
Atom visited(loc-x12-y6)
NegatedAtom visited(loc-x12-y6)
end_variable
begin_variable
var72
-1
2
Atom visited(loc-x12-y7)
NegatedAtom visited(loc-x12-y7)
end_variable
begin_variable
var73
-1
2
Atom visited(loc-x12-y8)
NegatedAtom visited(loc-x12-y8)
end_variable
begin_variable
var74
-1
2
Atom visited(loc-x12-y9)
NegatedAtom visited(loc-x12-y9)
end_variable
begin_variable
var75
-1
2
Atom visited(loc-x13-y0)
NegatedAtom visited(loc-x13-y0)
end_variable
begin_variable
var76
-1
2
Atom visited(loc-x13-y1)
NegatedAtom visited(loc-x13-y1)
end_variable
begin_variable
var77
-1
2
Atom visited(loc-x13-y10)
NegatedAtom visited(loc-x13-y10)
end_variable
begin_variable
var78
-1
2
Atom visited(loc-x13-y11)
NegatedAtom visited(loc-x13-y11)
end_variable
begin_variable
var79
-1
2
Atom visited(loc-x13-y12)
NegatedAtom visited(loc-x13-y12)
end_variable
begin_variable
var80
-1
2
Atom visited(loc-x13-y13)
NegatedAtom visited(loc-x13-y13)
end_variable
begin_variable
var81
-1
2
Atom visited(loc-x13-y14)
NegatedAtom visited(loc-x13-y14)
end_variable
begin_variable
var82
-1
2
Atom visited(loc-x13-y2)
NegatedAtom visited(loc-x13-y2)
end_variable
begin_variable
var83
-1
2
Atom visited(loc-x13-y3)
NegatedAtom visited(loc-x13-y3)
end_variable
begin_variable
var84
-1
2
Atom visited(loc-x13-y4)
NegatedAtom visited(loc-x13-y4)
end_variable
begin_variable
var85
-1
2
Atom visited(loc-x13-y5)
NegatedAtom visited(loc-x13-y5)
end_variable
begin_variable
var86
-1
2
Atom visited(loc-x13-y6)
NegatedAtom visited(loc-x13-y6)
end_variable
begin_variable
var87
-1
2
Atom visited(loc-x13-y7)
NegatedAtom visited(loc-x13-y7)
end_variable
begin_variable
var88
-1
2
Atom visited(loc-x13-y8)
NegatedAtom visited(loc-x13-y8)
end_variable
begin_variable
var89
-1
2
Atom visited(loc-x13-y9)
NegatedAtom visited(loc-x13-y9)
end_variable
begin_variable
var90
-1
2
Atom visited(loc-x14-y0)
NegatedAtom visited(loc-x14-y0)
end_variable
begin_variable
var91
-1
2
Atom visited(loc-x14-y1)
NegatedAtom visited(loc-x14-y1)
end_variable
begin_variable
var92
-1
2
Atom visited(loc-x14-y10)
NegatedAtom visited(loc-x14-y10)
end_variable
begin_variable
var93
-1
2
Atom visited(loc-x14-y11)
NegatedAtom visited(loc-x14-y11)
end_variable
begin_variable
var94
-1
2
Atom visited(loc-x14-y12)
NegatedAtom visited(loc-x14-y12)
end_variable
begin_variable
var95
-1
2
Atom visited(loc-x14-y13)
NegatedAtom visited(loc-x14-y13)
end_variable
begin_variable
var96
-1
2
Atom visited(loc-x14-y14)
NegatedAtom visited(loc-x14-y14)
end_variable
begin_variable
var97
-1
2
Atom visited(loc-x14-y2)
NegatedAtom visited(loc-x14-y2)
end_variable
begin_variable
var98
-1
2
Atom visited(loc-x14-y3)
NegatedAtom visited(loc-x14-y3)
end_variable
begin_variable
var99
-1
2
Atom visited(loc-x14-y4)
NegatedAtom visited(loc-x14-y4)
end_variable
begin_variable
var100
-1
2
Atom visited(loc-x14-y5)
NegatedAtom visited(loc-x14-y5)
end_variable
begin_variable
var101
-1
2
Atom visited(loc-x14-y6)
NegatedAtom visited(loc-x14-y6)
end_variable
begin_variable
var102
-1
2
Atom visited(loc-x14-y7)
NegatedAtom visited(loc-x14-y7)
end_variable
begin_variable
var103
-1
2
Atom visited(loc-x14-y8)
NegatedAtom visited(loc-x14-y8)
end_variable
begin_variable
var104
-1
2
Atom visited(loc-x14-y9)
NegatedAtom visited(loc-x14-y9)
end_variable
begin_variable
var105
-1
2
Atom visited(loc-x2-y0)
NegatedAtom visited(loc-x2-y0)
end_variable
begin_variable
var106
-1
2
Atom visited(loc-x2-y1)
NegatedAtom visited(loc-x2-y1)
end_variable
begin_variable
var107
-1
2
Atom visited(loc-x2-y10)
NegatedAtom visited(loc-x2-y10)
end_variable
begin_variable
var108
-1
2
Atom visited(loc-x2-y11)
NegatedAtom visited(loc-x2-y11)
end_variable
begin_variable
var109
-1
2
Atom visited(loc-x2-y12)
NegatedAtom visited(loc-x2-y12)
end_variable
begin_variable
var110
-1
2
Atom visited(loc-x2-y13)
NegatedAtom visited(loc-x2-y13)
end_variable
begin_variable
var111
-1
2
Atom visited(loc-x2-y14)
NegatedAtom visited(loc-x2-y14)
end_variable
begin_variable
var112
-1
2
Atom visited(loc-x2-y2)
NegatedAtom visited(loc-x2-y2)
end_variable
begin_variable
var113
-1
2
Atom visited(loc-x2-y3)
NegatedAtom visited(loc-x2-y3)
end_variable
begin_variable
var114
-1
2
Atom visited(loc-x2-y4)
NegatedAtom visited(loc-x2-y4)
end_variable
begin_variable
var115
-1
2
Atom visited(loc-x2-y5)
NegatedAtom visited(loc-x2-y5)
end_variable
begin_variable
var116
-1
2
Atom visited(loc-x2-y6)
NegatedAtom visited(loc-x2-y6)
end_variable
begin_variable
var117
-1
2
Atom visited(loc-x2-y7)
NegatedAtom visited(loc-x2-y7)
end_variable
begin_variable
var118
-1
2
Atom visited(loc-x2-y8)
NegatedAtom visited(loc-x2-y8)
end_variable
begin_variable
var119
-1
2
Atom visited(loc-x2-y9)
NegatedAtom visited(loc-x2-y9)
end_variable
begin_variable
var120
-1
2
Atom visited(loc-x3-y0)
NegatedAtom visited(loc-x3-y0)
end_variable
begin_variable
var121
-1
2
Atom visited(loc-x3-y1)
NegatedAtom visited(loc-x3-y1)
end_variable
begin_variable
var122
-1
2
Atom visited(loc-x3-y10)
NegatedAtom visited(loc-x3-y10)
end_variable
begin_variable
var123
-1
2
Atom visited(loc-x3-y11)
NegatedAtom visited(loc-x3-y11)
end_variable
begin_variable
var124
-1
2
Atom visited(loc-x3-y12)
NegatedAtom visited(loc-x3-y12)
end_variable
begin_variable
var125
-1
2
Atom visited(loc-x3-y13)
NegatedAtom visited(loc-x3-y13)
end_variable
begin_variable
var126
-1
2
Atom visited(loc-x3-y14)
NegatedAtom visited(loc-x3-y14)
end_variable
begin_variable
var127
-1
2
Atom visited(loc-x3-y2)
NegatedAtom visited(loc-x3-y2)
end_variable
begin_variable
var128
-1
2
Atom visited(loc-x3-y3)
NegatedAtom visited(loc-x3-y3)
end_variable
begin_variable
var129
-1
2
Atom visited(loc-x3-y4)
NegatedAtom visited(loc-x3-y4)
end_variable
begin_variable
var130
-1
2
Atom visited(loc-x3-y5)
NegatedAtom visited(loc-x3-y5)
end_variable
begin_variable
var131
-1
2
Atom visited(loc-x3-y6)
NegatedAtom visited(loc-x3-y6)
end_variable
begin_variable
var132
-1
2
Atom visited(loc-x3-y7)
NegatedAtom visited(loc-x3-y7)
end_variable
begin_variable
var133
-1
2
Atom visited(loc-x3-y8)
NegatedAtom visited(loc-x3-y8)
end_variable
begin_variable
var134
-1
2
Atom visited(loc-x3-y9)
NegatedAtom visited(loc-x3-y9)
end_variable
begin_variable
var135
-1
2
Atom visited(loc-x4-y0)
NegatedAtom visited(loc-x4-y0)
end_variable
begin_variable
var136
-1
2
Atom visited(loc-x4-y1)
NegatedAtom visited(loc-x4-y1)
end_variable
begin_variable
var137
-1
2
Atom visited(loc-x4-y10)
NegatedAtom visited(loc-x4-y10)
end_variable
begin_variable
var138
-1
2
Atom visited(loc-x4-y11)
NegatedAtom visited(loc-x4-y11)
end_variable
begin_variable
var139
-1
2
Atom visited(loc-x4-y12)
NegatedAtom visited(loc-x4-y12)
end_variable
begin_variable
var140
-1
2
Atom visited(loc-x4-y13)
NegatedAtom visited(loc-x4-y13)
end_variable
begin_variable
var141
-1
2
Atom visited(loc-x4-y14)
NegatedAtom visited(loc-x4-y14)
end_variable
begin_variable
var142
-1
2
Atom visited(loc-x4-y2)
NegatedAtom visited(loc-x4-y2)
end_variable
begin_variable
var143
-1
2
Atom visited(loc-x4-y3)
NegatedAtom visited(loc-x4-y3)
end_variable
begin_variable
var144
-1
2
Atom visited(loc-x4-y4)
NegatedAtom visited(loc-x4-y4)
end_variable
begin_variable
var145
-1
2
Atom visited(loc-x4-y5)
NegatedAtom visited(loc-x4-y5)
end_variable
begin_variable
var146
-1
2
Atom visited(loc-x4-y6)
NegatedAtom visited(loc-x4-y6)
end_variable
begin_variable
var147
-1
2
Atom visited(loc-x4-y7)
NegatedAtom visited(loc-x4-y7)
end_variable
begin_variable
var148
-1
2
Atom visited(loc-x4-y8)
NegatedAtom visited(loc-x4-y8)
end_variable
begin_variable
var149
-1
2
Atom visited(loc-x4-y9)
NegatedAtom visited(loc-x4-y9)
end_variable
begin_variable
var150
-1
2
Atom visited(loc-x5-y0)
NegatedAtom visited(loc-x5-y0)
end_variable
begin_variable
var151
-1
2
Atom visited(loc-x5-y1)
NegatedAtom visited(loc-x5-y1)
end_variable
begin_variable
var152
-1
2
Atom visited(loc-x5-y10)
NegatedAtom visited(loc-x5-y10)
end_variable
begin_variable
var153
-1
2
Atom visited(loc-x5-y11)
NegatedAtom visited(loc-x5-y11)
end_variable
begin_variable
var154
-1
2
Atom visited(loc-x5-y12)
NegatedAtom visited(loc-x5-y12)
end_variable
begin_variable
var155
-1
2
Atom visited(loc-x5-y13)
NegatedAtom visited(loc-x5-y13)
end_variable
begin_variable
var156
-1
2
Atom visited(loc-x5-y14)
NegatedAtom visited(loc-x5-y14)
end_variable
begin_variable
var157
-1
2
Atom visited(loc-x5-y2)
NegatedAtom visited(loc-x5-y2)
end_variable
begin_variable
var158
-1
2
Atom visited(loc-x5-y3)
NegatedAtom visited(loc-x5-y3)
end_variable
begin_variable
var159
-1
2
Atom visited(loc-x5-y4)
NegatedAtom visited(loc-x5-y4)
end_variable
begin_variable
var160
-1
2
Atom visited(loc-x5-y5)
NegatedAtom visited(loc-x5-y5)
end_variable
begin_variable
var161
-1
2
Atom visited(loc-x5-y6)
NegatedAtom visited(loc-x5-y6)
end_variable
begin_variable
var162
-1
2
Atom visited(loc-x5-y7)
NegatedAtom visited(loc-x5-y7)
end_variable
begin_variable
var163
-1
2
Atom visited(loc-x5-y8)
NegatedAtom visited(loc-x5-y8)
end_variable
begin_variable
var164
-1
2
Atom visited(loc-x5-y9)
NegatedAtom visited(loc-x5-y9)
end_variable
begin_variable
var165
-1
2
Atom visited(loc-x6-y0)
NegatedAtom visited(loc-x6-y0)
end_variable
begin_variable
var166
-1
2
Atom visited(loc-x6-y1)
NegatedAtom visited(loc-x6-y1)
end_variable
begin_variable
var167
-1
2
Atom visited(loc-x6-y10)
NegatedAtom visited(loc-x6-y10)
end_variable
begin_variable
var168
-1
2
Atom visited(loc-x6-y11)
NegatedAtom visited(loc-x6-y11)
end_variable
begin_variable
var169
-1
2
Atom visited(loc-x6-y12)
NegatedAtom visited(loc-x6-y12)
end_variable
begin_variable
var170
-1
2
Atom visited(loc-x6-y13)
NegatedAtom visited(loc-x6-y13)
end_variable
begin_variable
var171
-1
2
Atom visited(loc-x6-y14)
NegatedAtom visited(loc-x6-y14)
end_variable
begin_variable
var172
-1
2
Atom visited(loc-x6-y2)
NegatedAtom visited(loc-x6-y2)
end_variable
begin_variable
var173
-1
2
Atom visited(loc-x6-y3)
NegatedAtom visited(loc-x6-y3)
end_variable
begin_variable
var174
-1
2
Atom visited(loc-x6-y4)
NegatedAtom visited(loc-x6-y4)
end_variable
begin_variable
var175
-1
2
Atom visited(loc-x6-y5)
NegatedAtom visited(loc-x6-y5)
end_variable
begin_variable
var176
-1
2
Atom visited(loc-x6-y6)
NegatedAtom visited(loc-x6-y6)
end_variable
begin_variable
var177
-1
2
Atom visited(loc-x6-y7)
NegatedAtom visited(loc-x6-y7)
end_variable
begin_variable
var178
-1
2
Atom visited(loc-x6-y8)
NegatedAtom visited(loc-x6-y8)
end_variable
begin_variable
var179
-1
2
Atom visited(loc-x6-y9)
NegatedAtom visited(loc-x6-y9)
end_variable
begin_variable
var180
-1
2
Atom visited(loc-x7-y0)
NegatedAtom visited(loc-x7-y0)
end_variable
begin_variable
var181
-1
2
Atom visited(loc-x7-y1)
NegatedAtom visited(loc-x7-y1)
end_variable
begin_variable
var182
-1
2
Atom visited(loc-x7-y10)
NegatedAtom visited(loc-x7-y10)
end_variable
begin_variable
var183
-1
2
Atom visited(loc-x7-y11)
NegatedAtom visited(loc-x7-y11)
end_variable
begin_variable
var184
-1
2
Atom visited(loc-x7-y12)
NegatedAtom visited(loc-x7-y12)
end_variable
begin_variable
var185
-1
2
Atom visited(loc-x7-y13)
NegatedAtom visited(loc-x7-y13)
end_variable
begin_variable
var186
-1
2
Atom visited(loc-x7-y14)
NegatedAtom visited(loc-x7-y14)
end_variable
begin_variable
var187
-1
2
Atom visited(loc-x7-y2)
NegatedAtom visited(loc-x7-y2)
end_variable
begin_variable
var188
-1
2
Atom visited(loc-x7-y3)
NegatedAtom visited(loc-x7-y3)
end_variable
begin_variable
var189
-1
2
Atom visited(loc-x7-y4)
NegatedAtom visited(loc-x7-y4)
end_variable
begin_variable
var190
-1
2
Atom visited(loc-x7-y5)
NegatedAtom visited(loc-x7-y5)
end_variable
begin_variable
var191
-1
2
Atom visited(loc-x7-y6)
NegatedAtom visited(loc-x7-y6)
end_variable
begin_variable
var192
-1
2
Atom visited(loc-x7-y7)
NegatedAtom visited(loc-x7-y7)
end_variable
begin_variable
var193
-1
2
Atom visited(loc-x7-y8)
NegatedAtom visited(loc-x7-y8)
end_variable
begin_variable
var194
-1
2
Atom visited(loc-x7-y9)
NegatedAtom visited(loc-x7-y9)
end_variable
begin_variable
var195
-1
2
Atom visited(loc-x8-y0)
NegatedAtom visited(loc-x8-y0)
end_variable
begin_variable
var196
-1
2
Atom visited(loc-x8-y1)
NegatedAtom visited(loc-x8-y1)
end_variable
begin_variable
var197
-1
2
Atom visited(loc-x8-y10)
NegatedAtom visited(loc-x8-y10)
end_variable
begin_variable
var198
-1
2
Atom visited(loc-x8-y11)
NegatedAtom visited(loc-x8-y11)
end_variable
begin_variable
var199
-1
2
Atom visited(loc-x8-y12)
NegatedAtom visited(loc-x8-y12)
end_variable
begin_variable
var200
-1
2
Atom visited(loc-x8-y13)
NegatedAtom visited(loc-x8-y13)
end_variable
begin_variable
var201
-1
2
Atom visited(loc-x8-y14)
NegatedAtom visited(loc-x8-y14)
end_variable
begin_variable
var202
-1
2
Atom visited(loc-x8-y2)
NegatedAtom visited(loc-x8-y2)
end_variable
begin_variable
var203
-1
2
Atom visited(loc-x8-y3)
NegatedAtom visited(loc-x8-y3)
end_variable
begin_variable
var204
-1
2
Atom visited(loc-x8-y4)
NegatedAtom visited(loc-x8-y4)
end_variable
begin_variable
var205
-1
2
Atom visited(loc-x8-y5)
NegatedAtom visited(loc-x8-y5)
end_variable
begin_variable
var206
-1
2
Atom visited(loc-x8-y6)
NegatedAtom visited(l




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




r
begin_operator
move loc-x4-y5 loc-x3-y5
0
2
0 0 145 130
0 130 -1 0
1
end_operator
begin_operator
move loc-x4-y5 loc-x4-y4
0
2
0 0 145 144
0 144 -1 0
1
end_operator
begin_operator
move loc-x4-y5 loc-x4-y6
0
2
0 0 145 146
0 146 -1 0
1
end_operator
begin_operator
move loc-x4-y5 loc-x5-y5
0
2
0 0 145 160
0 160 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x3-y6
0
2
0 0 146 131
0 131 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x4-y5
0
2
0 0 146 145
0 145 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x4-y7
0
2
0 0 146 147
0 147 -1 0
1
end_operator
begin_operator
move loc-x4-y6 loc-x5-y6
0
2
0 0 146 161
0 161 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x3-y7
0
2
0 0 147 132
0 132 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x4-y6
0
2
0 0 147 146
0 146 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x4-y8
0
2
0 0 147 148
0 148 -1 0
1
end_operator
begin_operator
move loc-x4-y7 loc-x5-y7
0
2
0 0 147 162
0 162 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x3-y8
0
2
0 0 148 133
0 133 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x4-y7
0
2
0 0 148 147
0 147 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x4-y9
0
2
0 0 148 149
0 149 -1 0
1
end_operator
begin_operator
move loc-x4-y8 loc-x5-y8
0
2
0 0 148 163
0 163 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x3-y9
0
2
0 0 149 134
0 134 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x4-y10
0
2
0 0 149 137
0 137 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x4-y8
0
2
0 0 149 148
0 148 -1 0
1
end_operator
begin_operator
move loc-x4-y9 loc-x5-y9
0
2
0 0 149 164
0 164 -1 0
1
end_operator
begin_operator
move loc-x5-y0 loc-x4-y0
0
2
0 0 150 135
0 135 -1 0
1
end_operator
begin_operator
move loc-x5-y0 loc-x5-y1
0
2
0 0 150 151
0 151 -1 0
1
end_operator
begin_operator
move loc-x5-y0 loc-x6-y0
0
2
0 0 150 165
0 165 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x4-y1
0
2
0 0 151 136
0 136 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x5-y0
0
2
0 0 151 150
0 150 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x5-y2
0
2
0 0 151 157
0 157 -1 0
1
end_operator
begin_operator
move loc-x5-y1 loc-x6-y1
0
2
0 0 151 166
0 166 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x4-y10
0
2
0 0 152 137
0 137 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x5-y11
0
2
0 0 152 153
0 153 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x5-y9
0
2
0 0 152 164
0 164 -1 0
1
end_operator
begin_operator
move loc-x5-y10 loc-x6-y10
0
2
0 0 152 167
0 167 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x4-y11
0
2
0 0 153 138
0 138 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x5-y10
0
2
0 0 153 152
0 152 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x5-y12
0
2
0 0 153 154
0 154 -1 0
1
end_operator
begin_operator
move loc-x5-y11 loc-x6-y11
0
2
0 0 153 168
0 168 -1 0
1
end_operator
begin_operator
move loc-x5-y12 loc-x4-y12
0
2
0 0 154 139
0 139 -1 0
1
end_operator
begin_operator
move loc-x5-y12 loc-x5-y11
0
2
0 0 154 153
0 153 -1 0
1
end_operator
begin_operator
move loc-x5-y12 loc-x5-y13
0
2
0 0 154 155
0 155 -1 0
1
end_operator
begin_operator
move loc-x5-y12 loc-x6-y12
0
2
0 0 154 169
0 169 -1 0
1
end_operator
begin_operator
move loc-x5-y13 loc-x4-y13
0
2
0 0 155 140
0 140 -1 0
1
end_operator
begin_operator
move loc-x5-y13 loc-x5-y12
0
2
0 0 155 154
0 154 -1 0
1
end_operator
begin_operator
move loc-x5-y13 loc-x5-y14
0
2
0 0 155 156
0 156 -1 0
1
end_operator
begin_operator
move loc-x5-y13 loc-x6-y13
0
2
0 0 155 170
0 170 -1 0
1
end_operator
begin_operator
move loc-x5-y14 loc-x4-y14
0
2
0 0 156 141
0 141 -1 0
1
end_operator
begin_operator
move loc-x5-y14 loc-x5-y13
0
2
0 0 156 155
0 155 -1 0
1
end_operator
begin_operator
move loc-x5-y14 loc-x6-y14
0
2
0 0 156 171
0 171 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x4-y2
0
2
0 0 157 142
0 142 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x5-y1
0
2
0 0 157 151
0 151 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x5-y3
0
2
0 0 157 158
0 158 -1 0
1
end_operator
begin_operator
move loc-x5-y2 loc-x6-y2
0
2
0 0 157 172
0 172 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x4-y3
0
2
0 0 158 143
0 143 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x5-y2
0
2
0 0 158 157
0 157 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x5-y4
0
2
0 0 158 159
0 159 -1 0
1
end_operator
begin_operator
move loc-x5-y3 loc-x6-y3
0
2
0 0 158 173
0 173 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x4-y4
0
2
0 0 159 144
0 144 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x5-y3
0
2
0 0 159 158
0 158 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x5-y5
0
2
0 0 159 160
0 160 -1 0
1
end_operator
begin_operator
move loc-x5-y4 loc-x6-y4
0
2
0 0 159 174
0 174 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x4-y5
0
2
0 0 160 145
0 145 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x5-y4
0
2
0 0 160 159
0 159 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x5-y6
0
2
0 0 160 161
0 161 -1 0
1
end_operator
begin_operator
move loc-x5-y5 loc-x6-y5
0
2
0 0 160 175
0 175 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x4-y6
0
2
0 0 161 146
0 146 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x5-y5
0
2
0 0 161 160
0 160 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x5-y7
0
2
0 0 161 162
0 162 -1 0
1
end_operator
begin_operator
move loc-x5-y6 loc-x6-y6
0
2
0 0 161 176
0 176 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x4-y7
0
2
0 0 162 147
0 147 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y6
0
2
0 0 162 161
0 161 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x5-y8
0
2
0 0 162 163
0 163 -1 0
1
end_operator
begin_operator
move loc-x5-y7 loc-x6-y7
0
2
0 0 162 177
0 177 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x4-y8
0
2
0 0 163 148
0 148 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y7
0
2
0 0 163 162
0 162 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x5-y9
0
2
0 0 163 164
0 164 -1 0
1
end_operator
begin_operator
move loc-x5-y8 loc-x6-y8
0
2
0 0 163 178
0 178 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x4-y9
0
2
0 0 164 149
0 149 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y10
0
2
0 0 164 152
0 152 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x5-y8
0
2
0 0 164 163
0 163 -1 0
1
end_operator
begin_operator
move loc-x5-y9 loc-x6-y9
0
2
0 0 164 179
0 179 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x5-y0
0
2
0 0 165 150
0 150 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x6-y1
0
2
0 0 165 166
0 166 -1 0
1
end_operator
begin_operator
move loc-x6-y0 loc-x7-y0
0
2
0 0 165 180
0 180 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x5-y1
0
2
0 0 166 151
0 151 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y0
0
2
0 0 166 165
0 165 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y2
0
2
0 0 166 172
0 172 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x7-y1
0
2
0 0 166 181
0 181 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x5-y10
0
2
0 0 167 152
0 152 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y11
0
2
0 0 167 168
0 168 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y9
0
2
0 0 167 179
0 179 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x7-y10
0
2
0 0 167 182
0 182 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x5-y11
0
2
0 0 168 153
0 153 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y10
0
2
0 0 168 167
0 167 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y12
0
2
0 0 168 169
0 169 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x7-y11
0
2
0 0 168 183
0 183 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x5-y12
0
2
0 0 169 154
0 154 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y11
0
2
0 0 169 168
0 168 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y13
0
2
0 0 169 170
0 170 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x7-y12
0
2
0 0 169 184
0 184 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x5-y13
0
2
0 0 170 155
0 155 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y12
0
2
0 0 170 169
0 169 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y14
0
2
0 0 170 171
0 171 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x7-y13
0
2
0 0 170 185
0 185 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x5-y14
0
2
0 0 171 156
0 156 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y13
0
2
0 0 171 170
0 170 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x7-y14
0
2
0 0 171 186
0 186 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x5-y2
0
2
0 0 172 157
0 157 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y1
0
2
0 0 172 166
0 166 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y3
0
2
0 0 172 173
0 173 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x7-y2
0
2
0 0 172 187
0 187 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x5-y3
0
2
0 0 173 158
0 158 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y2
0
2
0 0 173 172
0 172 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y4
0
2
0 0 173 174
0 174 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x7-y3
0
2
0 0 173 188
0 188 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x5-y4
0
2
0 0 174 159
0 159 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y3
0
2
0 0 174 173
0 173 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y5
0
2
0 0 174 175
0 175 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x7-y4
0
2
0 0 174 189
0 189 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x5-y5
0
2
0 0 175 160
0 160 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y4
0
2
0 0 175 174
0 174 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y6
0
2
0 0 175 176
0 176 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x7-y5
0
2
0 0 175 190
0 190 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x5-y6
0
2
0 0 176 161
0 161 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y5
0
2
0 0 176 175
0 175 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y7
0
2
0 0 176 177
0 177 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x7-y6
0
2
0 0 176 191
0 191 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x5-y7
0
2
0 0 177 162
0 162 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y6
0
2
0 0 177 176
0 176 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y8
0
2
0 0 177 178
0 178 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x7-y7
0
2
0 0 177 192
0 192 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x5-y8
0
2
0 0 178 163
0 163 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y7
0
2
0 0 178 177
0 177 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y9
0
2
0 0 178 179
0 179 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x7-y8
0
2
0 0 178 193
0 193 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x5-y9
0
2
0 0 179 164
0 164 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y10
0
2
0 0 179 167
0 167 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y8
0
2
0 0 179 178
0 178 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x7-y9
0
2
0 0 179 194
0 194 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x6-y0
0
2
0 0 180 165
0 165 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x7-y1
0
2
0 0 180 181
0 181 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x8-y0
0
2
0 0 180 195
0 195 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x6-y1
0
2
0 0 181 166
0 166 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y0
0
2
0 0 181 180
0 180 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y2
0
2
0 0 181 187
0 187 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x8-y1
0
2
0 0 181 196
0 196 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x6-y10
0
2
0 0 182 167
0 167 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y11
0
2
0 0 182 183
0 183 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y9
0
2
0 0 182 194
0 194 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x8-y10
0
2
0 0 182 197
0 197 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 183 168
0 168 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 183 182
0 182 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 183 184
0 184 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 183 198
0 198 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 184 169
0 169 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 184 183
0 183 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y13
0
2
0 0 184 185
0 185 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 184 199
0 199 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x6-y13
0
2
0 0 185 170
0 170 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y12
0
2
0 0 185 184
0 184 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y14
0
2
0 0 185 186
0 186 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x8-y13
0
2
0 0 185 200
0 200 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 186 171
0 171 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 186 185
0 185 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 186 201
0 201 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 187 172
0 172 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 187 181
0 181 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 187 188
0 188 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 187 202
0 202 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 188 173
0 173 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 188 187
0 187 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 188 189
0 189 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 188 203
0 203 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 189 174
0 174 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 189 188
0 188 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 189 190
0 190 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 189 204
0 204 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 190 175
0 175 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 190 189
0 189 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 190 191
0 191 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 190 205
0 205 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 191 176
0 176 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 191 190
0 190 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 191 192
0 192 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 191 206
0 206 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 192 177
0 177 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 192 191
0 191 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 192 193
0 193 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 192 207
0 207 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 193 178
0 178 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 193 192
0 192 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 193 194
0 194 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 193 208
0 208 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 194 179
0 179 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 194 182
0 182 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 194 193
0 193 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 194 209
0 209 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 195 180
0 180 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 195 196
0 196 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 195 210
0 210 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 196 181
0 181 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 196 195
0 195 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 196 202
0 202 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 196 211
0 211 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 197 182
0 182 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 197 198
0 198 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 197 209
0 209 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 197 212
0 212 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 198 183
0 183 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 198 197
0 197 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 198 199
0 199 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 198 213
0 213 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 199 184
0 184 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 199 198
0 198 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 199 200
0 200 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 199 214
0 214 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 200 185
0 185 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 200 199
0 199 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 200 201
0 201 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 200 215
0 215 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 201 186
0 186 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 201 200
0 200 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 201 216
0 216 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 202 187
0 187 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 202 196
0 196 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 202 203
0 203 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 202 217
0 217 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 203 188
0 188 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 203 202
0 202 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 203 204
0 204 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 203 218
0 218 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 204 189
0 189 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 204 203
0 203 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 204 205
0 205 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 204 219
0 219 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 205 190
0 190 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 205 204
0 204 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 205 206
0 206 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 205 220
0 220 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 206 191
0 191 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 206 205
0 205 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 206 207
0 207 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 206 221
0 221 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 207 192
0 192 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 207 206
0 206 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 207 208
0 208 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 207 222
0 222 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 208 193
0 193 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 208 207
0 207 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 208 209
0 209 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 208 223
0 223 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 209 194
0 194 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 209 197
0 197 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 209 208
0 208 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 209 224
0 224 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 210 30
0 30 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 210 195
0 195 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 210 211
0 211 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 211 31
0 31 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 211 196
0 196 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 211 210
0 210 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 211 217
0 217 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 212 32
0 32 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 212 197
0 197 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 212 213
0 213 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 212 224
0 224 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 213 33
0 33 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 213 198
0 198 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 213 212
0 212 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 213 214
0 214 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 214 34
0 34 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 214 199
0 199 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 214 213
0 213 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 214 215
0 215 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 215 35
0 35 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 215 200
0 200 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 215 214
0 214 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 215 216
0 216 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 216 36
0 36 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 216 201
0 201 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 216 215
0 215 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 217 37
0 37 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 217 202
0 202 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 217 211
0 211 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 217 218
0 218 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 218 38
0 38 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 218 203
0 203 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 218 217
0 217 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 218 219
0 219 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 219 39
0 39 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 219 204
0 204 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 219 218
0 218 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 219 220
0 220 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 220 40
0 40 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 220 205
0 205 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 220 219
0 219 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 220 221
0 221 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 221 41
0 41 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 221 206
0 206 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 221 220
0 220 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 221 222
0 222 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 222 42
0 42 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 222 207
0 207 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 222 221
0 221 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 222 223
0 223 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 223 43
0 43 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 223 208
0 208 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 223 222
0 222 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 223 224
0 224 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 224 44
0 44 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 224 209
0 209 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 224 212
0 212 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 224 223
0 223 -1 0
1
end_operator
0
