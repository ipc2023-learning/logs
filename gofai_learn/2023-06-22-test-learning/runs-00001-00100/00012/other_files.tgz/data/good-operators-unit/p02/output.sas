begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var0
-1
9
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y2)
end_variable
begin_variable
var1
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var2
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var3
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var4
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var5
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var6
-1
2
Atom visited(loc-x2-y0)
NegatedAtom visited(loc-x2-y0)
end_variable
begin_variable
var7
-1
2
Atom visited(loc-x2-y1)
NegatedAtom visited(loc-x2-y1)
end_variable
begin_variable
var8
-1
2
Atom visited(loc-x2-y2)
NegatedAtom visited(loc-x2-y2)
end_variable
1
begin_mutex_group
9
0 0
0 1
0 2
0 3
0 4
0 5
0 6
0 7
0 8
end_mutex_group
begin_state
3
1
1
1
1
1
1
1
1
end_state
begin_goal
8
1 0
2 0
3 0
4 0
5 0
6 0
7 0
8 0
end_goal
24
begin_operator
move loc-x0-y0 loc-x0-y1
0
2
0 0 0 1
0 2 -1 0
1
end_operator
begin_operator
move loc-x0-y0 loc-x1-y0
0
1
0 0 0 3
1
end_operator
begin_operator
move loc-x0-y1 loc-x0-y0
0
2
0 0 1 0
0 1 -1 0
1
end_operator
begin_operator
move loc-x0-y1 loc-x0-y2
0
2
0 0 1 2
0 3 -1 0
1
end_operator
begin_operator
move loc-x0-y1 loc-x1-y1
0
2
0 0 1 4
0 4 -1 0
1
end_operator
begin_operator
move loc-x0-y2 loc-x0-y1
0
2
0 0 2 1
0 2 -1 0
1
end_operator
begin_operator
move loc-x0-y2 loc-x1-y2
0
2
0 0 2 5
0 5 -1 0
1
end_operator
begin_operator
move loc-x1-y0 loc-x0-y0
0
2
0 0 3 0
0 1 -1 0
1
end_operator
begin_operator
move loc-x1-y0 loc-x1-y1
0
2
0 0 3 4
0 4 -1 0
1
end_operator
begin_operator
move loc-x1-y0 loc-x2-y0
0
2
0 0 3 6
0 6 -1 0
1
end_operator
begin_operator
move loc-x1-y1 loc-x0-y1
0
2
0 0 4 1
0 2 -1 0
1
end_operator
begin_operator
move loc-x1-y1 loc-x1-y0
0
1
0 0 4 3
1
end_operator
begin_operator
move loc-x1-y1 loc-x1-y2
0
2
0 0 4 5
0 5 -1 0
1
end_operator
begin_operator
move loc-x1-y1 loc-x2-y1
0
2
0 0 4 7
0 7 -1 0
1
end_operator
begin_operator
move loc-x1-y2 loc-x0-y2
0
2
0 0 5 2
0 3 -1 0
1
end_operator
begin_operator
move loc-x1-y2 loc-x1-y1
0
2
0 0 5 4
0 4 -1 0
1
end_operator
begin_operator
move loc-x1-y2 loc-x2-y2
0
2
0 0 5 8
0 8 -1 0
1
end_operator
begin_operator
move loc-x2-y0 loc-x1-y0
0
1
0 0 6 3
1
end_operator
begin_operator
move loc-x2-y0 loc-x2-y1
0
2
0 0 6 7
0 7 -1 0
1
end_operator
begin_operator
move loc-x2-y1 loc-x1-y1
0
2
0 0 7 4
0 4 -1 0
1
end_operator
begin_operator
move loc-x2-y1 loc-x2-y0
0
2
0 0 7 6
0 6 -1 0
1
end_operator
begin_operator
move loc-x2-y1 loc-x2-y2
0
2
0 0 7 8
0 8 -1 0
1
end_operator
begin_operator
move loc-x2-y2 loc-x1-y2
0
2
0 0 8 5
0 5 -1 0
1
end_operator
begin_operator
move loc-x2-y2 loc-x2-y1
0
2
0 0 8 7
0 7 -1 0
1
end_operator
0
