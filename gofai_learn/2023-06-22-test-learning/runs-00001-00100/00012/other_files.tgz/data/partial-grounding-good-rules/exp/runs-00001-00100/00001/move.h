class(A,B,C) :-
   'ini:at-robot'(A,C).
class(A,B,C) :-
   'ini:connected'(A,D,C), 'ini:connected'(D,E,C), 'ini:at-robot'(E,C).
