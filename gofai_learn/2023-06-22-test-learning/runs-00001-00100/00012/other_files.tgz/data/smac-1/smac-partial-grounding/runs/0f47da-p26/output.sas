begin_version
3
end_version
begin_metric
0
end_metric
729
begin_variable
var0
-1
729
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y17)
Atom at-robot(loc-x0-y18)
Atom at-robot(loc-x0-y19)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y20)
Atom at-robot(loc-x0-y21)
Atom at-robot(loc-x0-y22)
Atom at-robot(loc-x0-y23)
Atom at-robot(loc-x0-y24)
Atom at-robot(loc-x0-y25)
Atom at-robot(loc-x0-y26)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y17)
Atom at-robot(loc-x1-y18)
Atom at-robot(loc-x1-y19)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y20)
Atom at-robot(loc-x1-y21)
Atom at-robot(loc-x1-y22)
Atom at-robot(loc-x1-y23)
Atom at-robot(loc-x1-y24)
Atom at-robot(loc-x1-y25)
Atom at-robot(loc-x1-y26)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y17)
Atom at-robot(loc-x10-y18)
Atom at-robot(loc-x10-y19)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y20)
Atom at-robot(loc-x10-y21)
Atom at-robot(loc-x10-y22)
Atom at-robot(loc-x10-y23)
Atom at-robot(loc-x10-y24)
Atom at-robot(loc-x10-y25)
Atom at-robot(loc-x10-y26)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y17)
Atom at-robot(loc-x11-y18)
Atom at-robot(loc-x11-y19)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y20)
Atom at-robot(loc-x11-y21)
Atom at-robot(loc-x11-y22)
Atom at-robot(loc-x11-y23)
Atom at-robot(loc-x11-y24)
Atom at-robot(loc-x11-y25)
Atom at-robot(loc-x11-y26)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y17)
Atom at-robot(loc-x12-y18)
Atom at-robot(loc-x12-y19)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y20)
Atom at-robot(loc-x12-y21)
Atom at-robot(loc-x12-y22)
Atom at-robot(loc-x12-y23)
Atom at-robot(loc-x12-y24)
Atom at-robot(loc-x12-y25)
Atom at-robot(loc-x12-y26)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y17)
Atom at-robot(loc-x13-y18)
Atom at-robot(loc-x13-y19)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y20)
Atom at-robot(loc-x13-y21)
Atom at-robot(loc-x13-y22)
Atom at-robot(loc-x13-y23)
Atom at-robot(loc-x13-y24)
Atom at-robot(loc-x13-y25)
Atom at-robot(loc-x13-y26)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y17)
Atom at-robot(loc-x14-y18)
Atom at-robot(loc-x14-y19)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y20)
Atom at-robot(loc-x14-y21)
Atom at-robot(loc-x14-y22)
Atom at-robot(loc-x14-y23)
Atom at-robot(loc-x14-y24)
Atom at-robot(loc-x14-y25)
Atom at-robot(loc-x14-y26)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y17)
Atom at-robot(loc-x15-y18)
Atom at-robot(loc-x15-y19)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y20)
Atom at-robot(loc-x15-y21)
Atom at-robot(loc-x15-y22)
Atom at-robot(loc-x15-y23)
Atom at-robot(loc-x15-y24)
Atom at-robot(loc-x15-y25)
Atom at-robot(loc-x15-y26)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y17)
Atom at-robot(loc-x16-y18)
Atom at-robot(loc-x16-y19)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y20)
Atom at-robot(loc-x16-y21)
Atom at-robot(loc-x16-y22)
Atom at-robot(loc-x16-y23)
Atom at-robot(loc-x16-y24)
Atom at-robot(loc-x16-y25)
Atom at-robot(loc-x16-y26)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x17-y0)
Atom at-robot(loc-x17-y1)
Atom at-robot(loc-x17-y10)
Atom at-robot(loc-x17-y11)
Atom at-robot(loc-x17-y12)
Atom at-robot(loc-x17-y13)
Atom at-robot(loc-x17-y14)
Atom at-robot(loc-x17-y15)
Atom at-robot(loc-x17-y16)
Atom at-robot(loc-x17-y17)
Atom at-robot(loc-x17-y18)
Atom at-robot(loc-x17-y19)
Atom at-robot(loc-x17-y2)
Atom at-robot(loc-x17-y20)
Atom at-robot(loc-x17-y21)
Atom at-robot(loc-x17-y22)
Atom at-robot(loc-x17-y23)
Atom at-robot(loc-x17-y24)
Atom at-robot(loc-x17-y25)
Atom at-robot(loc-x17-y26)
Atom at-robot(loc-x17-y3)
Atom at-robot(loc-x17-y4)
Atom at-robot(loc-x17-y5)
Atom at-robot(loc-x17-y6)
Atom at-robot(loc-x17-y7)
Atom at-robot(loc-x17-y8)
Atom at-robot(loc-x17-y9)
Atom at-robot(loc-x18-y0)
Atom at-robot(loc-x18-y1)
Atom at-robot(loc-x18-y10)
Atom at-robot(loc-x18-y11)
Atom at-robot(loc-x18-y12)
Atom at-robot(loc-x18-y13)
Atom at-robot(loc-x18-y14)
Atom at-robot(loc-x18-y15)
Atom at-robot(loc-x18-y16)
Atom at-robot(loc-x18-y17)
Atom at-robot(loc-x18-y18)
Atom at-robot(loc-x18-y19)
Atom at-robot(loc-x18-y2)
Atom at-robot(loc-x18-y20)
Atom at-robot(loc-x18-y21)
Atom at-robot(loc-x18-y22)
Atom at-robot(loc-x18-y23)
Atom at-robot(loc-x18-y24)
Atom at-robot(loc-x18-y25)
Atom at-robot(loc-x18-y26)
Atom at-robot(loc-x18-y3)
Atom at-robot(loc-x18-y4)
Atom at-robot(loc-x18-y5)
Atom at-robot(loc-x18-y6)
Atom at-robot(loc-x18-y7)
Atom at-robot(loc-x18-y8)
Atom at-robot(loc-x18-y9)
Atom at-robot(loc-x19-y0)
Atom at-robot(loc-x19-y1)
Atom at-robot(loc-x19-y10)
Atom at-robot(loc-x19-y11)
Atom at-robot(loc-x19-y12)
Atom at-robot(loc-x19-y13)
Atom at-robot(loc-x19-y14)
Atom at-robot(loc-x19-y15)
Atom at-robot(loc-x19-y16)
Atom at-robot(loc-x19-y17)
Atom at-robot(loc-x19-y18)
Atom at-robot(loc-x19-y19)
Atom at-robot(loc-x19-y2)
Atom at-robot(loc-x19-y20)
Atom at-robot(loc-x19-y21)
Atom at-robot(loc-x19-y22)
Atom at-robot(loc-x19-y23)
Atom at-robot(loc-x19-y24)
Atom at-robot(loc-x19-y25)
Atom at-robot(loc-x19-y26)
Atom at-robot(loc-x19-y3)
Atom at-robot(loc-x19-y4)
Atom at-robot(loc-x19-y5)
Atom at-robot(loc-x19-y6)
Atom at-robot(loc-x19-y7)
Atom at-robot(loc-x19-y8)
Atom at-robot(loc-x19-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y17)
Atom at-robot(loc-x2-y18)
Atom at-robot(loc-x2-y19)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y20)
Atom at-robot(loc-x2-y21)
Atom at-robot(loc-x2-y22)
Atom at-robot(loc-x2-y23)
Atom at-robot(loc-x2-y24)
Atom at-robot(loc-x2-y25)
Atom at-robot(loc-x2-y26)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x20-y0)
Atom at-robot(loc-x20-y1)
Atom at-robot(loc-x20-y10)
Atom at-robot(loc-x20-y11)
Atom at-robot(loc-x20-y12)
Atom at-robot(loc-x20-y13)
Atom at-robot(loc-x20-y14)
Atom at-robot(loc-x20-y15)
Atom at-robot(loc-x20-y16)
Atom at-robot(loc-x20-y17)
Atom at-robot(loc-x20-y18)
Atom at-robot(loc-x20-y19)
Atom at-robot(loc-x20-y2)
Atom at-robot(loc-x20-y20)
Atom at-robot(loc-x20-y21)
Atom at-robot(loc-x20-y22)
Atom at-robot(loc-x20-y23)
Atom at-robot(loc-x20-y24)
Atom at-robot(loc-x20-y25)
Atom at-robot(loc-x20-y26)
Atom at-robot(loc-x20-y3)
Atom at-robot(loc-x20-y4)
Atom at-robot(loc-x20-y5)
Atom at-robot(loc-x20-y6)
Atom at-robot(loc-x20-y7)
Atom at-robot(loc-x20-y8)
Atom at-robot(loc-x20-y9)
Atom at-robot(loc-x21-y0)
Atom at-robot(loc-x21-y1)
Atom at-robot(loc-x21-y10)
Atom at-robot(loc-x21-y11)
Atom at-robot(loc-x21-y12)
Atom at-robot(loc-x21-y13)
Atom at-robot(loc-x21-y14)
Atom at-robot(loc-x21-y15)
Atom at-robot(loc-x21-y16)
Atom at-robot(loc-x21-y17)
Atom at-robot(loc-x21-y18)
Atom at-robot(loc-x21-y19)
Atom at-robot(loc-x21-y2)
Atom at-robot(loc-x21-y20)
Atom at-robot(loc-x21-y21)
Atom at-robot(loc-x21-y22)
Atom at-robot(loc-x21-y23)
Atom at-robot(loc-x21-y24)
Atom at-robot(loc-x21-y25)
Atom at-robot(loc-x21-y26)
Atom at-robot(loc-x21-y3)
Atom at-robot(loc-x21-y4)
Atom at-robot(loc-x21-y5)
Atom at-robot(loc-x21-y6)
Atom at-robot(loc-x21-y7)
Atom at-robot(loc-x21-y8)
Atom at-robot(loc-x21-y9)
Atom at-robot(loc-x22-y0)
Atom at-robot(loc-x22-y1)
Atom at-robot(loc-x22-y10)
Atom at-robot(loc-x22-y11)
Atom at-robot(loc-x22-y12)
Atom at-robot(loc-x22-y13)
Atom at-robot(loc-x22-y14)
Atom at-robot(loc-x22-y15)
Atom at-robot(loc-x22-y16)
Atom at-robot(loc-x22-y17)
Atom at-robot(loc-x22-y18)
Atom at-robot(loc-x22-y19)
Atom at-robot(loc-x22-y2)
Atom at-robot(loc-x22-y20)
Atom at-robot(loc-x22-y21)
Atom at-robot(loc-x22-y22)
Atom at-robot(loc-x22-y23)
Atom at-robot(loc-x22-y24)
Atom at-robot(loc-x22-y25)
Atom at-robot(loc-x22-y26)
Atom at-robot(loc-x22-y3)
Atom at-robot(loc-x22-y4)
Atom at-robot(loc-x22-y5)
Atom at-robot(loc-x22-y6)
Atom at-robot(loc-x22-y7)
Atom at-robot(loc-x22-y8)
Atom at-robot(loc-x22-y9)
Atom at-robot(loc-x23-y0)
Atom at-robot(loc-x23-y1)
Atom at-robot(loc-x23-y10)
Atom at-robot(loc-x23-y11)
Atom at-robot(loc-x23-y12)
Atom at-robot(loc-x23-y13)
Atom at-robot(loc-x23-y14)
Atom at-robot(loc-x23-y15)
Atom at-robot(loc-x23-y16)
Atom at-robot(loc-x23-y17)
Atom at-robot(loc-x23-y18)
Atom at-robot(loc-x23-y19)
Atom at-robot(loc-x23-y2)
Atom at-robot(loc-x23-y20)
Atom at-robot(loc-x23-y21)
Atom at-robot(loc-x23-y22)
Atom at-robot(loc-x23-y23)
Atom at-robot(loc-x23-y24)
Atom at-robot(loc-x23-y25)
Atom at-robot(loc-x23-y26)
Atom at-robot(loc-x23-y3)
Atom at-robot(loc-x23-y4)
Atom at-robot(loc-x23-y5)
Atom at-robot(loc-x23-y6)
Atom at-robot(loc-x23-y7)
Atom at-robot(loc-x23-y8)
Atom at-robot(loc-x23-y9)
Atom at-robot(loc-x24-y0)
Atom at-robot(loc-x24-y1)
Atom at-robot(loc-x24-y10)
Atom at-robot(loc-x24-y11)
Atom at-robot(loc-x24-y12)
Atom at-robot(loc-x24-y13)
Atom at-robot(loc-x24-y14)
Atom at-robot(loc-x24-y15)
Atom at-robot(loc-x24-y16)
Atom at-robot(loc-x24-y17)
Atom at-robot(loc-x24-y18)
Atom at-robot(loc-x24-y19)
Atom at-robot(loc-x24-y2)
Atom at-robot(loc-x24-y20)
Atom at-robot(loc-x24-y21)
Atom at-robot(loc-x24-y22)
Atom at-robot(loc-x24-y23)
Atom at-robot(loc-x24-y24)
Atom at-robot(loc-x24-y25)
Atom at-robot(loc-x24-y26)
Atom at-robot(loc-x24-y3)
Atom at-robot(loc-x24-y4)
Atom at-robot(loc-x24-y5)
Atom at-robot(loc-x24-y6)
Atom at-robot(loc-x24-y7)
Atom at-robot(loc-x24-y8)
Atom at-robot(loc-x24-y9)
Atom at-robot(loc-x25-y0)
Atom at-robot(loc-x25-y1)
Atom at-robot(loc-x25-y10)
Atom at-robot(loc-x25-y11)
Atom at-robot(loc-x25-y12)
Atom at-robot(loc-x25-y13)
Atom at-robot(loc-x25-y14)
Atom at-robot(loc-x25-y15)
Atom at-robot(loc-x25-y16)
Atom at-robot(loc-x25-y17)
Atom at-robot(loc-x25-y18)
Atom at-robot(loc-x25-y19)
Atom at-robot(loc-x25-y2)
Atom at-robot(loc-x25-y20)
Atom at-robot(loc-x25-y21)
Atom at-robot(loc-x25-y22)
Atom at-robot(loc-x25-y23)
Atom at-robot(loc-x25-y24)
Atom at-robot(loc-x25-y25)
Atom at-robot(loc-x25-y26)
Atom at-robot(loc-x25-y3)
Atom at-robot(loc-x25-y4)
Atom at-robot(loc-x25-y5)
Atom at-robot(loc-x25-y6)
Atom at-robot(loc-x25-y7)
Atom at-robot(loc-x25-y8)
Atom at-robot(loc-x25-y9)
Atom at-robot(loc-x26-y0)
Atom at-robot(loc-x26-y1)
Atom at-robot(loc-x26-y10)
Atom at-robot(loc-x26-y11)
Atom at-robot(loc-x26-y12)
Atom at-robot(loc-x26-y13)
Atom at-robot(loc-x26-y14)
Atom at-robot(loc-x26-y15)
Atom at-robot(loc-x26-y16)
Atom at-robot(loc-x26-y17)
Atom at-robot(loc-x26-y18)
Atom at-robot(loc-x26-y19)
Atom at-robot(loc-x26-y2)
Atom at-robot(loc-x26-y20)
Atom at-robot(loc-x26-y21)
Atom at-robot(loc-x26-y22)
Atom at-robot(loc-x26-y23)
Atom at-robot(loc-x26-y24)
Atom at-robot(loc-x26-y25)
Atom at-robot(loc-x26-y26)
Atom at-robot(loc-x26-y3)
Atom at-robot(loc-x26-y4)
Atom at-robot(loc-x26-y5)
Atom at-robot(loc-x26-y6)
Atom at-robot(loc-x26-y7)
Atom at-robot(loc-x26-y8)
Atom at-robot(loc-x26-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y17)
Atom at-robot(loc-x3-y18)
Atom at-robot(loc-x3-y19)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y20)
Atom at-robot(loc-x3-y21)
Atom at-robot(loc-x3-y22)
Atom at-robot(loc-x3-y23)
Atom at-robot(loc-x3-y24)
Atom at-robot(loc-x3-y25)
Atom at-robot(loc-x3-y26)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y17)
Atom at-robot(loc-x4-y18)
Atom at-robot(loc-x4-y19)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y20)
Atom at-robot(loc-x4-y21)
Atom at-robot(loc-x4-y22)
Atom at-robot(loc-x4-y23)
Atom at-robot(loc-x4-y24)
Atom at-robot(loc-x4-y25)
Atom at-robot(loc-x4-y26)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y17)
Atom at-robot(loc-x5-y18)
Atom at-robot(loc-x5-y19)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y20)
Atom at-robot(loc-x5-y21)
Atom at-robot(loc-x5-y22)
Atom at-robot(loc-x5-y23)
Atom at-robot(loc-x5-y24)
Atom at-robot(loc-x5-y25)
Atom at-robot(loc-x5-y26)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y17)
Atom at-robot(loc-x6-y18)
Atom at-robot(loc-x6-y19)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y20)
Atom at-robot(loc-x6-y21)
Atom at-robot(loc-x6-y22)
Atom at-robot(loc-x6-y23)
Atom at-robot(loc-x6-y24)
Atom at-robot(loc-x6-y25)
Atom at-robot(loc-x6-y26)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y17)
Atom at-robot(loc-x7-y18)
Atom at-robot(loc-x7-y19)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y20)
Atom at-robot(loc-x7-y21)
Atom at-robot(loc-x7-y22)
Atom at-robot(loc-x7-y23)
Atom at-robot(loc-x7-y24)
Atom at-robot(loc-x7-y25)
Atom at-robot(loc-x7-y26)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y17)
Atom at-robot(loc-x8-y18)
Atom at-robot(loc-x8-y19)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y20)
Atom at-robot(loc-x8-y21)
Atom at-robot(loc-x8-y22)
Atom at-robot(loc-x8-y23)
Atom at-robot(loc-x8-y24)
Atom at-robot(loc-x8-y25)
Atom at-robot(loc-x8-y26)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y17)
Atom at-robot(loc-x9-y18)
Atom at-robot(loc-x9-y19)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y20)
Atom at-robot(loc-x9-y21)
Atom at-robot(loc-x9-y22)
Atom at-robot(loc-x9-y23)
Atom at-robot(loc-x9-y24)
Atom at-robot(loc-x9-y25)
Atom at-robot(loc-x9-y26)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var728
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var727
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var726
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var725
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var724
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var723
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var722
-1
2
Atom visited(loc-x0-y14)
NegatedAtom visited(loc-x0-y14)
end_variable
begin_variable
var721
-1
2
Atom visited(loc-x0-y15)
NegatedAtom visited(loc-x0-y15)
end_variable
begin_variable
var720
-1
2
Atom visited(loc-x0-y16)
NegatedAtom visited(loc-x0-y16)
end_variable
begin_variable
var719
-1
2
Atom visited(loc-x0-y17)
NegatedAtom visited(loc-x0-y17)
end_variable
begin_variable
var718
-1
2
Atom visited(loc-x0-y18)
NegatedAtom visited(loc-x0-y18)
end_variable
begin_variable
var717
-1
2
Atom visited(loc-x0-y19)
NegatedAtom visited(loc-x0-y19)
end_variable
begin_variable
var716
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var715
-1
2
Atom visited(loc-x0-y20)
NegatedAtom visited(loc-x0-y20)
end_variable
begin_variable
var714
-1
2
Atom visited(loc-x0-y21)
NegatedAtom visited(loc-x0-y21)
end_variable
begin_variable
var713
-1
2
Atom visited(loc-x0-y22)
NegatedAtom visited(loc-x0-y22)
end_variable
begin_variable
var712
-1
2
Atom visited(loc-x0-y23)
NegatedAtom visited(loc-x0-y23)
end_variable
begin_variable
var711
-1
2
Atom visited(loc-x0-y24)
NegatedAtom visited(loc-x0-y24)
end_variable
begin_variable
var710
-1
2
Atom visited(loc-x0-y25)
NegatedAtom visited(loc-x0-y25)
end_variable
begin_variable
var709
-1
2
Atom visited(loc-x0-y26)
NegatedAtom visited(loc-x0-y26)
end_variable
begin_variable
var708
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var707
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var706
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var705
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var704
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var703
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var702
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var701
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var700
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var699
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var698
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var697
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var696
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var695
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var694
-1
2
Atom visited(loc-x1-y15)
NegatedAtom visited(loc-x1-y15)
end_variable
begin_variable
var693
-1
2
Atom visited(loc-x1-y16)
NegatedAtom visited(loc-x1-y16)
end_variable
begin_variable
var692
-1
2
Atom visited(loc-x1-y17)
NegatedAtom visited(loc-x1-y17)
end_variable
begin_variable
var691
-1
2
Atom visited(loc-x1-y18)
NegatedAtom visited(loc-x1-y18)
end_variable
begin_variable
var690
-1
2
Atom visited(loc-x1-y19)
NegatedAtom visited(loc-x1-y19)
end_variable
begin_variable
var689
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var688
-1
2
Atom visited(loc-x1-y20)
NegatedAtom visited(loc-x1-y20)
end_variable
begin_variable
var687
-1
2
Atom visited(loc-x1-y21)
NegatedAtom visited(loc-x1-y21)
end_variable
begin_variable
var686
-1
2
Atom visited(loc-x1-y22)
NegatedAtom visited(loc-x1-y22)
end_variable
begin_variable
var685
-1
2
Atom visited(loc-x1-y23)
NegatedAtom visited(loc-x1-y23)
end_variable
begin_variable
var684
-1
2
Atom visited(loc-x1-y24)
NegatedAtom visited(loc-x1-y24)
end_variable
begin_variable
var683
-1
2
Atom visited(loc-x1-y25)
NegatedAtom visited(loc-x1-y25)
end_variable
begin_variable
var682
-1
2
Atom visited(loc-x1-y26)
NegatedAtom visited(loc-x1-y26)
end_variable
begin_variable
var681
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var680
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var679
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var678
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var677
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var676
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var675
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var674
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var673
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var672
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var671
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var670
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var669
-1
2
Atom visited(loc-x10-y13)
NegatedAtom visited(loc-x10-y13)
end_variable
begin_variable
var668
-1
2
Atom visited(loc-x10-y14)
NegatedAtom visited(loc-x10-y14)
end_variable
begin_variable
var667
-1
2
Atom visited(loc-x10-y15)
NegatedAtom visited(loc-x10-y15)
end_variable
begin_variable
var666
-1
2
Atom visited(loc-x10-y16)
NegatedAtom visited(loc-x10-y16)
end_variable
begin_variable
var665
-1
2
Atom visited(loc-x10-y17)
NegatedAtom visited(loc-x10-y17)
end_variable
begin_variable
var664
-1
2
Atom visited(loc-x10-y18)
NegatedAtom visited(loc-x10-y18)
end_variable
begin_variable
var663
-1
2
Atom visited(loc-x10-y19)
NegatedAtom visited(loc




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




10 loc-x8-y10
0
2
0 0 650 677
0 677 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 651 624
0 624 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 651 650
0 650 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 651 652
0 652 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 651 678
0 678 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 652 625
0 625 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 652 651
0 651 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y13
0
2
0 0 652 653
0 653 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 652 679
0 679 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x6-y13
0
2
0 0 653 626
0 626 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y12
0
2
0 0 653 652
0 652 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y14
0
2
0 0 653 654
0 654 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x8-y13
0
2
0 0 653 680
0 680 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 654 627
0 627 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 654 653
0 653 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y15
0
2
0 0 654 655
0 655 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 654 681
0 681 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x6-y15
0
2
0 0 655 628
0 628 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y14
0
2
0 0 655 654
0 654 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y16
0
2
0 0 655 656
0 656 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x8-y15
0
2
0 0 655 682
0 682 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x6-y16
0
2
0 0 656 629
0 629 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y15
0
2
0 0 656 655
0 655 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y17
0
2
0 0 656 657
0 657 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x8-y16
0
2
0 0 656 683
0 683 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x6-y17
0
2
0 0 657 630
0 630 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y16
0
2
0 0 657 656
0 656 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y18
0
2
0 0 657 658
0 658 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x8-y17
0
2
0 0 657 684
0 684 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x6-y18
0
2
0 0 658 631
0 631 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y17
0
2
0 0 658 657
0 657 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y19
0
2
0 0 658 659
0 659 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x8-y18
0
2
0 0 658 685
0 685 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x6-y19
0
2
0 0 659 632
0 632 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y18
0
2
0 0 659 658
0 658 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y20
0
2
0 0 659 661
0 661 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x8-y19
0
2
0 0 659 686
0 686 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 660 633
0 633 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 660 649
0 649 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 660 668
0 668 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 660 687
0 687 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x6-y20
0
2
0 0 661 634
0 634 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x7-y19
0
2
0 0 661 659
0 659 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x7-y21
0
2
0 0 661 662
0 662 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x8-y20
0
2
0 0 661 688
0 688 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x6-y21
0
2
0 0 662 635
0 635 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x7-y20
0
2
0 0 662 661
0 661 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x7-y22
0
2
0 0 662 663
0 663 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x8-y21
0
2
0 0 662 689
0 689 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x6-y22
0
2
0 0 663 636
0 636 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x7-y21
0
2
0 0 663 662
0 662 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x7-y23
0
2
0 0 663 664
0 664 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x8-y22
0
2
0 0 663 690
0 690 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x6-y23
0
2
0 0 664 637
0 637 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x7-y22
0
2
0 0 664 663
0 663 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x7-y24
0
2
0 0 664 665
0 665 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x8-y23
0
2
0 0 664 691
0 691 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x6-y24
0
2
0 0 665 638
0 638 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x7-y23
0
2
0 0 665 664
0 664 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x7-y25
0
2
0 0 665 666
0 666 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x8-y24
0
2
0 0 665 692
0 692 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x6-y25
0
2
0 0 666 639
0 639 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x7-y24
0
2
0 0 666 665
0 665 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x7-y26
0
2
0 0 666 667
0 667 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x8-y25
0
2
0 0 666 693
0 693 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x6-y26
0
2
0 0 667 640
0 640 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x7-y25
0
2
0 0 667 666
0 666 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x8-y26
0
2
0 0 667 694
0 694 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 668 641
0 641 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 668 660
0 660 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 668 669
0 669 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 668 695
0 695 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 669 642
0 642 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 669 668
0 668 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 669 670
0 670 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 669 696
0 696 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 670 643
0 643 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 670 669
0 669 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 670 671
0 671 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 670 697
0 697 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 671 644
0 644 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 671 670
0 670 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 671 672
0 672 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 671 698
0 698 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 672 645
0 645 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 672 671
0 671 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 672 673
0 673 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 672 699
0 699 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 673 646
0 646 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 673 672
0 672 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 673 674
0 674 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 673 700
0 700 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 674 647
0 647 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 674 650
0 650 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 674 673
0 673 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 674 701
0 701 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 675 648
0 648 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 675 676
0 676 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 675 702
0 702 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 676 649
0 649 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 676 675
0 675 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 676 687
0 687 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 676 703
0 703 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 677 650
0 650 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 677 678
0 678 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 677 701
0 701 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 677 704
0 704 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 678 651
0 651 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 678 677
0 677 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 678 679
0 679 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 678 705
0 705 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 679 652
0 652 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 679 678
0 678 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 679 680
0 680 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 679 706
0 706 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 680 653
0 653 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 680 679
0 679 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 680 681
0 681 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 680 707
0 707 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 681 654
0 654 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 681 680
0 680 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 681 682
0 682 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 681 708
0 708 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 682 655
0 655 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y14
0
2
0 0 682 681
0 681 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y16
0
2
0 0 682 683
0 683 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 682 709
0 709 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 683 656
0 656 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y15
0
2
0 0 683 682
0 682 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y17
0
2
0 0 683 684
0 684 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 683 710
0 710 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x7-y17
0
2
0 0 684 657
0 657 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y16
0
2
0 0 684 683
0 683 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y18
0
2
0 0 684 685
0 685 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x9-y17
0
2
0 0 684 711
0 711 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x7-y18
0
2
0 0 685 658
0 658 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y17
0
2
0 0 685 684
0 684 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y19
0
2
0 0 685 686
0 686 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x9-y18
0
2
0 0 685 712
0 712 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x7-y19
0
2
0 0 686 659
0 659 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y18
0
2
0 0 686 685
0 685 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y20
0
2
0 0 686 688
0 688 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x9-y19
0
2
0 0 686 713
0 713 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 687 660
0 660 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 687 676
0 676 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 687 695
0 695 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 687 714
0 714 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x7-y20
0
2
0 0 688 661
0 661 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y19
0
2
0 0 688 686
0 686 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y21
0
2
0 0 688 689
0 689 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x9-y20
0
2
0 0 688 715
0 715 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x7-y21
0
2
0 0 689 662
0 662 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y20
0
2
0 0 689 688
0 688 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y22
0
2
0 0 689 690
0 690 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x9-y21
0
2
0 0 689 716
0 716 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x7-y22
0
2
0 0 690 663
0 663 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x8-y21
0
2
0 0 690 689
0 689 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x8-y23
0
2
0 0 690 691
0 691 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x9-y22
0
2
0 0 690 717
0 717 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x7-y23
0
2
0 0 691 664
0 664 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x8-y22
0
2
0 0 691 690
0 690 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x8-y24
0
2
0 0 691 692
0 692 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x9-y23
0
2
0 0 691 718
0 718 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x7-y24
0
2
0 0 692 665
0 665 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x8-y23
0
2
0 0 692 691
0 691 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x8-y25
0
2
0 0 692 693
0 693 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x9-y24
0
2
0 0 692 719
0 719 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x7-y25
0
2
0 0 693 666
0 666 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x8-y24
0
2
0 0 693 692
0 692 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x8-y26
0
2
0 0 693 694
0 694 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x9-y25
0
2
0 0 693 720
0 720 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x7-y26
0
2
0 0 694 667
0 667 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x8-y25
0
2
0 0 694 693
0 693 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x9-y26
0
2
0 0 694 721
0 721 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 695 668
0 668 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 695 687
0 687 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 695 696
0 696 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 695 722
0 722 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 696 669
0 669 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 696 695
0 695 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 696 697
0 697 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 696 723
0 723 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 697 670
0 670 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 697 696
0 696 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 697 698
0 698 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 697 724
0 724 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 698 671
0 671 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 698 697
0 697 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 698 699
0 699 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 698 725
0 725 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 699 672
0 672 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 699 698
0 698 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 699 700
0 700 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 699 726
0 726 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 700 673
0 673 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 700 699
0 699 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 700 701
0 701 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 700 727
0 727 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 701 674
0 674 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 701 677
0 677 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 701 700
0 700 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 701 728
0 728 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 702 54
0 55 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 702 675
0 675 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 702 703
0 703 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 703 55
0 56 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 703 676
0 676 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 703 702
0 702 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 703 714
0 714 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 704 56
0 57 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 704 677
0 677 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 704 705
0 705 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 704 728
0 728 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 705 57
0 58 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 705 678
0 678 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 705 704
0 704 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 705 706
0 706 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 706 58
0 59 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 706 679
0 679 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 706 705
0 705 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 706 707
0 707 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 707 59
0 60 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 707 680
0 680 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 707 706
0 706 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 707 708
0 708 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 708 60
0 61 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 708 681
0 681 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 708 707
0 707 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y15
0
2
0 0 708 709
0 709 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 709 61
0 62 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x8-y15
0
2
0 0 709 682
0 682 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y14
0
2
0 0 709 708
0 708 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y16
0
2
0 0 709 710
0 710 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 710 62
0 63 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x8-y16
0
2
0 0 710 683
0 683 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y15
0
2
0 0 710 709
0 709 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y17
0
2
0 0 710 711
0 711 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x10-y17
0
2
0 0 711 63
0 64 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x8-y17
0
2
0 0 711 684
0 684 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y16
0
2
0 0 711 710
0 710 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y18
0
2
0 0 711 712
0 712 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x10-y18
0
2
0 0 712 64
0 65 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x8-y18
0
2
0 0 712 685
0 685 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y17
0
2
0 0 712 711
0 711 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y19
0
2
0 0 712 713
0 713 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x10-y19
0
2
0 0 713 65
0 66 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x8-y19
0
2
0 0 713 686
0 686 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y18
0
2
0 0 713 712
0 712 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y20
0
2
0 0 713 715
0 715 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 714 66
0 67 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 714 687
0 687 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 714 703
0 703 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 714 722
0 722 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x10-y20
0
2
0 0 715 67
0 68 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x8-y20
0
2
0 0 715 688
0 688 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y19
0
2
0 0 715 713
0 713 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y21
0
2
0 0 715 716
0 716 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x10-y21
0
2
0 0 716 68
0 69 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x8-y21
0
2
0 0 716 689
0 689 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y20
0
2
0 0 716 715
0 715 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y22
0
2
0 0 716 717
0 717 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x10-y22
0
2
0 0 717 69
0 70 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x8-y22
0
2
0 0 717 690
0 690 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x9-y21
0
2
0 0 717 716
0 716 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x9-y23
0
2
0 0 717 718
0 718 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x10-y23
0
2
0 0 718 70
0 71 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x8-y23
0
2
0 0 718 691
0 691 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x9-y22
0
2
0 0 718 717
0 717 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x9-y24
0
2
0 0 718 719
0 719 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x10-y24
0
2
0 0 719 71
0 72 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x8-y24
0
2
0 0 719 692
0 692 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x9-y23
0
2
0 0 719 718
0 718 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x9-y25
0
2
0 0 719 720
0 720 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x10-y25
0
2
0 0 720 72
0 73 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x8-y25
0
2
0 0 720 693
0 693 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x9-y24
0
2
0 0 720 719
0 719 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x9-y26
0
2
0 0 720 721
0 721 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x10-y26
0
2
0 0 721 73
0 74 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x8-y26
0
2
0 0 721 694
0 694 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x9-y25
0
2
0 0 721 720
0 720 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 722 74
0 75 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 722 695
0 695 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 722 714
0 714 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 722 723
0 723 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 723 75
0 76 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 723 696
0 696 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 723 722
0 722 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 723 724
0 724 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 724 76
0 77 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 724 697
0 697 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 724 723
0 723 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 724 725
0 725 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 725 77
0 78 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 725 698
0 698 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 725 724
0 724 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 725 726
0 726 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 726 78
0 79 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 726 699
0 699 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 726 725
0 725 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 726 727
0 727 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 727 79
0 80 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 727 700
0 700 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 727 726
0 726 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 727 728
0 728 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 728 80
0 81 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 728 701
0 701 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 728 704
0 704 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 728 727
0 727 -1 0
1
end_operator
0
