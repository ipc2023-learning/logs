begin_version
3
end_version
begin_metric
0
end_metric
676
begin_variable
var0
-1
676
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y17)
Atom at-robot(loc-x0-y18)
Atom at-robot(loc-x0-y19)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y20)
Atom at-robot(loc-x0-y21)
Atom at-robot(loc-x0-y22)
Atom at-robot(loc-x0-y23)
Atom at-robot(loc-x0-y24)
Atom at-robot(loc-x0-y25)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y17)
Atom at-robot(loc-x1-y18)
Atom at-robot(loc-x1-y19)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y20)
Atom at-robot(loc-x1-y21)
Atom at-robot(loc-x1-y22)
Atom at-robot(loc-x1-y23)
Atom at-robot(loc-x1-y24)
Atom at-robot(loc-x1-y25)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y17)
Atom at-robot(loc-x10-y18)
Atom at-robot(loc-x10-y19)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y20)
Atom at-robot(loc-x10-y21)
Atom at-robot(loc-x10-y22)
Atom at-robot(loc-x10-y23)
Atom at-robot(loc-x10-y24)
Atom at-robot(loc-x10-y25)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y17)
Atom at-robot(loc-x11-y18)
Atom at-robot(loc-x11-y19)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y20)
Atom at-robot(loc-x11-y21)
Atom at-robot(loc-x11-y22)
Atom at-robot(loc-x11-y23)
Atom at-robot(loc-x11-y24)
Atom at-robot(loc-x11-y25)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y17)
Atom at-robot(loc-x12-y18)
Atom at-robot(loc-x12-y19)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y20)
Atom at-robot(loc-x12-y21)
Atom at-robot(loc-x12-y22)
Atom at-robot(loc-x12-y23)
Atom at-robot(loc-x12-y24)
Atom at-robot(loc-x12-y25)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y17)
Atom at-robot(loc-x13-y18)
Atom at-robot(loc-x13-y19)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y20)
Atom at-robot(loc-x13-y21)
Atom at-robot(loc-x13-y22)
Atom at-robot(loc-x13-y23)
Atom at-robot(loc-x13-y24)
Atom at-robot(loc-x13-y25)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y17)
Atom at-robot(loc-x14-y18)
Atom at-robot(loc-x14-y19)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y20)
Atom at-robot(loc-x14-y21)
Atom at-robot(loc-x14-y22)
Atom at-robot(loc-x14-y23)
Atom at-robot(loc-x14-y24)
Atom at-robot(loc-x14-y25)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y17)
Atom at-robot(loc-x15-y18)
Atom at-robot(loc-x15-y19)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y20)
Atom at-robot(loc-x15-y21)
Atom at-robot(loc-x15-y22)
Atom at-robot(loc-x15-y23)
Atom at-robot(loc-x15-y24)
Atom at-robot(loc-x15-y25)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y17)
Atom at-robot(loc-x16-y18)
Atom at-robot(loc-x16-y19)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y20)
Atom at-robot(loc-x16-y21)
Atom at-robot(loc-x16-y22)
Atom at-robot(loc-x16-y23)
Atom at-robot(loc-x16-y24)
Atom at-robot(loc-x16-y25)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x17-y0)
Atom at-robot(loc-x17-y1)
Atom at-robot(loc-x17-y10)
Atom at-robot(loc-x17-y11)
Atom at-robot(loc-x17-y12)
Atom at-robot(loc-x17-y13)
Atom at-robot(loc-x17-y14)
Atom at-robot(loc-x17-y15)
Atom at-robot(loc-x17-y16)
Atom at-robot(loc-x17-y17)
Atom at-robot(loc-x17-y18)
Atom at-robot(loc-x17-y19)
Atom at-robot(loc-x17-y2)
Atom at-robot(loc-x17-y20)
Atom at-robot(loc-x17-y21)
Atom at-robot(loc-x17-y22)
Atom at-robot(loc-x17-y23)
Atom at-robot(loc-x17-y24)
Atom at-robot(loc-x17-y25)
Atom at-robot(loc-x17-y3)
Atom at-robot(loc-x17-y4)
Atom at-robot(loc-x17-y5)
Atom at-robot(loc-x17-y6)
Atom at-robot(loc-x17-y7)
Atom at-robot(loc-x17-y8)
Atom at-robot(loc-x17-y9)
Atom at-robot(loc-x18-y0)
Atom at-robot(loc-x18-y1)
Atom at-robot(loc-x18-y10)
Atom at-robot(loc-x18-y11)
Atom at-robot(loc-x18-y12)
Atom at-robot(loc-x18-y13)
Atom at-robot(loc-x18-y14)
Atom at-robot(loc-x18-y15)
Atom at-robot(loc-x18-y16)
Atom at-robot(loc-x18-y17)
Atom at-robot(loc-x18-y18)
Atom at-robot(loc-x18-y19)
Atom at-robot(loc-x18-y2)
Atom at-robot(loc-x18-y20)
Atom at-robot(loc-x18-y21)
Atom at-robot(loc-x18-y22)
Atom at-robot(loc-x18-y23)
Atom at-robot(loc-x18-y24)
Atom at-robot(loc-x18-y25)
Atom at-robot(loc-x18-y3)
Atom at-robot(loc-x18-y4)
Atom at-robot(loc-x18-y5)
Atom at-robot(loc-x18-y6)
Atom at-robot(loc-x18-y7)
Atom at-robot(loc-x18-y8)
Atom at-robot(loc-x18-y9)
Atom at-robot(loc-x19-y0)
Atom at-robot(loc-x19-y1)
Atom at-robot(loc-x19-y10)
Atom at-robot(loc-x19-y11)
Atom at-robot(loc-x19-y12)
Atom at-robot(loc-x19-y13)
Atom at-robot(loc-x19-y14)
Atom at-robot(loc-x19-y15)
Atom at-robot(loc-x19-y16)
Atom at-robot(loc-x19-y17)
Atom at-robot(loc-x19-y18)
Atom at-robot(loc-x19-y19)
Atom at-robot(loc-x19-y2)
Atom at-robot(loc-x19-y20)
Atom at-robot(loc-x19-y21)
Atom at-robot(loc-x19-y22)
Atom at-robot(loc-x19-y23)
Atom at-robot(loc-x19-y24)
Atom at-robot(loc-x19-y25)
Atom at-robot(loc-x19-y3)
Atom at-robot(loc-x19-y4)
Atom at-robot(loc-x19-y5)
Atom at-robot(loc-x19-y6)
Atom at-robot(loc-x19-y7)
Atom at-robot(loc-x19-y8)
Atom at-robot(loc-x19-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y17)
Atom at-robot(loc-x2-y18)
Atom at-robot(loc-x2-y19)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y20)
Atom at-robot(loc-x2-y21)
Atom at-robot(loc-x2-y22)
Atom at-robot(loc-x2-y23)
Atom at-robot(loc-x2-y24)
Atom at-robot(loc-x2-y25)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x20-y0)
Atom at-robot(loc-x20-y1)
Atom at-robot(loc-x20-y10)
Atom at-robot(loc-x20-y11)
Atom at-robot(loc-x20-y12)
Atom at-robot(loc-x20-y13)
Atom at-robot(loc-x20-y14)
Atom at-robot(loc-x20-y15)
Atom at-robot(loc-x20-y16)
Atom at-robot(loc-x20-y17)
Atom at-robot(loc-x20-y18)
Atom at-robot(loc-x20-y19)
Atom at-robot(loc-x20-y2)
Atom at-robot(loc-x20-y20)
Atom at-robot(loc-x20-y21)
Atom at-robot(loc-x20-y22)
Atom at-robot(loc-x20-y23)
Atom at-robot(loc-x20-y24)
Atom at-robot(loc-x20-y25)
Atom at-robot(loc-x20-y3)
Atom at-robot(loc-x20-y4)
Atom at-robot(loc-x20-y5)
Atom at-robot(loc-x20-y6)
Atom at-robot(loc-x20-y7)
Atom at-robot(loc-x20-y8)
Atom at-robot(loc-x20-y9)
Atom at-robot(loc-x21-y0)
Atom at-robot(loc-x21-y1)
Atom at-robot(loc-x21-y10)
Atom at-robot(loc-x21-y11)
Atom at-robot(loc-x21-y12)
Atom at-robot(loc-x21-y13)
Atom at-robot(loc-x21-y14)
Atom at-robot(loc-x21-y15)
Atom at-robot(loc-x21-y16)
Atom at-robot(loc-x21-y17)
Atom at-robot(loc-x21-y18)
Atom at-robot(loc-x21-y19)
Atom at-robot(loc-x21-y2)
Atom at-robot(loc-x21-y20)
Atom at-robot(loc-x21-y21)
Atom at-robot(loc-x21-y22)
Atom at-robot(loc-x21-y23)
Atom at-robot(loc-x21-y24)
Atom at-robot(loc-x21-y25)
Atom at-robot(loc-x21-y3)
Atom at-robot(loc-x21-y4)
Atom at-robot(loc-x21-y5)
Atom at-robot(loc-x21-y6)
Atom at-robot(loc-x21-y7)
Atom at-robot(loc-x21-y8)
Atom at-robot(loc-x21-y9)
Atom at-robot(loc-x22-y0)
Atom at-robot(loc-x22-y1)
Atom at-robot(loc-x22-y10)
Atom at-robot(loc-x22-y11)
Atom at-robot(loc-x22-y12)
Atom at-robot(loc-x22-y13)
Atom at-robot(loc-x22-y14)
Atom at-robot(loc-x22-y15)
Atom at-robot(loc-x22-y16)
Atom at-robot(loc-x22-y17)
Atom at-robot(loc-x22-y18)
Atom at-robot(loc-x22-y19)
Atom at-robot(loc-x22-y2)
Atom at-robot(loc-x22-y20)
Atom at-robot(loc-x22-y21)
Atom at-robot(loc-x22-y22)
Atom at-robot(loc-x22-y23)
Atom at-robot(loc-x22-y24)
Atom at-robot(loc-x22-y25)
Atom at-robot(loc-x22-y3)
Atom at-robot(loc-x22-y4)
Atom at-robot(loc-x22-y5)
Atom at-robot(loc-x22-y6)
Atom at-robot(loc-x22-y7)
Atom at-robot(loc-x22-y8)
Atom at-robot(loc-x22-y9)
Atom at-robot(loc-x23-y0)
Atom at-robot(loc-x23-y1)
Atom at-robot(loc-x23-y10)
Atom at-robot(loc-x23-y11)
Atom at-robot(loc-x23-y12)
Atom at-robot(loc-x23-y13)
Atom at-robot(loc-x23-y14)
Atom at-robot(loc-x23-y15)
Atom at-robot(loc-x23-y16)
Atom at-robot(loc-x23-y17)
Atom at-robot(loc-x23-y18)
Atom at-robot(loc-x23-y19)
Atom at-robot(loc-x23-y2)
Atom at-robot(loc-x23-y20)
Atom at-robot(loc-x23-y21)
Atom at-robot(loc-x23-y22)
Atom at-robot(loc-x23-y23)
Atom at-robot(loc-x23-y24)
Atom at-robot(loc-x23-y25)
Atom at-robot(loc-x23-y3)
Atom at-robot(loc-x23-y4)
Atom at-robot(loc-x23-y5)
Atom at-robot(loc-x23-y6)
Atom at-robot(loc-x23-y7)
Atom at-robot(loc-x23-y8)
Atom at-robot(loc-x23-y9)
Atom at-robot(loc-x24-y0)
Atom at-robot(loc-x24-y1)
Atom at-robot(loc-x24-y10)
Atom at-robot(loc-x24-y11)
Atom at-robot(loc-x24-y12)
Atom at-robot(loc-x24-y13)
Atom at-robot(loc-x24-y14)
Atom at-robot(loc-x24-y15)
Atom at-robot(loc-x24-y16)
Atom at-robot(loc-x24-y17)
Atom at-robot(loc-x24-y18)
Atom at-robot(loc-x24-y19)
Atom at-robot(loc-x24-y2)
Atom at-robot(loc-x24-y20)
Atom at-robot(loc-x24-y21)
Atom at-robot(loc-x24-y22)
Atom at-robot(loc-x24-y23)
Atom at-robot(loc-x24-y24)
Atom at-robot(loc-x24-y25)
Atom at-robot(loc-x24-y3)
Atom at-robot(loc-x24-y4)
Atom at-robot(loc-x24-y5)
Atom at-robot(loc-x24-y6)
Atom at-robot(loc-x24-y7)
Atom at-robot(loc-x24-y8)
Atom at-robot(loc-x24-y9)
Atom at-robot(loc-x25-y0)
Atom at-robot(loc-x25-y1)
Atom at-robot(loc-x25-y10)
Atom at-robot(loc-x25-y11)
Atom at-robot(loc-x25-y12)
Atom at-robot(loc-x25-y13)
Atom at-robot(loc-x25-y14)
Atom at-robot(loc-x25-y15)
Atom at-robot(loc-x25-y16)
Atom at-robot(loc-x25-y17)
Atom at-robot(loc-x25-y18)
Atom at-robot(loc-x25-y19)
Atom at-robot(loc-x25-y2)
Atom at-robot(loc-x25-y20)
Atom at-robot(loc-x25-y21)
Atom at-robot(loc-x25-y22)
Atom at-robot(loc-x25-y23)
Atom at-robot(loc-x25-y24)
Atom at-robot(loc-x25-y25)
Atom at-robot(loc-x25-y3)
Atom at-robot(loc-x25-y4)
Atom at-robot(loc-x25-y5)
Atom at-robot(loc-x25-y6)
Atom at-robot(loc-x25-y7)
Atom at-robot(loc-x25-y8)
Atom at-robot(loc-x25-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y17)
Atom at-robot(loc-x3-y18)
Atom at-robot(loc-x3-y19)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y20)
Atom at-robot(loc-x3-y21)
Atom at-robot(loc-x3-y22)
Atom at-robot(loc-x3-y23)
Atom at-robot(loc-x3-y24)
Atom at-robot(loc-x3-y25)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y17)
Atom at-robot(loc-x4-y18)
Atom at-robot(loc-x4-y19)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y20)
Atom at-robot(loc-x4-y21)
Atom at-robot(loc-x4-y22)
Atom at-robot(loc-x4-y23)
Atom at-robot(loc-x4-y24)
Atom at-robot(loc-x4-y25)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y17)
Atom at-robot(loc-x5-y18)
Atom at-robot(loc-x5-y19)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y20)
Atom at-robot(loc-x5-y21)
Atom at-robot(loc-x5-y22)
Atom at-robot(loc-x5-y23)
Atom at-robot(loc-x5-y24)
Atom at-robot(loc-x5-y25)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y17)
Atom at-robot(loc-x6-y18)
Atom at-robot(loc-x6-y19)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y20)
Atom at-robot(loc-x6-y21)
Atom at-robot(loc-x6-y22)
Atom at-robot(loc-x6-y23)
Atom at-robot(loc-x6-y24)
Atom at-robot(loc-x6-y25)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y17)
Atom at-robot(loc-x7-y18)
Atom at-robot(loc-x7-y19)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y20)
Atom at-robot(loc-x7-y21)
Atom at-robot(loc-x7-y22)
Atom at-robot(loc-x7-y23)
Atom at-robot(loc-x7-y24)
Atom at-robot(loc-x7-y25)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y17)
Atom at-robot(loc-x8-y18)
Atom at-robot(loc-x8-y19)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y20)
Atom at-robot(loc-x8-y21)
Atom at-robot(loc-x8-y22)
Atom at-robot(loc-x8-y23)
Atom at-robot(loc-x8-y24)
Atom at-robot(loc-x8-y25)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y17)
Atom at-robot(loc-x9-y18)
Atom at-robot(loc-x9-y19)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y20)
Atom at-robot(loc-x9-y21)
Atom at-robot(loc-x9-y22)
Atom at-robot(loc-x9-y23)
Atom at-robot(loc-x9-y24)
Atom at-robot(loc-x9-y25)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var675
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var674
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var673
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var672
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var671
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var670
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var669
-1
2
Atom visited(loc-x0-y14)
NegatedAtom visited(loc-x0-y14)
end_variable
begin_variable
var668
-1
2
Atom visited(loc-x0-y15)
NegatedAtom visited(loc-x0-y15)
end_variable
begin_variable
var667
-1
2
Atom visited(loc-x0-y16)
NegatedAtom visited(loc-x0-y16)
end_variable
begin_variable
var666
-1
2
Atom visited(loc-x0-y17)
NegatedAtom visited(loc-x0-y17)
end_variable
begin_variable
var665
-1
2
Atom visited(loc-x0-y18)
NegatedAtom visited(loc-x0-y18)
end_variable
begin_variable
var664
-1
2
Atom visited(loc-x0-y19)
NegatedAtom visited(loc-x0-y19)
end_variable
begin_variable
var663
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var662
-1
2
Atom visited(loc-x0-y20)
NegatedAtom visited(loc-x0-y20)
end_variable
begin_variable
var661
-1
2
Atom visited(loc-x0-y21)
NegatedAtom visited(loc-x0-y21)
end_variable
begin_variable
var660
-1
2
Atom visited(loc-x0-y22)
NegatedAtom visited(loc-x0-y22)
end_variable
begin_variable
var659
-1
2
Atom visited(loc-x0-y23)
NegatedAtom visited(loc-x0-y23)
end_variable
begin_variable
var658
-1
2
Atom visited(loc-x0-y24)
NegatedAtom visited(loc-x0-y24)
end_variable
begin_variable
var657
-1
2
Atom visited(loc-x0-y25)
NegatedAtom visited(loc-x0-y25)
end_variable
begin_variable
var656
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var655
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var654
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var653
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var652
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var651
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var650
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var649
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var648
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var647
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var646
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var645
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var644
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var643
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var642
-1
2
Atom visited(loc-x1-y15)
NegatedAtom visited(loc-x1-y15)
end_variable
begin_variable
var641
-1
2
Atom visited(loc-x1-y16)
NegatedAtom visited(loc-x1-y16)
end_variable
begin_variable
var640
-1
2
Atom visited(loc-x1-y17)
NegatedAtom visited(loc-x1-y17)
end_variable
begin_variable
var639
-1
2
Atom visited(loc-x1-y18)
NegatedAtom visited(loc-x1-y18)
end_variable
begin_variable
var638
-1
2
Atom visited(loc-x1-y19)
NegatedAtom visited(loc-x1-y19)
end_variable
begin_variable
var637
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var636
-1
2
Atom visited(loc-x1-y20)
NegatedAtom visited(loc-x1-y20)
end_variable
begin_variable
var635
-1
2
Atom visited(loc-x1-y21)
NegatedAtom visited(loc-x1-y21)
end_variable
begin_variable
var634
-1
2
Atom visited(loc-x1-y22)
NegatedAtom visited(loc-x1-y22)
end_variable
begin_variable
var633
-1
2
Atom visited(loc-x1-y23)
NegatedAtom visited(loc-x1-y23)
end_variable
begin_variable
var632
-1
2
Atom visited(loc-x1-y24)
NegatedAtom visited(loc-x1-y24)
end_variable
begin_variable
var631
-1
2
Atom visited(loc-x1-y25)
NegatedAtom visited(loc-x1-y25)
end_variable
begin_variable
var630
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var629
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(loc-x1-y4)
end_variable
begin_variable
var628
-1
2
Atom visited(loc-x1-y5)
NegatedAtom visited(loc-x1-y5)
end_variable
begin_variable
var627
-1
2
Atom visited(loc-x1-y6)
NegatedAtom visited(loc-x1-y6)
end_variable
begin_variable
var626
-1
2
Atom visited(loc-x1-y7)
NegatedAtom visited(loc-x1-y7)
end_variable
begin_variable
var625
-1
2
Atom visited(loc-x1-y8)
NegatedAtom visited(loc-x1-y8)
end_variable
begin_variable
var624
-1
2
Atom visited(loc-x1-y9)
NegatedAtom visited(loc-x1-y9)
end_variable
begin_variable
var623
-1
2
Atom visited(loc-x10-y0)
NegatedAtom visited(loc-x10-y0)
end_variable
begin_variable
var622
-1
2
Atom visited(loc-x10-y1)
NegatedAtom visited(loc-x10-y1)
end_variable
begin_variable
var621
-1
2
Atom visited(loc-x10-y10)
NegatedAtom visited(loc-x10-y10)
end_variable
begin_variable
var620
-1
2
Atom visited(loc-x10-y11)
NegatedAtom visited(loc-x10-y11)
end_variable
begin_variable
var619
-1
2
Atom visited(loc-x10-y12)
NegatedAtom visited(loc-x10-y12)
end_variable
begin_variable
var618
-1
2
Atom visited(loc-x10-y13)
NegatedAtom visited(loc-x10-y13)
end_variable
begin_variable
var617
-1
2
Atom visited(loc-x10-y14)
NegatedAtom visited(loc-x10-y14)
end_variable
begin_variable
var616
-1
2
Atom visited(loc-x10-y15)
NegatedAtom visited(loc-x10-y15)
end_variable
begin_variable
var615
-1
2
Atom visited(loc-x10-y16)
NegatedAtom visited(loc-x10-y16)
end_variable
begin_variable
var614
-1
2
Atom visited(loc-x10-y17)
NegatedAtom visited(loc-x10-y17)
end_variable
begin_variable
var613
-1
2
Atom visited(loc-x10-y18)
NegatedAtom visited(loc-x10-y18)
end_variable
begin_variable
var612
-1
2
Atom visited(loc-x10-y19)
NegatedAtom visited(loc-x10-y19)
end_variable
begin_variable
var611
-1
2
Atom visited(loc-x10-y2)
NegatedAtom visited(loc-x10-y2)
end_variable
begin_variable
var610
-1
2
Atom visited(loc-x10-y20)
NegatedAtom visited(loc-x10-y20)
end_variable
begin_variable
var609
-1
2
Atom visited(loc-x10-y21)
NegatedAtom visited(loc-x10-y21)
end_variable
begin_variable
var608
-1
2
Atom visited(loc-x10-y22)
NegatedAtom visited(loc-x10-y22)
end_variable
begin_variable
var607
-1
2
Atom visited(loc-x10-y23)
NegatedAtom visited(loc-x10-y23)
end_variable
begin_variable
var606
-1
2
Atom visited(loc-x10-y24)
NegatedAtom visited(loc-x10-y24)
end_variable
begin_variable
var605
-1
2
Atom visited(loc-x10-y25)
NegatedAtom visited(loc-x10-y25)
end_variable
begin_variable
var604
-1
2
Atom visited(loc-x10-y3)
NegatedAtom visited(loc-x10-y3)
end_variable
begin_variable
var603
-1
2
Atom visited(loc-x10-y4)
NegatedAtom visited(loc-x10-y4)
end_variable
begin_variable
var602
-1
2
Atom visited(loc-x10-y5)
NegatedAtom visited(loc-x10-y5)
end_variable
begin_variable
var601
-1
2
Atom visited(loc-x10-y6)
NegatedAtom visited(loc-x10-y6)
end_variable
begin_variable
var600
-1
2
Atom visited(loc-x10-y7)
NegatedAtom visited(loc-x10-y7)
end_variable
begin_variable
var599
-1
2
Atom visited(loc-x10-y8)
NegatedAtom visited(loc-x10-y8)
end_variable
begin_variable
var598
-1
2
Atom visited(loc-x10-y9)
NegatedAtom visited(loc-x10-y9)
end_variable
begin_variable
var597
-1
2
Atom visited(loc-x11-y0)
NegatedAtom visited(loc-x11-y0)
end_variable
begin_variable
var596
-1
2
Atom visited(loc-x11-y1)
NegatedAtom visited(loc-x11-y1)
end_variable
begin_variable
var




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1 loc-x6-y0
0
2
0 0 573 572
0 572 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x6-y2
0
2
0 0 573 584
0 584 -1 0
1
end_operator
begin_operator
move loc-x6-y1 loc-x7-y1
0
2
0 0 573 599
0 599 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x5-y10
0
2
0 0 574 548
0 548 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y11
0
2
0 0 574 575
0 575 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x6-y9
0
2
0 0 574 597
0 597 -1 0
1
end_operator
begin_operator
move loc-x6-y10 loc-x7-y10
0
2
0 0 574 600
0 600 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x5-y11
0
2
0 0 575 549
0 549 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y10
0
2
0 0 575 574
0 574 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x6-y12
0
2
0 0 575 576
0 576 -1 0
1
end_operator
begin_operator
move loc-x6-y11 loc-x7-y11
0
2
0 0 575 601
0 601 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x5-y12
0
2
0 0 576 550
0 550 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y11
0
2
0 0 576 575
0 575 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x6-y13
0
2
0 0 576 577
0 577 -1 0
1
end_operator
begin_operator
move loc-x6-y12 loc-x7-y12
0
2
0 0 576 602
0 602 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x5-y13
0
2
0 0 577 551
0 551 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y12
0
2
0 0 577 576
0 576 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x6-y14
0
2
0 0 577 578
0 578 -1 0
1
end_operator
begin_operator
move loc-x6-y13 loc-x7-y13
0
2
0 0 577 603
0 603 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x5-y14
0
2
0 0 578 552
0 552 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y13
0
2
0 0 578 577
0 577 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x6-y15
0
2
0 0 578 579
0 579 -1 0
1
end_operator
begin_operator
move loc-x6-y14 loc-x7-y14
0
2
0 0 578 604
0 604 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x5-y15
0
2
0 0 579 553
0 553 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y14
0
2
0 0 579 578
0 578 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x6-y16
0
2
0 0 579 580
0 580 -1 0
1
end_operator
begin_operator
move loc-x6-y15 loc-x7-y15
0
2
0 0 579 605
0 605 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x5-y16
0
2
0 0 580 554
0 554 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x6-y15
0
2
0 0 580 579
0 579 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x6-y17
0
2
0 0 580 581
0 581 -1 0
1
end_operator
begin_operator
move loc-x6-y16 loc-x7-y16
0
2
0 0 580 606
0 606 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x5-y17
0
2
0 0 581 555
0 555 -1 0
1
end_operator
begin_operator
move loc-x6-y17 loc-x7-y17
0
2
0 0 581 607
0 607 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x5-y18
0
2
0 0 582 556
0 556 -1 0
1
end_operator
begin_operator
move loc-x6-y18 loc-x7-y18
0
2
0 0 582 608
0 608 -1 0
1
end_operator
begin_operator
move loc-x6-y19 loc-x5-y19
0
2
0 0 583 557
0 557 -1 0
1
end_operator
begin_operator
move loc-x6-y19 loc-x7-y19
0
2
0 0 583 609
0 609 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x5-y2
0
2
0 0 584 558
0 558 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y1
0
2
0 0 584 573
0 573 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x6-y3
0
2
0 0 584 591
0 591 -1 0
1
end_operator
begin_operator
move loc-x6-y2 loc-x7-y2
0
2
0 0 584 610
0 610 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x5-y20
0
2
0 0 585 559
0 559 -1 0
1
end_operator
begin_operator
move loc-x6-y20 loc-x7-y20
0
2
0 0 585 611
0 611 -1 0
1
end_operator
begin_operator
move loc-x6-y21 loc-x5-y21
0
2
0 0 586 560
0 560 -1 0
1
end_operator
begin_operator
move loc-x6-y21 loc-x7-y21
0
2
0 0 586 612
0 612 -1 0
1
end_operator
begin_operator
move loc-x6-y22 loc-x5-y22
0
2
0 0 587 561
0 561 -1 0
1
end_operator
begin_operator
move loc-x6-y22 loc-x7-y22
0
2
0 0 587 613
0 613 -1 0
1
end_operator
begin_operator
move loc-x6-y23 loc-x5-y23
0
2
0 0 588 562
0 562 -1 0
1
end_operator
begin_operator
move loc-x6-y23 loc-x7-y23
0
2
0 0 588 614
0 614 -1 0
1
end_operator
begin_operator
move loc-x6-y24 loc-x5-y24
0
2
0 0 589 563
0 563 -1 0
1
end_operator
begin_operator
move loc-x6-y24 loc-x7-y24
0
2
0 0 589 615
0 615 -1 0
1
end_operator
begin_operator
move loc-x6-y25 loc-x5-y25
0
2
0 0 590 564
0 564 -1 0
1
end_operator
begin_operator
move loc-x6-y25 loc-x7-y25
0
2
0 0 590 616
0 616 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x5-y3
0
2
0 0 591 565
0 565 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y2
0
2
0 0 591 584
0 584 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x6-y4
0
2
0 0 591 592
0 592 -1 0
1
end_operator
begin_operator
move loc-x6-y3 loc-x7-y3
0
2
0 0 591 617
0 617 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x5-y4
0
2
0 0 592 566
0 566 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y3
0
2
0 0 592 591
0 591 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x6-y5
0
2
0 0 592 593
0 593 -1 0
1
end_operator
begin_operator
move loc-x6-y4 loc-x7-y4
0
2
0 0 592 618
0 618 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x5-y5
0
2
0 0 593 567
0 567 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y4
0
2
0 0 593 592
0 592 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x6-y6
0
2
0 0 593 594
0 594 -1 0
1
end_operator
begin_operator
move loc-x6-y5 loc-x7-y5
0
2
0 0 593 619
0 619 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x5-y6
0
2
0 0 594 568
0 568 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y5
0
2
0 0 594 593
0 593 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x6-y7
0
2
0 0 594 595
0 595 -1 0
1
end_operator
begin_operator
move loc-x6-y6 loc-x7-y6
0
2
0 0 594 620
0 620 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x5-y7
0
2
0 0 595 569
0 569 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y6
0
2
0 0 595 594
0 594 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x6-y8
0
2
0 0 595 596
0 596 -1 0
1
end_operator
begin_operator
move loc-x6-y7 loc-x7-y7
0
2
0 0 595 621
0 621 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x5-y8
0
2
0 0 596 570
0 570 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y7
0
2
0 0 596 595
0 595 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x6-y9
0
2
0 0 596 597
0 597 -1 0
1
end_operator
begin_operator
move loc-x6-y8 loc-x7-y8
0
2
0 0 596 622
0 622 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x5-y9
0
2
0 0 597 571
0 571 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y10
0
2
0 0 597 574
0 574 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x6-y8
0
2
0 0 597 596
0 596 -1 0
1
end_operator
begin_operator
move loc-x6-y9 loc-x7-y9
0
2
0 0 597 623
0 623 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x6-y0
0
2
0 0 598 572
0 572 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x7-y1
0
2
0 0 598 599
0 599 -1 0
1
end_operator
begin_operator
move loc-x7-y0 loc-x8-y0
0
2
0 0 598 624
0 624 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x6-y1
0
2
0 0 599 573
0 573 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y0
0
2
0 0 599 598
0 598 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x7-y2
0
2
0 0 599 610
0 610 -1 0
1
end_operator
begin_operator
move loc-x7-y1 loc-x8-y1
0
2
0 0 599 625
0 625 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x6-y10
0
2
0 0 600 574
0 574 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y11
0
2
0 0 600 601
0 601 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x7-y9
0
2
0 0 600 623
0 623 -1 0
1
end_operator
begin_operator
move loc-x7-y10 loc-x8-y10
0
2
0 0 600 626
0 626 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x6-y11
0
2
0 0 601 575
0 575 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y10
0
2
0 0 601 600
0 600 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x7-y12
0
2
0 0 601 602
0 602 -1 0
1
end_operator
begin_operator
move loc-x7-y11 loc-x8-y11
0
2
0 0 601 627
0 627 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x6-y12
0
2
0 0 602 576
0 576 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y11
0
2
0 0 602 601
0 601 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x7-y13
0
2
0 0 602 603
0 603 -1 0
1
end_operator
begin_operator
move loc-x7-y12 loc-x8-y12
0
2
0 0 602 628
0 628 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x6-y13
0
2
0 0 603 577
0 577 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y12
0
2
0 0 603 602
0 602 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x7-y14
0
2
0 0 603 604
0 604 -1 0
1
end_operator
begin_operator
move loc-x7-y13 loc-x8-y13
0
2
0 0 603 629
0 629 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 604 578
0 578 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 604 603
0 603 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y15
0
2
0 0 604 605
0 605 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 604 630
0 630 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x6-y15
0
2
0 0 605 579
0 579 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y14
0
2
0 0 605 604
0 604 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y16
0
2
0 0 605 606
0 606 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x8-y15
0
2
0 0 605 631
0 631 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x6-y16
0
2
0 0 606 580
0 580 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x8-y16
0
2
0 0 606 632
0 632 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x6-y17
0
2
0 0 607 581
0 581 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x8-y17
0
2
0 0 607 633
0 633 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x6-y18
0
2
0 0 608 582
0 582 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x8-y18
0
2
0 0 608 634
0 634 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x6-y19
0
2
0 0 609 583
0 583 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x8-y19
0
2
0 0 609 635
0 635 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 610 584
0 584 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 610 599
0 599 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 610 617
0 617 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 610 636
0 636 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x6-y20
0
2
0 0 611 585
0 585 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x8-y20
0
2
0 0 611 637
0 637 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x6-y21
0
2
0 0 612 586
0 586 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x8-y21
0
2
0 0 612 638
0 638 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x6-y22
0
2
0 0 613 587
0 587 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x8-y22
0
2
0 0 613 639
0 639 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x6-y23
0
2
0 0 614 588
0 588 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x8-y23
0
2
0 0 614 640
0 640 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x6-y24
0
2
0 0 615 589
0 589 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x8-y24
0
2
0 0 615 641
0 641 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x6-y25
0
2
0 0 616 590
0 590 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x8-y25
0
2
0 0 616 642
0 642 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 617 591
0 591 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 617 610
0 610 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 617 618
0 618 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 617 643
0 643 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 618 592
0 592 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 618 617
0 617 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 618 619
0 619 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 618 644
0 644 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 619 593
0 593 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 619 618
0 618 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 619 620
0 620 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 619 645
0 645 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 620 594
0 594 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 620 619
0 619 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 620 621
0 621 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 620 646
0 646 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 621 595
0 595 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 621 620
0 620 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 621 622
0 622 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 621 647
0 647 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 622 596
0 596 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 622 621
0 621 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 622 623
0 623 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 622 648
0 648 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 623 597
0 597 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 623 600
0 600 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 623 622
0 622 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 623 649
0 649 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 624 598
0 598 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 624 625
0 625 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 624 650
0 650 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 625 599
0 599 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 625 624
0 624 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 625 636
0 636 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 625 651
0 651 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 626 600
0 600 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 626 627
0 627 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 626 649
0 649 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 626 652
0 652 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 627 601
0 601 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 627 626
0 626 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 627 628
0 628 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 627 653
0 653 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 628 602
0 602 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 628 627
0 627 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 628 629
0 629 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 628 654
0 654 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 629 603
0 603 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 629 628
0 628 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 629 630
0 630 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 629 655
0 655 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 630 604
0 604 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 630 629
0 629 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 630 631
0 631 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 630 656
0 656 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 631 605
0 605 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 631 657
0 657 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 632 606
0 606 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 632 658
0 658 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x7-y17
0
2
0 0 633 607
0 607 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x9-y17
0
2
0 0 633 659
0 659 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x7-y18
0
2
0 0 634 608
0 608 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x9-y18
0
2
0 0 634 660
0 660 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x7-y19
0
2
0 0 635 609
0 609 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x9-y19
0
2
0 0 635 661
0 661 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 636 610
0 610 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 636 625
0 625 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 636 643
0 643 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 636 662
0 662 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x7-y20
0
2
0 0 637 611
0 611 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x9-y20
0
2
0 0 637 663
0 663 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x7-y21
0
2
0 0 638 612
0 612 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x9-y21
0
2
0 0 638 664
0 664 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x7-y22
0
2
0 0 639 613
0 613 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x9-y22
0
2
0 0 639 665
0 665 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x7-y23
0
2
0 0 640 614
0 614 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x9-y23
0
2
0 0 640 666
0 666 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x7-y24
0
2
0 0 641 615
0 615 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x9-y24
0
2
0 0 641 667
0 667 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x7-y25
0
2
0 0 642 616
0 616 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x9-y25
0
2
0 0 642 668
0 668 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 643 617
0 617 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 643 636
0 636 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 643 644
0 644 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 643 669
0 669 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 644 618
0 618 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 644 643
0 643 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 644 645
0 645 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 644 670
0 670 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 645 619
0 619 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 645 644
0 644 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 645 646
0 646 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 645 671
0 671 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 646 620
0 620 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 646 645
0 645 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 646 647
0 647 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 646 672
0 672 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 647 621
0 621 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 647 646
0 646 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 647 648
0 648 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 647 673
0 673 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 648 622
0 622 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 648 647
0 647 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 648 649
0 649 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 648 674
0 674 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 649 623
0 623 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 649 626
0 626 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 649 648
0 648 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 649 675
0 675 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 650 52
0 53 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 650 624
0 624 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 650 651
0 651 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 651 53
0 54 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 651 625
0 625 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 651 650
0 650 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 651 662
0 662 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 652 54
0 55 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 652 626
0 626 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 652 653
0 653 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 652 675
0 675 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 653 55
0 56 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 653 627
0 627 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 653 652
0 652 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 653 654
0 654 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 654 56
0 57 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 654 628
0 628 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 654 653
0 653 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 654 655
0 655 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 655 57
0 58 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 656 58
0 59 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 657 59
0 60 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 658 60
0 61 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x10-y17
0
2
0 0 659 61
0 62 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x10-y18
0
2
0 0 660 62
0 63 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x10-y19
0
2
0 0 661 63
0 64 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 662 64
0 65 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 662 636
0 636 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 662 651
0 651 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 662 669
0 669 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x10-y20
0
2
0 0 663 65
0 66 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x10-y21
0
2
0 0 664 66
0 67 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x10-y22
0
2
0 0 665 67
0 68 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x10-y23
0
2
0 0 666 68
0 69 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x10-y24
0
2
0 0 667 69
0 70 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x10-y25
0
2
0 0 668 70
0 71 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 669 71
0 72 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 669 643
0 643 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 669 662
0 662 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 669 670
0 670 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 670 72
0 73 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 670 644
0 644 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 670 669
0 669 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 670 671
0 671 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 671 73
0 74 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 671 645
0 645 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 671 670
0 670 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 671 672
0 672 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 672 74
0 75 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 672 646
0 646 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 672 671
0 671 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 672 673
0 673 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 673 75
0 76 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 673 647
0 647 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 673 672
0 672 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 673 674
0 674 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 674 76
0 77 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 674 648
0 648 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 674 673
0 673 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 674 675
0 675 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 675 77
0 78 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 675 649
0 649 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 675 652
0 652 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 675 674
0 674 -1 0
1
end_operator
0
