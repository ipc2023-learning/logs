begin_version
3
end_version
begin_metric
0
end_metric
784
begin_variable
var0
-1
784
Atom at-robot(loc-x0-y0)
Atom at-robot(loc-x0-y1)
Atom at-robot(loc-x0-y10)
Atom at-robot(loc-x0-y11)
Atom at-robot(loc-x0-y12)
Atom at-robot(loc-x0-y13)
Atom at-robot(loc-x0-y14)
Atom at-robot(loc-x0-y15)
Atom at-robot(loc-x0-y16)
Atom at-robot(loc-x0-y17)
Atom at-robot(loc-x0-y18)
Atom at-robot(loc-x0-y19)
Atom at-robot(loc-x0-y2)
Atom at-robot(loc-x0-y20)
Atom at-robot(loc-x0-y21)
Atom at-robot(loc-x0-y22)
Atom at-robot(loc-x0-y23)
Atom at-robot(loc-x0-y24)
Atom at-robot(loc-x0-y25)
Atom at-robot(loc-x0-y26)
Atom at-robot(loc-x0-y27)
Atom at-robot(loc-x0-y3)
Atom at-robot(loc-x0-y4)
Atom at-robot(loc-x0-y5)
Atom at-robot(loc-x0-y6)
Atom at-robot(loc-x0-y7)
Atom at-robot(loc-x0-y8)
Atom at-robot(loc-x0-y9)
Atom at-robot(loc-x1-y0)
Atom at-robot(loc-x1-y1)
Atom at-robot(loc-x1-y10)
Atom at-robot(loc-x1-y11)
Atom at-robot(loc-x1-y12)
Atom at-robot(loc-x1-y13)
Atom at-robot(loc-x1-y14)
Atom at-robot(loc-x1-y15)
Atom at-robot(loc-x1-y16)
Atom at-robot(loc-x1-y17)
Atom at-robot(loc-x1-y18)
Atom at-robot(loc-x1-y19)
Atom at-robot(loc-x1-y2)
Atom at-robot(loc-x1-y20)
Atom at-robot(loc-x1-y21)
Atom at-robot(loc-x1-y22)
Atom at-robot(loc-x1-y23)
Atom at-robot(loc-x1-y24)
Atom at-robot(loc-x1-y25)
Atom at-robot(loc-x1-y26)
Atom at-robot(loc-x1-y27)
Atom at-robot(loc-x1-y3)
Atom at-robot(loc-x1-y4)
Atom at-robot(loc-x1-y5)
Atom at-robot(loc-x1-y6)
Atom at-robot(loc-x1-y7)
Atom at-robot(loc-x1-y8)
Atom at-robot(loc-x1-y9)
Atom at-robot(loc-x10-y0)
Atom at-robot(loc-x10-y1)
Atom at-robot(loc-x10-y10)
Atom at-robot(loc-x10-y11)
Atom at-robot(loc-x10-y12)
Atom at-robot(loc-x10-y13)
Atom at-robot(loc-x10-y14)
Atom at-robot(loc-x10-y15)
Atom at-robot(loc-x10-y16)
Atom at-robot(loc-x10-y17)
Atom at-robot(loc-x10-y18)
Atom at-robot(loc-x10-y19)
Atom at-robot(loc-x10-y2)
Atom at-robot(loc-x10-y20)
Atom at-robot(loc-x10-y21)
Atom at-robot(loc-x10-y22)
Atom at-robot(loc-x10-y23)
Atom at-robot(loc-x10-y24)
Atom at-robot(loc-x10-y25)
Atom at-robot(loc-x10-y26)
Atom at-robot(loc-x10-y27)
Atom at-robot(loc-x10-y3)
Atom at-robot(loc-x10-y4)
Atom at-robot(loc-x10-y5)
Atom at-robot(loc-x10-y6)
Atom at-robot(loc-x10-y7)
Atom at-robot(loc-x10-y8)
Atom at-robot(loc-x10-y9)
Atom at-robot(loc-x11-y0)
Atom at-robot(loc-x11-y1)
Atom at-robot(loc-x11-y10)
Atom at-robot(loc-x11-y11)
Atom at-robot(loc-x11-y12)
Atom at-robot(loc-x11-y13)
Atom at-robot(loc-x11-y14)
Atom at-robot(loc-x11-y15)
Atom at-robot(loc-x11-y16)
Atom at-robot(loc-x11-y17)
Atom at-robot(loc-x11-y18)
Atom at-robot(loc-x11-y19)
Atom at-robot(loc-x11-y2)
Atom at-robot(loc-x11-y20)
Atom at-robot(loc-x11-y21)
Atom at-robot(loc-x11-y22)
Atom at-robot(loc-x11-y23)
Atom at-robot(loc-x11-y24)
Atom at-robot(loc-x11-y25)
Atom at-robot(loc-x11-y26)
Atom at-robot(loc-x11-y27)
Atom at-robot(loc-x11-y3)
Atom at-robot(loc-x11-y4)
Atom at-robot(loc-x11-y5)
Atom at-robot(loc-x11-y6)
Atom at-robot(loc-x11-y7)
Atom at-robot(loc-x11-y8)
Atom at-robot(loc-x11-y9)
Atom at-robot(loc-x12-y0)
Atom at-robot(loc-x12-y1)
Atom at-robot(loc-x12-y10)
Atom at-robot(loc-x12-y11)
Atom at-robot(loc-x12-y12)
Atom at-robot(loc-x12-y13)
Atom at-robot(loc-x12-y14)
Atom at-robot(loc-x12-y15)
Atom at-robot(loc-x12-y16)
Atom at-robot(loc-x12-y17)
Atom at-robot(loc-x12-y18)
Atom at-robot(loc-x12-y19)
Atom at-robot(loc-x12-y2)
Atom at-robot(loc-x12-y20)
Atom at-robot(loc-x12-y21)
Atom at-robot(loc-x12-y22)
Atom at-robot(loc-x12-y23)
Atom at-robot(loc-x12-y24)
Atom at-robot(loc-x12-y25)
Atom at-robot(loc-x12-y26)
Atom at-robot(loc-x12-y27)
Atom at-robot(loc-x12-y3)
Atom at-robot(loc-x12-y4)
Atom at-robot(loc-x12-y5)
Atom at-robot(loc-x12-y6)
Atom at-robot(loc-x12-y7)
Atom at-robot(loc-x12-y8)
Atom at-robot(loc-x12-y9)
Atom at-robot(loc-x13-y0)
Atom at-robot(loc-x13-y1)
Atom at-robot(loc-x13-y10)
Atom at-robot(loc-x13-y11)
Atom at-robot(loc-x13-y12)
Atom at-robot(loc-x13-y13)
Atom at-robot(loc-x13-y14)
Atom at-robot(loc-x13-y15)
Atom at-robot(loc-x13-y16)
Atom at-robot(loc-x13-y17)
Atom at-robot(loc-x13-y18)
Atom at-robot(loc-x13-y19)
Atom at-robot(loc-x13-y2)
Atom at-robot(loc-x13-y20)
Atom at-robot(loc-x13-y21)
Atom at-robot(loc-x13-y22)
Atom at-robot(loc-x13-y23)
Atom at-robot(loc-x13-y24)
Atom at-robot(loc-x13-y25)
Atom at-robot(loc-x13-y26)
Atom at-robot(loc-x13-y27)
Atom at-robot(loc-x13-y3)
Atom at-robot(loc-x13-y4)
Atom at-robot(loc-x13-y5)
Atom at-robot(loc-x13-y6)
Atom at-robot(loc-x13-y7)
Atom at-robot(loc-x13-y8)
Atom at-robot(loc-x13-y9)
Atom at-robot(loc-x14-y0)
Atom at-robot(loc-x14-y1)
Atom at-robot(loc-x14-y10)
Atom at-robot(loc-x14-y11)
Atom at-robot(loc-x14-y12)
Atom at-robot(loc-x14-y13)
Atom at-robot(loc-x14-y14)
Atom at-robot(loc-x14-y15)
Atom at-robot(loc-x14-y16)
Atom at-robot(loc-x14-y17)
Atom at-robot(loc-x14-y18)
Atom at-robot(loc-x14-y19)
Atom at-robot(loc-x14-y2)
Atom at-robot(loc-x14-y20)
Atom at-robot(loc-x14-y21)
Atom at-robot(loc-x14-y22)
Atom at-robot(loc-x14-y23)
Atom at-robot(loc-x14-y24)
Atom at-robot(loc-x14-y25)
Atom at-robot(loc-x14-y26)
Atom at-robot(loc-x14-y27)
Atom at-robot(loc-x14-y3)
Atom at-robot(loc-x14-y4)
Atom at-robot(loc-x14-y5)
Atom at-robot(loc-x14-y6)
Atom at-robot(loc-x14-y7)
Atom at-robot(loc-x14-y8)
Atom at-robot(loc-x14-y9)
Atom at-robot(loc-x15-y0)
Atom at-robot(loc-x15-y1)
Atom at-robot(loc-x15-y10)
Atom at-robot(loc-x15-y11)
Atom at-robot(loc-x15-y12)
Atom at-robot(loc-x15-y13)
Atom at-robot(loc-x15-y14)
Atom at-robot(loc-x15-y15)
Atom at-robot(loc-x15-y16)
Atom at-robot(loc-x15-y17)
Atom at-robot(loc-x15-y18)
Atom at-robot(loc-x15-y19)
Atom at-robot(loc-x15-y2)
Atom at-robot(loc-x15-y20)
Atom at-robot(loc-x15-y21)
Atom at-robot(loc-x15-y22)
Atom at-robot(loc-x15-y23)
Atom at-robot(loc-x15-y24)
Atom at-robot(loc-x15-y25)
Atom at-robot(loc-x15-y26)
Atom at-robot(loc-x15-y27)
Atom at-robot(loc-x15-y3)
Atom at-robot(loc-x15-y4)
Atom at-robot(loc-x15-y5)
Atom at-robot(loc-x15-y6)
Atom at-robot(loc-x15-y7)
Atom at-robot(loc-x15-y8)
Atom at-robot(loc-x15-y9)
Atom at-robot(loc-x16-y0)
Atom at-robot(loc-x16-y1)
Atom at-robot(loc-x16-y10)
Atom at-robot(loc-x16-y11)
Atom at-robot(loc-x16-y12)
Atom at-robot(loc-x16-y13)
Atom at-robot(loc-x16-y14)
Atom at-robot(loc-x16-y15)
Atom at-robot(loc-x16-y16)
Atom at-robot(loc-x16-y17)
Atom at-robot(loc-x16-y18)
Atom at-robot(loc-x16-y19)
Atom at-robot(loc-x16-y2)
Atom at-robot(loc-x16-y20)
Atom at-robot(loc-x16-y21)
Atom at-robot(loc-x16-y22)
Atom at-robot(loc-x16-y23)
Atom at-robot(loc-x16-y24)
Atom at-robot(loc-x16-y25)
Atom at-robot(loc-x16-y26)
Atom at-robot(loc-x16-y27)
Atom at-robot(loc-x16-y3)
Atom at-robot(loc-x16-y4)
Atom at-robot(loc-x16-y5)
Atom at-robot(loc-x16-y6)
Atom at-robot(loc-x16-y7)
Atom at-robot(loc-x16-y8)
Atom at-robot(loc-x16-y9)
Atom at-robot(loc-x17-y0)
Atom at-robot(loc-x17-y1)
Atom at-robot(loc-x17-y10)
Atom at-robot(loc-x17-y11)
Atom at-robot(loc-x17-y12)
Atom at-robot(loc-x17-y13)
Atom at-robot(loc-x17-y14)
Atom at-robot(loc-x17-y15)
Atom at-robot(loc-x17-y16)
Atom at-robot(loc-x17-y17)
Atom at-robot(loc-x17-y18)
Atom at-robot(loc-x17-y19)
Atom at-robot(loc-x17-y2)
Atom at-robot(loc-x17-y20)
Atom at-robot(loc-x17-y21)
Atom at-robot(loc-x17-y22)
Atom at-robot(loc-x17-y23)
Atom at-robot(loc-x17-y24)
Atom at-robot(loc-x17-y25)
Atom at-robot(loc-x17-y26)
Atom at-robot(loc-x17-y27)
Atom at-robot(loc-x17-y3)
Atom at-robot(loc-x17-y4)
Atom at-robot(loc-x17-y5)
Atom at-robot(loc-x17-y6)
Atom at-robot(loc-x17-y7)
Atom at-robot(loc-x17-y8)
Atom at-robot(loc-x17-y9)
Atom at-robot(loc-x18-y0)
Atom at-robot(loc-x18-y1)
Atom at-robot(loc-x18-y10)
Atom at-robot(loc-x18-y11)
Atom at-robot(loc-x18-y12)
Atom at-robot(loc-x18-y13)
Atom at-robot(loc-x18-y14)
Atom at-robot(loc-x18-y15)
Atom at-robot(loc-x18-y16)
Atom at-robot(loc-x18-y17)
Atom at-robot(loc-x18-y18)
Atom at-robot(loc-x18-y19)
Atom at-robot(loc-x18-y2)
Atom at-robot(loc-x18-y20)
Atom at-robot(loc-x18-y21)
Atom at-robot(loc-x18-y22)
Atom at-robot(loc-x18-y23)
Atom at-robot(loc-x18-y24)
Atom at-robot(loc-x18-y25)
Atom at-robot(loc-x18-y26)
Atom at-robot(loc-x18-y27)
Atom at-robot(loc-x18-y3)
Atom at-robot(loc-x18-y4)
Atom at-robot(loc-x18-y5)
Atom at-robot(loc-x18-y6)
Atom at-robot(loc-x18-y7)
Atom at-robot(loc-x18-y8)
Atom at-robot(loc-x18-y9)
Atom at-robot(loc-x19-y0)
Atom at-robot(loc-x19-y1)
Atom at-robot(loc-x19-y10)
Atom at-robot(loc-x19-y11)
Atom at-robot(loc-x19-y12)
Atom at-robot(loc-x19-y13)
Atom at-robot(loc-x19-y14)
Atom at-robot(loc-x19-y15)
Atom at-robot(loc-x19-y16)
Atom at-robot(loc-x19-y17)
Atom at-robot(loc-x19-y18)
Atom at-robot(loc-x19-y19)
Atom at-robot(loc-x19-y2)
Atom at-robot(loc-x19-y20)
Atom at-robot(loc-x19-y21)
Atom at-robot(loc-x19-y22)
Atom at-robot(loc-x19-y23)
Atom at-robot(loc-x19-y24)
Atom at-robot(loc-x19-y25)
Atom at-robot(loc-x19-y26)
Atom at-robot(loc-x19-y27)
Atom at-robot(loc-x19-y3)
Atom at-robot(loc-x19-y4)
Atom at-robot(loc-x19-y5)
Atom at-robot(loc-x19-y6)
Atom at-robot(loc-x19-y7)
Atom at-robot(loc-x19-y8)
Atom at-robot(loc-x19-y9)
Atom at-robot(loc-x2-y0)
Atom at-robot(loc-x2-y1)
Atom at-robot(loc-x2-y10)
Atom at-robot(loc-x2-y11)
Atom at-robot(loc-x2-y12)
Atom at-robot(loc-x2-y13)
Atom at-robot(loc-x2-y14)
Atom at-robot(loc-x2-y15)
Atom at-robot(loc-x2-y16)
Atom at-robot(loc-x2-y17)
Atom at-robot(loc-x2-y18)
Atom at-robot(loc-x2-y19)
Atom at-robot(loc-x2-y2)
Atom at-robot(loc-x2-y20)
Atom at-robot(loc-x2-y21)
Atom at-robot(loc-x2-y22)
Atom at-robot(loc-x2-y23)
Atom at-robot(loc-x2-y24)
Atom at-robot(loc-x2-y25)
Atom at-robot(loc-x2-y26)
Atom at-robot(loc-x2-y27)
Atom at-robot(loc-x2-y3)
Atom at-robot(loc-x2-y4)
Atom at-robot(loc-x2-y5)
Atom at-robot(loc-x2-y6)
Atom at-robot(loc-x2-y7)
Atom at-robot(loc-x2-y8)
Atom at-robot(loc-x2-y9)
Atom at-robot(loc-x20-y0)
Atom at-robot(loc-x20-y1)
Atom at-robot(loc-x20-y10)
Atom at-robot(loc-x20-y11)
Atom at-robot(loc-x20-y12)
Atom at-robot(loc-x20-y13)
Atom at-robot(loc-x20-y14)
Atom at-robot(loc-x20-y15)
Atom at-robot(loc-x20-y16)
Atom at-robot(loc-x20-y17)
Atom at-robot(loc-x20-y18)
Atom at-robot(loc-x20-y19)
Atom at-robot(loc-x20-y2)
Atom at-robot(loc-x20-y20)
Atom at-robot(loc-x20-y21)
Atom at-robot(loc-x20-y22)
Atom at-robot(loc-x20-y23)
Atom at-robot(loc-x20-y24)
Atom at-robot(loc-x20-y25)
Atom at-robot(loc-x20-y26)
Atom at-robot(loc-x20-y27)
Atom at-robot(loc-x20-y3)
Atom at-robot(loc-x20-y4)
Atom at-robot(loc-x20-y5)
Atom at-robot(loc-x20-y6)
Atom at-robot(loc-x20-y7)
Atom at-robot(loc-x20-y8)
Atom at-robot(loc-x20-y9)
Atom at-robot(loc-x21-y0)
Atom at-robot(loc-x21-y1)
Atom at-robot(loc-x21-y10)
Atom at-robot(loc-x21-y11)
Atom at-robot(loc-x21-y12)
Atom at-robot(loc-x21-y13)
Atom at-robot(loc-x21-y14)
Atom at-robot(loc-x21-y15)
Atom at-robot(loc-x21-y16)
Atom at-robot(loc-x21-y17)
Atom at-robot(loc-x21-y18)
Atom at-robot(loc-x21-y19)
Atom at-robot(loc-x21-y2)
Atom at-robot(loc-x21-y20)
Atom at-robot(loc-x21-y21)
Atom at-robot(loc-x21-y22)
Atom at-robot(loc-x21-y23)
Atom at-robot(loc-x21-y24)
Atom at-robot(loc-x21-y25)
Atom at-robot(loc-x21-y26)
Atom at-robot(loc-x21-y27)
Atom at-robot(loc-x21-y3)
Atom at-robot(loc-x21-y4)
Atom at-robot(loc-x21-y5)
Atom at-robot(loc-x21-y6)
Atom at-robot(loc-x21-y7)
Atom at-robot(loc-x21-y8)
Atom at-robot(loc-x21-y9)
Atom at-robot(loc-x22-y0)
Atom at-robot(loc-x22-y1)
Atom at-robot(loc-x22-y10)
Atom at-robot(loc-x22-y11)
Atom at-robot(loc-x22-y12)
Atom at-robot(loc-x22-y13)
Atom at-robot(loc-x22-y14)
Atom at-robot(loc-x22-y15)
Atom at-robot(loc-x22-y16)
Atom at-robot(loc-x22-y17)
Atom at-robot(loc-x22-y18)
Atom at-robot(loc-x22-y19)
Atom at-robot(loc-x22-y2)
Atom at-robot(loc-x22-y20)
Atom at-robot(loc-x22-y21)
Atom at-robot(loc-x22-y22)
Atom at-robot(loc-x22-y23)
Atom at-robot(loc-x22-y24)
Atom at-robot(loc-x22-y25)
Atom at-robot(loc-x22-y26)
Atom at-robot(loc-x22-y27)
Atom at-robot(loc-x22-y3)
Atom at-robot(loc-x22-y4)
Atom at-robot(loc-x22-y5)
Atom at-robot(loc-x22-y6)
Atom at-robot(loc-x22-y7)
Atom at-robot(loc-x22-y8)
Atom at-robot(loc-x22-y9)
Atom at-robot(loc-x23-y0)
Atom at-robot(loc-x23-y1)
Atom at-robot(loc-x23-y10)
Atom at-robot(loc-x23-y11)
Atom at-robot(loc-x23-y12)
Atom at-robot(loc-x23-y13)
Atom at-robot(loc-x23-y14)
Atom at-robot(loc-x23-y15)
Atom at-robot(loc-x23-y16)
Atom at-robot(loc-x23-y17)
Atom at-robot(loc-x23-y18)
Atom at-robot(loc-x23-y19)
Atom at-robot(loc-x23-y2)
Atom at-robot(loc-x23-y20)
Atom at-robot(loc-x23-y21)
Atom at-robot(loc-x23-y22)
Atom at-robot(loc-x23-y23)
Atom at-robot(loc-x23-y24)
Atom at-robot(loc-x23-y25)
Atom at-robot(loc-x23-y26)
Atom at-robot(loc-x23-y27)
Atom at-robot(loc-x23-y3)
Atom at-robot(loc-x23-y4)
Atom at-robot(loc-x23-y5)
Atom at-robot(loc-x23-y6)
Atom at-robot(loc-x23-y7)
Atom at-robot(loc-x23-y8)
Atom at-robot(loc-x23-y9)
Atom at-robot(loc-x24-y0)
Atom at-robot(loc-x24-y1)
Atom at-robot(loc-x24-y10)
Atom at-robot(loc-x24-y11)
Atom at-robot(loc-x24-y12)
Atom at-robot(loc-x24-y13)
Atom at-robot(loc-x24-y14)
Atom at-robot(loc-x24-y15)
Atom at-robot(loc-x24-y16)
Atom at-robot(loc-x24-y17)
Atom at-robot(loc-x24-y18)
Atom at-robot(loc-x24-y19)
Atom at-robot(loc-x24-y2)
Atom at-robot(loc-x24-y20)
Atom at-robot(loc-x24-y21)
Atom at-robot(loc-x24-y22)
Atom at-robot(loc-x24-y23)
Atom at-robot(loc-x24-y24)
Atom at-robot(loc-x24-y25)
Atom at-robot(loc-x24-y26)
Atom at-robot(loc-x24-y27)
Atom at-robot(loc-x24-y3)
Atom at-robot(loc-x24-y4)
Atom at-robot(loc-x24-y5)
Atom at-robot(loc-x24-y6)
Atom at-robot(loc-x24-y7)
Atom at-robot(loc-x24-y8)
Atom at-robot(loc-x24-y9)
Atom at-robot(loc-x25-y0)
Atom at-robot(loc-x25-y1)
Atom at-robot(loc-x25-y10)
Atom at-robot(loc-x25-y11)
Atom at-robot(loc-x25-y12)
Atom at-robot(loc-x25-y13)
Atom at-robot(loc-x25-y14)
Atom at-robot(loc-x25-y15)
Atom at-robot(loc-x25-y16)
Atom at-robot(loc-x25-y17)
Atom at-robot(loc-x25-y18)
Atom at-robot(loc-x25-y19)
Atom at-robot(loc-x25-y2)
Atom at-robot(loc-x25-y20)
Atom at-robot(loc-x25-y21)
Atom at-robot(loc-x25-y22)
Atom at-robot(loc-x25-y23)
Atom at-robot(loc-x25-y24)
Atom at-robot(loc-x25-y25)
Atom at-robot(loc-x25-y26)
Atom at-robot(loc-x25-y27)
Atom at-robot(loc-x25-y3)
Atom at-robot(loc-x25-y4)
Atom at-robot(loc-x25-y5)
Atom at-robot(loc-x25-y6)
Atom at-robot(loc-x25-y7)
Atom at-robot(loc-x25-y8)
Atom at-robot(loc-x25-y9)
Atom at-robot(loc-x26-y0)
Atom at-robot(loc-x26-y1)
Atom at-robot(loc-x26-y10)
Atom at-robot(loc-x26-y11)
Atom at-robot(loc-x26-y12)
Atom at-robot(loc-x26-y13)
Atom at-robot(loc-x26-y14)
Atom at-robot(loc-x26-y15)
Atom at-robot(loc-x26-y16)
Atom at-robot(loc-x26-y17)
Atom at-robot(loc-x26-y18)
Atom at-robot(loc-x26-y19)
Atom at-robot(loc-x26-y2)
Atom at-robot(loc-x26-y20)
Atom at-robot(loc-x26-y21)
Atom at-robot(loc-x26-y22)
Atom at-robot(loc-x26-y23)
Atom at-robot(loc-x26-y24)
Atom at-robot(loc-x26-y25)
Atom at-robot(loc-x26-y26)
Atom at-robot(loc-x26-y27)
Atom at-robot(loc-x26-y3)
Atom at-robot(loc-x26-y4)
Atom at-robot(loc-x26-y5)
Atom at-robot(loc-x26-y6)
Atom at-robot(loc-x26-y7)
Atom at-robot(loc-x26-y8)
Atom at-robot(loc-x26-y9)
Atom at-robot(loc-x27-y0)
Atom at-robot(loc-x27-y1)
Atom at-robot(loc-x27-y10)
Atom at-robot(loc-x27-y11)
Atom at-robot(loc-x27-y12)
Atom at-robot(loc-x27-y13)
Atom at-robot(loc-x27-y14)
Atom at-robot(loc-x27-y15)
Atom at-robot(loc-x27-y16)
Atom at-robot(loc-x27-y17)
Atom at-robot(loc-x27-y18)
Atom at-robot(loc-x27-y19)
Atom at-robot(loc-x27-y2)
Atom at-robot(loc-x27-y20)
Atom at-robot(loc-x27-y21)
Atom at-robot(loc-x27-y22)
Atom at-robot(loc-x27-y23)
Atom at-robot(loc-x27-y24)
Atom at-robot(loc-x27-y25)
Atom at-robot(loc-x27-y26)
Atom at-robot(loc-x27-y27)
Atom at-robot(loc-x27-y3)
Atom at-robot(loc-x27-y4)
Atom at-robot(loc-x27-y5)
Atom at-robot(loc-x27-y6)
Atom at-robot(loc-x27-y7)
Atom at-robot(loc-x27-y8)
Atom at-robot(loc-x27-y9)
Atom at-robot(loc-x3-y0)
Atom at-robot(loc-x3-y1)
Atom at-robot(loc-x3-y10)
Atom at-robot(loc-x3-y11)
Atom at-robot(loc-x3-y12)
Atom at-robot(loc-x3-y13)
Atom at-robot(loc-x3-y14)
Atom at-robot(loc-x3-y15)
Atom at-robot(loc-x3-y16)
Atom at-robot(loc-x3-y17)
Atom at-robot(loc-x3-y18)
Atom at-robot(loc-x3-y19)
Atom at-robot(loc-x3-y2)
Atom at-robot(loc-x3-y20)
Atom at-robot(loc-x3-y21)
Atom at-robot(loc-x3-y22)
Atom at-robot(loc-x3-y23)
Atom at-robot(loc-x3-y24)
Atom at-robot(loc-x3-y25)
Atom at-robot(loc-x3-y26)
Atom at-robot(loc-x3-y27)
Atom at-robot(loc-x3-y3)
Atom at-robot(loc-x3-y4)
Atom at-robot(loc-x3-y5)
Atom at-robot(loc-x3-y6)
Atom at-robot(loc-x3-y7)
Atom at-robot(loc-x3-y8)
Atom at-robot(loc-x3-y9)
Atom at-robot(loc-x4-y0)
Atom at-robot(loc-x4-y1)
Atom at-robot(loc-x4-y10)
Atom at-robot(loc-x4-y11)
Atom at-robot(loc-x4-y12)
Atom at-robot(loc-x4-y13)
Atom at-robot(loc-x4-y14)
Atom at-robot(loc-x4-y15)
Atom at-robot(loc-x4-y16)
Atom at-robot(loc-x4-y17)
Atom at-robot(loc-x4-y18)
Atom at-robot(loc-x4-y19)
Atom at-robot(loc-x4-y2)
Atom at-robot(loc-x4-y20)
Atom at-robot(loc-x4-y21)
Atom at-robot(loc-x4-y22)
Atom at-robot(loc-x4-y23)
Atom at-robot(loc-x4-y24)
Atom at-robot(loc-x4-y25)
Atom at-robot(loc-x4-y26)
Atom at-robot(loc-x4-y27)
Atom at-robot(loc-x4-y3)
Atom at-robot(loc-x4-y4)
Atom at-robot(loc-x4-y5)
Atom at-robot(loc-x4-y6)
Atom at-robot(loc-x4-y7)
Atom at-robot(loc-x4-y8)
Atom at-robot(loc-x4-y9)
Atom at-robot(loc-x5-y0)
Atom at-robot(loc-x5-y1)
Atom at-robot(loc-x5-y10)
Atom at-robot(loc-x5-y11)
Atom at-robot(loc-x5-y12)
Atom at-robot(loc-x5-y13)
Atom at-robot(loc-x5-y14)
Atom at-robot(loc-x5-y15)
Atom at-robot(loc-x5-y16)
Atom at-robot(loc-x5-y17)
Atom at-robot(loc-x5-y18)
Atom at-robot(loc-x5-y19)
Atom at-robot(loc-x5-y2)
Atom at-robot(loc-x5-y20)
Atom at-robot(loc-x5-y21)
Atom at-robot(loc-x5-y22)
Atom at-robot(loc-x5-y23)
Atom at-robot(loc-x5-y24)
Atom at-robot(loc-x5-y25)
Atom at-robot(loc-x5-y26)
Atom at-robot(loc-x5-y27)
Atom at-robot(loc-x5-y3)
Atom at-robot(loc-x5-y4)
Atom at-robot(loc-x5-y5)
Atom at-robot(loc-x5-y6)
Atom at-robot(loc-x5-y7)
Atom at-robot(loc-x5-y8)
Atom at-robot(loc-x5-y9)
Atom at-robot(loc-x6-y0)
Atom at-robot(loc-x6-y1)
Atom at-robot(loc-x6-y10)
Atom at-robot(loc-x6-y11)
Atom at-robot(loc-x6-y12)
Atom at-robot(loc-x6-y13)
Atom at-robot(loc-x6-y14)
Atom at-robot(loc-x6-y15)
Atom at-robot(loc-x6-y16)
Atom at-robot(loc-x6-y17)
Atom at-robot(loc-x6-y18)
Atom at-robot(loc-x6-y19)
Atom at-robot(loc-x6-y2)
Atom at-robot(loc-x6-y20)
Atom at-robot(loc-x6-y21)
Atom at-robot(loc-x6-y22)
Atom at-robot(loc-x6-y23)
Atom at-robot(loc-x6-y24)
Atom at-robot(loc-x6-y25)
Atom at-robot(loc-x6-y26)
Atom at-robot(loc-x6-y27)
Atom at-robot(loc-x6-y3)
Atom at-robot(loc-x6-y4)
Atom at-robot(loc-x6-y5)
Atom at-robot(loc-x6-y6)
Atom at-robot(loc-x6-y7)
Atom at-robot(loc-x6-y8)
Atom at-robot(loc-x6-y9)
Atom at-robot(loc-x7-y0)
Atom at-robot(loc-x7-y1)
Atom at-robot(loc-x7-y10)
Atom at-robot(loc-x7-y11)
Atom at-robot(loc-x7-y12)
Atom at-robot(loc-x7-y13)
Atom at-robot(loc-x7-y14)
Atom at-robot(loc-x7-y15)
Atom at-robot(loc-x7-y16)
Atom at-robot(loc-x7-y17)
Atom at-robot(loc-x7-y18)
Atom at-robot(loc-x7-y19)
Atom at-robot(loc-x7-y2)
Atom at-robot(loc-x7-y20)
Atom at-robot(loc-x7-y21)
Atom at-robot(loc-x7-y22)
Atom at-robot(loc-x7-y23)
Atom at-robot(loc-x7-y24)
Atom at-robot(loc-x7-y25)
Atom at-robot(loc-x7-y26)
Atom at-robot(loc-x7-y27)
Atom at-robot(loc-x7-y3)
Atom at-robot(loc-x7-y4)
Atom at-robot(loc-x7-y5)
Atom at-robot(loc-x7-y6)
Atom at-robot(loc-x7-y7)
Atom at-robot(loc-x7-y8)
Atom at-robot(loc-x7-y9)
Atom at-robot(loc-x8-y0)
Atom at-robot(loc-x8-y1)
Atom at-robot(loc-x8-y10)
Atom at-robot(loc-x8-y11)
Atom at-robot(loc-x8-y12)
Atom at-robot(loc-x8-y13)
Atom at-robot(loc-x8-y14)
Atom at-robot(loc-x8-y15)
Atom at-robot(loc-x8-y16)
Atom at-robot(loc-x8-y17)
Atom at-robot(loc-x8-y18)
Atom at-robot(loc-x8-y19)
Atom at-robot(loc-x8-y2)
Atom at-robot(loc-x8-y20)
Atom at-robot(loc-x8-y21)
Atom at-robot(loc-x8-y22)
Atom at-robot(loc-x8-y23)
Atom at-robot(loc-x8-y24)
Atom at-robot(loc-x8-y25)
Atom at-robot(loc-x8-y26)
Atom at-robot(loc-x8-y27)
Atom at-robot(loc-x8-y3)
Atom at-robot(loc-x8-y4)
Atom at-robot(loc-x8-y5)
Atom at-robot(loc-x8-y6)
Atom at-robot(loc-x8-y7)
Atom at-robot(loc-x8-y8)
Atom at-robot(loc-x8-y9)
Atom at-robot(loc-x9-y0)
Atom at-robot(loc-x9-y1)
Atom at-robot(loc-x9-y10)
Atom at-robot(loc-x9-y11)
Atom at-robot(loc-x9-y12)
Atom at-robot(loc-x9-y13)
Atom at-robot(loc-x9-y14)
Atom at-robot(loc-x9-y15)
Atom at-robot(loc-x9-y16)
Atom at-robot(loc-x9-y17)
Atom at-robot(loc-x9-y18)
Atom at-robot(loc-x9-y19)
Atom at-robot(loc-x9-y2)
Atom at-robot(loc-x9-y20)
Atom at-robot(loc-x9-y21)
Atom at-robot(loc-x9-y22)
Atom at-robot(loc-x9-y23)
Atom at-robot(loc-x9-y24)
Atom at-robot(loc-x9-y25)
Atom at-robot(loc-x9-y26)
Atom at-robot(loc-x9-y27)
Atom at-robot(loc-x9-y3)
Atom at-robot(loc-x9-y4)
Atom at-robot(loc-x9-y5)
Atom at-robot(loc-x9-y6)
Atom at-robot(loc-x9-y7)
Atom at-robot(loc-x9-y8)
Atom at-robot(loc-x9-y9)
end_variable
begin_variable
var783
-1
2
Atom visited(loc-x0-y0)
NegatedAtom visited(loc-x0-y0)
end_variable
begin_variable
var782
-1
2
Atom visited(loc-x0-y1)
NegatedAtom visited(loc-x0-y1)
end_variable
begin_variable
var781
-1
2
Atom visited(loc-x0-y10)
NegatedAtom visited(loc-x0-y10)
end_variable
begin_variable
var780
-1
2
Atom visited(loc-x0-y11)
NegatedAtom visited(loc-x0-y11)
end_variable
begin_variable
var779
-1
2
Atom visited(loc-x0-y12)
NegatedAtom visited(loc-x0-y12)
end_variable
begin_variable
var778
-1
2
Atom visited(loc-x0-y13)
NegatedAtom visited(loc-x0-y13)
end_variable
begin_variable
var777
-1
2
Atom visited(loc-x0-y14)
NegatedAtom visited(loc-x0-y14)
end_variable
begin_variable
var776
-1
2
Atom visited(loc-x0-y15)
NegatedAtom visited(loc-x0-y15)
end_variable
begin_variable
var775
-1
2
Atom visited(loc-x0-y16)
NegatedAtom visited(loc-x0-y16)
end_variable
begin_variable
var774
-1
2
Atom visited(loc-x0-y17)
NegatedAtom visited(loc-x0-y17)
end_variable
begin_variable
var773
-1
2
Atom visited(loc-x0-y18)
NegatedAtom visited(loc-x0-y18)
end_variable
begin_variable
var772
-1
2
Atom visited(loc-x0-y19)
NegatedAtom visited(loc-x0-y19)
end_variable
begin_variable
var771
-1
2
Atom visited(loc-x0-y2)
NegatedAtom visited(loc-x0-y2)
end_variable
begin_variable
var770
-1
2
Atom visited(loc-x0-y20)
NegatedAtom visited(loc-x0-y20)
end_variable
begin_variable
var769
-1
2
Atom visited(loc-x0-y21)
NegatedAtom visited(loc-x0-y21)
end_variable
begin_variable
var768
-1
2
Atom visited(loc-x0-y22)
NegatedAtom visited(loc-x0-y22)
end_variable
begin_variable
var767
-1
2
Atom visited(loc-x0-y23)
NegatedAtom visited(loc-x0-y23)
end_variable
begin_variable
var766
-1
2
Atom visited(loc-x0-y24)
NegatedAtom visited(loc-x0-y24)
end_variable
begin_variable
var765
-1
2
Atom visited(loc-x0-y25)
NegatedAtom visited(loc-x0-y25)
end_variable
begin_variable
var764
-1
2
Atom visited(loc-x0-y26)
NegatedAtom visited(loc-x0-y26)
end_variable
begin_variable
var763
-1
2
Atom visited(loc-x0-y27)
NegatedAtom visited(loc-x0-y27)
end_variable
begin_variable
var762
-1
2
Atom visited(loc-x0-y3)
NegatedAtom visited(loc-x0-y3)
end_variable
begin_variable
var761
-1
2
Atom visited(loc-x0-y4)
NegatedAtom visited(loc-x0-y4)
end_variable
begin_variable
var760
-1
2
Atom visited(loc-x0-y5)
NegatedAtom visited(loc-x0-y5)
end_variable
begin_variable
var759
-1
2
Atom visited(loc-x0-y6)
NegatedAtom visited(loc-x0-y6)
end_variable
begin_variable
var758
-1
2
Atom visited(loc-x0-y7)
NegatedAtom visited(loc-x0-y7)
end_variable
begin_variable
var757
-1
2
Atom visited(loc-x0-y8)
NegatedAtom visited(loc-x0-y8)
end_variable
begin_variable
var756
-1
2
Atom visited(loc-x0-y9)
NegatedAtom visited(loc-x0-y9)
end_variable
begin_variable
var755
-1
2
Atom visited(loc-x1-y0)
NegatedAtom visited(loc-x1-y0)
end_variable
begin_variable
var754
-1
2
Atom visited(loc-x1-y1)
NegatedAtom visited(loc-x1-y1)
end_variable
begin_variable
var753
-1
2
Atom visited(loc-x1-y10)
NegatedAtom visited(loc-x1-y10)
end_variable
begin_variable
var752
-1
2
Atom visited(loc-x1-y11)
NegatedAtom visited(loc-x1-y11)
end_variable
begin_variable
var751
-1
2
Atom visited(loc-x1-y12)
NegatedAtom visited(loc-x1-y12)
end_variable
begin_variable
var750
-1
2
Atom visited(loc-x1-y13)
NegatedAtom visited(loc-x1-y13)
end_variable
begin_variable
var749
-1
2
Atom visited(loc-x1-y14)
NegatedAtom visited(loc-x1-y14)
end_variable
begin_variable
var748
-1
2
Atom visited(loc-x1-y15)
NegatedAtom visited(loc-x1-y15)
end_variable
begin_variable
var747
-1
2
Atom visited(loc-x1-y16)
NegatedAtom visited(loc-x1-y16)
end_variable
begin_variable
var746
-1
2
Atom visited(loc-x1-y17)
NegatedAtom visited(loc-x1-y17)
end_variable
begin_variable
var745
-1
2
Atom visited(loc-x1-y18)
NegatedAtom visited(loc-x1-y18)
end_variable
begin_variable
var744
-1
2
Atom visited(loc-x1-y19)
NegatedAtom visited(loc-x1-y19)
end_variable
begin_variable
var743
-1
2
Atom visited(loc-x1-y2)
NegatedAtom visited(loc-x1-y2)
end_variable
begin_variable
var742
-1
2
Atom visited(loc-x1-y20)
NegatedAtom visited(loc-x1-y20)
end_variable
begin_variable
var741
-1
2
Atom visited(loc-x1-y21)
NegatedAtom visited(loc-x1-y21)
end_variable
begin_variable
var740
-1
2
Atom visited(loc-x1-y22)
NegatedAtom visited(loc-x1-y22)
end_variable
begin_variable
var739
-1
2
Atom visited(loc-x1-y23)
NegatedAtom visited(loc-x1-y23)
end_variable
begin_variable
var738
-1
2
Atom visited(loc-x1-y24)
NegatedAtom visited(loc-x1-y24)
end_variable
begin_variable
var737
-1
2
Atom visited(loc-x1-y25)
NegatedAtom visited(loc-x1-y25)
end_variable
begin_variable
var736
-1
2
Atom visited(loc-x1-y26)
NegatedAtom visited(loc-x1-y26)
end_variable
begin_variable
var735
-1
2
Atom visited(loc-x1-y27)
NegatedAtom visited(loc-x1-y27)
end_variable
begin_variable
var734
-1
2
Atom visited(loc-x1-y3)
NegatedAtom visited(loc-x1-y3)
end_variable
begin_variable
var733
-1
2
Atom visited(loc-x1-y4)
NegatedAtom visited(l




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




y13 loc-x8-y13
0
2
0 0 705 733
0 733 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x6-y14
0
2
0 0 706 678
0 678 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y13
0
2
0 0 706 705
0 705 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x7-y15
0
2
0 0 706 707
0 707 -1 0
1
end_operator
begin_operator
move loc-x7-y14 loc-x8-y14
0
2
0 0 706 734
0 734 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x6-y15
0
2
0 0 707 679
0 679 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y14
0
2
0 0 707 706
0 706 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x7-y16
0
2
0 0 707 708
0 708 -1 0
1
end_operator
begin_operator
move loc-x7-y15 loc-x8-y15
0
2
0 0 707 735
0 735 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x6-y16
0
2
0 0 708 680
0 680 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y15
0
2
0 0 708 707
0 707 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x7-y17
0
2
0 0 708 709
0 709 -1 0
1
end_operator
begin_operator
move loc-x7-y16 loc-x8-y16
0
2
0 0 708 736
0 736 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x6-y17
0
2
0 0 709 681
0 681 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y16
0
2
0 0 709 708
0 708 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x7-y18
0
2
0 0 709 710
0 710 -1 0
1
end_operator
begin_operator
move loc-x7-y17 loc-x8-y17
0
2
0 0 709 737
0 737 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x6-y18
0
2
0 0 710 682
0 682 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y17
0
2
0 0 710 709
0 709 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x7-y19
0
2
0 0 710 711
0 711 -1 0
1
end_operator
begin_operator
move loc-x7-y18 loc-x8-y18
0
2
0 0 710 738
0 738 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x6-y19
0
2
0 0 711 683
0 683 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y18
0
2
0 0 711 710
0 710 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x7-y20
0
2
0 0 711 713
0 713 -1 0
1
end_operator
begin_operator
move loc-x7-y19 loc-x8-y19
0
2
0 0 711 739
0 739 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x6-y2
0
2
0 0 712 684
0 684 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y1
0
2
0 0 712 701
0 701 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x7-y3
0
2
0 0 712 721
0 721 -1 0
1
end_operator
begin_operator
move loc-x7-y2 loc-x8-y2
0
2
0 0 712 740
0 740 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x6-y20
0
2
0 0 713 685
0 685 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x7-y19
0
2
0 0 713 711
0 711 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x7-y21
0
2
0 0 713 714
0 714 -1 0
1
end_operator
begin_operator
move loc-x7-y20 loc-x8-y20
0
2
0 0 713 741
0 741 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x6-y21
0
2
0 0 714 686
0 686 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x7-y20
0
2
0 0 714 713
0 713 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x7-y22
0
2
0 0 714 715
0 715 -1 0
1
end_operator
begin_operator
move loc-x7-y21 loc-x8-y21
0
2
0 0 714 742
0 742 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x6-y22
0
2
0 0 715 687
0 687 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x7-y21
0
2
0 0 715 714
0 714 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x7-y23
0
2
0 0 715 716
0 716 -1 0
1
end_operator
begin_operator
move loc-x7-y22 loc-x8-y22
0
2
0 0 715 743
0 743 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x6-y23
0
2
0 0 716 688
0 688 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x7-y22
0
2
0 0 716 715
0 715 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x7-y24
0
2
0 0 716 717
0 717 -1 0
1
end_operator
begin_operator
move loc-x7-y23 loc-x8-y23
0
2
0 0 716 744
0 744 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x6-y24
0
2
0 0 717 689
0 689 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x7-y23
0
2
0 0 717 716
0 716 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x7-y25
0
2
0 0 717 718
0 718 -1 0
1
end_operator
begin_operator
move loc-x7-y24 loc-x8-y24
0
2
0 0 717 745
0 745 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x6-y25
0
2
0 0 718 690
0 690 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x7-y24
0
2
0 0 718 717
0 717 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x7-y26
0
2
0 0 718 719
0 719 -1 0
1
end_operator
begin_operator
move loc-x7-y25 loc-x8-y25
0
2
0 0 718 746
0 746 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x6-y26
0
2
0 0 719 691
0 691 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x7-y25
0
2
0 0 719 718
0 718 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x7-y27
0
2
0 0 719 720
0 720 -1 0
1
end_operator
begin_operator
move loc-x7-y26 loc-x8-y26
0
2
0 0 719 747
0 747 -1 0
1
end_operator
begin_operator
move loc-x7-y27 loc-x6-y27
0
2
0 0 720 692
0 692 -1 0
1
end_operator
begin_operator
move loc-x7-y27 loc-x7-y26
0
2
0 0 720 719
0 719 -1 0
1
end_operator
begin_operator
move loc-x7-y27 loc-x8-y27
0
2
0 0 720 748
0 748 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x6-y3
0
2
0 0 721 693
0 693 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y2
0
2
0 0 721 712
0 712 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x7-y4
0
2
0 0 721 722
0 722 -1 0
1
end_operator
begin_operator
move loc-x7-y3 loc-x8-y3
0
2
0 0 721 749
0 749 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x6-y4
0
2
0 0 722 694
0 694 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y3
0
2
0 0 722 721
0 721 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x7-y5
0
2
0 0 722 723
0 723 -1 0
1
end_operator
begin_operator
move loc-x7-y4 loc-x8-y4
0
2
0 0 722 750
0 750 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x6-y5
0
2
0 0 723 695
0 695 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y4
0
2
0 0 723 722
0 722 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x7-y6
0
2
0 0 723 724
0 724 -1 0
1
end_operator
begin_operator
move loc-x7-y5 loc-x8-y5
0
2
0 0 723 751
0 751 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x6-y6
0
2
0 0 724 696
0 696 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y5
0
2
0 0 724 723
0 723 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x7-y7
0
2
0 0 724 725
0 725 -1 0
1
end_operator
begin_operator
move loc-x7-y6 loc-x8-y6
0
2
0 0 724 752
0 752 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x6-y7
0
2
0 0 725 697
0 697 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y6
0
2
0 0 725 724
0 724 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x7-y8
0
2
0 0 725 726
0 726 -1 0
1
end_operator
begin_operator
move loc-x7-y7 loc-x8-y7
0
2
0 0 725 753
0 753 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x6-y8
0
2
0 0 726 698
0 698 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y7
0
2
0 0 726 725
0 725 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x7-y9
0
2
0 0 726 727
0 727 -1 0
1
end_operator
begin_operator
move loc-x7-y8 loc-x8-y8
0
2
0 0 726 754
0 754 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x6-y9
0
2
0 0 727 699
0 699 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y10
0
2
0 0 727 702
0 702 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x7-y8
0
2
0 0 727 726
0 726 -1 0
1
end_operator
begin_operator
move loc-x7-y9 loc-x8-y9
0
2
0 0 727 755
0 755 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x7-y0
0
2
0 0 728 700
0 700 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x8-y1
0
2
0 0 728 729
0 729 -1 0
1
end_operator
begin_operator
move loc-x8-y0 loc-x9-y0
0
2
0 0 728 756
0 756 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x7-y1
0
2
0 0 729 701
0 701 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y0
0
2
0 0 729 728
0 728 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x8-y2
0
2
0 0 729 740
0 740 -1 0
1
end_operator
begin_operator
move loc-x8-y1 loc-x9-y1
0
2
0 0 729 757
0 757 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x7-y10
0
2
0 0 730 702
0 702 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y11
0
2
0 0 730 731
0 731 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x8-y9
0
2
0 0 730 755
0 755 -1 0
1
end_operator
begin_operator
move loc-x8-y10 loc-x9-y10
0
2
0 0 730 758
0 758 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x7-y11
0
2
0 0 731 703
0 703 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y10
0
2
0 0 731 730
0 730 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x8-y12
0
2
0 0 731 732
0 732 -1 0
1
end_operator
begin_operator
move loc-x8-y11 loc-x9-y11
0
2
0 0 731 759
0 759 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x7-y12
0
2
0 0 732 704
0 704 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y11
0
2
0 0 732 731
0 731 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x8-y13
0
2
0 0 732 733
0 733 -1 0
1
end_operator
begin_operator
move loc-x8-y12 loc-x9-y12
0
2
0 0 732 760
0 760 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x7-y13
0
2
0 0 733 705
0 705 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y12
0
2
0 0 733 732
0 732 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x8-y14
0
2
0 0 733 734
0 734 -1 0
1
end_operator
begin_operator
move loc-x8-y13 loc-x9-y13
0
2
0 0 733 761
0 761 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x7-y14
0
2
0 0 734 706
0 706 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y13
0
2
0 0 734 733
0 733 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x8-y15
0
2
0 0 734 735
0 735 -1 0
1
end_operator
begin_operator
move loc-x8-y14 loc-x9-y14
0
2
0 0 734 762
0 762 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x7-y15
0
2
0 0 735 707
0 707 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y14
0
2
0 0 735 734
0 734 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x8-y16
0
2
0 0 735 736
0 736 -1 0
1
end_operator
begin_operator
move loc-x8-y15 loc-x9-y15
0
2
0 0 735 763
0 763 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x7-y16
0
2
0 0 736 708
0 708 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y15
0
2
0 0 736 735
0 735 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x8-y17
0
2
0 0 736 737
0 737 -1 0
1
end_operator
begin_operator
move loc-x8-y16 loc-x9-y16
0
2
0 0 736 764
0 764 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x7-y17
0
2
0 0 737 709
0 709 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y16
0
2
0 0 737 736
0 736 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x8-y18
0
2
0 0 737 738
0 738 -1 0
1
end_operator
begin_operator
move loc-x8-y17 loc-x9-y17
0
2
0 0 737 765
0 765 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x7-y18
0
2
0 0 738 710
0 710 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y17
0
2
0 0 738 737
0 737 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x8-y19
0
2
0 0 738 739
0 739 -1 0
1
end_operator
begin_operator
move loc-x8-y18 loc-x9-y18
0
2
0 0 738 766
0 766 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x7-y19
0
2
0 0 739 711
0 711 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y18
0
2
0 0 739 738
0 738 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x8-y20
0
2
0 0 739 741
0 741 -1 0
1
end_operator
begin_operator
move loc-x8-y19 loc-x9-y19
0
2
0 0 739 767
0 767 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x7-y2
0
2
0 0 740 712
0 712 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y1
0
2
0 0 740 729
0 729 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x8-y3
0
2
0 0 740 749
0 749 -1 0
1
end_operator
begin_operator
move loc-x8-y2 loc-x9-y2
0
2
0 0 740 768
0 768 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x7-y20
0
2
0 0 741 713
0 713 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y19
0
2
0 0 741 739
0 739 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x8-y21
0
2
0 0 741 742
0 742 -1 0
1
end_operator
begin_operator
move loc-x8-y20 loc-x9-y20
0
2
0 0 741 769
0 769 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x7-y21
0
2
0 0 742 714
0 714 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y20
0
2
0 0 742 741
0 741 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x8-y22
0
2
0 0 742 743
0 743 -1 0
1
end_operator
begin_operator
move loc-x8-y21 loc-x9-y21
0
2
0 0 742 770
0 770 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x7-y22
0
2
0 0 743 715
0 715 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x8-y21
0
2
0 0 743 742
0 742 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x8-y23
0
2
0 0 743 744
0 744 -1 0
1
end_operator
begin_operator
move loc-x8-y22 loc-x9-y22
0
2
0 0 743 771
0 771 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x7-y23
0
2
0 0 744 716
0 716 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x8-y22
0
2
0 0 744 743
0 743 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x8-y24
0
2
0 0 744 745
0 745 -1 0
1
end_operator
begin_operator
move loc-x8-y23 loc-x9-y23
0
2
0 0 744 772
0 772 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x7-y24
0
2
0 0 745 717
0 717 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x8-y23
0
2
0 0 745 744
0 744 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x8-y25
0
2
0 0 745 746
0 746 -1 0
1
end_operator
begin_operator
move loc-x8-y24 loc-x9-y24
0
2
0 0 745 773
0 773 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x7-y25
0
2
0 0 746 718
0 718 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x8-y24
0
2
0 0 746 745
0 745 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x8-y26
0
2
0 0 746 747
0 747 -1 0
1
end_operator
begin_operator
move loc-x8-y25 loc-x9-y25
0
2
0 0 746 774
0 774 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x7-y26
0
2
0 0 747 719
0 719 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x8-y25
0
2
0 0 747 746
0 746 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x8-y27
0
2
0 0 747 748
0 748 -1 0
1
end_operator
begin_operator
move loc-x8-y26 loc-x9-y26
0
2
0 0 747 775
0 775 -1 0
1
end_operator
begin_operator
move loc-x8-y27 loc-x7-y27
0
2
0 0 748 720
0 720 -1 0
1
end_operator
begin_operator
move loc-x8-y27 loc-x8-y26
0
2
0 0 748 747
0 747 -1 0
1
end_operator
begin_operator
move loc-x8-y27 loc-x9-y27
0
2
0 0 748 776
0 776 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x7-y3
0
2
0 0 749 721
0 721 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y2
0
2
0 0 749 740
0 740 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x8-y4
0
2
0 0 749 750
0 750 -1 0
1
end_operator
begin_operator
move loc-x8-y3 loc-x9-y3
0
2
0 0 749 777
0 777 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x7-y4
0
2
0 0 750 722
0 722 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y3
0
2
0 0 750 749
0 749 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x8-y5
0
2
0 0 750 751
0 751 -1 0
1
end_operator
begin_operator
move loc-x8-y4 loc-x9-y4
0
2
0 0 750 778
0 778 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x7-y5
0
2
0 0 751 723
0 723 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y4
0
2
0 0 751 750
0 750 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x8-y6
0
2
0 0 751 752
0 752 -1 0
1
end_operator
begin_operator
move loc-x8-y5 loc-x9-y5
0
2
0 0 751 779
0 779 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x7-y6
0
2
0 0 752 724
0 724 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y5
0
2
0 0 752 751
0 751 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x8-y7
0
2
0 0 752 753
0 753 -1 0
1
end_operator
begin_operator
move loc-x8-y6 loc-x9-y6
0
2
0 0 752 780
0 780 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x7-y7
0
2
0 0 753 725
0 725 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y6
0
2
0 0 753 752
0 752 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x8-y8
0
2
0 0 753 754
0 754 -1 0
1
end_operator
begin_operator
move loc-x8-y7 loc-x9-y7
0
2
0 0 753 781
0 781 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x7-y8
0
2
0 0 754 726
0 726 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y7
0
2
0 0 754 753
0 753 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x8-y9
0
2
0 0 754 755
0 755 -1 0
1
end_operator
begin_operator
move loc-x8-y8 loc-x9-y8
0
2
0 0 754 782
0 782 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x7-y9
0
2
0 0 755 727
0 727 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y10
0
2
0 0 755 730
0 730 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x8-y8
0
2
0 0 755 754
0 754 -1 0
1
end_operator
begin_operator
move loc-x8-y9 loc-x9-y9
0
2
0 0 755 783
0 783 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x10-y0
0
2
0 0 756 56
0 57 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x8-y0
0
2
0 0 756 728
0 728 -1 0
1
end_operator
begin_operator
move loc-x9-y0 loc-x9-y1
0
2
0 0 756 757
0 757 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x10-y1
0
2
0 0 757 57
0 58 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x8-y1
0
2
0 0 757 729
0 729 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y0
0
2
0 0 757 756
0 756 -1 0
1
end_operator
begin_operator
move loc-x9-y1 loc-x9-y2
0
2
0 0 757 768
0 768 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x10-y10
0
2
0 0 758 58
0 59 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x8-y10
0
2
0 0 758 730
0 730 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y11
0
2
0 0 758 759
0 759 -1 0
1
end_operator
begin_operator
move loc-x9-y10 loc-x9-y9
0
2
0 0 758 783
0 783 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x10-y11
0
2
0 0 759 59
0 60 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x8-y11
0
2
0 0 759 731
0 731 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y10
0
2
0 0 759 758
0 758 -1 0
1
end_operator
begin_operator
move loc-x9-y11 loc-x9-y12
0
2
0 0 759 760
0 760 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x10-y12
0
2
0 0 760 60
0 61 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x8-y12
0
2
0 0 760 732
0 732 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y11
0
2
0 0 760 759
0 759 -1 0
1
end_operator
begin_operator
move loc-x9-y12 loc-x9-y13
0
2
0 0 760 761
0 761 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x10-y13
0
2
0 0 761 61
0 62 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x8-y13
0
2
0 0 761 733
0 733 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y12
0
2
0 0 761 760
0 760 -1 0
1
end_operator
begin_operator
move loc-x9-y13 loc-x9-y14
0
2
0 0 761 762
0 762 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x10-y14
0
2
0 0 762 62
0 63 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x8-y14
0
2
0 0 762 734
0 734 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y13
0
2
0 0 762 761
0 761 -1 0
1
end_operator
begin_operator
move loc-x9-y14 loc-x9-y15
0
2
0 0 762 763
0 763 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x10-y15
0
2
0 0 763 63
0 64 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x8-y15
0
2
0 0 763 735
0 735 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y14
0
2
0 0 763 762
0 762 -1 0
1
end_operator
begin_operator
move loc-x9-y15 loc-x9-y16
0
2
0 0 763 764
0 764 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x10-y16
0
2
0 0 764 64
0 65 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x8-y16
0
2
0 0 764 736
0 736 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y15
0
2
0 0 764 763
0 763 -1 0
1
end_operator
begin_operator
move loc-x9-y16 loc-x9-y17
0
2
0 0 764 765
0 765 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x10-y17
0
2
0 0 765 65
0 66 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x8-y17
0
2
0 0 765 737
0 737 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y16
0
2
0 0 765 764
0 764 -1 0
1
end_operator
begin_operator
move loc-x9-y17 loc-x9-y18
0
2
0 0 765 766
0 766 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x10-y18
0
2
0 0 766 66
0 67 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x8-y18
0
2
0 0 766 738
0 738 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y17
0
2
0 0 766 765
0 765 -1 0
1
end_operator
begin_operator
move loc-x9-y18 loc-x9-y19
0
2
0 0 766 767
0 767 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x10-y19
0
2
0 0 767 67
0 68 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x8-y19
0
2
0 0 767 739
0 739 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y18
0
2
0 0 767 766
0 766 -1 0
1
end_operator
begin_operator
move loc-x9-y19 loc-x9-y20
0
2
0 0 767 769
0 769 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x10-y2
0
2
0 0 768 68
0 69 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x8-y2
0
2
0 0 768 740
0 740 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y1
0
2
0 0 768 757
0 757 -1 0
1
end_operator
begin_operator
move loc-x9-y2 loc-x9-y3
0
2
0 0 768 777
0 777 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x10-y20
0
2
0 0 769 69
0 70 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x8-y20
0
2
0 0 769 741
0 741 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y19
0
2
0 0 769 767
0 767 -1 0
1
end_operator
begin_operator
move loc-x9-y20 loc-x9-y21
0
2
0 0 769 770
0 770 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x10-y21
0
2
0 0 770 70
0 71 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x8-y21
0
2
0 0 770 742
0 742 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y20
0
2
0 0 770 769
0 769 -1 0
1
end_operator
begin_operator
move loc-x9-y21 loc-x9-y22
0
2
0 0 770 771
0 771 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x10-y22
0
2
0 0 771 71
0 72 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x8-y22
0
2
0 0 771 743
0 743 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x9-y21
0
2
0 0 771 770
0 770 -1 0
1
end_operator
begin_operator
move loc-x9-y22 loc-x9-y23
0
2
0 0 771 772
0 772 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x10-y23
0
2
0 0 772 72
0 73 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x8-y23
0
2
0 0 772 744
0 744 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x9-y22
0
2
0 0 772 771
0 771 -1 0
1
end_operator
begin_operator
move loc-x9-y23 loc-x9-y24
0
2
0 0 772 773
0 773 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x10-y24
0
2
0 0 773 73
0 74 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x8-y24
0
2
0 0 773 745
0 745 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x9-y23
0
2
0 0 773 772
0 772 -1 0
1
end_operator
begin_operator
move loc-x9-y24 loc-x9-y25
0
2
0 0 773 774
0 774 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x10-y25
0
2
0 0 774 74
0 75 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x8-y25
0
2
0 0 774 746
0 746 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x9-y24
0
2
0 0 774 773
0 773 -1 0
1
end_operator
begin_operator
move loc-x9-y25 loc-x9-y26
0
2
0 0 774 775
0 775 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x10-y26
0
2
0 0 775 75
0 76 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x8-y26
0
2
0 0 775 747
0 747 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x9-y25
0
2
0 0 775 774
0 774 -1 0
1
end_operator
begin_operator
move loc-x9-y26 loc-x9-y27
0
2
0 0 775 776
0 776 -1 0
1
end_operator
begin_operator
move loc-x9-y27 loc-x10-y27
0
2
0 0 776 76
0 77 -1 0
1
end_operator
begin_operator
move loc-x9-y27 loc-x8-y27
0
2
0 0 776 748
0 748 -1 0
1
end_operator
begin_operator
move loc-x9-y27 loc-x9-y26
0
2
0 0 776 775
0 775 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x10-y3
0
2
0 0 777 77
0 78 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x8-y3
0
2
0 0 777 749
0 749 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y2
0
2
0 0 777 768
0 768 -1 0
1
end_operator
begin_operator
move loc-x9-y3 loc-x9-y4
0
2
0 0 777 778
0 778 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x10-y4
0
2
0 0 778 78
0 79 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x8-y4
0
2
0 0 778 750
0 750 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y3
0
2
0 0 778 777
0 777 -1 0
1
end_operator
begin_operator
move loc-x9-y4 loc-x9-y5
0
2
0 0 778 779
0 779 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x10-y5
0
2
0 0 779 79
0 80 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x8-y5
0
2
0 0 779 751
0 751 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y4
0
2
0 0 779 778
0 778 -1 0
1
end_operator
begin_operator
move loc-x9-y5 loc-x9-y6
0
2
0 0 779 780
0 780 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x10-y6
0
2
0 0 780 80
0 81 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x8-y6
0
2
0 0 780 752
0 752 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y5
0
2
0 0 780 779
0 779 -1 0
1
end_operator
begin_operator
move loc-x9-y6 loc-x9-y7
0
2
0 0 780 781
0 781 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x10-y7
0
2
0 0 781 81
0 82 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x8-y7
0
2
0 0 781 753
0 753 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y6
0
2
0 0 781 780
0 780 -1 0
1
end_operator
begin_operator
move loc-x9-y7 loc-x9-y8
0
2
0 0 781 782
0 782 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x10-y8
0
2
0 0 782 82
0 83 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x8-y8
0
2
0 0 782 754
0 754 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y7
0
2
0 0 782 781
0 781 -1 0
1
end_operator
begin_operator
move loc-x9-y8 loc-x9-y9
0
2
0 0 782 783
0 783 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x10-y9
0
2
0 0 783 83
0 84 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x8-y9
0
2
0 0 783 755
0 755 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y10
0
2
0 0 783 758
0 758 -1 0
1
end_operator
begin_operator
move loc-x9-y9 loc-x9-y8
0
2
0 0 783 782
0 782 -1 0
1
end_operator
0
