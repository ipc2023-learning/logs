%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% training data:
class('obj:loc-x0-y1', 'obj:loc-x0-y0', 'p01').
class('obj:loc-x1-y0', 'obj:loc-x0-y0', 'p01').
class('obj:loc-x2-y3', 'obj:loc-x3-y3', 'p03').
class('obj:loc-x3-y2', 'obj:loc-x3-y3', 'p03').
class('obj:loc-x2-y3', 'obj:loc-x3-y3', 'p04').
class('obj:loc-x3-y2', 'obj:loc-x3-y3', 'p04').
class('obj:loc-x3-y4', 'obj:loc-x3-y3', 'p04').
class('obj:loc-x4-y3', 'obj:loc-x3-y3', 'p04').
class('obj:loc-x0-y0', 'obj:loc-x1-y0', 'p05').
class('obj:loc-x1-y1', 'obj:loc-x1-y0', 'p05').
class('obj:loc-x2-y0', 'obj:loc-x1-y0', 'p05').
