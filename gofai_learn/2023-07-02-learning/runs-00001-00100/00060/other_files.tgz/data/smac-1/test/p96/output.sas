begin_version
3
end_version
begin_metric
0
end_metric
31
begin_variable
var0
-1
16
Atom at(v7, l1)
Atom at(v7, l10)
Atom at(v7, l11)
Atom at(v7, l12)
Atom at(v7, l13)
Atom at(v7, l14)
Atom at(v7, l15)
Atom at(v7, l16)
Atom at(v7, l2)
Atom at(v7, l3)
Atom at(v7, l4)
Atom at(v7, l5)
Atom at(v7, l6)
Atom at(v7, l7)
Atom at(v7, l8)
Atom at(v7, l9)
end_variable
begin_variable
var1
-1
16
Atom at(v6, l1)
Atom at(v6, l10)
Atom at(v6, l11)
Atom at(v6, l12)
Atom at(v6, l13)
Atom at(v6, l14)
Atom at(v6, l15)
Atom at(v6, l16)
Atom at(v6, l2)
Atom at(v6, l3)
Atom at(v6, l4)
Atom at(v6, l5)
Atom at(v6, l6)
Atom at(v6, l7)
Atom at(v6, l8)
Atom at(v6, l9)
end_variable
begin_variable
var2
-1
16
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l13)
Atom at(v5, l14)
Atom at(v5, l15)
Atom at(v5, l16)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var3
-1
16
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l13)
Atom at(v4, l14)
Atom at(v4, l15)
Atom at(v4, l16)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var4
-1
16
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l13)
Atom at(v3, l14)
Atom at(v3, l15)
Atom at(v3, l16)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var5
-1
16
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l13)
Atom at(v2, l14)
Atom at(v2, l15)
Atom at(v2, l16)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var6
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var10
-1
2
Atom capacity(v2, c0)
Atom capacity(v2, c1)
end_variable
begin_variable
var11
-1
2
Atom capacity(v6, c0)
Atom capacity(v6, c1)
end_variable
begin_variable
var12
-1
2
Atom capacity(v1, c0)
Atom capacity(v1, c1)
end_variable
begin_variable
var7
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var8
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var9
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var13
-1
2
Atom capacity(v5, c0)
Atom capacity(v5, c1)
end_variable
begin_variable
var15
-1
8
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l16)
Atom at(p1, l4)
Atom at(p1, l7)
Atom at(p1, l8)
Atom in(p1, v5)
end_variable
begin_variable
var20
-1
8
Atom at(p14, l12)
Atom at(p14, l14)
Atom at(p14, l16)
Atom at(p14, l4)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v5)
end_variable
begin_variable
var21
-1
3
Atom at(p15, l3)
Atom at(p15, l6)
Atom in(p15, v5)
end_variable
begin_variable
var22
-1
7
Atom at(p16, l10)
Atom at(p16, l12)
Atom at(p16, l14)
Atom at(p16, l16)
Atom at(p16, l4)
Atom at(p16, l7)
Atom in(p16, v5)
end_variable
begin_variable
var16
-1
6
Atom at(p10, l1)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v5)
end_variable
begin_variable
var17
-1
6
Atom at(p11, l1)
Atom at(p11, l13)
Atom at(p11, l5)
Atom at(p11, l6)
Atom in(p11, v1)
Atom in(p11, v5)
end_variable
begin_variable
var23
-1
6
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l5)
Atom at(p2, l6)
Atom in(p2, v1)
Atom in(p2, v5)
end_variable
begin_variable
var24
-1
5
Atom at(p3, l12)
Atom at(p3, l13)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v6)
end_variable
begin_variable
var26
-1
5
Atom at(p5, l12)
Atom at(p5, l13)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v6)
end_variable
begin_variable
var25
-1
5
Atom at(p4, l1)
Atom at(p4, l11)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v7)
end_variable
begin_variable
var30
-1
5
Atom at(p9, l11)
Atom at(p9, l13)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v7)
end_variable
begin_variable
var29
-1
5
Atom at(p8, l11)
Atom at(p8, l14)
Atom in(p8, v2)
Atom in(p8, v5)
Atom in(p8, v6)
end_variable
begin_variable
var14
-1
6
Atom at(p17, l11)
Atom at(p17, l8)
Atom in(p17, v3)
Atom in(p17, v4)
Atom in(p17, v5)
Atom in(p17, v7)
end_variable
begin_variable
var19
-1
6
Atom at(p13, l16)
Atom at(p13, l4)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v5)
Atom in(p13, v6)
end_variable
begin_variable
var27
-1
6
Atom at(p6, l13)
Atom at(p6, l16)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v5)
Atom in(p6, v6)
end_variable
begin_variable
var18
-1
7
Atom at(p12, l5)
Atom at(p12, l8)
Atom in(p12, v1)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v7)
end_variable
begin_variable
var28
-1
9
Atom at(p7




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




11 p9 c2 c3
1
3 2
2
0 24 0 3
0 12 3 2
1
end_operator
begin_operator
pick-up v4 l5 p12 c0 c1
1
3 11
2
0 29 0 4
0 12 1 0
1
end_operator
begin_operator
pick-up v4 l5 p12 c1 c2
1
3 11
2
0 29 0 4
0 12 2 1
1
end_operator
begin_operator
pick-up v4 l5 p12 c2 c3
1
3 11
2
0 29 0 4
0 12 3 2
1
end_operator
begin_operator
pick-up v4 l5 p7 c0 c1
1
3 11
2
0 30 0 5
0 12 1 0
1
end_operator
begin_operator
pick-up v4 l5 p7 c1 c2
1
3 11
2
0 30 0 5
0 12 2 1
1
end_operator
begin_operator
pick-up v4 l5 p7 c2 c3
1
3 11
2
0 30 0 5
0 12 3 2
1
end_operator
begin_operator
pick-up v4 l8 p17 c0 c1
1
3 14
2
0 26 1 3
0 12 1 0
1
end_operator
begin_operator
pick-up v4 l8 p17 c1 c2
1
3 14
2
0 26 1 3
0 12 2 1
1
end_operator
begin_operator
pick-up v4 l8 p17 c2 c3
1
3 14
2
0 26 1 3
0 12 3 2
1
end_operator
begin_operator
pick-up v5 l1 p10 c0 c1
1
2 0
2
0 18 0 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l1 p11 c0 c1
1
2 0
2
0 19 0 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l1 p2 c0 c1
1
2 0
2
0 20 0 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l12 p1 c0 c1
1
2 3
2
0 14 0 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l12 p14 c0 c1
1
2 3
2
0 15 0 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l12 p16 c0 c1
1
2 3
2
0 17 1 6
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l14 p1 c0 c1
1
2 5
2
0 14 2 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l14 p14 c0 c1
1
2 5
2
0 15 1 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l14 p16 c0 c1
1
2 5
2
0 17 2 6
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l14 p8 c0 c1
1
2 5
2
0 25 1 3
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l16 p1 c0 c1
1
2 7
2
0 14 3 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l16 p13 c0 c1
1
2 7
2
0 27 0 4
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l16 p14 c0 c1
1
2 7
2
0 15 2 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l16 p16 c0 c1
1
2 7
2
0 17 3 6
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l16 p6 c0 c1
1
2 7
2
0 28 1 4
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l4 p1 c0 c1
1
2 10
2
0 14 4 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l4 p14 c0 c1
1
2 10
2
0 15 3 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l4 p16 c0 c1
1
2 10
2
0 17 4 6
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l5 p10 c0 c1
1
2 11
2
0 18 1 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l5 p11 c0 c1
1
2 11
2
0 19 2 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l5 p12 c0 c1
1
2 11
2
0 29 0 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l5 p2 c0 c1
1
2 11
2
0 20 2 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l5 p7 c0 c1
1
2 11
2
0 30 0 6
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l6 p10 c0 c1
1
2 12
2
0 18 2 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l6 p11 c0 c1
1
2 12
2
0 19 3 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l6 p15 c0 c1
1
2 12
2
0 16 1 2
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l6 p2 c0 c1
1
2 12
2
0 20 3 5
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l7 p1 c0 c1
1
2 13
2
0 14 5 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l7 p14 c0 c1
1
2 13
2
0 15 4 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l7 p16 c0 c1
1
2 13
2
0 17 5 6
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l8 p1 c0 c1
1
2 14
2
0 14 6 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l8 p14 c0 c1
1
2 14
2
0 15 5 7
0 13 1 0
1
end_operator
begin_operator
pick-up v5 l8 p17 c0 c1
1
2 14
2
0 26 1 4
0 13 1 0
1
end_operator
begin_operator
pick-up v6 l13 p3 c0 c1
1
1 4
2
0 21 1 4
0 8 1 0
1
end_operator
begin_operator
pick-up v6 l13 p5 c0 c1
1
1 4
2
0 22 1 4
0 8 1 0
1
end_operator
begin_operator
pick-up v6 l14 p8 c0 c1
1
1 5
2
0 25 1 4
0 8 1 0
1
end_operator
begin_operator
pick-up v6 l16 p13 c0 c1
1
1 7
2
0 27 0 5
0 8 1 0
1
end_operator
begin_operator
pick-up v6 l16 p6 c0 c1
1
1 7
2
0 28 1 5
0 8 1 0
1
end_operator
begin_operator
pick-up v6 l5 p7 c0 c1
1
1 11
2
0 30 0 7
0 8 1 0
1
end_operator
begin_operator
pick-up v7 l11 p4 c0 c1
1
0 2
2
0 23 1 4
0 10 1 0
1
end_operator
begin_operator
pick-up v7 l11 p4 c1 c2
1
0 2
2
0 23 1 4
0 10 2 1
1
end_operator
begin_operator
pick-up v7 l11 p4 c2 c3
1
0 2
2
0 23 1 4
0 10 3 2
1
end_operator
begin_operator
pick-up v7 l11 p9 c0 c1
1
0 2
2
0 24 0 4
0 10 1 0
1
end_operator
begin_operator
pick-up v7 l11 p9 c1 c2
1
0 2
2
0 24 0 4
0 10 2 1
1
end_operator
begin_operator
pick-up v7 l11 p9 c2 c3
1
0 2
2
0 24 0 4
0 10 3 2
1
end_operator
begin_operator
pick-up v7 l5 p12 c0 c1
1
0 11
2
0 29 0 6
0 10 1 0
1
end_operator
begin_operator
pick-up v7 l5 p12 c1 c2
1
0 11
2
0 29 0 6
0 10 2 1
1
end_operator
begin_operator
pick-up v7 l5 p12 c2 c3
1
0 11
2
0 29 0 6
0 10 3 2
1
end_operator
begin_operator
pick-up v7 l5 p7 c0 c1
1
0 11
2
0 30 0 8
0 10 1 0
1
end_operator
begin_operator
pick-up v7 l5 p7 c1 c2
1
0 11
2
0 30 0 8
0 10 2 1
1
end_operator
begin_operator
pick-up v7 l5 p7 c2 c3
1
0 11
2
0 30 0 8
0 10 3 2
1
end_operator
begin_operator
pick-up v7 l8 p17 c0 c1
1
0 14
2
0 26 1 5
0 10 1 0
1
end_operator
begin_operator
pick-up v7 l8 p17 c1 c2
1
0 14
2
0 26 1 5
0 10 2 1
1
end_operator
begin_operator
pick-up v7 l8 p17 c2 c3
1
0 14
2
0 26 1 5
0 10 3 2
1
end_operator
0
