begin_version
3
end_version
begin_metric
0
end_metric
18
begin_variable
var0
-1
12
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l12)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var1
-1
12
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l12)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l5)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l8)
Atom at(v4, l9)
end_variable
begin_variable
var3
-1
12
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l12)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var4
-1
12
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var6
-1
2
Atom capacity(v4, c0)
Atom capacity(v4, c1)
end_variable
begin_variable
var7
-1
2
Atom capacity(v5, c0)
Atom capacity(v5, c1)
end_variable
begin_variable
var8
-1
2
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var9
-1
2
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var15
-1
3
Atom at(p4, l12)
Atom at(p4, l5)
Atom in(p4, v4)
end_variable
begin_variable
var17
-1
3
Atom at(p6, l10)
Atom at(p6, l7)
Atom in(p6, v5)
end_variable
begin_variable
var13
-1
4
Atom at(p2, l12)
Atom at(p2, l3)
Atom in(p2, v1)
Atom in(p2, v4)
end_variable
begin_variable
var10
-1
4
Atom at(p1, l12)
Atom at(p1, l4)
Atom in(p1, v2)
Atom in(p1, v4)
end_variable
begin_variable
var12
-1
4
Atom at(p10, l2)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
end_variable
begin_variable
var14
-1
4
Atom at(p3, l10)
Atom at(p3, l2)
Atom in(p3, v1)
Atom in(p3, v2)
end_variable
begin_variable
var18
-1
4
Atom at(p7, l7)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
end_variable
begin_variable
var11
-1
5
Atom at(p8, l11)
Atom at(p8, l2)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v5)
end_variable
begin_variable
var16
-1
5
Atom at(p5, l12)
Atom at(p5, l3)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v5)
end_variable
begin_variable
var19
-1
5
Atom at(p9, l12)
Atom at(p9, l2)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v5)
end_variable
77
begin_mutex_group
2
4 1
11 3
end_mutex_group
begin_mutex_group
2
4 1
10 3
end_mutex_group
begin_mutex_group
2
4 1
8 2
end_mutex_group
begin_mutex_group
2
5 1
15 4
end_mutex_group
begin_mutex_group
2
5 1
16 4
end_mutex_group
begin_mutex_group
2
5 1
9 2
end_mutex_group
begin_mutex_group
2
5 1
17 4
end_mutex_group
begin_mutex_group
2
11 3
10 3
end_mutex_group
begin_mutex_group
2
11 3
8 2
end_mutex_group
begin_mutex_group
2
15 4
16 4
end_mutex_group
begin_mutex_group
2
15 4
9 2
end_mutex_group
begin_mutex_group
2
15 4
17 4
end_mutex_group
begin_mutex_group
2
10 3
8 2
end_mutex_group
begin_mutex_group
2
16 4
9 2
end_mutex_group
begin_mutex_group
2
16 4
17 4
end_mutex_group
begin_mutex_group
2
9 2
17 4
end_mutex_group
begin_mutex_group
2
0 6
15 4
end_mutex_group
begin_mutex_group
2
0 6
16 4
end_mutex_group
begin_mutex_group
2
0 6
9 1
end_mutex_group
begin_mutex_group
2
0 6
9 2
end_mutex_group
begin_mutex_group
2
0 6
17 4
end_mutex_group
begin_mutex_group
2
6 1
15 2
end_mutex_group
begin_mutex_group
2
6 1
12 2
end_mutex_group
begin_mutex_group
2
6 1
10 2
end_mutex_group
begin_mutex_group
2
6 1
13 2
end_mutex_group
begin_mutex_group
2
6 1
16 2
end_mutex_group
begin_mutex_group
2
6 1
14 2
end_mutex_group
begin_mutex_group
2
6 1
17 2
end_mutex_group
begin_mutex_group
2
7 1
11 2
end_mutex_group
begin_mutex_group
2
7 1
15 3
end_mutex_group
begin_mutex_group
2
7 1
12 3
end_mutex_group
begin_mutex_group
2
7 1
13 3
end_mutex_group
begin_mutex_group
2
7 1
16 3
end_mutex_group
begin_mutex_group
2
7 1
14 3
end_mutex_group
begin_mutex_group
2
7 1
17 3
end_mutex_group
begin_mutex_group
2
11 2
15 3
end_mutex_group
begin_mutex_group
2
11 2
12 3
end_mutex_group
begin_mutex_group
2
11 2
13 3
end_mutex_group
begin_mutex_group
2
11 2
16 3
end_mutex_group
begin_mutex_group
2
11 2
14 3
end_mutex_group
begin_mutex_group
2
11 2
17 3
end_mutex_group
begin_mutex_group
2
15 2
12 2
end_mutex_group
begin_mutex_group
2
15 2
10 2
end_mutex_group
begin_mutex_group
2
15 2
13 2
end_mutex_group
begin_mutex_group
2
15 2
16 2
end_mutex_group
begin_mutex_group
2
15 2
14 2
end_mutex_group
begin_mutex_group
2
15 2
17 2
end_mutex_group
begin_mutex_group
2
15 3
12 3
end_mutex_group
begin_mutex_group
2
15 3
13 3
end_mutex_group
begin_mutex_group
2
15 3
16 3
end_mutex_group
begin_mutex_group
2
15 3
14 3
end_mutex_group
begin_mutex_group
2
15 3
17 3
end_mutex_group
begin_mutex_group
2
12 2
10 2
end_mutex_group
begin_mutex_group
2
12 2
13 2
end_mutex_group
begin_mutex_group
2
12 2
16 2
end_mutex_group
begin_mutex_group
2
12 2
14 2
end_mutex_group
begin_mutex_group
2
12 2
17 2
end_mutex_group
begin_mutex_group
2
12 3
13 3
end_mutex_group
begin_mutex_group
2
12 3
16 3
end_mutex_group
begin_mutex_group
2
12 3
14 3
end_mutex_group
begin_mutex_g




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




l4
0
1
0 0 7 6
1
end_operator
begin_operator
drive v5 l5 l6
0
1
0 0 7 8
1
end_operator
begin_operator
drive v5 l5 l7
0
1
0 0 7 9
1
end_operator
begin_operator
drive v5 l5 l8
0
1
0 0 7 10
1
end_operator
begin_operator
drive v5 l5 l9
0
1
0 0 7 11
1
end_operator
begin_operator
drive v5 l6 l12
0
1
0 0 8 3
1
end_operator
begin_operator
drive v5 l6 l3
0
1
0 0 8 5
1
end_operator
begin_operator
drive v5 l6 l4
0
1
0 0 8 6
1
end_operator
begin_operator
drive v5 l6 l5
0
1
0 0 8 7
1
end_operator
begin_operator
drive v5 l6 l8
0
1
0 0 8 10
1
end_operator
begin_operator
drive v5 l6 l9
0
1
0 0 8 11
1
end_operator
begin_operator
drive v5 l7 l1
0
1
0 0 9 0
1
end_operator
begin_operator
drive v5 l7 l11
0
1
0 0 9 2
1
end_operator
begin_operator
drive v5 l7 l12
0
1
0 0 9 3
1
end_operator
begin_operator
drive v5 l7 l3
0
1
0 0 9 5
1
end_operator
begin_operator
drive v5 l7 l5
0
1
0 0 9 7
1
end_operator
begin_operator
drive v5 l7 l8
0
1
0 0 9 10
1
end_operator
begin_operator
drive v5 l8 l10
0
1
0 0 10 1
1
end_operator
begin_operator
drive v5 l8 l12
0
1
0 0 10 3
1
end_operator
begin_operator
drive v5 l8 l2
0
1
0 0 10 4
1
end_operator
begin_operator
drive v5 l8 l3
0
1
0 0 10 5
1
end_operator
begin_operator
drive v5 l8 l4
0
1
0 0 10 6
1
end_operator
begin_operator
drive v5 l8 l5
0
1
0 0 10 7
1
end_operator
begin_operator
drive v5 l8 l6
0
1
0 0 10 8
1
end_operator
begin_operator
drive v5 l8 l7
0
1
0 0 10 9
1
end_operator
begin_operator
drive v5 l8 l9
0
1
0 0 10 11
1
end_operator
begin_operator
drive v5 l9 l1
0
1
0 0 11 0
1
end_operator
begin_operator
drive v5 l9 l10
0
1
0 0 11 1
1
end_operator
begin_operator
drive v5 l9 l12
0
1
0 0 11 3
1
end_operator
begin_operator
drive v5 l9 l2
0
1
0 0 11 4
1
end_operator
begin_operator
drive v5 l9 l5
0
1
0 0 11 7
1
end_operator
begin_operator
drive v5 l9 l6
0
1
0 0 11 8
1
end_operator
begin_operator
drive v5 l9 l8
0
1
0 0 11 10
1
end_operator
begin_operator
drop v1 l10 p3 c1 c2
1
3 1
2
0 13 2 0
0 6 0 1
1
end_operator
begin_operator
drop v1 l12 p2 c1 c2
1
3 3
2
0 10 2 0
0 6 0 1
1
end_operator
begin_operator
drop v1 l2 p10 c1 c2
1
3 4
2
0 12 2 0
0 6 0 1
1
end_operator
begin_operator
drop v1 l2 p8 c1 c2
1
3 4
2
0 15 2 1
0 6 0 1
1
end_operator
begin_operator
drop v1 l2 p9 c1 c2
1
3 4
2
0 17 2 1
0 6 0 1
1
end_operator
begin_operator
drop v1 l3 p5 c1 c2
1
3 5
2
0 16 2 1
0 6 0 1
1
end_operator
begin_operator
drop v1 l7 p7 c1 c2
1
3 9
2
0 14 2 0
0 6 0 1
1
end_operator
begin_operator
drop v2 l10 p3 c1 c2
1
2 1
2
0 13 3 0
0 7 0 1
1
end_operator
begin_operator
drop v2 l12 p1 c1 c2
1
2 3
2
0 11 2 0
0 7 0 1
1
end_operator
begin_operator
drop v2 l2 p10 c1 c2
1
2 4
2
0 12 3 0
0 7 0 1
1
end_operator
begin_operator
drop v2 l2 p8 c1 c2
1
2 4
2
0 15 3 1
0 7 0 1
1
end_operator
begin_operator
drop v2 l2 p9 c1 c2
1
2 4
2
0 17 3 1
0 7 0 1
1
end_operator
begin_operator
drop v2 l3 p5 c1 c2
1
2 5
2
0 16 3 1
0 7 0 1
1
end_operator
begin_operator
drop v2 l7 p7 c1 c2
1
2 9
2
0 14 3 0
0 7 0 1
1
end_operator
begin_operator
drop v4 l12 p1 c0 c1
1
1 3
2
0 11 3 0
0 4 0 1
1
end_operator
begin_operator
drop v4 l12 p2 c0 c1
1
1 3
2
0 10 3 0
0 4 0 1
1
end_operator
begin_operator
drop v4 l12 p4 c0 c1
1
1 3
2
0 8 2 0
0 4 0 1
1
end_operator
begin_operator
drop v5 l10 p6 c0 c1
1
0 1
2
0 9 2 0
0 5 0 1
1
end_operator
begin_operator
drop v5 l2 p8 c0 c1
1
0 4
2
0 15 4 1
0 5 0 1
1
end_operator
begin_operator
drop v5 l2 p9 c0 c1
1
0 4
2
0 17 4 1
0 5 0 1
1
end_operator
begin_operator
drop v5 l3 p5 c0 c1
1
0 5
2
0 16 4 1
0 5 0 1
1
end_operator
begin_operator
pick-up v1 l11 p8 c1 c2
1
3 2
2
0 15 0 2
0 6 1 0
1
end_operator
begin_operator
pick-up v1 l12 p5 c1 c2
1
3 3
2
0 16 0 2
0 6 1 0
1
end_operator
begin_operator
pick-up v1 l12 p9 c1 c2
1
3 3
2
0 17 0 2
0 6 1 0
1
end_operator
begin_operator
pick-up v1 l2 p3 c1 c2
1
3 4
2
0 13 1 2
0 6 1 0
1
end_operator
begin_operator
pick-up v1 l3 p2 c1 c2
1
3 5
2
0 10 1 2
0 6 1 0
1
end_operator
begin_operator
pick-up v1 l9 p10 c1 c2
1
3 11
2
0 12 1 2
0 6 1 0
1
end_operator
begin_operator
pick-up v1 l9 p7 c1 c2
1
3 11
2
0 14 1 2
0 6 1 0
1
end_operator
begin_operator
pick-up v2 l11 p8 c1 c2
1
2 2
2
0 15 0 3
0 7 1 0
1
end_operator
begin_operator
pick-up v2 l12 p5 c1 c2
1
2 3
2
0 16 0 3
0 7 1 0
1
end_operator
begin_operator
pick-up v2 l12 p9 c1 c2
1
2 3
2
0 17 0 3
0 7 1 0
1
end_operator
begin_operator
pick-up v2 l2 p3 c1 c2
1
2 4
2
0 13 1 3
0 7 1 0
1
end_operator
begin_operator
pick-up v2 l4 p1 c1 c2
1
2 6
2
0 11 1 2
0 7 1 0
1
end_operator
begin_operator
pick-up v2 l9 p10 c1 c2
1
2 11
2
0 12 1 3
0 7 1 0
1
end_operator
begin_operator
pick-up v2 l9 p7 c1 c2
1
2 11
2
0 14 1 3
0 7 1 0
1
end_operator
begin_operator
pick-up v4 l3 p2 c0 c1
1
1 5
2
0 10 1 3
0 4 1 0
1
end_operator
begin_operator
pick-up v4 l4 p1 c0 c1
1
1 6
2
0 11 1 3
0 4 1 0
1
end_operator
begin_operator
pick-up v4 l5 p4 c0 c1
1
1 7
2
0 8 1 2
0 4 1 0
1
end_operator
begin_operator
pick-up v5 l11 p8 c0 c1
1
0 2
2
0 15 0 4
0 5 1 0
1
end_operator
begin_operator
pick-up v5 l12 p5 c0 c1
1
0 3
2
0 16 0 4
0 5 1 0
1
end_operator
begin_operator
pick-up v5 l12 p9 c0 c1
1
0 3
2
0 17 0 4
0 5 1 0
1
end_operator
begin_operator
pick-up v5 l7 p6 c0 c1
1
0 9
2
0 9 1 2
0 5 1 0
1
end_operator
0
