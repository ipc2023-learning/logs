begin_version
3
end_version
begin_metric
0
end_metric
7
begin_variable
var1
-1
6
Atom at(v2, l1)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
end_variable
begin_variable
var2
-1
6
Atom at(v1, l1)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
end_variable
begin_variable
var4
-1
2
Atom capacity(v1, c0)
Atom capacity(v1, c1)
end_variable
begin_variable
var5
-1
2
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var7
-1
3
Atom at(p2, l2)
Atom at(p2, l5)
Atom in(p2, v2)
end_variable
begin_variable
var8
-1
3
Atom at(p3, l3)
Atom at(p3, l5)
Atom in(p3, v2)
end_variable
begin_variable
var6
-1
4
Atom at(p1, l2)
Atom at(p1, l4)
Atom in(p1, v1)
Atom in(p1, v2)
end_variable
10
begin_mutex_group
2
2 1
6 2
end_mutex_group
begin_mutex_group
2
3 1
6 3
end_mutex_group
begin_mutex_group
2
3 1
4 2
end_mutex_group
begin_mutex_group
2
3 1
5 2
end_mutex_group
begin_mutex_group
2
6 3
4 2
end_mutex_group
begin_mutex_group
2
6 3
5 2
end_mutex_group
begin_mutex_group
2
4 2
5 2
end_mutex_group
begin_mutex_group
2
2 0
6 0
end_mutex_group
begin_mutex_group
2
2 0
6 1
end_mutex_group
begin_mutex_group
2
2 0
6 3
end_mutex_group
begin_state
2
3
1
1
1
0
0
end_state
begin_goal
3
4 0
5 1
6 1
end_goal
68
begin_operator
drive v1 l1 l2
0
1
0 1 0 1
1
end_operator
begin_operator
drive v1 l1 l3
0
1
0 1 0 2
1
end_operator
begin_operator
drive v1 l1 l4
0
1
0 1 0 3
1
end_operator
begin_operator
drive v1 l1 l5
0
1
0 1 0 4
1
end_operator
begin_operator
drive v1 l1 l6
0
1
0 1 0 5
1
end_operator
begin_operator
drive v1 l2 l1
0
1
0 1 1 0
1
end_operator
begin_operator
drive v1 l2 l3
0
1
0 1 1 2
1
end_operator
begin_operator
drive v1 l2 l4
0
1
0 1 1 3
1
end_operator
begin_operator
drive v1 l2 l5
0
1
0 1 1 4
1
end_operator
begin_operator
drive v1 l2 l6
0
1
0 1 1 5
1
end_operator
begin_operator
drive v1 l3 l1
0
1
0 1 2 0
1
end_operator
begin_operator
drive v1 l3 l2
0
1
0 1 2 1
1
end_operator
begin_operator
drive v1 l3 l4
0
1
0 1 2 3
1
end_operator
begin_operator
drive v1 l3 l5
0
1
0 1 2 4
1
end_operator
begin_operator
drive v1 l3 l6
0
1
0 1 2 5
1
end_operator
begin_operator
drive v1 l4 l1
0
1
0 1 3 0
1
end_operator
begin_operator
drive v1 l4 l2
0
1
0 1 3 1
1
end_operator
begin_operator
drive v1 l4 l3
0
1
0 1 3 2
1
end_operator
begin_operator
drive v1 l4 l5
0
1
0 1 3 4
1
end_operator
begin_operator
drive v1 l4 l6
0
1
0 1 3 5
1
end_operator
begin_operator
drive v1 l5 l1
0
1
0 1 4 0
1
end_operator
begin_operator
drive v1 l5 l2
0
1
0 1 4 1
1
end_operator
begin_operator
drive v1 l5 l3
0
1
0 1 4 2
1
end_operator
begin_operator
drive v1 l5 l4
0
1
0 1 4 3
1
end_operator
begin_operator
drive v1 l5 l6
0
1
0 1 4 5
1
end_operator
begin_operator
drive v1 l6 l1
0
1
0 1 5 0
1
end_operator
begin_operator
drive v1 l6 l2
0
1
0 1 5 1
1
end_operator
begin_operator
drive v1 l6 l3
0
1
0 1 5 2
1
end_operator
begin_operator
drive v1 l6 l4
0
1
0 1 5 3
1
end_operator
begin_operator
drive v1 l6 l5
0
1
0 1 5 4
1
end_operator
begin_operator
drive v2 l1 l2
0
1
0 0 0 1
1
end_operator
begin_operator
drive v2 l1 l3
0
1
0 0 0 2
1
end_operator
begin_operator
drive v2 l1 l4
0
1
0 0 0 3
1
end_operator
begin_operator
drive v2 l1 l5
0
1
0 0 0 4
1
end_operator
begin_operator
drive v2 l1 l6
0
1
0 0 0 5
1
end_operator
begin_operator
drive v2 l2 l1
0
1
0 0 1 0
1
end_operator
begin_operator
drive v2 l2 l3
0
1
0 0 1 2
1
end_operator
begin_operator
drive v2 l2 l4
0
1
0 0 1 3
1
end_operator
begin_operator
drive v2 l2 l5
0
1
0 0 1 4
1
end_operator
begin_operator
drive v2 l2 l6
0
1
0 0 1 5
1
end_operator
begin_operator
drive v2 l3 l1
0
1
0 0 2 0
1
end_operator
begin_operator
drive v2 l3 l2
0
1
0 0 2 1
1
end_operator
begin_operator
drive v2 l3 l4
0
1
0 0 2 3
1
end_operator
begin_operator
drive v2 l3 l5
0
1
0 0 2 4
1
end_operator
begin_operator
drive v2 l3 l6
0
1
0 0 2 5
1
end_operator
begin_operator
drive v2 l4 l1
0
1
0 0 3 0
1
end_operator
begin_operator
drive v2 l4 l2
0
1
0 0 3 1
1
end_operator
begin_operator
drive v2 l4 l3
0
1
0 0 3 2
1
end_operator
begin_operator
drive v2 l4 l5
0
1
0 0 3 4
1
end_operator
begin_operator
drive v2 l4 l6
0
1
0 0 3 5
1
end_operator
begin_operator
drive v2 l5 l1
0
1
0 0 4 0
1
end_operator
begin_operator
drive v2 l5 l2
0
1
0 0 4 1
1
end_operator
begin_operator
drive v2 l5 l3
0
1
0 0 4 2
1
end_operator
begin_operator
drive v2 l5 l4
0
1
0 0 4 3
1
end_operator
begin_operator
drive v2 l5 l6
0
1
0 0 4 5
1
end_operator
begin_operator
drive v2 l6 l1
0
1
0 0 5 0
1
end_operator
begin_operator
drive v2 l6 l2
0
1
0 0 5 1
1
end_operator
begin_operator
drive v2 l6 l3
0
1
0 0 5 2
1
end_operator
begin_operator
drive v2 l6 l4
0
1
0 0 5 3
1
end_operator
begin_operator
drive v2 l6 l5
0
1
0 0 5 4
1
end_operator
begin_operator
drop v1 l4 p1 c0 c1
1
1 3
2
0 6 2 1
0 2 0 1
1
end_operator
begin_operator
drop v2 l2 p2 c1 c2
1
0 1
2
0 4 2 0
0 3 0 1
1
end_operator
begin_operator
drop v2 l4 p1 c1 c2
1
0 3
2
0 6 3 1
0 3 0 1
1
end_operator
begin_operator
drop v2 l5 p3 c1 c2
1
0 4
2
0 5 2 1
0 3 0 1
1
end_operator
begin_operator
pick-up v1 l2 p1 c0 c1
1
1 1
2
0 6 0 2
0 2 1 0
1
end_operator
begin_operator
pick-up v2 l2 p1 c1 c2
1
0 1
2
0 6 0 3
0 3 1 0
1
end_operator
begin_operator
pick-up v2 l3 p3 c1 c2
1
0 2
2
0 5 0 2
0 3 1 0
1
end_operator
begin_operator
pick-up v2 l5 p2 c1 c2
1
0 4
2
0 4 1 2
0 3 1 0
1
end_operator
0
