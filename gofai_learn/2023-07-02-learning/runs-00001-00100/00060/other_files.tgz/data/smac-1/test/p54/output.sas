begin_version
3
end_version
begin_metric
0
end_metric
19
begin_variable
var0
-1
9
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l9)
end_variable
begin_variable
var1
-1
9
Atom at(v4, l1)
Atom at(v4, l10)
Atom at(v4, l11)
Atom at(v4, l2)
Atom at(v4, l3)
Atom at(v4, l4)
Atom at(v4, l6)
Atom at(v4, l7)
Atom at(v4, l9)
end_variable
begin_variable
var2
-1
11
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var3
-1
11
Atom at(v2, l1)
Atom at(v2, l10)
Atom at(v2, l11)
Atom at(v2, l2)
Atom at(v2, l3)
Atom at(v2, l4)
Atom at(v2, l5)
Atom at(v2, l6)
Atom at(v2, l7)
Atom at(v2, l8)
Atom at(v2, l9)
end_variable
begin_variable
var4
-1
11
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var5
-1
2
Atom capacity(v5, c0)
Atom capacity(v5, c1)
end_variable
begin_variable
var6
-1
2
Atom capacity(v4, c0)
Atom capacity(v4, c1)
end_variable
begin_variable
var7
-1
2
Atom capacity(v3, c0)
Atom capacity(v3, c1)
end_variable
begin_variable
var8
-1
2
Atom capacity(v1, c0)
Atom capacity(v1, c1)
end_variable
begin_variable
var9
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var16
-1
3
Atom at(p7, l10)
Atom at(p7, l8)
Atom in(p7, v2)
end_variable
begin_variable
var11
-1
5
Atom at(p2, l2)
Atom at(p2, l6)
Atom at(p2, l9)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var13
-1
7
Atom at(p4, l1)
Atom at(p4, l11)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
end_variable
begin_variable
var10
-1
5
Atom at(p1, l10)
Atom at(p1, l3)
Atom in(p1, v2)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var12
-1
8
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
end_variable
begin_variable
var14
-1
9
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l4)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
end_variable
begin_variable
var15
-1
8
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l8)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
end_variable
begin_variable
var17
-1
5
Atom at(p8, l11)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
end_variable
begin_variable
var18
-1
5
Atom at(p9, l1)
Atom at(p9, l10)
Atom in(p9, v2)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
98
begin_mutex_group
2
5 1
13 4
end_mutex_group
begin_mutex_group
2
5 1
11 4
end_mutex_group
begin_mutex_group
2
5 1
18 4
end_mutex_group
begin_mutex_group
2
6 1
13 3
end_mutex_group
begin_mutex_group
2
6 1
11 3
end_mutex_group
begin_mutex_group
2
6 1
18 3
end_mutex_group
begin_mutex_group
2
7 1
14 7
end_mutex_group
begin_mutex_group
2
7 1
15 8
end_mutex_group
begin_mutex_group
2
7 1
16 7
end_mutex_group
begin_mutex_group
2
7 1
17 4
end_mutex_group
begin_mutex_group
2
8 1
14 5
end_mutex_group
begin_mutex_group
2
8 1
12 5
end_mutex_group
begin_mutex_group
2
8 1
15 6
end_mutex_group
begin_mutex_group
2
8 1
16 5
end_mutex_group
begin_mutex_group
2
8 1
17 2
end_mutex_group
begin_mutex_group
2
13 3
11 3
end_mutex_group
begin_mutex_group
2
13 3
18 3
end_mutex_group
begin_mutex_group
2
13 4
11 4
end_mutex_group
begin_mutex_group
2
13 4
18 4
end_mutex_group
begin_mutex_group
2
11 3
18 3
end_mutex_group
begin_mutex_group
2
11 4
18 4
end_mutex_group
begin_mutex_group
2
14 5
12 5
end_mutex_group
begin_mutex_group
2
14 5
15 6
end_mutex_group
begin_mutex_group
2
14 5
16 5
end_mutex_group
begin_mutex_group
2
14 5
17 2
end_mutex_group
begin_mutex_group
2
14 7
15 8
end_mutex_group
begin_mutex_group
2
14 7
16 7
end_mutex_group
begin_mutex_group
2
14 7
17 4
end_mutex_group
begin_mutex_group
2
12 5
15 6
end_mutex_group
begin_mutex_group
2
12 5
16 5
end_mutex_group
begin_mutex_group
2
12 5
17 2
end_mutex_group
begin_mutex_group
2
15 6
16 5
end_mutex_group
begin_mutex_group
2
15 6
17 2
end_mutex_group
begin_mutex_group
2
15 8
16 7
end_mutex_group
begin_mutex_group
2
15 8
17 4
end_mutex_group
begin_mutex_group
2
16 5
17 2
end_mutex_group
begin_mutex_group
2
16 7
17 4
end_mutex_group
begin_mutex_group
2
4 3
14 5
end_mutex_group
begin_mutex_group
2
4 3
12 5
end_mutex_group
begin_mutex_group
2
4 3
15 6
end_mutex_group
begin_mutex_group
2
4 3
16 5
end_mutex_group
begin_mutex_group
2
4 3
17 2
end_mutex_group
begin_mutex_group
2
4 7
14 5
end_mutex_group
begin_mutex_group
2
4 7
12 5
end_mutex_group
begin_mutex_group
2
4 7
15 6
end_mutex_group
begin_mutex_group
2
4 7
16 5
end_mutex_group
begin_mutex_group
2
4 7
17 2
end_mutex_group
begin_mutex_group
2
4 8
14 5
end_mutex_group
begin_mutex_group
2
4 8
12 5
end_mutex_group
begin_mutex_group
2
4 8
15 6
end_mutex_group
begin_mutex_group
2
4 8
16 5
end_mutex_group
begin_mutex_group
2
4 8
17 2
end_mutex_group
begin_




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




_operator
begin_operator
pick-up v2 l10 p1 c0 c1
1
3 1
2
0 13 0 2
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l10 p1 c1 c2
1
3 1
2
0 13 0 2
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l10 p3 c0 c1
1
3 1
2
0 14 0 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l10 p3 c1 c2
1
3 1
2
0 14 0 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l10 p5 c0 c1
1
3 1
2
0 15 0 7
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l10 p5 c1 c2
1
3 1
2
0 15 0 7
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l10 p6 c0 c1
1
3 1
2
0 16 1 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l10 p6 c1 c2
1
3 1
2
0 16 1 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l10 p7 c0 c1
1
3 1
2
0 10 0 2
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l10 p7 c1 c2
1
3 1
2
0 10 0 2
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l10 p9 c0 c1
1
3 1
2
0 18 1 2
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l10 p9 c1 c2
1
3 1
2
0 18 1 2
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l11 p3 c0 c1
1
3 2
2
0 14 1 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l11 p3 c1 c2
1
3 2
2
0 14 1 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l11 p4 c0 c1
1
3 2
2
0 12 1 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l11 p4 c1 c2
1
3 2
2
0 12 1 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l11 p5 c0 c1
1
3 2
2
0 15 1 7
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l11 p5 c1 c2
1
3 2
2
0 15 1 7
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l4 p3 c0 c1
1
3 5
2
0 14 2 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l4 p3 c1 c2
1
3 5
2
0 14 2 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l4 p5 c0 c1
1
3 5
2
0 15 3 7
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l4 p5 c1 c2
1
3 5
2
0 15 3 7
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l5 p3 c0 c1
1
3 6
2
0 14 3 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l5 p3 c1 c2
1
3 6
2
0 14 3 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l5 p4 c0 c1
1
3 6
2
0 12 3 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l5 p4 c1 c2
1
3 6
2
0 12 3 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l5 p6 c0 c1
1
3 6
2
0 16 3 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l5 p6 c1 c2
1
3 6
2
0 16 3 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l8 p5 c0 c1
1
3 9
2
0 15 4 7
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l8 p5 c1 c2
1
3 9
2
0 15 4 7
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l8 p6 c0 c1
1
3 9
2
0 16 4 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l8 p6 c1 c2
1
3 9
2
0 16 4 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l9 p3 c0 c1
1
3 10
2
0 14 4 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l9 p3 c1 c2
1
3 10
2
0 14 4 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l9 p4 c0 c1
1
3 10
2
0 12 4 6
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l9 p4 c1 c2
1
3 10
2
0 12 4 6
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l9 p5 c0 c1
1
3 10
2
0 15 5 7
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l9 p5 c1 c2
1
3 10
2
0 15 5 7
0 9 2 1
1
end_operator
begin_operator
pick-up v2 l9 p8 c0 c1
1
3 10
2
0 17 1 3
0 9 1 0
1
end_operator
begin_operator
pick-up v2 l9 p8 c1 c2
1
3 10
2
0 17 1 3
0 9 2 1
1
end_operator
begin_operator
pick-up v3 l1 p6 c0 c1
1
2 0
2
0 16 0 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l10 p3 c0 c1
1
2 1
2
0 14 0 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l10 p5 c0 c1
1
2 1
2
0 15 0 8
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l10 p6 c0 c1
1
2 1
2
0 16 1 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l11 p3 c0 c1
1
2 2
2
0 14 1 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l11 p5 c0 c1
1
2 2
2
0 15 1 8
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l4 p3 c0 c1
1
2 5
2
0 14 2 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l4 p5 c0 c1
1
2 5
2
0 15 3 8
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l5 p3 c0 c1
1
2 6
2
0 14 3 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l5 p6 c0 c1
1
2 6
2
0 16 3 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l8 p5 c0 c1
1
2 9
2
0 15 4 8
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l8 p6 c0 c1
1
2 9
2
0 16 4 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l9 p3 c0 c1
1
2 10
2
0 14 4 7
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l9 p5 c0 c1
1
2 10
2
0 15 5 8
0 7 1 0
1
end_operator
begin_operator
pick-up v3 l9 p8 c0 c1
1
2 10
2
0 17 1 4
0 7 1 0
1
end_operator
begin_operator
pick-up v4 l10 p1 c0 c1
1
1 1
2
0 13 0 3
0 6 1 0
1
end_operator
begin_operator
pick-up v4 l10 p9 c0 c1
1
1 1
2
0 18 1 3
0 6 1 0
1
end_operator
begin_operator
pick-up v4 l2 p2 c0 c1
1
1 3
2
0 11 0 3
0 6 1 0
1
end_operator
begin_operator
pick-up v4 l6 p2 c0 c1
1
1 6
2
0 11 1 3
0 6 1 0
1
end_operator
begin_operator
pick-up v4 l9 p2 c0 c1
1
1 8
2
0 11 2 3
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l10 p1 c0 c1
1
0 1
2
0 13 0 4
0 5 1 0
1
end_operator
begin_operator
pick-up v5 l10 p9 c0 c1
1
0 1
2
0 18 1 4
0 5 1 0
1
end_operator
begin_operator
pick-up v5 l2 p2 c0 c1
1
0 3
2
0 11 0 4
0 5 1 0
1
end_operator
begin_operator
pick-up v5 l6 p2 c0 c1
1
0 6
2
0 11 1 4
0 5 1 0
1
end_operator
begin_operator
pick-up v5 l9 p2 c0 c1
1
0 8
2
0 11 2 4
0 5 1 0
1
end_operator
0
