begin_version
3
end_version
begin_metric
0
end_metric
59
begin_variable
var0
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var1
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var2
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var7
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var3
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var4
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var5
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var6
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var8
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var12
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var17
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var19
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var10
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var9
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var14
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var11
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var13
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var15
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var16
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var18
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var20
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var21
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var22
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var23
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var25
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var24
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var26
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var27
-1
30
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b28)
Atom holding(b29)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var28
-1
3
Atom on(b12, b2)
Atom on(b12, b28)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b13, b3)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var30
-1
3
Atom on(b15, b11)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var31
-1
3
Atom on(b19, b16)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var32
-1
3
Atom on(b24, b14)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var33
-1
4
Atom on(b27, b7)
Atom on(b27, b8)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var54
-1
4
Atom on(b22, b20)
Atom on(b22, b24)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var34
-1
3
Atom on(b28, b1)
Atom on-table(b28)
<none of those>
end_variable
begin_variable
var35
-1
2
Atom clear(b28)
NegatedAtom clear(b28)
end_variable
begin_variable
var36
-1
10
Atom on(b7, b10)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b16)
Atom on(b7, b19)
Atom on(b7, b27)
Atom on(b7, b29)
Atom on(b7, b4)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var44
-1
9
Atom on(b14, b10)
Atom on(b14, b15)
Atom on(b14, b20)
Atom on(b14, b23)
Atom on(b14, b27)
Atom on(b14, b29)
Atom on(b14, b7)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var37
-1
10
Atom on(b29, b13)
Atom on(b29, b14)
Atom on(b29, b16)
Atom on(b29, b2)
Atom on(b29, b20)
Atom on(b29, b27)
Atom on(b29, b5)
Atom on(b29, b7)
Atom on-table(b29)
<none of those>
end_variable
begin_variable
var38
-1
10
Atom on(b10, b14)
Atom on(b10, b16)
Atom on(b10, b19)
Atom on(b10, b20)
Atom on(b10, b25)
Atom on(b10, b27)
Atom on(b10, b29)
Atom on(b10, b7)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var46
-1
10
Atom on(b20, b10)
Atom on(b20, b14)
Atom on(b20, b16)
Atom on(b20, b21)
Atom on(b20, b23)
Atom on(b20, b26)
Atom on(b20, b29)
Atom on(b20, b7)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var55
-1
10
Atom on(b26, b10)
Atom on(b26, b14)
Atom on(b26, b16)
Atom on(b26, b23)
Atom on(b26, b27)
Atom on(b26, b29)
Atom on(b26, b5)
Atom on(b26, b7)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var39
-1
13
Atom on(b16, b10)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b19)
Atom on(b16, b20)
Atom on(b16, b23)
Atom on(b16, b26)
Atom on(b16, b27)
Atom on(b16, b29)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var40
-1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




8 0 1
0 56 14 23
1
end_operator
begin_operator
unstack b6 b26
0
4
0 27 0 26
0 11 -1 0
0 8 0 1
0 56 15 23
1
end_operator
begin_operator
unstack b6 b27
0
4
0 27 0 26
0 7 -1 0
0 8 0 1
0 56 16 23
1
end_operator
begin_operator
unstack b6 b29
0
4
0 27 0 26
0 58 -1 0
0 8 0 1
0 56 17 23
1
end_operator
begin_operator
unstack b6 b3
0
4
0 27 0 26
0 25 -1 0
0 8 0 1
0 56 18 23
1
end_operator
begin_operator
unstack b6 b4
0
4
0 27 0 26
0 14 -1 0
0 8 0 1
0 56 19 23
1
end_operator
begin_operator
unstack b6 b7
0
4
0 27 0 26
0 8 0 1
0 17 -1 0
0 56 20 23
1
end_operator
begin_operator
unstack b6 b9
0
4
0 27 0 26
0 8 0 1
0 16 -1 0
0 56 21 23
1
end_operator
begin_operator
unstack b7 b10
0
4
0 27 0 27
0 15 -1 0
0 17 0 1
0 37 0 9
1
end_operator
begin_operator
unstack b7 b13
0
4
0 27 0 27
0 4 -1 0
0 17 0 1
0 37 1 9
1
end_operator
begin_operator
unstack b7 b14
0
4
0 27 0 27
0 10 -1 0
0 17 0 1
0 37 2 9
1
end_operator
begin_operator
unstack b7 b16
0
4
0 27 0 27
0 18 -1 0
0 17 0 1
0 37 3 9
1
end_operator
begin_operator
unstack b7 b19
0
4
0 27 0 27
0 6 -1 0
0 17 0 1
0 37 4 9
1
end_operator
begin_operator
unstack b7 b27
0
4
0 27 0 27
0 7 -1 0
0 17 0 1
0 37 5 9
1
end_operator
begin_operator
unstack b7 b29
0
4
0 27 0 27
0 58 -1 0
0 17 0 1
0 37 6 9
1
end_operator
begin_operator
unstack b7 b4
0
4
0 27 0 27
0 14 -1 0
0 17 0 1
0 37 7 9
1
end_operator
begin_operator
unstack b8 b1
0
4
0 27 0 28
0 24 -1 0
0 12 0 1
0 57 0 25
1
end_operator
begin_operator
unstack b8 b10
0
4
0 27 0 28
0 15 -1 0
0 12 0 1
0 57 1 25
1
end_operator
begin_operator
unstack b8 b11
0
4
0 27 0 28
0 20 -1 0
0 12 0 1
0 57 2 25
1
end_operator
begin_operator
unstack b8 b13
0
4
0 27 0 28
0 4 -1 0
0 12 0 1
0 57 3 25
1
end_operator
begin_operator
unstack b8 b14
0
4
0 27 0 28
0 10 -1 0
0 12 0 1
0 57 4 25
1
end_operator
begin_operator
unstack b8 b15
0
4
0 27 0 28
0 2 -1 0
0 12 0 1
0 57 5 25
1
end_operator
begin_operator
unstack b8 b16
0
4
0 27 0 28
0 18 -1 0
0 12 0 1
0 57 6 25
1
end_operator
begin_operator
unstack b8 b17
0
4
0 27 0 28
0 13 -1 0
0 12 0 1
0 57 7 25
1
end_operator
begin_operator
unstack b8 b18
0
4
0 27 0 28
0 19 -1 0
0 12 0 1
0 57 8 25
1
end_operator
begin_operator
unstack b8 b19
0
4
0 27 0 28
0 6 -1 0
0 12 0 1
0 57 9 25
1
end_operator
begin_operator
unstack b8 b2
0
4
0 27 0 28
0 23 -1 0
0 12 0 1
0 57 10 25
1
end_operator
begin_operator
unstack b8 b20
0
4
0 27 0 28
0 9 -1 0
0 12 0 1
0 57 11 25
1
end_operator
begin_operator
unstack b8 b21
0
4
0 27 0 28
0 22 -1 0
0 12 0 1
0 57 12 25
1
end_operator
begin_operator
unstack b8 b22
0
4
0 27 0 28
0 3 -1 0
0 12 0 1
0 57 13 25
1
end_operator
begin_operator
unstack b8 b23
0
4
0 27 0 28
0 26 -1 0
0 12 0 1
0 57 14 25
1
end_operator
begin_operator
unstack b8 b25
0
4
0 27 0 28
0 21 -1 0
0 12 0 1
0 57 15 25
1
end_operator
begin_operator
unstack b8 b26
0
4
0 27 0 28
0 11 -1 0
0 12 0 1
0 57 16 25
1
end_operator
begin_operator
unstack b8 b27
0
4
0 27 0 28
0 7 -1 0
0 12 0 1
0 57 17 25
1
end_operator
begin_operator
unstack b8 b29
0
4
0 27 0 28
0 58 -1 0
0 12 0 1
0 57 18 25
1
end_operator
begin_operator
unstack b8 b3
0
4
0 27 0 28
0 25 -1 0
0 12 0 1
0 57 19 25
1
end_operator
begin_operator
unstack b8 b4
0
4
0 27 0 28
0 14 -1 0
0 12 0 1
0 57 20 25
1
end_operator
begin_operator
unstack b8 b5
0
4
0 27 0 28
0 5 -1 0
0 12 0 1
0 57 21 25
1
end_operator
begin_operator
unstack b8 b7
0
4
0 27 0 28
0 17 -1 0
0 12 0 1
0 57 22 25
1
end_operator
begin_operator
unstack b8 b9
0
4
0 27 0 28
0 12 0 1
0 16 -1 0
0 57 23 25
1
end_operator
begin_operator
unstack b9 b1
0
4
0 27 0 29
0 24 -1 0
0 16 0 1
0 52 0 20
1
end_operator
begin_operator
unstack b9 b10
0
4
0 27 0 29
0 15 -1 0
0 16 0 1
0 52 1 20
1
end_operator
begin_operator
unstack b9 b13
0
4
0 27 0 29
0 4 -1 0
0 16 0 1
0 52 2 20
1
end_operator
begin_operator
unstack b9 b16
0
4
0 27 0 29
0 18 -1 0
0 16 0 1
0 52 3 20
1
end_operator
begin_operator
unstack b9 b17
0
4
0 27 0 29
0 13 -1 0
0 16 0 1
0 52 4 20
1
end_operator
begin_operator
unstack b9 b18
0
4
0 27 0 29
0 19 -1 0
0 16 0 1
0 52 5 20
1
end_operator
begin_operator
unstack b9 b19
0
4
0 27 0 29
0 6 -1 0
0 16 0 1
0 52 6 20
1
end_operator
begin_operator
unstack b9 b2
0
4
0 27 0 29
0 23 -1 0
0 16 0 1
0 52 7 20
1
end_operator
begin_operator
unstack b9 b20
0
4
0 27 0 29
0 9 -1 0
0 16 0 1
0 52 8 20
1
end_operator
begin_operator
unstack b9 b21
0
4
0 27 0 29
0 22 -1 0
0 16 0 1
0 52 9 20
1
end_operator
begin_operator
unstack b9 b22
0
4
0 27 0 29
0 3 -1 0
0 16 0 1
0 52 10 20
1
end_operator
begin_operator
unstack b9 b23
0
4
0 27 0 29
0 26 -1 0
0 16 0 1
0 52 11 20
1
end_operator
begin_operator
unstack b9 b25
0
4
0 27 0 29
0 21 -1 0
0 16 0 1
0 52 12 20
1
end_operator
begin_operator
unstack b9 b26
0
4
0 27 0 29
0 11 -1 0
0 16 0 1
0 52 13 20
1
end_operator
begin_operator
unstack b9 b27
0
4
0 27 0 29
0 7 -1 0
0 16 0 1
0 52 14 20
1
end_operator
begin_operator
unstack b9 b29
0
4
0 27 0 29
0 58 -1 0
0 16 0 1
0 52 15 20
1
end_operator
begin_operator
unstack b9 b3
0
4
0 27 0 29
0 25 -1 0
0 16 0 1
0 52 16 20
1
end_operator
begin_operator
unstack b9 b4
0
4
0 27 0 29
0 14 -1 0
0 16 0 1
0 52 17 20
1
end_operator
begin_operator
unstack b9 b7
0
4
0 27 0 29
0 17 -1 0
0 16 0 1
0 52 18 20
1
end_operator
0
