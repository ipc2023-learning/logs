begin_version
3
end_version
begin_metric
0
end_metric
56
begin_variable
var0
-1
2
Atom on-table(b2)
NegatedAtom on-table(b2)
end_variable
begin_variable
var1
-1
2
Atom on-table(b11)
NegatedAtom on-table(b11)
end_variable
begin_variable
var2
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var3
-1
2
Atom clear(b9)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var5
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var7
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var10
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var9
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var8
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var11
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var13
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var12
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var14
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var17
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var18
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var15
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var16
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var19
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var21
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var20
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var22
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var23
-1
28
Atom arm-empty()
Atom holding(b1)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b28)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b4, b27)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom on(b17, b11)
Atom on(b17, b21)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom on(b7, b23)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b15, b7)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var28
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var41
-1
4
Atom on(b21, b22)
Atom on(b21, b25)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom clear(b15)
Atom on(b8, b15)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom on(b23, b11)
Atom on(b23, b4)
Atom on(b23, b7)
Atom on(b23, b9)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var42
-1
8
Atom on(b12, b10)
Atom on(b12, b14)
Atom on(b12, b18)
Atom on(b12, b24)
Atom on(b12, b28)
Atom on(b12, b3)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var31
-1
11
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b18)
Atom on(b19, b23)
Atom on(b19, b3)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var48
-1
12
Atom on(b5, b12)
Atom on(b5, b13)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b20)
Atom on(b5, b21)
Atom on(b5, b22)
Atom on(b5, b6)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var32
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var34
-1
18
Atom on(b20, b10)
Atom on(b20, b11)
Atom on(b20, b12)
Atom on(b20, b16)
Atom on(b20, b19)
Atom on(b20, b21)
Atom on(b20, b22)
Atom on(b20, b23)
Atom on(b20, b24)
Atom on(b20, b26)
Atom on(b20, b27)
Atom on(b20, b28)
Atom on(b20, b3)
Atom on(b20, b5)
Atom on(b20, b6)
Atom on(b20, b7)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var37
-1
18
Atom on(b26, b1)
Atom on(b26, b10)
Atom on(b26, b11)
Atom on(b26, b12)
Atom on(b26, b14)
Atom on(b26, b16)
Atom on(b26, b18)
Atom on(b26, b19)
Atom on(b26, b20)
Atom on(b26, b23)
Atom on(b26, b27)
Atom on(b26, b28)
Atom on(b26, b3)
Atom on(b26, b5)
Atom on(b26, b6)
Atom on(b26, b7)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var38
-1
19
Atom on(b27, b1)
Atom on(b27, b10)
Atom on(b27, b11)
Atom on(b27, b12)
Atom on(b27, b14)
Atom on(b27, b16)
Atom on(b27, b17)
Atom on(b27, b19)
Atom on(b27, b21)
Atom on(b27, b23)
Atom on(b27, b24)
Atom on(b27, b26)
Atom on(b27, b28)
Atom on(b27, b3)
Atom on(b27, b5)
Atom on(b27, b6)
Atom on(b27, b7)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var40
-1
19
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b12)
Atom on(b16, b17)
Atom on(b16, 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0 41 11 18
1
end_operator
begin_operator
unstack b28 b26
0
4
0 23 0 20
0 13 -1 0
0 50 0 3
0 41 12 18
1
end_operator
begin_operator
unstack b28 b3
0
4
0 23 0 20
0 50 0 3
0 52 -1 0
0 41 13 18
1
end_operator
begin_operator
unstack b28 b4
0
4
0 23 0 20
0 50 0 3
0 5 -1 0
0 41 14 18
1
end_operator
begin_operator
unstack b28 b5
0
4
0 23 0 20
0 50 0 3
0 12 -1 0
0 41 15 18
1
end_operator
begin_operator
unstack b28 b6
0
4
0 23 0 20
0 50 0 3
0 51 -1 0
0 41 16 18
1
end_operator
begin_operator
unstack b3 b1
0
4
0 23 0 21
0 22 -1 0
0 52 0 3
0 48 0 25
1
end_operator
begin_operator
unstack b3 b10
0
4
0 23 0 21
0 20 -1 0
0 52 0 3
0 48 1 25
1
end_operator
begin_operator
unstack b3 b11
0
4
0 23 0 21
0 7 -1 0
0 52 0 3
0 48 2 25
1
end_operator
begin_operator
unstack b3 b12
0
4
0 23 0 21
0 49 -1 0
0 52 0 3
0 48 3 25
1
end_operator
begin_operator
unstack b3 b13
0
4
0 23 0 21
0 35 -1 0
0 52 0 3
0 48 4 25
1
end_operator
begin_operator
unstack b3 b14
0
4
0 23 0 21
0 17 -1 0
0 52 0 3
0 48 5 25
1
end_operator
begin_operator
unstack b3 b16
0
4
0 23 0 21
0 16 -1 0
0 52 0 3
0 48 6 25
1
end_operator
begin_operator
unstack b3 b17
0
4
0 23 0 21
0 6 -1 0
0 52 0 3
0 48 7 25
1
end_operator
begin_operator
unstack b3 b18
0
4
0 23 0 21
0 19 -1 0
0 52 0 3
0 48 8 25
1
end_operator
begin_operator
unstack b3 b19
0
4
0 23 0 21
0 11 -1 0
0 52 0 3
0 48 9 25
1
end_operator
begin_operator
unstack b3 b20
0
4
0 23 0 21
0 14 -1 0
0 52 0 3
0 48 10 25
1
end_operator
begin_operator
unstack b3 b21
0
4
0 23 0 21
0 8 -1 0
0 52 0 3
0 48 11 25
1
end_operator
begin_operator
unstack b3 b22
0
4
0 23 0 21
0 18 -1 0
0 52 0 3
0 48 12 25
1
end_operator
begin_operator
unstack b3 b23
0
4
0 23 0 21
0 9 -1 0
0 52 0 3
0 48 13 25
1
end_operator
begin_operator
unstack b3 b24
0
4
0 23 0 21
0 21 -1 0
0 52 0 3
0 48 14 25
1
end_operator
begin_operator
unstack b3 b25
0
4
0 23 0 21
0 4 -1 0
0 52 0 3
0 48 15 25
1
end_operator
begin_operator
unstack b3 b26
0
4
0 23 0 21
0 13 -1 0
0 52 0 3
0 48 16 25
1
end_operator
begin_operator
unstack b3 b27
0
4
0 23 0 21
0 15 -1 0
0 52 0 3
0 48 17 25
1
end_operator
begin_operator
unstack b3 b4
0
4
0 23 0 21
0 52 0 3
0 5 -1 0
0 48 18 25
1
end_operator
begin_operator
unstack b3 b5
0
4
0 23 0 21
0 52 0 3
0 12 -1 0
0 48 19 25
1
end_operator
begin_operator
unstack b3 b6
0
4
0 23 0 21
0 52 0 3
0 51 -1 0
0 48 20 25
1
end_operator
begin_operator
unstack b3 b7
0
4
0 23 0 21
0 52 0 3
0 10 -1 0
0 48 21 25
1
end_operator
begin_operator
unstack b3 b8
0
4
0 23 0 21
0 52 0 3
0 2 -1 0
0 48 22 25
1
end_operator
begin_operator
unstack b3 b9
0
4
0 23 0 21
0 52 0 3
0 3 -1 0
0 48 23 25
1
end_operator
begin_operator
unstack b4 b27
0
4
0 23 0 22
0 15 -1 0
0 5 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b5 b12
0
4
0 23 0 23
0 49 -1 0
0 12 0 1
0 34 0 11
1
end_operator
begin_operator
unstack b5 b13
0
4
0 23 0 23
0 35 -1 0
0 12 0 1
0 34 1 11
1
end_operator
begin_operator
unstack b5 b18
0
4
0 23 0 23
0 19 -1 0
0 12 0 1
0 34 2 11
1
end_operator
begin_operator
unstack b5 b19
0
4
0 23 0 23
0 11 -1 0
0 12 0 1
0 34 3 11
1
end_operator
begin_operator
unstack b5 b20
0
4
0 23 0 23
0 14 -1 0
0 12 0 1
0 34 4 11
1
end_operator
begin_operator
unstack b5 b21
0
4
0 23 0 23
0 8 -1 0
0 12 0 1
0 34 5 11
1
end_operator
begin_operator
unstack b5 b22
0
4
0 23 0 23
0 18 -1 0
0 12 0 1
0 34 6 11
1
end_operator
begin_operator
unstack b5 b6
0
4
0 23 0 23
0 12 0 1
0 51 -1 0
0 34 7 11
1
end_operator
begin_operator
unstack b5 b7
0
4
0 23 0 23
0 12 0 1
0 10 -1 0
0 34 8 11
1
end_operator
begin_operator
unstack b6 b1
0
4
0 23 0 24
0 22 -1 0
0 51 0 1
0 44 0 19
1
end_operator
begin_operator
unstack b6 b12
0
4
0 23 0 24
0 49 -1 0
0 51 0 1
0 44 1 19
1
end_operator
begin_operator
unstack b6 b13
0
4
0 23 0 24
0 35 -1 0
0 51 0 1
0 44 2 19
1
end_operator
begin_operator
unstack b6 b14
0
4
0 23 0 24
0 17 -1 0
0 51 0 1
0 44 3 19
1
end_operator
begin_operator
unstack b6 b16
0
4
0 23 0 24
0 16 -1 0
0 51 0 1
0 44 4 19
1
end_operator
begin_operator
unstack b6 b17
0
4
0 23 0 24
0 6 -1 0
0 51 0 1
0 44 5 19
1
end_operator
begin_operator
unstack b6 b18
0
4
0 23 0 24
0 19 -1 0
0 51 0 1
0 44 6 19
1
end_operator
begin_operator
unstack b6 b19
0
4
0 23 0 24
0 11 -1 0
0 51 0 1
0 44 7 19
1
end_operator
begin_operator
unstack b6 b20
0
4
0 23 0 24
0 14 -1 0
0 51 0 1
0 44 8 19
1
end_operator
begin_operator
unstack b6 b21
0
4
0 23 0 24
0 8 -1 0
0 51 0 1
0 44 9 19
1
end_operator
begin_operator
unstack b6 b22
0
4
0 23 0 24
0 18 -1 0
0 51 0 1
0 44 10 19
1
end_operator
begin_operator
unstack b6 b24
0
4
0 23 0 24
0 21 -1 0
0 51 0 1
0 44 11 19
1
end_operator
begin_operator
unstack b6 b25
0
4
0 23 0 24
0 4 -1 0
0 51 0 1
0 44 12 19
1
end_operator
begin_operator
unstack b6 b27
0
4
0 23 0 24
0 15 -1 0
0 51 0 1
0 44 13 19
1
end_operator
begin_operator
unstack b6 b28
0
4
0 23 0 24
0 50 -1 0
0 51 0 1
0 44 14 19
1
end_operator
begin_operator
unstack b6 b3
0
4
0 23 0 24
0 52 -1 0
0 51 0 1
0 44 15 19
1
end_operator
begin_operator
unstack b6 b4
0
4
0 23 0 24
0 5 -1 0
0 51 0 1
0 44 16 19
1
end_operator
begin_operator
unstack b6 b5
0
4
0 23 0 24
0 12 -1 0
0 51 0 1
0 44 17 19
1
end_operator
begin_operator
unstack b8 b15
0
3
0 23 0 26
0 30 1 0
0 2 0 1
1
end_operator
0
