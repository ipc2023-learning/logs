begin_version
3
end_version
begin_metric
0
end_metric
54
begin_variable
var0
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var1
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var2
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var3
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var4
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var5
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var6
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var7
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var9
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var8
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var12
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var13
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var14
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var15
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var17
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var18
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var16
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var19
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var20
-1
27
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var21
-1
3
Atom on(b12, b4)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var22
-1
3
Atom on(b17, b18)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var23
-1
3
Atom on(b22, b8)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b5, b2)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var25
-1
3
Atom on(b9, b16)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var26
-1
4
Atom on(b1, b12)
Atom on(b1, b24)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b25, b24)
Atom on-table(b25)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b8, b19)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b23, b22)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var31
-1
4
Atom on(b13, b1)
Atom on(b13, b27)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var30
-1
3
Atom clear(b23)
Atom on(b21, b23)
<none of those>
end_variable
begin_variable
var35
-1
10
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b13)
Atom on(b19, b26)
Atom on(b19, b27)
Atom on(b19, b4)
Atom on(b19, b8)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var34
-1
18
Atom on(b18, b1)
Atom on(b18, b11)
Atom on(b18, b13)
Atom on(b18, b14)
Atom on(b18, b16)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b24)
Atom on(b18, b25)
Atom on(b18, b26)
Atom on(b18, b27)
Atom on(b18, b3)
Atom on(b18, b4)
Atom on(b18, b6)
Atom on(b18, b7)
Atom on(b18, b9)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var40
-1
19
Atom on(b16, b1)
Atom on(b16, b10)
Atom on(b16, b11)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b15)
Atom on(b16, b2)
Atom on(b16, b20)
Atom on(b16, b24)
Atom on(b16, b25)
Atom on(b16, b26)
Atom on(b16, b27)
Atom on(b16, b3)
Atom on(b16, b4)
Atom on(b16, b6)
Atom on(b16, b7)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var33
-1
19
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b13)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b24)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var38
-1
19
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b13)
Atom on(b14, b16)
Atom on(b14, b18)
Atom on(b14, b2)
Atom on(b14, b24)
Atom on(b14, b25)
Atom on(b14, b26)
Atom on(b14, b27)
Atom on(b14, b3)
Atom on(b14, b4)
Atom on(b14, b6)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on(b14, b9)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var39
-1
20
Atom on(b15, b1)
Atom on(b15, b10)
Atom on(b15, b11)
Atom on(b15, b13)
Atom on(b15, b14)
Atom on(b15, b16)
Atom on(b15, b18)
Atom on(b15, b19)
Atom on(b15, b2)
Atom on(b15, b25)
Atom on(b15, b26)
Atom on(b15, b27)
Atom on(b15, b3)
Atom on(b15, b4)
Atom on(b15,




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
0 43 7 21
1
end_operator
begin_operator
unstack b4 b18
0
4
0 20 0 21
0 10 -1 0
0 51 0 1
0 43 8 21
1
end_operator
begin_operator
unstack b4 b19
0
4
0 20 0 21
0 8 -1 0
0 51 0 1
0 43 9 21
1
end_operator
begin_operator
unstack b4 b2
0
4
0 20 0 21
0 11 -1 0
0 51 0 1
0 43 10 21
1
end_operator
begin_operator
unstack b4 b21
0
4
0 20 0 21
0 2 -1 0
0 51 0 1
0 43 11 21
1
end_operator
begin_operator
unstack b4 b22
0
4
0 20 0 21
0 5 -1 0
0 51 0 1
0 43 12 21
1
end_operator
begin_operator
unstack b4 b24
0
4
0 20 0 21
0 18 -1 0
0 51 0 1
0 43 13 21
1
end_operator
begin_operator
unstack b4 b26
0
4
0 20 0 21
0 17 -1 0
0 51 0 1
0 43 14 21
1
end_operator
begin_operator
unstack b4 b27
0
4
0 20 0 21
0 50 -1 0
0 51 0 1
0 43 15 21
1
end_operator
begin_operator
unstack b4 b3
0
4
0 20 0 21
0 19 -1 0
0 51 0 1
0 43 16 21
1
end_operator
begin_operator
unstack b4 b5
0
4
0 20 0 21
0 51 0 1
0 0 -1 0
0 43 17 21
1
end_operator
begin_operator
unstack b4 b7
0
4
0 20 0 21
0 51 0 1
0 15 -1 0
0 43 18 21
1
end_operator
begin_operator
unstack b4 b9
0
4
0 20 0 21
0 51 0 1
0 47 -1 0
0 43 19 21
1
end_operator
begin_operator
unstack b5 b2
0
4
0 20 0 22
0 11 -1 0
0 0 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b6 b1
0
4
0 20 0 23
0 7 -1 0
0 16 0 1
0 46 0 24
1
end_operator
begin_operator
unstack b6 b10
0
4
0 20 0 23
0 13 -1 0
0 16 0 1
0 46 1 24
1
end_operator
begin_operator
unstack b6 b11
0
4
0 20 0 23
0 49 -1 0
0 16 0 1
0 46 2 24
1
end_operator
begin_operator
unstack b6 b12
0
4
0 20 0 23
0 3 -1 0
0 16 0 1
0 46 3 24
1
end_operator
begin_operator
unstack b6 b13
0
4
0 20 0 23
0 48 -1 0
0 16 0 1
0 46 4 24
1
end_operator
begin_operator
unstack b6 b14
0
4
0 20 0 23
0 9 -1 0
0 16 0 1
0 46 5 24
1
end_operator
begin_operator
unstack b6 b15
0
4
0 20 0 23
0 12 -1 0
0 16 0 1
0 46 6 24
1
end_operator
begin_operator
unstack b6 b16
0
4
0 20 0 23
0 14 -1 0
0 16 0 1
0 46 7 24
1
end_operator
begin_operator
unstack b6 b17
0
4
0 20 0 23
0 1 -1 0
0 16 0 1
0 46 8 24
1
end_operator
begin_operator
unstack b6 b18
0
4
0 20 0 23
0 10 -1 0
0 16 0 1
0 46 9 24
1
end_operator
begin_operator
unstack b6 b19
0
4
0 20 0 23
0 8 -1 0
0 16 0 1
0 46 10 24
1
end_operator
begin_operator
unstack b6 b21
0
4
0 20 0 23
0 2 -1 0
0 16 0 1
0 46 11 24
1
end_operator
begin_operator
unstack b6 b22
0
4
0 20 0 23
0 5 -1 0
0 16 0 1
0 46 12 24
1
end_operator
begin_operator
unstack b6 b24
0
4
0 20 0 23
0 18 -1 0
0 16 0 1
0 46 13 24
1
end_operator
begin_operator
unstack b6 b25
0
4
0 20 0 23
0 4 -1 0
0 16 0 1
0 46 14 24
1
end_operator
begin_operator
unstack b6 b26
0
4
0 20 0 23
0 17 -1 0
0 16 0 1
0 46 15 24
1
end_operator
begin_operator
unstack b6 b27
0
4
0 20 0 23
0 50 -1 0
0 16 0 1
0 46 16 24
1
end_operator
begin_operator
unstack b6 b3
0
4
0 20 0 23
0 19 -1 0
0 16 0 1
0 46 17 24
1
end_operator
begin_operator
unstack b6 b4
0
4
0 20 0 23
0 51 -1 0
0 16 0 1
0 46 18 24
1
end_operator
begin_operator
unstack b6 b5
0
4
0 20 0 23
0 0 -1 0
0 16 0 1
0 46 19 24
1
end_operator
begin_operator
unstack b6 b7
0
4
0 20 0 23
0 16 0 1
0 15 -1 0
0 46 20 24
1
end_operator
begin_operator
unstack b6 b8
0
4
0 20 0 23
0 16 0 1
0 6 -1 0
0 46 21 24
1
end_operator
begin_operator
unstack b6 b9
0
4
0 20 0 23
0 16 0 1
0 47 -1 0
0 46 22 24
1
end_operator
begin_operator
unstack b7 b1
0
4
0 20 0 24
0 7 -1 0
0 15 0 1
0 41 0 21
1
end_operator
begin_operator
unstack b7 b10
0
4
0 20 0 24
0 13 -1 0
0 15 0 1
0 41 1 21
1
end_operator
begin_operator
unstack b7 b11
0
4
0 20 0 24
0 49 -1 0
0 15 0 1
0 41 2 21
1
end_operator
begin_operator
unstack b7 b12
0
4
0 20 0 24
0 3 -1 0
0 15 0 1
0 41 3 21
1
end_operator
begin_operator
unstack b7 b13
0
4
0 20 0 24
0 48 -1 0
0 15 0 1
0 41 4 21
1
end_operator
begin_operator
unstack b7 b14
0
4
0 20 0 24
0 9 -1 0
0 15 0 1
0 41 5 21
1
end_operator
begin_operator
unstack b7 b15
0
4
0 20 0 24
0 12 -1 0
0 15 0 1
0 41 6 21
1
end_operator
begin_operator
unstack b7 b16
0
4
0 20 0 24
0 14 -1 0
0 15 0 1
0 41 7 21
1
end_operator
begin_operator
unstack b7 b18
0
4
0 20 0 24
0 10 -1 0
0 15 0 1
0 41 8 21
1
end_operator
begin_operator
unstack b7 b19
0
4
0 20 0 24
0 8 -1 0
0 15 0 1
0 41 9 21
1
end_operator
begin_operator
unstack b7 b21
0
4
0 20 0 24
0 2 -1 0
0 15 0 1
0 41 10 21
1
end_operator
begin_operator
unstack b7 b22
0
4
0 20 0 24
0 5 -1 0
0 15 0 1
0 41 11 21
1
end_operator
begin_operator
unstack b7 b24
0
4
0 20 0 24
0 18 -1 0
0 15 0 1
0 41 12 21
1
end_operator
begin_operator
unstack b7 b26
0
4
0 20 0 24
0 17 -1 0
0 15 0 1
0 41 13 21
1
end_operator
begin_operator
unstack b7 b27
0
4
0 20 0 24
0 50 -1 0
0 15 0 1
0 41 14 21
1
end_operator
begin_operator
unstack b7 b3
0
4
0 20 0 24
0 19 -1 0
0 15 0 1
0 41 15 21
1
end_operator
begin_operator
unstack b7 b4
0
4
0 20 0 24
0 51 -1 0
0 15 0 1
0 41 16 21
1
end_operator
begin_operator
unstack b7 b5
0
4
0 20 0 24
0 0 -1 0
0 15 0 1
0 41 17 21
1
end_operator
begin_operator
unstack b7 b6
0
4
0 20 0 24
0 16 -1 0
0 15 0 1
0 41 18 21
1
end_operator
begin_operator
unstack b7 b9
0
4
0 20 0 24
0 15 0 1
0 47 -1 0
0 41 19 21
1
end_operator
begin_operator
unstack b8 b19
0
4
0 20 0 25
0 8 -1 0
0 6 0 1
0 28 0 2
1
end_operator
begin_operator
unstack b9 b16
0
4
0 20 0 26
0 14 -1 0
0 47 0 1
0 25 0 2
1
end_operator
0
