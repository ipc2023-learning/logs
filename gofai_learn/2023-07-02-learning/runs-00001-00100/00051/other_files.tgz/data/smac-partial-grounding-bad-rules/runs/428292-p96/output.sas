begin_version
3
end_version
begin_metric
0
end_metric
56
begin_variable
var0
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var1
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var13
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var5
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var2
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var4
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var9
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var3
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var7
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var6
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var8
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var11
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var12
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var10
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var14
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var15
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var16
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var17
-1
2
Atom clear(b28)
NegatedAtom clear(b28)
end_variable
begin_variable
var18
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var19
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var20
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var21
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var22
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var23
-1
28
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b28)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
end_variable
begin_variable
var24
-1
3
Atom on(b11, b28)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var25
-1
3
Atom on(b7, b23)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var32
-1
4
Atom on(b18, b13)
Atom on(b18, b22)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var36
-1
4
Atom on(b17, b11)
Atom on(b17, b21)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var26
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var27
-1
3
Atom on(b2, b3)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b15, b7)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var30
-1
4
Atom on(b5, b7)
Atom on(b5, b8)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var47
-1
4
Atom on(b21, b22)
Atom on(b21, b25)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom clear(b15)
Atom on(b8, b15)
<none of those>
end_variable
begin_variable
var31
-1
11
Atom on(b10, b12)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b8)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var33
-1
10
Atom on(b20, b10)
Atom on(b20, b12)
Atom on(b20, b19)
Atom on(b20, b21)
Atom on(b20, b23)
Atom on(b20, b26)
Atom on(b20, b6)
Atom on(b20, b7)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var34
-1
12
Atom on(b22, b10)
Atom on(b22, b11)
Atom on(b22, b12)
Atom on(b22, b14)
Atom on(b22, b16)
Atom on(b22, b18)
Atom on(b22, b19)
Atom on(b22, b20)
Atom on(b22, b6)
Atom on(b22, b7)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var49
-1
12
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b14)
Atom on(b12, b18)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b28)
Atom on(b12, b3)
Atom on(b12, b7)
Atom on(b12, b9)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var37
-1
16
Atom on(b26, b1)
Atom on(b26, b10)
Atom on(b26, b12)
Atom on(b26, b13)
Atom on(b26, b16)
Atom on(b26, b18)
Atom on(b26, b19)
Atom on(b26, b20)
Atom on(b26, b23)
Atom on(b26, b27)
Atom on(b26, b28)
Atom on(b26, b3)
Atom on(b26, b6)
Atom on(b26, b7)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var38
-1
16
Atom on(b27, b1)
Atom on(b27, b10)
Atom on(b27, b11)
Atom on(b27, b12)
Atom on(b27, b13)
Atom on(b27, b14)
Atom on(b27, b16)
Atom on(b27, b17)
Atom on(b27, b19)
Atom on(b27, b23)
Atom on(b27, b24)
Atom on(b27, b28)
Atom on(b27, b6)
Atom on(b27, b7)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var35
-1
17
Atom on(b28, b1)
Atom on(b28, b10)
Atom on(b28, b12)
Atom on(b28, b13)
Atom on(b28, b16)
Atom on(b28, b17)
Atom on(b28, b18)
Atom on(b28, b19)
Atom on(b28, b20)
Atom o




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 0
0 20 0 1
0 49 0 22
1
end_operator
begin_operator
unstack b3 b11
0
4
0 23 0 22
0 4 -1 0
0 20 0 1
0 49 1 22
1
end_operator
begin_operator
unstack b3 b12
0
4
0 23 0 22
0 54 -1 0
0 20 0 1
0 49 2 22
1
end_operator
begin_operator
unstack b3 b13
0
4
0 23 0 22
0 52 -1 0
0 20 0 1
0 49 3 22
1
end_operator
begin_operator
unstack b3 b14
0
4
0 23 0 22
0 15 -1 0
0 20 0 1
0 49 4 22
1
end_operator
begin_operator
unstack b3 b16
0
4
0 23 0 22
0 18 -1 0
0 20 0 1
0 49 5 22
1
end_operator
begin_operator
unstack b3 b17
0
4
0 23 0 22
0 3 -1 0
0 20 0 1
0 49 6 22
1
end_operator
begin_operator
unstack b3 b18
0
4
0 23 0 22
0 5 -1 0
0 20 0 1
0 49 7 22
1
end_operator
begin_operator
unstack b3 b19
0
4
0 23 0 22
0 21 -1 0
0 20 0 1
0 49 8 22
1
end_operator
begin_operator
unstack b3 b20
0
4
0 23 0 22
0 8 -1 0
0 20 0 1
0 49 9 22
1
end_operator
begin_operator
unstack b3 b21
0
4
0 23 0 22
0 6 -1 0
0 20 0 1
0 49 10 22
1
end_operator
begin_operator
unstack b3 b22
0
4
0 23 0 22
0 9 -1 0
0 20 0 1
0 49 11 22
1
end_operator
begin_operator
unstack b3 b23
0
4
0 23 0 22
0 22 -1 0
0 20 0 1
0 49 12 22
1
end_operator
begin_operator
unstack b3 b24
0
4
0 23 0 22
0 16 -1 0
0 20 0 1
0 49 13 22
1
end_operator
begin_operator
unstack b3 b25
0
4
0 23 0 22
0 13 -1 0
0 20 0 1
0 49 14 22
1
end_operator
begin_operator
unstack b3 b26
0
4
0 23 0 22
0 11 -1 0
0 20 0 1
0 49 15 22
1
end_operator
begin_operator
unstack b3 b27
0
4
0 23 0 22
0 12 -1 0
0 20 0 1
0 49 16 22
1
end_operator
begin_operator
unstack b3 b4
0
4
0 23 0 22
0 20 0 1
0 14 -1 0
0 49 17 22
1
end_operator
begin_operator
unstack b3 b6
0
4
0 23 0 22
0 20 0 1
0 53 -1 0
0 49 18 22
1
end_operator
begin_operator
unstack b3 b7
0
4
0 23 0 22
0 20 0 1
0 7 -1 0
0 49 19 22
1
end_operator
begin_operator
unstack b3 b9
0
4
0 23 0 22
0 20 0 1
0 2 -1 0
0 49 20 22
1
end_operator
begin_operator
unstack b4 b1
0
4
0 23 0 23
0 19 -1 0
0 14 0 1
0 47 0 20
1
end_operator
begin_operator
unstack b4 b10
0
4
0 23 0 23
0 10 -1 0
0 14 0 1
0 47 1 20
1
end_operator
begin_operator
unstack b4 b11
0
4
0 23 0 23
0 4 -1 0
0 14 0 1
0 47 2 20
1
end_operator
begin_operator
unstack b4 b12
0
4
0 23 0 23
0 54 -1 0
0 14 0 1
0 47 3 20
1
end_operator
begin_operator
unstack b4 b13
0
4
0 23 0 23
0 52 -1 0
0 14 0 1
0 47 4 20
1
end_operator
begin_operator
unstack b4 b16
0
4
0 23 0 23
0 18 -1 0
0 14 0 1
0 47 5 20
1
end_operator
begin_operator
unstack b4 b17
0
4
0 23 0 23
0 3 -1 0
0 14 0 1
0 47 6 20
1
end_operator
begin_operator
unstack b4 b18
0
4
0 23 0 23
0 5 -1 0
0 14 0 1
0 47 7 20
1
end_operator
begin_operator
unstack b4 b19
0
4
0 23 0 23
0 21 -1 0
0 14 0 1
0 47 8 20
1
end_operator
begin_operator
unstack b4 b20
0
4
0 23 0 23
0 8 -1 0
0 14 0 1
0 47 9 20
1
end_operator
begin_operator
unstack b4 b21
0
4
0 23 0 23
0 6 -1 0
0 14 0 1
0 47 10 20
1
end_operator
begin_operator
unstack b4 b22
0
4
0 23 0 23
0 9 -1 0
0 14 0 1
0 47 11 20
1
end_operator
begin_operator
unstack b4 b23
0
4
0 23 0 23
0 22 -1 0
0 14 0 1
0 47 12 20
1
end_operator
begin_operator
unstack b4 b24
0
4
0 23 0 23
0 16 -1 0
0 14 0 1
0 47 13 20
1
end_operator
begin_operator
unstack b4 b26
0
4
0 23 0 23
0 11 -1 0
0 14 0 1
0 47 14 20
1
end_operator
begin_operator
unstack b4 b27
0
4
0 23 0 23
0 12 -1 0
0 14 0 1
0 47 15 20
1
end_operator
begin_operator
unstack b4 b28
0
4
0 23 0 23
0 17 -1 0
0 14 0 1
0 47 16 20
1
end_operator
begin_operator
unstack b4 b6
0
4
0 23 0 23
0 14 0 1
0 53 -1 0
0 47 17 20
1
end_operator
begin_operator
unstack b4 b7
0
4
0 23 0 23
0 14 0 1
0 7 -1 0
0 47 18 20
1
end_operator
begin_operator
unstack b5 b7
0
4
0 23 0 24
0 1 0 1
0 7 -1 0
0 31 0 3
1
end_operator
begin_operator
unstack b6 b12
0
4
0 23 0 25
0 54 -1 0
0 53 0 1
0 43 0 17
1
end_operator
begin_operator
unstack b6 b13
0
4
0 23 0 25
0 52 -1 0
0 53 0 1
0 43 1 17
1
end_operator
begin_operator
unstack b6 b14
0
4
0 23 0 25
0 15 -1 0
0 53 0 1
0 43 2 17
1
end_operator
begin_operator
unstack b6 b16
0
4
0 23 0 25
0 18 -1 0
0 53 0 1
0 43 3 17
1
end_operator
begin_operator
unstack b6 b19
0
4
0 23 0 25
0 21 -1 0
0 53 0 1
0 43 4 17
1
end_operator
begin_operator
unstack b6 b20
0
4
0 23 0 25
0 8 -1 0
0 53 0 1
0 43 5 17
1
end_operator
begin_operator
unstack b6 b21
0
4
0 23 0 25
0 6 -1 0
0 53 0 1
0 43 6 17
1
end_operator
begin_operator
unstack b6 b22
0
4
0 23 0 25
0 9 -1 0
0 53 0 1
0 43 7 17
1
end_operator
begin_operator
unstack b6 b23
0
4
0 23 0 25
0 22 -1 0
0 53 0 1
0 43 8 17
1
end_operator
begin_operator
unstack b6 b25
0
4
0 23 0 25
0 13 -1 0
0 53 0 1
0 43 9 17
1
end_operator
begin_operator
unstack b6 b27
0
4
0 23 0 25
0 12 -1 0
0 53 0 1
0 43 10 17
1
end_operator
begin_operator
unstack b6 b28
0
4
0 23 0 25
0 17 -1 0
0 53 0 1
0 43 11 17
1
end_operator
begin_operator
unstack b6 b3
0
4
0 23 0 25
0 20 -1 0
0 53 0 1
0 43 12 17
1
end_operator
begin_operator
unstack b6 b4
0
4
0 23 0 25
0 14 -1 0
0 53 0 1
0 43 13 17
1
end_operator
begin_operator
unstack b6 b7
0
4
0 23 0 25
0 53 0 1
0 7 -1 0
0 43 14 17
1
end_operator
begin_operator
unstack b6 b9
0
4
0 23 0 25
0 53 0 1
0 2 -1 0
0 43 15 17
1
end_operator
begin_operator
unstack b7 b23
0
4
0 23 0 26
0 22 -1 0
0 7 0 1
0 25 0 2
1
end_operator
begin_operator
unstack b8 b15
0
3
0 23 0 27
0 33 1 0
0 0 0 1
1
end_operator
0
