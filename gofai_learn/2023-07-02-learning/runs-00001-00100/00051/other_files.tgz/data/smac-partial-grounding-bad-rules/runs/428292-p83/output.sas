begin_version
3
end_version
begin_metric
0
end_metric
51
begin_variable
var0
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var5
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var1
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var2
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var3
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var4
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var6
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var15
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var8
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var7
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var10
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var11
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var13
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var12
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var14
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var9
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var16
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var17
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var18
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var19
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var20
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var21
-1
26
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
<none of those>
end_variable
begin_variable
var22
-1
3
Atom on(b13, b3)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var23
-1
5
Atom on(b10, b15)
Atom on(b10, b18)
Atom on(b10, b6)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var31
-1
4
Atom on(b16, b10)
Atom on(b16, b14)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var36
-1
6
Atom on(b15, b10)
Atom on(b15, b14)
Atom on(b15, b2)
Atom on(b15, b21)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var24
-1
14
Atom on(b3, b10)
Atom on(b3, b13)
Atom on(b3, b15)
Atom on(b3, b17)
Atom on(b3, b18)
Atom on(b3, b2)
Atom on(b3, b23)
Atom on(b3, b24)
Atom on(b3, b25)
Atom on(b3, b4)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var28
-1
14
Atom on(b11, b10)
Atom on(b11, b13)
Atom on(b11, b15)
Atom on(b11, b17)
Atom on(b11, b2)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b4)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var25
-1
15
Atom on(b18, b10)
Atom on(b18, b12)
Atom on(b18, b13)
Atom on(b18, b15)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b23)
Atom on(b18, b24)
Atom on(b18, b25)
Atom on(b18, b4)
Atom on(b18, b6)
Atom on(b18, b7)
Atom on(b18, b9)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var29
-1
15
Atom on(b22, b10)
Atom on(b22, b12)
Atom on(b22, b13)
Atom on(b22, b15)
Atom on(b22, b17)
Atom on(b22, b2)
Atom on(b22, b23)
Atom on(b22, b24)
Atom on(b22, b25)
Atom on(b22, b3)
Atom on(b22, b4)
Atom on(b22, b6)
Atom on(b22, b7)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var34
-1
15
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b13)
Atom on(b17, b14)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b23)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b9)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var30
-1
15
Atom on(b24, b10)
Atom on(b24, b13)
Atom on(b24, b14)
Atom on(b24, b15)
Atom on(b24, b16)
Atom on(b24, b17)
Atom on(b24, b18)
Atom on(b24, b19)
Atom on(b24, b2)
Atom on(b24, b4)
Atom on(b24, b6)
Atom on(b24, b7)
Atom on(b24, b9)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var39
-1
15
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b14)
Atom on(b12, b15)
Atom on(b12, b17)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b25)
Atom on(b12, b4)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var26
-1
17
Atom on(b23, b10)
Atom on(b23, b11)
Atom on(b23, b14)
Atom on(b23, b15)
Atom on(b23, b16)
Atom on(b23, b17)
Atom on(b23, b18)
Atom on(b23, b19)
Atom on(b23, b20)
Atom on(b23, b22)
Atom on(b23, b3)
Atom on(b23, b4)
Atom on(b23, b6)
Atom on(b23, b7)
Atom on(b23, b9)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var32
-1
17
Atom on(b25, b10)
Atom on(b25




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 43 12 19
1
end_operator
begin_operator
unstack b6 b24
0
4
0 21 0 21
0 17 -1 0
0 50 0 1
0 43 13 19
1
end_operator
begin_operator
unstack b6 b25
0
4
0 21 0 21
0 18 -1 0
0 50 0 1
0 43 14 19
1
end_operator
begin_operator
unstack b6 b3
0
4
0 21 0 21
0 11 -1 0
0 50 0 1
0 43 15 19
1
end_operator
begin_operator
unstack b6 b8
0
4
0 21 0 21
0 50 0 1
0 15 -1 0
0 43 16 19
1
end_operator
begin_operator
unstack b6 b9
0
4
0 21 0 21
0 50 0 1
0 19 -1 0
0 43 17 19
1
end_operator
begin_operator
unstack b7 b10
0
4
0 21 0 22
0 5 -1 0
0 20 0 1
0 40 0 17
1
end_operator
begin_operator
unstack b7 b11
0
4
0 21 0 22
0 6 -1 0
0 20 0 1
0 40 1 17
1
end_operator
begin_operator
unstack b7 b12
0
4
0 21 0 22
0 10 -1 0
0 20 0 1
0 40 2 17
1
end_operator
begin_operator
unstack b7 b13
0
4
0 21 0 22
0 0 -1 0
0 20 0 1
0 40 3 17
1
end_operator
begin_operator
unstack b7 b14
0
4
0 21 0 22
0 49 -1 0
0 20 0 1
0 40 4 17
1
end_operator
begin_operator
unstack b7 b15
0
4
0 21 0 22
0 7 -1 0
0 20 0 1
0 40 5 17
1
end_operator
begin_operator
unstack b7 b16
0
4
0 21 0 22
0 1 -1 0
0 20 0 1
0 40 6 17
1
end_operator
begin_operator
unstack b7 b18
0
4
0 21 0 22
0 14 -1 0
0 20 0 1
0 40 7 17
1
end_operator
begin_operator
unstack b7 b2
0
4
0 21 0 22
0 47 -1 0
0 20 0 1
0 40 8 17
1
end_operator
begin_operator
unstack b7 b22
0
4
0 21 0 22
0 9 -1 0
0 20 0 1
0 40 9 17
1
end_operator
begin_operator
unstack b7 b24
0
4
0 21 0 22
0 17 -1 0
0 20 0 1
0 40 10 17
1
end_operator
begin_operator
unstack b7 b3
0
4
0 21 0 22
0 11 -1 0
0 20 0 1
0 40 11 17
1
end_operator
begin_operator
unstack b7 b4
0
4
0 21 0 22
0 48 -1 0
0 20 0 1
0 40 12 17
1
end_operator
begin_operator
unstack b7 b6
0
4
0 21 0 22
0 50 -1 0
0 20 0 1
0 40 14 17
1
end_operator
begin_operator
unstack b7 b9
0
4
0 21 0 22
0 20 0 1
0 19 -1 0
0 40 15 17
1
end_operator
begin_operator
unstack b8 b1
0
4
0 21 0 23
0 4 -1 0
0 15 0 1
0 44 0 23
1
end_operator
begin_operator
unstack b8 b10
0
4
0 21 0 23
0 5 -1 0
0 15 0 1
0 44 1 23
1
end_operator
begin_operator
unstack b8 b11
0
4
0 21 0 23
0 6 -1 0
0 15 0 1
0 44 2 23
1
end_operator
begin_operator
unstack b8 b12
0
4
0 21 0 23
0 10 -1 0
0 15 0 1
0 44 3 23
1
end_operator
begin_operator
unstack b8 b14
0
4
0 21 0 23
0 49 -1 0
0 15 0 1
0 44 4 23
1
end_operator
begin_operator
unstack b8 b15
0
4
0 21 0 23
0 7 -1 0
0 15 0 1
0 44 5 23
1
end_operator
begin_operator
unstack b8 b16
0
4
0 21 0 23
0 1 -1 0
0 15 0 1
0 44 6 23
1
end_operator
begin_operator
unstack b8 b17
0
4
0 21 0 23
0 12 -1 0
0 15 0 1
0 44 7 23
1
end_operator
begin_operator
unstack b8 b18
0
4
0 21 0 23
0 14 -1 0
0 15 0 1
0 44 8 23
1
end_operator
begin_operator
unstack b8 b19
0
4
0 21 0 23
0 16 -1 0
0 15 0 1
0 44 9 23
1
end_operator
begin_operator
unstack b8 b2
0
4
0 21 0 23
0 47 -1 0
0 15 0 1
0 44 10 23
1
end_operator
begin_operator
unstack b8 b20
0
4
0 21 0 23
0 8 -1 0
0 15 0 1
0 44 11 23
1
end_operator
begin_operator
unstack b8 b22
0
4
0 21 0 23
0 9 -1 0
0 15 0 1
0 44 12 23
1
end_operator
begin_operator
unstack b8 b23
0
4
0 21 0 23
0 13 -1 0
0 15 0 1
0 44 13 23
1
end_operator
begin_operator
unstack b8 b24
0
4
0 21 0 23
0 17 -1 0
0 15 0 1
0 44 14 23
1
end_operator
begin_operator
unstack b8 b25
0
4
0 21 0 23
0 18 -1 0
0 15 0 1
0 44 15 23
1
end_operator
begin_operator
unstack b8 b3
0
4
0 21 0 23
0 11 -1 0
0 15 0 1
0 44 16 23
1
end_operator
begin_operator
unstack b8 b4
0
4
0 21 0 23
0 48 -1 0
0 15 0 1
0 44 17 23
1
end_operator
begin_operator
unstack b8 b5
0
4
0 21 0 23
0 3 -1 0
0 15 0 1
0 44 18 23
1
end_operator
begin_operator
unstack b8 b6
0
4
0 21 0 23
0 50 -1 0
0 15 0 1
0 44 19 23
1
end_operator
begin_operator
unstack b8 b7
0
4
0 21 0 23
0 20 -1 0
0 15 0 1
0 44 20 23
1
end_operator
begin_operator
unstack b8 b9
0
4
0 21 0 23
0 15 0 1
0 19 -1 0
0 44 21 23
1
end_operator
begin_operator
unstack b9 b10
0
4
0 21 0 24
0 5 -1 0
0 19 0 1
0 37 0 17
1
end_operator
begin_operator
unstack b9 b11
0
4
0 21 0 24
0 6 -1 0
0 19 0 1
0 37 1 17
1
end_operator
begin_operator
unstack b9 b12
0
4
0 21 0 24
0 10 -1 0
0 19 0 1
0 37 2 17
1
end_operator
begin_operator
unstack b9 b15
0
4
0 21 0 24
0 7 -1 0
0 19 0 1
0 37 3 17
1
end_operator
begin_operator
unstack b9 b16
0
4
0 21 0 24
0 1 -1 0
0 19 0 1
0 37 4 17
1
end_operator
begin_operator
unstack b9 b17
0
4
0 21 0 24
0 12 -1 0
0 19 0 1
0 37 5 17
1
end_operator
begin_operator
unstack b9 b19
0
4
0 21 0 24
0 16 -1 0
0 19 0 1
0 37 6 17
1
end_operator
begin_operator
unstack b9 b2
0
4
0 21 0 24
0 47 -1 0
0 19 0 1
0 37 7 17
1
end_operator
begin_operator
unstack b9 b22
0
4
0 21 0 24
0 9 -1 0
0 19 0 1
0 37 8 17
1
end_operator
begin_operator
unstack b9 b23
0
4
0 21 0 24
0 13 -1 0
0 19 0 1
0 37 9 17
1
end_operator
begin_operator
unstack b9 b24
0
4
0 21 0 24
0 17 -1 0
0 19 0 1
0 37 10 17
1
end_operator
begin_operator
unstack b9 b25
0
4
0 21 0 24
0 18 -1 0
0 19 0 1
0 37 11 17
1
end_operator
begin_operator
unstack b9 b3
0
4
0 21 0 24
0 11 -1 0
0 19 0 1
0 37 12 17
1
end_operator
begin_operator
unstack b9 b4
0
4
0 21 0 24
0 48 -1 0
0 19 0 1
0 37 13 17
1
end_operator
begin_operator
unstack b9 b6
0
4
0 21 0 24
0 50 -1 0
0 19 0 1
0 37 14 17
1
end_operator
begin_operator
unstack b9 b7
0
4
0 21 0 24
0 20 -1 0
0 19 0 1
0 37 15 17
1
end_operator
0
