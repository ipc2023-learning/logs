begin_version
3
end_version
begin_metric
0
end_metric
53
begin_variable
var0
-1
2
Atom on-table(b8)
NegatedAtom on-table(b8)
end_variable
begin_variable
var1
-1
2
Atom on-table(b25)
NegatedAtom on-table(b25)
end_variable
begin_variable
var2
-1
2
Atom on-table(b23)
NegatedAtom on-table(b23)
end_variable
begin_variable
var15
-1
2
Atom on-table(b13)
NegatedAtom on-table(b13)
end_variable
begin_variable
var14
-1
2
Atom on-table(b14)
NegatedAtom on-table(b14)
end_variable
begin_variable
var13
-1
2
Atom on-table(b15)
NegatedAtom on-table(b15)
end_variable
begin_variable
var17
-1
2
Atom on-table(b10)
NegatedAtom on-table(b10)
end_variable
begin_variable
var6
-1
2
Atom on-table(b3)
NegatedAtom on-table(b3)
end_variable
begin_variable
var7
-1
2
Atom on-table(b27)
NegatedAtom on-table(b27)
end_variable
begin_variable
var9
-1
2
Atom on-table(b2)
NegatedAtom on-table(b2)
end_variable
begin_variable
var10
-1
2
Atom on-table(b26)
NegatedAtom on-table(b26)
end_variable
begin_variable
var12
-1
2
Atom on-table(b18)
NegatedAtom on-table(b18)
end_variable
begin_variable
var5
-1
2
Atom on-table(b4)
NegatedAtom on-table(b4)
end_variable
begin_variable
var3
-1
2
Atom on-table(b7)
NegatedAtom on-table(b7)
end_variable
begin_variable
var8
-1
2
Atom on-table(b24)
NegatedAtom on-table(b24)
end_variable
begin_variable
var18
-1
2
Atom on-table(b1)
NegatedAtom on-table(b1)
end_variable
begin_variable
var4
-1
2
Atom on-table(b6)
NegatedAtom on-table(b6)
end_variable
begin_variable
var16
-1
2
Atom on-table(b11)
NegatedAtom on-table(b11)
end_variable
begin_variable
var11
-1
2
Atom on-table(b19)
NegatedAtom on-table(b19)
end_variable
begin_variable
var19
-1
27
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var20
-1
2
Atom on-table(b12)
NegatedAtom on-table(b12)
end_variable
begin_variable
var21
-1
2
Atom on-table(b17)
NegatedAtom on-table(b17)
end_variable
begin_variable
var23
-1
2
Atom on-table(b22)
NegatedAtom on-table(b22)
end_variable
begin_variable
var24
-1
2
Atom on-table(b5)
NegatedAtom on-table(b5)
end_variable
begin_variable
var25
-1
2
Atom on-table(b9)
NegatedAtom on-table(b9)
end_variable
begin_variable
var49
-1
2
Atom clear(b20)
Atom on(b16, b20)
end_variable
begin_variable
var26
-1
4
Atom clear(b21)
Atom on(b24, b21)
Atom on(b6, b21)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom clear(b16)
Atom on(b26, b16)
Atom on(b9, b16)
<none of those>
end_variable
begin_variable
var28
-1
9
Atom clear(b8)
Atom on(b12, b8)
Atom on(b14, b8)
Atom on(b15, b8)
Atom on(b17, b8)
Atom on(b22, b8)
Atom on(b5, b8)
Atom on(b9, b8)
<none of those>
end_variable
begin_variable
var29
-1
13
Atom clear(b25)
Atom on(b1, b25)
Atom on(b11, b25)
Atom on(b12, b25)
Atom on(b14, b25)
Atom on(b15, b25)
Atom on(b23, b25)
Atom on(b24, b25)
Atom on(b26, b25)
Atom on(b5, b25)
Atom on(b6, b25)
Atom on(b9, b25)
<none of those>
end_variable
begin_variable
var48
-1
19
Atom clear(b19)
Atom on(b1, b19)
Atom on(b10, b19)
Atom on(b11, b19)
Atom on(b12, b19)
Atom on(b17, b19)
Atom on(b22, b19)
Atom on(b23, b19)
Atom on(b24, b19)
Atom on(b26, b19)
Atom on(b27, b19)
Atom on(b3, b19)
Atom on(b4, b19)
Atom on(b5, b19)
Atom on(b6, b19)
Atom on(b7, b19)
Atom on(b8, b19)
Atom on(b9, b19)
<none of those>
end_variable
begin_variable
var50
-1
16
Atom clear(b22)
Atom on(b1, b22)
Atom on(b11, b22)
Atom on(b12, b22)
Atom on(b17, b22)
Atom on(b23, b22)
Atom on(b24, b22)
Atom on(b26, b22)
Atom on(b27, b22)
Atom on(b3, b22)
Atom on(b4, b22)
Atom on(b5, b22)
Atom on(b6, b22)
Atom on(b7, b22)
Atom on(b9, b22)
<none of those>
end_variable
begin_variable
var31
-1
6
Atom clear(b17)
Atom on(b11, b17)
Atom on(b2, b17)
Atom on(b23, b17)
Atom on(b6, b17)
<none of those>
end_variable
begin_variable
var32
-1
8
Atom clear(b14)
Atom on(b15, b14)
Atom on(b18, b14)
Atom on(b23, b14)
Atom on(b24, b14)
Atom on(b6, b14)
Atom on(b7, b14)
<none of those>
end_variable
begin_variable
var36
-1
11
Atom clear(b10)
Atom on(b15, b10)
Atom on(b17, b10)
Atom on(b19, b10)
Atom on(b23, b10)
Atom on(b3, b10)
Atom on(b4, b10)
Atom on(b5, b10)
Atom on(b6, b10)
Atom on(b7, b10)
<none of those>
end_variable
begin_variable
var33
-1
7
Atom clear(b5)
Atom on(b11, b5)
Atom on(b23, b5)
Atom on(b3, b5)
Atom on(b4, b5)
Atom on(b7, b5)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom clear(b12)
Atom on(b1, b12)
Atom on(b23, b12)
Atom on(b24, b12)
Atom on(b4, b12)
<none of those>
end_variable
begin_variable
var40
-1
14
Atom clear(b18)
Atom on(b1, b18)
Atom on(b10, b18)
Atom on(b12, b18)
Atom on(b14, b18)
Atom on(b15, b18)
Atom on(b17, b18)
Atom on(b2, b18)
Atom on(b23, b18)
Atom on(b24, b18)
Atom on(b3, b18)
Atom on(b4, b18)
Atom on(b6, b18)
<none of those>
end_variable
begin_varia




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
0 50 15 0
0 43 0 14
1
end_operator
begin_operator
unstack b4 b27
0
3
0 19 0 21
0 42 16 0
0 43 0 14
1
end_operator
begin_operator
unstack b4 b3
0
3
0 19 0 21
0 41 11 0
0 43 0 14
1
end_operator
begin_operator
unstack b4 b5
0
3
0 19 0 21
0 43 0 14
0 35 4 0
1
end_operator
begin_operator
unstack b4 b7
0
3
0 19 0 21
0 43 0 14
0 44 14 0
1
end_operator
begin_operator
unstack b4 b9
0
3
0 19 0 21
0 43 0 14
0 51 17 0
1
end_operator
begin_operator
unstack b5 b1
0
3
0 19 0 22
0 46 14 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b10
0
3
0 19 0 22
0 34 7 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b11
0
3
0 19 0 22
0 48 16 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b13
0
3
0 19 0 22
0 40 17 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b19
0
3
0 19 0 22
0 30 13 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b2
0
3
0 19 0 22
0 38 13 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b22
0
3
0 19 0 22
0 31 11 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b24
0
3
0 19 0 22
0 45 11 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b25
0
3
0 19 0 22
0 29 9 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b26
0
3
0 19 0 22
0 50 16 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b27
0
3
0 19 0 22
0 42 17 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b4
0
3
0 19 0 22
0 43 11 0
0 35 0 6
1
end_operator
begin_operator
unstack b5 b6
0
3
0 19 0 22
0 35 0 6
0 47 10 0
1
end_operator
begin_operator
unstack b5 b7
0
3
0 19 0 22
0 35 0 6
0 44 15 0
1
end_operator
begin_operator
unstack b5 b8
0
3
0 19 0 22
0 35 0 6
0 28 6 0
1
end_operator
begin_operator
unstack b5 b9
0
3
0 19 0 22
0 35 0 6
0 51 18 0
1
end_operator
begin_operator
unstack b6 b1
0
3
0 19 0 23
0 46 15 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b10
0
3
0 19 0 23
0 34 8 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b11
0
3
0 19 0 23
0 48 17 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b13
0
3
0 19 0 23
0 40 18 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b14
0
3
0 19 0 23
0 33 5 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b15
0
3
0 19 0 23
0 39 9 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b17
0
3
0 19 0 23
0 32 4 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b18
0
3
0 19 0 23
0 37 12 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b19
0
3
0 19 0 23
0 30 14 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b2
0
3
0 19 0 23
0 38 14 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b21
0
3
0 19 0 23
0 26 2 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b22
0
3
0 19 0 23
0 31 12 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b24
0
3
0 19 0 23
0 45 12 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b25
0
3
0 19 0 23
0 29 10 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b26
0
3
0 19 0 23
0 50 17 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b27
0
3
0 19 0 23
0 42 18 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b3
0
3
0 19 0 23
0 41 12 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b4
0
3
0 19 0 23
0 43 12 0
0 47 0 12
1
end_operator
begin_operator
unstack b6 b7
0
3
0 19 0 23
0 47 0 12
0 44 16 0
1
end_operator
begin_operator
unstack b6 b9
0
3
0 19 0 23
0 47 0 12
0 51 19 0
1
end_operator
begin_operator
unstack b7 b1
0
3
0 19 0 24
0 46 16 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b10
0
3
0 19 0 24
0 34 9 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b11
0
3
0 19 0 24
0 48 18 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b13
0
3
0 19 0 24
0 40 19 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b14
0
3
0 19 0 24
0 33 6 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b19
0
3
0 19 0 24
0 30 15 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b22
0
3
0 19 0 24
0 31 13 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b24
0
3
0 19 0 24
0 45 13 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b26
0
3
0 19 0 24
0 50 18 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b27
0
3
0 19 0 24
0 42 19 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b4
0
3
0 19 0 24
0 43 13 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b5
0
3
0 19 0 24
0 35 5 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b6
0
3
0 19 0 24
0 47 11 0
0 44 0 17
1
end_operator
begin_operator
unstack b7 b9
0
3
0 19 0 24
0 44 0 17
0 51 20 0
1
end_operator
begin_operator
unstack b8 b19
0
3
0 19 0 25
0 30 16 0
0 28 0 8
1
end_operator
begin_operator
unstack b9 b11
0
3
0 19 0 26
0 48 19 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b13
0
3
0 19 0 26
0 40 20 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b16
0
3
0 19 0 26
0 27 2 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b19
0
3
0 19 0 26
0 30 17 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b22
0
3
0 19 0 26
0 31 14 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b25
0
3
0 19 0 26
0 29 11 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b26
0
3
0 19 0 26
0 50 19 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b27
0
3
0 19 0 26
0 42 20 0
0 51 0 21
1
end_operator
begin_operator
unstack b9 b8
0
3
0 19 0 26
0 28 7 0
0 51 0 21
1
end_operator
0
