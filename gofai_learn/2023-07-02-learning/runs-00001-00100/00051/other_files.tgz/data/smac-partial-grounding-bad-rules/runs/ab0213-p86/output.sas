begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var0
-1
2
Atom on-table(b12)
NegatedAtom on-table(b12)
end_variable
begin_variable
var1
-1
2
Atom on-table(b1)
NegatedAtom on-table(b1)
end_variable
begin_variable
var2
-1
3
Atom clear(b24)
Atom on(b15, b24)
<none of those>
end_variable
begin_variable
var3
-1
3
Atom clear(b1)
Atom on(b21, b1)
<none of those>
end_variable
begin_variable
var4
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var5
-1
16
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b13)
Atom on(b2, b15)
Atom on(b2, b17)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b22)
Atom on(b2, b23)
Atom on(b2, b25)
Atom on(b2, b4)
Atom on(b2, b5)
Atom on(b2, b7)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var6
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var7
-1
18
Atom on(b22, b1)
Atom on(b22, b10)
Atom on(b22, b13)
Atom on(b22, b14)
Atom on(b22, b15)
Atom on(b22, b16)
Atom on(b22, b17)
Atom on(b22, b19)
Atom on(b22, b2)
Atom on(b22, b20)
Atom on(b22, b21)
Atom on(b22, b23)
Atom on(b22, b3)
Atom on(b22, b5)
Atom on(b22, b6)
Atom on(b22, b7)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var8
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var9
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var10
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var11
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var12
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var13
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var14
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var15
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var20
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var16
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var17
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var21
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var19
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var18
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var22
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var23
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var24
-1
25
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b25)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var26
-1
3
Atom on(b15, b2)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b25, b11)
Atom on-table(b25)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b18, b4)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b21, b5)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var30
-1
3
Atom on(b9, b3)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var32
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var31
-1
9
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b21)
Atom on(b7, b22)
Atom on(b7, b23)
Atom on(b7, b4)
Atom on(b7, b6)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var33
-1
12
Atom on(b4, b14)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b19)
Atom on(b4, b21)
Atom on(b4, b22)
Atom on(b4, b23)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var44
-1
14
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b14)
Atom on(b6, b15)
Atom on(b6, b16)
Atom on(b6, b2)
Atom on(b6, b22)
Atom on(b6, b23)
Atom on(b6, b25)
Atom on(b6, b3)
Atom on(b6, b4)
Atom on(b6, b7)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var36
-1
14
Atom on(b19, b1)
Atom on(b19, b11)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b20)
Atom on(b19, b21)
Atom on(b19, b23)
Atom on(b19, b25)
Atom on(b19, b4)
Atom on(b19, b6)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var37
-1
15
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b13)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b19)
Atom on(b3, b2)
Atom on(b3, b20)
Atom on(b3, b23)
Atom on(b3, b25)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b7)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var34
-1
14
Atom clear(b18)
Atom on(b10, b18)
Atom on(b11, b18)
Atom on(b13, b18)
Atom on(b14, b18)
Atom on(b16, b18)
Atom on(b17, b18)
Atom on(b2, b18)
Atom on(b20, b18)
Atom on(b22, b18)
Atom on(b3, b18)
Atom on(b4, b18)
Atom on(b5, b18)
<none of those>
end_variable
begin_variable
var35
-1
14
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b14)
Atom on(b13, b1




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 48 -1 0
0 14 0 1
0 32 4 11
1
end_operator
begin_operator
unstack b4 b22
0
4
0 24 0 19
0 11 -1 0
0 14 0 1
0 32 5 11
1
end_operator
begin_operator
unstack b4 b23
0
4
0 24 0 19
0 22 -1 0
0 14 0 1
0 32 6 11
1
end_operator
begin_operator
unstack b4 b5
0
4
0 24 0 19
0 14 0 1
0 12 -1 0
0 32 7 11
1
end_operator
begin_operator
unstack b4 b6
0
4
0 24 0 19
0 14 0 1
0 19 -1 0
0 32 8 11
1
end_operator
begin_operator
unstack b4 b7
0
4
0 24 0 19
0 14 0 1
0 9 -1 0
0 32 9 11
1
end_operator
begin_operator
unstack b4 b9
0
3
0 24 0 19
0 14 0 1
0 42 10 0
1
end_operator
begin_operator
unstack b5 b11
0
4
0 24 0 20
0 15 -1 0
0 12 0 1
0 40 0 14
1
end_operator
begin_operator
unstack b5 b13
0
4
0 24 0 20
0 49 -1 0
0 12 0 1
0 40 1 14
1
end_operator
begin_operator
unstack b5 b15
0
4
0 24 0 20
0 4 -1 0
0 12 0 1
0 40 2 14
1
end_operator
begin_operator
unstack b5 b16
0
4
0 24 0 20
0 23 -1 0
0 12 0 1
0 40 3 14
1
end_operator
begin_operator
unstack b5 b18
0
3
0 24 0 20
0 36 12 0
0 12 0 1
1
end_operator
begin_operator
unstack b5 b19
0
4
0 24 0 20
0 20 -1 0
0 12 0 1
0 40 4 14
1
end_operator
begin_operator
unstack b5 b2
0
4
0 24 0 20
0 10 -1 0
0 12 0 1
0 40 5 14
1
end_operator
begin_operator
unstack b5 b20
0
4
0 24 0 20
0 17 -1 0
0 12 0 1
0 40 6 14
1
end_operator
begin_operator
unstack b5 b21
0
4
0 24 0 20
0 48 -1 0
0 12 0 1
0 40 7 14
1
end_operator
begin_operator
unstack b5 b23
0
4
0 24 0 20
0 22 -1 0
0 12 0 1
0 40 8 14
1
end_operator
begin_operator
unstack b5 b25
0
4
0 24 0 20
0 6 -1 0
0 12 0 1
0 40 9 14
1
end_operator
begin_operator
unstack b5 b4
0
4
0 24 0 20
0 14 -1 0
0 12 0 1
0 40 10 14
1
end_operator
begin_operator
unstack b5 b6
0
4
0 24 0 20
0 12 0 1
0 19 -1 0
0 40 11 14
1
end_operator
begin_operator
unstack b5 b7
0
4
0 24 0 20
0 12 0 1
0 9 -1 0
0 40 12 14
1
end_operator
begin_operator
unstack b5 b9
0
3
0 24 0 20
0 12 0 1
0 42 11 0
1
end_operator
begin_operator
unstack b6 b1
0
4
0 24 0 21
0 3 -1 0
0 19 0 1
0 33 0 13
1
end_operator
begin_operator
unstack b6 b10
0
4
0 24 0 21
0 16 -1 0
0 19 0 1
0 33 1 13
1
end_operator
begin_operator
unstack b6 b14
0
4
0 24 0 21
0 18 -1 0
0 19 0 1
0 33 2 13
1
end_operator
begin_operator
unstack b6 b15
0
4
0 24 0 21
0 4 -1 0
0 19 0 1
0 33 3 13
1
end_operator
begin_operator
unstack b6 b16
0
4
0 24 0 21
0 23 -1 0
0 19 0 1
0 33 4 13
1
end_operator
begin_operator
unstack b6 b2
0
4
0 24 0 21
0 10 -1 0
0 19 0 1
0 33 5 13
1
end_operator
begin_operator
unstack b6 b22
0
4
0 24 0 21
0 11 -1 0
0 19 0 1
0 33 6 13
1
end_operator
begin_operator
unstack b6 b23
0
4
0 24 0 21
0 22 -1 0
0 19 0 1
0 33 7 13
1
end_operator
begin_operator
unstack b6 b25
0
4
0 24 0 21
0 6 -1 0
0 19 0 1
0 33 8 13
1
end_operator
begin_operator
unstack b6 b3
0
4
0 24 0 21
0 13 -1 0
0 19 0 1
0 33 9 13
1
end_operator
begin_operator
unstack b6 b4
0
4
0 24 0 21
0 14 -1 0
0 19 0 1
0 33 10 13
1
end_operator
begin_operator
unstack b6 b7
0
4
0 24 0 21
0 19 0 1
0 9 -1 0
0 33 11 13
1
end_operator
begin_operator
unstack b6 b9
0
3
0 24 0 21
0 19 0 1
0 42 12 0
1
end_operator
begin_operator
unstack b7 b15
0
4
0 24 0 22
0 4 -1 0
0 9 0 1
0 31 0 8
1
end_operator
begin_operator
unstack b7 b16
0
4
0 24 0 22
0 23 -1 0
0 9 0 1
0 31 1 8
1
end_operator
begin_operator
unstack b7 b21
0
4
0 24 0 22
0 48 -1 0
0 9 0 1
0 31 2 8
1
end_operator
begin_operator
unstack b7 b22
0
4
0 24 0 22
0 11 -1 0
0 9 0 1
0 31 3 8
1
end_operator
begin_operator
unstack b7 b23
0
4
0 24 0 22
0 22 -1 0
0 9 0 1
0 31 4 8
1
end_operator
begin_operator
unstack b7 b4
0
4
0 24 0 22
0 14 -1 0
0 9 0 1
0 31 5 8
1
end_operator
begin_operator
unstack b7 b6
0
4
0 24 0 22
0 19 -1 0
0 9 0 1
0 31 6 8
1
end_operator
begin_operator
unstack b7 b9
0
3
0 24 0 22
0 9 0 1
0 42 13 0
1
end_operator
begin_operator
unstack b8 b10
0
4
0 24 0 23
0 16 -1 0
0 8 0 1
0 45 0 16
1
end_operator
begin_operator
unstack b8 b11
0
4
0 24 0 23
0 15 -1 0
0 8 0 1
0 45 1 16
1
end_operator
begin_operator
unstack b8 b12
0
4
0 24 0 23
0 30 -1 0
0 8 0 1
0 45 2 16
1
end_operator
begin_operator
unstack b8 b15
0
4
0 24 0 23
0 4 -1 0
0 8 0 1
0 45 3 16
1
end_operator
begin_operator
unstack b8 b16
0
4
0 24 0 23
0 23 -1 0
0 8 0 1
0 45 4 16
1
end_operator
begin_operator
unstack b8 b17
0
4
0 24 0 23
0 21 -1 0
0 8 0 1
0 45 5 16
1
end_operator
begin_operator
unstack b8 b19
0
4
0 24 0 23
0 20 -1 0
0 8 0 1
0 45 6 16
1
end_operator
begin_operator
unstack b8 b2
0
4
0 24 0 23
0 10 -1 0
0 8 0 1
0 45 7 16
1
end_operator
begin_operator
unstack b8 b20
0
4
0 24 0 23
0 17 -1 0
0 8 0 1
0 45 8 16
1
end_operator
begin_operator
unstack b8 b21
0
4
0 24 0 23
0 48 -1 0
0 8 0 1
0 45 9 16
1
end_operator
begin_operator
unstack b8 b23
0
4
0 24 0 23
0 22 -1 0
0 8 0 1
0 45 10 16
1
end_operator
begin_operator
unstack b8 b25
0
4
0 24 0 23
0 6 -1 0
0 8 0 1
0 45 11 16
1
end_operator
begin_operator
unstack b8 b3
0
4
0 24 0 23
0 13 -1 0
0 8 0 1
0 45 12 16
1
end_operator
begin_operator
unstack b8 b5
0
4
0 24 0 23
0 12 -1 0
0 8 0 1
0 45 13 16
1
end_operator
begin_operator
unstack b8 b6
0
4
0 24 0 23
0 19 -1 0
0 8 0 1
0 45 14 16
1
end_operator
begin_operator
unstack b8 b7
0
4
0 24 0 23
0 9 -1 0
0 8 0 1
0 45 15 16
1
end_operator
begin_operator
unstack b8 b9
0
3
0 24 0 23
0 8 0 1
0 42 14 0
1
end_operator
0
