begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var0
-1
2
Atom on-table(b3)
NegatedAtom on-table(b3)
end_variable
begin_variable
var2
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var1
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var3
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var4
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var5
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var7
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var6
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var8
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var9
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var11
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var12
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var10
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var13
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var14
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var15
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var16
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var17
-1
21
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var18
-1
3
Atom on(b14, b7)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var19
-1
3
Atom on(b2, b13)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var20
-1
3
Atom on(b18, b2)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom on(b6, b16)
Atom on(b6, b18)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var29
-1
4
Atom on(b16, b14)
Atom on(b16, b20)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var23
-1
5
Atom on(b17, b13)
Atom on(b17, b15)
Atom on(b17, b6)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var22
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var24
-1
5
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b8)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var27
-1
14
Atom on(b10, b1)
Atom on(b10, b12)
Atom on(b10, b13)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b20)
Atom on(b10, b5)
Atom on(b10, b6)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var31
-1
14
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b13)
Atom on(b4, b17)
Atom on(b4, b19)
Atom on(b4, b20)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var33
-1
14
Atom on(b9, b1)
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b13)
Atom on(b9, b16)
Atom on(b9, b17)
Atom on(b9, b19)
Atom on(b9, b20)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var28
-1
15
Atom on(b11, b1)
Atom on(b11, b10)
Atom on(b11, b13)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b20)
Atom on(b11, b4)
Atom on(b11, b5)
Atom on(b11, b6)
Atom on(b11, b8)
Atom on(b11, b9)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var30
-1
15
Atom on(b20, b1)
Atom on(b20, b10)
Atom on(b20, b11)
Atom on(b20, b16)
Atom on(b20, b17)
Atom on(b20, b19)
Atom on(b20, b2)
Atom on(b20, b4)
Atom on(b20, b5)
Atom on(b20, b6)
Atom on(b20, b7)
Atom on(b20, b8)
Atom on(b20, b9)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var35
-1
17
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var25
-1
16
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b13)
Atom on(b5, b15)
Atom on(b5, b16)
Atom on(b5, b17)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b4)
Atom on(b5, b7)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var26
-1
17
Atom on(b7, b1)
Atom on(b7, b10)
Atom on(b7, b11)
Atom on(b7, b13)
Atom on(b7, b14)
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b18)
Atom on(b7, b19)
Atom on(b7, b2)
Atom on(b7, b20)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var32
-1
17
Atom on(b8, b10)
Atom on(b8, b11)
Atom on(b8, b13)
Atom on(b8, b14)
Atom on(b8, b15)
Atom on(b8, b16)




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0
4
0 17 0 15
0 11 0 1
0 15 -1 0
0 27 10 13
1
end_operator
begin_operator
unstack b4 b9
0
4
0 17 0 15
0 11 0 1
0 10 -1 0
0 27 11 13
1
end_operator
begin_operator
unstack b5 b1
0
4
0 17 0 16
0 14 -1 0
0 39 0 3
0 32 0 15
1
end_operator
begin_operator
unstack b5 b10
0
4
0 17 0 16
0 9 -1 0
0 39 0 3
0 32 1 15
1
end_operator
begin_operator
unstack b5 b11
0
4
0 17 0 16
0 13 -1 0
0 39 0 3
0 32 2 15
1
end_operator
begin_operator
unstack b5 b13
0
4
0 17 0 16
0 16 -1 0
0 39 0 3
0 32 3 15
1
end_operator
begin_operator
unstack b5 b15
0
4
0 17 0 16
0 3 -1 0
0 39 0 3
0 32 4 15
1
end_operator
begin_operator
unstack b5 b16
0
4
0 17 0 16
0 6 -1 0
0 39 0 3
0 32 5 15
1
end_operator
begin_operator
unstack b5 b17
0
4
0 17 0 16
0 37 -1 0
0 39 0 3
0 32 6 15
1
end_operator
begin_operator
unstack b5 b18
0
4
0 17 0 16
0 4 -1 0
0 39 0 3
0 32 7 15
1
end_operator
begin_operator
unstack b5 b19
0
4
0 17 0 16
0 38 -1 0
0 39 0 3
0 32 8 15
1
end_operator
begin_operator
unstack b5 b2
0
4
0 17 0 16
0 1 -1 0
0 39 0 3
0 32 9 15
1
end_operator
begin_operator
unstack b5 b20
0
4
0 17 0 16
0 12 -1 0
0 39 0 3
0 32 10 15
1
end_operator
begin_operator
unstack b5 b4
0
4
0 17 0 16
0 11 -1 0
0 39 0 3
0 32 11 15
1
end_operator
begin_operator
unstack b5 b7
0
4
0 17 0 16
0 39 0 3
0 8 -1 0
0 32 12 15
1
end_operator
begin_operator
unstack b5 b9
0
4
0 17 0 16
0 39 0 3
0 10 -1 0
0 32 13 15
1
end_operator
begin_operator
unstack b6 b18
0
4
0 17 0 17
0 4 -1 0
0 5 0 1
0 21 1 3
1
end_operator
begin_operator
unstack b7 b1
0
4
0 17 0 18
0 14 -1 0
0 8 0 1
0 33 0 16
1
end_operator
begin_operator
unstack b7 b10
0
4
0 17 0 18
0 9 -1 0
0 8 0 1
0 33 1 16
1
end_operator
begin_operator
unstack b7 b11
0
4
0 17 0 18
0 13 -1 0
0 8 0 1
0 33 2 16
1
end_operator
begin_operator
unstack b7 b13
0
4
0 17 0 18
0 16 -1 0
0 8 0 1
0 33 3 16
1
end_operator
begin_operator
unstack b7 b14
0
4
0 17 0 18
0 2 -1 0
0 8 0 1
0 33 4 16
1
end_operator
begin_operator
unstack b7 b15
0
4
0 17 0 18
0 3 -1 0
0 8 0 1
0 33 5 16
1
end_operator
begin_operator
unstack b7 b16
0
4
0 17 0 18
0 6 -1 0
0 8 0 1
0 33 6 16
1
end_operator
begin_operator
unstack b7 b18
0
4
0 17 0 18
0 4 -1 0
0 8 0 1
0 33 7 16
1
end_operator
begin_operator
unstack b7 b19
0
4
0 17 0 18
0 38 -1 0
0 8 0 1
0 33 8 16
1
end_operator
begin_operator
unstack b7 b2
0
4
0 17 0 18
0 1 -1 0
0 8 0 1
0 33 9 16
1
end_operator
begin_operator
unstack b7 b20
0
4
0 17 0 18
0 12 -1 0
0 8 0 1
0 33 10 16
1
end_operator
begin_operator
unstack b7 b4
0
4
0 17 0 18
0 11 -1 0
0 8 0 1
0 33 11 16
1
end_operator
begin_operator
unstack b7 b5
0
4
0 17 0 18
0 39 -1 0
0 8 0 1
0 33 12 16
1
end_operator
begin_operator
unstack b7 b6
0
4
0 17 0 18
0 5 -1 0
0 8 0 1
0 33 13 16
1
end_operator
begin_operator
unstack b7 b8
0
4
0 17 0 18
0 8 0 1
0 15 -1 0
0 33 14 16
1
end_operator
begin_operator
unstack b8 b10
0
4
0 17 0 19
0 9 -1 0
0 15 0 1
0 34 0 16
1
end_operator
begin_operator
unstack b8 b11
0
4
0 17 0 19
0 13 -1 0
0 15 0 1
0 34 1 16
1
end_operator
begin_operator
unstack b8 b13
0
4
0 17 0 19
0 16 -1 0
0 15 0 1
0 34 2 16
1
end_operator
begin_operator
unstack b8 b14
0
4
0 17 0 19
0 2 -1 0
0 15 0 1
0 34 3 16
1
end_operator
begin_operator
unstack b8 b15
0
4
0 17 0 19
0 3 -1 0
0 15 0 1
0 34 4 16
1
end_operator
begin_operator
unstack b8 b16
0
4
0 17 0 19
0 6 -1 0
0 15 0 1
0 34 5 16
1
end_operator
begin_operator
unstack b8 b17
0
4
0 17 0 19
0 37 -1 0
0 15 0 1
0 34 6 16
1
end_operator
begin_operator
unstack b8 b18
0
4
0 17 0 19
0 4 -1 0
0 15 0 1
0 34 7 16
1
end_operator
begin_operator
unstack b8 b19
0
4
0 17 0 19
0 38 -1 0
0 15 0 1
0 34 8 16
1
end_operator
begin_operator
unstack b8 b20
0
4
0 17 0 19
0 12 -1 0
0 15 0 1
0 34 9 16
1
end_operator
begin_operator
unstack b8 b4
0
4
0 17 0 19
0 11 -1 0
0 15 0 1
0 34 10 16
1
end_operator
begin_operator
unstack b8 b5
0
4
0 17 0 19
0 39 -1 0
0 15 0 1
0 34 11 16
1
end_operator
begin_operator
unstack b8 b6
0
4
0 17 0 19
0 5 -1 0
0 15 0 1
0 34 12 16
1
end_operator
begin_operator
unstack b8 b7
0
4
0 17 0 19
0 8 -1 0
0 15 0 1
0 34 13 16
1
end_operator
begin_operator
unstack b8 b9
0
4
0 17 0 19
0 15 0 1
0 10 -1 0
0 34 14 16
1
end_operator
begin_operator
unstack b9 b1
0
4
0 17 0 20
0 14 -1 0
0 10 0 1
0 28 0 13
1
end_operator
begin_operator
unstack b9 b10
0
4
0 17 0 20
0 9 -1 0
0 10 0 1
0 28 1 13
1
end_operator
begin_operator
unstack b9 b11
0
4
0 17 0 20
0 13 -1 0
0 10 0 1
0 28 2 13
1
end_operator
begin_operator
unstack b9 b13
0
4
0 17 0 20
0 16 -1 0
0 10 0 1
0 28 3 13
1
end_operator
begin_operator
unstack b9 b16
0
4
0 17 0 20
0 6 -1 0
0 10 0 1
0 28 4 13
1
end_operator
begin_operator
unstack b9 b17
0
4
0 17 0 20
0 37 -1 0
0 10 0 1
0 28 5 13
1
end_operator
begin_operator
unstack b9 b19
0
4
0 17 0 20
0 38 -1 0
0 10 0 1
0 28 6 13
1
end_operator
begin_operator
unstack b9 b20
0
4
0 17 0 20
0 12 -1 0
0 10 0 1
0 28 7 13
1
end_operator
begin_operator
unstack b9 b4
0
4
0 17 0 20
0 11 -1 0
0 10 0 1
0 28 8 13
1
end_operator
begin_operator
unstack b9 b5
0
4
0 17 0 20
0 39 -1 0
0 10 0 1
0 28 9 13
1
end_operator
begin_operator
unstack b9 b7
0
4
0 17 0 20
0 8 -1 0
0 10 0 1
0 28 10 13
1
end_operator
begin_operator
unstack b9 b8
0
4
0 17 0 20
0 15 -1 0
0 10 0 1
0 28 11 13
1
end_operator
0
