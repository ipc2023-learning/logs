begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var0
-1
11
Atom at(v5, l1)
Atom at(v5, l10)
Atom at(v5, l11)
Atom at(v5, l2)
Atom at(v5, l3)
Atom at(v5, l4)
Atom at(v5, l5)
Atom at(v5, l6)
Atom at(v5, l7)
Atom at(v5, l8)
Atom at(v5, l9)
end_variable
begin_variable
var1
-1
2
Atom at(v1, l4)
Atom at(v1, l5)
end_variable
begin_variable
var3
-1
2
Atom capacity(v3, c0)
Atom capacity(v3, c1)
end_variable
begin_variable
var4
-1
2
Atom capacity(v4, c0)
Atom capacity(v4, c1)
end_variable
begin_variable
var5
-1
2
Atom capacity(v1, c0)
Atom capacity(v1, c1)
end_variable
begin_variable
var2
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var6
-1
2
Atom capacity(v5, c0)
Atom capacity(v5, c1)
end_variable
begin_variable
var7
-1
16
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var8
-1
16
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var9
-1
16
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var10
-1
16
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var11
-1
16
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var12
-1
16
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var13
-1
16
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var14
-1
16
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var15
-1
16
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
180
begin_mutex_group
2
2 1
7 13
end_mutex_group
begin_mutex_group
2
2 1
8 13
end_mutex_group
begin_mutex_group
2
2 1
9 13
end_mutex_group
begin_mutex_group
2
2 1
10 13
end_mutex_group
begin_mutex_group
2
2 1
11 13
end_mutex_group
begin_mutex_group
2
2 1
12 13
end_mutex_group
begin_mutex_group
2
2 1
13 13
end_mutex_group
begin_mutex_group
2
2 1
14 13
end_mutex_group
begin_mutex_group
2
2 1
15 13
end_mutex_group
begin_mutex_group
2
3 1
7 14
end_mutex_group
begin_mutex_group
2
3 1
8 14
end_mutex_group
begin_mutex_group
2
3 1
9 14
end_mutex_group
begin_mutex_group
2
3 1
10 14
end_mutex_group
begin_mutex_group
2
3 1
11 14
end_mutex_group
begin_mutex_group
2
3 1
12 14
end_mutex_group
begin_mutex_group
2
3 1
13 14
end_mutex_group
begin_mutex_group
2
3 1
14 14
end_mutex_group
begin_mutex_group
2
3 1
15 14
end_mutex_group
begin_mutex_group
2
4 1
7 11
end_mutex_group
begin_mutex_group
2
4 1
8 11
end_mutex_group
begin_mutex_group
2
4 1
9 11
end_mutex_group
begin_mutex_group
2
4 1
10 11
end_mutex_group
begin_mutex_group
2
4 1
11 11
end_mutex_group
begin_mutex_group
2
4 1
12 11
end_mutex_group
begin_mutex_group
2
4 1
13 11
end_mutex_group
begin_mutex_group
2
4 1
14 11
end_mutex_group
begin_mutex_group
2
4 1
15 11
end_mutex_group
begin_mutex_group
2
6 1
7 15
end_mutex_group
begin_mutex_group
2
6 1
8 15
end_mutex_group
begin_mutex_group
2
6 1
9 15
end_mutex_group
begin_mutex_group
2
6 1
10 15
end_mutex_group
begin_mutex_group
2
6 1
11 15
end_mutex_group
begin_mutex_group
2
6 1
12 15
end_mutex_group
begin_mutex_group
2
6 1
13 15
end_mutex_group
begin_mutex_group
2
6 1
14 15
end_mutex_group
begin_mutex_group
2
6 1
15 15
end_mutex_group
begin_mutex_group




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





pick-up v5 l2 p8 c0 c1
1
0 3
2
0 14 3 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l2 p9 c0 c1
1
0 3
2
0 15 3 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p1 c0 c1
1
0 4
2
0 7 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p2 c0 c1
1
0 4
2
0 8 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p3 c0 c1
1
0 4
2
0 9 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p4 c0 c1
1
0 4
2
0 10 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p5 c0 c1
1
0 4
2
0 11 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p6 c0 c1
1
0 4
2
0 12 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p7 c0 c1
1
0 4
2
0 13 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p8 c0 c1
1
0 4
2
0 14 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l3 p9 c0 c1
1
0 4
2
0 15 4 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p1 c0 c1
1
0 5
2
0 7 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p2 c0 c1
1
0 5
2
0 8 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p3 c0 c1
1
0 5
2
0 9 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p4 c0 c1
1
0 5
2
0 10 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p5 c0 c1
1
0 5
2
0 11 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p6 c0 c1
1
0 5
2
0 12 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p7 c0 c1
1
0 5
2
0 13 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p8 c0 c1
1
0 5
2
0 14 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l4 p9 c0 c1
1
0 5
2
0 15 5 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p1 c0 c1
1
0 6
2
0 7 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p2 c0 c1
1
0 6
2
0 8 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p3 c0 c1
1
0 6
2
0 9 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p4 c0 c1
1
0 6
2
0 10 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p5 c0 c1
1
0 6
2
0 11 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p6 c0 c1
1
0 6
2
0 12 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p7 c0 c1
1
0 6
2
0 13 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p8 c0 c1
1
0 6
2
0 14 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l5 p9 c0 c1
1
0 6
2
0 15 6 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p1 c0 c1
1
0 7
2
0 7 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p2 c0 c1
1
0 7
2
0 8 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p3 c0 c1
1
0 7
2
0 9 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p4 c0 c1
1
0 7
2
0 10 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p5 c0 c1
1
0 7
2
0 11 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p6 c0 c1
1
0 7
2
0 12 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p7 c0 c1
1
0 7
2
0 13 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p8 c0 c1
1
0 7
2
0 14 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l6 p9 c0 c1
1
0 7
2
0 15 7 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p1 c0 c1
1
0 8
2
0 7 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p2 c0 c1
1
0 8
2
0 8 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p3 c0 c1
1
0 8
2
0 9 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p4 c0 c1
1
0 8
2
0 10 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p5 c0 c1
1
0 8
2
0 11 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p6 c0 c1
1
0 8
2
0 12 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p7 c0 c1
1
0 8
2
0 13 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p8 c0 c1
1
0 8
2
0 14 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l7 p9 c0 c1
1
0 8
2
0 15 8 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p1 c0 c1
1
0 9
2
0 7 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p2 c0 c1
1
0 9
2
0 8 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p3 c0 c1
1
0 9
2
0 9 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p4 c0 c1
1
0 9
2
0 10 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p5 c0 c1
1
0 9
2
0 11 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p6 c0 c1
1
0 9
2
0 12 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p7 c0 c1
1
0 9
2
0 13 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p8 c0 c1
1
0 9
2
0 14 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l8 p9 c0 c1
1
0 9
2
0 15 9 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p1 c0 c1
1
0 10
2
0 7 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p2 c0 c1
1
0 10
2
0 8 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p3 c0 c1
1
0 10
2
0 9 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p4 c0 c1
1
0 10
2
0 10 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p5 c0 c1
1
0 10
2
0 11 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p6 c0 c1
1
0 10
2
0 12 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p7 c0 c1
1
0 10
2
0 13 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p8 c0 c1
1
0 10
2
0 14 10 15
0 6 1 0
1
end_operator
begin_operator
pick-up v5 l9 p9 c0 c1
1
0 10
2
0 15 10 15
0 6 1 0
1
end_operator
0
