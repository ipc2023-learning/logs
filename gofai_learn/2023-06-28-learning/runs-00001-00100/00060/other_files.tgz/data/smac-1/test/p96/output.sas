begin_version
3
end_version
begin_metric
0
end_metric
26
begin_variable
var0
-1
3
Atom at(v6, l13)
Atom at(v6, l6)
Atom at(v6, l9)
end_variable
begin_variable
var1
-1
16
Atom at(v1, l1)
Atom at(v1, l10)
Atom at(v1, l11)
Atom at(v1, l12)
Atom at(v1, l13)
Atom at(v1, l14)
Atom at(v1, l15)
Atom at(v1, l16)
Atom at(v1, l2)
Atom at(v1, l3)
Atom at(v1, l4)
Atom at(v1, l5)
Atom at(v1, l6)
Atom at(v1, l7)
Atom at(v1, l8)
Atom at(v1, l9)
end_variable
begin_variable
var2
-1
2
Atom capacity(v2, c0)
Atom capacity(v2, c1)
end_variable
begin_variable
var5
-1
2
Atom capacity(v5, c0)
Atom capacity(v5, c1)
end_variable
begin_variable
var7
-1
2
Atom capacity(v6, c0)
Atom capacity(v6, c1)
end_variable
begin_variable
var3
-1
4
Atom capacity(v3, c0)
Atom capacity(v3, c1)
Atom capacity(v3, c2)
Atom capacity(v3, c3)
end_variable
begin_variable
var4
-1
4
Atom capacity(v4, c0)
Atom capacity(v4, c1)
Atom capacity(v4, c2)
Atom capacity(v4, c3)
end_variable
begin_variable
var6
-1
4
Atom capacity(v7, c0)
Atom capacity(v7, c1)
Atom capacity(v7, c2)
Atom capacity(v7, c3)
end_variable
begin_variable
var8
-1
2
Atom capacity(v1, c0)
Atom capacity(v1, c1)
end_variable
begin_variable
var9
-1
23
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l13)
Atom at(p1, l14)
Atom at(p1, l15)
Atom at(p1, l16)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
Atom in(p1, v6)
Atom in(p1, v7)
end_variable
begin_variable
var10
-1
23
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l13)
Atom at(p10, l14)
Atom at(p10, l15)
Atom at(p10, l16)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
Atom in(p10, v6)
Atom in(p10, v7)
end_variable
begin_variable
var11
-1
23
Atom at(p11, l1)
Atom at(p11, l10)
Atom at(p11, l11)
Atom at(p11, l12)
Atom at(p11, l13)
Atom at(p11, l14)
Atom at(p11, l15)
Atom at(p11, l16)
Atom at(p11, l2)
Atom at(p11, l3)
Atom at(p11, l4)
Atom at(p11, l5)
Atom at(p11, l6)
Atom at(p11, l7)
Atom at(p11, l8)
Atom at(p11, l9)
Atom in(p11, v1)
Atom in(p11, v2)
Atom in(p11, v3)
Atom in(p11, v4)
Atom in(p11, v5)
Atom in(p11, v6)
Atom in(p11, v7)
end_variable
begin_variable
var12
-1
23
Atom at(p12, l1)
Atom at(p12, l10)
Atom at(p12, l11)
Atom at(p12, l12)
Atom at(p12, l13)
Atom at(p12, l14)
Atom at(p12, l15)
Atom at(p12, l16)
Atom at(p12, l2)
Atom at(p12, l3)
Atom at(p12, l4)
Atom at(p12, l5)
Atom at(p12, l6)
Atom at(p12, l7)
Atom at(p12, l8)
Atom at(p12, l9)
Atom in(p12, v1)
Atom in(p12, v2)
Atom in(p12, v3)
Atom in(p12, v4)
Atom in(p12, v5)
Atom in(p12, v6)
Atom in(p12, v7)
end_variable
begin_variable
var13
-1
23
Atom at(p13, l1)
Atom at(p13, l10)
Atom at(p13, l11)
Atom at(p13, l12)
Atom at(p13, l13)
Atom at(p13, l14)
Atom at(p13, l15)
Atom at(p13, l16)
Atom at(p13, l2)
Atom at(p13, l3)
Atom at(p13, l4)
Atom at(p13, l5)
Atom at(p13, l6)
Atom at(p13, l7)
Atom at(p13, l8)
Atom at(p13, l9)
Atom in(p13, v1)
Atom in(p13, v2)
Atom in(p13, v3)
Atom in(p13, v4)
Atom in(p13, v5)
Atom in(p13, v6)
Atom in(p13, v7)
end_variable
begin_variable
var14
-1
23
Atom at(p14, l1)
Atom at(p14, l10)
Atom at(p14, l11)
Atom at(p14, l12)
Atom at(p14, l13)
Atom at(p14, l14)
Atom at(p14, l15)
Atom at(p14, l16)
Atom at(p14, l2)
Atom at(p14, l3)
Atom at(p14, l4)
Atom at(p14, l5)
Atom at(p14, l6)
Atom at(p14, l7)
Atom at(p14, l8)
Atom at(p14, l9)
Atom in(p14, v1)
Atom in(p14, v2)
Atom in(p14, v3)
Atom in(p14, v4)
Atom in(p14, v5)
Atom in(p14, v6)
Atom in(p14, v7)
end_variable
begin_variable
var15
-1
23
Atom at(p15, l1)
Atom at(p15, l10)
Atom at(p15, l11)
Atom at(p15, l12)
Atom at(p15, l13)
Atom at(p15, l14)
Atom at(p15, l15)
Atom at(p15, l16)
Atom at(p15, l2)
Atom at(p15, l3)
Atom at(p15, l4)
Atom at(p15, l5)
Atom at(p15, l6)
Atom at(p15, l7)
Atom at(p15, l8)
Atom at(p15, l9)
Atom in(p15, v1)
Atom in(p15, v2)
Atom in(p15, v3)
Atom in(p15, v4)
Atom in(p15, v5)
Atom in(p15, v6)
Atom in(p15, v7)
end_variable
begin_variable
var16
-1
23
Atom at(p16, l1)
Atom at(p16, l10)
Atom at(p16, l11)
Atom at(p16, l12)
Atom at(p16, l13)
Atom at(p16, l14)
Atom at(p16, l15)
Atom at(p16, l16)
Atom at(p16, l2)
Atom at(p16, l3)
Atom at(p16, l4)
Atom at(p16, l5)
Atom at(p16, l6)
Atom at(p16, l7)
Atom at(p16, l8)
Atom at(p16, l9)
Atom in(p16, v1)
Atom in(p16, v2)
Atom in(p16, v3)
Atom in(p16, v4)
Atom in(p16, v5)
Atom in(p16, v6)
Atom in(p16, v7)
end_variable
begin_variable
var17
-1
23
Atom at(p17, l1)
Atom at(p17, l10)
Atom at(p17, l11)
Atom at(p17, l12)
Atom at(p17, l13)
Atom at(p17, l14)
Atom at(p17, l15)
Atom at(p17, l16)
Atom at(p17, l2)
Atom at(p17, l3)
Atom at(p17, l4)
Atom at(p17, l5)
Atom at(p17, l6)
Atom at(p17, l7)
Atom at(p17, l8)
Atom at(p17, l9)
Atom in(p17, v1)
Atom in(p17, v2)
Atom in(p17, v3)
Atom in(p17, v4)
Atom in(p17, v5)
Atom in(p17, v6)
Atom in(p17, v7)
end_variable
begin_variable
var18
-1
23
Atom at(p2, l1)
Atom at




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





end_operator
begin_operator
pick-up v6 l9 p11 c0 c1
1
0 2
2
0 11 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p12 c0 c1
1
0 2
2
0 12 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p13 c0 c1
1
0 2
2
0 13 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p14 c0 c1
1
0 2
2
0 14 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p15 c0 c1
1
0 2
2
0 15 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p16 c0 c1
1
0 2
2
0 16 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p17 c0 c1
1
0 2
2
0 17 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p2 c0 c1
1
0 2
2
0 18 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p3 c0 c1
1
0 2
2
0 19 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p4 c0 c1
1
0 2
2
0 20 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p5 c0 c1
1
0 2
2
0 21 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p6 c0 c1
1
0 2
2
0 22 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p7 c0 c1
1
0 2
2
0 23 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p8 c0 c1
1
0 2
2
0 24 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v6 l9 p9 c0 c1
1
0 2
2
0 25 15 21
0 4 1 0
1
end_operator
begin_operator
pick-up v7 l11 p1 c0 c1
0
2
0 9 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p1 c1 c2
0
2
0 9 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p1 c2 c3
0
2
0 9 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p10 c0 c1
0
2
0 10 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p10 c1 c2
0
2
0 10 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p10 c2 c3
0
2
0 10 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p11 c0 c1
0
2
0 11 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p11 c1 c2
0
2
0 11 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p11 c2 c3
0
2
0 11 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p12 c0 c1
0
2
0 12 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p12 c1 c2
0
2
0 12 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p12 c2 c3
0
2
0 12 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p13 c0 c1
0
2
0 13 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p13 c1 c2
0
2
0 13 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p13 c2 c3
0
2
0 13 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p14 c0 c1
0
2
0 14 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p14 c1 c2
0
2
0 14 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p14 c2 c3
0
2
0 14 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p15 c0 c1
0
2
0 15 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p15 c1 c2
0
2
0 15 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p15 c2 c3
0
2
0 15 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p16 c0 c1
0
2
0 16 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p16 c1 c2
0
2
0 16 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p16 c2 c3
0
2
0 16 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p17 c0 c1
0
2
0 17 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p17 c1 c2
0
2
0 17 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p17 c2 c3
0
2
0 17 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p2 c0 c1
0
2
0 18 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p2 c1 c2
0
2
0 18 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p2 c2 c3
0
2
0 18 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p3 c0 c1
0
2
0 19 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p3 c1 c2
0
2
0 19 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p3 c2 c3
0
2
0 19 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p4 c0 c1
0
2
0 20 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p4 c1 c2
0
2
0 20 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p4 c2 c3
0
2
0 20 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p5 c0 c1
0
2
0 21 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p5 c1 c2
0
2
0 21 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p5 c2 c3
0
2
0 21 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p6 c0 c1
0
2
0 22 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p6 c1 c2
0
2
0 22 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p6 c2 c3
0
2
0 22 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p7 c0 c1
0
2
0 23 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p7 c1 c2
0
2
0 23 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p7 c2 c3
0
2
0 23 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p8 c0 c1
0
2
0 24 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p8 c1 c2
0
2
0 24 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p8 c2 c3
0
2
0 24 2 22
0 7 3 2
1
end_operator
begin_operator
pick-up v7 l11 p9 c0 c1
0
2
0 25 2 22
0 7 1 0
1
end_operator
begin_operator
pick-up v7 l11 p9 c1 c2
0
2
0 25 2 22
0 7 2 1
1
end_operator
begin_operator
pick-up v7 l11 p9 c2 c3
0
2
0 25 2 22
0 7 3 2
1
end_operator
0
