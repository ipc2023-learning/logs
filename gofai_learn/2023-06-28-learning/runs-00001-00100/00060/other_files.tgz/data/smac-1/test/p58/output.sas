begin_version
3
end_version
begin_metric
0
end_metric
16
begin_variable
var0
-1
12
Atom at(v3, l1)
Atom at(v3, l10)
Atom at(v3, l11)
Atom at(v3, l12)
Atom at(v3, l2)
Atom at(v3, l3)
Atom at(v3, l4)
Atom at(v3, l5)
Atom at(v3, l6)
Atom at(v3, l7)
Atom at(v3, l8)
Atom at(v3, l9)
end_variable
begin_variable
var3
-1
2
Atom capacity(v4, c0)
Atom capacity(v4, c1)
end_variable
begin_variable
var4
-1
2
Atom capacity(v5, c0)
Atom capacity(v5, c1)
end_variable
begin_variable
var1
-1
3
Atom capacity(v1, c0)
Atom capacity(v1, c1)
Atom capacity(v1, c2)
end_variable
begin_variable
var2
-1
3
Atom capacity(v2, c0)
Atom capacity(v2, c1)
Atom capacity(v2, c2)
end_variable
begin_variable
var5
-1
2
Atom capacity(v3, c0)
Atom capacity(v3, c1)
end_variable
begin_variable
var6
-1
17
Atom at(p1, l1)
Atom at(p1, l10)
Atom at(p1, l11)
Atom at(p1, l12)
Atom at(p1, l2)
Atom at(p1, l3)
Atom at(p1, l4)
Atom at(p1, l5)
Atom at(p1, l6)
Atom at(p1, l7)
Atom at(p1, l8)
Atom at(p1, l9)
Atom in(p1, v1)
Atom in(p1, v2)
Atom in(p1, v3)
Atom in(p1, v4)
Atom in(p1, v5)
end_variable
begin_variable
var7
-1
17
Atom at(p10, l1)
Atom at(p10, l10)
Atom at(p10, l11)
Atom at(p10, l12)
Atom at(p10, l2)
Atom at(p10, l3)
Atom at(p10, l4)
Atom at(p10, l5)
Atom at(p10, l6)
Atom at(p10, l7)
Atom at(p10, l8)
Atom at(p10, l9)
Atom in(p10, v1)
Atom in(p10, v2)
Atom in(p10, v3)
Atom in(p10, v4)
Atom in(p10, v5)
end_variable
begin_variable
var8
-1
17
Atom at(p2, l1)
Atom at(p2, l10)
Atom at(p2, l11)
Atom at(p2, l12)
Atom at(p2, l2)
Atom at(p2, l3)
Atom at(p2, l4)
Atom at(p2, l5)
Atom at(p2, l6)
Atom at(p2, l7)
Atom at(p2, l8)
Atom at(p2, l9)
Atom in(p2, v1)
Atom in(p2, v2)
Atom in(p2, v3)
Atom in(p2, v4)
Atom in(p2, v5)
end_variable
begin_variable
var9
-1
17
Atom at(p3, l1)
Atom at(p3, l10)
Atom at(p3, l11)
Atom at(p3, l12)
Atom at(p3, l2)
Atom at(p3, l3)
Atom at(p3, l4)
Atom at(p3, l5)
Atom at(p3, l6)
Atom at(p3, l7)
Atom at(p3, l8)
Atom at(p3, l9)
Atom in(p3, v1)
Atom in(p3, v2)
Atom in(p3, v3)
Atom in(p3, v4)
Atom in(p3, v5)
end_variable
begin_variable
var10
-1
17
Atom at(p4, l1)
Atom at(p4, l10)
Atom at(p4, l11)
Atom at(p4, l12)
Atom at(p4, l2)
Atom at(p4, l3)
Atom at(p4, l4)
Atom at(p4, l5)
Atom at(p4, l6)
Atom at(p4, l7)
Atom at(p4, l8)
Atom at(p4, l9)
Atom in(p4, v1)
Atom in(p4, v2)
Atom in(p4, v3)
Atom in(p4, v4)
Atom in(p4, v5)
end_variable
begin_variable
var11
-1
17
Atom at(p5, l1)
Atom at(p5, l10)
Atom at(p5, l11)
Atom at(p5, l12)
Atom at(p5, l2)
Atom at(p5, l3)
Atom at(p5, l4)
Atom at(p5, l5)
Atom at(p5, l6)
Atom at(p5, l7)
Atom at(p5, l8)
Atom at(p5, l9)
Atom in(p5, v1)
Atom in(p5, v2)
Atom in(p5, v3)
Atom in(p5, v4)
Atom in(p5, v5)
end_variable
begin_variable
var12
-1
17
Atom at(p6, l1)
Atom at(p6, l10)
Atom at(p6, l11)
Atom at(p6, l12)
Atom at(p6, l2)
Atom at(p6, l3)
Atom at(p6, l4)
Atom at(p6, l5)
Atom at(p6, l6)
Atom at(p6, l7)
Atom at(p6, l8)
Atom at(p6, l9)
Atom in(p6, v1)
Atom in(p6, v2)
Atom in(p6, v3)
Atom in(p6, v4)
Atom in(p6, v5)
end_variable
begin_variable
var13
-1
17
Atom at(p7, l1)
Atom at(p7, l10)
Atom at(p7, l11)
Atom at(p7, l12)
Atom at(p7, l2)
Atom at(p7, l3)
Atom at(p7, l4)
Atom at(p7, l5)
Atom at(p7, l6)
Atom at(p7, l7)
Atom at(p7, l8)
Atom at(p7, l9)
Atom in(p7, v1)
Atom in(p7, v2)
Atom in(p7, v3)
Atom in(p7, v4)
Atom in(p7, v5)
end_variable
begin_variable
var14
-1
17
Atom at(p8, l1)
Atom at(p8, l10)
Atom at(p8, l11)
Atom at(p8, l12)
Atom at(p8, l2)
Atom at(p8, l3)
Atom at(p8, l4)
Atom at(p8, l5)
Atom at(p8, l6)
Atom at(p8, l7)
Atom at(p8, l8)
Atom at(p8, l9)
Atom in(p8, v1)
Atom in(p8, v2)
Atom in(p8, v3)
Atom in(p8, v4)
Atom in(p8, v5)
end_variable
begin_variable
var15
-1
17
Atom at(p9, l1)
Atom at(p9, l10)
Atom at(p9, l11)
Atom at(p9, l12)
Atom at(p9, l2)
Atom at(p9, l3)
Atom at(p9, l4)
Atom at(p9, l5)
Atom at(p9, l6)
Atom at(p9, l7)
Atom at(p9, l8)
Atom at(p9, l9)
Atom in(p9, v1)
Atom in(p9, v2)
Atom in(p9, v3)
Atom in(p9, v4)
Atom in(p9, v5)
end_variable
165
begin_mutex_group
2
1 1
6 15
end_mutex_group
begin_mutex_group
2
1 1
7 15
end_mutex_group
begin_mutex_group
2
1 1
8 15
end_mutex_group
begin_mutex_group
2
1 1
9 15
end_mutex_group
begin_mutex_group
2
1 1
10 15
end_mutex_group
begin_mutex_group
2
1 1
11 15
end_mutex_group
begin_mutex_group
2
1 1
12 15
end_mutex_group
begin_mutex_group
2
1 1
13 15
end_mutex_group
begin_mutex_group
2
1 1
14 15
end_mutex_group
begin_mutex_group
2
1 1
15 15
end_mutex_group
begin_mutex_group
2
2 1
6 16
end_mutex_group
begin_mutex_group
2
2 1
7 16
end_mutex_group
begin_mutex_group
2
2 1
8 16
end_mutex_group
begin_mutex_group
2
2 1
9 16
end_mutex_group
begin_mutex_group
2
2 1
10 16
end_mutex_group
begin_mutex_group
2
2 1
11 16
end_mutex_group
begin_mutex_group
2
2 1
12 16
end_mutex_group
begin_mutex_group
2
2 1
13 16
end_mutex_group
begin_mutex_group
2
2 1
14 16
end_mutex_group
begin_mutex_group
2
2 1
15 16
end_mutex_group
begin_mutex_group
2
5 1
6 14
end_mutex_group
begin_mutex_group
2
5 1
7 14
end_mutex_group
begin_mutex_group
2
5 1
8 14
end_mutex_group
begin_mutex_group
2
5 1
9 14
end_mutex_group
begin_mutex_group
2
5 1
10 14
end_mutex_group
begin_mutex_group
2
5 1
11 14
end_mutex_group
begin_mutex_group
2
5 1





 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




1
0 7
2
0 10 7 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l5 p5 c0 c1
1
0 7
2
0 11 7 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l5 p6 c0 c1
1
0 7
2
0 12 7 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l5 p7 c0 c1
1
0 7
2
0 13 7 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l5 p8 c0 c1
1
0 7
2
0 14 7 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l5 p9 c0 c1
1
0 7
2
0 15 7 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p1 c0 c1
1
0 8
2
0 6 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p10 c0 c1
1
0 8
2
0 7 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p2 c0 c1
1
0 8
2
0 8 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p3 c0 c1
1
0 8
2
0 9 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p4 c0 c1
1
0 8
2
0 10 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p5 c0 c1
1
0 8
2
0 11 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p6 c0 c1
1
0 8
2
0 12 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p7 c0 c1
1
0 8
2
0 13 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p8 c0 c1
1
0 8
2
0 14 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l6 p9 c0 c1
1
0 8
2
0 15 8 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p1 c0 c1
1
0 9
2
0 6 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p10 c0 c1
1
0 9
2
0 7 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p2 c0 c1
1
0 9
2
0 8 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p3 c0 c1
1
0 9
2
0 9 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p4 c0 c1
1
0 9
2
0 10 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p5 c0 c1
1
0 9
2
0 11 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p6 c0 c1
1
0 9
2
0 12 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p7 c0 c1
1
0 9
2
0 13 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p8 c0 c1
1
0 9
2
0 14 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l7 p9 c0 c1
1
0 9
2
0 15 9 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p1 c0 c1
1
0 10
2
0 6 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p10 c0 c1
1
0 10
2
0 7 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p2 c0 c1
1
0 10
2
0 8 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p3 c0 c1
1
0 10
2
0 9 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p4 c0 c1
1
0 10
2
0 10 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p5 c0 c1
1
0 10
2
0 11 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p6 c0 c1
1
0 10
2
0 12 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p7 c0 c1
1
0 10
2
0 13 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p8 c0 c1
1
0 10
2
0 14 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l8 p9 c0 c1
1
0 10
2
0 15 10 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p1 c0 c1
1
0 11
2
0 6 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p10 c0 c1
1
0 11
2
0 7 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p2 c0 c1
1
0 11
2
0 8 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p3 c0 c1
1
0 11
2
0 9 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p4 c0 c1
1
0 11
2
0 10 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p5 c0 c1
1
0 11
2
0 11 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p6 c0 c1
1
0 11
2
0 12 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p7 c0 c1
1
0 11
2
0 13 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p8 c0 c1
1
0 11
2
0 14 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v3 l9 p9 c0 c1
1
0 11
2
0 15 11 14
0 5 1 0
1
end_operator
begin_operator
pick-up v4 l4 p1 c0 c1
0
2
0 6 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p10 c0 c1
0
2
0 7 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p2 c0 c1
0
2
0 8 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p3 c0 c1
0
2
0 9 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p4 c0 c1
0
2
0 10 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p5 c0 c1
0
2
0 11 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p6 c0 c1
0
2
0 12 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p7 c0 c1
0
2
0 13 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p8 c0 c1
0
2
0 14 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v4 l4 p9 c0 c1
0
2
0 15 6 15
0 1 1 0
1
end_operator
begin_operator
pick-up v5 l7 p1 c0 c1
0
2
0 6 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p10 c0 c1
0
2
0 7 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p2 c0 c1
0
2
0 8 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p3 c0 c1
0
2
0 9 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p4 c0 c1
0
2
0 10 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p5 c0 c1
0
2
0 11 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p6 c0 c1
0
2
0 12 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p7 c0 c1
0
2
0 13 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p8 c0 c1
0
2
0 14 9 16
0 2 1 0
1
end_operator
begin_operator
pick-up v5 l7 p9 c0 c1
0
2
0 15 9 16
0 2 1 0
1
end_operator
0
