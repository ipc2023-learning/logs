%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% modes:
:- discontiguous('ini:road'/3).
:- discontiguous('goal:road'/3).
:- modeb(*, 'ini:road'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:road'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:road'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:road'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:at'/3).
:- discontiguous('goal:at'/3).
:- modeb(*, 'ini:at'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:at'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:at'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:at'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:in'/3).
:- discontiguous('goal:in'/3).
:- modeb(*, 'ini:in'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:in'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:in'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:in'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:capacity'/3).
:- discontiguous('goal:capacity'/3).
:- modeb(*, 'ini:capacity'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:capacity'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:capacity'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:capacity'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:capacity-predecessor'/3).
:- discontiguous('goal:capacity-predecessor'/3).
:- modeb(*, 'ini:capacity-predecessor'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:capacity-predecessor'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:capacity-predecessor'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:capacity-predecessor'(-'type:object', +'type:object', +task_id)).

% types and constants

:- modeh(1, class(+'type:object', +'type:object', +'type:object', +task_id)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% determinations:
:- determination(class/4, 'ini:road'/3).
:- determination(class/4, 'goal:road'/3).
:- determination(class/4, 'ini:at'/3).
:- determination(class/4, 'goal:at'/3).
:- determination(class/4, 'ini:in'/3).
:- determination(class/4, 'goal:in'/3).
:- determination(class/4, 'ini:capacity'/3).
:- determination(class/4, 'goal:capacity'/3).
:- determination(class/4, 'ini:capacity-predecessor'/3).
:- determination(class/4, 'goal:capacity-predecessor'/3).

'type:object'('obj:v1').
'type:object'('obj:p1').
'type:object'('obj:l1').
'type:object'('obj:l2').
'type:object'('obj:c0').
'type:object'('obj:c1').
'type:object'('obj:l3').
'type:object'('obj:p2').
'type:object'('obj:c2').
'type:object'('obj:v2').
'type:object'('obj:l4').
'type:object'('obj:p3').
'type:object'('obj:p4').
'type:object'('obj:v3').
'type:object'('obj:l5').
'type:object'('obj:l6').
'type:object'('obj:l7').
'type:object'('obj:v4').
'type:object'('obj:p5').
'type:object'('obj:l8').
'type:object'('obj:p6').
'type:object'('obj:l9').


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p01
'ini:capacity'('obj:v1','obj:c1','p01').
'ini:road'('obj:l2','obj:l1','p01').
'ini:capacity-predecessor'('obj:c0','obj:c1','p01').
'ini:at'('obj:v1','obj:l1','p01').
'ini:at'('obj:p1','obj:l1','p01').
'ini:road'('obj:l1','obj:l2','p01').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p01

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p02
'ini:capacity'('obj:v1','obj:c1','p02').
'ini:at'('obj:v1','obj:l2','p02').
'ini:road'('obj:l2','obj:l1','p02').
'ini:capacity-predecessor'('obj:c0','obj:c1','p02').
'ini:at'('obj:p1','obj:l1','p02').
'ini:road'('obj:l1','obj:l2','p02').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p02

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p03
'ini:capacity'('obj:v1','obj:c1','p03').
'ini:road'('obj:l3','obj:l2','p03').
'ini:at'('obj:p1','obj:l3','p03').
'ini:road'('obj:l2','obj:l1','p03').
'ini:road'('obj:l2','obj:l3','p03').
'ini:capacity-predecessor'('obj:c0','obj:c1','p03').
'ini:at'('obj:v1','obj:l1','p03').
'ini:road'('obj:l1','obj:l2','p03').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p03

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p04
'ini:capacity'('obj:v1','obj:c1','p04').
'ini:road'('obj:l3','obj:l2','p04').
'ini:road'('obj:l2','obj:l1','p04').
'ini:road'('obj:l2','obj:l3','p04').
'ini:at'('obj:v1','obj:l3','p04').
'ini:capacity-predecessor'('obj:c0','obj:c1','p04').
'ini:at'('obj:p1','obj:l1','p04').
'ini:road'('obj:l1','obj:l2','p04').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p04

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p05
'ini:at'('obj:p2','obj:l1','p05').
'ini:road'('obj:l2','obj:l1','p05').
'ini:capacity'('obj:v1','obj:c2','p05').
'ini:capacity-predecessor'('obj:c0','obj:c1','p05').
'ini:capacity-predecessor'('obj:c1','obj:c2','p05').
'ini:at'('obj:v1','obj:l1','p05').
'ini:at'('obj:p1','obj:l1','p05').
'ini:road'('obj:l1','obj:l2','p05').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p05
'goal:at'('obj:p1','obj:l2','p05').
'goal:at'('obj:p2','obj:l2','p05').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p06
'ini:road'('obj:l2','obj:l1','p06').
'ini:at'('obj:v1','obj:l1','p06').
'ini:at'('obj:p2','obj:l2','p06').
'ini:capacity'('obj:v1','obj:c2','p06').
'ini:capacity-predecessor'('obj:c0','obj:c1','p06').
'ini:capacity-pre




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





'ini:road'('obj:l5','obj:l6','p33').
'ini:road'('obj:l1','obj:l5','p33').
'ini:road'('obj:l6','obj:l4','p33').
'ini:at'('obj:v2','obj:l8','p33').
'ini:road'('obj:l6','obj:l5','p33').
'ini:road'('obj:l3','obj:l5','p33').
'ini:capacity'('obj:v4','obj:c2','p33').
'ini:capacity-predecessor'('obj:c1','obj:c2','p33').
'ini:road'('obj:l4','obj:l6','p33').
'ini:road'('obj:l1','obj:l7','p33').
'ini:capacity-predecessor'('obj:c0','obj:c1','p33').
'ini:at'('obj:p3','obj:l6','p33').
'ini:road'('obj:l2','obj:l8','p33').
'ini:road'('obj:l3','obj:l4','p33').
'ini:road'('obj:l5','obj:l8','p33').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p33
'goal:at'('obj:p1','obj:l7','p33').
'goal:at'('obj:p2','obj:l8','p33').
'goal:at'('obj:p3','obj:l8','p33').
'goal:at'('obj:p4','obj:l7','p33').
'goal:at'('obj:p5','obj:l2','p33').
'goal:at'('obj:p6','obj:l4','p33').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p34
'ini:capacity'('obj:v4','obj:c1','p34').
'ini:road'('obj:l9','obj:l2','p34').
'ini:road'('obj:l7','obj:l3','p34').
'ini:road'('obj:l2','obj:l9','p34').
'ini:at'('obj:v1','obj:l5','p34').
'ini:at'('obj:p1','obj:l9','p34').
'ini:at'('obj:v4','obj:l6','p34').
'ini:at'('obj:p4','obj:l2','p34').
'ini:road'('obj:l2','obj:l3','p34').
'ini:road'('obj:l8','obj:l5','p34').
'ini:capacity'('obj:v1','obj:c2','p34').
'ini:road'('obj:l7','obj:l4','p34').
'ini:road'('obj:l6','obj:l2','p34').
'ini:road'('obj:l3','obj:l2','p34').
'ini:road'('obj:l4','obj:l7','p34').
'ini:capacity'('obj:v3','obj:c2','p34').
'ini:at'('obj:p6','obj:l2','p34').
'ini:at'('obj:v2','obj:l5','p34').
'ini:road'('obj:l9','obj:l1','p34').
'ini:at'('obj:p5','obj:l6','p34').
'ini:capacity'('obj:v2','obj:c2','p34').
'ini:road'('obj:l3','obj:l7','p34').
'ini:at'('obj:p2','obj:l8','p34').
'ini:road'('obj:l2','obj:l6','p34').
'ini:at'('obj:v3','obj:l8','p34').
'ini:road'('obj:l5','obj:l6','p34').
'ini:road'('obj:l1','obj:l9','p34').
'ini:road'('obj:l6','obj:l5','p34').
'ini:capacity-predecessor'('obj:c1','obj:c2','p34').
'ini:capacity-predecessor'('obj:c0','obj:c1','p34').
'ini:at'('obj:p3','obj:l6','p34').
'ini:road'('obj:l5','obj:l8','p34').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p34
'goal:at'('obj:p1','obj:l1','p34').
'goal:at'('obj:p2','obj:l5','p34').
'goal:at'('obj:p3','obj:l8','p34').
'goal:at'('obj:p4','obj:l5','p34').
'goal:at'('obj:p5','obj:l1','p34').
'goal:at'('obj:p6','obj:l9','p34').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p36
'ini:capacity'('obj:v4','obj:c1','p36').
'ini:road'('obj:l8','obj:l2','p36').
'ini:road'('obj:l5','obj:l7','p36').
'ini:road'('obj:l3','obj:l6','p36').
'ini:road'('obj:l5','obj:l2','p36').
'ini:road'('obj:l6','obj:l1','p36').
'ini:road'('obj:l7','obj:l2','p36').
'ini:road'('obj:l4','obj:l8','p36').
'ini:road'('obj:l9','obj:l2','p36').
'ini:at'('obj:p2','obj:l2','p36').
'ini:road'('obj:l6','obj:l8','p36').
'ini:at'('obj:p5','obj:l9','p36').
'ini:at'('obj:p4','obj:l8','p36').
'ini:road'('obj:l7','obj:l3','p36').
'ini:road'('obj:l1','obj:l6','p36').
'ini:road'('obj:l2','obj:l5','p36').
'ini:road'('obj:l2','obj:l9','p36').
'ini:at'('obj:p1','obj:l4','p36').
'ini:at'('obj:v4','obj:l1','p36').
'ini:road'('obj:l8','obj:l9','p36').
'ini:at'('obj:v1','obj:l3','p36').
'ini:capacity'('obj:v1','obj:c2','p36').
'ini:road'('obj:l2','obj:l7','p36').
'ini:road'('obj:l5','obj:l3','p36').
'ini:road'('obj:l8','obj:l7','p36').
'ini:road'('obj:l2','obj:l1','p36').
'ini:road'('obj:l1','obj:l8','p36').
'ini:road'('obj:l7','obj:l5','p36').
'ini:road'('obj:l4','obj:l2','p36').
'ini:road'('obj:l4','obj:l5','p36').
'ini:road'('obj:l4','obj:l9','p36').
'ini:road'('obj:l7','obj:l4','p36').
'ini:road'('obj:l1','obj:l2','p36').
'ini:at'('obj:p3','obj:l5','p36').
'ini:at'('obj:v3','obj:l9','p36').
'ini:road'('obj:l9','obj:l4','p36').
'ini:road'('obj:l6','obj:l2','p36').
'ini:road'('obj:l8','obj:l1','p36').
'ini:road'('obj:l4','obj:l3','p36').
'ini:road'('obj:l5','obj:l1','p36').
'ini:road'('obj:l4','obj:l7','p36').
'ini:at'('obj:v2','obj:l9','p36').
'ini:road'('obj:l7','obj:l1','p36').
'ini:road'('obj:l6','obj:l3','p36').
'ini:road'('obj:l2','obj:l4','p36').
'ini:road'('obj:l3','obj:l1','p36').
'ini:capacity'('obj:v3','obj:c1','p36').
'ini:capacity'('obj:v2','obj:c2','p36').
'ini:road'('obj:l8','obj:l4','p36').
'ini:road'('obj:l3','obj:l7','p36').
'ini:road'('obj:l9','obj:l8','p36').
'ini:road'('obj:l5','obj:l4','p36').
'ini:road'('obj:l7','obj:l8','p36').
'ini:road'('obj:l2','obj:l6','p36').
'ini:road'('obj:l8','obj:l6','p36').
'ini:road'('obj:l1','obj:l5','p36').
'ini:road'('obj:l6','obj:l9','p36').
'ini:road'('obj:l9','obj:l6','p36').
'ini:road'('obj:l3','obj:l5','p36').
'ini:road'('obj:l1','obj:l7','p36').
'ini:road'('obj:l2','obj:l8','p36').
'ini:road'('obj:l1','obj:l3','p36').
'ini:capacity-predecessor'('obj:c0','obj:c1','p36').
'ini:capacity-predecessor'('obj:c1','obj:c2','p36').
'ini:road'('obj:l3','obj:l4','p36').
'ini:at'('obj:p6','obj:l4','p36').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p36
'goal:at'('obj:p1','obj:l7','p36').
'goal:at'('obj:p2','obj:l9','p36').
'goal:at'('obj:p3','obj:l4','p36').
'goal:at'('obj:p4','obj:l4','p36').
'goal:at'('obj:p5','obj:l8','p36').
'goal:at'('obj:p6','obj:l7','p36').
