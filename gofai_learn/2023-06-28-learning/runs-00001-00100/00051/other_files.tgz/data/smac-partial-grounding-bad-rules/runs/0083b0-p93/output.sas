begin_version
3
end_version
begin_metric
0
end_metric
52
begin_variable
var1
-1
2
Atom clear(b3)
<none of those>
end_variable
begin_variable
var0
-1
2
Atom on-table(b11)
NegatedAtom on-table(b11)
end_variable
begin_variable
var3
-1
2
Atom clear(b17)
<none of those>
end_variable
begin_variable
var2
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var4
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var5
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var6
-1
2
Atom clear(b13)
<none of those>
end_variable
begin_variable
var10
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var11
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var12
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var13
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var7
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var8
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var15
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var14
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var9
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var16
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var17
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var18
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var19
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var20
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var21
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var22
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var23
-1
6
Atom arm-empty()
Atom holding(b10)
Atom holding(b11)
Atom holding(b22)
Atom holding(b7)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom on(b7, b3)
Atom on(b7, b8)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var35
-1
4
Atom holding(b23)
Atom on(b23, b10)
Atom on(b23, b18)
Atom on-table(b23)
end_variable
begin_variable
var43
-1
4
Atom holding(b21)
Atom on(b21, b7)
Atom on(b21, b8)
Atom on-table(b21)
end_variable
begin_variable
var25
-1
3
Atom on(b10, b21)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var38
-1
5
Atom holding(b4)
Atom on(b4, b1)
Atom on(b4, b13)
Atom on(b4, b24)
Atom on-table(b4)
end_variable
begin_variable
var44
-1
4
Atom holding(b25)
Atom on(b25, b11)
Atom on(b25, b22)
Atom on-table(b25)
end_variable
begin_variable
var26
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var27
-1
6
Atom holding(b26)
Atom on(b26, b12)
Atom on(b26, b2)
Atom on(b26, b20)
Atom on(b26, b25)
Atom on-table(b26)
end_variable
begin_variable
var28
-1
9
Atom holding(b5)
Atom on(b5, b11)
Atom on(b5, b13)
Atom on(b5, b17)
Atom on(b5, b23)
Atom on(b5, b25)
Atom on(b5, b4)
Atom on(b5, b8)
Atom on-table(b5)
end_variable
begin_variable
var42
-1
10
Atom holding(b18)
Atom on(b18, b13)
Atom on(b18, b15)
Atom on(b18, b2)
Atom on(b18, b20)
Atom on(b18, b26)
Atom on(b18, b27)
Atom on(b18, b4)
Atom on(b18, b5)
Atom on-table(b18)
end_variable
begin_variable
var45
-1
11
Atom holding(b15)
Atom on(b15, b13)
Atom on(b15, b17)
Atom on(b15, b18)
Atom on(b15, b2)
Atom on(b15, b20)
Atom on(b15, b22)
Atom on(b15, b26)
Atom on(b15, b4)
Atom on(b15, b5)
Atom on-table(b15)
end_variable
begin_variable
var31
-1
16
Atom holding(b20)
Atom on(b20, b12)
Atom on(b20, b15)
Atom on(b20, b16)
Atom on(b20, b19)
Atom on(b20, b2)
Atom on(b20, b21)
Atom on(b20, b23)
Atom on(b20, b24)
Atom on(b20, b26)
Atom on(b20, b4)
Atom on(b20, b5)
Atom on(b20, b6)
Atom on(b20, b8)
Atom on(b20, b9)
Atom on-table(b20)
end_variable
begin_variable
var30
-1
17
Atom holding(b9)
Atom on(b9, b12)
Atom on(b9, b15)
Atom on(b9, b16)
Atom on(b9, b18)
Atom on(b9, b19)
Atom on(b9, b2)
Atom on(b9, b20)
Atom on(b9, b21)
Atom on(b9, b23)
Atom on(b9, b24)
Atom on(b9, b26)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b8)
Atom on-table(b9)
end_variable
begin_variable
var33
-1
17
Atom holding(b2)
Atom on(b2, b12)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b18)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b22)
Atom on(b2, b23)
Atom on(b2, b25)
Atom on(b2, b26)
Atom on(b2, b5)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
end_variable
begin_variable
var29
-1
19
Atom holding(b12)
Atom on(b12, b11)
Atom on(b12, b13)
Atom on(b12, b15)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b22)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b25)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var32
-1
19
Atom holding(b6)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b14)
Atom on(b6, b15)
Atom on(b6, b16)
Atom on(b6, b18)
Atom on(b6, b19)
Atom on(b6, b2)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b23)
Atom on(b6, b24)
Atom on(b6, b25)
Atom on(b6, b26)
Atom on(




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0 23 0 5
0 5 -1 0
0 11 0 1
0 32 1 0
1
end_operator
begin_operator
unstack b5 b13
0
4
0 23 0 5
0 6 -1 0
0 11 0 1
0 32 2 0
1
end_operator
begin_operator
unstack b5 b17
0
4
0 23 0 5
0 2 -1 0
0 11 0 1
0 32 3 0
1
end_operator
begin_operator
unstack b5 b23
0
4
0 23 0 5
0 8 -1 0
0 11 0 1
0 32 4 0
1
end_operator
begin_operator
unstack b5 b25
0
4
0 23 0 5
0 7 -1 0
0 11 0 1
0 32 5 0
1
end_operator
begin_operator
unstack b5 b4
0
4
0 23 0 5
0 10 -1 0
0 11 0 1
0 32 6 0
1
end_operator
begin_operator
unstack b5 b8
0
4
0 23 0 5
0 11 0 1
0 22 -1 0
0 32 7 0
1
end_operator
begin_operator
unstack b6 b12
0
4
0 23 0 5
0 18 -1 0
0 17 0 1
0 39 1 0
1
end_operator
begin_operator
unstack b6 b13
0
4
0 23 0 5
0 6 -1 0
0 17 0 1
0 39 2 0
1
end_operator
begin_operator
unstack b6 b14
0
4
0 23 0 5
0 21 -1 0
0 17 0 1
0 39 3 0
1
end_operator
begin_operator
unstack b6 b15
0
4
0 23 0 5
0 14 -1 0
0 17 0 1
0 39 4 0
1
end_operator
begin_operator
unstack b6 b16
0
4
0 23 0 5
0 19 -1 0
0 17 0 1
0 39 5 0
1
end_operator
begin_operator
unstack b6 b18
0
4
0 23 0 5
0 13 -1 0
0 17 0 1
0 39 6 0
1
end_operator
begin_operator
unstack b6 b19
0
4
0 23 0 5
0 48 -1 0
0 17 0 1
0 39 7 0
1
end_operator
begin_operator
unstack b6 b2
0
4
0 23 0 5
0 50 -1 0
0 17 0 1
0 39 8 0
1
end_operator
begin_operator
unstack b6 b20
0
4
0 23 0 5
0 49 -1 0
0 17 0 1
0 39 9 0
1
end_operator
begin_operator
unstack b6 b21
0
4
0 23 0 5
0 9 -1 0
0 17 0 1
0 39 10 0
1
end_operator
begin_operator
unstack b6 b23
0
4
0 23 0 5
0 8 -1 0
0 17 0 1
0 39 11 0
1
end_operator
begin_operator
unstack b6 b24
0
4
0 23 0 5
0 20 -1 0
0 17 0 1
0 39 12 0
1
end_operator
begin_operator
unstack b6 b25
0
4
0 23 0 5
0 7 -1 0
0 17 0 1
0 39 13 0
1
end_operator
begin_operator
unstack b6 b26
0
4
0 23 0 5
0 47 -1 0
0 17 0 1
0 39 14 0
1
end_operator
begin_operator
unstack b6 b4
0
4
0 23 0 5
0 10 -1 0
0 17 0 1
0 39 15 0
1
end_operator
begin_operator
unstack b6 b5
0
4
0 23 0 5
0 11 -1 0
0 17 0 1
0 39 16 0
1
end_operator
begin_operator
unstack b6 b8
0
4
0 23 0 5
0 17 0 1
0 22 -1 0
0 39 17 0
1
end_operator
begin_operator
unstack b7 b8
0
4
0 23 0 4
0 3 0 1
0 22 -1 0
0 24 1 3
1
end_operator
begin_operator
unstack b8 b12
0
4
0 23 0 5
0 18 -1 0
0 22 0 1
0 46 1 0
1
end_operator
begin_operator
unstack b8 b13
0
4
0 23 0 5
0 6 -1 0
0 22 0 1
0 46 2 0
1
end_operator
begin_operator
unstack b8 b14
0
4
0 23 0 5
0 21 -1 0
0 22 0 1
0 46 3 0
1
end_operator
begin_operator
unstack b8 b15
0
4
0 23 0 5
0 14 -1 0
0 22 0 1
0 46 4 0
1
end_operator
begin_operator
unstack b8 b16
0
4
0 23 0 5
0 19 -1 0
0 22 0 1
0 46 5 0
1
end_operator
begin_operator
unstack b8 b17
0
4
0 23 0 5
0 2 -1 0
0 22 0 1
0 46 6 0
1
end_operator
begin_operator
unstack b8 b18
0
4
0 23 0 5
0 13 -1 0
0 22 0 1
0 46 7 0
1
end_operator
begin_operator
unstack b8 b19
0
4
0 23 0 5
0 48 -1 0
0 22 0 1
0 46 8 0
1
end_operator
begin_operator
unstack b8 b2
0
4
0 23 0 5
0 50 -1 0
0 22 0 1
0 46 9 0
1
end_operator
begin_operator
unstack b8 b20
0
4
0 23 0 5
0 49 -1 0
0 22 0 1
0 46 10 0
1
end_operator
begin_operator
unstack b8 b21
0
4
0 23 0 5
0 9 -1 0
0 22 0 1
0 46 11 0
1
end_operator
begin_operator
unstack b8 b23
0
4
0 23 0 5
0 8 -1 0
0 22 0 1
0 46 12 0
1
end_operator
begin_operator
unstack b8 b24
0
4
0 23 0 5
0 20 -1 0
0 22 0 1
0 46 13 0
1
end_operator
begin_operator
unstack b8 b25
0
4
0 23 0 5
0 7 -1 0
0 22 0 1
0 46 14 0
1
end_operator
begin_operator
unstack b8 b26
0
4
0 23 0 5
0 47 -1 0
0 22 0 1
0 46 15 0
1
end_operator
begin_operator
unstack b8 b27
0
4
0 23 0 5
0 12 -1 0
0 22 0 1
0 46 16 0
1
end_operator
begin_operator
unstack b8 b4
0
4
0 23 0 5
0 10 -1 0
0 22 0 1
0 46 17 0
1
end_operator
begin_operator
unstack b8 b5
0
4
0 23 0 5
0 11 -1 0
0 22 0 1
0 46 18 0
1
end_operator
begin_operator
unstack b8 b6
0
4
0 23 0 5
0 17 -1 0
0 22 0 1
0 46 19 0
1
end_operator
begin_operator
unstack b8 b9
0
4
0 23 0 5
0 22 0 1
0 16 -1 0
0 46 21 0
1
end_operator
begin_operator
unstack b9 b12
0
4
0 23 0 5
0 18 -1 0
0 16 0 1
0 36 1 0
1
end_operator
begin_operator
unstack b9 b15
0
4
0 23 0 5
0 14 -1 0
0 16 0 1
0 36 2 0
1
end_operator
begin_operator
unstack b9 b16
0
4
0 23 0 5
0 19 -1 0
0 16 0 1
0 36 3 0
1
end_operator
begin_operator
unstack b9 b18
0
4
0 23 0 5
0 13 -1 0
0 16 0 1
0 36 4 0
1
end_operator
begin_operator
unstack b9 b19
0
4
0 23 0 5
0 48 -1 0
0 16 0 1
0 36 5 0
1
end_operator
begin_operator
unstack b9 b2
0
4
0 23 0 5
0 50 -1 0
0 16 0 1
0 36 6 0
1
end_operator
begin_operator
unstack b9 b20
0
4
0 23 0 5
0 49 -1 0
0 16 0 1
0 36 7 0
1
end_operator
begin_operator
unstack b9 b21
0
4
0 23 0 5
0 9 -1 0
0 16 0 1
0 36 8 0
1
end_operator
begin_operator
unstack b9 b23
0
4
0 23 0 5
0 8 -1 0
0 16 0 1
0 36 9 0
1
end_operator
begin_operator
unstack b9 b24
0
4
0 23 0 5
0 20 -1 0
0 16 0 1
0 36 10 0
1
end_operator
begin_operator
unstack b9 b26
0
4
0 23 0 5
0 47 -1 0
0 16 0 1
0 36 11 0
1
end_operator
begin_operator
unstack b9 b4
0
4
0 23 0 5
0 10 -1 0
0 16 0 1
0 36 12 0
1
end_operator
begin_operator
unstack b9 b5
0
4
0 23 0 5
0 11 -1 0
0 16 0 1
0 36 13 0
1
end_operator
begin_operator
unstack b9 b6
0
4
0 23 0 5
0 17 -1 0
0 16 0 1
0 36 14 0
1
end_operator
begin_operator
unstack b9 b8
0
4
0 23 0 5
0 22 -1 0
0 16 0 1
0 36 15 0
1
end_operator
0
