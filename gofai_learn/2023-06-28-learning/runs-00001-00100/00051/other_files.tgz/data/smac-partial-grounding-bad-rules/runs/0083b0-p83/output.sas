begin_version
3
end_version
begin_metric
0
end_metric
51
begin_variable
var0
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var1
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var2
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var3
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var5
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var4
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var6
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var7
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var8
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var10
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var9
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var11
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var12
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var13
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var14
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var15
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var16
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var18
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var17
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var19
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var20
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var21
-1
7
Atom arm-empty()
Atom holding(b1)
Atom holding(b13)
Atom holding(b14)
Atom holding(b5)
Atom holding(b8)
<none of those>
end_variable
begin_variable
var22
-1
3
Atom on(b1, b12)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var23
-1
3
Atom on(b5, b17)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b8, b20)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var25
-1
3
Atom on(b14, b8)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom on(b13, b3)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var30
-1
6
Atom holding(b15)
Atom on(b15, b10)
Atom on(b15, b2)
Atom on(b15, b21)
Atom on(b15, b4)
Atom on-table(b15)
end_variable
begin_variable
var47
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var28
-1
17
Atom holding(b18)
Atom on(b18, b10)
Atom on(b18, b12)
Atom on(b18, b13)
Atom on(b18, b15)
Atom on(b18, b17)
Atom on(b18, b19)
Atom on(b18, b2)
Atom on(b18, b20)
Atom on(b18, b23)
Atom on(b18, b24)
Atom on(b18, b25)
Atom on(b18, b4)
Atom on(b18, b6)
Atom on(b18, b7)
Atom on(b18, b9)
Atom on-table(b18)
end_variable
begin_variable
var29
-1
17
Atom holding(b3)
Atom on(b3, b10)
Atom on(b3, b13)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b17)
Atom on(b3, b18)
Atom on(b3, b2)
Atom on(b3, b20)
Atom on(b3, b22)
Atom on(b3, b23)
Atom on(b3, b24)
Atom on(b3, b25)
Atom on(b3, b4)
Atom on(b3, b6)
Atom on(b3, b7)
Atom on-table(b3)
end_variable
begin_variable
var35
-1
18
Atom holding(b10)
Atom on(b10, b12)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b18)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b22)
Atom on(b10, b23)
Atom on(b10, b24)
Atom on(b10, b25)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b9)
Atom on-table(b10)
end_variable
begin_variable
var33
-1
19
Atom holding(b25)
Atom on(b25, b10)
Atom on(b25, b11)
Atom on(b25, b12)
Atom on(b25, b13)
Atom on(b25, b15)
Atom on(b25, b16)
Atom on(b25, b17)
Atom on(b25, b18)
Atom on(b25, b19)
Atom on(b25, b22)
Atom on(b25, b23)
Atom on(b25, b24)
Atom on(b25, b3)
Atom on(b25, b4)
Atom on(b25, b6)
Atom on(b25, b7)
Atom on(b25, b9)
Atom on-table(b25)
end_variable
begin_variable
var27
-1
19
Atom holding(b11)
Atom on(b11, b10)
Atom on(b11, b13)
Atom on(b11, b15)
Atom on(b11, b16)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b2)
Atom on(b11, b20)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b24)
Atom on(b11, b25)
Atom on(b11, b4)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b9)
Atom on-table(b11)
end_variable
begin_variable
var36
-1
19
Atom holding(b12)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b15)
Atom on(b12, b16)
Atom on(b12, b17)
Atom on(b12, b18)
Atom on(b12, b19)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b23)
Atom on(b12, b24)
Atom on(b12, b25)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b6)
Atom on(b12, b7)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var38
-1
19
Atom holding(b17)
Atom on(b17, b10)
Atom on(b17, b11)
Atom on(b17, b12)
Atom on(b17, b13)
Atom on(b17, b15)
Atom on(b17, b16)
Atom on(b17, b18)
Atom on(b17, b2)
Atom on(b17, b20)
Atom on(b17, b23)
Atom on(b17, b24)
Atom on(b17, b25)
Atom on(b17, b3)
Atom on(b17, b4)
Atom on(b17, b6)
Atom on(b17, b7)
Atom on(b17, b9)
Atom on-table(b17)
end_variable
begin_variable
var39
-1
19
Atom holding(b22)
Atom on(b22, b10)
Atom on(b22,




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 21 0 6
0 4 -1 0
0 50 0 1
0 45 6 0
1
end_operator
begin_operator
unstack b6 b16
0
4
0 21 0 6
0 18 -1 0
0 50 0 1
0 45 7 0
1
end_operator
begin_operator
unstack b6 b17
0
4
0 21 0 6
0 11 -1 0
0 50 0 1
0 45 8 0
1
end_operator
begin_operator
unstack b6 b18
0
4
0 21 0 6
0 7 -1 0
0 50 0 1
0 45 9 0
1
end_operator
begin_operator
unstack b6 b19
0
4
0 21 0 6
0 15 -1 0
0 50 0 1
0 45 10 0
1
end_operator
begin_operator
unstack b6 b2
0
4
0 21 0 6
0 48 -1 0
0 50 0 1
0 45 11 0
1
end_operator
begin_operator
unstack b6 b20
0
4
0 21 0 6
0 20 -1 0
0 50 0 1
0 45 12 0
1
end_operator
begin_operator
unstack b6 b21
0
4
0 21 0 6
0 5 -1 0
0 50 0 1
0 45 13 0
1
end_operator
begin_operator
unstack b6 b22
0
4
0 21 0 6
0 8 -1 0
0 50 0 1
0 45 14 0
1
end_operator
begin_operator
unstack b6 b23
0
4
0 21 0 6
0 9 -1 0
0 50 0 1
0 45 15 0
1
end_operator
begin_operator
unstack b6 b24
0
4
0 21 0 6
0 17 -1 0
0 50 0 1
0 45 16 0
1
end_operator
begin_operator
unstack b6 b25
0
4
0 21 0 6
0 12 -1 0
0 50 0 1
0 45 17 0
1
end_operator
begin_operator
unstack b6 b3
0
4
0 21 0 6
0 6 -1 0
0 50 0 1
0 45 18 0
1
end_operator
begin_operator
unstack b6 b4
0
4
0 21 0 6
0 49 -1 0
0 50 0 1
0 45 19 0
1
end_operator
begin_operator
unstack b6 b5
0
4
0 21 0 6
0 0 -1 0
0 50 0 1
0 45 20 0
1
end_operator
begin_operator
unstack b6 b8
0
4
0 21 0 6
0 50 0 1
0 2 -1 0
0 45 21 0
1
end_operator
begin_operator
unstack b6 b9
0
4
0 21 0 6
0 50 0 1
0 16 -1 0
0 45 22 0
1
end_operator
begin_operator
unstack b7 b1
0
4
0 21 0 6
0 1 -1 0
0 19 0 1
0 46 1 0
1
end_operator
begin_operator
unstack b7 b10
0
4
0 21 0 6
0 14 -1 0
0 19 0 1
0 46 2 0
1
end_operator
begin_operator
unstack b7 b11
0
4
0 21 0 6
0 10 -1 0
0 19 0 1
0 46 3 0
1
end_operator
begin_operator
unstack b7 b12
0
4
0 21 0 6
0 13 -1 0
0 19 0 1
0 46 4 0
1
end_operator
begin_operator
unstack b7 b13
0
4
0 21 0 6
0 3 -1 0
0 19 0 1
0 46 5 0
1
end_operator
begin_operator
unstack b7 b14
0
4
0 21 0 6
0 28 -1 0
0 19 0 1
0 46 6 0
1
end_operator
begin_operator
unstack b7 b15
0
4
0 21 0 6
0 4 -1 0
0 19 0 1
0 46 7 0
1
end_operator
begin_operator
unstack b7 b16
0
4
0 21 0 6
0 18 -1 0
0 19 0 1
0 46 8 0
1
end_operator
begin_operator
unstack b7 b17
0
4
0 21 0 6
0 11 -1 0
0 19 0 1
0 46 9 0
1
end_operator
begin_operator
unstack b7 b18
0
4
0 21 0 6
0 7 -1 0
0 19 0 1
0 46 10 0
1
end_operator
begin_operator
unstack b7 b19
0
4
0 21 0 6
0 15 -1 0
0 19 0 1
0 46 11 0
1
end_operator
begin_operator
unstack b7 b2
0
4
0 21 0 6
0 48 -1 0
0 19 0 1
0 46 12 0
1
end_operator
begin_operator
unstack b7 b20
0
4
0 21 0 6
0 20 -1 0
0 19 0 1
0 46 13 0
1
end_operator
begin_operator
unstack b7 b22
0
4
0 21 0 6
0 8 -1 0
0 19 0 1
0 46 14 0
1
end_operator
begin_operator
unstack b7 b23
0
4
0 21 0 6
0 9 -1 0
0 19 0 1
0 46 15 0
1
end_operator
begin_operator
unstack b7 b24
0
4
0 21 0 6
0 17 -1 0
0 19 0 1
0 46 16 0
1
end_operator
begin_operator
unstack b7 b25
0
4
0 21 0 6
0 12 -1 0
0 19 0 1
0 46 17 0
1
end_operator
begin_operator
unstack b7 b3
0
4
0 21 0 6
0 6 -1 0
0 19 0 1
0 46 18 0
1
end_operator
begin_operator
unstack b7 b4
0
4
0 21 0 6
0 49 -1 0
0 19 0 1
0 46 19 0
1
end_operator
begin_operator
unstack b7 b6
0
4
0 21 0 6
0 50 -1 0
0 19 0 1
0 46 21 0
1
end_operator
begin_operator
unstack b7 b8
0
4
0 21 0 6
0 19 0 1
0 2 -1 0
0 46 22 0
1
end_operator
begin_operator
unstack b7 b9
0
4
0 21 0 6
0 19 0 1
0 16 -1 0
0 46 23 0
1
end_operator
begin_operator
unstack b8 b20
0
4
0 21 0 5
0 20 -1 0
0 2 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b9 b1
0
4
0 21 0 6
0 1 -1 0
0 16 0 1
0 40 1 0
1
end_operator
begin_operator
unstack b9 b10
0
4
0 21 0 6
0 14 -1 0
0 16 0 1
0 40 2 0
1
end_operator
begin_operator
unstack b9 b11
0
4
0 21 0 6
0 10 -1 0
0 16 0 1
0 40 3 0
1
end_operator
begin_operator
unstack b9 b12
0
4
0 21 0 6
0 13 -1 0
0 16 0 1
0 40 4 0
1
end_operator
begin_operator
unstack b9 b15
0
4
0 21 0 6
0 4 -1 0
0 16 0 1
0 40 5 0
1
end_operator
begin_operator
unstack b9 b16
0
4
0 21 0 6
0 18 -1 0
0 16 0 1
0 40 6 0
1
end_operator
begin_operator
unstack b9 b17
0
4
0 21 0 6
0 11 -1 0
0 16 0 1
0 40 7 0
1
end_operator
begin_operator
unstack b9 b18
0
4
0 21 0 6
0 7 -1 0
0 16 0 1
0 40 8 0
1
end_operator
begin_operator
unstack b9 b19
0
4
0 21 0 6
0 15 -1 0
0 16 0 1
0 40 9 0
1
end_operator
begin_operator
unstack b9 b2
0
4
0 21 0 6
0 48 -1 0
0 16 0 1
0 40 10 0
1
end_operator
begin_operator
unstack b9 b20
0
4
0 21 0 6
0 20 -1 0
0 16 0 1
0 40 11 0
1
end_operator
begin_operator
unstack b9 b22
0
4
0 21 0 6
0 8 -1 0
0 16 0 1
0 40 12 0
1
end_operator
begin_operator
unstack b9 b23
0
4
0 21 0 6
0 9 -1 0
0 16 0 1
0 40 13 0
1
end_operator
begin_operator
unstack b9 b24
0
4
0 21 0 6
0 17 -1 0
0 16 0 1
0 40 14 0
1
end_operator
begin_operator
unstack b9 b25
0
4
0 21 0 6
0 12 -1 0
0 16 0 1
0 40 15 0
1
end_operator
begin_operator
unstack b9 b3
0
4
0 21 0 6
0 6 -1 0
0 16 0 1
0 40 16 0
1
end_operator
begin_operator
unstack b9 b4
0
4
0 21 0 6
0 49 -1 0
0 16 0 1
0 40 17 0
1
end_operator
begin_operator
unstack b9 b6
0
4
0 21 0 6
0 50 -1 0
0 16 0 1
0 40 18 0
1
end_operator
begin_operator
unstack b9 b7
0
4
0 21 0 6
0 19 -1 0
0 16 0 1
0 40 19 0
1
end_operator
begin_operator
unstack b9 b8
0
4
0 21 0 6
0 2 -1 0
0 16 0 1
0 40 20 0
1
end_operator
0
