begin_version
3
end_version
begin_metric
0
end_metric
48
begin_variable
var0
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var2
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var1
-1
2
Atom clear(b1)
<none of those>
end_variable
begin_variable
var3
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var4
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var5
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var7
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var8
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var10
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var9
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var11
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var12
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var13
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var14
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var15
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var16
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var17
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var18
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var19
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var20
-1
24
Atom arm-empty()
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
<none of those>
end_variable
begin_variable
var21
-1
3
Atom on(b11, b20)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var22
-1
3
Atom on(b17, b4)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var23
-1
3
Atom on(b23, b5)
Atom on-table(b23)
<none of those>
end_variable
begin_variable
var24
-1
4
Atom on(b14, b11)
Atom on(b14, b18)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom on(b24, b1)
Atom on(b24, b17)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom on(b4, b22)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var27
-1
3
Atom on(b5, b2)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b18, b10)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var29
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var30
-1
9
Atom on(b10, b13)
Atom on(b10, b16)
Atom on(b10, b2)
Atom on(b10, b21)
Atom on(b10, b22)
Atom on(b10, b24)
Atom on(b10, b8)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var41
-1
11
Atom on(b8, b10)
Atom on(b8, b16)
Atom on(b8, b2)
Atom on(b8, b20)
Atom on(b8, b21)
Atom on(b8, b22)
Atom on(b8, b24)
Atom on(b8, b6)
Atom on(b8, b7)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var31
-1
15
Atom on(b22, b10)
Atom on(b22, b13)
Atom on(b22, b15)
Atom on(b22, b16)
Atom on(b22, b19)
Atom on(b22, b2)
Atom on(b22, b24)
Atom on(b22, b3)
Atom on(b22, b4)
Atom on(b22, b5)
Atom on(b22, b7)
Atom on(b22, b8)
Atom on(b22, b9)
Atom on-table(b22)
<none of those>
end_variable
begin_variable
var32
-1
16
Atom on(b13, b10)
Atom on(b13, b12)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b21)
Atom on(b13, b24)
Atom on(b13, b3)
Atom on(b13, b4)
Atom on(b13, b5)
Atom on(b13, b6)
Atom on(b13, b7)
Atom on(b13, b9)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var40
-1
16
Atom on(b6, b10)
Atom on(b6, b12)
Atom on(b6, b13)
Atom on(b6, b16)
Atom on(b6, b19)
Atom on(b6, b2)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b22)
Atom on(b6, b24)
Atom on(b6, b3)
Atom on(b6, b7)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var36
-1
17
Atom on(b19, b10)
Atom on(b19, b13)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b2)
Atom on(b19, b20)
Atom on(b19, b21)
Atom on(b19, b22)
Atom on(b19, b24)
Atom on(b19, b3)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var37
-1
17
Atom on(b2, b10)
Atom on(b2, b12)
Atom on(b2, b13)
Atom on(b2, b14)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b22)
Atom on(b2, b24)
Atom on(b2, b3)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var42
-1
17
Atom on(b7, b10)
Atom on(b7, b12)
Atom on(b7, b13)
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b19)
Atom on(b7, b2)
Atom on(b7, b20)
Atom on(b7, b21)
Atom on(b7, b22)
Atom on(b7, b23)
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




b7
0
4
0 20 0 17
0 12 0 1
0 46 -1 0
0 39 13 17
1
end_operator
begin_operator
unstack b3 b8
0
4
0 20 0 17
0 12 0 1
0 8 -1 0
0 39 14 17
1
end_operator
begin_operator
unstack b3 b9
0
4
0 20 0 17
0 12 0 1
0 19 -1 0
0 39 15 17
1
end_operator
begin_operator
unstack b4 b22
0
4
0 20 0 18
0 14 -1 0
0 5 0 1
0 26 0 2
1
end_operator
begin_operator
unstack b5 b2
0
4
0 20 0 19
0 18 -1 0
0 6 0 1
0 27 0 2
1
end_operator
begin_operator
unstack b6 b10
0
4
0 20 0 20
0 9 -1 0
0 10 0 1
0 34 0 15
1
end_operator
begin_operator
unstack b6 b12
0
4
0 20 0 20
0 15 -1 0
0 10 0 1
0 34 1 15
1
end_operator
begin_operator
unstack b6 b13
0
4
0 20 0 20
0 11 -1 0
0 10 0 1
0 34 2 15
1
end_operator
begin_operator
unstack b6 b16
0
4
0 20 0 20
0 47 -1 0
0 10 0 1
0 34 3 15
1
end_operator
begin_operator
unstack b6 b19
0
4
0 20 0 20
0 13 -1 0
0 10 0 1
0 34 4 15
1
end_operator
begin_operator
unstack b6 b2
0
4
0 20 0 20
0 18 -1 0
0 10 0 1
0 34 5 15
1
end_operator
begin_operator
unstack b6 b20
0
4
0 20 0 20
0 16 -1 0
0 10 0 1
0 34 6 15
1
end_operator
begin_operator
unstack b6 b21
0
4
0 20 0 20
0 45 -1 0
0 10 0 1
0 34 7 15
1
end_operator
begin_operator
unstack b6 b22
0
4
0 20 0 20
0 14 -1 0
0 10 0 1
0 34 8 15
1
end_operator
begin_operator
unstack b6 b24
0
4
0 20 0 20
0 7 -1 0
0 10 0 1
0 34 9 15
1
end_operator
begin_operator
unstack b6 b3
0
4
0 20 0 20
0 12 -1 0
0 10 0 1
0 34 10 15
1
end_operator
begin_operator
unstack b6 b7
0
4
0 20 0 20
0 10 0 1
0 46 -1 0
0 34 11 15
1
end_operator
begin_operator
unstack b6 b8
0
4
0 20 0 20
0 10 0 1
0 8 -1 0
0 34 12 15
1
end_operator
begin_operator
unstack b6 b9
0
4
0 20 0 20
0 10 0 1
0 19 -1 0
0 34 13 15
1
end_operator
begin_operator
unstack b7 b10
0
4
0 20 0 21
0 9 -1 0
0 46 0 1
0 37 0 16
1
end_operator
begin_operator
unstack b7 b12
0
4
0 20 0 21
0 15 -1 0
0 46 0 1
0 37 1 16
1
end_operator
begin_operator
unstack b7 b13
0
4
0 20 0 21
0 11 -1 0
0 46 0 1
0 37 2 16
1
end_operator
begin_operator
unstack b7 b15
0
4
0 20 0 21
0 17 -1 0
0 46 0 1
0 37 3 16
1
end_operator
begin_operator
unstack b7 b16
0
4
0 20 0 21
0 47 -1 0
0 46 0 1
0 37 4 16
1
end_operator
begin_operator
unstack b7 b19
0
4
0 20 0 21
0 13 -1 0
0 46 0 1
0 37 5 16
1
end_operator
begin_operator
unstack b7 b2
0
4
0 20 0 21
0 18 -1 0
0 46 0 1
0 37 6 16
1
end_operator
begin_operator
unstack b7 b20
0
4
0 20 0 21
0 16 -1 0
0 46 0 1
0 37 7 16
1
end_operator
begin_operator
unstack b7 b21
0
4
0 20 0 21
0 45 -1 0
0 46 0 1
0 37 8 16
1
end_operator
begin_operator
unstack b7 b22
0
4
0 20 0 21
0 14 -1 0
0 46 0 1
0 37 9 16
1
end_operator
begin_operator
unstack b7 b23
0
4
0 20 0 21
0 4 -1 0
0 46 0 1
0 37 10 16
1
end_operator
begin_operator
unstack b7 b24
0
4
0 20 0 21
0 7 -1 0
0 46 0 1
0 37 11 16
1
end_operator
begin_operator
unstack b7 b6
0
4
0 20 0 21
0 10 -1 0
0 46 0 1
0 37 12 16
1
end_operator
begin_operator
unstack b7 b8
0
4
0 20 0 21
0 46 0 1
0 8 -1 0
0 37 13 16
1
end_operator
begin_operator
unstack b8 b10
0
4
0 20 0 22
0 9 -1 0
0 8 0 1
0 31 0 10
1
end_operator
begin_operator
unstack b8 b16
0
4
0 20 0 22
0 47 -1 0
0 8 0 1
0 31 1 10
1
end_operator
begin_operator
unstack b8 b2
0
4
0 20 0 22
0 18 -1 0
0 8 0 1
0 31 2 10
1
end_operator
begin_operator
unstack b8 b20
0
4
0 20 0 22
0 16 -1 0
0 8 0 1
0 31 3 10
1
end_operator
begin_operator
unstack b8 b21
0
4
0 20 0 22
0 45 -1 0
0 8 0 1
0 31 4 10
1
end_operator
begin_operator
unstack b8 b22
0
4
0 20 0 22
0 14 -1 0
0 8 0 1
0 31 5 10
1
end_operator
begin_operator
unstack b8 b24
0
4
0 20 0 22
0 7 -1 0
0 8 0 1
0 31 6 10
1
end_operator
begin_operator
unstack b8 b7
0
4
0 20 0 22
0 46 -1 0
0 8 0 1
0 31 8 10
1
end_operator
begin_operator
unstack b9 b1
0
4
0 20 0 23
0 2 -1 0
0 19 0 1
0 44 1 0
1
end_operator
begin_operator
unstack b9 b10
0
4
0 20 0 23
0 9 -1 0
0 19 0 1
0 44 2 0
1
end_operator
begin_operator
unstack b9 b12
0
4
0 20 0 23
0 15 -1 0
0 19 0 1
0 44 3 0
1
end_operator
begin_operator
unstack b9 b13
0
4
0 20 0 23
0 11 -1 0
0 19 0 1
0 44 4 0
1
end_operator
begin_operator
unstack b9 b15
0
4
0 20 0 23
0 17 -1 0
0 19 0 1
0 44 5 0
1
end_operator
begin_operator
unstack b9 b16
0
4
0 20 0 23
0 47 -1 0
0 19 0 1
0 44 6 0
1
end_operator
begin_operator
unstack b9 b17
0
4
0 20 0 23
0 3 -1 0
0 19 0 1
0 44 7 0
1
end_operator
begin_operator
unstack b9 b19
0
4
0 20 0 23
0 13 -1 0
0 19 0 1
0 44 8 0
1
end_operator
begin_operator
unstack b9 b2
0
4
0 20 0 23
0 18 -1 0
0 19 0 1
0 44 9 0
1
end_operator
begin_operator
unstack b9 b20
0
4
0 20 0 23
0 16 -1 0
0 19 0 1
0 44 10 0
1
end_operator
begin_operator
unstack b9 b21
0
4
0 20 0 23
0 45 -1 0
0 19 0 1
0 44 11 0
1
end_operator
begin_operator
unstack b9 b22
0
4
0 20 0 23
0 14 -1 0
0 19 0 1
0 44 12 0
1
end_operator
begin_operator
unstack b9 b23
0
4
0 20 0 23
0 4 -1 0
0 19 0 1
0 44 13 0
1
end_operator
begin_operator
unstack b9 b4
0
4
0 20 0 23
0 5 -1 0
0 19 0 1
0 44 15 0
1
end_operator
begin_operator
unstack b9 b5
0
4
0 20 0 23
0 6 -1 0
0 19 0 1
0 44 16 0
1
end_operator
begin_operator
unstack b9 b6
0
4
0 20 0 23
0 10 -1 0
0 19 0 1
0 44 17 0
1
end_operator
begin_operator
unstack b9 b7
0
4
0 20 0 23
0 46 -1 0
0 19 0 1
0 44 18 0
1
end_operator
begin_operator
unstack b9 b8
0
4
0 20 0 23
0 8 -1 0
0 19 0 1
0 44 19 0
1
end_operator
0
