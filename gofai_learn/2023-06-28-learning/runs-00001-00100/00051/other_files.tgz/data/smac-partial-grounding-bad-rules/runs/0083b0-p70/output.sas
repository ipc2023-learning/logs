begin_version
3
end_version
begin_metric
0
end_metric
42
begin_variable
var0
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var2
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var1
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var5
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var3
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var4
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var6
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var9
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var8
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var7
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var10
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var11
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var12
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var13
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var14
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var15
-1
21
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b13)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
<none of those>
end_variable
begin_variable
var16
-1
3
Atom on(b13, b21)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var17
-1
3
Atom on(b15, b6)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var18
-1
3
Atom on(b17, b18)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var19
-1
3
Atom on(b16, b15)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var20
-1
3
Atom on(b19, b17)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom on(b11, b12)
Atom on(b11, b20)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom on(b21, b13)
Atom on(b21, b4)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var23
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var24
-1
3
Atom on(b7, b11)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var33
-1
4
Atom on(b3, b11)
Atom on(b3, b15)
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var25
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var26
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var29
-1
12
Atom on(b18, b1)
Atom on(b18, b10)
Atom on(b18, b11)
Atom on(b18, b12)
Atom on(b18, b20)
Atom on(b18, b21)
Atom on(b18, b3)
Atom on(b18, b4)
Atom on(b18, b5)
Atom on(b18, b8)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var30
-1
11
Atom on(b4, b1)
Atom on(b4, b10)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b18)
Atom on(b4, b2)
Atom on(b4, b20)
Atom on(b4, b21)
Atom on(b4, b9)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var27
-1
13
Atom on(b9, b10)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b18)
Atom on(b9, b2)
Atom on(b9, b20)
Atom on(b9, b21)
Atom on(b9, b4)
Atom on(b9, b5)
Atom on(b9, b6)
Atom on(b9, b8)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var28
-1
13
Atom on(b1, b10)
Atom on(b1, b11)
Atom on(b1, b18)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b3)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b6)
Atom on(b1, b9)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var35
-1
14
Atom on(b6, b1)
Atom on(b6, b10)
Atom on(b6, b11)
Atom on(b6, b12)
Atom on(b6, b18)
Atom on(b6, b2)
Atom on(b6, b20)
Atom on(b6, b21)
Atom on(b6, b4)
Atom on(b6, b5)
Atom on(b6, b8)
Atom on(b6, b9)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var31
-1
14
Atom on(b5, b1)
Atom on(b5, b10)
Atom on(b5, b11)
Atom on(b5, b12)
Atom on(b5, b18)
Atom on(b5, b19)
Atom on(b5, b2)
Atom on(b5, b20)
Atom on(b5, b21)
Atom on(b5, b4)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var37
-1
16
Atom holding(b12)
Atom on(b12, b1)
Atom on(b12, b10)
Atom on(b12, b11)
Atom on(b12, b14)
Atom on(b12, b18)
Atom on(b12, b2)
Atom on(b12, b20)
Atom on(b12, b21)
Atom on(b12, b3)
Atom on(b12, b4)
Atom on(b12, b5)
Atom on(b12, b6)
Atom on(b12, b8)
Atom on(b12, b9)
Atom on-table(b12)
end_variable
begin_variable
var32
-1
15
Atom on(b10, b1)
Atom on(b10, b12)
Atom on(b10, b15)
Atom on(b10, b16)
Atom on(b10, b17)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b21)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b8)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var34
-1
16
Atom on(b2, b10)
Atom on(b2, b11)
Atom on(b2, b12)
Atom on(b2, b15)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b19)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b3)
Atom on(b2, b6)
Atom on(b2, b8)
Atom on




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




or
begin_operator
unstack b4 b1
0
4
0 15 0 14
0 8 -1 0
0 7 0 1
0 29 0 10
1
end_operator
begin_operator
unstack b4 b10
0
4
0 15 0 14
0 39 -1 0
0 7 0 1
0 29 1 10
1
end_operator
begin_operator
unstack b4 b11
0
4
0 15 0 14
0 5 -1 0
0 7 0 1
0 29 2 10
1
end_operator
begin_operator
unstack b4 b12
0
4
0 15 0 14
0 14 -1 0
0 7 0 1
0 29 3 10
1
end_operator
begin_operator
unstack b4 b18
0
4
0 15 0 14
0 10 -1 0
0 7 0 1
0 29 4 10
1
end_operator
begin_operator
unstack b4 b2
0
4
0 15 0 14
0 13 -1 0
0 7 0 1
0 29 5 10
1
end_operator
begin_operator
unstack b4 b20
0
4
0 15 0 14
0 40 -1 0
0 7 0 1
0 29 6 10
1
end_operator
begin_operator
unstack b4 b21
0
4
0 15 0 14
0 4 -1 0
0 7 0 1
0 29 7 10
1
end_operator
begin_operator
unstack b4 b9
0
4
0 15 0 14
0 7 0 1
0 6 -1 0
0 29 8 10
1
end_operator
begin_operator
unstack b5 b1
0
4
0 15 0 15
0 8 -1 0
0 9 0 1
0 33 0 13
1
end_operator
begin_operator
unstack b5 b10
0
4
0 15 0 15
0 39 -1 0
0 9 0 1
0 33 1 13
1
end_operator
begin_operator
unstack b5 b11
0
4
0 15 0 15
0 5 -1 0
0 9 0 1
0 33 2 13
1
end_operator
begin_operator
unstack b5 b12
0
4
0 15 0 15
0 14 -1 0
0 9 0 1
0 33 3 13
1
end_operator
begin_operator
unstack b5 b18
0
4
0 15 0 15
0 10 -1 0
0 9 0 1
0 33 4 13
1
end_operator
begin_operator
unstack b5 b19
0
4
0 15 0 15
0 26 -1 0
0 9 0 1
0 33 5 13
1
end_operator
begin_operator
unstack b5 b2
0
4
0 15 0 15
0 13 -1 0
0 9 0 1
0 33 6 13
1
end_operator
begin_operator
unstack b5 b20
0
4
0 15 0 15
0 40 -1 0
0 9 0 1
0 33 7 13
1
end_operator
begin_operator
unstack b5 b21
0
4
0 15 0 15
0 4 -1 0
0 9 0 1
0 33 8 13
1
end_operator
begin_operator
unstack b5 b4
0
4
0 15 0 15
0 7 -1 0
0 9 0 1
0 33 9 13
1
end_operator
begin_operator
unstack b5 b8
0
4
0 15 0 15
0 9 0 1
0 12 -1 0
0 33 10 13
1
end_operator
begin_operator
unstack b5 b9
0
4
0 15 0 15
0 9 0 1
0 6 -1 0
0 33 11 13
1
end_operator
begin_operator
unstack b6 b1
0
4
0 15 0 16
0 8 -1 0
0 11 0 1
0 32 0 13
1
end_operator
begin_operator
unstack b6 b10
0
4
0 15 0 16
0 39 -1 0
0 11 0 1
0 32 1 13
1
end_operator
begin_operator
unstack b6 b11
0
4
0 15 0 16
0 5 -1 0
0 11 0 1
0 32 2 13
1
end_operator
begin_operator
unstack b6 b12
0
4
0 15 0 16
0 14 -1 0
0 11 0 1
0 32 3 13
1
end_operator
begin_operator
unstack b6 b18
0
4
0 15 0 16
0 10 -1 0
0 11 0 1
0 32 4 13
1
end_operator
begin_operator
unstack b6 b2
0
4
0 15 0 16
0 13 -1 0
0 11 0 1
0 32 5 13
1
end_operator
begin_operator
unstack b6 b20
0
4
0 15 0 16
0 40 -1 0
0 11 0 1
0 32 6 13
1
end_operator
begin_operator
unstack b6 b21
0
4
0 15 0 16
0 4 -1 0
0 11 0 1
0 32 7 13
1
end_operator
begin_operator
unstack b6 b4
0
4
0 15 0 16
0 7 -1 0
0 11 0 1
0 32 8 13
1
end_operator
begin_operator
unstack b6 b5
0
4
0 15 0 16
0 9 -1 0
0 11 0 1
0 32 9 13
1
end_operator
begin_operator
unstack b6 b8
0
4
0 15 0 16
0 11 0 1
0 12 -1 0
0 32 10 13
1
end_operator
begin_operator
unstack b6 b9
0
4
0 15 0 16
0 11 0 1
0 6 -1 0
0 32 11 13
1
end_operator
begin_operator
unstack b7 b11
0
4
0 15 0 17
0 5 -1 0
0 23 0 1
0 24 0 2
1
end_operator
begin_operator
unstack b8 b1
0
4
0 15 0 18
0 8 -1 0
0 12 0 1
0 37 0 15
1
end_operator
begin_operator
unstack b8 b10
0
4
0 15 0 18
0 39 -1 0
0 12 0 1
0 37 1 15
1
end_operator
begin_operator
unstack b8 b11
0
4
0 15 0 18
0 5 -1 0
0 12 0 1
0 37 2 15
1
end_operator
begin_operator
unstack b8 b12
0
4
0 15 0 18
0 14 -1 0
0 12 0 1
0 37 3 15
1
end_operator
begin_operator
unstack b8 b16
0
4
0 15 0 18
0 27 -1 0
0 12 0 1
0 37 4 15
1
end_operator
begin_operator
unstack b8 b18
0
4
0 15 0 18
0 10 -1 0
0 12 0 1
0 37 5 15
1
end_operator
begin_operator
unstack b8 b2
0
4
0 15 0 18
0 13 -1 0
0 12 0 1
0 37 6 15
1
end_operator
begin_operator
unstack b8 b20
0
4
0 15 0 18
0 40 -1 0
0 12 0 1
0 37 7 15
1
end_operator
begin_operator
unstack b8 b21
0
4
0 15 0 18
0 4 -1 0
0 12 0 1
0 37 8 15
1
end_operator
begin_operator
unstack b8 b3
0
4
0 15 0 18
0 3 -1 0
0 12 0 1
0 37 9 15
1
end_operator
begin_operator
unstack b8 b4
0
4
0 15 0 18
0 7 -1 0
0 12 0 1
0 37 10 15
1
end_operator
begin_operator
unstack b8 b5
0
4
0 15 0 18
0 9 -1 0
0 12 0 1
0 37 11 15
1
end_operator
begin_operator
unstack b8 b6
0
4
0 15 0 18
0 11 -1 0
0 12 0 1
0 37 12 15
1
end_operator
begin_operator
unstack b8 b9
0
4
0 15 0 18
0 12 0 1
0 6 -1 0
0 37 13 15
1
end_operator
begin_operator
unstack b9 b10
0
4
0 15 0 19
0 39 -1 0
0 6 0 1
0 30 0 12
1
end_operator
begin_operator
unstack b9 b11
0
4
0 15 0 19
0 5 -1 0
0 6 0 1
0 30 1 12
1
end_operator
begin_operator
unstack b9 b12
0
4
0 15 0 19
0 14 -1 0
0 6 0 1
0 30 2 12
1
end_operator
begin_operator
unstack b9 b18
0
4
0 15 0 19
0 10 -1 0
0 6 0 1
0 30 3 12
1
end_operator
begin_operator
unstack b9 b2
0
4
0 15 0 19
0 13 -1 0
0 6 0 1
0 30 4 12
1
end_operator
begin_operator
unstack b9 b20
0
4
0 15 0 19
0 40 -1 0
0 6 0 1
0 30 5 12
1
end_operator
begin_operator
unstack b9 b21
0
4
0 15 0 19
0 4 -1 0
0 6 0 1
0 30 6 12
1
end_operator
begin_operator
unstack b9 b4
0
4
0 15 0 19
0 7 -1 0
0 6 0 1
0 30 7 12
1
end_operator
begin_operator
unstack b9 b5
0
4
0 15 0 19
0 9 -1 0
0 6 0 1
0 30 8 12
1
end_operator
begin_operator
unstack b9 b6
0
4
0 15 0 19
0 11 -1 0
0 6 0 1
0 30 9 12
1
end_operator
begin_operator
unstack b9 b8
0
4
0 15 0 19
0 12 -1 0
0 6 0 1
0 30 10 12
1
end_operator
0
