begin_version
3
end_version
begin_metric
0
end_metric
41
begin_variable
var0
-1
2
Atom on-table(b18)
NegatedAtom on-table(b18)
end_variable
begin_variable
var1
-1
2
Atom on-table(b9)
NegatedAtom on-table(b9)
end_variable
begin_variable
var14
-1
2
Atom on-table(b11)
NegatedAtom on-table(b11)
end_variable
begin_variable
var3
-1
2
Atom on-table(b6)
NegatedAtom on-table(b6)
end_variable
begin_variable
var8
-1
2
Atom on-table(b2)
NegatedAtom on-table(b2)
end_variable
begin_variable
var10
-1
2
Atom on-table(b16)
NegatedAtom on-table(b16)
end_variable
begin_variable
var2
-1
2
Atom on-table(b7)
NegatedAtom on-table(b7)
end_variable
begin_variable
var15
-1
2
Atom on-table(b10)
NegatedAtom on-table(b10)
end_variable
begin_variable
var13
-1
2
Atom on-table(b13)
NegatedAtom on-table(b13)
end_variable
begin_variable
var6
-1
2
Atom on-table(b3)
NegatedAtom on-table(b3)
end_variable
begin_variable
var4
-1
2
Atom on-table(b5)
NegatedAtom on-table(b5)
end_variable
begin_variable
var12
-1
2
Atom on-table(b14)
NegatedAtom on-table(b14)
end_variable
begin_variable
var7
-1
2
Atom on-table(b20)
NegatedAtom on-table(b20)
end_variable
begin_variable
var5
-1
2
Atom on-table(b4)
NegatedAtom on-table(b4)
end_variable
begin_variable
var9
-1
2
Atom on-table(b17)
NegatedAtom on-table(b17)
end_variable
begin_variable
var11
-1
2
Atom on-table(b15)
NegatedAtom on-table(b15)
end_variable
begin_variable
var16
-1
2
Atom on-table(b1)
NegatedAtom on-table(b1)
end_variable
begin_variable
var17
-1
19
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b9)
<none of those>
end_variable
begin_variable
var19
-1
5
Atom clear(b19)
Atom on(b16, b19)
Atom on(b3, b19)
Atom on(b4, b19)
<none of those>
end_variable
begin_variable
var20
-1
7
Atom clear(b12)
Atom on(b16, b12)
Atom on(b3, b12)
Atom on(b4, b12)
Atom on(b7, b12)
Atom on(b9, b12)
<none of those>
end_variable
begin_variable
var18
-1
10
Atom clear(b18)
Atom on(b1, b18)
Atom on(b11, b18)
Atom on(b13, b18)
Atom on(b14, b18)
Atom on(b15, b18)
Atom on(b17, b18)
Atom on(b6, b18)
Atom on(b9, b18)
<none of those>
end_variable
begin_variable
var27
-1
18
Atom clear(b8)
Atom holding(b8)
Atom on(b1, b8)
Atom on(b10, b8)
Atom on(b11, b8)
Atom on(b13, b8)
Atom on(b14, b8)
Atom on(b15, b8)
Atom on(b16, b8)
Atom on(b17, b8)
Atom on(b2, b8)
Atom on(b20, b8)
Atom on(b3, b8)
Atom on(b4, b8)
Atom on(b5, b8)
Atom on(b6, b8)
Atom on(b7, b8)
Atom on(b9, b8)
end_variable
begin_variable
var33
-1
12
Atom clear(b20)
Atom on(b10, b20)
Atom on(b11, b20)
Atom on(b14, b20)
Atom on(b17, b20)
Atom on(b2, b20)
Atom on(b4, b20)
Atom on(b5, b20)
Atom on(b6, b20)
Atom on(b7, b20)
Atom on(b9, b20)
<none of those>
end_variable
begin_variable
var21
-1
15
Atom clear(b11)
Atom on(b1, b11)
Atom on(b10, b11)
Atom on(b13, b11)
Atom on(b14, b11)
Atom on(b15, b11)
Atom on(b16, b11)
Atom on(b17, b11)
Atom on(b2, b11)
Atom on(b20, b11)
Atom on(b3, b11)
Atom on(b5, b11)
Atom on(b6, b11)
Atom on(b9, b11)
<none of those>
end_variable
begin_variable
var24
-1
12
Atom clear(b10)
Atom on(b1, b10)
Atom on(b11, b10)
Atom on(b13, b10)
Atom on(b14, b10)
Atom on(b15, b10)
Atom on(b16, b10)
Atom on(b2, b10)
Atom on(b3, b10)
Atom on(b5, b10)
Atom on(b7, b10)
<none of those>
end_variable
begin_variable
var28
-1
14
Atom clear(b13)
Atom on(b1, b13)
Atom on(b14, b13)
Atom on(b15, b13)
Atom on(b16, b13)
Atom on(b18, b13)
Atom on(b20, b13)
Atom on(b3, b13)
Atom on(b4, b13)
Atom on(b5, b13)
Atom on(b6, b13)
Atom on(b7, b13)
Atom on(b9, b13)
<none of those>
end_variable
begin_variable
var31
-1
11
Atom clear(b5)
Atom on(b11, b5)
Atom on(b15, b5)
Atom on(b16, b5)
Atom on(b17, b5)
Atom on(b20, b5)
Atom on(b4, b5)
Atom on(b6, b5)
Atom on(b7, b5)
Atom on(b9, b5)
<none of those>
end_variable
begin_variable
var34
-1
13
Atom clear(b4)
Atom on(b1, b4)
Atom on(b10, b4)
Atom on(b12, b4)
Atom on(b13, b4)
Atom on(b14, b4)
Atom on(b15, b4)
Atom on(b16, b4)
Atom on(b17, b4)
Atom on(b2, b4)
Atom on(b20, b4)
Atom on(b5, b4)
<none of those>
end_variable
begin_variable
var35
-1
13
Atom clear(b17)
Atom on(b10, b17)
Atom on(b11, b17)
Atom on(b14, b17)
Atom on(b15, b17)
Atom on(b2, b17)
Atom on(b20, b17)
Atom on(b3, b17)
Atom on(b4, b17)
Atom on(b6, b17)
Atom on(b7, b17)
Atom on(b9, b17)
<none of those>
end_variable
begin_variable
var36
-1
12
Atom clear(b15)
Atom on(b1, b15)
Atom on(b10, b15)
Atom on(b13, b15)
Atom on(b16, b15)
Atom on(b17, b15)
Atom on(b20, b15)
Atom on(b3, b15)
Atom on(b5, b15)
Atom on(b6, b15)
Atom on(b7, b15)
<none of those>
end_variable
begin_variable
var22
-1
13
Atom clear(b6)
Atom on(b1, b6)
Atom on(b10, b6)
Atom on(b11, b6)
Atom on(b13, b6)
Atom on(b16, b6)
Atom on(b17, b6)
Atom on(b2, b6)
Atom on(b20, b6)
Atom on(b3, b6)
Atom on(b4, b6)
Atom on(b5, b6)
<none of those>
end_variable
begin_variable
var23
-1
15
Atom clear(b2)
Atom on(b1, b2)
Atom on(b10, b2)
Atom on(b13, b2)
Atom on(b15, b2)
Atom on(b16, b2)
Atom on(b17, b2)
Atom




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




 b4 b12
0
3
0 17 0 14
0 19 3 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b13
0
3
0 17 0 14
0 25 8 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b14
0
3
0 17 0 14
0 34 12 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b16
0
3
0 17 0 14
0 33 6 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b17
0
3
0 17 0 14
0 28 8 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b19
0
3
0 17 0 14
0 18 3 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b2
0
3
0 17 0 14
0 31 10 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b20
0
3
0 17 0 14
0 22 6 0
0 27 0 12
1
end_operator
begin_operator
unstack b4 b5
0
3
0 17 0 14
0 27 0 12
0 26 6 0
1
end_operator
begin_operator
unstack b4 b6
0
3
0 17 0 14
0 27 0 12
0 30 10 0
1
end_operator
begin_operator
unstack b4 b7
0
3
0 17 0 14
0 27 0 12
0 32 13 0
1
end_operator
begin_operator
unstack b4 b8
0
3
0 17 0 14
0 27 0 12
0 21 13 0
1
end_operator
begin_operator
unstack b4 b9
0
3
0 17 0 14
0 27 0 12
0 37 8 0
1
end_operator
begin_operator
unstack b5 b1
0
3
0 17 0 15
0 36 8 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b10
0
3
0 17 0 15
0 24 9 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b11
0
3
0 17 0 15
0 23 11 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b13
0
3
0 17 0 15
0 25 9 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b14
0
3
0 17 0 15
0 34 13 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b15
0
3
0 17 0 15
0 29 8 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b16
0
3
0 17 0 15
0 33 7 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b2
0
3
0 17 0 15
0 31 11 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b20
0
3
0 17 0 15
0 22 7 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b3
0
3
0 17 0 15
0 35 8 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b4
0
3
0 17 0 15
0 27 11 0
0 26 0 10
1
end_operator
begin_operator
unstack b5 b6
0
3
0 17 0 15
0 26 0 10
0 30 11 0
1
end_operator
begin_operator
unstack b5 b7
0
3
0 17 0 15
0 26 0 10
0 32 14 0
1
end_operator
begin_operator
unstack b5 b8
0
3
0 17 0 15
0 26 0 10
0 21 14 0
1
end_operator
begin_operator
unstack b6 b11
0
3
0 17 0 16
0 23 12 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b13
0
3
0 17 0 16
0 25 10 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b14
0
3
0 17 0 16
0 34 14 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b15
0
3
0 17 0 16
0 29 9 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b17
0
3
0 17 0 16
0 28 9 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b18
0
3
0 17 0 16
0 20 7 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b2
0
3
0 17 0 16
0 31 12 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b20
0
3
0 17 0 16
0 22 8 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b3
0
3
0 17 0 16
0 35 9 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b5
0
3
0 17 0 16
0 26 7 0
0 30 0 12
1
end_operator
begin_operator
unstack b6 b7
0
3
0 17 0 16
0 30 0 12
0 32 15 0
1
end_operator
begin_operator
unstack b6 b8
0
3
0 17 0 16
0 30 0 12
0 21 15 0
1
end_operator
begin_operator
unstack b6 b9
0
3
0 17 0 16
0 30 0 12
0 37 9 0
1
end_operator
begin_operator
unstack b7 b1
0
3
0 17 0 18
0 36 9 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b10
0
3
0 17 0 18
0 24 10 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b12
0
3
0 17 0 18
0 19 4 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b13
0
3
0 17 0 18
0 25 11 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b14
0
3
0 17 0 18
0 34 15 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b15
0
3
0 17 0 18
0 29 10 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b16
0
3
0 17 0 18
0 33 8 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b17
0
3
0 17 0 18
0 28 10 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b2
0
3
0 17 0 18
0 31 13 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b20
0
3
0 17 0 18
0 22 9 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b3
0
3
0 17 0 18
0 35 10 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b5
0
3
0 17 0 18
0 26 8 0
0 32 0 1
1
end_operator
begin_operator
unstack b7 b8
0
3
0 17 0 18
0 32 0 1
0 21 16 0
1
end_operator
begin_operator
unstack b8 b7
0
3
0 17 0 18
0 32 16 0
0 21 0 1
1
end_operator
begin_operator
unstack b9 b11
0
3
0 17 0 17
0 23 13 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b12
0
3
0 17 0 17
0 19 5 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b13
0
3
0 17 0 17
0 25 12 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b14
0
3
0 17 0 17
0 34 16 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b16
0
3
0 17 0 17
0 33 9 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b17
0
3
0 17 0 17
0 28 11 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b18
0
3
0 17 0 17
0 20 8 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b20
0
3
0 17 0 17
0 22 10 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b3
0
3
0 17 0 17
0 35 11 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b5
0
3
0 17 0 17
0 26 9 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b7
0
3
0 17 0 17
0 32 17 0
0 37 0 10
1
end_operator
begin_operator
unstack b9 b8
0
3
0 17 0 17
0 21 17 0
0 37 0 10
1
end_operator
0
