begin_version
3
end_version
begin_metric
0
end_metric
43
begin_variable
var0
-1
2
Atom on-table(b3)
NegatedAtom on-table(b3)
end_variable
begin_variable
var1
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var2
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var3
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var4
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var5
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var6
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var7
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var8
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var9
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var10
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var11
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var12
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var14
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var13
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var15
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var16
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var17
-1
22
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var18
-1
3
Atom on(b12, b14)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var19
-1
3
Atom on(b19, b5)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var20
-1
3
Atom on(b13, b21)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var21
-1
4
Atom on(b21, b13)
Atom on(b21, b16)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var22
-1
4
Atom on(b7, b17)
Atom on(b7, b21)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var23
-1
4
Atom on(b8, b10)
Atom on(b8, b6)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var25
-1
4
Atom on(b11, b1)
Atom on(b11, b4)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b6, b1)
Atom on-table(b6)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom clear(b3)
Atom on(b20, b3)
<none of those>
end_variable
begin_variable
var27
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var33
-1
13
Atom on(b16, b1)
Atom on(b16, b13)
Atom on(b16, b14)
Atom on(b16, b17)
Atom on(b16, b18)
Atom on(b16, b2)
Atom on(b16, b21)
Atom on(b16, b4)
Atom on(b16, b7)
Atom on(b16, b8)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var31
-1
14
Atom on(b14, b1)
Atom on(b14, b10)
Atom on(b14, b11)
Atom on(b14, b13)
Atom on(b14, b16)
Atom on(b14, b17)
Atom on(b14, b18)
Atom on(b14, b2)
Atom on(b14, b21)
Atom on(b14, b5)
Atom on(b14, b7)
Atom on(b14, b8)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var29
-1
14
Atom on(b5, b1)
Atom on(b5, b13)
Atom on(b5, b14)
Atom on(b5, b16)
Atom on(b5, b17)
Atom on(b5, b18)
Atom on(b5, b2)
Atom on(b5, b21)
Atom on(b5, b4)
Atom on(b5, b7)
Atom on(b5, b8)
Atom on(b5, b9)
Atom on-table(b5)
<none of those>
end_variable
begin_variable
var37
-1
14
Atom on(b2, b1)
Atom on(b2, b11)
Atom on(b2, b13)
Atom on(b2, b16)
Atom on(b2, b17)
Atom on(b2, b18)
Atom on(b2, b20)
Atom on(b2, b21)
Atom on(b2, b5)
Atom on(b2, b7)
Atom on(b2, b8)
Atom on(b2, b9)
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var28
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var32
-1
15
Atom on(b10, b1)
Atom on(b10, b11)
Atom on(b10, b13)
Atom on(b10, b14)
Atom on(b10, b16)
Atom on(b10, b18)
Atom on(b10, b2)
Atom on(b10, b21)
Atom on(b10, b4)
Atom on(b10, b5)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var34
-1
16
Atom on(b9, b1)
Atom on(b9, b11)
Atom on(b9, b12)
Atom on(b9, b13)
Atom on(b9, b14)
Atom on(b9, b15)
Atom on(b9, b16)
Atom on(b9, b17)
Atom on(b9, b18)
Atom on(b9, b19)
Atom on(b9, b20)
Atom on(b9, b4)
Atom on(b9, b7)
Atom on(b9, b8)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var30
-1
17
Atom on(b1, b11)
Atom on(b1, b12)
Atom on(b1, b13)
Atom on(b1, b14)
Atom on(b1, b15)
Atom on(b1, b16)
Atom on(b1, b19)
Atom on(b1, b2)
Atom on(b1, b20)
Atom on(b1, b21)
Atom on(b1, b4)
Atom on(b1, b5)
Atom on(b1, b7)
Atom on(b1, b8)
Atom on(b1, b9)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var35
-1
17
Atom on(b4, b1)
Atom on(b4, b11)
Atom on(b4, b12)
Atom on(b4, b13)
Atom on(b4, b15)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b18)
Atom on(b4, b19)
Atom on(b4, b2)
Atom on(b4, b20)
Atom on(b4, b21)
Atom on(b4, b5)
Atom on(b4, b7)
A




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ator
unstack b19 b5
0
4
0 17 0 11
0 2 0 1
0 11 -1 0
0 19 0 2
1
end_operator
begin_operator
unstack b2 b1
0
4
0 17 0 12
0 16 -1 0
0 12 0 1
0 31 0 13
1
end_operator
begin_operator
unstack b2 b11
0
4
0 17 0 12
0 4 -1 0
0 12 0 1
0 31 1 13
1
end_operator
begin_operator
unstack b2 b13
0
4
0 17 0 12
0 5 -1 0
0 12 0 1
0 31 2 13
1
end_operator
begin_operator
unstack b2 b16
0
4
0 17 0 12
0 13 -1 0
0 12 0 1
0 31 3 13
1
end_operator
begin_operator
unstack b2 b17
0
4
0 17 0 12
0 15 -1 0
0 12 0 1
0 31 4 13
1
end_operator
begin_operator
unstack b2 b18
0
4
0 17 0 12
0 40 -1 0
0 12 0 1
0 31 5 13
1
end_operator
begin_operator
unstack b2 b20
0
4
0 17 0 12
0 12 0 1
0 32 -1 0
0 31 6 13
1
end_operator
begin_operator
unstack b2 b21
0
4
0 17 0 12
0 12 0 1
0 8 -1 0
0 31 7 13
1
end_operator
begin_operator
unstack b2 b5
0
4
0 17 0 12
0 12 0 1
0 11 -1 0
0 31 8 13
1
end_operator
begin_operator
unstack b2 b7
0
4
0 17 0 12
0 12 0 1
0 6 -1 0
0 31 9 13
1
end_operator
begin_operator
unstack b2 b8
0
4
0 17 0 12
0 12 0 1
0 7 -1 0
0 31 10 13
1
end_operator
begin_operator
unstack b2 b9
0
4
0 17 0 12
0 12 0 1
0 39 -1 0
0 31 11 13
1
end_operator
begin_operator
unstack b20 b3
0
3
0 17 0 13
0 32 0 1
0 26 1 0
1
end_operator
begin_operator
unstack b21 b13
0
4
0 17 0 14
0 5 -1 0
0 8 0 1
0 21 0 3
1
end_operator
begin_operator
unstack b3 b18
0
3
0 17 0 15
0 40 2 0
0 26 0 2
1
end_operator
begin_operator
unstack b4 b1
0
4
0 17 0 16
0 16 -1 0
0 14 0 1
0 36 0 16
1
end_operator
begin_operator
unstack b4 b11
0
4
0 17 0 16
0 4 -1 0
0 14 0 1
0 36 1 16
1
end_operator
begin_operator
unstack b4 b12
0
4
0 17 0 16
0 1 -1 0
0 14 0 1
0 36 2 16
1
end_operator
begin_operator
unstack b4 b13
0
4
0 17 0 16
0 5 -1 0
0 14 0 1
0 36 3 16
1
end_operator
begin_operator
unstack b4 b15
0
4
0 17 0 16
0 3 -1 0
0 14 0 1
0 36 4 16
1
end_operator
begin_operator
unstack b4 b16
0
4
0 17 0 16
0 13 -1 0
0 14 0 1
0 36 5 16
1
end_operator
begin_operator
unstack b4 b17
0
4
0 17 0 16
0 15 -1 0
0 14 0 1
0 36 6 16
1
end_operator
begin_operator
unstack b4 b18
0
4
0 17 0 16
0 40 -1 0
0 14 0 1
0 36 7 16
1
end_operator
begin_operator
unstack b4 b19
0
4
0 17 0 16
0 2 -1 0
0 14 0 1
0 36 8 16
1
end_operator
begin_operator
unstack b4 b2
0
4
0 17 0 16
0 12 -1 0
0 14 0 1
0 36 9 16
1
end_operator
begin_operator
unstack b4 b20
0
4
0 17 0 16
0 32 -1 0
0 14 0 1
0 36 10 16
1
end_operator
begin_operator
unstack b4 b21
0
4
0 17 0 16
0 8 -1 0
0 14 0 1
0 36 11 16
1
end_operator
begin_operator
unstack b4 b5
0
4
0 17 0 16
0 14 0 1
0 11 -1 0
0 36 12 16
1
end_operator
begin_operator
unstack b4 b7
0
4
0 17 0 16
0 14 0 1
0 6 -1 0
0 36 13 16
1
end_operator
begin_operator
unstack b4 b8
0
4
0 17 0 16
0 14 0 1
0 7 -1 0
0 36 14 16
1
end_operator
begin_operator
unstack b5 b1
0
4
0 17 0 17
0 16 -1 0
0 11 0 1
0 30 0 13
1
end_operator
begin_operator
unstack b5 b13
0
4
0 17 0 17
0 5 -1 0
0 11 0 1
0 30 1 13
1
end_operator
begin_operator
unstack b5 b14
0
4
0 17 0 17
0 10 -1 0
0 11 0 1
0 30 2 13
1
end_operator
begin_operator
unstack b5 b16
0
4
0 17 0 17
0 13 -1 0
0 11 0 1
0 30 3 13
1
end_operator
begin_operator
unstack b5 b17
0
4
0 17 0 17
0 15 -1 0
0 11 0 1
0 30 4 13
1
end_operator
begin_operator
unstack b5 b18
0
4
0 17 0 17
0 40 -1 0
0 11 0 1
0 30 5 13
1
end_operator
begin_operator
unstack b5 b2
0
4
0 17 0 17
0 12 -1 0
0 11 0 1
0 30 6 13
1
end_operator
begin_operator
unstack b5 b21
0
4
0 17 0 17
0 8 -1 0
0 11 0 1
0 30 7 13
1
end_operator
begin_operator
unstack b5 b4
0
4
0 17 0 17
0 14 -1 0
0 11 0 1
0 30 8 13
1
end_operator
begin_operator
unstack b5 b7
0
4
0 17 0 17
0 11 0 1
0 6 -1 0
0 30 9 13
1
end_operator
begin_operator
unstack b5 b8
0
4
0 17 0 17
0 11 0 1
0 7 -1 0
0 30 10 13
1
end_operator
begin_operator
unstack b5 b9
0
4
0 17 0 17
0 11 0 1
0 39 -1 0
0 30 11 13
1
end_operator
begin_operator
unstack b6 b1
0
4
0 17 0 18
0 16 -1 0
0 27 0 1
0 25 0 2
1
end_operator
begin_operator
unstack b7 b21
0
4
0 17 0 19
0 8 -1 0
0 6 0 1
0 22 1 3
1
end_operator
begin_operator
unstack b8 b6
0
4
0 17 0 20
0 27 -1 0
0 7 0 1
0 23 1 3
1
end_operator
begin_operator
unstack b9 b1
0
4
0 17 0 21
0 16 -1 0
0 39 0 1
0 34 0 15
1
end_operator
begin_operator
unstack b9 b11
0
4
0 17 0 21
0 4 -1 0
0 39 0 1
0 34 1 15
1
end_operator
begin_operator
unstack b9 b12
0
4
0 17 0 21
0 1 -1 0
0 39 0 1
0 34 2 15
1
end_operator
begin_operator
unstack b9 b14
0
4
0 17 0 21
0 10 -1 0
0 39 0 1
0 34 4 15
1
end_operator
begin_operator
unstack b9 b15
0
4
0 17 0 21
0 3 -1 0
0 39 0 1
0 34 5 15
1
end_operator
begin_operator
unstack b9 b16
0
4
0 17 0 21
0 13 -1 0
0 39 0 1
0 34 6 15
1
end_operator
begin_operator
unstack b9 b17
0
4
0 17 0 21
0 15 -1 0
0 39 0 1
0 34 7 15
1
end_operator
begin_operator
unstack b9 b18
0
4
0 17 0 21
0 40 -1 0
0 39 0 1
0 34 8 15
1
end_operator
begin_operator
unstack b9 b19
0
4
0 17 0 21
0 2 -1 0
0 39 0 1
0 34 9 15
1
end_operator
begin_operator
unstack b9 b20
0
4
0 17 0 21
0 32 -1 0
0 39 0 1
0 34 10 15
1
end_operator
begin_operator
unstack b9 b4
0
4
0 17 0 21
0 14 -1 0
0 39 0 1
0 34 11 15
1
end_operator
begin_operator
unstack b9 b7
0
4
0 17 0 21
0 6 -1 0
0 39 0 1
0 34 12 15
1
end_operator
begin_operator
unstack b9 b8
0
4
0 17 0 21
0 7 -1 0
0 39 0 1
0 34 13 15
1
end_operator
0
