begin_version
3
end_version
begin_metric
0
end_metric
50
begin_variable
var0
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var2
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var1
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var5
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var3
-1
2
Atom clear(b25)
NegatedAtom clear(b25)
end_variable
begin_variable
var6
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var4
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var7
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var8
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var9
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var11
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var10
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var12
-1
2
Atom clear(b22)
NegatedAtom clear(b22)
end_variable
begin_variable
var13
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var16
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var17
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var14
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var15
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var19
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var18
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var20
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var21
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var22
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var23
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var24
-1
25
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b11)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b25)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
end_variable
begin_variable
var26
-1
4
Atom on(b15, b2)
Atom on(b15, b24)
Atom on-table(b15)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom on(b25, b11)
Atom on(b25, b9)
Atom on-table(b25)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b8, b12)
Atom on(b8, b7)
<none of those>
end_variable
begin_variable
var42
-1
3
Atom on(b1, b21)
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var44
-1
3
Atom on(b18, b4)
Atom on-table(b18)
<none of those>
end_variable
begin_variable
var46
-1
4
Atom on(b21, b1)
Atom on(b21, b5)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var47
-1
3
Atom on(b9, b3)
Atom on-table(b9)
<none of those>
end_variable
begin_variable
var49
-1
3
Atom on(b12, b13)
Atom on-table(b12)
<none of those>
end_variable
begin_variable
var50
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var29
-1
16
Atom on(b11, b14)
Atom on(b11, b15)
Atom on(b11, b17)
Atom on(b11, b18)
Atom on(b11, b19)
Atom on(b11, b20)
Atom on(b11, b21)
Atom on(b11, b22)
Atom on(b11, b23)
Atom on(b11, b25)
Atom on(b11, b4)
Atom on(b11, b6)
Atom on(b11, b7)
Atom on(b11, b8)
Atom on-table(b11)
<none of those>
end_variable
begin_variable
var30
-1
16
Atom on(b13, b10)
Atom on(b13, b11)
Atom on(b13, b14)
Atom on(b13, b15)
Atom on(b13, b16)
Atom on(b13, b18)
Atom on(b13, b19)
Atom on(b13, b2)
Atom on(b13, b20)
Atom on(b13, b21)
Atom on(b13, b25)
Atom on(b13, b4)
Atom on(b13, b6)
Atom on(b13, b9)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var33
-1
16
Atom on(b19, b1)
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b17)
Atom on(b19, b2)
Atom on(b19, b21)
Atom on(b19, b23)
Atom on(b19, b25)
Atom on(b19, b4)
Atom on(b19, b6)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var36
-1
16
Atom on(b4, b13)
Atom on(b4, b14)
Atom on(b4, b16)
Atom on(b4, b17)
Atom on(b4, b18)
Atom on(b4, b19)
Atom on(b4, b21)
Atom on(b4, b22)
Atom on(b4, b23)
Atom on(b4, b5)
Atom on(b4, b6)
Atom on(b4, b7)
Atom on(b4, b8)
Atom on(b4, b9)
Atom on-table(b4)
<none of those>
end_variable
begin_variable
var37
-1
16
Atom on(b7, b15)
Atom on(b7, b16)
Atom on(b7, b17)
Atom on(b7, b2)
Atom on(b7, b20)
Atom on(b7, b21)
Atom on(b7, b22)
Atom on(b7, b23)
Atom on(b7, b3)
Atom on(b7, b4)
Atom on(b7, b5)
Atom on(b7, b6)
Atom on(b7, b8)
Atom on(b7, b9)
Atom on-table(b7)
<none of those>
end_variable
begin_variable
var35
-1
17
Atom on(b3, b10)
Atom on(b3, b11)
Atom on(b3, b13)
Atom on(b3, b15)
Atom on(b3, b16)
Atom on(b3, b18)
Atom on(b3, b19)
Atom on(b3, b20)
Atom on(b3, b22)
Atom on(b3, b23)
Atom on(b3, b25)
Atom on(b3, b4)
Atom on(b3, b5)
Atom on(b3, b7)
Atom on(b3, b9)
Atom on-table(b3)
<none of 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




0 8 0 1
0 5 -1 0
0 39 14 16
1
end_operator
begin_operator
unstack b4 b13
0
4
0 24 0 19
0 10 -1 0
0 15 0 1
0 37 0 15
1
end_operator
begin_operator
unstack b4 b16
0
4
0 24 0 19
0 23 -1 0
0 15 0 1
0 37 2 15
1
end_operator
begin_operator
unstack b4 b17
0
4
0 24 0 19
0 21 -1 0
0 15 0 1
0 37 3 15
1
end_operator
begin_operator
unstack b4 b18
0
4
0 24 0 19
0 3 -1 0
0 15 0 1
0 37 4 15
1
end_operator
begin_operator
unstack b4 b19
0
4
0 24 0 19
0 17 -1 0
0 15 0 1
0 37 5 15
1
end_operator
begin_operator
unstack b4 b21
0
4
0 24 0 19
0 7 -1 0
0 15 0 1
0 37 6 15
1
end_operator
begin_operator
unstack b4 b22
0
4
0 24 0 19
0 12 -1 0
0 15 0 1
0 37 7 15
1
end_operator
begin_operator
unstack b4 b23
0
4
0 24 0 19
0 22 -1 0
0 15 0 1
0 37 8 15
1
end_operator
begin_operator
unstack b4 b5
0
4
0 24 0 19
0 15 0 1
0 13 -1 0
0 37 9 15
1
end_operator
begin_operator
unstack b4 b6
0
4
0 24 0 19
0 15 0 1
0 20 -1 0
0 37 10 15
1
end_operator
begin_operator
unstack b4 b7
0
4
0 24 0 19
0 15 0 1
0 14 -1 0
0 37 11 15
1
end_operator
begin_operator
unstack b4 b8
0
4
0 24 0 19
0 15 0 1
0 2 -1 0
0 37 12 15
1
end_operator
begin_operator
unstack b4 b9
0
4
0 24 0 19
0 15 0 1
0 5 -1 0
0 37 13 15
1
end_operator
begin_operator
unstack b5 b11
0
4
0 24 0 20
0 11 -1 0
0 13 0 1
0 44 0 18
1
end_operator
begin_operator
unstack b5 b13
0
4
0 24 0 20
0 10 -1 0
0 13 0 1
0 44 1 18
1
end_operator
begin_operator
unstack b5 b14
0
4
0 24 0 20
0 16 -1 0
0 13 0 1
0 44 2 18
1
end_operator
begin_operator
unstack b5 b15
0
4
0 24 0 20
0 6 -1 0
0 13 0 1
0 44 3 18
1
end_operator
begin_operator
unstack b5 b16
0
4
0 24 0 20
0 23 -1 0
0 13 0 1
0 44 4 18
1
end_operator
begin_operator
unstack b5 b18
0
4
0 24 0 20
0 3 -1 0
0 13 0 1
0 44 5 18
1
end_operator
begin_operator
unstack b5 b19
0
4
0 24 0 20
0 17 -1 0
0 13 0 1
0 44 6 18
1
end_operator
begin_operator
unstack b5 b2
0
4
0 24 0 20
0 9 -1 0
0 13 0 1
0 44 7 18
1
end_operator
begin_operator
unstack b5 b21
0
4
0 24 0 20
0 7 -1 0
0 13 0 1
0 44 9 18
1
end_operator
begin_operator
unstack b5 b23
0
4
0 24 0 20
0 22 -1 0
0 13 0 1
0 44 10 18
1
end_operator
begin_operator
unstack b5 b25
0
4
0 24 0 20
0 4 -1 0
0 13 0 1
0 44 11 18
1
end_operator
begin_operator
unstack b5 b3
0
4
0 24 0 20
0 8 -1 0
0 13 0 1
0 44 12 18
1
end_operator
begin_operator
unstack b5 b4
0
4
0 24 0 20
0 15 -1 0
0 13 0 1
0 44 13 18
1
end_operator
begin_operator
unstack b5 b6
0
4
0 24 0 20
0 13 0 1
0 20 -1 0
0 44 14 18
1
end_operator
begin_operator
unstack b5 b7
0
4
0 24 0 20
0 13 0 1
0 14 -1 0
0 44 15 18
1
end_operator
begin_operator
unstack b5 b9
0
4
0 24 0 20
0 13 0 1
0 5 -1 0
0 44 16 18
1
end_operator
begin_operator
unstack b6 b10
0
4
0 24 0 21
0 18 -1 0
0 20 0 1
0 41 1 17
1
end_operator
begin_operator
unstack b6 b11
0
4
0 24 0 21
0 11 -1 0
0 20 0 1
0 41 2 17
1
end_operator
begin_operator
unstack b6 b14
0
4
0 24 0 21
0 16 -1 0
0 20 0 1
0 41 3 17
1
end_operator
begin_operator
unstack b6 b15
0
4
0 24 0 21
0 6 -1 0
0 20 0 1
0 41 4 17
1
end_operator
begin_operator
unstack b6 b16
0
4
0 24 0 21
0 23 -1 0
0 20 0 1
0 41 5 17
1
end_operator
begin_operator
unstack b6 b18
0
4
0 24 0 21
0 3 -1 0
0 20 0 1
0 41 6 17
1
end_operator
begin_operator
unstack b6 b2
0
4
0 24 0 21
0 9 -1 0
0 20 0 1
0 41 7 17
1
end_operator
begin_operator
unstack b6 b22
0
4
0 24 0 21
0 12 -1 0
0 20 0 1
0 41 8 17
1
end_operator
begin_operator
unstack b6 b23
0
4
0 24 0 21
0 22 -1 0
0 20 0 1
0 41 9 17
1
end_operator
begin_operator
unstack b6 b24
0
4
0 24 0 21
0 0 -1 0
0 20 0 1
0 41 10 17
1
end_operator
begin_operator
unstack b6 b25
0
4
0 24 0 21
0 4 -1 0
0 20 0 1
0 41 11 17
1
end_operator
begin_operator
unstack b6 b3
0
4
0 24 0 21
0 8 -1 0
0 20 0 1
0 41 12 17
1
end_operator
begin_operator
unstack b6 b7
0
4
0 24 0 21
0 20 0 1
0 14 -1 0
0 41 13 17
1
end_operator
begin_operator
unstack b6 b8
0
4
0 24 0 21
0 20 0 1
0 2 -1 0
0 41 14 17
1
end_operator
begin_operator
unstack b6 b9
0
4
0 24 0 21
0 20 0 1
0 5 -1 0
0 41 15 17
1
end_operator
begin_operator
unstack b7 b15
0
4
0 24 0 22
0 6 -1 0
0 14 0 1
0 38 0 15
1
end_operator
begin_operator
unstack b7 b16
0
4
0 24 0 22
0 23 -1 0
0 14 0 1
0 38 1 15
1
end_operator
begin_operator
unstack b7 b17
0
4
0 24 0 22
0 21 -1 0
0 14 0 1
0 38 2 15
1
end_operator
begin_operator
unstack b7 b2
0
4
0 24 0 22
0 9 -1 0
0 14 0 1
0 38 3 15
1
end_operator
begin_operator
unstack b7 b20
0
4
0 24 0 22
0 19 -1 0
0 14 0 1
0 38 4 15
1
end_operator
begin_operator
unstack b7 b21
0
4
0 24 0 22
0 7 -1 0
0 14 0 1
0 38 5 15
1
end_operator
begin_operator
unstack b7 b23
0
4
0 24 0 22
0 22 -1 0
0 14 0 1
0 38 7 15
1
end_operator
begin_operator
unstack b7 b3
0
4
0 24 0 22
0 8 -1 0
0 14 0 1
0 38 8 15
1
end_operator
begin_operator
unstack b7 b4
0
4
0 24 0 22
0 15 -1 0
0 14 0 1
0 38 9 15
1
end_operator
begin_operator
unstack b7 b5
0
4
0 24 0 22
0 13 -1 0
0 14 0 1
0 38 10 15
1
end_operator
begin_operator
unstack b7 b6
0
4
0 24 0 22
0 20 -1 0
0 14 0 1
0 38 11 15
1
end_operator
begin_operator
unstack b7 b8
0
4
0 24 0 22
0 14 0 1
0 2 -1 0
0 38 12 15
1
end_operator
begin_operator
unstack b7 b9
0
4
0 24 0 22
0 14 0 1
0 5 -1 0
0 38 13 15
1
end_operator
begin_operator
unstack b8 b12
0
4
0 24 0 23
0 33 -1 0
0 2 0 1
0 27 0 2
1
end_operator
0
