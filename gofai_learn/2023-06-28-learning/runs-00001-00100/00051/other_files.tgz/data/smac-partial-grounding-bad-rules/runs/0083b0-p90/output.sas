begin_version
3
end_version
begin_metric
0
end_metric
55
begin_variable
var0
-1
2
Atom on-table(b4)
NegatedAtom on-table(b4)
end_variable
begin_variable
var1
-1
2
Atom clear(b24)
NegatedAtom clear(b24)
end_variable
begin_variable
var2
-1
2
Atom clear(b18)
NegatedAtom clear(b18)
end_variable
begin_variable
var3
-1
2
Atom clear(b8)
NegatedAtom clear(b8)
end_variable
begin_variable
var5
-1
2
Atom clear(b14)
NegatedAtom clear(b14)
end_variable
begin_variable
var4
-1
2
Atom clear(b4)
NegatedAtom clear(b4)
end_variable
begin_variable
var6
-1
2
Atom clear(b20)
NegatedAtom clear(b20)
end_variable
begin_variable
var7
-1
2
Atom clear(b16)
NegatedAtom clear(b16)
end_variable
begin_variable
var9
-1
2
Atom clear(b10)
NegatedAtom clear(b10)
end_variable
begin_variable
var8
-1
2
Atom clear(b1)
NegatedAtom clear(b1)
end_variable
begin_variable
var10
-1
2
Atom clear(b2)
NegatedAtom clear(b2)
end_variable
begin_variable
var11
-1
2
Atom clear(b12)
NegatedAtom clear(b12)
end_variable
begin_variable
var12
-1
2
Atom clear(b27)
NegatedAtom clear(b27)
end_variable
begin_variable
var18
-1
2
Atom clear(b7)
NegatedAtom clear(b7)
end_variable
begin_variable
var13
-1
2
Atom clear(b9)
NegatedAtom clear(b9)
end_variable
begin_variable
var16
-1
2
Atom clear(b19)
NegatedAtom clear(b19)
end_variable
begin_variable
var17
-1
2
Atom clear(b23)
NegatedAtom clear(b23)
end_variable
begin_variable
var14
-1
2
Atom clear(b5)
NegatedAtom clear(b5)
end_variable
begin_variable
var15
-1
2
Atom clear(b6)
NegatedAtom clear(b6)
end_variable
begin_variable
var20
-1
2
Atom clear(b26)
NegatedAtom clear(b26)
end_variable
begin_variable
var19
-1
2
Atom clear(b15)
NegatedAtom clear(b15)
end_variable
begin_variable
var21
-1
2
Atom clear(b3)
NegatedAtom clear(b3)
end_variable
begin_variable
var22
-1
2
Atom clear(b11)
NegatedAtom clear(b11)
end_variable
begin_variable
var23
-1
28
Atom arm-empty()
Atom holding(b1)
Atom holding(b10)
Atom holding(b12)
Atom holding(b13)
Atom holding(b14)
Atom holding(b15)
Atom holding(b16)
Atom holding(b17)
Atom holding(b18)
Atom holding(b19)
Atom holding(b2)
Atom holding(b20)
Atom holding(b21)
Atom holding(b22)
Atom holding(b23)
Atom holding(b24)
Atom holding(b25)
Atom holding(b26)
Atom holding(b27)
Atom holding(b3)
Atom holding(b4)
Atom holding(b5)
Atom holding(b6)
Atom holding(b7)
Atom holding(b8)
Atom holding(b9)
<none of those>
end_variable
begin_variable
var24
-1
3
Atom on(b24, b22)
Atom on-table(b24)
<none of those>
end_variable
begin_variable
var25
-1
3
Atom on(b13, b7)
Atom on-table(b13)
<none of those>
end_variable
begin_variable
var26
-1
3
Atom on(b21, b23)
Atom on-table(b21)
<none of those>
end_variable
begin_variable
var27
-1
4
Atom on(b14, b18)
Atom on(b14, b24)
Atom on-table(b14)
<none of those>
end_variable
begin_variable
var28
-1
3
Atom on(b8, b11)
Atom on-table(b8)
<none of those>
end_variable
begin_variable
var29
-1
3
Atom on(b17, b16)
Atom on-table(b17)
<none of those>
end_variable
begin_variable
var30
-1
2
Atom clear(b17)
NegatedAtom clear(b17)
end_variable
begin_variable
var39
-1
8
Atom on(b16, b13)
Atom on(b16, b18)
Atom on(b16, b19)
Atom on(b16, b21)
Atom on(b16, b24)
Atom on(b16, b9)
Atom on-table(b16)
<none of those>
end_variable
begin_variable
var40
-1
10
Atom on(b20, b13)
Atom on(b20, b14)
Atom on(b20, b16)
Atom on(b20, b18)
Atom on(b20, b21)
Atom on(b20, b22)
Atom on(b20, b4)
Atom on(b20, b6)
Atom on-table(b20)
<none of those>
end_variable
begin_variable
var31
-1
2
Atom clear(b21)
NegatedAtom clear(b21)
end_variable
begin_variable
var32
-1
2
Atom clear(b13)
NegatedAtom clear(b13)
end_variable
begin_variable
var33
-1
19
Atom on(b19, b1)
Atom on(b19, b10)
Atom on(b19, b11)
Atom on(b19, b12)
Atom on(b19, b14)
Atom on(b19, b15)
Atom on(b19, b16)
Atom on(b19, b20)
Atom on(b19, b22)
Atom on(b19, b23)
Atom on(b19, b26)
Atom on(b19, b4)
Atom on(b19, b5)
Atom on(b19, b6)
Atom on(b19, b7)
Atom on(b19, b8)
Atom on(b19, b9)
Atom on-table(b19)
<none of those>
end_variable
begin_variable
var35
-1
19
Atom on(b27, b1)
Atom on(b27, b10)
Atom on(b27, b12)
Atom on(b27, b15)
Atom on(b27, b16)
Atom on(b27, b19)
Atom on(b27, b2)
Atom on(b27, b20)
Atom on(b27, b22)
Atom on(b27, b23)
Atom on(b27, b26)
Atom on(b27, b3)
Atom on(b27, b4)
Atom on(b27, b5)
Atom on(b27, b6)
Atom on(b27, b8)
Atom on(b27, b9)
Atom on-table(b27)
<none of those>
end_variable
begin_variable
var37
-1
19
Atom on(b10, b11)
Atom on(b10, b12)
Atom on(b10, b14)
Atom on(b10, b16)
Atom on(b10, b19)
Atom on(b10, b2)
Atom on(b10, b20)
Atom on(b10, b22)
Atom on(b10, b25)
Atom on(b10, b26)
Atom on(b10, b27)
Atom on(b10, b3)
Atom on(b10, b4)
Atom on(b10, b6)
Atom on(b10, b7)
Atom on(b10, b8)
Atom on(b10, b9)
Atom on-table(b10)
<none of those>
end_variable
begin_variable
var41
-1
19
Atom on(b26, b1)
Atom on(b26, b10)
Atom on(b26, b11)
Atom on(b26, b12)
Atom on(b26, b14)
Atom on(b26, b15)
Atom on(b26, b16)
Atom on(b26, b19)
Atom on(b26, b2)
Atom on(b26, b20)
Atom on(b26, b22)
Atom on(b26, b23)
Atom on(b26, b25)
Atom on(b26, b27)
Atom on(b26, b5)
Atom on(b26, b6)
Atom on(b26, b9)
Atom on-table(b26)
<none of those>
end_variable
begin_variable
var43
-1
19
Atom on(b9, b1)
Atom on(b9, b11)
Atom 




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 





0 45 14 20
1
end_operator
begin_operator
unstack b5 b4
0
4
0 23 0 22
0 5 -1 0
0 17 0 1
0 45 15 20
1
end_operator
begin_operator
unstack b5 b6
0
4
0 23 0 22
0 17 0 1
0 18 -1 0
0 45 16 20
1
end_operator
begin_operator
unstack b5 b7
0
4
0 23 0 22
0 17 0 1
0 13 -1 0
0 45 17 20
1
end_operator
begin_operator
unstack b5 b9
0
4
0 23 0 22
0 17 0 1
0 14 -1 0
0 45 18 20
1
end_operator
begin_operator
unstack b6 b10
0
4
0 23 0 23
0 8 -1 0
0 18 0 1
0 42 0 19
1
end_operator
begin_operator
unstack b6 b11
0
4
0 23 0 23
0 22 -1 0
0 18 0 1
0 42 1 19
1
end_operator
begin_operator
unstack b6 b12
0
4
0 23 0 23
0 11 -1 0
0 18 0 1
0 42 2 19
1
end_operator
begin_operator
unstack b6 b14
0
4
0 23 0 23
0 4 -1 0
0 18 0 1
0 42 3 19
1
end_operator
begin_operator
unstack b6 b15
0
4
0 23 0 23
0 20 -1 0
0 18 0 1
0 42 4 19
1
end_operator
begin_operator
unstack b6 b16
0
4
0 23 0 23
0 7 -1 0
0 18 0 1
0 42 5 19
1
end_operator
begin_operator
unstack b6 b19
0
4
0 23 0 23
0 15 -1 0
0 18 0 1
0 42 6 19
1
end_operator
begin_operator
unstack b6 b20
0
4
0 23 0 23
0 6 -1 0
0 18 0 1
0 42 7 19
1
end_operator
begin_operator
unstack b6 b22
0
4
0 23 0 23
0 53 -1 0
0 18 0 1
0 42 8 19
1
end_operator
begin_operator
unstack b6 b23
0
4
0 23 0 23
0 16 -1 0
0 18 0 1
0 42 9 19
1
end_operator
begin_operator
unstack b6 b25
0
4
0 23 0 23
0 52 -1 0
0 18 0 1
0 42 10 19
1
end_operator
begin_operator
unstack b6 b26
0
4
0 23 0 23
0 19 -1 0
0 18 0 1
0 42 11 19
1
end_operator
begin_operator
unstack b6 b27
0
4
0 23 0 23
0 12 -1 0
0 18 0 1
0 42 12 19
1
end_operator
begin_operator
unstack b6 b3
0
4
0 23 0 23
0 21 -1 0
0 18 0 1
0 42 13 19
1
end_operator
begin_operator
unstack b6 b4
0
4
0 23 0 23
0 5 -1 0
0 18 0 1
0 42 14 19
1
end_operator
begin_operator
unstack b6 b5
0
4
0 23 0 23
0 17 -1 0
0 18 0 1
0 42 15 19
1
end_operator
begin_operator
unstack b6 b7
0
4
0 23 0 23
0 18 0 1
0 13 -1 0
0 42 16 19
1
end_operator
begin_operator
unstack b6 b8
0
4
0 23 0 23
0 18 0 1
0 3 -1 0
0 42 17 19
1
end_operator
begin_operator
unstack b7 b1
0
4
0 23 0 24
0 9 -1 0
0 13 0 1
0 43 0 19
1
end_operator
begin_operator
unstack b7 b10
0
4
0 23 0 24
0 8 -1 0
0 13 0 1
0 43 1 19
1
end_operator
begin_operator
unstack b7 b11
0
4
0 23 0 24
0 22 -1 0
0 13 0 1
0 43 2 19
1
end_operator
begin_operator
unstack b7 b12
0
4
0 23 0 24
0 11 -1 0
0 13 0 1
0 43 3 19
1
end_operator
begin_operator
unstack b7 b14
0
4
0 23 0 24
0 4 -1 0
0 13 0 1
0 43 4 19
1
end_operator
begin_operator
unstack b7 b15
0
4
0 23 0 24
0 20 -1 0
0 13 0 1
0 43 5 19
1
end_operator
begin_operator
unstack b7 b16
0
4
0 23 0 24
0 7 -1 0
0 13 0 1
0 43 6 19
1
end_operator
begin_operator
unstack b7 b19
0
4
0 23 0 24
0 15 -1 0
0 13 0 1
0 43 7 19
1
end_operator
begin_operator
unstack b7 b2
0
4
0 23 0 24
0 10 -1 0
0 13 0 1
0 43 8 19
1
end_operator
begin_operator
unstack b7 b20
0
4
0 23 0 24
0 6 -1 0
0 13 0 1
0 43 9 19
1
end_operator
begin_operator
unstack b7 b22
0
4
0 23 0 24
0 53 -1 0
0 13 0 1
0 43 10 19
1
end_operator
begin_operator
unstack b7 b23
0
4
0 23 0 24
0 16 -1 0
0 13 0 1
0 43 11 19
1
end_operator
begin_operator
unstack b7 b25
0
4
0 23 0 24
0 52 -1 0
0 13 0 1
0 43 12 19
1
end_operator
begin_operator
unstack b7 b26
0
4
0 23 0 24
0 19 -1 0
0 13 0 1
0 43 13 19
1
end_operator
begin_operator
unstack b7 b27
0
4
0 23 0 24
0 12 -1 0
0 13 0 1
0 43 14 19
1
end_operator
begin_operator
unstack b7 b3
0
4
0 23 0 24
0 21 -1 0
0 13 0 1
0 43 15 19
1
end_operator
begin_operator
unstack b7 b5
0
4
0 23 0 24
0 17 -1 0
0 13 0 1
0 43 16 19
1
end_operator
begin_operator
unstack b7 b9
0
4
0 23 0 24
0 13 0 1
0 14 -1 0
0 43 17 19
1
end_operator
begin_operator
unstack b8 b11
0
4
0 23 0 25
0 22 -1 0
0 3 0 1
0 28 0 2
1
end_operator
begin_operator
unstack b9 b1
0
4
0 23 0 26
0 9 -1 0
0 14 0 1
0 39 0 18
1
end_operator
begin_operator
unstack b9 b11
0
4
0 23 0 26
0 22 -1 0
0 14 0 1
0 39 1 18
1
end_operator
begin_operator
unstack b9 b14
0
4
0 23 0 26
0 4 -1 0
0 14 0 1
0 39 2 18
1
end_operator
begin_operator
unstack b9 b15
0
4
0 23 0 26
0 20 -1 0
0 14 0 1
0 39 3 18
1
end_operator
begin_operator
unstack b9 b16
0
4
0 23 0 26
0 7 -1 0
0 14 0 1
0 39 4 18
1
end_operator
begin_operator
unstack b9 b19
0
4
0 23 0 26
0 15 -1 0
0 14 0 1
0 39 5 18
1
end_operator
begin_operator
unstack b9 b2
0
4
0 23 0 26
0 10 -1 0
0 14 0 1
0 39 6 18
1
end_operator
begin_operator
unstack b9 b20
0
4
0 23 0 26
0 6 -1 0
0 14 0 1
0 39 7 18
1
end_operator
begin_operator
unstack b9 b22
0
4
0 23 0 26
0 53 -1 0
0 14 0 1
0 39 8 18
1
end_operator
begin_operator
unstack b9 b25
0
4
0 23 0 26
0 52 -1 0
0 14 0 1
0 39 9 18
1
end_operator
begin_operator
unstack b9 b26
0
4
0 23 0 26
0 19 -1 0
0 14 0 1
0 39 10 18
1
end_operator
begin_operator
unstack b9 b27
0
4
0 23 0 26
0 12 -1 0
0 14 0 1
0 39 11 18
1
end_operator
begin_operator
unstack b9 b3
0
4
0 23 0 26
0 21 -1 0
0 14 0 1
0 39 12 18
1
end_operator
begin_operator
unstack b9 b4
0
4
0 23 0 26
0 5 -1 0
0 14 0 1
0 39 13 18
1
end_operator
begin_operator
unstack b9 b5
0
4
0 23 0 26
0 17 -1 0
0 14 0 1
0 39 14 18
1
end_operator
begin_operator
unstack b9 b6
0
4
0 23 0 26
0 18 -1 0
0 14 0 1
0 39 15 18
1
end_operator
begin_operator
unstack b9 b7
0
4
0 23 0 26
0 13 -1 0
0 14 0 1
0 39 16 18
1
end_operator
0
