%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% modes:
:- discontiguous('ini:at_kitchen_bread'/2).
:- discontiguous('goal:at_kitchen_bread'/2).
:- modeb(*, 'ini:at_kitchen_bread'(+'type:object', +task_id)).
:- modeb(*, 'goal:at_kitchen_bread'(+'type:object', +task_id)).
:- discontiguous('ini:at_kitchen_content'/2).
:- discontiguous('goal:at_kitchen_content'/2).
:- modeb(*, 'ini:at_kitchen_content'(+'type:object', +task_id)).
:- modeb(*, 'goal:at_kitchen_content'(+'type:object', +task_id)).
:- discontiguous('ini:at_kitchen_sandwich'/2).
:- discontiguous('goal:at_kitchen_sandwich'/2).
:- modeb(*, 'ini:at_kitchen_sandwich'(+'type:object', +task_id)).
:- modeb(*, 'goal:at_kitchen_sandwich'(+'type:object', +task_id)).
:- discontiguous('ini:no_gluten_bread'/2).
:- discontiguous('goal:no_gluten_bread'/2).
:- modeb(*, 'ini:no_gluten_bread'(+'type:object', +task_id)).
:- modeb(*, 'goal:no_gluten_bread'(+'type:object', +task_id)).
:- discontiguous('ini:no_gluten_content'/2).
:- discontiguous('goal:no_gluten_content'/2).
:- modeb(*, 'ini:no_gluten_content'(+'type:object', +task_id)).
:- modeb(*, 'goal:no_gluten_content'(+'type:object', +task_id)).
:- discontiguous('ini:ontray'/3).
:- discontiguous('goal:ontray'/3).
:- modeb(*, 'ini:ontray'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:ontray'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:ontray'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:ontray'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:no_gluten_sandwich'/2).
:- discontiguous('goal:no_gluten_sandwich'/2).
:- modeb(*, 'ini:no_gluten_sandwich'(+'type:object', +task_id)).
:- modeb(*, 'goal:no_gluten_sandwich'(+'type:object', +task_id)).
:- discontiguous('ini:allergic_gluten'/2).
:- discontiguous('goal:allergic_gluten'/2).
:- modeb(*, 'ini:allergic_gluten'(+'type:object', +task_id)).
:- modeb(*, 'goal:allergic_gluten'(+'type:object', +task_id)).
:- discontiguous('ini:not_allergic_gluten'/2).
:- discontiguous('goal:not_allergic_gluten'/2).
:- modeb(*, 'ini:not_allergic_gluten'(+'type:object', +task_id)).
:- modeb(*, 'goal:not_allergic_gluten'(+'type:object', +task_id)).
:- discontiguous('ini:served'/2).
:- discontiguous('goal:served'/2).
:- modeb(*, 'ini:served'(+'type:object', +task_id)).
:- modeb(*, 'goal:served'(+'type:object', +task_id)).
:- discontiguous('ini:waiting'/3).
:- discontiguous('goal:waiting'/3).
:- modeb(*, 'ini:waiting'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:waiting'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:waiting'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:waiting'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:at'/3).
:- discontiguous('goal:at'/3).
:- modeb(*, 'ini:at'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'goal:at'(+'type:object', -'type:object', +task_id)).
:- modeb(*, 'ini:at'(-'type:object', +'type:object', +task_id)).
:- modeb(*, 'goal:at'(-'type:object', +'type:object', +task_id)).
:- discontiguous('ini:notexist'/2).
:- discontiguous('goal:notexist'/2).
:- modeb(*, 'ini:notexist'(+'type:object', +task_id)).
:- modeb(*, 'goal:notexist'(+'type:object', +task_id)).

% types and constants

:- modeh(1, class(+'type:object', +'type:object', +'type:object', +task_id)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% determinations:
:- determination(class/4, 'ini:at_kitchen_bread'/2).
:- determination(class/4, 'goal:at_kitchen_bread'/2).
:- determination(class/4, 'ini:at_kitchen_content'/2).
:- determination(class/4, 'goal:at_kitchen_content'/2).
:- determination(class/4, 'ini:at_kitchen_sandwich'/2).
:- determination(class/4, 'goal:at_kitchen_sandwich'/2).
:- determination(class/4, 'ini:no_gluten_bread'/2).
:- determination(class/4, 'goal:no_gluten_bread'/2).
:- determination(class/4, 'ini:no_gluten_content'/2).
:- determination(class/4, 'goal:no_gluten_content'/2).
:- determination(class/4, 'ini:ontray'/3).
:- determination(class/4, 'goal:ontray'/3).
:- determination(class/4, 'ini:no_gluten_sandwich'/2).
:- determination(class/4, 'goal:no_gluten_sandwich'/2).
:- determination(class/4, 'ini:allergic_gluten'/2).
:- determination(class/4, 'goal:allergic_gluten'/2).
:- determination(class/4, 'ini:not_allergic_gluten'/2).
:- determination(class/4, 'goal:not_allergic_gluten'/2).
:- determination(class/4, 'ini:served'/2).
:- determination(class/4, 'goal:served'/2).
:- determination(class/4, 'ini:waiting'/3).
:- determination(class/4, 'goal:waiting'/3).
:- determination(class/4, 'ini:at'/3).
:- determination(class/4, 'goal:at'/3).
:- determination(class/4, 'ini:notexist'/2).
:- determination(class/4, 'goal:notexist'/2).

'type:object'('obj:kitchen').
'type:object'('obj:child1').
'type:object'('obj:tray1').
'type:object'('obj:sandw1').
'type:object'('obj:bread1').
'type:object'('obj:content1').
'type:object'('obj:table1').
'type:object'('obj:sandw2').
'type:object'('obj:bread2').
'type:object'('obj:content2').
'type:object'('obj:table2').
'type:object'('obj:tray2').
'type:object'('obj:child2').
'type:object'('obj:sandw3').
'type:object'('obj:bread3').
'type:object'('obj:content3').
'type:ob




 ===== FILE TOO LARGE --> MIDDLE FILE CONTENTS OMITTED ===== 




ay2','obj:kitchen','p47').
'ini:waiting'('obj:child1','obj:table3','p47').
'ini:at_kitchen_bread'('obj:bread6','p47').
'ini:notexist'('obj:sandw6','p47').
'ini:not_allergic_gluten'('obj:child4','p47').
'ini:waiting'('obj:child3','obj:table2','p47').
'ini:no_gluten_bread'('obj:bread1','p47').
'ini:notexist'('obj:sandw8','p47').
'ini:at_kitchen_bread'('obj:bread4','p47').
'ini:no_gluten_content'('obj:content5','p47').
'ini:waiting'('obj:child4','obj:table3','p47').
'ini:at'('obj:tray1','obj:kitchen','p47').
'ini:at_kitchen_content'('obj:content5','p47').
'ini:allergic_gluten'('obj:child3','p47').
'ini:no_gluten_bread'('obj:bread2','p47').
'ini:at_kitchen_bread'('obj:bread1','p47').
'ini:notexist'('obj:sandw4','p47').
'ini:at_kitchen_content'('obj:content1','p47').
'ini:at_kitchen_content'('obj:content2','p47').
'ini:waiting'('obj:child2','obj:table3','p47').
'ini:notexist'('obj:sandw1','p47').
'ini:not_allergic_gluten'('obj:child2','p47').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p47
'goal:served'('obj:child1','p47').
'goal:served'('obj:child2','p47').
'goal:served'('obj:child3','p47').
'goal:served'('obj:child4','p47').
'goal:served'('obj:child5','p47').
'goal:served'('obj:child6','p47').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p48
'ini:no_gluten_bread'('obj:bread6','p48').
'ini:at_kitchen_bread'('obj:bread5','p48').
'ini:no_gluten_content'('obj:content3','p48').
'ini:notexist'('obj:sandw2','p48').
'ini:notexist'('obj:sandw5','p48').
'ini:at_kitchen_content'('obj:content3','p48').
'ini:at_kitchen_bread'('obj:bread3','p48').
'ini:notexist'('obj:sandw3','p48').
'ini:waiting'('obj:child5','obj:table3','p48').
'ini:at_kitchen_bread'('obj:bread2','p48').
'ini:notexist'('obj:sandw7','p48').
'ini:at_kitchen_content'('obj:content4','p48').
'ini:allergic_gluten'('obj:child2','p48').
'ini:waiting'('obj:child6','obj:table2','p48').
'ini:at_kitchen_content'('obj:content6','p48').
'ini:not_allergic_gluten'('obj:child5','p48').
'ini:at'('obj:tray2','obj:kitchen','p48').
'ini:notexist'('obj:sandw6','p48').
'ini:at_kitchen_bread'('obj:bread6','p48').
'ini:not_allergic_gluten'('obj:child4','p48').
'ini:not_allergic_gluten'('obj:child3','p48').
'ini:notexist'('obj:sandw8','p48').
'ini:allergic_gluten'('obj:child6','p48').
'ini:at_kitchen_bread'('obj:bread4','p48').
'ini:no_gluten_content'('obj:content5','p48').
'ini:at'('obj:tray1','obj:kitchen','p48').
'ini:at_kitchen_content'('obj:content5','p48').
'ini:waiting'('obj:child4','obj:table1','p48').
'ini:not_allergic_gluten'('obj:child1','p48').
'ini:waiting'('obj:child1','obj:table2','p48').
'ini:no_gluten_bread'('obj:bread3','p48').
'ini:waiting'('obj:child3','obj:table1','p48').
'ini:at_kitchen_bread'('obj:bread1','p48').
'ini:notexist'('obj:sandw4','p48').
'ini:at_kitchen_content'('obj:content1','p48').
'ini:at_kitchen_content'('obj:content2','p48').
'ini:waiting'('obj:child2','obj:table1','p48').
'ini:notexist'('obj:sandw1','p48').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p48
'goal:served'('obj:child1','p48').
'goal:served'('obj:child2','p48').
'goal:served'('obj:child3','p48').
'goal:served'('obj:child4','p48').
'goal:served'('obj:child5','p48').
'goal:served'('obj:child6','p48').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% init p49
'ini:no_gluten_bread'('obj:bread6','p49').
'ini:at_kitchen_bread'('obj:bread5','p49').
'ini:no_gluten_content'('obj:content3','p49').
'ini:notexist'('obj:sandw2','p49').
'ini:notexist'('obj:sandw5','p49').
'ini:at_kitchen_content'('obj:content3','p49').
'ini:at_kitchen_bread'('obj:bread3','p49').
'ini:notexist'('obj:sandw3','p49').
'ini:waiting'('obj:child5','obj:table1','p49').
'ini:not_allergic_gluten'('obj:child6','p49').
'ini:at_kitchen_bread'('obj:bread2','p49').
'ini:notexist'('obj:sandw7','p49').
'ini:no_gluten_content'('obj:content4','p49').
'ini:waiting'('obj:child4','obj:table2','p49').
'ini:at_kitchen_content'('obj:content4','p49').
'ini:waiting'('obj:child6','obj:table2','p49').
'ini:at_kitchen_content'('obj:content6','p49').
'ini:at'('obj:tray2','obj:kitchen','p49').
'ini:notexist'('obj:sandw6','p49').
'ini:at_kitchen_bread'('obj:bread6','p49').
'ini:waiting'('obj:child1','obj:table1','p49').
'ini:not_allergic_gluten'('obj:child3','p49').
'ini:notexist'('obj:sandw8','p49').
'ini:at_kitchen_bread'('obj:bread4','p49').
'ini:at'('obj:tray1','obj:kitchen','p49').
'ini:at_kitchen_content'('obj:content5','p49').
'ini:allergic_gluten'('obj:child5','p49').
'ini:not_allergic_gluten'('obj:child1','p49').
'ini:allergic_gluten'('obj:child4','p49').
'ini:waiting'('obj:child3','obj:table1','p49').
'ini:no_gluten_bread'('obj:bread2','p49').
'ini:at_kitchen_bread'('obj:bread1','p49').
'ini:notexist'('obj:sandw4','p49').
'ini:at_kitchen_content'('obj:content1','p49').
'ini:at_kitchen_content'('obj:content2','p49').
'ini:waiting'('obj:child2','obj:table3','p49').
'ini:notexist'('obj:sandw1','p49').
'ini:not_allergic_gluten'('obj:child2','p49').
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% goal p49
'goal:served'('obj:child1','p49').
'goal:served'('obj:child2','p49').
'goal:served'('obj:child3','p49').
'goal:served'('obj:child4','p49').
'goal:served'('obj:child5','p49').
'goal:served'('obj:child6','p49').
